extends Module

var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")

func _init():
	id = "WintersRabbitSpeciesUpdate"
	author = "Code: Fantos Idea/Graphics: Max-Maxou"

	bodyparts = [
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitEars1.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitEars2.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitEars3.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitHead.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitLegs.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitTail1.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitTail2.gd",
	]

	if (RAT_ArchetypeLoad == false):
		species = [
			"res://Modules/WintersRabbitSpeciesUpdate/RabbitFluffy.gd"
		]
	else:
		species = [
			"res://Modules/WintersRabbitSpeciesUpdate/Rabbit.gd"
		]
