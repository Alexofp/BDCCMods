extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"
func _init():
	visibleName = "Scaled nipple breasts"
	id = "scaledbreastsnipple"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastNipples/ScaledBreastNippleFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastNipples/ScaledBreastNipple.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
