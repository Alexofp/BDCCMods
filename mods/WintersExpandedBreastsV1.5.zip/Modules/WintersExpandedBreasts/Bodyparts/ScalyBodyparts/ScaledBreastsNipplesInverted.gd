extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Scaled inverted nipple breasts"
	id = "scaledbreastsnippleinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastNipplesInverted/ScaledBreastNippleInvertedFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastNipplesInverted/ScaledBreastNippleInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
