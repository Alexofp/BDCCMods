extends Module

var breastOptions : Dictionary = {
	# breastid: rat option
}

func _init():
	id = "WintersExpandedBreasts"
	author = "Avery Winters & Selinoccino (Assets by Anon)"

	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/BaseBDCC/")

func register(): # best to do it here
	var modules = GlobalRegistry.getModules().keys() # to avoid calling too many times, and also only getting the keys for performance reasons kinda
	
	var maleBodyparts : Array = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/MaleBodyparts/Base/")
	
	#Bodyparts
	if ("WintersFluffyBodyparts" in modules):
		bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/"))
		
		bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/"))
		
		maleBodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/MaleBodyparts/Fluffy/"))
		maleBodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/MaleBodyparts/Scaly/"))
	
	.register()
	for maleb in maleBodyparts:
		GlobalRegistry.registerBodypart(maleb)
	
	if "Hypertus" in modules:
		var c : Reference = GlobalRegistry.getModule("WintersCoreModule").createCodegen()
		
		var temp : String = "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable"
		
		c.formatId("%shyperable").formatName("Hyper %s").setTraits({"Hyperable": true }).setExtend('"%s.gd"' % temp, '"{OLD_PATH}Hyper.gd"').formatPath("res://Modules/WintersExpandedBreasts/Bodyparts/Hyperable/%s.gd")
		
		c.do(bodyparts, true, false, true)
		
		c.setExtend("", '"res://Modules/WintersExpandedBreasts/Bodyparts/Hyperable/{OLD_FILE}.gd"')
		c.do(maleBodyparts, true, false, true)
#		c.formatName("%shyperable").doPartSkins(partSkins)

func isBreastEnabled(bid:String) -> bool:
	var option = breastOptions.get(bid)
	if option:
		return option.getValue()
	
	return getDefaultForBreast(bid)

func getDefaultForBreast(bid:String) -> bool:
	var bpo = GlobalRegistry.getBodypartRef(bid)
	if !bpo:
		return false
	return bpo.isWinteredDefault() if bpo.has_method("isWinteredDefault") else false

func RatConfigure(ratconf):
	ratconf.overrideModConfigName(id, "Winter's Expanded Breasts")
	
	for thing in ["Vanilla", "Fluffy", "Scaled"]:
		for t in [" (Feminine)", " (Masculine)"]:
			ratconf.addCategory(id, thing+t)
	
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Breasts)
	for bid in all:
		var bp = GlobalRegistry.getBodypartRef(bid)
		if bp.has_method("isWinterable") && bp.isWinterable():
			var disp : String = bp.visibleName if bp else ("Error (%s)" % bid)
			disp[0] = disp[0].to_upper()
			var desc : String = "Created by: %s\n\nEnable or disable this dick" % (bp.author if bp && bp.author else "(unknown)")
			
			var cat : String = getCategoryName(bid, bp.getTraits())
			
			breastOptions[bid] = ratconf.addOptionBool(id, bid, cat, disp, desc, getDefaultForBreast(bid))
	

func getCategoryName(bid:String, traits) -> String:
	var v : String = "Vanilla"
	if bid.begins_with("fluff"):
	 v = "Fluffy"
	elif bid.begins_with("scaled"):
		v = "Scaled"
	
	if !(traits and traits.get(PartTrait.BreastsMale, false)):
		v += " (Feminine)"
	else:
		v += " (Masculine)"
	return v
