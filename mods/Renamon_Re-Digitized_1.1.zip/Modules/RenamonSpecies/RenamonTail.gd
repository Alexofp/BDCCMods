extends BodypartTail

func _init():
	visibleName = "Renamon tail"
	id = "renamontail"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonTail/RenamonTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
