extends Module

func _init():
	id = "RenamonSpecies"
	author = "DurenBlake"
	
	bodyparts = [
		"res://Modules/RenamonSpecies/RenamonEars.gd",
		"res://Modules/RenamonSpecies/RenamonHead.gd",
		"res://Modules/RenamonSpecies/RenamonHeadWE.gd",
		"res://Modules/RenamonSpecies/RenamonBody.gd",
		"res://Modules/RenamonSpecies/RenamonArms.gd",
		"res://Modules/RenamonSpecies/RenamonLegs.gd",
		"res://Modules/RenamonSpecies/RenamonTail.gd",
		"res://Modules/RenamonSpecies/RenamonFemaleBreasts.gd",
		"res://Modules/RenamonSpecies/RenamonMaleBreasts.gd",
	]
	species = [
		"res://Modules/RenamonSpecies/Renamon.gd"
	]
