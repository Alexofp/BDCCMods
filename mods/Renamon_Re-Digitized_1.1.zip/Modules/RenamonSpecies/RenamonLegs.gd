extends BodypartLeg

func _init():
	visibleName = "Renamon legs"
	id = "renamonlegs"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonLegs/RenamonLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
