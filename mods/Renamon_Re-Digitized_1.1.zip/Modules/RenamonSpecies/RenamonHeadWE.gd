extends BodypartHead

func _init():
	visibleName = "Renamon head Without Eyes"
	id = "renamonheadwe"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonHeadWE/RenamonHead.tscn"

func getHeadLength():
	return 0.5
