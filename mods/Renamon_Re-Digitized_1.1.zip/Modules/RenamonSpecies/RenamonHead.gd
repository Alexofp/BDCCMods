extends BodypartHead

func _init():
	visibleName = "Renamon head"
	id = "renamonhead"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonHead/RenamonHead.tscn"

func getHeadLength():
	return 0.5
