extends Species

func _init():
	id = "Renamon"
	
func getVisibleName():
	return "Renamon"

func getDefaultLegs(_gender):
	return "renamonlegs"

func getDefaultTail(_gender):
	return "renamontail"

func isPlayable():
	return true

func getDefaultBody(_gender):
	return "renamonbody"
	
func getVisibleDescription():
	return "Cute and tall"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "renamonmalebreasts"
	
	return "renamonfemalebreasts"

func getDefaultHead(_gender):
	return "renamonhead"

func getDefaultArms(_gender):
	return "renamonarms"

func getDefaultEars(_gender):
	return "renamonears"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]

func supportsMane():
	return false
