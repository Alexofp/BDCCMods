extends BodypartArms

func _init():
	visibleName = "Renamon arms"
	id = "renamonarms"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonArms/RenamonArms.tscn"
