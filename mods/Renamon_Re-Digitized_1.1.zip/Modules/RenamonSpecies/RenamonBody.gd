extends BodypartBody

func _init():
	visibleName = "Renamon body"
	id = "renamonbody"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonBody/RenamonBody.tscn"

func getVulgarName() -> String:
	return "renamon body"

func getAVulgarName() -> String:
	return "a renamon body"
