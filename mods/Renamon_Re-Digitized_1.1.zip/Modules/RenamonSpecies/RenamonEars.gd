extends BodypartEars

func _init():
	visibleName = "Renamon ears"
	id = "renamonears"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonEars/RenamonEars.tscn"
