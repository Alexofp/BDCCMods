extends "res://Inventory/Items/UsedCondom.gd"

var sabotaged : bool = false

func getVisibleName():
	return .getVisibleName() + (" (sabotaged)" if sabotaged else "")

func getInventoryGroupName():
	return .getVisibleName()

func getPossibleActions():
	var pa = .getPossibleActions()
	if !sabotaged:
		pa.append({
			"name": "Sabotage",
			"scene": "CS_CondomSabotageScene",
			"description": "Sabotage the condom to increase the chance it breaks next time someone uses it",
			})
	
	return pa

func saveData():
	var d = .saveData()
	d["sabotaged"]=sabotaged
	return d

func loadData(d):
	.loadData(d)
	sabotaged = d.get("sabotaged",false)
