extends Module

func _init():
	id = "RAT_CondomSabotage"
	author = "Selinoccino"
	
	scenes = ["res://Modules/CondomSabotage/CS_CondomSabotageScene.gd"]
	

func postInit() -> void:
	GlobalRegistry.registerItem("res://Modules/CondomSabotage/NewUsedCondom.gd")

func RatConfigure(ratc) -> void:
	ratc.overrideModConfigName(id, "Condom Sabotage (Rat)")
	ratc.addOptionNum(id, "breakChanceMult", "General", "Break Chance Multiplier (%)", "Multiplies a condom's break chance by this value when sabotaged. Caps at 95%.", 300.0).setMin(0).setGreater().setStep(1.0)
