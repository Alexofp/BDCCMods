extends Module

func _init():
	id = "CondomSabotage"
	author = "Selinoccino"
	
	scenes = ["res://Modules/CondomSabotage/CS_CondomSabotageScene.gd"]
	

func postInit() -> void:
	GlobalRegistry.registerItem("res://Modules/CondomSabotage/NewUsedCondom.gd")
