extends "res://Scenes/SceneBase.gd"

var uniqueItemID = ""
var item: ItemBase = null

func _init():
	sceneID = "CS_CondomSabotageScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		uniqueItemID = _args[0]
	
func _reactInit():
	if(GM.pc.hasBoundArms()):
		setState("cant")
		return
	
	if(!uniqueItemID):
		return
		
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
	if(!item):
		return
	

func _run():
	if(state == ""):
		saynn("You sabotage the %s." % item.getVisibleName())
		item.breakChance = clamp((item.breakChance * 3.0), 30, 95)
		item.sabotaged = true
		
		addButton("Continue", "Okay", "endthescene")

	elif(state == "cant"):
		saynn("You can't sabotage the %s with your arms bound." % item.getVisibleName())
		
		addButton("Continue", "Damn", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	setState(_action)

func saveData():
	var data = .saveData()
	
	data["uniqueItemID"] = uniqueItemID
	
	return data
	
func loadData(data):
	.loadData(data)
	
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
