extends PartSkinBase

func _init():
	id = "mouthtail2p1e"
	partID = "mouthtail2"

func getName():
	return "Mouth Tail Pattern 1 Eyes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail2Pattern1E.png"),
	}
