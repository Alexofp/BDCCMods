extends PartSkinBase

func _init():
	id = "mouthtail2p2"
	partID = "mouthtail2"

func getName():
	return "Mouth Tail Pattern 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail2Pattern2.png"),
	}
