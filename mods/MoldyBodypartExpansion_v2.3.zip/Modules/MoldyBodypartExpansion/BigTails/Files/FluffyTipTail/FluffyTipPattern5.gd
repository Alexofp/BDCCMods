extends PartSkinBase

func _init():
	id = "fluffytippattern5"
	partID = "fluffytiptail"

func getName():
	return "Tailbone"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FluffyTipPattern5.png"),
	}
 
