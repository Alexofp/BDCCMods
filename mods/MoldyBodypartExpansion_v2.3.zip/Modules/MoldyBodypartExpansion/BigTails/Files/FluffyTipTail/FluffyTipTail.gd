extends BodypartTail

func _init():
	visibleName = "Fluffy Tip Tail"
	id = "fluffytiptail"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffyTipTail/FluffyTipTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
