extends PartSkinBase

func _init():
	id = "fluffytippattern4"
	partID = "fluffytiptail"

func getName():
	return "Cyberware"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FluffyTipPattern4.png"),
	}
 
