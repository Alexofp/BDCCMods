extends PartSkinBase

func _init():
	id = "fluffytippattern2"
	partID = "fluffytiptail"

func getName():
	return "Cross Pattern"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FluffyTipPattern2.png"),
	}
 
