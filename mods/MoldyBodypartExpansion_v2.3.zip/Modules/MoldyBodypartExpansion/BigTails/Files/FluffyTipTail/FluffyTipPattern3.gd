extends PartSkinBase

func _init():
	id = "fluffytippattern3"
	partID = "fluffytiptail"

func getName():
	return "Ebb and Flow"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FluffyTipPattern3.png"),
	}
 
