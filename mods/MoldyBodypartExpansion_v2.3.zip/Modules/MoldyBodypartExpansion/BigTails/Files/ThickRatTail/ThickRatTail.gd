extends BodypartTail

func _init():
	visibleName = "Thick Rat Tail"
	id = "thickrattail"

func getCompatibleSpecies():
	return ["rat"]

func getLewdSizeAdjective():
	return RNG.pick(["long", "thick"])

func getLewdAdjective():
	return RNG.pick(["furless", "soft", "solid"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ThickRatTail/ThickRatTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
