extends PartSkinBase

func _init():
	id = "thickratpattern2"
	partID = "thickrattail"

func getName():
	return "Sploched"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/OtherTails/ThickRatPattern2.png"),
	}
