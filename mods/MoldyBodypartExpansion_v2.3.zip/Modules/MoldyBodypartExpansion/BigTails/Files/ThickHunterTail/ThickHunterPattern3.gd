extends PartSkinBase

func _init():
	id = "thickhunterpattern3"
	partID = "thickhuntertail"

func getName():
	return "Marooned"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/ThickHunterPattern3.png"),
	}
