extends PartSkinBase

func _init():
	id = "thickhunterpattern2"
	partID = "thickhuntertail"

func getName():
	return "Chaos Stripes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/ThickHunterPattern2.png"),
	}
