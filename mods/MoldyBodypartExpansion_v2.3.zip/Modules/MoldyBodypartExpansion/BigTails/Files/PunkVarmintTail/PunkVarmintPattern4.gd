extends PartSkinBase

func _init():
	id = "punkratpattern4"
	partID = "punkrattail"

func getName():
	return "Watercolor"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/OtherTails/PunkVarmintPattern4.png"),
	}
