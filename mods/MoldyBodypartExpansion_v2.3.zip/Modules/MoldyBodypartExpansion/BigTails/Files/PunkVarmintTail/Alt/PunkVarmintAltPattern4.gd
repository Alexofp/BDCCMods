extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintPattern4.gd"

func _init():
	id = "punkrataltpattern4"
	partID = "punkratalttail"
