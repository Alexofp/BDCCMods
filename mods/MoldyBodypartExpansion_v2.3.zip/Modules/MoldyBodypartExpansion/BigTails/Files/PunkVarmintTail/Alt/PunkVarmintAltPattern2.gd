extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintPattern2.gd"

func _init():
	id = "punkrataltpattern2"
	partID = "punkratalttail"
