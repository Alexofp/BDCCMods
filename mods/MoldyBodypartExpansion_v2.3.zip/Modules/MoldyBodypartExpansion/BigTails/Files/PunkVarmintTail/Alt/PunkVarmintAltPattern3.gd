extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintPattern3.gd"

func _init():
	id = "punkrataltpattern3"
	partID = "punkratalttail"
