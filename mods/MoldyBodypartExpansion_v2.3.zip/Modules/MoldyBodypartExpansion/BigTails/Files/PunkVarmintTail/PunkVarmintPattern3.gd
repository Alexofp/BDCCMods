extends PartSkinBase

func _init():
	id = "punkratpattern3"
	partID = "punkrattail"

func getName():
	return "Battle Scared"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/OtherTails/PunkVarmintPattern3.png"),
	}
