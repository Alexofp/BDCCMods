extends PartSkinBase

func _init():
	id = "punkratpattern2"
	partID = "punkrattail"

func getName():
	return "Underground"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/OtherTails/PunkVarmintPattern2.png"),
	}
