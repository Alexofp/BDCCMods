extends BodypartTail

func _init():
	visibleName = "Punk Varmint Tail"
	id = "punkvarminttail"

func getCompatibleSpecies():
	return ["rat", "possum"]

func getLewdSizeAdjective():
	return RNG.pick(["long", "thick"])

func getLewdAdjective():
	return RNG.pick(["furless", "soft", "solid"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
