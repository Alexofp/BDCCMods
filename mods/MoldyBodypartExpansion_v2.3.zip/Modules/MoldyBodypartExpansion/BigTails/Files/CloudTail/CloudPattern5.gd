extends PartSkinBase

func _init():
	id = "cloudpattern5"
	partID = "cloudtail"

func getName():
	return "Painted"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/CloudPattern5.png"),
	}
