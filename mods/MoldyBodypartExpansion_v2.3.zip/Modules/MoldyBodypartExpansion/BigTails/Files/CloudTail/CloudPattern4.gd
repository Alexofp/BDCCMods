extends PartSkinBase

func _init():
	id = "cloudpattern4"
	partID = "cloudtail"

func getName():
	return "Tie-Dye"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/CloudPattern4.png"),
	}
