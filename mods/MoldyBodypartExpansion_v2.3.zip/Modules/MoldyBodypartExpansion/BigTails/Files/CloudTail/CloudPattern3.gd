extends PartSkinBase

func _init():
	id = "cloudpattern3"
	partID = "cloudtail"

func getName():
	return "Northern Lights"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/CloudPattern3.png"),
	}
