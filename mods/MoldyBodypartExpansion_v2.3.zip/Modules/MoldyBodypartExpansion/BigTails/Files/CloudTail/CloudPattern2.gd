extends PartSkinBase

func _init():
	id = "cloudpattern2"
	partID = "cloudtail"

func getName():
	return "Clouded"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/CloudPattern2.png"),
	}
