extends BodypartTail

func _init():
	visibleName = "Mystic Fox Tail"
	id = "mysticfoxtail"

func getCompatibleSpecies():
	return [Species.Canine]

func getLewdSizeAdjective():
	return RNG.pick(["long", "swirly"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm", "foxy"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/MysticFoxTail/MysticFoxTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
