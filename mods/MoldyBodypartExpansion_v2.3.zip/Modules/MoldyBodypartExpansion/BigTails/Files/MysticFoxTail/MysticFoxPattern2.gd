extends PartSkinBase

func _init():
	id = "mysticfoxpattern2"
	partID = "mysticfoxtail"

func getName():
	return "Feral Tail Pattern 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/OkamiFoxPattern2.png"),
	}
