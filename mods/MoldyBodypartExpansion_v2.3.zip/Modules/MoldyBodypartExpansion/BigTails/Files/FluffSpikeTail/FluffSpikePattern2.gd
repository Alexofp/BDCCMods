extends PartSkinBase

func _init():
	id = "fluffspikepattern2"
	partID = "fluffspiketail"

func getName():
	return "Fluffy Spiked Pattern 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FluffySpikedPattern2.png"),
	}
