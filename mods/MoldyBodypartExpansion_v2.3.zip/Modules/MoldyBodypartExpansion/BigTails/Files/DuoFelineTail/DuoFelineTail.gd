extends BodypartTail

func _init():
	visibleName = "Double Feline Tail"
	id = "duofelinetail"

func getCompatibleSpecies():
	return [Species.Feline]

func getLewdSizeAdjective():
	return RNG.pick(["long", "twin"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/DuoFelineTail/DuoFelineTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
