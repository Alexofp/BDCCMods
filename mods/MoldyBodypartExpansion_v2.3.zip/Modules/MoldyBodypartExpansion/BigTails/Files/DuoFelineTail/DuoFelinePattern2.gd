extends PartSkinBase

func _init():
	id = "duofelinepatter2"
	partID = "duofelinetail"

func getName():
	return "Heart Pattern"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FelineTails/DuoFelinePattern2.png"),
	}
