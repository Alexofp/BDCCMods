extends PartSkinBase

func _init():
	id = "bushyfoxpattern8"
	partID = "bushyfoxtail"

func getName():
	return "Speed Stripe"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern8.png"),
	}
