extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern2.gd" 

func _init():
	id = "bushykitpattern2"
	partID = "bushykittail"
