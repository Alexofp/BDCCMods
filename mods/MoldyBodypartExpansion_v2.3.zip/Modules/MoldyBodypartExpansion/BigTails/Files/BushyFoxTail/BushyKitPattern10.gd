extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern10.gd"

func _init():
	id = "bushykitpattern10"
	partID = "bushykittail"
