extends PartSkinBase

func _init():
	id = "bushyfoxpattern2"
	partID = "bushyfoxtail"

func getName():
	return "Spikey Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern2.png"),
	}
