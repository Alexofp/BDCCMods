extends PartSkinBase

func _init():
	id = "bushyfoxpattern9"
	partID = "bushyfoxtail"

func getName():
	return "Blend"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern9.png"),
	}
