extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern4.gd"

func _init():
	id = "bushykitpattern4"
	partID = "bushykittail"
