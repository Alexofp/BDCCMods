extends PartSkinBase

func _init():
	id = "bushyfoxpattern6"
	partID = "bushyfoxtail"

func getName():
	return "Flow Fox"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern6.png"),
	}
