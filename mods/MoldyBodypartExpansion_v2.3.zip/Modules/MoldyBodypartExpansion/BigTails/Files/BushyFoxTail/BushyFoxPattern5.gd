extends PartSkinBase

func _init():
	id = "bushyfoxpattern5"
	partID = "bushyfoxtail"

func getName():
	return "\"Five-Tails\""

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern5.png"),
	}
