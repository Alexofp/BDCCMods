extends PartSkinBase

func _init():
	id = "bushyfoxpattern7"
	partID = "bushyfoxtail"

func getName():
	return "Striped Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern7.png"),
	}
