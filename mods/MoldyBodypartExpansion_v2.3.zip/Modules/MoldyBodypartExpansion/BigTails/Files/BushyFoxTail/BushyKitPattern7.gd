extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern7.gd"

func _init():
	id = "bushykitpattern7"
	partID = "bushykittail"
