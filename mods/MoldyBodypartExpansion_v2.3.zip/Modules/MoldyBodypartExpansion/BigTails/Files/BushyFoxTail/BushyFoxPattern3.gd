extends PartSkinBase

func _init():
	id = "bushyfoxpattern3"
	partID = "bushyfoxtail"

func getName():
	return "Dipstick"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern3.png"),
	}
