extends PartSkinBase

func _init():
	id = "bushyfoxpattern11"
	partID = "bushyfoxtail"

func getName():
	return "Tricolor"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern11.png"),
	}
