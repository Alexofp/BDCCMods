extends PartSkinBase

func _init():
	id = "bushyfoxpattern10"
	partID = "bushyfoxtail"

func getName():
	return "True Fox"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern10.png"),
	}
