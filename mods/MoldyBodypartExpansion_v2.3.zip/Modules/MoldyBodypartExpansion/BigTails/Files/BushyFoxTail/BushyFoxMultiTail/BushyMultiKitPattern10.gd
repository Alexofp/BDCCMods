extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern10.gd"

func _init():
	id = "bushymultikitpattern10"
	partID = "bushymultikittail"
