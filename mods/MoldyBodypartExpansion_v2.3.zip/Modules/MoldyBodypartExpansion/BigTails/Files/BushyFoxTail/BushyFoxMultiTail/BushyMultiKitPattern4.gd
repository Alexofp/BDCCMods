extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern4.gd"

func _init():
	id = "bushymultikitpattern4"
	partID = "bushymultikittail"
