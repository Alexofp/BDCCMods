extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern2.gd" 

func _init():
	id = "bushymultikitpattern2"
	partID = "bushymultikittail"
