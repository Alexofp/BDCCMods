extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern9.gd"

func _init():
	id = "bushymultikitpattern9"
	partID = "bushymultikittail"
