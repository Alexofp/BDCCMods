extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern11.gd"

func _init():
	id = "bushymultikitpattern11"
	partID = "bushymultikittail"
