extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern6.gd"

func _init():
	id = "bushymultikitpattern6"
	partID = "bushymultikittail"
