extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern5.gd"

func _init():
	id = "bushymultikitpattern5"
	partID = "bushymultikittail"
