extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern8.gd"

func _init():
	id = "bushymultikitpattern8"
	partID = "bushymultikittail"
