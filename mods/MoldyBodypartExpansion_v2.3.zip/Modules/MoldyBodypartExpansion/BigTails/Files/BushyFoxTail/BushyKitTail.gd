extends BodypartTail

func _init():
	visibleName = "Bushy Kitsune Tail"
	id = "bushykittail"

func getCompatibleSpecies():
	return [Species.Canine]

func getLewdSizeAdjective():
	return RNG.pick(["long", "big", "multi"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm", "foxy"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
