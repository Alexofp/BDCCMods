extends "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern3.gd"

func _init():
	id = "bushykitpattern3"
	partID = "bushykittail"
