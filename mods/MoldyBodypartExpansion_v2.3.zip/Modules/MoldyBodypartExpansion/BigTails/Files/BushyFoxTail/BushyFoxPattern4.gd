extends PartSkinBase

func _init():
	id = "bushyfoxpattern4"
	partID = "bushyfoxtail"

func getName():
	return "Dipstick Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FoxTails/BushyFoxPattern4.png"),
	}
