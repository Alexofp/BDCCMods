extends BodypartTail

func _init():
	visibleName = "Bushy Fox Tail"
	id = "bushyfoxtail"

func getCompatibleSpecies():
	return [Species.Canine]

func getLewdSizeAdjective():
	return RNG.pick(["long", "big"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm", "foxy"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
