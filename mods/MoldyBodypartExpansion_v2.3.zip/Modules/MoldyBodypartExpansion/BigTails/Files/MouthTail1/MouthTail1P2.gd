extends PartSkinBase

func _init():
	id = "mouthtail1p2"
	partID = "mouthtail1"

func getName():
	return "Mouth Tail Pattern 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail1Pattern2.png"),
	}
