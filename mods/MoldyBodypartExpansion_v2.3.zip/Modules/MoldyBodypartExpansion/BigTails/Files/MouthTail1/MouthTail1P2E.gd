extends PartSkinBase

func _init():
	id = "mouthtail1p2e"
	partID = "mouthtail1"

func getName():
	return "Mouth Tail Pattern 2 Eyes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail1Pattern2E.png"),
	}
