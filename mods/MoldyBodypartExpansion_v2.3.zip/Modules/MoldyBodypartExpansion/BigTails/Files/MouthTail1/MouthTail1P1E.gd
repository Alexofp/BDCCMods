extends PartSkinBase

func _init():
	id = "mouthtail1p1e"
	partID = "mouthtail1"

func getName():
	return "Mouth Tail Pattern 1 Eyes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail1Pattern1E.png"),
	}
