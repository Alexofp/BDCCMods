extends PartSkinBase

func _init():
	id = "fluffballpattern2"
	partID = "fluffballtail"

func getName():
	return "Spotted"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/FluffballPattern2.png"),
	}
