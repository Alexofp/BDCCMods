extends PartSkinBase

func _init():
	id = "fluffballpattern4"
	partID = "fluffballtail"

func getName():
	return "Tri-Color"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/FluffballPattern4.png"),
	}
