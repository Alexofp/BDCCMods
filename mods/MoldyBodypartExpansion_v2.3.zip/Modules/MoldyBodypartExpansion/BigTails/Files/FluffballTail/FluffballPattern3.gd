extends PartSkinBase

func _init():
	id = "fluffballpattern3"
	partID = "fluffballtail"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/FluffballPattern3.png"),
	}
