extends PartSkinBase

func _init():
	id = "puffytailpattern3"
	partID = "puffywolftail"

func getName():
	return "Puffy Tail Pattern 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/PuffyWolfPattern3.png"),
	}
