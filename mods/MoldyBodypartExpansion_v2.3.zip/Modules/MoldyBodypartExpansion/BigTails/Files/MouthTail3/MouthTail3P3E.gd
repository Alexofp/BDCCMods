extends PartSkinBase

func _init():
	id = "mouthtail3p3e"
	partID = "mouthtail3"

func getName():
	return "Faded w/ Eyes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail3Pattern3E.png"),
	}
