extends PartSkinBase

func _init():
	id = "mouthtail3p1e"
	partID = "mouthtail3"

func getName():
	return "Feral Marks w/ Eyes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail3Pattern1E.png"),
	}
