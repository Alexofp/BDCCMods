extends PartSkinBase

func _init():
	id = "mouthtail3p3"
	partID = "mouthtail3"

func getName():
	return "Faded"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail3Pattern3.png"),
	}
