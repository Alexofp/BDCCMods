extends PartSkinBase

func _init():
	id = "mouthtail3p2"
	partID = "mouthtail3"

func getName():
	return "Dotted Stripes"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MouthTails/MouthTail3Pattern2.png"),
	}
