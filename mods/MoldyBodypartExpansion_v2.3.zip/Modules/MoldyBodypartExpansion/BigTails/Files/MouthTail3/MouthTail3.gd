extends BodypartTail

func _init():
	visibleName = "Mouth Tail 3"
	id = "mouthtail3"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["wiggling", "fluffy", "panting"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
