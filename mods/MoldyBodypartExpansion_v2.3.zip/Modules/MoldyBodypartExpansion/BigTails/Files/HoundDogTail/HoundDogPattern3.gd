extends PartSkinBase

func _init():
	id = "hounddogpattern3"
	partID = "hounddogtail"

func getName():
	return "Frosty"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/HoundDogPattern3.png"),
	}
