extends PartSkinBase

func _init():
	id = "hounddogpattern2"
	partID = "hounddogtail"

func getName():
	return "Smudged Alt"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/CanineTails/HoundDogPattern2.png"),
	}
