extends BodypartTail

func _init():
	visibleName = "Thresher Shark Tail"
	id = "threshersharktail"

func getCompatibleSpecies():
	return ["shark"]

func getLewdSizeAdjective():
	return RNG.pick(["long", "finned"])

func getLewdAdjective():
	return RNG.pick(["smooth", "silky", "moist"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ThresherSharkTail/ThresherSharkTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
