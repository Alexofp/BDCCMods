extends PartSkinBase

func _init():
	id = "threshersharkpattern2"
	partID = "threshersharktail"

func getName():
	return "Tiger Pattern"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/SharkTails/ThresherSharkPattern2.png"),
	}
