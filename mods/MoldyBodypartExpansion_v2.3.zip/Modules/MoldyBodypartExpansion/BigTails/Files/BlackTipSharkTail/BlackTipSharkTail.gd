extends BodypartTail

func _init():
	visibleName = "Black Tipped Shark Tail"
	id = "blacktipsharktail"

func getCompatibleSpecies():
	return ["shark"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["selachian", "finned"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/BlackTipSharkTail/BlackTipSharkTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
