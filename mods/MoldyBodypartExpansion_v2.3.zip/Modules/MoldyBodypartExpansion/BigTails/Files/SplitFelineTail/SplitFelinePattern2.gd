extends PartSkinBase

func _init():
	id = "splitfelinepattern2"
	partID = "splitfelinetail"

func getName():
	return "Duo Leopard"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/FelineTails/SplitFelinePattern2.png"),
	}
