extends BodypartTail

func _init():
	visibleName = "Split Feline Tail"
	id = "splitfelinetail"

func getCompatibleSpecies():
	return [Species.Feline]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["soft", "fluffy", "split"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/SplitFelineTail/SplitFelineTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
