extends BodypartTail

func _init():
	visibleName = "Flowerbloom Tail"
	id = "flowerbloomtail"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdSizeAdjective():
	return RNG.pick(["long", "bushy"])

func getLewdAdjective():
	return RNG.pick(["soft", "knotty", "flower secented"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/FlowerbloomTail/FlowerbloomTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
