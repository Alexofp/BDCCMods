extends PartSkinBase

func _init():
	id = "flowerbloompattern3"
	partID = "flowerbloomtail"

func getName():
	return "Swirly"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FlowerbloomPattern3.png"),
	}
 
