extends PartSkinBase

func _init():
	id = "flowerbloompattern4"
	partID = "flowerbloomtail"

func getName():
	return "Sakura"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FlowerbloomPattern4.png"),
	}
 
