extends PartSkinBase

func _init():
	id = "flowerbloompattern2"
	partID = "flowerbloomtail"

func getName():
	return "Shaded"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/BigTails/Images/MultiTails/FlowerbloomPattern2.png"),
	}
 
