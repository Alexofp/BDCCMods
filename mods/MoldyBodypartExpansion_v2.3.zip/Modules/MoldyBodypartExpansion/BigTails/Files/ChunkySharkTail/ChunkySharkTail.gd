extends BodypartTail

func _init():
	visibleName = "Chunky Shark Tail"
	id = "chunkysharktail"

func getCompatibleSpecies():
	return ["shark"]

func getLewdSizeAdjective():
	return RNG.pick(["long", "finned"])

func getLewdAdjective():
	return RNG.pick(["smooth", "silky", "moist"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ChunkySharkTail/ChunkySharkTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
