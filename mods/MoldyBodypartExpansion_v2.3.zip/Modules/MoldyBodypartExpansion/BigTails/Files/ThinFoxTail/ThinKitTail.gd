extends BodypartTail

func _init():
	visibleName = "Thin Kitsune Tail"
	id = "thinkittail"

func getCompatibleSpecies():
	return [Species.Canine]

func getLewdSizeAdjective():
	return RNG.pick(["long", "big", "multi", "sleek"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm", "foxy"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ThinFoxTail/ThinKitTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
