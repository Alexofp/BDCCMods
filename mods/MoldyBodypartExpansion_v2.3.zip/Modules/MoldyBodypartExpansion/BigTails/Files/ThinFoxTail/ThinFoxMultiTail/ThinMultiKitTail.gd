extends BodypartTail

func _init():
	visibleName = "Thin Kitsune Tails Split"
	id = "thinmultikittail"

func getCompatibleSpecies():
	return [Species.Canine]

func getLewdSizeAdjective():
	return RNG.pick(["long", "thin", "sleek"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm", "foxy"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ThinFoxTail/ThinFoxMultiTail/ThinMultiKitTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
