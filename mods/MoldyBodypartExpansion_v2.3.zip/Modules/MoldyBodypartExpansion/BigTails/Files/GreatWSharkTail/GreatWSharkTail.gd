extends BodypartTail

func _init():
	visibleName = "Great White Shark Tail"
	id = "greatwsharktail"

func getCompatibleSpecies():
	return ["shark"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["selachian", "finned"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/GreatWSharkTail/GreatWSharkTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
