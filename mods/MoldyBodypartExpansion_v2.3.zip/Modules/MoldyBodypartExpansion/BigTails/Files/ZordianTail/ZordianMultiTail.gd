extends BodypartTail

func _init():
	visibleName = "Zordian Multi Tail"
	id = "zordianmultitail"

func getCompatibleSpecies():
	return ["zordian"]

func getLewdSizeAdjective():
	return RNG.pick(["long", "thin", "fluffy"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ZordianTail/ZordianMultiTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
