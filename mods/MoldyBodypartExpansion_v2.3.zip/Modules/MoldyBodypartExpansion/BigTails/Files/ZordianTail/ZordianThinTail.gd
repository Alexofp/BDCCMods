extends BodypartTail

func _init():
	visibleName = "Thin Zordian Tail"
	id = "zordianthintail"

func getCompatibleSpecies():
	return [Species.Canine, "zordian"]

func getLewdSizeAdjective():
	return RNG.pick(["long", "thin", "sleek"])

func getLewdAdjective():
	return RNG.pick(["soft", "warm"])

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/BigTails/Files/ZordianTail/ZordianThinTail.tscn"

func hasCustomSkinPattern():
	return true

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
