extends Module

var noGenerate : bool = true
#var addPlayerWingsOptions : bool = true

func _init():
	id = "MoldyBodypartExpansion"
	author = "MoldyT"
	
	bodyparts = [
#                          --- Big Tails ---
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail1/MouthTail1.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail2/MouthTail2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3.gd",

		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PuffyWolfTail/PuffyWolfTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FeralWolfTail/FeralWolfTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/HoundDogTail/HoundDogTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThickHunterTail/ThickHunterTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffballTail/FluffballTail.gd",

		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThinFoxTail/ThinFoxTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThinFoxTail/ThinKitTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThinFoxTail/ThinFoxMultiTail/ThinMultiKitTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MysticFoxTail/MysticFoxTail.gd",

		"res://Modules/MoldyBodypartExpansion/BigTails/Files/SLeopardTail/SLeopardTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffLeopardTail/FluffLeopardTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/DuoFelineTail/DuoFelineTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/SplitFelineTail/SplitFelineTail.gd",
		
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffSpikeTail/FluffSpikeTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/CloudTail/CloudTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffyTipTail/FluffyTipTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FlowerbloomTail/FlowerbloomTail.gd",
		
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ChunkySharkTail/ChunkySharkTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThresherSharkTail/ThresherSharkTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BlackTipSharkTail/BlackTipSharkTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/GreatWSharkTail/GreatWSharkTail.gd",
		
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ZordianTail/ZordianMultiTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ZordianTail/ZordianThinTail.gd",
		
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThickRatTail/ThickRatTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintTail.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/Alt/PunkVarmintAltTail.gd",

#                          --- Visible Vaginas ---
		"res://Modules/MoldyBodypartExpansion/VisibleVaginas/CanineVagina/CanineVagina.gd",
	
#                       	   --- Wings ---
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/SDragWing/SDragWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/BFlyWing/BFlyWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/BatFoldWing/BatFoldWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/CDragWing/CDragWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/SMothWing/SMothWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/DiredragonWing/DiredragonWings.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/ThinBeeWing/ThinBeeWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/SBeeWing/SBeeWing.gd",

		"res://Modules/MoldyBodypartExpansion/Wings/Feathered/SFeatherWing/SFeatherWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Feathered/DuoFeatherWing/DuoFeatherWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Feathered/LongFoldedWing/LongFoldedWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Feathered/StubbyFluffWing/StubbyFluffWing.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/SlimBatWing/SlimBatWing.gd",
	]
	
	partSkins = [
#                           --- Mouth Tails ---
		#Tail Pattern 1
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail1/MouthTail1P1E.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail1/MouthTail1P2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail1/MouthTail1P2E.gd",
		#Tail Pattern 2
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail2/MouthTail2P1E.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail2/MouthTail2P2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail2/MouthTail2P2E.gd",
		#Tail Pattern 3
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3P1E.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3P2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3P2E.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3P3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MouthTail3/MouthTail3P3E.gd",

#                           --- Canine Tails ---
		#Puffy Wolf Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FeralWolfTail/FeralWolfPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PuffyWolfTail/PuffyWolfPattern3.gd",
		#Feral Wolf Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FeralWolfTail/FeralWolfPattern2.gd",
		#Hound Dog Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/HoundDogTail/HoundDogPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/HoundDogTail/HoundDogPattern3.gd",
		#Thick Hunter Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThickHunterTail/ThickHunterPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThickHunterTail/ThickHunterPattern3.gd",
		#Fluffball Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffballTail/FluffballPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffballTail/FluffballPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffballTail/FluffballPattern4.gd",

#                            --- Fox Tails ---
		#Regular Bushy Kitsune Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern4.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern5.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern6.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern7.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern8.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern9.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern10.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxPattern11.gd",
		#Multi Bushy Kitsune Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern4.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern5.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern6.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern7.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern8.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern9.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern10.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyFoxMultiTail/BushyMultiKitPattern11.gd",
		#Mystic Fox Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/MysticFoxTail/MysticFoxPattern2.gd",

#                            --- Kitsune Tails ---
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern4.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern5.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern6.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern7.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern8.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern9.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern10.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/BushyFoxTail/BushyKitPattern11.gd",

#                           --- Feline Tails ---
		#Snow Leopard Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/SLeopardTail/SLeopardPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/SLeopardTail/SLeopardPattern3.gd",
		#Fluffy Leopard Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffLeopardTail/FluffLeopardPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffLeopardTail/FluffLeopardPattern3.gd",
		#Duo Feline Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/DuoFelineTail/DuoFelinePattern2.gd",
		#Split Feline Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/SplitFelineTail/SplitFelinePattern2.gd",

#                           --- Shark Tails ---
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThresherSharkTail/ThresherSharkPattern2.gd",

#                           --- Mixed Tails ---
		#Fluff Spike Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffSpikeTail/FluffSpikePattern2.gd",
		#Cloud Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/CloudTail/CloudPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/CloudTail/CloudPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/CloudTail/CloudPattern4.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/CloudTail/CloudPattern5.gd",
		#Fluff Tip Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffyTipTail/FluffyTipPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffyTipTail/FluffyTipPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffyTipTail/FluffyTipPattern4.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FluffyTipTail/FluffyTipPattern5.gd",
		#Flowerbloom Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FlowerbloomTail/FlowerbloomPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FlowerbloomTail/FlowerbloomPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/FlowerbloomTail/FlowerbloomPattern4.gd",

#                           --- Other Tails ---
		#Thick Rat Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/ThickRatTail/ThickRatPattern2.gd",
		#Punk Rat Tail
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/PunkVarmintPattern4.gd",
		#Punk Rat Tail Alt
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/Alt/PunkVarmintAltPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/Alt/PunkVarmintAltPattern3.gd",
		"res://Modules/MoldyBodypartExpansion/BigTails/Files/PunkVarmintTail/Alt/PunkVarmintAltPattern4.gd",

#                           --- Membrane Wings ---
		#CaninBad Dragon Wing
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/CDragWing/CDragPattern2.gd",
		
		"res://Modules/MoldyBodypartExpansion/Wings/Feathered/StubbyFluffWing/StubbyFluffPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Membrane/SlimBatWing/SlimBatPattern2.gd",
		"res://Modules/MoldyBodypartExpansion/Wings/Feathered/LongFoldedWing/LongFoldedPattern2.gd"
	]
	

func postInit():
	var codegen = load("res://Modules/MoldyBodypartExpansion/VisibleVaginas/ClothingCompat/CompatCodeGen.gd")
	
	codegen.do([ # vanilla
		#Clothes compat files
		"res://Inventory/Items/Clothes/AndroidSuit.gd",
		"res://Inventory/Items/Clothes/CasualClothes.gd",
		"res://Inventory/Items/Clothes/EngineerClothes.gd",
		"res://Inventory/Items/Clothes/EngineerClothesAlex.gd",
		"res://Inventory/Items/Clothes/EngineerClothesOld.gd",
		"res://Inventory/Items/Clothes/GuardArmor.gd",
		"res://Inventory/Items/Clothes/GuardArmorRiot.gd",
		"res://Inventory/Items/Clothes/InmateUniformGeneral.gd",
		"res://Inventory/Items/Clothes/InmateUniformHighSec.gd",
		"res://Inventory/Items/Clothes/InmateUniformSexDeviant.gd",
		"res://Inventory/Items/Clothes/LabcoatOutfit.gd",
		"res://Inventory/Items/Clothes/LabcoatOutfitAlt.gd",
		"res://Inventory/Items/Clothes/LatexSuit.gd",
		"res://Inventory/Items/Clothes/LeatherJacket.gd",
		"res://Inventory/Items/Clothes/Leotard.gd",
		"res://Inventory/Items/Clothes/NurseClothes.gd",
		"res://Inventory/Items/Clothes/NurseClothesAlt.gd",
		"res://Inventory/Items/Clothes/OfficialClothes.gd",
		"res://Inventory/Items/Clothes/OfficialClothesRed.gd",
		"res://Inventory/Items/Clothes/SyndiArmor.gd",
		#Underwear compat files
		"res://Inventory/Items/Underwear/LacePanties.gd",
		"res://Inventory/Items/Underwear/MirriPanties.gd",
		"res://Inventory/Items/Underwear/PlainBriefs.gd",
		"res://Inventory/Items/Underwear/PlainPanties.gd",
		"res://Inventory/Items/Underwear/SportyBriefs.gd",
		"res://Inventory/Items/Underwear/Strapon.gd",
		#BDSM compat files
	])
	
	var modules = GlobalRegistry.getModules().keys() # to avoid calling too many times, and also only getting the keys for performance reasons kinda
	if ("LongUniform" in modules):
		codegen.do([
			#Clothes compat files
			"res://Modules/LongUniform/Uniforms/LongUniform.gd",
			"res://Modules/LongUniform/Uniforms/LongUniformLilac.gd",
			"res://Modules/LongUniform/Uniforms/LongUniformRed.gd",
			"res://Modules/LongUniform/Uniforms/CropTopUniform.gd",
			"res://Modules/LongUniform/Uniforms/CropTopLilac.gd",
			"res://Modules/LongUniform/Uniforms/CropTopRed.gd",
			"res://Modules/LongUniform/Uniforms/MaternityUniform.gd",
			"res://Modules/LongUniform/Uniforms/MaternityUniformLilac.gd",
			"res://Modules/LongUniform/Uniforms/MaternityUniformRed.gd",
			"res://Modules/LongUniform/Uniforms/BottomsOnlyUniform.gd",
			"res://Modules/LongUniform/Uniforms/BottomsOnlyRed.gd",
			"res://Modules/LongUniform/Uniforms/BottomsOnlyLilac.gd",
			#Underwear compat files
			"res://Modules/LongUniform/Misc Clothes/CowBriefs.gd",
			"res://Modules/LongUniform/Misc Clothes/CowPanties.gd",
			#BDSM compat files
		])
	if ("ClothingMegapack" in modules):
		codegen.do([
			#Clothes compat files
			"res://Modules/Clothing Megapack/InmateShortUniformHighSec.gd",
			"res://Modules/Clothing Megapack/InmateShortUniformSexDeviant.gd",
			"res://Modules/Clothing Megapack/InmateUniformShortGeneral.gd",
			"res://Modules/Clothing Megapack/InmateUniformShortNeutral.gd",
			"res://Modules/Clothing Megapack/InmateWhiteHoodieGeneral.gd",
			"res://Modules/Clothing Megapack/InmateWhiteHoodieHighSec.gd",
			"res://Modules/Clothing Megapack/InmateWhiteHoodieSexDeviant.gd",
			"res://Modules/Clothing Megapack/InmateWhiteShortUniformGeneral.gd",
			"res://Modules/Clothing Megapack/InmateWhiteShortUniformHighSec.gd",
			"res://Modules/Clothing Megapack/InmateWhiteShortUniformSexDeviant.gd",
			#Underwear compat files
			"res://Modules/Clothing Megapack/KittyPanties.gd",
			"res://Modules/Clothing Megapack/WhiteKittyPanties.gd",
			#BDSM compat files
		])
	if ("ContrabandClothesModule" in modules):
		codegen.do([
			#Clothes compat files
			"res://Modules/ContrabandClothesModule/InmateUniformShortGeneral.gd",
			"res://Modules/ContrabandClothesModule/InmateShortUniformSexDeviant.gd",
			"res://Modules/ContrabandClothesModule/InmateShortUniformHighSec.gd",
			"res://Modules/ContrabandClothesModule/InmateUniformShortNeutral.gd",
			#Underwear compat files
			#BDSM compat files
		])
	if ("ContrabandClothes2Module" in modules):
		codegen.do([
			#Clothes compat files
			#Underwear compat files
			"res://Modules/ContrabandClothes2Module/KittyPanties.gd",
			#BDSM compat files
		])
	if ("felliniModule" in modules):
		codegen.do([
			#Clothes compat files
			#Underwear compat files
			"res://Modules/FelliniModule/Clothing/felliniShorts.gd",
			#BDSM compat files
		])
	if ("GooBondage" in modules):
		codegen.do([
			#Clothes compat files
			#Underwear compat files
			#BDSM compat files
			"res://Modules/GooBondage/NullBulge/NullBulgeV.gd",
		])
	if ("HeelsSuit" in modules):
		codegen.do([
			#Clothes compat files
			"res://Modules/HeelsSuitModule/HeelsSuit.gd"
			#Underwear compat files
		])
	if ("BDSMstuff" in modules):
		codegen.do([
			#Clothes compat files
			#Underwear compat files
			#BDSM compat files
			"res://Modules/MoreBDSMstuffModule/BDSM/Suit.gd",
		])
	if ("powerArmorLightnigh" in modules):
		codegen.do([
			#Clothes compat files
			"res://Modules/powerArmor/Items/PowerArmor.gd", 
			#Underwear compat files
			#BDSM compat files
		])
	if ("Striped_Clothes" in modules):
		codegen.do([
			#Clothes compat files
			#Underwear compat files
			"res://Modules/Striped_Clothes/Clothing/striped/panties/panties.gd",
			#BDSM compat files
		])
	
	
	

func register():
	.register()
	
	GlobalRegistry.registerBodypart("res://Modules/MoldyBodypartExpansion/VisibleVaginas/defaultVaginaReplacement.gd", "MoldyT")
	GlobalRegistry.registerBodypartSlot("res://Modules/MoldyBodypartExpansion/Special/wingBodypartSlot.gd")


var speciesOptions : Dictionary # [String,float]

func getSpeciesDefaultsList() -> Dictionary:
	return {
		"protogen": 50.0,
		"Protogen": 50.0,
		Species.Canine:100.0,
		"skulldog":100.0,
		"nightstalker":100.0,
		"redpanda":100.0,
	}

func getSpeciesWeight(speciesId:String) -> float:
	var option = speciesOptions.get(speciesId)
	if option:
		return option.getOptionValue()
	
	return getSpeciesDefaultsList().get(speciesId, 0.0)

func onFoxLibModInit(foxModuleAPI):
	#foxModuleAPI.addBooleanOptionInCategory("Moldy Bodypart Expansion","noGenerate", "No wing generation", "Prevents wings from generating on NPCs",true)
	
#	foxModuleAPI.addBooleanOptionInCategory("Moldy Bodypart Expansion","addPlayerWingsOptions", "Player wings", "Allows wings to appear during character creation", false)
	
	var all = GlobalRegistry.getAllSpecies()
	for spid in all:
		var sp = all[spid]
		speciesOptions[spid] = foxModuleAPI.addSliderOptionInCategory("Moldy Bodypart Visible Vaginas", spid, "%s (%s)" % [ sp.getVisibleName() if sp else "Error", spid ], "This species has this much chance to generate with the new vaginas instead of the default ones", getSpeciesWeight(spid)).advanced()
	


