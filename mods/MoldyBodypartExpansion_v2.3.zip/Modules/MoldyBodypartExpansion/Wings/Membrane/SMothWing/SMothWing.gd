extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Soft Moth Wings"
	id = "smothwing"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/SMothWing/SMothWing.tscn"
