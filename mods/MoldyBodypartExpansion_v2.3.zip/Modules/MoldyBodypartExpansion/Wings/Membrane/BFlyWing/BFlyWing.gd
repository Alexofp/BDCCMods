extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Butterfly Wings"
	id = "bflywing"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/BFlyWing/BFlyWing.tscn"
