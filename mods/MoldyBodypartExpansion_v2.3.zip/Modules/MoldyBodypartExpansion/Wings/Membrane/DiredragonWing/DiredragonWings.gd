extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Dire Dragon Wings"
	id = "diredragonwings"

func getCompatibleSpecies():
	return ["diredragon"]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/DiredragonWing/DiredragonWings.tscn"
