extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Short Bee Wings"
	id = "sbeewing"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/SBeeWing/SBeeWing.tscn"
