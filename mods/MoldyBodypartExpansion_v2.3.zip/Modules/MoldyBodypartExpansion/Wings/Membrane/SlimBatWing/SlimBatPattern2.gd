extends PartSkinBase

func _init():
	id = "batslimpattern2"
	partID = "batslimwing"

func getName():
	return "Membrane"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/Wings/Membrane/SlimBatWing/SlimBatPattern2.png"),
	}
