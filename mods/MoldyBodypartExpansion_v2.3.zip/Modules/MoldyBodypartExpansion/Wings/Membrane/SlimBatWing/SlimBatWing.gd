extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Slim Bat Wings"
	id = "batslimwing"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/SlimBatWing/SlimBatWing.tscn"

func hasCustomSkinPattern():
	return true
