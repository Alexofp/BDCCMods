extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Colossal Dragon Wings"
	id = "cdragwing"

func getCompatibleSpecies():
	return ["dragon"]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/CDragWing/CDragWing.tscn"

func hasCustomSkinPattern():
	return true
