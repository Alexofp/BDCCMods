extends PartSkinBase

func _init():
	id = "cdragpattern2"
	partID = "cdragwing"

func getName():
	return "Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/Wings/Membrane/CDragWing/CDragPattern2.png"),
	}
