extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Sharp Dragon Wings"
	id = "sdragwing"

func getCompatibleSpecies():
	return ["dragon"]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Membrane/SDragWing/SDragWing.tscn"
