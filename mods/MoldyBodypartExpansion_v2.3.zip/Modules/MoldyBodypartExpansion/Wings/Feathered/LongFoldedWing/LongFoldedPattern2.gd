extends PartSkinBase

func _init():
	id = "longfoldpattern2"
	partID = "longfoldwing"

func getName():
	return "Feathery"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/Wings/Feathered/LongFoldedWing/LongFoldedPattern2.png"),
	}
