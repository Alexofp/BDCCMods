extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Long Folded Wings"
	id = "longfoldwing"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Feathered/LongFoldedWing/LongFoldedWing.tscn"

func hasCustomSkinPattern():
	return true
