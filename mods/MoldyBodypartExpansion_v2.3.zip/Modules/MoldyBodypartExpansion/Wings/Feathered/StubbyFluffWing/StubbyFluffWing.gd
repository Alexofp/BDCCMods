extends "res://Modules/MoldyBodypartExpansion/Special/wingsBodypartTemplate.gd"

func _init():
	visibleName = "Stubby Fluffy Wings"
	id = "stubbyfluffwing"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/Wings/Feathered/StubbyFluffWing/StubbyFluffWing.tscn"

func hasCustomSkinPattern():
	return true
