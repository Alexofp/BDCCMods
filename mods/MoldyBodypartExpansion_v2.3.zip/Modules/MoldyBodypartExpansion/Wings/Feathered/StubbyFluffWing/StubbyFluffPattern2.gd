extends PartSkinBase

func _init():
	id = "stubbyfluffpattern2"
	partID = "stubbyfluffwing"

func getName():
	return "Feathery"

func getPatternTexture():
	return {
		"": preload("res://Modules/MoldyBodypartExpansion/Wings/Feathered/StubbyFluffWing/StubbyFluffPattern2.png"),
	}
