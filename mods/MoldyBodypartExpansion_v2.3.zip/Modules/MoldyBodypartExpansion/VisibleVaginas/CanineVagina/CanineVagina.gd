extends BodypartVagina

func _init():
	visibleName = "Canine vagina"
	id = "caninevagina"

func getCompatibleSpecies():
	return [Species.Any, Species.AnyNPC]

func getDoll3DScene():
	return "res://Modules/MoldyBodypartExpansion/VisibleVaginas/CanineVagina/CanineVagina/CanineVagina.tscn"

func getLewdAdjective():
	return RNG.pick(["pink", "wet"])

func getOrificeName():
	return "canine pussy"

func getCharacterCreatorDesc():
	return "A wet and inviting pink pussy."

func supportsSkin():
	return true


func npcGenerationWeight(_dynamicCharacter):
	var species = _dynamicCharacter.getSpecies() if _dynamicCharacter else []
	
	if !species or species.size()<1:
		return 0.0
	
	var avgWeight : float = 0.0
	
	var mod = GlobalRegistry.getModule("MoldyBodypartExpansion")
	
	for spec in species:
		avgWeight += mod.getSpeciesWeight(spec)
	
	
	return (avgWeight*0.01)/species.size()

