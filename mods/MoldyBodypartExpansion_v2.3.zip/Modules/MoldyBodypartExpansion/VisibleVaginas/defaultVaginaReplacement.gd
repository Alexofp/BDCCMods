extends "res://Player/Bodyparts/Vagina/Vagina.gd"

func npcGenerationWeight(_dynamicCharacter):
	var species = _dynamicCharacter.getSpecies() if _dynamicCharacter else []
	
	if !species or species.size()<1:
		return 1.0
	
	var avgWeight = 0.0
	
	var mod = GlobalRegistry.getModule("MoldyBodypartExpansion")
	
	for spec in species:
		avgWeight += mod.getSpeciesWeight(spec)
	
	return 1.0 - ((avgWeight*0.01)/species.size())
