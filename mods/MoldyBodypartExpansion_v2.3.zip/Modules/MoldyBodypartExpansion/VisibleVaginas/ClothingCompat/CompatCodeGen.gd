extends Node

const codeGenReplacementsFolder = "user://MoldyBodypartCodeGen/" # save new files here

static func do(itemsToEdit:Array=[]) -> void:
	
	
	
	var d = Directory.new()
	if !d.dir_exists(codeGenReplacementsFolder): # make the dir
		d.make_dir_recursive(codeGenReplacementsFolder)
	
	for itempath in itemsToEdit:
		var itemInst = load(itempath)
		if !itemInst:
			continue
		var itemid = itemInst.new().id
		if !GlobalRegistry.items.has(itemid): # doesn't exist, can't replace, move on
			continue
		
		var newPath = codeGenReplacementsFolder+itempath.get_file() # where we'll save the new one
		
		
		var scriptText = "\n".join([ # the actual code generation
			"extends \"%s\"" % itempath, # we extend from the script file we just got, to inherit and replace its functions
			"func getHidesParts(_character):",
			"	var d = .getHidesParts(_character)",
			"	if !d:",
			"		d={}",
			"	",
			"	if d.get(BodypartSlot.Penis,false):", # only hides vagina if it also hides the penis
			"		d[BodypartSlot.Vagina]=true",
			"	return d",
		])
		
		
		var file := File.new()
		if file.file_exists(newPath):
			if file.open(newPath,File.READ)==OK: # file open successfully
				if file.get_as_text().sha256_text()==scriptText.sha256_text():
					continue # ignore if it's the same
				file.close()
		
		if file.open(newPath,File.WRITE)!=OK: # creating the file failed, move on
			continue
		
		
		file.store_string(scriptText) # sstore new script data
		
		
		file.close() # close the file to save it
		
		# register to replace the original
		GlobalRegistry.registerItem(newPath)
		
