extends Bodypart

func getSlot():
	return "wings"

func npcGenerationWeight(_dynamicCharacter):
	if GlobalRegistry.getModule("MoldyBodypartExpansion").noGenerate:
		return 0.0
	return 1.0

#func getCompatibleSpeciesFinal() -> Array:
#	if !GlobalRegistry.getModule("MoldyBodypartExpansion").addPlayerWingsOptions && GM.main && GM.main.getCurrentScene().sceneID=="CharacterCreatorScene":
#		return []
#
#	return .getCompatibleSpeciesFinal()
