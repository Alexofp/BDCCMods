# FoxLib ModHelper (Aka. FLMH)

FoxLib ModHelper is a tool bundled with each FoxLib release, it allows you to make mods without wasting time on packaging.

To use this tool you will need to install python 3 onto your computer: <https://www.python.org/downloads/>

## Setting up FoxLib ModHelper

There is 2 supported ways of doing mod development with FoxLib ModHelper, with an editor by using BDCC project source code, or in a new empty folder.

While I recommend use an empty folder to make your mods, I respect that some peoples want to do modding inside BDCC project source code to get the godot editor.

For either case, you need to do the following:
- Copy `FLMH.py` from your `FoxLib.zip` into the folder you want to do modding in.
- Copy your `FoxLib.zip` either to the `libs` subfolder or the same folder as `FLMH.py`  
  (FoxLib ModHelper will only load other mods definitions if they are in the `libs` subfolder)
- create your mod info json, `ModName.json` (Replace ModName with your actual mod name)
- Inside your `ModName.json` create `"name"`, `"description"`, `"author"`, `"modversion"`, `"gameversion"`

An example of valid mod info `.json` would be:
```json
{
	"name": "ModName",
	"description": "I'm a cool mod",
	"author": "Me",
	"modversion": "0.1",
	"gameversion": "*"
}

```

### Using FoxLib ModHelper in a project

When using FoxLib ModHelper in a project, you can only put files inside your module folder in `Modules/MyModule/*` (`MyModule` is the module name you picked)

If you want to add files outside your Module, you will have to move your mod files outside BDCC project.

## Building & Testing

To build your mod, just do `./FLMH.py build`

When developing you often want to test your code in rapid iteration, just run `./FLMH.py test` to build and run your mod inside BDCC quickly.

FoxLib ModHelper will report to you when some inconsistencies are found.

## Preprocessor

Preprocessor has some useful features, designed to help you make your mod more easily.

The `#import` statement is a helper tool that you can use to import a named class file (Defined with `class_name YourClassName`).

This can be useful when modding inside the editor, as the editor may auto import named classes while the real game don't.

for example, you can add the line `#import FoxUIManager` before a function calling `FoxUIManager.showGameConsole()` to make sure it's still imported on the full game version, for example.

If you are making a library, you can use `#public_api` to tell FoxLib ModHelper the class is a public API to be used by other mods

## Mod info extensions

"raw", "parsed", "trimmed"

FoxLib ModHelper can be configured via your `ModName.json` file, the following options are supported:
- `FLMH_source_mode`: Configure how FoxLib ModHelper will treat your source code:
  - `raw`: Means your code will ship as-is, disabling the preprocessor and it's features.
  - `parsed`: Means the preprocessor will be applied (Default)
  - `trimmed`: Remove comments from the release zip file
- `FLMH_definition_mode`: Tell FoxLib ModHelper how they should make FoxLib definition file (Aka. `.fldef`)
  - `none`: Do not make `.fldef` under any circumstances.
  - `standard`: Will populate definitions with public APIs only (default)
  - `extended`: Will populate definitions with public and private APIs
