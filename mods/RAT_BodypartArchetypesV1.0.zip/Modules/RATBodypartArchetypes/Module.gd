extends Module

var replacedSpecies : Array = []

var defaultTypeChance : float = 15.0

func _init():
	id = "RAT_FluffyArchetypes"
	author = "Selinoccino"
	

func loadModContent(mod:Module) -> Dictionary:
	if !mod.has_method("getAddedRatArchetypes"):
		return {}
	
	var modData = mod.getAddedRatArchetypes()
	
	if typeof(modData) != TYPE_DICTIONARY:
		return {}
	
	for key in modData:
		if typeof(modData[key]) == TYPE_STRING:
			var old = modData[key]
			modData[key] = readJsonData(old)
			continue
		
		var res : Dictionary = {}
		for path in modData[key]:
			res.merge(readJsonData(path), true)
		
		modData[key] = res
	
	return modData

func postInit():
	var speciesMap : Dictionary = {} # speciesID: types stuff
	
	for mod in GlobalRegistry.getModules().values():
		var mdata = loadModContent(mod)
		for species in mdata:
			for type in mdata[species]:
				speciesMap.get_or_add(species, {})[type] = mdata[species][type]
	
	replaceAllSpecies(speciesMap) # replaceAllSpecies is just the current postInit func renamed, and its replaced var made into an argument


func replaceAllSpecies(replaced:Dictionary):
	#replaced = id: types dict (typeID: type array)
	
	var typesSpecies = load("res://Modules/RATBodypartArchetypes/TypedSpecies.gd")
	
	var allsps = GlobalRegistry.getAllSpecies()
	for species in replaced:
		if !species in allsps:
			continue
		
		var spobj = allsps[species]
		if !spobj:
			continue
		
		replaced[species]["default"] = getDefaultType(species)
		
		replacedSpecies.append(typesSpecies.new(spobj, replaced[species]))
	

func getDefaultType(_speciesID:String="") -> Dictionary:
	return {
		"optionDisplay": "Default Bodyparts",
		"defaultWeight": 0.0,
	}

func readJsonData(path:String, type:int=TYPE_DICTIONARY, nullval={}):
	var f = File.new()
	
	var e = f.open(path, File.READ)
	
	if e != OK:
		Log.error(id+": error accessing json data file %s, code %s" % [ path, e])
		return nullval
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		Log.error(id+": error reading json data from file %s, code %s at line %s, message: %s" % [ path, r.error, r.error_line, r.error_string ])
		return nullval
	
	if typeof(r.result) != type:
		Log.error(id+": error parsing json data from file %s, unexpected return type, type: %s, expected: %s" % [ path, typeof(r.result), type ])
		return nullval
	
	return r.result
	


var typesOptions : Dictionary = {
	# species::typeID: foxlib option
}

func onFoxLibModInit(foxModuleAPI):
	for species in replacedSpecies:
		foxifyTypedSpecies(species, foxModuleAPI)

func foxifyTypedSpecies(typedSpecies, foxModuleAPI):
	var types : Dictionary = typedSpecies.types
	var species : Species = typedSpecies.mimic
	
	for typeID in types:
		var type = types[typeID]
		var sptext = species.getVisibleName()
		var newID : String = species.id+"::"+typeID
		
		var desc = type.get("description", "")
		
		typesOptions[newID] = foxModuleAPI.addSliderOptionInCategory("FluffyArchetypes: "+sptext, newID, "Type %s" % typeID if !type.has("optionDisplay") else type["optionDisplay"].replace("{DEF}", sptext), "Weight for this type" + ("\n\n"+desc if desc else ""), getChanceForType(newID)).advanced()

func getChanceForType(typestr:String) -> float:
	var option = typesOptions.get(typestr, null)
	if option:
		return option.getOptionValue()
	
	var split = typestr.split("::", false, 2)
	var speciesID = split[0]
	if split.size()<2 or !GlobalRegistry.getAllSpecies().has(speciesID):
		return 0.0
	
	var typeID = split[1]
	return GlobalRegistry.getSpecies(speciesID).types.get(typeID, {}).get("defaultWeight", defaultTypeChance)
