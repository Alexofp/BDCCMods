extends ItemBase

var redColor : Color = Color.white
var greenColor : Color = Color.white
var blueColor : Color = Color.white

var patternPath : String = "" # change to fallback in _init, or leave empty if you define manually in MeshWithPatternForItem

###	SETTING UP	###
#	You need:
#	1. Make your item extends from this (extends "res://Modules/MoldyBodypartExpansion/Special/patternableItem.gd")
#	2. Set your rigged parts (for now doesn't work with unrigged ones)
#	(when setting the rigged parts, use a scene that inherits your base bodypart's scene, go see MeshWithPatternForItem for instructions)
#	3. Copy-paste getRiggedSlot(), make it return the string of the slot from your rigged parts function
#	4. Replace getAllPatternPaths() to return your pattern paths
#	5. Done for here, go set up MeshWithPatternForItem and its scene now
###				###

## replace
func getRiggedSlot() -> String:
	var ks = getRiggedParts(null).keys()
	return ks[0] if ks else ""

func getVisisbleDescription():
	var txt = .getVisisbleDescription()
	
	txt += "\n[color=gray]Colors: [/color]"
	for channel in ["r","g","b"]:
		var c = getClothesColor(channel).to_html(false)
		txt += "\n[color=#%s]#%s[/color]" % [ c, c ]
	
	
	return txt

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"wing": "res://Modules/MoldyBodypartExpansion/Wings/Feathered/SFeatherWing/SFeatherWing.tscn",
	}

func getAllPatternPaths() -> Array: # array of strings
	return []

func setPattern(path:String) -> void:
	patternPath = path
	updateWearerAppearance()

func updateDoll(_doll: Doll3D):
	var part = getRiggedSceneOnDoll(_doll)
	if part:
		for child in part.get_children():
			if child.has_method("patternable"):
				child.patternRedColor = redColor
				child.patternGreenColor = greenColor
				child.patternBlueColor = blueColor
				
				if patternPath:
					child.customSkinPattern = load(patternPath)
				elif !child.customSkinPattern:
					var ps = getAllPatternPaths()
					if ps:
						child.customSkinPattern = load(ps[0])
				
				child.updateMaterial()

func getRiggedSceneOnDoll(doll:Doll3D) -> Spatial:
	## replace wing with slot from rigged part function
	return doll.parts.get(getRiggedSlot(), null)

func canDye(): # has to be false
	return false

## expects channel, any of "r" (or anything unlike the other two), "g", "b". any unrecognized value is seen as red
func getClothesColor(channel:String="r") -> Color:
	if channel == "g":
		return greenColor
	elif channel == "b":
		return blueColor
	
	return redColor

## expects channel, any of "r" (or anything unlike the other two), "g", "b". any unrecognized value is seen as red. default color is white
func setClothesColor(channel:String="r", col:Color=Color.white) -> void:
	if channel == "g":
		greenColor = col
	elif channel == "b":
		blueColor = col
	else:
		redColor = col
	
	updateWearerAppearance()

func saveData():
	var d = .saveData()
	
	d["redColor"] = redColor.to_html()
	d["greenColor"] = greenColor.to_html()
	d["blueColor"] = blueColor.to_html()
	d["patternPath"] = patternPath
	
	return d

func loadData(d):
	redColor = Color(SAVE.loadVar(d, "redColor", "ffffff"))
	greenColor = Color(SAVE.loadVar(d, "greenColor", "ffffff"))
	blueColor = Color(SAVE.loadVar(d, "blueColor", "ffffff"))
	var ps = getAllPatternPaths()
	patternPath = SAVE.loadVar(d, "patternPath", ps[0] if ps else "")
	updateWearerAppearance()
	.loadData(d)
	

func onDollUpdate(_doll : Doll3D, _zone, _dollpart):
#	if(_dollpart != null && _dollpart.has_method("setColor")):
#		_dollpart.setColor(clothesColor)
	updateDoll(_doll)

func getItemCategory():
	return "Patternables"
