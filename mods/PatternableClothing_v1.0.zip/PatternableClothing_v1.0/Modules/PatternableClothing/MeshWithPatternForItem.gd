extends MeshInstanceWithPattern

var patternRedColor : Color = Color.white
var patternGreenColor : Color = Color.white
var patternBlueColor : Color = Color.white

###	SETTING UP	###
#	You need:
#	1. Make a scene that inherits from your base bodypart scene, if it exists
#	(if you don't know how, click the plus button on the scene tabs and then add your base scene as the root node, or right-click it and click "new inherited scene")
#	2. Set your rigged part's meshes to this script
#	3. Define custom skin pattern as fallback; if none is set then the first one defined in the patternableItem will be used
#	4. Done for here, go set up patternableItem now
###				###


## this is for checking class basically, whatever
func patternable():
	return true

#func _ready():
#	.request_ready()
#	updateMaterial()

func updateMaterial():
	if(!OPTIONS.shouldUseAdvancedShaders()):
		return
	if(writingsHandler):
		writingsHandler.triggerUpdate()
	
	var theDoll = getDoll()
	if(theDoll != null):
		if(showCumLayer && theDoll.getCumAmount() > 0):
			fancyMaterial.set_shader_param("cum_transparency", 1.0)
			fancyMaterial.set_shader_param("cum_amount", theDoll.getCumAmount())
			fancyMaterial.set_shader_param("cum_color", theDoll.getCumColor())
		else:
			fancyMaterial.set_shader_param("cum_transparency", 0.0)
			fancyMaterial.set_shader_param("cum_amount", 0)
		
		
		
			#fancyMaterial = materialWithSkin.duplicate()
			if(customSkinPattern != null):
				fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
			
			
			fancyMaterial.set_shader_param("pattern_red_color", patternRedColor)
		
			fancyMaterial.set_shader_param("pattern_green_color", patternGreenColor)
		
			fancyMaterial.set_shader_param("pattern_blue_color", patternBlueColor)
			#print(skinData)
