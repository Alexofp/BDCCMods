extends EventBase

func _init():
	id = "RAT_LaundromatEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["LaundryUniformMachineScene", "dye_clothes_menu"])

func isItemPatternable(item:ItemBase) -> bool:
	if item.canDye():
		return false
	
	return item.has_method("setClothesColor") && item.has_method("getClothesColor")

func getAllPatternableItems() -> Array:
	var resultInv = []
	var resultEq = []
	var inv = GM.pc.getInventory()
	for item in inv.items:
		if(isItemPatternable(item)):
			resultInv.append(item)
	for item in inv.equippedItems.values():
		if(isItemPatternable(item)):
			resultEq.append(item)
	return [resultEq, resultInv]

func run(_id,_args):
	var allpts = getAllPatternableItems()
	for item in allpts[0]: # equipped
		addButtonWithChecks(item.getVisibleName(), "[color=gray](equipped)[/color]\n\n%s" % item.getVisibleDescription(), "choose_item", [item.uniqueID], [[ButtonChecks.HasCredits, 5]])
	for item in allpts[1]: # equipped
		addButtonWithChecks(item.getVisibleName(), item.getVisibleDescription(), "choose_item", [item.uniqueID], [[ButtonChecks.HasCredits, 5]])

func onButton(_method, _args):
	if _method=="choose_item" && _args:
		runScene("RAT_AdvDyeScene", _args)
