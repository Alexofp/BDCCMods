extends SceneBase

var dyingItemUniqueID = ""
var colorPickerScene = preload("res://UI/ColorPickerWidget.tscn")
var savedDyedColor : Dictionary = {} # data is Channel:Hex

# this scene will only work with items that have the "getClothesColor" and "setClothesColor" methods

func _init():
	sceneID = "RAT_AdvDyeScene"

func doSaveItemColor(item:ItemBase) -> Dictionary:
	var d : Dictionary = {}
	for channel in ["r","g","b"]:
		d[channel] = item.getClothesColor(channel).to_html()
	
	return d

func doLoadItemColor(item:ItemBase, savedColor:Dictionary) -> void:
	for channel in savedColor.keys():
		item.setClothesColor(channel, Color(savedColor[channel]))

func _initScene(_args = []):
	if(_args.size() < 1):
		endScene()
		return
	
	dyingItemUniqueID = _args[0]
	var theItem:ItemBase = getItem()
	if !(theItem.has_method("getClothesColor") && theItem.has_method("setClothesColor")):
		endScene()
		return
	
	savedDyedColor = doSaveItemColor(theItem)

func doItemSetupAnimations(theItem:ItemBase) -> void:
	if(theItem.hasTag(ItemTag.Strapon)):
		playAnimation(StageScene.Solo, "stand", {bodyState={exposedCrotch=true}})
	elif(theItem.getClothingSlot() != null && (theItem.getClothingSlot() in [InventorySlot.UnderwearBottom, InventorySlot.UnderwearTop])):
		playAnimation(StageScene.Solo, "stand", {bodyState={underwear=true}})
	else:
		playAnimation(StageScene.Solo, "stand")

func _run():
	if(state == ""):
		var theItem:ItemBase = getItem()
		
		doItemSetupAnimations(theItem)
		
		addButton("Nevermind", "Go back", "nevermind")
		
		for channel in ["r","g","b"]:
			var txts = {
				"r":"red", "g":"green", "b":"blue",
			}
			addButton("Change %s color" % txts.get(channel,"unknown"), "Change this color", "dyingChannel:%s" % channel)
			
			#addButtonWithChecks("Confirm", "Pay 5 credits and finalize the color", "do_pay_coloritem", [theItem], [[ButtonChecks.HasCredits, 5]])
			#addButton("Cancel", "You changed your mind", "cancel_dying")
		
		addButton("Change pattern", "Change the item's pattern", "listPatterns")
		addButtonWithChecks("Finalize color", "Done (needs 5 credits)", "finalize_color", [], [[ButtonChecks.HasCredits, 5]])
	
	elif state == "listPatterns":
		addButton("Back", "You're done", "")
		listAllPatterns(getItem())
	
	elif state.begins_with("dyingChannel:"):
		var theItem:ItemBase = getItem()
		
		var channel : String = state.trim_prefix("dyingChannel:")
		var colorPicker = colorPickerScene.instance()
		GM.ui.addFullScreenCustomControl("colorpicker"+channel, colorPicker)
		colorPicker.setCurrentColor(theItem.getClothesColor(channel))
		colorPicker.connect("color_changed", self, "changebasecolormenu_colorchanged", [channel])
		
		addButton("Cancel","","cancel_coloring_channel",[channel])
		addButton("Done","","")
		
	
	

func getItem() -> ItemBase:
	return GM.pc.getInventory().getItemByUniqueID(dyingItemUniqueID)

func listAllPatterns(item:ItemBase) -> void:
	var idx : int = 1
	for path in item.getAllPatternPaths():
		var pres = path.split("::", false, 2)
		var nam : String = (pres[0] if pres && pres[0]!=path else "Pattern %s" % idx)
		var desc : String = "Choose this one"
		if item.patternPath==path:
			nam = "["+nam+"]"
			desc = "Current pattern"
		
		addButton(nam, desc, "choosePattern", [pres[1] if pres.size()>1 else path.trim_prefix("::")])
		idx += 1

func getFullColors() -> Dictionary:
	var r : Dictionary = {}
	for channel in ["r","g","b"]:
		if GM.ui.textboxes.has("colorpicker"+channel):
			r[channel] = GM.ui.getUIdata("colorpicker"+channel).to_html()
	
	return r

func _react(_action: String, _args):
	if _action == "choosePattern" && _args:
		var theItem:ItemBase = getItem()
		theItem.setPattern(_args[0])
		setState("listPatterns")
		return
	
	if(_action == "finalize_color"):
		var theItem:ItemBase = getItem()
		var theColor = getFullColors()
		doLoadItemColor(theItem, theColor)
		GM.pc.addCredits(-5)
		GM.pc.unequipStrapon()
		
		endScene()
		return
	
	if(_action == ""):
		var theItem = getItem()
		
		if(!GM.pc.getInventory().hasEquippedItemWithUniqueID(dyingItemUniqueID)):
			var theSlot = theItem.getClothingSlot()
			if(theSlot != null):
				if(GM.pc.getInventory().canEquipSlot(theSlot)):
					if(GM.pc.getInventory().hasSlotEquipped(theSlot)):
						if(!GM.pc.getInventory().getEquippedItem(theSlot).isRestraint()):
							# We have something equipped but it's not a restraint, can replace
							GM.pc.getInventory().forceEquipStoreOther(theItem)
					else:
						# Nothing equipped there, can put on
						GM.pc.getInventory().forceEquipStoreOther(theItem)
		setState("")
		return
	
	if(_action == "nevermind"):
		var theItem:ItemBase = getItem()
		doLoadItemColor(theItem, savedDyedColor)
		setState("dye_clothes_menu")
		GM.pc.unequipStrapon()
		endScene()
		return
	
	if _action == "cancel_coloring_channel" && _args:
		var theItem:ItemBase = getItem()
		
		theItem.setClothesColor(_args[0], Color(savedDyedColor.get(_args[0],"ffffff")))
		
		setState("")
		return
	
	if(_action == "endthescene"):
		endScene()
		return
	
	setState(_action)

var isChanging = false
func changebasecolormenu_colorchanged(_theColor, channel:String="r"):
	if(isChanging):
		return
	isChanging = true
	yield(get_tree().create_timer(0.3), "timeout")
	if(GM.ui.getCustomControl("colorpicker"+channel) == null):
		isChanging = false
		return
	var theColor = GM.ui.getCustomControl("colorpicker"+channel).getCurrentColor()
	
	var theItem:ItemBase = getItem()
	theItem.setClothesColor(channel, theColor)

	#thePC.updateAppearance()
	isChanging = false

func saveData():
	var data = .saveData()
	
	data["dyingItemUniqueID"] = dyingItemUniqueID
	data["savedDyedColor"] = convertSavedColorsToString(savedDyedColor)
	
	return data
	
func loadData(data):
	.loadData(data)
	
	dyingItemUniqueID = SAVE.loadVar(data, "dyingItemUniqueID", "")
	savedDyedColor = convertStringToSavedColors(SAVE.loadVar(data, "savedDyedColor", "r:ffffff\ng:ffffff\n:bffffff"))

func convertSavedColorsToString(cols:Dictionary) -> String:
	var valueSep : String = ":"
	var channelSep : String = "\n"
	var a = []
	for channel in cols.keys():
		a.append("%s%s%s" % [ channel, valueSep, cols[channel] ])
	
	return channelSep.join(a)

func convertStringToSavedColors(string:String) -> Dictionary:
	var d = {}
	var valueSep : String = ":"
	var channelSep : String = "\n"
	
	for entry in string.split(channelSep, false):
		d[entry.get_slice(valueSep, 0)] = entry.get_slice(valueSep, 1)
	
	return d
