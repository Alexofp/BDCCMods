extends Module

func _init():
	id = "PatternableClothing"
	author = "Selinoccino"
	
	events = [
		"res://Modules/PatternableClothing/laundromatEvent.gd"
	]
	
	scenes = [
		"res://Modules/PatternableClothing/newDyeScene.gd"
	]

