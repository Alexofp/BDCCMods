extends SceneBase

func check_for_unlocks():
	var clients = GM.main.getModuleFlag("BunnySuit", "ProstitutionClientsServiced", 0)
	
	var cum_holes = 0
	var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
	if vagina and vagina.has_method("getOrifice"):
		var orifice = vagina.getOrifice()
		if orifice and orifice.has_method("getFluidAmount"):
			cum_holes += orifice.getFluidAmount()
	
	var anus = GM.pc.getBodypart(BodypartSlot.Anus)
	if anus and anus.has_method("getOrifice"):
		var orifice = anus.getOrifice()
		if orifice and orifice.has_method("getFluidAmount"):
			cum_holes += orifice.getFluidAmount()
	
	var cum_body = 0
	if GM.pc.has_method("bodyFluids") and GM.pc.bodyFluids.has_method("getFluidAmount"):
		cum_body = GM.pc.bodyFluids.getFluidAmount()
	
	if clients >= 8 and not GM.pc.getInventory().hasItemID("BunnySuitChest"):
		GM.pc.getInventory().addItemID("BunnySuitChest")
		GM.main.addMessage("You earned: Bunny Suit Top!")
	
	if clients >= 20 and not GM.pc.getInventory().hasItemID("BunnySuitStockings"):
		GM.pc.getInventory().addItemID("BunnySuitStockings")
		GM.main.addMessage("You earned: Bunny Suit Stockings!")
	
	if cum_holes >= 8000 and not GM.pc.getInventory().hasItemID("BunnySuitTail"):
		GM.pc.getInventory().addItemID("BunnySuitTail")
		GM.main.addMessage("You earned: Bunny Tail!")
	
	if cum_body >= 5000 and not GM.pc.getInventory().hasItemID("BunnySuitHeels"):
		GM.pc.getInventory().addItemID("BunnySuitHeels")
		GM.main.addMessage("You earned: Bunny Suit Heels!")
