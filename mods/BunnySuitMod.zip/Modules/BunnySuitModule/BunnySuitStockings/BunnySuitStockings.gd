extends ItemBase

func _init():
	id = "BunnySuitStockings"

func getVisibleName():
	return "Bunny Suit Stockings"

func getDescription():
	return "Stockings for a Bunny Suit"

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"Stockings": "res://Modules/BunnySuitModule/BunnySuitStockings/BunnySuitStockings.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your Bunny Suit Stockings"
	else:
		return "take off your Bunny Suit Stockings"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your Bunny Suit Stockings"
	else:
		return "put on your Bunny Suit Stockings"

func generateItemState():
	itemState = ShirtAndShortsState.new()

func getPartZIndex():
	return -1

func getPrice():
	return 80

func getTags():
	return [
		ItemTag.SexEngineCanApply,
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SoldByUnderwearVendomat,
		ItemTag.SoldByGeneralVendomat,
	]

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [10]),
		buff(Buff.ForcedObedienceBuff, [15]),
		buff(Buff.EncounterChanceModifierInmatesBuff, [40]),
		buff(Buff.MaxLustBuff, [75]),
		buff(Buff.MaxStaminaBuff, [50]),
		]

func getInventoryImage():
	return "res://Modules/BunnySuitModule/BunnySuitStockings/icon.tres"