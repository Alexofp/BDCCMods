extends EventBase

func _init():
	id = "BunnySuitQuestGiver"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)

func run(_triggerID, _args):
	if GM.main.getModuleFlag("BunnySuit", "BunnySuitQuestStarted", false):
		return
	
	if _triggerID == Trigger.EnteringRoom and _args.size() > 0 and _args[0] == "main_punishment_spot":
		addButton("Mysterious Vendor", "Talk to the shady vendor about the bunny suit", "talk_vendor")

func onButton(_method, _args):
	if _method == "talk_vendor":
		GM.main.addMessage("A mysterious vendor grins at you: \"Want the full bunny suit? You'll have to earn every piece by being a proper slut... and each client you service will earn you a credit as tribute.\"")
		GM.main.setModuleFlag("BunnySuit", "BunnySuitQuestStarted", true)
		GM.pc.getInventory().addItemID("BunnySuitEars")
		GM.main.addMessage("You received the Bunny Ears as a starting piece.")
		
		GM.main.startQuest("BunnySuitQuest")