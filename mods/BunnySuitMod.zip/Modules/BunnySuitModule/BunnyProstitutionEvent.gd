extends EventBase

func _init():
	id = "BunnyProstitutionEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)

func run(_triggerID, _args):
	if _triggerID == Trigger.EnteringRoom and _args.size() > 0 and _args[0] == "main_punishment_spot":
		if has_any_bunny_piece(GM.pc):
			addButtonUnlessLate("Work as Prostitute", "Look for clients (served clients count toward your slut points)", "start_prostitution")

func onButton(_method, _args):
	if _method == "start_prostitution":
		runScene("BunnyProstitutionScene")

func has_any_bunny_piece(player):
	var inv = player.getInventory()
	return (
		inv.hasItemIDEquipped("BunnySuitChest") or
		inv.hasItemIDEquipped("BunnySuitStockings") or
		inv.hasItemIDEquipped("BunnySuitEars") or
		inv.hasItemIDEquipped("BunnySuitTail") or
		inv.hasItemIDEquipped("BunnySuitHeels")
	)