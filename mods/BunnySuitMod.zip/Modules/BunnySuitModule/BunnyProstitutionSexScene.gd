extends "res://Scenes/SceneBase.gd"

var sexEngine: SexEngine
var currentCategory = []
var npcID = ""   

func _init():
    sceneID = "BunnyProstitutionSexScene"
    showFightUI = true

func _initScene(_args = []):
    if _args.size() > 0:
        npcID = _args[0]
    
    sexEngine = SexEngine.new()
    sexEngine.setInventoryToUse(sceneSavedItemsInv)
    
    addCharacter(npcID)
    
    sexEngine.initPeople([npcID], ["pc"])
    sexEngine.initSexType(SexType.DefaultSex)
    sexEngine.start()

func resolveCustomCharacterName(_charID):
    if _charID == "npc":
        return npcID
    return null

func _run():
    if state == "":
        setCharactersEasyList(sexEngine.getCharIDList())
        
        var animInfo = sexEngine.getCurrentAnimation()
        if animInfo != null and animInfo.size() >= 2:
            var scene = animInfo[0]
            var state = animInfo[1]
            playAnimation(scene, state, {"pc": "pc", "npc": npcID})
        else:

            playAnimation(StageScene.SexStart, "sex", {"pc": "pc", "npc": npcID})
        
        saynn(sexEngine.getFinalOutput())
        
        if !sexEngine.hasSexEnded():
            if sexEngine.canEndSexAnyTime():
                addExtraButtonAt(4, "END SEX", "Enough fun for now", "stopsex")
            else:
                addExtraButtonAt(4, "QUICK SEX", "Simulate the sex", "simulatesex")
            
            if sexEngine.canSwitchPCTarget():
                addExtraButtonAt(3, "TARGET", "Switch target", "switchtarget")
            
            var canToggleDynJoiners = sexEngine.canToggleDynamicJoiners()
            if canToggleDynJoiners:
                if sexEngine.didPCAllowDynamicJoiners():
                    addExtraButton("Disallow joiners", "", "toggle_dynamic_join")
                else:
                    addExtraButton("Allow joiners", "", "toggle_dynamic_join")
            
            if sexEngine.canChooseDomAutonomy():
                if !sexEngine.isDomAutonomyEnabled():
                    addExtraButton("Enable dom autonomy", "", "toggle_dom_autonomy")
                else:
                    addExtraButton("Disable dom autonomy", "", "toggle_dom_autonomy")
            
            if currentCategory.size() > 0:
                addButton("Back", "Back to previous menu", "backbutton")
            
            var theTargetID = sexEngine.getPCTarget()
            for domID in sexEngine.getDoms():
                var domInfo = sexEngine.getDomInfo(domID)
                sayn(domInfo.getInfoStringFinal(theTargetID == domID))
            for subID in sexEngine.getSubs():
                var subInfo = sexEngine.getSubInfo(subID)
                sayn(subInfo.getInfoStringFinal(theTargetID == subID))
            sayn("")

            var theActions = sexEngine.getActionsForCharID("pc", true)
            for actionInfo in theActions:
                var actionCategory = []
                if "category" in actionInfo:
                    actionCategory = actionInfo["category"]
                
                if currentCategory == actionCategory:
                    var desc = "No description provided"
                    if actionInfo.has("desc"):
                        desc = actionInfo["desc"]
                    if actionInfo.has("chance") && actionInfo["chance"] != null:
                        desc = "Success chance: " + str(Util.roundF(actionInfo["chance"], 1)) + "%\n" + desc
                    addButton(actionInfo["name"], desc, "doAction", [actionInfo])
            
            addCategoryButtons(theActions)
        
        else:
            addButton("LEAVE", "The sex has ended", "endthescene")

func _react(_action: String, _args):
    if _action == "stopsex" || _action == "endthescene":
        sexEngine.endSex()
        endScene()
        return
    
    if _action == "toggle_dom_autonomy":
        sexEngine.toggleDomAutonomy()
        return
    
    if _action == "toggle_dynamic_join":
        sexEngine.toggleDynamicJoiners()
        return
    
    if _action == "simulatesex":
        var turns = 100
        while !sexEngine.hasSexEnded() && turns > 0:
            turns -= 1
            sexEngine.doAction({id = "auto"})
            processTime(60)
        return
    
    if _action == "doAction":
        currentCategory = []
        sexEngine.doAction(_args[0])
        processTime(60)
        setState("")  
        return
    
    if _action == "backbutton":
        if currentCategory.size() > 0:
            currentCategory.pop_back()
        setState("")
        return
    
    if _action == "switchtarget":
        sexEngine.switchPCTarget()
        setState("")
        return
    
    if _action == "pickcategory":
        currentCategory.append(_args[0])
        setState("")
        return

    setState(_action)

func addCategoryButtons(theActions):
    var categoryButtons = {}
    for actionInfo in theActions:
        var actionCategory = []
        if "category" in actionInfo:
            actionCategory = actionInfo["category"]
        
        if currentCategory.size() >= actionCategory.size():
            continue
        
        var good = true
        for i in range(currentCategory.size()):
            if currentCategory[i] != actionCategory[i]:
                good = false
                break
        if !good:
            continue
        
        var newCategory = actionCategory[currentCategory.size()]
        if !categoryButtons.has(newCategory):
            categoryButtons[newCategory] = true
            addButton("!" + newCategory, "", "pickcategory", [newCategory])

func _onSceneEnd():
    if sexEngine:
        sexEngine.endSex()

func supportsShowingPawns() -> bool:
    return true