extends ItemBase

func _init():
	id = "BunnySuitTail"

func getVisibleName():
	return "Bunny Suit Tail"

func getDescription():
	return "a Tail for a Bunny Suit"

func getClothingSlot():
	return InventorySlot.Anal

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"Bunny Suit Tail": "res://Modules/BunnySuitModule/BunnySuitTail/BunnySuitTail.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your Tail"
	else:
		return "take off your Tail"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your Tail"
	else:
		return "put on your Tail"

func getPrice():
	return 40

func getTags():
	return [
		ItemTag.SexEngineCanApply,
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SoldByUnderwearVendomat,
		ItemTag.SoldByGeneralVendomat,
	]

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [15]),
		buff(Buff.ForcedObedienceBuff, [15]),
		buff(Buff.EncounterChanceModifierInmatesBuff, [10]),
		]

func getInventoryImage():
	return "res://Modules/BunnySuitModule/BunnySuitTail/icon.tres"
