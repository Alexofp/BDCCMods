extends QuestBase

func _init():
	id = "BunnySuitQuest"

func getVisibleName():
	return "Bunny Suit Collection"

func getProgress():
	var result = []
	
	result.append("The mysterious vendor told you she wants the full bunny suit.")
	result.append("Service clients and take cum to earn pieces.")
	result.append("You were told after you reach each goal, work again to gain your reward...")
	result.append("")
	
	var clients = GM.main.getModuleFlag("BunnySuit", "ProstitutionClientsServiced", 0)
	result.append("Clients serviced: " + str(clients) + " / 8 (Top)")
	result.append("Clients serviced: " + str(clients) + " / 20 (Stockings)")
	result.append("")
	
	var cum_holes = 0
	var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
	if vagina and vagina.has_method("getOrifice"):
		var orifice = vagina.getOrifice()
		if orifice:
			cum_holes += orifice.getFluidAmount()
	
	var anus = GM.pc.getBodypart(BodypartSlot.Anus)
	if anus and anus.has_method("getOrifice"):
		var orifice = anus.getOrifice()
		if orifice:
			cum_holes += orifice.getFluidAmount()
	
	result.append("Cum in holes: " + str(int(cum_holes)) + " / 8000 (Tail)")
	result.append("More Cum in holes: " + str(int(cum_holes)) + " / 12000 (Heels)")
	result.append("")
	
	result.append("Collected pieces:")
	result.append("   " + ("✓" if hasBunnyPiece("BunnySuitEars") else "☐") + " Bunny Ears")
	result.append("   " + ("✓" if hasBunnyPiece("BunnySuitChest") else "☐") + " Bunny Suit Top")
	result.append("   " + ("✓" if hasBunnyPiece("BunnySuitStockings") else "☐") + " Bunny Suit Stockings")
	result.append("   " + ("✓" if hasBunnyPiece("BunnySuitTail") else "☐") + " Bunny Tail")
	result.append("   " + ("✓" if hasBunnyPiece("BunnySuitHeels") else "☐") + " Bunny Suit Heels")
	
	return result

func isVisible():
	return GM.main.getModuleFlag("BunnySuit", "BunnySuitQuestStarted", false)

func isCompleted():
	return hasBunnyPiece("BunnySuitEars") && \
		   hasBunnyPiece("BunnySuitChest") && \
		   hasBunnyPiece("BunnySuitStockings") && \
		   hasBunnyPiece("BunnySuitTail") && \
		   hasBunnyPiece("BunnySuitHeels")

func hasBunnyPiece(piece_id):
	var inv = GM.pc.getInventory()
	
	if inv.hasItemID(piece_id):
		return true
	
	if inv.has_method("hasItemIDEquipped"):
		if inv.hasItemIDEquipped(piece_id):
			return true
	
	return false

func onQuestUpdate():
	check_for_unlocks()

func check_for_unlocks():
	var unlocker = load("res://Modules/BunnySuitModule/BunnySuitPieceUnlocker.gd").new()
	unlocker.check_for_unlocks()