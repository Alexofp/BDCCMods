extends ItemBase

func _init():
	id = "BunnySuitEars"

func getVisibleName():
	return "Bunny Suit Ears"

func getDescription():
	return "Bunny Ears for a Bunny Suit"

func getClothingSlot():
	return InventorySlot.Unique

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"Bunny Ears": "res://Modules/BunnySuitModule/BunnySuitEars/BunnySuitEars.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your Bunny Ears"
	else:
		return "take off your Bunny Ears"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your Bunny Ears"
	else:
		return "put on your Bunny Ears"

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [15]),
		buff(Buff.VirilityBuff, [35]),
		buff(Buff.ForcedObedienceBuff, [30]),
		]

func getInventoryImage():
	return "res://Modules/BunnySuitModule/BunnySuitEars/icon.tres"

func onDollUpdate(_doll : Doll3D, _zone, _dollpart):
	updateHead(_doll, _dollpart)
	if(canDye() && _dollpart != null && _dollpart.has_method("setColor")):
		_dollpart.setColor(clothesColor)

func updateHead(_doll: Doll3D, _dollpart: Node):
	var stateID = ""
	if _dollpart.has_node("Layer1") && _dollpart.get_node("Layer1").has_node("HeadStatePicker"):
		var statePicker = _dollpart.get_node("Layer1").get_node("HeadStatePicker")
		var head = getWearer().getBodypart("head")
		var headID = head.id
		stateID = powerLoomMatchID(headID)# Fennec -> Feline, Bulldog -> Small Horse, Fox -> Canine
		if stateID == "":
			stateID = powerLoomGuessID(head, statePicker)

	_doll.setState("headtype", stateID)

func powerLoomMatchID(headID: String) -> String:
	if headID in ["caninehead", "bulldoghead", "dragonhead", "felinehead", "fennechead", "foxhead", "horsehead", "horseheadbig", "humanhead", "wolfhead"]:
		match headID:
			"bulldoghead":
				headID = "horsehead"
			"fennechead":
				headID = "felinehead"
			"foxhead":
				headID = "caninehead"
		return headID
	return ""

func powerLoomGuessID(head, statePicker) -> String:# For modded bodparts
	var moddedHeadLenght = head.getHeadLength()
	var headLenghts = {"caninehead": 0.55, "felinehead": 0.25, "deagonhead": 0.7, "horseheadbig": 1.0, "humanhead": 0, "wolfhead": 0.6}
	var states = statePicker.get_children()
	var smallestDifference = {"part": "none", "value": 10}
	for state in states:
		var stateValue = state.stateValue
		var difference = abs(moddedHeadLenght - headLenghts[stateValue])
		if difference < smallestDifference["value"]:
			smallestDifference["value"] = difference
			smallestDifference["part"] = stateValue

	return smallestDifference["part"]
