extends Module

func _init():
	id = "BunnySuit"
	author = "WolfStarArt and stinkyfentman"

	items = [
		"res://Modules/BunnySuitModule/BunnySuit/BunnySuit.gd",
		"res://Modules/BunnySuitModule/BunnySuitTail/BunnySuitTail.gd",
		"res://Modules/BunnySuitModule/BunnySuitStockings/BunnySuitStockings.gd",
		"res://Modules/BunnySuitModule/BunnySuitHeels/BunnySuitHeels.gd",
		"res://Modules/BunnySuitModule/BunnySuitEars/BunnySuitEars.gd",
	]

	quests = [
		"res://Modules/BunnySuitModule/BunnySuitQuest.gd",
	]

	events = [
		"res://Modules/BunnySuitModule/BunnyProstitutionEvent.gd",
		"res://Modules/BunnySuitModule/BunnySuitQuestGiver.gd",
	]

	scenes = [
		"res://Modules/BunnySuitModule/BunnyProstitutionScene.gd",
		"res://Modules/BunnySuitModule/BunnySuitPieceUnlocker.gd",
	]

func getFlags():
	return {
		"BunnySuitQuestStarted": flag(FlagType.Bool),
		"ProstitutionClientsServiced": flag(FlagType.Number),
		"TotalCumInPussy": flag(FlagType.Number),
		"TotalCumInAss": flag(FlagType.Number),
		"TotalCumInHoles": flag(FlagType.Number),
		"TotalCumOnBody": flag(FlagType.Number),
	}
