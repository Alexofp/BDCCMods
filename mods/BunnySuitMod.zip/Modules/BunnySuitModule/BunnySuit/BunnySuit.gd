extends ItemBase

func _init():
	id = "BunnySuitChest"

func getVisibleName():
	return "Bunny Suit"

func getDescription():
	return "A Bunny Suit?"

func getClothingSlot():
	return InventorySlot.Body

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"Bunny Suit": "res://Modules/BunnySuitModule/BunnySuit/BunnySuit.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your Bunny Suit"
	else:
		return "take off your Bunny Suit"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your Bunny Suit"
	else:
		return "put on your Bunny Suit"

func generateItemState():
	itemState = ShirtAndShortsState.new()

func getPrice():
	return 150

func getTags():
	return [
		ItemTag.SexEngineCanApply,
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SoldByUnderwearVendomat,
		ItemTag.SoldByGeneralVendomat,
		ItemTag.SoldByTheAnnouncer,
		ItemTag.SoldByAlexRynard,
		]

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [20]),
		buff(Buff.FertilityBuff, [10]),
		buff(Buff.VirilityBuff, [10]),
		buff(Buff.ForcedObedienceBuff, [25]),
		buff(Buff.EncounterChanceModifierInmatesBuff, [20]),
		]

func getInventoryImage():
	return "res://Modules/BunnySuitModule/BunnySuit/icon.tres"
