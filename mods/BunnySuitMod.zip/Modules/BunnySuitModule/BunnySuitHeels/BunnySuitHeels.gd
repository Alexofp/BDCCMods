extends ItemBase

func _init():
	id = "BunnySuitHeels"

func getVisibleName():
	return "Bunny Suit Heels"

func getDescription():
	return "High heels for the bunny suit."

func getClothingSlot():
	return InventorySlot.Ankles

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"Heels": "res://Modules/BunnySuitModule/BunnySuitHeels/BunnySuitHeels.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your Bunny Suit Heels"
	else:
		return "take off your Bunny Suit Heels"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your Bunny Suit Heels"
	else:
		return "put on your Bunny Suit Heels"

func getPartZIndex():
	return 1 

func getPrice():
	return 40

func getTags():
	return [
		ItemTag.CanBeForcedByGuards,
		ItemTag.CanBeForcedInStocks,
		ItemTag.SoldByUnderwearVendomat,
		ItemTag.SexEngineCanApply,
	]

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [5]),
		buff(Buff.ForcedObedienceBuff, [25]),
		buff(Buff.AmbientPainBuff, [20]),
		buff(Buff.DodgeChanceBuff, [-30])
	]

func getInventoryImage():
	return "res://Modules/BunnySuitModule/BunnySuitHeels/icon.tres"