extends "res://Scenes/SceneBase.gd"

var currentNPC = null
var lastNpcID = ""
var Unlocker = preload("res://Modules/BunnySuitModule/BunnySuitPieceUnlocker.gd")

func _init():
	sceneID = "BunnyProstitutionScene"

func _reactInit():
	addCharacter("pc")
	GM.pc.setLocation("main_punishment_spot")
	aimCamera("main_punishment_spot")
	playAnimation(StageScene.Solo, "stand")

func _run():
	
	var clients = GM.main.getModuleFlag("BunnySuit", "ProstitutionClientsServiced", 0)
	
	var cum_holes = 0
	var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
	if vagina and vagina.has_method("getOrifice"):
		var orifice = vagina.getOrifice()
		if orifice and orifice.has_method("getFluidAmount"):
			cum_holes += orifice.getFluidAmount()
	
	var anus = GM.pc.getBodypart(BodypartSlot.Anus)
	if anus and anus.has_method("getOrifice"):
		var orifice = anus.getOrifice()
		if orifice and orifice.has_method("getFluidAmount"):
			cum_holes += orifice.getFluidAmount()
	
	if clients >= 8 and not hasBunnyPiece("BunnySuitChest"):
		GM.pc.getInventory().addItemID("BunnySuitChest")
		GM.main.addMessage("You earned: Bunny Suit Top!")
	
	if clients >= 20 and not hasBunnyPiece("BunnySuitStockings"):
		GM.pc.getInventory().addItemID("BunnySuitStockings")
		GM.main.addMessage("You earned: Bunny Suit Stockings!")
	
	if cum_holes >= 8000 and not hasBunnyPiece("BunnySuitTail"):
		GM.pc.getInventory().addItemID("BunnySuitTail")
		GM.main.addMessage("You earned: Bunny Tail!")
	
	if cum_holes >= 12000 and not hasBunnyPiece("BunnySuitHeels"):
		GM.pc.getInventory().addItemID("BunnySuitHeels")
		GM.main.addMessage("You earned: Bunny Suit Heels!")

	
	if state == "":
		saynn("You strut around in your sexy bunny suit, looking for clients...")
		showNearbyCharacters()
		
		addButton("Work the area", "Look for clients", "look_for_client")
		addButton("Leave", "Stop working for now", "endscene")
		return

	if state == "look_for_client":
		var npcID = getRandomNpcID()
		if !npcID:
			saynn("No one seems interested right now...")
			addButton("Keep trying", "", "look_for_client")
			addButton("Leave", "", "endscene")
			return
		
		lastNpcID = npcID
		currentNPC = npcID
		if !hasCharacter(npcID):
			addCharacter(npcID)
		
		var npcName = "The client"
		var npc = GlobalRegistry.getCharacter(npcID)
		if npc:
			npcName = npc.getName()
		
		var roll = randf()
		
		if roll < 0.5:
			saynn(npcName + " eyes you hungrily.")
			saynn('"That bunny suit... You taking clients?"')
			addButton("Prepare for sex", "Start paid session", "before_sex")
			addButton("Refuse", "Not now", "endscene")
		else:
			var item = getRandomValuableItem()
			if item:
				saynn(npcName + " points at something you're carrying.")
				saynn('"Hey you, give me that ' + item.getVisibleName() + '."')
				addButton("Give item", "Hand it over", "give_item", [item])
				addButton("Refuse", "Keep your stuff", "endscene")
			else:
				saynn(npcName + " eyes you hungrily.")
				saynn('"That bunny suit... You taking clients?"')
				addButton("Prepare for sex", "Start paid session", "before_sex")
				addButton("Refuse", "Not now", "endscene")
		return

	if state == "before_sex":
		saynn("You prepare every inch of your body before sex, realizing that it is too late to back out...")
		giveRewards(lastNpcID, true)
		addButton("I am ready...", "Begin the session", "start_sex")
		return

func getRandomValuableItem():
	var items = GM.pc.getInventory().getAllItems()
	if items.size() == 0:
		return null
	for item in items:
		if !item.isRestraint():
			return item
	return RNG.pick(items)

func give_item(item):
	GM.pc.getInventory().removeItem(item)
	saynn("You hand over the " + item.getVisibleName() + ".")
	giveRewards(lastNpcID, true)
	addButton("Continue", "", "look_for_client")

func start_sex():
	if currentNPC:
		runScene("GenericSexScene", [currentNPC, "pc"], "subbysex")
		if currentNPC:
			removeCharacter(currentNPC)
		currentNPC = null
		lastNpcID = ""
		endScene()
	return

func giveRewards(_npcID, _isSmall = false, multiplier = 1.0):
	var base = 55 if !_isSmall else 25
	var earnings = int((base + RNG.randi_range(25, 90)) * multiplier)
	
	if hasFullBunnySuit(GM.pc):
		earnings = int(earnings * 1.65)
		saynn("Your complete bunny suit made the client very generous!")
	
	var tribute = 5
	if hasFullBunnySuit(GM.pc):
		tribute = 10
	
	GM.main.increaseModuleFlag("BunnySuit", "ProstitutionClientsServiced", 1)
	
	if Unlocker:
		Unlocker.check_for_unlocks()
	
	updateCumFlags()
	
	GM.pc.addMoney(earnings)
	saynn("You earned " + str(earnings) + " credits.\n(Plus " + str(tribute) + " slut points tribute!)")

func updateCumFlags():
	var cum_holes = 0
	var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
	if vagina and vagina.has_method("getOrifice"):
		var orifice = vagina.getOrifice()
		if orifice and orifice.has_method("getFluidAmount"):
			cum_holes += orifice.getFluidAmount()
	
	var anus = GM.pc.getBodypart(BodypartSlot.Anus)
	if anus and anus.has_method("getOrifice"):
		var orifice = anus.getOrifice()
		if orifice and orifice.has_method("getFluidAmount"):
			cum_holes += orifice.getFluidAmount()
	
	var cum_body = 0
	if GM.pc.has_method("bodyFluids") and GM.pc.bodyFluids.has_method("getFluidAmount"):
		cum_body = GM.pc.bodyFluids.getFluidAmount()
	
	GM.main.setModuleFlag("BunnySuit", "TotalCumInHoles", cum_holes)
	GM.main.setModuleFlag("BunnySuit", "TotalCumOnBody", cum_body)

func showNearbyCharacters():
	saynn("The area has some people around...")

func getRandomNpcID():
	return RNG.pick(GM.main.getDynamicCharacters())

func hasFullBunnySuit(player):
	var inv = player.getInventory()
	return (
		inv.hasItemIDEquipped("BunnySuitChest") &&
		inv.hasItemIDEquipped("BunnySuitStockings") &&
		inv.hasItemIDEquipped("BunnySuitEars") &&
		inv.hasItemIDEquipped("BunnySuitTail") &&
		inv.hasItemIDEquipped("BunnySuitHeels")
	)

func hasBunnyPiece(piece_id):
	var inv = GM.pc.getInventory()
	
	if inv.hasItemID(piece_id):
		return true
	
	if inv.has_method("hasItemIDEquipped"):
		if inv.hasItemIDEquipped(piece_id):
			return true
	
	return false

func hasCharacter(charID):
	return GM.main.getCharacter(charID) != null

func _react(_action: String, _args):
	if _action == "start_sex":
		start_sex()
		return
	
	if _action == "before_sex":
		setState("before_sex")
		return
	
	if _action == "endscene":
		endScene()
		return
	
	if _action == "give_item":
		give_item(_args[0])
		return
	
	setState(_action)