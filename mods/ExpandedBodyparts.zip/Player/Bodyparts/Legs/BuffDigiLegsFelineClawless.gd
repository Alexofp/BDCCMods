extends BodypartLeg

func _init():
	visibleName = "Buff Feline Clawless DigiLegs"
	id = "BuffDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Legs/DigiLegs/ExpandedBodyparts/Buff/BuffDigiLegsFelineClawless.tscn"
func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Feline Clawless DigiLegs (ExpandedBodyparts)"
