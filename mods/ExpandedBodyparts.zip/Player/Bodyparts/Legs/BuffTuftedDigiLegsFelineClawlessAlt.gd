extends BodypartLeg

func _init():
	visibleName = "Buff Tuffed Feline Clawless DigiLegs Alt"
	id = "BuffTuffedDigiLegsFelineClawlessAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Legs/DigiLegs/ExpandedBodyparts/Buff/BuffTuffedDigiLegsFelineClawlessAlt.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Tuffed Feline Clawless DigiLegs Alt (ExpandedBodyparts)"
