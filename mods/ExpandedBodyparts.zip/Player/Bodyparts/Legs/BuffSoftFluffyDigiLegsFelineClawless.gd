extends BodypartLeg

func _init():
	visibleName = "Buff S & F Feline Clawless DigiLegs"
	id = "BuffSoftFluffyDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Legs/DigiLegs/ExpandedBodyparts/Buff/BuffSoftFluffyDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Soft and Fluffy Feline Clawless DigiLegs (ExpandedBodyparts)"
