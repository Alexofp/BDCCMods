extends BodypartLeg

func _init():
	visibleName = "Buff Fluffy Feline Clawless DigiLegs"
	id = "BuffFluffyDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Legs/DigiLegs/ExpandedBodyparts/Buff/BuffFluffyDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Fluffy Feline Clawless DigiLegs (ExpandedBodyparts)"
