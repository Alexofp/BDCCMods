extends BodypartLeg

func _init():
	visibleName = "B & F Feline Clawless DigiLegs"
	id = "BuffFluffyDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Legs/DigiLegs/BuffFluffyDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "Buff and Fluffy Feline Clawless DigiLegs (ExpandedBodyparts)"
