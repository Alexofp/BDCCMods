extends BodypartLeg

func _init():
	visibleName = "Buff Soft Feline Clawless DigiLegs"
	id = "BuffSoftDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Legs/DigiLegs/ExpandedBodyparts/Buff/BuffSoftDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Soft Feline Clawless DigiLegs (ExpandedBodyparts)"
