extends BodypartBody

func _init():
	visibleName = "Buff Mizutsune Body"
	id = "BuffMizutsuneBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/MH Species/Buff/BuffMizutsuneBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Mizutsune Body (ExpandedBodyparts)"
