extends BodypartBody

func _init():
	visibleName = "Buff Odogaron Body"
	id = "BuffOdogaronBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/MH Species/Buff/BuffOdogaronBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Odogaron Body (ExpandedBodyparts)"
