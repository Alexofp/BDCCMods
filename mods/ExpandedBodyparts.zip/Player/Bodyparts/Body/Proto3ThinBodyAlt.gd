extends BodypartBody

func _init():
	visibleName = "Proto3 Thin Body Alt"
	id = "Proto3ThinBodyAlt"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Protogen/Thin/Proto3ThinBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Proto3 Thin Body Alt (ExpandedBodyparts)"
