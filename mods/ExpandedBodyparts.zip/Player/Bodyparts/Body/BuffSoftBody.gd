extends BodypartBody

func _init():
	visibleName = "Buff Soft Body"
	id = "BuffSoftBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Buff/BuffSoftBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Soft Body (ExpandedBodyparts)"
