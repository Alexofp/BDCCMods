extends BodypartBody

func _init():
	visibleName = "Proto2 Thin Body Alt"
	id = "Proto2ThinBodyAlt"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Protogen/Thin/Proto2ThinBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Proto2 Thin Body Alt (ExpandedBodyparts)"
