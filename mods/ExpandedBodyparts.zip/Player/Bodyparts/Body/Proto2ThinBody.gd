extends BodypartBody

func _init():
	visibleName = "Proto2 Thin Body"
	id = "Proto2ThinBody"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Protogen/Thin/Proto2ThinBody.tscn"

func getCharacterCreatorDesc():
	return "Proto2 Thin Body (ExpandedBodyparts)"
