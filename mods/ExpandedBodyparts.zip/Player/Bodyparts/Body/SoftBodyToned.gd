extends BodypartBody

func _init():
	visibleName = "TonedSoft Body"
	id = "TonedSoftBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Toned/TonedSoftBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Soft Body (ExpandedBodyparts)"
