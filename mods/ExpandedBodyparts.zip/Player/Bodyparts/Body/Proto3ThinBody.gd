extends BodypartBody

func _init():
	visibleName = "Proto3 Thin Body"
	id = "Proto3ThinBody"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Protogen/Thin/Proto3ThinBody.tscn"

func getCharacterCreatorDesc():
	return "Proto3 Thin Body (ExpandedBodyparts)"
