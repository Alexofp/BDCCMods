extends BodypartBody

func _init():
	visibleName = "Proto1 Thin Body"
	id = "Proto1ThinBody"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Protogen/Thin/Proto1ThinBody.tscn"

func getCharacterCreatorDesc():
	return "Proto1 Thin Body (ExpandedBodyparts)"
