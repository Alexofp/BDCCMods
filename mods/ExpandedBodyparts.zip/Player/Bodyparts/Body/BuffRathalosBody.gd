extends BodypartBody

func _init():
	visibleName = "Buff Rathalos Body"
	id = "BuffRathalosBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/MH Species/Buff/BuffRathalosBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Rathalos Body (ExpandedBodyparts)"
