extends BodypartBody

func _init():
	visibleName = "Toned Soft Body Alt"
	id = "TonedSoftBodyAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Toned/TonedSoftBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Toned Soft Body Alt (ExpandedBodyparts)"
