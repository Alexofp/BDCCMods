extends BodypartBody

func _init():
	visibleName = "Buff Nergi Body"
	id = "BuffNergiBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/MH Species/Buff/BuffNergiBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Nergi Body (ExpandedBodyparts)"
