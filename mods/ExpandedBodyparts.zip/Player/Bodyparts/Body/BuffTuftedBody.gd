extends BodypartBody

func _init():
	visibleName = "Buff Tufted Body"
	id = "BuffTuftedBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Buff/BuffTuftedBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Tufted Body (ExpandedBodyparts)"
