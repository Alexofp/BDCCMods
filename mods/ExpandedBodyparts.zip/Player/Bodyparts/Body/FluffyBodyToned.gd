extends BodypartBody

func _init():
	visibleName = "Toned Fluffy Body"
	id = "TonedFluffyBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Toned/TonedFluffyBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Fluffy Body (ExpandedBodyparts)"
