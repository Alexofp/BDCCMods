extends BodypartBody

func _init():
	visibleName = "Proto1 Thin Body Alt"
	id = "Proto1ThinBodyAlt"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Protogen/Thin/Proto1ThinBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Proto1 Thin Body Alt (ExpandedBodyparts)"
