extends BodypartBody

func _init():
	visibleName = "Buff Soft Body Alt"
	id = "BuffSoftBodyAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Body/ExpandedBodyparts/Buff/BuffSoftBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Buff Soft Body Alt (ExpandedBodyparts)"
