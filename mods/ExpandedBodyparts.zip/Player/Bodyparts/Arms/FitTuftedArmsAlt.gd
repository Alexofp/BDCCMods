extends BodypartArms

func _init():
	visibleName = "Fit Tufted Arms Alt"
	id = "FitTuftedArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitFluffyTuftedArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Tufted Arms Alt (ExpandedBodyparts)"
