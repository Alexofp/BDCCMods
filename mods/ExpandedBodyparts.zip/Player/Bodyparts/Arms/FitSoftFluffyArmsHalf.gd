extends BodypartArms

func _init():
	visibleName = "Fit S & F Arms Half"
	id = "FitSoftFluffyArmsHalf"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitSoftFluffyArmsHalf.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Soft and Fluffy Arms Half (ExpandedBodyparts)"
