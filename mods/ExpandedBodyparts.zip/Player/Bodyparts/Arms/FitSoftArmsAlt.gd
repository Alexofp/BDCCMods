extends BodypartArms

func _init():
	visibleName = "Fit Soft Arms Alt"
	id = "FitSoftArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitSoftArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Soft Arms Alt (ExpandedBodyparts)"
