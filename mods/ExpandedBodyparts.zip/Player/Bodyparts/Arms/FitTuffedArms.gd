extends BodypartArms

func _init():
	visibleName = "Fit Tuffed Arms"
	id = "FitTuffedArms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitTuffedArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Tuffed Arms (ExpandedBodyparts)"
