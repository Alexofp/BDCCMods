extends BodypartArms

func _init():
	visibleName = "Fit F & T Arms Alt"
	id = "FitFluffyTuffedArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitFluffyTuffedArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy and Tuffed Arms Alt (ExpandedBodyparts)"
