extends BodypartArms

func _init():
	visibleName = "Fit F & T Arms"
	id = "FitFluffyTuffedArms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitFluffyTuffedArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy and Tuffed Arms (ExpandedBodyparts)"
