extends BodypartArms

func _init():
	visibleName = "Fit F & T Arms Half"
	id = "FitFluffyTuftedArmsHalf"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Arms/BuffArms/ExpandedBodyparts/Fit/FitFluffyTuftedArmsHalf.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy and Tufted Arms Half (ExpandedBodyparts)"
