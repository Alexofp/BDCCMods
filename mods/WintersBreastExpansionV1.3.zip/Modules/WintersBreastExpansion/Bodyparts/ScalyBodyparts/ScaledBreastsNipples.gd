extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateBreastsScaleable.gd"
func _init():
	visibleName = "Scaled nipple breasts"
	id = "scaledbreastnipples"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastNipples/ScaledBreastNippleFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastNipples/ScaledBreastNipple.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
