extends WorldEditBase

var roomIDs = [
	"main_green_corridor1",
	"main_green_corridor2",
	"main_green_corridor3",
	"main_green_corridor4",
	"main_green_corridor5",
	"main_green_corridor6",
	"main_green_secret",
]
var extra = [
	"yard_stars_green"
]



func _init():
	id = "GreenWorldEdit"
#	isRegular = true  # true = apply() is called after every tick
	
func apply(world: GameWorld):
	if(getFlag("GreenThumb.isGardener",false)):
		for entry in roomIDs:
			var theroom = GM.world.getRoomByID(entry)
			world.setRoomGridColor(entry, RoomStuff.RoomColor.White)
			world.setRoomColor(entry, RoomStuff.RoomColor.Green)
			world.setRoomSprite(entry, RoomStuff.RoomSprite.IMPORTANT)
			if(theroom.loctag_Greenhouses):
				theroom.loctag_Greenhouses = false
		var _dummy = GM.world.getRoomByID("yard_stars_green")
		_dummy.roomDescription = "A set of stairs lead up to the greenhouses with markings on the floor remind inmates that the greenhouses are off-limits for them. Luckily, you're allowed to enter Greenhouse 1 for work reasons."
		if(getFlag("GreenThumb.tutorial2",false)):
			GM.world.getRoomByID("main_green_corridor1").roomDescription = "This entrance area of the greenhouses look largely unused with windows looking out over the side yard. You've set up the hydroponics and grow beds in this room, filling the once-empty space with the scent of damp soil. More crates and unfinished construction materials lead around this first building. A few guards are eyeing you with suspicion, but they leave you alone."
			GM.world.getRoomByID("main_green_corridor2").roomDescription = "This half of the Greenhouse is built into the cavern. Crates are still stacked around but all the hydroponics and grow beds are all set up. The staff roster posted on the wall is empty aside from your prisoner number. Whiteboards, notebooks, and science equipment are all sitting on the tables. You have no idea what they are for. \n\nAn Elevator sits off in the corner, watched by a camera and requires ID and a meeting over an intercom to use. Wherever it goes, Guards can be seen coming and going from it, with a few hanging around the spot. \nBest not go near it."
			GM.world.getRoomByID("main_green_corridor4").roomDescription = "This half of the Greenhouse is built into the cavern. Crates are still stacked around but all the hydroponics and grow beds are all set up. The staff roster posted on the wall is empty aside from your prisoner number. Whiteboards, notebooks, and science equipment are all sitting on the tables. You have no idea what they are for. \n\nAnother Elevator is north of here, but it lies completely unfinished, with a permanently unpowered closed glass door showing a dark and empty elevator shaft."
			GM.world.getRoomByID("main_green_corridor5").roomDescription = "This half of the Greenhouse is built into the cavern. Crates are still stacked around but all the hydroponics and grow beds are all set up. The staff roster posted on the wall is empty aside from your prisoner number. Whiteboards, notebooks, and science equipment are all sitting on the tables. You have no idea what they are for."
			GM.world.getRoomByID("main_green_corridor3").roomDescription = "This entrance area of the greenhouses look largely unused with windows looking out over the side yard. You've set up the hydroponics and grow beds in this room, filling the once-empty space with the scent of damp soil. More crates and unfinished construction materials lead around this first building. A few guards are eyeing you with suspicion, but they leave you alone."
			GM.world.getRoomByID("main_green_corridor6").roomDescription = "This entrance area of the greenhouses look largely unused with windows looking out over the side yard. You've set up the hydroponics and grow beds in this room, filling the once-empty space with the scent of damp soil. More crates and unfinished construction materials lead around this first building. A few guards are eyeing you with suspicion, but they leave you alone. \n\nTo the south the building opens up to a small balcony and another greenhouse building. That one is still [color=red]off limits[/color] to you."
			
			
	else:
		return false
	
#setRoomGridColor
#setRoomColor
#setRoomSprite
#getRoomByID
#isRoomInZone
#isLocSafe
