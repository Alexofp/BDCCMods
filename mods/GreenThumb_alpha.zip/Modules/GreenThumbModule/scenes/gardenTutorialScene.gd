extends SceneBase

# if water = 0 growth is halted. water is consumed per growth stage
# fertilizer increases yield. large time cost?

func _init():
	sceneID = "gardenTutorialScene"
	
func _initScene(_args = []):
	pass
		
		
func _run():
	if(state == ""):
		var day1 = getFlag("GreenThumb.tutorialrun",false)
		var day2 = getFlag("GreenThumb.tutorial1",false)
		var day3 = getFlag("GreenThumb.tutorial2",false)
		addCharacter("wyra")
		playAnimation(StageScene.Duo, "stand", {pc="wyra", flipNPC=false, npc="pc"})
		if(GM.main.getTime() > 12*60*60):
			saynn("Wyra's not here. He probably left when you didn't show up. He did say to meet him in the morning...")
			addButton("Nevermind","Try again tomorrow","endthescene")
		if(day3):
			saynn("You meet Wyra for your third day of greenhouse setup.")
			addButton("Continue","desc","setup3")
			addButton("Cancel","Not today","endthescene")
		elif(day2):
			saynn("You meet Wyra for your second day of greenhouse setup.")
			
			saynn("[say=wyra] Come on, {pc.name}. Still plenty of work ahead of us. [/say]")
			if(GM.pc.isFullyNaked()):
				saynn("He pauses, noticing your state of undress.")
				saynn("[say=wyra] And you're already prepared! That's the kind of initiative that'll get you promoted to junior greenhouse assistant![/say]")
			
			
			addButton("Continue","desc","setup2")
			addButton("Cancel","Not today","endthescene")
		elif(day1):
			saynn("Wyra meets you at the door with a smile that's perhaps too enthusiastic for this time of day. In his hands, he holds some green fabric.")
			saynn("[say=wyra] Ready to get started, intern? This'll take pretty much all day, so cancel your other plans. [/say]")
			
			addButton("Continue","desc","dressing")
			addButton("Cancel","Not today","endthescene")
		else:
			saynn("Something went wrong.")
			addButton("it borken","desc","endthescene")
			
	if(state== "dressing"):

		saynn("[say=wyra] Before we get to work, though, you'll have to wear this. [/say]")
		
		saynn("He holds up the cloth, which is revealed to be an apron. It's the kind of thing you'd expect to wear when gardening.")
		saynn("However, when you reach out to take it, Wyra pulls back.")
		
		saynn("[say=wyra] I should clarify. You'll wear this, and [i]only[/i] this. Strip. [/say]")
		
		saynn("[say=pc] That looks pretty small... [/say]")
		
		saynn("[say=wyra] So? I've seen what you inmates get up to. In comparison, this is tame. Plus it's an easy way to show that you have permission to be in here. Unless you'd like the guards to stop you every 5 miuntes... [/say]")
		
		addButton("Continue","desc","dressing2")
		addButton("No way!","Not wearing that","endthescene")
		
	if(state == "dressing2"):
		var personality = GM.pc.getPersonality()
		if(GM.pc.isFullyNaked()):
			say("Well, it's more than you're currently wearing...")
		elif(personality.getStat("Subby")>=0.15):
			say("Well...it's humiliating, but you comply, blushing deeply.")
		elif(personality.getStat("Subby")<=-0.15):
			say("Fine. You're willing to play his game...for now.")
		else:
			say("You really should have expected this. But at least you're getting paid...")
		
		if(personality.getStat("Coward")>=0.30):
			saynn("Under Wyra's watchful eyes, you strip naked, doing your best to hide your naughty bits with your hands.")
		elif(personality.getStat("Coward")<=-0.30):
			saynn("If he wants a peek, you'll give him one. You boldly get naked, flauting your assets to the grinning gardener.")
		else:
			saynn("You awkwardly strip down, hoping that nobody in the yard is watching too closely.")
			
		saynn("Wyra tosses the apron at you, making no attempt to hide his voyeuristic gaze. It's skimpy, barely enough to cover you in front and leaving your bare ass hanging out in the back.")
			
		var inv = GM.pc.getInventory()
		inv.unequipSlot(InventorySlot.UnderwearTop)
		inv.unequipSlot(InventorySlot.UnderwearBottom)
		inv.unequipSlot(InventorySlot.Body)
		inv.forceEquipItemID("apronnaked")
		addButton("Continue","desc","setup1")
		
		
	if(state == "setup1"):
		aimCamera("main_green_corridor1")
		playAnimation(StageScene.Duo, "stand", {pc="wyra", flipNPC=true, npc="pc"})
		
		saynn("Wyra directs you to unpack crates and move bags of soil. There's also racks of full-spectrum sun lamps and what seems like meters upon meters of tubes and hoses.")
		saynn("[say=pc] Couldn't you get a cart instead of making me carry the bags of soil?[/say]")
		saynn("[say=wyra] Yeah, but you're an inmate, so you gotta do what I say. Plus, it builds character. [/say]")
		saynn("You suspect it has more to do with getting to ogle your butt.")
		addMessage("Each room in the greenhouse has one garden plot.\nEach plot will grow a single type of plant at a time.")
		addMessage("A plot must be tilled and prepared before planting.")
		addMessage("The different plant options have different growing time and selling price.")
		addButton("Continue","desc","conclude")
		
	if(state == "setup2"):
		aimCamera("main_green_corridor3")
		var inv = GM.pc.getInventory()
		inv.unequipSlot(InventorySlot.UnderwearTop)
		inv.unequipSlot(InventorySlot.UnderwearBottom)
		inv.unequipSlot(InventorySlot.Body)
		inv.forceEquipItemID("apronnaked")
		saynn("You quickly get changed into your garden 'outfit'.")
		saynn("Time to tackle the tubing. There's a bunch of different hoses, all tangled up - some for water, others for nutrient mix, even ductwork to divert some CO2 from the air scrubbers. You end up crawling into lots of tight spaces to connect things, while Wyra gets to enjoy the view.")
		saynn("[say=wyra] All the water is recycled, ya know. [/say]")
		saynn("[say=pc] So this comes from the same water we drink? [/say]")
		saynn("[say=wyra] Yep. So next time you're fucking in the showers, remember that you'll be drinking that. [/say]")
		addMessage("Once the seeds are planted, it will attempt to grow once every few in-game hours.")
		addMessage("It uses 1 water each time it grows.\nA plot must have water available for it to grow.")
		addButton("Continue","desc","conclude")
		
	if(state == "setup3"):
		aimCamera("main_green_corridor6")
		var inv = GM.pc.getInventory()
		inv.unequipSlot(InventorySlot.UnderwearTop)
		inv.unequipSlot(InventorySlot.UnderwearBottom)
		inv.unequipSlot(InventorySlot.Body)
		inv.forceEquipItemID("apronnaked")
		
		saynn("As the hours pass, you clean up empty crates and boxes, and get some soil samples for Wyra. The sun lamps flick on and the hydroponics gurgle. This is starting to look like a proper greenhouse! Then Wyra hands you some bags that have a...[i]unique[/i] smell.")
		saynn("[say=pc] Where does the fertilizer come from? [/say]")
		saynn("[say=wyra] You do not wanna know the answer, inmate. [/say]")
		addMessage("When a plot grows, it will use up 1 fertilizer (if there is any) to increase its yield.\nYield starts at 75%, meaning you will get 75% of the credits when harvesting.")
		addButton("Continue","desc","conclude")
		
	if(state == "conclude"):
		saynn("Whew! That was a hard day of work. You can't wait to hit the showers and then crawl into bed.")
		
		if(getFlag("GreenThumb.tutorial1",false) && getFlag("GreenThumb.tutorial2",false)):
			setFlag("GreenThumb.tutorialrun", false)
			setFlag("GreenThumb.tutorial1", false)
			setFlag("GreenThumb.isGardener", true)
			setFlag("GreenThumb.inGreenhouse", true)
			saynn("[say=wyra] Congrats, intern {pc.name}! You're now a full member of the greenhouse crew. Starting tomorrow, you'll have free access to Greenhouse 1.[/say]")
			
			saynn("Finally, the hard work is over. From now on, you can sit back and watch the plants grow. No more hitting rocks for you!")
			saynn("[say=wyra] If you need some help, or just want to chat, you can find me back here. Oh and you can keep the apron. Seeya around![/say]")
			var inv = GM.pc.getInventory()
			inv.unequipSlot(InventorySlot.Body)
			GM.main.applyWorldEdit("GreenWorldEdit")
			addMessage("Guard encounters within Greenhouse 1 are disabled during the day.")
			
			
		if(getFlag("GreenThumb.tutorial1",false)):
			setFlag("GreenThumb.tutorial2",true)
			setFlag("GreenThumb.inGreenhouse", true)
			saynn("[say=wyra] Nice work, intern {pc.name}. Same deal as before, come back tomorrow and we'll finish it up.[/say]")
			var inv = GM.pc.getInventory()
			inv.clearSlot(InventorySlot.Body)
			saynn("You should probably get dressed.")
		
		if(!getFlag("GreenThumb.tutorial1",false) && getFlag("GreenThumb.tutorialrun")):
			setFlag("GreenThumb.tutorial1",true)
			setFlag("GreenThumb.inGreenhouse", true)
			saynn("[say=wyra] See, that wasn't half bad! You've earned your pay. Come back bright and early tomorrow if you want more.[/say]")
			saynn("He transfers 6 work credits to you.")
			saynn("[say=wyra] Also, you can stop wearing the apron now. [/say]")
			var inv = GM.pc.getInventory()
			inv.clearSlot(InventorySlot.Body)
			saynn("You should probably get dressed.")
			
		addButton("Continue","desc","endthescene")
		GM.main.processTimeUntil(60*60*22)
		GM.pc.addStamina(-1*GM.pc.getMaxStamina())
		GM.pc.addCredits(6)
	
	
func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
		
	setState(_action)


#func playerchecks():
#
#	GM.pc.isInventorySlotBlocked()
#	GM.pc.isHeavilyPregnant()
#	GM.pc.isGagged()
#	GM.pc.hasBoundArms()
#	GM.pc.hasBoundLegs()
#	pass
