extends SceneBase

var seen1 = false
var seen2 = false

func _init():
	sceneID = "GardenIntro"
	
func _initScene(_args = []):
	if(not _args.empty()):
		setState(_args[0])
	else:
		setState("")

func _run():
	if(state == ""):

		saynn("You take a closer look at the glossy sign. \n\n\n\n")
		
		saynn("[center][b][color=green]Help Wanted! \n Tired of hitting rocks? We are seeking WELL-BEHAVED inmates to run the greenhouse! Inmates with good standing can apply by speaking to the greenhouse manager.[/color][/b][/center]")
		
		saynn("\n\n Having been inside the greenhouse, you’ve seen how only one of them grows anything.  You wonder if this labor shortage is related.")

		addButton("Manager?", "wtf who da greenhouse manager", "2")
		
	if(state == "2"):
		addCharacter("wyra")
		getCharacter("wyra").updateBodyparts()
		playAnimation(StageScene.Duo, "stand", {npc="pc", flipNPC=false, pc="wyra"})
#		say("[table=2][cell][img=64]res://Modules/GreenThumbModule/plant.png[/img][/cell][cell]")
		setFlag("GreenThumb.wyraIntroduced", true) 
		
		saynn("A feline-human hybrid exiting the greenhouse takes note of you. He smells of soil and growing things, and his engineer uniform is muddy.")
		
		saynn("[say=wyra]Hey, you interested?[/say]")

		saynn("[say=pc]Who, me?[/say]")

		saynn("[say=wyra]Yeah. Are you willing to work in the dirt? [/say]")
		saynn("He places a hand on his hip and appraises you.")
		var addstr = ""
		if(GM.pc.isFullyNaked()):
			if(GM.pc.hasBodypart(BodypartSlot.Breasts)):
				sayn("[say=wyra] Nice tits, by the way.[/say]")
			addstr += "Every inch of you is exposed to his gaze. His eyes linger on your body, soaking in every detail. "
		elif(GM.pc.hasEffect(StatusEffect.CoveredInCum)):
			addstr += "Upon seeing the shine of the bodily fluids covering you, his expression flickers briefly. "
		elif(GM.pc.hasBuff(Buff.ExposureBuff)):
			addstr += "His eyes linger on your exposed skin. "
		else:
			addstr += "He looks you up and down, taking a bit longer than what could be considered polite. "
		saynn(addstr+ "Apparently he approves of your physique, as he smiles and continues.")
			
		saynn("[say=wyra] Name’s Wyra. I’m pretty much in charge of maintaining the greenhouses here. I’ve been trying for ages to get the higher-ups to hire a few actual gardeners, but there’s never the budget for it. Whatever it is they’re spending it on in Medical – well, I digress. Anyways, I put up that sign to try and entice some inmates away from the mines. [/say]")
		
		saynn("Working in the greenhouse would certainly be a change from hitting rocks.")
		
		addButton("Engineer?", "Why's an engineer in charge of the greenhouse", "explain1")
		addButton("Details?", "What's in it for you?", "explain2")
#		addDisabledButton("Agree", "garden time")
#		addDisabledButton("Refuse", "no i like rocks")
	
	if(state == "explain1"):
		
		saynn("[say=pc] Why is an engineer in charge of plants? Don't you do technical stuff?[/say]")
		
		saynn("He scoffs.")
		saynn("[say=wyra] What, you think plants just grow? Getting a viable ecosystem to thrive in a dead space rock like this is a marvel of technology in itself. [/say]")
		
		saynn("He brushes some dirt off his uniform.")
		
		saynn("[say=wyra] Seriously, though, I was just assigned to do maintenance on the automation systems that were [i]supposed[/i] to be installed in both greenhouses. A sudden price increase meant the allocated budget only covered the southern greenhouse. Of course, higher-ups refused to pay out more to hire actual garden staff. I always liked the greenery n’ stuff, so I volunteered and here I am.[/say]")
		
		addDisabledButton("Engineer?", "Why's an engineer in charge of the greenhouse")
		addButton("Details?", "What's in it for you?", "explain2")
		seen1 = true
		if(seen1 && seen2):
			saynn("[say=wyra] So, are you down to get dirty?[/say]")
			
			addButton("Agree", "garden time", "gardener")
			addButton("Refuse", "no i like rocks", "nah")
		else:
			addDisabledButton("Agree", "garden time")
			addDisabledButton("Refuse", "no i like rocks")
		
	if(state == "explain2"):
		saynn("[say=pc] So I’d get credits? And I thought it was off-limits for inmates. [/say]")

		saynn("[say=wyra] You’d need special permission, and it’d only cover greenhouse 1. Had enough of those apple-stealing whores, so I’m not gonna let any inmates into greenhouse 2. [/say]")
		var addstr = "He gazes off into the distance, his expression one of fury. Probably best not to "
		if(getFlag("TaviModule.Tavi_GotApple")):
			addstr += "let him know that you’re one of those apple-stealing whores."
		else:
			addstr += "ask him for more detail."
		saynn(addstr)
		
		saynn("[say=wyra] Anyways, I need a second set of hands to unpack and set up everything in greenhouse 1. I reckon it’ll take three days or so, and you’d get, hmm, 6 work credits per day. After that, if you’re up for it, I’d pay you proportional to the crop yield after each harvest. [/say]")
		addButton("Engineer?", "Why's an engineer in charge of the greenhouse", "explain1")
		addDisabledButton("Details?", "What's in it for you?")
		seen2 = true
		if(seen1 && seen2):
			saynn("[say=wyra] So, are you down to get dirty?[/say]")
			
			addButton("Agree", "garden time", "gardener")
			addButton("Refuse", "no i like rocks", "nah")
		else:
			addDisabledButton("Agree", "garden time")
			addDisabledButton("Refuse", "no i like rocks")
	
		
	if(state == "gardener"):
		var _eee = GM.pc.getReputation().getRepLevel(RepStat.Staff)
		saynn("[say=wyra] Glad to hear it! Just one quick thing to check first...[/say]")
		
		saynn("He pulls out a worn but obviously well cared-for datapad and pokes at it for a moment.")
		
		saynn("[say=wyra] Let's see...P-12859...disciplinary records...[/say]")
		
		if(_eee >= 3):
			var addstr = "[say=wyra] Well, says here you've been quite the naughty"
			if(GM.pc.getPronounGender()==Gender.Male):
				addstr += " boy."
			elif(GM.pc.getPronounGender()==Gender.Female):
				addstr += " girl."
			else:
				addstr += " inmate."
			saynn(addstr+"[/say]")
			saynn("[say=wyra] Now, far be it for me to judge, but the Warden will need to sign off on your access permission, and he won't approve of troublemakers.")
			addButton("Continue", "naughty", "naughty")
			addButton("Nevermind", "forget this", "nah")
		else:
			var addstr = "[say=wyra] Looks like you've been a good"
			if(GM.pc.getPronounGender()==Gender.Male):
				addstr += " boy!"
			elif(GM.pc.getPronounGender()==Gender.Female):
				addstr += " girl!"
			else:
				addstr += " inmate!"
			saynn(addstr+"[/say]")
			saynn("[say=wyra] Let me just fill this out...[/say]")
			saynn("He types something into his datapad.")
			saynn("[say=wyra] There! Now, assuming this gets approved, just meet me back here tomorrow and we can get started.[/say]")
			
			setModuleFlag("GreenThumb","tutorialrun",true)
#			GM.main.applyWorldEdit("GreenWorldEdit")
			addButton("Continue", "See what happens next", "finish")
			
	if(state == "naughty"):
		setFlag("GreenThumb.ObedienceQuestStart",true)
		saynn("[say=wyra] I'd need some kind of proof that you'll behave. Maybe you could show submission to the guards? Maybe even let them fuck you, whatever! [/say]")
		
		addMessage("You got a new task")
		addButton("Continue", "Time to go", "endthescene")
			
	if(state == "nah"):
		saynn("[say=pc] Nah, I'm good.[/say]")
		
		saynn("[say=wyra] Ah. I suppose not everyone has a green thumb, after all. Let me know if you reconsider, though. I could use the help.[/say]")

		addButton("Continue", "Time to go", "endthescene")
		
	if(state == "finish"):
		saynn("[say=wyra] Oh, almost forgot. You got a name, P-12859?[/say]")
		
		saynn("You introduce yourself.")
		
		saynn("[say=wyra] {pc.name}, huh? Maybe we can even get you a title. 'Greenhouse intern {pc.name}'.[/say]")
		
		saynn("He bids you farewell and departs. Looks like you have a new prison job!")

		addButton("Continue", "Time to go", "endthescene")
		
		setFlag("GreenThumb.1daytimer",true)
		

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
