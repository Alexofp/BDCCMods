extends SceneBase

var condition

func _init():
	sceneID = "gardenCheckpointScene"
	
func _initScene(_args = []):
	if(not _args.empty()):
		condition = _args[0]
	else:
		setState("")

func _run():
		
	if(state == ""):
		saynn("Test test")
		
		addButton("cancel","end","endthescene")
		
#	GM.main.applyWorldEdit("GreenWorldUnEdit")
#	GM.pc.getInventory().clearSlot(InventorySlot.Body)
	
	
func _react(_action: String, _args):

	if(_action == "endthescene"):
		endScene()
		return
		
	setState(_action)

