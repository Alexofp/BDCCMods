extends SceneBase

var GU = preload("res://Modules/GreenThumbModule/util/GreenUtil.gd")
var genericInventoryScreenScene = preload("res://UI/Inventory/GenericInventoryScreen.tscn")
var GT = getModule("GreenThumb")

var seedlist = GlobalRegistry.getModule("GreenThumb").SeedDict
var attribute = GlobalRegistry.getModule("GreenThumb").SeedMeta
var seedenum = GlobalRegistry.getModule("GreenThumb").SeedEnum
var seedtime = GlobalRegistry.getModule("GreenThumb").SeedTime
var seedcost = GlobalRegistry.getModule("GreenThumb").SeedCost

var inventory
var plot
#var plotOld

var theseed
var seedindex
var binsize
var thenum


const watertimecost:int = 3600
const waterstamcost:int = 5
const ferttimecost:int = 3600
const fertstamcost:int = 20
const tilltimecost:int = 3600
const tillstamcost:int = 20


# if water = 0 growth is halted. water is consumed per growth stage
# fertilizer increases yield. large time cost?

func _init():
	sceneID = "gardenPlotScene"
	
func _initScene(_args = []):
	thenum = _args[0].right(_args[0].length()-1)
	if(getFlag("GreenThumb.plot"+thenum) != null):
		plot = getFlag("GreenThumb.plot"+thenum)
	else:
		plot = GU.new()
		setFlag("GreenThumb.plot"+thenum, plot)
		plot.id = _args[0]

func _run():
	_initScene([GM.pc.getLocation()]) # needed for rollback
	say("[img=32]res://Modules/GreenThumbModule/plant.png[/img]")
	
#	plotOld = plot
	if(plot.isPlanted):
		theseed = seedlist[plot.cropType]
		seedindex = seedenum[plot.cropType]
		var growtime = seedtime[seedindex]*60*60
		binsize = growtime/10
		var elapsed = (GM.main.getTimeInGlobalSeconds() - plot.plantedAt)
		if(GM.main.getTimeInGlobalSeconds() < plot.lastChecked):
			saynn("rolled back")
		if GT.debugV: sayn("[color=#b565f7]debug elapsed time since planted "+String(elapsed)+"s[/color]")
		processCropTime(elapsed)
		
	if(state == ""):
		saynn("[b]Greenhouse Plot #"+ thenum +"[/b]")
		var statusText = "[b]Status:[/b] "
		addButtonAt(14, "Go back","Go back","endthescene")
		
		if(!getFlag("GreenThumb.unlock"+thenum)):
			statusText += "The grow beds are a mess. You'll have to set it up before you can plant anything new here."
			addButton("Set up plot",String(tilltimecost/3600)+" hour, "+String(tillstamcost)+ " stamina", "unlock")
			addDisabledButton("Plant seeds","idk")
			addDisabledButton("Water plants","idk")
			addDisabledButton("Add fertilizer","idk")

		elif(getFlag("GreenThumb.unlock"+thenum)):
			if(plot.isPlanted):
				var seedInfo:Dictionary = seedlist[plot.cropType]
				if(checkifDone()):
					statusText += "The "+seedInfo.itemName+" you planted here is ready to harvest."
					statusText += finalCrop()
					checkAttribute(seedindex)
					addButton("Harvest","crops done", "harvest")
					if getFlag("GreenThumb.hasCucumber",false) or getFlag("GreenThumb.bananaFlag",false):
						statusText += "\n\nOr, you could wait and instead grab one for your...[i]personal pleasure[/i]...(UNFINISHED)"
						addDisabledButton("Dildo?", "Enjoy some 'me' time with the fruits of your labor")
					if getFlag("GreenThumb.vineFlag",false):
						statusText += "\n\nOr, you could wait and instead use the tentacle serum...(UNFINISHED)"
						addDisabledButton("Something","idk")
					
				else:
					statusText += "This plot is planted with "+ seedInfo.itemName + "."
					if(plot.water==0):
						statusText += "\n [b][pulse color=#fc0202 height=0.0 freq=2.0]No water, growth is halted![/pulse][/b]"
					if(plot.fertilizer==0):
						statusText += "\n [color=#e8aa25]No fertilizer, crop yield decrease![/color]"
					statusText += getPlantInfo()
					addDisabledButton("Plant seeds","There's already plants here")
					if(GM.pc.getStamina() <= 0):
						addDisabledButton("Water plants","too tired")
					else:
						addButton("Water plants",String(watertimecost/3600)+" hour, "+String(waterstamcost)+ " stamina","woter")
					if(GM.pc.getStamina() <= 0):
						addDisabledButton("Add fertilizer","Too tired")
					else:
						addButton("Add fertilizer",String(ferttimecost/3600)+" hour, "+String(fertstamcost)+ " stamina", "fertile")
			else:
				statusText += "This plot is ready for planting."
				if plot.prevCropBonus: statusText += "\n\tThe soil here is enriched!"
				addButton("Plant seeds", "Do it!", "plant")

#			addButton("eat dirt", "idk", "gross")
		saynn(statusText)
		
	if(state == "unlock"):
		saynn("text when tilling a plot")
		addButton("Continue","Go back","doUnlock")
		
	if(state == "woter"):
		if(plot.water >= 10):
			plot.water = 10
			saynn("water at max")
			addButton("Cancel","Go back","")
		else:
			saynn("mmm w o t e r")
			addButton("Continue","Go back","dowater")
		
	if(state == "fertile"):
		if(plot.fertilizer >= 10):
			saynn("fertilizer at max")
			plot.fertilizer = 10
			addButton("Cancel","Go back","")
		else:
			saynn("You add some fertilizer")
			addButton("Continue","Go back","dofert")
		
	if(state == "plant"):
		var entries:Dictionary = {}
		for itemID in seedlist:
			var seedInfo:Dictionary = seedlist[itemID]
			entries[itemID] = {
					name = seedInfo["itemName"],
					desc = seedInfo["desc"],
					actions = [["doPlant","plant"]],
				}
		inventory = genericInventoryScreenScene.instance()
		GM.ui.addFullScreenCustomControl("inventory", inventory)
		inventory.setRightPanelStretchRation(0.75)
		inventory.setEntries(entries)
		addButton("Back", "desc", "")
		var _ok = inventory.connect("onInteractWith", self, "onpeepee")
		
	if(state == "harvest"):
		saynn("You get to work harvesting.")
		addButton("Done", "Go back", "doharvest")
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		plot.lastChecked = GM.main.getTimeInGlobalSeconds()
		endScene()
		return
		
	if(_action == "dildoscene"):
		runScene("a")
		setState("")
		return
		
	if(_action == "pctentacle"):
		runScene("a")
		setState("")
		return
		
	if(_action == "dounlock"):
		setFlag("GreenThumb.unlock"+thenum, true)
		plot.lastChecked = GM.main.getTimeInGlobalSeconds()
		GM.main.processTime(tilltimecost)
		GM.pc.addStamina(-tillstamcost)
		setState("")
		return
	
	if(_action == "dowater"):
		plot.water += 5
		if(plot.water > 10):
			plot.water = 10
		GM.pc.addStamina(-waterstamcost)
		plot.lastChecked = GM.main.getTimeInGlobalSeconds()
		GM.main.processTime(watertimecost)
		setState("")
		return
	
	if(_action == "dofert"):
		plot.fertilizer = plot.fertilizer + 2
		if(plot.fertilizer > 10):
			plot.fertilizer = 10
		plot.lastChecked = GM.main.getTimeInGlobalSeconds()
		GM.main.processTime(ferttimecost)
		GM.pc.addStamina(-fertstamcost)
		setState("")
		return
	
	if(_action == "doPlant"):
		setState("")
		plot.cropType = _args[0]
		plot.isPlanted = true
		plot.lastChecked = GM.main.getTimeInGlobalSeconds()
		GM.main.processTime(60*60)
		plot.plantedAt = GM.main.getTimeInGlobalSeconds()
		theseed = seedlist[_args[0]]
		seedindex = seedenum[_args[0]]
		plot.water = 0
		plot.fertilizer = 0
		if GT.debug: print("[GreenThumb] planted "+plot.cropType+" in plot "+String(thenum)+" at global time "+String(plot.plantedAt)+"s")
		plot.readyIn = seedtime[seedindex]*60*60
		plot.growthStage = 0
		if(plot.prevCropBonus):
			plot.fertilizer = 5
			plot.prevCropBonus = false
		return
		
	if(_action == "doharvest"):
		var _moneys = seedcost[seedindex]
		GM.pc.addCredits(int(round(_moneys*plot.yieldmod)))
		applyAttribute(seedindex)
		plot.cropType = ""
		plot.isPlanted = false
		plot.water = 0
		plot.fertilizer = 0
		setFlag("GreenThumb.unlock"+thenum, false)
		setState("")
		return
	
	setState(_action)


func processCropTime(_elapsed):
	var growthbywater = 0
	var wtest = plot.water
	var _watertime = 0
	var growthbytime = _elapsed/binsize - plot.growthStage
	if(growthbytime == plot.growthStage):
			plot.readyIn = (seedtime[seedindex]*60*60 + plot.plantedAt) - GM.main.getTimeInGlobalSeconds()
			return

	if GT.debugV: sayn("[color=#b565f7]debug processed " + String(_elapsed) + " seconds, tried to grow "+String(growthbytime)+" times[/color]")
	while(wtest>0):
		growthbywater += 1
		_watertime += binsize
		wtest -=1
	if GT.debugV: sayn("[color=#b565f7]debug had enough water for "+String(growthbywater)+" growth[/color]")
	var actualgrow = min(growthbytime, growthbywater)

	if GT.debugV: sayn("[color=#b565f7]debug actually grew "+String(actualgrow)+" times taking "+String(actualgrow)+" water[/color]")
	plot.water -= actualgrow
	var fert = min(plot.fertilizer, actualgrow)
	while(fert>0):
		plot.yieldmod += 0.05
		fert -= 1
		plot.fertilizer -=1
	if(growthbytime>growthbywater):
		var _dummy2 = _elapsed - _watertime
		if GT.debugV: sayn("[color=#b565f7]debug paused growth "+String(_dummy2)+"s ago[/color]")
		plot.plantedAt += _elapsed - _watertime
	var old = plot.readyIn
	plot.readyIn = (seedtime[seedindex]*60*60 + plot.plantedAt) - GM.main.getTimeInGlobalSeconds()
	if GT.debugV: sayn("[color=#b565f7]debug advanced crop timer by "+String(plot.readyIn-old)+"s[/color]")
	plot.growthStage += actualgrow

func onpeepee(_type:String, _action, _args):
	plot.yieldmod = 0.75
	GM.main.pickOption(_action, [_type])

func checkifDone():
	if(plot.readyIn <= 0):
		return true
	else:
		return false
		
		
#	0 "Weird"
#	1 "Nutritious"
#	2 "Phallic"
#	3 "Fixer"
#	4 "Vine"
#	5 "Hearty"
#	6 "Cumfill"

func checkAttribute(_index):
	var todo = []
	var ii = 0
	for entry in attribute:
		var arr = attribute[ii]
		if(arr.has(_index)):
			todo.append(ii)
		ii += 1
	if(todo.has(0)):
		setFlag("GreenThumb.weirdFlag", true)
	if(todo.has(2)):
		if _index == 2: setFlag("GreenThumb.hasCucumber", true)
		if _index == 0: setFlag("GreenThumb.bananaFlag", true)
	if(todo.has(4)):
		setFlag("GreenThumb.vineFlag", true)

		
	
func applyAttribute(_index):
	var todo = []
	var ii = 0
	for entry in attribute:
		var arr = attribute[ii]
		if(arr.has(_index)):
			todo.append(ii)
		ii += 1
	if(todo.has(1)):
		setFlag("GreenThumb.foodcount", 3)
		addMessage("Some of your harvest has been sent to the canteen!")
	if(todo.has(3)):
		plot.prevCropBonus = true
		addMessage("Growing this has enriched the soil here!")
	if(todo.has(5)):
		setFlag("GreenThumb.healcount", 3)
		addMessage("Some of your harvest has been sent to the canteen!")
	if(todo.has(6)):
		setFlag("GreenThumb.cumcount", 3)
		addMessage("Some of your harvest has been sent to the canteen!")
	
		

func getPlantInfo():	
	var timestring = Util.getTimeStringHHMM(plot.readyIn)
	var amount = plot.yieldmod*100
	var growing
	if(plot.growthStage == 0):
		growing = "\n\nThe seeds have yet to sprout."
	if(plot.growthStage > 0 && plot.growthStage <= 3):
		growing = "\n\nThere are little green sprouts just starting to grow."
	if(plot.growthStage > 3 && plot.growthStage <= 7):
		growing = "\n\nThe plants are growing nicely."
	if(plot.growthStage > 7 && plot.growthStage < 10):
		growing = "\n\nThe plants are almost ready to harvest."
	
	var text = [
		growing,
		"\n\nReady to harvest in: " + timestring,
		"\nExpected yield: " + String(amount)+"%",
		"\nWater level: "+String(plot.water)+"/10",
		"\nFertilizer level: "+String(plot.fertilizer)+"/10",
	]
	text = String(text).replace(",","")
	var _temp = text.substr(1,text.length()-2)
	return text.substr(1,text.length()-2)
	


func finalCrop():
	return "\n\nFinal Yield: "+String(plot.yieldmod*100)+"%\nBase sell price: " + String(seedcost[seedindex])+"\nTotal pay: "+String(round(seedcost[seedindex]*plot.yieldmod))+" credits"
