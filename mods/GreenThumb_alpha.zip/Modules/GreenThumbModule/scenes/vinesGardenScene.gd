extends SceneBase

var veggie
var pussy:bool
var penis:bool
var inv:Inventory


func _init():
	sceneID = "vinesGardenScene"
	
func _initScene(_args = []):
	if(not _args.empty()):
		veggie = _args[0]
		setState("")
	else:
		veggie = "vegetable"
		setState("")

	pussy = GM.pc.hasReachableVagina()
	penis = GM.pc.hasReachablePenis()
	inv = GM.pc.getInventory()


func holeword():
	if(pussy):
		return RNG.pick(["pussy", "pussy slit", "kitty", "petals", "slit", "folds","delicate folds"])
	else:
		return RNG.pick(["back entrance", "anus", "tailhole"])
	
func adjective():
	return RNG.pick(["tight","drippy","needy","hungry","eager"])

func _run():
	
	if(state == ""):
		playAnimation(StageScene.TentaclesTease, "tease", {npc="pc", npcBodyState={exposedCrotch=true, hard=true}, pc="invisible"})
		var nude = (not inv.hasSlotEquipped(InventorySlot.Body) || inv.hasSlotEquipped(InventorySlot.UnderwearBottom))
#		("text1" if var != 1 else "text2")
#		+RNG.pick(["pussy", "pussy slit", "kitty", "petals", "slit", "folds","clit and lips","delicate folds"])
#		str(getRandomAnusWord())
#		GM.pc.orgasmFrom("axis")
#		GM.pc.addSkillExperience(Skill.SexSlave, 50)
		saynn("Looking around, you see that there's nobody nearby. Now's your chance to relieve your arousal! Quickly grabbing the girthiest vegetable from your harvest, you duck behind a row of hydroponics.")

		saynn("In mere moments you are "+("" if nude else "naked below the waist and ")+"practically drooling in anticipation as you inspect your improvised dildo. The "+veggie+" you picked is long and girthy enough to imitate the real thing, but it has several uneven bumps and has a slight curve to it that you can't wait to feel in your "+adjective()+" "+holeword()+".")

		saynn("The building heat in your groin demands your attention, and you're eager to soothe that ache. At first, you gently tease your "+adjective()+" "+holeword()+" with the "+veggie+", basking in the tingly sensation. Soon, though, it's not enough, so you press in.")

		saynn("Your "+adjective()+" "+holeword()+"  accepts this offering in one smooth stroke, gliding deep into your sensitive innards. You give a little moan as your "+("rock-hard cock twitches" if penis else "thighs twitch")+", the sensation of being so deliciously filled taking over. For a moment, you stop thrusting and wiggle the "+veggie+" around, using that slight curve to your advantage in order to press against your weak spots. Your "+("dick is leaking pre," if penis else holeword()+" is leaking juices,")+" coating your thighs with slick and encouraging you to go deeper.")
		addButton("Continue","See what happens next","2")
		
	if(state == "2"):
		playAnimation("DildoScene", ["squirm","res://Modules/GreenThumbModule/items/Eggplant.tscn"], {npc="pc", npcBodyState={exposedCrotch=true, hard=true}, npcCum=true, pc="invisible"})
				
		saynn("Taking a deep breath, you ram the "+veggie+" all the way to the root! Your free hand flies to your mouth to stifle a moan that would almost certainly get you caught"+(", although the thought of that only excites you more" if GM.pc.getSkillLevel(Skill.Exhibitionism) > 2 else "")+". Your makeshift dildo presses against your deepest parts, your insides are clenching and massaging it as if it were a real cock. With your "+("tail flicking and your " if GM.pc.hasBodypart(BodypartSlot.Tail) else "") + ("eyes rolling" if GM.pc.bodypartHasTrait(BodypartSlot.Legs, PartTrait.LegsHoofs) else "toes curling")+", it takes a surprising amount of effort to remove it from the vice-grip of your "+adjective()+" "+holeword()+". Shuddering at the emptiness, you waste no time pumping it in and out, setting a rhythym that sends bolts of pleasure directly to your brain.")
		
		saynn("You gush and quiver around your temporary toy, your mind lost in the sensation. Distantly, you wonder if anyone might hear the sloppy sounds of you plowing your wet, "+adjective()+" "+holeword()+", but that quickly becomes unimportant as you feel your climax building. With a "+veggie+" this big, it's almost too easy to twist it around and caress your sensitive spots with every thrust, and it's driving you crazy with need.")
		
		saynn("Your orgasm approaches rapidly, and every time you bottom out "+("your cock throbs, pressure building" if penis else "the knot in your womb grows tighter")+". You can already tell it's going to be a good one. The makeshift dildo hits all the right places, sending pleasant tingles all over your body. You find yourself moaning without a care, your other hand busy teasing your poor neglected "+("cock" if penis else "nipples")+". You're almost there...")
		
		saynn("You cum in a flash of white-hot ecstasy, your "+ ("pussy gripping down and gushing girlcum around" if pussy else "asshole twitching around") +" the fruits of your labors"+(" and your dick delivers thick streams of hot cum" if penis else "")+". For a few blissful moments, that pleasure is all that exists, and you float on that high.")
		
		
		addButton("Continue","See what happens next","3")
		
	if(state == "3"):
		var notnude = (inv.hasSlotEquipped(InventorySlot.Body) || inv.hasSlotEquipped(InventorySlot.UnderwearBottom))
		playAnimation("Cuddling", "idle", {npc="pc", pc="invisible"})
		saynn("When you return to your body, you find the deck in front of you soaked in sexual fluids. That really took the edge off! Feeling relaxed, you ponder whether or not you should clean up your mess "+("as you get dressed" if notnude else "")+". However, the decision is made for you as you hear footsteps approaching your hiding spot.")
		
		saynn("You stand up and hope you don't look like you've just fucked yourself silly on a "+veggie+", when the footsteps round the corner and you see Wyra.")
		
		addButton("Continue","See what happens next","4")
		
	if(state == "4"):
		addCharacter("wyra")
		playAnimation(StageScene.Duo, "stand", {npc="wyra", flipNPC=false, pc="pc"})
		saynn("[say=wyra]Everything okay over here? Seems like you're taking a while to get this harvested.[/say]")
		
		saynn("To your absolute shame, you realize you're still holding your prized "+veggie+". It proudly glistens with your juices. Combined with your flushed face, there's no hiding what you've been up to.")
		
		saynn("Instead of reprimanding you, Wyra gives you a knowing grin.")
		
		saynn("[say=wyra]Ah, didn't know you were so... passionate about gardening, {pc.Name}. Just remember to get some work done, I'm not paying you to slack off.[/say]")
		
		saynn("You get back to work harvesting the rest of the "+veggie+"s, your "+holeword()+" tingling with pleasant aftershocks...")
		
		addButton("End","end","endthescene")
		
	
	
func _react(_action: String, _args):

	if(_action == "endthescene"):
		endScene()
		return
		
	setState(_action)
