extends SceneBase

var GU = preload("res://Modules/GreenThumbModule/util/GreenUtil.gd")
var mod = GlobalRegistry.getModule("GreenThumb")


func _init():
	sceneID = "gardenTest"

func _run():
		
	if(state == ""):
		saynn("Green thumb module debug")
		
		var flags = mod.getFlags()
		for entry in flags.keys():
			var ttt = getModuleFlag("GreenThumb", entry, false)
			if(!entry.begins_with("plot")):
				sayn(entry + ":" + String(ttt))
		
		addButton("Cancel", "Go back", "endthescene")
		
		addButton("flags", "set module flags which trigger the intro event", "flipflag")
		addButton("run intro", "run intro", "gardenbegin")
		addButton("run setup", "run tutorial", "gardenteach")
		addButton("finish tut", "mark tutorial finished", "flagtut")
		addButton("run planter scene", "do it", "interactgarden")
		addButton("worldedit","do it","world")
		addButton("quest","begin quest","quest")
		addButton("quest done","finish quest","endquest")
		addButton("food test","does it work","food")
		addButton("advance time","to end of day","zoom")

	
	
func _react(_action: String, _args):

	if(_action == "flipflag"):
		setModuleFlag("GreenThumb","explored",true)
#		setModuleFlag("GreenThumb","tutorial",true)
	if(_action == "flagtut"):
		setModuleFlag("GreenThumb","tutorial2",true)
		setModuleFlag("GreenThumb","tutorial1",false)
		setModuleFlag("GreenThumb","tutorialrun",false)
		
	if(_action == "quest"):
		setModuleFlag("GreenThumb","ObedienceQuestStart",true)
		
	if(_action == "endquest"):
		setModuleFlag("GreenThumb","ObedienceQuestFinished",true)
		
	if(_action == "gardenbegin"):
		runScene("GardenIntro")
		
	if(_action == "gardenteach"):
		runScene("gardenTutorialScene")
	
	if(_action == "interactgarden"):
		runScene("gardenPlotScene",["main_green_corridor1",GU.new()])
	
	if(_action=="world"):
		GM.main.applyWorldEdit("GreenWorldEdit")
		
	if(_action == "food"):
		increaseFlag("GreenThumb.foodcount",1)
		increaseFlag("GreenThumb.healcount",1)
		increaseFlag("GreenThumb.cumcount",1)
	
		
	if(_action == "zoom"):
		GM.main.processTimeUntil(22*60*60)
		
	
	if(_action == "endthescene"):
		endScene()
		return

