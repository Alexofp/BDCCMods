extends EventBase

func _init():
	id = "GreenQuestEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["GenericSexScene", ""])
	
func run(_triggerID, _args):
	if(!getFlag("GreenThumb.ObedienceQuestStart")):
		return false
	var engine = GM.main.getCurrentScene().sexEngine
	if(engine.hasSexEnded() && engine.isSub("pc")):
		var names = engine.getDoms().keys()
		for person in names:
			var pp = GM.main.getCharacter(person)
			if(pp.getCharacterType() == CharacterType.Guard):
				increaseFlag("GreenThumb.subcount",1)
	if(getFlag("GreenThumb.subcount") == 3):
		setFlag("GreenThumb.ObedienceQuestFinished", true)
		addMessage("Task completed")

func react(_triggerID, _args):
	pass

func getPriority():
	return 1

