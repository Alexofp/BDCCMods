extends EventBase

func _init():
	id = "GardenEntrance"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, ["yard_stars_green", ""])

# steps to trigger gardening:
# enter the storage closet north of the first greenhouse
# getDays() > 3

func react(_triggerID, _args):
	if(getFlag("GreenThumb.isGardener") && not GM.main.isVeryLate()):
		GM.main.applyWorldEdit("GreenWorldEdit")

func run(_triggerID, _args):
	if(GM.main.isVeryLate()):
		GM.main.applyWorldEdit("GreenWorldUnEdit")
		
	if(getFlag("GreenThumb.explored", null) && GM.main.getDays() > 3 && !getFlag("GreenThumb.isGardener") && !getFlag("GreenThumb.tutorialrun") && !getFlag("GreenThumb.wyraIntroduced")):
		addButton("Sign", "A glossy sign that says 'help wanted'", "green_volunteer")
	elif(getFlag("GreenThumb.tutorialrun") && !getFlag("GreenThumb.1daytimer") && !getFlag("GreenThumb.inGreenhouse")):
		addButton("Start gardening", "Learn to plants", "tutorial")
	elif(getFlag("GreenThumb.wyraIntroduced")):
		if(GM.main.isVeryLate()):
			addDisabledButton("Wyra", "It's too late for that.")
		else:
			addButton("Wyra","Find the greenhouse manager","wyraTalk")
	else:
		addDisabledButton("Sign", "A glossy sign that says 'help wanted'. It wasn't here before. Exploring the greenhouse might reveal why...")


func getPriority():
	return 2

func onButton(_method, _args):
	if(_method == "green_volunteer"):
		runScene("GardenIntro")
	if(_method == "tutorial"):
		runScene("gardenTutorialScene")
	if(_method == "wyraTalk"):
		runScene("wyraTalkScene")
