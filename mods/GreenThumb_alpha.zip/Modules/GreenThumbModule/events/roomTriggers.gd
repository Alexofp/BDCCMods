extends EventBase

var location

func _init():
	id = "roomTriggers"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor1", "1"])
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor2", "2"])
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor3", "3"])
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor4", "4"])
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor5", "5"])
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor6", "6"])
#	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_secret", "7"])
#	es.addTrigger(self, Trigger.EnteringRoom, ["yard_stars_green", "8"])

func react(_triggerID, _args):
	if(getFlag("GreenThumb.isGardener") && not GM.main.isVeryLate()):
		GM.main.applyWorldEdit("GreenWorldEdit")


func run(_triggerID, _args):
	if(!getModuleFlag("GreenThumb","isGardener",false)):
		return false
	setFlag("GreenThumb.inGreenhouse",true)
	if(GM.main.isVeryLate()):
		addDisabledButton("Garden", "It's too late for that.")
		GM.main.applyWorldEdit("GreenWorldUnEdit")
	else:
		addButton("Garden", "description", "go-garden")
		location = _args

func onButton(_method, _args):
	
	if(_method == "go-garden"):
		runScene("gardenPlotScene",[location[0]])


func getPriority():
	return 1


