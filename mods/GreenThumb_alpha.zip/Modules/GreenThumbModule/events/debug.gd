extends EventBase

func _init():
	id = "GreenDebug"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["MeScene", ""])

func run(_triggerID, _args):
	if getModule("GreenThumb").debug:
		addButton("garden debug", "Debug", "debug")

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "debug"):
		runScene("gardenTest")
