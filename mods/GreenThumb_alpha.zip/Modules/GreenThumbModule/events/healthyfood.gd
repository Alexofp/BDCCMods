extends EventBase

func _init():
	id = "healthyFood"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EatingInCanteen)
	es.addTrigger(self, Trigger.EnteringRoom, ["hall_canteen", 0])

func react(_triggerID, _args):

	
	var food = getFlag("GreenThumb.foodcount", 0) >= 0
	var heal = getFlag("GreenThumb.healcount", 0) >= 0
	var cum = getFlag("GreenThumb.cumcount", 0) >= 0
	if((food or heal or cum) and _triggerID == Trigger.EnteringRoom):
		addMessage("Some of the crops you grew have been added to the food here.\n")
	if(_triggerID == Trigger.EatingInCanteen):
		increaseFlag("GreenThumb.foodcount", -1)
		increaseFlag("GreenThumb.healcount", -1)
		increaseFlag("GreenThumb.cumcount", -1)
		food = getFlag("GreenThumb.foodcount", 0) >= 0
		heal = getFlag("GreenThumb.healcount", 0) >= 0
		cum = getFlag("GreenThumb.cumcount", 0) >= 0
		if(food):
			GM.pc.addStamina(50)
			say(" The fresh vegetables you grew are delicious, though. You'd almost forgotten how real food tastes!")
			addMessage("The nutritious food gives you an energy boost.")
		if(heal):
			GM.pc.addPain(-100)
			say(" The potatoes you grew are delicious, though. You'd almost forgotten how real food tastes!")
			addMessage("The hearty food makes you forget about any pain.")
		if(cum):
			say("The jizzfruit tastes about as you expected. Salty, but slightly sweet...")
			if(GM.pc.hasBodypart(BodypartSlot.Penis)):
				var penis: BodypartPenis = GM.pc.getBodypart(BodypartSlot.Penis)
				var production: FluidProduction = penis.getFluidProduction()
				if(production == null):
					return false
				else:
					production.fillPercent(1.0)
					addMessage("You feel a strange churning in your balls as they are filled with potent cum!")
			else:
				addMessage("You lack the parts to take advantage of the jizzfruit, though...")
		
		if(getFlag("GreenThumb.foodcount", 0) == 0):
			addMessage("\n That was the last of your nutritious food!")
		if(getFlag("GreenThumb.healcount", 0) == 0):
			addMessage("\n That was the last of your hearty food!")
		if(getFlag("GreenThumb.cumcount", 0) == 0):
			addMessage("\n That was the last of your jizzfruit!")
	
func getPriority():
	return 0
	
