extends EventBase

func _init():
	id = "quickTrigger"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, ["main_green_corridor7", ""])

func react(_triggerID, _args):
	setFlag("GreenThumb.explored", true)
	

func getPriority():
	return 0

