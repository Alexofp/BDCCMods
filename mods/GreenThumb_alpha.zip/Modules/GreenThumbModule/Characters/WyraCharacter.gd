extends Character

func _init():
	id = "wyra"
	npcHasMenstrualCycle = false
	npcCharacterType = CharacterType.Engineer
	
	pickedSkin=""
	pickedSkinRColor=Color("ffa37d64")
	pickedSkinGColor=Color("ffe4c7b9")
	pickedSkinBColor=Color("ff834d35")
	npcSkinData={
	"hair": {"r": Color("ff351d18"),"g": Color("ff4f2c23"),"b": Color("ff351d18"),},
	"ears": {"g": Color("ffdfa19b"),"b": Color("ffe9d8d2"),},
	"breasts": {"r": Color("ffeba794"),"b": Color("ffb7736c"),},
	}
#	clothesColor: Color = Color.white
	
	npcPersonality = {
		PersonalityStat.Brat: 0.7,
		PersonalityStat.Mean: -1.0,
		PersonalityStat.Subby: 0.75,
		PersonalityStat.Impatient: 0.0,
		PersonalityStat.Naive: 0.35,
		PersonalityStat.Coward: -0.5,
	}
	npcDefaultFetishInterest = FetishInterest.Neutral
	npcFetishes = {
		Fetish.AnalSexReceiving : FetishInterest.ReallyDislikes,
		Fetish.AnalSexGiving : FetishInterest.Hates,
		Fetish.VaginalSexGiving : FetishInterest.Hates,
		Fetish.VaginalSexReceiving : FetishInterest.Loves,
		Fetish.OralSexReceiving : FetishInterest.Likes,
		Fetish.OralSexGiving : FetishInterest.Likes,
		Fetish.Sadism : FetishInterest.ReallyDislikes,
		Fetish.Masochism : FetishInterest.Hates,
		Fetish.UnconsciousSex : FetishInterest.Loves,
		Fetish.BeingBred : FetishInterest.Dislikes,
		Fetish.Bondage : FetishInterest.Likes,
		Fetish.Rigging : FetishInterest.Likes,
		Fetish.Condoms : FetishInterest.Dislikes,
		Fetish.DrugUse : FetishInterest.Likes,
		Fetish.Exhibitionism : FetishInterest.Loves,
		Fetish.Tribadism : FetishInterest.SlightlyDislikes,
		Fetish.StraponSexVaginal : FetishInterest.Dislikes,
		Fetish.StraponSexAnal : FetishInterest.SlightlyDislikes,
		Fetish.Choking : FetishInterest.SlightlyDislikes,
		Fetish.HypnosisSubject : FetishInterest.Loves,
	}
	
	npcHasMenstrualCycle = false
	
func _getName():
	return "Wyra"

func getGender():
	return Gender.Male
	
func getSmallDescription() -> String:
	return "mod author forgot to change this"

func getChatColor():
	return '#a0e8af'

func getSpecies():
	return ["feline"]

func getThickness() -> int:
	return 40

func getFemininity() -> int:
	return 10

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanhead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("simplehair"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("lynxears"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	var penis = GlobalRegistry.createBodypart("felinepenis")
	penis.lengthCM = 22
	penis.ballsScale = 1
	giveBodypartUnlessSame(penis)
	var tail = GlobalRegistry.createBodypart("felinetail")
	tail.tailScale = 1
	giveBodypartUnlessSame(tail)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("plantilegs"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("buffarms"))


func getDefaultEquipment():
	return ["CasualClothes"]

