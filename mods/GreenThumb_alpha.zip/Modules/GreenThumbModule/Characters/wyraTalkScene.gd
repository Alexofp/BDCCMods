extends SceneBase


func _init():
	sceneID = "wyraTalkScene"

func _run():
		
	if(state == ""):
		playAnimation(StageScene.Duo, "stand", {npc="pc", flipNPC=false, pc="wyra"})
		saynn("You wait around, hoping to catch Wyra as he exits the greenhouse.")
		
		if(!getFlag("GreenThumb.isGardener",false)):
			if(!getFlag("GreenThumb.tutorialrun",false)):
				saynn("[say=wyra] Oh, you again, P-12859. What do you want? [/say]")
				addButton("Reconsider","You want to ask about the greenhouse job again","reconsider")
			else:
				saynn("[say=wyra] Meet me back here in the morning.[/say]")
		else:
			saynn("[say=wyra] Hi there! Did you need something, Intern {pc.name}? [/say]")
		
		addButton("Talk", "Pick a topic to talk about", "talk")
		addButton("Appearance", "Take a closer look", "appearance")
#		addDisabledButton("Lewd", "so no bitches?")
		
		if(getFlag("GreenThumb.ObedienceQuestFinished",false) && getFlag("GreenThumb.ObedienceQuestStart",false)):
			addButton("Obedient?","You completed Wyra's task","quest")
		addButton("Leave", "Time to go", "endthescene")

	if(state == "appearance"):
		saynn("idk he looks like something. work in progress.")
		addButton("Back","Go back","")

	if(state=="talk"):
		saynn("work in progress")
		
		addDisabledButton("Himself", "What's his story?")
		addDisabledButton("Hybrid?", "You can't just ask people why they're hybrids...")
		addButton("Garden", "How does gardening work again?", "gardentalk")
		addDisabledButton("Promotion", "Ask about getting access to more seeds and plots")
		addButton("Nevermind", "Go back", "")
		
	if(state == "gardentalk"):
		saynn("Wyra gives a long explanation of how to garden.")
		
		addMessage("Each room in the greenhouse has one garden plot.\nEach plot will grow a single type of plant at a time.")
		addMessage("A plot must be tilled and prepared before planting.")
		addMessage("The different plant options have different growing time and selling price.")
		addMessage("Once the seeds are planted, it will attempt to grow once every few in-game hours.")
		addMessage("It uses 1 water each time it grows.\nA plot must have water available for it to grow.")
		addMessage("When a plot grows, it will use up 1 fertilizer (if there is any) to increase its yield.\nYield starts at 75%, meaning you will get 75% of the credits when harvesting.")
		
		addButton("Back","Go back","")

	if(state=="reconsider"):
		
		saynn("[say=wyra] Changed your mind about being down to get dirty?[/say]")
		
		addButton("Agree", "garden time", "gardener")
		
		addButton("Refuse", "no i like rocks", "nah")

	if(state == "quest"):
		
		var personality = GM.pc.getPersonality()
		if(personality.getStat("Subby")>=0.15):
			saynn("[say=pc] Um...I got fucked by the guards...[/say]")
		elif(personality.getStat("Subby")<=-0.15):
			saynn("[say=pc] I fucked some guards. Can I get permission now? [/say]")
		else:
			saynn("[say=pc] I whored myself out to some guards. Is that enough? [/say]")
		saynn("Wyra looks at you, tapping his chin.")
		saynn("[say=wyra] Oh, really? I was joking about the fucking. Well, I guess if you're willing to go that far, you'll behave for me. Right?[/say]")
		saynn("He types something into his datapad.")
		saynn("[say=wyra] Let me just fill this out...There! Now, assuming this gets approved, just meet me back here tomorrow and we can get started.[/say]")
		setModuleFlag("GreenThumb","tutorialrun",true)
		setFlag("GreenThumb.ObedienceQuestStart", false)
		
		saynn("[say=wyra] So, did you need anything else? [/say]")
		addButton("Continue", "See what happens next", "")
	
	
func _react(_action: String, _args):
	
	if(_action == "gardener"):
		runScene("GardenIntro",["gardener"])
		endScene()
	
	if(_action == "nah"):
		runScene("GardenIntro",["nah"])
		endScene()
	
	if(_action == "endthescene"):
		endScene()
		
	setState(_action)
	return

