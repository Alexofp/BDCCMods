extends SceneBase


func _init():
	sceneID = "wyraTalkScene"

func _run():
		
	if(state == ""):
		playAnimation(StageScene.Duo, "stand", {npc="pc", flipNPC=false, pc="wyra"})
		saynn("You wait around, hoping to catch Wyra as he exits the greenhouse.")
		
		if(!getFlag("GreenThumb.isGardener",false)):
			if(!getFlag("GreenThumb.tutorialrun",false)):
				saynn("[say=wyra] Oh, you again, P-12859. What do you want? [/say]")
				addButton("Reconsider","You want to ask about the greenhouse job again","reconsider")
			else:
				saynn("[say=wyra] Meet me back here in the morning.[/say]")
		else:
			saynn("[say=wyra] Hi there! Did you need something, Intern {pc.name}? [/say]")
		
		addButton("Talk", "Pick a topic to talk about", "talk")
		addButton("Appearance", "Take a closer look", "appearance")
#		addDisabledButton("Lewd", "so no bitches?")
		
		if(getFlag("GreenThumb.ObedienceQuestFinished",false) && getFlag("GreenThumb.ObedienceQuestStart",false)):
			addButton("Obedient?","You completed Wyra's task","quest")
		addButton("Leave", "Time to go", "endthescene")

	if(state == "appearance"):
		saynn("Wyra is dressed in an engineer's outfit, albeit one stained with mud instead of grease. He's clearly a hybrid, having the features of a human and the ears, tail, and fur of a feline. A little below average height, his calm brown eyes catch you looking, and he gives a knowing smirk. His hair is brunette, and his fur is tawny with a few darker patches. As you look lower, you can tell there's a bulge in between his legs.")

		addButton("Back","Go back","")

	if(state=="talk"):
		saynn("[say=wyra]Here for some chit-chat? Alright then.[/say]")
		
		addDisabledButton("Himself", "unfinished")
		addButton("Hybrid?", "He's obviously got some feline features...","hybrid")
		addButton("Garden", "How does gardening work again?", "gardentalk")
		addButton("Promotion", "Ask about getting access to more seeds and plots", "promotion")
		addButton("Nevermind", "Go back", "")
		
	if(state == "hybrid"):
		saynn("[say=pc]I can't help but notice...you're a hybrid?[/say]")
		saynn("Wyra frowns.")
		saynn("[say=wyra]That's a pretty bold thing to ask a stranger. Unless...you're interested in getting to know me better?[/say]")
		saynn("[say=pc]Sorry...Just forget I asked.[/say]")
		addMessage("Oh My God, Karen, You Can’t Just Ask Someone Why They're A Hybrid...")
		addButton("Nevermind", "Go back", "talk")
		
	if(state == "promotion"):
		saynn("[say=pc]Could I maybe get more seeds and plots?[/say]")
		saynn("[say=wyra]Sure, if you can pay for it. Like I said, there's no room in the budget.[/say]")
		saynn("[say=pc]How much would it take?[/say]")
		saynn("Wyra names a number of credits that is too large to even consider. At your shocked expression, he chuckles.")
		saynn("[say=wyra]This is pretty pricey. But hey, maybe in the future something will change.[/say]")
		addMessage("lazy mod author didn't add more stuff")
		addButton("Back", "Go back", "talk")
		
	if(state == "gardentalk"):
		saynn("Wyra gives a long explanation of how to garden.")
		
		addMessage("Each room in the greenhouse has one garden plot.\nEach plot will grow a single type of plant at a time.")
		addMessage("A plot must be tilled and prepared before planting.")
		addMessage("The different plant options have different growing time and selling price.")
		addMessage("Once the seeds are planted, it will attempt to grow once every few in-game hours.")
		addMessage("It uses 1 water each time it grows.\nA plot must have water available for it to grow.")
		addMessage("When a plot grows, it will use up 1 fertilizer (if there is any) to increase its yield.\nYield starts at 75%, meaning you will get 75% of the credits when harvesting.")
		
		addButton("Back","Go back","")
		
	if(state=="lore"):
		saynn("[say=wyra]What's there to know about lil' ole me? Are you perhaps flirting with me, Intern {pc.name}?[/say]")
		saynn("He gives an exagerrated wink. You can't quite tell if he's teasing you or not.")
		
		addButton("Hobby?", "How'd he start gardening?","lore2")
		addButton("Here?", "Why work at this prison?","lore3")
		addButton("Me?", "How come he recruited you?", "lore4")
		addDisabledButton("Flirt","unfinished")
		addDisabledButton("Voyeur?", "unfinished")
		addDisabledButton("Sex?", "unfinished")
		addButton("Nevermind", "Go back", "")
		
	if(state=="lore2"):
		saynn("[say=wyra]lore![/say]")
		
		addButton("Continue", "Go back", "lore")

	if(state=="reconsider"):
		
		saynn("[say=wyra] Changed your mind about being down to get dirty?[/say]")
		
		addButton("Agree", "garden time", "gardener")
		
		addButton("Refuse", "no i like rocks", "nah")

	if(state == "quest"):
		
		var personality = GM.pc.getPersonality()
		if(personality.getStat("Subby")>=0.15):
			saynn("[say=pc] Um...I got fucked by the guards...[/say]")
		elif(personality.getStat("Subby")<=-0.15):
			saynn("[say=pc] I fucked some guards. Can I get permission now? [/say]")
		else:
			saynn("[say=pc] I whored myself out to some guards. Is that enough? [/say]")
		saynn("Wyra looks at you, tapping his chin.")
		saynn("[say=wyra] Oh, really? I was joking about the fucking. Well, I guess if you're willing to go that far, you'll behave for me. Right?[/say]")
		saynn("He types something into his datapad.")
		saynn("[say=wyra] Let me just fill this out...There! Now, assuming this gets approved, just meet me back here tomorrow and we can get started.[/say]")
		setModuleFlag("GreenThumb","tutorialrun",true)
		setFlag("GreenThumb.ObedienceQuestStart", false)
		
		saynn("[say=wyra] So, did you need anything else? [/say]")
		addButton("Continue", "See what happens next", "")
	
	
func _react(_action: String, _args):
	
	if(_action == "gardener"):
		runScene("GardenIntro",["gardener"])
		endScene()
	
	if(_action == "nah"):
		runScene("GardenIntro",["nah"])
		endScene()
	
	if(_action == "endthescene"):
		endScene()
		
	setState(_action)
	return

