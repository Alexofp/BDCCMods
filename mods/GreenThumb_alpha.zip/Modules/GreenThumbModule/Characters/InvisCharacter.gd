extends Character

func _init():
	id = "invisible"
	npcHasMenstrualCycle = false
	npcCharacterType = CharacterType.Inmate
	
func _getName():
	return ""

func getGender():
	return Gender.Other
	
func getSmallDescription() -> String:
	return ""


func getSpecies():
	return ["none"]

	

