extends Node
class_name GreenUtil

var id:String
var isPlanted:bool
var cropType:String
var plantedAt:int
var readyIn:int
var growthStage:int
var lastChecked:int
var water:int
var yieldmod:float
var fertilizer:int
var prevCropBonus:bool



func _init():
	id = "bad id"
	
func getRef():
	return self
	
func pauseTimer():
	pass

static func plantIcon(width: int = 16) -> String:
	return "[img="+str(width)+"]"+"res://Modules/GreenThumbModule/plant.png"+"[/img]"

func saveData():
	var data = {}
	data["id"] = id
	data["isPlanted"] = isPlanted
	data["cropType"] = cropType
	data["plantedAt"] = plantedAt
	data["readyIn"] = readyIn
	data["growthStage"] = growthStage
	data["lastChecked"] = lastChecked
	data["water"] = water
	data["yieldmod"] = yieldmod
	data["fertilizer"] = fertilizer
	data["prevCropBonus"] = prevCropBonus
	return data

func loadData(data):
	id = SAVE.loadVar(data, "id", "")
	isPlanted = SAVE.loadVar(data, "isPlanted", false)
	cropType = SAVE.loadVar(data, "cropType", "")
	plantedAt = SAVE.loadVar(data, "plantedAt", 0)
	readyIn = SAVE.loadVar(data, "readyIn", 0)
	growthStage = SAVE.loadVar(data, "growthStage", 0)
	lastChecked = SAVE.loadVar(data, "lastChecked",0)
	water = SAVE.loadVar(data, "water", 0)
	yieldmod = SAVE.loadVar(data, "yieldmod", 0)
	fertilizer = SAVE.loadVar(data, "fertilizer", 0)
	prevCropBonus = SAVE.loadVar(data, "prevCropBonus", false)

