extends QuestBase

func _init():
	id = "GreenThumb_ObedienceQuest"

func getVisibleName():
	return "Prove Your Obedience"

func getProgress():
	var result = []
	var num = getFlag("GreenThumb.subcount", 0)
	if(getFlag("GreenThumb.ObedienceQuestFinished")):
		result.append("This is enough to convince Wyra. I should speak to him outside the greenhouses.")
	result.append("So far, I've been the sub in " + String(num) + " encounters.")
	result.append("Wyra will get greenhouse clearance for you if you can prove you'll behave. He recommends that you approach three guards and submit to them.")
	

	return result

func isVisible():
	return GM.main.getFlag("GreenThumb.ObedienceQuestStart", false)

func isCompleted():
	return GM.main.getFlag("GreenThumb.ObedienceQuestFinished", false)

func isMainQuest():
	return false


func getFlag(flagID, defaultValue = null):
	return GM.main.getFlag(flagID, defaultValue)
