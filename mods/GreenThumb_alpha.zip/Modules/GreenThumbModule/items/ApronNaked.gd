extends ItemBase


func _init():
	id = "apronnaked"

func getVisibleName():
	return "Apron"
	
func getDescription():
	var text = "placeholder"
	return text

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		buff(Buff.ExposureBuff,[25])
	]

func canSell():
	return false

func isImportant():
	return true

func getTags():
	return []


func onUnequipped():
	pass
	

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your apron"
	else:
		return "take off your apron"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your apron"
	else:
		return "put on your apron"

func generateItemState():
	itemState = ShirtAndShortsState.new()
	itemState.canActuallyBeDamaged = false # Is hack because there are many clothes that use this state already and don't support damaging..

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	else:
		return {"clothing":"res://Modules/GreenThumbModule/items/gardenOutfit.tscn",}

