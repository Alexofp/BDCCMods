extends ItemBase

var isLegal = false

func _init():
	id = "wheatItem"

# apple is illegal only temporally as a test item
func getVisibleName():
	if(isLegal):
		return "Wheat berries"

	
func getDescription():
	if(isLegal):
		return "A handful of dried grain. Why did you take this? Can you even eat this raw?"


func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	_attacker.addPain(1)
	_attacker.addStamina(5)
	removeXOrDestroy(1)
	return _attacker.getName() + " ate a handful of raw wheat, like an idiot."

func getPossibleActions():
	return [
		{
			"name": "Eat one!",
			"scene": "UseItemLikeInCombatScene",
			"description": "Eat the grain",
		},
	]

func getPrice():
	return 0

func canSell():
	return true

func canCombine():
	return true

func tryCombine(_otherItem):
	if(isLegal != _otherItem.isLegal):
		return false
	return .tryCombine(_otherItem)

func getTags():
	return [ItemTag.Illegal]

func getItemCategory():
	return ItemCategory.Generic

func saveData():
	var data = .saveData()
	return data
	
func loadData(data):
	.loadData(data)
	

func getInventoryImage():
	return null
