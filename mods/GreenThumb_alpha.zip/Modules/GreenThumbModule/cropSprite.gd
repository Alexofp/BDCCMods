extends Node



#RoomStuff.RoomSprite.BOSS: 
const PLANT = preload("res://Modules/GreenThumbModule/plant.png")


