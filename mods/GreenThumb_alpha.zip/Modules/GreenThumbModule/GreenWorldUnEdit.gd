extends WorldEditBase

var roomIDs = [
	"main_green_corridor1",
	"main_green_corridor2",
	"main_green_corridor3",
	"main_green_corridor4",
	"main_green_corridor5",
	"main_green_corridor6",
	"main_green_secret",
]
var extra = [
	"yard_stars_green"
]



func _init():
	id = "GreenWorldUnEdit"
#	isRegular = true  # true = apply() is called after every tick
	
func apply(world: GameWorld):
	
	var _dummy = GM.world.getRoomByID("yard_stars_green")
	_dummy.roomDescription = "A set of stairs lead up to the greenhouses with markings on the floor remind inmates that the greenhouses are [color=red]off-limits[/color] for them. It's past curfew, so you're not allowed in either."
	GM.world.getRoomByID("main_green_corridor1").roomDescription = "This entrance area of the greenhouses look largely unused with windows looking out over the side yard. You've set up the hydroponics and grow beds in this room, filling the once-empty space with the scent of damp soil. More crates and unfinished construction materials lead around this first building."
	GM.world.getRoomByID("main_green_corridor3").roomDescription = "This entrance area of the greenhouses look largely unused with windows looking out over the side yard. You've set up the hydroponics and grow beds in this room, filling the once-empty space with the scent of damp soil. More crates and unfinished construction materials lead around this first building."
	GM.world.getRoomByID("main_green_corridor6").roomDescription = "This entrance area of the greenhouses look largely unused with windows looking out over the side yard. You've set up the hydroponics and grow beds in this room, filling the once-empty space with the scent of damp soil. More crates and unfinished construction materials lead around this first building."
	
	for entry in roomIDs:
		var theroom = GM.world.getRoomByID(entry)
		world.setRoomGridColor(entry, RoomStuff.RoomColor.Red)
		world.setRoomColor(entry, RoomStuff.RoomColor.Green)
		world.setRoomSprite(entry, RoomStuff.RoomSprite.NONE)
		theroom.loctag_Greenhouses = true

	
#setRoomGridColor
#setRoomColor
#setRoomSprite
#getRoomByID
#isRoomInZone
#isLocSafe
