extends Module
class_name GreenThumb

#var options = ResourceLoader.exists("res://Modules/FoxLib/Module.gd")
var debug
var debugV

# seeds
enum SeedEnum {
	bluespace_banana, 
	cabbage,  
	cucumber, 
	jizzberry, 
	kudzu_vine, 
	potato, 
	rice, 
	soybeans, 
	wheat, 
	wildflower, 
	}

var SeedTime = [
	55,
	48,
	32,
	56,
	10,
	36,
	30,
	50,
	62,
	24,
]

var SeedCost = [
	15,
	8,
	6,
	0,
	2,
	10,
	12,
	8,
	23,
	0,
]

var SeedAttribute = {
	"Weird":"this crop is so weird even the mod author doesn't know what it does.",
	"Nutritious":"this crop will increase stamina regained by eating for 3 days.",
	"Phallic":"this vegetable looks kinda like a...",
	"Fixer":"this crop enriches the soil, so the next thing planted after this has higher yield.",
	"Vine":"if you have Artica and Eliza's serum, it would work on this plant.",
	"Hearty":"this crop will cure pain when eating in the canteen for 3 days.",
	"Cumfill":"eating this in the canteen will quickly refill your balls. Lasts 3 days."
}

var SeedMeta = [
	[0],
	[1,2],
	[0,2],
	[4,7],
	[4,9],
	[5],
	[3],
]

var SeedDict:Dictionary = {
	"bluspace_banana":{"itemName":"Bluespace Banana", "desc":"What the fuck does this do. \nSell Price: "+ String(SeedCost[0]) + " credits \nTime: "+ String(SeedTime[0]) +" hours \n\nWeird - "+SeedAttribute.Weird+"\n\nPhallic - " + SeedAttribute.Phallic},
	"cabbage":{"itemName":"Cabbage", "desc":"It's green. It's leafy. It's a ball. [i]MY CABBAGESSS![/i] \nSell Price: "+ String(SeedCost[1]) + " credits \nTime: "+ String(SeedTime[1]) +" hours \n\nNutritious - "+SeedAttribute.Nutritious},
	"cucumber":{"itemName":"Cucumbers", "desc":"A vegetable with some girth. \nSell Price: "+ String(SeedCost[2]) + " credits \nTime: "+ String(SeedTime[2]) +" hours \n\nNutritious - " + SeedAttribute.Nutritious + "\n\nPhallic - " + SeedAttribute.Phallic},
	"jizzberry":{"itemName":"Jizzberry", "desc":"This off-white fruit is said to taste like...well...ya know... \nSell Price: "+ String(SeedCost[3]) + " credits \nTime: "+ String(SeedTime[3]) +" hours\n\nCumfill - " + SeedAttribute.Cumfill},
	"kudzu_vine":{"itemName":"Kudzu", "desc":"An inedible vine that grows really fast. \nSell Price: "+ String(SeedCost[4]) + " credits \nTime: "+ String(SeedTime[4]) +" hours \n\nFixer - " + SeedAttribute.Fixer + "\n\nVine - " + SeedAttribute.Vine},
	"potato":{"itemName":"Potato", "desc":"Boil 'em. Mash 'em. Stick 'em in a stew. \nSell Price: "+ String(SeedCost[5]) + " credits \nTime: "+ String(SeedTime[5]) +" hours \n\nHearty - " + SeedAttribute.Hearty},
	"rice":{"itemName":"Rice", "desc":"Always remember to wash the rice.\nSell Price: "+ String(SeedCost[6]) + " credits \nTime: "+ String(SeedTime[6]) +" hours"},
	"soybeans":{"itemName":"Soybeans", "desc":"Get soypilled. \nSell Price: "+ String(SeedCost[7]) + " credits \nTime: "+ String(SeedTime[7]) +" hours \n\nFixer - " + SeedAttribute.Fixer},
	"wheat":{"itemName":"Wheat", "desc":"For when you need to get bread.\nSell Price: "+ String(SeedCost[8]) + " credits \nTime: "+ String(SeedTime[8]) +" hours"},
	"wildflower":{"itemName":"Wildflowers", "desc":"The seed packet advertises that these flowers are 'genetically modified' for 'maximum color'. \nSell Price: "+ String(SeedCost[9]) + " credits \nTime: "+ String(SeedTime[9]) +" hours\n\nVine - " + SeedAttribute.Vine},
}


func getFlags():
	return {
		"debug": flag(FlagType.Bool),
		"debugV": flag(FlagType.Bool),
		"explored": flag(FlagType.Bool),
		"wyraIntroduced": flag(FlagType.Bool),
		"ObedienceQuestStart": flag(FlagType.Bool),
		"ObedienceQuestFinished": flag(FlagType.Bool),
		"subcount": flag(FlagType.Number),
		"foodcount": flag(FlagType.Number),
		"cumcount": flag(FlagType.Number),
		"healcount": flag(FlagType.Number),
		"isGardener": flag(FlagType.Bool),
		"1daytimer":flag(FlagType.Bool),
		"unlock1": flag(FlagType.Bool),
		"unlock2": flag(FlagType.Bool),
		"unlock3": flag(FlagType.Bool),
		"unlock4": flag(FlagType.Bool),
		"unlock5": flag(FlagType.Bool),
		"unlock6": flag(FlagType.Bool),
		"tutorial2": flag(FlagType.Bool),
		"tutorial1": flag(FlagType.Bool),
		"tutorialrun": flag(FlagType.Bool),
		"inGreenhouse": flag(FlagType.Bool),
		"hasCucumber": flag(FlagType.Bool),
		"vineFlag": flag(FlagType.Bool),
		"bananaFlag": flag(FlagType.Bool),
		"weirdFlag": flag(FlagType.Bool),


		
		# these flags are storing an object reference
		# a bit of a hack and will probably break something
		"plot1": flag(FlagType.Anything),
		"plot2": flag(FlagType.Anything),
		"plot3": flag(FlagType.Anything),
		"plot4": flag(FlagType.Anything),
		"plot5": flag(FlagType.Anything),
		"plot6": flag(FlagType.Anything),
		
	}

func _init():
	id = "GreenThumb"
	author = "bringlebangul"
	
	scenes = [
		"res://Modules/GreenThumbModule/scenes/GardenIntro.gd",
		"res://Modules/GreenThumbModule/scenes/gardenTest.gd",
		"res://Modules/GreenThumbModule/scenes/gardenPlotScene.gd",
#		"res://Modules/GreenThumbModule/scenes/gardenCheckpointScene.gd",
		"res://Modules/GreenThumbModule/scenes/gardenTutorialScene.gd",
		"res://Modules/GreenThumbModule/Characters/wyraTalkScene.gd",
		]
		
	characters = [
		"res://Modules/GreenThumbModule/Characters/WyraCharacter.gd",
	]
	
	items = [
		"res://Modules/GreenThumbModule/items/ApronNaked.gd",
	]
	
	events = [
		"res://Modules/GreenThumbModule/events/GardenEntrance.gd",
		"res://Modules/GreenThumbModule/events/debug.gd",
		"res://Modules/GreenThumbModule/events/roomTriggers.gd",
		"res://Modules/GreenThumbModule/events/quickTrigger.gd",
		"res://Modules/GreenThumbModule/events/GreenQuestEvent.gd",
		"res://Modules/GreenThumbModule/events/healthyfood.gd"
	]
	
	worldEdits = [
		"res://Modules/GreenThumbModule/GreenWorldEdit.gd",
		"res://Modules/GreenThumbModule/GreenWorldUnEdit.gd"
	]
	quests = [
		"res://Modules/GreenThumbModule/ObedientQuest.gd",
	]

		
func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addBooleanOptionInCategory("GreenThumb","debugV", "Debug", "Wanna see some debug text?",false)
#	foxModuleAPI.addBooleanOptionInCategory("GreenThumb","Crops need water", "", "currently does nothing",true)
#	foxModuleAPI.addBooleanOptionInCategory("GreenThumb","Crop harvest depends on fertilizer", "", "currently does nothing",true)


func resetFlagsOnNewDay():
	setFlag("GreenThumb.inGreenhouse", false)
	setFlag("GreenThumb.1daytimer",false)


