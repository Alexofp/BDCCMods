extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "sNarga"
	
func getVisibleName():
	return "Nargacuga"

func getDefaultLegs(_gender):
	return "sNargaLegs"

func getDefaultTail(_gender):
	return "sNargatail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Swift Wyvern"

func getDefaultHead(_gender):
	return "sNargaHead"

func getDefaultArms(_gender):
	return "sNargaArms"

func getDefaultEars(_gender):
	return "sNargaEars"

func getDefaultBody(_gender):
	return "sNargabody"

func getDefaultHorns(_gender):
	return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sNargaPHY"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#32303a", "#2b2626", "#823f3f"], 
		["#3c3545", "#3f2d58", "#6c3e3e"], 
		["#313965", "#232e3b", "#7a3333"],
		["#32456a", "#1e202e", "#8b2d2d"],
		#Lucent Nargacuga
		["#c4c0f1", "#51577c", "#c25e5e"],
		["#e5defd", "#5a69c9", "#e45b5b"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
	
