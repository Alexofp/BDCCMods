extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable Nargacuga penis"
	id = "sNargaPHY"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["wyvern", "knotted", "barbed"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Penis/Narga_Penis.tscn"

func getVulgarName() -> String:
	return "Knotted wyvern cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
		"Hyperable": true,
		}

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getCharacterCreatorDesc():
	return "From MH Species"
