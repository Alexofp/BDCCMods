extends "res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd"

func _init():
	visibleName = "Slitted Nargacuga penis"
	id = "sNargaPS"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["wyvern", "knotted", "barbed", "slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Penis_Slit/Narga_Penis_slit.tscn"

func getVulgarName() -> String:
	return "Knotted wyvern cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
		}

func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func getCharacterCreatorDesc():
	return "From MH Species"
