extends BodypartBody

func _init():
	visibleName = "Nargacuga body"
	id = "sNargabody"

func getCompatibleSpecies():
	return ["sNarga"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Body/Narga_Body.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
