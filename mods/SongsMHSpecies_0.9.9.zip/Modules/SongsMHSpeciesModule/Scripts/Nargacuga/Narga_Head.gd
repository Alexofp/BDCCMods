extends BodypartHead

func _init():
	visibleName = "Nargacuga Head"
	id = "sNargaHead"

func getCompatibleSpecies():
	return ["sNarga"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Head/Narga_Head.tscn"

func getHeadLength():
	return 0.75
