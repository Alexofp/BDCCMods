extends BodypartTail

func _init():
	visibleName = "Nargacuga Tail"
	id = "sNargatail"

func getCompatibleSpecies():
	return ["sNarga"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Tail/Narga_Tail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
