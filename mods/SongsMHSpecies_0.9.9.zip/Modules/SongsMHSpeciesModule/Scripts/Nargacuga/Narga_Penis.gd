extends BodypartPenis

func _init():
	visibleName = "Nargacuga penis"
	id = "sNargaP"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["dragon", "knotted", "barbed"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Penis/Narga_Penis.tscn"

func getVulgarName() -> String:
	return "Knotted dragon cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
		}

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getCharacterCreatorDesc():
	return "From MH Species"
