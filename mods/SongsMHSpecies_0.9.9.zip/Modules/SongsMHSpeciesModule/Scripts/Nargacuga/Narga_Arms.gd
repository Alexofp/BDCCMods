extends BodypartArms

func _init():
	visibleName = "Nargacuga arms"
	id = "sNargaArms"

func getCompatibleSpecies():
	return ["sNarga"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Arms/Narga_Arm.tscn"
