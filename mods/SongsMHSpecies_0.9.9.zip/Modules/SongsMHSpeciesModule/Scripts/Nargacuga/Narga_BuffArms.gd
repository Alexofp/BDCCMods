extends BodypartArms

func _init():
	visibleName = "Nargacuga buff arms"
	id = "sNargaArmsBuff"

func getCompatibleSpecies():
	return ["sNarga"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Arms/Narga_BuffArm.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
