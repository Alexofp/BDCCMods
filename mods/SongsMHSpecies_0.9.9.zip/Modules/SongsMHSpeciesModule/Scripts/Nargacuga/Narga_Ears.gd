extends BodypartEars

func _init():
	visibleName = "Nargacuga ears"
	id = "sNargaEars"

func getCompatibleSpecies():
	return ["sNarga"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Ears/Narga_Ears.tscn"
