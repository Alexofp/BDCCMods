extends BodypartLeg

func _init():
	visibleName = "Nargacuga legs"
	id = "sNargaLegs"

func getCompatibleSpecies():
	return ["sNarga"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nargacuga/Narga_Legs/Narga_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
