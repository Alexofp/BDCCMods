extends "res://Modules/WintersCoreModule/CompatabilityPatches/RAT_Archetypes/SpeciesBase.gd"

func getRegisteredMethods() -> Array:
	var a : Array = []
	for suffix in [
		"Tail", "Head", "Ears", "Body", "Legs", "Arms", "Breasts", "Penis"
	]:
		a.append("getDefault"+suffix)
	
	return a

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & ExpandedBreasts
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultTail(_old, _gender):
	return "horsetail"

func getDefaultHead(_old, _gender):
	return "horsehead"

func getDefaultEars(_old, _gender):
	return "horseears"

func getDefaultBody(_old, _gender):
	if (hasFluff && !hasArchetype):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_old, _gender):
	if (hasFluff && !hasArchetype):
		return "fluffhoofs"
	return "hoofs"

func getDefaultArms(_old, _gender):
	if (hasFluff):
		return "fluffarms"
	return "anthroarms"

func getDefaultPenis(_old, _gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "equinepenis"
	else:
		return null
