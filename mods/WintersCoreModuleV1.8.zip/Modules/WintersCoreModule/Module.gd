extends Module

func _init():
	id = "WintersCoreModule"
	author = "Avery Winters & Selinoccino"

func createCodegen() -> Reference:
	return load("res://Modules/WintersCoreModule/codegen.gd").new()

func RatArchetify() -> void:
	var p : String = "res://Modules/WintersCoreModule/CompatabilityPatches/RAT_Archetypes/CallableRegisters/"
	var d : Dictionary = {
		Species.Canine: p+"Canine.gd",
		Species.Demon: p+"Demon.gd",
		Species.Dragon: p+"Dragon.gd",
		Species.Equine: p+"Equine.gd",
		Species.Feline: p+"Feline.gd",
		Species.Human: p+"Human.gd",
	}
	
	for id in d:
		var species = GlobalRegistry.getSpecies(id)
		if !species:
			continue
		
		load(d[id]).new().registerToSpecies(species)

func postInit():
	if !("RAT_Archetypes" in GlobalRegistry.getModules()):
		for p in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersCoreModule/CompatabilityPatches/BDCC/"):
			GlobalRegistry.registerSpecies(p)
