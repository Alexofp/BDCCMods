extends ItemBase

func _init():
	id = "SerpentsPiercings"

func getVisibleName():
	return "Serpent's Piercings"

func getDescription():
	return "A pair of nipple piercings with banners tied by rope. You cannot make out the symbol on the banners. They look like the belong to some kind of goddess."

func getClothingSlot():
	return InventorySlot.UnderwearTop

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"piercings": "res://Modules/FashionoftheEmeraldSerpentModule/SerpentsPiercings/SerpentsPiercings.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your piercings"
	else:
		return "take off your piercings"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your piercings"
	else:
		return "put on your piercings"

func generateItemState():
	itemState = BraState.new()

func getPrice():
	return 15000

func getTags():
	return [
		ItemTag.SoldByTheAnnouncer,
		ItemTag.RopeHarness,
		]

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 100]),
		buff(Buff.ExposureBuff, [100]),
		buff(Buff.OvulationEggsAmountBuff, [5]),
		]

func getInventoryImage():
	return "res://Modules/FashionoftheEmeraldSerpentModule/SerpentsPiercings/icon.tres"
