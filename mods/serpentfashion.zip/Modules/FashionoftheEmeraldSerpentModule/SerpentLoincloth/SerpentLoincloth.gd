extends ItemBase

func _init():
	id = "SerpentLoincloth"

func getVisibleName():
	return "Serpent Loincloth"

func getDescription():
	return "A typical loincloth that has some... weird properties to it. It seems likes it's made of luxury fabrics, as it's soft to the touch. The markings on the fabric are unreadable to you."

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"loincloth": "res://Modules/FashionoftheEmeraldSerpentModule/SerpentLoincloth/SerpentLoincloth.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your loincloth"
	else:
		return "take off your loincloth"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your loincloth"
	else:
		return "put on your loincloth"

func generateItemState():
	itemState = PantiesState.new()

func getPrice():
	return 20000

func getTags():
	return [
		ItemTag.SoldByTheAnnouncer,
		ItemTag.RopeHarness,
		]

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 100]),
		buff(Buff.ExposureBuff, [200]),
		buff(Buff.OvulationEggsAmountBuff, [5]),
		]

func getInventoryImage():
	return "res://Modules/FashionoftheEmeraldSerpentModule/SerpentLoincloth/icon.tres"
