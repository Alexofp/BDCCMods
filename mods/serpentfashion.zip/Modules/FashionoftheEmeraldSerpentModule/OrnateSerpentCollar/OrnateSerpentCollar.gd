extends ItemBase

func _init():
	id = "snakecollara"

func getVisibleName():
	return "Ornate Serpent Collar"

func getDescription():
	return "A [b]VERY[/b] special collar made out of a material you don't recognize, but feels very much like gold. It's forged to shape a serpent. It's studded with Emerald crystals, but it doesn't feel right. It feels comfy to wear however..."

func getClothingSlot():
	return InventorySlot.Neck

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"collar": "res://Modules/FashionoftheEmeraldSerpentModule/OrnateSerpentCollar/OrnateSerpentCollar.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your collar"
	else:
		return "take off your collar"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your collar"
	else:
		return "put on your collar"

func getPrice():
	return 5000000

func getTags():
	return [
		ItemTag.SoldByTheAnnouncer,
		ItemTag.AllowsEnslaving,
		ItemTag.TFItem,
		ItemTag.ReturnsToPCIfSlaveReleased,
		]

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 250]),
		buff(Buff.ExposureBuff, [300]),
		buff(Buff.OvulationEggsAmountBuff, [10]),
		buff(Buff.FertilityBuff, [25]),
		buff(Buff.ForcedObedienceBuff, [5]),
		buff(Buff.FetishGainBuff, [5]),
		buff(Buff.TransformationSpeedBuff, [20]),
		]

func generateRestraintData():
	restraintData = RestraintSlaveCollar.new()

func getInventoryImage():
	return "res://Modules/FashionoftheEmeraldSerpentModule/OrnateSerpentCollar/icon.tres"
