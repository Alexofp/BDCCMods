extends ItemBase

func _init():
	id = "ControlledOrnateSerpentCollar"

func getVisibleName():
	return "Controlled Ornate Serpent Collar"

func getDescription():
	return "[i][b]SILENCED BY YOUR GODDESS[/b][/i]"

func getClothingSlot():
	return InventorySlot.Neck

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"collar": "res://Modules/FashionoftheEmeraldSerpentModule/ControlledOrnateSerpentCollar/ControlledOrnateSerpentCollar.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your collar"
	else:
		return "take off your collar"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your collar"
	else:
		return "put on your collar"

func getTags():
	return [
		ItemTag.BDSMRestraint,
		ItemTag.AllowsEnslaving,
		ItemTag.TFItem,
		ItemTag.Hypnovisor,
		]

func getBuffs():
	return [
		buff(Buff.RingGagBuff),
		buff(Buff.RestrainedArmsBuff),
		buff(Buff.BlockedHandsBuff),
		buff(Buff.RestrainedLegsBuff),
		buff(Buff.StatBuff, [Stat.Sexiness, 500]),
		buff(Buff.ExposureBuff, [500]),
		buff(Buff.FertilityBuff, [50]),
		buff(Buff.OvulationEggsAmountBuff, [40]),
		buff(Buff.FetishGainBuff, [50]),
		buff(Buff.TransformationSpeedBuff, [50]),
		buff(Buff.ForcedObedienceBuff, [50]),
		]

func generateRestraintData():
	restraintData = RestraintSlaveCollar.new()

func getInventoryImage():
	return "res://Modules/FashionoftheEmeraldSerpentModule/ControlledOrnateSerpentCollar/icon.tres"
