HeelsSuit by MOON_HALO

FAQ:

Q: Where can I obtain the outfit?

A: Go to the vendomat on the cellblock floor where you can buy underwear. You can purchase the outfit here for fifteen credits. If you don't see it here, please ensure that the mod is installed correctly.


Q: Fifteen credits? Why is it so expensive? Couldn't you have made it cheaper?

A: Jeez, do you have any idea what a STEAL that price is? I thought I was being generous! But if you really don't want to pay for it, enable the Debug menu and select Give Player Item > Clothes > HeelsSuit.


Q: Well then, why is it so cheap? Why can inmates at BDCC even buy it to begin with?

A: Someone at the prison - I won't name any names - managed to buy a special batch from the manufacturer for dirt cheap. By "special", I mean "recalled". They had the prison stock the vendomats with them just to see what would happen.


Q: Why don't the high heels actually make you taller?

A: The plantigrade high heeled-boots are slightly bigger on the inside, a rare instance of bluespace being used for fashion. Created by a talented physicist with a high heels fetish, but whose ego couldn't stand it when this made his partners taller than him, he later sold the design to a fashion firm. The core technology was adapted to create high heels that were flat-soled for the wearer, aimed at people who had difficulty walking in regular ones. Meanwhile, if you look carefully, the digitigrade/unguligrade boots don't actually elevate the wearer at all: they just add heels to the back of their feet.


Q: That sounds stupid. Can't you make the player taller? It can't be that hard!

A: Trust me, it is that hard, plus some. It is simply beyond the scope of this mod.


Q: The boots look distorted during specific animations. Can you fix this?

A: Probably not. To get the boots to work properly, I had to create custom meshes to work with their uniquely shaped skins. The way they're set up, both the planti and digi boots work fine with the standard walking, crawling, and attacking animations. When the feet are bent at extreme angles - particularly during specific sex activities and other events you'll probably be naked for anyway - things might look a little warped. This is the best I can do without remaking those specific animations to look better while wearing this particular outfit, which is beyond the scope of this mod.