Mod name: Horsecock Punishment
Category: Slave Management / Punishment
Game Version: 0.3.2
Mod Version: 1.0.1

Description:
Instead of the horsecock dildo only ever being something the player rides on themselves, this mod lets you force one of your slaves onto it instead.

Adds "Horsecock dildo" as a new Punish action in the slave management menu, right alongside things like Wooden Horse and Stocks. Requires owning a Horsecock dildo item first.

The scene mirrors the item's own solo riding scene. Their reaction (fighting it, whimpering through it, etc) branches based on their actual resistance, fear, and broken spirit stats, same as the game's other slave punishments do.

It's built on the NpcSlave/SlaveActionBase system, so it won't show up on regular pawns (if you request this change I will do it ; in the future I could also experiment with new animations).

[This shouldn't conflict with anything else. If a line doesn't fit a particular slave's anatomy or a state branch reads oddly, let me know what the slave's state was at the time.]
