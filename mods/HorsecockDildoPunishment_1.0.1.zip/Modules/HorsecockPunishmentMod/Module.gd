extends Module

func _init():
	id = "HorsecockPunishmentMod"
	author = "Adria"

	slaveActions = [
		"res://Modules/HorsecockPunishmentMod/PunishHorsecockDildo.gd",
	]

	scenes = [
		"res://Modules/HorsecockPunishmentMod/PunishHorsecockDildoScene.gd",
	]
