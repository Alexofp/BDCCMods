#!/usr/bin/env python
# -*- coding: utf-8 -*-
# FoxLib ModHelper Wrapper
# It is recommended to use PyCharm to edit this file!

import os  # <- Used for file manipulation
import sys  # <- Used to parse program arguments
import stat  # <- Used to check unix file permissions (Not used on Windows)
import signal  # <- Ignore keyboard interrupts
import zipfile  # <- Used to extract FLMH.py from FoxLib.zip
import platform  # <- Used to check if you are on Windows/Mac/Linux
import subprocess  # <- Used to run FLMH.py

platforms_ids = {"Linux": "linux", "Darwin": "mac", "Windows": "windows", }
platform_id = platforms_ids.get(platform.system()) or None
use_compatibility_signal_pass = sys.version_info >= (3, 13)
ctrl_c_signal_sent = False


def get_game_data_path():
    if platform_id is None:
        raise OSError("Getting game data path is not supported on this platform: " + platform.system())
    if platform_id == "windows":
        return os.path.join(os.getenv("APPDATA"), "Godot\\app_userdata\\BDCC")
    elif platform_id == "mac":
        return os.path.expanduser("~/Library/Application Support/Godot/app_userdata/BDCC")
    else:  # Assume Linux or unix like
        return os.path.expanduser("~/.local/share/godot/app_userdata/BDCC")


def game_data_wrapper():
    if platform_id is None:
        return False
    game_data_path = get_game_data_path()
    if not os.path.isdir(game_data_path):
        os.makedirs(game_data_path)
    open_file_program = "xdg-open"
    if platform_id == "windows":
        open_file_program = "start.exe"
    elif platform_id == "mac":
        open_file_program = "open"
    else:
        xdg_desktop = os.getenv("XDG_CURRENT_DESKTOP")
        if xdg_desktop == "GNOME":
            open_file_program = "gnome-open"
        elif xdg_desktop == "KDE":
            open_file_program = "kde-open"
    subprocess.run([open_file_program, game_data_path])
    return True


def main_wrapper(argv):
    game_data_path = get_game_data_path()
    game_mods_path = os.path.join(game_data_path, "mods")
    mod_helper_path = os.path.join(os.path.join(game_data_path, "foxlib"), "mod_helper")
    is_renewing = len(argv) > 1 and argv[1] == "renew"
    if not os.path.isdir(mod_helper_path) and not os.makedirs(mod_helper_path):
        raise IOError("Failed to create foxlib/mod_helper directory")
    foxlib_mod_zip = None
    foxlib_mod_helper_dest = None
    for file in os.listdir(game_mods_path):
        if file.startswith("FoxLib_v") and file.endswith(".zip"):
            foxlib_mod_zip = os.path.join(game_mods_path, file)
            foxlib_mod_helper_name = ("FLMH_v" + file[8:-4] + ".py").replace("-", "_")
            foxlib_mod_helper_dest = os.path.join(mod_helper_path, foxlib_mod_helper_name)
    if foxlib_mod_zip is None:
        if len(argv) == 2 and argv[1] == "game-data" and game_data_wrapper():
            return
        raise IOError("FoxLib was not found in your mods directory!")
    if (is_renewing or not os.path.isfile(foxlib_mod_helper_dest) or
            (foxlib_mod_zip.endswith("-dev.zip") and  # Check for mtime for dev FoxLib
             os.path.getmtime(foxlib_mod_zip) > os.path.getmtime(foxlib_mod_helper_dest))):
        with zipfile.ZipFile(foxlib_mod_zip, 'r') as zip_ref:
            with zip_ref.open("FLMH.py") as compressed_script, open(foxlib_mod_helper_dest, 'wb') as extracted_script:
                extracted_script.write(compressed_script.read())
    if platform_id != "windows":
        unix_perms = os.stat(foxlib_mod_helper_dest).st_mode
        if (unix_perms & stat.S_IXUSR) == 0:
            unix_perms |= stat.S_IXUSR
            os.chmod(foxlib_mod_helper_dest, unix_perms)
    if is_renewing:
        print("FLMHW: Re-extracted a clean version of FLMH.py")
    else:
        process = subprocess.Popen([foxlib_mod_helper_dest] + argv[1:])

        def forward_ctrl_c(signum, frame):
            global ctrl_c_signal_sent
            if ctrl_c_signal_sent:
                return
            ctrl_c_signal_sent = True
            if sys.platform == "win32":
                process.send_signal(signal.CTRL_C_EVENT)
            elif not use_compatibility_signal_pass:
                process.send_signal(signal.SIGINT)

        signal.signal(signal.SIGINT, forward_ctrl_c)
        if sys.platform == "win32" and signal.CTRL_C_EVENT != signal.SIGINT:
            signal.signal(signal.CTRL_C_EVENT, forward_ctrl_c)
        process.wait()
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        if sys.platform == "win32" and signal.CTRL_C_EVENT != signal.SIGINT:
            signal.signal(signal.CTRL_C_EVENT, signal.SIG_IGN)
        if process.returncode != 0:
            print("FoxLib ModHelper exited with code " + str(process.returncode))
            if len(argv) == 2 and argv[1] == "game-data" and game_data_wrapper():
                print("FoxLib ModHelper Wrapper: Used built-in implementation for \"game-data\"")


if __name__ == '__main__':
    main_wrapper(sys.argv)
