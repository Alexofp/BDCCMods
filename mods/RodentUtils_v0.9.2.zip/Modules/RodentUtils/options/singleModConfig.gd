extends Control

onready var optionsvb : VBoxContainer = $vb/contents/mod/sc/opsvb
var optionsRef : Reference = GlobalRegistry.getModule("RodentUtils").Options

var butt : PackedScene = load("res://Game/UI/Buttons/BetterButton.tscn")

var thingy : Dictionary = {
	optionsRef.ValueTypes.TEXT: load("res://Modules/RodentUtils/options/please me stop being stupid/TextOption.tscn"),
	optionsRef.ValueTypes.FILE: load("res://Modules/RodentUtils/options/please me stop being stupid/FileOption.tscn"),
	optionsRef.ValueTypes.DIRECTORY: load("res://Modules/RodentUtils/options/please me stop being stupid/DirectoryOption.tscn"),
	optionsRef.ValueTypes.MULTILINE: load("res://Modules/RodentUtils/options/please me stop being stupid/MultilineOption.tscn"),
	optionsRef.ValueTypes.DROPDOWN: load("res://Modules/RodentUtils/options/please me stop being stupid/DropdownOption.tscn"),
	optionsRef.ValueTypes.COLOR: load("res://Modules/RodentUtils/options/please me stop being stupid/ColorOption.tscn"),
	optionsRef.ValueTypes.BOOL: load("res://Modules/RodentUtils/options/please me stop being stupid/BoolOption.tscn"),
	optionsRef.ValueTypes.NUM: load("res://Modules/RodentUtils/options/please me stop being stupid/NumOption.tscn"),
}

var invalid : PackedScene = load("res://Modules/RodentUtils/options/please me stop being stupid/LabelOption.tscn")

func _ready() -> void:
	for n in [ $vb/contents/mod/sc, $vb/contents/tabs ]:
		n.connect("gui_input", self, "scroll_gui_input", [n])
	setToConfigAndModule(null, null)

func setToConfigAndModule(config, module:Module) -> void:
	clear()
	if !(config && module):
		$vb/Label.text = "No module selected"
		$vb/author.text = "No author"
		return
	$vb/Label.text = module.id if !config.nameOverride else config.nameOverride
	$vb/author.text = ("Created by %s" % (module.author if module.author else "(unknown)")) if !config.authorOverride else config.authorOverride
	
	var keys = config.options.keys()
	if keys:
		var c = keys.pop_front()
		newTab(c, config.options[c])
		newCategory(config.options[c])
	for cat in keys:
		newTab(cat, config.options[cat])
		
	

func newTab(id:String, options:Array) -> void:
	var t : BetterButton = butt.instance()
	
	t.connect("pressedActually", self, "newCategory", [options])
	
	$vb/contents/tabs/tabs.add_child(t)
	t.mouse_filter = Control.MOUSE_FILTER_PASS
	t.rect_min_size.x = 200
	t.setButtonText(id)
	t.key_label.text = ""

func newCategory(options:Array) -> void:
	Util.delete_children(optionsvb)
	
	var st : bool = GM.main!=null
	for option in options:
		var o = newOption(option, st)
		optionsvb.add_child(o)
		o.setToOption(option)
	

func newOption(option, doPlayer:bool=false) -> Control:
	var thing : Control = null
	if !option:
		thing = invalid.instance()
		thing.setText("Bad option")
		thing.setColor(Color.lightcoral)
		return thing
	
	var t : int = option.valueType
	
	if (doPlayer && option.playerMode == 2) or (!doPlayer && option.playerMode == 1):
		thing = invalid.instance()
		thing.setText("Can only be edited from the main menu!" if doPlayer else "Can only be edited in-game!")
		thing.setColor(Color.lightcoral)
	elif thingy.has(t):
		thing = thingy[t].instance()
	else:
		thing = invalid.instance()
		thing.setText("Invalid value type!")
		thing.setColor(Color.lightcoral)
	
	return thing

func clear() -> void:
	Util.delete_children($vb/contents/tabs/tabs)
	Util.delete_children(optionsvb)
	GlobalTooltip.resetTooltips()

func scroll_gui_input(event: InputEvent, sc:ScrollContainer) -> void:
	if event is InputEventMouseMotion:
		if event.pressure>0.5:
			sc.scroll_horizontal -= event.relative.x*2
			sc.scroll_vertical -= event.relative.y*2
	

