extends "res://Modules/RodentUtils/options/please me stop being stupid/TextOption.gd"

func configValueSetter(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.connect("text_changed", self, "setValueWoo", [_option, v])

func unconfigValueSetter(_option) -> void:
	var v = get_node_or_null(valueSetter)
	if v.is_connected("text_changed", self, "setValueWoo"):
		v.disconnect("text_changed", self, "setValueWoo")

func setValueWoo(_option, thingy) -> void:
	_option.setValue(thingy.text)
