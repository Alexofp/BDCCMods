extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.value = _option.getValue()

