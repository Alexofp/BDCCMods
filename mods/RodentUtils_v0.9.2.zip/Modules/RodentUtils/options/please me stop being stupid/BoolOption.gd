extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.set_pressed_no_signal(bool(_option.getValue()))
	updateButt(v.pressed, v)

func updateButt(state:bool, b:Button) -> void:
	b.text = "Yes" if state else "No"

func configValueSetter(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.connect("toggled", _option, "setValue")

func unconfigValueSetter(_option) -> void:
	var v = get_node_or_null(valueSetter)
	if v.is_connected("toggled", _option, "setValue"):
		v.disconnect("toggled", _option, "setValue")

func _ready() -> void:
	$CheckBox.connect("toggled", self, "updateButt", [$CheckBox])
