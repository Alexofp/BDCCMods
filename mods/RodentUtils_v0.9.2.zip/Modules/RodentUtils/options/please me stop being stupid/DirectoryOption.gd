extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.current_path = _option.getValue()
	$vb/Current.text = v.current_path if v.current_path else "(unset)"

func configValueSetter(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.connect("dir_selected", _option, "setValue")
	v.access = _option.getExtra("access", FileDialog.ACCESS_USERDATA)

func unconfigValueSetter(_option) -> void:
	var v = get_node_or_null(valueSetter)
	if v.is_connected("dir_selected", _option, "setValue"):
		v.disconnect("dir_selected", _option, "setValue")

func _ready() -> void:
	$vb/Browse.key_label.text = ""
