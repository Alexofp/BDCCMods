extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = get_node_or_null(valueSetter)
	v.color = _option.getValue()

func _on_ColorPickerButton_color_changed(color: Color) -> void:
	if option:
		option.setValue(color)
