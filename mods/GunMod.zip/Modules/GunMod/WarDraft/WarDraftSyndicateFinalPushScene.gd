extends SceneBase

var npcID:String = ""
var wavePhase:String = "" # "scout" or "breach"
var waveLeft:int = 0

func _init():
	sceneID = "WarDraftSyndicateFinalPushScene"

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func beginWave(phase:String, count:int):
	wavePhase = phase
	waveLeft = count
	GM.main.PS.warnIfNoWeapon()
	spawnWaveEnemy()

func spawnWaveEnemy():
	var theGenerator = GM.main.PS.getEnemySoldierGeneratorScript().new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	npcID = theChar.getID()
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "holdrifle", {npc=npcID, npcAction=["holdrifle", GM.main.PS.getEnemyWeaponModelPath()]})
	runScene("FightScene", [npcID, "WarDraftPatrol"], "waveFight")

func spawnCommander():
	npcID = "drask"
	GM.main.PS.warnIfNoWeapon()
	addCharacter("drask")
	playAnimation(StageScene.Duo, "holdrifle", {npc="drask", npcAction=["holdrifle", "res://Modules/GunMod/Models/EnergyRifle.tscn"]})
	runScene("FightScene", ["drask", "WarDraftPatrol"], "commanderFight")

func _run():
	if(state == ""):
		addCharacter("vex")
		playAnimation(StageScene.Duo, "stand", {npc="vex"})
		saynn("Vex doesn't call the line together quietly. She wants noise, and every soldier within earshot is already worked up before she says a word.")

		saynn("[say=vex]We're taking Drask's position today. Whole thing, front to back. I want it loud.[/say]")

		saynn("The squad answers her with something between a cheer and a snarl.")

		saynn("[say=vex]Same command that hit Kessler's Ridge sits behind that wall. You've all heard the story by now. Today we get to finish it.[/say]")

		saynn("[say=vex]You've earned the front on this one. Don't waste it.[/say]")

		saynn("[say=pc]Rodger.[/say]")

		saynn("[say=vex]Good answer. Move out, and try to enjoy yourself.[/say]")

		addButton("Move out", "Advance on Drask's position", "advance")

	if(state == "advance"):
		saynn("The advance is fast and loud, nothing careful about it.")

		saynn("[say=vex]Jackal, report.[/say]")

		saynn("Silence on the line. Vex calls it again, sharper.")

		saynn("[say=vex]Jackal! Report![/say]")

		saynn("Nothing comes back. Somewhere off to your right, a callsign you'd gotten used to hearing stops answering.")

		saynn("[say=pc]Fucking asshole! Jackal's gone.[/say]")

		saynn("[say=vex]Somebody's going to pay for that...[/say]")

		saynn("Nobody around you slows down. If anything the pace picks up, boots hitting harder.")

		saynn("Movement ahead, in the wreckage of a burnt out transport. A forward scout squad, dug in and waiting for exactly this.")

		addButton("Push through", "Clear the scouts", "start_scout_wave")

	if(state == "wave_between"):
		if(wavePhase == "scout"):
			saynn("Another one breaks from cover before the first even hits the ground. "+str(waveLeft)+" left, and somebody near you sounds delighted about it.")
			saynn("[say=pc]More of them![/say]")
		else:
			saynn("A second guard peels off from the doorway, rifle already up. "+str(waveLeft)+" left.")
			saynn("[say=pc]Still one more![/say]")

		addButton("Continue", "Keep fighting", "next_wave")

	if(state == "after_scout"):
		removeCharacter(npcID)
		saynn("The scout squad stops moving. Vex jogs up beside you, slightly panting, grin wide enough to be a problem.")

		saynn("[say=vex]That's what I like to see. Wall's past this ridge. Won't be that easy again. Move out people![/say]")

		saynn("Nobody stops for Jackal's body. Someone steps over it without looking down.")

		saynn("[say=pc]We're not even-[/say]")

		saynn("[say=vex]No. We'll grieve later, lets move.[/say]")

		addButton("Continue", "Push on toward the wall", "outer_wall")

	if(state == "outer_wall"):
		saynn("By the time the wall comes into view, cratered and still smoking, Vex's voice comes over the line.")

		saynn("[say=vex]That's him. End of the line. We're finishing this today, and I want to hear it when we do.[/say]")

		saynn("[say=pc]Jackal didn't make it.. anyone else?[/say]")

		saynn("[say=vex]Two more, on the flank!.[/say]")

		saynn("The wall's held by a pair of guards in full kit, dug into a firing position with a clear line on the breach point. Getting through means going straight at them.")

		addButton("Breach", "Force the wall", "start_breach_wave")

	if(state == "after_breach"):
		removeCharacter(npcID)
		saynn("The second guard drops and doesn't get back up. Vex staggers a half step, a graze along her ribs already soaking through her armor, she laughs it off.")

		saynn("[say=pc]Vex![/say]")

		saynn("[say=vex]Barely felt it. Go on, that's clearly not for me.[/say]")

		saynn("She waves off anyone who so much as looks like they're thinking about stopping to check on her.")

		saynn("[say=vex]Whoever's running that post is inside. Go finish it before I decide I want to.[/say]")

		saynn("[say=pc]I'll finish it.[/say]")

		addButton("Go in alone", "Breach the command post's inner room", "push_in")

	if(state == "push_in"):
		addCharacter("drask")
		playAnimation(StageScene.Duo, "stand", {npc="drask"})
		saynn("You breach the inner room in a wall of noise and smoke. Drask's already on his feet, rifle up, and whatever he was expecting through that door, it wasn't you.")

		saynn("[say=drask]...You.[/say]")

		saynn("He doesn't lower the rifle. His hand's not quite steady on it either.")

		saynn("[say=drask]I trained you. I vouched for you. And you're standing on the other side of my own barrel.[/say]")

		addButton("Push on what changed.", "You vouched for someone who doesn't exist anymore.", "vouched_callout")
		addButton("Push on why you left", "You were never going to let me walk away from this clean either way.", "why_defect")
		addButton("I'm not here to talk.", "Skip straight to the fight", "just_fight")

	if(state == "vouched_callout"):
		saynn("[say=pc]You vouched the wrong pawn, Sarge.[/say]")

		saynn("[say=drask]That's not- I never sent anyone out to die. I kept people alive out there.[/say]")

		saynn("[say=pc]You kept the ones you could still put a name to. When Vex's people had me ziptied in a cell, nobody radioed you. Nobody came looking.[/say]")

		saynn("[say=drask]I didn't know you were-[/say]")

		saynn("[say=pc]Doesn't matter. I was already just a number by then, same as everyone else you couldn't keep track of.[/say]")

		saynn("He doesn't have an answer ready for that one. It costs him a second he can't afford.")

		addButton("Continue", "Finish it", "drask_ready")

	if(state == "why_defect"):
		saynn("[say=pc]You were never going to let me walk out of this war clean either way, Sarge.[/say]")

		saynn("[say=drask]That's not true. I would've come for you.[/say]")

		saynn("[say=pc]Nobody did. I sat in a Syndicate cell and AlphaCorp never even noticed I was gone. Vex noticed.[/say]")

		saynn("[say=drask]So you're her bitch now? Listen to yourself.[/say]")

		saynn("[say=pc]At least she's honest about owning me. Nobody back home even bothered lying about it.[/say]")

		saynn("Something in his face cracks, just slightly, before the rifle comes back up.")

		addButton("Continue", "Finish it", "drask_ready")

	if(state == "just_fight"):
		saynn("[say=pc]I'm not here to talk, Sarge.[/say]")

		saynn("[say=drask]...Yeah. Figured.[/say]")

		addButton("Continue", "Get it over with", "drask_ready")

	if(state == "drask_ready"):
		saynn("[say=drask]Guess I taught you too well.[/say]")

		saynn("[say=pc]Guess you did.[/say]")

		addButton("Engage", "Fight Drask", "commander_fight")

	if(state == "lost_encounter"):
		playAnimation(StageScene.Duo, "defeat", {npc=npcID})
		if(npcID == "drask"):
			saynn("Drask gets the better of you, and the room tilts sideways before you can do anything about it. He doesn't say anything smug about it. He doesn't have to.")
		else:
			saynn("{npc.name} gets the better of you, and the ground tilts sideways before you can do anything about it.")

		addButton("Continue", "See what happens next", "start_defeated_sex")

	if(state == "encounter_captured"):
		removeCharacter(npcID)
		playAnimation(StageScene.Sleeping, "sleep")
		saynn("Everything goes dark before the rest of the squad even makes it into the room.")

		addButton("Continue", "See what happens next", "go_captured")

	if(state == "encounter_survived_sex"):
		removeCharacter(npcID)
		if(npcID == "drask"):
			saynn("You claw your way back to your feet, breathing hard. Whatever's left of the squad clears the room without you.")

			saynn("Vex isn't going to be happy about this. That's a problem for after you've caught your breath.")
		else:
			saynn("You claw your way back to your feet, breathing hard. Behind you, someone's already moving up to cover your position.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "victory"):
		playAnimation(StageScene.Duo, "stand", {npc="drask", npcAction="defeat"})
		saynn("Drask finally goes down, disarmed and pinned under you. Outside, the gunfire's already thinning into something that used to be a fight and isn't anymore.")

		if(GM.main.PS.dropEnemyWeapon(GM.main.PS.EnemyWeaponDropChance, "GunModEnergyRifle")):
			saynn("You kick his energy rifle out of reach before he can think about reaching for it. Still fully charged.")

		saynn("[say=drask]...Go on, then.[/say]")

		saynn("[say=pc]Not my call anymore.[/say]")

		addButton("Continue", "See what happens next", "vex_arrives_drask")

	if(state == "vex_arrives_drask"):
		addCharacter("vex")
		playAnimation(StageScene.Duo, "stand", {npc="vex"})
		saynn("Vex limps in behind you, one hand still pressed to her side, and goes very still when she sees who's on the floor.")

		saynn("[say=vex]Well. Look who finally ran out of luck.[/say]")

		saynn("Drask doesn't answer her. He's not looking at her at all. He's looking at you.")

		saynn("[say=vex]Oh, don't do that, sweetheart. Don't get shy on me now.[/say]")

		saynn("She crouches down next to him, tilting his chin up with two fingers like she's inspecting livestock.")

		saynn("[say=vex]I'm going to enjoy this a great deal more than the paperwork usually deserves.[/say]")

		addButton("Join in", "Take part", "claim_drask_join")
		addButton("Just watch", "Stay out of it", "claim_drask_watch")

	if(state == "claim_drask_join"):
		addCharacter("vex", ["naked"])
		addCharacter("drask", ["naked"])

		if(GM.pc.hasPenis()):
			playAnimation(StageScene.SexSpitroast, "sex", {
				pc="drask", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true, hard=true},
				npc2="pc", npc2BodyState={naked=true, hard=true},
			})

			saynn("Between the two of you, he doesn't get much say in any of it. Vex has him bent forward before he's even done catching his breath, and you're not about to let the front end go to waste.")

			saynn("[say=vex]There he is. Look at you, taking it from both ends and still trying to keep that scowl on.[/say]")

			saynn("Drask doesn't answer. Can't, really, not with his mouth full, and every time he tries to brace against it Vex just drives in a little harder to remind him whose idea this was.")

			playAnimation(StageScene.SexSpitroast, "fast", {
				pc="drask", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true, hard=true},
				npc2="pc", npc2BodyState={naked=true, hard=true},
			})

			saynn("[say=vex]Faster than you'd think for a man his size~ Guess that's the one order he's still following.[/say]")

			saynn("Whatever's left of his composure goes somewhere around the time both of you find the same rhythm, and he stops fighting either of you, just braced between you and taking it.")

			playAnimation(StageScene.SexSpitroast, "inside", {
				pc="drask", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true, hard=true},
				npc2="pc", npc2BodyState={naked=true, hard=true},
				npcCum=true, pcCum=true,
			})

			saynn("Vex finishes with a low, satisfied laugh, and you're right behind her, and for one long second Drask just kneels there between you both, wrecked and silent.")

			saynn("[say=vex]See? Told you it'd be worth the paperwork.[/say]")
		else:
			playAnimation(StageScene.SexBehind, "sex", {
				pc="drask", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true, hard=true},
			})

			saynn("Vex has him bent forward before he's even done catching his breath, one hand fisted in his hair, the other steering his hips exactly where she wants them.")

			saynn("[say=vex]There he is. Come here, get a good look at his face while I work.[/say]")

			saynn("You crouch in front of him, close enough that he has to look at you or nowhere at all, and he chooses you every time, jaw tight, refusing to give either of you a sound.")

			playAnimation(StageScene.SexBehind, "fast", {
				pc="drask", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true, hard=true},
			})

			saynn("[say=vex]Faster than you'd think for a man his size~ Guess that's the one order he's still following.[/say]")

			saynn("You reach out and tip his chin up yourself, and something in his expression finally cracks, somewhere between hate and relief that it's you and not just her.")

			playAnimation(StageScene.SexBehind, "inside", {
				pc="drask", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true, hard=true},
				npcCum=true,
			})

			saynn("Vex finishes with a low, satisfied laugh, still holding him steady through the last of it, and for one long second Drask just kneels there, wrecked and silent.")

			saynn("[say=vex]See? Told you it'd be worth the paperwork.[/say]")

		addButton("Continue", "See what happens next", "drask_secured")

	if(state == "claim_drask_watch"):
		addCharacter("vex", ["naked"])
		addCharacter("drask", ["naked"])

		playAnimation(StageScene.SexBehind, "sex", {
			pc="drask", bodyState={naked=true, exposedCrotch=true},
			npc="vex", npcBodyState={naked=true, hard=true},
		})

		saynn("You stay back and let her have this one. Vex doesn't wait for an invitation, bending him forward and working him open with the same brisk efficiency she does everything else.")

		saynn("[say=vex]Don't just stand there, sweetheart. Watch. This is the part where he learns what losing actually costs.[/say]")

		playAnimation(StageScene.SexBehind, "fast", {
			pc="drask", bodyState={naked=true, exposedCrotch=true},
			npc="vex", npcBodyState={naked=true, hard=true},
		})

		saynn("Drask doesn't make it easy on himself, jaw locked, refusing to give her a single sound. It doesn't slow her down any.")

		playAnimation(StageScene.SexBehind, "inside", {
			pc="drask", bodyState={naked=true, exposedCrotch=true},
			npc="vex", npcBodyState={naked=true, hard=true},
			npcCum=true,
		})

		saynn("She finishes with a low laugh, still holding him steady, and looks over at you like she's checking whether you enjoyed the show.")

		saynn("[say=vex]Not going to lie, I expected you to want a turn.[/say]")

		saynn("[say=pc]Maybe next time.[/say]")

		saynn("[say=vex]Mm. I'll hold you to that.[/say]")

		addButton("Continue", "See what happens next", "drask_secured")

	if(state == "drask_secured"):
		saynn("It's over fast, and Drask doesn't fight any of it. Whatever's left of him by the end isn't putting up a struggle when they zip-tie his wrists.")

		saynn("[say=pc]...Is he going to be okay?[/say]")

		saynn("[say=vex]Define okay. He's breathing. That's the part Command cares about.[/say]")

		addButton("Continue", "See what happens next", "victory_vex")

	if(state == "victory_vex"):
		saynn("[say=vex]Kessler's Ridge, evened out. Not bad for an afternoon.[/say]")

		saynn("She looks satisfied in a way you haven't seen from her before.")

		saynn("[say=vex]I'll get word to the outpost myself. This is the kind of thing that earns a soldier a real seat at the ta-[/say]")

		addButton("Continue", "Let the moment last", "mirri_crash")

	if(state == "mirri_crash"):
		saynn("A shrieking whine drowns out everything else as an unmarked ship comes in low and hot, trailing smoke, and doesn't so much land as arrive. It clips the doorway and slams down right where Vex is standing.")

		saynn("A loud thud is heard where Vex once was.")

		saynn("[say=pc]...Vex?[/say]")

		saynn("Nothing answers.")

		addButton("Continue", "See what happens next", "grabbed")

	if(state == "grabbed"):
		addCharacter("mirri")
		playAnimation(StageScene.Duo, "stand", {npc="mirri"})
		saynn("The ship's hatch drops open and Mirri jumps out already moving, grabbing you by the collar before you can process what you just watched.")

		saynn("[say=mirri]There you are! Rough looking room. Let's not stick around for the cleanup crew.[/say]")

		addButton("Continue", "Get out", "escape_gunfire")

	if(state == "escape_gunfire"):
		saynn("Whatever's left of the squad doesn't wait for an explanation. As far as they can tell, an unmarked ship just killed their commander and is now hauling off one of their own, so they open up on it with everything they've got.")

		saynn("Rifle fire rakes the hull the second the ship lifts off, Mirri swearing the whole way up through the atmosphere.")

		saynn("[say=mirri]Ungrateful sons of- hang on![/say]")

		saynn("The ship lurches hard enough to throw you into a bulkhead, then steadies out as the gunfire falls away below.")

		addButton("Continue", "See what she wants", "leaving")

	if(state == "leaving"):
		saynn("[say=pc]...You killed her.[/say]")

		saynn("Mirri doesn't even look up from the console.")

		saynn("[say=mirri]Wasn't the plan. Wasn't exactly an accident either, knowing my luck.[/say]")

		saynn("You should feel something about that. You're still working out what.")

		saynn("[say=pc]She had it coming.[/say]")

		saynn("[say=mirri]That's the spirit. Most people at least pretend to be sad for a minute.[/say]")

		saynn("[say=pc]I watched what she did to Drask an hour ago.. I'm not pretending anything.[/say]")

		saynn("Mirri glances back at you properly for the first time since you got on board, and whatever she sees there, she doesn't argue with it.")

		saynn("[say=mirri]You're worth more to me walking around owing me than dead in a war that just lost its favorite psychopath. Small mercies.[/say]")

		addButton("Continue", "See where this goes", "ending")

	if(state == "ending"):
		saynn("Before you can even process what just happened, again, you're already on approach to BDCC. Your collar's exactly as tight as it was the day you left.")

		addButton("Leave", "Go home", "go_home")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_scout_wave"):
		processTime(10*60)
		beginWave("scout", 2)
		return

	if(_action == "next_wave"):
		removeCharacter(npcID)
		spawnWaveEnemy()
		return

	if(_action == "start_breach_wave"):
		processTime(10*60)
		beginWave("breach", 2)
		return

	if(_action == "commander_fight"):
		spawnCommander()
		return

	if(_action == "start_defeated_sex"):
		getCharacter(npcID).prepareForSexAsDom()
		runScene("GenericSexScene", [npcID, "pc", SexType.DefaultSex, {SexMod.SubMustGoUnconscious:true, SexMod.DisableDynamicJoiners:true}], "defeated_sex")
		return

	if(_action == "claim_drask_join"):
		processTime(15*60)
		getCharacter("drask").cummedInAnusBy("vex", FluidSource.Penis)
		if(GM.pc.hasPenis()):
			getCharacter("drask").cummedInMouthBy("pc", FluidSource.Penis)
			GM.pc.orgasmFrom("drask")
			GM.pc.addSkillExperience(Skill.SexSlave, 30, "claim_drask_sex")
		GM.pc.getFetishHolder().addFetish(Fetish.Sadism, RNG.randf_range(0.05, 0.15))

	if(_action == "claim_drask_watch"):
		processTime(15*60)
		getCharacter("drask").cummedInAnusBy("vex", FluidSource.Penis)

	if(_action == "go_captured"):
		endScene()
		runScene(GM.main.PS.getCombatLossSceneID())
		return

	if(_action == "go_home"):
		GM.main.PSH.unlockEndingAddMessage("WarDraft", "vex_collateral")
		GM.pc.setLocation(GM.pc.getCellLocation())
		GM.main.stopPlayerSlavery()
		endScene()
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "waveFight"):
		processTime(5*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			if(GM.main.PS.dropEnemyWeapon(GM.main.PS.EnemyWeaponDropChance, GM.main.PS.getEnemyWeaponID())):
				GM.main.PS.addMessage("You strip a fully-loaded "+GM.main.PS.getEnemyWeaponName()+" off the body.")
			waveLeft -= 1
			if(waveLeft <= 0):
				if(wavePhase == "scout"):
					setState("after_scout")
				else:
					setState("after_breach")
			else:
				setState("wave_between")
		else:
			setState("lost_encounter")

	if(_tag == "commanderFight"):
		processTime(5*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			setState("victory")
		else:
			setState("lost_encounter")

	if(_tag == "defeated_sex"):
		var sexResult:SexEngineResult = _result[0]
		var gotUncon:bool = sexResult.isSubUnconscious("pc")

		if(gotUncon):
			setState("encounter_captured")
		else:
			setState("encounter_survived_sex")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID
	data["wavePhase"] = wavePhase
	data["waveLeft"] = waveLeft

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
	wavePhase = SAVE.loadVar(data, "wavePhase", "")
	waveLeft = SAVE.loadVar(data, "waveLeft", 0)
