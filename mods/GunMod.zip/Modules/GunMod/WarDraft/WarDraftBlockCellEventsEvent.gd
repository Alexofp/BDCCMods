extends EventBase

# RestingInCellScene.gd (reused as-is for the wardraft_bunker/bunker2 beds -
# see CLAUDE.md) fires the same global Trigger.SleepInCell any real prison
# cell would, with no location check at all. Modules/PlayerSlaveryModule/
# Util/NpcOwnerSleepTogetherEvent.gd listens for exactly that trigger to let
# a softly-owned NPC slave crawl into bed with the player - completely
# reasonable in an actual BDCC cell, not reasonable in a war-zone bunk in a
# totally different scenario. PriorityEventTrigger.triggerReact() stops at
# the first handler that returns true (Events/EventTriggers/
# PriorityEventTrigger.gd), so intercepting the trigger here with a higher
# priority than NpcOwnerSleepTogetherEvent's default (10, EventBase.gd's own
# default - it never overrides getPriority()) blocks it from ever running
# while in WarDraft. RestingInCellScene itself discards this trigger's return
# value ("if(GM.ES.triggerReact(Trigger.SleepInCell)): pass"), so returning
# true here has no other side effect.

func _init():
	id = "WarDraftBlockCellEventsEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SleepInCell)

func getPriority():
	return 100

func react(_triggerID, _args):
	return GM.main.isInSpecificPlayerSlavery("WarDraft")
