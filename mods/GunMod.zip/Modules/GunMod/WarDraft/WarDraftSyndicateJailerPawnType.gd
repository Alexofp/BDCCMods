extends "res://Game/InteractionSystem/PawnTypes/Guard.gd"

# Dedicated pawn type for WarDraftBase's own detention jailers - same guard
# stats/pool/generator as a regular Guard (inherited), just with two
# differences from the shared Guard.gd type every base-game prison guard
# also uses:
# - A distinct world-map icon color. CharacterPawn.getPawnColor() colors any
#   CharacterType.Guard pawn blue by default (the same color a regular
#   AlphaCorp/prison guard gets) - overriding getCustomPawnColor() here is
#   the only per-type hook for that, can't touch it on the shared Guard.gd
#   type without recoloring every guard in the game.
# - Locked onto the Patrol goal exclusively via getProcessedGoalScore()
#   zeroing every other Alone goal's score. Without this, a freshly spawned
#   pawn's very first goal pick (and every 300-second re-evaluation after)
#   is a weighted-random pick across ALL alone goals plus Patrol, so it can
#   land on something else entirely - these pawns exist purely to patrol
#   while WarDraftJailerPatrolTask.canDoTask() allows it, so nothing else is
#   worth ever picking.

func _init():
	id = "WarDraftSyndicateJailer"

func getCustomPawnColor(_pawn):
	return Color.red

func getProcessedGoalScore(_pawn, _goalID:String, theScore:float, _isKeepScore:bool) -> float:
	if(_goalID == InteractionGoal.Patrol):
		return theScore
	return 0.0
