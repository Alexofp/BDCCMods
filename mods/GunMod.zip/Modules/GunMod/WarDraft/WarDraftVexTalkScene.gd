extends SceneBase

func _init():
	sceneID = "WarDraftVexTalkScene"

func _run():
	if(state == ""):
		addCharacter("vex")
		playAnimation(StageScene.Solo, "stand", {pc="vex"})
		saynn("Vex glances up the moment you walk in, and her eyes don't wander off again. You get the feeling she already worked out exactly what you're worth to her, and likes the number.")

		addButton("Talk", "Ask Vex about your situation", "talk")
		addButton("Appearance", "Look at Vex", "appearance")
		addButton("Sex?", "Proposition Commander Vex", "sex_offer")
		if(GM.main.PS.corruption >= GM.main.PS.CorruptionThresholdForFinalPush):
			addButton("The final push?", "Ask about hitting Drask's position", "final_push_offer")
		addButton("Leave", "Get moving", "endthescene")

	if(state == "appearance"):
		saynn("Vex is lean for a commander, all wiry muscle and a jaw strong enough to make you nervous just watching her talk. Her coat runs sandy tan with a scatter of dark brown spots down her back and flanks, paling out toward a cream underbelly.")

		saynn("Her hair's a perfect match for someone who looks otherwise built for violence: a deep wine red, streaked through with white, worn loose instead of tied back, like she wants you looking at it instead of the teeth. Her ears never stop moving, tracking every sound in the room.")

		saynn("She wears the same Syndicate armor as the rest of her people. She wants you to see her curves when she's the one making your day worse.")

		saynn("Underneath, it looks like she's packing a solid fifteen centimeters, though it's rarely the thing anyone in the room ends up most worried about.")

		addButton("Back", "Ask something else", "")

	if(state == "sex_offer"):
		saynn("[say=pc]...Since we're talking. You ever get bored out here, Commander?[/say]")

		saynn("[say=vex]Bored? No. Curious what you're actually asking me, though.[/say]")

		saynn("[say=pc]You know what I'm asking.[/say]")

		saynn("[say=vex]Mm. Cute, thinking this was ever going to be your idea.[/say]")

		saynn("She's already closing the distance before you've finished deciding whether you meant it, one clawed hand finding your jaw and tilting your face up like she's checking the merchandise.")

		saynn("[say=vex]On your knees. Face the wall, hands on it too, bitch.[/say]")

		addButton("Do as she says", "Get on your knees", "vex_sex")
		addButton("Not now", "Change your mind", "")

	if(state == "vex_sex"):
		addCharacter("vex", ["naked"])
		playAnimation(StageScene.SexBehind, "sex", {
			bodyState={naked=true, exposedCrotch=true},
			npcBodyState={naked=true, hard=true}, npc="vex",
		})

		saynn("You turn and face the wall the way she told you to, palms flat against cold metal, and you hear rather than see her getting undressed behind you: buckles, then fabric, then nothing. A clawed hand runs slowly down your spine, unhurried, like she already knows you're not going anywhere.")

		saynn("[say=vex]Good. Now stay just like that.[/say]")

		saynn("Her cock presses against you before you're even braced for it, hot and already hard, and she doesn't bother easing into anything.")

		playAnimation(StageScene.SexBehind, "fast", {
			bodyState={naked=true, exposedCrotch=true},
			npcBodyState={naked=true, hard=true}, npc="vex",
		})

		saynn("[say=vex]There we go~ Look at that. You take it better than half my own soldiers.[/say]")

		saynn("She sets a pace that's entirely her own decision, one clawed hand braced on your hip hard enough to bruise, the other tangled in whatever's left of your hair. Every thrust is punctuated with a low, satisfied sound, like she's savoring exactly how little say you get in any of this.")

		if(GM.pc.hasPenis()):
			if(GM.pc.isWearingChastityCage()):
				saynn("Your caged cock throbs uselessly against the metal with every thrust, leaking precum you have no way to do anything about. Vex notices. Vex always notices.")

				saynn("[say=vex]Aww. Poor thing, all dressed up with nowhere to go~[/say]")
			else:
				saynn("Your own cock is achingly hard by now, bobbing untouched with every thrust, and you can't help but reach down and start stroking yourself in rhythm with her.")

				saynn("[say=vex]There you go. Multitasking. I like that in a subordinate~[/say]")
		elif(GM.pc.hasVagina()):
			saynn("One of your hands sneaks down between your own legs without much permission from the rest of you, fingers finding your clit and rubbing in time with her thrusts.")

			saynn("[say=vex]Go on. Not like I asked, but go on~[/say]")

		saynn("The pace picks up, her breath going ragged behind you, claws digging in just a little harder. Whatever composure she started with is fraying at the edges now, replaced with something hungrier.")

		saynn("[say=vex]Fuck- you're going to make me actually work for this.[/say]")

		playAnimation(StageScene.SexBehind, "inside", {
			bodyState={naked=true, exposedCrotch=true},
			npcBodyState={naked=true, hard=true}, npc="vex",
			pcCum=true, npcCum=true,
		})

		saynn("She finishes with her teeth against the back of your shoulder, not quite biting, and a long, low groan that's the closest thing to unguarded you've heard out of her yet. She doesn't pull out right away, just stays there a moment, catching her breath, still holding your hip like she's not quite ready to let go of it.")

		if(GM.pc.hasPenis()):
			saynn("The feeling of her finishing inside you, combined with your own hand's rhythm, tips you over the edge right after her. You spill against the wall, legs unsteady, riding out the last of it with her still buried in you.")
		elif(GM.pc.hasVagina()):
			saynn("Between her own climax and your own fingers, you're right behind her, a wave of heat crashing through you hard enough that your knees nearly give out against the wall.")
		else:
			saynn("You're left shaking against the wall, wrung out from everything except your own release, and somehow that doesn't feel like an accident either.")

		saynn("Vex finally pulls back, already reaching for her fatigues like this was the least remarkable part of her afternoon.")

		saynn("[say=vex]Good. Same time next week, sweetheart?[/say]")

		saynn("[say=pc]...That an order?[/say]")

		saynn("[say=vex]Everything's an order. You're just starting to notice.[/say]")

		addButton("Continue", "Catch your breath", "endthescene")

	if(state == "talk"):
		saynn("[say=vex]Get on with it, dear.[/say]")

		addButton("What now?", "Ask about your situation", "situation_topic")
		addButton("Why?", "Ask what she gets out of it", "enjoy_topic")
		addButton("Drask?", "Ask if she knows the AlphaCorp sergeant", "drask_topic")
		addButton("Back", "Enough talking", "")

	if(state == "situation_topic"):
		saynn("[say=pc]So what happens to me now?[/say]")

		saynn("[say=vex]You will be a good little soldier and make us proud. Go out there and hit those AlphaCorp deadbeats and send a message.[/say]")

		saynn("She says it with a proud grin on her face, like she struck gold finding you.")

		addButton("Continue", "Ask something else", "talk")

	if(state == "enjoy_topic"):
		saynn("[say=pc]Why do you even enjoy this? It's just a job.[/say]")

		saynn("[say=vex]For you, maybe. I could've as easily stayed behind a desk. But here? Things are much more intimate and personal.[/say]")

		saynn("You figure she would not make a good accountant.")

		addButton("Continue", "Ask something else", "talk")

	if(state == "drask_topic"):
		saynn("[say=pc]You know Sergeant Drask?[/say]")

		saynn("[say=vex]Ohh that muscle for brains? Of course. Loud, sentimental, keeps his people alive longer than he should be able to. It's almost impressive.[/say]")

		saynn("[say=pc]You say that like it's an insult.[/say]")

		saynn("[say=vex]It is. Caring about them just means there's more of him to break when they stop coming home.[/say]")

		saynn("[say=pc]You talk about him a lot for someone who barely knows him.[/say]")

		saynn("[say=vex]Mm. Maybe I just like the idea of being the one who finally gets him on his knees.[/say]")

		saynn("She says it light, like a joke. Her eyes don't.")

		saynn("[say=pc]That an appetite or a grudge?[/say]")

		saynn("[say=vex]Does it have to be one or the other, sweetheart?[/say]")

		addButton("Continue", "Ask something else", "talk")

	if(state == "final_push_offer"):
		saynn("[say=pc]Command's putting together a run at Drask's position?[/say]")

		saynn("[say=vex]Not Command's idea. Mine. And it's not a run, it's a statement. Every soldier I've got is already arming uo.[/say]")

		saynn("[say=vex]You've earned the front row. Say the word and I turn everyone loose.[/say]")

		addButton("Turn them loose", "Start the assault on Drask's position", "start_final_push")
		addButton("Not yet", "Keep patrolling for now", "")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_final_push"):
		endScene()
		runScene("WarDraftSyndicateFinalPushScene")
		return

	if(_action == "vex_sex"):
		processTime(20*60)
		GM.pc.orgasmFrom("vex")
		GM.pc.cummedInAnusBy("vex", FluidSource.Penis)
		GM.pc.addSkillExperience(Skill.SexSlave, 30, "vex_talk_sex")

	setState(_action)
