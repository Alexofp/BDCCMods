extends SceneBase

const SyndicateSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/SyndicateSoldierGenerator.gd")

var npcID:String = ""
var wavePhase:String = "" # "scout" or "breach"
var waveLeft:int = 0

func _init():
	sceneID = "WarDraftFinalPushScene"

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func beginWave(phase:String, count:int):
	wavePhase = phase
	waveLeft = count
	GM.main.PS.warnIfNoWeapon()
	spawnWaveEnemy()

func spawnWaveEnemy():
	var theGenerator := SyndicateSoldierGeneratorScript.new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	npcID = theChar.getID()
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "holdrifle", {npc=npcID, npcAction=["holdrifle", "res://Modules/GunMod/Models/MarauderRifle.tscn"]})
	runScene("FightScene", [npcID, "WarDraftPatrol"], "waveFight")

func spawnCommander():
	npcID = "vex"
	GM.main.PS.warnIfNoWeapon()
	addCharacter("vex")
	playAnimation(StageScene.Duo, "holdrifle", {npc="vex", npcAction=["holdrifle", "res://Modules/GunMod/Models/EnergyRifle.tscn"]})
	runScene("FightScene", ["vex", "WarDraftPatrol"], "commanderFight")

func _run():
	if(state == ""):
		addCharacter("drask")
		playAnimation(StageScene.Duo, "stand", {npc="drask"})
		saynn("Drask calls the whole line together before dawn, no jokes this time.")

		saynn("[say=drask]Command's calling it. We're taking the Syndicate's forward command post today. Whole thing, front to back. This is the real one.[/say]")

		saynn("[say=drask]Intel says it's the same command post that hit Kessler's Ridge. I've waited a long time for this.[/say]")

		saynn("He doesn't say anything else about that. He doesn't need to.")

		saynn("[say=drask]You've earned your spot at the front of this one. Command wanted to know who's been racking up kills out there. I told them your name.[/say]")

		saynn("[say=drask]Don't make me regret that.[/say]")

		saynn("[say=pc]Try not to die on me either, Sarge.[/say]")

		saynn("He looks over the rest of the squad, a dozen scared faces trying not to show it.")

		saynn("[say=drask]Move out. Stay on my line and you'll see tomorrow.[/say]")

		addButton("Move out", "Advance on the command post", "advance")

	if(state == "advance"):
		saynn("The advance is slow and ugly. Ground gets contested a meter at a time, and not everyone who starts the push finishes it.")

		saynn("[say=drask]Rook, report.[/say]")

		saynn("Silence on the line. Drask calls it again, harder.")

		saynn("[say=drask]Rook! Report, damn it![/say]")

		saynn("Nothing. Somewhere off to your left, a name you'd learned over the last few weeks stops answering the radio.")

		saynn("[say=pc]Rook's not answering.[/say]")

		saynn("[say=drask]I heard. Keep moving. We grieve after we win.[/say]")

		saynn("Movement ahead, in the wreckage of a burnt-out transport. A forward scout squad, dug in and waiting for exactly this.")

		addButton("Push through", "Clear the scouts", "start_scout_wave")

	if(state == "wave_between"):
		if(wavePhase == "scout"):
			saynn("Another one breaks from cover before the first even hits the ground. "+str(waveLeft)+" left.")
			saynn("[say=pc]More of them![/say]")
		else:
			saynn("A second guard peels off from the doorway, rifle already up. "+str(waveLeft)+" left.")
			saynn("[say=pc]Still one more![/say]")

		addButton("Continue", "Keep fighting", "next_wave")

	if(state == "after_scout"):
		removeCharacter(npcID)
		saynn("The scout squad stops moving. Drask jogs up beside you, breathing hard, and claps a heavy hand on your shoulder.")

		saynn("[say=drask]Good. That's good. Command post's dug in past this ridge. Won't be that easy again.[/say]")

		saynn("Someone drags Rook's body out of the open by the collar of their fatigues, quiet about it. Drask doesn't look over. You get the feeling he's counting the cost in his head and not liking the number.")

		saynn("[say=pc]We're not stopping for him either, huh.[/say]")

		saynn("[say=drask]No. On me. We're not stopping to bury anyone today.[/say]")

		addButton("Continue", "Push on toward the wall", "outer_wall")

	if(state == "outer_wall"):
		saynn("By the time the command post's outer wall comes into view, cratered and still smoking from the artillery prep, Drask's voice comes over the line, flat and hard.")

		saynn("[say=drask]That's the CO's position. End of the line. Whoever's in there, we're ending this today.[/say]")

		saynn("[say=pc]Rook didn't make it.. anyone else?[/say]")

		saynn("[say=drask]Two more, on the flank. Ask me about it after. Right now I need your head in this, not in the dirt with them.[/say]")

		saynn("The wall's held by a pair of guards in full kit, dug into a firing position with a clear line on the breach point. Getting through means going straight at them.")

		addButton("Breach", "Force the wall", "start_breach_wave")

	if(state == "after_breach"):
		removeCharacter(npcID)
		saynn("The second guard drops and doesn't get back up. For a second it looks clean. Then Drask staggers, one hand clamped over his side, dark fur going darker underneath it.")

		saynn("[say=pc]Sarge![/say]")

		saynn("[say=drask]I'm fine. Caught most of it on the plate. Most of it.[/say]")

		saynn("He doesn't sound fine. He waves off the medic jogging over before they even get close.")

		saynn("[say=drask]Whoever's running that post is inside. I can't walk in there like this.[/say]")

		saynn("He looks at you. No anger in it this time, just tired.")

		saynn("[say=drask]This one's yours. Finish it.[/say]")

		saynn("[say=pc]I'll finish it.[/say]")

		addButton("Go in alone", "Breach the command post's inner room", "push_in")

	if(state == "push_in"):
		addCharacter("vex")
		playAnimation(StageScene.Duo, "stand", {npc="vex"})
		saynn("You breach the command post's inner room in a wall of noise and smoke. Only one person's left standing in it: a hyena in Syndicate armor, no helmet, grinning like this is the best part of her day.")

		saynn("[say=vex]Oh, good. AlphaCorp sent someone with a pulse this time.[/say]")

		saynn("She glances past you at the empty doorway.")

		saynn("[say=vex]Just you? Where's the big sad one who keeps talking about his dead friends on an open channel? I was looking forward to that reunion.[/say]")

		addButton("He's still breathing. No thanks to you.", "Push back", "kessler_callout")
		addButton("Chain of command ends with you?", "Ask who's really in charge here", "chain_of_command")
		addButton("I'm not here to talk.", "Skip straight to the fight", "just_fight")

	if(state == "chain_of_command"):
		saynn("[say=pc]So who's really in charge back here.. you the CO, or is there someone smarter hiding behind you?[/say]")

		saynn("[say=vex]There's no one behind me, sweetheart. Never has been. I don't do the hiding-behind-a-desk thing. That's an AlphaCorp specialty.[/say]")

		saynn("[say=vex]I earned this post the same way I earn everything. Somebody was in my way, and then they weren't.[/say]")

		addButton("Continue", "Keep talking", "vex_personal")

	if(state == "kessler_callout"):
		saynn("[say=pc]He's still breathing. No thanks to you.[/say]")

		saynn("[say=vex]Kessler's Ridge? That was me, yeah. Whole line, gone in twenty minutes. I remember because it was a good day.[/say]")

		saynn("She tilts her head, studying you like you're a puzzle she's already solved.")

		saynn("[say=vex]He tell you that story before he sent you at me? Cute. Sentimental, even for him.[/say]")

		addButton("Continue", "Keep talking", "vex_personal")

	if(state == "just_fight"):
		saynn("[say=pc]I'm not here to talk.[/say]")

		saynn("[say=vex]Finally, someone who gets it.[/say]")

		addButton("Continue", "Get it over with", "vex_ready")

	if(state == "vex_personal"):
		saynn("[say=vex]Talk fast, by the way. I get bored easy, and you're already borrowing time.[/say]")

		addButton("Why do you even enjoy this?", "Ask what she gets out of it", "vex_enjoy")
		addButton("You knew going in he'd send someone after you eventually.", "Push on the inevitability of this", "vex_inevitable")
		addButton("Enough. Let's finish this.", "Move to the fight", "vex_ready")

	if(state == "vex_enjoy"):
		saynn("[say=pc]Why do you even enjoy this? It's just a war. Just a job.[/say]")

		saynn("[say=vex]For you, maybe. I could've stayed behind a desk somewhere safe and boring. I didn't, because a desk doesn't get to watch someone's face do what yours is doing right now.[/say]")

		saynn("She doesn't say it like a threat. She says it like she's already had a good day and you're the reason why.")

		addButton("Continue", "Get it over with", "vex_ready")

	if(state == "vex_inevitable"):
		saynn("[say=pc]You knew going in he'd send someone after you eventually.. everyone you burn down does, sooner or later.[/say]")

		saynn("[say=vex]Sure. And every single one of them ends up on the same floor, looking up at me, wondering the exact same thing you're about to.[/say]")

		saynn("[say=pc]Which is what?[/say]")

		saynn("[say=vex]Whether it was worth it. Spoiler: it never is. Doesn't stop anybody from trying.[/say]")

		addButton("Continue", "Get it over with", "vex_ready")

	if(state == "vex_ready"):
		saynn("[say=vex]Let's see how long that pulse of yours lasts.[/say]")

		saynn("[say=pc]Long enough.[/say]")

		addButton("Engage", "Fight the commander", "commander_fight")

	if(state == "lost_encounter"):
		playAnimation(StageScene.Duo, "defeat", {npc=npcID})
		if(npcID == "vex"):
			saynn("Vex gets the better of you, and the room tilts sideways before you can do anything about it. The last thing you hear is her laughing.")
		else:
			saynn("{npc.name} gets the better of you, and the ground tilts sideways before you can do anything about it.")

		addButton("Continue", "See what happens next", "start_defeated_sex")

	if(state == "encounter_captured"):
		removeCharacter(npcID)
		playAnimation(StageScene.Sleeping, "sleep")
		saynn("Everything goes dark before the rest of the squad even makes it into the room.")

		addButton("Continue", "See what happens next", "go_captured")

	if(state == "encounter_survived_sex"):
		removeCharacter(npcID)
		if(npcID == "vex"):
			saynn("You claw your way back to your feet, breathing hard. The rest of the squad clears the room without you.")

			saynn("Command post's taken either way. Whatever's left of your discharge case is going to have to wait for another day.")
		else:
			saynn("You claw your way back to your feet, breathing hard. Behind you, someone's already calling for a medic that isn't coming fast enough.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "victory"):
		playAnimation(StageScene.Duo, "stand", {npc="vex", npcAction="defeat"})
		saynn("Vex finally goes down, disarmed and pinned under you. Outside, the last of the gunfire tapers off into an unfamiliar sound: nothing.")

		if(GM.main.PS.dropEnemyWeapon(GM.main.PS.EnemyWeaponDropChance, "GunModEnergyRifle")):
			saynn("You kick her energy rifle out of reach and pick it up before anyone else can. Still fully charged.")

		saynn("[say=vex]...Go on, then. Finish it. Or is dragging it out half the fun for you too?[/say]")

		saynn("[say=pc]You're not exactly in a hurry to die.[/say]")

		saynn("[say=vex]Aww, but where's the fun in that? I'd rather see what you do next.[/say]")

		addButton("Claim her", "Take her, now that she can't stop you", "claim_vex")
		addButton("Leave her for processing", "Don't take the bait", "vex_secured")

	if(state == "claim_vex"):
		addCharacter("vex", ["naked"])

		if(GM.pc.hasPenis()):
			playAnimation(StageScene.SexBehind, "sex", {
				bodyState={naked=true, hard=true},
				npcBodyState={naked=true, exposedCrotch=true}, npc="vex",
			})

			saynn("You flip her over onto her front and get her wrists pinned before she's even decided whether to fight it. She doesn't. Not really.")

			saynn("[say=vex]Oh? Didn't know you had it in you.[/say]")

			saynn("You don't answer her. You just push in, and for once it's her breath that catches instead of yours.")

			playAnimation(StageScene.SexBehind, "fast", {
				bodyState={naked=true, hard=true},
				npcBodyState={naked=true, exposedCrotch=true}, npc="vex",
			})

			saynn("[say=vex]Mm- fine. Fine, you've earned some enthusiasm.[/say]")

			saynn("She's still trying to sound like she's the one running this, even with her face half into the floor and her voice fraying at the edges with every thrust.")

			playAnimation(StageScene.SexBehind, "inside", {
				bodyState={naked=true, hard=true},
				npcBodyState={naked=true, exposedCrotch=true}, npc="vex",
				pcCum=true,
			})

			saynn("You finish deep inside her, and for one full second she goes completely silent, claws scraping uselessly against the floor.")

			saynn("[say=vex]...Don't get used to that.[/say]")

			saynn("[say=pc]Wouldn't dream of it.[/say]")
		else:
			playAnimation(StageScene.SexOralForced, "suck", {
				pc="pc", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true},
			})

			saynn("You get a fist in her hair and push her down where you want her. She goes, more out of surprise than obedience, and glares up at you the entire way down.")

			saynn("[say=vex]You've got some nerve.[/say]")

			saynn("[say=pc]Learned from the best.[/say]")

			playAnimation(StageScene.SexOralForced, "suckfast", {
				pc="pc", bodyState={naked=true, exposedCrotch=true},
				npc="vex", npcBodyState={naked=true},
			})

			saynn("Whatever she was about to say next gets lost. She settles into it faster than she'd probably like to admit, and the smugness in her eyes starts slipping the longer you hold her there.")

			saynn("She pulls back at last, wiping her mouth with the back of her hand, composure only about half rebuilt.")

			saynn("[say=vex]...Don't get used to that.[/say]")

			saynn("[say=pc]Wouldn't dream of it.[/say]")

		addButton("Continue", "See what happens next", "vex_secured")

	if(state == "vex_secured"):
		saynn("You get her wrists zip-tied behind her back while she's still catching her breath. She doesn't fight it. She's just picking her moment.")

		saynn("[say=vex]Careful hauling around Syndicate command staff. Command doesn't take kindly to it.[/say]")

		saynn("[say=pc]Neither does AlphaCorp. You're the one in my zip ties.[/say]")

		addButton("Continue", "See what happens next", "drask_arrives")

	if(state == "drask_arrives"):
		addCharacter("drask")
		playAnimation(StageScene.Duo, "stand", {npc="drask"})
		saynn("Drask limps into the room a minute later, one arm braced against the doorframe, and stops when he sees Vex zip-tied on the floor, very much alive.")

		saynn("[say=drask]...She's alive.[/say]")

		saynn("[say=pc]She's alive.[/say]")

		saynn("His hand drifts toward his sidearm before he catches himself.")

		saynn("[say=drask]Same one that hit Kessler's Ridge. I could end this right now.[/say]")

		saynn("[say=pc]You could. Command's going to want her breathing more than you want her dead.[/say]")

		saynn("He stares her down. Vex stares right back, not even flinching.")

		saynn("[say=drask]...Yeah. Doesn't mean I have to like it.[/say]")

		saynn("He lowers his hand and looks away from her.")

		saynn("[say=drask]Get her processed. Two guards on her, no exceptions.[/say]")

		addButton("Continue", "See what happens next", "victory_drask")

	if(state == "victory_drask"):
		removeCharacter("vex")
		saynn("[say=drask]Rook and the two on the flank. They're the ones who paid for this. Not me, not you. Don't let anyone back at the outpost tell it any different.[/say]")

		saynn("He straightens up, wincing, and forces his usual scowl back into place.")

		saynn("[say=drask]That's a real discharge earned right there. I'll get the paperwork moving myself, soon as someone stitches me back to-[/say]")

		addButton("Continue", "Let the moment last", "mirri_crash")

	if(state == "mirri_crash"):

		saynn("A shrieking whine drowns out everything else as an unmarked ship comes in low and hot, trailing smoke, and doesn't so much land as arrive. It clips the wall and slams down right where Drask is standing.")

		saynn("A loud thud is heard where Drask once was.")

		saynn("[say=pc]...Drask?[/say]")

		saynn("Nothing answers.")

		addButton("Continue", "See what happens next", "grabbed")

	if(state == "grabbed"):
		addCharacter("mirri")
		playAnimation(StageScene.Duo, "stand", {npc="mirri"})
		saynn("The ship's hatch drops open and Mirri jumps out already moving, grabbing you by the collar of your fatigues before you can process what you just watched.")

		saynn("[say=mirri]Long time no see honey. Quite the shithole you've got yourself into! Quick, let's bounce![/say]")

		addButton("Continue", "Get out", "escape_gunfire")

	if(state == "escape_gunfire"):
		saynn("The surviving squad doesn't wait for an explanation. As far as they can tell, an unmarked ship just killed their sergeant and is now hauling off one of their own, so they open up on it with everything they've got.")

		saynn("Rifle fire rakes the hull the second the ship lifts off, Mirri swearing the whole way up through the atmosphere.")

		saynn("[say=mirri]Ungrateful sons of- hang on![/say]")

		saynn("The ship lurches hard enough to throw you into a bulkhead, then steadies out as the gunfire falls away below.")

		addButton("Continue", "See what she wants", "leaving")

	if(state == "leaving"):
		saynn("[say=pc]Mirri what the fuck was that? You killed him! His guts were all over the place![/say]")

		saynn("Mirri doesn't even look up from the console.")

		saynn("[say=mirri]Ohh, don't worry. He'll be fine.[/say]")

		saynn("[say=pc]He is very clearly not fine, Mirri.[/say]")

		saynn("[say=mirri]Details. Wasn't the plan, and it's not like I aimed for him. C'mon, AlphaCorp's so rich they probably have a machine that'll put him right together. Don't be so beat, things happen when you're flying a stolen gunship into a warzone at full throttle.[/say]")

		saynn("You look at her with disgust.")
		
		saynn("[say=mirri]Oh come on, you barely knew the guy! You probably killed dozens more here.[/say]")
		
		saynn("[say=pc]Sigh.[/say]")
		
		saynn("[say=pc]And what the hell was your plan anyway, didn't you think in that stupid head of yours to come sooner?[/say]")

		saynn("[say=mirri]Look, you're worth more to me walking around owing me than dead in a discharge ceremony that just got a lot more complicated. Small mercies. Plus, there was traffic.[/say]")

		addButton("Continue", "See where this goes", "smuggling_topic")

	if(state == "smuggling_topic"):
		saynn("[say=pc]How do you even get military-grade guns to a war outpost in the first place?[/say]")

		saynn("Mirri shrugs, finally easing off the throttle now the gunfire's well behind you.")

		saynn("[say=mirri]Same way I get anything. AlphaCorp and Syndicate logistics both leak, if you know which crates to skim before anyone logs the manifest. Rework the serials, run it through people who don't ask questions, and it's just stock by the time it reaches me.[/say]")

		saynn("[say=pc]And the uniforms? The armor?[/say]")

		saynn("[say=mirri]Same pipeline. Surplus, mostly. Gear that got written off as destroyed and somehow wasn't. Conscripts like you never check where your own kit came from. Why would you?[/say]")

		saynn("[say=mirri]Papers say you were never here. Try to keep it that way. And maybe don't mention the part where I ran over your sergeant.[/say]")

		saynn("Before you can even process what just happened, again, you're already on approach to BDCC. Your collar's exactly as tight as it was the day you left.")

		addButton("Leave", "Go home", "go_home")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_scout_wave"):
		processTime(10*60)
		beginWave("scout", 2)
		return

	if(_action == "next_wave"):
		removeCharacter(npcID)
		spawnWaveEnemy()
		return

	if(_action == "start_breach_wave"):
		processTime(10*60)
		beginWave("breach", 2)
		return

	if(_action == "commander_fight"):
		spawnCommander()
		return

	if(_action == "start_defeated_sex"):
		getCharacter(npcID).prepareForSexAsDom()
		runScene("GenericSexScene", [npcID, "pc", SexType.DefaultSex, {SexMod.SubMustGoUnconscious:true, SexMod.DisableDynamicJoiners:true}], "defeated_sex")
		return

	if(_action == "claim_vex"):
		processTime(15*60)
		if(GM.pc.hasPenis()):
			getCharacter("vex").cummedInAnusBy("pc", FluidSource.Penis)
		elif(GM.pc.hasVagina()):
			getCharacter("vex").cummedInMouthBy("pc", FluidSource.Vagina)
		GM.pc.orgasmFrom("vex")
		GM.pc.addSkillExperience(Skill.SexSlave, 30, "claim_vex_sex")

	if(_action == "go_captured"):
		endScene()
		runScene("WarDraftCapturedScene")
		return

	if(_action == "go_home"):
		GM.main.PSH.unlockEndingAddMessage("WarDraft", "mirri_bailout")
		GM.pc.setLocation(GM.pc.getCellLocation())
		GM.main.stopPlayerSlavery()
		endScene()
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "waveFight"):
		processTime(5*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			if(GM.main.PS.dropEnemyWeapon()):
				GM.main.PS.addMessage("You strip a fully-loaded Marauder rifle off the body.")
			waveLeft -= 1
			if(waveLeft <= 0):
				if(wavePhase == "scout"):
					setState("after_scout")
				else:
					setState("after_breach")
			else:
				setState("wave_between")
		else:
			setState("lost_encounter")

	if(_tag == "commanderFight"):
		processTime(5*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			setState("victory")
		else:
			setState("lost_encounter")

	if(_tag == "defeated_sex"):
		var sexResult:SexEngineResult = _result[0]
		var gotUncon:bool = sexResult.isSubUnconscious("pc")

		if(gotUncon):
			setState("encounter_captured")
		else:
			setState("encounter_survived_sex")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID
	data["wavePhase"] = wavePhase
	data["waveLeft"] = waveLeft

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
	wavePhase = SAVE.loadVar(data, "wavePhase", "")
	waveLeft = SAVE.loadVar(data, "waveLeft", 0)
