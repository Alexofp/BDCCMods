extends BodypartHead

func _init():
	visibleName = "Renamon head without shine in eyes"
	id = "renamonheadnoshine"

func getCompatibleSpecies():
	return ["Renamon"]

func getDoll3DScene():
	return "res://Modules/RenamonSpecies/Bodyparts/RenamonHeadNoShine/RenamonHead.tscn"

func getHeadLength():
	return 0.5
