extends CustomBodypartSlot

func _init():
	id = "wings"

func getVisibleName() -> String:
	return getVisibleNameNoCap().capitalize()

func getVisibleNameNoCap() -> String:
	return "wings"

func isEssential() -> bool:
	return false
