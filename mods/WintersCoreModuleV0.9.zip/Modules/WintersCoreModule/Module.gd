extends Module

func _init():
	id = "WintersCoreModule"
	author = "Avery Winters"