extends BodypartBreasts

func getTraits():
	return {
		PartTrait.BreastsFemale: true,
	}

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getVulgarName() -> String:
	return "female breasts"

func getAVulgarName() -> String:
	return getVulgarName()
