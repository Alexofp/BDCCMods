extends PartSkinBase

func _init():
	id = "DPB3S"
	partID = "DPB3"

func getName():
	return "Skin 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed3/Skin/Barbs3_Skin.png"),
	}
