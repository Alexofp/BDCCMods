extends BodypartPenis

func _init():
	visibleName = "barbed dragon penis type 3"
	id = "DPB3"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "ridges", "dragon"])

func getDoll3DScene():
	return "res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed3/Penis/DragonPenisBarbed3.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisRidges: true,
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "rough dragon cock"
