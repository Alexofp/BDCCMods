extends BodypartPenis

func _init():
	visibleName = "barbed dragon penis type 2"
	id = "DPB2"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "bulbous", "dragon"])

func getDoll3DScene():
	return "res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed2/Penis/DragonPenisBarbed2.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "curbed dragon cock"
