extends PartSkinBase

func _init():
	id = "DPB2S"
	partID = "DPB2"

func getName():
	return "Skin 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed2/Skin/Barbs2_Skin.png"),
	}
