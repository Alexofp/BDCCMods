extends BodypartPenis

func _init():
	visibleName = "monstrous barbed dragon penis"
	id = "MBDP1"
	pickedGColor = Color.black
	pickedBColor = Color.cyan

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["bulbous", "alien-like", "dragon", "spiky"])

func getDoll3DScene():
	return "res://Modules/AdditionalDragonPenisPack/DragonPenis_Monstrous/Penis/DragonPenisMonstrous.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisRidges: true,
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "monstrous barbed cock"
