extends PartSkinBase

func _init():
	id = "MBDP1S"
	partID = "MBDP1"

func getName():
	return "Skin 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/AdditionalDragonPenisPack/DragonPenis_Monstrous/Skin/BarbsM_Skin.png"),
	}
