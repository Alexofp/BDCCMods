extends Module

func _init():
	id = "More Dragon Penis"
	author = "Gecked"
	
	bodyparts = [
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed1/DragonPenisBarbed1.gd",
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed2/DragonPenisBarbed2.gd",
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed3/DragonPenisBarbed3.gd",
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Monstrous/DragonPenisMonstrous.gd",
	]
	partSkins = [
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed1/Skin/BDR1_Pattern1.gd",
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed2/Skin/BDR2_Pattern1.gd",
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed3/Skin/BDR3_Pattern1.gd",
		"res://Modules/AdditionalDragonPenisPack/DragonPenis_Monstrous/Skin/MR1_Pattern1.gd",
	]
