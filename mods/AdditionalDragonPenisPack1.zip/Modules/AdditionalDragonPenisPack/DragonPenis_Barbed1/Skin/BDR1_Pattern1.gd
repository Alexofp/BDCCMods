extends PartSkinBase

func _init():
	id = "DPB1S"
	partID = "DPB1"

func getName():
	return "Skin 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed1/Skin/Barbs0_Skin.png"),
	}
