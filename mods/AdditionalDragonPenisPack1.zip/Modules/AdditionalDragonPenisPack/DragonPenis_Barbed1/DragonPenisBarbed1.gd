extends BodypartPenis

func _init():
	visibleName = "barbed dragon penis type 1"
	id = "DPB1"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "dangerously barbed", "scalie"])

func getDoll3DScene():
	return "res://Modules/AdditionalDragonPenisPack/DragonPenis_Barbed1/Penis/DragonPenisBarbed1.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisRidges: true,
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "spiky dragon cock"
