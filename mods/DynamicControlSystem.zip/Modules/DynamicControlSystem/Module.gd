extends Module

const UPDATE_EXECUTOR_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/UpdateExecutor.gd"
)

const DEFAULT_HANDLERS_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/Handlers/DefaultHandlers.gd"
)

const DEFAULT_UPDATE_DEFINITIONS_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/Updates/DefaultUpdateDefinitions.gd"
)

const MODIFIER_REGISTRY_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/ModifierRegistry.gd"
)

const UPDATE_REGISTRY_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/UpdateRegistry.gd"
)

const UPDATE_ACTION_REGISTRY_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/UpdateActionRegistry.gd"
)

const DEFAULT_UPDATE_ACTIONS_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/Updates/DefaultUpdateActions.gd"
)

const BODY_HANDLER_REGISTRY_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/BodyHandlerRegistry.gd"
)

const DCS_BOOTSTRAP_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/DCSBootstrap.gd"
)

var update_executor = null
var body_handler_registry = null
var modifier_registry = null
var update_registry = null
var update_action_registry = null
var loaded_resources = {}
var registered_resources = {}
var registered_files = {}
var registration_log = []

func _init():
    id = "DynamicControlSystemModule"
    author = "Djakise"

    bodyparts = []

    scenes = [
        "res://Modules/DynamicControlSystem/CharacterCreatorSceneDCS.gd"
    ]

    modifier_registry = MODIFIER_REGISTRY_SCRIPT.new()
    body_handler_registry = BODY_HANDLER_REGISTRY_SCRIPT.new()
    update_registry = UPDATE_REGISTRY_SCRIPT.new()
    update_action_registry = UPDATE_ACTION_REGISTRY_SCRIPT.new()

    DCS_BOOTSTRAP_SCRIPT.new().register_defaults(self)

    update_executor = UPDATE_EXECUTOR_SCRIPT.new(self)

    var default_definition = get_update_definition("default")

    print("DCS: Default exists = ", has_update_definition("default"))
    print("DCS: Default ID = ", default_definition.get("id", ""))
    print("DCS: Default handlers = ", default_definition.get("handlers", []))
    print("DCS: Default updates = ", default_definition.get("updates", []))
    print(
    "DCS: updateAppearance registered = ",
    has_update_action("updateAppearance")
    )



func unregister_body_handler(handler) -> bool:
    if body_handler_registry == null:
        return false

    return body_handler_registry.unregister_handler(handler)


func get_body_handlers() -> Array:
    if body_handler_registry == null:
        return []

    return body_handler_registry.get_handlers()


func register_modifier_rule(
    rule,
    source: String = "",
    author: String = ""
) -> bool:
    var rule_id = ""

    if rule != null:
        rule_id = str(rule.get("id"))

    if source.empty():
        source = "Unknown source"

    if author.empty():
        author = "Unspecified"

    log_component_registration(
        "Registration Requested",
        "ModifierRule",
        rule_id,
        source,
        author
    )

    if modifier_registry == null or rule == null:
        log_component_registration(
            "Registration Rejected",
            "ModifierRule",
            rule_id,
            source,
            author
        )
        return false

    if not modifier_registry.register_rule(rule):
        log_component_registration(
            "Registration Rejected",
            "ModifierRule",
            rule_id,
            source,
            author
        )
        return false

    log_component_registration(
        "Registration Successful",
        "ModifierRule",
        rule_id,
        source,
        author
    )

    return true


func unregister_modifier_rule(rule_id: String) -> bool:
    if modifier_registry == null:
        return false

    return modifier_registry.unregister_rule(rule_id)


func get_modifier_rules() -> Array:
    if modifier_registry == null:
        return []

    return modifier_registry.get_rules()


func get_modifier_registry():
    return modifier_registry


func register_update_definition(
    definition_id: String,
    handlers: Array,
    updates: Array,
    source: String = "",
    author: String = ""
) -> bool:
    if source.empty():
        source = "Unknown source"

    if author.empty():
        author = "Unspecified"

    log_component_registration(
        "Registration Requested",
        "UpdateDefinition",
        definition_id,
        source,
        author
    )

    if update_registry == null:
        log_component_registration(
            "Registration Rejected",
            "UpdateDefinition",
            definition_id,
            source,
            author
        )
        return false

    if not update_registry.register_definition(
        definition_id,
        handlers,
        updates
    ):
        log_component_registration(
            "Registration Rejected",
            "UpdateDefinition",
            definition_id,
            source,
            author
        )
        return false

    log_component_registration(
        "Registration Successful",
        "UpdateDefinition",
        definition_id,
        source,
        author
    )

    return true


func unregister_update_definition(definition_id: String) -> bool:
    if update_registry == null:
        return false

    return update_registry.unregister_definition(definition_id)


func get_update_definition(definition_id: String) -> Dictionary:
    if update_registry == null:
        return {}

    return update_registry.get_definition(definition_id)


func has_update_definition(definition_id: String) -> bool:
    if update_registry == null:
        return false

    return update_registry.has_definition(definition_id)


func register_update_action(
    action_id: String,
    action,
    source: String = "",
    author: String = ""
) -> bool:
    if source.empty():
        source = "Unknown source"

    if author.empty():
        author = "Unspecified"

    log_component_registration(
        "Registration Requested",
        "UpdateAction",
        action_id,
        source,
        author
    )

    if update_action_registry == null or action == null:
        log_component_registration(
            "Registration Rejected",
            "UpdateAction",
            action_id,
            source,
            author
        )
        return false

    if not update_action_registry.register_action(action_id, action):
        log_component_registration(
            "Registration Rejected",
            "UpdateAction",
            action_id,
            source,
            author
        )
        return false

    log_component_registration(
        "Registration Successful",
        "UpdateAction",
        action_id,
        source,
        author
    )

    return true


func get_update_action(action_id: String):
    if update_action_registry == null:
        return null

    return update_action_registry.get_action(action_id)


func has_update_action(action_id: String) -> bool:
    if update_action_registry == null:
        return false

    return update_action_registry.has_action(action_id)


func execute_update_definition(definition_id: String, context = {}) -> bool:
    if update_executor == null:
        print("DCS: Update executor is not initialized")
        return false

    return update_executor.execute_definition(
        definition_id,
        context
    )


func register_handler_pack(pack) -> bool:
    var bootstrap = DCS_BOOTSTRAP_SCRIPT.new()
    return bootstrap.register_pack(self, pack)


func register_body_handler(
    handler,
    source: String = "",
    author: String = ""
) -> bool:
    var handler_id = ""

    if handler != null and handler.has_method("get_id"):
        handler_id = str(handler.get_id())

    if source.empty():
        source = "Unknown source"

    if author.empty():
        author = "Unspecified"

    log_component_registration(
        "Registration Requested",
        "BodyHandler",
        handler_id,
        source,
        author
    )

    if body_handler_registry == null or handler == null:
        log_component_registration(
            "Registration Rejected",
            "BodyHandler",
            handler_id,
            source,
            author
        )
        return false

    if handler_id.empty():
        log_component_registration(
            "Registration Rejected",
            "BodyHandler",
            handler_id,
            source,
            author
        )
        return false

    if registered_resources.has(handler_id):
        var existing = registered_resources[handler_id]

        print("DCS: Duplicate resource ID: ", handler_id)
        print(
            "DCS: Existing source: ",
            existing["source"],
            " | Author: ",
            existing["author"]
        )
        print(
            "DCS: Incoming source: ",
            source,
            " | Author: ",
            author
        )

        log_component_registration(
            "Registration Rejected",
            "BodyHandler",
            handler_id,
            source,
            author
        )
        return false

    if not body_handler_registry.register_handler(
        handler,
        source,
        author
    ):
        log_component_registration(
            "Registration Rejected",
            "BodyHandler",
            handler_id,
            source,
            author
        )
        return false

    registered_resources[handler_id] = {
        "resource": handler,
        "type": "BodyHandler",
        "source": source,
        "author": author
    }

    log_component_registration(
        "Registration Successful",
        "BodyHandler",
        handler_id,
        source,
        author
    )

    return true



func load_resource(path: String):
    var resource = load(path)

    if resource == null:
        print("DCS: Resource load failed | ", path)
        return null

    loaded_resources[path] = resource

    return resource


func register_handler_from_path(
    path: String,
    author: String = ""
) -> bool:
    if author.empty():
        author = "Unspecified"

    var script = load_resource(path)

    if script == null:
        log_component_registration(
            "Registration Requested",
            "BodyHandler",
            "",
            path,
            author
        )
        log_component_registration(
            "Registration Rejected",
            "BodyHandler",
            "",
            path,
            author
        )
        return false

    var handler = script.new()

    if handler == null:
        log_component_registration(
            "Registration Requested",
            "BodyHandler",
            "",
            path,
            author
        )
        log_component_registration(
            "Registration Rejected",
            "BodyHandler",
            "",
            path,
            author
        )
        print("DCS: Handler creation failed | ", path)
        return false

    var registered = register_body_handler(
        handler,
        path,
        author
    )

    if registered:
        print("DCS: Handler registered | ", path)
    else:
        print("DCS: Handler registration failed | ", path)

    return registered


func log_file_registration(
    status: String,
    path: String,
    mod_name: String,
    resource_type: String = ""
):
    var date = OS.get_datetime()

    var timestamp = "%04d-%02d-%02d %02d:%02d:%02d" % [
        date["year"],
        date["month"],
        date["day"],
        date["hour"],
        date["minute"],
        date["second"]
    ]

    var entry = {
        "status": status,
        "path": path,
        "mod": mod_name,
        "type": resource_type,
        "timestamp": timestamp
    }

    registration_log.append(entry)

    print(
        "DCS: ",
        status,
        " | Mod: ",
        mod_name,
        " | Path: ",
        path,
        " | Type: ",
        resource_type,
        " | Time: ",
        timestamp
    )


func log_component_registration(
    status: String,
    component_type: String,
    component_id: String,
    source: String,
    mod_name: String
):
    var date = OS.get_datetime()

    var timestamp = "%04d-%02d-%02d %02d:%02d:%02d" % [
        date["year"],
        date["month"],
        date["day"],
        date["hour"],
        date["minute"],
        date["second"]
    ]

    var entry = {
        "status": status,
        "component": component_type,
        "id": component_id,
        "source": source,
        "mod": mod_name,
        "timestamp": timestamp
    }

    registration_log.append(entry)

    print(
        "DCS: Component ",
        status,
        " | Type: ",
        component_type,
        " | ID: ",
        component_id,
        " | Source: ",
        source,
        " | Mod: ",
        mod_name,
        " | Time: ",
        timestamp
    )


func get_registration_log() -> Array:
    return registration_log.duplicate(true)


func register_file(
    path: String,
    mod_name: String = ""
) -> bool:

    if mod_name.empty():
        mod_name = "Unspecified"

    log_file_registration(
        "Registration Requested",
        path,
        mod_name
    )

    if registered_files.has(path):
        log_file_registration(
            "Registration Rejected",
            path,
            mod_name
        )
        return false

    var resource = load_resource(path)

    if resource == null:
        log_file_registration(
            "Registration Failed",
            path,
            mod_name
        )
        return false

    var resource_type = resource.get_class()

    registered_files[path] = {
        "resource": resource,
        "type": resource_type,
        "mod": mod_name,
        "path": path
    }

    log_file_registration(
        "Registration Successful",
        path,
        mod_name,
        resource_type
    )

    return true


func get_registered_files() -> Dictionary:
    return registered_files.duplicate(true)