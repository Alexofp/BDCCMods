extends HSlider

func _ready():
    print("DCS TEST: Slider scene loaded = ", self != null)
    print("DCS TEST: Slider width = ", rect_size.x)