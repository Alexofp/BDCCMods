extends Reference


var definitions = {}


func register_definition(
    definition_id: String,
    handlers: Array,
    updates: Array
) -> bool:
    if definition_id.empty():
        print("DCS: Cannot register update definition: empty ID")
        return false

    if definitions.has(definition_id):
        print("DCS: Update definition ID already exists: ", definition_id)
        return false

    definitions[definition_id] = {
        "id": definition_id,
        "handlers": handlers.duplicate(),
        "updates": updates.duplicate()
    }

    return true


func unregister_definition(definition_id: String) -> bool:
    if definition_id.empty():
        return false

    if definition_id == "default":
        print("DCS: Cannot unregister the default definition")
        return false

    if not definitions.has(definition_id):
        return false

    definitions.erase(definition_id)
    return true


func get_definition(definition_id: String) -> Dictionary:
    if not definitions.has(definition_id):
        return {}

    return definitions[definition_id].duplicate(true)


func has_definition(definition_id: String) -> bool:
    return definitions.has(definition_id)
