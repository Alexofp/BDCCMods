extends Reference


var dcs_module = null


func _init(module = null):
    dcs_module = module


func execute_definition(definition_id: String, context = {}) -> bool:
    if dcs_module == null:
        print("DCS: Cannot execute updates: module is null")
        return false

    var definition = dcs_module.get_update_definition(definition_id)

    if definition.empty():
        print("DCS: Update definition not found: ", definition_id)
        return false

    var update_ids = definition.get("updates", [])

    if update_ids.empty():
        return true

    var all_succeeded = true

    for update_id in update_ids:
        var action = dcs_module.get_update_action(str(update_id))

        if action == null:
            print("DCS: Update action not found: ", update_id)
            all_succeeded = false
            continue

        if not action.has_method("execute"):
            print("DCS: Update action has no execute method: ", update_id)
            all_succeeded = false
            continue

        var success = action.execute(context)

        if not success:
            print("DCS: Update action failed: ", update_id)
            all_succeeded = false

    return all_succeeded
