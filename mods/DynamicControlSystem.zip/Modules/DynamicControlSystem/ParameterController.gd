extends Reference


func get_value(bodypart, config: Dictionary, handler = null):
    if bodypart == null:
        return null

    var key = str(config.get("key", ""))

    if key == "":
        return null

    var getter = str(config.get("handler_getter", ""))

    if getter != "" and handler != null:
        if handler.has_method(getter):
            return handler.call(getter, bodypart, key)
        return null

    var storage = str(config.get("storage", "property"))

    if storage == "override":
        var meta_key = _get_meta_key(key)

        if bodypart.has_meta(meta_key):
            return bodypart.get_meta(meta_key)

    var property_name = str(config.get("property", key))

    if property_name == "":
        return null

    return bodypart.get(property_name)


func set_value(bodypart, config: Dictionary, value, handler = null) -> bool:
    if bodypart == null:
        return false

    var key = str(config.get("key", ""))

    if key == "":
        return false

    var value_type = str(config.get("type", ""))

    match value_type:
        "int":
            value = int(round(float(value)))
        "float":
            value = float(value)
        "bool":
            value = bool(value)
        "string":
            value = str(value)

    var setter = str(config.get("handler_setter", ""))

    if setter != "" and handler != null:
        if not handler.has_method(setter):
            return false

        handler.call(setter, bodypart, key, value)
        return true

    var storage = str(config.get("storage", "property"))
    var property_name = str(config.get("property", key))

    if storage == "override":
        bodypart.set_meta(_get_meta_key(key), value)

        var apply_property = str(config.get("apply_property", ""))

        if apply_property != "":
            bodypart.set(apply_property, value)

        return true

    if property_name == "":
        return false

    bodypart.set(property_name, value)
    return true


func _get_meta_key(key: String) -> String:
    return "dcs_parameter_" + key
