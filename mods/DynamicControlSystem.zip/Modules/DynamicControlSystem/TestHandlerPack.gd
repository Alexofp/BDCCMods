extends "res://Modules/DynamicControlSystem/HandlerPack.gd"

const MODIFIER_RULE_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/ModifierRule.gd"
)

const TEST_UPDATE_ACTION_SCRIPT = preload(
    "res://Modules/DCSExtensionTest/TestUpdateAction.gd"
)

func _init():
    author = "DCS Test A"

func get_handlers() -> Array:
    return [
        preload(
            "res://Modules/DynamicControlSystem/TestConflictHandler.gd"
        ).new()
    ]


func get_update_definitions() -> Array:
    return [
        {
            "id": "test",
            "handlers": [
                "PenisHandler"
            ],
            "updates": [
                "updateAppearance"
            ]
        }
    ]


func get_update_actions() -> Array:
    return [
        {
            "id": "testUpdate",
            "action": TEST_UPDATE_ACTION_SCRIPT.new()
        }
    ]


func get_modifier_rules() -> Array:
    var test_rule = MODIFIER_RULE_SCRIPT.new()
    test_rule.id = "dcs_extension_test_add"
    test_rule.target_property = "test_property"
    test_rule.operation = "add"
    test_rule.value = 10.0

    return [test_rule]
