extends Reference
class_name DCSParameterConfig

var key: String = ""
var label: String = ""
var min_value: float = 0.0
var max_value: float = 100.0
var step: float = 1.0

var value_type: String = "float"
var storage: String = "property"
var property: String = ""
var apply_property: String = ""

# Необязательные методы специализированного обработчика.
var handler_getter: String = ""
var handler_setter: String = ""

var value_names: Dictionary = {}
var descriptions: Dictionary = {}


func _init(
    p_key: String = "",
    p_label: String = "",
    p_min: float = 0.0,
    p_max: float = 100.0,
    p_step: float = 1.0
):
    key = p_key
    label = p_label
    min_value = p_min
    max_value = p_max
    step = p_step
    property = p_key


func to_dictionary() -> Dictionary:
    return {
        "key": key,
        "label": label,
        "min": min_value,
        "max": max_value,
        "step": step,
        "type": value_type,
        "storage": storage,
        "property": property,
        "apply_property": apply_property,
        "handler_getter": handler_getter,
        "handler_setter": handler_setter,
        "value_names": value_names,
        "descriptions": descriptions
    }
