extends Reference


var id: String = ""
var target_property: String = ""
var operation: String = "add"
var value: float = 0.0
var enabled: bool = true
var priority: int = 0


func is_active(_target) -> bool:
    return enabled


func apply(current_value: float, target) -> float:
    if not is_active(target):
        return current_value

    match operation:
        "add":
            return current_value + value

        "multiply":
            return current_value * value

        "override":
            return value

    return current_value
