extends VBoxContainer

const PARAMETER_CONTROLLER_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/ParameterController.gd"
)

var parameter_controller = PARAMETER_CONTROLLER_SCRIPT.new()

var bodypart = null
var active_handler = null
var definition_id = "default"
var parameter_container: VBoxContainer
var sliders = {}
var value_labels = {}
var description_labels = {}
var parameter_configs = {}


func _ready():
    size_flags_horizontal = Control.SIZE_EXPAND_FILL
    parameter_container = self

    var text_output = get_parent().get_node_or_null("TextOutput")

    if text_output != null:
        text_output.visible = false

    _refresh_controls()


func _exit_tree():
    var parent = get_parent()

    if parent != null:
        var text_output = parent.get_node_or_null("TextOutput")

        if text_output != null:
            text_output.visible = true


func set_definition(new_definition_id: String, target = null) -> bool:
    var dcs_module = GlobalRegistry.getModule(
        "DynamicControlSystemModule"
    )

    if dcs_module == null:
        return false

    if not dcs_module.has_update_definition(new_definition_id):
        print("DCS: Definition not found: ", new_definition_id)
        return false

    definition_id = new_definition_id

    if target != null:
        setBodypart(target)
    elif bodypart != null:
        setBodypart(bodypart)

    return true


func setBodypart(new_bodypart):
    bodypart = new_bodypart
    active_handler = null

    var dcs_module = GlobalRegistry.getModule(
        "DynamicControlSystemModule"
    )

    if dcs_module == null:
        print("DCS: Module not found")
        _refresh_controls()
        return
    
    var definition = dcs_module.get_update_definition(
    definition_id
    )

    if definition.empty():
        print("DCS: Definition not found: ", definition_id)
        _refresh_controls()
        return

    var allowed_handlers = definition.get("handlers", [])
    var handlers = dcs_module.get_body_handlers()

    for handler in handlers:
        if not handler.has_method("get_id"):
            print("DCS: Handler has no ID method: ", handler)
            continue

        var handler_id = handler.get_id()

        if not allowed_handlers.has(handler_id):
            continue

        if not handler.has_method("can_handle"):
            continue

        if handler.can_handle(bodypart):
            active_handler = handler
            print("DCS: Selected handler: ", handler_id)
            break

    if active_handler == null:
        print("DCS: No suitable handler found in definition: ", definition_id)

    _refresh_controls()



func _refresh_controls():
    if not is_inside_tree():
        return

    for child in parameter_container.get_children():
        parameter_container.remove_child(child)
        child.queue_free()

    sliders.clear()
    value_labels.clear()
    description_labels.clear()
    parameter_configs.clear()

    if bodypart == null or active_handler == null:
        return

    var parameters = active_handler.get_parameters(bodypart)

    for config in parameters:
        _add_parameter_control(config)


func _add_parameter_control(config: Dictionary):
    var key = str(config["key"])
    parameter_configs[key] = config

    var value_row = HBoxContainer.new()
    parameter_container.add_child(value_row)

    var name_label = Label.new()
    name_label.text = str(config["label"]) + ":"
    value_row.add_child(name_label)

    var value_label = Label.new()
    value_row.add_child(value_label)
    value_labels[key] = value_label

    var slider = HSlider.new()
    slider.min_value = float(config["min"])
    slider.max_value = float(config["max"])
    slider.step = float(config["step"])
    slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    parameter_container.add_child(slider)
    sliders[key] = slider

    var description_label = Label.new()
    description_label.autowrap = true
    parameter_container.add_child(description_label)
    description_labels[key] = description_label

    slider.connect(
        "value_changed",
        self,
        "_on_parameter_changed",
        [key]
    )

    var current_value = parameter_controller.get_value(
        bodypart,
        config,
        active_handler
    )

    slider.set_block_signals(true)
    slider.value = float(current_value)
    slider.set_block_signals(false)

    _update_parameter_text(key, current_value)



func _on_parameter_changed(value, key: String):
    if bodypart == null or active_handler == null:
        return

    var config = parameter_configs[key]

    if str(config["type"]) == "int":
        value = int(round(value))

    var success = parameter_controller.set_value(
        bodypart,
        config,
        value,
        active_handler
    )

    if not success:
        return

    _update_parameter_text(key, value)

    var dcs_module = GlobalRegistry.getModule(
        "DynamicControlSystemModule"
    )

    if dcs_module == null:
        print("DCS: Cannot update: module not found")
        return


    var update_success = dcs_module.execute_update_definition(
        definition_id,
        {"target": bodypart}
    )

    if not update_success:
        print("DCS: Failed to execute update definition: ", definition_id)


#    print(
#        "DCS: Definition = ",
#        definition_id,
#        ", update result = ",
#        update_success
#    )


#    if GM.pc != null:
#        GM.pc.updateAppearance()



func _update_parameter_text(key: String, value):
    var config = parameter_configs[key]
    var display_value = str(value)

    if active_handler != null \
    and active_handler.has_method("format_value"):

        var custom_value = active_handler.format_value(value)

        if custom_value != null:
            display_value = str(custom_value)

        else:
            display_value = _get_default_display_value(
                key,
                value,
                config
            )

    else:
        display_value = _get_default_display_value(
            key,
            value,
            config
        )

    value_labels[key].text = display_value

    var description = ""

    if config.has("descriptions"):
        var descriptions = config["descriptions"]
        var integer_value = int(round(float(value)))

        if descriptions.has(integer_value):
            description = str(descriptions[integer_value])

    description_labels[key].text = description


func _get_default_display_value(
    key: String,
    value,
    config: Dictionary
) -> String:
    var display_value = str(value)

    if key == "lengthCM":
        display_value = Util.cmToString(float(value))

    elif key == "ballsScale":
        display_value = str(
            Util.roundF(float(value) * 100.0, 1)
        ) + "%"

    elif key == "thickness":
        display_value = str(
            Util.roundF(float(value), 1)
        ) + "%"

    elif config.has("value_names"):
        var value_names = config["value_names"]
        var integer_value = int(round(float(value)))

        if value_names.has(integer_value):
            display_value = str(value_names[integer_value])

            if key == "size":
                var bone_scale = BreastsSize.breastSizeToBoneScale(
                    integer_value
                )
                var percentage = Util.roundF(
                    bone_scale * 100.0,
                    1
                )

                display_value += " (" + str(percentage) + "%)"

    elif float(config["step"]) < 1.0:
        display_value = str(Util.roundF(float(value), 2))

    return display_value
