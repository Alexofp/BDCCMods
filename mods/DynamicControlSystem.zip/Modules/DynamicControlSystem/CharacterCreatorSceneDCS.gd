extends "res://Scenes/CharacterCreatorScene.gd"

const EDITOR_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/DynamicControlEditor.gd"
)

var dcs_current_bodypart = null
var dcs_thickness_menu_active = false


func _run():
    ._run()

    if state == "bodypartAttributes":
        call_deferred("_openBodypartEditor")

    elif state == "bodyAttributeMenu":
        if bodyPickedAttribID == "thickness":
            dcs_thickness_menu_active = true
            call_deferred("_openButtocksEditor")
        else:
            dcs_thickness_menu_active = false


func _react(_action: String, _args):
    if _action == "pickbodypart":
        ._react(_action, _args)
        return

    ._react(_action, _args)


func _openBodypartEditor():
    if state != "bodypartAttributes":
        return

    var bodypart = GM.pc.getBodypart(pickingBodypartType)

    if bodypart == null:
        return

    dcs_current_bodypart = bodypart

    var editor = GM.ui.getCustomControl("dcs_editor")

    if editor == null:
        editor = EDITOR_SCRIPT.new()
        GM.ui.addCustomControl("dcs_editor", editor)

    editor.visible = true
    editor.set_definition("default", bodypart)



func _openButtocksEditor():
    if state != "bodyAttributeMenu":
        return

    if bodyPickedAttribID != "thickness":
        return

    if GM.pc == null:
        print("DCS: Player character is null")
        return

    print("DCS: Opening Thickness editor")

    var editor = GM.ui.getCustomControl("dcs_editor")

    if editor == null:
        editor = EDITOR_SCRIPT.new()
        GM.ui.addCustomControl("dcs_editor", editor)

    editor.visible = true
    editor.set_definition("default", GM.pc)

