extends "res://Modules/DynamicControlSystem/Handlers/BodyHandler.gd"


func get_id() -> String:
    return "TestConflictHandler"


func can_handle(_bodypart) -> bool:
    return false


func get_title() -> String:
    return "Test conflict handler"


func get_parameters(_bodypart) -> Array:
    return []