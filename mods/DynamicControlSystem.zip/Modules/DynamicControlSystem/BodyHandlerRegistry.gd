extends Reference

var handlers = []
var handler_sources = {}


func register_handler(
    handler,
    source: String = "",
    author: String = ""
) -> bool:
    if handler == null:
        return false

    if not handler.has_method("can_handle"):
        return false

    if not handler.has_method("get_parameters"):
        return false

    if not handler.has_method("get_id"):
        return false

    var handler_id = handler.get_id()

    if source.empty():
        source = "Unknown source"

    if author.empty():
        author = "Unknown author"

    for registered_handler in handlers:
        if registered_handler.get_id() == handler_id:
            var existing_source = handler_sources.get(
                handler_id,
                {
                    "source": "Unknown source",
                    "author": "Unknown author"
                }
            )

            print("DCS: Duplicate handler ID: ", handler_id)
            print(
                "DCS: Existing source: ",
                existing_source["source"],
                " | Author: ",
                existing_source["author"]
            )
            print(
                "DCS: Incoming source: ",
                source,
                " | Author: ",
                author
            )
            return false

    handlers.append(handler)
    handler_sources[handler_id] = {
        "source": source,
        "author": author
    }

    return true


func unregister_handler(handler) -> bool:
    var index = handlers.find(handler)

    if index < 0:
        return false

    var handler_id = handler.get_id()
    handlers.remove(index)
    handler_sources.erase(handler_id)

    return true


func get_handlers() -> Array:
    return handlers.duplicate()
