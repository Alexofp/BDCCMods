extends Reference


func can_handle(_bodypart) -> bool:
    return false


func get_title() -> String:
    return "Body parameters"


func get_parameters(_bodypart) -> Array:
    return []


func get_value(bodypart, key: String):
    if bodypart == null:
        return null

    return bodypart.get(key)


func set_value(bodypart, key: String, value) -> void:
    if bodypart == null:
        return

    bodypart.set(key, value)