extends "res://Modules/DynamicControlSystem/Handlers/BodyHandler.gd"

const PARAMETER_CONFIG = preload(
    "res://Modules/DynamicControlSystem/ParameterConfig.gd"
)


func get_id() -> String:
    return "ThicknessHandler"


func can_handle(bodypart) -> bool:
    return bodypart != null \
        and bodypart.has_method("getThickness") \
        and bodypart.has_method("setThickness")


func get_title() -> String:
    return "Thickness"


func get_parameters(_bodypart) -> Array:
    var thickness = PARAMETER_CONFIG.new(
        "thickness",
        "Thickness",
        0.0,
        200.0,
        0.1
    )

    thickness.value_type = "int"
    thickness.handler_getter = "get_value"
    thickness.handler_setter = "set_value"

    return [
        thickness.to_dictionary()
    ]


func get_value(bodypart, _key: String):
    if bodypart == null:
        return null

    return bodypart.getThickness()


func set_value(bodypart, _key: String, value) -> void:
    if bodypart == null:
        return

    bodypart.setThickness(int(value))