extends "res://Modules/DynamicControlSystem/Handlers/BodyHandler.gd"

const PARAMETER_CONFIG = preload(
    "res://Modules/DynamicControlSystem/ParameterConfig.gd"
)


func get_id() -> String:
    return "BreastHandler"


func can_handle(bodypart) -> bool:
    return bodypart != null \
        and bodypart.has_method("getBreastsAdjustScale") \
        and bodypart.has_method("getSize")


func get_title() -> String:
    return "Breast parameters"


func get_parameters(_bodypart) -> Array:
    var size = PARAMETER_CONFIG.new(
        "size",
        "Breast size",
        -1.0,
        15.0,
        0.01
    )

    size.value_type = "int"
    size.value_names = {
        -1: "Forever flat",
        0: "Flat",
        1: "A-cup",
        2: "B-cup",
        3: "C-cup",
        4: "D-cup",
        5: "DD-cup",
        6: "DDD-cup",
        7: "G-cup",
        8: "H-cup",
        9: "I-cup",
        10: "J-cup",
        11: "K-cup",
        12: "L-cup",
        13: "M-cup",
        14: "N-cup",
        15: "O-cup"
    }

    size.descriptions = {
        -1: "Permanent state: breasts will not grow or produce milk.",
        0: "Flat breasts."
    }

    return [
        size.to_dictionary()
    ]


func get_value(bodypart, key: String):
    return bodypart.get(key)


func set_value(bodypart, key: String, value) -> void:
    bodypart.set(key, int(value))