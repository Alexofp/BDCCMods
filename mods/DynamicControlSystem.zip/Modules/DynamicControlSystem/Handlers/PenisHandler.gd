extends "res://Modules/DynamicControlSystem/Handlers/BodyHandler.gd"

const PARAMETER_CONFIG = preload(
    "res://Modules/DynamicControlSystem/ParameterConfig.gd"
)


func get_id() -> String:
    return "PenisHandler"


func can_handle(bodypart) -> bool:
    return bodypart != null \
        and bodypart.has_method("getPenisScale") \
        and bodypart.has_method("getBallsScale")


func get_title() -> String:
    return "Penis parameters"


func get_parameters(_bodypart) -> Array:
    var length = PARAMETER_CONFIG.new(
        "lengthCM",
        "Length (cm)",
        4.0,
        50.0,
        0.01
    )
    length.value_type = "float"

    var balls = PARAMETER_CONFIG.new(
        "ballsScale",
        "Balls scale",
        0.0,
        5.0,
        0.01
    )
    balls.value_type = "float"

    return [
        length.to_dictionary(),
        balls.to_dictionary()
    ]


func get_value(bodypart, key: String):
    return bodypart.get(key)


func set_value(bodypart, key: String, value) -> void:
    bodypart.set(key, value)