extends Reference

const BOOTSTRAP_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/DCSBootstrap.gd"
)


func get_handlers() -> Array:
    return BOOTSTRAP_SCRIPT.new().load_handlers_from_folder(
        "res://Modules/DynamicControlSystem/Handlers"
    )