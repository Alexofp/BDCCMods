extends "res://Modules/DynamicControlSystem/HandlerPack.gd"

const DEFAULT_DEFINITIONS_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/Updates/DefaultUpdateDefinitions.gd"
)

const DEFAULT_ACTIONS_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/Updates/DefaultUpdateActions.gd"
)


func get_handlers() -> Array:
    return []


func get_update_definitions() -> Array:
    return DEFAULT_DEFINITIONS_SCRIPT.new().get_definitions()


func get_update_actions() -> Array:
    return DEFAULT_ACTIONS_SCRIPT.new().get_actions()