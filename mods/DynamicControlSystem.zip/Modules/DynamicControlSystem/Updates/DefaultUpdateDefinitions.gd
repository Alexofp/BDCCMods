extends Reference


func get_definitions() -> Array:
    return [
        {
            "id": "default",
            "handlers": [
                "PenisHandler",
                "BreastHandler",
                "ThicknessHandler",
                "TailHandler"
            ],
            "updates": [
                "updateAppearance"
            ]
        }
    ]
