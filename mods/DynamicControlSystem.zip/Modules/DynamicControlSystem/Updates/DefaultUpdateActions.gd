extends Reference

const UPDATE_APPEARANCE_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/Updates/UpdateAppearance.gd"
)


func get_actions() -> Array:
    return [
        {
            "id": "updateAppearance",
            "action": UPDATE_APPEARANCE_SCRIPT.new()
        }
    ]
