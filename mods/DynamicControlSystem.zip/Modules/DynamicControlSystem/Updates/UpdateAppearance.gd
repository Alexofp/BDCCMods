extends Reference


func execute(context = {}) -> bool:
    var target = context.get("target", null)

    if target == null:
        target = GM.pc

    if target == null:
        print("DCS: Update target is null")
        return false

    if target.has_method("updateAppearance"):
        target.updateAppearance()
        return true

    print("DCS: Target has no updateAppearance method")
    return false
