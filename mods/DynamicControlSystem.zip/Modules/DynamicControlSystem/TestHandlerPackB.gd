extends "res://Modules/DynamicControlSystem/HandlerPack.gd"


func _init():
    author = "DCS Test B"

func get_handlers() -> Array:
    return [
        preload(
            "res://Modules/DynamicControlSystem/TestConflictHandler.gd"
        ).new()
    ]


func get_update_definitions() -> Array:
    return [
        {
            "id": "test_b",
            "handlers": [
                "PenisHandler"
            ],
            "updates": [
                "updateAppearance"
            ]
        }
    ]


func get_update_actions() -> Array:
    return []