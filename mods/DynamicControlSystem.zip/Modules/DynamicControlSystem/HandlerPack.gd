extends Reference

var is_dcs_handler_pack = true
var author = ""


func get_handlers() -> Array:
    return []


func get_update_definitions() -> Array:
    return []


func get_update_actions() -> Array:
    return []

func get_modifier_rules() -> Array:
    return []