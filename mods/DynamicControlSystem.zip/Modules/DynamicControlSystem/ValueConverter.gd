extends Reference
class_name DCSValueConverter


static func convert_value(number, precision = 0, show_percent = 0):
    var multiplier = pow(10.0, precision)
    var converted_number = number

    if show_percent == 0:
        converted_number = number * 100.0

    converted_number = round(
        converted_number * multiplier
    ) / multiplier

    var result = str(converted_number)

    if show_percent == 0:
        result += "%"

    return result


static func format_attribute(attribute_text, formatted_value):
    return str(attribute_text) + ": " + str(formatted_value)
