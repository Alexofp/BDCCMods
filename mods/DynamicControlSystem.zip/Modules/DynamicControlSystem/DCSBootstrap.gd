
extends Reference

const DEFAULT_PACK_SCRIPT = preload(
    "res://Modules/DynamicControlSystem/DefaultDCSHandlerPack.gd"
)

const HANDLERS_FOLDER = "res://Modules/DynamicControlSystem/Handlers"


func register_defaults(dcs_module) -> void:
    var default_pack = DEFAULT_PACK_SCRIPT.new()

    register_pack(
        dcs_module,
        default_pack,
        "res://Modules/DynamicControlSystem/DefaultDCSHandlerPack.gd"
    )

    var handlers = load_handlers_from_folder(HANDLERS_FOLDER)

    for handler_data in handlers:
        var handler = handler_data["handler"]
        var source = handler_data["source"]

        if not dcs_module.register_body_handler(
            handler,
            source,
            "DCS"
        ):
            print(
                "DCS: Failed to register discovered handler: ",
                handler.get_id()
            )
        else:
            print(
                "DCS: Auto-registered handler: ",
                handler.get_id()
            )


func load_handlers_from_folder(folder: String) -> Array:
    var result = []
    var dir = Directory.new()

    if dir.open(folder) != OK:
        print("DCS: Cannot open handlers folder: ", folder)
        return result

    dir.list_dir_begin(true)
    var file_name = dir.get_next()

    while file_name != "":
        if not dir.current_is_dir() \
        and file_name.ends_with("Handler.gd") \
        and file_name != "BodyHandler.gd":
            var path = folder.plus_file(file_name)
            var script = load(path)

            if script != null:
                var handler = script.new()

                if handler.has_method("get_id") \
                and handler.has_method("can_handle") \
                and handler.has_method("get_parameters"):
                    result.append({
                        "handler": handler,
                        "source": path
                    })
                else:
                    print("DCS: Skipping non-handler script: ", path)

        file_name = dir.get_next()

    dir.list_dir_end()
    return result


func register_handler_packs_from_folder(
    dcs_module,
    folder: String
) -> bool:
    var dir = Directory.new()

    if dir.open(folder) != OK:
        print("DCS: Cannot open handler packs folder: ", folder)
        return false

    var all_succeeded = true

    dir.list_dir_begin(true)
    var file_name = dir.get_next()

    while file_name != "":
        if not dir.current_is_dir() and file_name.ends_with(".gd"):
            var path = folder.plus_file(file_name)
            var script = load(path)

            if script == null:
                print("DCS: Cannot load script: ", path)
                all_succeeded = false
            else:
                var instance = script.new()

                if instance != null \
                and instance.get("is_dcs_handler_pack") == true:
                    if not register_pack(
                        dcs_module,
                        instance,
                        path
                    ):
                        print("DCS: Failed to register pack: ", path)
                        all_succeeded = false

        file_name = dir.get_next()

    dir.list_dir_end()
    return all_succeeded


func register_pack(
    dcs_module,
    pack,
    source: String = ""
) -> bool:
    if dcs_module == null or pack == null:
        return false

    if not pack.has_method("get_handlers"):
        return false

    if not pack.has_method("get_update_definitions"):
        return false

    if not pack.has_method("get_update_actions"):
        return false
    
    if not pack.has_method("get_modifier_rules"):
        return false

    var author = pack.get("author")

    if source.empty():
        source = pack.get_script().resource_path \
            if pack.get_script() != null \
            else "Unknown source"

    if author == null or str(author).empty():
        author = "Unspecified"

    print(
        "DCS: Registering pack | Source: ",
        source,
        " | Author: ",
        author
    )

    var all_succeeded = true

    var handlers = pack.get_handlers()
    var definitions = pack.get_update_definitions()
    var actions = pack.get_update_actions()
    var modifier_rules = pack.get_modifier_rules()

    if typeof(handlers) != TYPE_ARRAY:
        return false

    if typeof(definitions) != TYPE_ARRAY:
        return false

    if typeof(actions) != TYPE_ARRAY:
        return false

    if typeof(modifier_rules) != TYPE_ARRAY:
        return false

    for handler in handlers:
        if not dcs_module.register_body_handler(
            handler,
            source,
            str(author)
        ):
            print(
                "DCS: Failed to register handler | Pack: ",
                source,
                " | Author: ",
                author
            )
            all_succeeded = false

    for definition in definitions:
        if typeof(definition) != TYPE_DICTIONARY:
            _log_rejected_component(
                dcs_module,
                "UpdateDefinition",
                "",
                source,
                str(author)
            )
            print("DCS: Invalid update definition | Pack: ", source)
            all_succeeded = false
            continue

        if not definition.has("id") \
        or not definition.has("handlers") \
        or not definition.has("updates"):
            _log_rejected_component(
                dcs_module,
                "UpdateDefinition",
                str(definition.get("id", "")),
                source,
                str(author)
            )
            print("DCS: Invalid update definition fields | Pack: ", source)
            all_succeeded = false
            continue

        if typeof(definition["handlers"]) != TYPE_ARRAY \
        or typeof(definition["updates"]) != TYPE_ARRAY:
            _log_rejected_component(
                dcs_module,
                "UpdateDefinition",
                str(definition["id"]),
                source,
                str(author)
            )
            print(
                "DCS: Invalid update definition arrays: ",
                definition["id"],
                " | Pack: ",
                source
            )
            all_succeeded = false
            continue

        if not dcs_module.register_update_definition(
            str(definition["id"]),
            definition["handlers"],
            definition["updates"],
            source,
            str(author)
        ):
            print(
                "DCS: Failed to register definition: ",
                definition["id"],
                " | Pack: ",
                source,
                " | Author: ",
                author
            )
            all_succeeded = false

    for action_data in actions:
        if typeof(action_data) != TYPE_DICTIONARY:
            _log_rejected_component(
                dcs_module,
                "UpdateAction",
                "",
                source,
                str(author)
            )
            print("DCS: Invalid update action | Pack: ", source)
            all_succeeded = false
            continue

        if not action_data.has("id") or not action_data.has("action"):
            _log_rejected_component(
                dcs_module,
                "UpdateAction",
                str(action_data.get("id", "")),
                source,
                str(author)
            )
            print("DCS: Invalid update action fields | Pack: ", source)
            all_succeeded = false
            continue

        if not dcs_module.register_update_action(
            str(action_data["id"]),
            action_data["action"],
            source,
            str(author)
        ):
            print(
                "DCS: Failed to register action: ",
                action_data["id"],
                " | Pack: ",
                source,
                " | Author: ",
                author
            )
            all_succeeded = false

    for rule in modifier_rules:
        if not dcs_module.register_modifier_rule(
            rule,
            source,
            str(author)
        ):
            print(
                "DCS: Failed to register modifier rule | Pack: ",
                source,
                " | Author: ",
                author
            )
            all_succeeded = false

    return all_succeeded

func _log_rejected_component(
    dcs_module,
    component_type: String,
    component_id: String,
    source: String,
    author: String
) -> void:
    dcs_module.log_component_registration(
        "Registration Requested",
        component_type,
        component_id,
        source,
        author
    )

    dcs_module.log_component_registration(
        "Registration Rejected",
        component_type,
        component_id,
        source,
        author
    )