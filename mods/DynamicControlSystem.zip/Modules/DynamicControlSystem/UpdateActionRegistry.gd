extends Reference


var actions = {}


func register_action(action_id: String, action) -> bool:
    if action_id.empty():
        print("DCS: Cannot register update action: empty ID")
        return false

    if actions.has(action_id):
        print("DCS: Update action ID already exists: ", action_id)
        return false

    if action == null or not action.has_method("execute"):
        print("DCS: Invalid update action: ", action_id)
        return false

    actions[action_id] = action
    return true


func unregister_action(action_id: String) -> bool:
    if action_id.empty() or not actions.has(action_id):
        return false

    actions.erase(action_id)
    return true


func get_action(action_id: String):
    if not actions.has(action_id):
        return null

    return actions[action_id]


func has_action(action_id: String) -> bool:
    return actions.has(action_id)
