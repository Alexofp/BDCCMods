extends Reference


var rules = []



func register_rule(rule) -> bool:
    if rule == null:
        return false

    if not rule.has_method("is_active"):
        return false

    if not rule.has_method("apply"):
        return false

    var rule_id = str(rule.get("id"))
    var property_name = str(rule.get("target_property"))

    if rule_id.empty():
        return false

    if property_name.empty():
        return false

    for registered_rule in rules:
        if str(registered_rule.get("id")) == rule_id:
            return false

    rules.append(rule)
    return true



func unregister_rule(rule_id: String) -> bool:
    for i in range(rules.size()):
        if rules[i].id == rule_id:
            rules.remove(i)
            return true

    return false


func get_rules() -> Array:
    return rules.duplicate()


func get_rules_for_property(property_name: String) -> Array:
    var result = []

    for rule in rules:
        if rule.target_property == property_name:
            result.append(rule)

    return result



func apply_modifiers(
    property_name: String,
    current_value: float,
    target
) -> float:
    var result = current_value
    var matching_rules = get_rules_for_property(property_name)

    # Сортируем правила по приоритету: от меньшего к большему.
    matching_rules.sort_custom(self, "_sort_rules_by_priority")

    for rule in matching_rules:
        result = rule.apply(result, target)

    return result


func _sort_rules_by_priority(a, b) -> bool:
    return int(a.get("priority")) < int(b.get("priority"))

