extends EventBase

func _init():
	id = "PortalExtLewdsEvent"

func registerTriggers(es):
	es.addTrigger(self, "PortalExtEvent")
	es.addTrigger(self, "PortalExtSleepingEvent")
	es.addTrigger(self, "PortalExtShowerEvent")
	

func react(_triggerID, _args):
	
	if(_triggerID == "PortalExtEvent"):
		runScene("PortalExtLewdsScene")
		
		return true
		
	if(_triggerID == "PortalExtSleepingEvent"):
		runScene("PortalExtSleepingLewdScene")
		
		return true
		
	if(_triggerID == "PortalExtShowerEvent"):
		runScene("PortalExtShowerLewdScene")
		
		return true
	
func getPriority():
	return 10
