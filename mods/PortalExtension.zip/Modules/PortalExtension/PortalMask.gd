extends ItemBase

var unlocked = false

func _init():
	id = "PortalMask"

func getVisibleName():
	return "Portal Mask"
	
func getDescription():
	return "A mask that might be seen as a simple medical cover for your mouth. It's been modified with a ring gag attached to a portal."

func getClothingSlot():
	return InventorySlot.Unique

func getBuffs():
	
	return [
		buff(Buff.GagBuff),
		]
		

func getPrice():
	return 20

func getSellPrice():
	return 20

func canSell():
	return true

func getTags():
	if(GM.main != null && (GM.main.getFlag("PortalPantiesModule.Panties_PcDenied") || GM.main.getFlag("PortalPantiesModule.Panties_FleshlightsReturnedToAlex"))):
		return [ItemTag.BDSMRestraint, ItemTag.SoldByAlexRynard]
	return [ItemTag.BDSMRestraint]

func isRestraint():
	return true

func isImportant():
	if(unlocked):
		return false
	return true

func canForceOntoNpc():
	return true

func canForceOntoStaticNpc(): # Messes with the content of static npcs
	return false

func canBeEasilyRemovedByDom():
	return true

func generateRestraintData():
	restraintData = load("res://Modules/PortalPantiesModule/PortalPanties/RestraintPortalPanties.gd").new()
	restraintData.setLevel(10)

func getTakingOffStringLong(withS):
	if(withS):
		return "temporary disables and removes your mask"
	else:
		return "temporary disable and remove your mask"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the mask"
	else:
		return "put on the mask"

func getTakeOffScene():
	return "PortalMaskTakeOffScene"

func coversBodyparts():
	return {
	#BodypartSlot.Mouth: true,
	 }

func alwaysVisible():
	if(unlocked):
		return false
	return true

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"Mask": "res://Modules/PortalExtension/RiggedParts//PortalMask/portalmask.tscn"}

func onDollUpdate(_doll : Doll3D, _zone, _dollpart):
	updateHead(_doll, _dollpart)
	if(canDye() && _dollpart != null && _dollpart.has_method("setColor")):
		_dollpart.setColor(clothesColor)

func updateHead(_doll: Doll3D, _dollpart: Node):
	var stateID = ""
	if _dollpart.has_node("Layer1") && _dollpart.get_node("Layer1").has_node("HeadStatePicker"):
		var statePicker = _dollpart.get_node("Layer1").get_node("HeadStatePicker")
		var head = getWearer().getBodypart("head")
		var headID = head.id
		stateID = powerLoomMatchID(headID)# Fennec -> Feline, Bulldog -> Small Horse, Fox -> Canine
		if stateID == "":
			stateID = powerLoomGuessID(head, statePicker)

	_doll.setState("headtype", stateID)

func powerLoomMatchID(headID: String) -> String:
	if headID in ["caninehead", "bulldoghead", "dragonhead", "felinehead", "fennechead", "foxhead", "horsehead", "horseheadbig", "humanhead", "wolfhead"]:
		match headID:
			"bulldoghead":
				headID = "horsehead"
			"fennechead":
				headID = "felinehead"
			"foxhead":
				headID = "caninehead"
		return headID
	else:
		headID = "felinehead"
		return headID

func powerLoomGuessID(head, statePicker) -> String:# For modded bodparts
	var moddedHeadLenght = head.getHeadLength()
	var headLenghts = {"caninehead": 0.55, "felinehead": 0.25, "deagonhead": 0.7, "horseheadbig": 1.0, "humanhead": 0, "wolfhead": 0.6}
	var states = statePicker.get_children()
	var smallestDifference = {"part": "none", "value": 10}
	for state in states:
		var stateValue = state.stateValue
		var difference = abs(moddedHeadLenght - headLenghts[stateValue])
		if difference < smallestDifference["value"]:
			smallestDifference["value"] = difference
			smallestDifference["part"] = stateValue

	return smallestDifference["part"]

func getInventoryImage():
	return "res://Modules/PortalExtension/RiggedParts/PortalMask/portalmask.png"

func saveData():
	var data = .saveData()
	
	data["unlocked"] = unlocked
	
	return data
	
func loadData(data):
	.loadData(data)
	
	unlocked = SAVE.loadVar(data, "unlocked", false)
