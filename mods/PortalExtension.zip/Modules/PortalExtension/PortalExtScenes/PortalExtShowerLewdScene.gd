extends "res://Scenes/SceneBase.gd"

var sceneSet = ""

func _init():
	sceneID = "PortalExtShowerLewdScene"

func _run():
	var possible = [
	
	]
	
	if(GM.pc.hasVagina() && getModuleFlag("PortalExtension", "Vagina")):
		possible.append("vaginal")
	if(GM.pc.hasPenis() && getModuleFlag("PortalExtension", "Penis")):
		possible.append("penis")
	if(getModuleFlag("PortalExtension", "Ass")):
		possible.append("anal")
	if(getModuleFlag("PortalExtension", "Mouth")):
		possible.append("oral")
	
	if(possible.size() > 0):
		sceneSet = RNG.pick(possible)
	else:
		endScene()
	
	if(state == ""):
		playAnimation(StageScene.SexStanding, RNG.pick(["sex", "fast"]), {onlySub=true, npc="pc", npcBodyState={naked=true}})
		
		sceneSet = RNG.pick(possible)
		
		saynn("You’re wearing portal items even while taking a shower, hopefully that won’t break them.")

		if(sceneSet == "vaginal"):
			saynn("But it doesn't seem like that's your primary concern at the moment. You feel fingers sliding over your magically elsewhere pussy, and shivers run up your spine as you gasp sharply, then cover your mouth, hoping that nobody else heard that. They're gentle, slick, and... Is that soap?")
			saynn("You can feel the tingling slickness of somebody using a cleansing soap on your nethers. Your eyes widen and flutter as you squirm, those fingers exploring every fold, crevice and nook of your nethers, spreading liquid cleaner that clings to your body, and you can feel the gentle itching as it soaks in.")
			saynn(RNG.pick([
				"[say=pc]Wait, w-what? I can clean myse- ...Ah, shit...",
				"[say=pc]Can... Can somebody see me bathing...?!",
			]))
			saynn("Those digits slide deeper into your sex, making you arch your hips, but soon they retract. A single spray of water follows, washing away the clinging liquid, and all the built up grime with it. ...Is that sink water? Somebody is washing you out like a worn sex toy! ...Though, maybe that's more appropriate than you want to admit.")
		elif(sceneSet == "anal"):
			saynn("You're only just enjoying the scrubbing and self exploration, mindful of your equipment, when someone expresses their lack of concerns. ...By squirting something cool and foamy all over your not-here backside. Shivers run up your spine, eyes go wide and you hiss with surprise at the sudden sensation, clenching instinctively.")
			saynn("The fingers that follow don't seem to particularily care. They brush around your trembling star, teasing and nudging, moving the sudsy foam around and... Yep. Yes, those fingers are indeed gently scrubbing your undercarriage. Even as you furiously blush and squirm they push in, forcing fingers and soap into your backside.")
			saynn(RNG.pick([
				"[say=pc]G-god damn it, come on...!",
				"[say=pc]Let me have a little, nnhh, dignity...!",
			]))
			saynn("There's no way to stop them though, not really. Your ass is getting scrubbed by hand like it or not, and they're more talented than they should be. Your sensitive tailhole trembles and clenches as you try not to work, hoping that you're actually alone in the shower as those digits delve deep into your backside, curling to work against your inner walls.")
		elif(sceneSet == "oral"):
			saynn("You're scrubbing yourself down, debating on how you can clean your mouth, when suddenly, someone else sticks their fingers in your forcibly open maw. You recoil, confused, but can't pull away. The digits brush over your tongue, graze your teeth, almost inspecting you. You try not to lick the fingers as they explore your mouth.")
			saynn("Eventually the digits retract from your mouth, only to be replaced with... A fucking toothbrush?! This person is brushing your teeth! ...But what the fuck are you going to do, fight it off with your tongue? That sounds like an invitation. The brush scrubs over your teeth, scrubbing and cleaning what it can reach slowly.")
			saynn(RNG.pick([
				"[say=pc]Ahh, yho a'hole!",
				"[say=pc]Ahhh..."
			]))

		elif(sceneSet == "penis"):
			saynn("Your hands are just soaping up your chest when you suddenly feel it. The hands on your disembodied cock. You throb almost immediately as you shiver, expecting to find another hole wrapped around you as you stiffen in the hands fondling your cock. ...But no, they're gentle. And then, water splashes over your rod. It makes you shiver for a moment.")
			saynn("Then, those hands get slick. You feel bubbles forming on your skin. This isn't lube, they... Somebody is soaping your cock. The now slippery hands stroke along it's length, even as the rod rises to a full turgid erection in the messy grip. Fingers explore you, stroke the length, and feel every little bit of throbbing mass.")
			saynn(RNG.pick([
				"[say=pc]Is... Is this dignified...?",
				"[say=pc]Man, f-fuck, come on...!",
			]))
			saynn("It's not like your protests go anywhere, though. Those fingers explore every inch of your soon turgid cock, massaging. They're thorough, even slipping a hand down to cup and massage your balls, palming those sturdy tanks while continuing to stroke your rod. They must have you propped up somehow. ...Unless there's multiple people...")
		addButton("Get Clean", "What sick fuck cleans you without consent", "cum")

	if(state == "cum"):
		playAnimation(StageScene.SexStanding, RNG.pick(["inside", "fast"]), {onlySub=true, npc="pc", npcBodyState={naked=true}})
		
		if(sceneSet == "vaginal"):
			saynn("The fingers scrubbing you inside and out are thorough. They also don't stop after they've rinsed you clean. Your eyes widen as the tingling in your core spreads, making you squirm as you gasp and pant. That isn't supposed to be part of the process!")
			saynn("But those fingers are relentless anyway. Your hips rock, you squirm as the digits scrub, brush, even curl against your G-spot, surprising thorough and all their work. Your legs are trembling as you grab the wall, helpless to stop the aggressive, and surprisingly talented fingering your clean cunt is getting.")
			saynn(RNG.pick([
				"[say=pc]W-wait, no, fuck, that's not fair...!",
				"[say=pc]Nnnhh, I'm clean, what are you...!",
			]))
			saynn("Inevitablly, the thorough fingers get what they want. Even as you clamp your thighs together, your hips buck and you have to press your face to the shower wall to hide your blush as you cum all over the cruel digits, soaking them in girl cum helpless as you press your thighs together around nothing.")

		elif(sceneSet == "anal"):
			saynn("Those fingers pull away after a few moments, letting your backside grip closed again. And then, the water. The cold splash sends a jolt over your spine, and you gasp, helpless as those fingers push right back into you now with a spray of water to wash away the soap. Your face burns hot as you squirm helplessly.")
			saynn("And yet, as you're liberally scrubbed, rinsed, drained, and then fingers shoved right back into your tight ass, you can feel it. The clenching in your core is more than telling, the heat rising up your body as those digits press to your walls and fingerfuck you so readily. Somehow they find buttons you weren't aware of, and suddenly...")
			saynn(RNG.pick([
				"[say=pc]N... No, not like...!",
				"[say=pc]MmmNNNNHHohfuck!",
			]))
			saynn("You cry out into your cupped palm as you cum like the best of whores, legs trembling, knees clacking together, ring clenching around the fingers that were scrubbing you inside and out, and the way you practically vibrated around them would make it impossible to mistake it for anything but you cumming on those fingers in your ass. And just like that, they slip away, gone.")

		elif(sceneSet=="oral"):
			saynn("The scrubbing is thorough, brushing your teeth from all sides that can be reached with the portal's gag equipment in place. The brush even moves to scrub your tongue, how curtious. It's awkward, and eventually you have to stick out your tongue before they shove the brush down your throat, but soon it's removed.")
			saynn("The brushing is done, and water soon pours into your mouth and you struggle to swish and clear the cleaning fluids before gravity seems to reverse and it pours back out. Almost immediately after though, you feel an explorative tongue shoved into your mouth and you can't help but squirm as you're roughly throat kissed.")
			saynn("Just as quickly though the tongue pulls free and you're left feeling clean, violated, and minty fresh, with a hint of someone else's greedy tongue on your taste buds. They just couldn't leave it nice.")

		elif(sceneSet == "penis"):
			saynn("The hands work every throbbing inch of your length, scrubbing liberally from root to tip, each individual ball, right down to your taint. They're far too thorough for your good, and you can feel your heart rate picking up as the muscles of your groin begin to flex and clench. The soap makes it far too easy for them to work you.")
			saynn("The sudden splash of cold water shocks the sense of control right out of your head. Your dick jumps as the hand pumps, scrubbing soap off of you while jerking you off liberally. The entire time you're cumming all over... Well, you're not sure where you're cumming, but your nuts are definitely clenching while you beat your fist against the wall.")
			saynn(RNG.pick([
				"[say=pc]Hhnnngh...!",
				"[say=pc]F-fuuuuck....",
			]))
			saynn("Your overly sensitive cock is left to throb and pulse while the water washes you off, your nuts flexing as you shudder and gasp helplessly. A little extra soap is applied to your tip, then washed away once more, leaving you clean and well scrubbed. ...And drained.")
		# (scene ends)
		addButton("Continue", "...Thank you...?", "endthescene")


func _react(_action: String, _args):
	if(_action in ["cum"]):
		var pickedInmate = NpcFinder.grabNpcIDFromPoolOrGenerate(CharacterPool.Inmates, [[NpcCon.HasPenis], [NpcCon.NoChastity]], InmateGenerator.new(), {NpcGen.HasPenis: true, NpcGen.NoChastity: true})
		if(pickedInmate == "" || pickedInmate == null):
			pickedInmate = "inmateMaleCanine"

		if(sceneSet != "oral"):
			GM.pc.orgasmFrom(pickedInmate)
	
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)

