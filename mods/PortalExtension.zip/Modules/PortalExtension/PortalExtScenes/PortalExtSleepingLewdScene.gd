extends "res://Scenes/SceneBase.gd"

var npcID = ""
var sceneSet = ""
var penisTarget = ""

func _init():
	sceneID = "PortalExtSleepingLewdScene"

func _run():
	var possible = [
	]
	
	if(GM.pc.hasVagina() && getModuleFlag("PortalExtension", "Vagina")):
		possible.append("vaginal")
	if(GM.pc.hasPenis() && getModuleFlag("PortalExtension", "Penis")):
		possible.append("cock")
	if(getModuleFlag("PortalExtension", "Ass")):
		possible.append("anal")
	if(getModuleFlag("PortalExtension", "Mouth")):
		possible.append("oral")
	
	if(possible.size() > 0):
		sceneSet = RNG.pick(possible)
	else:
		endScene()
		
	if(sceneSet == "cock"):
		penisTarget = RNG.pick([
			"oral",
			"vaginal",
			"anal"
		])
	
	if(state == ""):
		saynn("You were still sleeping in your cell, enjoying the empty pointless dreams that your mind produces. Little stories that are composed out of familiar elements that seem so meaningless together.")

		# (if pussy)
		if(sceneSet == "vaginal"):
			saynn("Oh, but this dream seems particularly interesting. Quite lewd too, someone’s hand is reaching down for your crotch and gives your pussy slit a rub, making you quite wet.")
			saynn("Then the hand gets pulled away, replaced with a dick that brushes against your sex. You begin to wonder if it's still a dream even, the sensations are quite real.")
		elif(sceneSet == "anal"):
			saynn("Oh, but this dream seems particularly interesting. Quite lewd too, someone’s hand is reaching down for your butt and gives your tailhole a rub, making you quite eager.")
			saynn("Then the hand gets pulled away, replaced with a dick that brushes against your pucker. You begin to wonder if it's still a dream even, the sensations are quite real.")
		elif(sceneSet == "oral"):
			saynn("Oh, but this dream seems particularily interesting. Quite lewd too, someone's fingers are brushing your lips, teasing them open and sliding into your mouth, making you sigh with delight.")
			saynn("You go to suck the fingers, lick them, but they're pulled away. Then they're replaced with a dick, brushing your lips. You begin to wonder if it's still a dream even, the sensations are quite real.")
			if(sceneSet == "cock"):
				if(penisTarget == "oral"):
					saynn("Oh, but this dream seems particularily interesting. Quite lewd too, someone's fingers are brushing your already rigid cock. They brush the length from root to tip, and dream-you begins {pc.his} hips upwards.")
					saynn("You feel lips at your throbbing tip. You go to grab at their head and show your appreciation, but your hands pass through harmlessly. You can only moan as your cock begins to disappear into that sweet mouth.")
				elif(penisTarget == "vaginal"):
					saynn("Oh, but this dream seems particularily interesting. Quite lewd too, someone's fingers are brushing your already rigid cock. They touch the base, holding you steady, squeezing, before something brushes the head.")
					saynn("The warmth and wetness is distinct, leaving a slick stain on your cock as dream-you reaches up to grab at the hips poised over your rod. But you touch nothing. That pussy touches plenty as it slides down your cock.")
				else:
					saynn("Oh, but this dream seems particularily interesting. Quite lewd too, someone's fingers are brushing your already rigid cock. They touch the base, holding you steady, squeezing, before something brushes the head.")
					saynn("The distinct warmth and winking grip of a tailhole is distinct, pressuring on the crown of your cock. A thick bead of your own pre adds to the already present lubricant as that tight grip slides down over your tip.")

		addButton("Keep sleeping", "Whatever, you just want your rest", "keep_sleeping")
		addButton("Wake up!", "That shouldn’t be happening", "wake_up!")


	if(state == "keep_sleeping"):
		# (if pussy)
		if(sceneSet == "vaginal"):
			saynn("You try to really immerse yourself into that dream and push away the awakening. Dream-you spreads {pc.his} legs more for that cock and lets it spread your {pc.pussyStretch} pussy wide before entering it.")
			saynn("This surreal experience feels so good to you, little passionate moans escape from your lips as the cock starts fucking you in a dream. While the other you is squirming around in {pc.his} bed, reaching for the portal panties. Such a nice dream.")
			saynn("You feel the intruding dream cock approaching its peak, the thrusts become fast and powerful. You both get shoved over the peak and climax. More little sleepy moans escape from you while the cock starts shooting its load deep into your womb.")

		# (if no pussy)
		elif(sceneSet == "anal"):
			saynn("You try to really immerse yourself into that dream and push away the awakening. Dream-you spreads {pc.his} legs more for that cock and lets it prod at your {pc.analStretch} ring before stretching it wide and sliding in.")
			saynn("This surreal experience feels so good to you, little passionate moans escape from your lips as the cock starts fucking you in a dream. While the other you is squirming around in {pc.his} bed, reaching for the portal panties. Such a nice dream.")
			saynn("You feel the intruding dream cock approaching its peak, the thrusts become fast and powerful. You both get shoved over the peak and climax. More little sleepy moans escape from you while the cock starts shooting its load deep inside you.")

		elif(sceneSet == "oral"):
			saynn("The dream is too nice to give up. Dream-you tilts {pc.his} head back, opening that mouth for the thick cock that's sliding past eager, slick lips. Your tongue extends, sliding along the rod, guiding it in that hungry maw.")
			saynn("It's so real. It's so nice. The taste of faintly musky cock opening your throat, the way it slides past your lips, making you gag a little just before those warm, bloated nuts brush your chin. The thrusts are slow, easy, it's almost delightful how tender this dream cock is.")
			saynn("The thrusts don't stay gentle for long, however. Soon dream you touches {pc.his} throat, feeling the way that thick bulge rolls up and down, knowing you're doing such a good job for this gorgeous slab of cock. You can't help but think you've earned the thick treat soon blasting down your throat in thick, plentiful shots.")

		else:
			if(penisTarget == "oral"):
				saynn("The dream is just too lovely to wake up. Those lips slide down your cock, and leave you shuddering as the tongue bathes your cum vein with greedy licks. The sucking make your hips rise as the bobbing starts. You don't know who this is, but you love them.")
				saynn("The steady throbbing feels so real while the heavenly maw works it's way up and down your turgid wood, hardly even lifting you from sleep while you're tended to. The stroking gets faster, more eagerly as you leak pre onto the mystery tongue only your cock can sense.")
				saynn("Of course such lovely treatment eventually draws your tension to a taut line, your balls flexing, your hips rolling, right before your cum down that amazingly pleasent throat. Your eyes roll back as you moan helplessly, hips jerking up slightly as your balls flex, flooding that maw with lust.")
			if(penisTarget == "vaginal"):
				saynn("The dream is just too lovely to wake up. The slick warmth slides down over your rod, engulfing you in slick heat, and you can't help the audible groan that rises as your back arches, hips lifting instinctively. But the figure above you does all the work.")
				saynn("Right down to the base, you soon feel the gripping sex press to your lap and begin to ride. Slow at first, but rapidly picking up speed, riding you as if you were just a perfect pillar to scratch their internal itch, and damn if you could manage to complain about it.")
				saynn("Soon you feel the walls around your length begin to clamp and squeeze, milking around you as you grunt and groan, and the convulsions rapidly being about your own finish. You feels your body clenching up, cock flexing as thick seed floods the stranger. All too soon the creamy sex lifts up and off of you.")
			if(penisTarget == "anal"):
				saynn("The dream is just too lovely to wake up. The pressure of that tight backside parts, sliding down over your tip to slowly engulf you. The heat, the tight hold, it's almost too much to properly enjoy, but your steel cock makes room for itself in that wonderful backside.")
				saynn("The pressure slowly eases as the ring presses to your base and begins to ride. Slow at first, steadily gaining pace as you arch and sigh with pleasure, enjoying the simple but amazing ride that you were being used for. Even as you press your hips up you're entirely subject to your top's demands for pacing.")
				saynn("Of course, the pleasure is too good. Soon your can feel your body clenching. Squeezing in all the right places. As your eyes roll back into your head your mouth falls open and you can't hold in the deep groan as your cock begins to dump a generous load into that perfect, tight ass, filling it good and thoroughly with your lust.")
		addButton("Wake up", "That was a nice dream", "wake_up")

	if(state == "wake_up"):
		if(sceneSet != "oral"):
			saynn("When the dream is over, you open your eyes and sit down, still panting from the magical experience. Strange thoughts start going through your head, you reach down for your crotch but only find the portal panties there.")
		else:
			saynn("When the dream is over, you open your eyes and sit down, still panting for breath. Strange thoughts start filling your head, you reach up to touch your mouth but only feel the sealed portal mask covering your features.")
		saynn(RNG.pick([
			"[say=pc]Was I?..[/say]",
			"[say=pc]Was that..[/say]",
		]))
		
		addButton("Continue", "Wet dreams", "endthescene")


	if(state == "wake_up!"):
		playAnimation(StageScene.SexAllFours, RNG.pick(["sex", "fast", "sexflop", "fastflop"]), {onlySub=true, npc="pc", npcBodyState={naked=true}})
		
		if(sceneSet == "vaginal"):
			saynn("You open your eyes and realize that nothing of it was a dream, you indeed feel a cock rubbing against your pussy through the portal panties before suddenly penetrating your sex!")
			saynn("You try to get up but the rough thrusts pin you to the bed. You turn around and get on all fours, moaning while someone’s cock pounds your slit hard, making you shift forward each time.")
			saynn(RNG.pick([
				"[say=pc]Fuck..[/say]",
				"[say=pc]So rough..[/say]",
			]))
			saynn("It doesn’t take long before the orgasm overwhelms your body, little shivers in your limbs cause your top part of the body to flop onto the bed while your {pc.thick} butt gets sticked out more. You moan into the pillow as the cock thrusts harder, powering through your clenching before cumming too and stuffing your pussy full of cum!")

		elif(sceneSet == "anal"):
			saynn("You open your eyes and realize that nothing of it was a dream, you indeed feel a cock rubbing against your tailhole through the portal panties before suddenly penetrating your ass!")
			saynn("You try to get up but the rough thrusts pin you to the bed. You turn around and get on all fours, moaning while someone’s cock pounds your fuckhole hard, making you shift forward each time.")
			saynn(RNG.pick([
				"[say=pc]Fuck..[/say]",
				"[say=pc]So rough..[/say]",
			]))
			saynn("It doesn’t take long before the orgasm overwhelms your body, little shivers in your limbs cause your top part of the body to flop onto the bed while your {pc.thick} butt gets sticked out more. You moan into the pillow as the cock thrusts harder, powering through your clenching before cumming too and stuffing your ass full of cum!")

		elif(sceneSet == "oral"):
			saynn("Eventually you blink open your eyes, and suddenly realize that there was less dream than you thought. The thick length is still rubbing your lips, but when you open your mouth to complain, it's plenty enough invitation. The thick cock drives right down your throat in one swift thrust, gagging you immediately.")
			saynn("You don't even get a chance to complain, grabbing your mouth with one hand and your throat in the other. You try to roll over to make it easier but it doesn't help while that fat dick rams your throat full. Blissfully it seems like someone with a midnight bone to pick, because that cock is soon flexing and throbbing with impending release.")
			saynn(RNG.pick([
				"[say=pc]Mmmnnhhhh!",
				"The sound of rough, throat stretching oral is the only sound that can escape you. At least it's muted.",
			]))
			saynn("Blissfully, even as you paw at your throat and the bed, the rampaging face fuck doesn't take too long to conclude. You feel balls smack your chin before the fat, flexing dick begins flooding your belly with a warm midnight snack. You taste the last of it as the dick draws from your helpless lips.")
		
		else:
			if(penisTarget == "oral"):
				saynn("You suddenly snap out of the rather pleasant dream, to realize... Yeah, no, your disembodied cock is getting sucked good and rough. You don't know who needed a midnight snack so badly, but they're greedily polishing your cock, throating it like they're practicing for someone important in the morning.")
				saynn("The greedy throating of your cock is surely as loud as it is sloppy, not that you can hear it through the portal, but it does make you hopeful that somebody can hear them gorging themselves on your fat cock. Not that it seems to matter to them, or your cock with how it's sending lightening up your spine.")
				saynn(RNG.pick([
					"[say=pc]Oh fuck, mmnh...!",
					"[say=pc]E-even at night...?!"
				]))
				saynn("The abrupt, aggressive slurp job does it's natural work, and your eyes roll back into your head as you fight the inevitable. You bite your lip, grab the sheets, but it can't be helped. You buck as you cum, groaning and hoping you're not disturbing anyone else in the cells while you bust a nut down a stranger's throat. Maybe you'll see the telltale bulge later today.")
				
				if(penisTarget == "vaginal"):
					saynn("The dream suddenly fades, but the grip of that mystery pussy does not. Slick walls slide down the length of you in steady motions, squishy mound touching on your lap. You can't see it, but you can certainly feel it, and the slick femcum left on your dick with each rise up, the heat as it slams right back down onto your lap.")
					saynn("Your back arches as your bite your lip, grunting with the effort to not cry out and disturb the other occupants of the block, which certainly wouldn't help your predictament. But goddamnit, surprise or not that pussy is good, and you can feel your groin tensing with the restrained demand to flood that womb.")
					saynn(RNG.pick([
						"Nnnhh... D-damnit...!",
						"F... Fuuuuck...",
					]))
					saynn("Of course your restraing can't hold out forever. Even as you clench, grit your teeth and cover your mouth, your cock jumps before flooding that slick cock milker with your dense load. Your hips jerk, bouncing up, but you can't stop the flood. That cunt presses to your lap, grinds to milk your last, then draws up and off of your spend cock, done with you.")
				
				if(penisTarget == "anal"):
					saynn("The soft, fluffy clouds disappear from around you, but that ass only tightens around the crown of your cock. Almost painfully tight, that body slides down your cock, making it... Well, your cock is already gone, but it disappears a second time in that toe curling grip. It presses firmly to your lap and slides right back off, starts a steady rhythm on you.")
					saynn("Clamping a hand over your mouth, you fight to not alert the whole block that you're getting your cock worked, but that ring working your cock is hard to not cry out for. You manage it somehow, tipping your head back against the pillow, hips rising as you shiver and squirm. That ass bounces on your cock, never quite touching your lap, denying you the last bit of satisfaction.")
					saynn(RNG.pick([
						"Hhnnn...!",
						"F-fuck that's tight...!"
					]))
					saynn("Your stamina can't last all night. It's just as that tight asshole drives down to your lap and presses, grinding while convulsing, you can only guess in an orgasm of their own. You feel the thick load bubble up from your tanks, disappearing into nothingness as you give a low, gutteral groan, hips trembling. Eventually the tight grip slides off of you and you can only imagine the mess of both your cock and that ass.")
		addButton("Continue", "Can't even sleep without getting used", "endthescene")

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _react(_action: String, _args):
	var pickedInmate
	if(_action in ["keep_sleeping", "wake_up!"]):
		if(!penisTarget == "vaginal"):
			pickedInmate = NpcFinder.grabNpcIDFromPoolOrGenerate(CharacterPool.Inmates, [[NpcCon.HasPenis], [NpcCon.NoChastity]], InmateGenerator.new(), {NpcGen.HasPenis: true, NpcGen.NoChastity: true})
			if(pickedInmate == "" || pickedInmate == null):
				pickedInmate = "inmateMaleCanine"
			npcID = pickedInmate
		else:
			pickedInmate = NpcFinder.grabNpcIDFromPoolOrGenerate(CharacterPool.Inmates, [[NpcCon.HasVagina], [NpcCon.NoChastity]], InmateGenerator.new(), {NpcGen.NoChastity: true})
			if(pickedInmate == "" || pickedInmate == null):
				pickedInmate = "inmateMaleCanine"
			npcID = pickedInmate
		
		if(sceneSet == "vaginal"):
			GM.pc.gotVaginaFuckedBy(pickedInmate)
			GM.pc.cummedInVaginaBy(pickedInmate)
			GM.pc.orgasmFrom(pickedInmate)
		elif(sceneSet == "anal"):
			GM.pc.gotAnusFuckedBy(pickedInmate)
			GM.pc.cummedInAnusBy(pickedInmate)
			GM.pc.orgasmFrom(pickedInmate)
		elif(sceneSet == "oral"):
			GM.pc.gotThroatFuckedBy(pickedInmate)
			GM.pc.cummedInMouthBy(pickedInmate)
		elif(sceneSet == "penis"):
			GM.pc.orgasmFrom(pickedInmate)
			if(penisTarget == "oral"):
				getCharacter(npcID).cummedInMouthBy(GM.pc)
			if(penisTarget == "vaginal"):
				getCharacter(npcID).cummedInVaginaBy(GM.pc)
			if(penisTarget == "anal"):
				getCharacter(npcID).cummedInAusBy(GM.pc)
		
	
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)

func saveData():
	var data = .saveData()
	
	data["npcID"] = npcID
	
	return data
	
func loadData(data):
	.loadData(data)
	
	npcID = SAVE.loadVar(data, "npcID", "inmateMaleCanine")
