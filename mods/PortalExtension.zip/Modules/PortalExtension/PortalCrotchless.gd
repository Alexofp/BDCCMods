extends ItemBase

var unlocked = false

func _init():
	id = "PortalCrotchless"

func getVisibleName():
	return "Portal Crotchless"
	
func getDescription():
	return "A pair of panties with the crotch cut away, leaving only the back piece covering you. Watch where you leave it!."

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getBuffs():
	return [
		buff(Buff.ChastityAnusBuff),
		]
		

func getPrice():
	return 20

func getSellPrice():
	return 20

func canSell():
	return true

func getTags():
	if(GM.main != null && (GM.main.getFlag("PortalPantiesModule.Panties_PcDenied") || GM.main.getFlag("PortalPantiesModule.Panties_FleshlightsReturnedToAlex"))):
		return [ItemTag.BDSMRestraint, ItemTag.SoldByAlexRynard]
	return [ItemTag.BDSMRestraint]

func isRestraint():
	return true

func isImportant():
	if(unlocked):
		return false
	return true

func canForceOntoNpc():
	return true

func canForceOntoStaticNpc(): # Messes with the content of static npcs
	return false

func canBeEasilyRemovedByDom():
	return true

func generateRestraintData():
	restraintData = load("res://Modules/PortalPantiesModule/PortalPanties/RestraintPortalPanties.gd").new()
	restraintData.setLevel(10)

func getTakingOffStringLong(withS):
	if(withS):
		return "temporary disables and slips down your panties"
	else:
		return "temporary disable and slip down your panties"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the panties"
	else:
		return "put on the panties"

func getRiggedParts(_character):
	return {
		"panties": "res://Modules/PortalExtension/RiggedParts/PortalCrotchless/portalcrotchless.tscn",
	}	

func getHidesParts(_character):
	return {
		#BodypartSlot.Penis: true,
	}

func getTakeOffScene():
	return "PortalCrotchlessTakeOffScene"

func coversBodyparts():
	return {
	BodypartSlot.Anus: true,
	 }

func alwaysVisible():
	if(unlocked):
		return false
	return true

func getInventoryImage():
	return "res://Modules/PortalExtension/RiggedParts/PortalCrotchless/portalcrotchless.png"

func saveData():
	var data = .saveData()
	
	data["unlocked"] = unlocked
	
	return data
	
func loadData(data):
	.loadData(data)
	
	unlocked = SAVE.loadVar(data, "unlocked", false)
