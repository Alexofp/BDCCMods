extends Module

func getFlags():
	return {
		"Penis": flag(FlagType.Bool),
		"Vagina": flag(FlagType.Bool),
		"Ass": flag(FlagType.Bool),
		"Mouth": flag(FlagType.Bool),
	}
	

func _init():
	id = "PortalExtension"
	author = "Dequire"
	
	items = [
		"res://Modules/PortalExtension/PortalJock.gd",
		"res://Modules/PortalExtension/PortalMask.gd",
		"res://Modules/PortalExtension/PortalCrotchless.gd",
	]
	
	scenes = [
		"res://Modules/PortalExtension/PortalExtScenes/PortalJockTakeOffScene.gd",
		"res://Modules/PortalExtension/PortalExtScenes/PortalMaskTakeOffScene.gd",
		"res://Modules/PortalExtension/PortalExtScenes/PortalCrotchlessTakeOffScene.gd",
		"res://Modules/PortalExtension/PortalExtScenes/PortalExtShowerLewdScene.gd",
		"res://Modules/PortalExtension/PortalExtScenes/PortalExtLewdsScene.gd",
		"res://Modules/PortalExtension/PortalExtScenes/PortalExtSleepingLewdScene.gd",
	]
	
	events = [
		"res://Modules/PortalExtension/PortalExtEvents/PortalExtEvent.gd",
		"res://Modules/PortalExtension/PortalExtEvents/PortalExtLewdsEvent.gd",
	]
	
func registerEventTriggers():
	GM.ES.registerEventTrigger("PortalExtEvent", EventTriggerWeighted.new())
	GM.ES.registerEventTrigger("PortalExtShowerEvent", EventTriggerWeighted.new())
	GM.ES.registerEventTrigger("PortalExtSleepingEvent", EventTriggerWeighted.new())
