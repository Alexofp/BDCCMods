extends ItemBase

var unlocked = false

func _init():
	id = "PortalJock"

func getVisibleName():
	return "Portal Jockstrap"
	
func getDescription():
	return "A jockstrap that's been modified like the portal panties. Watch your back! 'Cus now you can't watch your front."

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getBuffs():
	return [
		buff(Buff.ChastityPenisBuff),
		buff(Buff.ChastityVaginaBuff),
		]

func getPrice():
	return 20

func getSellPrice():
	return 20

func canSell():
	return true

func getTags():
	if(GM.main != null && (GM.main.getFlag("PortalPantiesModule.Panties_PcDenied") || GM.main.getFlag("PortalPantiesModule.Panties_FleshlightsReturnedToAlex"))):
		return [ItemTag.BDSMRestraint, ItemTag.SoldByAlexRynard]
	return [ItemTag.BDSMRestraint]

func isRestraint():
	return true

func isImportant():
	if(unlocked):
		return false
	return true

func canForceOntoNpc():
	return true

func canForceOntoStaticNpc(): # Messes with the content of static npcs
	return false

func canBeEasilyRemovedByDom():
	return true

func generateRestraintData():
	restraintData = load("res://Modules/PortalPantiesModule/PortalPanties/RestraintPortalPanties.gd").new()
	restraintData.setLevel(10)

func getTakingOffStringLong(withS):
	if(withS):
		return "temporary disables and slips down your jockstrap"
	else:
		return "temporary disable and slip down your jockstrap"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the jockstrap"
	else:
		return "put on the jockstrap"

func getRiggedParts(_character):
	return {
		"panties": "res://Modules/PortalExtension/RiggedParts/PortalJock/PortalJock.tscn",
	}	

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
	}

func getTakeOffScene():
	return "PortalJockTakeOffScene"

func coversBodyparts():
	return {
	BodypartSlot.Vagina: true,
	BodypartSlot.Penis: true,
	 }

func alwaysVisible():
	if(unlocked):
		return false
	return true

func getInventoryImage():
	return "res://Modules/PortalExtension/RiggedParts/PortalJock/portaljocks.png"

func saveData():
	var data = .saveData()
	
	data["unlocked"] = unlocked
	
	return data
	
func loadData(data):
	.loadData(data)
	
	unlocked = SAVE.loadVar(data, "unlocked", false)
