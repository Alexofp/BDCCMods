extends Module

const SAVE_FILE_PATH = "user://mod_heights.json"
var sceneID = "IgnoreMe"
var height_script = load("res://Modules/WolffsHeightMod/HeightIK_Injection.gd")

func _init():
	id = "WolffsHeightMod"
	author = "Wolff"
	
	items = [
		"res://Modules/WolffsHeightMod/Inventory/Items/HeightPillGrow.gd",
		"res://Modules/WolffsHeightMod/Inventory/Items/HeightPillShrink.gd"
	]
	
	call_deferred("start_skeleton_injector")

func start_skeleton_injector():
	var tree = Engine.get_main_loop()
	if tree and tree is SceneTree:
		tree.connect("node_added", self, "_on_node_added")

func _on_node_added(node):
	if node.get_class() == "Skeleton" and node.name == "Skeleton":
		if not node.get_script(): 
			node.set_script(height_script)
			node.set_process(true)
			if node.has_method("_ready"):
				node._ready()

func onFoxLibModInit(foxModuleAPI):
	var randomize_enabled = load_toggle_setting()
	Engine.set_meta("randomize_npc_heights", randomize_enabled)

	var toggle = foxModuleAPI.addBooleanOptionInCategory(
		"Wolff's Height Mod",
		"randomize_npc_heights",
		"Randomize NEW NPCs",
		"If enabled, newly encountered NPCs receive random heights. If disabled, new NPCs spawn at default 1.0 height. Pills will still work on them either way.",
		randomize_enabled
	)
	if toggle != null and toggle.has_signal("option_changed"):
		toggle.connect("option_changed", self, "on_toggle_changed")

	var reset_btn = foxModuleAPI.addButtonOptionInCategory(
		"Wolff's Height Mod",
		"reset_all_heights_btn",
		"Reset Encountered NPCs to Default",
		"WARNING: Resets all discovered NPCs to 1.0 height, wiping pill effects. Undiscovered NPCs elsewhere in the prison are unaffected."
	)
	if reset_btn != null and reset_btn.has_signal("option_changed"):
		reset_btn.connect("option_changed", self, "on_reset_clicked")

func on_toggle_changed(new_value: bool):
	Engine.set_meta("randomize_npc_heights", new_value)
	save_toggle_setting(new_value)

func on_reset_clicked(_val = null):
	wipe_all_npc_heights()

# FILE SAVING LOADING function
func wipe_all_npc_heights():
	var saved_data = {}
	var file = File.new()
	
	if file.file_exists(SAVE_FILE_PATH):
		file.open(SAVE_FILE_PATH, File.READ)
		var parse_result = JSON.parse(file.get_as_text())
		file.close()
		if parse_result.error == OK and typeof(parse_result.result) == TYPE_DICTIONARY:
			saved_data = parse_result.result
			
	if saved_data.empty() and Engine.has_meta("global_height_dict"):
		saved_data = Engine.get_meta("global_height_dict")
		
	for key in saved_data.keys():
		if key != "__settings__" and key != "pc":
			saved_data[key] = 1.0
			
	file.open(SAVE_FILE_PATH, File.WRITE)
	file.store_string(JSON.print(saved_data))
	file.close()
	
	Engine.set_meta("global_height_dict", saved_data)
	print("WolffsHeightMod: Discovered NPC heights reset to 1.0 globally!")

func load_toggle_setting() -> bool:
	var file = File.new()
	if file.file_exists(SAVE_FILE_PATH):
		file.open(SAVE_FILE_PATH, File.READ)
		var content = file.get_as_text()
		file.close()
		var parse_result = JSON.parse(content)
		if parse_result.error == OK and typeof(parse_result.result) == TYPE_DICTIONARY:
			if parse_result.result.has("__settings__") and parse_result.result["__settings__"].has("randomize"):
				return parse_result.result["__settings__"]["randomize"]
	return true

func save_toggle_setting(is_enabled: bool):
	var saved_data = {}
	var file = File.new()
	if file.file_exists(SAVE_FILE_PATH):
		file.open(SAVE_FILE_PATH, File.READ)
		var parse_result = JSON.parse(file.get_as_text())
		file.close()
		if parse_result.error == OK and typeof(parse_result.result) == TYPE_DICTIONARY:
			saved_data = parse_result.result

	if not saved_data.has("__settings__"):
		saved_data["__settings__"] = {}
	saved_data["__settings__"]["randomize"] = is_enabled

	file.open(SAVE_FILE_PATH, File.WRITE)
	file.store_string(JSON.print(saved_data))
	file.close()