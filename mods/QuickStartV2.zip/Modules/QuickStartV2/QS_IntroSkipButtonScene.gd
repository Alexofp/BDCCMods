extends SceneBase

var beltType = null

func _init():
	sceneID = "QS_IntroSkipButtonScene"

func _run():
	if(state == ""):

		if(GM.pc.hasPerk(Perk.StartMaleChastity) && GM.pc.hasPenis()):
			setFlag("MedicalModule.PC_ReceivedPermanentCage", true)
			setState("chastitySelect")
		else:
			setState("crimeSelect")

	if(state == "chastitySelect"):
		playAnimation(StageScene.Solo, "stand", {bodyState={naked=true}})

		saynn("Pick your chastity belt type:")

		addButton(("[Normal]" if beltType == "regular_one" else "Normal"),"The more comfortable one","regular_one")
		addButton(("[Flat]" if beltType == "flat_one" else "Flat"),"The more punishing one","flat_one")
		if(GM.pc.getInventory().getEquippedItem(InventorySlot.Penis) == null):
			addDisabledButton("Continue","You must select a chastity belt")
		else:
			addButton("Continue","Looks good","crimeSelect")

	if(state == "crimeSelect"):
		playAnimation(StageScene.Solo, "stand")
		saynn("What crime are you guilty of?")

		addButton("Innocent", "You were framed (start as general block inmate)", "crime_innocent")
		addButton("Thief", "You stole a large sum of money (start as general block inmate)", "crime_theft")
		addButton("Murderer", "You killed someone (start as high security inmate)", "crime_murder")
		addButton("Prostitute", "You were an unlicensed prostitute (start as sexual deviant inmate)", "crime_prostitution")

	if(state in ["crime_innocent", "crime_theft", "crime_murder", "crime_prostitution"]):
		GM.pc.getInventory().equipItem(GlobalRegistry.createItem("inmatecollar"))

		setState("promptPreferences")

	if(state in "promptPreferences"):
		saynn("Almost done! Do you want to adjust your character's preferences? You can change these later at any time.")
		addButton("Yes","Adjust my preferences","changePreferences")
		addButton("No","Do this later","done")

	if(state == "done"):
		var uniform = GlobalRegistry.createItem("inmateuniform")
		
		uniform.setPrisonerNumber(GM.pc.getFullInmateNumber())
		uniform.setInmateType(GM.pc.getInmateType())
		GM.pc.getInventory().forceEquipRemoveOther(uniform)

		GM.pc.updateAppearance()
		saynn("You're done! Enjoy!")
		addButton("Continue","Start playing","endthisscene")

		

func onTextBoxEnterPressed(_new_text:String):
	GM.main.pickOption("setname", [])

func _react(_action: String, _args):
	if(_action == "setname"):
		if(getTextboxData("player_name") == ""):
			return
		
		GM.pc.setName(getTextboxData("player_name"))
		
		#setState("pickgender")
		runScene("CharacterCreatorScene", [], "character_creator")
		return
	
	if(_action == "endthisscene"):
		GM.main.setFlag("Game_CompletedPrologue", true)
		aimCamera(GM.pc.getCellLocation())
		GM.pc.setLocation(GM.pc.getCellLocation())
		startNewDay()
		GM.pc.afterSleepingInBed()
		runScene("WorldScene")
		endScene()
	
	#"crime_innocent", "crime_theft", "crime_murder", "crime_prostitution"
	
	if(_action == "crime_innocent"):
		setFlag("Player_Crime_Type", Flag.Crime_Type.Innocent)
		GM.pc.setInmateType(InmateType.General)
	if(_action == "crime_theft"):
		setFlag("Player_Crime_Type", Flag.Crime_Type.Theft)
		GM.pc.setInmateType(InmateType.General)
	if(_action == "crime_murder"):
		setFlag("Player_Crime_Type", Flag.Crime_Type.Murder)
		GM.pc.setInmateType(InmateType.HighSec)
	if(_action == "crime_prostitution"):
		setFlag("Player_Crime_Type", Flag.Crime_Type.Prostitution)
		GM.pc.setInmateType(InmateType.SexDeviant)
	
	if(_action == "regular_one"):
		beltType = _action
		setFlag("MedicalModule.PC_PickedFlatPermanentCage", false)
		
		GM.pc.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("ChastityCagePermanentNormal"))
		setState("chastitySelect")
		return
		
	if(_action == "flat_one"):
		beltType = _action
		setFlag("MedicalModule.PC_PickedFlatPermanentCage", true)
		
		GM.pc.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("ChastityCagePermanent"))
		setState("chastitySelect")
		return

	if(_action == "changePreferences"):
		runScene("EncountersMenuScene", [], "encounters_menu")

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "encounters_menu"):
		setState("done")
