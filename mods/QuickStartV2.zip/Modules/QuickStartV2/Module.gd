extends Module

func _init():
	id = "QuickStart"
	author = "MOON_HALO"

	scenes = [
		"res://Modules/QuickStartV2/QS_IntroSkipButtonScene.gd",
	]

	events = [
		"res://Modules/QuickStartV2/QS_IntroSkipButtonEvent.gd",
	]