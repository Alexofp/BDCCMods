extends EventBase

func _init():
	id = "QS_IntroSkipButtonEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", ""])
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", "take_a_sit"])
	
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", "donecreating"])
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", "didntdoit"])
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", "wantlawyer"])
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", "staysilent"])
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene", "admit"])

func run(_triggerID, _args):
	GM.main.clearMessages()
	if _args[0] == "IntroScene":
		if _args[1] in ["", "take_a_sit"]:
			addMessage("To skip to character creation, Select \"QUICKSTART\"")
			GM.ui.addButtonAt(14,"QUICKSTART", "Skip to character creation", "EVENTSYSTEM_BUTTON", [self, "askforname", [""]])
		if _args[1] in ["donecreating", "didntdoit", "wantlawyer", "staysilent", "admit"]:
			GM.ui.addButtonAt(14,"QUICKSTART", "Skip the rest of the intro sequence", "EVENTSYSTEM_BUTTON", [self, "QuickStart", [""]])
		if _args[1] == "admit":
			addMessage("Last chance to skip the rest of the intro sequence! Select \"QUICKSTART\"")
		
		

func onButton(_method, _args):
	if(_method == "askforname"):
		GM.main.sceneStack[0]["state"] = "askforname"
		GM.main.sceneStack[0].run()
	if(_method == "QuickStart"):
		runScene("QS_IntroSkipButtonScene")
		GM.main.sceneStack[0].endScene()
