extends Module

func _init():
	id = "WintersCoreModule"
	author = "Avery Winters & Selinoccino"

	species = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersCoreModule/CompatabilityPatches/BDCC/")
