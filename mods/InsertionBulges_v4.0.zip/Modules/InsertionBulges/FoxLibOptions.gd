const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const T_BOOL := "boolean"
const T_PERCENT := "slider"
const T_CHOICE := "choice"
const T_BUTTON := "button"
const CAT_MAIN := "Insertion Bulges"
const CAT_SIMPLE := "Insertion Bulges: Simple and Medium"
const CAT_MEDIUM := "Insertion Bulges: Medium"
const CAT_DETAILED := "Insertion Bulges: Detailed"
const CATEGORIES := [CAT_MAIN, CAT_SIMPLE, CAT_MEDIUM, CAT_DETAILED]
const RESTORE_ID := "bulgeRestore"
const ID_PREFIX := "v4_"
const OPTIONS := [
{
	"id": "bulgeEffect", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["simple", "Simple"], ["medium", "Medium"], ["detailed", "Detailed"]],
	"title": "Effect",
	"desc": "How the bulge is drawn. Simple: a smooth round bump. Medium: the bump copies the cock's shape and moves" \
		+ " softly. Detailed (recommended): the body's own outline stretches over the cock. Each effect's settings are" \
		+ " in its own section, shown with FoxLib's \"Show advanced mod options\".",
},
{
	"id": "bulgeSizeModifier", "cat": CAT_SIMPLE, "type": T_PERCENT, "advanced": true,
	"title": "Bulge size",
	"desc": "How big bulges are. 0% hides them (not the mouth's).",
},
{
	"id": "bulgeShapeFidelity", "cat": CAT_SIMPLE, "type": T_PERCENT, "advanced": true,
	"title": "Cock shape",
	"desc": "How much the bulge copies the cock's own shape (its knot, its flare). 0% = a smooth round bump.",
},
{
	"id": RESTORE_ID, "cat": CAT_MAIN, "type": T_BUTTON, "advanced": false,
	"title": "Restore recommended settings",
	"desc": "Puts every Insertion Bulges option back to its recommended value.",
},
{
	"id": "bulgeLag", "cat": CAT_MEDIUM, "type": T_BOOL, "advanced": true,
	"title": "Soft motion",
	"desc": "The bulge grows, shrinks and wobbles softly instead of following the cock at once.",
},
{
	"id": "bulgePregnantBelly", "cat": CAT_MEDIUM, "type": T_BOOL, "advanced": true,
	"title": "Pregnant belly",
	"desc": "A pregnant belly swells where the cock pushes inside it.",
},
{
	"id": "bulgeOtherHalfAdd", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Knots and ridges",
	"desc": "Makes knots and ridges stand out more on the bulge.",
},
{
	"id": "bulgeLipAmount", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Opening at the hole",
	"desc": "The skin round the hole opens around the cock and is pulled out with it. 0% is off.",
},
{
	"id": "bulgeDirection", "cat": CAT_MEDIUM, "type": T_CHOICE, "advanced": true,
	"values": [["blend", "Between hole and cock"], ["shaft", "Along the cock"],
		["belly", "Along the belly"], ["torso", "Along the body"]],
	"title": "Bulge direction",
	"desc": "Which way the bulge runs in the body: along the cock, along the belly, straight up the" \
		+ " body, or between the hole and the cock (recommended).",
},
{
	"id": "bulgeLagDeflate", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Settle speed",
	"desc": "How fast a bulge goes down. Lower lets it linger after a pose change. Needs Soft motion on.",
},
{
	"id": "bulgeTorsoArch", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Torso stretch",
	"desc": "A cock longer than the body: its extra length bunches up and the bulge swells in an arch," \
		+ " most in the middle. 0% is off: the bulge just stops at the chest.",
},
{
	"id": "bulgeOralSize", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Throat size",
	"desc": "How big the throat bulge is. 0% hides it.",
},
{
	"id": "bulgeOralSwallow", "cat": CAT_MEDIUM, "type": T_BOOL, "advanced": true,
	"title": "Swallowing",
	"desc": "While the cock rests deep in the throat, the throat gives a small swallow every few seconds.",
},
{
	"id": "bulgesEnabled", "cat": CAT_MAIN, "type": T_BOOL, "advanced": false,
	"title": "Show bulges",
	"desc": "The body swells where a cock is inside it, and the part inside is hidden. Off turns the whole mod off.",
},
{
	"id": "bulgeFollowBody", "cat": CAT_DETAILED, "type": T_PERCENT, "advanced": true,
	"title": "Follow the body",
	"desc": "Inside the body the cock bends along it instead of going straight. 0% = straight.",
},
{
	"id": "bulgeBelly", "cat": CAT_DETAILED, "type": T_PERCENT, "advanced": true,
	"title": "Toward the belly",
	"desc": "Inside the body the cock runs close to the belly and pushes it out. 0% = through the middle.",
},
{
	"id": "bulgeStopAtNeck", "cat": CAT_DETAILED, "type": T_BOOL, "advanced": true,
	"title": "Stop at the neck",
	"desc": "A cock longer than the torso does not run out of the top: pushed against the neck it bows out, like a wire, and straightens as it pulls back.",
},
{
	"id": "bulgeSkinShadeStrength", "cat": CAT_DETAILED, "type": T_PERCENT, "advanced": true,
	"title": "Shade strength",
	"desc": "How visible the under-skin shade is. 0% = not at all, 100% = very dark.",
},
{
	"id": "bulgeSkinShadeStyle", "cat": CAT_DETAILED, "type": T_CHOICE, "advanced": true,
	"values": [["none", "None"], ["soft", "Soft"], ["soft_outline", "Soft + outline"], ["filled", "Filled"],
		["filled_outline", "Filled + outline"], ["halo", "Halo"], ["halo_outline", "Halo + outline"],
		["xray", "X-ray"], ["xray_outline", "X-ray + outline"]],
	"title": "Shade style",
	"desc": "How the cock shows through the skin. None: it does not. Soft: a soft shadow with a light rim. Filled: an even dark shape." \
		+ " Halo: a blurred shadow. X-ray: the cock's own drawing, darker. + outline: the cock's drawn outline too.",
},
{
	"id": "bulgeSkinShadeOnTop", "cat": CAT_DETAILED, "type": T_BOOL, "advanced": true,
	"title": "Shade over everything",
	"desc": "The under-skin shade shows over the head, arms, legs and other characters too, not only over the body.",
},
]
static func foxId(row:Dictionary) -> String:
	return ID_PREFIX + str(row["id"])
static func shipped(row:Dictionary):
	return Settings.compiled(str(row["id"]))
static func percentOf(row:Dictionary) -> int:
	return int(round(float(shipped(row)) * 100.0))
static func settingFor(row:Dictionary) -> String:
	if(str(row["type"]) == T_BUTTON || Settings.declaration(str(row["id"])) == null):
		return ""
	return str(row["id"])
static func rowFor(name:String) -> Dictionary:
	for row in OPTIONS:
		if(settingFor(row) == name):
			return row
	return {}
static func decode(row:Dictionary, raw):
	if(str(row["type"]) != T_PERCENT):
		return raw
	if(typeof(raw) != TYPE_INT && typeof(raw) != TYPE_REAL):
		return raw
	return float(raw) / 100.0
static func encode(row:Dictionary, given):
	if(str(row["type"]) != T_PERCENT):
		return given
	if(typeof(given) != TYPE_INT && typeof(given) != TYPE_REAL):
		return given
	return int(round(float(given) * 100.0))
const MANAGER_PATH := "res://Modules/FoxLib/Internal/FoxOptionsManager.gd"
const SECTION := Boot.MARKER_MOD
const STORE_LABEL := "FoxLib's mod options (section " + SECTION + " of user://foxlib/mod_options.cfg)"
const ABSENT := "insertionbulges-v4-no-such-foxlib-key"
const CACHE := {"looked": false, "manager": null}
static func manager():
	if(!CACHE["looked"]):
		CACHE["looked"] = true
		if(ResourceLoader.exists(MANAGER_PATH)):
			CACHE["manager"] = load(MANAGER_PATH)
	return CACHE["manager"]
static func live() -> bool:
	return manager() != null
static func storeLabel() -> String:
	return STORE_LABEL
static func forget() -> void:
	CACHE["looked"] = false
	CACHE["manager"] = null
static func stored(mgr = manager()) -> Dictionary:
	var out:Dictionary = {}
	if(mgr == null):
		return out
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name == ""):
			continue
		var raw = mgr.getOption(SECTION, foxId(row), ABSENT)
		if(typeof(raw) == TYPE_STRING && str(raw) == ABSENT):
			continue
		var vetted:Array = Settings.vetSetting(name, decode(row, raw))
		if(!vetted[0].empty()):
			Boot.loud("FoxLibOptions: " + STORE_LABEL + " holds '" + str(row["id"]) + "' = " \
				+ str(raw) + ", which this build cannot use - " \
				+ PoolStringArray(vetted[0]).join("; ") + ". THAT ONE SETTING IS IGNORED this run" \
				+ " and falls back to the bench or the compiled default; every other setting is" \
				+ " unaffected. Reset that option in FoxLib's mod options screen.")
			continue
		out[name] = vetted[1]
	return out
static func store(name:String, given, mgr = manager()) -> bool:
	if(mgr == null):
		Boot.loud("FoxLibOptions: asked to store '" + name + "' with FoxLib not installed. Nothing" \
			+ " written. This is a bug in the caller: Settings.store() must route to its own file" \
			+ " when FoxLib is absent.")
		return false
	var row:Dictionary = rowFor(name)
	if(row.empty()):
		Boot.loud("FoxLibOptions: '" + name + "' is not on FoxLib's options screen, so there is" \
			+ " nowhere in " + STORE_LABEL + " to put it. NOTHING WRITTEN and the value is NOT" \
			+ " saved. Add a row for it in FoxLibOptions.OPTIONS, or set it through" \
			+ " the Bench.")
		return false
	mgr.setOption(SECTION, foxId(row), encode(row, given))
	mgr.optionalySave()
	Settings.changed()
	return true
static func clear(name:String, mgr = manager()) -> bool:
	if(mgr == null || rowFor(name).empty()):
		return false
	mgr.clearOption(SECTION, foxId(rowFor(name)))
	mgr.optionalySave()
	Settings.changed()
	return true
static func restoreDefaults(mgr = manager()) -> int:
	var cleared := 0
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name != "" && clear(name, mgr)):
			cleared += 1
	Boot.say("InsertionBulges 4: " + str(cleared) + " option(s) back to the recommended settings.")
	return cleared
static func declare(api, host = null) -> Array:
	var ids:Array = []
	if(api == null):
		Boot.loud("FoxLibOptions: FoxLib called onFoxLibModInit with no API object. NO OPTION IS" \
			+ " REGISTERED and the mod has no menu this run; it still draws.")
		return ids
	for row in OPTIONS:
		var id:String = foxId(row)
		var cat:String = str(row["cat"])
		var kind:String = str(row["type"])
		var made = null
		if(kind == T_BOOL):
			made = api.addBooleanOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				bool(shipped(row)))
		elif(kind == T_PERCENT):
			made = api.addSliderOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				percentOf(row))
		elif(kind == T_CHOICE):
			made = api.addListOptionInCategory(cat, id, str(row["title"]), row["values"],
				str(row["desc"]), str(shipped(row)))
		elif(kind == T_BUTTON):
			made = api.addButtonOptionInCategory(cat, id, str(row["title"]), str(row["desc"]))
			if(made != null && host != null && made.has_signal("option_changed")):
				made.connect("option_changed", host, "onRestoreDefaults")
		if(made == null):
			Boot.loud("FoxLibOptions: FoxLib answered nothing for option '" + id + "', so that one" \
				+ " row is not on the screen. The rest are. This is a FoxLib API change - re-read" \
				+ " FoxLib/FoxModuleAPI.gd.")
			continue
		elif(kind != T_BUTTON && host != null && made.has_signal("option_changed")):
			made.connect("option_changed", host, "onOptionChanged")
		if(bool(row.get("advanced", false))):
			made = made.advanced()
		ids.append(id)
	return ids
