const MARKERS := [
	"res://Player/Player3D/Bulge2/Driver.gd",
	"res://Player/Player3D/Bulge/BulgeDoll.gd",
	"res://Bulge3/Driver.gd",
]
const DECISION_META := "insertionbulges_v4_may_run"
const VERSION := "4.0"
static func blockedBy(paths:Array) -> Array:
	var found:Array = []
	var f := File.new()
	for path in paths:
		if(f.file_exists(path)):
			found.append(path)
	return found
static func mayRun(from:String = "?") -> bool:
	var tree = Engine.get_main_loop()
	if(tree == null || !(tree is SceneTree)):
		return blockedBy(MARKERS).empty()
	if(tree.has_meta(DECISION_META)):
		return bool(tree.get_meta(DECISION_META))
	var found:Array = blockedBy(MARKERS)
	tree.set_meta(DECISION_META, found.empty())
	if(!found.empty()):
		loud("REFUSING TO RUN: InsertionBulges 4 and an older InsertionBulges (1.x to 3.x) are mutually exclusive," \
			+ " and an older one is mounted (found " + PoolStringArray(found).join(", ") + ")." \
			+ " Unmount either pack and restart. 4.0 draws nothing this session; the older mod is" \
			+ " unaffected. [hook=" + from + "]")
	return found.empty()
static func loud(line:String) -> void:
	var text := "!!! InsertionBulges 4: " + line
	push_error(text)
	say(text)
static func say(text:String) -> void:
	print(text)
	var loop := Engine.get_main_loop()
	if(loop != null && loop.has_method("get_root")):
		var console = loop.get_root().get_node_or_null("Console")
		if(console != null && console.has_method("printLine")):
			console.printLine(text)
const MARKER_MOD := "InsertionBulges"
const BOOT_MAGIC := "bulge4-boot"
const BOOT_LINE_META := "insertionbulges_v4_boot_line"
static func bootLine() -> String:
	var integration:String = "refused"
	if(mayRun("bootLine")):
		integration = "live"
	return BOOT_MAGIC + " mod=" + VERSION + " integration=" + integration + " backend=none"
static func sayBootLineOnce() -> bool:
	var tree = Engine.get_main_loop()
	if(tree != null && tree is SceneTree):
		if(tree.has_meta(BOOT_LINE_META)):
			return false
		tree.set_meta(BOOT_LINE_META, true)
	say(bootLine())
	return true
