const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const DECLARED := {
"bulgeEffect": {
	"value": "detailed", "unit": "simple/medium/detailed", "owner": "Driver", "source": "PLANS/1-plan-4.0 decision 11",
	"note": "the drawing: a new id, so every player starts on Detailed (3.4's bulgePipeline is not read)",
},
"bulgeSizeModifier": {
	"value": 0.6, "unit": "0..1", "owner": "Simple, Medium", "source": "the published 3.4",
	"note": "how big Simple's and Medium's bumps are; Detailed: not yet (decision 12)",
},
"bulgeShapeFidelity": {
	"value": 0.8, "unit": "0..1", "owner": "Simple, Medium (Intent)", "source": "the published 3.4",
	"note": "how much the bump copies the cock's girth along it (Intent.shapeGain, normalisedShape)",
},
"bulgeLag": {
	"value": true, "unit": "on/off", "owner": "Medium (Spring)", "source": "the published 3.4",
	"note": "soft motion: each bump's size follows a damped spring, and fades out after the cock leaves",
},
"bulgePregnantBelly": {
	"value": true, "unit": "on/off", "owner": "Medium (Belly)", "source": "PLANS/1-plan-4.0 phase 6",
	"note": "3.4's bulgeBellyVariant swell (on) or off: a pregnant belly swells along the bump",
},
"bulgeOtherHalfAdd": {
	"value": 0.5, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "Knots and ridges: the facing half's own variation added on top, its bumps stand out more",
},
"bulgeLipAmount": {
	"value": 0.2, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "Opening at the hole: how far the skin at the entry opens round the shaft, a share of its girth there",
},
"bulgeDirection": {
	"value": "blend", "unit": "blend/shaft/belly/torso", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "which way the band runs: between hole and shaft, along the shaft, along the belly's edge, along the torso",
},
"bulgeLagDeflate": {
	"value": 0.25, "unit": "0..1 speed", "owner": "Medium (Spring)", "source": "the published 3.4",
	"note": "Settle speed: how fast a bump goes down again (soft motion)",
},
"bulgeTorsoArch": {
	"value": 0.5, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "a cock longer than the body: how much its extra length raises the bump's middle (0: it just stops)",
},
"bulgeOralSize": {
	"value": 0.6, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "Throat size: bulgeSizeModifier for the throat",
},
"bulgeOralSwallow": {
	"value": false, "unit": "on/off", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "a narrowing ring runs down the throat every few seconds while the cock rests deep",
},
"bulgesEnabled": {
	"value": true, "unit": "on/off", "owner": "PRESENT", "source": "PLANS/PIANO1",
	"note": "the mod's off switch",
},
"bulgeFollowBody": {
	"value": 0.7, "unit": "0..1", "owner": "PRESENT", "source": "PLANS/PIANO1 phase E",
	"note": "past the entry the cock turns to run along the penetrated body (lab bend): 0 straight",
},
"bulgeBelly": {
	"value": 1.0, "unit": "0..1", "owner": "PRESENT", "source": "PLANS/PIANO1 phase E",
	"note": "inside the body the cock runs toward the belly (lab belly): 0 the body's middle, 1 along the belly",
},
"bulgeStopAtNeck": {
	"value": true, "unit": "on/off", "owner": "PRESENT", "source": "PLANS/PIANO1 phase E",
	"note": "a cock longer than the torso bows outward against the neck instead of running out of it (lab stop_at_neck)",
},
"bulgeSkinShadeStrength": {
	"value": 0.6, "unit": "0..1", "owner": "PRESENT", "source": "RESEARCH/MeshMergeLab PLAN point 1",
	"note": "how visible that shade is (the lab harness's 60%; past 60% it gets darker faster, ~90% at 100%)",
},
"bulgeSkinShadeStyle": {
	"value": "soft", "unit": "none, or soft/filled/halo/xray, each also _outline", "owner": "PRESENT", "source": "RESEARCH/MeshMergeLab PLAN 8d; none: PLANS/1-plan-4.0 decision 4",
	"note": "the cock's shape seen through the skin, over the torso: none (no shade), soft (a soft dark inside, a light rim), filled (an even dark silhouette), halo (a blurred one), xray (the cock's own drawing, darkened); _outline adds the cock's drawn outline",
},
"bulgeSkinShadeOnTop": {
	"value": true, "unit": "on/off", "owner": "PRESENT", "source": "RESEARCH/MeshMergeLab PLAN 8c",
	"note": "the shade is drawn over everything (head, arms, legs, other dolls), not only over the torso",
},
}
const LAYER_GAME := "game option"
const LAYER_MOD := "mod setting"
const LAYER_DEFAULT := "compiled default"
const LAYER_NONE := "not a setting"
const LAYER_BENCH := "workbench overlay"
const OVERLAY := {}
const CACHE := {"loaded": false, "settings": {}, "asked": false, "fox": null}
const CHANGED := {"n": 0}
static func changed() -> void:
	var counter:Dictionary = CHANGED
	counter["n"] = int(counter["n"]) + 1
static func overlay(name:String, given) -> void:
	var o:Dictionary = OVERLAY
	o[name] = given
	changed()
static func gameOption(name:String) -> Array:
	if(OPTIONS == null || !(name in OPTIONS)):
		return [false, null]
	return [true, OPTIONS.get(name)]
static func declaration(name:String):
	return DECLARED.get(name)
static func compiled(name:String):
	if(DECLARED.has(name)):
		return DECLARED[name]["value"]
	return null
static func vetSetting(name:String, given) -> Array:
	var bad:Array = []
	if(!DECLARED.has(name)):
		bad.append("'" + name + "' is not one of this mod's settings (" \
			+ PoolStringArray(DECLARED.keys()).join(", ") + ")")
		return [bad, null]
	var declared = DECLARED[name]["value"]
	if(typeof(declared) == TYPE_REAL && typeof(given) == TYPE_INT):
		given = float(given)
	if(typeof(given) != typeof(declared)):
		bad.append("'" + name + "' wants " + typename(declared) + ", got " + typename(given))
		return [bad, null]
	return [bad, given]
static func typename(value) -> String:
	match typeof(value):
		TYPE_BOOL:
			return "a bool"
		TYPE_INT:
			return "an int"
		TYPE_REAL:
			return "a float"
		TYPE_STRING:
			return "a string"
	return "a value of type " + str(typeof(value))
const PATH := "user://bulge4_settings.json"
const FORMAT_VERSION := 1
const KEY_FORMAT := "format"
const KEY_SETTINGS := "settings"
const LEGAL_KEYS := [KEY_FORMAT, KEY_SETTINGS]
static func parse(text:String, where:String = PATH):
	var parsed:JSONParseResult = JSON.parse(text)
	if(parsed.error != OK):
		Boot.loud("Settings: " + where + " is not valid JSON - line " + str(parsed.error_line) + ": " \
			+ str(parsed.error_string) + ". NOTHING IS APPLIED and no setting is stored this run;" \
			+ " every setting falls back to the compiled default. Delete the file or" \
			+ " fix it - it is never partially read.")
		return null
	var doc = parsed.result
	var bad:PoolStringArray = PoolStringArray()
	if(typeof(doc) != TYPE_DICTIONARY):
		bad.append("the file is not a JSON object")
		return refuse(where, bad)
	for key in doc:
		if(!LEGAL_KEYS.has(key)):
			bad.append("unknown top-level key '" + str(key) + "' - legal keys are " \
				+ PoolStringArray(LEGAL_KEYS).join(", "))
	if(typeof(doc.get(KEY_FORMAT, null)) != TYPE_INT && typeof(doc.get(KEY_FORMAT, null)) != TYPE_REAL):
		bad.append("\"" + KEY_FORMAT + "\" is missing or is not a number - a settings file says which" \
			+ " build wrote it")
	elif(float(doc[KEY_FORMAT]) != float(FORMAT_VERSION)):
		bad.append("\"" + KEY_FORMAT + "\" is " + str(doc[KEY_FORMAT]) + " and this build reads " \
			+ str(FORMAT_VERSION))
	if(typeof(doc.get(KEY_SETTINGS, null)) != TYPE_DICTIONARY):
		bad.append("\"" + KEY_SETTINGS + "\" is missing or is not an object")
		return refuse(where, bad)
	var wanted:Dictionary = {}
	for name in doc[KEY_SETTINGS]:
		if(declaration(str(name)) == null):
			Boot.loud("Settings: " + where + " holds '" + str(name) + "', which this build has no" \
				+ " setting for. IGNORED; every other setting is read.")
			continue
		var vetted:Array = vetSetting(str(name), doc[KEY_SETTINGS][name])
		for complaint in vetted[0]:
			bad.append(str(complaint))
		if(vetted[0].empty()):
			wanted[str(name)] = vetted[1]
	if(!bad.empty()):
		return refuse(where, bad)
	return wanted
static func refuse(where:String, bad:PoolStringArray):
	Boot.loud("Settings: " + where + " REFUSED, NOTHING APPLIED - every setting falls back to the" \
		+ " compiled default this run. " + str(bad.size()) + " problem(s): " \
		+ bad.join("; ") + ". Delete the file or fix it; it is never partially read.")
	return null
static func loadFrom(path:String) -> Dictionary:
	var f := File.new()
	if(!f.file_exists(path)):
		return {}
	if(f.open(path, File.READ) != OK):
		Boot.loud("Settings: cannot open " + path + " for reading. Nothing applied; every setting" \
			+ " falls back to the compiled default this run.")
		return {}
	var text:String = f.get_as_text()
	f.close()
	var wanted = parse(text, path)
	if(wanted == null):
		return {}
	return wanted
const FOXLIB_PATH := "res://Modules/InsertionBulges/FoxLibOptions.gd"
static func foxLib():
	if(!CACHE["asked"]):
		CACHE["asked"] = true
		var adapter = load(FOXLIB_PATH)
		if(adapter != null && adapter.live()):
			CACHE["fox"] = adapter
	return CACHE["fox"]
static func liveStore(fox = foxLib()) -> String:
	if(fox != null):
		return str(fox.storeLabel())
	return PATH
static func stored(fox = foxLib()) -> Dictionary:
	if(fox != null):
		return fox.stored()
	if(!CACHE["loaded"]):
		CACHE["loaded"] = true
		CACHE["settings"] = loadFrom(PATH)
	return CACHE["settings"]
static func forget() -> void:
	CACHE["loaded"] = false
	CACHE["settings"] = {}
	changed()
static func write(settings:Dictionary, path:String = PATH) -> bool:
	var doc := {}
	doc[KEY_FORMAT] = FORMAT_VERSION
	doc[KEY_SETTINGS] = settings
	var f := File.new()
	if(f.open(path, File.WRITE) != OK):
		Boot.loud("Settings: cannot open " + path + " for writing. Nothing written and nothing" \
			+ " changed - the setting you just set is NOT saved and will not survive a restart.")
		return false
	f.store_string(JSON.print(doc, "  ", true))
	f.close()
	return true
static func store(name:String, given, fox = foxLib()) -> bool:
	var vetted:Array = vetSetting(name, given)
	if(!vetted[0].empty()):
		Boot.loud("Settings: '" + name + "' NOT stored, nothing changed and nothing written - " \
			+ PoolStringArray(vetted[0]).join("; ") + ".")
		return false
	if(fox != null):
		return fox.store(name, vetted[1])
	var next:Dictionary = stored(fox).duplicate()
	next[name] = vetted[1]
	if(!write(next)):
		return false
	CACHE["settings"] = next
	changed()
	return true
static func clear(name:String, fox = foxLib()) -> bool:
	if(fox != null):
		return fox.clear(name)
	var next:Dictionary = stored(fox).duplicate()
	if(!next.erase(name)):
		return false
	if(!write(next)):
		return false
	CACHE["settings"] = next
	changed()
	return true
static func resolve(name:String) -> Dictionary:
	if(declaration(name) == null):
		Boot.loud("Settings: no setting named '" + name + "'. Add it to DECLARED in" \
			+ " Modules/InsertionBulges/Settings.gd, or fix the name.")
		return row(name, null, LAYER_NONE, "no such setting")
	var asked:Array = gameOption(name)
	if(asked[0]):
		return row(name, asked[1], LAYER_GAME, "the game's own option")
	if(OVERLAY.has(name)):
		return row(name, OVERLAY[name], LAYER_BENCH, "the workbench")
	var mine:Dictionary = stored()
	if(mine.has(name)):
		return row(name, mine[name], LAYER_MOD, liveStore())
	return row(name, compiled(name), LAYER_DEFAULT, str(declaration(name)["source"]))
static func value(name:String):
	return resolve(name)["value"]
static func row(name:String, value_, layer:String, detail:String) -> Dictionary:
	return {"setting": name, "value": value_, "layer": layer, "detail": detail}
