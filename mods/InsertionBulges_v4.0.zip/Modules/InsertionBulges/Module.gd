extends Module
const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const FoxLibOptions := preload("res://Modules/InsertionBulges/FoxLibOptions.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
func _init():
	id = "InsertionBulges"
	author = "xrob1"
func preInit():
	var _printed:bool = Boot.sayBootLineOnce()
func onFoxLibModInit(foxModuleAPI):
	if(!Boot.mayRun("onFoxLibModInit")):
		return
	var _ids:Array = FoxLibOptions.declare(foxModuleAPI, self)
func onOptionChanged(_value):
	Settings.changed()
func onRestoreDefaults(_value = null):
	var _cleared:int = FoxLibOptions.restoreDefaults()
	onOptionChanged(null)
