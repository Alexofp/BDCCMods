extends Reference
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const Eyes := preload("res://Bulge4/Observe/Eyes.gd")
const PortalScenes := preload("res://Bulge4/Infer/PortalScenes.gd")
const META := "bdccBulge4FrameContext"
const META_SNAPSHOT := "bdccBulge4Snapshot"
const META_NOW := "bdccBulge4Now"
const HOLES := ["vagina", "anus", "mouth"]

static func of(stageScene, relations:Array) -> Dictionary:
	var frame:int = Engine.get_idle_frames()
	if(stageScene.has_meta(META)):
		var kept:Array = stageScene.get_meta(META)
		if(int(kept[0]) == frame):
			return kept[1]
	var eyes = Eyes.new(stageScene)
	var context:Dictionary = {"frame": frame, "eyes": eyes, "scene_path": null, "participants": [],
		"shafts": {}, "holes": {}, "props": {}}
	if(stageScene.has_meta(META_SNAPSHOT)):
		var snapshot:Dictionary = stageScene.get_meta(META_SNAPSHOT)
		context["scene_path"] = snapshot.get("scene_path")
		context["participants"] = snapshot.get("participants", [])
	for r in relations:
		var shaft = r["shaft"]
		if(!context["shafts"].has(shaft)):
			context["shafts"][shaft] = Snapshot.shaftCardOf(eyes, shaft)
		var owner = r["hole_owner"]
		if(!context["holes"].has(owner)):
			var holes:Dictionary = {}
			for holeID in HOLES:
				holes[holeID] = eyes.holeOf(owner, holeID)
			context["holes"][owner] = holes
	var path = context["scene_path"]
	if(typeof(path) == TYPE_STRING && PortalScenes.TABLE.has(path) && PortalScenes.TABLE[path].has("portal")):
		var owner:String = str(PortalScenes.TABLE[path]["portal"]["owner"])
		context["props"][owner] = eyes.propsOf(owner)
	stageScene.set_meta(META, [frame, context])
	return context
