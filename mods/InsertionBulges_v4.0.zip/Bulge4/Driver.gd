extends Reference
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const SnapReplayer := preload("res://Bulge4/Infer/SnapReplayer.gd")
const Ladder := preload("res://Bulge4/Infer/Ladder.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const EFFECTS := {"simple": "res://Bulge4/Effects/Simple/Simple.gd", "medium": "res://Bulge4/Effects/Medium/Medium.gd",
	"detailed": "res://Bulge4/Effects/Detailed/RubberSkin.gd"}
const DEFAULT_EFFECT := "detailed"
const LOADED := {}
const TUNING := {"seen": -1, "on": true, "effect": DEFAULT_EFFECT, "opts": {}}
static func readSettings() -> void:
	var tuning:Dictionary = TUNING
	if(int(tuning["seen"]) == int(Settings.CHANGED["n"])):
		return
	tuning["seen"] = int(Settings.CHANGED["n"])
	tuning["on"] = bool(Settings.value("bulgesEnabled"))
	var effect:String = str(Settings.value("bulgeEffect"))
	if(!EFFECTS.has(effect)):
		effect = DEFAULT_EFFECT
	tuning["effect"] = effect
	var shade:float = 0.0
	if(str(Settings.value("bulgeSkinShadeStyle")) != "none"):
		shade = float(Settings.value("bulgeSkinShadeStrength"))
	tuning["opts"] = {"bend": float(Settings.value("bulgeFollowBody")), "belly": float(Settings.value("bulgeBelly")),
		"stop_at_neck": bool(Settings.value("bulgeStopAtNeck")), "shade_strength": shade,
		"shade_style": str(Settings.value("bulgeSkinShadeStyle")), "shade_on_top": bool(Settings.value("bulgeSkinShadeOnTop"))}
static func effectScript(name:String):
	var loaded:Dictionary = LOADED
	if(!loaded.has(name)):
		loaded[name] = load(str(EFFECTS[name]))
	return loaded[name]
const META_FRAME := "bdccBulge4Frame"
const META_REPORT := "bdccBulge4Report"
const META_POSE := "bdccBulge4Pose"
const META_POSE_SINCE := "bdccBulge4PoseSince"
const META_ITEMS := "bdccBulge4Items"
const META_KEPT := "bdccBulge4Kept"
const META_EFFECT := "bdccBulge4Effect"
const REFRESH := {"frames": 6}
const HELD_CONFIDENCE := -1
const FRAME_CLOCK := {"fps": 0}
static func tick(stageScene, frame:int, now:float):
	if(stageScene == null || !is_instance_valid(stageScene)):
		return null
	if(int(FRAME_CLOCK["fps"]) > 0):
		now = float(frame) / float(FRAME_CLOCK["fps"])
	if(!Boot.mayRun("Bulge4/Driver.tick")):
		return null
	if(stageScene.has_meta(META_FRAME) && stageScene.get_meta(META_FRAME) == frame):
		if(stageScene.has_meta(META_REPORT)):
			return stageScene.get_meta(META_REPORT)
		return null
	stageScene.set_meta(META_FRAME, frame)
	stageScene.set_meta(META_REPORT, null)
	stageScene.set_meta(Frame.META_NOW, now)
	readSettings()
	var effect:String = str(TUNING["effect"])
	if(!bool(TUNING["on"])):
		effect = ""
	var drawn:String = ""
	if(stageScene.has_meta(META_EFFECT)):
		drawn = str(stageScene.get_meta(META_EFFECT))
	if(drawn != effect):
		if(drawn != ""):
			effectScript(drawn).restoreAll(stageScene)
		stageScene.set_meta(META_EFFECT, effect)
	if(effect == ""):
		stageScene.remove_meta(META_KEPT)
		return null
	var script = effectScript(effect)
	var poseID = stageScene.get("currentAnim")
	var pose:String = ""
	if(poseID != null):
		pose = str(poseID)
	var age:float = ageOf(stageScene, pose, now)
	var key:Array = [pose, dollKey(stageScene)]
	var kept = null
	if(stageScene.has_meta(META_KEPT)):
		kept = stageScene.get_meta(META_KEPT)
	if(kept == null || kept[1] != key || frame - int(kept[0]) >= int(REFRESH["frames"]) || frame < int(kept[0])):
		var snapshot = Snapshot.build(stageScene, pose)
		if(typeof(snapshot) != TYPE_DICTIONARY):
			stageScene.remove_meta(META_KEPT)
			script.restoreAll(stageScene)
			return null
		var inferred:Dictionary = SnapReplayer.infer(snapshot, age)
		stageScene.set_meta(META_ITEMS, inferred["items"])
		stageScene.set_meta(Frame.META_SNAPSHOT, snapshot)
		var fused:Dictionary = Ladder.fuse(snapshot, inferred["items"], [])
		if(kept != null && kept[1] == key):
			var participants:Dictionary = Ladder.participantsOf(snapshot)
			for old in kept[2]["relations"]:
				var held:Dictionary = old.duplicate()
				held["confidence"] = HELD_CONFIDENCE
				Ladder.claim(fused, participants, held)
		kept = [frame, key, fused, inferred["notes"]]
		stageScene.set_meta(META_KEPT, kept)
	var table:Dictionary = kept[2]
	var report:Dictionary = {
		"pose": pose,
		"effect": effect,
		"relations": table["relations"],
		"problems": table["problems"],
		"notes": kept[3],
		"skins": script.run(stageScene, table["relations"], TUNING["opts"]),
	}
	stageScene.set_meta(META_REPORT, report)
	return report
static func dollKey(stageScene) -> Array:
	var ids:Array = []
	for doll in stageScene.getDolls():
		if(doll != null && is_instance_valid(doll)):
			ids.append(doll.get_instance_id())
		else:
			ids.append(0)
	return ids
static func ageOf(stageScene, pose:String, now:float) -> float:
	if(!stageScene.has_meta(META_POSE) || str(stageScene.get_meta(META_POSE)) != pose):
		stageScene.set_meta(META_POSE, pose)
		stageScene.set_meta(META_POSE_SINCE, now)
	return now - float(stageScene.get_meta(META_POSE_SINCE))
