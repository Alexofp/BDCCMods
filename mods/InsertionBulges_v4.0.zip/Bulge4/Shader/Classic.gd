extends Reference
const Inject := preload("res://Bulge4/Shader/Inject.gd")
const KEY := "classic"
const META := "bulge4_classic"

static func shaderFor(source:Shader):
	if(source.has_meta(META)):
		var kept = source.get_meta(META)
		if(kept is Shader):
			return kept
		return null
	var made = Inject.shaderFor(source, KEY, partsFor(source.code))
	if(made == null):
		source.set_meta(META, false)
	else:
		source.set_meta(META, made)
	return made

static func partsFor(code:String) -> Dictionary:
	var parts:Dictionary = {"head": HEAD, "vertex_end": VERTEX_END, "fragment_top": FRAGMENT_TOP,
		"uv": "(UV - bulge_offset)", "fragment_end": FRAGMENT_END}
	if(hasWord(code, "UV_pattern") && hasWord(code, "pattern_size")):
		parts["extra"] = {"UV_pattern": "(UV_pattern - bulge_offset * pattern_size)"}
	if(hasWord(code, "texture_albedo")):
		parts["fragment_end"] = FRAGMENT_END + SKIRT_OVER_BODY
	parts["fragment_end"] += SHAFT_CLIP
	return parts

static func hasWord(code:String, word:String) -> bool:
	var re := RegEx.new()
	var _ok = re.compile("\\b" + word + "\\b")
	return re.search(code) != null

const HEAD := """
// Insertion bulges. One per orifice, so a body taken in all three at once keeps every swelling:
// with fewer slots than holes the losing penetration changes from frame to frame, because the
// slots are ranked globally by depth, and its bulge jumps between holes instead of staying put.
// The bulge is a swelling of the receiver's own FRONT CONTOUR (belly, chest, throat), not a
// lump wrapped around the shaft: the contour is pushed outwards over a limited height, and
// how far up that height sits follows insertion depth.
// The band's own direction now comes from the shaft's line in the receiver's rest space, so
// a cock angled steeply and one angled shallowly displace different parts of the belly; the
// SHAPE is still the body's, which is the half of the decoupling that stands.
// The push only grows along the outward direction through a ramp gentler than 1:1, so the
// map cannot fold. Two earlier attempts are worth not repeating: a radial pull folds the
// body onto itself as soon as it is strong enough to hide an oversized shaft, and painting
// the lump into the cutout's transparent margin looks like a sticker.
// bulge_segN: xy = bump centre (UV), zw = a point one step towards the body's front, so
//             normalize(zw - xy) is the outward direction of the contour that bulges
// bulge_parN: x = falloff height of the bump (world units), y = how far the contour moves out
//             (world units), z = shading amount, w = half length of the swollen stretch, so
//             the contour stays pushed out all the way from the hole to the tip instead of
//             only at the tip
// bulge_shpN / bulge_shpNb: the shaft's own thickness across the band, seven samples base to tip -
//             three in shpN.xyz and four in shpNb - plus, in shpN.w, how far behind the skin the
//             shaft's own line runs, which is what lets the rim be shaded where the cock is rather
//             than around the band. Seven and not eight because of that w.
//             WHICH WAY ROUND IS NOT SENT. The writer turns the samples over instead, where both UV
//             points are in hand, so these always read base to tip from here. An older comment here
//             claimed the sign travelled in w and another claimed w was free; both were stale.
//             Defaulted to a flat shaft, never to zeros - a slot nobody has written to yet has to
//             draw what it drew before this existed, and a zero thickness is a different statement
//             and a visible one.
uniform vec4 bulge_seg0;
uniform vec4 bulge_par0;
uniform vec4 bulge_shp0 = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_shp0b = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_seg1;
uniform vec4 bulge_par1;
uniform vec4 bulge_shp1 = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_shp1b = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_seg2;
uniform vec4 bulge_par2;
uniform vec4 bulge_shp2 = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_shp2b = vec4(1.0, 1.0, 1.0, 1.0);
// PLANS/34: 1 where a slot's swelling may bend round the shaft (the crotch), 0 for the throat.
uniform float bulge_radial_on0 = 1.0;
uniform float bulge_radial_on1 = 1.0;
uniform float bulge_radial_on2 = 1.0;
// How much of the shaft's own shape the swelling takes. 0 leaves it out entirely and draws the hump
// this mod drew before phase 3; 1 is the literal silhouette, which on a real belly is too much
// because there is tissue in between. This default must equal BulgeUtils.SHAPE_FIDELITY_DEFAULT -
// GLSL cannot read a GDScript const, so the two are written twice and a check compares them. The
// writer sets this every frame anyway; the default is what a mesh nobody has written to yet draws.
uniform float bulge_shape_fidelity = 0.55;
// How the rim is shaped. 0 is the ramp this mod always drew, whose 0.5 contour - the line the rim
// is painted on - is a straight line at half the ramp's depth running the whole length of the band,
// and which reads on a thigh as a ruled line with no anatomy behind it. 1 shades a section of the
// shaft instead, so that contour follows the cock under the skin. This one only ever touches
// COLOUR: the push is unchanged either way, so none of it can fold the map the way the
// displacement can.
uniform float bulge_rim_shape = 1.0;
uniform float bulge_push_radial = 0.0;
// PLANS/34: Field.pushDirection. 0 pushes every point the same way, 1 away from the shaft's line.
vec2 pushDirection(vec2 outward, float along, float across, float halfBand, float axisDepth, float amount) {
	if(amount <= 0.0) {
		return outward;
	}
	float beyond = sign(across) * max(abs(across) - halfBand, 0.0);
	// Never inward: below the shaft's line the direction would flip and tear the skin at the line.
	vec2 radialDir = outward * max(along + axisDepth, max(axisDepth, 0.0001)) + vec2(-outward.y, outward.x) * beyond;
	if(length(radialDir) <= 0.0001) {
		return outward;
	}
	vec2 mixed = mix(outward, normalize(radialDir), amount);
	if(length(mixed) <= 0.0001) {
		return outward;
	}
	return normalize(mixed);
}
uniform vec2 bulge_aspect = vec2(1.0, 1.0); // multiplies UV to get world-ish units, so radii stay isotropic
// option 2: per slot, 0 or 1. A belly is held by the spine so only its front moves, but a throat
// has no spine to hold it, so both sides of the neck swelled and its own axis stayed put.
//uniform vec2 bulge_symmetric;
// 1 on the body cutout, whose mesh was given a skirt of geometry with UVs running past 0..1.
// Only that mesh may have its out-of-range samples blanked; on a part with tiled UVs the same
// test would erase the artwork.
uniform float bulge_expanded = 0.0;

// Medium's BAKED FIELD (3.4's H6), fed in instead of computed here. The bake shader runs this
// file's own `bulgeField` over a slot TEXTURE rather than three uniform sets (no three-slot cap) and
// renders the composition into one RGBA float target: `COLOR = vec4(offset, field, shade)`, so
// xy is the UV offset, z is the field and w is the shade, each meaning exactly what the local of the
// same name below means: the bake composes field as `max(.w)` and shade as `max(.w * par.z)`
// across its rows, which is what the two `max` lines in fragment() do across the three slots.
// bulge_baked_on defaults to 0.0: Simple (the three uniform slots) draws as if the bake did not exist.
uniform sampler2D bulge_baked;
uniform float bulge_baked_on = 0.0;
// PLANS/61 (trial, Big bulges: Mesh): the bake carries the forward push, and vertex() moves the
// body's own points by it (UV to the mesh's rest plane through bulge_rest_du / _dv, the inverse of
// the UV fit); the pixels are then read where they are, not warped.
uniform float bulge_mesh_on = 0.0;
uniform vec2 bulge_rest_du = vec2(0.0);
uniform vec2 bulge_rest_dv = vec2(0.0);

// Hides the part of a shaft that is inside somebody. shaft_clip is a threshold on UV.x,
// values >= 1.5 disable it. shaft_clip_dir picks which side of the threshold gets hidden.
uniform float shaft_clip = 2.0;
uniform float shaft_clip_dir = -1.0;
uniform float shaft_clip_feather = 0.008;

// 1 on the margin skirt, 0 on the body (vertex alpha, BulgeUtils.buildExpandedMesh; a mesh with no
// colours reads white, so 0). The skirt is skinned with its edge's weights, so where it lies over the body
// it drew a shifted second copy of the skin once bones moved: it is only drawn over empty space.
varying float bulge_skirt;

// Returns vec4(uvOffset.xy, weight, unused). The offset points out of the body, so sampling
// at uv - offset drags the skin (silhouette included) outwards.
// Seven samples across six segments, no branch and no array index. Each blend is inert until u
// reaches its segment, because its weight is 0 until then, so this is exactly the piecewise curve
// it looks like.
//
// SMOOTHSTEP PER SEGMENT and not straight lines. Straight lines were what this drew first, and at
// full fidelity they put five visible creases across the belly - a piecewise line is continuous but
// its SLOPE jumps at every sample, and a slope that jumps on a lit surface reads as a step. Turning
// the knob down to about 0.55 hid them, but only by scaling the whole shape towards flat, which is
// paying for the fix with the effect.
//
// Why this curve and not a fitted one. The bound the whole phase rests on is that the shape's peak
// is exactly 1.0, because the renderer sizes the push by the peak and clamps that push to keep the
// warp injective. A Catmull-Rom or any curve fitted THROUGH the samples can rise above all of them
// between two, which breaks that bound and folds the body - on some shafts, at some depths, which
// is the worst way to find out. smoothstep cannot: it is monotone from 0 to 1, so each segment stays
// between its own two endpoints and the whole curve stays inside the samples' own range. Smooth and
// bounded, where a fitted curve is smooth and not.
//
// The cost is a flat spot at each sample, since smoothstep has zero slope at both ends. On seven
// samples across a belly that reads as an organic undulation rather than as a fault.
//
// NOT COVERED BY A CHECK, and said so rather than left to be assumed: this is shader code and the
// suite has no way to run it. What the suite does hold is the renderer's half - that the shape it
// hands over is normalised to a peak of exactly 1.0 - and the argument above is why that peak is
// still the curve's peak once this has interpolated it.
float shapeAt(vec4 a, vec4 b, float u) {
	float f = clamp(u, 0.0, 1.0) * 6.0;
	float r = mix(a.x, a.y, smoothstep(0.0, 1.0, clamp(f, 0.0, 1.0)));
	r = mix(r, a.z, smoothstep(0.0, 1.0, clamp(f - 1.0, 0.0, 1.0)));
	r = mix(r, b.x, smoothstep(0.0, 1.0, clamp(f - 2.0, 0.0, 1.0)));
	r = mix(r, b.y, smoothstep(0.0, 1.0, clamp(f - 3.0, 0.0, 1.0)));
	r = mix(r, b.z, smoothstep(0.0, 1.0, clamp(f - 4.0, 0.0, 1.0)));
	r = mix(r, b.w, smoothstep(0.0, 1.0, clamp(f - 5.0, 0.0, 1.0)));
	return r;
}

// Field.bandPlateau (PLANS/8, PLANS/37): the player's bulgeTipRound, written by MeshWithPattern.setBulge.
uniform float bulge_band_plateau = 0.25;
// Field.gd UNION_OVERLAP (PLANS/16): the player's bulgeUnionOverlap, written by MeshWithPattern.setBulge.
uniform float bulge_union_overlap = 0.3;

vec4 bulgeField(vec2 uv, vec4 seg, vec4 par, vec4 shp, vec4 shp2, float radialOn) { // option 2 took a symmetric flag here
	if(par.x <= 0.0001 || par.y <= 0.0001) {
		return vec4(0.0);
	}
	vec2 p = uv * bulge_aspect;
	vec2 c = seg.xy * bulge_aspect;
	// The second point carries both the outward direction and how deep into the body the push
	// is allowed to reach. That depth belongs to the body, not to the shaft: tying it to the
	// shaft's girth made a big cock drag the far side of the body forwards as well.
	vec2 reach = seg.zw * bulge_aspect - c;
	float ramp = max(length(reach), 0.0001);
	vec2 outward = reach / ramp;
	vec2 rel = p - c;
	float along = dot(rel, outward);                        // + = towards the front contour
	float across = dot(rel, vec2(-outward.y, outward.x));   // along the contour

	// The swelling holds at full strength over the inserted stretch (par.w each way from the
	// centre) and only then falls off, which is what keeps the body full behind the tip.
	// Zero slope at the ends so it blends in instead of finishing on a visible line.
	// PLANS/8: only BAND_PLATEAU of the stretch is flat, the rest joins the falloff - same total
	// length, a dome and not a slab (a flat plateau drew a straight-edged block on the outline).
	// ANCHORED AT THE ENTRY: across < 0 is the entry end (u = 0), which keeps the full plateau, so the
	// swelling always starts at the hole; only the tip end is rounded.
	float plateau = across < 0.0 ? par.w : par.w * bulge_band_plateau;
	float h = clamp(1.0 - max(abs(across) - plateau, 0.0) / (par.x + par.w - plateau), 0.0, 1.0);
	h = h * h * (3.0 - 2.0 * h);
	// And then by the shaft's own thickness at this point of it. par.w is the inserted stretch's
	// half length and across is the distance along it from the middle, so u runs 0 at one end to 1
	// at the other for free - the band was already built in exactly those terms.
	float u = clamp(0.5 + across / max(2.0 * par.w, 0.0001), 0.0, 1.0);
	// Which end is the tip was settled by the writer, which turned the samples round if it had to:
	// only there are both UV points in hand. So these read base to tip from here.
	// See shapeAt for why the interpolation is smoothstepped rather than straight, and why a curve
	// fitted through the samples is not an option however much better it would follow them.
	float profile = shapeAt(shp, shp2, u);
	h = h * mix(1.0, profile, bulge_shape_fidelity);
	// Everything from the centre plane outwards moves by the full amount, the interior eases
	// in over the ramp. smoothstep's slope peaks at 1.5/ramp, so the warp stays injective only
	// while the push stays under ramp/1.5, which is the bound the solver clamps to.
	float g = smoothstep(-ramp, 0.0, along);
	vec2 push = pushDirection(outward, along, across, par.w, shp.w, bulge_push_radial * radialOn);
	// option 2: the same ramp read from the centre outwards both ways, so the axis held still and
	// each surface moved away from it. Peak slope is unchanged, so the bound above still held.
	//if(symmetric > 0.5) {
	//	g = smoothstep(0.0, ramp, abs(along));
	//	push = outward * sign(along);
	//}

	float weight = h * g;

	// The shading field, which is no longer the same thing as the pushing one.
	//
	// A section of the shaft rather than a ramp: half thickness r at this point along it, and an
	// axis placed so the tube's outer edge lands on the skin the push put there - par.y out - for
	// every profile, thick or thin. Then the bright core runs down the shaft's centre line and the
	// rim darkens towards both of its edges, which is a cylinder seen head on.
	//
	// profile is 1.0 with nothing measured, so an unreadable shaft is a plain cylinder rather than
	// nothing at all, and the throat - which is handed no shape on purpose - gets one too.
	// w is how far behind the skin the shaft's line runs. The tube is centred THERE and reaches out
	// to the skin the push put at +par.y, so the bright core follows the cock and the rim darkens
	// towards its edges. Centred on the band instead - which is what this did first - it comes out
	// parallel to the shaft and beside it, because the band is on the body's surface and the shaft
	// is under it, and those two are apart by construction.
	float axis = -shp.w;
	float r = max(shp.w + par.y, 0.0001);
	float tube = clamp(1.0 - abs(along - axis) / r, 0.0, 1.0);
	// Along the band it keeps the same envelope, so both ends still fade rather than finishing on
	// an edge. At 0 this is weight exactly, which is what makes the old look reachable.
	float lit = mix(weight, h * tube, bulge_rim_shape);
	return vec4(push * (par.y * weight) / bulge_aspect, weight, lit);
}
"""

const VERTEX_END := """
	bulge_skirt = 1.0 - COLOR.a;
	if(bulge_mesh_on > 0.5 && bulge_baked_on > 0.5) {
		vec2 moved = textureLod(bulge_baked, vec2(clamp(UV.x, 0.0, 1.0), 1.0 - clamp(UV.y, 0.0, 1.0)), 0.0).xy;
		VERTEX.xy += bulge_rest_du * moved.x + bulge_rest_dv * moved.y;
	}
"""

const FRAGMENT_TOP := """

	// Push the front contour out. Sampling further inside the body drags the skin, and with
	// it the alpha edge, outwards: the cutouts have plenty of margin geometry for that.
	vec4 bulge0 = bulgeField(UV, bulge_seg0, bulge_par0, bulge_shp0, bulge_shp0b, bulge_radial_on0);
	vec4 bulge1 = bulgeField(UV, bulge_seg1, bulge_par1, bulge_shp1, bulge_shp1b, bulge_radial_on1);
	vec4 bulge2 = bulgeField(UV, bulge_seg2, bulge_par2, bulge_shp2, bulge_shp2b, bulge_radial_on2);
	// The offsets add up, the fields do not: two slots pushing the same patch of skin have to move
	// it twice as far, but the rim shading is one surface effect and would double into a black
	// smudge. Each field is weighted by its OWN slot's shading amount before the max, because
	// par.z belongs to the slot: taking max(field) and then scaling would let a strongly shaded
	// slot lend its darkness to a shallower one that never asked for any.
	// ponytail: summed offsets, unclamped. bulgeField's own bound is that the warp stays injective
	// only while the push stays under ramp/1.5, and that is enforced per slot, not on the sum. Two
	// deep penetrations could already cross it; three make it easier, so three deep at once may
	// smear rather than swell. Nobody has measured it. Upgrade path when it shows on screen: clamp
	// the length of bulge_offset to the smallest ramp/1.5 among the contributing slots.
	vec2 bulge_offset = bulge0.xy + bulge1.xy + bulge2.xy;
	// PLANS/16: a union, not a sum - Field.unionOf line for line. One slot alone moves the skin as
	// before; overlapping ones move it by the biggest push plus UNION_OVERLAP of the rest.
	float pushSum = length(bulge0.xy) + length(bulge1.xy) + length(bulge2.xy);
	float pushMost = max(max(length(bulge0.xy), length(bulge1.xy)), length(bulge2.xy));
	if(pushSum > 0.0) {
		bulge_offset *= (pushMost + bulge_union_overlap * (pushSum - pushMost)) / pushSum;
	}
	// w, not z: z is what moved the skin and w is what colours it. They were one number until the
	// rim's straight line turned out to be the ramp's own 0.5 contour and nothing else.
	float bulge_field = max(max(bulge0.w, bulge1.w), bulge2.w);
	float bulge_shade = max(max(bulge0.w * bulge_par0.z, bulge1.w * bulge_par1.z), bulge2.w * bulge_par2.z);
	// Medium: ONE fetch replaces the three calls above, same three numbers with the same meanings,
	// read at the raw UV (the original fragment() below reads UV - bulge_offset).
	// ponytail: the three bulgeField calls above still run when this is on and their results are
	// thrown away (kept as 3.4 drew it, pixel for pixel, the Inject check). Cost near zero: Medium leaves
	// bulge_par0/1/2 at 0 and bulgeField returns on its first test. Upgrade path: an if/else around them.
	if(bulge_baked_on > 0.5) {
		// V IS FLIPPED ON THE WAY IN, and that is the platform and not a preference. A render
		// target is stored bottom row first, so `texture(target, vec2(u, 0.0))` reads the BOTTOM of
		// what was drawn while canvas v = 0 is the TOP (3.4 measured it: a viewport drawing the ramp
		// `UV.y` reads 0.02 at its top row and 0.98 at its bottom).
		// WITHOUT THIS LINE EVERY BAKED BULGE IS DRAWN AT 1 - v OF WHERE THE SLOT PUT IT, which on
		// a body is somewhere else entirely and reads as the bake doing nothing at all.
		vec4 baked = texture(bulge_baked, vec2(UV.x, 1.0 - UV.y));
		bulge_offset = baked.xy;
		bulge_field = baked.z;
		bulge_shade = baked.w;
	}
	if(bulge_mesh_on > 0.5) {
		bulge_offset = vec2(0.0);
	}
"""

const FRAGMENT_END := """
	// The dolls are unshaded flat art, so the lump has to be painted on: a dark ring where
	// the skin curves away plus a lighter top where it faces the camera.
	if(bulge_shade > 0.001) {
		float rim = clamp(bulge_field * (1.0 - bulge_field) * 4.0, 0.0, 1.0);
		float core = smoothstep(0.55, 1.0, bulge_field);
		float shadeAmount = clamp(bulge_shade, 0.0, 1.5);
		ALBEDO *= mix(1.0, 0.78, rim * shadeAmount);
		ALBEDO *= mix(1.0, 1.13, core * shadeAmount);
	}
	// Anything sampling past the edge of the texture is the margin skirt: draw it as empty
	// rather than as smeared edge pixels. This is what gives a bulge room to grow into. Only on
	// the mesh that actually got a skirt, since a part with tiled UVs is legitimately outside.
	vec2 bulge_uv = UV - bulge_offset;
	if(bulge_expanded > 0.5 && (bulge_uv.x < 0.0 || bulge_uv.x > 1.0 || bulge_uv.y < 0.0 || bulge_uv.y > 1.0)) {
		ALPHA = 0.0;
	}
"""

const SKIRT_OVER_BODY := """
	// A skirt pixel draws only over empty space: where the unwarped skin at its own UV is already body,
	// the body's own triangle draws it (warped or not) and the skirt's copy would sit shifted on top.
	if(bulge_expanded > 0.5 && bulge_skirt > 0.001 && UV.x >= 0.0 && UV.x <= 1.0 && UV.y >= 0.0 && UV.y <= 1.0
			&& texture(texture_albedo, UV).a > 0.02) {
		ALPHA = 0.0;
	}
"""

const SHAFT_CLIP := """
	// Hide the inserted part of a shaft instead of letting it draw over the body it is in.
	if(shaft_clip < 1.5) {
		float clipDistance = (UV.x - shaft_clip) * shaft_clip_dir;
		ALPHA *= 1.0 - smoothstep(-shaft_clip_feather, shaft_clip_feather, clipDistance);
	}
"""
