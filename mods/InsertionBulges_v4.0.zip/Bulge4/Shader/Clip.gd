extends Reference
const Inject := preload("res://Bulge4/Shader/Inject.gd")
const Classic := preload("res://Bulge4/Shader/Classic.gd")
const KEY := "clip"
const HEAD := """
// Hides the part of a shaft that is inside somebody. shaft_clip is a threshold on UV.x,
// values >= 1.5 disable it. shaft_clip_dir picks which side of the threshold gets hidden.
uniform float shaft_clip = 2.0;
uniform float shaft_clip_dir = -1.0;
uniform float shaft_clip_feather = 0.008;
"""

static func shaderFor(source:Shader):
	return Inject.shaderFor(source, KEY, {"head": HEAD, "fragment_end": Classic.SHAFT_CLIP})
