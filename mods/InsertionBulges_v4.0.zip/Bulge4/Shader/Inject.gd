extends Reference

const CACHE := {}

static func shaderFor(source:Shader, key:String, parts:Dictionary):
	var cache:Dictionary = CACHE
	var id:String = key + "\n" + source.code
	if(!cache.has(id)):
		cache[id] = null
		var code:String = inject(source.code, parts)
		if(code != ""):
			var made := Shader.new()
			made.code = code
			cache[id] = made
	return cache[id]

static func inject(code:String, parts:Dictionary) -> String:
	var frag:Array = bodyOf(code, "fragment")
	if(frag.empty()):
		return ""
	var body:String = code.substr(frag[0], frag[1] - frag[0])
	var word := RegEx.new()
	if(parts.has("uv")):
		var _uv = word.compile("\\bUV\\b")
		body = word.sub(body, str(parts["uv"]), true)
	var extra:Dictionary = parts.get("extra", {})
	for key in extra:
		var _word = word.compile("\\b" + str(key) + "\\b")
		body = word.sub(body, str(extra[key]), true)
	code = code.substr(0, frag[0]) + "\n" + str(parts.get("fragment_top", "")) + body \
		+ "\n" + str(parts.get("fragment_end", "")) + "\n" + code.substr(frag[1])
	var head:String = str(parts.get("head", ""))
	var vert:Array = bodyOf(code, "vertex")
	if(!vert.empty()):
		code = code.substr(0, vert[1]) + "\n" + str(parts.get("vertex_end", "")) + "\n" + code.substr(vert[1])
	elif(parts.has("vertex_end")):
		head += "\nvoid vertex() {\n" + str(parts["vertex_end"]) + "\n}\n"
	var first := RegEx.new()
	var _first = first.compile("(?m)^[ \\t]*(?:(?:highp|mediump|lowp)\\s+)?(void|float|u?int|bool|[biu]?vec[234]|mat[234])\\s+\\w+\\s*\\(")
	var found = first.search(code)
	var at:int = code.length()
	if(found != null):
		at = found.get_start()
	return code.substr(0, at) + head + "\n" + code.substr(at)

static func bodyOf(code:String, name:String) -> Array:
	var re := RegEx.new()
	var _ok = re.compile("void\\s+" + name + "\\s*\\(\\s*\\)\\s*\\{")
	var found = re.search(code)
	if(found == null):
		return []
	var open:int = found.get_end()
	var depth:int = 1
	var close:int = open
	var n:int = code.length()
	while(close < n && depth > 0):
		var ch:String = code[close]
		if(ch == "/" && close + 1 < n && code[close + 1] == "/"):
			var eol:int = code.find("\n", close)
			if(eol < 0):
				eol = n
			close = eol
			continue
		if(ch == "/" && close + 1 < n && code[close + 1] == "*"):
			var end:int = code.find("*/", close + 2)
			if(end < 0):
				end = n - 2
			close = end + 2
			continue
		if(ch == "{"):
			depth += 1
		elif(ch == "}"):
			depth -= 1
		close += 1
	return [open, close - 1]
