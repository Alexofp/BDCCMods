extends Reference
const BodyDeform := preload("res://Bulge4/Effects/Detailed/Lab/BodyDeform.gd")
const BodyShape := preload("res://Bulge4/Effects/Detailed/Lab/BodyShape.gd")
const BodyPose := preload("res://Bulge4/Effects/Detailed/Lab/BodyPose.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const Eyes := preload("res://Bulge4/Observe/Eyes.gd")
const PropShaft := preload("res://Bulge4/Effects/Detailed/PropShaft.gd")
const PortalScenes := preload("res://Bulge4/Infer/PortalScenes.gd")
const HOLES := ["vagina", "anus", "mouth"]
const SHAFT_BONE := "Penis"
const COVER := 1.0
const LOCK := true
const OPTS := {"backend": "auto", "shader_extra": {"UV_pattern": "(UV_pattern + bulge_d * pattern_size)"}, "posed_build": true}
const BENCH := {}
const META_STATE := "ib36Skin"
const SHADE_Z := 0.001
const META_SHAPE := "ib36ShaftShape"
const COCK_OFF := ["limp", "caged"]
const META_WEIGHTS := "ib36Weights"
const META_PORTAL := "bulge4PortalDeepest"
const WEIGHT_CELLS := 48

static func run(stageScene, relations:Array, opts:Dictionary = {}) -> Array:
	var o:Dictionary = OPTS.duplicate()
	for key in opts:
		o[key] = opts[key]
	for key in BENCH:
		o[key] = BENCH[key]
	var rows:Array = []
	var dolls:Array = stageScene.getDolls()
	var wanted:Dictionary = {}
	var props:Array = []
	for r in relations:
		if(!HOLES.has(str(r["hole"]))):
			continue
		var owner:int = dollIndex(str(r["hole_owner"]))
		var by:int = dollIndex(str(r["shaft"]))
		if(by < 0 && propIndex(str(r["shaft"])) >= 0 && props.empty()):
			props = Eyes.propsIn(stageScene)
		if(owner < 0 || owner >= dolls.size() || by >= dolls.size() || (by < 0 && propIndex(str(r["shaft"])) >= props.size())):
			continue
		if(!wanted.has(owner)):
			wanted[owner] = []
		wanted[owner].append(r)
	for index in range(dolls.size()):
		var doll = dolls[index]
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			if(!wanted.has(index)):
				restore(torso)
				continue
			var shafts:Array = []
			var holes:Array = []
			var by:Array = []
			for r in wanted[index]:
				var source = null
				if(dollIndex(str(r["shaft"])) >= 0):
					source = BulgeDoll.forDoll(dolls[dollIndex(str(r["shaft"]))])
				else:
					source = props[propIndex(str(r["shaft"]))]
				shafts.append([source, str(r["hole"]) == "mouth", portalOf(stageScene, r)])
				holes.append(str(r["hole"]))
				by.append(str(r["shaft"]))
			var ro:Dictionary = o
			if(bool(BENCH.get("capture_now", false))):
				ro = o.duplicate()
				ro["capture_suffix"] = "_doll" + str(index)
			var row:Dictionary = draw(torso, helper, shafts, ro)
			row["doll"] = "doll" + str(index)
			row["hole"] = holes[0]
			row["shaft"] = by[0]
			row["holes"] = holes
			row["shafts"] = by
			rows.append(row)
	if(wanted.empty()):
		warm(dolls, o)
	elif(bool(BENCH.get("capture_now", false))):
		var knobs:Dictionary = BENCH
		knobs["capture_now"] = false
	return rows

static func warm(dolls:Array, opts:Dictionary) -> void:
	for doll in dolls:
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		var shaft = helper.getShaftInfo()
		if(shaft != null && !shaft["meshes"].empty() && !shapeReady(shaft["meshes"][0])):
			var _shape = shaftShapeOf(shaft["meshes"][0])
			return
		for torso in helper.getBulgeMeshesForZone(""):
			var state:Dictionary = stateOf(torso)
			if(state["bshape"] == null):
				var _bshape = bodyShapeOf(torso, state)
				return
			if(state.has("warm") || !bool(opts.get("posed_build", true))):
				continue
			state["warm"] = true
			var skel:Skeleton = helper.getSkeletonNode()
			if(skel == null || state["bshape"].empty()):
				continue
			var posed:Dictionary = posedOf(torso, state["orig"], skel)
			if(!posed.empty()):
				var _pose = BodyPose.pose(state["orig"], state["bshape"], posed["mats"], float(opts.get("lock_at", BodyDeform.DEFAULTS["lock_at"])), posed["at"])
				return

static func bodyShapeOf(torso, state:Dictionary) -> Dictionary:
	if(state["bshape"] == null):
		var bodyTex = BulgeUtils.getAlbedoTexture(torso)
		state["bshape"] = {}
		if(bodyTex != null):
			state["bshape"] = BodyShape.measure(state["orig"], bodyTex)
	return state["bshape"]

static func restoreAll(stageScene) -> void:
	for doll in stageScene.getDolls():
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			restore(torso)

static func dollIndex(id:String) -> int:
	if(!id.begins_with("doll")):
		return -1
	return int(id.substr(4))

static func propIndex(id:String) -> int:
	if(!id.begins_with(Eyes.KIND_PROP)):
		return -1
	return int(id.substr(Eyes.KIND_PROP.length()))

static func stateOf(torso) -> Dictionary:
	if(!torso.has_meta(META_STATE)):
		torso.set_meta(META_STATE, {"orig": torso.mesh, "on": false, "cache": {}, "bshape": null, "clips": []})
	return torso.get_meta(META_STATE)

static func restore(torso) -> void:
	if(!torso.has_meta(META_STATE)):
		return
	var state:Dictionary = torso.get_meta(META_STATE)
	unclip(state)
	restoreMesh(torso, state)

static func restoreMesh(torso, state:Dictionary) -> void:
	BodyDeform.skin_off(torso.fancyMaterial)
	hideShade(state)
	if(!bool(state["on"])):
		return
	state["on"] = false
	torso.mesh = state["orig"]
	torso.set_surface_material(0, torso.fancyMaterial)

static func carryOf(shaftHelper, posed:Dictionary, portal:Dictionary = {}):
	if(shaftHelper == null):
		return "no shaft doll"
	var shaft = shaftHelper.getShaftInfo()
	if(shaft == null || shaft["meshes"].empty()):
		return "no shaft mesh"
	var penis = shaft["meshes"][0]
	var cock = cockState(shaftHelper)
	if(COCK_OFF.has(cock)):
		return "the cock is " + cock
	var penisSkel:Skeleton = shaftHelper.getSkeletonNode()
	if(penisSkel == null):
		return "no skeleton"
	var base:int = penisSkel.find_bone(SHAFT_BONE)
	if(base < 0):
		return "no " + SHAFT_BONE + " bone"
	var shape:Dictionary = shaftShapeOf(penis)
	if(shape.empty()):
		return "cannot measure the shaft"
	var penisWorldFromRest:Transform = penisSkel.global_transform * penisSkel.get_bone_global_pose(base) \
		* BulgeUtils.getBoneRestGlobal(penisSkel, base).affine_inverse()
	var restA:Vector2 = shape["pts"][0]
	var restB:Vector2 = shape["pts"][shape["pts"].size() - 1]
	if(!portal.empty()):
		penisWorldFromRest = throughPortal(portal, penisWorldFromRest.xform(Vector3(restA.x, restA.y, 0.0)),
			penisWorldFromRest.xform(Vector3(restB.x, restB.y, 0.0))) * penisWorldFromRest
	var worldA:Vector3 = penisWorldFromRest.xform(Vector3(restA.x, restA.y, 0.0))
	var worldB:Vector3 = penisWorldFromRest.xform(Vector3(restB.x, restB.y, 0.0))
	var atA:Transform = skinningAt(posed, worldA)
	var inA:Vector3 = atA.affine_inverse().xform(worldA)
	var inB:Vector3 = atA.affine_inverse().xform(worldB)
	var mirrored:bool = det2(penisWorldFromRest.basis) * det2(atA.basis) < 0.0
	var xp:Transform = similarity(restA, restB, Vector2(inA.x, inA.y), Vector2(inB.x, inB.y), mirrored)
	var xw:Transform = similarity(restA, restB, Vector2(worldA.x, worldA.y), Vector2(worldB.x, worldB.y),
		det2(penisWorldFromRest.basis) < 0.0)
	var out:Dictionary = {"helper": shaftHelper, "mesh": penis.mesh, "mask": outlineTexture(penis), "shape": shape, "skel": penisSkel, "worldA": worldA,
		"worldB": worldB, "atA": atA, "inA": inA, "inB": inB, "xp": xp, "xw": xw}
	if(!portal.empty()):
		out["portal"] = true
	return out

static func portalOf(stageScene, r:Dictionary) -> Dictionary:
	if(str(r.get("source")) != "portal" || stageScene.get_script() == null):
		return {}
	var row = PortalScenes.TABLE.get(stageScene.get_script().resource_path.trim_prefix("res://"))
	if(typeof(row) != TYPE_DICTIONARY || !row.has("portal")):
		return {}
	var eyes = Eyes.new(stageScene)
	var helper = eyes.helperFor(str(r["shaft"]))
	var hole = eyes.holeOf(str(r["hole_owner"]), str(r["hole"]))
	if(helper == null || hole == null || helper.getShaftInfo() == null):
		return {}
	var card:Dictionary = helper.getShaftInfo()
	var opening = PortalScenes.openingOf(eyes.propsOf(str(row["portal"]["owner"])).get(str(row["portal"]["zone"])),
		card["base"], (card["tip"] - card["base"]).normalized())
	if(typeof(opening) != TYPE_VECTOR3):
		return {}
	if(!stageScene.has_meta(META_PORTAL)):
		stageScene.set_meta(META_PORTAL, {})
	var deepest:Dictionary = stageScene.get_meta(META_PORTAL)
	if(!deepest.has(str(r["shaft"]))):
		deepest[str(r["shaft"])] = {"along": 0.0}
	return {"opening": opening, "pos": hole["pos"], "inward": hole["inward"], "deepest": deepest[str(r["shaft"])]}

static func throughPortal(portal:Dictionary, a:Vector3, b:Vector3) -> Transform:
	var dir:Vector3 = Vector3(b.x - a.x, b.y - a.y, 0.0).normalized()
	var length:float = Vector2(b.x - a.x, b.y - a.y).length()
	var along:float = (portal["opening"] - a).dot(dir)
	var deepest:Dictionary = portal["deepest"]
	deepest["along"] = min(deepest["along"], along)
	var at:Vector3 = a + dir * (length - (length - along) * length / (length - deepest["along"]))
	var inward:Vector2 = Vector2(portal["inward"].x, portal["inward"].y)
	var turn := Basis(Vector3(0.0, 0.0, 1.0), inward.angle() - Vector2(dir.x, dir.y).angle())
	return Transform(turn, Vector3(portal["pos"].x, portal["pos"].y, at.z) - turn.xform(at))

static func carryOfProp(prop:Dictionary, posed:Dictionary):
	var skel:Skeleton = prop["skeleton"]
	var row:Dictionary = prop["row"]
	if(!is_instance_valid(skel) || !skel.is_visible_in_tree()):
		return "the prop is gone"
	var meshInstance:MeshInstance = null
	for child in skel.get_children():
		if(child is MeshInstance && child.skin != null):
			meshInstance = child
	if(meshInstance == null):
		return "no prop mesh"
	var cut:Dictionary = PropShaft.cutOf(meshInstance, row)
	var shape:Dictionary = PropShaft.shapeOf(meshInstance, row)
	var bone:int = skel.find_bone(str(row["bones"][0]))
	if(cut.empty() || shape.empty() || bone < 0):
		return "cannot measure the prop's shaft"
	var worldFromRest:Transform = meshInstance.global_transform * skel.get_bone_global_pose(bone) \
		* meshInstance.skin.get_bind_pose(cut["bind"]) * cut["frame"].affine_inverse()
	var restA:Vector2 = shape["pts"][0]
	var restB:Vector2 = shape["pts"][shape["pts"].size() - 1]
	var worldA:Vector3 = worldFromRest.xform(Vector3(restA.x, restA.y, 0.0))
	var worldB:Vector3 = worldFromRest.xform(Vector3(restB.x, restB.y, 0.0))
	var atA:Transform = skinningAt(posed, worldA)
	var inA:Vector3 = atA.affine_inverse().xform(worldA)
	var inB:Vector3 = atA.affine_inverse().xform(worldB)
	var mirrored:bool = det2(worldFromRest.basis) * det2(atA.basis) < 0.0
	var xp:Transform = similarity(restA, restB, Vector2(inA.x, inA.y), Vector2(inB.x, inB.y), mirrored)
	var xw:Transform = similarity(restA, restB, Vector2(worldA.x, worldA.y), Vector2(worldB.x, worldB.y),
		det2(worldFromRest.basis) < 0.0)
	return {"helper": null, "mesh": cut["mesh"], "mask": BulgeUtils.getAlbedoTexture(meshInstance), "mask_span": cut["uv_span"], "shape": shape,
		"skel": skel, "worldA": worldA, "worldB": worldB, "atA": atA, "inA": inA, "inB": inB, "xp": xp, "xw": xw}

static func draw(torso, holeHelper, shafts:Array, opts:Dictionary = OPTS) -> Dictionary:
	var state:Dictionary = stateOf(torso)
	var orig:Mesh = state["orig"]
	var torsoSkel:Skeleton = holeHelper.getSkeletonNode()
	if(torsoSkel == null):
		return fail(torso, "no skeleton")
	var bshape:Dictionary = bodyShapeOf(torso, state)
	if(bshape.empty()):
		return fail(torso, "cannot measure the body")
	var posed:Dictionary = posedOf(torso, orig, torsoSkel)
	if(posed.empty()):
		return fail(torso, "the torso has no skin binds")
	var carries:Array = []
	var why:String = ""
	for one in shafts:
		var c
		if(typeof(one[0]) == TYPE_DICTIONARY):
			c = carryOfProp(one[0], posed)
		else:
			c = carryOf(one[0], posed, one[2])
		if(typeof(c) == TYPE_STRING):
			why = c
			continue
		c["throat"] = bool(one[1])
		carries.append(c)
	if(carries.empty()):
		return fail(torso, why)
	var main:Dictionary = carries[0]
	var penisMesh:Mesh = main["mesh"]
	var shape:Dictionary = main["shape"]
	var penisSkel:Skeleton = main["skel"]
	var atA:Transform = main["atA"]
	var xp:Transform = main["xp"]
	var xw:Transform = main["xw"]
	opts = opts.duplicate()
	opts["throat"] = main["throat"]
	if(str(BENCH.get("capture_to", "")) != "" && bool(BENCH.get("capture_now", false))):
		captureTo(str(BENCH["capture_to"]) + str(opts.get("capture_suffix", "")), torso, orig, posed["mats"], carries)
	var t0:int = OS.get_ticks_usec()
	var posedBuild:bool = bool(opts.get("posed_build", true))
	var pose:Dictionary = {}
	var skin:ArrayMesh
	if(posedBuild):
		pose = BodyPose.pose(orig, bshape, posed["mats"], float(opts.get("lock_at", BodyDeform.DEFAULTS["lock_at"])), posed["at"])
		if(BodyDeform.options(opts)["backend"] == "gpu"):
			var host:Node = torso.get_viewport()
			var mapName:String = "BulgeUvMap" + str(torso.get_instance_id())
			BodyPose.uv_map(pose, host, mapName)
			state["uv_map"] = host.get_node(mapName)
			freeWith(torso, state["uv_map"])
		var shade:float = float(opts.get("shade_strength", 0.0))
		var shadeMat = null
		if(shade > 0.0):
			shadeMat = shadeMaterialOf(state, main["mask"], 0, opts, main.get("mask_span", Vector2.ONE))
			if(shadeMat == null):
				shade = 0.0
		var more:Array = []
		for i in range(1, carries.size()):
			var c:Dictionary = carries[i]
			var smat = null
			if(shade > 0.0):
				smat = shadeMaterialOf(state, c["mask"], i, opts, c.get("mask_span", Vector2.ONE))
			more.append({"mesh": c["mesh"], "xp": BodyPose.flat_xf(pose, c["xw"]), "shape": c["shape"],
				"flip": false, "throat": c["throat"], "shade_mat": smat})
		opts["more"] = more
		skin = BodyDeform.deform(pose["mesh"], Transform.IDENTITY, penisMesh, BodyPose.flat_xf(pose, xw), shape,
			pose["bs"], false, true, COVER, shade, torso.fancyMaterial, shadeMat, LOCK, null, opts)
	else:
		var more:Array = []
		for i in range(1, carries.size()):
			var c:Dictionary = carries[i]
			more.append({"mesh": c["mesh"], "xp": c["xp"], "shape": c["shape"], "flip": false, "throat": c["throat"]})
		opts["more"] = more
		skin = BodyDeform.deform(orig, Transform.IDENTITY, penisMesh, xp, shape, bshape, false, true,
			COVER, 0.0, torso.fancyMaterial, null, LOCK, state["cache"], opts)
	var row:Dictionary = {"backend": "-", "verts": 0, "hit": false}
	if(skin.has_meta("info") && typeof(skin.get_meta("info")) == TYPE_DICTIONARY):
		var info:Dictionary = skin.get_meta("info")
		row["hit"] = bool(info["hit"])
		row["entry"] = info["entry_pt"]
		row["base"] = info["base"]
		row["tip"] = info["tip"]
		if(bool(BENCH.get("hole_trace", false)) && posedBuild):
			var holes:Dictionary = {}
			for zone in HOLES:
				var at = holeHelper.getOrificeAnchor(zone)
				if(at != null):
					holes[zone] = BodyPose.world_of(pose, Vector2(at.x, at.y))
			row["game_holes"] = holes
	var infos:Array = []
	if(skin.has_meta("infos")):
		infos = skin.get_meta("infos")
	var clips:Array = []
	for i in range(carries.size()):
		if(i >= infos.size() || !bool(infos[i]["hit"])):
			continue
		row["hit"] = true
		var c:Dictionary = carries[i]
		if(c["helper"] == null || c.has("portal")):
			continue
		var entry:Vector2 = infos[i]["entry_pt"]
		var entryWorld:Vector3
		if(posedBuild):
			var flat:Vector2 = BodyPose.world_of(pose, entry)
			entryWorld = Vector3(flat.x, flat.y, c["worldA"].z)
		else:
			var near:int = nearestVertex(weightLookupOf(orig), entry)
			entryWorld = BodyPose._blend(posed["mats"], posed["bones"], posed["weights"], near).xform(Vector3(entry.x, entry.y, 0.0))
		c["helper"].unTaperShaftBones()
		c["helper"].applyShaftClip(entryWorld)
		clips.append(c["helper"])
	for helper in state["clips"]:
		if(!clips.has(helper)):
			unclipOne(helper)
	state["clips"] = clips
	if(bool(BENCH.get("trace", false)) && row.has("entry")):
		row["trace"] = traceOf(bshape, skin.get_meta("info"), skin, penisSkel, atA)
	if(!skin.has_meta("polys")):
		restoreMesh(torso, state)
		row["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
		if(posedBuild && skin.has_meta("shaded") && !skin.get_meta("shaded").empty()):
			drawShade(torso, state, skin, pose, posed)
			row["shade_only"] = true
			return row
		row["why"] = "no outline change (the shaft stays inside the body, is outside it, or is past the lock line)"
		return row
	if(bool(BENCH.get("areas", false))):
		var polys:Dictionary = skin.get_meta("polys")
		row["area_body"] = stepify(BodyShape.area(polys["body"]), 0.001)
		row["area_target"] = stepify(BodyShape.area(polys["target"]), 0.001)
	var weighted:ArrayMesh
	if(posedBuild):
		weighted = BodyPose.unpose(skin, pose)
		if(weighted == null):
			restoreMesh(torso, state)
			row["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
			row["why"] = "the posed skin carries no bones"
			return row
	else:
		weighted = weightedOf(skin, orig)
	torso.mesh = weighted
	torso.set_surface_material(0, torso.fancyMaterial)
	state["on"] = true
	if(posedBuild):
		drawShade(torso, state, skin, pose, posed)
	if(bool(BENCH.get("fold_check", false))):
		row["folded"] = foldedOf(skin, weighted, posed["mats"], pose)
	if(row.has("trace")):
		var wa:Array = weighted.surface_get_arrays(0)
		var posedSkin:Array = []
		var restSkin:Array = []
		for i in range(wa[Mesh.ARRAY_VERTEX].size()):
			var v:Vector3 = wa[Mesh.ARRAY_VERTEX][i]
			restSkin.append(v)
			posedSkin.append(BodyPose._blend(posed["mats"], wa[Mesh.ARRAY_BONES], wa[Mesh.ARRAY_WEIGHTS], i).xform(v))
		row["trace"]["skin_rest"] = listOf(restSkin)
		row["trace"]["skin_posed"] = listOf(posedSkin)
		row["trace"]["torso_posed"] = listOf(posed["at"])
		var fm = torso.fancyMaterial
		row["trace"]["drawn"] = {"format": weighted.surface_get_format(0), "uv2": (weighted.surface_get_format(0) & Mesh.ARRAY_FORMAT_TEX_UV2) != 0,
			"bones": (weighted.surface_get_format(0) & Mesh.ARRAY_FORMAT_BONES) != 0, "bulge_on": fm.get_shader_param("bulge_on"),
			"border_n": fm.get_shader_param("bulge_border_n"), "mapped_shader": fm.shader.code.find("bulge_shift") >= 0,
			"mesh_is_skin": weighted == skin, "surface_mat_same": torso.get_surface_material(0) == fm,
			"material_override": torso.material_override != null}
		var dump:String = str(BENCH.get("dump_to", ""))
		if(dump != "" && bool(BENCH.get("dump_now", false))):
			BENCH["dump_now"] = false
			var clean := ArrayMesh.new()
			clean.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, weighted.surface_get_arrays(0))
			var _m = ResourceSaver.save(dump + "/skin_mesh.res", clean)
			var params:Dictionary = {}
			for info in VisualServer.shader_get_param_list(fm.shader.get_rid()):
				var v = fm.get_shader_param(info["name"])
				if(v is Texture):
					var _t = ResourceSaver.save(dump + "/tex_" + info["name"] + ".res", v)
					v = "tex:" + info["name"]
				params[info["name"]] = v
			var f := File.new()
			if(f.open(dump + "/params.txt", File.WRITE) == OK):
				f.store_var(params)
				f.close()
			var sh := File.new()
			if(sh.open(dump + "/shader.txt", File.WRITE) == OK):
				sh.store_string(fm.shader.code)
				sh.close()
	row["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
	row["backend"] = str(skin.get_meta("stats")["backend"])
	row["verts"] = int(skin.get_meta("stats")["verts"])
	return row

static func captureTo(dir:String, torso, orig:Mesh, mats:Array, carries:Array) -> void:
	var _made = Directory.new().make_dir_recursive(dir)
	var parts:Array = [["torso", orig, BulgeUtils.getAlbedoTexture(torso)]]
	var more:Array = []
	for i in range(carries.size()):
		var name:String = "penis"
		if(i > 0):
			name = "penis_" + str(i)
			more.append({"xp": carries[i]["xp"], "xw": carries[i]["xw"], "throat": carries[i]["throat"]})
		parts.append([name, carries[i]["mesh"], carries[i]["mask"]])
	for part in parts:
		var clean := ArrayMesh.new()
		clean.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, part[1].surface_get_arrays(0))
		var _saved = ResourceSaver.save(dir + "/" + part[0] + ".res", clean)
		var tex = part[2]
		if(tex != null):
			var img:Image = tex.get_data()
			if(img.is_compressed()):
				var _d = img.decompress()
			var _png = img.save_png(dir + "/" + part[0] + ".png")
	var f := File.new()
	if(f.open(dir + "/pose.var", File.WRITE) == OK):
		f.store_var({"mats": mats, "xp": carries[0]["xp"], "xw": carries[0]["xw"], "throat": carries[0]["throat"], "more": more})
		f.close()

static func foldedOf(skin:ArrayMesh, weighted:ArrayMesh, mats:Array, pose:Dictionary) -> int:
	var wa:Array = weighted.surface_get_arrays(0)
	var built:PoolVector3Array = wa[Mesh.ARRAY_VERTEX]
	if(!pose.empty()):
		built = skin.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
	var idx:PoolIntArray = wa[Mesh.ARRAY_INDEX]
	var drawn := PoolVector3Array()
	for i in range(wa[Mesh.ARRAY_VERTEX].size()):
		drawn.append(BodyPose._blend(mats, wa[Mesh.ARRAY_BONES], wa[Mesh.ARRAY_WEIGHTS], i).xform(wa[Mesh.ARRAY_VERTEX][i]))
	var flipped := 0
	var total := 0
	for t in range(0, idx.size() - 2, 3):
		var a:float = area2(built[idx[t]], built[idx[t + 1]], built[idx[t + 2]])
		var b:float = area2(drawn[idx[t]], drawn[idx[t + 1]], drawn[idx[t + 2]])
		if(a == 0.0 || b == 0.0):
			continue
		total += 1
		if((a > 0.0) != (b > 0.0)):
			flipped += 1
	return int(min(flipped, total - flipped))

static func area2(a:Vector3, b:Vector3, c:Vector3) -> float:
	return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)

static func traceOf(bshape:Dictionary, info:Dictionary, skin:ArrayMesh, penisSkel:Skeleton, atA:Transform) -> Dictionary:
	var out:Dictionary = {"outline": listOf(bshape["outline"]), "path": listOf(info.get("path", [])),
		"guide": listOf(info.get("guide", [])), "entry": listOf([info["entry_pt"]])}
	if(skin.has_meta("polys")):
		var polys:Dictionary = skin.get_meta("polys")
		out["sleeve"] = listOf(polys["sleeve"])
		out["target"] = listOf(polys["target"])
	var bones:Array = []
	for name in [SHAFT_BONE, "Penis2", "Penis3"]:
		var b:int = penisSkel.find_bone(name)
		if(b >= 0):
			var w:Vector3 = (penisSkel.global_transform * penisSkel.get_bone_global_pose(b)).origin
			bones.append(atA.affine_inverse().xform(w))
	out["animated_bones"] = listOf(bones)
	var base:int = penisSkel.find_bone(SHAFT_BONE)
	var tipBone:int = penisSkel.find_bone("Penis3")
	if(base >= 0 && tipBone >= 0):
		var baseScale:float = penisSkel.get_bone_global_pose(base).basis.get_scale().y
		out["taper_drawn"] = stepify(penisSkel.get_bone_global_pose(tipBone).basis.get_scale().y / baseScale, 0.001)
		out["taper_animated"] = stepify(penisSkel.get_bone_pose(tipBone).basis.get_scale().y
			* penisSkel.get_bone_pose(penisSkel.get_bone_parent(tipBone)).basis.get_scale().y, 0.001)
	return out

static func listOf(points) -> Array:
	var out:Array = []
	for p in points:
		out.append([stepify(p.x, 0.0001), stepify(p.y, 0.0001)])
	return out

const SHADE_STYLES := {"soft": [0, 0.0], "soft_outline": [0, 1.0], "filled": [1, 0.0], "filled_outline": [1, 1.0],
	"halo": [2, 0.0], "halo_outline": [2, 1.0], "xray": [3, 0.0], "xray_outline": [3, 1.0]}
const SHADE_TEXEL := Vector2(0.006, 0.012)
static func shadeMaterialOf(state:Dictionary, tex, slot:int, opts:Dictionary, span:Vector2 = Vector2.ONE):
	if(tex == null):
		return null
	var mats:Array = state.get("shade_mats", [])
	while(mats.size() <= slot):
		mats.append(null)
	var onTop:bool = bool(opts.get("shade_on_top", false))
	if(mats[slot] == null || mats[slot].get_shader_param("mask") != tex || mats[slot].shader != BodyDeform.shade_shader(onTop)):
		mats[slot] = BodyDeform.make_shade_material(tex, onTop)
	state["shade_mats"] = mats
	var look:Array = SHADE_STYLES.get(str(opts.get("shade_style", "soft")), SHADE_STYLES["soft"])
	if(mats[slot].get_shader_param("texel") != SHADE_TEXEL * span):
		mats[slot].set_shader_param("texel", SHADE_TEXEL * span)
	mats[slot].set_shader_param("style", int(look[0]))
	mats[slot].set_shader_param("outline", float(look[1]))
	return mats[slot]

static func drawShade(torso, state:Dictionary, skin:ArrayMesh, pose:Dictionary, posed:Dictionary) -> void:
	if(skin.get_surface_count() < 2 || !skin.has_meta("shaded")):
		if(bool(BENCH.get("shade_trace", false))):
			print("SHADETRACE ", Engine.get_idle_frames(), " ", torso.get_instance_id(), " hidden surfaces=", skin.get_surface_count(), " shaded=", skin.has_meta("shaded"))
		hideShade(state)
		return
	var host:Node = torso.get_viewport()
	var node = state.get("shade_node")
	if(node == null || !is_instance_valid(node)):
		node = MeshInstance.new()
		node.name = "BulgeShade" + str(torso.get_instance_id())
		host.add_child(node)
		state["shade_node"] = node
		freeWith(torso, node)
	var at:PoolVector3Array = posed["at"]
	var cam = host.get_camera()
	var toward:float = 1.0
	if(cam != null && at.size() > 0 && cam.global_transform.origin.z < at[0].z):
		toward = -1.0
	var z:float = -INF
	for v in at:
		z = max(z, v.z * toward)
	z = (z + SHADE_Z) * toward
	var key:Array = []
	var gpu:bool = true
	for sf in range(1, skin.get_surface_count()):
		var mat = skin.surface_get_material(sf)
		gpu = gpu && bool(mat.get_shader_param("gpu_bend"))
		key.append([mat.get_instance_id(), skin.surface_get_array_len(sf), skin.surface_get_array_index_len(sf)])
	if(bool(BENCH.get("shade_trace", false))):
		print("SHADETRACE ", Engine.get_idle_frames(), " ", torso.get_instance_id(), " reuse=", gpu && key == state.get("shade_key") && node.mesh != null, " key=", key)
	if(gpu && key == state.get("shade_key") && node.mesh != null):
		for sf in range(1, skin.get_surface_count()):
			var mat = skin.surface_get_material(sf)
			mat.set_shader_param("mirror", bool(pose["mirror"]))
			mat.set_shader_param("shade_z", z)
		node.visible = true
		return
	state["shade_key"] = null
	if(gpu):
		state["shade_key"] = key
	var m := ArrayMesh.new()
	for sf in range(1, skin.get_surface_count()):
		var a:Array = skin.surface_get_arrays(sf)
		var mat = skin.surface_get_material(sf)
		if(bool(mat.get_shader_param("gpu_bend"))):
			mat.set_shader_param("mirror", bool(pose["mirror"]))
			mat.set_shader_param("shade_z", z)
		else:
			var verts:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
			for i in range(verts.size()):
				var w:Vector2 = BodyPose.world_of(pose, Vector2(verts[i].x, verts[i].y))
				verts[i] = Vector3(w.x, w.y, z)
			a[Mesh.ARRAY_VERTEX] = verts
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
		m.surface_set_material(sf - 1, mat)
	m.custom_aabb = BodyDeform.SHADE_AABB
	node.mesh = m
	node.global_transform = Transform.IDENTITY
	node.visible = true

static func freeWith(torso, node:Node) -> void:
	if(!torso.is_connected("tree_exiting", node, "queue_free")):
		var _c = torso.connect("tree_exiting", node, "queue_free", [], Object.CONNECT_ONESHOT)

static func hideShade(state:Dictionary) -> void:
	var node = state.get("shade_node")
	if(node != null && is_instance_valid(node)):
		node.visible = false

static func unclip(state:Dictionary) -> void:
	for helper in state["clips"]:
		unclipOne(helper)
	state["clips"] = []

static func unclipOne(helper) -> void:
	if(helper != null && is_instance_valid(helper)):
		helper.clearBulgeState()
		helper.restoreShaftTaper()

static func fail(torso, why:String) -> Dictionary:
	restore(torso)
	return {"hit": false, "why": why}

static func shaftShapeOf(penis) -> Dictionary:
	var mesh:Mesh = penis.mesh
	if(!mesh.has_meta(META_SHAPE)):
		mesh.set_meta(META_SHAPE, {})
	var shapes:Dictionary = mesh.get_meta(META_SHAPE)
	var tex = outlineTexture(penis)
	if(tex == null):
		return {}
	var key:int = tex.get_instance_id()
	if(!shapes.has(key)):
		shapes[key] = BodyDeform.shape(mesh, tex)
	return shapes[key]

static func shapeReady(penis) -> bool:
	var tex = outlineTexture(penis)
	return tex == null || (penis.mesh.has_meta(META_SHAPE) && penis.mesh.get_meta(META_SHAPE).has(tex.get_instance_id()))

static func cockState(shaftHelper) -> String:
	if(shaftHelper.doll == null || !shaftHelper.doll.has_method("getFinalState")):
		return ""
	var v = shaftHelper.doll.getFinalState("cock")
	if(v == null):
		return ""
	return str(v)

static func outlineTexture(meshInstance):
	return BulgeUtils.getAlbedoTexture(meshInstance)

static func weightedOf(skin:ArrayMesh, orig:Mesh) -> ArrayMesh:
	if(skin.has_meta("weighted")):
		return skin.get_meta("weighted")
	var a:Array = skin.surface_get_arrays(0)
	if(a[Mesh.ARRAY_BONES] != null && a[Mesh.ARRAY_BONES].size() == a[Mesh.ARRAY_VERTEX].size() * 4):
		skin.set_meta("weighted", skin)
		return skin
	var lookup:Dictionary = weightLookupOf(orig)
	var verts:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
	var srcBones = lookup["bones"]
	var srcWeights = lookup["weights"]
	var bones := PoolIntArray()
	var weights := PoolRealArray()
	bones.resize(verts.size() * 4)
	weights.resize(verts.size() * 4)
	for i in range(verts.size()):
		var v:int = nearestVertex(lookup, Vector2(verts[i].x, verts[i].y))
		for j in range(4):
			bones[i * 4 + j] = int(srcBones[v * 4 + j])
			weights[i * 4 + j] = float(srcWeights[v * 4 + j])
	a[Mesh.ARRAY_BONES] = bones
	a[Mesh.ARRAY_WEIGHTS] = weights
	var out := ArrayMesh.new()
	out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	skin.set_meta("weighted", out)
	return out

static func weightLookupOf(orig:Mesh) -> Dictionary:
	if(orig.has_meta(META_WEIGHTS)):
		return orig.get_meta(META_WEIGHTS)
	var a:Array = orig.surface_get_arrays(0)
	var lookup:Dictionary = {"verts": a[Mesh.ARRAY_VERTEX], "bones": a[Mesh.ARRAY_BONES], "weights": a[Mesh.ARRAY_WEIGHTS],
		"box": orig.get_aabb()}
	orig.set_meta(META_WEIGHTS, lookup)
	return lookup

static func nearestVertex(lookup:Dictionary, p:Vector2) -> int:
	if(!lookup.has("near")):
		nearGridOf(lookup)
	var q:Vector2 = (p - lookup["origin"]) / float(lookup["cell"])
	var gx:int = int(clamp(floor(q.x), 0, int(lookup["nx"]) - 1))
	var gy:int = int(clamp(floor(q.y), 0, int(lookup["ny"]) - 1))
	return int(lookup["near"][gy * int(lookup["nx"]) + gx])

static func nearGridOf(lookup:Dictionary) -> void:
	var verts:PoolVector3Array = lookup["verts"]
	var box:AABB = lookup["box"]
	var cell:float = max(box.size.x, box.size.y) / float(WEIGHT_CELLS)
	var nx:int = int(ceil(box.size.x / cell)) + 1
	var ny:int = int(ceil(box.size.y / cell)) + 1
	var near := PoolIntArray()
	near.resize(nx * ny)
	for gy in range(ny):
		for gx in range(nx):
			var p := Vector2(box.position.x + (gx + 0.5) * cell, box.position.y + (gy + 0.5) * cell)
			var best:int = 0
			var bestD:float = INF
			for i in range(verts.size()):
				var d:float = p.distance_squared_to(Vector2(verts[i].x, verts[i].y))
				if(d < bestD):
					bestD = d
					best = i
			near[gy * nx + gx] = best
	lookup["origin"] = Vector2(box.position.x, box.position.y)
	lookup["cell"] = cell
	lookup["nx"] = nx
	lookup["ny"] = ny
	lookup["near"] = near

static func posedOf(torso, orig:Mesh, skel:Skeleton) -> Dictionary:
	var skin = torso.get("skin")
	if(skin == null):
		return {}
	var mats:Array = []
	for bind in range(skin.get_bind_count()):
		var bone:int = skin.get_bind_bone(bind)
		if(bone < 0):
			bone = skel.find_bone(skin.get_bind_name(bind))
		var m:Transform = Transform.IDENTITY
		if(bone >= 0):
			m = skel.global_transform * skel.get_bone_global_pose(bone) * skin.get_bind_pose(bind)
		mats.append(m)
	var lookup:Dictionary = weightLookupOf(orig)
	var verts:PoolVector3Array = lookup["verts"]
	var bones = lookup["bones"]
	var weights = lookup["weights"]
	var at:PoolVector3Array = BodyPose.skinned(verts, bones, weights, mats)
	return {"mats": mats, "at": at, "bones": bones, "weights": weights}

static func det2(b:Basis) -> float:
	return b.x.x * b.y.y - b.x.y * b.y.x

static func skinningAt(posed:Dictionary, p:Vector3) -> Transform:
	var at:PoolVector3Array = posed["at"]
	var best:int = 0
	var bestD:float = INF
	for i in range(at.size()):
		var d:float = Vector2(p.x, p.y).distance_squared_to(Vector2(at[i].x, at[i].y))
		if(d < bestD):
			bestD = d
			best = i
	return BodyPose._blend(posed["mats"], posed["bones"], posed["weights"], best)

static func similarity(a:Vector2, b:Vector2, a2:Vector2, b2:Vector2, mirrored:bool) -> Transform:
	var d:Vector2 = b - a
	if(mirrored):
		d.y = -d.y
	var d2:Vector2 = b2 - a2
	var den:float = max(d.length_squared(), 0.0000001)
	var ar:float = (d2.x * d.x + d2.y * d.y) / den
	var ai:float = (d2.y * d.x - d2.x * d.y) / den
	var xcol := Vector3(ar, ai, 0.0)
	var ycol := Vector3(-ai, ar, 0.0)
	if(mirrored):
		ycol = -ycol
	var s:float = sqrt(ar * ar + ai * ai)
	var basis := Basis(xcol, ycol, Vector3(0.0, 0.0, s))
	var o3:Vector3 = basis.xform(Vector3(a.x, a.y, 0.0))
	return Transform(basis, Vector3(a2.x - o3.x, a2.y - o3.y, 0.0))
