extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument

const ShaftShape = preload("res://Bulge4/Effects/Detailed/Lab/ShaftShape.gd")
const RES = 128
const ALPHA = 0.5
const ALPHA_CUT = 128


static func measure(mesh: Mesh, texture: Texture, res: int = RES) -> Dictionary:
	var fit = ShaftShape.fitOf(mesh)
	if fit == null or texture == null:
		return {}
	var img = texture.get_data()
	var data = ShaftShape.alphaData(img)
	var w = img.get_width()
	var h = img.get_height()
	var rowU: Vector3 = fit["u"]
	var rowV: Vector3 = fit["v"]
	var size: Vector2 = fit["restMax"] - fit["restMin"]
	var cell = max(size.x, size.y) / float(res)
	if cell <= 0.0:
		return {}
	var gw = int(ceil(size.x / cell)) + 2
	var gh = int(ceil(size.y / cell)) + 2
	var origin: Vector2 = fit["restMin"] - Vector2(cell, cell)
	var inside = PoolByteArray()
	inside.resize(gw * gh)
	var lo = Vector2(gw, gh)
	var hi = Vector2(-1, -1)
	var du = rowU.x * cell
	var dv = rowV.x * cell
	for gy in gh:
		var p0 = origin + Vector2(0.5, gy + 0.5) * cell
		var u0 = rowU.x * p0.x + rowU.y * p0.y + rowU.z
		var v0 = rowV.x * p0.x + rowV.y * p0.y + rowV.z
		for gx in gw:
			var u = u0 + du * gx
			var v = v0 + dv * gx
			var on = 0
			if u >= 0.0 and u <= 1.0 and v >= 0.0 and v <= 1.0:
				if data[(int(v * (h - 1)) * w + int(u * (w - 1))) * 4 + 3] >= ALPHA_CUT:
					on = 1
					lo = Vector2(min(lo.x, gx), min(lo.y, gy))
					hi = Vector2(max(hi.x, gx), max(hi.y, gy))
			inside[gy * gw + gx] = on
	if hi.x < 0:
		return {}
	var bmin = origin + (lo + Vector2(0.5, 0.5)) * cell
	var bmax = origin + (hi + Vector2(0.5, 0.5)) * cell
	var d_in = _dist(inside, gw, gh, 0)
	var d_out = _dist(inside, gw, gh, 1)
	var sd = PoolRealArray()
	sd.resize(gw * gh)
	for i in gw * gh:
		sd[i] = (d_in[i] - d_out[i]) * cell
	return {"sd": sd, "gw": gw, "gh": gh, "origin": origin, "cell": cell, "bounds": Rect2(bmin, bmax - bmin),
		"outline": _refine(_outline(sd, gw, gh, origin, cell), data, w, h, fit, cell), "fit": fit,
		"axis": _axis(sd, gw, gh, origin, cell, false), "front": _axis(sd, gw, gh, origin, cell, true)}


static func _axis(sd: PoolRealArray, gw: int, gh: int, origin: Vector2, cell: float, front: bool) -> PoolVector2Array:
	var raw = []
	for gy in gh:
		var best = -1
		var left = -1
		for gx in gw:
			if sd[gy * gw + gx] > 0.0 and left < 0:
				left = gx
			if sd[gy * gw + gx] > cell and (best < 0 or sd[gy * gw + gx] > sd[gy * gw + best]):
				best = gx
		if best >= 0 and front:
			raw.append(origin + Vector2(left, gy + 0.5) * cell)
		elif best >= 0:
			raw.append(origin + Vector2(best + 0.5, gy + 0.5) * cell)
	var out = PoolVector2Array()
	var w = max(int(gh * 0.08), 1)
	for i in raw.size():
		var acc = Vector2.ZERO
		var n = 0
		for j in range(max(i - w, 0), min(i + w, raw.size() - 1) + 1):
			acc += raw[j]
			n += 1
		out.append(acc / n)
	return out


static func sd(s: Dictionary, p: Vector2) -> float:
	var gw: int = s["gw"]
	var gh: int = s["gh"]
	var g: Vector2 = (p - s["origin"]) / s["cell"] - Vector2(0.5, 0.5)
	var c = Vector2(clamp(g.x, 0.0, gw - 1.0), clamp(g.y, 0.0, gh - 1.0))
	var extra = (g - c).length() * s["cell"]
	var x0 = int(c.x)
	var y0 = int(c.y)
	var x1 = min(x0 + 1, gw - 1)
	var y1 = min(y0 + 1, gh - 1)
	var fx = c.x - x0
	var fy = c.y - y0
	var d = s["sd"]
	var a = lerp(d[y0 * gw + x0], d[y0 * gw + x1], fx)
	var b = lerp(d[y1 * gw + x0], d[y1 * gw + x1], fx)
	return lerp(a, b, fy) - extra


static func _dist(src: PoolByteArray, gw: int, gh: int, target: int) -> PoolRealArray:
	var d = PoolRealArray()
	d.resize(gw * gh)
	for i in gw * gh:
		d[i] = 1000000.0
		if src[i] == target:
			d[i] = 0.0
	var diag = 1.41421356
	if gw < 2 or gh < 2:
		return d
	for x in range(1, gw):
		d[x] = min(d[x], d[x - 1] + 1.0)
	for y in range(1, gh):
		var r = y * gw
		d[r] = min(d[r], min(d[r - gw] + 1.0, d[r - gw + 1] + diag))
		for i in range(r + 1, r + gw - 1):
			d[i] = min(min(d[i], d[i - 1] + 1.0), min(d[i - gw] + 1.0, min(d[i - gw - 1], d[i - gw + 1]) + diag))
		var e = r + gw - 1
		d[e] = min(min(d[e], d[e - 1] + 1.0), min(d[e - gw] + 1.0, d[e - gw - 1] + diag))
	var last = (gh - 1) * gw
	for i in range(last + gw - 2, last - 1, -1):
		d[i] = min(d[i], d[i + 1] + 1.0)
	for y in range(gh - 2, -1, -1):
		var r = y * gw
		var e = r + gw - 1
		d[e] = min(d[e], min(d[e + gw] + 1.0, d[e + gw - 1] + diag))
		for i in range(e - 1, r, -1):
			d[i] = min(min(d[i], d[i + 1] + 1.0), min(d[i + gw] + 1.0, min(d[i + gw + 1], d[i + gw - 1]) + diag))
		d[r] = min(min(d[r], d[r + 1] + 1.0), min(d[r + gw] + 1.0, d[r + gw + 1] + diag))
	return d


static func _outline(sd: PoolRealArray, gw: int, gh: int, origin: Vector2, cell: float) -> PoolVector2Array:
	var pos = {}
	var adj = {}
	for y in gh - 1:
		for x in gw - 1:
			var inside = sd[y * gw + x] > 0.0
			if inside == (sd[y * gw + x + 1] > 0.0) and inside == (sd[(y + 1) * gw + x] > 0.0) and inside == (sd[(y + 1) * gw + x + 1] > 0.0):
				continue
			var ids = [y * gw + x, y * gw + x + 1, (y + 1) * gw + x + 1, (y + 1) * gw + x]
			var keys = [(y * gw + x) * 2, (y * gw + x + 1) * 2 + 1, ((y + 1) * gw + x) * 2, (y * gw + x) * 2 + 1]
			var ends = [[0, 1], [1, 2], [3, 2], [0, 3]]
			var hit = []
			for e in 4:
				var va = sd[ids[ends[e][0]]]
				var vb = sd[ids[ends[e][1]]]
				if (va > 0.0) != (vb > 0.0):
					hit.append(keys[e])
					if not pos.has(keys[e]):
						var pa = origin + (_cell_xy(ids[ends[e][0]], gw) + Vector2(0.5, 0.5)) * cell
						var pb = origin + (_cell_xy(ids[ends[e][1]], gw) + Vector2(0.5, 0.5)) * cell
						pos[keys[e]] = pa.linear_interpolate(pb, va / (va - vb))
			for i in range(0, hit.size() - 1, 2):
				for pair in [[hit[i], hit[i + 1]], [hit[i + 1], hit[i]]]:
					if not adj.has(pair[0]):
						adj[pair[0]] = []
					adj[pair[0]].append(pair[1])
	var best = PoolVector2Array()
	var seen = {}
	for start in adj:
		if seen.has(start):
			continue
		var loop = PoolVector2Array()
		var prev = -1
		var cur = start
		while not seen.has(cur):
			seen[cur] = true
			loop.append(pos[cur])
			var nxt = -1
			for o in adj[cur]:
				if o != prev and not seen.has(o):
					nxt = o
					break
			if nxt < 0:
				break
			prev = cur
			cur = nxt
		if loop.size() > best.size():
			best = loop
	if area(best) < 0.0:
		best.invert()
	return best


static func _refine(loop: PoolVector2Array, data: PoolByteArray, w: int, h: int, fit: Dictionary, cell: float) -> PoolVector2Array:
	var n = loop.size()
	var out = PoolVector2Array()
	for i in n:
		var t = (loop[(i + 1) % n] - loop[(i - 1 + n) % n]).normalized()
		var o = Vector2(t.y, -t.x)
		var a = loop[i] - o * cell * 1.5
		var b = loop[i] + o * cell * 1.5
		if _on(data, w, h, fit, a) and not _on(data, w, h, fit, b):
			for k in 14:
				var m = (a + b) * 0.5
				if _on(data, w, h, fit, m):
					a = m
				else:
					b = m
			out.append((a + b) * 0.5)
		else:
			out.append(loop[i])
	return out


static func _on(data: PoolByteArray, w: int, h: int, fit: Dictionary, p: Vector2) -> bool:
	var uv = ShaftShape.restToUV(fit, p)
	if uv.x < 0.0 or uv.x > 1.0 or uv.y < 0.0 or uv.y > 1.0:
		return false
	return data[(int(uv.y * (h - 1)) * w + int(uv.x * (w - 1))) * 4 + 3] >= ALPHA_CUT


static func _cell_xy(i: int, gw: int) -> Vector2:
	return Vector2(i % gw, i / gw)


static func area(poly) -> float:
	var a = 0.0
	for i in poly.size():
		var p = poly[i]
		var q = poly[(i + 1) % poly.size()]
		a += p.x * q.y - q.x * p.y
	return a * 0.5
