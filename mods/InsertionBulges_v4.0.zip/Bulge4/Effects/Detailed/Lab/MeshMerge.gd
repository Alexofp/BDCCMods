extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument

const METHODS = ["surfaces", "single"]
const UV_MODES = ["keep", "planar", "fit_body"]


static func merge(method, ma, xa, mb, xb, uv_mode, material) -> ArrayMesh:
	var a = extract(ma, xa)
	var b = extract(mb, xb)
	_remap_uv(b, a, uv_mode)
	var mesh = ArrayMesh.new()
	if method == "single":
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _pack(_concat(a, b)))
	else:
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _pack(a))
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _pack(b))
	for s in mesh.get_surface_count():
		mesh.surface_set_material(s, material)
	return mesh


static func extract(mesh: Mesh, xf: Transform) -> Dictionary:
	var arr = mesh.surface_get_arrays(0)
	var v = arr[Mesh.ARRAY_VERTEX]
	var n = arr[Mesh.ARRAY_NORMAL]
	var uv = arr[Mesh.ARRAY_TEX_UV]
	var c = arr[Mesh.ARRAY_COLOR]
	var idx = arr[Mesh.ARRAY_INDEX]
	var ov = PoolVector3Array()
	var on = PoolVector3Array()
	var ouv = PoolVector2Array()
	var oc = PoolColorArray()
	var oi = PoolIntArray()
	var count = v.size()
	var has_n = n != null and n.size() == count
	var has_uv = uv != null and uv.size() == count
	var has_c = c != null and c.size() == count
	for k in count:
		ov.append(xf.xform(v[k]))
		on.append(Vector3.BACK)
		ouv.append(Vector2.ZERO)
		oc.append(Color.white)
		if has_n:
			on[k] = xf.basis.xform(n[k]).normalized()
		if has_uv:
			ouv[k] = uv[k]
		if has_c:
			oc[k] = c[k]
	if idx != null and idx.size() > 0:
		oi = idx
	else:
		for k in count:
			oi.append(k)
	return {"v": ov, "n": on, "uv": ouv, "c": oc, "i": oi}


static func _concat(a: Dictionary, b: Dictionary) -> Dictionary:
	var out = {}
	for key in ["v", "n", "uv", "c"]:
		var arr = a[key]
		arr.append_array(b[key])
		out[key] = arr
	var idx = a["i"]
	var off = a["v"].size()
	for i in b["i"]:
		idx.append(i + off)
	out["i"] = idx
	return out


static func _pack(d: Dictionary) -> Array:
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = d["v"]
	arrays[Mesh.ARRAY_NORMAL] = d["n"]
	arrays[Mesh.ARRAY_TEX_UV] = d["uv"]
	arrays[Mesh.ARRAY_COLOR] = d["c"]
	if d.has("uv2"):
		arrays[Mesh.ARRAY_TEX_UV2] = d["uv2"]
	arrays[Mesh.ARRAY_INDEX] = d["i"]
	return arrays


static func _remap_uv(b: Dictionary, a: Dictionary, mode: String) -> void:
	if mode == "keep" or a["v"].size() == 0:
		return
	var av = a["v"]
	var auv = a["uv"]
	var out = PoolVector2Array()
	if mode == "planar":
		var lo = av[0]
		var hi = av[0]
		for p in av:
			lo = Vector3(min(lo.x, p.x), min(lo.y, p.y), 0)
			hi = Vector3(max(hi.x, p.x), max(hi.y, p.y), 0)
		var size = hi - lo
		for p in b["v"]:
			out.append(Vector2((p.x - lo.x) / max(size.x, 1e-6), 1.0 - (p.y - lo.y) / max(size.y, 1e-6)))
	else:
		var fu = _fit(av, auv, 0)
		var fv = _fit(av, auv, 1)
		for p in b["v"]:
			out.append(Vector2(fu.x * p.x + fu.y, fv.x * p.y + fv.y))
	b["uv"] = out


static func _fit(pos: PoolVector3Array, uv: PoolVector2Array, axis: int) -> Vector2:
	var n = pos.size()
	var mp = 0.0
	var mu = 0.0
	for k in n:
		mp += pos[k][axis]
		mu += uv[k][axis]
	mp /= n
	mu /= n
	var cov = 0.0
	var var_p = 0.0
	for k in n:
		var dp = pos[k][axis] - mp
		cov += dp * (uv[k][axis] - mu)
		var_p += dp * dp
	var slope = 0.0
	if var_p > 1e-9:
		slope = cov / var_p
	return Vector2(slope, mu - slope * mp)
