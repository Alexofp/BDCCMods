extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument
const MeshMerge = preload("res://Bulge4/Effects/Detailed/Lab/MeshMerge.gd")

const ShaftShape = preload("res://Bulge4/Effects/Detailed/Lab/ShaftShape.gd")
const BodyShape = preload("res://Bulge4/Effects/Detailed/Lab/BodyShape.gd")
const PROFILE_BINS = 128

const DEFAULTS = {
	"backend": "auto",
	"cell": 0.05,
	"step": 0.04,
	"depth": 0.15,
	"margin": 0.06,
	"skin": 1.08,
	"fillet": 0.6,
	"lock_at": 0.7,
	"fidelity": 0.8,
	"bend": 0.0,
	"belly": 0.0,
	"belly_gap": 0.2,
	"entry_rest": true,
	"gpu_shape": false,
	"sdf_fillet": 1.0,
	"mvc": 3.0,
	"stop_at_neck": true,
	"throat": false,
	"gpu_cell": 0.1,
	"gpu_cell_fr": 0.8,
	"shader_extra": {},
}


static func options(opts: Dictionary) -> Dictionary:
	var o = DEFAULTS.duplicate()
	for key in opts:
		o[key] = opts[key]
	if o["backend"] == "auto":
		o["backend"] = "gpu"
		if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2 and not OS.has_feature("pc"):
			o["backend"] = "cpu"
	return o


static func shape(mesh: Mesh, tex: Texture) -> Dictionary:
	var m = ShaftShape.measure(mesh, tex, PROFILE_BINS)
	var fit = ShaftShape.fitOf(mesh)
	if m.empty() or fit == null:
		return {}
	var img = tex.get_data()
	var data = ShaftShape.alphaData(img)
	var pts = []
	var rad = []
	var bins = m["profile"].size()
	for i in bins:
		var t = m["skip"] + (1.0 - m["skip"]) * (i + 0.5) / float(bins)
		var x = lerp(m["span"].x, m["span"].y, t)
		var e = m["extents"][i]
		if e.y - e.x <= 0.0:
			continue
		pts.append(Vector2(x, (e.x + e.y) * 0.5))
		rad.append((e.y - e.x) * 0.5)
	if pts.size() < 2:
		return {}
	var dx = (pts[pts.size() - 1].x - pts[0].x) / float(pts.size() - 1)
	for extra in bins:
		var x2 = pts[pts.size() - 1].x + dx
		var e2 = ShaftShape.columnExtent(data, fit, x2, fit["restMin"].y, fit["restMax"].y, img.get_width(), img.get_height())
		if e2.y - e2.x <= 0.0:
			break
		pts.append(Vector2(x2, (e2.x + e2.y) * 0.5))
		rad.append((e2.y - e2.x) * 0.5)
	return {"pts": pts, "rad": rad, "girth": m["girth"], "skip": m["skip"]}


static func _scale(xf: Transform) -> float:
	return xf.basis.x.length()


static func _shape_world(shape: Dictionary, xp: Transform, flip: bool) -> Dictionary:
	var sp = shape["pts"]
	var sr = shape["rad"]
	var n = sp.size()
	var pts = []
	var rad = []
	var across = []
	pts.resize(n)
	rad.resize(n)
	across.resize(n)
	var k = _scale(xp)
	var up = xp.basis.xform(Vector3.UP)
	var a = Vector2(up.x, up.y).normalized()
	for i in n:
		var w = xp.xform(Vector3(sp[i].x, sp[i].y, 0.0))
		pts[i] = Vector2(w.x, w.y)
		rad[i] = sr[i] * k
		across[i] = a
	var dir = (pts[n - 1] - pts[0]).normalized()
	if flip:
		pts.invert()
		rad.invert()
		dir = -dir
	return {"pts": pts, "rad": rad, "dir": dir, "across": across}


const BLEND = 2.0
const PATH_STEPS = 64


static func _bend(sw: Dictionary, entry: int, entry_f: float, bs: Dictionary, xa: Transform, o: Dictionary) -> Dictionary:
	var k = _scale(xa)
	var r = 0.0
	for x in sw["rad"]:
		r = max(r, x)
	var guide = _guide(bs, xa, o["belly"], o["belly_gap"] * r / max(k, 0.000001))
	var front = _front_sign(xa)
	if o["throat"]:
		guide.invert()
		front = -front
	var pts = sw["pts"]
	var n = pts.size()
	var dir = (pts[n - 1] - pts[0]).normalized()
	var side = Vector2(-dir.y, dir.x)
	var along = []
	var off = []
	for p in pts:
		along.append((p - pts[0]).dot(dir))
		off.append((p - pts[0]).dot(side))
	var e = along[entry]
	if entry > 0:
		e = lerp(along[entry - 1], along[entry], entry_f)
	var start = pts[0] + dir * e
	var inside = along[n - 1] - e
	var bend = clamp(o["bend"], 0.0, 1.0)
	var axis = [start, start + dir * inside]
	if guide.size() >= 2:
		var gcum = _cumulative_open(guide)
		var g0 = _project(guide, gcum, start)
		if bend > 0.0:
			axis = _guide_path(start, dir, guide, gcum, g0, BLEND * r / bend, inside)
		if o["stop_at_neck"]:
			var room = gcum[gcum.size() - 1] - g0 - sw["rad"][n - 1]
			if not o["throat"]:
				room = _room(guide, gcum, g0, bs, xa) - sw["rad"][n - 1]
			if room > 0.0 and inside > room:
				axis = _pressed(_truncated(axis, room), inside, front, PRESS_BEND * r)
	var cum = _cumulative_open(axis)
	var end = cum[cum.size() - 1]
	var rad = sw["rad"]
	var acr = sw["across"]
	var last = axis.size() - 2
	var out = []
	var across = []
	var ang = []
	var rads = []
	var straight = []
	for i in n:
		var s = along[i] - e
		var f = 1.0
		if i > entry and s > end + 1e-6:
			var s0 = along[i - 1] - e
			f = clamp((end - s0) / max(s - s0, 1e-9), 0.0, 1.0)
			s = end
		if i <= entry:
			out.append(pts[i])
			across.append(acr[i])
			ang.append(0.0)
		else:
			var q = int(clamp(cum.bsearch(s) - 1, 0, last))
			var seg = axis[q + 1] - axis[q]
			var t = clamp((s - cum[q]) / max(cum[q + 1] - cum[q], 1e-9), 0.0, 1.0)
			var a = dir.angle_to(seg.normalized())
			out.append(axis[q] + seg * t + side.rotated(a) * lerp(off[i - 1], off[i], f))
			across.append(acr[i].rotated(a))
			ang.append(a)
		if f < 1.0:
			rads.append(lerp(rad[i - 1], rad[i], f))
			straight.append(pts[i - 1].linear_interpolate(pts[i], f))
			break
		rads.append(rad[i])
		straight.append(pts[i])
	var bent = sw.duplicate()
	bent["pts"] = out
	bent["rad"] = rads
	bent["across"] = across
	bent["straight"] = straight
	bent["ang"] = ang
	bent["guide"] = guide
	bent["axis"] = _truncated(axis, inside)
	return bent


static func _guide_path(start: Vector2, dir: Vector2, guide: Array, gcum: Array, g0: float, blend: float, length: float) -> Array:
	blend = max(blend, 1.5 * start.distance_to(_guide_at(guide, gcum, g0)))
	var step = length / PATH_STEPS
	var out = [start]
	var got = 0.0
	var s = 0.0
	var m = guide.size()
	var total = gcum[m - 1]
	var over = (guide[m - 1] - guide[0]).normalized()
	var prev = start
	for _q in PATH_STEPS * 4 - 1:
		if got >= length:
			break
		s += step
		var gs = g0 + s
		var gp
		if gs <= total:
			var i = int(clamp(gcum.bsearch(gs) - 1, 0, m - 2))
			var seg = guide[i + 1] - guide[i]
			gp = guide[i] + seg * clamp((gs - gcum[i]) / max(gcum[i + 1] - gcum[i], 1e-9), 0.0, 1.0)
		else:
			gp = guide[m - 1] + over * (gs - total)
		var p = (start + dir * s).linear_interpolate(gp, smoothstep(0.0, blend, s))
		got += p.distance_to(prev)
		out.append(p)
		prev = p
	return out


static func _guide_at(guide: Array, gcum: Array, s: float) -> Vector2:
	var total = gcum[gcum.size() - 1]
	if s <= total:
		return _at_arc(guide, gcum, s)[0]
	var m = guide.size()
	return guide[m - 1] + (guide[m - 1] - guide[0]).normalized() * (s - total)


static func _project(line: Array, cum: Array, p: Vector2) -> float:
	var best = INF
	var at = 0.0
	for i in line.size() - 1:
		var q = Geometry.get_closest_point_to_segment_2d(p, line[i], line[i + 1])
		var d = p.distance_squared_to(q)
		if d < best:
			best = d
			at = cum[i] + line[i].distance_to(q)
	return at


static func _truncated(line: Array, length: float) -> Array:
	var cum = _cumulative_open(line)
	var out = [line[0]]
	for i in range(1, line.size()):
		if cum[i] >= length:
			out.append(_at_arc(line, cum, length)[0])
			return out
		out.append(line[i])
	return out


static func _at_arc(line: Array, cum: Array, s: float) -> Array:
	var i = int(clamp(cum.bsearch(s) - 1, 0, line.size() - 2))
	var seg = line[i + 1] - line[i]
	var f = clamp((s - cum[i]) / max(cum[i + 1] - cum[i], 1e-9), 0.0, 1.0)
	return [line[i] + seg * f, seg.normalized()]





static func _guide(bs: Dictionary, xa: Transform, belly: float, gap: float) -> Array:
	if bs.has("anchors"):
		return _fitted_guide(bs, xa, belly, gap)
	var raw = []
	var f = bs["front"]
	var ax = bs["axis"]
	var n = f.size()
	for i in n:
		var t = (f[min(i + 1, n - 1)] - f[max(i - 1, 0)]).normalized()
		var inward = Vector2(t.y, -t.x)
		var middle = max((ax[i] - f[i]).dot(inward), 0.0)
		var d = min(lerp(middle, gap, clamp(belly, 0.0, 1.0)), middle)
		var p = f[i] + inward * d
		if raw.empty() or p.y > raw[raw.size() - 1].y:
			raw.append(p)
	var out = []
	for p in _smooth(raw, max(int(raw.size() * 0.05), 1)):
		out.append(_xy(xa.xform(Vector3(p.x, p.y, 0.0))))
	return out


const GUIDE_SAMPLES = 64


static func _fitted_guide(bs: Dictionary, xa: Transform, belly: float, gap: float) -> Array:
	var pts = []
	for a in bs["anchors"]:
		var middle = a[2]
		var d = min(lerp(middle, gap, clamp(belly, 0.0, 1.0)), middle)
		var f = 0.0
		if middle > 1e-9:
			f = d / middle
		pts.append(a[1].linear_interpolate(a[0], f))
	var ts = [0.0]
	for i in range(1, pts.size()):
		ts.append(ts[i - 1] + pts[i].distance_to(pts[i - 1]))
	var total = max(ts[ts.size() - 1], 1e-9)
	var m = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
	var rx = [0.0, 0.0, 0.0]
	var ry = [0.0, 0.0, 0.0]
	for i in pts.size():
		var t = ts[i] / total
		var row = [1.0, t, t * t]
		for r in 3:
			for c in 3:
				m[r][c] += row[r] * row[c]
			rx[r] += row[r] * pts[i].x
			ry[r] += row[r] * pts[i].y
	var cx = _solve3(m, rx)
	var cy = _solve3(m, ry)
	var out = []
	for q in GUIDE_SAMPLES + 1:
		var t = q / float(GUIDE_SAMPLES)
		var p = Vector2(cx[0] + cx[1] * t + cx[2] * t * t, cy[0] + cy[1] * t + cy[2] * t * t)
		out.append(_xy(xa.xform(Vector3(p.x, p.y, 0.0))))
	return out


static func _solve3(a: Array, b: Array) -> Array:
	var det = _det3(a)
	if abs(det) < 1e-12:
		return [b[0] / max(a[0][0], 1e-9), 0.0, 0.0]
	var out = []
	for c in 3:
		var m = [a[0].duplicate(), a[1].duplicate(), a[2].duplicate()]
		for r in 3:
			m[r][c] = b[r]
		out.append(_det3(m) / det)
	return out


static func _det3(a: Array) -> float:
	return a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1]) - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0]) + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0])


static func _room(guide: Array, gcum: Array, g0: float, bs: Dictionary, xa: Transform) -> float:
	var room = gcum[gcum.size() - 1] - g0
	var last = guide[guide.size() - 1]
	if bs.has("posed"):
		return room + last.distance_to(_xy(xa.xform(Vector3(bs["top"].x, bs["top"].y, 0.0))))
	var top = xa.affine_inverse().xform(Vector3(last.x, last.y, 0.0))
	return room + max(bs["bounds"].end.y - top.y, 0.0) * _scale(xa)


const PRESS_MAX = 0.3
const PRESS_BEND = 1.5


static func _pressed(base: Array, length: float, front: float, turn := 0.0) -> Array:
	var bc = _cumulative_open(base)
	var R = bc[bc.size() - 1]
	if R <= 1e-6 or length <= R:
		return base
	var c0 = []
	for q in 49:
		c0.append(_at_arc(base, bc, R * q / 48.0)[0])
	var hmax = PRESS_MAX * R
	if turn > 0.0:
		hmax = min(hmax, R * R / (2.0 * PI * PI * turn))
	var h = min(2.0 / PI * sqrt(R * (length - R)), hmax)
	for _i in 3:
		var got = _cumulative_open(_bowed(c0, h, front))
		var extra = got[got.size() - 1] - R
		if extra <= 1e-9 or h >= hmax:
			break
		h = min(h * sqrt((length - R) / extra), hmax)
	return _bowed(c0, h, front)


static func _bowed(c0: Array, h: float, front: float) -> Array:
	var out = []
	var m = c0.size()
	for q in m:
		var t = (c0[min(q + 1, m - 1)] - c0[max(q - 1, 0)]).normalized()
		out.append(c0[q] + Vector2(-t.y, t.x) * front * h * 0.5 * (1.0 - cos(2.0 * PI * q / float(m - 1))))
	return out


static func _front_sign(xa: Transform) -> float:
	if xa.basis.x.x * xa.basis.y.y - xa.basis.x.y * xa.basis.y.x < 0.0:
		return -1.0
	return 1.0


static func _cumulative_open(pts: Array) -> Array:
	var c = [0.0]
	for i in pts.size() - 1:
		c.append(c[i] + pts[i].distance_to(pts[i + 1]))
	return c


static func bend_points(v: PoolVector3Array, info: Dictionary) -> PoolVector3Array:
	if not info.has("ang"):
		return v
	var p = info["straight"]
	var b = info["path"]
	var dir = (p[p.size() - 1] - p[0]).normalized()
	var along = []
	for q in p:
		along.append((q - p[0]).dot(dir))
	for k in v.size():
		var q = Vector2(v[k].x, v[k].y)
		var i = along.bsearch((q - p[0]).dot(dir)) - 1
		i = int(clamp(i, 0, p.size() - 1))
		var off = q - p[i]
		if i == p.size() - 1 and off.dot(dir) > 0.0:
			off -= dir * off.dot(dir)
		var w = b[i] + off.rotated(info["ang"][i])
		v[k] = Vector3(w.x, w.y, v[k].z)
	return v


static func bend_mesh(mesh: Mesh, xf: Transform, info: Dictionary) -> ArrayMesh:
	var a = mesh.surface_get_arrays(0)
	var v = PoolVector3Array()
	for p in a[Mesh.ARRAY_VERTEX]:
		v.append(xf.xform(p))
	a[Mesh.ARRAY_VERTEX] = bend_points(v, info)
	a[Mesh.ARRAY_NORMAL] = null
	a[Mesh.ARRAY_TANGENT] = null
	a[Mesh.ARRAY_BONES] = null
	a[Mesh.ARRAY_WEIGHTS] = null
	var out = ArrayMesh.new()
	out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	out.surface_set_material(0, mesh.surface_get_material(0))
	return out


const POSED_SD_PAD = 4


static func _ensure_sd(bs: Dictionary) -> void:
	if bs.has("posed") and (not bs.has("sd") or bs.has("sd_window")):
		bs.erase("sd_window")
		_posed_sd(bs)


static func _sd_near(bs: Dictionary, box: Rect2) -> void:
	if not bs.has("posed") or (bs.has("sd") and not bs.has("sd_window")):
		return
	if bs.has("sd_window") and bs["sd_window"].encloses(box):
		return
	bs["sd_window"] = box
	_posed_sd(bs, box)


static func _posed_sd(pb: Dictionary, box = null) -> void:
	var cell = pb["cell"]
	var b = pb["bounds"]
	var origin = b.position - Vector2(cell, cell) * POSED_SD_PAD
	var gw = int(ceil(b.size.x / cell)) + 2 * POSED_SD_PAD
	var gh = int(ceil(b.size.y / cell)) + 2 * POSED_SD_PAD
	if box != null:
		var x0 = int(clamp(floor((box.position.x - origin.x) / cell) - 1, 0, gw - 2))
		var y0 = int(clamp(floor((box.position.y - origin.y) / cell) - 1, 0, gh - 2))
		var x1 = int(clamp(ceil((box.end.x - origin.x) / cell) + 1, x0 + 2, gw))
		var y1 = int(clamp(ceil((box.end.y - origin.y) / cell) + 1, y0 + 2, gh))
		origin += Vector2(x0, y0) * cell
		gw = x1 - x0
		gh = y1 - y0
	var inside = _scan(pb["outline"], origin + Vector2(0.5, 0.5) * cell, cell, gw, gh)
	var edge = PoolByteArray()
	edge.resize(gw * gh)
	for i in gw * gh:
		edge[i] = 0
	for y in gh:
		for i in range(y * gw, y * gw + gw - 1):
			if inside[i] != inside[i + 1]:
				edge[i] = 1
				edge[i + 1] = 1
	for i in gw * (gh - 1):
		if inside[i] != inside[i + gw]:
			edge[i] = 1
			edge[i + gw] = 1
	var d = BodyShape._dist(edge, gw, gh, 1)
	var sd = PoolRealArray()
	sd.resize(gw * gh)
	for i in gw * gh:
		var u = (d[i] + 0.5) * cell
		if inside[i] == 0:
			u = -u
		sd[i] = u
	pb["sd"] = sd
	pb["gw"] = gw
	pb["gh"] = gh
	pb["origin"] = origin


const ANALYZE_CHUNK = 32
const ANALYZE_FS = [0.0, -0.6, 0.6, -0.9, 0.9]


static func analyze(sw: Dictionary, bs: Dictionary, inv: Transform, k: float, rest_entry := false, throat := false) -> Dictionary:
	var dir = sw["dir"]
	var n = Vector2(-dir.y, dir.x)
	var pts = sw["pts"]
	var rad = sw["rad"]
	var sdbs = bs
	var to = Transform2D(_xy(inv.basis.x), _xy(inv.basis.y), _xy(inv.origin))
	var bind = "entry_xf"
	if throat:
		bind = "neck_xf"
	var rest = rest_entry and bs.has(bind)
	if rest:
		sdbs = bs["rest_bs"]
		to = _flat_to_rest(bs, bind) * to
	var at = -1
	var i = 0
	while i < pts.size() and at < 0:
		var m = min(i + ANALYZE_CHUNK, pts.size())
		if not rest:
			_analyze_window(bs, inv, k, pts, rad, n, max(i - 1, 0), m)
		var gw = sdbs["gw"]
		var gh = sdbs["gh"]
		var org = sdbs["origin"]
		var cell = sdbs["cell"]
		var sdv = sdbs["sd"]
		for j in range(i, m):
			for f in ANALYZE_FS:
				var g = (to.xform(pts[j] + n * rad[j] * f) - org) / cell - Vector2(0.5, 0.5)
				var cx = clamp(g.x, 0.0, gw - 1.0)
				var cy = clamp(g.y, 0.0, gh - 1.0)
				var x0 = int(cx)
				var y0 = int(cy)
				var x1 = min(x0 + 1, gw - 1)
				var y1 = min(y0 + 1, gh - 1)
				var fx = cx - x0
				var lo = lerp(sdv[y0 * gw + x0], sdv[y0 * gw + x1], fx)
				var hi = lerp(sdv[y1 * gw + x0], sdv[y1 * gw + x1], fx)
				if lerp(lo, hi, cy - y0) - (g - Vector2(cx, cy)).length() * cell > 0.0:
					at = j
					break
			if at >= 0:
				break
		i = m
	var ef = 1.0
	var entry_pt = pts[max(at, 0)]
	if at > 0:
		var v0 = _reach_in(sdbs, to, k, pts[at - 1], n, rad[at - 1])
		var v1 = _reach_in(sdbs, to, k, pts[at], n, rad[at])
		if v1 > v0:
			ef = clamp(-v0 / (v1 - v0), 0.0, 1.0)
		entry_pt = pts[at - 1].linear_interpolate(pts[at], ef)
	return {"dir": dir, "n": n, "hit": at >= 0, "entry": at, "entry_f": ef, "entry_pt": entry_pt, "base": pts[0], "tip": pts[pts.size() - 1]}


static func _analyze_window(bs: Dictionary, inv: Transform, k: float, pts: Array, rad: Array, n: Vector2, a: int, b: int) -> void:
	if not bs.has("posed"):
		return
	var q = _xy(inv.xform(_v3(pts[a])))
	var box = Rect2(q, Vector2.ZERO)
	var deep = 0.0
	for j in range(a, b):
		deep = max(deep, rad[j])
		box = box.expand(_xy(inv.xform(_v3(pts[j] + n * rad[j])))).expand(_xy(inv.xform(_v3(pts[j] - n * rad[j]))))
	if b < pts.size():
		deep += pts[b].distance_to(pts[b - 1])
	_sd_near(bs, box.grow(deep / max(k, 1e-6) + 2.0 * bs["cell"]))


static func _reach_in(bs: Dictionary, to: Transform2D, k: float, p: Vector2, n: Vector2, r: float) -> float:
	var v = -INF
	for f in ANALYZE_FS:
		v = max(v, BodyShape.sd(bs, to.xform(p + n * r * f)) * k)
	return v


static func _flat_to_rest(pb: Dictionary, bind := "entry_xf") -> Transform2D:
	var r: Transform = pb[bind]
	var sx = 1.0
	if pb["mirror"]:
		sx = -1.0
	var o = r.origin + r.basis.z * pb["z0"]
	return Transform2D(Vector2(sx * r.basis.x.x, r.basis.x.y), Vector2(sx * r.basis.y.x, r.basis.y.y), Vector2(sx * o.x, o.y)).affine_inverse()


static func deform(ma, xa, mp, xp, shape, bshape, flip, on, cover, shade, body_mat, shade_mat, lock := false, cache = null, opts := {}) -> ArrayMesh:
	var o = options(opts)
	if bshape.has("posed") and not bshape.has("uv_map"):
		o["backend"] = "cpu"
	var key = [xa, xp, flip, on, cover, shade > 0.0, lock, shape.size(), bshape.size(), o.values()]
	if cache != null and cache.get("key") == key:
		if shade > 0.0 and cache["mesh"].get_surface_count() > 1:
			shade_mat.set_shader_param("shade", shade)
		_sync_gpu(cache["mesh"], body_mat)
		return cache["mesh"]
	var t0 = OS.get_ticks_usec()
	var mesh = ArrayMesh.new()
	var info = null
	var g = null
	var pens = [[{"mesh": mp, "xp": xp, "shape": shape, "flip": flip, "throat": o["throat"], "shade_mat": shade_mat}, null, null]]
	for one in o.get("more", []):
		pens.append([one, null, null])
	var infos = []
	if on and not bshape.empty():
		var entering = []
		for pen in pens:
			var d = pen[0]
			if d["shape"].empty():
				continue
			var po = o
			if bool(d.get("throat", false)) != o["throat"]:
				po = o.duplicate()
				po["throat"] = bool(d.get("throat", false))
			var sw = _shape_world(d["shape"], d["xp"], bool(d.get("flip", false)))
			var inf = analyze(sw, bshape, xa.affine_inverse(), _scale(xa), po["entry_rest"], po["throat"])
			if inf["hit"] and (po["bend"] > 0.0 or po["stop_at_neck"]):
				sw = _bend(sw, inf["entry"], inf["entry_f"], bshape, xa, po)
				inf["tip"] = sw["pts"][sw["pts"].size() - 1]
				inf["straight"] = sw["straight"]
				inf["ang"] = sw["ang"]
				inf["guide"] = sw["guide"]
				inf["axis"] = sw["axis"]
			inf["path"] = sw["pts"]
			pen[1] = sw
			pen[2] = inf
			infos.append(inf)
			if inf["hit"]:
				entering.append([sw, inf["entry"], inf["entry_f"]])
		if pens[0][2] != null:
			info = pens[0][2]
			mesh.set_meta("info", info)
		mesh.set_meta("infos", infos)
		if not entering.empty():
			g = _geometry(bshape, xa, entering, cover, lock, o, o["gpu_shape"] and o["backend"] == "gpu" and bshape.has("uv_map"))
	var stats = {"backend": "-", "verts": 0, "tris": 0}
	var skin = null
	var mat = body_mat
	if g:
		mesh.set_meta("polys", {"body": g["W"], "sleeve": g["sp"], "sleeves": g.get("sps", [g["sp"]]), "target": g["U"]})
		if o["backend"] == "gpu":
			skin = _gpu_arrays(bshape, xa, g, o, ma)
			if skin and g.has("own"):
				stats["own"] = g["own"]
				stats["patch_src"] = g["patch_src"]
			if skin:
				mat = _gpu_material(bshape, body_mat, o)
				_gpu_params(mat, bshape, xa, g, o)
				stats["backend"] = "gpu"
		if skin == null:
			skin = _cpu_arrays(bshape, xa, g, o, ma)
			stats["backend"] = "cpu"
	if skin:
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, skin)
		stats["verts"] = skin[Mesh.ARRAY_VERTEX].size()
		stats["tris"] = skin[Mesh.ARRAY_INDEX].size() / 3
	else:
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, MeshMerge._pack(MeshMerge.extract(ma, xa)))
	mesh.surface_set_material(0, mat)
	var shaded = []
	if shade > 0.0:
		var cut = []
		if g and g.has("cut"):
			cut = g["cut"]
		var at = -1
		for pen in pens:
			var inf = pen[2]
			if inf == null:
				continue
			at += 1
			var smat = pen[0].get("shade_mat")
			if not inf["hit"] or smat == null:
				continue
			var pc = cut
			if not g and lock:
				pc = []
				var W = PoolVector2Array()
				for p in bshape["outline"]:
					W.append(_xy(xa.xform(Vector3(p.x, p.y, 0.0))))
				var whole = _sleeve_poly(pen[1], inf["entry"], cover, o, inf["entry_f"])
				if whole.size() >= 3:
					for piece in _lock_cut(bshape, xa, o["lock_at"], W):
						pc += _overlaps(whole, piece)
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _shade_arrays(pen[0]["mesh"], pen[0]["xp"], inf, pc, smat, o.get("shade_gpu", true)))
			smat.set_shader_param("shade", shade)
			mesh.surface_set_material(mesh.get_surface_count() - 1, smat)
			shaded.append(at)
	mesh.set_meta("shaded", shaded)
	if not shaded.empty():
		mesh.custom_aabb = SHADE_AABB
	if stats["backend"] != "gpu" and body_mat is ShaderMaterial:
		skin_off(body_mat)
	stats["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
	mesh.set_meta("stats", stats)
	if cache != null:
		cache["key"] = key
		cache["mesh"] = mesh
	return mesh


const SLEEVE_OPEN = 0.1
const FILLET_STEP = 0.25
const SLEEVE_THIN = 0.1


static func _geometry(bs: Dictionary, xa: Transform, pens: Array, cover: float, lock: bool, o: Dictionary, sdf := false):
	var inv = xa.affine_inverse()
	var k = _scale(xa)
	var h = o["step"] * k
	var dm = o["depth"] * k
	var margin = o["margin"] * k
	var W = Transform2D(_xy(xa.basis.x), _xy(xa.basis.y), _xy(xa.origin)).xform(PoolVector2Array(bs["outline"]))
	var lock_cut = []
	if lock:
		lock_cut = _lock_cut(bs, xa, o["lock_at"], W)
	var sps = []
	var cut = []
	var rmax = 0.0
	for pen in pens:
		var sp = _sleeve(bs, pen[0], pen[1], pen[2], cover, o, h)
		if sp.size() < 3:
			continue
		var whole = sp
		for piece in lock_cut:
			sp = _largest(Geometry.clip_polygons_2d(sp, piece))
			cut += _overlaps(whole, piece)
		if sp.size() < 3:
			continue
		sps.append(sp)
		for r in pen[0]["rad"]:
			rmax = max(rmax, r)
	if sps.empty():
		return null
	sps = _merged(sps)
	var sp = sps[0]
	var fr = max(rmax * o["fillet"], 1e-3)
	var U = W
	for one in sps:
		U = _largest(Geometry.merge_polygons_2d(U, one))
	if sdf and sps.size() == 1:
		return _sdf_shape(W, sp, U, fr, inv, k, dm, margin)
	var coarse = max(h, fr * FILLET_STEP)
	var closed = _largest(_offset(_largest(_offset(_resample(U, coarse), fr)), -fr))
	for one in sps:
		var near = _largest(_offset(_resample(one, coarse), fr * 1.5))
		for piece in Geometry.intersect_polygons_2d(closed, near):
			if not Geometry.is_polygon_clockwise(piece):
				U = _largest(Geometry.merge_polygons_2d(U, piece))
	if Geometry.is_polygon_clockwise(U):
		U.invert()
	var Wd = _resample(W, h)
	var Ud = _resample(U, h)
	var bsz = h * 4.0
	var bk = _buckets(Ud, bsz)
	var cum = _cumulative(Ud)
	var L = cum[Ud.size()]
	var N = Wd.size()
	var inside = []
	var sbs = []
	for one in sps:
		sbs.append(_rect(one).grow(1e-4))
	for p in Wd:
		var got = false
		for q in sps.size():
			if sbs[q].has_point(p) and Geometry.is_point_in_polygon(p, sps[q]):
				got = true
				break
		inside.append(got)
	var start = inside.find(false)
	if start < 0 or inside.find(true) < 0:
		return null
	Wd = _rotate(Wd, start)
	inside = _rotate(inside, start)
	var nn = _nearest(Ud, bk, bsz, Wd[0])
	var Up = [_param(Ud, cum, nn)]
	var on = 0.1 * h
	var nu = Ud.size()
	var seg = PoolVector2Array()
	var den = PoolRealArray()
	seg.resize(nu)
	den.resize(nu)
	for i in nu:
		var ab = Ud[(i + 1) % nu] - Ud[i]
		seg[i] = ab
		den[i] = max(ab.length_squared(), 1e-12)
	var hint = nn[0]
	var j = 1
	while j <= N:
		if j < N and inside[j]:
			var r1 = j
			while r1 < N and inside[r1]:
				r1 += 1
			nn = _nearest(Ud, bk, bsz, Wd[r1 % N], hint, 200, on)
			hint = nn[0]
			var du = fposmod(_param(Ud, cum, nn) - fposmod(Up[j - 1], L), L)
			if du > 0.95 * L:
				du = 0.0
			var arc = [0.0]
			for t in range(j, r1 + 1):
				arc.append(arc[arc.size() - 1] + Wd[(t - 1) % N].distance_to(Wd[t % N]))
			for t in range(1, arc.size()):
				Up.append(Up[j - 1] + du * arc[t] / max(arc[arc.size() - 1], 1e-6))
			j = r1 + 1
		else:
			var p = Wd[j % N]
			var bd = INF
			var bi = 0
			var bf = 0.0
			for w in range(hint, hint + 4):
				var i = w % nu
				var a = Ud[i]
				var f = clamp((p - a).dot(seg[i]) / den[i], 0.0, 1.0)
				var d = p.distance_to(a + seg[i] * f)
				if d < bd:
					bd = d
					bi = i
					bf = f
			var u = 0.0
			if bd <= on:
				u = cum[bi] + bf * (cum[bi + 1] - cum[bi])
			else:
				nn = _nearest(Ud, bk, bsz, p, hint, 200, on)
				bi = nn[0]
				u = _param(Ud, cum, nn)
			hint = bi
			var du = fposmod(u - fposmod(Up[j - 1], L), L)
			if du > 0.5 * L:
				du = 0.0
			Up.append(Up[j - 1] + du)
			j += 1
	var Wn = []
	for i in N:
		var t = (Wd[(i + 1) % N] - Wd[(i - 1 + N) % N]).normalized()
		Wn.append(Vector2(-t.y, t.x))
	var src = []
	var nrm = []
	src.resize(Ud.size())
	nrm.resize(Ud.size())
	var lo = 0
	var u0 = Up[0]
	for i in Ud.size():
		var v = u0 + fposmod(cum[i] - u0, L)
		if Up[lo] > v:
			lo = 0
		while lo + 1 < N and Up[lo + 1] <= v:
			lo += 1
		var f = clamp((v - Up[lo]) / max(Up[lo + 1] - Up[lo], 1e-9), 0.0, 1.0)
		var w0 = lo % N
		var w1 = (lo + 1) % N
		src[i] = Wd[w0].linear_interpolate(Wd[w1], f)
		nrm[i] = Wn[w0].linear_interpolate(Wn[w1], f).normalized()
	return {"W": W, "sp": sp, "sps": sps, "U": U, "Ud": Ud, "src": src, "nrm": nrm, "bk": bk, "bsz": bsz, "fr": fr,
		"inv": inv, "k": k, "dm": dm, "margin": margin, "cut": cut}


static func _sleeve(bs: Dictionary, sw: Dictionary, entry: int, entry_f: float, cover: float, o: Dictionary, h: float) -> PoolVector2Array:
	var sp = _sleeve_poly(sw, entry, cover, o, entry_f)
	if sp.size() < 3:
		return PoolVector2Array()
	if bs.has("posed"):
		sp = _largest(Geometry.merge_polygons_2d(sp, sp))
		if sp.size() < 3:
			return PoolVector2Array()
	var e = 0.0
	for r in sw["rad"]:
		e = max(e, r)
	e *= o["skin"] * SLEEVE_OPEN
	sp = _thin(sp, SLEEVE_THIN * h)
	var opened = _largest(_offset(_largest(_offset(sp, -e, OPEN_TOL)), e, OPEN_TOL))
	if opened.size() >= 3 and abs(BodyShape.area(opened)) > 0.85 * abs(BodyShape.area(sp)):
		sp = _thin(opened, SLEEVE_THIN * h)
	return sp


static func _merged(sps: Array) -> Array:
	var out = []
	for one in sps:
		var cur = one
		var rest = []
		for other in out:
			var u = Geometry.merge_polygons_2d(cur, other)
			var outer = []
			for piece in u:
				if not Geometry.is_polygon_clockwise(piece):
					outer.append(piece)
			if outer.size() == 1:
				cur = outer[0]
			else:
				rest.append(other)
		rest.append(cur)
		out = rest
	return out


static func _sdf_shape(W: PoolVector2Array, sp: PoolVector2Array, U: PoolVector2Array, fr: float, inv: Transform, k: float, dm: float, margin: float):
	if BodyShape.area(sp) < 0.0:
		sp.invert()
	var nw = W.size()
	var ns = sp.size()
	var sb = _rect(sp).grow(1e-4)
	var inside = []
	inside.resize(nw)
	var any_in = false
	var any_out = false
	for i in nw:
		inside[i] = sb.has_point(W[i]) and Geometry.is_point_in_polygon(W[i], sp)
		if inside[i]:
			any_in = true
		else:
			any_out = true
	if not any_in or not any_out:
		return null
	var r0 = -1
	var best = 0
	var i = 0
	var start = inside.find(false)
	while i < nw:
		var j = (start + i) % nw
		if inside[j]:
			var run = 0
			while run < nw and inside[(j + run) % nw]:
				run += 1
			if run > best:
				best = run
				r0 = j
			i += run
		else:
			i += 1
	var sig = PoolRealArray()
	sig.resize(ns)
	var acc = 0.0
	for q in ns:
		sig[q] = acc
		acc += sp[q].distance_to(sp[(q + 1) % ns])
	var sp_len = acc
	var j1 = _cross_sp(W[(r0 - 1 + nw) % nw], W[r0], sp, sig)
	var j2 = _cross_sp(W[(r0 + best - 1) % nw], W[(r0 + best) % nw], sp, sig)
	var Wn = PoolVector2Array()
	Wn.resize(nw)
	for q in nw:
		var t = (W[(q + 1) % nw] - W[(q - 1 + nw) % nw]).normalized()
		Wn[q] = Vector2(-t.y, t.x)
	var P = PoolVector2Array([j1[0]])
	var Pn = PoolVector2Array([Wn[(r0 - 1 + nw) % nw].linear_interpolate(Wn[r0], 0.5).normalized()])
	for q in best:
		P.append(W[(r0 + q) % nw])
		Pn.append(Wn[(r0 + q) % nw])
	P.append(j2[0])
	Pn.append(Wn[(r0 + best - 1) % nw].linear_interpolate(Wn[(r0 + best) % nw], 0.5).normalized())
	var Pc = PoolRealArray([0.0])
	for q in range(1, P.size()):
		Pc.append(Pc[q - 1] + P[q].distance_to(P[q - 1]))
	var Wb = PoolRealArray()
	Wb.resize(nw)
	for q in nw:
		Wb[q] = float(not inside[q])
	var sig_len = fposmod(j2[1] - j1[1], sp_len)
	if sig_len <= 1e-6:
		return null
	return {"W": W, "sp": sp, "U": U, "fr": fr, "inv": inv, "k": k, "dm": dm, "margin": margin, "sdf": {"W": W, "Wn": Wn,
		"sp": sp, "sig": sig, "sp_len": sp_len, "sig_a": j1[1], "sig_len": sig_len, "P": P, "Pn": Pn, "Pc": Pc, "Wb": Wb}}


static func _cross_sp(a: Vector2, b: Vector2, sp: PoolVector2Array, sig: PoolRealArray) -> Array:
	var ns = sp.size()
	var best = [b, 0.0]
	var bd = INF
	for q in ns:
		var c = sp[q]
		var e = sp[(q + 1) % ns]
		var x = Geometry.segment_intersects_segment_2d(a, b, c, e)
		if x != null:
			var d = a.distance_to(x)
			if d < bd:
				bd = d
				best = [x, sig[q] + c.distance_to(x)]
	if bd == INF:
		for q in ns:
			var c = sp[q]
			var e = sp[(q + 1) % ns]
			var x = Geometry.get_closest_point_to_segment_2d(b, c, e)
			var d = b.distance_to(x)
			if d < bd:
				bd = d
				best = [x, sig[q] + c.distance_to(x)]
	return best


static func _cpu_arrays(bs: Dictionary, xa: Transform, g: Dictionary, o: Dictionary, ma: Mesh):
	_ensure_sd(bs)
	var U = g["U"]
	var Ud = g["Ud"]
	var G = _grown(g)
	var src = g["src"]
	var nrm = g["nrm"]
	var bk = g["bk"]
	var bsz = g["bsz"]
	var inv = g["inv"]
	var k = g["k"]
	var dm = g["dm"]
	var margin = g["margin"]
	var gr = _grid(G, o["cell"] * k)
	if gr.empty():
		return null
	var box = gr["box"]
	var c = gr["c"]
	var nx = gr["nx"]
	var ny = gr["ny"]
	var used = gr["used"]
	var idx = gr["idx"]
	var in_u = _scan(U, box.position, c, nx, ny)
	var zones = []
	for one in g.get("sps", [g["sp"]]):
		zones.append(_largest(_offset(one, g["fr"] * 1.5 + dm + 2.0 * margin)))
	var in_z = _scan_any(zones, box.position, c, nx, ny)
	var in_w = _scan(g["W"], box.position, c, nx, ny)
	var ua = _uv_affine(bs, inv)
	var uo = ua[0]
	var ux = ua[1]
	var uy = ua[2]
	var sk = _skin_data(ma, bs)
	var posed = bs.has("posed")
	var M = Ud.size()
	var rings = int(ceil((dm + 2.0 * margin) / bsz))
	var hint = -1
	var verts = PoolVector3Array()
	var uvs = PoolVector2Array()
	verts.resize(nx * ny)
	uvs.resize(nx * ny)
	for q in nx * ny:
		var x = box.position + Vector2(q % nx, q / nx) * c
		verts[q] = Vector3(x.x, x.y, 0.0)
		var s = x
		if used[q] and (in_z[q] or not in_w[q]):
			var wid = smoothstep(0.5 * dm, dm, BodyShape.sd(bs, _xy(inv.xform(verts[q]))) * k)
			if wid < 1.0:
				var reach = rings
				if not in_w[q]:
					reach = 200
				var nn = _nearest(Ud, bk, bsz, x, hint, reach)
				var i = nn[0]
				hint = i
				var f = nn[1]
				var d = nn[2]
				if not in_u[q]:
					d = -d
				var at = src[i].linear_interpolate(src[(i + 1) % M], f) + nrm[i].linear_interpolate(nrm[(i + 1) % M], f).normalized() * clamp(d, -2.0 * margin, dm)
				s = at.linear_interpolate(x, wid)
		if posed and used[q]:
			var ps =_xy(inv.xform(Vector3(s.x, s.y, 0.0)))
			var su = _skin_at(sk, bs, ps, _lattice_key(ps, 0.002))
			var off = ps - su["q"]
			uvs[q] = su["uv"] + su["j"][0] * off.x + su["j"][1] * off.y
		else:
			uvs[q] = uo + ux * s.x + uy * s.y
	var nors = PoolVector3Array()
	var cols = PoolColorArray()
	nors.resize(nx * ny)
	cols.resize(nx * ny)
	for q in nx * ny:
		nors[q] = Vector3.BACK
		cols[q] = Color.white
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = nors
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	if sk["skinned"]:
		var bones = PoolIntArray()
		var weights = PoolRealArray()
		for q in nx * ny:
			if used[q]:
				var at = _skin_at(sk, bs, _xy(inv.xform(verts[q])), _lattice_key(_xy(verts[q]), c))
				bones.append_array(at["b"])
				weights.append_array(at["w"])
			else:
				bones.append_array(NO_BONES)
				weights.append_array(NO_WEIGHTS)
		arrays[Mesh.ARRAY_BONES] = bones
		arrays[Mesh.ARRAY_WEIGHTS] = weights
	return arrays


static func _grid(G, c: float) -> Dictionary:
	var box = _rect(G)
	var p0 = Vector2(floor(box.position.x / c) * c, floor(box.position.y / c) * c)
	box = Rect2(p0, box.end - p0)
	var nx = int(ceil(box.size.x / c)) + 1
	var ny = int(ceil(box.size.y / c)) + 1
	var in_g = _scan(G, box.position + Vector2(0.5, 0.5) * c, c, nx - 1, ny - 1)
	var used = PoolByteArray()
	used.resize(nx * ny)
	for q in nx * ny:
		used[q] = 0
	var idx = PoolIntArray()
	for gy in ny - 1:
		for gx in nx - 1:
			if in_g[gy * (nx - 1) + gx]:
				var a = gy * nx + gx
				idx.append(a)
				idx.append(a + 1)
				idx.append(a + nx + 1)
				idx.append(a)
				idx.append(a + nx + 1)
				idx.append(a + nx)
				used[a] = 1
				used[a + 1] = 1
				used[a + nx] = 1
				used[a + nx + 1] = 1
	if idx.size() == 0:
		return {}
	return {"box": box, "c": c, "nx": nx, "ny": ny, "used": used, "idx": idx}


static func _uv_affine(bs: Dictionary, inv: Transform) -> Array:
	var fit = bs["fit"]
	var uo = ShaftShape.restToUV(fit, _xy(inv.xform(Vector3.ZERO)))
	return [uo, ShaftShape.restToUV(fit, _xy(inv.xform(Vector3.RIGHT))) - uo, ShaftShape.restToUV(fit, _xy(inv.xform(Vector3.UP))) - uo]


static func _gpu_arrays(bs: Dictionary, xa: Transform, g: Dictionary, o: Dictionary, ma: Mesh):
	if bs.has("uv_map"):
		return _gpu_posed_arrays(bs, g, o, ma)
	var gr = _grid(_grown(g), o["gpu_cell"] * g["k"])
	if gr.empty():
		return null
	var ua = _uv_affine(bs, g["inv"])
	var sk = _skin_data(ma, bs)
	var n = gr["nx"] * gr["ny"]
	var verts = PoolVector3Array()
	var nors = PoolVector3Array()
	var uvs = PoolVector2Array()
	var pos = PoolVector2Array()
	var cols = PoolColorArray()
	var bones = PoolIntArray()
	var weights = PoolRealArray()
	verts.resize(n)
	nors.resize(n)
	uvs.resize(n)
	pos.resize(n)
	cols.resize(n)
	for q in n:
		var x = gr["box"].position + Vector2(q % gr["nx"], q / gr["nx"]) * gr["c"]
		verts[q] = Vector3(x.x, x.y, 0.0)
		nors[q] = Vector3.BACK
		pos[q] = x
		cols[q] = Color.white
		var uv = ua[0] + ua[1] * x.x + ua[2] * x.y
		var at = null
		if gr["used"][q]:
			at = _skin_at(sk, bs, _xy(g["inv"].xform(verts[q])), _lattice_key(x, gr["c"]))
			var d = x - _xy(xa.xform(Vector3(at["q"].x, at["q"].y, 0.0)))
			uv = at["uv"] + ua[1] * d.x + ua[2] * d.y
		uvs[q] = uv
		if sk["skinned"]:
			if at:
				bones.append_array(at["b"])
				weights.append_array(at["w"])
			else:
				bones.append_array(NO_BONES)
				weights.append_array(NO_WEIGHTS)
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = nors
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_TEX_UV2] = pos
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = gr["idx"]
	if sk["skinned"]:
		arrays[Mesh.ARRAY_BONES] = bones
		arrays[Mesh.ARRAY_WEIGHTS] = weights
	return arrays


static func _grown(g: Dictionary) -> PoolVector2Array:
	return _largest(_offset(g["U"], g["margin"]))


static func _gpu_posed_arrays(bs: Dictionary, g: Dictionary, o: Dictionary, ma: Mesh):
	var c = max(o["gpu_cell"] * g["k"], o["gpu_cell_fr"] * g["fr"])
	var grow = g["fr"] * 1.5 + g["dm"] + 2.0 * g["margin"]
	var step = max(grow * 0.25, c)
	var zones = []
	for one in g.get("sps", [g["sp"]]):
		zones.append(_largest(_offset(_resample(one, step), grow + step)))
	var zb = _rect(zones[0])
	for one in zones:
		zb = zb.merge(_rect(one))
	var box = _rect(g["U"]).grow(g["margin"]).clip(zb.grow(c))
	var p0 = Vector2(floor(box.position.x / c) * c, floor(box.position.y / c) * c)
	var nx = int(ceil((box.end.x - p0.x) / c)) + 1
	var ny = int(ceil((box.end.y - p0.y) / c)) + 1
	var at = p0 + Vector2(0.5, 0.5) * c
	var in_z = _scan_any(zones, at, c, nx - 1, ny - 1)
	var in_w = _scan(g["W"], p0, c, nx, ny)
	var a = ma.surface_get_arrays(0)
	var verts = a[Mesh.ARRAY_VERTEX]
	var nors = a[Mesh.ARRAY_NORMAL]
	var uvs = a[Mesh.ARRAY_TEX_UV]
	var bones = a[Mesh.ARRAY_BONES]
	var weights = a[Mesh.ARRAY_WEIGHTS]
	var idx = a[Mesh.ARRAY_INDEX]
	var nb = verts.size()
	var room = nb + nx * ny
	var pos = PoolVector2Array()
	var cols = PoolColorArray()
	pos.resize(room)
	cols.resize(room)
	for i in nb:
		var v = verts[i]
		pos[i] = Vector2(v.x, v.y)
		cols[i] = Color.white
	if nors == null or nors.size() != nb:
		nors = PoolVector3Array()
		nors.resize(nb)
		for i in nb:
			nors[i] = Vector3.BACK
	var body_pts = pos
	body_pts.resize(nb)
	verts.resize(room)
	nors.resize(room)
	uvs.resize(room)
	var nv = nb
	var ni = idx.size()
	idx.resize(ni + 6 * (nx - 1) * (ny - 1))
	var made = PoolIntArray()
	made.resize(nx * ny)
	for i in nx * ny:
		made[i] = -1
	var offs = [0, 1, nx + 1, nx]
	var corner = [0, 0, 0, 0]
	for gy in ny - 1:
		for gx in nx - 1:
			var ci = gy * (nx - 1) + gx
			var k0 = gy * nx + gx
			if not in_z[ci] or (in_w[k0] and in_w[k0 + 1] and in_w[k0 + nx] and in_w[k0 + nx + 1]):
				continue
			for q in 4:
				var key = gy * nx + gx + offs[q]
				if made[key] < 0:
					var x = p0 + Vector2(key % nx, key / nx) * c
					made[key] = nv
					verts[nv] = Vector3(x.x, x.y, 0.0)
					nors[nv] = Vector3.BACK
					uvs[nv] = Vector2.ZERO
					pos[nv] = x
					cols[nv] = Color.white
					nv += 1
					zb = zb.expand(x)
				corner[q] = made[key]
			idx[ni] = corner[0]
			idx[ni + 1] = corner[1]
			idx[ni + 2] = corner[2]
			idx[ni + 3] = corner[0]
			idx[ni + 4] = corner[2]
			idx[ni + 5] = corner[3]
			ni += 6
	verts.resize(nv)
	nors.resize(nv)
	uvs.resize(nv)
	pos.resize(nv)
	cols.resize(nv)
	idx.resize(ni)
	var o4 = nb * 4
	bones.resize(nv * 4)
	weights.resize(nv * 4)
	var src = _patch_sources(nv - nb, nb, pos, body_pts)
	for vi in src:
		for j in range(vi * 4, vi * 4 + 4):
			bones[o4] = bones[j]
			weights[o4] = weights[j]
			o4 += 1
	g["zone"] = zb.grow(2.0 * g["margin"])
	g["own"] = nb
	g["patch_src"] = src
	a[Mesh.ARRAY_VERTEX] = verts
	a[Mesh.ARRAY_NORMAL] = nors
	a[Mesh.ARRAY_TEX_UV] = uvs
	a[Mesh.ARRAY_TEX_UV2] = pos
	a[Mesh.ARRAY_COLOR] = cols
	a[Mesh.ARRAY_BONES] = bones
	a[Mesh.ARRAY_WEIGHTS] = weights
	a[Mesh.ARRAY_INDEX] = idx
	a[Mesh.ARRAY_TANGENT] = null
	return a


static func _patch_sources(n: int, nb: int, at: PoolVector2Array, pts: PoolVector2Array) -> PoolIntArray:
	var near = AStar2D.new()
	near.reserve_space(pts.size())
	for vi in pts.size():
		near.add_point(vi, pts[vi])
	var src = PoolIntArray()
	src.resize(n)
	for i in n:
		src[i] = near.get_closest_point(at[nb + i])
	return src


static func _skin_data(ma: Mesh, bs: Dictionary) -> Dictionary:
	if bs.has("skin_data"):
		return bs["skin_data"]
	var a = ma.surface_get_arrays(0)
	var v = a[Mesh.ARRAY_VERTEX]
	var idx = a[Mesh.ARRAY_INDEX]
	if idx == null or idx.size() == 0:
		idx = range(v.size())
	var bones = a[Mesh.ARRAY_BONES]
	var weights = a[Mesh.ARRAY_WEIGHTS]
	var skinned = bones != null and weights != null and bones.size() == v.size() * 4 and weights.size() == v.size() * 4
	var pts = []
	for p in v:
		pts.append(Vector2(p.x, p.y))
	var box = ma.get_aabb()
	var cell = max(max(box.size.x, box.size.y) / 32.0, 1e-6)
	var tris = {}
	for t in range(0, idx.size() - 2, 3):
		var p0 = pts[idx[t]]
		var p1 = pts[idx[t + 1]]
		var p2 = pts[idx[t + 2]]
		for gx in range(int(floor(min(p0.x, min(p1.x, p2.x)) / cell)), int(floor(max(p0.x, max(p1.x, p2.x)) / cell)) + 1):
			for gy in range(int(floor(min(p0.y, min(p1.y, p2.y)) / cell)), int(floor(max(p0.y, max(p1.y, p2.y)) / cell)) + 1):
				var key = gx * 65536 + gy
				if not tris.has(key):
					tris[key] = []
				tris[key].append(t)
	var data = {"p": pts, "i": idx, "uv": a[Mesh.ARRAY_TEX_UV], "bones": bones, "weights": weights, "skinned": skinned,
		"hash": tris, "cell": cell, "at": {}}
	if bs.has("rest_bs"):
		var rest = []
		for p in bs["rest_v"]:
			rest.append(Vector2(p.x, p.y))
		data["rest"] = rest
		data["rest_bs"] = bs["rest_bs"]
	bs["skin_data"] = data
	return data


static func _skin_at(sk: Dictionary, bs: Dictionary, r: Vector2, key: int) -> Dictionary:
	if sk["at"].has(key):
		return sk["at"][key]
	var q = r
	if BodyShape.sd(bs, r) < 0.0:
		var ol = bs["outline"]
		if not sk.has("ol_bk"):
			sk["ol_size"] = bs["cell"] * 4.0
			sk["ol_bk"] = _buckets(ol, sk["ol_size"])
		var nn = _nearest(ol, sk["ol_bk"], sk["ol_size"], r)
		q = ol[nn[0]].linear_interpolate(ol[(nn[0] + 1) % ol.size()], nn[1])
	var pts = sk["p"]
	var idx = sk["i"]
	var corners = []
	var lam = []
	var cellKey = int(floor(q.x / sk["cell"])) * 65536 + int(floor(q.y / sk["cell"]))
	var deepest = -INF
	for t in sk["hash"].get(cellKey, []):
		var l = _barycentric(q, pts[idx[t]], pts[idx[t + 1]], pts[idx[t + 2]])
		if l.x >= -1e-5 and l.y >= -1e-5 and l.z >= -1e-5:
			var depth = 0.0
			if sk.has("rest"):
				var rp = sk["rest"]
				depth = BodyShape.sd(sk["rest_bs"], rp[idx[t]] * l.x + rp[idx[t + 1]] * l.y + rp[idx[t + 2]] * l.z)
			if depth > deepest:
				deepest = depth
				corners = [idx[t], idx[t + 1], idx[t + 2]]
				lam = [l.x, l.y, l.z]
			if not sk.has("rest"):
				break
	if corners.empty():
		var best = 0
		var bd2 = INF
		for i in pts.size():
			if pts[i].distance_squared_to(q) < bd2:
				bd2 = pts[i].distance_squared_to(q)
				best = i
		corners = [best]
		lam = [1.0]
	var uv = Vector2.ZERO
	var mb = []
	var mw = []
	var sb = sk["bones"]
	var sw = sk["weights"]
	for c in corners.size():
		uv += sk["uv"][corners[c]] * lam[c]
		if sk["skinned"]:
			for j in 4:
				var w = sw[corners[c] * 4 + j] * lam[c]
				if w <= 0.0:
					continue
				var b = sb[corners[c] * 4 + j]
				var at = mb.find(b)
				if at < 0:
					mb.append(b)
					mw.append(w)
				else:
					mw[at] += w
	var bs4 = [0, 0, 0, 0]
	var ws4 = [0.0, 0.0, 0.0, 0.0]
	var total = 0.0
	for j in 4:
		var top = -1
		for m in mw.size():
			if top < 0 or mw[m] > mw[top]:
				top = m
		if top < 0 or mw[top] <= 0.0:
			break
		bs4[j] = mb[top]
		ws4[j] = mw[top]
		total += mw[top]
		mw[top] = -1.0
	if total > 0.0:
		for j in 4:
			ws4[j] /= total
	var j = [Vector2.ZERO, Vector2.ZERO]
	if corners.size() == 3:
		var e1 = pts[corners[1]] - pts[corners[0]]
		var e2 = pts[corners[2]] - pts[corners[0]]
		var u1 = sk["uv"][corners[1]] - sk["uv"][corners[0]]
		var u2 = sk["uv"][corners[2]] - sk["uv"][corners[0]]
		var det = e1.x * e2.y - e2.x * e1.y
		if abs(det) > 1e-12:
			j = [(u1 * e2.y - u2 * e1.y) / det, (u2 * e1.x - u1 * e2.x) / det]
	var out = {"q": q, "uv": uv, "b": PoolIntArray(bs4), "w": PoolRealArray(ws4), "j": j}
	sk["at"][key] = out
	return out


const NO_BONES = [0, 0, 0, 0]
const NO_WEIGHTS = [0.0, 0.0, 0.0, 0.0]


static func _lattice_key(x: Vector2, c: float) -> int:
	return ((int(round(x.x / c)) + 32768) * 65536 + (int(round(x.y / c)) + 32768)) * 64 + int(round(c * 1000.0)) % 64


static func _barycentric(p: Vector2, a: Vector2, b: Vector2, c: Vector2) -> Vector3:
	var v0 = b - a
	var v1 = c - a
	var v2 = p - a
	var den = v0.x * v1.y - v1.x * v0.y
	if abs(den) < 1e-12:
		return Vector3(-1, -1, -1)
	var l1 = (v2.x * v1.y - v1.x * v2.y) / den
	var l2 = (v0.x * v2.y - v2.x * v0.y) / den
	return Vector3(1.0 - l1 - l2, l1, l2)


static func _gpu_material(bs: Dictionary, body_mat, o: Dictionary) -> ShaderMaterial:
	var mat = null
	if body_mat is ShaderMaterial:
		var sh = body_mat.shader
		if not sh.has_meta("bulge_skin"):
			if not sh.has_meta("bulge_shader"):
				var gen = Shader.new()
				gen.code = skin_shader(sh.code, o["shader_extra"])
				gen.set_meta("bulge_skin", true)
				sh.set_meta("bulge_shader", gen)
			body_mat.shader = sh.get_meta("bulge_shader")
		mat = body_mat
	elif bs.has("gpu_mat"):
		mat = bs["gpu_mat"]
	else:
		var gen2 = Shader.new()
		gen2.code = skin_shader(BASE_SHADER)
		mat = ShaderMaterial.new()
		mat.shader = gen2
		mat.set_meta("body_skin", true)
		mat.set_shader_param("albedo_tex", body_mat.albedo_texture)
		bs["gpu_mat"] = mat
	if not bs.has("uv_map"):
		if not bs.has("gpu_sd"):
			var img = Image.new()
			img.create(bs["gw"], bs["gh"], false, Image.FORMAT_RF)
			img.lock()
			for y in bs["gh"]:
				for x in bs["gw"]:
					img.set_pixel(x, y, Color(bs["sd"][y * bs["gw"] + x], 0, 0))
			img.unlock()
			var tex = ImageTexture.new()
			if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
				tex.create_from_image(gles2_table(img), 0)
			else:
				tex.create_from_image(img, Texture.FLAG_FILTER)
			bs["gpu_sd"] = tex
		mat.set_shader_param("bulge_sd", bs["gpu_sd"])
		if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
			mat.set_shader_param("bulge_sd_px", Vector2(bs["gw"], bs["gh"]))
		mat.set_shader_param("bulge_sd_origin", bs["origin"])
		mat.set_shader_param("bulge_sd_size", Vector2(bs["gw"], bs["gh"]) * bs["cell"])
	_sync(mat, body_mat)
	return mat


static func _sync(mat: ShaderMaterial, body_mat) -> void:
	if body_mat is SpatialMaterial:
		mat.set_shader_param("albedo_color", body_mat.albedo_color)


static func _sync_gpu(mesh: ArrayMesh, body_mat) -> void:
	var gpu = mesh.has_meta("stats") and mesh.get_meta("stats")["backend"] == "gpu"
	if body_mat is ShaderMaterial:
		body_mat.set_shader_param("bulge_on", gpu)
	var mat = mesh.surface_get_material(0)
	if mat is ShaderMaterial and mat.has_meta("body_skin"):
		_sync(mat, body_mat)


static func skin_off(mat) -> void:
	if mat is ShaderMaterial:
		mat.set_shader_param("bulge_on", false)


static func _gpu_params(mat: ShaderMaterial, bs: Dictionary, xa: Transform, g: Dictionary, o: Dictionary) -> void:
	var inv = g["inv"]
	var r0 = _xy(inv.xform(Vector3.ZERO))
	var rx = _xy(inv.xform(Vector3.RIGHT)) - r0
	var ry = _xy(inv.xform(Vector3.UP)) - r0
	mat.set_shader_param("bulge_rest_x", Vector3(rx.x, ry.x, r0.x))
	mat.set_shader_param("bulge_rest_y", Vector3(rx.y, ry.y, r0.y))
	var ua = _uv_affine(bs, inv)
	mat.set_shader_param("bulge_uv_x", ua[1])
	mat.set_shader_param("bulge_uv_y", ua[2])
	mat.set_shader_param("bulge_posed", bs.has("uv_map"))
	if bs.has("uv_map"):
		mat.set_shader_param("bulge_uv_map", bs["uv_map"]["tex"])
		mat.set_shader_param("bulge_uv_map_origin", bs["uv_map"]["origin"])
		mat.set_shader_param("bulge_uv_map_size", bs["uv_map"]["size"])
		if bs["uv_map"].has("depth"):
			mat.set_shader_param("bulge_uv_depth", bs["uv_map"]["depth"])
			mat.set_shader_param("bulge_uv_map_px", bs["uv_map"]["tex"].get_width())
	var zb = g.get("zone", Rect2(-1e9, -1e9, 2e9, 2e9))
	var reach = g["dm"]
	var hs = PoolRealArray()
	if not g.has("sdf"):
		hs = _bulge_heights(g["Ud"], g["src"])
		var fade = o["mvc"]
		if fade > 0.0:
			for h in hs:
				reach = max(reach, fade * h)
			zb = zb.grow(reach - g["dm"])
	mat.set_shader_param("bulge_zone", Plane(zb.position.x, zb.position.y, zb.end.x, zb.end.y))
	mat.set_shader_param("bulge_mvc", o["mvc"] > 0.0)
	mat.set_shader_param("bulge_reach", reach)
	mat.set_shader_param("bulge_k", g["k"])
	mat.set_shader_param("bulge_depth", g["dm"])
	mat.set_shader_param("bulge_margin", g["margin"])
	mat.set_shader_param("bulge_sdf", g.has("sdf"))
	if g.has("sdf"):
		_sdf_params(mat, g["sdf"], g["fr"] * o["sdf_fillet"])
		mat.set_shader_param("bulge_on", true)
		return
	var Ud = g["Ud"]
	var src = g["src"]
	var nrm = g["nrm"]
	var nu = Ud.size()
	var img = null
	if mat.has_meta("border_img"):
		img = mat.get_meta("border_img")
	if img == null or img.get_width() < nu:
		img = Image.new()
		img.create(nearest_po2(nu), 3, false, Image.FORMAT_RGBAF)
		var t = ImageTexture.new()
		t.create_from_image(gles2_table(img), 0)
		mat.set_meta("border_img", img)
		mat.set_meta("border_tex", t)
	img.lock()
	for i in nu:
		img.set_pixel(i, 0, Color(Ud[i].x, Ud[i].y, src[i].x, src[i].y))
		img.set_pixel(i, 1, Color(nrm[i].x, nrm[i].y, 0, 0))
	_chunk_boxes(img, Ud, 2)
	img.unlock()
	var tex = mat.get_meta("border_tex")
	if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
		tex.set_data(gles2_table(img))
		mat.set_shader_param("bulge_border_px", tex.get_size())
	else:
		tex.set_data(img)
	mat.set_shader_param("bulge_border", tex)
	mat.set_shader_param("bulge_border_n", Ud.size())
	mat.set_shader_param("bulge_on", true)


static func _sdf_params(mat: ShaderMaterial, d: Dictionary, fillet: float) -> void:
	var sp = d["sp"]
	var W = d["W"]
	var P = d["P"]
	var w = max(max(sp.size(), W.size()), P.size())
	var img = Image.new()
	img.create(w, 8, false, Image.FORMAT_RGBAF)
	img.lock()
	for i in sp.size():
		img.set_pixel(i, 0, Color(sp[i].x, sp[i].y, d["sig"][i], 0))
	_chunk_boxes(img, sp, 1)
	for i in W.size():
		img.set_pixel(i, 2, Color(W[i].x, W[i].y, d["Wn"][i].x, d["Wn"][i].y))
	_chunk_boxes(img, W, 3)
	for i in P.size():
		img.set_pixel(i, 4, Color(P[i].x, P[i].y, d["Pn"][i].x, d["Pn"][i].y))
		img.set_pixel(i, 5, Color(d["Pc"][i], 0, 0, 0))
	for i in W.size():
		img.set_pixel(i, 6, Color(d["Wb"][i], 0, 0, 0))
	for i in sp.size():
		var t = fposmod(d["sig"][i] - d["sig_a"], d["sp_len"])
		img.set_pixel(i, 7, Color(float(t <= d["sig_len"] + 1e-6), 0, 0, 0))
	img.unlock()
	var tex = ImageTexture.new()
	tex.create_from_image(gles2_table(img), 0)
	mat.set_shader_param("bulge_shape", tex)
	if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
		mat.set_shader_param("bulge_shape_px", tex.get_size())
	mat.set_shader_param("bulge_sp_n", sp.size())
	mat.set_shader_param("bulge_w_n", W.size())
	mat.set_shader_param("bulge_p_n", P.size())
	mat.set_shader_param("bulge_sp_len", d["sp_len"])
	mat.set_shader_param("bulge_sig_a", d["sig_a"])
	mat.set_shader_param("bulge_sig_len", d["sig_len"])
	mat.set_shader_param("bulge_fillet", max(fillet, 1e-5))


static func _bulge_heights(Ud: PoolVector2Array, src: PoolVector2Array) -> PoolRealArray:
	var n = Ud.size()
	var h = PoolRealArray()
	h.resize(n)
	for i in n:
		h[i] = Ud[i].distance_to(src[i])
	var out = PoolRealArray()
	out.resize(n)
	var w = min(HEIGHT_SMOOTH, (n - 1) / 2)
	var acc = 0.0
	for k in range(-w, w + 1):
		acc += h[posmod(k, n)]
	for i in n:
		out[i] = acc / (2 * w + 1)
		acc += h[posmod(i + w + 1, n)] - h[posmod(i - w, n)]
	return out


static func _chunk_boxes(img: Image, loop: PoolVector2Array, row: int) -> void:
	var n = loop.size()
	for c in range(0, n, BORDER_CHUNK):
		var lo = loop[c]
		var hi = loop[c]
		for i in range(c, min(c + BORDER_CHUNK, n) + 1):
			var q = loop[i % n]
			lo = Vector2(min(lo.x, q.x), min(lo.y, q.y))
			hi = Vector2(max(hi.x, q.x), max(hi.y, q.y))
		img.set_pixel(c / BORDER_CHUNK, row, Color(lo.x, lo.y, hi.x, hi.y))


static func skin_shader(code: String, extra: Dictionary = {}) -> String:
	var re = RegEx.new()
	re.compile("void\\s+fragment\\s*\\(\\s*\\)\\s*\\{")
	var m = re.search(code)
	if m:
		var open = m.get_end()
		var depth = 1
		var close = open
		while close < code.length() and depth > 0:
			if code[close] == "{":
				depth += 1
			elif code[close] == "}":
				depth -= 1
			close += 1
		var body = code.substr(open, close - 1 - open)
		var word = RegEx.new()
		word.compile("\\bUV\\b")
		body = word.sub(body, "(UV + bulge_d + bulge_l)", true)
		for key in extra:
			word.compile("\\b" + key + "\\b")
			body = word.sub(body, extra[key], true)
		code = code.substr(0, open) + "\n\tvec2 bulge_l;\n\tvec2 bulge_d = bulge_shift(bulge_pos, UV, bulge_l);" + body + code.substr(close - 1)
	re.compile("void\\s+vertex\\s*\\(\\s*\\)\\s*\\{")
	m = re.search(code)
	var head = MAP_GLSL
	if m:
		code = code.substr(0, m.get_end()) + "\n\tbulge_pos = UV2;" + code.substr(m.get_end())
	else:
		head += "\nvoid vertex() {\n\tbulge_pos = UV2;\n}\n"
	re.compile("(?m)^\\s*(render_mode|shader_type)[^\\n]*\\n")
	var at = 0
	for h in re.search_all(code):
		at = h.get_end()
	if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
		head = gles2(head)
	return code.substr(0, at) + head + code.substr(at)


const GLES2_INT_MINMAX = "\\b(min|max)\\((i0 \\+ BULGE_CHUNK|i \\+ stride|\\(i1 - i0\\))"
static func gles2(code: String) -> String:
	var re = RegEx.new()
	re.compile(GLES2_INT_MINMAX)
	code = re.sub(code, "bulge_i$1($2", true)
	code = code.replace("texture(bulge_uv_map, ", "bulge_uvm(").replace("texture(bulge_sd, ", "bulge_sdt(")
	var out = ""
	var at = 0
	var sizes = {}
	while true:
		var k = code.find("texelFetch(", at)
		if k < 0:
			break
		var a = _call_args(code, k + 11)
		var tex = a[0][0]
		var xy = _call_args(a[0][1], a[0][1].find("(") + 1)[0]
		sizes[tex] = true
		out += code.substr(at, k - at) + "bulge_fetch(" + tex + ", " + tex + "_px, " + xy[0] + ", " + xy[1] + ")"
		at = a[1]
	out += code.substr(at)
	var head = GLES2_FETCH
	for tex in sizes:
		head += "uniform vec2 " + tex + "_px = vec2(1.0);  // " + tex + "'s size in byte texels\n"
	var decl = "varying vec2 bulge_pos;\n"
	var i = out.find(decl)
	if i >= 0:
		i += decl.length()
		out = out.substr(0, i) + GLES2_MAPS + out.substr(i)
	return head + out


static func gles2_table(img: Image) -> Image:
	if OS.get_current_video_driver() != OS.VIDEO_DRIVER_GLES2:
		return img
	var data = img.get_data()
	var out = Image.new()
	out.create_from_data(data.size() / 4 / img.get_height(), img.get_height(), false, Image.FORMAT_RGBA8, data)
	return out


const GLES2_FETCH = """// GLES2 (BodyDeform.gles2): the tables' floats as bytes (gles2_table).
int bulge_imin(int a, int b) {
	if (a < b) {
		return a;
	}
	return b;
}
int bulge_imax(int a, int b) {
	if (a > b) {
		return a;
	}
	return b;
}
// A float from its 4 IEEE bytes (r: the lowest). Zero and denormals: 0. Only the exponent is rounded to a whole
// number: the bytes come as byte / 255 (off by ~1e-5), so the mantissa is off by ~1 ulp at most.
// (No branch, no mod, one floor: this runs for every table read, the most of GLES2's cost, tools/gputime.gd.)
float bulge_float(vec4 c) {
	vec4 b = c * 255.0;
	float s = step(127.5, b.a);  // the sign bit
	float h = step(127.5, b.b);  // the exponent's lowest bit
	float e = floor((b.a - 128.0 * s) * 2.0 + h + 0.5);
	float m = (b.b - 128.0 * h) / 128.0 + b.g / 32768.0 + b.r / 8388608.0;
	return (1.0 - 2.0 * s) * step(0.5, e) * exp2(e - 127.0) * (1.0 + m);
}
// texelFetch(t, ivec2(x, y), 0) of the float table t (px: t's size in byte texels).
vec4 bulge_fetch(sampler2D t, vec2 px, int x, int y) {
	float fx = float(x) * 4.0 + 0.5;
	float v = (float(y) + 0.5) / px.y;
	return vec4(bulge_float(texture(t, vec2(fx / px.x, v))), bulge_float(texture(t, vec2((fx + 1.0) / px.x, v))),
		bulge_float(texture(t, vec2((fx + 2.0) / px.x, v))), bulge_float(texture(t, vec2((fx + 3.0) / px.x, v))));
}
"""
const GLES2_MAPS = """// GLES2 (BodyDeform.gles2): MAP_GLSL's filtered maps, filtered here.
uniform vec2 bulge_sd_px = vec2(1.0);
uniform sampler2D bulge_uv_depth;          // BodyPose.uv_map's depth map (bulge_uv_map: its uv)
uniform float bulge_uv_map_px = 1.0;
float bulge_sd_at(vec2 i) {
	return bulge_float(texture(bulge_sd, (clamp(i, vec2(0.0), bulge_sd_px - 1.0) + 0.5) / bulge_sd_px));
}
// texture(bulge_sd, t): bilinear, clamped to the edge, as the GLES3 texture's filter.
vec4 bulge_sdt(vec2 t) {
	vec2 p = t * bulge_sd_px - 0.5;
	vec2 b = floor(p);
	vec2 f = p - b;
	float v = mix(mix(bulge_sd_at(b), bulge_sd_at(b + vec2(1.0, 0.0)), f.x),
		mix(bulge_sd_at(b + vec2(0.0, 1.0)), bulge_sd_at(b + vec2(1.0, 1.0)), f.x), f.y);
	return vec4(v, 0.0, 0.0, 0.0);
}
// The uv map's texel i: uv (12 bits each, BodyPose.UV_MAP_GLES2), depth (24 bits over 0..BodyPose.UV_MAP_DEPTH).
vec4 bulge_uvm_at(vec2 i) {
	vec2 c = (clamp(i, vec2(0.0), vec2(bulge_uv_map_px - 1.0)) + 0.5) / bulge_uv_map_px;
	vec3 a = floor(texture(bulge_uv_map, c).rgb * 255.0 + 0.5);
	vec3 d = floor(texture(bulge_uv_depth, c).rgb * 255.0 + 0.5);
	return vec4((a.r * 16.0 + floor(a.b / 16.0)) / 4095.0, (a.g * 16.0 + mod(a.b, 16.0)) / 4095.0,
		dot(d, vec3(65536.0, 256.0, 1.0)) / 16777215.0 * 16.0, 1.0);
}
// texture(bulge_uv_map, t): bilinear, clamped to the edge, as the GLES3 map's filter.
vec4 bulge_uvm(vec2 t) {
	vec2 p = t * bulge_uv_map_px - 0.5;
	vec2 b = floor(p);
	vec2 f = p - b;
	return mix(mix(bulge_uvm_at(b), bulge_uvm_at(b + vec2(1.0, 0.0)), f.x),
		mix(bulge_uvm_at(b + vec2(0.0, 1.0)), bulge_uvm_at(b + vec2(1.0, 1.0)), f.x), f.y);
}
"""


static func _call_args(code: String, from: int) -> Array:
	var args = []
	var depth = 0
	var start = from
	var i = from
	while i < code.length():
		var c = code[i]
		if c == "(":
			depth += 1
		elif c == ")":
			if depth == 0:
				break
			depth -= 1
		elif c == "," and depth == 0:
			args.append(code.substr(start, i - start).strip_edges())
			start = i + 1
		i += 1
	args.append(code.substr(start, i - start).strip_edges())
	return [args, i + 1]


const BASE_SHADER = """shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, blend_mix;
uniform sampler2D albedo_tex : hint_albedo;
uniform vec4 albedo_color : hint_color = vec4(1.0);

void fragment() {
	vec4 c = texture(albedo_tex, UV) * albedo_color;
	ALBEDO = c.rgb;
	ALPHA = c.a;
}
"""

const MAP_GLSL = """
// BodyDeform rubber skin (added by BodyDeform.skin_shader; every name starts with bulge_).
uniform bool bulge_on = false;
uniform sampler2D bulge_sd;          // BodyShape signed distance grid (rest units, > 0 inside the drawing)
uniform vec2 bulge_sd_origin;
uniform vec2 bulge_sd_size;
uniform vec3 bulge_rest_x;           // deform xy -> body rest xy
uniform vec3 bulge_rest_y;
uniform float bulge_k = 1.0;         // body scale
uniform vec2 bulge_uv_x;             // deform xy -> body uv (linear part)
uniform vec2 bulge_uv_y;
uniform bool bulge_posed = false;    // a posed body: its uv is not affine, it is read from the uv map instead
uniform sampler2D bulge_uv_map;      // BodyPose.uv_map: the posed body's uv at every deform-space point
uniform vec2 bulge_uv_map_origin;
uniform vec2 bulge_uv_map_size;
uniform vec4 bulge_zone = vec4(-1e9, -1e9, 1e9, 1e9);  // posed: outside this box (min xy, max xy) the mapping is the identity
uniform sampler2D bulge_border;      // row 0: target border xy, matching body border xy; row 1: inward normal;
                                     // row 2: per chunk of BULGE_CHUNK segments, its box (min xy, max xy)
uniform int bulge_border_n = 0;
const int BULGE_CHUNK = 16;
const float BULGE_MVC_FAR = 2.0;    // mvc: a border chunk farther than this many of its box sizes counts as
const int BULGE_MVC_CHORDS = 4;     // this many chords (1 chord: a curved chunk near a notch pulled the skin off, 3x neck)
const int BULGE_WALK = 8;           // mvc: steps of half bulge_depth back onto the body
const float BULGE_LINE = 0.05;      // mvc: the drawn outline's thickness with its soft edge (rest units, 0.025 left smudges): the drawing is read deeper than it
uniform bool bulge_sdf = false;      // gpu_shape: the target and its matching made here (BodyDeform._sdf_params)
uniform sampler2D bulge_shape;
uniform int bulge_sp_n = 0;
uniform int bulge_w_n = 0;
uniform int bulge_p_n = 0;
uniform float bulge_sp_len = 1.0;
uniform float bulge_sig_a = 0.0;
uniform float bulge_sig_len = 1.0;
uniform float bulge_fillet = 0.1;
uniform float bulge_depth = 0.15;
uniform float bulge_margin = 0.06;
uniform float bulge_reach = 0.15;    // mvc: the cage's fade depth (mvc * the tallest bulge height)
uniform bool bulge_mvc = false;      // BodyDeform "mvc": the skin by mean value coordinates on the target border
varying vec2 bulge_pos;

// The distance from x to the target border: the nearest chunk's box first, then only chunks nearer than the best.
float bulge_border_dist(vec2 x) {
	int nc = (bulge_border_n + BULGE_CHUNK - 1) / BULGE_CHUNK;
	float best = 1e9;
	for (int c = 0; c < nc; c++) {
		vec4 box = texelFetch(bulge_border, ivec2(c, 2), 0);
		if (length(max(max(box.xy - x, x - box.zw), vec2(0.0))) >= best) {
			continue;
		}
		int i0 = c * BULGE_CHUNK;
		int i1 = min(i0 + BULGE_CHUNK, bulge_border_n);
		vec2 a = texelFetch(bulge_border, ivec2(i0, 0), 0).xy;
		for (int i = i0; i < i1; i++) {
			int j = i + 1;
			if (j == bulge_border_n) {
				j = 0;
			}
			vec2 b = texelFetch(bulge_border, ivec2(j, 0), 0).xy;
			vec2 ab = b - a;
			best = min(best, length(x - a - ab * clamp(dot(x - a, ab) / max(dot(ab, ab), 1e-12), 0.0, 1.0)));
			a = b;
		}
	}
	return best;
}

// The posed body's uv at deform-space point p.
vec2 bulge_uv_at(vec2 p) {
	vec2 t = (p - bulge_uv_map_origin) / bulge_uv_map_size;
	return texture(bulge_uv_map, t).rg;
}

// gpu_shape: the closed loop in bulge_shape row `row` (n points; row + 1: chunk boxes), against x:
// vec4(signed distance, > 0 inside (even-odd), nearest segment, fraction along it, 0). As the border loop below.
// Also, in `border`, the nearest among the segments still border (flag row `frow`: 1 at either end):
// vec3(its distance, segment, fraction).
vec4 bulge_near(int row, int n, vec2 x, int frow, out vec3 border) {
	int nc = (n + BULGE_CHUNK - 1) / BULGE_CHUNK;
	bool inside = false;
	int c0 = 0;
	float d0 = 1e9;
	for (int c = 0; c < nc; c++) {
		vec4 box = texelFetch(bulge_shape, ivec2(c, row + 1), 0);
		float db = length(max(max(box.xy - x, x - box.zw), vec2(0.0)));
		if (db < d0) {
			d0 = db;
			c0 = c;
		}
		if (box.w <= x.y || box.y > x.y || box.z <= x.x) {
			continue;
		}
		int i0 = c * BULGE_CHUNK;
		int i1 = min(i0 + BULGE_CHUNK, n);
		if (box.x > x.x) {
			int e = i1;
			if (e == n) {
				e = 0;
			}
			if ((texelFetch(bulge_shape, ivec2(i0, row), 0).y > x.y) != (texelFetch(bulge_shape, ivec2(e, row), 0).y > x.y)) {
				inside = !inside;
			}
			continue;
		}
		vec2 a = texelFetch(bulge_shape, ivec2(i0, row), 0).xy;
		for (int i = i0; i < i1; i++) {
			int j = i + 1;
			if (j == n) {
				j = 0;
			}
			vec2 b = texelFetch(bulge_shape, ivec2(j, row), 0).xy;
			if ((a.y > x.y) != (b.y > x.y) && x.x < a.x + (x.y - a.y) / (b.y - a.y) * (b.x - a.x)) {
				inside = !inside;
			}
			a = b;
		}
	}
	float best = 1e9;
	int bi = 0;
	float bf = 0.0;
	float bb = 1e9;
	int bbi = 0;
	float bbf = 0.0;
	for (int k = -1; k < nc; k++) {
		int c = k;
		if (k < 0) {
			c = c0;
		} else if (k == c0) {
			continue;
		} else {
			vec4 box = texelFetch(bulge_shape, ivec2(c, row + 1), 0);
			if (length(max(max(box.xy - x, x - box.zw), vec2(0.0))) >= max(best, bb)) {
				continue;
			}
		}
		int i0 = c * BULGE_CHUNK;
		int i1 = min(i0 + BULGE_CHUNK, n);
		vec2 a = texelFetch(bulge_shape, ivec2(i0, row), 0).xy;
		float fa = texelFetch(bulge_shape, ivec2(i0, frow), 0).x;
		for (int i = i0; i < i1; i++) {
			int j = i + 1;
			if (j == n) {
				j = 0;
			}
			vec2 b = texelFetch(bulge_shape, ivec2(j, row), 0).xy;
			float fb = texelFetch(bulge_shape, ivec2(j, frow), 0).x;
			vec2 ab = b - a;
			float f = clamp(dot(x - a, ab) / max(dot(ab, ab), 1e-12), 0.0, 1.0);
			float d = length(x - a - ab * f);
			if (d < best) {
				best = d;
				bi = i;
				bf = f;
			}
			if (fa + fb > 0.5 && d < bb) {
				bb = d;
				bbi = i;
				bbf = f;
			}
			a = b;
			fa = fb;
		}
	}
	if (!inside) {
		best = -best;
	}
	border = vec3(bb, float(bbi), bbf);
	return vec4(best, float(bi), bf, 0.0);
}

// gpu_shape: where the skin at x comes from (before the body-depth blend). Target = body U sleeve with a smooth
// minimum (the fillets); on the sleeve's side the skin is the pushed-in border P stretched over the sleeve's border
// from J1 to J2, on the body's side the body's own border, in the fillet a blend of the two.
vec2 bulge_sdf_source(vec2 x) {
	vec3 sb;
	vec4 nb = bulge_near(2, bulge_w_n, x, 6, sb);
	vec3 sq;
	vec4 np = bulge_near(0, bulge_sp_n, x, 7, sq);
	float a = -nb.x;  // outside > 0
	float b = -np.x;
	float h = clamp(0.5 + 0.5 * (b - a) / bulge_fillet, 0.0, 1.0);
	float d = -(mix(b, a, h) - bulge_fillet * h * (1.0 - h));  // the target: body U sleeve, smooth minimum
	// the skin comes from the nearer border piece still on the target's border (the body's own, or the sleeve's
	// out of the body), blended within a fillet width of the tie; past 2 margins outside, no blend (the two
	// pieces can be far apart: a blend would land inside the body)
	float w = clamp(0.5 + 0.5 * (sq.x - sb.x) / bulge_fillet, 0.0, 1.0);  // the body's weight
	w = mix(step(0.5, w), w, clamp(1.0 + d / (2.0 * bulge_margin), 0.0, 1.0));
	nb.yz = sb.yz;
	np.yz = sq.yz;
	int bi = int(nb.y);
	int bj = bi + 1;
	if (bj == bulge_w_n) {
		bj = 0;
	}
	vec4 WA = texelFetch(bulge_shape, ivec2(bi, 2), 0);
	vec4 WB = texelFetch(bulge_shape, ivec2(bj, 2), 0);
	vec2 src_b = mix(WA.xy, WB.xy, nb.z);
	vec2 n_b = mix(WA.zw, WB.zw, nb.z);
	int si = int(np.y);
	int sj = si + 1;
	float s1 = bulge_sp_len;
	if (sj < bulge_sp_n) {
		s1 = texelFetch(bulge_shape, ivec2(sj, 0), 0).z;
	}
	float sig = mix(texelFetch(bulge_shape, ivec2(si, 0), 0).z, s1, np.z);
	float t = mod(sig - bulge_sig_a, bulge_sp_len) / bulge_sig_len;
	if (t > 1.0) {  // the sleeve's border inside the body: the nearer end
		if ((t - 1.0) * bulge_sig_len < 0.5 * (bulge_sp_len - bulge_sig_len)) {
			t = 1.0;
		} else {
			t = 0.0;
		}
	}
	float L = t * texelFetch(bulge_shape, ivec2(bulge_p_n - 1, 5), 0).x;
	vec2 src_p = texelFetch(bulge_shape, ivec2(bulge_p_n - 1, 4), 0).xy;
	vec2 n_p = texelFetch(bulge_shape, ivec2(bulge_p_n - 1, 4), 0).zw;
	float c0 = 0.0;
	for (int i = 0; i < bulge_p_n - 1; i++) {
		float c1 = texelFetch(bulge_shape, ivec2(i + 1, 5), 0).x;
		if (c1 >= L) {
			float f = clamp((L - c0) / max(c1 - c0, 1e-9), 0.0, 1.0);
			vec4 PA = texelFetch(bulge_shape, ivec2(i, 4), 0);
			vec4 PB = texelFetch(bulge_shape, ivec2(i + 1, 4), 0);
			src_p = mix(PA.xy, PB.xy, f);
			n_p = mix(PA.zw, PB.zw, f);
			break;
		}
		c0 = c1;
	}
	vec2 src = mix(src_p, src_b, w);
	vec2 nrm = normalize(mix(n_p, n_b, w));
	return src + nrm * clamp(d, -2.0 * bulge_margin, bulge_depth);
}

// Where the skin at signed distance d (> 0 inside) from the target border, nearest at segment i, fraction f, comes
// from: the matching body border point moved d inward (clamped to a strip bulge_depth thick)
vec2 bulge_source(int i, float f, float d) {
	int j = i + 1;
	if (j == bulge_border_n) {
		j = 0;
	}
	vec4 A = texelFetch(bulge_border, ivec2(i, 0), 0);
	vec4 B = texelFetch(bulge_border, ivec2(j, 0), 0);
	vec2 nrm = normalize(mix(texelFetch(bulge_border, ivec2(i, 1), 0).xy, texelFetch(bulge_border, ivec2(j, 1), 0).xy, f));
	return mix(A.zw, B.zw, f) + nrm * clamp(d, -2.0 * bulge_margin, bulge_depth);
}

// The body uv shift at deform-space point x, whose grid uv is uv (0 while bulge_on is false). line: the drawing's
// extra shift (UV, not the pattern), so a bulge pixel off the target border never wears the stretched outline.
vec2 bulge_shift(vec2 x, vec2 uv, out vec2 line) {
	line = vec2(0.0);
	if (!bulge_on || (!bulge_sdf && bulge_border_n <= 2)) {
		return vec2(0.0);
	}
	if (x.x < bulge_zone.x || x.y < bulge_zone.y || x.x > bulge_zone.z || x.y > bulge_zone.w) {
		return vec2(0.0);  // (only a posed body sets it: there every pixel out here is the body's own mesh)
	}
	vec2 r = vec2(dot(bulge_rest_x, vec3(x, 1.0)), dot(bulge_rest_y, vec3(x, 1.0)));
	float depth;  // inside the drawing
	if (bulge_posed) {
		depth = texture(bulge_uv_map, (x - bulge_uv_map_origin) / bulge_uv_map_size).b;
	} else {
		depth = texture(bulge_sd, (r - bulge_sd_origin) / bulge_sd_size).r;
	}
	float gate = bulge_depth;
	if (bulge_mvc && !bulge_sdf) {
		gate = bulge_reach;
	}
	float wid = smoothstep(0.5 * gate, gate, depth * bulge_k);
	if (wid >= 1.0) {
		return vec2(0.0);  // deep inside: its own uv (a posed body draws its own mesh there)
	}
	if (bulge_mvc && !bulge_sdf) {
		// mean value coordinates of x on the target border (vertex v_i, edge angle a_i seen from x):
		// w_i = (tan(a_{i-1} / 2) + tan(a_i / 2)) / |v_i - x|, tan(a / 2) = cross / (|d_i| |d_j| + dot), signed
		// (a concave border). The skin at x: sum w_i src_i / sum w_i (src = the matching body border point)
		// Summed edge by edge (w_i = sum over v_i's two edges of tan(a / 2) / |v_i - x|, the same total), so a chunk of
		// BULGE_CHUNK edges far from x (its box farther than BULGE_MVC_FAR box sizes) counts as BULGE_MVC_CHORDS chords.
		// ponytail: the switch chord <-> edges moves s a little; blend the two if a seam ever shows
		int n = bulge_border_n;
		int nc = (n + BULGE_CHUNK - 1) / BULGE_CHUNK;
		vec4 F = texelFetch(bulge_border, ivec2(0, 0), 0);
		float W = 0.0;
		vec2 S = vec2(0.0);
		vec2 N = vec2(0.0);  // the same mix of the body border's direction there (turned inward after the loop)
		bool on = false;
		vec2 at = vec2(0.0);
		float wind = 0.0;  // sum of the half edge angles: pi inside the cage, 0 outside
		for (int c = 0; c < nc; c++) {
			vec4 box = texelFetch(bulge_border, ivec2(c, 2), 0);
			int i0 = c * BULGE_CHUNK;
			int i1 = min(i0 + BULGE_CHUNK, n);
			int stride = 1;  // (not "step": that is GLSL's step())
			if (length(max(max(box.xy - x, x - box.zw), vec2(0.0))) > BULGE_MVC_FAR * length(box.zw - box.xy)) {
				stride = max((i1 - i0) / BULGE_MVC_CHORDS, 1);
			}
			vec4 P = texelFetch(bulge_border, ivec2(i0, 0), 0);
			vec2 dp = P.xy - x;
			float rp = length(dp);
			for (int i = i0; i < i1; i += stride) {
				int j = min(i + stride, i1);
				if (j >= n) {
					j = 0;
				}
				vec4 Q = texelFetch(bulge_border, ivec2(j, 0), 0);
				vec2 dq = Q.xy - x;
				float rq = length(dq);
				if (rp < 1e-6) {
					on = true;  // x on a border point: its own source
					at = P.zw;
				}
				float t = (dp.x * dq.y - dp.y * dq.x) / max(rp * rq + dot(dp, dq), 1e-12);
				wind += atan(t);
				float wp = t / max(rp, 1e-6);
				float wq = t / max(rq, 1e-6);
				W += wp + wq;
				S += wp * P.zw + wq * Q.zw;
				N += (wp + wq) * (Q.zw - P.zw);  // (no fetch per point: the matching body border's own direction)
				P = Q;
				dp = dq;
				rp = rq;
			}
		}
		// inward: the side of the border's direction where sample 0's inward normal lies
		vec2 t0 = texelFetch(bulge_border, ivec2(1, 0), 0).zw - F.zw;
		N = vec2(-N.y, N.x) * sign(dot(vec2(-t0.y, t0.x), texelFetch(bulge_border, ivec2(0, 1), 0).xy));
		vec2 s = S / W;
		if (on) {
			s = at;
		}
		s = mix(s, x, wid);
		// (outside the cage the formula extrapolates: the usual mapping below keeps those pixels as before; a
		// concave cage can send a point off the body: the usual skin takes over there too)
		if (abs(wind) < 0.5 * 3.14159265) {
			W = 0.0;
		}
		if (bulge_posed) {
			vec4 m = texture(bulge_uv_map, (s - bulge_uv_map_origin) / bulge_uv_map_size);
			// a concave cage can send s off the body: walked back in along the mixed normal (no switch of mapping)
			// (not on the target border: its source is the body border itself, the outline drawn there)
			float lw = BULGE_LINE * bulge_k;
			// then the crossing found by halving and moved half an outline in (the uv map's edge texels mix in the
			// empty ones), so the source moves smoothly with x (no step bands)
			float dt = -1.0;  // x to the target border, only where needed (a source on or near the body border)
			if (m.b * bulge_k < 2.0 * lw) {
				dt = bulge_border_dist(x);
			}
			if (m.b <= 1e-4 && dt > 2.0 * lw && abs(W) > 1e-6 && dot(N, N) > 1e-12) {
				vec2 nn = normalize(N / W);
				vec2 lo = s;
				for (int k = 0; k < BULGE_WALK && m.b <= 1e-4; k++) {
					lo = s;
					s += nn * bulge_depth * 0.5;
					m = texture(bulge_uv_map, (s - bulge_uv_map_origin) / bulge_uv_map_size);
				}
				if (m.b > 1e-4) {
					for (int k = 0; k < 6; k++) {
						vec2 mid = 0.5 * (lo + s);
						if (texture(bulge_uv_map, (mid - bulge_uv_map_origin) / bulge_uv_map_size).b > 1e-4) {
							s = mid;
						} else {
							lo = mid;
						}
					}
					s += nn * 0.5 * lw;
					m = texture(bulge_uv_map, (s - bulge_uv_map_origin) / bulge_uv_map_size);
				}
			}
			if (m.b > 1e-4 && abs(W) > 1e-6) {
				// the drawing: a source within 2 outlines of the body border steps in to that depth, fully once x is 2 outlines off the target border (there the outline is drawn as it is)
				if (m.b * bulge_k < 2.0 * lw && dt < 0.0) {
					dt = bulge_border_dist(x);  // (the walk brought s in, still shallow)
				}
				float want = 2.0 * lw * smoothstep(lw, 2.0 * lw, dt) * (1.0 - wid);
				vec2 sl = s;
				vec4 ml = m;
				// (up the depth's slope: the mixed normal cancels out midway between two sides of a thin part)
				vec2 ex = vec2(0.5 * lw, 0.0);
				vec2 ey = vec2(0.0, 0.5 * lw);
				vec2 gr = vec2(0.0);
				if (ml.b * bulge_k < want) {
					gr = vec2(
						texture(bulge_uv_map, (sl + ex - bulge_uv_map_origin) / bulge_uv_map_size).b
							- texture(bulge_uv_map, (sl - ex - bulge_uv_map_origin) / bulge_uv_map_size).b,
						texture(bulge_uv_map, (sl + ey - bulge_uv_map_origin) / bulge_uv_map_size).b
							- texture(bulge_uv_map, (sl - ey - bulge_uv_map_origin) / bulge_uv_map_size).b);
				}
				for (int k = 0; k < BULGE_WALK && ml.b * bulge_k < want && dot(gr, gr) > 1e-14; k++) {
					vec2 nx = sl + normalize(gr) * 0.5 * lw;
					vec4 mn = texture(bulge_uv_map, (nx - bulge_uv_map_origin) / bulge_uv_map_size);
					if (mn.b <= 1e-4) {
						break;  // (stepped off the body: the last point on it)
					}
					sl = nx;
					ml = mn;
				}
				line = ml.rg - m.rg;
				return m.rg - uv;
			}
		} else if (abs(W) > 1e-6) {
			// ponytail: the straight body keeps the outline's stretch (line 0); bulge_sd at s gives the depth if needed
			return bulge_uv_x * (s.x - x.x) + bulge_uv_y * (s.y - x.y);
		}
	}
	if (bulge_sdf) {
		vec2 s2 = mix(bulge_sdf_source(x), x, wid);
		if (bulge_posed) {
			return bulge_uv_at(s2) - uv;
		}
		return bulge_uv_x * (s2.x - x.x) + bulge_uv_y * (s2.y - x.y);
	}
	// (OTTIMIZZAZIONE.md priority 10: chunks with boxes, the same answer as a loop over every segment)
	// inside (even-odd, a ray to +x): a chunk all to the right of x crosses it as often as its two ends lie on
	// two sides of it; one all to the left or above/below never; only the others go segment by segment.
	// nearest: the chunk whose box is nearest first, then only chunks whose box is nearer than the best so far.
	int nc = (bulge_border_n + BULGE_CHUNK - 1) / BULGE_CHUNK;
	bool inside = false;
	int c0 = 0;
	float d0 = 1e9;
	for (int c = 0; c < nc; c++) {
		vec4 box = texelFetch(bulge_border, ivec2(c, 2), 0);
		float db = length(max(max(box.xy - x, x - box.zw), vec2(0.0)));
		if (db < d0) {
			d0 = db;
			c0 = c;
		}
		if (box.w <= x.y || box.y > x.y || box.z <= x.x) {
			continue;  // (all its ends on one side of the ray's line, or all left of x: no crossing counts)
		}
		int i0 = c * BULGE_CHUNK;
		int i1 = min(i0 + BULGE_CHUNK, bulge_border_n);
		if (box.x > x.x) {
			int e = i1;
			if (e == bulge_border_n) {
				e = 0;
			}
			float y0 = texelFetch(bulge_border, ivec2(i0, 0), 0).y;
			float y1 = texelFetch(bulge_border, ivec2(e, 0), 0).y;
			if ((y0 > x.y) != (y1 > x.y)) {
				inside = !inside;
			}
			continue;
		}
		vec2 a = texelFetch(bulge_border, ivec2(i0, 0), 0).xy;
		for (int i = i0; i < i1; i++) {
			int j = i + 1;
			if (j == bulge_border_n) {
				j = 0;
			}
			vec2 b = texelFetch(bulge_border, ivec2(j, 0), 0).xy;
			if ((a.y > x.y) != (b.y > x.y) && x.x < a.x + (x.y - a.y) / (b.y - a.y) * (b.x - a.x)) {
				inside = !inside;
			}
			a = b;
		}
	}
	float best = 1e9;
	int bi = 0;
	float bf = 0.0;
	for (int k = -1; k < nc; k++) {
		int c = k;
		if (k < 0) {
			c = c0;
		} else if (k == c0) {
			continue;
		} else {
			vec4 box = texelFetch(bulge_border, ivec2(c, 2), 0);
			if (length(max(max(box.xy - x, x - box.zw), vec2(0.0))) >= best) {
				continue;
			}
		}
		int i0 = c * BULGE_CHUNK;
		int i1 = min(i0 + BULGE_CHUNK, bulge_border_n);
		vec2 a = texelFetch(bulge_border, ivec2(i0, 0), 0).xy;
		for (int i = i0; i < i1; i++) {
			int j = i + 1;
			if (j == bulge_border_n) {
				j = 0;
			}
			vec2 b = texelFetch(bulge_border, ivec2(j, 0), 0).xy;
			vec2 ab = b - a;
			float f = clamp(dot(x - a, ab) / max(dot(ab, ab), 1e-12), 0.0, 1.0);
			float d = length(x - a - ab * f);
			if (d < best) {
				best = d;
				bi = i;
				bf = f;
			}
			a = b;
		}
	}
	float d = best;
	if (!inside) {
		d = -best;
	}
	vec2 s = bulge_source(bi, bf, d);
	s = mix(s, x, wid);
	if (bulge_posed) {
		return bulge_uv_at(s) - uv;
	}
	return bulge_uv_x * (s.x - x.x) + bulge_uv_y * (s.y - x.y);
}
"""


const OFFSET_TOL = 0.01
const OPEN_TOL = 0.05
static func _offset(poly: PoolVector2Array, d: float, tol := OFFSET_TOL) -> Array:
	if abs(d) < 1e-9:
		return [poly]
	var s = 0.25 / (tol * abs(d))
	var out = []
	for q in Geometry.offset_polygon_2d(Transform2D.IDENTITY.scaled(Vector2(s, s)).xform(poly), d * s, Geometry.JOIN_ROUND):
		out.append(Transform2D.IDENTITY.scaled(Vector2(1.0 / s, 1.0 / s)).xform(q))
	return out


static func _sleeve_poly(sw: Dictionary, entry: int, cover: float, o: Dictionary, entry_f := 1.0) -> PoolVector2Array:
	var n = sw["pts"].size()
	var last = entry + int(round(clamp(cover, 0.0, 1.0) * (n - 1 - entry)))
	var out = PoolVector2Array()
	if last <= entry:
		return out
	var skin = o["skin"]
	var f = clamp(o["fidelity"], 0.0, 1.0)
	var win = max(int(n * 0.12), 2)
	var ay = sw["across"]
	var pts = sw["pts"]
	var rads = sw["rad"]
	var first = entry
	if entry > 0 and entry_f < 0.999:
		first = entry - 1
	var e0 = max(first - win, 0)
	var e1 = min(last + win, n - 1)
	var gc = _smooth(pts, win, e0, e1)
	var env = []
	env.resize(n)
	for i in n:
		env[i] = 0.0
		if i < e0 or i > e1 or (i % 2 == 1 and i > e0 and i < e1):
			continue
		var e = 0.0
		var ai = ay[i]
		var base = gc[i].dot(ai)
		for j in range(max(i - win, 0), min(i + win, n - 1) + 1, 2):
			e = max(e, abs(pts[j].dot(ai) - base) + rads[j])
		env[i] = e
	for i in range(e0 + 1, e1):
		if i % 2 == 1:
			env[i] = max(env[i - 1], env[i + 1])
	var gr = _smooth(env, win, first, last)
	var kap = _curvature(gc, max(win / 2, 1), first, last)
	var lower = []
	var c = Vector2.ZERO
	var r = 0.0
	var fi = f
	for i in range(first, last + 1):
		c = gc[i].linear_interpolate(pts[i], fi)
		r = lerp(gr[i], rads[i], fi) * skin
		var ru = r
		var rl = r
		if abs(kap[i]) > 1e-6:
			var tt = (gc[min(i + 1, n - 1)] - gc[max(i - 1, 0)]).normalized()
			if (ay[i].dot(Vector2(-tt.y, tt.x)) > 0.0) == (kap[i] > 0.0):
				ru = min(ru, FOLD / abs(kap[i]))
			else:
				rl = min(rl, FOLD / abs(kap[i]))
		out.append(c + ay[i] * ru)
		lower.append(c - ay[i] * rl)
	if first < entry:
		out[0] = out[0].linear_interpolate(out[1], entry_f)
		lower[0] = lower[0].linear_interpolate(lower[1], entry_f)
	var t = (c - gc[last - 1].linear_interpolate(pts[last - 1], fi)).normalized()
	var cap = r * lerp(1.0, 0.25, fi)
	for a in range(1, 8):
		var ang = PI * a / 8.0
		out.append(c + ay[last] * r * cos(ang) + t * cap * sin(ang))
	for i in range(lower.size() - 1, -1, -1):
		out.append(lower[i])
	return out


const BORDER_CHUNK = 16
const HEIGHT_SMOOTH = 8
const FOLD = 0.8


static func _curvature(p: Array, w: int, lo := 0, hi := -1) -> Array:
	if hi < 0:
		hi = p.size() - 1
	var k = []
	var a0 = max(lo - w, 0)
	var a1 = min(hi + w, p.size() - 1)
	for i in p.size():
		if i < a0 or i > a1:
			k.append(0.0)
			continue
		var a = p[max(i - 1, 0)]
		var b = p[i]
		var c = p[min(i + 1, p.size() - 1)]
		var ds = 0.5 * (a.distance_to(b) + b.distance_to(c))
		if ds <= 1e-9 or a == b or b == c:
			k.append(0.0)
		else:
			k.append((b - a).angle_to(c - b) / ds)
	return _smooth(k, w, lo, hi)


static func _smooth(a: Array, w: int, from := 0, to := -1) -> Array:
	var n = a.size()
	var out = []
	out.resize(n)
	if n == 0:
		return out
	if to < 0:
		to = n - 1
	var acc = a[from] * 0.0
	var lo = max(from - w, 0)
	var hi = lo - 1
	for i in range(from, to + 1):
		var top = min(i + w, n - 1)
		while hi < top:
			hi += 1
			acc += a[hi]
		var bottom = max(i - w, 0)
		while lo < bottom:
			acc -= a[lo]
			lo += 1
		out[i] = acc / (hi - lo + 1)
	return out


static func _overlaps(a: PoolVector2Array, b: PoolVector2Array) -> Array:
	var out = []
	for piece in Geometry.intersect_polygons_2d(a, b):
		if not Geometry.is_polygon_clockwise(piece):
			out.append(piece)
	return out


static func _lock_cut(bs: Dictionary, xa: Transform, at: float, W: PoolVector2Array) -> Array:
	var out = []
	for piece in Geometry.clip_polygons_2d(_lock_poly(bs, xa, at), W):
		if not Geometry.is_polygon_clockwise(piece):
			out.append(piece)
	return out


static func _lock_poly(bs: Dictionary, xa: Transform, at: float) -> PoolVector2Array:
	if bs.has("lock_poly"):
		return bs["lock_poly"]
	var b = bs["bounds"]
	var x0 = b.position.x + b.size.x * at
	var out = PoolVector2Array()
	for p in [Vector2(x0, b.position.y - 50.0), Vector2(x0 + 50.0, b.position.y - 50.0), Vector2(x0 + 50.0, b.end.y + 50.0), Vector2(x0, b.end.y + 50.0)]:
		out.append(_xy(xa.xform(Vector3(p.x, p.y, 0.0))))
	return out


static func _largest(polys) -> PoolVector2Array:
	if polys.size() == 1:
		return polys[0]
	var best = PoolVector2Array()
	var ba = 0.0
	for p in polys:
		var a = abs(BodyShape.area(p))
		if a > ba:
			ba = a
			best = p
	return best


static func _thin(loop: PoolVector2Array, tol: float) -> PoolVector2Array:
	var n = loop.size()
	if n < 8 or tol <= 0.0:
		return loop
	var out = PoolVector2Array()
	var a = loop[0]
	out.append(a)
	var ref = 0.0
	var lo = 0.0
	var hi = 0.0
	var far = 0.0
	var i = 1
	while i < n:
		var d = loop[i] - a
		var l = d.length()
		if l <= tol and far == 0.0:
			i += 1
			continue
		var half = asin(min(tol / max(l, 1e-12), 1.0))
		if far == 0.0:
			ref = d.angle()
			lo = -half
			hi = half
			far = l
			i += 1
			continue
		var rel = wrapf(d.angle() - ref, -PI, PI)
		if rel < lo or rel > hi or l < far - tol:
			a = loop[i - 1]
			out.append(a)
			far = 0.0
			continue
		lo = max(lo, rel - half)
		hi = min(hi, rel + half)
		far = max(far, l)
		i += 1
	if out[out.size() - 1] != loop[n - 1]:
		out.append(loop[n - 1])
	return out


static func _rect(poly) -> Rect2:
	var r = Rect2(poly[0], Vector2.ZERO)
	for p in poly:
		r = r.expand(p)
	return r


static func _rotate(a, start: int):
	var out = a
	if a is Array:
		out = a.duplicate()
	for i in a.size():
		out[i] = a[(i + start) % a.size()]
	return out


static func _resample(loop, h: float) -> PoolVector2Array:
	var cum = _cumulative(loop)
	var total = cum[loop.size()]
	var n = max(int(total / h), 8)
	var out = PoolVector2Array()
	var j = 0
	for i in n:
		var s = total * i / n
		while cum[j + 1] < s:
			j += 1
		var f = (s - cum[j]) / max(cum[j + 1] - cum[j], 1e-9)
		out.append(loop[j].linear_interpolate(loop[(j + 1) % loop.size()], f))
	return out


static func _cumulative(loop) -> Array:
	var cum = [0.0]
	for i in loop.size():
		cum.append(cum[i] + loop[i].distance_to(loop[(i + 1) % loop.size()]))
	return cum


static func _param(loop, cum: Array, nn: Array) -> float:
	return cum[nn[0]] + nn[1] * (cum[nn[0] + 1] - cum[nn[0]])


static func _scan(poly, origin: Vector2, c: float, nx: int, ny: int) -> PoolByteArray:
	var out = PoolByteArray()
	out.resize(nx * ny)
	for i in nx * ny:
		out[i] = 0
	var rows = []
	rows.resize(ny)
	for gy in ny:
		rows[gy] = []
	var n = poly.size()
	for i in n:
		var a = poly[i]
		var b = poly[(i + 1) % n]
		if a.y == b.y:
			continue
		var y0 = min(a.y, b.y)
		var y1 = max(a.y, b.y)
		for gy in range(max(int(ceil((y0 - origin.y) / c)), 0), min(int(ceil((y1 - origin.y) / c)), ny)):
			var y = origin.y + gy * c
			if y >= y0 and y < y1:
				rows[gy].append(a.x + (y - a.y) / (b.y - a.y) * (b.x - a.x))
	for gy in ny:
		var xs = rows[gy]
		xs.sort()
		for k in range(0, xs.size() - 1, 2):
			for gx in range(max(int(ceil((xs[k] - origin.x) / c)), 0), min(int(floor((xs[k + 1] - origin.x) / c)), nx - 1) + 1):
				out[gy * nx + gx] = 1
	return out


static func _scan_any(polys: Array, origin: Vector2, c: float, nx: int, ny: int) -> PoolByteArray:
	var out = _scan(polys[0], origin, c, nx, ny)
	for q in range(1, polys.size()):
		var more = _scan(polys[q], origin, c, nx, ny)
		for i in out.size():
			if more[i]:
				out[i] = 1
	return out


static func _buckets(loop, size: float) -> Dictionary:
	var b = {}
	for i in loop.size():
		var p = loop[i]
		var q = loop[(i + 1) % loop.size()]
		for gx in range(int(floor(min(p.x, q.x) / size)), int(floor(max(p.x, q.x) / size)) + 1):
			for gy in range(int(floor(min(p.y, q.y) / size)), int(floor(max(p.y, q.y) / size)) + 1):
				var key = gx * 65536 + gy
				if not b.has(key):
					b[key] = []
				b[key].append(i)
	return b


static func _nearest(loop, b: Dictionary, size: float, p: Vector2, hint: int = -1, max_ring: int = 200, near := 0.0) -> Array:
	var cx = int(floor(p.x / size))
	var cy = int(floor(p.y / size))
	var best = INF
	var bi = 0
	var bf = 0.0
	var n = loop.size()
	if hint >= 0:
		var lo = hint - 3
		if near > 0.0:
			lo = hint
		for j in range(lo, hint + 4):
			var i = posmod(j, n)
			var a = loop[i]
			var ab = loop[(i + 1) % n] - a
			var f = clamp((p - a).dot(ab) / max(ab.length_squared(), 1e-12), 0.0, 1.0)
			var d = p.distance_to(a + ab * f)
			if d < best:
				best = d
				bi = i
				bf = f
		if best <= near:
			return [bi, bf, best]
	for ring in max_ring + 1:
		if best <= ring * size:
			break
		for gx in range(cx - ring, cx + ring + 1):
			var step = 1
			if gx != cx - ring and gx != cx + ring:
				step = 2 * ring
			for gy in range(cy - ring, cy + ring + 1, step):
				var key = gx * 65536 + gy
				if not b.has(key):
					continue
				for i in b[key]:
					var a = loop[i]
					var ab = loop[(i + 1) % n] - a
					var f = clamp((p - a).dot(ab) / max(ab.length_squared(), 1e-12), 0.0, 1.0)
					var d = p.distance_to(a + ab * f)
					if d < best:
						best = d
						bi = i
						bf = f
	return [bi, bf, best]


static func make_shade_material(penis: Texture, on_top := false) -> ShaderMaterial:
	var mat = ShaderMaterial.new()
	mat.shader = shade_shader(on_top)
	mat.render_priority = 1
	if on_top:
		mat.render_priority = 10
	mat.set_shader_param("mask", penis)
	return mat


const _SHADE_SHADERS = {}


static func _gpu_bends(sh: Shader) -> bool:
	if sh.has_meta("gpu_bend"):
		return sh.get_meta("gpu_bend")
	return sh.code.find("gpu_bend") >= 0


static func shade_shader(on_top: bool) -> Shader:
	var cache = _SHADE_SHADERS
	if cache.has(on_top):
		return cache[on_top]
	var sh = Shader.new()
	var modes = "unshaded, cull_disabled, depth_draw_never"
	if on_top:
		modes += ", depth_test_disable"
	sh.code = """shader_type spatial;
render_mode """ + modes + """;
uniform sampler2D mask : hint_albedo;
uniform float shade = 0.5;
uniform float outline = 0.0;
uniform int style = 0;  // 0 soft + rim, 1 filled, 2 halo, 3 x-ray (the owner's picks of six, PLAN 8d); outline goes over any
uniform float alpha = 1.0;
uniform float fade = 0.15;  // the shade fades in over this distance past the entry (0.35 hid half a size-1 penis)
uniform vec2 texel = vec2(0.006, 0.012);
""" + _shade_vertex() + """
// wide blur of the mask's alpha (two rings of 8): ~1 in the middle of the penis, falling toward its edges
float wide(sampler2D m, vec2 uv, vec2 t) {
	float s = 0.0;
	for (int i = 0; i < 8; i++) {
		float an = float(i) * 0.785398;
		vec2 d = vec2(cos(an), sin(an)) * t;
		s += texture(m, uv + d * 3.0).a + texture(m, uv + d * 6.0).a;
	}
	return s / 16.0;
}
void fragment() {
	vec4 c = texture(mask, UV);
	float a = c.a;
	float b = a + texture(mask, UV + vec2(texel.x, 0.0)).a + texture(mask, UV - vec2(texel.x, 0.0)).a
		+ texture(mask, UV + vec2(0.0, texel.y)).a + texture(mask, UV - vec2(0.0, texel.y)).a;
	b /= 5.0;
	float rim = clamp((a - b) * 3.0, 0.0, 1.0);          // light edge of the bulge
	float boost = mix(1.0, 1.5, smoothstep(0.6, 1.0, shade));
	float lum = dot(c.rgb, vec3(0.299, 0.587, 0.114));
	float drawn = a * smoothstep(0.6, 0.2, lum);         // the penis's own drawn (dark) lines
	float w = smoothstep(0.0, fade, along);
	vec3 col = vec3(0.0);
	float al = 0.0;
	if (style == 1) {          // filled: one even dark silhouette (a little lighter under an outline, so it shows)
		al = a * mix(0.9, 0.75, outline) * shade;
	} else if (style == 2) {   // halo: a soft blurred shadow, no sharp edge
		float m = wide(mask, UV, texel);
		al = smoothstep(0.05, 0.8, m) * 0.9 * shade;
	} else if (style == 3) {   // x-ray: the penis's own drawing, darkened, seen through the skin
		col = c.rgb * 0.35;
		al = a * 0.85 * shade;
	} else {                   // 0: a soft dark inside and a light rim (as before)
		float body_shadow = 0.60 * b * (1.0 - rim) * boost;
		col = vec3(rim);
		al = max(body_shadow, 0.55 * rim * boost) * shade;
	}
	float la = min(drawn * outline * 1.2 * shade * boost, 1.0);  // the penis's drawn outline, over any style
	ALBEDO = mix(col, vec3(0.0), la);
	if (in_cut(flat_q)) {
		w = 0.0;  // (behind the back, where the lock cut the sleeve: a floating shadow, the owner's "ghosts")
	}
	ALPHA = clamp(max(al, la), 0.0, 1.0) * w * alpha;
}"""
	if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
		sh.code = _shade_gles2(sh.code)
	sh.set_meta("gpu_bend", sh.code.find("gpu_bend") >= 0)
	cache[on_top] = sh
	return sh


static func _cut_off(pen: Dictionary, cut: Array) -> Dictionary:
	if cut.empty():
		return pen
	var v = pen["v"]
	var uv = pen["uv"]
	var dd = pen["d"]
	var idx = pen["i"]
	var boxes = []
	for piece in cut:
		boxes.append(_rect(piece))
	var before = []
	var out = []
	for k in v.size():
		var q = Vector2(v[k].x, v[k].y)
		var b = dd[k] <= 0.0
		var o = false
		if not b:
			for j in cut.size():
				if boxes[j].has_point(q) and Geometry.is_point_in_polygon(q, cut[j]):
					o = true
					break
		before.append(b)
		out.append(o)
	var ov = PoolVector3Array()
	var ouv = PoolVector2Array()
	var od = PoolRealArray()
	var oi = PoolIntArray()
	for t in range(0, idx.size() - 2, 3):
		var a = idx[t]
		var b = idx[t + 1]
		var c = idx[t + 2]
		var kept = 0
		for k in [a, b, c]:
			if not before[k] and not out[k]:
				kept += 1
		if kept == 0:
			continue
		if not (out[a] or out[b] or out[c]):
			for k in [a, b, c]:
				oi.append(ov.size())
				ov.append(v[k])
				ouv.append(uv[k])
				od.append(dd[k])
			continue
		var pa = Vector2(v[a].x, v[a].y)
		var pb = Vector2(v[b].x, v[b].y)
		var pc = Vector2(v[c].x, v[c].y)
		if abs((pb - pa).cross(pc - pa)) < 1e-12:
			continue
		var tri = PoolVector2Array([pa, pb, pc])
		if Geometry.is_polygon_clockwise(tri):
			tri.invert()
		var left = [tri]
		for piece in cut:
			var next = []
			for poly in left:
				for rest in Geometry.clip_polygons_2d(poly, piece):
					if not Geometry.is_polygon_clockwise(rest):
						next.append(rest)
			left = next
		for piece in left:
			var tris = Geometry.triangulate_polygon(piece)
			var base = ov.size()
			for q in piece:
				var w = _barycentric(q, pa, pb, pc)
				ov.append(Vector3(q.x, q.y, v[a].z))
				ouv.append(uv[a] * w.x + uv[b] * w.y + uv[c] * w.z)
				od.append(dd[a] * w.x + dd[b] * w.y + dd[c] * w.z)
			for k in tris:
				oi.append(base + k)
	var n = PoolVector3Array()
	var col = PoolColorArray()
	for _k in ov.size():
		n.append(Vector3.BACK)
		col.append(Color.white)
	return {"v": ov, "n": n, "uv": ouv, "c": col, "i": oi, "d": od}


const META_SHADE_BASE = "bd_shade_base"
const SHADE_AABB = AABB(Vector3(-1e4, -1e4, -1e4), Vector3(2e4, 2e4, 2e4))


const BEND_TAB = 512
static func _shade_arrays(mp: Mesh, xp: Transform, info: Dictionary, cut: Array, smat: ShaderMaterial, gpu := true) -> Array:
	if not mp.has_meta(META_SHADE_BASE):
		var src = mp.surface_get_arrays(0)
		var nv = src[Mesh.ARRAY_VERTEX].size()
		var nor = PoolVector3Array()
		var col = PoolColorArray()
		for _k in nv:
			nor.append(Vector3.BACK)
			col.append(Color.white)
		var idx = src[Mesh.ARRAY_INDEX]
		if idx == null or idx.size() == 0:
			idx = PoolIntArray()
			for k in nv:
				idx.append(k)
		var uv = src[Mesh.ARRAY_TEX_UV]
		if uv == null or uv.size() != nv:
			uv = PoolVector2Array()
			uv.resize(nv)
		mp.set_meta(META_SHADE_BASE, {"v": src[Mesh.ARRAY_VERTEX], "uv": uv, "i": idx, "n": nor, "c": col})
	var base = mp.get_meta(META_SHADE_BASE)
	gpu = gpu and _gpu_bends(smat.shader)
	if gpu:
		_bend_table(smat, info, xp)
		_cut_table(smat, cut)
		var raw = []
		raw.resize(Mesh.ARRAY_MAX)
		raw[Mesh.ARRAY_VERTEX] = base["v"]
		raw[Mesh.ARRAY_NORMAL] = base["n"]
		raw[Mesh.ARRAY_TEX_UV] = base["uv"]
		raw[Mesh.ARRAY_COLOR] = base["c"]
		raw[Mesh.ARRAY_INDEX] = base["i"]
		return raw
	smat.set_shader_param("gpu_bend", false)
	smat.set_shader_param("cut_n", 0)
	var sv = xp.xform(base["v"])
	var n = sv.size()
	var e = info["entry_pt"]
	var dir = info["dir"]
	var out = PoolVector3Array()
	out.resize(n)
	var dd = PoolRealArray()
	dd.resize(n)
	var uv2 = PoolVector2Array()
	uv2.resize(n)
	var bent = info.has("ang")
	var p = []
	var b = []
	var ang = []
	var bdir = Vector2.RIGHT
	var along = []
	if bent:
		p = info["straight"]
		b = info["path"]
		ang = info["ang"]
		bdir = (p[p.size() - 1] - p[0]).normalized()
		for q in p:
			along.append((q - p[0]).dot(bdir))
	for k in n:
		var q = Vector2(sv[k].x, sv[k].y)
		var d = (q - e).dot(dir)
		dd[k] = d
		uv2[k] = Vector2(d, 0.0)
		if bent:
			var i = int(clamp(along.bsearch((q - p[0]).dot(bdir)) - 1, 0, p.size() - 1))
			var off = q - p[i]
			if i == p.size() - 1 and off.dot(bdir) > 0.0:
				off -= bdir * off.dot(bdir)
			q = b[i] + off.rotated(ang[i])
		out[k] = Vector3(q.x, q.y, 0.02)
	if not cut.empty():
		return MeshMerge._pack(_overlay(_cut_off({"v": out, "uv": base["uv"], "i": base["i"], "d": dd}, cut)))
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = out
	arrays[Mesh.ARRAY_NORMAL] = base["n"]
	arrays[Mesh.ARRAY_TEX_UV] = base["uv"]
	arrays[Mesh.ARRAY_TEX_UV2] = uv2
	arrays[Mesh.ARRAY_COLOR] = base["c"]
	arrays[Mesh.ARRAY_INDEX] = base["i"]
	return arrays


static func _shade_gles2(code: String) -> String:
	code = code.replace("\tvec4 c = texture(mask, UV);\n", "\tvec4 c = texture(mask, UV);\n\tc.rgb = bulge_lin(c.rgb);\n")
	var end = code.rfind("}")
	code = code.substr(0, end) + "\tALBEDO = bulge_srgb(ALBEDO);\n\tALPHA = 1.0 - pow(1.0 - ALPHA, 1.0 / 2.2);\n}"
	var at = code.find("void fragment()")
	return code.substr(0, at) + """vec3 bulge_lin(vec3 c) {
	return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
}
vec3 bulge_srgb(vec3 c) {
	return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}
""" + code.substr(at)


static func _shade_vertex() -> String:
	var gles2 = OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2
	if gles2 and not OS.has_feature("pc"):
		return """varying float along;
varying vec2 flat_q;  // (GLES2 wants every varying written before fragment() reads it)
void vertex() {
	along = UV2.x;  // the distance past the entry along the penis (deform: pen "d")
	flat_q = VERTEX.xy;
}
bool in_cut(vec2 p) {
	return false;
}"""
	var code = """// gpu_bend (_shade_arrays, most frames): the surface is the penis mesh at rest; placed by shade_xp, bent here like
// bend_points (row 0 of bend_tab: straight sample, bent sample; row 1: its place along bend_dir, its turn), mirrored
// (BodyPose.world_of) and put at shade_z. Otherwise the cpu placed it and UV2.x is the distance past the entry.
uniform bool gpu_bend = false;
uniform mat4 shade_xp;
uniform vec2 shade_entry = vec2(0.0);
uniform vec2 shade_dir = vec2(1.0, 0.0);
uniform sampler2D bend_tab : hint_black;
uniform int bend_n = 0;  // 0: straight
uniform vec2 bend_p0 = vec2(0.0);
uniform vec2 bend_dir = vec2(1.0, 0.0);
uniform bool mirror = false;
uniform float shade_z = 0.02;
varying float along;
varying vec2 flat_q;  // where this point is in deform's (flat) space: the cut test
void vertex() {
	if (gpu_bend) {
		vec2 q = (shade_xp * vec4(VERTEX, 1.0)).xy;
		along = dot(q - shade_entry, shade_dir);
		if (bend_n > 0) {
			float a = dot(q - bend_p0, bend_dir);
			int i = 0;
			for (int k = 1; k < bend_n; k++) {  // the last sample before a (bend_points' bsearch)
				if (texelFetch(bend_tab, ivec2(k, 1), 0).r < a) {
					i = k;
				} else {
					break;
				}
			}
			vec4 r0 = texelFetch(bend_tab, ivec2(i, 0), 0);
			float ang = texelFetch(bend_tab, ivec2(i, 1), 0).g;
			vec2 off = q - r0.xy;
			if (i == bend_n - 1 && dot(off, bend_dir) > 0.0) {  // past the last sample (stop_at_neck cut the rest)
				off -= bend_dir * dot(off, bend_dir);
			}
			q = r0.zw + vec2(off.x * cos(ang) - off.y * sin(ang), off.x * sin(ang) + off.y * cos(ang));
		}
		flat_q = q;
		if (mirror) {
			q.x = -q.x;
		}
		VERTEX = vec3(q, shade_z);
	} else {
		along = UV2.x;  // the distance past the entry along the penis (deform: pen "d")
		flat_q = VERTEX.xy;
	}
}
// the lock's cut pieces (cut_tab: one edge a texel, every piece's edges in a row): inside one = no shade
uniform sampler2D cut_tab : hint_black;
uniform int cut_n = 0;
bool in_cut(vec2 p) {
	bool inside = false;
	for (int k = 0; k < cut_n; k++) {
		vec4 e = texelFetch(cut_tab, ivec2(k, 0), 0);
		if ((e.y > p.y) != (e.w > p.y) && p.x < (e.z - e.x) * (p.y - e.y) / (e.w - e.y) + e.x) {
			inside = !inside;
		}
	}
	return inside;
}
"""
	if gles2:
		return gles2(code.replace("uniform int cut_n = 0;\n", "uniform int cut_n = 0;\n" + GLES2_CUT_BOX[0]) \
			.replace("\tbool inside = false;\n", GLES2_CUT_BOX[1] + "\tbool inside = false;\n"))
	return code


const GLES2_CUT_BOX = ["uniform vec4 cut_box = vec4(0.0);  // the cut's box: min xy, max xy (_cut_table)\n",
	"\tif (p.x < cut_box.x || p.y < cut_box.y || p.x > cut_box.z || p.y > cut_box.w) {\n\t\treturn false;\n\t}\n"]


static func _bend_table(smat: ShaderMaterial, info: Dictionary, xp: Transform) -> void:
	smat.set_shader_param("gpu_bend", true)
	smat.set_shader_param("shade_xp", xp)
	smat.set_shader_param("shade_entry", info["entry_pt"])
	smat.set_shader_param("shade_dir", info["dir"])
	if not info.has("ang"):
		smat.set_shader_param("bend_n", 0)
		return
	var p = info["straight"]
	var b = info["path"]
	var ang = info["ang"]
	var n = min(p.size(), BEND_TAB)
	var bdir = (p[p.size() - 1] - p[0]).normalized()
	var img = null
	if smat.has_meta("bend_img"):
		img = smat.get_meta("bend_img")
	if img == null:
		img = Image.new()
		img.create(BEND_TAB, 2, false, Image.FORMAT_RGBAF)
		smat.set_meta("bend_img", img)
		var t = ImageTexture.new()
		t.create_from_image(gles2_table(img), 0)
		smat.set_meta("bend_tex", t)
		if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
			smat.set_shader_param("bend_tab_px", t.get_size())
		smat.set_shader_param("bend_tab", t)
	img.lock()
	for i in n:
		img.set_pixel(i, 0, Color(p[i].x, p[i].y, b[i].x, b[i].y))
		img.set_pixel(i, 1, Color((p[i] - p[0]).dot(bdir), ang[i], 0.0, 0.0))
	img.unlock()
	if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
		smat.get_meta("bend_tex").set_data(gles2_table(img))
	else:
		smat.get_meta("bend_tex").set_data(img)
	smat.set_shader_param("bend_n", n)
	smat.set_shader_param("bend_p0", p[0])
	smat.set_shader_param("bend_dir", bdir)


const CUT_TAB = 1024
static func _cut_table(smat: ShaderMaterial, cut: Array) -> void:
	var n = 0
	if not cut.empty():
		var img = null
		if smat.has_meta("cut_img"):
			img = smat.get_meta("cut_img")
		if img == null:
			img = Image.new()
			img.create(CUT_TAB, 1, false, Image.FORMAT_RGBAF)
			smat.set_meta("cut_img", img)
			var t = ImageTexture.new()
			t.create_from_image(gles2_table(img), 0)
			smat.set_meta("cut_tex", t)
			if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
				smat.set_shader_param("cut_tab_px", t.get_size())
			smat.set_shader_param("cut_tab", t)
		img.lock()
		var gles2 = OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2
		var box = Rect2(cut[0][0], Vector2.ZERO)
		for piece in cut:
			for k in piece.size():
				if n >= CUT_TAB:
					break
				var a = piece[k]
				var b = piece[(k + 1) % piece.size()]
				img.set_pixel(n, 0, Color(a.x, a.y, b.x, b.y))
				if gles2:
					box = box.expand(a)
				n += 1
		img.unlock()
		if gles2:
			smat.set_shader_param("cut_box", Plane(box.position.x, box.position.y, box.end.x, box.end.y))
			smat.get_meta("cut_tex").set_data(gles2_table(img))
		else:
			smat.get_meta("cut_tex").set_data(img)
	smat.set_shader_param("cut_n", n)


static func _overlay(pen: Dictionary) -> Dictionary:
	var v = PoolVector3Array()
	var nor = PoolVector3Array()
	var col = PoolColorArray()
	var uv2 = PoolVector2Array()
	for k in pen["v"].size():
		var p = pen["v"][k]
		v.append(Vector3(p.x, p.y, 0.02))
		nor.append(Vector3.BACK)
		col.append(Color.white)
		uv2.append(Vector2(pen["d"][k], 0.0))
	return {"v": v, "n": nor, "uv": pen["uv"], "c": col, "i": pen["i"], "uv2": uv2}


static func _v3(p: Vector2) -> Vector3:
	return Vector3(p.x, p.y, 0.0)


static func _xy(p: Vector3) -> Vector2:
	return Vector2(p.x, p.y)
