extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument

static func fitOf(mesh:Mesh):
	if(mesh == null || mesh.get_surface_count() <= 0):
		return null
	var arrays:Array = mesh.surface_get_arrays(0)
	if(arrays.size() <= Mesh.ARRAY_TEX_UV):
		return null
	var verts = arrays[Mesh.ARRAY_VERTEX]
	var uvs = arrays[Mesh.ARRAY_TEX_UV]
	if(verts == null || uvs == null || verts.size() < 3 || uvs.size() != verts.size()):
		return null
	var A := [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
	var bu := [0.0, 0.0, 0.0]
	var bv := [0.0, 0.0, 0.0]
	var restMin := Vector2(99999.0, 99999.0)
	var restMax := Vector2(-99999.0, -99999.0)
	for i in range(verts.size()):
		var vert:Vector3 = verts[i]
		var uv:Vector2 = uvs[i]
		var p := [vert.x, vert.y, 1.0]
		for r in range(3):
			for c in range(3):
				A[r][c] += p[r] * p[c]
			bu[r] += p[r] * uv.x
			bv[r] += p[r] * uv.y
		restMin.x = min(restMin.x, vert.x)
		restMin.y = min(restMin.y, vert.y)
		restMax.x = max(restMax.x, vert.x)
		restMax.y = max(restMax.y, vert.y)
	var mu = solve3(A, bu)
	var mv = solve3(A, bv)
	if(mu == null || mv == null):
		return null
	return {
		"u": Vector3(mu[0], mu[1], mu[2]),
		"v": Vector3(mv[0], mv[1], mv[2]),
		"restMin": restMin,
		"restMax": restMax,
	}


static func restToUV(fit:Dictionary, restPos:Vector2) -> Vector2:
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	return Vector2(
		rowU.x * restPos.x + rowU.y * restPos.y + rowU.z,
		rowV.x * restPos.x + rowV.y * restPos.y + rowV.z)


static func solve3(A:Array, b:Array):
	var m := [
		[A[0][0], A[0][1], A[0][2], b[0]],
		[A[1][0], A[1][1], A[1][2], b[1]],
		[A[2][0], A[2][1], A[2][2], b[2]],
	]
	for col in range(3):
		var pivot := col
		for r in range(col + 1, 3):
			if(abs(m[r][col]) > abs(m[pivot][col])):
				pivot = r
		var swap = m[col]
		m[col] = m[pivot]
		m[pivot] = swap
		var diag:float = m[col][col]
		if(abs(diag) < 0.000000001):
			return null
		for c in range(col, 4):
			m[col][c] /= diag
		for r in range(3):
			if(r == col):
				continue
			var factor:float = m[r][col]
			for c in range(col, 4):
				m[r][c] -= factor * m[col][c]
	return [m[0][3], m[1][3], m[2][3]]


const SAMPLES_PER_COLUMN:int = 256
const ALPHA_THRESHOLD:float = 0.35
const ALPHA_CUT = 90
static func columnExtent(data:PoolByteArray, fit:Dictionary, x:float, minY:float, maxY:float, width:int, height:int) -> Vector2:
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	var dy = (maxY - minY) / float(SAMPLES_PER_COLUMN)
	var u0 = rowU.x * x + rowU.y * (minY + 0.5 * dy) + rowU.z
	var v0 = rowV.x * x + rowV.y * (minY + 0.5 * dy) + rowV.z
	var du = rowU.y * dy
	var dv = rowV.y * dy
	var lowest = -1
	for sample in range(SAMPLES_PER_COLUMN):
		var u = u0 + du * sample
		var v = v0 + dv * sample
		if u >= 0.0 and u <= 1.0 and v >= 0.0 and v <= 1.0:
			if data[(int(v * (height - 1)) * width + int(u * (width - 1))) * 4 + 3] >= ALPHA_CUT:
				lowest = sample
				break
	if lowest < 0:
		return Vector2.ZERO
	var highest = lowest
	for sample in range(SAMPLES_PER_COLUMN - 1, lowest, -1):
		var u = u0 + du * sample
		var v = v0 + dv * sample
		if u >= 0.0 and u <= 1.0 and v >= 0.0 and v <= 1.0:
			if data[(int(v * (height - 1)) * width + int(u * (width - 1))) * 4 + 3] >= ALPHA_CUT:
				highest = sample
				break
	return Vector2(lerp(minY, maxY, (lowest + 0.5) / float(SAMPLES_PER_COLUMN)), lerp(minY, maxY, (highest + 0.5) / float(SAMPLES_PER_COLUMN)))


static func alphaData(image:Image) -> PoolByteArray:
	if image.get_format() != Image.FORMAT_RGBA8:
		image = image.duplicate()
		if image.is_compressed():
			image.decompress()
		image.convert(Image.FORMAT_RGBA8)
	return image.get_data()


const CLIFF_COLUMNS:int = 96
const CLIFF_LIMIT:float = 0.45
const CLIFF_RATIO:float = 1.35
const SKIP_BASE:float = 0.3
static func findCliff(data:PoolByteArray, fit:Dictionary, drawnBase:float, drawnTip:float, minY:float, maxY:float, width:int, height:int) -> float:
	var previous:float = -1.0
	var bestDrop:float = 0.0
	var bestT:float = -1.0
	for column in range(CLIFF_COLUMNS):
		var t:float = CLIFF_LIMIT * (column + 0.5) / float(CLIFF_COLUMNS)
		var extent:Vector2 = columnExtent(data, fit, lerp(drawnBase, drawnTip, t), minY, maxY, width, height)
		var here:float = max(extent.y - extent.x, 0.0)
		if(here <= 0.0):
			previous = -1.0
			continue
		if(previous > 0.0 && previous - here > bestDrop && previous / here >= CLIFF_RATIO):
			bestDrop = previous - here
			bestT = t
		previous = here
	if(bestT < 0.0):
		return SKIP_BASE
	return bestT


const DEFAULT_BINS:int = 64
const SCAN_COLUMNS:int = 48
static func measure(mesh:Mesh, texture:Texture, bins:int = DEFAULT_BINS) -> Dictionary:
	var fit:Dictionary = fitOf(mesh)
	if(fit == null || texture == null):
		return {}
	var image:Image = texture.get_data()
	if(image == null):
		return {}
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var width:int = image.get_width()
	var height:int = image.get_height()
	var data:PoolByteArray = alphaData(image)
	var drawnBase:float = restMax.x
	var drawnTip:float = restMin.x
	var found:bool = false
	for column in range(SCAN_COLUMNS):
		var x:float = lerp(restMax.x, restMin.x, (column + 0.5) / float(SCAN_COLUMNS))
		var extent0:Vector2 = columnExtent(data, fit, x, restMin.y, restMax.y, width, height)
		if(extent0.y - extent0.x <= 0.0):
			continue
		if(!found):
			drawnBase = x
			found = true
		drawnTip = x
	if(!found):
		return {}
	var skip:float = findCliff(data, fit, drawnBase, drawnTip, restMin.y, restMax.y, width, height)
	var profile:Array = []
	var extents:Array = []
	for bin in range(bins):
		var t:float = skip + (1.0 - skip) * (bin + 0.5) / float(bins)
		var x2:float = lerp(drawnBase, drawnTip, t)
		var extent:Vector2 = columnExtent(data, fit, x2, restMin.y, restMax.y, width, height)
		extents.append(extent)
		profile.append(max(extent.y - extent.x, 0.0) * 0.5)
	var total:float = 0.0
	for value in profile:
		total += value
	var mean:float = total / float(max(profile.size(), 1))
	if(mean <= 0.0001):
		return {}
	for i in range(profile.size()):
		profile[i] = profile[i] / mean
	var edges:Array = edgesOf(extents, mean)
	return {
		"profile": profile,
		"girth": mean,
		"span": Vector2(drawnBase, drawnTip),
		"skip": skip,
		"edge_up": edges[0],
		"edge_down": edges[1],
		"extents": extents,
	}


static func edgesOf(extents:Array, mean:float) -> Array:
	var n:float = 0.0
	var sx:float = 0.0
	var sy:float = 0.0
	var sxx:float = 0.0
	var sxy:float = 0.0
	for i in range(extents.size()):
		var e:Vector2 = extents[i]
		if(e.y - e.x <= 0.0):
			continue
		var mid:float = (e.x + e.y) * 0.5
		n += 1.0
		sx += i
		sy += mid
		sxx += i * i
		sxy += i * mid
	var up:Array = []
	var down:Array = []
	if(n < 2.0 || mean <= 0.0001):
		return [up, down]
	var slope:float = (n * sxy - sx * sy) / max(n * sxx - sx * sx, 0.000001)
	var offset:float = (sy - slope * sx) / n
	for i in range(extents.size()):
		var e:Vector2 = extents[i]
		if(e.y - e.x <= 0.0):
			up.append(0.0)
			down.append(0.0)
			continue
		var axis:float = offset + slope * i
		up.append(max(e.y - axis, 0.0) / mean)
		down.append(max(axis - e.x, 0.0) / mean)
	return [up, down]


static func profileAt(profile:Array, t:float) -> float:
	if(profile.empty()):
		return 1.0
	var last:int = profile.size() - 1
	var local:float = clamp(t, 0.0, 1.0) * last
	var low:int = int(floor(local))
	var high:int = int(min(low + 1, last))
	return lerp(float(profile[low]), float(profile[high]), local - low)
