extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument

const BodyShape = preload("res://Bulge4/Effects/Detailed/Lab/BodyShape.gd")
const BodyDeform = preload("res://Bulge4/Effects/Detailed/Lab/BodyDeform.gd")
const LOCK_REACH = 0.5
const SD_COARSE = 2.0
const MIRROR_STRIDE = 4


static func pose(mesh: Mesh, bs: Dictionary, mats: Array, lock_at: float, pv = null) -> Dictionary:
	if not bs.has("rest_arrays"):
		bs["rest_arrays"] = mesh.surface_get_arrays(0)
	var a = bs["rest_arrays"].duplicate()
	var rv = a[Mesh.ARRAY_VERTEX]
	var bones = a[Mesh.ARRAY_BONES]
	var weights = a[Mesh.ARRAY_WEIGHTS]
	if not bs.has("rest_z0"):
		var z = 0.0
		for p in rv:
			z += p.z / rv.size()
		bs["rest_z0"] = z
	var z0 = bs["rest_z0"]
	if pv == null or pv.size() != rv.size():
		pv = skinned(rv, bones, weights, mats)
	var idx = a[Mesh.ARRAY_INDEX]
	var flipped = 0
	var total = 0
	for t in range(0, idx.size() - 2, 3 * MIRROR_STRIDE):
		var a0 = rv[idx[t]]
		var a1 = rv[idx[t + 1]]
		var a2 = rv[idx[t + 2]]
		var b0 = pv[idx[t]]
		var b1 = pv[idx[t + 1]]
		var b2 = pv[idx[t + 2]]
		var r = (a1.x - a0.x) * (a2.y - a0.y) - (a2.x - a0.x) * (a1.y - a0.y)
		var q = (b1.x - b0.x) * (b2.y - b0.y) - (b2.x - b0.x) * (b1.y - b0.y)
		if r != 0.0 and q != 0.0:
			total += 1
			if (r > 0.0) != (q > 0.0):
				flipped += 1
	var out = {"mats": mats, "z0": z0, "mirror": flipped * 2 > total, "pv": pv, "rv": rv}
	var sx = 1.0
	if out["mirror"]:
		sx = -1.0
	a[Mesh.ARRAY_VERTEX] = Transform(Basis(Vector3(sx, 0, 0), Vector3(0, 1, 0), Vector3.ZERO), Vector3.ZERO).xform(pv)
	var pm = ArrayMesh.new()
	pm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	out["mesh"] = pm
	var sk = BodyDeform._skin_data(mesh, bs)
	var pb = {"posed": true, "fit": bs["fit"], "cell": bs["cell"] * SD_COARSE}
	for key in ["outline", "front", "axis"]:
		pb[key] = _pose_line(out, sk, bs, bs[key], key)
	var clean = BodyDeform._largest(Geometry.merge_polygons_2d(pb["outline"], pb["outline"]))
	if clean.size() >= 3:
		if Geometry.is_polygon_clockwise(clean):
			clean.invert()
		pb["outline"] = clean
	pb["bounds"] = BodyDeform._rect(pb["outline"])
	pb["rest_v"] = rv
	pb["rest_bs"] = bs
	pb["lock_poly"] = _lock_band(out, sk, bs, lock_at)
	pb["top"] = _pose_point(out, sk, bs, Vector2(bs["axis"][bs["axis"].size() - 1].x, bs["bounds"].end.y))
	_anchors(out, sk, bs, pb)
	if not bs.has("entry_bind"):
		bs["entry_bind"] = _entry_bind(rv, bones, weights, bs)
	if not bs.has("neck_bind"):
		bs["neck_bind"] = _entry_bind(rv, bones, weights, bs, true)
	if bs["entry_bind"] >= 0 and bs["entry_bind"] < mats.size():
		pb["entry_xf"] = mats[bs["entry_bind"]]
		pb["z0"] = z0
		pb["mirror"] = out["mirror"]
	if bs["neck_bind"] >= 0 and bs["neck_bind"] < mats.size():
		pb["neck_xf"] = mats[bs["neck_bind"]]
		pb["z0"] = z0
		pb["mirror"] = out["mirror"]
	out["bs"] = pb
	if not bs.has("rest_sd"):
		var rsd = PoolRealArray()
		for p in rv:
			rsd.append(BodyShape.sd(bs, Vector2(p.x, p.y)))
		bs["rest_sd"] = rsd
	out["rest_sd"] = bs["rest_sd"]
	return out


static func skinned(rv: PoolVector3Array, bones, weights, mats: Array) -> PoolVector3Array:
	var nm = mats.size()
	var pv = PoolVector3Array()
	pv.resize(rv.size())
	for i in rv.size():
		var r = rv[i]
		var acc = Vector3.ZERO
		for j in range(i * 4, i * 4 + 4):
			var w = weights[j]
			var k = bones[j]
			if w > 0.0 and k >= 0 and k < nm:
				acc += (mats[k] * r) * w
		pv[i] = acc
	return pv


const ENTRY_BAND = 0.25


static func _entry_bind(rv, bones, weights, bs: Dictionary, top := false) -> int:
	if bones == null or weights == null or bones.size() != rv.size() * 4 or weights.size() != rv.size() * 4:
		return -1
	var low = bs["bounds"].position.y + bs["bounds"].size.y * ENTRY_BAND
	var high = bs["bounds"].end.y - bs["bounds"].size.y * ENTRY_BAND
	var sums = {}
	for i in rv.size():
		if (not top and rv[i].y > low) or (top and rv[i].y < high):
			continue
		for j in range(i * 4, i * 4 + 4):
			if weights[j] > 0.0:
				sums[bones[j]] = sums.get(bones[j], 0.0) + weights[j]
	var best = -1
	var most = 0.0
	for b in sums:
		if sums[b] > most:
			most = sums[b]
			best = b
	return best


const GUIDE_POINTS = 4


static func _anchors(pose: Dictionary, sk: Dictionary, bs: Dictionary, pb: Dictionary) -> void:
	var axis = bs["axis"]
	var front = bs["front"]
	var n = axis.size()
	var out = []
	for k in GUIDE_POINTS:
		var i = int(round(k * (n - 1) / float(GUIDE_POINTS - 1)))
		var t = (front[min(i + 1, n - 1)] - front[max(i - 1, 0)]).normalized()
		var middle = max((axis[i] - front[i]).dot(Vector2(t.y, -t.x)), 0.0)
		out.append([_pose_point(pose, sk, bs, axis[i]), _pose_point(pose, sk, bs, front[i]), middle])
	pb["anchors"] = out


static func _lock_band(pose: Dictionary, sk: Dictionary, bs: Dictionary, lock_at: float) -> PoolVector2Array:
	var key = "lock %s" % lock_at
	if sk.has("line_tabs") and sk["line_tabs"].has(key):
		return _pose_line(pose, sk, bs, [], key)
	var b = bs["bounds"]
	var x0 = b.position.x + b.size.x * lock_at
	var x1 = b.end.x + b.size.x * LOCK_REACH
	var corners = [Vector2(x0, b.position.y), Vector2(x1, b.position.y), Vector2(x1, b.end.y), Vector2(x0, b.end.y)]
	var step = bs["cell"] * 2.0
	var line = []
	for i in 4:
		var p = corners[i]
		var q = corners[(i + 1) % 4]
		var n = max(int(p.distance_to(q) / step), 1)
		for k in n:
			line.append(p.linear_interpolate(q, float(k) / n))
	return _pose_line(pose, sk, bs, line, key)


const _SHADERS = {}
const UV_MAP = 512
const UV_MAP_PAD = 0.3
const UV_MAP_SHADER = """shader_type spatial;
render_mode unshaded, cull_disabled;
varying float bulge_depth;
void vertex() {
	bulge_depth = VERTEX.z;  // the rest depth inside the drawing (uv_map puts it in z)
}
void fragment() {
	ALBEDO = vec3(UV, max(bulge_depth, 0.0));
}
"""


const UV_MAP_DEPTH = 16.0
const UV_MAP_GLES2 = """shader_type spatial;
render_mode unshaded, cull_disabled;
uniform bool depth_pass = false;
varying float bulge_depth;
void vertex() {
	bulge_depth = VERTEX.z;
}
void fragment() {
	if (depth_pass) {
		float d = floor(clamp(bulge_depth / 16.0, 0.0, 1.0) * 16777215.0 + 0.5);
		ALBEDO = vec3(floor(d / 65536.0), mod(floor(d / 256.0), 256.0), mod(d, 256.0)) / 255.0;
	} else {
		vec2 q = floor(clamp(UV, 0.0, 1.0) * 4095.0 + 0.5);
		ALBEDO = vec3(floor(q.x / 16.0), floor(q.y / 16.0), mod(q.x, 16.0) * 16.0 + mod(q.y, 16.0)) / 255.0;
	}
}
"""


static func uv_map(pose: Dictionary, host: Node, name: String = "BulgeUvMap") -> void:
	var gles2 = OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2
	var vp = host.get_node_or_null(name)
	if vp == null:
		vp = _map_viewport(gles2, false)
		vp.name = name
		host.add_child(vp)
		if not gles2:
			vp.get_texture().flags = Texture.FLAG_FILTER
		else:
			var dvp = _map_viewport(true, true)
			dvp.name = "Depth"
			vp.add_child(dvp)
	var a = pose["mesh"].surface_get_arrays(0)
	var v = a[Mesh.ARRAY_VERTEX]
	for i in v.size():
		v[i].z = pose["rest_sd"][i]
	a[Mesh.ARRAY_VERTEX] = v
	a[Mesh.ARRAY_BONES] = null
	a[Mesh.ARRAY_WEIGHTS] = null
	var m = ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	var b = pose["bs"]["bounds"].grow(UV_MAP_PAD)
	var side = max(b.size.x, b.size.y)
	var c = b.position + b.size * 0.5
	var maps = [vp]
	if gles2:
		maps.append(vp.get_node("Depth"))
	for map in maps:
		map.get_child(1).mesh = m
		var cam = map.get_child(0)
		cam.size = side
		cam.transform = Transform(Basis.IDENTITY, Vector3(c.x, c.y, 50.0))
		map.render_target_update_mode = Viewport.UPDATE_ONCE
	pose["bs"]["uv_map"] = {"tex": vp.get_texture(), "origin": c - Vector2(side, side) * 0.5, "size": Vector2(side, side)}
	if gles2:
		pose["bs"]["uv_map"]["depth"] = maps[1].get_texture()


static func _map_viewport(gles2: bool, depth_pass: bool) -> Viewport:
	var vp = Viewport.new()
	vp.size = Vector2(UV_MAP, UV_MAP)
	vp.own_world = true
	vp.hdr = true
	vp.keep_3d_linear = not gles2
	vp.transparent_bg = true
	var cam = Camera.new()
	cam.projection = Camera.PROJECTION_ORTHOGONAL
	cam.near = 0.01
	cam.far = 100.0
	cam.current = true
	vp.add_child(cam)
	var mi = MeshInstance.new()
	var mat = ShaderMaterial.new()
	var key = "uv_map"
	var code = UV_MAP_SHADER
	if gles2:
		key = "uv_map_gles2"
		code = UV_MAP_GLES2
	var cache = _SHADERS
	if not cache.has(key):
		cache[key] = Shader.new()
		cache[key].code = code
	mat.shader = cache[key]
	if gles2:
		mat.set_shader_param("depth_pass", depth_pass)
	mi.material_override = mat
	vp.add_child(mi)
	return vp


static func flat_xf(pose: Dictionary, xf: Transform) -> Transform:
	if pose["mirror"]:
		return Transform(Basis(Vector3(-1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1)), Vector3.ZERO) * xf
	return xf


static func world_of(pose: Dictionary, p: Vector2) -> Vector2:
	if pose["mirror"]:
		return Vector2(-p.x, p.y)
	return p


static func unpose(skin: ArrayMesh, pose: Dictionary):
	var a = skin.surface_get_arrays(0)
	var bones = a[Mesh.ARRAY_BONES]
	var weights = a[Mesh.ARRAY_WEIGHTS]
	if bones == null or weights == null:
		return null
	var v = a[Mesh.ARRAY_VERTEX]
	var z0 = pose["z0"]
	var own = 0
	var src = PoolIntArray()
	if skin.has_meta("stats"):
		own = int(skin.get_meta("stats").get("own", 0))
		src = skin.get_meta("stats").get("patch_src", src)
	var rv = pose["rv"]
	for i in own:
		v[i] = rv[i]
	var mats = pose["mats"]
	var nm = mats.size()
	var mt = PoolRealArray()
	mt.resize(nm * 6)
	for k in nm:
		var m = mats[k]
		mt[k * 6] = m.basis.x.x
		mt[k * 6 + 1] = m.basis.x.y
		mt[k * 6 + 2] = m.basis.y.x
		mt[k * 6 + 3] = m.basis.y.y
		mt[k * 6 + 4] = m.origin.x + m.basis.z.x * z0
		mt[k * 6 + 5] = m.origin.y + m.basis.z.y * z0
	var sx = 1.0
	if pose["mirror"]:
		sx = -1.0
	var memo = {}
	var ns = src.size()
	for i in range(own, v.size()):
		var key = -1
		if i - own < ns:
			key = src[i - own]
		var bl = memo.get(key)
		if bl == null:
			var xx = 0.0
			var xy = 0.0
			var yx = 0.0
			var yy = 0.0
			var cx = 0.0
			var cy = 0.0
			var wsum = 0.0
			for j in range(i * 4, i * 4 + 4):
				var w = weights[j]
				var k = bones[j]
				if w <= 0.0 or k < 0 or k >= nm:
					continue
				wsum += w
				var q = k * 6
				xx += mt[q] * w
				xy += mt[q + 1] * w
				yx += mt[q + 2] * w
				yy += mt[q + 3] * w
				cx += mt[q + 4] * w
				cy += mt[q + 5] * w
			var det = xx * yy - yx * xy
			if wsum <= 0.0 or abs(det) < 1e-12:
				det = 0.0
			bl = [xx, xy, yx, yy, cx, cy, det]
			if key >= 0:
				memo[key] = bl
		if bl[6] == 0.0:
			continue
		var p = v[i]
		var tx = p.x * sx - bl[4]
		var ty = p.y - bl[5]
		v[i] = Vector3((tx * bl[3] - bl[2] * ty) / bl[6], (bl[0] * ty - tx * bl[1]) / bl[6], z0)
	a[Mesh.ARRAY_VERTEX] = v
	var out = ArrayMesh.new()
	out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	out.surface_set_material(0, skin.surface_get_material(0))
	for key in skin.get_meta_list():
		out.set_meta(key, skin.get_meta(key))
	return out


static func _pose_point(pose: Dictionary, sk: Dictionary, bs: Dictionary, p: Vector2) -> Vector2:
	if not sk.has("recipes"):
		sk["recipes"] = {}
	var rc = sk["recipes"].get(p)
	if rc == null:
		rc = _recipe(sk, bs, p)
		sk["recipes"][p] = rc
	if rc.size() == 6:
		var pv = pose["pv"]
		return _flat(pose, pv[rc[0]] * rc[3] + pv[rc[1]] * rc[4] + pv[rc[2]] * rc[5])
	return _flat(pose, _blend(pose["mats"], rc[0], rc[1], 0).xform(Vector3(p.x, p.y, pose["z0"])))


static func _recipe(sk: Dictionary, bs: Dictionary, p: Vector2) -> Array:
	var pts = sk["p"]
	var idx = sk["i"]
	for t in sk["hash"].get(int(floor(p.x / sk["cell"])) * 65536 + int(floor(p.y / sk["cell"])), []):
		var l = BodyDeform._barycentric(p, pts[idx[t]], pts[idx[t + 1]], pts[idx[t + 2]])
		if l.x >= -1e-5 and l.y >= -1e-5 and l.z >= -1e-5:
			return [idx[t], idx[t + 1], idx[t + 2], l.x, l.y, l.z]
	var at = BodyDeform._skin_at(sk, bs, p, BodyDeform._lattice_key(p, 0.002))
	return [at["b"], at["w"]]


static func _pose_line(pose: Dictionary, sk: Dictionary, bs: Dictionary, line, key := "") -> PoolVector2Array:
	var out = PoolVector2Array()
	if key == "":
		for p in line:
			out.append(_pose_point(pose, sk, bs, p))
		return out
	if not sk.has("line_tabs"):
		sk["line_tabs"] = {}
	var tab = sk["line_tabs"].get(key)
	if tab == null:
		var rows = []
		var blends = []
		var seen = {}
		for p in line:
			_pose_point(pose, sk, bs, p)
			var rc = sk["recipes"][p]
			if rc.size() == 6:
				rows.append(rc)
			else:
				var id = str(rc[0]) + str(rc[1])
				if not seen.has(id):
					seen[id] = blends.size()
					blends.append(rc)
				rows.append([seen[id], Vector3(p.x, p.y, pose["z0"])])
		tab = [rows, blends]
		sk["line_tabs"][key] = tab
	var pv = pose["pv"]
	var mats = pose["mats"]
	var mirror = pose["mirror"]
	var xs = []
	for bw in tab[1]:
		xs.append(_blend(mats, bw[0], bw[1], 0))
	var rows = tab[0]
	out.resize(rows.size())
	for k in rows.size():
		var rc = rows[k]
		var q
		if rc.size() == 6:
			q = pv[rc[0]] * rc[3] + pv[rc[1]] * rc[4] + pv[rc[2]] * rc[5]
		else:
			q = xs[rc[0]] * rc[1]
		if mirror:
			out[k] = Vector2(-q.x, q.y)
		else:
			out[k] = Vector2(q.x, q.y)
	return out


static func _flat(pose: Dictionary, p: Vector3) -> Vector2:
	if pose["mirror"]:
		return Vector2(-p.x, p.y)
	return Vector2(p.x, p.y)


static func _blend(mats: Array, bones, weights, i: int) -> Transform:
	var b = Basis(Vector3.ZERO, Vector3.ZERO, Vector3.ZERO)
	var o = Vector3.ZERO
	for j in 4:
		var w = float(weights[i * 4 + j])
		var k = int(bones[i * 4 + j])
		if w <= 0.0 or k < 0 or k >= mats.size():
			continue
		b.x += mats[k].basis.x * w
		b.y += mats[k].basis.y * w
		b.z += mats[k].basis.z * w
		o += mats[k].origin * w
	return Transform(b, o)


