extends Reference

const BodyDeform := preload("res://Bulge4/Effects/Detailed/Lab/BodyDeform.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const META_CUT := "bulge4PropCut"
const MIN_WEIGHT := 0.5

static func cutOf(meshInstance:MeshInstance, row:Dictionary) -> Dictionary:
	var mesh:Mesh = meshInstance.mesh
	if(mesh == null):
		return {}
	if(!mesh.has_meta(META_CUT)):
		mesh.set_meta(META_CUT, {})
	var cuts:Dictionary = mesh.get_meta(META_CUT)
	var cutBones:Array = row.get("cut", row["bones"])
	var key:String = str(cutBones)
	if(!cuts.has(key)):
		cuts[key] = makeCut(mesh, meshInstance.skin, row["bones"], cutBones)
	return cuts[key]

static func shapeOf(meshInstance:MeshInstance, row:Dictionary) -> Dictionary:
	var cut:Dictionary = cutOf(meshInstance, row)
	var tex = BulgeUtils.getAlbedoTexture(meshInstance)
	if(cut.empty() || tex == null):
		return {}
	var key:int = tex.get_instance_id()
	if(!cut["shapes"].has(key)):
		if(row.get("outline") == "mesh"):
			cut["shapes"][key] = meshShape(cut["mesh"])
		else:
			cut["shapes"][key] = BodyDeform.shape(cut["mesh"], tex)
	return cut["shapes"][key]

const SHAPE_BINS := 64
static func meshShape(mesh:Mesh) -> Dictionary:
	var a:Array = mesh.surface_get_arrays(0)
	var verts:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
	var index:PoolIntArray = a[Mesh.ARRAY_INDEX]
	var lo:float = INF
	var hi:float = -INF
	for v in verts:
		lo = min(lo, v.x)
		hi = max(hi, v.x)
	var low:Array = []
	var high:Array = []
	for _i in range(SHAPE_BINS):
		low.append(INF)
		high.append(-INF)
	var step:float = (hi - lo) / float(SHAPE_BINS)
	for t in range(0, index.size(), 3):
		for e in range(3):
			var p:Vector3 = verts[index[t + e]]
			var q:Vector3 = verts[index[t + (e + 1) % 3]]
			for i in range(SHAPE_BINS):
				var x:float = hi - (i + 0.5) * step
				if((p.x - x) * (q.x - x) > 0.0 || p.x == q.x):
					continue
				var y:float = lerp(p.y, q.y, (x - p.x) / (q.x - p.x))
				low[i] = min(low[i], y)
				high[i] = max(high[i], y)
	var pts:Array = []
	var rad:Array = []
	var total:float = 0.0
	for i in range(SHAPE_BINS):
		if(high[i] < low[i]):
			continue
		pts.append(Vector2(hi - (i + 0.5) * step, (low[i] + high[i]) * 0.5))
		rad.append((high[i] - low[i]) * 0.5)
		total += rad[rad.size() - 1]
	if(pts.size() < 2):
		return {}
	return {"pts": pts, "rad": rad, "girth": total / float(rad.size()), "skip": 0.0}

static func makeCut(mesh:Mesh, skin:Skin, bones:Array, cutBones:Array) -> Dictionary:
	if(skin == null || mesh.get_surface_count() < 1 || bones.size() < 2):
		return {}
	var binds:Dictionary = {}
	for i in range(skin.get_bind_count()):
		binds[skin.get_bind_name(i)] = i
	if(!binds.has(bones[0]) || !binds.has(bones[bones.size() - 1])):
		return {}
	var wanted:Dictionary = {}
	for one in cutBones:
		if(binds.has(one)):
			wanted[binds[one]] = true
	var a:Array = mesh.surface_get_arrays(0)
	var verts:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
	if(a[Mesh.ARRAY_BONES] == null || a[Mesh.ARRAY_WEIGHTS] == null || a[Mesh.ARRAY_TEX_UV] == null):
		return {}
	var vb:PoolIntArray = a[Mesh.ARRAY_BONES]
	var vw:PoolRealArray = a[Mesh.ARRAY_WEIGHTS]
	var uvs:PoolVector2Array = a[Mesh.ARRAY_TEX_UV]
	var first:Vector3 = skin.get_bind_pose(binds[bones[0]]).affine_inverse().origin
	var last:Vector3 = skin.get_bind_pose(binds[bones[bones.size() - 1]]).affine_inverse().origin
	var axis:Vector2 = Vector2(last.x - first.x, last.y - first.y).normalized()
	var frame := Transform(Basis(Vector3(-axis.x, axis.y, 0.0), Vector3(-axis.y, -axis.x, 0.0), Vector3(0.0, 0.0, 1.0)),
		Vector3.ZERO)
	var newIndex := PoolIntArray()
	newIndex.resize(verts.size())
	var outVerts := PoolVector3Array()
	var outUVs := PoolVector2Array()
	var uvLow := Vector2(INF, INF)
	var uvHigh := Vector2(-INF, -INF)
	for v in range(verts.size()):
		var w:float = 0.0
		for j in range(4):
			if(wanted.has(vb[v * 4 + j])):
				w += vw[v * 4 + j]
		newIndex[v] = -1
		if(w >= MIN_WEIGHT):
			newIndex[v] = outVerts.size()
			outVerts.append(frame.xform(verts[v]))
			outUVs.append(uvs[v])
			uvLow = Vector2(min(uvLow.x, uvs[v].x), min(uvLow.y, uvs[v].y))
			uvHigh = Vector2(max(uvHigh.x, uvs[v].x), max(uvHigh.y, uvs[v].y))
	var index = a[Mesh.ARRAY_INDEX]
	if(index == null):
		index = PoolIntArray(range(verts.size()))
	var outIndex := PoolIntArray()
	for t in range(0, index.size() - 2, 3):
		var i0:int = newIndex[index[t]]
		var i1:int = newIndex[index[t + 1]]
		var i2:int = newIndex[index[t + 2]]
		if(i0 >= 0 && i1 >= 0 && i2 >= 0):
			outIndex.append_array(PoolIntArray([i0, i1, i2]))
	if(outIndex.empty()):
		return {}
	var out:Array = []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = outVerts
	out[Mesh.ARRAY_TEX_UV] = outUVs
	out[Mesh.ARRAY_INDEX] = outIndex
	var cutMesh := ArrayMesh.new()
	cutMesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, out)
	return {"mesh": cutMesh, "frame": frame, "bind": binds[bones[0]], "shapes": {}, "uv_span": uvHigh - uvLow}
