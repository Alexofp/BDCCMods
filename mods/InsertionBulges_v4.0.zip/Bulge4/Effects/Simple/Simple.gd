extends Reference
const Entries := preload("res://Bulge4/Effects/Classic/Entries.gd")
const Measures := preload("res://Bulge4/Effects/Classic/Measures.gd")
const Report := preload("res://Bulge4/Effects/Classic/Report.gd")
const Tuning := preload("res://Bulge4/Effects/Classic/Tuning.gd")
const FieldMath := preload("res://Bulge4/Effects/Classic/Field.gd")
const Skirt := preload("res://Bulge4/Effects/Classic/Skirt.gd")
const Classic := preload("res://Bulge4/Shader/Classic.gd")
const Fits := preload("res://Bulge4/Infer/Fits.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const NO_FOLD_FRACTION = 1.0 / FieldMath.RAMP_SLOPE_PEAK
const META_TORSO := "bdccBulge4Simple"
const META_CLIPPED := "bdccBulge4SimpleClipped"

static func run(stageScene, relations:Array, _opts:Dictionary = {}) -> Array:
	var t0:int = OS.get_ticks_usec()
	var _changed:bool = Entries.use("simple")
	var dolls:Array = stageScene.getDolls()
	for doll in dolls:
		var helper = helperOf(doll)
		if(helper != null):
			for torso in helper.getBulgeMeshesForZone(""):
				clearBumps(torso)
	var rows:Array = []
	var clipped:Array = []
	var entries:Array = []
	if(!relations.empty()):
		entries = Entries.of(stageScene, relations)
	var built:Dictionary = Report.build(entries)
	var byKey:Dictionary = {}
	for entry in entries:
		var engagement:Dictionary = entry["engagement"]
		byKey[Report.rowKey(engagement["shaft"], engagement["hole_owner"], engagement["hole"])] = entry
	var context:Dictionary = {}
	if(!entries.empty()):
		context = Measures.contextFor(stageScene, relations)
	for bulge in built["bulges"]:
		var entry = byKey.get(Report.rowKey(bulge["shaft"], bulge["participant"], bulge["hole"]))
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		var intent = entry.get("intent")
		var rig = context["rig"].get(engagement["hole_owner"])
		var holeHelper = helperOf(dollAt(dolls, engagement["hole_owner"]))
		if(holeHelper == null || typeof(rig) != TYPE_DICTIONARY || typeof(intent) != TYPE_DICTIONARY):
			continue
		var centreWorld:Vector3 = restToWorld(rig, intent["centre_rest"])
		var frontWorld:Vector3 = restDirToWorld(rig, intent["front_dir_rest"])
		var travelWorld:Vector3 = restDirToWorld(rig, intent["travel_dir_rest"])
		var verts:int = applyBulge(holeHelper, str(bulge["hole"]), int(bulge["slot"]), centreWorld,
			centreWorld + frontWorld * float(intent["reach"]), float(intent["spread"]),
			float(intent["amplitude"]), float(intent["shade"]), float(intent["column_half"]),
			intent["shape"], centreWorld + travelWorld, float(intent["axis_depth"]))
		rows.append({"doll": engagement["hole_owner"], "hole": str(bulge["hole"]), "shaft": engagement["shaft"],
			"slot": int(bulge["slot"]), "amplitude": float(intent["amplitude"]), "spread": float(intent["spread"]),
			"verts": verts})
	for clip in built["clips"]:
		var entry = byKey.get(Report.rowKey(clip["participant"], clip["hole_owner"], clip["hole"]))
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		var card = context["shafts"].get(engagement["shaft"])
		var shaftHelper = helperOf(dollAt(dolls, engagement["shaft"]))
		if(shaftHelper == null || !Fits.isShaft(card)):
			continue
		var base:Vector3 = card["base"]
		var dir:Vector3 = (card["tip"] - base) / float(card["length"])
		shaftHelper.unTaperShaftBones()
		shaftHelper.applyShaftClip(base + dir * float(clip["clip_on_axis"]))
		clipped.append(shaftHelper)
	var was:Array = []
	if(stageScene.has_meta(META_CLIPPED)):
		was = stageScene.get_meta(META_CLIPPED)
	for helper in was:
		if(is_instance_valid(helper) && !clipped.has(helper)):
			helper.clearBulgeState()
			helper.restoreShaftTaper()
	stageScene.set_meta(META_CLIPPED, clipped)
	var ms:float = float(OS.get_ticks_usec() - t0) / 1000.0
	for row in rows:
		row["ms"] = ms / float(rows.size())
	return rows

static func restoreAll(stageScene) -> void:
	if(stageScene.has_meta(META_CLIPPED)):
		for helper in stageScene.get_meta(META_CLIPPED):
			if(is_instance_valid(helper)):
				helper.clearBulgeState()
				helper.restoreShaftTaper()
		stageScene.remove_meta(META_CLIPPED)
	for doll in stageScene.getDolls():
		var helper = helperOf(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			restore(torso)

static func restore(torso) -> void:
	if(!torso.has_meta(META_TORSO)):
		return
	var state:Dictionary = torso.get_meta(META_TORSO)
	var material:ShaderMaterial = torso.fancyMaterial
	material.shader = state["shader"]
	if(torso.mesh != state["mesh"]):
		torso.mesh = state["mesh"]
		torso.set_surface_material(0, material)
	torso.remove_meta(META_TORSO)

static func prepare(torso) -> bool:
	if(torso.has_meta(META_TORSO)):
		return true
	var material:ShaderMaterial = torso.fancyMaterial
	var injected = Classic.shaderFor(material.shader)
	if(injected == null):
		return false
	torso.set_meta(META_TORSO, {"mesh": torso.mesh, "shader": material.shader, "lit": false})
	material.shader = injected
	var expanded = Skirt.getExpandedMesh(torso.mesh, Skirt.PAD)
	if(expanded != null && expanded != torso.mesh):
		torso.mesh = expanded
		torso.set_surface_material(0, material)
		material.set_shader_param("bulge_expanded", 1.0)
	material.set_shader_param("bulge_aspect", torso.uvFit["aspect"])
	return true

static func clearBumps(torso) -> void:
	if(!torso.has_meta(META_TORSO)):
		return
	var state:Dictionary = torso.get_meta(META_TORSO)
	if(!bool(state["lit"])):
		return
	for i in range(BulgeUtils.BULGE_SLOTS):
		torso.fancyMaterial.set_shader_param("bulge_par" + str(i), Plane(0.0, 0.0, 0.0, 0.0))
	state["lit"] = false

static func helperOf(doll):
	if(doll == null || !is_instance_valid(doll)):
		return null
	return BulgeDoll.forDoll(doll)

static func dollAt(dolls:Array, id):
	var name:String = str(id)
	if(!name.begins_with("doll")):
		return null
	var index:int = int(name.substr(4))
	if(index < 0 || index >= dolls.size()):
		return null
	return dolls[index]

static func applyBulge(helper, zone:String, index:int, entryWorld:Vector3, tipWorld:Vector3, radius:float,
		strength:float, shade:float, halfLength:float, shape, bandEndWorld, axisDepth:float) -> int:
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return 0
	var boneName:String = BulgeDoll.BULGE_BONE.get(zone, "Hips")
	var restEntry:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, entryWorld)
	var restTip:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, tipWorld)
	var restBandEnd:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, bandEndWorld)
	var verts:int = 0
	for themesh in helper.getBulgeMeshesForZone(zone):
		if(!prepare(themesh)):
			continue
		var meshStrength:float = strength
		var fit = BulgeUtils.fitOf(themesh)
		if(typeof(fit) == TYPE_DICTIONARY):
			meshStrength = unfoldedAmplitude(strength,
				BulgeUtils.restToUV(fit, Vector2(restEntry.x, restEntry.y)),
				BulgeUtils.restToUV(fit, Vector2(restTip.x, restTip.y)), fit["aspect"])
		var radialOn:float = 1.0
		if(zone == "mouth"):
			radialOn = 0.0
		setBulge(themesh, index, Vector2(restEntry.x, restEntry.y), Vector2(restTip.x, restTip.y), radius, meshStrength,
			shade, halfLength, shape, Vector2(restBandEnd.x, restBandEnd.y), axisDepth, radialOn)
		verts += themesh.mesh.surface_get_array_len(0)
	return verts

static func unfoldedAmplitude(amplitude:float, uvA:Vector2, uvB:Vector2, aspect:Vector2) -> float:
	return min(amplitude, ((uvB - uvA) * aspect).length() * NO_FOLD_FRACTION)

static func setBulge(torso, index:int, restA:Vector2, restB:Vector2, spread:float, amplitude:float, shade:float,
		halfLength:float, shape, restBandEnd, axisDepth:float, radialOn:float) -> void:
	if(index < 0 || index >= BulgeUtils.BULGE_SLOTS):
		return
	var uvFit:Dictionary = torso.uvFit
	var material:ShaderMaterial = torso.fancyMaterial
	var uvA:Vector2 = BulgeUtils.restToUV(uvFit, restA)
	var uvB:Vector2 = BulgeUtils.restToUV(uvFit, restB)
	material.set_shader_param("bulge_seg" + str(index), Plane(uvA.x, uvA.y, uvB.x, uvB.y))
	material.set_shader_param("bulge_par" + str(index), Plane(spread, amplitude, shade, halfLength))
	var shapePair:Array = profileOf(uvFit, shape, uvA, uvB, restBandEnd, axisDepth)
	material.set_shader_param("bulge_shp" + str(index), shapePair[0])
	material.set_shader_param("bulge_shp" + str(index) + "b", shapePair[1])
	material.set_shader_param("bulge_shape_fidelity", 1.0)
	material.set_shader_param("bulge_rim_shape", clamp(float(Tuning.value("bulgeRimShape")), 0.0, 1.0))
	material.set_shader_param("bulge_push_radial", FieldMath.radial())
	material.set_shader_param("bulge_radial_on" + str(index), radialOn)
	material.set_shader_param("bulge_band_plateau", FieldMath.bandPlateau())
	material.set_shader_param("bulge_union_overlap", clamp(float(Tuning.value("bulgeUnionOverlap")), 0.0, 1.0))
	torso.get_meta(META_TORSO)["lit"] = true
static func profileOf(uvFit:Dictionary, shape, uvA:Vector2, uvB:Vector2, restBandEnd, axisDepth:float) -> Array:
	var flat:Array = [Plane(1.0, 1.0, 1.0, axisDepth), Plane(1.0, 1.0, 1.0, 1.0)]
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 2 || typeof(restBandEnd) != TYPE_VECTOR2):
		return flat
	var aspect:Vector2 = uvFit["aspect"]
	var here:Vector2 = uvA * aspect
	var outward:Vector2 = uvB * aspect - here
	var across:Vector2 = Vector2(-outward.y, outward.x)
	var towardsTip:Vector2 = BulgeUtils.restToUV(uvFit, restBandEnd) * aspect - here
	var samples:Array = resampled(shape, BulgeUtils.SHAPE_TRANSPORT)
	if(towardsTip.dot(across) < 0.0):
		samples.invert()
	return [Plane(samples[0], samples[1], samples[2], axisDepth),
		Plane(samples[3], samples[4], samples[5], samples[6])]
static func resampled(shape:Array, count:int) -> Array:
	var last:int = shape.size() - 1
	var out:Array = []
	for i in range(count):
		var at:float = float(i) / float(count - 1) * float(last)
		var low:int = int(floor(at))
		var high:int = int(min(low + 1, last))
		out.append(lerp(float(shape[low]), float(shape[high]), at - low))
	return out

static func restToWorld(rig:Dictionary, restPoint:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().xform(restPoint)
static func restDirToWorld(rig:Dictionary, restDir:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().basis.xform(restDir).normalized()
