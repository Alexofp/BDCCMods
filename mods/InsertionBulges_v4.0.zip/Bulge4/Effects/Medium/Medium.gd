extends Reference
const Entries := preload("res://Bulge4/Effects/Classic/Entries.gd")
const Measures := preload("res://Bulge4/Effects/Classic/Measures.gd")
const Report := preload("res://Bulge4/Effects/Classic/Report.gd")
const Tuning := preload("res://Bulge4/Effects/Classic/Tuning.gd")
const Intent := preload("res://Bulge4/Effects/Classic/Intent.gd")
const FieldMath := preload("res://Bulge4/Effects/Classic/Field.gd")
const Simple := preload("res://Bulge4/Effects/Simple/Simple.gd")
const Spring := preload("res://Bulge4/Effects/Medium/Spring.gd")
const Belly := preload("res://Bulge4/Effects/Medium/Belly.gd")
const Bake := preload("res://Bulge4/Effects/Medium/Bake.gd")
const BakePool := preload("res://Bulge4/Effects/Medium/BakePool.gd")
const Subdivide := preload("res://Bulge4/Effects/Medium/Subdivide.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const Fits := preload("res://Bulge4/Infer/Fits.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const META_POOL := "bdccBulge4BakePool"
const META_SPRING := "bdccBulge4Spring"
const META_CLIPPED := "bdccBulge4MediumClipped"
const META_BAKED := "bdccBulge4Baked"

static func run(stageScene, relations:Array, _opts:Dictionary = {}) -> Array:
	var t0:int = OS.get_ticks_usec()
	if(Entries.use("medium")):
		tune()
	var dolls:Array = stageScene.getDolls()
	for doll in dolls:
		var helper = Simple.helperOf(doll)
		if(helper != null):
			for torso in helper.getBulgeMeshesForZone(""):
				if(torso.has_meta(META_BAKED)):
					torso.fancyMaterial.set_shader_param("bulge_baked_on", 0.0)
					torso.remove_meta(META_BAKED)
	var context:Dictionary = Measures.contextFor(stageScene, relations)
	var entries:Array = []
	if(!relations.empty()):
		entries = Entries.of(stageScene, relations)
	var now:float = float(stageScene.get_meta(Frame.META_NOW))
	if(bool(Tuning.value("bulgeLag"))):
		var springWas = null
		if(stageScene.has_meta(META_SPRING)):
			springWas = stageScene.get_meta(META_SPRING)
		stageScene.set_meta(META_SPRING, Spring.settle(springWas, entries, now))
	var variant:String = str(Tuning.value("bulgeBellyVariant"))
	if(variant != Belly.VARIANT_OFF || Belly.torsoOn() || Belly.bulkOn()):
		Belly.apply(entries, context["eyes"], variant)
	else:
		Belly.release(context["eyes"])
	var built:Dictionary = Report.build(entries)
	var byKey:Dictionary = {}
	for entry in entries:
		var engagement:Dictionary = entry["engagement"]
		byKey[Report.rowKey(engagement["shaft"], engagement["hole_owner"], engagement["hole"])] = entry
	var perMesh:Dictionary = {}
	for bulge in built["bulges"]:
		var entry = byKey.get(Report.rowKey(bulge["shaft"], bulge["participant"], bulge["hole"]))
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		var holeOwner = engagement["hole_owner"]
		var intent = entry.get("intent")
		var rig = context["rig"].get(holeOwner)
		var holeHelper = Simple.helperOf(Simple.dollAt(dolls, holeOwner))
		if(holeHelper == null || typeof(rig) != TYPE_DICTIONARY || typeof(intent) != TYPE_DICTIONARY):
			continue
		var centreWorld:Vector3 = Simple.restToWorld(rig, intent["centre_rest"])
		var frontWorld:Vector3 = Simple.restDirToWorld(rig, intent["front_dir_rest"])
		var travelWorld:Vector3 = Simple.restDirToWorld(rig, intent["travel_dir_rest"])
		var points = restBulgePoints(holeHelper, str(bulge["hole"]), centreWorld,
			centreWorld + frontWorld * float(intent["reach"]), centreWorld + travelWorld)
		if(typeof(points) != TYPE_DICTIONARY):
			continue
		var lipPoints = null
		if(float(intent.get("lip", 0.0)) > 0.0):
			var lipWorld:Vector3 = Simple.restToWorld(rig, intent["lip_rest"])
			lipPoints = restBulgePoints(holeHelper, str(bulge["hole"]), lipWorld,
				lipWorld + Simple.restDirToWorld(rig, intent["lip_dir_rest"]), null)
		for themesh in holeHelper.getBulgeMeshesForZone(str(bulge["hole"])):
			var fit = BulgeUtils.fitOf(themesh)
			if(typeof(fit) != TYPE_DICTIONARY):
				continue
			var meshKey:String = str(holeOwner) + "#" + str(themesh.get_instance_id())
			if(!perMesh.has(meshKey)):
				perMesh[meshKey] = {"mesh": themesh, "fit": fit, "slots": [], "doll": holeOwner, "holes": [], "shafts": []}
			perMesh[meshKey]["slots"].append(slotFor(intent, points, fit, lipPoints))
			perMesh[meshKey]["holes"].append(str(bulge["hole"]))
			perMesh[meshKey]["shafts"].append(engagement["shaft"])
	var rows:Array = []
	if(!perMesh.empty()):
		var pool = poolOn(stageScene)
		for meshKey in perMesh:
			var row:Dictionary = perMesh[meshKey]
			var texture = pool.textureFor(meshKey, row["slots"], row["fit"]["aspect"])
			if(texture == null || !setBakedBulge(row["mesh"], texture)):
				continue
			rows.append({"doll": row["doll"], "hole": row["holes"][0], "shaft": row["shafts"][0], "holes": row["holes"],
				"shafts": row["shafts"], "bumps": row["slots"].size(), "verts": row["mesh"].mesh.surface_get_array_len(0)})
	var clipped:Array = []
	for clip in built["clips"]:
		var entry = byKey.get(Report.rowKey(clip["participant"], clip["hole_owner"], clip["hole"]))
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		var card = context["shafts"].get(engagement["shaft"])
		var shaftHelper = Simple.helperOf(Simple.dollAt(dolls, engagement["shaft"]))
		if(shaftHelper == null || !Fits.isShaft(card)):
			continue
		var base:Vector3 = card["base"]
		var dir:Vector3 = (card["tip"] - base) / float(card["length"])
		shaftHelper.unTaperShaftBones()
		shaftHelper.applyShaftClip(base + dir * float(clip["clip_on_axis"]))
		clipped.append(shaftHelper)
	var was:Array = []
	if(stageScene.has_meta(META_CLIPPED)):
		was = stageScene.get_meta(META_CLIPPED)
	for helper in was:
		if(is_instance_valid(helper) && !clipped.has(helper)):
			helper.clearBulgeState()
			helper.restoreShaftTaper()
	stageScene.set_meta(META_CLIPPED, clipped)
	var ms:float = float(OS.get_ticks_usec() - t0) / 1000.0
	for row in rows:
		row["ms"] = ms / float(rows.size())
	return rows

static func restoreAll(stageScene) -> void:
	if(stageScene.has_meta(META_CLIPPED)):
		for helper in stageScene.get_meta(META_CLIPPED):
			if(is_instance_valid(helper)):
				helper.clearBulgeState()
				helper.restoreShaftTaper()
		stageScene.remove_meta(META_CLIPPED)
	Belly.release(Frame.Eyes.new(stageScene))
	stageScene.remove_meta(META_SPRING)
	if(stageScene.has_meta(META_POOL)):
		var pool = stageScene.get_meta(META_POOL)
		if(pool != null && is_instance_valid(pool)):
			pool.queue_free()
		stageScene.remove_meta(META_POOL)
	for doll in stageScene.getDolls():
		var helper = Simple.helperOf(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			torso.remove_meta(META_BAKED)
			Simple.restore(torso)

static func tune() -> void:
	var _ok = Spring.setRates(Spring.hzFor(float(Tuning.value("bulgeLagInflate"))),
		Spring.hzFor(float(Tuning.value("bulgeLagDeflate"))))
	var _damped = Spring.setZeta(1.0 - 0.5 * clamp(float(Tuning.value("bulgeLagWobble")), 0.0, 1.0))
	var _oral = Spring.setOralTuning(Spring.hzFor(float(Tuning.value("bulgeLagInflate"))),
		Spring.hzFor(float(Tuning.value("bulgeLagDeflate"))),
		1.0 - 0.5 * clamp(float(Tuning.value("bulgeLagWobble")), 0.0, 1.0))
	var tuning:Dictionary = Belly.TUNING
	tuning["gain"] = 2.0 * clamp(float(Tuning.value("bulgeBellyGain")), 0.0, 1.0)
	var torso:Dictionary = Belly.TORSO
	torso["on"] = bool(Tuning.value("bulgeTorsoSwell"))
	var arch:Dictionary = Intent.ARCH
	arch["amount"] = clamp(float(Tuning.value("bulgeTorsoArch")), 0.0, 1.0)

static func poolOn(stageScene):
	if(stageScene.has_meta(META_POOL)):
		var had = stageScene.get_meta(META_POOL)
		if(had != null && is_instance_valid(had)):
			return had
	var pool = BakePool.new()
	pool.name = "Bulge4BakePool"
	stageScene.add_child(pool)
	stageScene.set_meta(META_POOL, pool)
	return pool

static func setBakedBulge(torso, texture) -> bool:
	if(!Simple.prepare(torso)):
		return false
	var material:ShaderMaterial = torso.fancyMaterial
	material.set_shader_param("bulge_baked", texture)
	var on:float = 0.0
	var fit = torso.get("uvFit")
	if(FieldMath.warpMode() == FieldMath.WARP_MESH && typeof(fit) == TYPE_DICTIONARY):
		var rowU:Vector3 = fit["u"]
		var rowV:Vector3 = fit["v"]
		var det:float = rowU.x * rowV.y - rowU.y * rowV.x
		if(abs(det) > 0.0000001):
			on = 1.0
			material.set_shader_param("bulge_rest_du", Vector2(rowV.y, -rowV.x) / det)
			material.set_shader_param("bulge_rest_dv", Vector2(-rowU.y, rowU.x) / det)
	material.set_shader_param("bulge_mesh_on", on)
	var wanted = Subdivide.unsubdivided(torso.mesh)
	if(on > 0.5):
		wanted = Subdivide.getSubdividedMesh(torso.mesh)
	if(wanted != torso.mesh):
		torso.mesh = wanted
		torso.set_surface_material(0, material)
	material.set_shader_param("bulge_baked_on", 1.0)
	torso.set_meta(META_BAKED, true)
	return true

static func restBulgePoints(helper, zone:String, entryWorld:Vector3, tipWorld:Vector3, bandEndWorld):
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return null
	var boneName:String = BulgeDoll.BULGE_BONE.get(zone, "Hips")
	var restEntry:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, entryWorld)
	var restTip:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, tipWorld)
	var restBandEnd:Vector3 = restTip
	if(bandEndWorld != null):
		restBandEnd = BulgeUtils.worldToRest(skeleton, boneName, bandEndWorld)
	return {
		"a": Vector2(restEntry.x, restEntry.y),
		"b": Vector2(restTip.x, restTip.y),
		"band": Vector2(restBandEnd.x, restBandEnd.y),
	}

static func slotFor(intent:Dictionary, points:Dictionary, fit:Dictionary, lipPoints = null) -> Dictionary:
	var uvA:Vector2 = BulgeUtils.restToUV(fit, points["a"])
	var uvB:Vector2 = BulgeUtils.restToUV(fit, points["b"])
	var uvBand:Vector2 = BulgeUtils.restToUV(fit, points["band"])
	var lipAt:Vector2 = uvA
	var lipToward:Vector2 = uvA
	var lip:float = 0.0
	if(typeof(lipPoints) == TYPE_DICTIONARY):
		lipAt = BulgeUtils.restToUV(fit, lipPoints["a"])
		lipToward = BulgeUtils.restToUV(fit, lipPoints["b"])
		lip = float(intent.get("lip", 0.0))
	return {
		"lip_at": lipAt,
		"lip_toward": lipToward,
		"lip": lip,
		"lip_reach": float(intent.get("lip_reach", 0.0)),
		"lip_motion": float(intent.get("lip_motion", 0.0)),
		"lip_stroke": float(intent.get("lip_stroke", 0.0)),
		"radial_on": radialOnFor(intent),
		"plateau": float(intent.get("plateau", FieldMath.plateauFor(str(intent.get("zone", ""))))),
		"centre": uvA,
		"front": uvB,
		"spread": float(intent["spread"]),
		"amplitude": amplitudeFor(float(intent["amplitude"]), uvA, uvB, fit["aspect"]),
		"shade": float(intent["shade"]),
		"column_half": float(intent["column_half"]),
		"shape": Bake.orientedShape(intent["shape"], uvA, uvB, uvBand, fit["aspect"]),
		"axis_depth": float(intent["axis_depth"]),
	}
static func radialOnFor(intent:Dictionary) -> float:
	if(str(intent.get("zone", "")) == "mouth"):
		return 0.0
	return 1.0
static func amplitudeFor(amplitude:float, uvA:Vector2, uvB:Vector2, aspect:Vector2) -> float:
	if(!FieldMath.capped()):
		return amplitude
	return Simple.unfoldedAmplitude(amplitude, uvA, uvB, aspect)
