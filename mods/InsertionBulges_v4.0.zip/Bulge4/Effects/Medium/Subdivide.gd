extends Reference
const SUBDIVIDE_LEVELS := 2
const META_SUBDIVIDED = "bdccBulge4SubdividedMesh"
const META_SUBDIVIDED_FROM = "bdccBulge4SubdividedFrom"

static func getSubdividedMesh(mesh:Mesh):
	if(mesh == null || mesh.has_meta(META_SUBDIVIDED_FROM)):
		return mesh
	if(mesh.has_meta(META_SUBDIVIDED)):
		return mesh.get_meta(META_SUBDIVIDED)
	if(mesh.get_surface_count() != 1 || (mesh is ArrayMesh && mesh.get_blend_shape_count() > 0)):
		return mesh
	var arrays:Array = mesh.surface_get_arrays(0)
	if(arrays[Mesh.ARRAY_INDEX] == null || arrays[Mesh.ARRAY_TEX_UV] == null):
		return mesh
	for _level in range(SUBDIVIDE_LEVELS):
		arrays = subdivided(arrays)
	var built:ArrayMesh = ArrayMesh.new()
	built.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	built.custom_aabb = mesh.get_aabb()
	built.set_meta(META_SUBDIVIDED_FROM, mesh)
	mesh.set_meta(META_SUBDIVIDED, built)
	return built

static func subdivided(arrays:Array) -> Array:
	var verts:PoolVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var uvs:PoolVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var indices:PoolIntArray = arrays[Mesh.ARRAY_INDEX]
	var normals = arrays[Mesh.ARRAY_NORMAL]
	var tangents = arrays[Mesh.ARRAY_TANGENT]
	var bones = arrays[Mesh.ARRAY_BONES]
	var weights = arrays[Mesh.ARRAY_WEIGHTS]
	var colors = arrays[Mesh.ARRAY_COLOR]
	var hasColors:bool = colors != null && colors.size() == verts.size()
	var hasNormals:bool = normals != null && normals.size() == verts.size()
	var hasTangents:bool = tangents != null && tangents.size() == verts.size() * 4
	var hasBones:bool = bones != null && weights != null && bones.size() == verts.size() * 4 \
		&& weights.size() == verts.size() * 4
	var outVerts:PoolVector3Array = PoolVector3Array(verts)
	var outUVs:PoolVector2Array = PoolVector2Array(uvs)
	var outNormals = null
	var outColors = null
	if(hasColors):
		outColors = PoolColorArray(colors)
	var outTangents = null
	var outBones = null
	var outWeights = null
	if(hasNormals):
		outNormals = PoolVector3Array(normals)
	if(hasTangents):
		outTangents = PoolRealArray(tangents)
	if(hasBones):
		outBones = PoolIntArray(bones)
		outWeights = PoolRealArray(weights)
	var outIndices:PoolIntArray = PoolIntArray()
	var middles:Dictionary = {}
	for i in range(0, indices.size(), 3):
		var corner:Array = [indices[i], indices[i + 1], indices[i + 2]]
		var mid:Array = []
		for k in range(3):
			var a:int = corner[k]
			var b:int = corner[(k + 1) % 3]
			var key:int = int(min(a, b)) * 1000003 + int(max(a, b))
			if(!middles.has(key)):
				middles[key] = outVerts.size()
				outVerts.push_back((verts[a] + verts[b]) * 0.5)
				outUVs.push_back((uvs[a] + uvs[b]) * 0.5)
				if(hasNormals):
					outNormals.push_back((normals[a] + normals[b]).normalized())
				if(hasColors):
					outColors.push_back(colors[a].linear_interpolate(colors[b], 0.5))
				if(hasTangents):
					for c in range(4):
						outTangents.push_back(tangents[a * 4 + c])
				if(hasBones):
					var mixed:Dictionary = {}
					for end in [a, b]:
						for c in range(4):
							var bone:int = bones[end * 4 + c]
							mixed[bone] = float(mixed.get(bone, 0.0)) + weights[end * 4 + c] * 0.5
					var ranked:Array = []
					for bone in mixed:
						ranked.append([mixed[bone], bone])
					ranked.sort()
					ranked.invert()
					var total:float = 0.0
					for c in range(int(min(4, ranked.size()))):
						total += float(ranked[c][0])
					for c in range(4):
						if(c < ranked.size() && total > 0.0):
							outBones.push_back(int(ranked[c][1]))
							outWeights.push_back(float(ranked[c][0]) / total)
						else:
							outBones.push_back(0)
							outWeights.push_back(0.0)
			mid.append(middles[key])
		for tri in [[corner[0], mid[0], mid[2]], [mid[0], corner[1], mid[1]],
				[mid[2], mid[1], corner[2]], [mid[0], mid[1], mid[2]]]:
			for index in tri:
				outIndices.push_back(index)
	var out:Array = []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = outVerts
	out[Mesh.ARRAY_TEX_UV] = outUVs
	out[Mesh.ARRAY_INDEX] = outIndices
	if(hasNormals):
		out[Mesh.ARRAY_NORMAL] = outNormals
	if(hasColors):
		out[Mesh.ARRAY_COLOR] = outColors
	if(hasTangents):
		out[Mesh.ARRAY_TANGENT] = outTangents
	if(hasBones):
		out[Mesh.ARRAY_BONES] = outBones
		out[Mesh.ARRAY_WEIGHTS] = outWeights
	return out

static func unsubdivided(mesh:Mesh):
	if(mesh != null && mesh.has_meta(META_SUBDIVIDED_FROM)):
		return mesh.get_meta(META_SUBDIVIDED_FROM)
	return mesh
