extends Reference
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const FieldMath := preload("res://Bulge4/Effects/Classic/Field.gd")
const Measures := preload("res://Bulge4/Effects/Classic/Measures.gd")
const VALUES := {
	"bulgeSizeModifier": 0.6, "bulgeOralSize": 0.6, "bulgeOralSimpleSize": 0.8,
	"bulgeShapeFidelity": 0.8, "bulgeOtherHalfAdd": 0.5, "bulgeOtherHalfFollow": 0.2,
	"bulgeDirection": "blend", "bulgeEndFade": 1.0, "bulgeInsertedGirth": 0.0, "bulgeReachDeeper": 0.0,
	"bulgeShade": 0.0, "bulgeLipAmount": 0.2, "bulgeLipAnchor": "hole", "bulgeLipMotion": "out",
	"bulgeStartAtMouth": false, "bulgeThroatPath": "neck", "bulgeOralMouthLength": 0.4,
	"bulgeOralSwallow": false, "bulgeOralThroatStretch": true,
	"bulgeRimShape": 1.0, "bulgeUnionOverlap": 1.0, "bulgePushRadial": 0.0, "bulgeWarp": "mesh", "bulgeTipRound": 0.0,
	"bulgeLag": true, "bulgeLagInflate": 0.8, "bulgeLagDeflate": 0.25, "bulgeLagWobble": 0.6,
	"bulgeBellyVariant": "swell", "bulgeBellyGain": 0.6, "bulgeTorsoSwell": true, "bulgeTorsoArch": 0.5,
}
const PER_EFFECT := {
	"simple": {"bulgeThroatPath": "neck", "samples": 7},
	"medium": {"bulgeThroatPath": "body", "samples": 33},
}
const ROWS := ["bulgeSizeModifier", "bulgeShapeFidelity", "bulgeLag"]
const MEDIUM_ROWS := ["bulgeOtherHalfAdd", "bulgeLipAmount", "bulgeDirection", "bulgeLagDeflate", "bulgeTorsoArch",
	"bulgeOralSize", "bulgeOralSwallow"]
const LIVE := {"seen": -1, "effect": ""}
static func refresh(effect:String) -> bool:
	var live:Dictionary = LIVE
	if(int(live["seen"]) == int(Settings.CHANGED["n"]) && str(live["effect"]) == effect):
		return false
	live["seen"] = int(Settings.CHANGED["n"])
	live["effect"] = effect
	for name in ROWS:
		live[name] = Settings.value(name)
	for name in MEDIUM_ROWS:
		live[name] = VALUES[name]
		if(effect == "medium"):
			live[name] = Settings.value(name)
	live["bulgeBellyVariant"] = "off"
	if(bool(Settings.value("bulgePregnantBelly"))):
		live["bulgeBellyVariant"] = "swell"
	var own:Dictionary = PER_EFFECT[effect]
	live["bulgeThroatPath"] = own["bulgeThroatPath"]
	var shape:Dictionary = Measures.SHAPE
	shape["samples"] = int(own["samples"])
	FieldMath.setUnionOverlap(float(value("bulgeUnionOverlap")))
	var _tuned = FieldMath.setTuning(1.0, clamp(float(value("bulgeRimShape")), 0.0, 1.0))
	FieldMath.setRadial(float(value("bulgePushRadial")))
	FieldMath.setWarpMode(str(value("bulgeWarp")))
	FieldMath.setTipRound(float(value("bulgeTipRound")))
	FieldMath.setOralTipRound(float(value("bulgeTipRound")))
	return true
static func value(name:String):
	if(LIVE.has(name)):
		return LIVE[name]
	return VALUES[name]
static func forZone(name:String, zone:String):
	if(zone == "mouth" && name == "bulgeSizeModifier"):
		return value("bulgeOralSize")
	return value(name)
