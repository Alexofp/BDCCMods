extends Reference
const Intent := preload("res://Bulge4/Effects/Classic/Intent.gd")
const Measures := preload("res://Bulge4/Effects/Classic/Measures.gd")
const FieldMath := preload("res://Bulge4/Effects/Classic/Field.gd")
const Tuning := preload("res://Bulge4/Effects/Classic/Tuning.gd")
const META_CROTCH := "bdccBulge4Crotch"

static func use(effect:String) -> bool:
	if(!Tuning.refresh(effect)):
		return false
	var lip:Dictionary = Intent.LIP
	lip["read_at"] = -1000000
	var direction:Dictionary = Intent.DIRECTION
	direction["read_at"] = -1000000
	return true

static func of(stageScene, relations:Array) -> Array:
	var context:Dictionary = Measures.contextFor(stageScene, relations)
	var engagements:Array = []
	for r in relations:
		engagements.append(Measures.engagementOf(r))
	var crotchWas:Dictionary = {}
	if(stageScene.has_meta(META_CROTCH)):
		crotchWas = stageScene.get_meta(META_CROTCH)
	var entries:Array = entriesFor(context, engagements, context["rig"], crotchWas)
	var crotchNow:Dictionary = {}
	for one in entries:
		if(typeof(one["measures"]) == TYPE_DICTIONARY && one["measures"].has("crotch_hole")):
			crotchNow[keyOf(one["engagement"])] = one["measures"]["crotch_hole"]
	stageScene.set_meta(META_CROTCH, crotchNow)
	return entries

static func keyOf(one:Dictionary) -> String:
	return str(one["shaft"]) + " -> " + str(one["hole_owner"]) + "/" + str(one["hole"])

static func entriesFor(snapshot:Dictionary, engagements:Array, rigs:Dictionary,
		crotchWas:Dictionary = {}) -> Array:
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	var crotchCount:Dictionary = {}
	for one in engagements:
		if(str(one["hole"]) == Intent.HOLE_VAGINA):
			crotchCount[str(one["hole_owner"])] = int(crotchCount.get(str(one["hole_owner"]), 0)) + 1
	var entries:Array = []
	for engagement in engagements:
		var measures = Intent.measuresFor(snapshot, engagement,
			str(crotchWas.get(keyOf(engagement), "")))
		if(typeof(measures) == TYPE_DICTIONARY && int(crotchCount.get(str(engagement["hole_owner"]), 0)) > 1 \
				&& measures.has("crotch_hole")):
			measures["anchor_hole"] = measures["crotch_hole"]
		var intent = null
		if(typeof(measures) == TYPE_DICTIONARY):
			intent = Intent.buildFor(rigs.get(engagement["hole_owner"]), measures,
				shafts.get(engagement["shaft"]), str(engagement["hole"]))
		if(typeof(intent) == TYPE_DICTIONARY && measures.has("anchor_hole")):
			var reachKeep:float = float(intent["reach"])
			intent = Intent.withAmplitude(intent, float(intent["amplitude"]) / (1.0 + FieldMath.unionOverlap()))
			intent["reach_keep"] = reachKeep
			intent["reach"] = max(float(intent["reach"]), reachKeep)
		entries.append({"engagement": engagement, "measures": measures, "intent": intent})
	return entries
