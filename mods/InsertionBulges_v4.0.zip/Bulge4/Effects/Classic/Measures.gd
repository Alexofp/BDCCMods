extends Reference
const Fits := preload("res://Bulge4/Infer/Fits.gd")
const PortalScenes := preload("res://Bulge4/Infer/PortalScenes.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const HOLE_MOUTH := "mouth"
const SLOT_HEAD := "head"
const DEFAULT_OVERSIZE := 0.9
const FALLBACK_GIRTH:float = 0.0
const PROFILE_MAX:float = 1.6
const STROKE_REFERENCE_LENGTH := 1.678
const PORTAL_AXIS_REST := Vector3(0.0, 1.0, 0.0)
const SHAPE := {"samples": BulgeUtils.SHAPE_TRANSPORT}

static func contextFor(stageScene, relations:Array) -> Dictionary:
	var context:Dictionary = Frame.of(stageScene, relations)
	if(context.has("rig")):
		return context
	var eyes = context["eyes"]
	var rigs:Dictionary = {}
	var oversize:Dictionary = {}
	for r in relations:
		var owner = r["hole_owner"]
		if(!rigs.has(owner)):
			rigs[owner] = rigOf(eyes, owner)
		for holeID in Frame.HOLES:
			var key:String = oversizeKey(r["shaft"], owner, holeID)
			if(!oversize.has(key)):
				oversize[key] = oversizeOf(eyes, r["shaft"], owner, holeID)
	context["rig"] = rigs
	context["oversize"] = oversize
	return context

static func engagementOf(relation:Dictionary) -> Dictionary:
	return {
		"shaft": relation["shaft"],
		"hole_owner": relation["hole_owner"],
		"hole": str(relation["hole"]),
		"provenance": {"source": str(relation["source"]), "confidence": int(relation["confidence"]), "refused": []},
		"state": "stated",
	}


static func measuresOf(candidate:Dictionary, card, oversize:Dictionary) -> Dictionary:
	var shape:Array = shapeOf(candidate, card)
	var measures:Dictionary = {
		"entry": candidate["entry"],
		"depth": candidate["depth"],
		"axis": candidate["axis"],
		"girth_at_entry": shape[0],
		"shape": shape,
		"oversize": float(oversize.get(
			oversizeKey(candidate["shaft"], candidate["hole_owner"], candidate["hole"]),
			DEFAULT_OVERSIZE)),
	}
	if(typeof(card) == TYPE_DICTIONARY && typeof(card.get("edge_up")) == TYPE_ARRAY \
			&& !card["edge_up"].empty()):
		measures["shape_up"] = shapeOf(candidate, card, "edge_up")
		measures["shape_down"] = shapeOf(candidate, card, "edge_down")
	return measures
static func shapeOf(candidate:Dictionary, card, key:String = "profile") -> Array:
	var along:float = float(candidate["along"])
	var depth:float = float(candidate["depth"])
	var out:Array = []
	var count:int = int(SHAPE["samples"])
	for i in count:
		out.append(girthFrom(card, along + depth * float(i) / float(count - 1), key))
	return out
static func girthFrom(card, along, key:String = "profile") -> float:
	if(typeof(card) != TYPE_DICTIONARY):
		return FALLBACK_GIRTH
	var length:float = float(card.get("length", 0.0))
	if(length <= 0.0):
		return FALLBACK_GIRTH
	if(!card.has("skip")):
		return FALLBACK_GIRTH
	var t:float = clamp(float(along) / length, 0.0, 1.0)
	var shape:float = profileAt(card.get(key, []), t, float(card["skip"]))
	return float(card.get("radius", 0.0)) * min(shape, PROFILE_MAX)
static func profileAt(profile:Array, t:float, skip:float) -> float:
	if(profile.empty()):
		return 1.0
	var last:int = profile.size() - 1
	var span:float = max(1.0 - skip, 0.001)
	var local:float = clamp((t - skip) / span, 0.0, 1.0) * last
	var low:int = int(floor(local))
	var high:int = int(min(low + 1, last))
	return lerp(profile[low], profile[high], local - low)
static func oversizeKey(shaftOwner, holeOwner, holeID) -> String:
	return str(shaftOwner) + " " + str(holeOwner) + " " + str(holeID)


static func portalMeasuresFor(snapshot, shaftOwner, holeOwner, holeID:String):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !PortalScenes.TABLE.has(path)):
		return null
	var row:Dictionary = PortalScenes.TABLE[path]
	if(!row.has("portal") || str(row["shaft"]) != str(shaftOwner) \
			|| str(row["hole_owner"]) != str(holeOwner)):
		return null
	var measured = transferred(snapshot, row, str(shaftOwner), str(holeOwner), holeID)
	if(measured == null):
		return null
	return measured["measures"]
static func portalOwns(snapshot, shaftOwner, holeOwner) -> bool:
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return false
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !PortalScenes.TABLE.has(path)):
		return false
	var row:Dictionary = PortalScenes.TABLE[path]
	return row.has("portal") && str(row["shaft"]) == str(shaftOwner) \
		&& str(row["hole_owner"]) == str(holeOwner)
static func transferred(snapshot:Dictionary, row:Dictionary, shaftOwner:String, holeOwner:String,
		holeID:String):
	var shafts = snapshot.get("shafts")
	var holes = snapshot.get("holes")
	var props = snapshot.get("props")
	if(typeof(shafts) != TYPE_DICTIONARY || typeof(holes) != TYPE_DICTIONARY \
			|| typeof(props) != TYPE_DICTIONARY):
		return null
	var card = shafts.get(shaftOwner)
	if(!Fits.isShaft(card)):
		return null
	var length:float = float(card["length"])
	if(length < Fits.MIN_SHAFT_LENGTH):
		return null
	var portal:Dictionary = row["portal"]
	var owned = props.get(str(portal["owner"]))
	if(typeof(owned) != TYPE_DICTIONARY):
		return null
	var base:Vector3 = card["base"]
	var tip:Vector3 = card["tip"]
	var dir:Vector3 = (tip - base) / length
	var mouth = PortalScenes.openingOf(owned.get(str(portal["zone"])), base, dir)
	if(typeof(mouth) != TYPE_VECTOR3):
		return null
	var along:float = clamp((mouth - base).dot(dir), 0.0, length)
	var depth:float = length - along
	if((mouth - (base + dir * along)).length() > Fits.LATERAL_TOLERANCE_OTHER):
		return null
	var drawnAlong:float = clamp(along * length / STROKE_REFERENCE_LENGTH, 0.0, length)
	depth = length - drawnAlong
	var hole = PortalScenes.holeFor(holes, holeOwner, holeID)
	if(hole == null):
		return null
	var oversize:Dictionary = {}
	if(typeof(snapshot.get("oversize")) == TYPE_DICTIONARY):
		oversize = snapshot["oversize"]
	var candidate:Dictionary = {
		"shaft": shaftOwner,
		"hole_owner": holeOwner,
		"hole": hole["id"],
		"along": drawnAlong,
		"depth": depth,
		"clip_along": along,
		"entry": hole["pos"],
		"axis": portalAxis(snapshot, holeOwner, hole["inward"]),
		"fit": 0.0,
	}
	return {"hole": hole["id"], "measures": portalMeasures(candidate, card, oversize, length)}
static func portalAxis(snapshot:Dictionary, holeOwner:String, inward:Vector3) -> Vector3:
	var rigs = snapshot.get("rig")
	if(typeof(rigs) != TYPE_DICTIONARY || typeof(rigs.get(holeOwner)) != TYPE_DICTIONARY \
			|| typeof(rigs[holeOwner].get("hips")) != TYPE_TRANSFORM):
		return inward
	var hips:Transform = rigs[holeOwner]["hips"]
	return hips.affine_inverse().basis.xform(PORTAL_AXIS_REST).normalized()
static func portalMeasures(candidate:Dictionary, card, oversize:Dictionary, length:float) -> Dictionary:
	var measures:Dictionary = measuresOf(candidate, card, oversize)
	var axis:Vector3 = candidate["axis"]
	var tip:Vector3 = candidate["entry"] + axis * float(candidate["depth"])
	measures["shaft_tip"] = tip
	measures["shaft_base"] = tip - axis * length
	measures["clip_skin"] = 0.0
	measures["clip_along"] = float(candidate["clip_along"])
	measures["deadzone"] = 0.0
	return measures


static func rigOf(eyes, participantID):
	var helper = eyes.helperFor(participantID)
	if(helper == null):
		return null
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return null
	return {
		"hips": hipsToRest(skeleton),
		"origin": {
			"vagina": helper.getBulgeOriginRest("vagina"),
			"anus": helper.getBulgeOriginRest("anus"),
			"mouth": helper.getBulgeOriginRest("mouth"),
		},
		"neck_axis": helper.getNeckAxisWorld(),
		"spine_chain": helper.getSpineChainWorld(),
		"contour": helper.getFrontContour("vagina"),
		"margins": marginsOf(helper),
	}
static func hipsToRest(skeleton:Skeleton):
	var boneIdx:int = skeleton.find_bone("Hips")
	if(boneIdx < 0):
		return null
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	var restGlobal:Transform = BulgeUtils.getBoneRestGlobal(skeleton, boneIdx)
	return restGlobal * posedGlobal.affine_inverse()
static func marginsOf(helper) -> Array:
	var margins:Array = []
	for themesh in helper.getBulgeMeshesForZone("vagina"):
		if(!themesh.is_visible_in_tree()):
			continue
		margins.append(BulgeUtils.getFrontMargin(themesh))
	return margins
static func oversizeOf(eyes, shaftOwner, holeOwner, holeID):
	var topChar = charFor(eyes.dollFor(shaftOwner))
	var bottomChar = charFor(eyes.dollFor(holeOwner))
	if(topChar == null || bottomChar == null):
		return DEFAULT_OVERSIZE
	var slot:String = str(holeID)
	if(slot == HOLE_MOUTH):
		slot = SLOT_HEAD
	if(!bottomChar.hasBodypart(slot)):
		return DEFAULT_OVERSIZE
	var freeRoom:float = bottomChar.getPenetrationFreeRoom(slot, topChar.getPenisSize())
	return clamp(0.35 + max(-freeRoom, 0.0) / 18.0, 0.3, 1.7)
static func charFor(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll) || !theDoll.has_method("getCharacterID")):
		return null
	var charID = theDoll.getCharacterID()
	if(charID is String):
		if(charID == ""):
			return null
		return GlobalRegistry.getCharacter(charID)
	if(typeof(charID) != TYPE_OBJECT || !is_instance_valid(charID)):
		return null
	if(!charID.has_method("getPenisSize") || !charID.has_method("getPenetrationFreeRoom")):
		return null
	return charID
