extends Reference
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const META_EXPANDED = "bdccBulge4ExpandedMesh"
const PAD := 1.2

static func getExpandedMesh(mesh:Mesh, pad:float):
	if(mesh == null || pad <= 0.0):
		return mesh
	if(mesh.has_meta(META_EXPANDED)):
		var cached = mesh.get_meta(META_EXPANDED)
		if(cached is Mesh):
			return cached
		return mesh
	var built = buildExpandedMesh(mesh, pad)
	if(built == null):
		mesh.set_meta(META_EXPANDED, false)
		return mesh
	mesh.set_meta(META_EXPANDED, built)
	return built

static func buildExpandedMesh(mesh:Mesh, pad:float):
	if(mesh.get_surface_count() <= 0):
		return null
	if(mesh is ArrayMesh && mesh.get_blend_shape_count() > 0):
		return null
	var fit = BulgeUtils.getUVFit(mesh)
	if(fit == null):
		return null
	var arrays:Array = mesh.surface_get_arrays(0)
	var verts:PoolVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var uvs:PoolVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var indices:PoolIntArray = arrays[Mesh.ARRAY_INDEX]
	if(verts.size() == 0 || uvs.size() != verts.size() || indices.size() < 3):
		return null
	var edgeUse:Dictionary = {}
	var thirdOf:Dictionary = {}
	for i in range(0, indices.size(), 3):
		for corner in range(3):
			var a:int = indices[i + corner]
			var b:int = indices[i + (corner + 1) % 3]
			var key:String = str(min(a, b)) + "_" + str(max(a, b))
			edgeUse[key] = edgeUse.get(key, 0) + 1
			thirdOf[key] = indices[i + (corner + 2) % 3]
	var centre:Vector2 = Vector2.ZERO
	for vert in verts:
		centre += Vector2(vert.x, vert.y)
	centre /= float(verts.size())
	var newVerts:PoolVector3Array = PoolVector3Array(verts)
	var newUVs:PoolVector2Array = PoolVector2Array(uvs)
	var newIndices:PoolIntArray = PoolIntArray(indices)
	var newNormals = arrays[Mesh.ARRAY_NORMAL]
	var newTangents = arrays[Mesh.ARRAY_TANGENT]
	var newBones = arrays[Mesh.ARRAY_BONES]
	var newWeights = arrays[Mesh.ARRAY_WEIGHTS]
	var newColors:PoolColorArray = PoolColorArray()
	for _i in range(verts.size()):
		newColors.push_back(Color(1, 1, 1, 1))
	var boundary:Array = []
	var normalOf:Dictionary = {}
	for key in edgeUse:
		if(edgeUse[key] != 1):
			continue
		var ends:Array = key.split("_")
		var a:int = int(ends[0])
		var b:int = int(ends[1])
		var pa:Vector2 = Vector2(verts[a].x, verts[a].y)
		var along:Vector2 = Vector2(verts[b].x, verts[b].y) - pa
		if(along.length() < 0.000001):
			continue
		var n:Vector2 = Vector2(-along.y, along.x).normalized()
		var third:Vector3 = verts[int(thirdOf[key])]
		if(n.dot(Vector2(third.x, third.y) - pa) > 0.0):
			n = -n
		normalOf[a] = normalOf.get(a, Vector2.ZERO) + n
		normalOf[b] = normalOf.get(b, Vector2.ZERO) + n
		boundary.append([a, b])
	var dirOf:Dictionary = {}
	var reachOf:Dictionary = {}
	for seg in boundary:
		for index in seg:
			if(dirOf.has(index)):
				continue
			var at:Vector2 = Vector2(verts[index].x, verts[index].y)
			var outward:Vector2 = normalOf.get(index, Vector2.ZERO)
			if(outward.length() < 0.0001):
				outward = at - centre
			if(outward.length() < 0.0001):
				continue
			dirOf[index] = outward.normalized()
			reachOf[index] = skirtReach(at, dirOf[index], pad, index, boundary, verts)
	for seg in boundary:
		var a2:int = int(seg[0])
		var b2:int = int(seg[1])
		if(!dirOf.has(a2) || !dirOf.has(b2)):
			continue
		var crossing:Vector2 = raysMeet(Vector2(verts[a2].x, verts[a2].y), dirOf[a2],
			Vector2(verts[b2].x, verts[b2].y), dirOf[b2])
		if(crossing.x > 0.0 && crossing.y > 0.0):
			reachOf[a2] = min(float(reachOf[a2]), crossing.x * 0.9)
			reachOf[b2] = min(float(reachOf[b2]), crossing.y * 0.9)
	var skirtFor:Dictionary = {}
	for key in edgeUse:
		if(edgeUse[key] != 1):
			continue
		var parts:Array = key.split("_")
		for side in range(2):
			var index:int = int(parts[side])
			if(skirtFor.has(index) || !dirOf.has(index)):
				continue
			var source:Vector3 = verts[index]
			var outward:Vector2 = dirOf[index]
			var moved:Vector3 = source + Vector3(outward.x, outward.y, 0.0) * float(reachOf[index])
			skirtFor[index] = newVerts.size()
			newVerts.push_back(moved)
			newUVs.push_back(BulgeUtils.restToUV(fit, Vector2(moved.x, moved.y)))
			newColors.push_back(Color(1, 1, 1, 0))
			if(newNormals != null && newNormals.size() > index):
				newNormals.push_back(newNormals[index])
			if(newTangents != null && newTangents.size() >= (index + 1) * 4):
				for component in range(4):
					newTangents.push_back(newTangents[index * 4 + component])
			if(newBones != null && newBones.size() >= (index + 1) * 4):
				for slot in range(4):
					newBones.push_back(newBones[index * 4 + slot])
					newWeights.push_back(newWeights[index * 4 + slot])
	if(skirtFor.empty()):
		return null
	for key in edgeUse:
		if(edgeUse[key] != 1):
			continue
		var parts2:Array = key.split("_")
		var a2:int = int(parts2[0])
		var b2:int = int(parts2[1])
		if(!skirtFor.has(a2) || !skirtFor.has(b2)):
			continue
		var a3:int = skirtFor[a2]
		var b3:int = skirtFor[b2]
		newIndices.append_array(PoolIntArray([a2, b2, b3, a2, b3, a3]))
	var out:Array = []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = newVerts
	out[Mesh.ARRAY_TEX_UV] = newUVs
	out[Mesh.ARRAY_INDEX] = newIndices
	out[Mesh.ARRAY_COLOR] = newColors
	if(newNormals != null):
		out[Mesh.ARRAY_NORMAL] = newNormals
	if(newTangents != null):
		out[Mesh.ARRAY_TANGENT] = newTangents
	if(newBones != null):
		out[Mesh.ARRAY_BONES] = newBones
		out[Mesh.ARRAY_WEIGHTS] = newWeights
	var expanded:ArrayMesh = ArrayMesh.new()
	expanded.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, out)
	expanded.custom_aabb = mesh.get_aabb()
	return expanded

static func skirtReach(from:Vector2, dir:Vector2, pad:float, own:int, boundary:Array, verts) -> float:
	var reach:float = pad
	for seg in boundary:
		if(int(seg[0]) == own || int(seg[1]) == own):
			continue
		var q0:Vector2 = Vector2(verts[seg[0]].x, verts[seg[0]].y)
		var s:Vector2 = Vector2(verts[seg[1]].x, verts[seg[1]].y) - q0
		var denom:float = dir.x * s.y - dir.y * s.x
		if(abs(denom) < 0.000000001):
			continue
		var w:Vector2 = q0 - from
		var hit:float = (w.x * s.y - w.y * s.x) / denom
		var on:float = (w.x * dir.y - w.y * dir.x) / denom
		if(hit > 0.0001 && on >= 0.0 && on <= 1.0):
			reach = min(reach, hit * 0.5)
	return reach

static func raysMeet(p:Vector2, dp:Vector2, q:Vector2, dq:Vector2) -> Vector2:
	var denom:float = dp.x * dq.y - dp.y * dq.x
	if(abs(denom) < 0.000000001):
		return Vector2(-1, -1)
	var w:Vector2 = q - p
	return Vector2((w.x * dq.y - w.y * dq.x) / denom, (w.x * dp.y - w.y * dp.x) / denom)
