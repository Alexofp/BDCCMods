extends MeshInstance
class_name MeshInstanceWithPattern

export var pattern_start:Vector2
export var pattern_size:Vector2 = Vector2(1.0, 1.0)
export(String, "head", "hair", "ears", "horns", "body", "arms", "breasts", "penis", "vagina", "anus", "tail", "legs", "CUSTOM") var bodypartSlot:String
export var bodypartSlotCustom:String = ""
export(Texture) var customOverlay = null
export(Texture) var customSkinPattern = null
export(Texture) var customAlbedo = null
export(bool) var showCumLayer = true
export(Vector2) var cumLayerScale = Vector2(1.0, 1.0)
export(String) var custonSkinVariant = ""
var partRef
var fancyMaterial
var defaultOverlay = preload("res://Player/Player3D/Skins/defaultoverlay.png")

var materialWithSkin = preload("res://Player/Player3D/Skins/MaterialForPartWithSkin.tres")

export(bool) var supportsWritings = false
var writingsHandler
var writingZoneInfos:Dictionary = {}
var albedoTextureSize:Vector2

const Driver = preload("res://Bulge4/Driver.gd")
const BulgeUtils = preload("res://Bulge4/Doll/BulgeUtils.gd")
const Clip = preload("res://Bulge4/Shader/Clip.gd")
var uvFit = null
const BULGE_DISABLED_CLIP = 2.0
var hasShaftClip:bool = false
var clipShaderIn:bool = false
func getPart():
	if(partRef == null):
		return null
	return partRef.get_ref()

func getDoll():
	var thePart = getPart()
	if(thePart == null):
		return null
	return thePart.getDoll()

func _ready():
	if(!OPTIONS.shouldUseAdvancedShaders()):
		set_process(false)
		return
	
	var albedoTexture:Texture
	if(customAlbedo != null):
		albedoTexture = customAlbedo
	else:
		var current_material = get_surface_material(0)
		albedoTexture = current_material.albedo_texture
	if(albedoTexture):
		albedoTextureSize = albedoTexture.get_size()
	
	
	fancyMaterial = materialWithSkin.duplicate()
	if(customSkinPattern == null):
		fancyMaterial.set_shader_param("pattern_start", pattern_start / 2048.0 * 256.0)
		fancyMaterial.set_shader_param("pattern_size", pattern_size / 2048.0 * 256.0)
		fancyMaterial.set_shader_param("cum_scale", Vector2(5.0, 5.0) * cumLayerScale)
	else:
		fancyMaterial.set_shader_param("pattern_start", pattern_start)
		fancyMaterial.set_shader_param("pattern_size", pattern_size)
		fancyMaterial.set_shader_param("cum_scale", Vector2(0.5, 0.5) * cumLayerScale)
	fancyMaterial.set_shader_param("texture_albedo", albedoTexture)
	if(customOverlay != null):
		fancyMaterial.set_shader_param("texture_customOverlay", customOverlay)
	fancyMaterial.set_shader_param("random_shift", RNG.randf_range(0.0, 1000.0))
	set_surface_material(0, fancyMaterial)
	uvFit = BulgeUtils.getUVFit(mesh)
	set_process(getFinalBodypartSlot() == "body")
	
	if(supportsWritings && OPTIONS.isVisibleBodywritingsEnabled()):
		for child in get_children():
			if(child is WritingZoneInfoNode):
				writingZoneInfos[child.zone] = child
		
		writingsHandler = preload("res://Player/Player3D/WritingsHandler/WritingsHandler.tscn").instance()
		add_child(writingsHandler)
		writingsHandler.setData(self)

func _process(_delta):
	var theDoll = getDoll()
	if(theDoll == null || !is_instance_valid(theDoll)):
		return
	var stageScene = theDoll.get_parent()
	if(stageScene == null || !stageScene.has_method("getDolls")):
		return
	Driver.tick(stageScene, Engine.get_idle_frames(), OS.get_ticks_msec() / 1000.0)
func updateMaterial():
	if(!OPTIONS.shouldUseAdvancedShaders()):
		return
	if(writingsHandler):
		writingsHandler.triggerUpdate()
	
	var theDoll = getDoll()
	if(theDoll != null):
		if(showCumLayer && theDoll.getCumAmount() > 0):
			fancyMaterial.set_shader_param("cum_transparency", 1.0)
			fancyMaterial.set_shader_param("cum_amount", theDoll.getCumAmount())
			fancyMaterial.set_shader_param("cum_color", theDoll.getCumColor())
		else:
			fancyMaterial.set_shader_param("cum_transparency", 0.0)
			fancyMaterial.set_shader_param("cum_amount", 0)
		
		var skinData = theDoll.getSkinDataByID(getFinalBodypartSlot())
		if(skinData != null):
			if(skinData.has("partskin") && skinData.has("partid")):
				var theSkin = GlobalRegistry.getPartSkin(skinData["partid"], skinData["partskin"])
				if(theSkin != null):
					var thePatternTexture = theSkin.getPatternTexture()
					if(thePatternTexture != null):
						if(thePatternTexture is Dictionary):
							if(thePatternTexture.has(custonSkinVariant)):
								fancyMaterial.set_shader_param("texture_pattern", thePatternTexture[custonSkinVariant])
							elif(customSkinPattern != null):
								fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
						else:
							fancyMaterial.set_shader_param("texture_pattern", thePatternTexture)
					elif(customSkinPattern != null):
						fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
			elif(customSkinPattern != null):
				fancyMaterial.set_shader_param("texture_pattern", customSkinPattern)
			elif(skinData.has("skin")):
				var theSkin = GlobalRegistry.getSkin(skinData["skin"])
				if(theSkin != null):
					fancyMaterial.set_shader_param("texture_pattern", theSkin.getPatternTexture())
			
			if(skinData.has("r")):
				fancyMaterial.set_shader_param("pattern_red_color", skinData["r"])
			else:
				fancyMaterial.set_shader_param("pattern_red_color", Color.white)
			if(skinData.has("g")):
				fancyMaterial.set_shader_param("pattern_green_color", skinData["g"])
			else:
				fancyMaterial.set_shader_param("pattern_green_color", Color.white)
			if(skinData.has("b")):
				fancyMaterial.set_shader_param("pattern_blue_color", skinData["b"])
			else:
				fancyMaterial.set_shader_param("pattern_blue_color", Color.white)

func updateFacing():
	if(writingsHandler):
		writingsHandler.updateFacing()

func supportsBulges() -> bool:
	return fancyMaterial != null && uvFit != null
func setShaftClipAtRestX(restX:float, feather:float = 0.006):
	if(!supportsBulges()):
		return
	var restMin:Vector2 = uvFit["restMin"]
	var restMax:Vector2 = uvFit["restMax"]
	if(restX <= restMin.x):
		clearShaftClip()
		return
	if(!clipShaderIn):
		var clipped = Clip.shaderFor(fancyMaterial.shader)
		if(clipped == null):
			return
		fancyMaterial.shader = clipped
		clipShaderIn = true
	var midRestY:float = (restMin.y + restMax.y) * 0.5
	var clipUV:Vector2 = BulgeUtils.restToUV(uvFit, Vector2(restX, midRestY))
	var rowU:Vector3 = uvFit["u"]
	var dir:float = 1.0
	if(rowU.x >= 0.0):
		dir = -1.0
	fancyMaterial.set_shader_param("shaft_clip", clipUV.x)
	fancyMaterial.set_shader_param("shaft_clip_dir", dir)
	fancyMaterial.set_shader_param("shaft_clip_feather", feather)
	hasShaftClip = true
func clearShaftClip():
	if(!hasShaftClip || fancyMaterial == null):
		return
	fancyMaterial.set_shader_param("shaft_clip", BULGE_DISABLED_CLIP)
	hasShaftClip = false
func getFinalBodypartSlot() -> String:
	if(bodypartSlot == "CUSTOM"):
		return bodypartSlotCustom
	return bodypartSlot
