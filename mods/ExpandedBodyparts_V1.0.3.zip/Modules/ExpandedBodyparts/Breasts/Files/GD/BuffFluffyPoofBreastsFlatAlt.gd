extends "res://Modules/ExpandedBodyparts/Breasts/Files/GD/BuffFluffyPoofBreastsAlt.gd"

func _init():
	visibleName = "Buff Fluffy Poof Breasts Flat Alt"
	id = "BuffFluffyPoofBreastsFlatAlt"
	size = BreastsSize.FOREVER_FLAT
	
func getCharacterCreatorDesc():
	return "Buff Fluffy Poof Breasts Flat Alt (ExpandedBodyparts)"
	
func getTraits():
	return {
		PartTrait.BreastsMale: true,
	}

func getLewdAdjective():
	return RNG.pick(["firm", "strong", "fluffy", "furry"])

func getLewdName():
	if(size <= BreastsSize.A):
		return "pecs"

	return RNG.pick(["manbreasts", "manboobs", "mantits", "jugs", "orbs"])

func safeWhenExposed():
	if(size <= BreastsSize.A):
		return true
	
	return false

func generateDataFor(_dynamicCharacter):
	pass

func getVulgarName() -> String:
	return "male pecs"

func getAVulgarName() -> String:
	return getVulgarName()
