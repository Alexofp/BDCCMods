extends BodypartArms

func _init():
	visibleName = "Fit F & T Arms"
	id = "FitFluffyTuftedArms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitFluffyTuftedArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy and Tufted Arms (ExpandedBodyparts)"
