extends BodypartArms

func _init():
	visibleName = "Fit F & T Arms Half"
	id = "FitFluffyTuftedArmsHalf"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitFluffyTuftedArmsHalf.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy and Tufted Arms Half (ExpandedBodyparts)"
