extends BodypartArms

func _init():
	visibleName = "Fit Arms Alt"
	id = "FitArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Arms With Paws and Thumbs (ExpandedBodyparts)"
