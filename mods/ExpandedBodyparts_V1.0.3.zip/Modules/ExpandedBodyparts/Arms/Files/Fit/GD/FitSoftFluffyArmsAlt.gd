extends BodypartArms

func _init():
	visibleName = "Fit S & F Arms Alt"
	id = "FitSoftFluffyArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitSoftFluffyArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Soft and Fluffy Arms Alt (ExpandedBodyparts)"
