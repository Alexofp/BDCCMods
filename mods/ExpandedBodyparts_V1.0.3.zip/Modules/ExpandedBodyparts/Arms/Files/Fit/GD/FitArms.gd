extends BodypartArms

func _init():
	visibleName = "Fit Arms"
	id = "FitArms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Arms With Thumbs (ExpandedBodyparts)"
