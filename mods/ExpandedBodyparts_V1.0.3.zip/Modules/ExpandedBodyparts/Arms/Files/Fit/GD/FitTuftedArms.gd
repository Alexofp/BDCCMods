extends BodypartArms

func _init():
	visibleName = "Fit Tufted Arms"
	id = "FitTuftedArms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitTuftedArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Tufted Arms (ExpandedBodyparts)"
