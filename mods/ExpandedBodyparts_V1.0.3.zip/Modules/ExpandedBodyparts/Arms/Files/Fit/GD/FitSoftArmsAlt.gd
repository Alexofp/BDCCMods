extends BodypartArms

func _init():
	visibleName = "Fit Soft Arms Alt"
	id = "FitSoftArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitSoftArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Soft Arms Alt (ExpandedBodyparts)"
