extends BodypartArms

func _init():
	visibleName = "Fit S & F Arms Half"
	id = "FitSoftFluffyArmsHalf"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitSoftFluffyArmsHalf.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Soft and Fluffy Arms Half (ExpandedBodyparts)"
