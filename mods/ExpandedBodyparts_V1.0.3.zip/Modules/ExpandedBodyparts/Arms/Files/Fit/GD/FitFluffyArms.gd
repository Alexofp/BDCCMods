extends BodypartArms

func _init():
	visibleName = "Fit Fluffy Arms"
	id = "FitFluffyArms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitFluffyArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy Arms (ExpandedBodyparts)"
