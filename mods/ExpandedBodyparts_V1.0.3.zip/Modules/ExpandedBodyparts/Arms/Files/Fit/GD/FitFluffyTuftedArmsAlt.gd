extends BodypartArms

func _init():
	visibleName = "Fit F & T Arms Alt"
	id = "FitFluffyTuftedArmsAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Arms/Files/Fit/TSCN/FitFluffyTuftedArmsAlt.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
func getCharacterCreatorDesc():
	return "Fit Fluffy and Tufted Arms Alt (ExpandedBodyparts)"
