extends BodypartBody

func _init():
	visibleName = "Proto2 Thin Body"
	id = "Proto2ThinBody"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Addons/Protogen/Bodys/Files/Thin/TSCN/Proto1ThinBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Proto2 Thin Body (ExpandedBodyparts)"
