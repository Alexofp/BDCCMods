extends BodypartBody

func _init():
	visibleName = "Proto1 Thin Body"
	id = "Proto1ThinBody"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Addons/Protogen/Bodys/Files/Thin/TSCN/Proto1ThinBody.tscn"

func getCharacterCreatorDesc():
	return "Proto1 Thin Body (ExpandedBodyparts)"
