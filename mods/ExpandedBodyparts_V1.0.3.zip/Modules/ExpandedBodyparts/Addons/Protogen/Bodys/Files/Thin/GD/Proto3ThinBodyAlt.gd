extends BodypartBody

func _init():
	visibleName = "Proto3 Thin Body Alt"
	id = "Proto3ThinBodyAlt"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Addons/Protogen/Bodys/Files/Thin/TSCN/Proto3ThinBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Proto3 Thin Body Alt (ExpandedBodyparts)"
