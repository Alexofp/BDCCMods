extends BodypartBody

func _init():
	visibleName = "Proto3 Thin Body"
	id = "Proto3ThinBody"

func getCompatibleSpecies():
	return [Species.protogen]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Addons/Protogen/Bodys/Files/Thin/TSCN/Proto2ThinBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Proto3 Thin Body (ExpandedBodyparts)"
