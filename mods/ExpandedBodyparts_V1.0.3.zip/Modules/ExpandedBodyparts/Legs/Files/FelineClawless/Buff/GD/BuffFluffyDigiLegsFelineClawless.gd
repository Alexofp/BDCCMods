extends BodypartLeg

func _init():
	visibleName = "Buff Fluffy Feline Clawless DigiLegs"
	id = "BuffFluffyDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Legs/Files/FelineClawless/Buff/TSCN/BuffFluffyDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Fluffy Feline Clawless DigiLegs (ExpandedBodyparts)"
