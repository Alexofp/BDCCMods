extends BodypartLeg

func _init():
	visibleName = "Buff S & T Feline Clawless DigiLegs"
	id = "BuffSoftTuftedDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Legs/Files/FelineClawless/Buff/TSCN/BuffSoftTuftedDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Soft and Tufted Feline Clawless DigiLegs (ExpandedBodyparts)"
