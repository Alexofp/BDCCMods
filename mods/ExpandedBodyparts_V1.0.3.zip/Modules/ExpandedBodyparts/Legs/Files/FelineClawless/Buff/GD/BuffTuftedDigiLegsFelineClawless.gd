extends BodypartLeg

func _init():
	visibleName = "Buff Tufted Feline Clawless DigiLegs"
	id = "BuffTuftedDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Legs/Files/FelineClawless/Buff/TSCN/BuffTuftedDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Tufted Feline Clawless DigiLegs (ExpandedBodyparts)"
