extends BodypartLeg

func _init():
	visibleName = "Buff Soft Feline Clawless DigiLegs"
	id = "BuffSoftDigiLegsFelineClawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Legs/Files/FelineClawless/Buff/TSCN/BuffSoftDigiLegsFelineClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
func getCharacterCreatorDesc():
	return "Buff Soft Feline Clawless DigiLegs (ExpandedBodyparts)"
