extends "res://Modules/Z_Hypertus/Misc/ModBodypartBreasts.gd"

func _init():
	visibleName = "Hyperable Buff Fluffy Poof Breasts"
	id = "BuffFluffyPoofBreastshyperable"
	size = breastSizeModClass.G

func getCharacterCreatorDesc():
	return "Hyperable Buff Fluffy Poof Breasts (ExpandedBodyparts) Note: Current texture for this are a stand in for now."

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return breastSizeModClass.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= breastSizeModClass.FLAT):
		return "res://Modules/ExpandedBodyparts/Breasts/Files/TSCN/BuffFluffyPoofBreastsFlat.tscn"
	return "res://Modules/ExpandedBodyparts/Breasts/Files/TSCN/BuffFluffyPoofBreasts.tscn"

func getTraits():
	return {
		PartTrait.BreastsFemale: true,
		"Hyperable": true,
	}
