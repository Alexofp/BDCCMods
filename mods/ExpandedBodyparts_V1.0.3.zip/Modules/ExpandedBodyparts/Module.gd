extends Module

var ProtogenSpeciesExist = ResourceLoader.exists("res://Modules/AnonsProtogenSpecies/Protogen.gd")
var HypertusExist = ResourceLoader.exists("res://Modules/Z_Hypertus/Module.gd")

func _init():
	id = "ExpandedBodyparts"
	author = "Astro"
	
	bodyparts = []
	bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/ExpandedBodyparts/Arms/"))
	bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/ExpandedBodyparts/Bodys/"))
	bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/ExpandedBodyparts/Breasts/"))
	bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/ExpandedBodyparts/Legs/"))
	
	if (ProtogenSpeciesExist == true):
		bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/ExpandedBodyparts/Addons/Protogen/"))
	
	if (HypertusExist == true):
		bodyparts.append_array(GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/ExpandedBodyparts/CompatibilityPatches/Hypertus/"))
	
