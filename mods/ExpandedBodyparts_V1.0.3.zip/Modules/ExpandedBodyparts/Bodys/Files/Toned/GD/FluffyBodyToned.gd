extends BodypartBody

func _init():
	visibleName = "Toned Fluffy Body"
	id = "TonedFluffyBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Toned/TSCN/TonedFluffyBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Fluffy Body (ExpandedBodyparts)"
