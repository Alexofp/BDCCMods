extends BodypartBody

func _init():
	visibleName = "TonedSoft Body"
	id = "TonedSoftBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Toned/TSCN/TonedSoftBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Soft Body (ExpandedBodyparts)"
