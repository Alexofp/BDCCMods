extends BodypartBody

func _init():
	visibleName = "Toned Soft Body Alt"
	id = "TonedSoftBodyAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Toned/TSCN/TonedSoftBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Toned Soft Body Alt (ExpandedBodyparts)"
