extends BodypartBody

func _init():
	visibleName = "Buff Fluffy Body"
	id = "BuffFluffyBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Buff/TSCN/BuffFluffyBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Fluffy Body (ExpandedBodyparts) Re-added from Winters Fluffy Bodyparts."
