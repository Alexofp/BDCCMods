extends BodypartBody

func _init():
	visibleName = "Buff Soft Body Alt"
	id = "BuffSoftBodyAlt"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Buff/TSCN/BuffSoftBodyAlt.tscn"

func getCharacterCreatorDesc():
	return "Buff Soft Body Alt (ExpandedBodyparts)"
