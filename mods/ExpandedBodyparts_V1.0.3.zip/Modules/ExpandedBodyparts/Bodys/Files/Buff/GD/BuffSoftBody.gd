extends BodypartBody

func _init():
	visibleName = "Buff Soft Body"
	id = "BuffSoftBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Buff/TSCN/BuffSoftBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Soft Body (ExpandedBodyparts)"
