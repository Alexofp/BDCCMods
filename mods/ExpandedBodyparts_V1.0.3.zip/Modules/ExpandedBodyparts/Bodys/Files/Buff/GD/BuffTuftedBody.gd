extends BodypartBody

func _init():
	visibleName = "Buff Tufted Body"
	id = "BuffTuftedBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/Buff/TSCN/BuffTuftedBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Tufted Body (ExpandedBodyparts)"
