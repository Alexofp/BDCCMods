extends BodypartBody

func _init():
	visibleName = "Toned Odogaron Body"
	id = "TonedOdogaronBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Toned/TSCN/TonedOdogaronBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Odogaron Body (ExpandedBodyparts)"
