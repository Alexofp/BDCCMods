extends BodypartBody

func _init():
	visibleName = "Toned Mizutsune Body"
	id = "TonedMizutsuneBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Toned/TSCN/TonedMizutsuneBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Mizutsune Body (ExpandedBodyparts)"
