extends BodypartBody

func _init():
	visibleName = "Toned Nergi Body"
	id = "TonedNergiBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Toned/TSCN/TonedNergiBody.tscn"

func getCharacterCreatorDesc():
	return "Toned Nergi Body (ExpandedBodyparts)"
