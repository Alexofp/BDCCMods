extends BodypartBody

func _init():
	visibleName = "Buff Mizutsune Body"
	id = "BuffMizutsuneBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Buff/TSCN/BuffMizutsuneBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Mizutsune Body (ExpandedBodyparts)"
