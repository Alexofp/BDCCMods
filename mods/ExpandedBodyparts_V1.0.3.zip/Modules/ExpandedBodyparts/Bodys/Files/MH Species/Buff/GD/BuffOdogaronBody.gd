extends BodypartBody

func _init():
	visibleName = "Buff Odogaron Body"
	id = "BuffOdogaronBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Buff/TSCN/BuffOdogaronBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Odogaron Body (ExpandedBodyparts)"
