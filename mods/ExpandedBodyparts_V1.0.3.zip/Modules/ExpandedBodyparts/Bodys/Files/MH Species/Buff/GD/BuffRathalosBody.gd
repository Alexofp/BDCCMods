extends BodypartBody

func _init():
	visibleName = "Buff Rathalos Body"
	id = "BuffRathalosBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Buff/TSCN/BuffRathalosBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Rathalos Body (ExpandedBodyparts)"
