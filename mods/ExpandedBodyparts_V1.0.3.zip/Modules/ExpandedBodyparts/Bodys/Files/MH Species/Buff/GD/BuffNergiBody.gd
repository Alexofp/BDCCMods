extends BodypartBody

func _init():
	visibleName = "Buff Nergi Body"
	id = "BuffNergiBody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/ExpandedBodyparts/Bodys/Files/MH Species/Buff/TSCN/BuffNergiBody.tscn"

func getCharacterCreatorDesc():
	return "Buff Nergi Body (ExpandedBodyparts)"
