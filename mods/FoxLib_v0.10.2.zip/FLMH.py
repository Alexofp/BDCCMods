#!/usr/bin/env python
# -*- coding: utf-8 -*-
# FoxLib ModHelper
# It is recommended to use PyCharm to edit this file!

# <editor-fold defaultstate="collapsed" desc="Python imports" >
import io  # <- Temporary buffers for image manipulation
import os  # <- Used for file manipulation
import sys  # <- Used to parse program arguments and check if output is terminal
import time  # <- Used to check the age of the cache for game dev git build
import stat  # <- Used to check unix file permissions (Not used on Windows)
import json  # <- Used to read mod info file
import struct  # <- Get PNG size for making .stex files
import signal  # <- Used to kill child process for internal test mode
import shutil  # <- Used to delete folder, for "un-foxlib" and deleting broken game folder
import random  # <- Used for code generation for "debug" command
import zipfile  # <- Used to make your mod or read other mod entries
import platform  # <- Used to check if you are on Windows/Mac/Linux
import subprocess  # <- Used to run BDCC itself for the "run-game" and "test" commands

try:
    import colorama  # <- Used to get console ANSI color codes working (Especially on Windows)

    colorama.init()
except ImportError:
    colorama = None

try:
    import readline  # <- Used for tab completion for the "cli" command
except ImportError:
    try:
        from pyreadline.rlmain import Readline
    except ImportError:
        try:
            from pyreadline3 import Readline  # <- Used for tab completion for the "cli" command
        except ImportError:
            Readline = None
    if Readline is not None:
        # PYCharm think it's not callable, but it's always callable.
        # noinspection PyCallingNonCallable
        readline = Readline()
    else:
        readline = None

try:
    import requests  # <- Used to download BDCC for the "run-game", "test", and "debug" commands
except ImportError:
    requests = None

has_urllib_request = False
try:
    import urllib.request  # <- Used to download BDCC for the "run-game", "test", and "debug" commands

    has_urllib_request = True
except ImportError:
    urllib = None

try:
    from pydub import AudioSegment  # <- Used to convert wav into ogg.
except ImportError:
    AudioSegment = None

try:
    import ffmpeg  # <- Used to convert wav into ogg.
except ImportError:
    ffmpeg = None

try:
    from PIL import Image  # <- Used for texture filtering
except:
    Image = None
# </editor-fold>

# Change at your own risk
show_me_experimental_stuff = False

# <editor-fold defaultstate="collapsed" desc="Godot & BDCC Data (Very big)" >
# BDCC Game constants
game_downloads = {
    "version": "0.1.12fix4",
    "linux": "bdcc-linux.zip",
    "mac": "bdcc-mac.zip",
    "windows": "bdcc-windows.zip",
    "pattern": "https://github.com/Alexofp/BDCC/releases/download/${version}/bdcc-${platform}.zip",
    "dev-pattern": "https://nightly.link/Alexofp/BDCC/workflows/godot-ci/dev/bdcc-${platform}.zip"
}
bug_fixed_versions_map = {
    "0.1.7": "0.1.7fix1",
    "0.1.8": "0.1.8fix3",
    "0.1.9": "0.1.9fix1",
    "0.1.10": "0.1.10fix1",
    "0.1.11": "0.1.11fix1",
    "0.1.12": "0.1.12fix4"
}
godot_class_names = ["Node", "AcceptDialog", "AnimatedSprite", "AnimatedSprite3D", "AnimationPlayer", "AnimationTree",
                     "AnimationTreePlayer", "Area", "Area2D", "ARVRAnchor", "ARVRCamera", "ARVRController",
                     "ARVROrigin", "AspectRatioContainer", "AudioStreamPlayer", "AudioStreamPlayer2D",
                     "AudioStreamPlayer3D", "BackBufferCopy", "BakedLightmap", "BaseButton", "Bone2D", "BoneAttachment",
                     "BoxContainer", "Button", "Camera", "Camera2D", "CanvasItem", "CanvasLayer", "CanvasModulate",
                     "CenterContainer", "CheckBox", "CheckButton", "ClippedCamera", "CollisionObject",
                     "CollisionObject2D", "CollisionPolygon", "CollisionPolygon2D", "CollisionShape",
                     "CollisionShape2D", "ColorPicker", "ColorPickerButton", "ColorRect", "ConeTwistJoint",
                     "ConfirmationDialog", "Container", "Control", "CPUParticles", "CPUParticles2D", "CSGBox",
                     "CSGCombiner", "CSGCylinder", "CSGMesh", "CSGPolygon", "CSGPrimitive", "CSGShape", "CSGSphere",
                     "CSGTorus", "CullInstance", "DampedSpringJoint2D", "DirectionalLight", "EditorFileDialog",
                     "EditorFileSystem", "EditorInspector", "EditorInterface", "EditorPlugin", "EditorProperty",
                     "EditorResourcePicker", "EditorResourcePreview", "EditorScriptPicker", "EditorSpinSlider",
                     "FileDialog", "FileSystemDock", "FlowContainer", "Generic6DOFJoint", "GeometryInstance", "GIProbe",
                     "GraphEdit", "GraphNode", "GridContainer", "GridMap", "GrooveJoint2D", "HBoxContainer",
                     "HFlowContainer", "HingeJoint", "HScrollBar", "HSeparator", "HSlider", "HSplitContainer",
                     "HTTPRequest", "ImmediateGeometry", "InstancePlaceholder", "InterpolatedCamera", "ItemList",
                     "Joint", "Joint2D", "KinematicBody", "KinematicBody2D", "Label", "Label3D", "Light", "Light2D",
                     "LightOccluder2D", "Line2D", "LineEdit", "LinkButton", "Listener", "Listener2D", "LOD",
                     "MarginContainer", "MenuButton", "MergeGroup", "MeshInstance", "MeshInstance2D",
                     "MultiMeshInstance", "MultiMeshInstance2D", "Navigation", "Navigation2D", "NavigationAgent",
                     "NavigationAgent2D", "NavigationMeshInstance", "NavigationObstacle", "NavigationObstacle2D",
                     "NavigationPolygonInstance", "NinePatchRect", "Node2D", "Occluder", "OmniLight", "OptionButton",
                     "Panel", "PanelContainer", "ParallaxBackground", "ParallaxLayer", "Particles", "Particles2D",
                     "Path", "Path2D", "PathFollow", "PathFollow2D", "PhysicalBone", "PhysicsBody", "PhysicsBody2D",
                     "PinJoint", "PinJoint2D", "Polygon2D", "Popup", "PopupDialog", "PopupMenu", "PopupPanel", "Portal",
                     "Position2D", "Position3D", "ProgressBar", "ProximityGroup", "Range", "RayCast", "RayCast2D",
                     "ReferenceRect", "ReflectionProbe", "RemoteTransform", "RemoteTransform2D", "ResourcePreloader",
                     "RichTextLabel", "RigidBody", "RigidBody2D", "Room", "RoomGroup", "RoomManager", "RootMotionView",
                     "ScriptCreateDialog", "ScriptEditor", "ScrollBar", "ScrollContainer", "Separator", "ShapeCast",
                     "ShapeCast2D", "Skeleton", "Skeleton2D", "SkeletonIK", "Slider", "SliderJoint", "SoftBody",
                     "Spatial", "SpinBox", "SplitContainer", "SpotLight", "SpringArm", "Sprite", "Sprite3D",
                     "SpriteBase3D", "StaticBody", "StaticBody2D", "TabContainer", "Tabs", "TextEdit", "TextureButton",
                     "TextureProgress", "TextureRect", "TileMap", "Timer", "ToolButton", "TouchScreenButton", "Tree",
                     "Tween", "VBoxContainer", "VehicleBody", "VehicleWheel", "VFlowContainer", "VideoPlayer",
                     "Viewport", "ViewportContainer", "VisibilityEnabler", "VisibilityEnabler2D", "VisibilityNotifier",
                     "VisibilityNotifier2D", "VisualInstance", "VScrollBar", "VSeparator", "VSlider", "VSplitContainer",
                     "WindowDialog", "WorldEnvironment", "YSort", "Resource", "AnimatedTexture", "Animation",
                     "AnimationNode", "AnimationNodeAdd2", "AnimationNodeAdd3", "AnimationNodeAnimation",
                     "AnimationNodeBlend2", "AnimationNodeBlend3", "AnimationNodeBlendSpace1D",
                     "AnimationNodeBlendSpace2D", "AnimationNodeBlendTree", "AnimationNodeOneShot",
                     "AnimationNodeOutput", "AnimationNodeStateMachine", "AnimationNodeStateMachinePlayback",
                     "AnimationNodeStateMachineTransition", "AnimationNodeTimeScale", "AnimationNodeTimeSeek",
                     "AnimationNodeTransition", "AnimationRootNode", "ArrayMesh", "AtlasTexture", "AudioBusLayout",
                     "AudioEffect", "AudioEffectAmplify", "AudioEffectBandLimitFilter", "AudioEffectBandPassFilter",
                     "AudioEffectCapture", "AudioEffectChorus", "AudioEffectCompressor", "AudioEffectDelay",
                     "AudioEffectDistortion", "AudioEffectEQ", "AudioEffectEQ10", "AudioEffectEQ21", "AudioEffectEQ6",
                     "AudioEffectFilter", "AudioEffectHighPassFilter", "AudioEffectHighShelfFilter",
                     "AudioEffectLimiter", "AudioEffectLowPassFilter", "AudioEffectLowShelfFilter",
                     "AudioEffectNotchFilter", "AudioEffectPanner", "AudioEffectPhaser", "AudioEffectPitchShift",
                     "AudioEffectRecord", "AudioEffectReverb", "AudioEffectSpectrumAnalyzer",
                     "AudioEffectStereoEnhance", "AudioStream", "AudioStreamGenerator", "AudioStreamMicrophone",
                     "AudioStreamMP3", "AudioStreamOGGVorbis", "AudioStreamRandomPitch", "AudioStreamSample",
                     "BakedLightmapData", "BitMap", "BitmapFont", "BoxShape", "ButtonGroup", "CameraTexture",
                     "CanvasItemMaterial", "CapsuleMesh", "CapsuleShape", "CapsuleShape2D", "CircleShape2D",
                     "ConcavePolygonShape", "ConcavePolygonShape2D", "ConvexPolygonShape", "ConvexPolygonShape2D",
                     "CryptoKey", "CSharpScript", "CubeMap", "CubeMesh", "Curve", "Curve2D", "Curve3D", "CurveTexture",
                     "CylinderMesh", "CylinderShape", "DynamicFont", "DynamicFontData", "EditorSettings",
                     "EditorSpatialGizmoPlugin", "Environment", "ExternalTexture", "Font", "GDNativeLibrary",
                     "GDScript", "GIProbeData", "GLTFAccessor", "GLTFAnimation", "GLTFBufferView", "GLTFCamera",
                     "GLTFCollider", "GLTFDocument", "GLTFDocumentExtension", "GLTFLight", "GLTFMesh", "GLTFNode",
                     "GLTFPhysicsBody", "GLTFSkeleton", "GLTFSkin", "GLTFSpecGloss", "GLTFState", "GLTFTexture",
                     "GLTFTextureSampler", "Gradient", "GradientTexture", "GradientTexture2D", "HeightMapShape",
                     "Image", "ImageTexture", "InputEvent", "InputEventAction", "InputEventGesture",
                     "InputEventJoypadButton", "InputEventJoypadMotion", "InputEventKey", "InputEventMagnifyGesture",
                     "InputEventMIDI", "InputEventMouse", "InputEventMouseButton", "InputEventMouseMotion",
                     "InputEventPanGesture", "InputEventScreenDrag", "InputEventScreenTouch", "InputEventWithModifiers",
                     "LargeTexture", "LineShape2D", "Material", "Material3D", "Mesh", "MeshLibrary", "MeshTexture",
                     "MultiMesh", "NativeScript", "NavigationMesh", "NavigationPolygon", "NoiseTexture",
                     "OccluderPolygon2D", "OccluderShape", "OccluderShapePolygon", "OccluderShapeSphere",
                     "OpenSimplexNoise", "ORMSpatialMaterial", "PackedDataContainer", "PackedScene", "PackedSceneGLTF",
                     "PanoramaSky", "ParticlesMaterial", "PHashTranslation", "PhysicsMaterial", "PlaneMesh",
                     "PlaneShape", "PluginScript", "PointMesh", "PolygonPathFinder", "PrimitiveMesh", "PrismMesh",
                     "ProceduralSky", "ProxyTexture", "QuadMesh", "RayShape", "RayShape2D", "RectangleShape2D",
                     "RichTextEffect", "Script", "SegmentShape2D", "Shader", "ShaderMaterial", "Shape", "Shape2D",
                     "ShortCut", "Skin", "Sky", "SpatialMaterial", "SphereMesh", "SphereShape", "SpriteFrames",
                     "StreamTexture", "StyleBox", "StyleBoxEmpty", "StyleBoxFlat", "StyleBoxLine", "StyleBoxTexture",
                     "TextFile", "TextMesh", "Texture", "Texture3D", "TextureArray", "TextureLayered", "Theme",
                     "TileSet", "TorusMesh", "Translation", "VideoStream", "VideoStreamGDNative", "VideoStreamTheora",
                     "VideoStreamWebm", "ViewportTexture", "VisualScript", "VisualScriptBasicTypeConstant",
                     "VisualScriptBuiltinFunc", "VisualScriptClassConstant", "VisualScriptComment",
                     "VisualScriptComposeArray", "VisualScriptCondition", "VisualScriptConstant",
                     "VisualScriptConstructor", "VisualScriptCustomNode", "VisualScriptDeconstruct",
                     "VisualScriptEmitSignal", "VisualScriptEngineSingleton", "VisualScriptExpression",
                     "VisualScriptFunction", "VisualScriptFunctionCall", "VisualScriptGlobalConstant",
                     "VisualScriptIndexGet", "VisualScriptIndexSet", "VisualScriptInputAction", "VisualScriptIterator",
                     "VisualScriptLists", "VisualScriptLocalVar", "VisualScriptLocalVarSet", "VisualScriptMathConstant",
                     "VisualScriptNode", "VisualScriptOperator", "VisualScriptPreload", "VisualScriptPropertyGet",
                     "VisualScriptPropertySet", "VisualScriptResourcePath", "VisualScriptReturn",
                     "VisualScriptSceneNode", "VisualScriptSceneTree", "VisualScriptSelect", "VisualScriptSelf",
                     "VisualScriptSequence", "VisualScriptSubCall", "VisualScriptSwitch", "VisualScriptTypeCast",
                     "VisualScriptVariableGet", "VisualScriptVariableSet", "VisualScriptWhile", "VisualScriptYield",
                     "VisualScriptYieldSignal", "VisualShader", "VisualShaderNode", "VisualShaderNodeBooleanConstant",
                     "VisualShaderNodeBooleanUniform", "VisualShaderNodeColorConstant", "VisualShaderNodeColorFunc",
                     "VisualShaderNodeColorOp", "VisualShaderNodeColorUniform", "VisualShaderNodeCompare",
                     "VisualShaderNodeCubeMap", "VisualShaderNodeCubeMapUniform", "VisualShaderNodeCustom",
                     "VisualShaderNodeDeterminant", "VisualShaderNodeDotProduct", "VisualShaderNodeExpression",
                     "VisualShaderNodeFaceForward", "VisualShaderNodeFresnel", "VisualShaderNodeGlobalExpression",
                     "VisualShaderNodeGroupBase", "VisualShaderNodeIf", "VisualShaderNodeInput", "VisualShaderNodeIs",
                     "VisualShaderNodeOuterProduct", "VisualShaderNodeOutput", "VisualShaderNodeScalarClamp",
                     "VisualShaderNodeScalarConstant", "VisualShaderNodeScalarDerivativeFunc",
                     "VisualShaderNodeScalarFunc", "VisualShaderNodeScalarInterp", "VisualShaderNodeScalarOp",
                     "VisualShaderNodeScalarSmoothStep", "VisualShaderNodeScalarSwitch",
                     "VisualShaderNodeScalarUniform", "VisualShaderNodeSwitch", "VisualShaderNodeTexture",
                     "VisualShaderNodeTextureUniform", "VisualShaderNodeTextureUniformTriplanar",
                     "VisualShaderNodeTransformCompose", "VisualShaderNodeTransformConstant",
                     "VisualShaderNodeTransformDecompose", "VisualShaderNodeTransformFunc",
                     "VisualShaderNodeTransformMult", "VisualShaderNodeTransformUniform",
                     "VisualShaderNodeTransformVecMult", "VisualShaderNodeUniform", "VisualShaderNodeUniformRef",
                     "VisualShaderNodeVec3Constant", "VisualShaderNodeVec3Uniform", "VisualShaderNodeVectorClamp",
                     "VisualShaderNodeVectorCompose", "VisualShaderNodeVectorDecompose",
                     "VisualShaderNodeVectorDerivativeFunc", "VisualShaderNodeVectorDistance",
                     "VisualShaderNodeVectorFunc", "VisualShaderNodeVectorInterp", "VisualShaderNodeVectorLen",
                     "VisualShaderNodeVectorOp", "VisualShaderNodeVectorRefract", "VisualShaderNodeVectorScalarMix",
                     "VisualShaderNodeVectorScalarSmoothStep", "VisualShaderNodeVectorScalarStep",
                     "VisualShaderNodeVectorSmoothStep", "World", "World2D", "X509Certificate", "Object", "AESContext",
                     "AnimationTrackEditPlugin", "ARVRInterface", "ARVRInterfaceGDNative", "ARVRPositionalTracker",
                     "ARVRServer", "AStar", "AStar2D", "AudioEffectInstance", "AudioEffectSpectrumAnalyzerInstance",
                     "AudioServer", "AudioStreamGeneratorPlayback", "AudioStreamPlayback",
                     "AudioStreamPlaybackResampled", "CallbackTweener", "CameraFeed", "CameraServer", "CharFXTransform",
                     "ClassDB", "ConfigFile", "Crypto", "Directory", "DTLSServer", "EditorExportPlugin",
                     "EditorFeatureProfile", "EditorFileSystemDirectory", "EditorImportPlugin", "EditorInspectorPlugin",
                     "EditorResourceConversionPlugin", "EditorResourcePreviewGenerator", "EditorSceneImporter",
                     "EditorSceneImporterFBX", "EditorSceneImporterGLTF", "EditorScenePostImport", "EditorScript",
                     "EditorSelection", "EditorSpatialGizmo", "EditorVCSInterface", "EncodedObjectAsID", "Engine",
                     "Expression", "File", "FuncRef", "GDNative", "GDScriptFunctionState", "Geometry", "GodotSharp",
                     "HashingContext", "HMACContext", "HTTPClient", "Input", "InputMap", "IntervalTweener", "IP",
                     "JavaClass", "JavaClassWrapper", "JavaScript", "JavaScriptObject", "JNISingleton", "JSON",
                     "JSONParseResult", "JSONRPC", "KinematicCollision", "KinematicCollision2D", "MainLoop",
                     "Marshalls", "MeshDataTool", "MethodTweener", "MobileVRInterface", "MultiplayerAPI",
                     "MultiplayerPeerGDNative", "Mutex", "Navigation2DServer", "NavigationMeshGenerator",
                     "NavigationServer", "NetworkedMultiplayerCustom", "NetworkedMultiplayerENet",
                     "NetworkedMultiplayerPeer", "OS", "PackedDataContainerRef", "PacketPeer", "PacketPeerDTLS",
                     "PacketPeerGDNative", "PacketPeerStream", "PacketPeerUDP", "PCKPacker", "Performance",
                     "Physics2DDirectBodyState", "Physics2DDirectSpaceState", "Physics2DServer",
                     "Physics2DShapeQueryParameters", "Physics2DTestMotionResult", "PhysicsDirectBodyState",
                     "PhysicsDirectSpaceState", "PhysicsServer", "PhysicsShapeQueryParameters",
                     "PhysicsTestMotionResult", "ProjectSettings", "PropertyTweener", "RandomNumberGenerator",
                     "Reference", "RegEx", "RegExMatch", "ResourceFormatLoader", "ResourceFormatSaver",
                     "ResourceImporter", "ResourceInteractiveLoader", "ResourceLoader", "ResourceSaver", "SceneState",
                     "SceneTree", "SceneTreeTimer", "SceneTreeTween", "Semaphore", "SkinReference", "SpatialGizmo",
                     "SpatialVelocityTracker", "StreamPeer", "StreamPeerBuffer", "StreamPeerGDNative", "StreamPeerSSL",
                     "StreamPeerTCP", "SurfaceTool", "TCP_Server", "Thread", "Time", "TranslationServer", "TreeItem",
                     "TriangleMesh", "Tweener", "UDPServer", "UndoRedo", "UPNP", "UPNPDevice", "VisualScriptEditor",
                     "VisualScriptFunctionState", "VisualServer", "WeakRef", "WebRTCDataChannel",
                     "WebRTCDataChannelGDNative", "WebRTCMultiplayer", "WebRTCPeerConnection",
                     "WebRTCPeerConnectionGDNative", "WebSocketClient", "WebSocketMultiplayerPeer", "WebSocketPeer",
                     "WebSocketServer", "WebXRInterface", "XMLParser", "AABB", "Array", "Basis", "bool", "Color",
                     "Dictionary", "float", "int", "NodePath", "Plane", "PoolByteArray", "PoolColorArray",
                     "PoolIntArray", "PoolRealArray", "PoolStringArray", "PoolVector2Array", "PoolVector3Array", "Quat",
                     "Rect2", "RID", "String", "Transform", "Transform2D", "Variant", "Vector2", "Vector3"]
godot_primitive_method_names = ["abs", "affine_inverse", "angle", "angle_to", "angle_to_point", "append",
                                "append_array", "aspect", "back", "basis_xform", "basis_xform_inv", "begins_with",
                                "bigrams", "blend", "bounce", "bsearch", "bsearch_custom", "c_escape", "c_unescape",
                                "capitalize", "casecmp_to", "ceil", "center", "clamped", "clear", "clip", "compress",
                                "contrasted", "count", "countn", "cross", "cubic_interpolate", "cubic_slerp",
                                "darkened", "decompress", "decompress_dynamic", "dedent", "determinant", "direction_to",
                                "distance_squared_to", "distance_to", "dot", "duplicate", "empty", "encloses",
                                "ends_with", "erase", "expand", "fill", "find", "find_key", "find_last", "findn",
                                "floor", "format", "from_hsv", "front", "get", "get_any_point", "get_area",
                                "get_as_property_path", "get_base_dir", "get_basename", "get_center",
                                "get_concatenated_subnames", "get_endpoint", "get_euler", "get_extension", "get_file",
                                "get_id", "get_longest_axis", "get_longest_axis_index", "get_longest_axis_size",
                                "get_luminance", "get_name", "get_name_count", "get_or_add", "get_origin",
                                "get_orthogonal_index", "get_rotation", "get_rotation_quat", "get_scale",
                                "get_shortest_axis", "get_shortest_axis_index", "get_shortest_axis_size", "get_slice",
                                "get_string_from_ascii", "get_string_from_utf8", "get_subname", "get_subname_count",
                                "get_support", "gray", "grow", "grow_individual", "grow_margin", "has", "has_all",
                                "has_no_area", "has_no_surface", "has_point", "hash", "hex_encode", "hex_to_int",
                                "http_escape", "http_unescape", "humanize_size", "indent", "insert", "interpolate_with",
                                "intersect_3", "intersection", "intersects", "intersects_plane", "intersects_ray",
                                "intersects_segment", "inverse", "invert", "inverted", "is_abs_path", "is_absolute",
                                "is_empty", "is_equal_approx", "is_normalized", "is_point_over", "is_rel_path",
                                "is_subsequence_of", "is_subsequence_ofi", "is_valid_filename", "is_valid_float",
                                "is_valid_hex_number", "is_valid_html_color", "is_valid_identifier", "is_valid_integer",
                                "is_valid_ip_address", "is_zero_approx", "join", "json_escape", "keys", "left",
                                "length", "length_squared", "lightened", "limit_length", "linear_interpolate",
                                "looking_at", "lstrip", "match", "matchn", "max", "max_axis", "md5_buffer", "md5_text",
                                "merge", "min", "min_axis", "move_toward", "naturalnocasecmp_to", "new", "nocasecmp_to",
                                "normalized", "ord_at", "orthonormalized", "outer", "pad_decimals", "pad_zeros",
                                "percent_decode", "percent_encode", "pick_random", "plus_file", "pop_at", "pop_back",
                                "pop_front", "posmod", "posmodv", "project", "push_back", "push_front", "reflect",
                                "remove", "repeat", "replace", "replacen", "resize", "rfind", "rfindn", "right",
                                "rotated", "round", "rsplit", "rstrip", "scaled", "set", "set_axis_angle", "set_euler",
                                "sha1_buffer", "sha1_text", "sha256_buffer", "sha256_text", "shuffle", "sign",
                                "signed_angle_to", "similarity", "simplify_path", "size", "slerp", "slerpni", "slice",
                                "slide", "snapped", "sort", "sort_custom", "split", "split_floats", "strip_edges",
                                "strip_escapes", "subarray", "substr", "tangent", "tdotx", "tdoty", "tdotz",
                                "to_abgr32", "to_abgr64", "to_argb32", "to_argb64", "to_ascii", "to_diagonal_matrix",
                                "to_float", "to_html", "to_int", "to_lower", "to_rgba32", "to_rgba64", "to_upper",
                                "to_utf8", "to_wchar", "translated", "transposed", "trim_prefix", "trim_suffix",
                                "validate_node_name", "values", "xform", "xform_inv", "xml_escape", "xml_unescape"]
game_class_names = ["AIStrategyBase", "AnusOrifice", "AttachmentProxy", "Attack", "AttackRequirement", "AuctionAction",
                    "AuctionActionType", "AuctionBidder", "AuctionSlaveReaction", "AuctionTrait", "AuctionTraitType",
                    "BaseCharacter", "BaseStageScene3D", "BasicAI", "BetterButton", "BodilyFluids", "BodyWritings",
                    "BodyWritingsDB", "BodyWritingsZone", "Bodypart", "BodypartAnus", "BodypartArms", "BodypartBody",
                    "BodypartBreasts", "BodypartEars", "BodypartHair", "BodypartHead", "BodypartHorns", "BodypartLeg",
                    "BodypartPenis", "BodypartSlot", "BodypartTail", "BodypartVagina", "BoneHandle", "BraState",
                    "BreastsSize", "Buff", "BuffAttribute", "BuffBase", "BuffsHolder", "ButtonChecks",
                    "CellblockModule", "Character", "CharacterArchetype", "CharacterFlag", "CharacterGeneratorBase",
                    "CharacterPawn", "CharacterPool", "CharacterType", "Child", "ChildSystem", "CodeBlockBase",
                    "CodeContex", "ColorUtils", "ComputerBase", "ContentType", "CreatedInteraction",
                    "CreatedInteractionAction", "CreatedInteractionInterruption", "CreatedInteractionState",
                    "CrotchBlockEditorType", "CrotchBlocks", "CrotchFavBlocksResource", "CrotchSlotAnim",
                    "CrotchSlotButtonChecks", "CrotchSlotCalls", "CrotchSlotImage", "CrotchSlotVar", "CrotchUtil",
                    "CrotchVarType", "CumProduction", "CurveRenderer", "CycleStage", "DamageType", "Datapack",
                    "DatapackCharacter", "DatapackImage", "DatapackQuest", "DatapackQuestBase",
                    "DatapackQuestCodeContext", "DatapackResource", "DatapackScene", "DatapackSceneBase",
                    "DatapackSceneCodeContext", "DatapackSceneImage", "DatapackSceneState", "DatapackSceneTrigger",
                    "DatapackSceneTriggerType", "DatapackSceneVarType", "DatapackSkin", "DatapackTriggerCodeContext",
                    "DeepLTranslator", "DialogueFiller", "DialogueFillerAdder", "DialogueForm", "DialogueFormBank",
                    "DialogueParser", "Direction", "Doll3D", "DollAttachmentZone", "DollSkeleton", "DrugDen",
                    "DrugDenEventBase", "DrugDenJunkieGenerator", "DungeonMapGenerator", "DynCharExtraSettings",
                    "DynamicCharacter", "EggCell", "EncounterSettings", "EngineerGenerator", "EngineerLoot",
                    "EscapeQuest", "EventBase", "EventSystem", "EventTrigger", "EventTriggerLocation",
                    "EventTriggerPriority", "EventTriggerSceneHook", "EventTriggerWeighted", "ExtendGame", "Fetish",
                    "FetishBase", "FetishHolder", "FetishInterest", "FightClubFighter", "FightClubModule",
                    "FightClubRank", "Flag", "FlagType", "FlexGridContainer", "FluidBase", "FluidDNA",
                    "FluidProduction", "FluidSource", "Fluids", "GDUnzip", "GameExtender", "GameExtenderSystem",
                    "GameParser", "GameRoom", "GameUI", "GameWorld", "Gender", "GlobalTask", "GoogleBatchTranslator",
                    "GoogleTranslator", "GuardGenerator", "GuardLoot", "GymModule", "HK_Glasses", "HK_HypnoRestraint",
                    "HK_Sessions", "HypnokinkUtil", "ImageCon", "ImageConditions", "ImagePack", "Images",
                    "InmateGenerator", "InmateLoot", "InmateType", "InteractionGoal", "InteractionGoalBase",
                    "InteractionSystem", "Interest", "InterestTopic", "Inventory", "InventorySlot", "ItemBase",
                    "ItemCategory", "ItemState", "ItemTag", "JiggleBone", "JunkieLoot", "Lactation", "LightInventory",
                    "LimbTypes", "Log", "LootList", "LootTableBase", "LoseEarlyAI", "LustAction", "LustActivity",
                    "LustCombatState", "LustFocus", "LustInterests", "MainScene", "MapDecoration", "MedicalLoot",
                    "MedicalModule", "MenstrualCycle", "MeshInstanceWithPattern", "MicrosoftTranslator",
                    "MinigameResult", "ModEntry", "Module", "MyBoneAttachment", "MyProfiler", "MyProfilerBase",
                    "MyProjectSettings", "NOET", "NOM", "NakedSlaveGenerator", "NemesisReason", "NetworkedComputerBase",
                    "NovaModule", "NpcBreakTaskBase", "NpcCon", "NpcEnslavementQuest", "NpcFinder", "NpcGen",
                    "NpcGender", "NpcOwnerActionType", "NpcOwnerBase", "NpcOwnerEventBase", "NpcOwnerEventRunner",
                    "NpcOwnerSexLimits", "NpcOwnerTraitBase", "NpcRank", "NpcSlave", "NpcTaskPool", "NurseGenerator",
                    "NurseryTaskBase", "Orifice", "OrificeType", "OverriddenPlayer", "PantiesState", "PapagoTranslate",
                    "PartOrient", "PartOrientPicker", "PartSkinBase", "PartState", "PartStatePicker", "PartTrait",
                    "PawnInteractionBase", "PawnReactions", "PawnTypeBase", "Perk", "PerkBase", "Personality",
                    "PersonalityStat", "PickupLineDB", "Player", "PlayerSlaveryBase", "PlayerSlaveryDef",
                    "PlayerSlaveryHolder", "PunishmentsModule", "Quest", "QuestBase", "QuestSystem", "RNG", "RNGData",
                    "RahiModule", "RelationshipEntry", "RelationshipSystem", "RepStat", "RepStatBase", "Reputation",
                    "ReputationPlaceholder", "RestraintBallGag", "RestraintBlindfold", "RestraintButtplug",
                    "RestraintChastityCage", "RestraintData", "RestraintHandCuffs", "RestraintHypnovisor",
                    "RestraintLegCuffs", "RestraintMittens", "RestraintMuzzle", "RestraintRingGag",
                    "RestraintRopeHarness", "RestraintSlaveCollar", "RestraintStocks", "RestraintStraitjacket",
                    "RestraintType", "RestraintUnremovable", "RestraintVaginalplug", "Rollbacker", "RoomAction",
                    "RoomStuff", "SaveConversion", "SayParser", "SceneBase", "Science", "SensitiveZone",
                    "SexActIntensity", "SexActivityBase", "SexActivityTag", "SexDomInfo", "SexEngine",
                    "SexEngineResult", "SexEngineResultDom", "SexEngineResultSub", "SexEvent", "SexEventHelper",
                    "SexGoal", "SexGoalBase", "SexInfoBase", "SexMod", "SexReaction", "SexReactionHandler", "SexStance",
                    "SexSubInfo", "SexType", "SexTypeBase", "SexVoice", "ShirtAndShortsState", "SimpleParser",
                    "SimpleStringInterpolator", "Skill", "SkillBase", "SkillsHolder", "SkinBase", "SkinType",
                    "SlaveActionBase", "SlaveActivityBase", "SlaveAuction", "SlaveAuctionBidders", "SlaveEventBase",
                    "SlaveType", "SlaveTypeBase", "SmartLock", "SmartLockBase", "SocialEventType",
                    "SpecialRelationshipBase", "Species", "SpeciesCompatibility", "SpeechModifierBase", "Stage3D",
                    "StageScene", "Stat", "StatBase", "StatusEffect", "StatusEffectBase", "StatusEffectsPanel",
                    "SubGameWorld", "TFBase", "TFEffect", "TFHolder", "TFResult", "TFUtil", "TaviModule", "TestQuest",
                    "TestResource", "TextureRectLayered", "ThroatOrifice", "TopicBase", "TranslationLanguage",
                    "TranslatorBase", "Trigger", "UniqueOrgasm", "Util", "VaginaOrifice", "WHCond", "WHEvent",
                    "WorldEditBase", "WorldFloor", "WorldHistory", "WorldHistoryEvent", "WorldPopulation", "WorldZone",
                    "WritingZoneInfoNode", "WritingsHandler"]
game_globals_names = ["PortableModeDetector", "Console", "OPTIONS", "GlobalRegistry", "GM", "SAVE", "GlobalTooltip",
                      "AutoTranslation", "CrotchFavBlocks", "ModularDialogue"]
game_modules_names = ["AcePregExpac", "AlexRynardModule", "ArticaModule", "CellblockModule", "DrugDenModule",
                      "ElizaModule", "FightClubModule", "GymModule", "HypnokinkModule", "JackiModule", "MedicalModule",
                      "NovaModule", "NpcSlaveryModule", "PlayerSlaveryModule", "PortalPantiesModule",
                      "PunishmentsModule", "RahiModule", "SlaveAuctionModule", "SocketModule", "TaviModule"]
# </editor-fold>

tool_version = "0.10.2"
expect_foxlib_version = "0.10.2"
expect_foxlib_version_alt = expect_foxlib_version + "-dev"
debug_foxlib_semver = [0, 2, 0]
debug_foxlib_version = "0.2.0"
verify_foxlib_semver = [0, 4, 0]
verify_foxlib_version = "0.4.0"
game_test_foxlib_semver = [0, 7, 0]
game_test_foxlib_version = "0.7.0"
foxlib_scene_semver = [0, 8, 0]
foxlib_scene_version = "0.8.0"
foxlib_foxlib_semver = [0, 4, 0]
foxlib_foxlib_version = "0.4.0"
valid_source_modes = ["raw", "parsed", "processed", "trimmed"]  # FLMH_source_mode (Default: "processed")
valid_definition_mode = ["none", "standard", "extended"]  # FLMH_definition_mode (Default: "standard")
valid_foxlib_verify_mode = ["auto", "none", "verify"]  # FLMH_foxlib_verify_mode (Default: "auto")
valid_run_game_test_on = ["never", "test"]  # FLMH_run_game_test_on (Default: "never")
valid_mod_menu_display = ["vanilla", "simple"]  # FLMH_mod_menu_display (Default: "vanilla")

rahi_json_entry_index_order = ["name", "description", "author", "modversion", "gameversion"]

macro_to_property = {
    "mod_name": "name",
    "mod_description": "description",
    "mod_author": "author",
    "mod_version": "modversion",
    "game_version": "gameversion",
    "source_mode": "FLMH_source_mode",
    "definition_mode": "FLMH_definition_mode",
    "foxlib_verify_mode": "FLMH_foxlib_verify_mode",
    "run_game_test_on": "FLMH_run_game_test_on",
    "rahi_changelog": "FLMH_rahi_changelog",
    "rahi_preview": "FLMH_rahi_preview",
}
macro_to_default = {
    "source_mode": "processed",
    "definition_mode": "standard",
    "foxlib_verify_mode": "auto",
    "run_game_test_on": "never",
}

foxlib_known_debuggable = ["FoxLib/FoxCrotchBlock.gd", "FoxLib/FoxScene.gd", "FoxLib/FoxModule.gd"]
foxlib_modules_names = ["FoxLib", "FoxLibVerifier", "FoxLibAutoInstaller"""]
reserved_mod_names = ["BDCC", "FoxLib", "FoxLibVerifier", "FoxLibAutoInstaller"]
source_paths_default = [".import", "Docs", "Events", "FoxLib", "Modules", "Player", "Scenes"]
required_keys = ["description", "author", "modversion", "gameversion"]
str_digits = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
reserved_keywords = ["", "extends", "class", "class_name", "func", "static", "var", "const", "self", "null"]
conditions_keywords = ["if", "while", "for", "in", "and", "or", "+", "-", "*", "/", "&&", "||", "!", "<", ">"]
platforms_ids = {"Linux": "linux", "Darwin": "mac", "Windows": "windows", }
platform_id = platforms_ids.get(platform.system()) or None
main_game_mode = os.path.exists("GlobalRegistry.gd") and os.path.exists("Modules")
definitions_files = []
definitions = {}
const_imports = {}

source_paths = []
debuggable = {}
imports = {}
mod_definitions = {}
mod_debuggable = {}
public_mod_definitions = {}
public_mod_debuggable = {}
public_mod_imports = {}
mod_godot_files = {}
modInfo = ""
modBaseName = ""
modInfoDict = {}
modHideSuffix = ""
modSemver = ""
modExtendsFoxLib = False
possible_commands = []
terminal_title_cache = ""
git_path = ""
godot_editor_path = ""

EXT_FOXLIB_DEF = ".fldef"
MACRO_PREFIX = "%FLMH_"
MACRO_PREFIX_LEN = len(MACRO_PREFIX)
ENV_GAME_TEST_FOXLIB = "FoxLibGameTest"

ansi_reset = ""
ansi_yellow = ""
ansi_green = ""
ansi_cyan = ""
ansi_red = ""
ansi_bold = ""
if sys.stdout.isatty():
    ansi_reset = "\033[0m"
    ansi_yellow = "\033[0;33;93m"
    ansi_green = "\033[0;32;92m"
    ansi_cyan = "\033[0;36m"
    ansi_red = "\033[0;31m"
    ansi_bold = "\033[1m"
    if platform_id == "windows" and colorama is None:
        kernel32 = __import__("ctypes").windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        del kernel32

FLMH_COLOR_PREFIX = ansi_cyan + ansi_bold + "FLMH"
FLMH_ERR = ansi_red + "[" + FLMH_COLOR_PREFIX + ansi_red + "] "
FLMH_WARN = ansi_yellow + "[" + FLMH_COLOR_PREFIX + ansi_yellow + "] "
FLMH_LOG = ansi_reset + "[" + FLMH_COLOR_PREFIX + ansi_reset + "] "
FLMH_FINE = ansi_green + ansi_bold + "[" + FLMH_COLOR_PREFIX + ansi_green + ansi_bold + "] "
FLMH_DEBUG = FLMH_LOG + ansi_bold + "DEBUG: " + ansi_reset
FLMH_CLI = ansi_reset + "[" + FLMH_COLOR_PREFIX + ansi_reset + "] > " + ansi_reset
FLMH_END = ansi_reset

libFoxLibPath = ""
libFoxLibVersion = ""
libFoxLibSemver = [0, 0, 0]
libFoxLibImportRoot = False

# Modding by moving this script into Godot project isn't something I'll recommend, but I'll try to support it
foxlib_import_debug = []
foxlib_verifier_path = "Modules/FoxLibVerifier/PreInit.gd"
foxlib_paths_unix = ["Docs", "FoxLib", "Modules/FoxLib", "Modules/FoxLibVerifier"]
foxlib_paths_win32 = ["Docs", "FoxLib", "Modules\\FoxLib", "Modules\\FoxLibVerifier"]
foxlib_paths = foxlib_paths_win32 if platform_id == "windows" else foxlib_paths_unix

desc_separator_warn = ("[center][img=128x64]Images/WorldTiles/TrimCaution.png[/img]" +
                       "[img=128x64]Images/WorldTiles/TrimCaution.png[/img]" +
                       "[img=128x64]Images/WorldTiles/TrimCaution.png[/img]" +
                       "[img=128x64]Images/WorldTiles/TrimCaution.png[/img]" +
                       "[img=128x64]Images/WorldTiles/TrimCaution.png[/img]" +
                       "[img=128x64]Images/WorldTiles/TrimCaution.png[/img][/center]")


class CompileError(OSError):
    pass


def terminal_set_console_title(title):
    global terminal_title_cache
    if terminal_title_cache == title:
        return
    terminal_title_cache = title
    if platform_id == "windows":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleTitleW(title)
            return
        except AttributeError or ImportError:
            pass
    if len(ansi_reset) > 0:
        print("\033]2;" + title + "\007", end="")


def print_err(message):
    print(FLMH_ERR + message + FLMH_END)


def print_warn(message):
    print(FLMH_WARN + message + FLMH_END)


def print_log(message):
    print(FLMH_LOG + message + FLMH_END)


def print_fine(message):
    print(FLMH_FINE + message + FLMH_END)


def print_dbg(message):
    print(FLMH_DEBUG + message + FLMH_END)


def error_to_string(error: Exception):
    return " ".join(error.args)


def print_raised(error: Exception):
    print_err(error_to_string(error))


def add_if_missing(input_list: list, element):
    if element not in input_list:
        input_list.append(element)


def delete_recursively(file):
    if os.path.isdir(file):
        shutil.rmtree(file)
    elif os.path.exists(file):
        os.remove(file)


def strip_line_or_error(line: str) -> str:
    line = line.strip()
    if line.find('\n') != -1:
        raise CompileError("Cannot strip \"" + line + "\"")
    return line


def digit_ify(text: str) -> str:
    str_index = 0
    str_len = len(text)
    if str_len == 0 or text.isdigit():
        return text
    while str_index < str_len and text[str_index].isdigit():
        str_index += 1
    if str_index == 0:
        return text
    return text[0:str_index]


def semver_str(version: str):
    version = version.split('-', 1)[0]
    entries = version.split('.')
    if len(entries) < 2 or not entries[0].isdigit() or not entries[1].isdigit():
        return [0, 0, 0]
    if len(entries) > 2:
        entries[2] = digit_ify(entries[2])
    if len(entries) == 2 or not entries[2].isdigit():
        return [int(entries[0]), int(entries[1]), 0]
    return [int(entries[0]), int(entries[1]), int(entries[2])]


def str_semver(semver):
    return str(semver[0]) + "." + str(semver[1]) + "." + str(semver[2])


def compare_int(int1, int2):
    return 1 if int1 < int2 else -1 if int1 > int1 else 0


def compare_semver(semver1, semver2):
    if semver1[0] != semver2[0]:
        return compare_int(semver1[0], semver2[0])
    if semver1[1] != semver2[1]:
        return compare_int(semver1[1], semver2[1])
    return compare_int(semver1[2], semver2[2])


def optionally_remove(obj, key):
    if key in obj:
        obj.remove(key)


def escape_to_gd_string_raw(string: str):
    return (string.replace("\\", "\\\\")
            .replace("\"", "\\\"").replace("\n", "\\n"))


def escape_to_gd_string(string: str):
    return "\"" + escape_to_gd_string_raw(string) + "\""


def escape_to_gd_string_with_code(string: str):
    next_var = string.find("${")
    next_var_end = string.find("}", next_var + 1)
    if next_var == -1 or next_var_end == -1:
        return "\"" + escape_to_gd_string_raw(string) + "\""
    last_text_cutoff = 0
    text_buffer = "\""
    while next_var != -1 and next_var_end != -1:
        next_var_invalidate_space = string.find(" ", next_var + 1)
        next_var_invalidate_newline = string.find("\n", next_var + 1)
        next_var_invalidate_new_value = string.find("${", next_var + 1)
        if ((next_var_invalidate_space != -1 and next_var_invalidate_space < next_var_end) or
                (next_var_invalidate_newline != -1 and next_var_invalidate_newline < next_var_end) or
                (next_var_invalidate_new_value != -1 and next_var_invalidate_new_value < next_var_end) or
                (next_var + 2 == next_var_end)):
            next_var = string.find("${", next_var + 1)
            next_var_end = string.find("}", next_var + 1)
            continue
        text_buffer += escape_to_gd_string_raw(string[last_text_cutoff:next_var])
        text_buffer += "\" + "
        text_buffer += string[next_var + 2:next_var_end]
        text_buffer += " + \""
        last_text_cutoff = next_var_end + 1
        next_var = string.find("${", next_var_end + 1)
        next_var_end = string.find("}", next_var + 1)

    return text_buffer + escape_to_gd_string_raw(string[last_text_cutoff:]) + "\""


def parse_properties(f, keys, on_ext=None):
    def parse_line(line):
        line = strip_line_or_error(line)
        if line.startswith("#"):
            if on_ext is not None:
                on_ext(line)
        elif "=" in line:
            name, value = line.split("=", 1)
            keys[strip_line_or_error(name)] = strip_line_or_error(value)
        else:
            if on_ext is not None:
                on_ext(line)

    if isinstance(f, str):
        for _line in f.splitlines():
            parse_line(_line)
    else:
        for _line in f:
            parse_line(_line)


def read_properties_file(file, keys=None, on_ext=None):
    if keys is None:
        keys = {}
    with open(file) as f:
        parse_properties(keys, f, on_ext)
    return keys


def parse_definitions(f, definitions_target=None, include_private=False, debug_classes=None, cls_imports=None):
    if definitions_target is None:
        definitions_target = definitions
        debug_classes = debuggable
        cls_imports = imports

    def ext_parse(line):
        line = str(line)
        if line.startswith("#private_map ") and include_private:
            name, value = line[13:].split("=", 1)
            definitions_target[strip_line_or_error(name)] = strip_line_or_error(value)
        elif line.startswith("#imports ") and cls_imports is not None:
            name, value = line[13:].split("=", 1)
            cls_imports[strip_line_or_error(name)] = strip_line_or_error(value).split(",")
        elif line.startswith("#dbg ") and debug_classes is not None:
            debug_classes[line[5:]] = True

    parse_properties(f, definitions_target, ext_parse)


def read_definitions_file(file, definitions_target=None, include_private=False, debug_classes=None):
    with open(file) as f:
        parse_definitions(f, definitions_target, include_private, debug_classes)


def read_definitions_from_mod_file(file_path, definition_entry_base, definitions_target=None, include_private=False):
    definition_entry = definition_entry_base + EXT_FOXLIB_DEF
    mod_info_entry = definition_entry_base + ".json"
    with zipfile.ZipFile(file_path, mode="r") as mod_archive:
        all_entries = [member.filename for member in mod_archive.infolist()]
        if definition_entry in all_entries:
            parse_definitions(mod_archive.read(definition_entry).decode("utf-8"), definitions_target, include_private)
        elif mod_info_entry not in all_entries:
            print_warn("The file " + definition_entry_base + ".zip doesn't look like a BDCC mod")
            if definition_entry_base.startswith("FoxLib_v"):
                print_err("Please check the file name as without the correct file name FoxLib cannot be parsed")
                print_err("properly and this may results in some FoxLib ModHelper features being unavailable.")
            else:
                print_warn("Please check that it's file name is the same as it's original mod file name")
        elif definition_entry_base.startswith("FoxLib_v"):
            print_warn("FoxLib ModHelper requires at least FoxLib v0.2.0 to properly work.")


def can_convert_wav_to_ogg():
    return AudioSegment is not None or ffmpeg is not None


def convert_wav_to_ogg(from_path: str, to_path: str):
    if AudioSegment is not None:
        sound = AudioSegment.from_wav(from_path)
        sound.export(to_path, format="ogg")
    elif ffmpeg is not None:
        (ffmpeg.input(from_path, format='wav')
         .output(to_path, format='ogg', acodec='libvorbis', loglevel='quiet', hide_banner=None).run())
    else:
        raise OSError("Unable to convert wav into ogg due to both pydub and ffmpeg-python being missing")


def get_game_data_path():
    if platform_id is None:
        raise OSError("Getting game data path is not supported on this platform: " + platform.system())
    if platform_id == "windows":
        return os.path.join(os.getenv("APPDATA"), "Godot\\app_userdata\\BDCC")
    elif platform_id == "mac":
        return os.path.expanduser("~/Library/Application Support/Godot/app_userdata/BDCC")
    else:  # Assume Linux or unix like
        return os.path.expanduser("~/.local/share/godot/app_userdata/BDCC")


def init_common(error_backlog: list):
    global main_game_mode, source_paths, modInfoDict, modBaseName, modInfo, modSemver, modHideSuffix, \
        libFoxLibPath, libFoxLibVersion, libFoxLibSemver, libFoxLibImportRoot, godot_editor_path
    # "/usr/lib/godot3-bin/Godot_v3.6-stable_x11.64"
    source_paths = source_paths_default
    modInfo = None
    modBaseName = os.path.basename(os.path.realpath(os.getcwd()))
    modSemver = [0, 0, 0]
    modHideSuffix = ""

    libFoxLibPath = None
    libFoxLibVersion = None
    libFoxLibSemver = [0, 0, 0]
    libFoxLibImportRoot = False
    definitions.clear()
    debuggable.clear()
    mod_definitions.clear()
    mod_debuggable.clear()
    public_mod_definitions.clear()
    public_mod_debuggable.clear()
    godot_editor_path = ""
    if os.path.exists("/usr/lib/godot3-bin"):
        for file_name in os.listdir("/usr/lib/godot3-bin"):
            full_path = "/usr/lib/godot3-bin/" + file_name
            if file_name.startswith("Godot_v3.") and file_name.endswith(".64") and os.path.isfile(full_path):
                godot_editor_path = full_path
    main_game_mode = os.path.exists("GlobalRegistry.gd") and os.path.exists("Modules")
    for rf in os.listdir("."):
        if rf.endswith(".json") and rf != "DonationInfo.json" and not rf.endswith(".rahi.json"):
            if modInfo is not None:
                # Compute FoxLib even if we have an error.
                error_backlog.append("Multiple mod infos detected, found " + modInfo + " and " + rf)
            else:
                modInfo = rf
        elif (rf.startswith("FoxLib_v") and rf.endswith(".zip") and
              "(" not in rf and not os.path.exists("FoxLib.json")):
            libFoxLibPath = os.path.abspath(rf)
            libFoxLibVersion = rf[8:-4]
            libFoxLibImportRoot = True
        # FoxLib Definitions
        if rf.endswith(EXT_FOXLIB_DEF):
            definitions_files.append(rf)

    if modInfo is not None:
        modBaseName = modInfo[:-5]

    if modBaseName != "FoxLib":
        for known_debuggable in foxlib_known_debuggable:
            debuggable[known_debuggable] = False

    if os.path.isdir("libs"):
        for lf in os.listdir("libs"):
            if lf.endswith(EXT_FOXLIB_DEF):
                definitions_files.append(os.path.join("libs", lf))
            elif lf.startswith("FoxLib_v") and lf.endswith(".zip") and "(" not in lf:
                libFoxLibPath = os.path.abspath(os.path.join("libs", lf))
                libFoxLibVersion = lf[8:-4]
                libFoxLibImportRoot = False
    # Compute FoxLib even if we have an error.
    if len(error_backlog) != 0:
        return
    try_generate_module_path_tmp = None
    if modInfo is None:
        module_dir_gen_tmp = os.path.join("Modules", modBaseName)
        if modBaseName in reserved_mod_names or main_game_mode or os.path.isfile(module_dir_gen_tmp):
            error_backlog.append("Cannot auto generate mod info json")
            return
        modInfo = modBaseName + ".json"
        with open(modInfo, 'w') as f:
            f.write("{\n")
            f.write("\t\"name\": \"" + modBaseName + "\",\n")
            f.write("\t\"description\": \"Insert description here\",\n")
            f.write("\t\"author\": \"Insert your name here\",\n")
            f.write("\t\"modversion\": \"0.0.1\",\n")
            f.write("\t\"gameversion\": \"*\"\n")
            f.write("}\n")
        if not os.path.isdir(module_dir_gen_tmp):
            os.makedirs(module_dir_gen_tmp)
            try_generate_module_path_tmp = os.path.join(module_dir_gen_tmp, "Module.gd")

    # In main game mode, check modules for bundling.
    if main_game_mode:
        source_paths = []
        for module in os.listdir("Modules"):
            if module not in game_modules_names and module not in foxlib_modules_names:
                source_paths.append(os.path.join("Modules", module))

    # Ignore FoxLib lib when building FoxLib
    if modBaseName == "FoxLib":
        libFoxLibPath = None
        libFoxLibVersion = None
        libFoxLibImportRoot = False
    use_game_data_foxlib = False
    if libFoxLibPath is None and modBaseName != "FoxLib":
        if platform_id is not None:
            game_data_path = get_game_data_path()
            game_foxlib_path = os.path.join(
                os.path.join(game_data_path, "mods"),
                "FoxLib_v" + expect_foxlib_version + ".zip")
            game_foxlib_path_alt = os.path.join(
                os.path.join(game_data_path, "mods"),
                "FoxLib_v" + expect_foxlib_version_alt + ".zip")
            if os.path.isfile(game_foxlib_path):
                libFoxLibPath = game_foxlib_path
                libFoxLibVersion = expect_foxlib_version
                libFoxLibImportRoot = True
                use_game_data_foxlib = True
            elif os.path.isfile(game_foxlib_path_alt):
                libFoxLibPath = game_foxlib_path_alt
                libFoxLibVersion = expect_foxlib_version_alt
                libFoxLibImportRoot = True
                use_game_data_foxlib = True
        if libFoxLibPath is None:
            print_warn("FoxLib was not found as a library")
    for definitions_file in definitions_files:
        read_definitions_file(definitions_file)
    if os.path.isdir("libs"):
        for f in os.listdir("libs"):
            if f.endswith(".zip"):
                read_definitions_from_mod_file(  # Read definitions of mods zip files
                    os.path.join("libs", f), f[:-4])
    if libFoxLibImportRoot and modBaseName != "FoxLib":
        read_definitions_from_mod_file(libFoxLibPath, "FoxLib_v" + libFoxLibVersion)
    with open(modInfo, 'r') as modInfoFile:
        modInfoDict = json.load(modInfoFile)
    modSemver = semver_str(modInfoDict["modversion"])
    if modBaseName == "FoxLib":
        libFoxLibSemver = modSemver
    elif libFoxLibVersion is not None:
        libFoxLibSemver = semver_str(libFoxLibVersion)
    if try_generate_module_path_tmp is not None:
        with open(try_generate_module_path_tmp, 'w') as f:
            if use_game_data_foxlib or compare_semver(debug_foxlib_semver, libFoxLibSemver) < 0:
                f.write("extends \"res://FoxLib/FoxModule.gd\"\n")
            else:
                f.write("extends FoxModule\n")
            f.write("\n")
            f.write("var myCoolModOption = true\n")
            f.write("\n")
            f.write("func _init():\n")
            f.write("\tid = \"" + modBaseName + "\"\n")
            f.write("\tname = \"" + modBaseName + " v%FLMH_mod_version%\"\n")
            f.write("\tauthor = \"Insert your name here\"\n")
            f.write("\taddBooleanOption(\"myCoolModOption\", \"My cool mod option!\",\n")
            f.write("\t\t\"This is a very cool mod option!\", true)\n")
            f.write("\n")
            f.write("func preInit():\n")
            f.write("\tpass\n")
            f.write("\n")
            f.write("func postInit():\n")
            f.write("\tpass\n")

    # This is quite forward in the code, but we need to update tab complete on init call.
    update_cli_tab_completer()
    return


def init():
    error_backlog = []
    init_common(error_backlog)
    for error in error_backlog:
        print_err(error)


# Parse godot files to map their names as paths
def parse_gd_first_pass(file, path, file_name):
    global modExtendsFoxLib
    name = None
    is_public = False
    is_debuggable = False
    is_soft_debuggable = False
    line_number = 0
    file_warnings = []
    script_preload_imports = []
    allow_code_scan = True
    with open(file) as f:
        for line in f:
            line = line.strip()
            line_number += 1
            if line == "#private_api":
                is_public = False
            elif line == "#public_api":
                is_public = True
            # Strip comments during parse
            if "#" in line:
                line = line[:line.find('#')].strip()
            if line.startswith("class_name "):
                if name is not None:
                    raise CompileError("File " + path + " has registered a name twice")
                name = line[11:].strip()
                if MACRO_PREFIX in name:
                    raise CompileError("Cannot use preprocessor macro in class_name, but used in " + path)
                elif name in reserved_keywords:
                    raise CompileError("Name " + name + " is a reserved keyword but requested by " + path)
                elif name in godot_class_names:
                    raise CompileError("Name " + name + " is already in use by Godot but is requested by " + path +
                                       " (Did you mean to call \"extends " + name + "\" instead?)")
                elif name in game_class_names:
                    raise CompileError("Name " + name + " is already in use by BDCC but is requested by " + path +
                                       " (Did you mean to call \"extends " + name + "\" instead?)")
                elif name in mod_definitions:
                    raise CompileError("Name " + name + " is defined twice at " +
                                       mod_definitions[name] + " and at " + path)
                else:
                    mod_definitions[name] = path
                    definitions[name] = path
            elif line.startswith("extends "):
                if "#" in line:
                    extends = line[8:line.find('#')].strip()
                else:
                    extends = line[8:].strip()
                if MACRO_PREFIX in extends:
                    raise CompileError("Cannot use preprocessor macro in extends, but used in " + path)
                if ((extends.startswith("\"") and extends.endswith("\"")) or
                        (extends.startswith("\'") and extends.endswith("\'"))):
                    extends_file = extends[1:-1]
                else:
                    extends_file = definitions.get(extends)
                debuggable_status = None
                if extends_file is not None and extends_file.startswith("res://FoxLib/"):
                    modExtendsFoxLib = True
                if extends_file is not None and extends_file.startswith("res://"):
                    debuggable_status = debuggable.get(extends_file[6:])
                if debuggable_status is not None:
                    is_debuggable = True
            elif line.startswith("#foxlib_scene ") or line == "#foxlib_scene":
                if compare_semver(foxlib_scene_semver, libFoxLibSemver) < 0:
                    raise CompileError("Need at least FoxLib " + foxlib_scene_version + " to use \"#foxlib_scene\"")
                modExtendsFoxLib = True
                allow_code_scan = False
                is_debuggable = True
            elif allow_code_scan and line.startswith("const "):
                preload_index = line.find(" = preload(\"res://")
                if preload_index != -1:
                    import_name = line[6:preload_index]
                    if import_name in godot_class_names:
                        file_warnings.append(
                            "import " + import_name + " is already covered by Godot. (Line " + str(line_number) + ")")
                    elif import_name in game_class_names:
                        file_warnings.append(
                            "import " + import_name + " is already covered by BDCC. (Line " + str(line_number) + ")")
                    if import_name == "FLMHDebug":
                        is_soft_debuggable = True
                    script_preload_imports.append(import_name)
            elif ((line.startswith("static func ") or line.startswith("func ")) and
                  allow_code_scan and (":" not in line)):
                raise CompileError("File " + path + " missing \":\" at line " +
                                   str(line_number) + " in \"" + line + "\"")
            elif ((line.startswith("for ") or line.startswith("if ") or
                   line.startswith("elif ") or line.startswith("else ")) and
                  ("(" not in line) and allow_code_scan and (":" not in line)):
                raise CompileError("File " + path + " missing \":\" at line " +
                                   str(line_number) + " in \"" + line + "\"")
    if is_public and name is not None:
        public_mod_definitions[name] = path
    if name is not None and name != file_name[:-3]:
        file_warnings.append("\"class_name\" of " + file_name + " is " + name + " which doesn't match it's file name.")
    if is_soft_debuggable and is_debuggable:
        raise CompileError("File " + path + " imported FLMHDebug while it's parent imported FLMHDebug too.")
    mod_godot_files[path] = True
    if is_soft_debuggable:
        if is_public:
            public_mod_debuggable[path] = False
        mod_debuggable[path] = False
        debuggable[path] = False
    if is_debuggable:
        if is_public:
            public_mod_debuggable[path] = True
        mod_debuggable[path] = True
        debuggable[path] = True
    if len(file_warnings) > 0:
        print_warn("Warnings for: " + ansi_bold + path)
        for file_warning in file_warnings:
            print_warn(file_warning)
    if len(script_preload_imports) > 0:
        imports[path] = script_preload_imports
        if is_public:
            public_mod_imports[path] = script_preload_imports


def parse_gd_second_pass(file, path):
    line_number = 0
    with open(file) as f:
        for line in f:
            line = line.strip()
            line_number += 1
            if line.startswith("#import "):
                statement = line[8:].strip()
                as_type_index = statement.find(" as ")
                if as_type_index == -1:
                    import_type = statement
                else:
                    import_type = statement[:as_type_index].strip()
                type_file = definitions[type]
                if type_file is None:
                    raise CompileError("File " + path + " tried to import " + import_type +
                                       " but it was not found in the project path (Line " + str(line_number) + ")")
                if type_file == path:
                    raise CompileError("File " + path + " tried to import itself (Line " + str(line_number) + ")")


def parse_gd_recursively(file: str, path: str, second_pass: bool, error_backlog: list, suggestion_backlog: list):
    for f in os.listdir(file):
        child_file = os.path.join(file, f)
        child_path = path + "/" + f
        if os.path.isdir(child_file):
            parse_gd_recursively(child_file, child_path, second_pass, error_backlog, suggestion_backlog)
        elif child_path.endswith(".gd"):
            try:
                if second_pass:
                    parse_gd_second_pass(child_file, child_path)
                else:
                    parse_gd_first_pass(child_file, child_path, f)
            except CompileError as e:
                error_backlog.append(error_to_string(e))
        elif child_path.endswith(".wav") and not second_pass and not os.path.exists(child_path + ".import"):
            print_warn(".wav files from mods can't be loaded by godot! \"" + child_path + "\"")
            add_if_missing(suggestion_backlog,
                           ".wav files can be converted into .ogg with the \"wav-to-ogg\" task")


def check_common(error_backlog: list, suggestion_backlog: list):
    global source_paths, modInfoDict, modInfo, modExtendsFoxLib, libFoxLibSemver
    init_common(error_backlog)
    if len(error_backlog) != 0:
        return
    if len(source_paths) == 0:
        error_backlog.append("No source paths found, FLMH is unable to detect your extra module folder.")
        return
    modExtendsFoxLib = False
    err_msg = "Missing required fields in " + str(modInfo) + ": "
    do_err = False
    for f in required_keys:
        if f not in modInfoDict:
            err_msg = err_msg + f + ", "
            do_err = True
    if do_err:
        raise CompileError(err_msg[:-2])
    mod_description_tmp = modInfoDict.get("description")
    if mod_description_tmp.startswith("file:"):
        mod_description_file = mod_description_tmp[5:]
        if not os.path.isfile(mod_description_file):
            raise CompileError("Description want a file, but " + mod_description_file + " is missing")
    source_mode = modInfoDict.get("FLMH_source_mode")
    if source_mode is not None and source_mode not in valid_source_modes:
        raise CompileError("Detected invalid FLMH_source_mode: " + source_mode)
    definition_mode = modInfoDict.get("FLMH_definition_mode")
    if definition_mode is not None and definition_mode not in valid_definition_mode:
        raise CompileError("Detected invalid FLMH_definition_mode: " + definition_mode)
    foxlib_verify_mode = modInfoDict.get("FLMH_foxlib_verify_mode")
    if foxlib_verify_mode is not None and foxlib_verify_mode not in valid_foxlib_verify_mode:
        raise CompileError("Detected invalid FLMH_foxlib_verify_mode: " + foxlib_verify_mode)
    if foxlib_verify_mode == "verify" and compare_semver(verify_foxlib_semver, libFoxLibSemver) < 0:
        raise CompileError("Verify mode was forced on, but it require at least FoxLib " +
                           verify_foxlib_version + " or later")
    run_game_test_on = modInfoDict.get("FLMH_run_game_test_on")
    if run_game_test_on is not None and run_game_test_on not in valid_run_game_test_on:
        raise CompileError("Detected invalid FLMH_run_game_test_on: " + run_game_test_on)
    rahi_changelog = modInfoDict.get("FLMH_rahi_changelog")
    if rahi_changelog is not None and not os.path.isfile(rahi_changelog):
        raise CompileError("FLMH_rahi_changelog must point to a valid file.")
    mod_menu_display = modInfoDict.get("FLMH_mod_menu_display")
    if mod_menu_display is not None and mod_menu_display not in valid_mod_menu_display:
        raise CompileError("Detected invalid FLMH_mod_menu_display: " + mod_menu_display)
    # FoxLib ModHelper will always expect a matching FoxLib version.
    if (modBaseName == "FoxLib" and expect_foxlib_version != modInfoDict["modversion"] and
            expect_foxlib_version_alt != modInfoDict["modversion"]):
        print_warn("Expecting FoxLib version " + expect_foxlib_version +
                   " but building FoxLib " + modInfoDict["modversion"])
    for source_path in source_paths:
        source_file = os.path.abspath(os.path.join(".", source_path))
        if os.path.isdir(source_file):
            parse_gd_recursively(source_file, source_path, False, error_backlog, suggestion_backlog)


def check():
    error_backlog = []
    suggestion_backlog = []
    try:
        check_common(error_backlog, suggestion_backlog)
        if len(error_backlog) == 0 and modInfoDict.get("FLMH_source_mode") != "raw":
            for source_path in source_paths:
                source_file = os.path.abspath(os.path.join(".", source_path))
                if os.path.isdir(source_file):
                    parse_gd_recursively(source_file, source_path, True, error_backlog, suggestion_backlog)
    except CompileError as err:
        error_backlog.append(error_to_string(err))

    if len(error_backlog) == 0:
        for suggestion in suggestion_backlog:
            print_warn(suggestion)

        print_fine("No class naming errors found during source code checking!")
    else:
        for error in error_backlog:
            print_err(error)

        for suggestion in suggestion_backlog:
            print_warn(suggestion)


def resolve_macro(macro: str, path: str):
    global modInfoDict, modSemver
    if macro == "current_path":
        return path
    if macro == "mod_version_major":
        return str(modSemver[0])
    if macro == "mod_version_minor":
        return str(modSemver[1])
    if macro == "mod_version_patch":
        return str(modSemver[2])
    macro_property = macro_to_property.get(macro) or None
    if macro_property is not None:
        return modInfoDict[macro_property] or macro_to_default[macro] or ""
    return "null"


def apply_macros(line: str, path: str, line_number):
    find_index_start = line.find(MACRO_PREFIX)
    if find_index_start == -1:
        return line
    string_append_index = 0
    buffer = ""
    while find_index_start != -1:
        find_index_end = line.find("%", find_index_start + 1)
        if find_index_end == -1:
            raise CompileError("Unfinished line macro \"" + line[find_index_start:].strip() +
                               "\" at line " + str(line_number) + " in " + path)
        raw_macro = line[find_index_start + MACRO_PREFIX_LEN:find_index_end]
        if "#" in raw_macro:
            raise CompileError("Comments not allowed in macros at line " + str(line_number) + " in " + path)
        solved_macro = resolve_macro(raw_macro, path)
        buffer = buffer + line[string_append_index:find_index_start] + solved_macro
        string_append_index = find_index_end + 1
        find_index_start = line.find(MACRO_PREFIX, string_append_index)
    buffer = buffer + line[string_append_index:]
    return buffer


def find_out_of_string(text, find_char, starting_index=None, check_last=False):
    debug_algo = False
    found_index = 0
    find_increment = 1
    itr_text = text
    if check_last:
        if starting_index is not None:
            starting_index = len(text) - starting_index
        found_index = len(text) - 1
        find_increment = -1
        itr_text = reversed(text)
    if starting_index is None:
        starting_index = 0
    if max(starting_index, 0) >= len(text):
        return -1
    can_see = True
    text_char = '\"'
    for c in itr_text:
        if can_see:
            if c == '\"' or c == '\'':
                can_see = False
                text_char = c
            if c == find_char and debug_algo:
                print_dbg("Found " + find_char + " at " + str(found_index) +
                          " " + text[found_index - 1:found_index + 2] + " " + str(check_last) +
                          " | " + str(starting_index))
            if c == find_char and starting_index <= 0:
                return found_index
        else:
            if c == text_char and debug_algo:
                print_warn("Tex: " + text + " -> " + text[found_index - 2:found_index + 1] +
                           " " + str(found_index) + "/" + str(len(text)) + " (" + find_char + ")")
            # Need to be weird to be bidirectional
            if c == text_char and (starting_index == 0 or "\\" != text[found_index - 1:found_index]):
                can_see = True
        starting_index -= 1
        found_index += find_increment
    if check_last and found_index != -1:
        raise AssertionError("My code is buggy 1")
    if not check_last and found_index != len(text):
        raise AssertionError("My code is buggy 2")
    return found_index


def find_method_arg_closing(text, starting_index):
    text = text[starting_index:].strip()
    if text.startswith(")"):
        return starting_index
    can_see = True
    text_char = '\"'
    blind = False
    stack = 0
    line_index = starting_index
    for c in text:
        if can_see:
            if c == '\"' or c == '\'':
                can_see = False
                text_char = c
            if c == "(":
                stack += 1
            if c == ")":
                stack -= 1
                if stack < 0:
                    return line_index
        elif blind:
            blind = False
        else:
            if c == '\\':
                blind = True
            elif c == text_char:
                can_see = True
        line_index += 1
    return -1


def find_last_out_of_string(text, find_char, starting_index=None):
    return find_out_of_string(text, find_char, starting_index, True)


# Find last dot we should modify info
def find_last_func_dot(line):
    line_length = len(line)
    prev_last_dot_index = -1
    last_dot_index = find_last_out_of_string(line, '.')
    if last_dot_index + 1 == line_length:
        last_dot_index = find_last_out_of_string(line, '.', last_dot_index)
    while prev_last_dot_index != last_dot_index:
        prev_last_dot_index = last_dot_index
        # Ignore numbers like "1.0", "0.5", "0.0"
        if line[last_dot_index + 1] in str_digits:
            last_dot_index = find_last_out_of_string(line, '.', last_dot_index)
        if last_dot_index == -1:
            return -1
        end_array = find_out_of_string(line, ']', last_dot_index)
        if end_array != -1:
            start_array = find_last_out_of_string(line, '[', end_array)
            if start_array != -1 and start_array < last_dot_index < end_array:
                last_dot_index = find_last_out_of_string(line, '.', start_array)
        if last_dot_index == -1:
            return -1
        end_object = find_out_of_string(line, '}', last_dot_index)
        if end_object != -1:
            start_object = find_last_out_of_string(line, '{', end_object)
            if start_object != -1 and start_object < last_dot_index < end_object:
                last_dot_index = find_last_out_of_string(line, '.', start_object)
        if last_dot_index == -1:
            return -1
    return last_dot_index


def apply_debug_hooks(line, debug_level, debug_hook_dbg, import_excludes) -> str:
    last_dot_index = find_last_func_dot(line)
    # The FLMHDebug check is primitive but is good enough for it's intended purpose
    if last_dot_index == -1 or (last_dot_index == 9 and line[:last_dot_index] == "FLMHDebug"):
        return line
    last_opening_parenthesis_index = find_last_out_of_string(line, '(')
    late_cutoff = find_last_out_of_string(line, ',', last_dot_index)
    last_preceding_opening_parenthesis_index = find_last_out_of_string(line, '(', last_dot_index)
    last_preceding_closing_parenthesis_index = find_last_out_of_string(line, ')', last_dot_index)
    if last_preceding_closing_parenthesis_index < last_preceding_opening_parenthesis_index:
        late_cutoff = max(late_cutoff, last_preceding_opening_parenthesis_index)
    last_array_assign_statement = find_last_out_of_string(line, ':', last_dot_index)
    if late_cutoff < last_array_assign_statement:
        late_cutoff = last_array_assign_statement + 1
    # lps -> last_preceding_space
    cond_lps = last_dot_index - 1
    prev_cond_lps = last_dot_index
    while cond_lps != -1:
        cond_lps = find_last_out_of_string(line, ' ', cond_lps - 1)
        # try to find the if/and/or
        if cond_lps > 4 and line[cond_lps + 1:prev_cond_lps] in conditions_keywords:
            late_cutoff = max(late_cutoff, prev_cond_lps)
        prev_cond_lps = cond_lps

    prefix = ""
    if late_cutoff != -1:
        prefix = (apply_debug_hooks_trim(
            line[:late_cutoff], debug_level, debug_hook_dbg, import_excludes) +
                  line[late_cutoff:late_cutoff + 1])
    late_cutoff = late_cutoff + 1
    first_char = line[late_cutoff:late_cutoff + 1]
    while first_char == "!" or first_char == "(" or first_char == " ":
        late_cutoff += 1
        first_char = line[late_cutoff:late_cutoff + 1]
    object_instance_input = line[late_cutoff:last_dot_index]
    if (object_instance_input.find(".") == -1 and
            (object_instance_input in import_excludes or
             object_instance_input in game_class_names or
             object_instance_input in godot_class_names)):
        return line  # Workaround Godot bug: https://github.com/godotengine/godot/issues/49290
    if object_instance_input.startswith("=") or object_instance_input.startswith(" ="):
        print_warn("Failed to properly install a debug hook at " + debug_hook_dbg + " (Inner assignment)")
        return line  # Skip for inner assignments (We should not reach there)
    if (object_instance_input.startswith("load(") and object_instance_input.endswith(")") and
            find_method_arg_closing(object_instance_input, 5) + 1 == len(object_instance_input)):
        return line  # Workaround Godot bug
    if last_dot_index > last_opening_parenthesis_index or debug_level == 1:
        if object_instance_input in reserved_keywords or object_instance_input.endswith("\""):
            return line  # Don't check for null for reserved keywords, or strings
        if object_instance_input in game_globals_names:
            return line  # Don't check if object is null for global instances
        post_line = line[last_dot_index:]
        if post_line.startswith("=") or post_line.startswith(" ="):
            print_warn("Failed to properly install a debug hook at " + debug_hook_dbg + " (Outer assignment)")
            return line  # Skip for outer assignments (We should not reach there)
        return (prefix + "FLMHDebug.check_non_null(\"" + debug_hook_dbg + "\", " +
                apply_debug_hooks_trim(object_instance_input,
                                       debug_level, debug_hook_dbg, import_excludes) + ")" +
                post_line)
    opening_parenthesis_index = find_out_of_string(line, '(', last_dot_index)
    method_close_index = find_method_arg_closing(line, opening_parenthesis_index + 1)
    method_name = line[last_dot_index + 1:opening_parenthesis_index]
    if late_cutoff == last_dot_index or method_name.endswith("%"):
        return line  # We cannot hook arrays or super calls safely at all
    if line[last_dot_index + 1:opening_parenthesis_index] in godot_primitive_method_names:
        return (prefix + "FLMHDebug.check_non_null(\"" + debug_hook_dbg + "\", " +
                apply_debug_hooks_trim(object_instance_input,  # We cannot hook primitive method names
                                       debug_level, debug_hook_dbg, import_excludes) + ")" +
                line[last_dot_index:])
    if method_close_index == -1:  # Only -1 if call is split on multiple lines
        if debug_level < 3:
            return line
        return (prefix + "FLMHDebug.call_virtual_unsafe(\"" + debug_hook_dbg + "\", " +
                apply_debug_hooks_trim(object_instance_input,
                                       debug_level, debug_hook_dbg, import_excludes) +
                ", \"" + method_name + "\", [" +
                line[opening_parenthesis_index + 1:method_close_index] +
                "]" + line[method_close_index:])
    method_args = line[opening_parenthesis_index + 1:method_close_index]
    if method_args.strip() == "":
        return (prefix + "FLMHDebug.call_virtual_simple(\"" + debug_hook_dbg + "\", " +
                apply_debug_hooks_trim(object_instance_input,
                                       debug_level, debug_hook_dbg, import_excludes) +
                ", \"" + method_name + "\"" + line[method_close_index:])
    if method_args.find(",") == -1:
        return (prefix + "FLMHDebug.call_virtual_single(\"" + debug_hook_dbg + "\", " +
                apply_debug_hooks_trim(object_instance_input,
                                       debug_level, debug_hook_dbg, import_excludes) +
                ", \"" + method_name + "\", " + method_args + line[method_close_index:])
    return (prefix + "FLMHDebug.call_virtual_safe(\"" + debug_hook_dbg + "\", " +
            apply_debug_hooks_trim(object_instance_input,
                                   debug_level, debug_hook_dbg, import_excludes) +
            ", \"" + method_name + "\", [" + method_args + "]" + line[method_close_index:])


def apply_debug_hooks_trim(line: str, debug_level, debug_hook_dbg, import_excludes) -> str:
    end_array = find_last_out_of_string(line, ']')
    if end_array != -1:
        start_array = find_last_out_of_string(line, '[', end_array)
        if start_array == -1:
            return (apply_debug_hooks_trim(
                line[:end_array], debug_level, debug_hook_dbg, import_excludes) +
                    line[end_array:])
        else:
            array_inside = "[" + apply_debug_hooks_trim(
                line[start_array + 1:end_array], debug_level, debug_hook_dbg, import_excludes) + "]"
            array_inside_placeholder = None
            # It's random, but it "works"
            while array_inside_placeholder is None or line.find(array_inside_placeholder) != -1:
                array_inside_placeholder = (
                        "%array_" + str(random.randint(0, 9)) + str(random.randint(0, 9)) +
                        str(random.randint(0, 9)) + str(start_array % 9) + str(len(line) % 9) + "%")
            return (apply_debug_hooks_trim(line[:start_array] + array_inside_placeholder +
                                           line[end_array + 1:], debug_level, debug_hook_dbg, import_excludes)
                    .replace(array_inside_placeholder, array_inside))
    r_striped_line = line.rstrip()
    if len(r_striped_line) == 0:
        return line
    l_striped_line = line.lstrip()
    line_end = line[len(r_striped_line):]
    line_start = line[:len(line) - len(l_striped_line)]
    stripped_line = line.strip()
    if stripped_line.startswith("if "):
        line_start += "if "
        stripped_line = stripped_line[3:]
    elif stripped_line.startswith("elif "):
        line_start += "elif "
        stripped_line = stripped_line[5:]
    elif stripped_line.startswith("return "):
        line_start += "return "
        stripped_line = stripped_line[7:]
    elif stripped_line.startswith("for "):
        in_index = stripped_line.find(" in ") + 4
        if in_index == 3:
            return line
        line_start += stripped_line[:in_index]
        stripped_line = stripped_line[in_index:]
    if stripped_line.startswith("not "):
        line_start += "not "
        stripped_line = stripped_line[4:]
    for cond in conditions_keywords:
        cond_end = " " + cond
        cond_start = cond + " "
        cond_start_sec = cond + "("
        if stripped_line.endswith(cond_end):
            line_end = cond_end + line_end
            stripped_line = stripped_line[:-len(cond_end)]
        if stripped_line.startswith(cond_start):
            line_start = line_start + cond_start
            stripped_line = stripped_line[len(cond_start):]
        if stripped_line.startswith(cond_start_sec):
            line_start = line_start + cond_start_sec
            stripped_line = stripped_line[len(cond_start_sec):]
    return line_start + apply_debug_hooks(stripped_line, debug_level, debug_hook_dbg, import_excludes) + line_end


def default_source_processor(line, path, line_number, script_lines, source_processor_data):
    if line is None or path is None or line_number is None or script_lines is None or source_processor_data is None:
        raise CompileError("Invalid call to source_processor() during compile")
    return line


def get_source_processor_indent(source_processor_data, indent_add=None):
    if indent_add is None:
        indent_add = source_processor_data["indent_add"]
    indent_type = source_processor_data.get("indent_type") or "    "
    return source_processor_data["indent_extra"] + (indent_type * indent_add)


def append_source_processor_line(line_end, script_lines, source_processor_data, line, indent_add=None):
    script_lines.append(get_source_processor_indent(source_processor_data, indent_add) + line + line_end)


def scene_source_processor_ensure_init_flushed(line_end, script_lines, source_processor_data):
    if source_processor_data.get("scene_init"):
        source_processor_data["scene_init"] = False
        initial_characters = source_processor_data.get("scene_initial_characters")
        if initial_characters is not None and len(initial_characters) != 0:
            script_lines.append("    initialSceneCharacters = " +
                                (str(initial_characters).replace("\'", "\"")) + line_end)
        if source_processor_data.get("scene_allow_softlock"):
            script_lines.append("    allowSoftlock = true" + line_end)


def scene_source_processor_ensure_in_run(line_end, script_lines, source_processor_data):
    if source_processor_data.get("scene_in_run"):
        return
    source_processor_data["scene_in_run"] = True
    scene_source_processor_ensure_init_flushed(line_end, script_lines, source_processor_data)
    script_lines.append(line_end)
    script_lines.append("func _run():" + line_end)
    script_lines.append("    if state == \"\":" + line_end)
    source_processor_data["indent_add"] = 2
    source_processor_data["scene_current_state"] = ""
    source_processor_data["scene_current_state_ln_start"] = len(script_lines)


def scene_source_processor_flush_text(line_end, script_lines, source_processor_data):
    text_to_flush = source_processor_data.get("scene_text_buf")
    if text_to_flush is None or text_to_flush == "":
        return
    chr_selector = text_to_flush.find(": ")
    if chr_selector != -1 and chr_selector + 1 == text_to_flush.find(" "):
        text_to_flush = "[say=" + text_to_flush[0:chr_selector] + "]" + text_to_flush[chr_selector + 2:] + "[/say]"
    scene_source_processor_ensure_in_run(line_end, script_lines, source_processor_data)
    append_source_processor_line(line_end, script_lines, source_processor_data,
                                 "saynn(" + escape_to_gd_string_with_code(text_to_flush) + ")")
    source_processor_data["scene_text_buf"] = None


def scene_source_processor_end_state(line_end, script_lines, source_processor_data):
    if not source_processor_data.get("scene_manage_states"):
        return
    if source_processor_data.get("scene_current_state_ln_start") == len(script_lines):
        if source_processor_data.get("scene_current_state") == "":
            append_source_processor_line(line_end, script_lines, source_processor_data, "pass")
        else:
            del script_lines[-1]


def scene_source_processor_flush_react(line_end, script_lines, source_processor_data):
    react_blocks = source_processor_data.get("scene_react_blocks")
    if not react_blocks:
        return
    script_lines.append(line_end)
    script_lines.append("func _react(_action: String, _args):" + line_end)
    first_react_block = True
    for react_id, react_data in react_blocks.items():
        if react_data is None or len(react_data) == 0:
            continue
        if first_react_block:
            script_lines.append("    if _action == " + escape_to_gd_string(react_id) + ":" + line_end)
            first_react_block = False
        else:
            script_lines.append("    elif _action == " + escape_to_gd_string(react_id) + ":" + line_end)
        script_lines.extend(react_data)
    script_lines.append("    ._react(_action, _args)" + line_end)


def scene_source_processor(line, path, line_number, script_lines, source_processor_data):
    r_striped_line = line.rstrip()
    line_end = line[len(r_striped_line):]
    if line_end == "":
        line_end = "\n"
    if (line == "@foxlib_scene_init" and source_processor_data.get("scene_init") is None
            and source_processor_data.get("scene_id") is not None):
        script_lines.append("extends \"res://FoxLib/FoxScene.gd\"" + line_end)
        script_lines.append(line_end)
        script_lines.append("func _init():" + line_end)
        script_lines.append("    sceneID = \"" + source_processor_data.get("scene_id") + "\"" + line_end)
        source_processor_data["scene_init"] = True
        source_processor_data["scene_characters"] = []
        return None
    if r_striped_line == "":
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        return None
    elif line == "@end" or r_striped_line == "#end_foxlib_scene":
        scene_source_processor_ensure_init_flushed(line_end, script_lines, source_processor_data)
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        scene_source_processor_end_state(line_end, script_lines, source_processor_data)
        scene_source_processor_flush_react(line_end, script_lines, source_processor_data)
        return line
    elif r_striped_line.startswith("#character "):
        if not source_processor_data.get("scene_init"):
            raise CompileError("Failed to add character outside of init method.")
        new_initial_character = r_striped_line[11:].lstrip()
        if escape_to_gd_string(new_initial_character) != ("\"" + new_initial_character + "\""):
            raise CompileError("Unsupported character name: " + escape_to_gd_string(new_initial_character))
        initial_characters = source_processor_data.get("scene_initial_characters")
        if initial_characters is None:
            initial_characters = []
            source_processor_data["scene_initial_characters"] = initial_characters
        initial_characters.append(new_initial_character)
        return None
    elif r_striped_line == "#allow_softlock":
        if not source_processor_data.get("scene_init"):
            raise CompileError("Failed to allow softlock outside of init method.")
        source_processor_data["scene_allow_softlock"] = True
        return None
    elif r_striped_line.startswith("#code "):
        scene_source_processor_ensure_in_run(line_end, script_lines, source_processor_data)
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        append_source_processor_line(line_end, script_lines, source_processor_data,
                                     apply_macros(r_striped_line[5:].lstrip(), path, line_number))
        return None
    elif r_striped_line.startswith("#react "):
        if not source_processor_data.get("scene_manage_states"):
            raise CompileError("Only the \"#foxlib_scene\" block can manage states")
        current_state = source_processor_data.get("scene_current_state") or ""
        react_blocks = source_processor_data.get("scene_react_blocks")
        if react_blocks is None:
            react_blocks = {}
            source_processor_data["scene_react_blocks"] = react_blocks
        react_block = react_blocks.get(current_state)
        if react_block is None:
            react_block = []
            react_blocks[current_state] = react_block
        react_block.append("        " + (r_striped_line[7:].strip()) + line_end)
        return None
    elif r_striped_line.startswith("#if "):
        scene_source_processor_ensure_in_run(line_end, script_lines, source_processor_data)
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        append_source_processor_line(line_end, script_lines, source_processor_data, "if " +
                                     apply_macros(r_striped_line[5:].lstrip(), path, line_number) + ":")
        source_processor_data["indent_add"] = source_processor_data["indent_add"] + 1
        return None
    elif r_striped_line.startswith("#elif "):
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        old_indent_add = source_processor_data["indent_add"]
        if old_indent_add == 0:
            raise CompileError("Cannot close non existent if statement")
        append_source_processor_line(line_end, script_lines, source_processor_data, "elif " +
                                     apply_macros(r_striped_line[5:].lstrip(), path, line_number) + ":",
                                     old_indent_add - 1)
        return None
    elif r_striped_line == "#else":
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        old_indent_add = source_processor_data["indent_add"]
        if old_indent_add == 0:
            raise CompileError("Cannot close non existent if statement")
        append_source_processor_line(line_end, script_lines, source_processor_data, "else:",
                                     old_indent_add - 1)
        return None
    elif r_striped_line.startswith("#state "):
        if not source_processor_data.get("scene_manage_states"):
            raise CompileError("Only the \"#foxlib_scene\" block can manage states")
        scene_source_processor_ensure_in_run(line_end, script_lines, source_processor_data)
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        old_indent_add = source_processor_data["indent_add"]
        if old_indent_add == 0:
            raise CompileError("Cannot close non existent if statement")
        new_state = r_striped_line[7:]
        if new_state == "endthescene":
            raise CompileError("The state \"endthescene\" is a reserved state id")
        if source_processor_data.get("scene_current_state") == new_state:
            raise CompileError("Cannot switch to an already existing state")
        scene_source_processor_end_state(line_end, script_lines, source_processor_data)
        script_lines.append("    elif state == " + escape_to_gd_string(new_state) + ":" + line_end)
        source_processor_data["indent_add"] = 2
        source_processor_data["scene_current_state"] = new_state
        source_processor_data["scene_current_state_ln_start"] = len(script_lines)
        return None
    elif r_striped_line == "#endif":
        scene_source_processor_flush_text(line_end, script_lines, source_processor_data)
        old_indent_add = source_processor_data["indent_add"]
        if old_indent_add == 0:
            raise CompileError("Cannot close non existent if statement")
        source_processor_data["indent_add"] = old_indent_add - 1
        return None
    elif not r_striped_line.startswith("#"):
        text_buf = source_processor_data.get("scene_text_buf") or ""
        if text_buf == "":
            text_buf = r_striped_line
        else:
            text_buf = text_buf + " " + r_striped_line
        source_processor_data["scene_text_buf"] = text_buf
        return None
    return line


def processor_calc_indent_extra(script_lines, source_processor_data):
    source_processor_data["indent_extra"] = ""
    source_processor_data["indent_add"] = 0
    source_processor_data["indent_type"] = "    "
    script_lines_index = len(script_lines) - 1
    while script_lines_index >= 0:
        line_to_test = script_lines[script_lines_index]
        l_stripped_line_to_test = line_to_test.lstrip()
        if l_stripped_line_to_test != "":
            cutoff_index = len(line_to_test) - len(l_stripped_line_to_test)
            source_processor_data["indent_extra"] = line_to_test[:cutoff_index]
            if source_processor_data["indent_extra"].startswith("\t"):
                source_processor_data["indent_type"] = "\t"
            return
        script_lines_index = script_lines_index - 1


def add_gd_to_zip(file, path, mod_zip: zipfile.ZipFile, source_mode, debug_level, trace):
    script_lines = []
    script_preload_imports = []
    is_public = False
    class_name = ""
    line_number = 0
    # Disable debug mode for debugging code
    if path == "FoxLib/ModHelper/FLMHDebug.gd":
        debug_level = 0
        trace = False
    allow_debug = True
    debug_status = debuggable.get(path)
    debug_imported = debug_status or False
    source_processor = default_source_processor
    source_processor_data = {"indent_extra": "", "indent_add": 0, "indent_type": "    "}
    with open(file) as f:
        trace_method_name = None
        for line in f:
            if source_mode != "parsed":
                line = source_processor(line, path, line_number, script_lines, source_processor_data)
                if line is None:
                    continue
                line = apply_macros(line, path, line_number)
            line_pre = None
            line_number += 1
            unmodified_line = line
            r_striped_line = line.rstrip()
            if trace_method_name is not None:
                striped_line = line.strip()
                if striped_line != "pass" and not striped_line.startswith("pass "):
                    line_pre = (line[:len(line) - len(line.lstrip())] +
                                "FLMHDebug.trace(\"" + path + ":" + trace_method_name + "() enter\")")
                trace_method_name = None
            if r_striped_line == "#private_api":
                is_public = False
            elif r_striped_line == "#public_api":
                is_public = True
            elif r_striped_line == "#start_foxlib_scene":
                if source_mode == "parsed":
                    raise CompileError("Cannot use \"#start_foxlib_scene\" in parse mode.")
                if source_processor != default_source_processor:
                    raise CompileError("Cannot use multiple source processors at the same time")
                processor_calc_indent_extra(script_lines, source_processor_data)
                source_processor_data["scene_manage_states"] = False
                source_processor_data["scene_in_run"] = True
                source_processor_data["used_foxlib_scene"] = True
                source_processor = scene_source_processor
            elif r_striped_line == "#foxlib_scene":
                if source_mode == "parsed":
                    raise CompileError("Cannot use \"#foxlib_scene\" in parse mode.")
                if source_processor != default_source_processor:
                    raise CompileError("Cannot use multiple source processors at the same time")
                if source_processor_data.get("scene_id") is not None or line_number != 1:
                    raise CompileError("Can only use \"#foxlib_scene\" as the first line.")
                if compare_semver(foxlib_scene_semver, libFoxLibSemver) < 0:
                    raise CompileError("Need at least FoxLib " + foxlib_scene_version + " to use \"#foxlib_scene\"")
                source_processor_data["scene_manage_states"] = True
                source_processor_data["scene_id"] = modBaseName + path[path.find("/") + 1: -3]
                scene_source_processor("@foxlib_scene_init", path, line_number,
                                       script_lines, source_processor_data)
                source_processor = scene_source_processor
                continue
            elif r_striped_line.startswith("#foxlib_scene "):
                if source_mode == "parsed":
                    raise CompileError("Cannot use \"#foxlib_scene\" in parse mode.")
                if source_processor != default_source_processor:
                    raise CompileError("Cannot use multiple source processors at the same time")
                if line_number != 1:
                    raise CompileError("Can only use \"#foxlib_scene\" as the first line.")
                if compare_semver(foxlib_scene_semver, libFoxLibSemver) < 0:
                    raise CompileError("Need at least FoxLib " + foxlib_scene_version + " to use \"#foxlib_scene\"")
                source_processor_data["scene_manage_states"] = True
                source_processor_data["scene_id"] = r_striped_line[14:]
                scene_source_processor("@foxlib_scene_init", path, line_number,
                                       script_lines, source_processor_data)
                source_processor = scene_source_processor
                continue
            elif r_striped_line == "#end_foxlib_scene":
                if source_processor != scene_source_processor:
                    raise CompileError("Not in a foxlib scene tag")
                source_processor = default_source_processor
            elif line.startswith("class_name "):
                if "#" in line:
                    class_name = line[11:line.find('#')].strip()
                else:
                    class_name = line[11:].strip()
            elif line.startswith("extends "):
                if "#" in r_striped_line:
                    extends = r_striped_line[8:line.find('#')].strip()
                else:
                    extends = r_striped_line[8:].strip()
                if ((extends.startswith("\"") and extends.endswith("\"")) or
                        (extends.startswith("\'") and extends.endswith("\'"))):
                    extends_file = extends[1:-1]
                else:
                    extends_file = definitions.get(extends)
                    if extends_file is not None:
                        extends_file = "res://" + extends_file
                debuggable_status = None
                if extends_file is not None and extends_file.startswith("res://"):
                    parent_path = extends_file[6:]
                    if (debug_level > 0 or trace) and parent_path in mod_godot_files.keys():
                        debuggable_status = True
                    else:
                        debuggable_status = debuggable.get(parent_path)
                    parent_imports = imports.get(parent_path)
                    if parent_imports is not None:
                        script_preload_imports += parent_imports
                if debuggable_status is not None:
                    mod_debuggable[path] = True
                    debuggable[path] = True
                    debug_imported = True
                if extends_file is not None:
                    line = "extends \"" + extends_file + "\"" + line[len(r_striped_line):]
            elif line.startswith("const "):
                preload_index = line.find(" = preload(\"res://")
                if preload_index != -1:
                    import_name = line[6:preload_index]
                    script_preload_imports.append(import_name)
            elif line.startswith("static func ") and trace and debug_imported:
                name_end_index = line.find("(")
                if name_end_index != -1:
                    trace_method_name = line[12:name_end_index]
            elif line.startswith("func ") and trace and debug_imported:
                name_end_index = line.find("(")
                if name_end_index != -1:
                    trace_method_name = line[5:name_end_index]
                    # Avoid spamming with traces
                    if trace_method_name == "_process" or trace_method_name == "_physics_process":
                        trace_method_name = None
            elif line.startswith("#import "):
                statement = line[8:].strip()
                as_type_index = statement.find(" as ")
                if as_type_index == -1:
                    import_type = statement
                    import_name = statement
                else:
                    import_type = statement[:as_type_index].strip()
                    import_name = statement[as_type_index + 4:].strip()
                type_file = definitions.get(import_type)
                if type_file is None:
                    if import_type in game_class_names and import_name == import_type:
                        continue  # If importing game classes as-is, don't error out
                    raise CompileError("File " + path + " tried to import " + import_type +
                                       " but it was not found in the project path (Line " + str(line_number) + ")")
                if type_file == path or import_type == class_name:
                    raise CompileError("File " + path + " tried to import itself (Line " + str(line_number) + ")")
                line = "const " + import_name + " = preload(\"res://" + type_file + "\")" + line[len(r_striped_line):]
                script_preload_imports.append(import_name)
            elif r_striped_line == "#nodebug":
                allow_debug = False
            elif r_striped_line == "#debug":
                allow_debug = True
            elif r_striped_line == "#safedebug":
                allow_debug = True
                debug_level = min(debug_level, 2)
            if r_striped_line == "const FLMHDebug = preload(\"res://FoxLib/ModHelper/FLMHDebug.gd\")":
                if debug_imported:
                    line = line[len(r_striped_line):]
                else:
                    debug_imported = True
            elif debug_level > 0 or trace:
                if len(r_striped_line) == 0:
                    # In debug mode, we always import FLMHDebug, as we use it to hook method calls
                    if not debug_imported and debug_status is None:
                        if (path == "Modules/FoxLib/Module.gd" or
                                path == "FoxLib/CrotchBlocks/Item/FoxRemoveDatapackItemID.gd"):
                            print_err("Something wrong happened: " + str(parent_path))
                        line = "const FLMHDebug = preload(\"res://FoxLib/ModHelper/FLMHDebug.gd\")" + line
                        debug_imported = True
                        if "FLMHDebug" not in script_preload_imports:
                            script_preload_imports.append("FLMHDebug")
                elif debug_imported and allow_debug and debug_level > 0:
                    line_suffix = ""
                    # Comments can mess up debug hook generation
                    comment_index = find_out_of_string(line, "#")
                    if comment_index != -1:
                        line_suffix = line[comment_index:]
                        line = line[:comment_index]
                    setter_index = line.find("=")
                    debug_hook_dbg = path + ":" + str(line_number)
                    if setter_index == -1:
                        line = apply_debug_hooks_trim(
                            line, debug_level, debug_hook_dbg, script_preload_imports)
                    else:
                        line = (apply_debug_hooks_trim(
                            line[:setter_index], debug_level,
                            debug_hook_dbg, script_preload_imports) + "="
                                + apply_debug_hooks_trim(
                                    line[setter_index + 1:], debug_level,
                                    debug_hook_dbg, script_preload_imports))
                    line = line + line_suffix
            # In trimmed source mode, remove comments and unfiltered preprocessor directives
            if source_mode == "trimmed":
                if "#" in line:
                    line = line[:line.find('#')] + unmodified_line[len(r_striped_line):]
            if line_pre is not None:
                script_lines.append(line_pre + unmodified_line[len(r_striped_line):])
            script_lines.append(line)
    source_processor("@end", path, line_number,
                     script_lines, source_processor_data)
    if debug_imported and debug_status is None:
        debuggable[path] = False
        mod_debuggable[path] = False
        if is_public:
            public_mod_debuggable[path] = False
    if len(script_preload_imports) > 0:
        imports[path] = script_preload_imports
        if is_public:
            public_mod_imports[path] = script_preload_imports
    if source_mode != "parsed":
        mod_zip.writestr(path, "".join(script_lines))


# https://github.com/godotengine/godot/blob/3.6/editor/import/resource_importer_texture.cpp
# https://github.com/godotengine/godot/blob/3.6/scene/resources/texture.h
# https://github.com/godotengine/godot/blob/3.6/servers/visual_server.h
def add_png_to_zip(file: str, path: str, mod_zip, suggestion_backlog: list, force) -> None:
    if mod_zip is not None:
        mod_zip.write(file, path)
    if os.path.exists(file + ".import") and not force:
        return
    use_webp_format = False  # Image is not None
    import_path = path + ".import"
    stex_path = path + ".stex"
    png_size = os.path.getsize(file)
    if png_size < 24:
        raise OSError("Invalid PNG File: " + file)
    with open(file, 'rb') as input_png:
        data = input_png.read(25)
        if data.startswith(b'\211PNG\r\n\032\n') and (data[12:16] == b'IHDR'):
            # noinspection PyTypeChecker
            w, h = struct.unpack(">LL", data[16:24])
            width = int(w)
            height = int(h)
        else:
            raise OSError("Invalid PNG File: " + file)
    import_file = ("[remap]\n\nimporter=\"texture\"\ntype=\"StreamTexture\"\npath=\"res://" + stex_path + "\"\n" +
                   "metadata={\n\"vram_texture\": false\n}\n\n"
                   "[deps]\n\nsource_file=\"" + path + "\"\ndest_files=[ \"" + stex_path + "\" ]\n")
    if mod_zip is None:
        with open(file + ".import", 'w') as import_file:
            import_file.write(str(import_file))
    else:
        mod_zip.writestr(import_path, import_file)
    stex_file = b"GDST"  # Header Magic
    stex_file += struct.pack("<H", width)  # Width
    stex_file += struct.pack("<H", 0)  # Custom Width
    stex_file += struct.pack("<H", height)  # Height
    stex_file += struct.pack("<H", 0)  # Custom Height
    texture_flag_filter = 4  # Linear filtering flag
    stex_file += struct.pack("<I", texture_flag_filter)  # Texture flags
    format_bit_png = 1 << 20  # Format bit png
    format_bit_webp = 1 << 21  # Format bit webp
    if use_webp_format:
        stex_file += struct.pack("<I", format_bit_webp)  # Format
        stex_file += struct.pack("<I", 1)  # Mipmaps count
        img = Image.open(path)
        buf = io.BytesIO()
        img.save(buf, format="WEBP", quality=70, method=6, lossless=False)
        webp_buf = buf.getvalue()
        stex_file += struct.pack("<I", len(webp_buf) + 4)  # Packed Image size
        stex_file += b"WEBP"
        stex_file += webp_buf
    else:
        stex_file += struct.pack("<I", format_bit_png)  # Format
        stex_file += struct.pack("<I", 1)  # Mipmaps count
        stex_file += struct.pack("<I", png_size + 4)  # Packed Image size
        stex_file += b"PNG "
        with open(file, 'rb') as input_png:
            stex_file += input_png.read()
        # add_if_missing(suggestion_backlog,
        #                "The pillow (Aka. PIL) python library is missing, mod images may look aliased in-game")
    if mod_zip is None:
        with open(file + ".stex", 'wb') as stex_fd:
            stex_fd.write(stex_file)
    else:
        mod_zip.writestr(stex_path, stex_file)


def add_to_zip_recursively(file, path, mod_zip: zipfile.ZipFile, source_mode,
                           debug_level, trace, suggestion_backlog: list):
    for f in os.listdir(file):
        child_file = os.path.join(file, f)
        child_path = path + "/" + f
        if os.path.isdir(child_file):
            add_to_zip_recursively(child_file, child_path, mod_zip, source_mode,
                                   debug_level, trace, suggestion_backlog)
        elif child_path.endswith(".gd") and source_mode != "raw":
            add_gd_to_zip(child_file, child_path, mod_zip, source_mode, debug_level, trace)
            if source_mode == "parsed":
                mod_zip.write(child_file, child_path)
        elif child_path.endswith(".png") and source_mode != "raw":
            add_png_to_zip(child_file, child_path, mod_zip, suggestion_backlog, False)
        else:
            mod_zip.write(child_file, child_path)


def add_mod_info_to_zip(mod_zip: zipfile.ZipFile, file, path):
    mod_zip.write(file, path)


def add_foxlib_code_to_mod_zip(mod_zip, entry_name):
    global libFoxLibPath
    with zipfile.ZipFile(libFoxLibPath, mode="r") as foxlib_archive:
        mod_zip.writestr(entry_name, foxlib_archive.read(entry_name).decode("utf-8"))


def append_rahi_newline(line):
    if line.endswith("\n\n"):
        return line
    elif line.endswith("\n"):
        return line + "\n"
    else:
        return line + "\n\n"


def dump_as_rahi_json(full_base_name, rahi_description):
    global modInfoDict, modHideSuffix
    buffer = "\t{\n"
    for rahi_entry in rahi_json_entry_index_order:
        if rahi_entry == "description":
            entry_obj = rahi_description
        elif rahi_entry == "author":
            entry_obj = modInfoDict.get(rahi_entry)
            if modHideSuffix != "" and entry_obj.endswith(modHideSuffix):
                entry_obj = entry_obj[:-len(modHideSuffix)]
            next_open = entry_obj.find("[")
            next_close = 0
            while next_open != -1 and next_close != -1:
                next_close = entry_obj.find("]", next_open)
                if next_close != -1:
                    entry_obj = entry_obj[:next_open] + entry_obj[next_close + 1:]
                    next_open = entry_obj.find("[", next_open)
        elif rahi_entry == "modversion":
            entry_obj = modInfoDict.get(rahi_entry) + modHideSuffix
        else:
            entry_obj = modInfoDict.get(rahi_entry)
        if entry_obj is None and rahi_entry == "name":
            entry_obj = modBaseName
        if entry_obj is not None:
            buffer += "\t\t\"" + rahi_entry + "\": " + json.dumps(entry_obj, ensure_ascii=False) + ",\n"
    buffer += "\t\t\"download\": \""
    buffer += "https://raw.githubusercontent.com/Alexofp/BDCCMods/main/mods/"
    buffer += full_base_name + ".zip\"\n"
    buffer += "\t}\n"
    return buffer


def build(debug_level=0, trace=False):
    global main_game_mode, source_paths, modInfoDict, modHideSuffix, \
        modBaseName, modInfo, modExtendsFoxLib, libFoxLibSemver
    error_backlog = []
    suggestion_backlog = []
    try:
        check_common(error_backlog, suggestion_backlog)
    except CompileError as err:
        error_backlog.append(error_to_string(err))
    if len(error_backlog) != 0:
        for error in error_backlog:
            print_err(error)
        for suggestion in suggestion_backlog:
            print_warn(suggestion)
        return False
    assert isinstance(modBaseName, str) and len(modBaseName) > 0 and isinstance(modInfo, str)
    source_mode = modInfoDict.get("FLMH_source_mode") or "processed"
    definition_mode = modInfoDict.get("FLMH_definition_mode") or "standard"
    rahi_preview = modInfoDict.get("FLMH_rahi_preview") or None
    rahi_changelog = modInfoDict.get("FLMH_rahi_changelog") or None
    foxlib_verify_mode = modInfoDict.get("FLMH_foxlib_verify_mode") or "auto"
    mod_menu_display = modInfoDict.get("FLMH_mod_menu_display") or "vanilla"
    if foxlib_verify_mode == "auto":
        if modBaseName == "FoxLib":
            foxlib_verify_mode = "none"  # It's actually always enabled on FoxLib
        elif modExtendsFoxLib and compare_semver(verify_foxlib_semver, libFoxLibSemver) >= 0:
            foxlib_verify_mode = "verify"
        else:
            foxlib_verify_mode = "none"
    if "name" not in modInfoDict:
        modInfoDict["name"] = modBaseName
    mod_version = modInfoDict["modversion"]
    if debug_level != 0 or trace:
        full_base_name = modBaseName + "_debug"
    else:
        full_base_name = modBaseName + "_v" + mod_version

    # Apply custom macros to description
    mod_description_tmp = modInfoDict.get("description")
    if mod_description_tmp.startswith("file:"):
        mod_description_file = mod_description_tmp[5:]
        mod_description_lines_tmp = []
        mod_description_line_number_tmp = 0
        with open(mod_description_file) as f:
            for line in f:
                line = line.rstrip()
                if line.startswith("## "):
                    continue
                elif line == "#separator_warn":
                    line = desc_separator_warn
                line = apply_macros(line, mod_description_file, mod_description_line_number_tmp)
                mod_description_line_number_tmp = mod_description_line_number_tmp + 1
                mod_description_lines_tmp.append(line + "\n")
        mod_description_tmp = "".join(mod_description_lines_tmp)
    else:
        mod_description_tmp = apply_macros(mod_description_tmp, modInfo, 0)
    rahi_description_prefix = ""
    if mod_menu_display == "vanilla":
        modInfoDict["description"] = mod_description_tmp
    else:
        modHideSuffix = "[color="
        modInfoDict["author"] = (modInfoDict.get("author") or "") + modHideSuffix
        display_game_version = modInfoDict.get("FLMH_mod_menu_display_game_version") or modInfoDict["gameversion"]
        if display_game_version == "*":
            display_game_version = "Any"
        if display_game_version == "":
            desc_prefix = ("][/color]\n" +  # Close Comment eater
                           "Mod version: " + mod_version + "\n")
            rahi_prefix = desc_prefix
        else:
            desc_prefix = ("][/color]\n" +  # Close Comment eater
                           "Game version: " + display_game_version + "\n" +
                           "Mod version: " + mod_version + "\n")
            rahi_prefix = ("][/color]\n" +  # Close Comment eater
                           "Game version: " + display_game_version + "\n")
        modInfoDict["description"] = (desc_prefix + mod_description_tmp)
        rahi_description_prefix = (rahi_prefix + "Filename: " + full_base_name + ".zip\n")

    with zipfile.ZipFile(os.path.abspath(full_base_name + ".zip"), "w",
                         zipfile.ZIP_DEFLATED, False, 9) as mod_zip:
        for source_path in source_paths:
            source_file = os.path.abspath(os.path.join(".", source_path))
            if os.path.isdir(source_file):
                add_to_zip_recursively(source_file, source_path, mod_zip, source_mode,
                                       debug_level, trace, suggestion_backlog)
        if foxlib_verify_mode == "verify":
            add_foxlib_code_to_mod_zip(mod_zip, foxlib_verifier_path)
        if os.path.isfile("LICENSE") and not main_game_mode:
            mod_zip.write(os.path.abspath(os.path.join(".", "LICENSE")), "LICENSE")
        # Bundle the tool in FoxLib.zip releases
        if modBaseName == "FoxLib":
            mod_zip.write(os.path.abspath(os.path.join(".", "FLMH.py")), "FLMH.py")
            mod_zip.write(os.path.abspath(os.path.join(".", "FLMHW.py")), "FLMHW.py")
        mod_zip.writestr(full_base_name + ".json", json.dumps(modInfoDict, ensure_ascii=True))
        if rahi_preview is not None or rahi_changelog is not None:
            rahi_description = rahi_description_prefix + mod_description_tmp
            if rahi_changelog is not None:
                rahi_description = append_rahi_newline(rahi_description)
                with open(rahi_changelog, 'r') as file:
                    rahi_description = rahi_description + file.read().rstrip()
            if rahi_preview is not None:
                rahi_description = (append_rahi_newline(rahi_description) +
                                    "[url=" + rahi_preview + "]Click for preview[/url]")
            mod_zip.writestr(full_base_name + ".rahi.json", dump_as_rahi_json(full_base_name, rahi_description))
        if (definition_mode != "none" and (
                (len(public_mod_definitions) > 0 or len(public_mod_debuggable) > 0 or
                 (len(mod_definitions) > 0 and definition_mode == "extended")))):
            definitions_buffer = "# FoxLib Definitions\n"
            for key, value in public_mod_definitions.items():
                definitions_buffer += key + "=" + value + "\n"
            for key, value in public_mod_debuggable.items():
                definitions_buffer += "#dbg " + key + "\n"
            for key, value in public_mod_imports.items():
                definitions_buffer += "#imports " + key + "=" + (",".join(value)) + "\n"
            if definition_mode == "extended":
                for key, value in mod_definitions.items():
                    if key not in public_mod_definitions:
                        definitions_buffer += "#private_map " + key + "=" + value + "\n"
                for key, value in mod_debuggable.items():
                    if key not in public_mod_debuggable:
                        definitions_buffer += "#dbg " + key + "\n"
            mod_zip.writestr(full_base_name + EXT_FOXLIB_DEF, definitions_buffer)
    for suggestion in suggestion_backlog:
        print_warn(suggestion)
    print_fine("Your mod was successfully built as " + full_base_name + ".zip")
    return True


def check_get_game_executable(folder, soft_cache=False):
    if not os.path.isdir(folder):
        return None
    for game_file in os.listdir(folder):
        if game_file.startswith("~") or game_file.startswith(".") or game_file.endswith(".pck"):
            continue
        file_path = os.path.join(folder, game_file)
        if os.path.isdir(file_path):
            continue
        if soft_cache and os.path.getmtime(file_path) + 24 * 60 * 60 < time.time():
            return None
        return file_path
    return None


def check_get_game_data(folder):
    if not os.path.isdir(folder):
        return None
    for game_file in os.listdir(folder):
        if not game_file.endswith(".pck"):
            continue
        file_path = os.path.join(folder, game_file)
        if os.path.isdir(file_path):
            continue
        return file_path
    return None


def can_download_file():
    return requests is not None or has_urllib_request


def download_file(url, file):
    if requests is not None:
        get_response = requests.get(url, stream=True)
        with open(file, 'wb') as f:
            for chunk in get_response.iter_content(chunk_size=2048):
                if chunk:  # filter out keep-alive chunks
                    f.write(chunk)
    elif has_urllib_request:
        urllib.request.urlretrieve(url, file)


def support_game_test_raw():
    global libFoxLibSemver
    return compare_semver(game_test_foxlib_semver, libFoxLibSemver) >= 0


def support_testing(advanced, game_test):
    global modInfoDict, libFoxLibSemver
    # MacOS overcomplexify it's system to look fancy
    # And, I don't have a mac to see how I can get around their crap
    if platform_id == "mac":
        print_err("Testing is unsupported on MacOS")
        return False
    if platform_id is None:
        print_err("Testing is unsupported on this platform: " + platform.system())
        return False
    if not can_download_file():
        print_err("Your current python runtime lack networking capabilities")
        return False
    source_mode = modInfoDict.get("FLMH_source_mode") or "processed"
    if advanced and (source_mode == "raw" or source_mode == "parsed"):
        print_err("Advanced debugging is not available with " + source_mode + " source mode")
        return False
    if game_test > 0 and not support_game_test_raw():
        print_err("Game test requires at least FoxLib " + game_test_foxlib_version + " or later")
        return False
    return True


def download_and_run_game(game_version, debug_mode, game_test, use_special_path=False):
    game_data_path = get_game_data_path()
    is_dev_build = game_version == "dev"
    foxlib_mod_helper = os.path.join(os.path.join(game_data_path, "foxlib"), "mod_helper")
    zip_file_destination = os.path.join(foxlib_mod_helper, "bdcc-" + platform_id + "-" + game_version + ".zip")
    game_binary_destination = os.path.join(foxlib_mod_helper, "bdcc-" + platform_id + "-" + game_version)
    game_executable = check_get_game_executable(game_binary_destination, is_dev_build)
    if not os.path.isdir(game_binary_destination):
        os.makedirs(game_binary_destination)
    if game_executable is None and (is_dev_build or not os.path.exists(zip_file_destination)):
        platform_ext = game_downloads[platform_id]
        download_pattern = game_downloads["pattern"]
        if is_dev_build:
            download_pattern = game_downloads["dev-pattern"]
        download_link = (download_pattern.replace("${platform_ext}", platform_ext)
                         .replace("${version}", game_version).replace("${platform}", platform_id))
        print_log("Downloading BDCC " + game_version + " from " + download_link)
        download_file(download_link, zip_file_destination)
    if game_executable is None:
        if os.path.exists(game_binary_destination):
            delete_recursively(game_binary_destination)
        with zipfile.ZipFile(zip_file_destination, 'r') as game_zip_file:
            game_zip_file.extractall(game_binary_destination)
        game_executable = check_get_game_executable(game_binary_destination)
    game_process_pid = 0
    if game_executable is not None:
        print_log("Running BDCC " + game_version)
        if platform_id != "windows":
            unix_perms = os.stat(game_executable).st_mode
            if (unix_perms & stat.S_IXUSR) == 0:
                unix_perms |= stat.S_IXUSR
                os.chmod(game_executable, unix_perms)
        try:
            subprocess_env = os.environ.copy()
            subprocess_env[ENV_GAME_TEST_FOXLIB] = str(game_test)
            if use_special_path:
                # Only used for internal testing.
                game_data_pck = check_get_game_data(game_binary_destination)
                game_process = subprocess.Popen([godot_editor_path, "--debug",
                                                 "--main-pack", game_data_pck], env=subprocess_env)
                game_process_pid = game_process.pid
                game_process.wait()
                game_exit_code = game_process.returncode
            elif debug_mode:
                game_exit_code = subprocess.run([game_executable, "--debug"], env=subprocess_env).returncode
            else:
                game_exit_code = subprocess.run([game_executable], env=subprocess_env).returncode
            print_log("Process exit code: " + str(game_exit_code))
        except KeyboardInterrupt:
            print("")
            print_log("Process terminated by the user")
            if game_process_pid != 0:
                os.kill(game_process_pid, signal.SIGTERM)


def run_game(debug_mode, game_test):
    global modInfoDict, modInfo
    init_common([])
    if not support_testing(False, game_test):
        return
    game_version = None
    if modInfo is not None:
        with open(modInfo, 'r') as modInfoFile:
            modInfoDict = json.load(modInfoFile)
        game_version = modInfoDict.get("gameversion")
    if game_version is None or game_version == "*":
        game_version = game_downloads["version"]
    if game_version in bug_fixed_versions_map:
        game_version = bug_fixed_versions_map[game_version]
    download_and_run_game(game_version, debug_mode, game_test)


def test(debug_level=0, trace=False, game_test=-1, game_version=None, use_special_path=False):
    global modBaseName, modInfoDict
    if not support_testing(debug_level > 0 or trace, game_test):
        return
    if not build(debug_level, trace):
        return
    if game_test < 0:
        if modInfoDict.get("FLMH_run_game_test_on") == "test" and support_game_test_raw():
            game_test = 1
        else:
            game_test = 0
    print_log("Installing your mod as " + modBaseName + "_v" + modInfoDict["modversion"] + ".zip")
    game_mods_folder = os.path.join(get_game_data_path(), "mods")
    if not os.path.isdir(game_mods_folder):
        os.makedirs(game_mods_folder)
    zip_name_debug = modBaseName + "_debug.zip"
    zip_name_un_versioned = modBaseName + ".zip"
    zip_name_versioned_start = modBaseName + "_v"
    for f in os.listdir(game_mods_folder):
        if not f.endswith(".zip"):
            continue
        if (f == zip_name_un_versioned or f == zip_name_debug
                or f.startswith(zip_name_versioned_start)):
            os.remove(os.path.join(game_mods_folder, f))
    if debug_level != 0 or trace:
        mod_zip_file_name = modBaseName + "_debug.zip"
    else:
        mod_zip_file_name = modBaseName + "_v" + modInfoDict["modversion"] + ".zip"
    destination_zip_file = os.path.join(game_mods_folder, mod_zip_file_name)
    source_zip_file = os.path.abspath(mod_zip_file_name)
    shutil.copyfile(source_zip_file, destination_zip_file)
    if game_version is None or game_version == "":
        game_version = modInfoDict.get("gameversion")
        if game_version is None or game_version == "*":
            game_version = game_downloads["version"]
        elif game_version in bug_fixed_versions_map:
            game_version = bug_fixed_versions_map[game_version]
    download_and_run_game(game_version, True, game_test, use_special_path=use_special_path)


def debug(debug_level, trace=False):
    global libFoxLibVersion, libFoxLibSemver
    error_backlog = []
    init_common(error_backlog)
    if len(error_backlog) != 0:
        for error in error_backlog:
            print_err(error)
        return
    can_debug = libFoxLibVersion == expect_foxlib_version or compare_semver(debug_foxlib_semver, libFoxLibSemver) >= 0
    if not can_debug and modBaseName != "FoxLib":
        print_err("To use the debug command you must use FoxLib " + debug_foxlib_version + " or later")
        return
    print_warn("Debug command is experimental")
    test(debug_level, trace)


def extract_mod_for_editor(mod_path, root_path):
    base_zip_name = os.path.basename(mod_path)
    base_mod_name = base_zip_name[:-4]
    extract_definitions = {}
    read_definitions_from_mod_file(mod_path, base_mod_name, extract_definitions, True)
    extract_replace_lines = {}
    for key, value in extract_definitions.items():
        strip_line_or_error(key)
        strip_line_or_error(value)
        new_key = "const " + key + " = preload(\"res://" + value + "\")"
        new_value = "#include " + key
        extract_replace_lines[new_key] = new_value
    abs_root = os.path.abspath(root_path)
    with zipfile.ZipFile(mod_path, mode="r") as mod_archive:
        namelist = mod_archive.namelist()
        optionally_remove(namelist, "LICENSE")
        optionally_remove(namelist, "FLMH.py")
        optionally_remove(namelist, "FLMHW.py")
        optionally_remove(namelist, base_mod_name + ".json")
        optionally_remove(namelist, base_mod_name + ".rahi.json")
        optionally_remove(namelist, base_mod_name + EXT_FOXLIB_DEF)
        mod_archive.extractall(abs_root, namelist)
    if len(extract_replace_lines) > 0:
        script_lines = []
        for entry_path in namelist:
            if not entry_path.endswith(".gd"):
                continue
            did_change = False
            entry_file = os.path.join(abs_root, entry_path)
            with open(entry_file, 'r') as entry_data:
                for line in entry_data:
                    stripped_line = line.strip()
                    stripped_value = extract_replace_lines.get(stripped_line)
                    if stripped_value is not None:
                        line = line.replace(stripped_line, stripped_value)
                        did_change = True
                    script_lines.append(line)
            if did_change:
                with open(entry_file, 'w') as entry_writer:
                    entry_writer.write("".join(script_lines))
            script_lines.clear()


def un_foxlib_legacy_files():
    delete_recursively("Player/Bodyparts/Legs/AAFoxLibPreInitHook.gd")
    delete_recursively("Player/Bodyparts/Legs/AAFoxLibVerifier.gd")


def foxlib():
    global main_game_mode, libFoxLibPath, libFoxLibVersion
    init_common([])
    if not main_game_mode:
        print_err("This command is only available when modding inside of a BDCC project")
        return
    if libFoxLibPath is None:
        print_err("FoxLib zip file was not found inside the project, please make sure it is named properly.")
        return
    can_foxlib = libFoxLibVersion == expect_foxlib_version or compare_semver(foxlib_foxlib_semver, libFoxLibSemver) >= 0
    if not can_foxlib:
        print_err("To use the foxlib command you must use FoxLib " + foxlib_foxlib_version + " or later")
        return

    un_foxlib_legacy_files()
    extract_mod_for_editor(libFoxLibPath, ".")
    print_fine("Extracted FoxLib v" + libFoxLibVersion + " to your project")


def un_foxlib():
    global main_game_mode
    init_common([])
    if not main_game_mode:
        print_err("This command is only available when modding inside of a BDCC project")
        return
    if not os.path.exists("FoxLib"):
        print_err("FoxLib isn't present in your project!")
        return
    un_foxlib_legacy_files()
    for path in foxlib_paths:
        delete_recursively(path)
    print_fine("Deleted FoxLib from your project")


def game_data():
    if platform_id is None:
        print_err("Unable to get data folder on this platform: " + platform.system())
        return
    game_data_path = get_game_data_path()
    if not os.path.isdir(game_data_path):
        os.makedirs(game_data_path)
    open_file_program = "xdg-open"
    if platform_id == "windows":
        open_file_program = "start.exe"
    elif platform_id == "mac":
        open_file_program = "open"
    else:
        xdg_desktop = os.getenv("XDG_CURRENT_DESKTOP")
        if xdg_desktop == "GNOME":
            open_file_program = "gnome-open"
        elif xdg_desktop == "KDE":
            open_file_program = "kde-open"
    subprocess.run([open_file_program, game_data_path])


def check_git():
    global git_path
    if platform_id == "windows":
        git_path = "C:\\Program Files\\Git\\bin\\git.exe"
    else:
        git_path = "/usr/bin/git"
    if not os.path.isfile(git_path):
        git_path = None
    return


def git_gui():
    global git_path
    check_git()
    if git_path is None:
        print_err("Git was not found on this system!")
        return
    try:
        game_exit_code = subprocess.run([git_path, "gui"]).returncode
        print_log("Process exit code: " + str(game_exit_code))
    except KeyboardInterrupt:
        print("")
        print_log("Process terminated by the user")


def convert_wav_to_ogg_recursively(from_path: str):
    for f in os.listdir(from_path):
        child_file = os.path.join(from_path, f)
        if os.path.isdir(child_file):
            convert_wav_to_ogg_recursively(child_file)
        elif child_file.endswith(".wav"):
            ogg_file = child_file[:-4] + ".ogg"
            if not os.path.exists(ogg_file):
                convert_wav_to_ogg(child_file, ogg_file)


def wav_to_ogg():
    if not can_convert_wav_to_ogg():
        print_err("Unable to convert wav into ogg due to both pydub and ffmpeg python being missing")
        return
    for source_path in source_paths:
        source_file = os.path.abspath(os.path.join(".", source_path))
        if os.path.isdir(source_file):
            convert_wav_to_ogg_recursively(source_file)


def import_resources_recursively(file, path, suggestion_backlog: list, force):
    for f in os.listdir(file):
        child_file = os.path.join(file, f)
        child_path = path + "/" + f
        if os.path.isdir(child_file):
            import_resources_recursively(child_file, child_path, suggestion_backlog, force)
        elif child_path.endswith(".png"):
            add_png_to_zip(child_file, child_path, None, suggestion_backlog, force)


def import_resources(force=False):
    error_backlog = []
    init_common(error_backlog)
    if len(error_backlog) != 0:
        for error in error_backlog:
            print_err(error)
        return
    suggestion_backlog = []
    for source_path in source_paths:
        source_file = os.path.abspath(os.path.join(".", source_path))
        if os.path.isdir(source_file):
            import_resources_recursively(source_file, source_path, suggestion_backlog, force)
    for suggestion in suggestion_backlog:
        print_warn(suggestion)
    print_fine("Successfully imported all supported resources")


def deimport_resources_recursively(file, path, suggestion_backlog: list):
    for f in os.listdir(file):
        child_file = os.path.join(file, f)
        child_path = path + "/" + f
        if os.path.isdir(child_file):
            deimport_resources_recursively(child_file, child_path, suggestion_backlog)
        elif child_path.endswith(".stex") or child_path.endswith(".import"):
            os.unlink(child_file)


def deimport_resources():
    error_backlog = []
    init_common(error_backlog)
    if len(error_backlog) != 0:
        for error in error_backlog:
            print_err(error)
        return
    suggestion_backlog = []
    for source_path in source_paths:
        source_file = os.path.abspath(os.path.join(".", source_path))
        if os.path.isdir(source_file):
            deimport_resources_recursively(source_file, source_path, suggestion_backlog)
    for suggestion in suggestion_backlog:
        print_warn(suggestion)
    print_fine("Successfully deimported all supported resources")


def lazy_aa_offset(pos_list: list, dx, dy):
    if dx == 0 and dy == 0:
        return
    if dx > 0:
        sym = "pX"
    elif dx < 0:
        sym = "nX"
    else:
        if dy < 0:
            add_if_missing(pos_list, "pXnY")
            add_if_missing(pos_list, "nXnY")
        else:
            add_if_missing(pos_list, "pXpY")
            add_if_missing(pos_list, "nXpY")
        return
    if dy > 0:
        add_if_missing(pos_list, sym + "pY")
    elif dy < 0:
        add_if_missing(pos_list, sym + "nY")
    else:
        if dx < 0:
            add_if_missing(pos_list, "nXnY")
            add_if_missing(pos_list, "nXpY")
        else:
            add_if_missing(pos_list, "pXnY")
            add_if_missing(pos_list, "pXpY")


def apply_lazy_aa(file: str, path: str) -> None:
    millis_start = round(time.time() * 1000)
    img = Image.open(file)
    if img.mode != "RGBA":
        img = img.convert("RGBA")
    pixels = img.load()
    width, height = img.size
    neighbour_offsets = [
        (1, 1), (0, 1), (-1, 1), (1, 0), (-1, 0), (1, -1), (0, -1), (-1, -1),
    ]
    did_work = False
    for y in range(height - 1):
        if y == 0:
            continue
        for x in range(width - 1):
            if x == 0:
                continue
            r, g, b, a = pixels[x, y]
            fast_lm = r + g + b
            rn, gn, bn = 0, 0, 0
            pos_list = []
            if a <= 2:
                # Transparent pixel check
                neighbor_count = 0
                for dx, dy in neighbour_offsets:
                    rx, gx, bx, ax = pixels[x + dx, y + dy]
                    if ax < 2:
                        continue
                    if abs(rn - rx) <= 1 and abs(gn - gx) <= 1 and abs(bn - bx) <= 1 and abs(ax - 63) <= 1:
                        continue
                    if ax < 253:
                        neighbor_count = 0
                        break
                    if neighbor_count == 0:
                        lazy_aa_offset(pos_list, dx, dy)
                        neighbor_count = 1
                        rn = rx
                        gn = gx
                        bn = bx
                    elif abs(rn - rx) > 1 or abs(gn - gx) > 1 or abs(bn - bx) > 1:
                        neighbor_count = 0
                        break
                    else:
                        lazy_aa_offset(pos_list, dx, dy)
                        neighbor_count = neighbor_count + 1
                if (neighbor_count == 4 and len(pos_list) != 4) or neighbor_count >= 6:
                    pixels[x, y] = (rn, gn, bn, 63)
                    did_work = True
                continue
            if a < 253 or fast_lm <= 2:
                continue
            # Opaque pixel check
            neighbor_count = 0
            fast_lmn = 0
            self_pos_list = []
            for dx, dy in neighbour_offsets:
                rx, gx, bx, ax = pixels[x + dx, y + dy]
                if ax < 253:
                    neighbor_count = 0
                    break
                if abs(r - rx) <= 1 and abs(g - gx) <= 1 and abs(b - bx) <= 1:
                    lazy_aa_offset(self_pos_list, dx, dy)
                    continue
                if neighbor_count == 0:
                    lazy_aa_offset(pos_list, dx, dy)
                    neighbor_count = 1
                    rn = rx
                    gn = gx
                    bn = bx
                    fast_lmn = rn + gn + gx
                elif abs(rn - rx) > 1 or abs(gn - gx) > 1 or abs(bn - bx) > 1:
                    neighbor_count = 0
                    break
                else:
                    lazy_aa_offset(pos_list, dx, dy)
                    neighbor_count = neighbor_count + 1
            if fast_lm <= fast_lmn and neighbor_count == 4:
                neighbor_count = 0
            if neighbor_count == 8:
                pixels[x, y] = (rn, gn, bn, 255)
                did_work = True
            elif neighbor_count >= 4 and len(pos_list) != 4 and len(self_pos_list) != 4:
                ifc = 2
                efc = 1
                tfc = ifc + efc
                nr = int(((r * ifc) + (rn * efc)) / tfc)
                ng = int(((g * ifc) + (gn * efc)) / tfc)
                nb = int(((b * ifc) + (bn * efc)) / tfc)
                pixels[x, y] = (nr, ng, nb, 255)
                did_work = True
    if did_work:
        img.save(file, optimize=True)
        ms_duration = round(time.time() * 1000) - millis_start
        print_log("Applied Lazy-AA to " + path + " (Took " + str(ms_duration) + "ms)")
    else:
        ms_duration = round(time.time() * 1000) - millis_start
        print_log("No Lazy-AA Needed for " + path + " (Took " + str(ms_duration) + "ms)")


def apply_lazy_aa_recursively(file, path, suggestion_backlog: list):
    for f in os.listdir(file):
        child_file = os.path.join(file, f)
        child_path = path + "/" + f
        if os.path.isdir(child_file):
            apply_lazy_aa_recursively(child_file, child_path, suggestion_backlog)
        elif child_path.endswith(".png"):
            apply_lazy_aa(child_file, child_path)


def task_apply_lazy_aa():
    error_backlog = []
    init_common(error_backlog)
    if len(error_backlog) != 0:
        for error in error_backlog:
            print_err(error)
        return
    if Image is None:
        print_err("Need pillow (Aka. PIL) python library to apply lazy AA")
        return
    suggestion_backlog = []
    for source_path in source_paths:
        source_file = os.path.abspath(os.path.join(".", source_path))

        if os.path.isdir(source_file):
            apply_lazy_aa_recursively(source_file, source_path, suggestion_backlog)
    for suggestion in suggestion_backlog:
        print_warn(suggestion)
    print_fine("Successfully applied lazy anti aliasing to images")


def apply_upscale_x2(file: str, path: str) -> None:
    millis_start = round(time.time() * 1000)
    img = Image.open(file)
    width, height = img.size
    if width > 2048 or height > 2048:
        print_log("Skip " + path + " for upscale, has it is already big enough!")
        return
    img_x2 = img.resize((width * 2, height * 2), Image.Resampling.BILINEAR)
    img_x2.save(file, optimize=True)
    ms_duration = round(time.time() * 1000) - millis_start
    print_log("Applied X2 Upscale to " + path + " (Took " + str(ms_duration) + "ms)")


def apply_upscale_x2_recursively(file, path, suggestion_backlog: list):
    for f in os.listdir(file):
        child_file = os.path.join(file, f)
        child_path = path + "/" + f
        if os.path.isdir(child_file):
            apply_upscale_x2_recursively(child_file, child_path, suggestion_backlog)
        elif child_path.endswith(".png"):
            apply_upscale_x2(child_file, child_path)


def task_apply_upscale_x2():
    error_backlog = []
    init_common(error_backlog)
    if len(error_backlog) != 0:
        for error in error_backlog:
            print_err(error)
        return
    if Image is None:
        print_err("Need pillow (Aka. PIL) python library to upscale X2")
        return
    suggestion_backlog = []
    for source_path in source_paths:
        source_file = os.path.abspath(os.path.join(".", source_path))

        if os.path.isdir(source_file):
            apply_upscale_x2_recursively(source_file, source_path, suggestion_backlog)
    for suggestion in suggestion_backlog:
        print_warn(suggestion)
    print_fine("Successfully applied X2 Upscaling to images")


def update_cli_tab_completer():
    global main_game_mode, possible_commands, modInfoDict, git_path
    source_mode = modInfoDict.get("FLMH_source_mode") or "processed"
    source_no_edit = (source_mode == "raw" or source_mode == "parsed")
    possible_commands = ["help", "version", "init", "check", "build"]
    if platform_id is not None and platform_id != "mac" and can_download_file():
        for possible_command in ["run-game", "run-debug", "test"]:
            possible_commands.append(possible_command)
        if support_game_test_raw():
            possible_commands.append("run-game-test")
        if not source_no_edit:
            possible_commands.append("trace0")
            if show_me_experimental_stuff:
                for possible_command in \
                        ["debug1", "debug2", "debug3",
                         "trace1", "trace2", "trace3"]:
                    possible_commands.append(possible_command)
        if git_path is not None:
            possible_commands.append("git-gui")
    if main_game_mode:
        possible_commands.append("foxlib")
        possible_commands.append("un-foxlib")
    if platform_id is not None:
        possible_commands.append("game-data")
    if can_convert_wav_to_ogg():
        possible_commands.append("wav-to-ogg")
    possible_commands.append("quit")
    possible_commands.append("exit")
    possible_commands.sort()


def run_task(task_command, task_argument, from_cli):
    if task_command == "help":
        init_common([])
        source_mode = modInfoDict.get("FLMH_source_mode") or "processed"
        source_no_edit = (source_mode == "raw" or source_mode == "parsed")
        help_arrow = ansi_bold + "->" + ansi_reset
        print(ansi_reset + "FoxLib ModHelper v" + tool_version + " usage:")
        print(" help       " + help_arrow + " Show this help message")
        print(" version    " + help_arrow + " Show this tool version and exit")
        print(" init       " + help_arrow + " Load the mod info json, and create it if missing")
        print(" check      " + help_arrow + " Check if FoxLib ModHelper can parse your source code correctly")
        print(" build      " + help_arrow + " Build your mod and make a zip file out of it")
        if can_convert_wav_to_ogg() and not main_game_mode:
            print(" wav-to-ogg " + help_arrow + " Convert .wav to .ogg (Original .wav files preserved)")
        if platform_id is not None and platform_id != "mac" and can_download_file():
            print(" run-game   " + help_arrow + " Run Broken Dreams Correctional Center without doing anything extra")
            print(" run-debug  " + help_arrow + " Run Broken Dreams Correctional Center in debug mode")
            print(" test       " + help_arrow + " Upload your mod to the mod folder of the game and run it")
            if not source_no_edit:
                if show_me_experimental_stuff:
                    print(" debug(1-3) " + help_arrow + " Like test, but make a special debug build")
                    print(" debug1     " + help_arrow + " Only debug Null access (Safe)")
                    print(" debug2     " + help_arrow + " Debug method calls that are safe to hook into (Default)")
                    print(" debug3     " + help_arrow + " Debug all method calls (Unsafe)")
        if main_game_mode:
            print(" foxlib     " + help_arrow + " Install FoxLib into BDCC project (To use in editor)")
            print(" un-foxlib  " + help_arrow + " Un-Install FoxLib from BDCC project")
        if platform_id is not None:
            print(" game-data  " + help_arrow + " Open BDCC game data folder")
        if from_cli:
            print(" quit/exit  " + help_arrow + " Quit FoxLib ModHelper console")
        else:
            print(" cli        " + help_arrow + " Run FoxLib ModHelper as console")
    elif task_command == "version":
        print("FoxLib ModHelper v" + tool_version)
    elif task_command == "init":
        init()
    elif task_command == "check":
        check()
    elif task_command == "build":
        build()
    elif task_command == "run-game":
        run_game(False, 0)
    elif task_command == "run-game-test":
        run_game(False, 2)
    elif task_command == "run-debug":
        run_game(True, 0)
    elif task_command == "test":
        test(game_version=task_argument)
    elif task_command == "xtest":
        # For internal testing
        test(game_version=task_argument, use_special_path=True)
    elif task_command == "debug1":
        debug(1)
    elif task_command == "debug" or task_command == "debug2":
        debug(2)
    elif task_command == "debug3":
        debug(3)
    elif task_command == "trace0":
        debug(0, True)
    elif task_command == "trace1":
        debug(1, True)
    elif task_command == "trace" or task_command == "trace2":
        debug(2, True)
    elif task_command == "trace3":
        debug(3, True)
    elif task_command == "foxlib":
        foxlib()
    elif task_command == "un-foxlib":
        un_foxlib()
    elif task_command == "game-data":
        game_data()
    elif task_command == "git-gui":
        git_gui()
    elif task_command == "wav-to-ogg":
        wav_to_ogg()
    elif task_command == "import":
        import_resources()
    elif task_command == "reimport":
        import_resources(True)
    elif task_command == "deimport":
        deimport_resources()
    elif task_command == "lazy-aa":
        task_apply_lazy_aa()
    elif task_command == "upscale-x2":
        task_apply_upscale_x2()
    else:
        print_err("Unknown task: " + task_command)


def tab_completer(text, state):
    global possible_commands
    for cmd in possible_commands:
        if cmd.startswith(text):
            if not state:
                return cmd
            else:
                state -= 1
    return None


def cli():
    global modBaseName
    should_run = True
    check_git()
    if readline is not None:
        if readline.__doc__ is not None and 'libedit' in readline.__doc__:
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
        readline.set_completer_delims(' \t\n')
        readline.set_completer(tab_completer)
        update_cli_tab_completer()
    while should_run:
        if modBaseName is not None and len(modBaseName) > 0:
            terminal_set_console_title("FoxLib ModHelper v" + tool_version + " (" + modBaseName + ")")
        else:
            terminal_set_console_title("FoxLib ModHelper v" + tool_version)
        try:
            command = input(FLMH_CLI)
            command_arg = ""
            command_index = command.find(" ")
            if command_index != -1:
                command_arg = command[command_index + 1:]
                command = command[0:command_index]
        except KeyboardInterrupt:
            print("")
            command = "quit"
            command_arg = ""
        if command == "quit" or command == "exit":
            should_run = False
        elif command != "cli" and command != "":
            run_task(command, command_arg, True)


# This code will be copied in "FLMHW.py" (Aka. FoxLib ModHelper Wrapper)
if __name__ == '__main__':
    task = "ERROR"
    task_arg = ""
    if len(sys.argv) <= 1:
        task = "cli-help"
    else:
        task = sys.argv[1]
        if len(sys.argv) > 2:
            task_arg = sys.argv[2]

    if task == "quit" or task == "exit":
        print_err("Only available to exit cli mode")
    elif task == "cli":
        init_common([])
        cli()
    elif task == "cli-help":
        run_task("help", task_arg, True)
        cli()
    else:
        run_task(task, task_arg, False)
