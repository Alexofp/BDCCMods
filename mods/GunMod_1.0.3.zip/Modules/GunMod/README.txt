Mod name: GunMod
Category: Weapons / PlayerSlavery Scenario
Game Version: 0.3.2
Mod Version: 1.0.3

Description:
Adds a bunch of firearms and a full PlayerSlavery scenario built around them: "War Draft", a conscription story between AlphaCorp and the Syndicate. Gameplay loop is similar to the Drug Den, but WITH GUNZ.

War Draft: you get conscripted into AlphaCorp's war against the Syndicate, whether you like it or not. Run patrols and objectives for AlphaCorp under Sergeant Drask, or end up defecting to the Syndicate and Commander Vex instead. Each side tracked with its own stat, each with its own hub, and each building toward its own real finale fight.

Features:
- 5 new weapons: Pistol, Laser Pistol (taken from base game), Service Rifle, Energy Rifle, Marauder Rifle
- Sold by Mirri; the 3 rifles also drop (rarely) from Drug Den junkie loot
- New two-handed rifle hold/aim/fire animations
- New "War Draft" scenario in the PlayerSlavery picker
- Two full sides to play: stay loyal to AlphaCorp under Sergeant Drask, or defect to the Syndicate under Commander Vex
- Each side tracked with its own stat (AlphaCorp morale / Syndicate corruption)
- Real patrol loop: patrols, ambushes, bomb/rescue objectives, captured-soldier encounters
- Armory restock that also heals your pain
- Kidlat cameo
- Conscript uniform gear
- Two full finale boss fights, one per faction, with reactive dialogue
- Hand scripted cool and awesome sex scenes
- 4 distinct endings

1.0.3 fixes: regular prison guards could randomly and permanently show up red on the world map (looking like a HighSec inmate) - caused by the Syndicate detention jailer's map-color fix leaking into the game's normal ambient guard spawner. Guards are no longer affected going forward (already-mistagged guards on existing saves stay red until they respawn).

1.0.2 fixes: Commander Vex's sex scenes (talk-hub "Sex?" option, and claiming a defeated Drask during the Syndicate finale) had the pose backwards from the dialogue - Vex now actually tops like she's supposed to. The rifle idle/aim holds didn't loop and would freeze on the last frame. Those same sex scenes, plus claiming a defeated Vex during the AlphaCorp finale, now actually step through separate tease/sex/fast/finish stages instead of jumping straight to one frozen pose. Also fixed a soft lock where an unrelated quest's periodic "wake up in your cell" event (e.g. Eliza's chastity content) could teleport you off the War Draft map mid-scenario without properly ending it.

[This is my biggest project yet. Please let me know if you hit anything broken. Two base-game files are edited directly for the rifle hold poses rather than being purely additive, so this could conflict with another mod touching the same files.]
