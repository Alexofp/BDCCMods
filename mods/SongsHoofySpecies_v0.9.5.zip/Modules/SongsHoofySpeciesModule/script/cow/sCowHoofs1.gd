extends BodypartLeg

func _init():
	visibleName = "cow hoofs"
	id = "scowhoofs1"

func getCompatibleSpecies():
	return ["scow"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/Cowhoofs1/SCowHoofs1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}


