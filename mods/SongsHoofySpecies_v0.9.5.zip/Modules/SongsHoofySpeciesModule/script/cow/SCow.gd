extends Species

func _init():
	id = "scow"
	
func getVisibleName():
	return "Cow"

func getDefaultLegs(_gender):
	return "scowhoofs1"

func getDefaultTail(_gender):
	return "sunitail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "Milky Friends"

func getDefaultHead(_gender):
	return "scowhead1"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "suniears1"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "scowhorns1"
	else:
		return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("songjohorseparts" in GlobalRegistry.getModules()):
			return "songhorsepenis"
		else:
			return "equinepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 10.0],
		[2, 1.5],
		[3, 0.5],
	]
