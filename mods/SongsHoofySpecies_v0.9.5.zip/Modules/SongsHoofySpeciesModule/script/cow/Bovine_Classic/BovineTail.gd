extends BodypartTail

func _init():
	visibleName = "Classic bovine tail"
	id = "bovinetail"

func getCompatibleSpecies():
	return ["scow", "bovine"]

func getCharacterCreatorDesc():
	return "parts from bovine mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/Bovine_Classic/BovineTail/BovineTail.tscn"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
