extends BodypartHead

func _init():
	visibleName = "Classic bovine head"
	id = "bovinehead"

func getCompatibleSpecies():
	return ["scow", "bovine"]

func getCharacterCreatorDesc():
	return "parts from bovine mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/Bovine_Classic/BovineHead/BovineHead.tscn"

func npcGenerationWeight(_dynamicCharacter):
	var sp = _dynamicCharacter.npcSpecies
	if sp == ["scow"]:
		return 0.0
	elif sp == ["bovine"]:
		return 1.0
