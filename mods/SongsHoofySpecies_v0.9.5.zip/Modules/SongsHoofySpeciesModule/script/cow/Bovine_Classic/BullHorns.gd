extends BodypartHorns

func _init():
	visibleName = "Classic bull horns"
	id = "bullhorns"

func getCompatibleSpecies():
	return ["scow", "bovine"]

func getCharacterCreatorDesc():
	return "parts from bovine mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/Bovine_Classic/BullHorn/BullHorn.tscn"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
