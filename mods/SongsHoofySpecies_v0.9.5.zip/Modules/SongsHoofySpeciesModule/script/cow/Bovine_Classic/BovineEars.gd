extends BodypartEars

func _init():
	visibleName = "Classic bovine ears"
	id = "bovineears"

func getCompatibleSpecies():
	return ["scow", "bovine"]

func getCharacterCreatorDesc():
	return "parts from bovine mod by avery winters"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/Bovine_Classic/BovineEar/BovineEars.tscn"


#(just in case)
#func getRiggedParts(_character):
#	var curPart
#	var cr = _character.get_name()
#	if cr != "Player":
#		cr = _character.id
#	if GM.main.saveDynamicCharactersData().has(cr):
#		curPart = _character.saveData()["bodyparts"]["head"]["id"]
#	else:
#		curPart = GM.pc.saveData().bodyparts["head"]["id"]
#	if curPart == "scowhead1":
#		return {"head": "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Ears1/Uniears1.tscn"}
#	else:
#		return {"head": "res://Modules/SongsHoofySpeciesModule/pngs/cow/Bovine_Legacy/BovineEar/BovineEars.tscn"}
