extends BodypartPenis

func _init():
	visibleName = "bull penis"
	id = "bullpenis"

func getCompatibleSpecies():
	return ["scow", "bovine"]

func getLewdAdjective():
	return RNG.pick(["bovine", "tapered", "flared"])

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/Bovine_Classic/BullPenis/BullPenis.tscn"

func getCharacterCreatorDesc():
	return "This is from the original mod, but if you've seen it, why in God's name would someone ever use it. I asked and apparently some deranged motherfucker back in the day asked Max to make it like this. I'm keeping it here for the sake of preservation but I turned off NPC generation for it. I, Anon, am currently beholden unto nobody, and im telling whoever wanted this, past or present, to go fuck themselves."

func npcGenerationWeight(_dynamicCharacter):
	return 0.0
