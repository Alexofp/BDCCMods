extends BodypartHorns

func _init():
	visibleName = "cow horns1"
	id = "scowhorns1"

func getCompatibleSpecies():
	return ["scow"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/CowHorns1/SCowHorns1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

