extends BodypartHead

func _init():
	visibleName = "cow head 1"
	id = "scowhead1"

func getCompatibleSpecies():
	return ["scow"]

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/CowHead1/SCowHead1.tscn"

func getHeadLength():
	return 0.30
