extends BodypartHead

func _init():
	visibleName = "cow head 2"
	id = "scowhead2"

func getCompatibleSpecies():
	return ["scow"]

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/cow/CowHead2/SCowHead2.tscn"

func getHeadLength():
	return 0.30
