extends Species

func _init():
	id = "sgoat"
	
func getVisibleName():
	return "Goat"

func getDefaultLegs(_gender):
	return "sgoathoofs1"

func getDefaultTail(_gender):
	return "sunitail2"

func isPlayable():
	return true

func getVisibleDescription():
	return "Curious and Stubbron friends."

func getDefaultHead(_gender):
	return "sgoathead1"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "suniears3"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "sgoathorns1"
	else:
		return "sgoathorns2"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 8.0],
		[3, 4.0],
		[4, 2.0],
		[5, 0.5],
	]
