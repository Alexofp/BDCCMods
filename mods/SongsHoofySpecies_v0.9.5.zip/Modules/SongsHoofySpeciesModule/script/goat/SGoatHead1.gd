extends BodypartHead

func _init():
	visibleName = "goat head 1"
	id = "sgoathead1"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goathead1/SGoatHead1.tscn"

func getHeadLength():
	return 0.30

func getCharacterCreatorDesc():
	return "From Hoofy Species"
	
