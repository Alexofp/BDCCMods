extends BodypartHead

func _init():
	visibleName = "goat head 2"
	id = "sgoathead2"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goathead2/SGoatHead2.tscn"

func getHeadLength():
	return 0.25

func getCharacterCreatorDesc():
	return "From Hoofy Species"
