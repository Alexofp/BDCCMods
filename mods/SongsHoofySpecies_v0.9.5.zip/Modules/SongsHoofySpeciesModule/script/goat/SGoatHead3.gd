extends BodypartHead

func _init():
	visibleName = "Gazelle head"
	id = "sgoathead3"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goathead3/SGoatHead3.tscn"

func getHeadLength():
	return 0.35

func getCharacterCreatorDesc():
	return "From Hoofy Species"
