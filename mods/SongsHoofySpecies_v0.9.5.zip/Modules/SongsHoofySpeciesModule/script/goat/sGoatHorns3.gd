extends BodypartHorns

func _init():
	visibleName = "gazelle horns"
	id = "sgoathorns3"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goathorns3/SGoatHorns3.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func npcGenerationWeight(_dynamicCharacter):
	var npchead = _dynamicCharacter.getBodypart(BodypartSlot.Head)
	if npchead.id == "sgoathead3":
		return 3.0
	else :
		return 0.0
