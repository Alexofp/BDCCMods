extends BodypartHorns

func _init():
	visibleName = "goat horns 1"
	id = "sgoathorns1"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goathorns1/SGoatHorns1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func npcGenerationWeight(_dynamicCharacter):
	var npchead = _dynamicCharacter.getBodypart(BodypartSlot.Head)
	if npchead.id == "sgoathead3":
		return 0.0
	else :
		return 1.0
