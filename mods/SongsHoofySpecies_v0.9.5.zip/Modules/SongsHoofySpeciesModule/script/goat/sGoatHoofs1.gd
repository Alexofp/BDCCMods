extends BodypartLeg

func _init():
	visibleName = "goat hoofs"
	id = "sgoathoofs1"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goathoofs1/SGoatHoofs1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
