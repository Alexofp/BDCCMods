extends BodypartEars

func _init():
	visibleName = "Goat Ears 1"
	id = "goatears1"

func getCompatibleSpecies():
	return ["sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/goat/goatEars1/goatears1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
