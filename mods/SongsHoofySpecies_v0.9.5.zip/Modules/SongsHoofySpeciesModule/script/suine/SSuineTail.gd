extends BodypartTail

func _init():
	visibleName = "Pig tail"
	id = "suinetail"

func getCompatibleSpecies():
	return ["ssuine"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/suine/suineTail/SSuintail.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
