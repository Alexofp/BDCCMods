extends BodypartHead

func _init():
	visibleName = "boar head"
	id = "ssuinehead2"

func getCompatibleSpecies():
	return ["ssuine"]

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/suine/suineHead2/suineHead2.tscn"

func getHeadLength():
	return 0.25
