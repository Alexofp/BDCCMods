extends BodypartLeg

func _init():
	visibleName = "Pig hoofs"
	id = "ssuinehoofs"

func getCompatibleSpecies():
	return ["ssuine"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/suine/suineHoofs/SSuineHoofs1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
