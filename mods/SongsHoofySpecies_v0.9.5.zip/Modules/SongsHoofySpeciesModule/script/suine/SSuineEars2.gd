extends BodypartEars

func _init():
	visibleName = "Suine Ears 2"
	id = "ssuineears2"

func getCompatibleSpecies():
	return ["ssuine"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/suine/suineEars2/suineEars2.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func npcGenerationWeight(_dynamicCharacter):
	var npchead = _dynamicCharacter.getBodypart(BodypartSlot.Head)
	if npchead.id == "ssuinehead1":
		return 0.5
	elif npchead.id == "ssuinehead2":
		return 1.0
