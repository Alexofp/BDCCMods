extends BodypartHead

func _init():
	visibleName = "pig head"
	id = "ssuinehead1"

func getCompatibleSpecies():
	return ["ssuine"]

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/suine/suineHead1/suineHead1.tscn"

func getHeadLength():
	return 0.25
