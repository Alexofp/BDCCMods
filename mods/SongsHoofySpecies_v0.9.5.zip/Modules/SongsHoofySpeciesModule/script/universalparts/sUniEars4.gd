extends BodypartEars

func _init():
	visibleName = "Hoofy Ears4"
	id = "suniears4"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Ears4/Uniears4.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
