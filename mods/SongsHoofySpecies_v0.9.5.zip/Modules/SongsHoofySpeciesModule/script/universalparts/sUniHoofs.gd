extends BodypartLeg

func _init():
	visibleName = "Hoofy Hoofs"
	id = "sunihoofs1"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/hoofs/Unihoofs.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
