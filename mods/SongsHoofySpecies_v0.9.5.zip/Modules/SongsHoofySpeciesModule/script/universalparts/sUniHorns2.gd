extends BodypartHorns

func _init():
	visibleName = "Hoofy Horns2"
	id = "sunihorns2"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Horns2/UniHorns2.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func npcGenerationWeight(_dynamicCharacter):
	var npchead = _dynamicCharacter.getBodypart(BodypartSlot.Head)
	if npchead.id == "sgoathead3":
		return 0.5
	else :
		return 1.0
