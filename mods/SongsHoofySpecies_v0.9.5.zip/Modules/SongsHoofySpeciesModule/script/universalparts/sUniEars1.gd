extends BodypartEars

func _init():
	visibleName = "Hoofy Ears1"
	id = "suniears1"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Ears1/Uniears1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
