extends BodypartTail

func _init():
	visibleName = "Hoofy tail2"
	id = "sunitail2"

func getCompatibleSpecies():
	return ["sdeer", "sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/tail2/Unitail2.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
