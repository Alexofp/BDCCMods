extends BodypartTail

func _init():
	visibleName = "Hoofy tail1"
	id = "sunitail1"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/tail1/Unitail1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
