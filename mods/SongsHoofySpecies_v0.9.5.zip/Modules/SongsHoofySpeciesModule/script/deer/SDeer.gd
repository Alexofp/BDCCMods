extends Species

func _init():
	id = "sdeer"
	
func getVisibleName():
	return "Deer"

func getDefaultLegs(_gender):
	return "sdeerhoofs1"

func getDefaultTail(_gender):
	return "sunitail2"

func isPlayable():
	return true

func getVisibleDescription():
	return "Herbivores of the forest"

func getDefaultHead(_gender):
	return "sdeerhead1"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "suniears2"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "sdeerantlers1"
	else:
		return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 7.0],
		[2, 5.0],
		[3, 0.5],
	]
