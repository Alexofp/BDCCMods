extends BodypartHorns

func _init():
	visibleName = "deer antlers 4"
	id = "sdeerantlers4"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerantlers4/SDeerAntlers4.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

