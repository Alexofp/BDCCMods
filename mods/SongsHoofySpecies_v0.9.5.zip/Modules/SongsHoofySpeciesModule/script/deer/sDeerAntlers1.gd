extends BodypartHorns

func _init():
	visibleName = "deer antlers"
	id = "sdeerantlers1"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerantlers1/SDeerAntlers1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

