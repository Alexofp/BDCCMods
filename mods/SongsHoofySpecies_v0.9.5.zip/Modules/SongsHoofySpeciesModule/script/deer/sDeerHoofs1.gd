extends BodypartLeg

func _init():
	visibleName = "deer hoofs"
	id = "sdeerhoofs1"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerhoofs1/SDeerHoofs1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

