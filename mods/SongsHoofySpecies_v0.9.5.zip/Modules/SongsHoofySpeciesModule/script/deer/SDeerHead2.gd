extends BodypartHead

func _init():
	visibleName = "deer head 2"
	id = "sdeerhead2"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerHead2/SDeerHead2.tscn"

func getHeadLength():
	return 0.45

func getCharacterCreatorDesc():
	return "From Hoofy Species"
