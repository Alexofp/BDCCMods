extends BodypartHorns

func _init():
	visibleName = "deer antlers 3"
	id = "sdeerantlers33"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerantlers3/SDeerAntlers3.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

