extends BodypartHorns

func _init():
	visibleName = "deer antlers 2"
	id = "sdeerantlers2"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerantlers2/SDeerAntlers2.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

