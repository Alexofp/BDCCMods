extends Species

func _init():
	id = "deer"

func isPlayable():
	return true

func getVisibleName():
	return "ClassicDeer"

func getVisibleDescription():
	return "species from deer mod by avery winter"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	return "deerlegs"

func getDefaultTail(_gender):
	return "deertail"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "deerhorns"
	else:
		return null

func getDefaultHead(_gender):
	return "deerhead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "deerears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersEquinePenises" in GlobalRegistry.getModules()):
			return "equinepenistapered"
		else:
			return "equinepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 2.0],
		[2, 8.0],
		[3, 6.0],
		[4, 4.0],
		[5, 2.0],
		[6, 1.0],
		[7, 0.5],
	]

func npcGenerationWeight():
	return 0.0
