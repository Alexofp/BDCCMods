extends BodypartTail

func _init():
	visibleName = "Classic deer tail"
	id = "deertail"

func getCompatibleSpecies():
	return ["sdeer", "deer"]

func getCharacterCreatorDesc():
	return "parts from deer mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/Deer_Classic/DeerTail/DeerTail.tscn"
