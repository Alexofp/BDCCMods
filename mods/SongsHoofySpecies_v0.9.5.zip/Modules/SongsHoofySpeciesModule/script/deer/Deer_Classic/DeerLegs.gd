extends BodypartLeg

func _init():
	visibleName = "Classic deer legs"
	id = "deerlegs"

func getCompatibleSpecies():
	return ["sdeer", "deer"]

func getCharacterCreatorDesc():
	return "parts from deer mod by avery winters"

func getDoll3DScene():
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "res://Modules/SongsHoofySpeciesModule/pngs/deer/Deer_Classic/DeerLegs/DeerLegsFluffy.tscn"
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/Deer_Classic/DeerLegs/DeerLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func npcGenerationWeight(_dynamicCharacter):
	var sp = _dynamicCharacter.npcSpecies
	if sp == ["sdeer"]:
		return 0.0
	elif sp == ["deer"]:
		return 1.0
