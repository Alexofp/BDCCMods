extends BodypartHorns

func _init():
	visibleName = "Classic deer horns"
	id = "deerhorns"

func getCompatibleSpecies():
	return ["sdeer", "deer"]

func getCharacterCreatorDesc():
	return "parts from deer mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/Deer_Classic/DeerHorn/DeerHorns.tscn"
