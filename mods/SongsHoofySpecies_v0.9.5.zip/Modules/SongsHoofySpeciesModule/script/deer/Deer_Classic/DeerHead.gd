extends BodypartHead

func _init():
	visibleName = "Classic deer head"
	id = "deerhead"

func getCompatibleSpecies():
	return ["sdeer", "deer"]

func getCharacterCreatorDesc():
	return "parts from deer mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/Deer_Classic/DeerHead/DeerHead.tscn"

func npcGenerationWeight(_dynamicCharacter):
	var sp = _dynamicCharacter.npcSpecies
	if sp == ["sdeer"]:
		return 0.0
	elif sp == ["deer"]:
		return 1.0
