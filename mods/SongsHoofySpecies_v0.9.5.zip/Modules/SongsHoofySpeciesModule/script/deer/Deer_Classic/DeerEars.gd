extends BodypartEars

func _init():
	visibleName = "Classic deer ears"
	id = "deerears"

func getCompatibleSpecies():
	return ["sdeer", "deer"]

func getCharacterCreatorDesc():
	return "parts from deer mod by avery winters"

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/Deer_Classic/DeerEars/DeerEars.tscn"
