extends BodypartHead

func _init():
	visibleName = "deer head 1"
	id = "sdeerhead1"

func getCompatibleSpecies():
	return ["sdeer"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/deer/deerHead1/SDeerHead1.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "From Hoofy Species"
