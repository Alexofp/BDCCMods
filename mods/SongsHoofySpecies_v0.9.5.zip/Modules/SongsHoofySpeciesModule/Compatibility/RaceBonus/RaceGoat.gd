extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "Racegoat"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("sgoat")):
		return true
	return false


func getEffectName():
	return "Trouble makers"

func getEffectDesc():
	return "As a goat, you are swift and stubborn, but still Vulnerable prey. "

func getEffectImage():
	return "res://Images/StatusEffects/dodging.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff, [20.0]),
		buff(Buff.StatBuff, [Stat.Agility, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, -4]),
		buff(Buff.StatBuff, [Stat.Strength, 3]),
		buff(Buff.ReceivedLustDamageBuff, [-25]),
		buff(Buff.PhysicalDamageBuff, [10.0]),
		buff(Buff.ReceivedPhysicalDamageBuff, [10.0]),
	]
