extends Reference
class_name ModdedCharacterGeneratorBase

static func makeBase(idprefix = "dynamicnpc", _args = {}):
	var dynamicCharacter = DynamicCharacter.new()
	if(is_instance_valid(GM.main)):
		dynamicCharacter.id = GM.main.generateCharacterID(idprefix)
	
	if(_args.has(NpcGen.Temporary) && _args[NpcGen.Temporary]):
		dynamicCharacter.temporaryCharacter = true
	
	if(is_instance_valid(GM.main)):
		GM.main.addDynamicCharacter(dynamicCharacter)
	elif(_args.has("addtonode") && _args["addtonode"]):
		_args["addtonode"].add_child(dynamicCharacter)
	return dynamicCharacter

static func pickGender(character:DynamicCharacter, _args = {}):
	if(_args.has(NpcGen.HasVagina) && _args[NpcGen.HasVagina]):
		character.npcGeneratedGender = GM.main.getEncounterSettings().generateGenderFromAllowed(NpcGender.getAllWithVagina())
	elif(_args.has(NpcGen.HasPenis) && _args[NpcGen.HasPenis]):
		character.npcGeneratedGender = GM.main.getEncounterSettings().generateGenderFromAllowed(NpcGender.getAllWithPenis())
	elif(_args.has(NpcGen.GenderList)):
		character.npcGeneratedGender = GM.main.getEncounterSettings().generateGenderFromAllowed(_args[NpcGen.GenderList])
	elif(_args.has(NpcGen.Gender)):
		character.npcGeneratedGender = _args[NpcGen.Gender]
	else:
		character.npcGeneratedGender = GM.main.getEncounterSettings().generateGender()

static func pickName(character:DynamicCharacter, _args = {}):
	if(_args.has(NpcGen.Name)):
		character.npcName = _args[NpcGen.Name]
	else:
		if(character.getGender() == Gender.Male):
			character.npcName = RNG.randomMaleName()
		else:
			character.npcName = RNG.randomFemaleName()

static func pickEquipment(character:DynamicCharacter, _args = {}):
	if(_args.has("editor_noequip") && _args["editor_noequip"]):
		character.npcDefaultEquipment = []
	else:
		character.npcDefaultEquipment = ["CasualClothes", "LaceBra", "LacePanties"]

static func pickNonStaticEquipment(_character:DynamicCharacter, _args = {}):
	pass

static func pickedSpeciesType(_args = {}):
	return "guard"

static func pickSpecies(character:DynamicCharacter, _args = {}):
	if(_args.has(NpcGen.Species)):
		character.npcSpecies = [_args[NpcGen.Species]]
		return
	
	var speciesType = pickedSpeciesType(_args)
	var allSpecies = GlobalRegistry.getAllSpecies()
	var possible = []
	for speciesID in allSpecies:
		var specie = allSpecies[speciesID]
		if(!specie.canBeUsedForNPCType(speciesType)):
			continue
		
		var weight = GM.main.getEncounterSettings().getSpeciesWeight(speciesID)
		if(weight != null && weight > 0.0):
			possible.append([speciesID, weight])
	
	var randomSpecies = RNG.pickWeightedPairs(possible)
	if(randomSpecies == null):
		randomSpecies = Species.Canine
	
	character.npcSpecies = [randomSpecies]

static func pickSkinAndColors(character:DynamicCharacter, _args = {}):
	character.applyRandomSkinAndColors()

static func createBodyparts(character:DynamicCharacter, _args = {}):
	var theSpecies:Array = character.npcSpecies
	for bodypartSlot in BodypartSlot.getAll():
		var possible := Bodypart.findPossibleBodypartIDs(bodypartSlot, character, theSpecies, character.npcGeneratedGender)
		var fullWeight:float = 0.0
		for pairs in possible:
			fullWeight += max(0.0, pairs[1])
		
		#print(bodypartSlot, " ", possible) # Uncomment for debug
		if(possible.size() > 0):
			if(!RNG.chance(fullWeight * 100.0)):
				continue
			
			var bodypartID = RNG.pickWeightedPairs(possible)
			if(bodypartID != null && bodypartID != ""):
				var bodypart = GlobalRegistry.createBodypart(bodypartID)
				if(!bodypart):
					continue
				character.giveBodypartUnlessSame(bodypart)
				bodypart.generateDataFor(character)

static func pickBodyAttributes(character:DynamicCharacter, _args = {}):
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.BodyAttributesEnable:
			settingCheck = true
	
	if settingCheck:
		if(character.getGender() == Gender.Male):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.MaleThicknessMin, 
				npcGenSettingsModule.MaleThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.MaleFeminityMin, 
				npcGenSettingsModule.MaleFeminityMax)
		if(character.getGender() == Gender.Female):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.FemaleThicknessMin, 
				npcGenSettingsModule.FemaleThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.FemaleFeminityMin, 
				npcGenSettingsModule.FemaleFeminityMax)
		if(character.getGender() == Gender.Androgynous):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.AndrogynousThicknessMin, 
				npcGenSettingsModule.AndrogynousThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.AndrogynousFeminityMin, 
				npcGenSettingsModule.AndrogynousFeminityMax)
		if(character.getGender() == Gender.Other):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.OtherThicknessMin, 
				npcGenSettingsModule.OtherThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.OtherFeminityMin, 
				npcGenSettingsModule.OtherFeminityMax)
	else:
		if(character.getGender() == Gender.Male):
			character.npcThickness = RNG.randi_range(0, 60)
			character.npcFeminity = RNG.randi_range(0, 50)
		if(character.getGender() == Gender.Female):
			character.npcThickness = RNG.randi_range(0, 110)
			character.npcFeminity = RNG.randi_range(50, 100)
		if(character.getGender() == Gender.Androgynous):
			character.npcThickness = RNG.randi_range(0, 100)
			character.npcFeminity = RNG.randi_range(25, 75)
		if(character.getGender() == Gender.Other):
			character.npcThickness = RNG.randi_range(0, 100)
			character.npcFeminity = RNG.randi_range(0, 100)

static func pickArchetypes(character:DynamicCharacter, _args = {}):
	var possible = CharacterArchetype.getAll()
	
	var picked = []
	
	var amount = RNG.randi_range(2, 4)
	for _i in range(amount):
		picked.append(RNG.pick(possible))
	character.npcArchetypes = picked
	print(picked)

static func pickFetishes(character:DynamicCharacter, _args = {}):
	var fetishHolder = character.getFetishHolder()
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	
	fetishHolder.clear()
	
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.FetishesEnable:
			settingCheck = true
	
	if settingCheck:
		var values = npcGenSettingsModule.FetishValues()
		for fetishID in values:
			print(fetishID + " : " + fetishID[0] + " , " + fetishID[1])
			fetishHolder.setFetish(fetishID, RNG.randf_range(fetishID[0], fetishID[1]))
	else:
		for fetishID in GlobalRegistry.getFetishes():
			if(RNG.chance(50)):
				fetishHolder.setFetish(fetishID, RNG.pick([FetishInterest.Dislikes, FetishInterest.SlightlyDislikes, FetishInterest.SlightlyLikes]))
			elif(RNG.chance(5)):
				fetishHolder.setFetish(fetishID, RNG.pick([FetishInterest.Hates, FetishInterest.Loves]))
			else:
				fetishHolder.setFetish(fetishID, FetishInterest.Neutral)
	
	settingCheck = true
	if (npcGenSettingsModule != null):
		if !npcGenSettingsModule.ArchetypesEnable:
			settingCheck = false
	
	if settingCheck:
		for archetype in character.npcArchetypes:
			var fetishes = CharacterArchetype.getFetishes(archetype)
			for fetishID in fetishes:
				var addValue:float = fetishes[fetishID]
				if(addValue > 0.0):
					fetishHolder.addFetish(fetishID, RNG.randf_range(0.0, addValue))
				elif(addValue < 0.0):
					fetishHolder.addFetish(fetishID, -RNG.randf_range(0.0, -addValue))

	fetishHolder.removeImpossibleFetishes()

static func pickLustInterests(character:DynamicCharacter, _args = {}):
	var interestWeights = [
		[Interest.Hates, 0.5],
		[Interest.ReallyDislikes, 0.6],
		[Interest.Dislikes, 0.7],
		[Interest.SlightlyDislikes, 0.6],
		[Interest.KindaLikes, 1.0],
		[Interest.Likes, 1.0],
		[Interest.ReallyLikes, 1.0],
		[Interest.Loves, 1.0],
	]
	
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.LustTopicsEnable:
			settingCheck = true
	
	if settingCheck:
		var weights = npcGenSettingsModule.LustTopicsWeightedPairs()
		for topic in weights:
			var pickedInterest = RNG.pickWeightedPairs(weights[topic])
			if(pickedInterest != Interest.Neutral):
				character.getLustInterests().addInterest(topic, pickedInterest)
	else:
		for topicA in GlobalRegistry.getLustTopicObjects():
			var topic: TopicBase = topicA
			var handlesIDs = topic.handles_ids
			for id in handlesIDs:
				var pickedInterest = RNG.pickWeightedPairs(interestWeights)
				
				if(pickedInterest != Interest.Neutral):
					character.getLustInterests().addInterest(id, pickedInterest)

static func getAttacks():
	return ["stunbatonAttack", "trygetupattack"]

static func getPossibleAttacks():
	return ["HeatGrenade", "DoubleCuffPC", "CuffPCHands", "ForceGagPC", "ForceMuzzlePC", "stunbatonOverchargeAttack", "simplekickattack", "biteattack", "shoveattack"]
	
static func pickAttacks(character:DynamicCharacter, _args = {}):
	var baseAttacks = getAttacks()
	for possibleAttack in getPossibleAttacks():
		if(RNG.chance(50)):
			baseAttacks.append(possibleAttack)
	character.npcAttacks = baseAttacks

static func pickPersonality(character:DynamicCharacter, _args = {}):
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	var personality = character.getPersonality()
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.PersonalitiesEnable:
			settingCheck = true
	
	personality.clear()
	if settingCheck:
		var values = npcGenSettingsModule.PersonalityLevels()
		for statID in values:
			personality.setStat(statID, RNG.randf_range(values[statID][0], values[statID][1]))
			if(RNG.chance(npcGenSettingsModule.PersonalityStrongChance)):
				personality.setStat(statID, RNG.randf_range(values[statID][0], values[statID][1])*npcGenSettingsModule.PersonalityStrongMult)
	else:
		for statID in PersonalityStat.getAll():
			personality.setStat(statID, RNG.randf_range(-0.3, 0.3))
			if(RNG.chance(5)):
				personality.setStat(statID, RNG.randf_range(-0.3, 0.3)*5.0)
	
	settingCheck = true
	if (npcGenSettingsModule != null):
		if !npcGenSettingsModule.ArchetypesEnable:
			settingCheck = false
	
	if settingCheck:
		for archetype in character.npcArchetypes:
			var personalityChanges = CharacterArchetype.getPersonalityChanges(archetype)
			for personalityStat in personalityChanges:
				var howMuchMax = personalityChanges[personalityStat]
				
				if(howMuchMax > 0.0):
					personality.addStat(personalityStat, RNG.randf_range(0.0, howMuchMax))
				elif(howMuchMax < 0.0):
					personality.addStat(personalityStat, -RNG.randf_range(0.0, -howMuchMax))

static func pickSmallDescription(character:DynamicCharacter, _args = {}):
	var thedesc = ""
	thedesc += Util.getSpeciesName(character.npcSpecies)
	thedesc += ". "
	thedesc += NpcGender.getVisibleName(character.npcGeneratedGender)+"."
	
	return thedesc

static func pickLevel(character:DynamicCharacter, _args = {}):
	if(_args.has(NpcGen.Level)):
		character.npcLevel = _args[NpcGen.Level]
	else:
		if(GM.pc == null || !is_instance_valid(GM.pc)):
			character.npcLevel = 1
		else:
			character.npcLevel = Util.maxi(GM.pc.getLevel() + RNG.randi_range(-3,3), 0)# Just some random lvl
	character.getSkillsHolder().setLevel(character.npcLevel)

static func pickStats(character:DynamicCharacter, _args = {}):
	var statDistributionTypes = [
		["tank", 10.0],
		["luster", 10.0],
		["balanced", 5.0],
		["weak", 5.0],
	]
	
	var pickedType = RNG.pickWeightedPairs(statDistributionTypes)
	var level = Util.maxi(0, character.npcLevel)
	
	character.npcBaseLust = 100
	character.npcBasePain = 100
	character.npcBaseStamina = 100
	
	if(pickedType == "tank"):
		character.npcBasePain = 70 + pow(level, 0.6) * 10 + RNG.randi_range(0, level*2)
		character.npcBaseLust = 50 + pow(level, 0.5) * 3
		character.npcBaseStamina = RNG.randi_range(7, 12)*10 + pow(level, 0.3) * 3
	if(pickedType == "luster"):
		character.npcBaseLust = 70 + pow(level, 0.6) * 10 + RNG.randi_range(0, level*2)
		character.npcBasePain = 50 + pow(level, 0.5) * 3 + RNG.randi_range(0, level)
		character.npcBaseStamina = RNG.randi_range(7, 12)*10 + pow(level, 0.25) * 5
	if(pickedType == "balanced"):
		character.npcBaseLust = 60 + pow(level, 0.5) * 10 + RNG.randi_range(0, level*2)
		character.npcBasePain = 60 + pow(level, 0.5) * 10 + RNG.randi_range(0, level*2)
		character.npcBaseStamina = RNG.randi_range(5, 12)*10 + pow(level, 0.5) * 10
	if(pickedType == "weak"):
		character.npcBaseLust = 50 + pow(level, 0.3) * 10 + RNG.randi_range(0, level*2)
		character.npcBasePain = 50 + pow(level, 0.3) * 10 + RNG.randi_range(0, level*2)
		character.npcBaseStamina = RNG.randi_range(5, 7)*10 + pow(level, 0.5) * 10

	character.npcBasePain = int(round(character.npcBasePain/5)*5)
	character.npcBaseLust = int(round(character.npcBaseLust/5)*5)
	character.npcBaseStamina = int(round(character.npcBaseStamina/5)*5)

static func resetStats(character:DynamicCharacter, _args = {}):
	character.addStamina( character.getMaxStamina() )

static func applyArgs(_character:DynamicCharacter, _args = {}):
	if(_args.has(NpcGen.PersonalityStat)):
		var stats = _args[NpcGen.PersonalityStat]
		# Possible: { NpcGen.PersonalityStat: [PersonalityStat.Mean, 1.0] }
		# Or: { NpcGen.PersonalityStat: [[PersonalityStat.Mean, 1.0], [PersonalityStat.Subby, 1.0]] }
		var personality = _character.getPersonality()
		
		if(!Util.isArrayOfArrays(stats)):
			stats = [stats]
		for statToChange in stats:
			personality.setStat(statToChange[0], statToChange[1])
			
	if(_args.has(NpcGen.Fetish)):
		var fetishes = _args[NpcGen.Fetish]
		var fetishHolder = _character.getFetishHolder()
		
		if(!Util.isArrayOfArrays(fetishes)):
			fetishes = [fetishes]
		for fetishToChange in fetishes:
			fetishHolder.setFetish(fetishToChange[0], fetishToChange[1])
		
	if(_args.has(NpcGen.Flag)):
		var flagsToAdd = _args[NpcGen.Flag]
		
		if(!Util.isArrayOfArrays(flagsToAdd)):
			flagsToAdd = [flagsToAdd]
		for flagToChange in flagsToAdd:
			_character.setFlag(flagToChange[0], flagToChange[1])
		
static func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = CharacterType.Generic
		
static func getRandomItemIDByTag(itemTag):
	var itemIDs = GlobalRegistry.getItemIDsByTag(itemTag)
	if(itemIDs == null || itemIDs.size() == 0):
		return null
	
	var weights = []
	for itemID in itemIDs:
		var itemRef:ItemBase = GlobalRegistry.getItemRef(itemID)
		
		weights.append(itemRef.getItemWeightForNpcGeneration())
	
	return RNG.pickWeighted(itemIDs, weights)
		
static func generate(caller_ref:Reference, _args = {}):
	var character = caller_ref.makeBase("dynamicnpc", _args)
	# If the function relies on something, it must be below the function that generates that something!
	caller_ref.pickCharacterType(character, _args)
	caller_ref.pickGender(character, _args)
	pickBodyAttributes(character, _args) # Relies on gender
	caller_ref.pickName(character, _args) # Relies on gender
	caller_ref.pickSpecies(character, _args) # Relies on character type
	caller_ref.pickSkinAndColors(character, _args) # Relies on species
	caller_ref.pickLevel(character, _args)
	caller_ref.pickStats(character, _args) # Relies on level
	caller_ref.pickArchetypes(character, _args)
	caller_ref.createBodyparts(character, _args) # Relies on gender and species
	caller_ref.pickAttacks(character, _args)
	pickFetishes(character, _args) # Relies on bodyparts
	pickLustInterests(character, _args)
	pickPersonality(character, _args)
	caller_ref.applyArgs(character, _args) # Relies on fetishes and personality
	caller_ref.pickEquipment(character, _args) # Relies on character type
	character.npcSmallDescription = caller_ref.pickSmallDescription(character, _args)
	
	character.resetEquipment()
	caller_ref.resetStats(character, _args)
	caller_ref.pickNonStaticEquipment(character, _args)
	
	# Letting the species object tweak the character
	for species in character.getSpecies():
		var speciesObject = GlobalRegistry.getSpecies(species)
		if(speciesObject != null):
			speciesObject.onDynamicNpcCreation(character, _args)
	
	character.updateNonBattleEffects()
	return character
