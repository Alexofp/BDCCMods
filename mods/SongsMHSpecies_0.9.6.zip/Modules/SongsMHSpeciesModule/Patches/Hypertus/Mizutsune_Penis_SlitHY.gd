extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Mizutsune penis Slit Hyper"
	id = "sMizutsunePSHY"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["wyvern", "tapered", "slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Penis_Slit/Mizutsune_Penis_slit.tscn"

func getTraits():
	return {
		"Hyperable": true,
	}

func getVulgarName() -> String:
	return "tapered wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func getCharacterCreatorDesc():
	return "From MH Species"
