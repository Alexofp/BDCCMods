extends BodypartTail

func _init():
	visibleName = "Mizutsune tail"
	id = "sMizutsuneTail"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon", "fluffy"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Tail/Mizutsune_Tail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
