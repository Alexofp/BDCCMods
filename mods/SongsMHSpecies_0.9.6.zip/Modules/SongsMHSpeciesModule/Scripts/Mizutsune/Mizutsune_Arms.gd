extends BodypartArms

func _init():
	visibleName = "Mizutsune arms"
	id = "sMizutsuneArms"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Arms/Mizutsune_Arms.tscn"
