extends BodypartArms

func _init():
	visibleName = "Mizutsune buff arms"
	id = "sMizutsuneArmsBuff"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Arms/Mizutsune_BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
