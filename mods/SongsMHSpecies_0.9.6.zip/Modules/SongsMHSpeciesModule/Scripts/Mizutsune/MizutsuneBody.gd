extends BodypartBody

func _init():
	visibleName = "Mizutsune body"
	id = "sMizutsunebody"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Body/Mizutsune_body.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
