extends BodypartLeg

func _init():
	visibleName = "Mizutsune legs"
	id = "sMizutsuneLegs"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Legs/Mizutsune_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
