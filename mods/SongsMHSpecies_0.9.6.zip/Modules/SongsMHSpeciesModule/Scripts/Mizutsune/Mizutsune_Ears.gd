extends BodypartEars

func _init():
	visibleName = "Mizutsune ears"
	id = "sMizutsuneEars"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Ears/Mizutsune_Ears.tscn"
