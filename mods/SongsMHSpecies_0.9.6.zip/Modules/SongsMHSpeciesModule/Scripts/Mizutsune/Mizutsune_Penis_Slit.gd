extends BodypartPenis

func _init():
	visibleName = "Mizutsune penis Slit"
	id = "sMizutsunePS"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["wyvern", "tapered", "slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Penis_Slit/Mizutsune_Penis_slit.tscn"

func getVulgarName() -> String:
	return "tapered wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func getCharacterCreatorDesc():
	return "From MH Species"
