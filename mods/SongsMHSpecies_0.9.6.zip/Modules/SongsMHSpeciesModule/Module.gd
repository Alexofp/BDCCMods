extends Module

func _init():
	id = "SMHspeciesmod"
	author = "Songjo"
	
	bodyparts = [
		#Odogaron
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/OdogaronBody.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Ears.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Tail.gd",
		#Tobi-Kadachi
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Body.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Tail.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Ears.gd",
		#Rathalos
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Body.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Tail.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Ears.gd",
		#Mizutsune
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Ears.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/MizutsuneBody.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Tail.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Penis_Slit.gd",
		]
	
	species = [
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune.gd",
	]
