Pack downloaded from Freesound
----------------------------------------

"Clothes &amp; Fabrics Pack #1"

This Pack of sounds contains sounds by the following user:
 - Joao_Janz ( https://freesound.org/people/Joao_Janz/ )

You can find this pack online at: https://freesound.org/people/Joao_Janz/packs/27772/


Pack description
----------------

Enjoy!


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 493505__joao-janz__clothes-rustling-movement-13-22.wav
    * url: https://freesound.org/s/493505/
    * license: Creative Commons 0
  * 493504__joao-janz__clothes-rustling-movement-13-23.wav
    * url: https://freesound.org/s/493504/
    * license: Creative Commons 0
  * 493503__joao-janz__clothes-rustling-movement-13-24.wav
    * url: https://freesound.org/s/493503/
    * license: Creative Commons 0
  * 493502__joao-janz__clothes-rustling-movement-13-25.wav
    * url: https://freesound.org/s/493502/
    * license: Creative Commons 0
  * 493501__joao-janz__clothes-rustling-movement-13-26.wav
    * url: https://freesound.org/s/493501/
    * license: Creative Commons 0
  * 493500__joao-janz__clothes-rustling-movement-13-3.wav
    * url: https://freesound.org/s/493500/
    * license: Creative Commons 0
  * 493499__joao-janz__clothes-rustling-movement-13-4.wav
    * url: https://freesound.org/s/493499/
    * license: Creative Commons 0
  * 493498__joao-janz__clothes-rustling-movement-13-5.wav
    * url: https://freesound.org/s/493498/
    * license: Creative Commons 0
  * 493497__joao-janz__clothes-rustling-movement-13-6.wav
    * url: https://freesound.org/s/493497/
    * license: Creative Commons 0
  * 493496__joao-janz__clothes-rustling-movement-13-7.wav
    * url: https://freesound.org/s/493496/
    * license: Creative Commons 0
  * 493495__joao-janz__clothes-shaking-movement-6-19.wav
    * url: https://freesound.org/s/493495/
    * license: Creative Commons 0
  * 493494__joao-janz__clothes-shaking-movement-6-2.wav
    * url: https://freesound.org/s/493494/
    * license: Creative Commons 0
  * 493493__joao-janz__clothes-shaking-movement-6-13.wav
    * url: https://freesound.org/s/493493/
    * license: Creative Commons 0
  * 493492__joao-janz__clothes-shaking-movement-6-14.wav
    * url: https://freesound.org/s/493492/
    * license: Creative Commons 0
  * 493491__joao-janz__clothes-shaking-movement-6-15.wav
    * url: https://freesound.org/s/493491/
    * license: Creative Commons 0
  * 493490__joao-janz__clothes-shaking-movement-6-16.wav
    * url: https://freesound.org/s/493490/
    * license: Creative Commons 0
  * 493489__joao-janz__clothes-shaking-movement-6-20.wav
    * url: https://freesound.org/s/493489/
    * license: Creative Commons 0
  * 493488__joao-janz__clothes-rustling-movement-7-12.wav
    * url: https://freesound.org/s/493488/
    * license: Creative Commons 0
  * 493487__joao-janz__clothes-rustling-movement-7-11.wav
    * url: https://freesound.org/s/493487/
    * license: Creative Commons 0
  * 493486__joao-janz__clothes-rustling-movement-6-9.wav
    * url: https://freesound.org/s/493486/
    * license: Creative Commons 0
  * 493485__joao-janz__clothes-rustling-movement-6-8.wav
    * url: https://freesound.org/s/493485/
    * license: Creative Commons 0
  * 493484__joao-janz__clothes-rustling-movement-6-7.wav
    * url: https://freesound.org/s/493484/
    * license: Creative Commons 0
  * 493483__joao-janz__clothes-rustling-movement-6-6.wav
    * url: https://freesound.org/s/493483/
    * license: Creative Commons 0
  * 493482__joao-janz__clothes-rustling-movement-6-5.wav
    * url: https://freesound.org/s/493482/
    * license: Creative Commons 0
  * 493481__joao-janz__clothes-rustling-movement-6-4.wav
    * url: https://freesound.org/s/493481/
    * license: Creative Commons 0
  * 493480__joao-janz__clothes-rustling-movement-8-1.wav
    * url: https://freesound.org/s/493480/
    * license: Creative Commons 0
  * 493479__joao-janz__clothes-rustling-movement-7-13.wav
    * url: https://freesound.org/s/493479/
    * license: Creative Commons 0
  * 493478__joao-janz__clothes-shaking-movement-6-17.wav
    * url: https://freesound.org/s/493478/
    * license: Creative Commons 0
  * 493477__joao-janz__clothes-shaking-movement-6-18.wav
    * url: https://freesound.org/s/493477/
    * license: Creative Commons 0
  * 493476__joao-janz__clothes-shaking-movement-7-3.wav
    * url: https://freesound.org/s/493476/
    * license: Creative Commons 0
  * 493475__joao-janz__clothes-shaking-movement-7-2.wav
    * url: https://freesound.org/s/493475/
    * license: Creative Commons 0
  * 493474__joao-janz__clothes-shaking-movement-3-5.wav
    * url: https://freesound.org/s/493474/
    * license: Creative Commons 0
  * 493473__joao-janz__clothes-rustling-movement-13-21.wav
    * url: https://freesound.org/s/493473/
    * license: Creative Commons 0
  * 493472__joao-janz__clothes-rustling-movement-13-20.wav
    * url: https://freesound.org/s/493472/
    * license: Creative Commons 0
  * 493471__joao-janz__clothes-rustling-movement-13-2.wav
    * url: https://freesound.org/s/493471/
    * license: Creative Commons 0
  * 493470__joao-janz__clothes-rustling-movement-13-19.wav
    * url: https://freesound.org/s/493470/
    * license: Creative Commons 0
  * 493469__joao-janz__clothes-rustling-movement-13-18.wav
    * url: https://freesound.org/s/493469/
    * license: Creative Commons 0
  * 493468__joao-janz__clothes-rustling-movement-13-17.wav
    * url: https://freesound.org/s/493468/
    * license: Creative Commons 0
  * 493467__joao-janz__clothes-rustling-movement-13-16.wav
    * url: https://freesound.org/s/493467/
    * license: Creative Commons 0
  * 493466__joao-janz__clothes-rustling-movement-13-15.wav
    * url: https://freesound.org/s/493466/
    * license: Creative Commons 0
  * 493465__joao-janz__clothes-rustling-movement-13-14.wav
    * url: https://freesound.org/s/493465/
    * license: Creative Commons 0
  * 493464__joao-janz__clothes-rustling-movement-13-13.wav
    * url: https://freesound.org/s/493464/
    * license: Creative Commons 0
  * 493463__joao-janz__clothes-shaking-movement-5-6.wav
    * url: https://freesound.org/s/493463/
    * license: Creative Commons 0
  * 493462__joao-janz__clothes-rustling-movement-8-5.wav
    * url: https://freesound.org/s/493462/
    * license: Creative Commons 0
  * 493461__joao-janz__clothes-rustling-movement-8-6.wav
    * url: https://freesound.org/s/493461/
    * license: Creative Commons 0
  * 493460__joao-janz__clothes-rustling-movement-8-7.wav
    * url: https://freesound.org/s/493460/
    * license: Creative Commons 0
  * 493459__joao-janz__clothes-rustling-movement-8-8.wav
    * url: https://freesound.org/s/493459/
    * license: Creative Commons 0
  * 493458__joao-janz__clothes-rustling-movement-8-10.wav
    * url: https://freesound.org/s/493458/
    * license: Creative Commons 0
  * 493457__joao-janz__clothes-rustling-movement-8-2.wav
    * url: https://freesound.org/s/493457/
    * license: Creative Commons 0
  * 493456__joao-janz__clothes-rustling-movement-8-3.wav
    * url: https://freesound.org/s/493456/
    * license: Creative Commons 0
  * 493455__joao-janz__clothes-rustling-movement-8-4.wav
    * url: https://freesound.org/s/493455/
    * license: Creative Commons 0
  * 493454__joao-janz__clothes-rustling-movement-8-9.wav
    * url: https://freesound.org/s/493454/
    * license: Creative Commons 0
  * 493453__joao-janz__clothes-rustling-movement-9-1.wav
    * url: https://freesound.org/s/493453/
    * license: Creative Commons 0
  * 493452__joao-janz__clothes-shaking-movement-6-9.wav
    * url: https://freesound.org/s/493452/
    * license: Creative Commons 0
  * 493451__joao-janz__clothes-shaking-movement-7-1.wav
    * url: https://freesound.org/s/493451/
    * license: Creative Commons 0
  * 493450__joao-janz__clothes-shaking-movement-6-5.wav
    * url: https://freesound.org/s/493450/
    * license: Creative Commons 0
  * 493449__joao-janz__clothes-shaking-movement-6-6.wav
    * url: https://freesound.org/s/493449/
    * license: Creative Commons 0
  * 493448__joao-janz__clothes-shaking-movement-6-7.wav
    * url: https://freesound.org/s/493448/
    * license: Creative Commons 0
  * 493447__joao-janz__clothes-shaking-movement-6-8.wav
    * url: https://freesound.org/s/493447/
    * license: Creative Commons 0
  * 493446__joao-janz__clothes-shaking-movement-6-22.wav
    * url: https://freesound.org/s/493446/
    * license: Creative Commons 0
  * 493445__joao-janz__clothes-shaking-movement-6-23.wav
    * url: https://freesound.org/s/493445/
    * license: Creative Commons 0
  * 493444__joao-janz__clothes-shaking-movement-6-3.wav
    * url: https://freesound.org/s/493444/
    * license: Creative Commons 0
  * 493443__joao-janz__clothes-shaking-movement-6-4.wav
    * url: https://freesound.org/s/493443/
    * license: Creative Commons 0
  * 493442__joao-janz__clothes-shaking-movement-3-14.wav
    * url: https://freesound.org/s/493442/
    * license: Creative Commons 0
  * 493441__joao-janz__clothes-rustling-movement-3-3.wav
    * url: https://freesound.org/s/493441/
    * license: Creative Commons 0
  * 493440__joao-janz__clothes-rustling-movement-3-4.wav
    * url: https://freesound.org/s/493440/
    * license: Creative Commons 0
  * 493439__joao-janz__clothes-shaking-movement-3-15.wav
    * url: https://freesound.org/s/493439/
    * license: Creative Commons 0
  * 493438__joao-janz__clothes-rustling-movement-2-1.wav
    * url: https://freesound.org/s/493438/
    * license: Creative Commons 0
  * 493437__joao-janz__clothes-rustling-movement-2-2.wav
    * url: https://freesound.org/s/493437/
    * license: Creative Commons 0
  * 493436__joao-janz__clothes-rustling-movement-1-3.wav
    * url: https://freesound.org/s/493436/
    * license: Creative Commons 0
  * 493435__joao-janz__clothes-rustling-movement-1-4.wav
    * url: https://freesound.org/s/493435/
    * license: Creative Commons 0
  * 493434__joao-janz__clothes-rustling-movement-3-1.wav
    * url: https://freesound.org/s/493434/
    * license: Creative Commons 0
  * 493433__joao-janz__clothes-rustling-movement-3-2.wav
    * url: https://freesound.org/s/493433/
    * license: Creative Commons 0
  * 493432__joao-janz__clothes-rustling-movement-2-3.wav
    * url: https://freesound.org/s/493432/
    * license: Creative Commons 0
  * 493431__joao-janz__clothes-rustling-movement-2-4.wav
    * url: https://freesound.org/s/493431/
    * license: Creative Commons 0
  * 493430__joao-janz__clothes-shaking-movement-3-8.wav
    * url: https://freesound.org/s/493430/
    * license: Creative Commons 0
  * 493429__joao-janz__clothes-shaking-movement-3-7.wav
    * url: https://freesound.org/s/493429/
    * license: Creative Commons 0
  * 493428__joao-janz__clothes-shaking-movement-4-1.wav
    * url: https://freesound.org/s/493428/
    * license: Creative Commons 0
  * 493427__joao-janz__clothes-shaking-movement-3-9.wav
    * url: https://freesound.org/s/493427/
    * license: Creative Commons 0
  * 493426__joao-janz__clothes-shaking-movement-4-11.wav
    * url: https://freesound.org/s/493426/
    * license: Creative Commons 0
  * 493425__joao-janz__clothes-shaking-movement-4-10.wav
    * url: https://freesound.org/s/493425/
    * license: Creative Commons 0
  * 493424__joao-janz__clothes-shaking-movement-4-13.wav
    * url: https://freesound.org/s/493424/
    * license: Creative Commons 0
  * 493423__joao-janz__clothes-shaking-movement-4-12.wav
    * url: https://freesound.org/s/493423/
    * license: Creative Commons 0
  * 493422__joao-janz__clothes-shaking-movement-4-15.wav
    * url: https://freesound.org/s/493422/
    * license: Creative Commons 0
  * 493421__joao-janz__clothes-shaking-movement-4-14.wav
    * url: https://freesound.org/s/493421/
    * license: Creative Commons 0
  * 493420__joao-janz__clothes-shaking-movement-6-11.wav
    * url: https://freesound.org/s/493420/
    * license: Creative Commons 0
  * 493419__joao-janz__clothes-rustling-movement-1-2.wav
    * url: https://freesound.org/s/493419/
    * license: Creative Commons 0
  * 493418__joao-janz__clothes-rustling-movement-1-1.wav
    * url: https://freesound.org/s/493418/
    * license: Creative Commons 0
  * 493417__joao-janz__clothes-rustling-movement-13-9.wav
    * url: https://freesound.org/s/493417/
    * license: Creative Commons 0
  * 493416__joao-janz__clothes-rustling-movement-13-8.wav
    * url: https://freesound.org/s/493416/
    * license: Creative Commons 0
  * 493415__joao-janz__clothes-rustling-movement-14-2.wav
    * url: https://freesound.org/s/493415/
    * license: Creative Commons 0
  * 493414__joao-janz__clothes-rustling-movement-14-1.wav
    * url: https://freesound.org/s/493414/
    * license: Creative Commons 0
  * 493413__joao-janz__clothes-rustling-movement-14-4.wav
    * url: https://freesound.org/s/493413/
    * license: Creative Commons 0
  * 493412__joao-janz__clothes-rustling-movement-14-3.wav
    * url: https://freesound.org/s/493412/
    * license: Creative Commons 0
  * 493411__joao-janz__clothes-rustling-movement-14-6.wav
    * url: https://freesound.org/s/493411/
    * license: Creative Commons 0
  * 493410__joao-janz__clothes-rustling-movement-14-5.wav
    * url: https://freesound.org/s/493410/
    * license: Creative Commons 0
  * 493409__joao-janz__clothes-shaking-movement-3-11.wav
    * url: https://freesound.org/s/493409/
    * license: Creative Commons 0
  * 493408__joao-janz__clothes-shaking-movement-5-5.wav
    * url: https://freesound.org/s/493408/
    * license: Creative Commons 0
  * 493407__joao-janz__clothes-shaking-movement-3-10.wav
    * url: https://freesound.org/s/493407/
    * license: Creative Commons 0
  * 493406__joao-janz__clothes-shaking-movement-5-1.wav
    * url: https://freesound.org/s/493406/
    * license: Creative Commons 0
  * 493405__joao-janz__clothes-shaking-movement-5-2.wav
    * url: https://freesound.org/s/493405/
    * license: Creative Commons 0
  * 493404__joao-janz__clothes-shaking-movement-4-8.wav
    * url: https://freesound.org/s/493404/
    * license: Creative Commons 0
  * 493403__joao-janz__clothes-shaking-movement-4-9.wav
    * url: https://freesound.org/s/493403/
    * license: Creative Commons 0
  * 493402__joao-janz__clothes-shaking-movement-4-6.wav
    * url: https://freesound.org/s/493402/
    * license: Creative Commons 0
  * 493401__joao-janz__clothes-shaking-movement-4-7.wav
    * url: https://freesound.org/s/493401/
    * license: Creative Commons 0
  * 493400__joao-janz__clothes-shaking-movement-4-4.wav
    * url: https://freesound.org/s/493400/
    * license: Creative Commons 0
  * 493399__joao-janz__clothes-shaking-movement-4-5.wav
    * url: https://freesound.org/s/493399/
    * license: Creative Commons 0
  * 493398__joao-janz__clothes-shaking-movement-4-2.wav
    * url: https://freesound.org/s/493398/
    * license: Creative Commons 0
  * 493397__joao-janz__clothes-shaking-movement-4-3.wav
    * url: https://freesound.org/s/493397/
    * license: Creative Commons 0
  * 493396__joao-janz__clothes-rustling-movement-10-8.wav
    * url: https://freesound.org/s/493396/
    * license: Creative Commons 0
  * 493395__joao-janz__clothes-rustling-movement-10-9.wav
    * url: https://freesound.org/s/493395/
    * license: Creative Commons 0
  * 493394__joao-janz__clothes-rustling-movement-10-4.wav
    * url: https://freesound.org/s/493394/
    * license: Creative Commons 0
  * 493393__joao-janz__clothes-rustling-movement-10-5.wav
    * url: https://freesound.org/s/493393/
    * license: Creative Commons 0
  * 493392__joao-janz__clothes-rustling-movement-10-6.wav
    * url: https://freesound.org/s/493392/
    * license: Creative Commons 0
  * 493391__joao-janz__clothes-rustling-movement-10-7.wav
    * url: https://freesound.org/s/493391/
    * license: Creative Commons 0
  * 493390__joao-janz__clothes-rustling-movement-10-1.wav
    * url: https://freesound.org/s/493390/
    * license: Creative Commons 0
  * 493389__joao-janz__clothes-rustling-movement-10-10.wav
    * url: https://freesound.org/s/493389/
    * license: Creative Commons 0
  * 493388__joao-janz__clothes-rustling-movement-10-2.wav
    * url: https://freesound.org/s/493388/
    * license: Creative Commons 0
  * 493387__joao-janz__clothes-rustling-movement-10-3.wav
    * url: https://freesound.org/s/493387/
    * license: Creative Commons 0
  * 493386__joao-janz__clothes-shaking-movement-3-1.wav
    * url: https://freesound.org/s/493386/
    * license: Creative Commons 0
  * 493385__joao-janz__clothes-shaking-movement-2-9.wav
    * url: https://freesound.org/s/493385/
    * license: Creative Commons 0
  * 493384__joao-janz__clothes-rustling-movement-11-17.wav
    * url: https://freesound.org/s/493384/
    * license: Creative Commons 0
  * 493383__joao-janz__clothes-rustling-movement-11-18.wav
    * url: https://freesound.org/s/493383/
    * license: Creative Commons 0
  * 493382__joao-janz__clothes-rustling-movement-11-13.wav
    * url: https://freesound.org/s/493382/
    * license: Creative Commons 0
  * 493381__joao-janz__clothes-rustling-movement-11-14.wav
    * url: https://freesound.org/s/493381/
    * license: Creative Commons 0
  * 493380__joao-janz__clothes-rustling-movement-11-15.wav
    * url: https://freesound.org/s/493380/
    * license: Creative Commons 0
  * 493379__joao-janz__clothes-rustling-movement-11-16.wav
    * url: https://freesound.org/s/493379/
    * license: Creative Commons 0
  * 493378__joao-janz__clothes-rustling-movement-11-1.wav
    * url: https://freesound.org/s/493378/
    * license: Creative Commons 0
  * 493377__joao-janz__clothes-rustling-movement-11-10.wav
    * url: https://freesound.org/s/493377/
    * license: Creative Commons 0
  * 493376__joao-janz__clothes-rustling-movement-11-11.wav
    * url: https://freesound.org/s/493376/
    * license: Creative Commons 0
  * 493375__joao-janz__clothes-rustling-movement-11-12.wav
    * url: https://freesound.org/s/493375/
    * license: Creative Commons 0
  * 493374__joao-janz__clothes-rustling-movement-5-6.wav
    * url: https://freesound.org/s/493374/
    * license: Creative Commons 0
  * 493373__joao-janz__clothes-rustling-movement-5-7.wav
    * url: https://freesound.org/s/493373/
    * license: Creative Commons 0
  * 493372__joao-janz__clothes-rustling-movement-6-1.wav
    * url: https://freesound.org/s/493372/
    * license: Creative Commons 0
  * 493371__joao-janz__clothes-rustling-movement-6-10.wav
    * url: https://freesound.org/s/493371/
    * license: Creative Commons 0
  * 493370__joao-janz__clothes-rustling-movement-5-2.wav
    * url: https://freesound.org/s/493370/
    * license: Creative Commons 0
  * 493369__joao-janz__clothes-rustling-movement-5-3.wav
    * url: https://freesound.org/s/493369/
    * license: Creative Commons 0
  * 493368__joao-janz__clothes-rustling-movement-5-4.wav
    * url: https://freesound.org/s/493368/
    * license: Creative Commons 0
  * 493367__joao-janz__clothes-rustling-movement-5-5.wav
    * url: https://freesound.org/s/493367/
    * license: Creative Commons 0
  * 493366__joao-janz__clothes-shaking-movement-2-6.wav
    * url: https://freesound.org/s/493366/
    * license: Creative Commons 0
  * 493365__joao-janz__clothes-shaking-movement-2-5.wav
    * url: https://freesound.org/s/493365/
    * license: Creative Commons 0
  * 493364__joao-janz__clothes-shaking-movement-2-4.wav
    * url: https://freesound.org/s/493364/
    * license: Creative Commons 0
  * 493363__joao-janz__clothes-shaking-movement-2-3.wav
    * url: https://freesound.org/s/493363/
    * license: Creative Commons 0
  * 493362__joao-janz__clothes-rustling-movement-6-2.wav
    * url: https://freesound.org/s/493362/
    * license: Creative Commons 0
  * 493361__joao-janz__clothes-rustling-movement-6-3.wav
    * url: https://freesound.org/s/493361/
    * license: Creative Commons 0
  * 493360__joao-janz__clothes-shaking-movement-2-8.wav
    * url: https://freesound.org/s/493360/
    * license: Creative Commons 0
  * 493359__joao-janz__clothes-shaking-movement-2-7.wav
    * url: https://freesound.org/s/493359/
    * license: Creative Commons 0
  * 493358__joao-janz__clothes-shaking-movement-3-6.wav
    * url: https://freesound.org/s/493358/
    * license: Creative Commons 0
  * 493357__joao-janz__clothes-shaking-movement-6-21.wav
    * url: https://freesound.org/s/493357/
    * license: Creative Commons 0
  * 493356__joao-janz__clothes-rustling-movement-4-2.wav
    * url: https://freesound.org/s/493356/
    * license: Creative Commons 0
  * 493355__joao-janz__clothes-rustling-movement-4-1.wav
    * url: https://freesound.org/s/493355/
    * license: Creative Commons 0
  * 493354__joao-janz__clothes-rustling-movement-3-6.wav
    * url: https://freesound.org/s/493354/
    * license: Creative Commons 0
  * 493353__joao-janz__clothes-rustling-movement-3-5.wav
    * url: https://freesound.org/s/493353/
    * license: Creative Commons 0
  * 493352__joao-janz__clothes-rustling-movement-4-6.wav
    * url: https://freesound.org/s/493352/
    * license: Creative Commons 0
  * 493351__joao-janz__clothes-rustling-movement-4-5.wav
    * url: https://freesound.org/s/493351/
    * license: Creative Commons 0
  * 493350__joao-janz__clothes-rustling-movement-4-4.wav
    * url: https://freesound.org/s/493350/
    * license: Creative Commons 0
  * 493349__joao-janz__clothes-rustling-movement-4-3.wav
    * url: https://freesound.org/s/493349/
    * license: Creative Commons 0
  * 493348__joao-janz__clothes-shaking-movement-3-12.wav
    * url: https://freesound.org/s/493348/
    * license: Creative Commons 0
  * 493347__joao-janz__clothes-shaking-movement-3-13.wav
    * url: https://freesound.org/s/493347/
    * license: Creative Commons 0
  * 493346__joao-janz__clothes-rustling-movement-5-1.wav
    * url: https://freesound.org/s/493346/
    * license: Creative Commons 0
  * 493345__joao-janz__clothes-rustling-movement-4-7.wav
    * url: https://freesound.org/s/493345/
    * license: Creative Commons 0
  * 493344__joao-janz__clothes-shaking-movement-3-16.wav
    * url: https://freesound.org/s/493344/
    * license: Creative Commons 0
  * 493343__joao-janz__clothes-shaking-movement-3-2.wav
    * url: https://freesound.org/s/493343/
    * license: Creative Commons 0
  * 493342__joao-janz__clothes-shaking-movement-3-3.wav
    * url: https://freesound.org/s/493342/
    * license: Creative Commons 0
  * 493341__joao-janz__clothes-shaking-movement-3-4.wav
    * url: https://freesound.org/s/493341/
    * license: Creative Commons 0
  * 493340__joao-janz__clothes-rustling-movement-13-1.wav
    * url: https://freesound.org/s/493340/
    * license: Creative Commons 0
  * 493339__joao-janz__clothes-rustling-movement-13-10.wav
    * url: https://freesound.org/s/493339/
    * license: Creative Commons 0
  * 493338__joao-janz__clothes-rustling-movement-12-7.wav
    * url: https://freesound.org/s/493338/
    * license: Creative Commons 0
  * 493337__joao-janz__clothes-rustling-movement-12-8.wav
    * url: https://freesound.org/s/493337/
    * license: Creative Commons 0
  * 493336__joao-janz__clothes-rustling-movement-12-5.wav
    * url: https://freesound.org/s/493336/
    * license: Creative Commons 0
  * 493335__joao-janz__clothes-rustling-movement-12-6.wav
    * url: https://freesound.org/s/493335/
    * license: Creative Commons 0
  * 493334__joao-janz__clothes-rustling-movement-12-3.wav
    * url: https://freesound.org/s/493334/
    * license: Creative Commons 0
  * 493333__joao-janz__clothes-rustling-movement-12-4.wav
    * url: https://freesound.org/s/493333/
    * license: Creative Commons 0
  * 493332__joao-janz__clothes-rustling-movement-13-11.wav
    * url: https://freesound.org/s/493332/
    * license: Creative Commons 0
  * 493331__joao-janz__clothes-rustling-movement-13-12.wav
    * url: https://freesound.org/s/493331/
    * license: Creative Commons 0
  * 493330__joao-janz__clothes-shaking-movement-6-12.wav
    * url: https://freesound.org/s/493330/
    * license: Creative Commons 0
  * 493329__joao-janz__clothes-shaking-movement-1-1.wav
    * url: https://freesound.org/s/493329/
    * license: Creative Commons 0
  * 493328__joao-janz__clothes-rustling-movement-9-9.wav
    * url: https://freesound.org/s/493328/
    * license: Creative Commons 0
  * 493327__joao-janz__clothes-rustling-movement-9-6.wav
    * url: https://freesound.org/s/493327/
    * license: Creative Commons 0
  * 493326__joao-janz__clothes-rustling-movement-9-5.wav
    * url: https://freesound.org/s/493326/
    * license: Creative Commons 0
  * 493325__joao-janz__clothes-rustling-movement-9-8.wav
    * url: https://freesound.org/s/493325/
    * license: Creative Commons 0
  * 493324__joao-janz__clothes-rustling-movement-9-7.wav
    * url: https://freesound.org/s/493324/
    * license: Creative Commons 0
  * 493323__joao-janz__clothes-rustling-movement-9-2.wav
    * url: https://freesound.org/s/493323/
    * license: Creative Commons 0
  * 493322__joao-janz__clothes-rustling-movement-9-10.wav
    * url: https://freesound.org/s/493322/
    * license: Creative Commons 0
  * 493321__joao-janz__clothes-rustling-movement-9-4.wav
    * url: https://freesound.org/s/493321/
    * license: Creative Commons 0
  * 493320__joao-janz__clothes-rustling-movement-9-3.wav
    * url: https://freesound.org/s/493320/
    * license: Creative Commons 0
  * 493319__joao-janz__clothes-rustling-movement-11-7.wav
    * url: https://freesound.org/s/493319/
    * license: Creative Commons 0
  * 493318__joao-janz__clothes-rustling-movement-11-6.wav
    * url: https://freesound.org/s/493318/
    * license: Creative Commons 0
  * 493317__joao-janz__clothes-rustling-movement-11-9.wav
    * url: https://freesound.org/s/493317/
    * license: Creative Commons 0
  * 493316__joao-janz__clothes-rustling-movement-11-8.wav
    * url: https://freesound.org/s/493316/
    * license: Creative Commons 0
  * 493315__joao-janz__clothes-rustling-movement-11-3.wav
    * url: https://freesound.org/s/493315/
    * license: Creative Commons 0
  * 493314__joao-janz__clothes-rustling-movement-11-2.wav
    * url: https://freesound.org/s/493314/
    * license: Creative Commons 0
  * 493308__joao-janz__clothes-rustling-movement-11-5.wav
    * url: https://freesound.org/s/493308/
    * license: Creative Commons 0
  * 493307__joao-janz__clothes-rustling-movement-11-4.wav
    * url: https://freesound.org/s/493307/
    * license: Creative Commons 0
  * 493306__joao-janz__clothes-shaking-movement-6-10.wav
    * url: https://freesound.org/s/493306/
    * license: Creative Commons 0
  * 493305__joao-janz__clothes-shaking-movement-6-1.wav
    * url: https://freesound.org/s/493305/
    * license: Creative Commons 0
  * 493304__joao-janz__clothes-shaking-movement-5-8.wav
    * url: https://freesound.org/s/493304/
    * license: Creative Commons 0
  * 493303__joao-janz__clothes-shaking-movement-5-7.wav
    * url: https://freesound.org/s/493303/
    * license: Creative Commons 0
  * 493302__joao-janz__clothes-rustling-movement-12-2.wav
    * url: https://freesound.org/s/493302/
    * license: Creative Commons 0
  * 493301__joao-janz__clothes-rustling-movement-12-1.wav
    * url: https://freesound.org/s/493301/
    * license: Creative Commons 0
  * 493300__joao-janz__clothes-shaking-movement-5-4.wav
    * url: https://freesound.org/s/493300/
    * license: Creative Commons 0
  * 493299__joao-janz__clothes-shaking-movement-5-3.wav
    * url: https://freesound.org/s/493299/
    * license: Creative Commons 0
  * 493298__joao-janz__clothes-shaking-movement-2-1.wav
    * url: https://freesound.org/s/493298/
    * license: Creative Commons 0
  * 493297__joao-janz__clothes-shaking-movement-2-2.wav
    * url: https://freesound.org/s/493297/
    * license: Creative Commons 0
  * 493296__joao-janz__clothes-shaking-movement-1-4.wav
    * url: https://freesound.org/s/493296/
    * license: Creative Commons 0
  * 493295__joao-janz__clothes-shaking-movement-1-5.wav
    * url: https://freesound.org/s/493295/
    * license: Creative Commons 0
  * 493294__joao-janz__clothes-shaking-movement-1-2.wav
    * url: https://freesound.org/s/493294/
    * license: Creative Commons 0
  * 493293__joao-janz__clothes-shaking-movement-1-3.wav
    * url: https://freesound.org/s/493293/
    * license: Creative Commons 0
  * 493292__joao-janz__clothes-shaking-movement-1-8.wav
    * url: https://freesound.org/s/493292/
    * license: Creative Commons 0
  * 493291__joao-janz__clothes-shaking-movement-1-9.wav
    * url: https://freesound.org/s/493291/
    * license: Creative Commons 0
  * 493290__joao-janz__clothes-shaking-movement-1-6.wav
    * url: https://freesound.org/s/493290/
    * license: Creative Commons 0
  * 493289__joao-janz__clothes-shaking-movement-1-7.wav
    * url: https://freesound.org/s/493289/
    * license: Creative Commons 0
  * 493287__joao-janz__blanket-shaking-movement-1-6.wav
    * url: https://freesound.org/s/493287/
    * license: Creative Commons 0
  * 493286__joao-janz__blanket-shaking-movement-1-7.wav
    * url: https://freesound.org/s/493286/
    * license: Creative Commons 0
  * 493285__joao-janz__blanket-shaking-movement-1-2.wav
    * url: https://freesound.org/s/493285/
    * license: Creative Commons 0
  * 493284__joao-janz__blanket-shaking-movement-1-3.wav
    * url: https://freesound.org/s/493284/
    * license: Creative Commons 0
  * 493283__joao-janz__blanket-shaking-movement-1-4.wav
    * url: https://freesound.org/s/493283/
    * license: Creative Commons 0
  * 493282__joao-janz__blanket-shaking-movement-1-5.wav
    * url: https://freesound.org/s/493282/
    * license: Creative Commons 0
  * 493281__joao-janz__blanket-rustling-movement-2-8.wav
    * url: https://freesound.org/s/493281/
    * license: Creative Commons 0
  * 493280__joao-janz__blanket-rustling-movement-3-1.wav
    * url: https://freesound.org/s/493280/
    * license: Creative Commons 0
  * 493279__joao-janz__blanket-rustling-movement-3-2.wav
    * url: https://freesound.org/s/493279/
    * license: Creative Commons 0
  * 493278__joao-janz__blanket-shaking-movement-1-1.wav
    * url: https://freesound.org/s/493278/
    * license: Creative Commons 0
  * 493277__joao-janz__blanket-shaking-movement-2-6.wav
    * url: https://freesound.org/s/493277/
    * license: Creative Commons 0
  * 493276__joao-janz__blanket-shaking-movement-2-5.wav
    * url: https://freesound.org/s/493276/
    * license: Creative Commons 0
  * 493275__joao-janz__blanket-shaking-movement-2-8.wav
    * url: https://freesound.org/s/493275/
    * license: Creative Commons 0
  * 493274__joao-janz__blanket-shaking-movement-2-7.wav
    * url: https://freesound.org/s/493274/
    * license: Creative Commons 0
  * 493273__joao-janz__blanket-shaking-movement-2-2.wav
    * url: https://freesound.org/s/493273/
    * license: Creative Commons 0
  * 493272__joao-janz__blanket-shaking-movement-2-1.wav
    * url: https://freesound.org/s/493272/
    * license: Creative Commons 0
  * 493271__joao-janz__blanket-shaking-movement-2-4.wav
    * url: https://freesound.org/s/493271/
    * license: Creative Commons 0
  * 493270__joao-janz__blanket-shaking-movement-2-3.wav
    * url: https://freesound.org/s/493270/
    * license: Creative Commons 0
  * 493269__joao-janz__blanket-rustling-movement-2-6.wav
    * url: https://freesound.org/s/493269/
    * license: Creative Commons 0
  * 493268__joao-janz__blanket-rustling-movement-2-7.wav
    * url: https://freesound.org/s/493268/
    * license: Creative Commons 0
  * 493267__joao-janz__blanket-rustling-movement-2-2.wav
    * url: https://freesound.org/s/493267/
    * license: Creative Commons 0
  * 493266__joao-janz__blanket-rustling-movement-2-3.wav
    * url: https://freesound.org/s/493266/
    * license: Creative Commons 0
  * 493265__joao-janz__blanket-rustling-movement-2-4.wav
    * url: https://freesound.org/s/493265/
    * license: Creative Commons 0
  * 493264__joao-janz__blanket-rustling-movement-2-5.wav
    * url: https://freesound.org/s/493264/
    * license: Creative Commons 0
  * 493263__joao-janz__blanket-rustling-movement-1-1.wav
    * url: https://freesound.org/s/493263/
    * license: Creative Commons 0
  * 493262__joao-janz__blanket-rustling-movement-1-2.wav
    * url: https://freesound.org/s/493262/
    * license: Creative Commons 0
  * 493261__joao-janz__blanket-rustling-movement-1-3.wav
    * url: https://freesound.org/s/493261/
    * license: Creative Commons 0
  * 493260__joao-janz__blanket-rustling-movement-2-1.wav
    * url: https://freesound.org/s/493260/
    * license: Creative Commons 0
  * 493221__joao-janz__belt-buckle-handling-4-11.wav
    * url: https://freesound.org/s/493221/
    * license: Creative Commons 0
  * 493220__joao-janz__belt-buckle-handling-4-12.wav
    * url: https://freesound.org/s/493220/
    * license: Creative Commons 0
  * 493219__joao-janz__belt-buckle-handling-4-1.wav
    * url: https://freesound.org/s/493219/
    * license: Creative Commons 0
  * 493218__joao-janz__belt-buckle-handling-4-10.wav
    * url: https://freesound.org/s/493218/
    * license: Creative Commons 0
  * 493217__joao-janz__belt-buckle-handling-3-7.wav
    * url: https://freesound.org/s/493217/
    * license: Creative Commons 0
  * 493216__joao-janz__belt-buckle-handling-3-8.wav
    * url: https://freesound.org/s/493216/
    * license: Creative Commons 0
  * 493215__joao-janz__belt-buckle-handling-3-5.wav
    * url: https://freesound.org/s/493215/
    * license: Creative Commons 0
  * 493214__joao-janz__belt-buckle-handling-3-6.wav
    * url: https://freesound.org/s/493214/
    * license: Creative Commons 0
  * 493213__joao-janz__belt-buckle-handling-5-3.wav
    * url: https://freesound.org/s/493213/
    * license: Creative Commons 0
  * 493212__joao-janz__belt-buckle-handling-5-4.wav
    * url: https://freesound.org/s/493212/
    * license: Creative Commons 0
  * 493211__joao-janz__belt-buckle-handling-5-10.wav
    * url: https://freesound.org/s/493211/
    * license: Creative Commons 0
  * 493210__joao-janz__leather-belt-stretching-1-6.wav
    * url: https://freesound.org/s/493210/
    * license: Creative Commons 0
  * 493209__joao-janz__leather-belt-stretching-1-3.wav
    * url: https://freesound.org/s/493209/
    * license: Creative Commons 0
  * 493208__joao-janz__belt-buckle-handling-4-13.wav
    * url: https://freesound.org/s/493208/
    * license: Creative Commons 0
  * 493207__joao-janz__belt-buckle-handling-4-14.wav
    * url: https://freesound.org/s/493207/
    * license: Creative Commons 0
  * 493206__joao-janz__belt-buckle-handling-5-11.wav
    * url: https://freesound.org/s/493206/
    * license: Creative Commons 0
  * 493205__joao-janz__belt-buckle-handling-5-7.wav
    * url: https://freesound.org/s/493205/
    * license: Creative Commons 0
  * 493204__joao-janz__belt-buckle-handling-2-2.wav
    * url: https://freesound.org/s/493204/
    * license: Creative Commons 0
  * 493203__joao-janz__belt-buckle-handling-2-3.wav
    * url: https://freesound.org/s/493203/
    * license: Creative Commons 0
  * 493202__joao-janz__belt-buckle-handling-5-12.wav
    * url: https://freesound.org/s/493202/
    * license: Creative Commons 0
  * 493201__joao-janz__belt-buckle-handling-2-10.wav
    * url: https://freesound.org/s/493201/
    * license: Creative Commons 0
  * 493200__joao-janz__belt-buckle-handling-2-11.wav
    * url: https://freesound.org/s/493200/
    * license: Creative Commons 0
  * 493199__joao-janz__belt-buckle-handling-2-12.wav
    * url: https://freesound.org/s/493199/
    * license: Creative Commons 0
  * 493198__joao-janz__belt-buckle-handling-2-13.wav
    * url: https://freesound.org/s/493198/
    * license: Creative Commons 0
  * 493197__joao-janz__belt-buckle-handling-1-7.wav
    * url: https://freesound.org/s/493197/
    * license: Creative Commons 0
  * 493196__joao-janz__belt-buckle-handling-1-8.wav
    * url: https://freesound.org/s/493196/
    * license: Creative Commons 0
  * 493195__joao-janz__belt-buckle-handling-1-9.wav
    * url: https://freesound.org/s/493195/
    * license: Creative Commons 0
  * 493194__joao-janz__belt-buckle-handling-2-1.wav
    * url: https://freesound.org/s/493194/
    * license: Creative Commons 0
  * 493193__joao-janz__belt-buckle-handling-5-14.wav
    * url: https://freesound.org/s/493193/
    * license: Creative Commons 0
  * 493192__joao-janz__leather-belt-stretching-1-7.wav
    * url: https://freesound.org/s/493192/
    * license: Creative Commons 0
  * 493191__joao-janz__belt-buckle-handling-4-9.wav
    * url: https://freesound.org/s/493191/
    * license: Creative Commons 0
  * 493190__joao-janz__leather-belt-stretching-1-9.wav
    * url: https://freesound.org/s/493190/
    * license: Creative Commons 0
  * 493189__joao-janz__belt-buckle-handling-4-8.wav
    * url: https://freesound.org/s/493189/
    * license: Creative Commons 0
  * 493188__joao-janz__belt-buckle-handling-5-13.wav
    * url: https://freesound.org/s/493188/
    * license: Creative Commons 0
  * 493187__joao-janz__belt-buckle-handling-4-3.wav
    * url: https://freesound.org/s/493187/
    * license: Creative Commons 0
  * 493186__joao-janz__belt-buckle-handling-5-8.wav
    * url: https://freesound.org/s/493186/
    * license: Creative Commons 0
  * 493185__joao-janz__belt-buckle-handling-5-6.wav
    * url: https://freesound.org/s/493185/
    * license: Creative Commons 0
  * 493184__joao-janz__belt-buckle-handling-5-1.wav
    * url: https://freesound.org/s/493184/
    * license: Creative Commons 0
  * 493183__joao-janz__belt-buckle-handling-5-5.wav
    * url: https://freesound.org/s/493183/
    * license: Creative Commons 0
  * 493182__joao-janz__belt-buckle-handling-5-2.wav
    * url: https://freesound.org/s/493182/
    * license: Creative Commons 0
  * 493181__joao-janz__belt-buckle-handling-5-9.wav
    * url: https://freesound.org/s/493181/
    * license: Creative Commons 0
  * 493180__joao-janz__belt-buckle-handling-2-9.wav
    * url: https://freesound.org/s/493180/
    * license: Creative Commons 0
  * 493179__joao-janz__belt-buckle-handling-2-8.wav
    * url: https://freesound.org/s/493179/
    * license: Creative Commons 0
  * 493178__joao-janz__belt-buckle-handling-3-2.wav
    * url: https://freesound.org/s/493178/
    * license: Creative Commons 0
  * 493177__joao-janz__belt-buckle-handling-3-1.wav
    * url: https://freesound.org/s/493177/
    * license: Creative Commons 0
  * 493176__joao-janz__belt-buckle-handling-2-5.wav
    * url: https://freesound.org/s/493176/
    * license: Creative Commons 0
  * 493175__joao-janz__belt-buckle-handling-2-4.wav
    * url: https://freesound.org/s/493175/
    * license: Creative Commons 0
  * 493174__joao-janz__belt-buckle-handling-2-7.wav
    * url: https://freesound.org/s/493174/
    * license: Creative Commons 0
  * 493173__joao-janz__belt-buckle-handling-2-6.wav
    * url: https://freesound.org/s/493173/
    * license: Creative Commons 0
  * 493172__joao-janz__belt-buckle-handling-4-7.wav
    * url: https://freesound.org/s/493172/
    * license: Creative Commons 0
  * 493171__joao-janz__belt-buckle-handling-4-6.wav
    * url: https://freesound.org/s/493171/
    * license: Creative Commons 0
  * 493170__joao-janz__belt-buckle-handling-4-5.wav
    * url: https://freesound.org/s/493170/
    * license: Creative Commons 0
  * 493169__joao-janz__belt-buckle-handling-4-4.wav
    * url: https://freesound.org/s/493169/
    * license: Creative Commons 0
  * 493168__joao-janz__belt-buckle-handling-3-4.wav
    * url: https://freesound.org/s/493168/
    * license: Creative Commons 0
  * 493167__joao-janz__belt-buckle-handling-3-3.wav
    * url: https://freesound.org/s/493167/
    * license: Creative Commons 0
  * 493166__joao-janz__belt-buckle-handling-4-16.wav
    * url: https://freesound.org/s/493166/
    * license: Creative Commons 0
  * 493165__joao-janz__belt-buckle-handling-4-15.wav
    * url: https://freesound.org/s/493165/
    * license: Creative Commons 0
  * 493160__joao-janz__belt-buckle-handling-4-2.wav
    * url: https://freesound.org/s/493160/
    * license: Creative Commons 0
  * 493159__joao-janz__leather-belt-stretching-1-1.wav
    * url: https://freesound.org/s/493159/
    * license: Creative Commons 0
  * 493158__joao-janz__leather-belt-stretching-1-2.wav
    * url: https://freesound.org/s/493158/
    * license: Creative Commons 0
  * 493157__joao-janz__leather-belt-stretching-1-10.wav
    * url: https://freesound.org/s/493157/
    * license: Creative Commons 0
  * 493156__joao-janz__leather-belt-stretching-1-5.wav
    * url: https://freesound.org/s/493156/
    * license: Creative Commons 0
  * 493155__joao-janz__leather-belt-stretching-2-1.wav
    * url: https://freesound.org/s/493155/
    * license: Creative Commons 0
  * 493154__joao-janz__leather-belt-stretching-1-8.wav
    * url: https://freesound.org/s/493154/
    * license: Creative Commons 0
  * 493153__joao-janz__belt-buckle-handling-5-15.wav
    * url: https://freesound.org/s/493153/
    * license: Creative Commons 0
  * 493152__joao-janz__leather-belt-stretching-1-4.wav
    * url: https://freesound.org/s/493152/
    * license: Creative Commons 0
  * 493151__joao-janz__leather-belt-stretching-2-2.wav
    * url: https://freesound.org/s/493151/
    * license: Creative Commons 0
  * 493150__joao-janz__belt-buckle-handling-1-5.wav
    * url: https://freesound.org/s/493150/
    * license: Creative Commons 0
  * 493149__joao-janz__belt-buckle-handling-1-6.wav
    * url: https://freesound.org/s/493149/
    * license: Creative Commons 0
  * 493148__joao-janz__belt-buckle-handling-1-13.wav
    * url: https://freesound.org/s/493148/
    * license: Creative Commons 0
  * 493147__joao-janz__belt-buckle-handling-1-2.wav
    * url: https://freesound.org/s/493147/
    * license: Creative Commons 0
  * 493146__joao-janz__belt-buckle-handling-1-3.wav
    * url: https://freesound.org/s/493146/
    * license: Creative Commons 0
  * 493145__joao-janz__belt-buckle-handling-1-4.wav
    * url: https://freesound.org/s/493145/
    * license: Creative Commons 0
  * 493144__joao-janz__belt-buckle-handling-1-1.wav
    * url: https://freesound.org/s/493144/
    * license: Creative Commons 0
  * 493143__joao-janz__belt-buckle-handling-1-10.wav
    * url: https://freesound.org/s/493143/
    * license: Creative Commons 0
  * 493142__joao-janz__belt-buckle-handling-1-11.wav
    * url: https://freesound.org/s/493142/
    * license: Creative Commons 0
  * 493141__joao-janz__belt-buckle-handling-1-12.wav
    * url: https://freesound.org/s/493141/
    * license: Creative Commons 0


