extends Reference

# Runs after every mod ZIP is mounted and before game content is registered.
# Wraps the few game functions this mod needs; see RuntimePatches.gd.
func _init():
	var result = load("res://Modules/LockTweaks/RuntimePatches.gd").apply_all()
	Log.print("[SmartLocks Extended] Runtime patches: " + str(result))
