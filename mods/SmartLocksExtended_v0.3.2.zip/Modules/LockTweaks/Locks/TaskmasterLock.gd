extends "res://Modules/LockTweaks/Locks/SlutLock.gd"

var requiredDays:int = 2
var consecutiveDays:int = 0
var taskDay:int = 0
var released:bool = false
var assessing:bool = false

func _init():
	id = "TaskmasterLock"

func getName():
	return "Taskmaster Lock"

func onLocked(context):
	requiredDays = Settings.scaled_requirement("TaskmasterDays", 2, 1, 30)
	consecutiveDays = 0
	taskDay = GM.main.getDays() if GM.main != null else 0
	released = false
	.onLocked(context)

func canBeSimpleRemoved() -> bool:
	return released

func morning_check(day:int):
	if released or day <= taskDay:
		return
	# Final state check only; the assessment message below replaces the "tasks complete" reminder.
	assessing = true
	checkIfTasksGotCompleted()
	assessing = false
	if day == taskDay + 1 and isEverythingCompleted():
		consecutiveDays += 1
	else:
		consecutiveDays = 0
	taskDay = day
	canRemoveReminded = false
	if consecutiveDays >= requiredDays:
		released = true
		message("Taskmaster Lock: the required streak is complete. The lock opens at the morning check.")
		return
	generateTasks(roll_task_count())
	message("Taskmaster Lock morning check: " + str(consecutiveDays) + "/" + str(requiredDays) + " consecutive days. A new task list has been assigned.")

func announce_completion():
	if assessing:
		return
	if not canRemoveReminded and isEverythingCompleted():
		canRemoveReminded = true
		message("Taskmaster Lock: today's tasks are complete. Assessment happens at the next morning check.")

func getUnlockDescription():
	var text = "Consecutive completed days: %d/%d.\n" % [consecutiveDays, requiredDays]
	if released:
		text += "Morning assessment passed. The lock can be removed."
	else:
		text += "All daily tasks must be complete at the next morning check. A missed day resets the streak.\n" + getQuestProgressText()
	if keysAllowed:
		text += "\nAlternatively, use %d ordinary restraint keys." % keyAmount
	return text

func saveData():
	var data = .saveData()
	data["requiredDays"] = requiredDays
	data["consecutiveDays"] = consecutiveDays
	data["taskDay"] = taskDay
	data["released"] = released
	return data

func loadData(data):
	.loadData(data)
	requiredDays = int(max(1, SAVE.loadVar(data, "requiredDays", 2)))
	consecutiveDays = int(max(0, SAVE.loadVar(data, "consecutiveDays", 0)))
	taskDay = int(SAVE.loadVar(data, "taskDay", GM.main.getDays() if GM.main != null else 0))
	released = bool(SAVE.loadVar(data, "released", false))
