extends "res://Modules/LockTweaks/Locks/ModLockBase.gd"

var holders:Array = []
var released:Array = []

func _init():
	id = "MultiKeyholderLock"

func getName():
	return "Multi-keyholder lock"

func onLocked(context):
	var wanted = int(Settings.number("Keyholders", 3, 2, 10))
	holders = Settings.pick_npcs(getWearer(), context.get("forcer", null), wanted)
	released = []
	setup_keys(2, 8)

func isKeyholder(char_id:String):
	return holders.has(char_id) and not released.has(char_id)

# Returns true only for a NEW release. Repeated interactions cannot count twice.
func releaseKeyholder(char_id:String):
	if not isKeyholder(char_id):
		return false
	released.append(char_id)
	return true

func canBeSimpleRemoved() -> bool:
	for char_id in holders:
		if not released.has(char_id):
			return false
	return true

func getUnlockDescription():
	var lines = ["Each holder must open their own lock. Releases: %d/%d." % [released.size(), holders.size()]]
	for char_id in holders:
		var character = GlobalRegistry.getCharacter(char_id)
		var holder_name = character.getName() if character != null else "Unavailable holder (" + char_id + ")"
		lines.append(("[OPEN] " if released.has(char_id) else "[LOCKED] ") + holder_name)
	if holders.empty():
		lines.append("No eligible keyholders were available. The lock can be removed.")
	return with_keys_line(PoolStringArray(lines).join("\n"))

func saveData():
	return save_keys({"holders": holders.duplicate(), "released": released.duplicate()})

func loadData(data):
	holders = []
	released = []
	for char_id in SAVE.loadVar(data, "holders", []):
		if char_id is String and char_id != "" and not holders.has(char_id):
			holders.append(char_id)
	for char_id in SAVE.loadVar(data, "released", []):
		if holders.has(char_id) and not released.has(char_id):
			released.append(char_id)
	load_keys(data, 5, false)
