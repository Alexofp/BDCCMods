extends "res://Modules/LockTweaks/Locks/ModLockBase.gd"

var ownerID:String = ""
var targetCredits:int = 50
var paidCredits:int = 0
# Qualifying prostitution earnings not yet delivered, keyed by income transaction.
var earnings:Dictionary = {}
var partialPayments:bool = true

func _init():
	id = "ProstitutionLock"

func getName():
	return "Prostitution Lock"

func onLocked(context):
	targetCredits = Settings.scaled_requirement("ProstitutionCredits", 50, 1, 10000)
	partialPayments = bool(Settings.value("ProstitutionPartial", true))
	paidCredits = 0
	earnings = {}
	var owners = Settings.pick_npcs(getWearer(), context.get("forcer", null), 1)
	ownerID = owners[0] if not owners.empty() else ""
	setup_keys(2, 5)

# Deliberately not a keyholder: asking for keys or winning a fight cannot bypass payment.
func isLockOwner(char_id:String):
	return ownerID == char_id and not canBeSimpleRemoved()

func canBeSimpleRemoved() -> bool:
	return ownerID == "" or paidCredits >= targetCredits

func remaining_debt() -> int:
	return int(max(0, targetCredits - paidCredits))

func qualified_credits():
	var total = 0
	for amount in earnings.values():
		total += int(amount)
	return total

# Accepts at most what is still owed beyond earnings already held. Returns the amount accepted.
func add_income(transaction:String, amount:int):
	if canBeSimpleRemoved() or transaction == "" or amount <= 0:
		return 0
	var accepted = int(min(amount, max(0, remaining_debt() - qualified_credits())))
	if accepted > 0:
		earnings[transaction] = int(earnings.get(transaction, 0)) + accepted
	return accepted

# Removes up to `amount` of one transaction's earnings. Returns the amount removed.
func refund_income(transaction:String, amount:int):
	var removed = int(min(max(0, amount), earnings.get(transaction, 0)))
	if removed > 0:
		earnings[transaction] -= removed
		if earnings[transaction] <= 0:
			earnings.erase(transaction)
	return removed

# What can be paid now: limited by the debt, qualifying earnings, and wallet credits.
func payment_amount(player):
	var remaining = remaining_debt()
	var available = int(min(remaining, min(qualified_credits(), max(0, player.getCredits()))))
	if not partialPayments and available < remaining:
		return 0
	return available

func pay(player, owner_id:String):
	if not isLockOwner(owner_id) or player != getWearer():
		return 0
	var amount = payment_amount(player)
	if amount <= 0:
		return 0
	var left = amount
	for transaction in earnings.keys():
		left -= refund_income(transaction, left)
		if left <= 0:
			break
	player.addCredits(-amount)
	paidCredits += amount
	return amount

func getUnlockDescription():
	if ownerID == "":
		return with_keys_line("No eligible owner was available. The lock can be removed.")
	var owner = GlobalRegistry.getCharacter(ownerID)
	var owner_name = owner.getName() if owner != null else "Unavailable owner"
	var text = "Owner: %s. Delivered: %d/%d credits.\nQualifying prostitution earnings available: %d credits.\nEarn credits through prostitution, then talk to the owner to deliver them." % [owner_name, paidCredits, targetCredits, qualified_credits()]
	if not partialPayments:
		text += "\nThe remaining amount must be paid in full."
	return with_keys_line(text)

func saveData():
	return save_keys({"ownerID": ownerID, "targetCredits": targetCredits, "paidCredits": paidCredits, "earnings": earnings.duplicate(), "partialPayments": partialPayments})

func loadData(data):
	ownerID = str(SAVE.loadVar(data, "ownerID", ""))
	targetCredits = int(max(1, SAVE.loadVar(data, "targetCredits", 50)))
	paidCredits = int(clamp(SAVE.loadVar(data, "paidCredits", 0), 0, targetCredits))
	earnings = {}
	var saved_earnings = SAVE.loadVar(data, "earnings", {})
	for transaction in saved_earnings:
		var amount = int(max(0, saved_earnings[transaction]))
		if amount > 0:
			earnings[str(transaction)] = amount
	partialPayments = bool(SAVE.loadVar(data, "partialPayments", true))
	load_keys(data, 5, false)
