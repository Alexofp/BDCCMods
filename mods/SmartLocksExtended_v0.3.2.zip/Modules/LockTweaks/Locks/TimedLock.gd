extends "res://Modules/LockTweaks/Locks/ModLockBase.gd"

var unlockAt:int = 0

func _init():
	id = "TimedLock"
	keyAmount = 3
	keysAllowed = true

func getName():
	return "Timed lock"

func onLocked(_context):
	var hours = Settings.random_between("TimedHoursMin", 6, "TimedHoursMax", 24, 1, 720)
	unlockAt = now() + hours * 3600
	setup_keys(2, 5)

func now():
	return GM.main.getTimeInGlobalSeconds() if GM.main != null else 0

func canBeSimpleRemoved() -> bool:
	return now() >= unlockAt

func getUnlockDescription():
	var remaining = max(0, unlockAt - now())
	var text
	if remaining <= 0:
		text = "Timer complete. The lock can be removed."
	elif Settings.has_starting_perk(getWearer(), Settings.UNCERTAIN_SENTENCE):
		text = "Timer still locked. The timer appears to be broken."
	else:
		var minutes = int(ceil(remaining / 60.0))
		text = "Time remaining: %dh %dm (in-game time)." % [int(minutes / 60), minutes % 60]
	return with_keys_line(text)

func saveData():
	return save_keys({"unlockAt": unlockAt})

func loadData(data):
	unlockAt = int(SAVE.loadVar(data, "unlockAt", now()))
	load_keys(data, 3, true)
