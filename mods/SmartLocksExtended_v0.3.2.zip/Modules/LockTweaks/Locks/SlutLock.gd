extends "res://Inventory/SmartLocks/Locks/SlutLock.gd"

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var keysAllowed:bool = true
var releaseChecked:bool = false
var processingTasks:bool = false

func onLocked(context):
	.onLocked(context)
	keyAmount = Settings.key_count(id, keyAmount)
	keysAllowed = Settings.keys_allowed(id)

func canBeUnlockedWithKeys() -> bool:
	return keysAllowed

func getUnlockDescription():
	if keysAllowed:
		return .getUnlockDescription()
	return "Ordinary keys cannot open this lock.\n" + getQuestProgressText()

func saveData():
	var data = .saveData()
	data["keysAllowed"] = keysAllowed
	data["releaseChecked"] = releaseChecked
	return data

func loadData(data):
	# Let the game load its own fields (including any added in future versions),
	# then rebuild the task list with this mod's task classes and save repairs.
	.loadData(data)
	keyAmount = int(keyAmount)
	canRemoveReminded = bool(canRemoveReminded)
	for task in tasks:
		task.disconnect("onTaskCompleted", self, "onSlutTaskCompleted")
	clearTasks()
	for entry in SAVE.loadVar(data, "tasks", []):
		var task_id = SAVE.loadVar(entry, "id", "")
		var task = create_task(task_id)
		if task == null:
			continue
		task.loadData(SAVE.loadVar(entry, "data", {}))
		if task_id == "HaveSexWithSpecies":
			task.needAmount = 1
			if task.currentAmount >= 1:
				task.taskIsCompleted = true
		if task_id == "PenetrateEveryHole":
			task.migrate_for(getWearer())
		add_task(task)
	keysAllowed = bool(SAVE.loadVar(data, "keysAllowed", true))
	releaseChecked = bool(SAVE.loadVar(data, "releaseChecked", false))
	processingTasks = false

func create_task(task_id):
	if task_id == "PenetrateEveryHole":
		return load("res://Modules/LockTweaks/Tasks/EveryHoleTask.gd").new()
	return GlobalRegistry.createSlaveBreakTask(task_id)

func generateTasks(howManyTasks = 2):
	clearTasks()
	releaseChecked = false
	canRemoveReminded = false
	var wearer = getWearer()
	if wearer == null:
		return
	# Refresh restraint buffs first, as the game does, so impossible tasks are filtered out.
	# Covers Faulty Release resets and Taskmaster daily lists, not only initial locking.
	wearer.updateNonBattleEffects()
	if not Settings.value("VanillaTaskCount", true):
		howManyTasks = Settings.random_between("TasksMin", 1, "TasksMax", 2, 1, 20)
	var choices = []
	for task_id in GlobalRegistry.getSlaveBreakTaskRefs():
		var task_ref = GlobalRegistry.getSlaveBreakTaskRef(task_id)
		if not Settings.value("TaskEnabled_" + task_id, true) or not task_ref.isPossibleForSlutlock(wearer):
			continue
		var weight = task_ref.getSlutlockWeight()
		if weight > 0:
			choices.append([task_id, weight])
	while howManyTasks > 0 and not choices.empty():
		var task_id = RNG.pickWeightedPairs(choices)
		var task = create_task(task_id)
		task.generateFor(wearer, false, Settings.roll_difficulty())
		apply_amount_setting(task)
		add_task(task)
		howManyTasks -= 1
		if not Settings.value("RepeatTasks", false):
			for index in range(choices.size() - 1, -1, -1):
				if choices[index][0] == task_id:
					choices.remove(index)

# Applies the task's amount multiplier after difficulty. Fixed-condition tasks are unaffected.
func apply_amount_setting(task):
	if task.id == "HaveSexWithSpecies":
		task.needAmount = 1 # Always exactly one qualifying event.
	elif task.id == "PenetrateEveryHole":
		task.set_amount_scale(Settings.task_amount(task.id))
	else:
		var amount_scale = Settings.task_amount(task.id)
		# Some tasks start at the wearer's existing amount. Scale only the new requirement.
		if amount_scale != 1.0:
			task.needAmount = task.currentAmount + max(1, ceil((task.needAmount - task.currentAmount) * amount_scale))

func add_task(task):
	var _ok = task.connect("onTaskCompleted", self, "onSlutTaskCompleted")
	tasks.append(task)

func fine_print_active():
	return id == "SlutLock" and Settings.has_starting_perk(getWearer(), Settings.FINE_PRINT)

func active_tasks():
	if fine_print_active():
		for task in tasks:
			if not task.isCompleted():
				return [task]
		return []
	return tasks

func handleSexEvent(event:SexEvent):
	processingTasks = true
	for task in active_tasks():
		task.onSexEvent(getWearer(), event)
	processingTasks = false
	resolve_completion()

func onSexEnded(context = {}):
	processingTasks = true
	for task in active_tasks():
		task.onSexEnded(getWearer(), context)
	processingTasks = false
	resolve_completion()

func checkIfTasksGotCompleted():
	processingTasks = true
	for task in active_tasks():
		task.checkIfCompletedFor(getWearer())
	processingTasks = false
	resolve_completion()

func onSlutTaskCompleted(_task):
	if not processingTasks:
		resolve_completion()

func resolve_completion():
	if not isEverythingCompleted():
		return
	if id == "SlutLock" and not tasks.empty() and not releaseChecked and Settings.has_starting_perk(getWearer(), Settings.FAULTY_RELEASE):
		releaseChecked = true
		if RNG.chance(50):
			generateTasks(roll_task_count())
			message("Faulty Release: the Slut Lock resets and assigns a new task list.")
			return
	announce_completion()

func announce_completion():
	.onSlutTaskCompleted(null)

# The game's own task-count odds: usually 1-2, with a 3% chance of 5 and 10% of 3.
# generateTasks replaces it when original task counts are turned off in settings.
static func roll_task_count():
	if RNG.chance(3):
		return 5
	if RNG.chance(10):
		return 3
	return RNG.randi_range(1, 2)

func message(text:String):
	if GM.main != null and getWearer() == GM.pc:
		GM.main.addMessage(text)

func getQuestProgressText():
	if fine_print_active():
		var disclosed = []
		for task in tasks:
			var text = task.getTaskStringSlutLock()
			if task.isCompleted():
				disclosed.append("[color=green]" + text + "[/color]")
				continue
			var wearer = getWearer()
			if wearer != null and not task.isPossibleForSlutlock(wearer):
				text += " (Impossible)"
			disclosed.append("[color=red]" + text + "[/color]")
			disclosed.append("Further conditions, if any, remain undisclosed.")
			break
		return PoolStringArray(disclosed).join("\n")
	var text = .getQuestProgressText()
	# A few original task descriptions omit their numeric progress.
	for task in tasks:
		if task.id != "HaveSexWithSpecies" and task.needAmount > 1 and task.getTaskStringSlutLock().find("/") < 0:
			text += "\n" + task.id + " progress: " + str(task.currentAmount) + "/" + str(task.needAmount)
	if tasks.empty():
		text = "No enabled tasks are possible. The lock can be removed."
	return text

func getSexGoalWeightModifier(goal_id:String) -> float:
	if not fine_print_active():
		return .getSexGoalWeightModifier(goal_id)
	var result = 1.0
	for task in active_tasks():
		result += task.getSexGoalWeightModifier(goal_id)
	return max(result, 0.0)
