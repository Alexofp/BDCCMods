extends SmartLockBase

# Shared ordinary-key handling for the lock types this mod adds from scratch
# (Timed, Multi-keyholder, Prostitution). Locks extending the game's own lock
# types (Tight, Slut, Keyholder, Taskmaster) keep the game's key handling instead.

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var keyAmount:int = 5
var keysAllowed:bool = false

# Rolls the key count (the game-style range unless overridden in settings) and bypass policy.
func setup_keys(vanilla_min:int, vanilla_max:int):
	keyAmount = Settings.key_count(id, RNG.randi_range(vanilla_min, vanilla_max))
	keysAllowed = Settings.keys_allowed(id)

func canBeUnlockedWithKeys() -> bool:
	return keysAllowed

func getKeysAmountToUnlock() -> int:
	return keyAmount

func with_keys_line(text:String) -> String:
	if keysAllowed:
		text += "\nAlternatively, use %d ordinary restraint keys." % keyAmount
	return text

func save_keys(data:Dictionary) -> Dictionary:
	data["keyAmount"] = keyAmount
	data["keysAllowed"] = keysAllowed
	return data

# Defaults apply to saves made before a field existed, so each lock type keeps its own.
func load_keys(data, default_amount:int, default_allowed:bool):
	keyAmount = int(max(1, SAVE.loadVar(data, "keyAmount", default_amount)))
	keysAllowed = bool(SAVE.loadVar(data, "keysAllowed", default_allowed))

func message(text:String):
	if GM.main != null and getWearer() == GM.pc:
		GM.main.addMessage(text)
