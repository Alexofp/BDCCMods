extends "res://Game/InteractionSystem/Interactions/AskingForKey.gd"

# The original narration announces total freedom. After a Multi-keyholder partial
# release that is not true, so say so only while other holders' locks remain.
const RELEASE_LINES = ["Freedom..", "Freedom, yay."]

func saynn(theText:String):
	if theText in RELEASE_LINES and has_pending_holders():
		theText = "Their key has been used. Other keyholders still hold locks on your restraints."
	.saynn(theText)

func has_pending_holders():
	var starter = getRoleChar("starter")
	if starter == null:
		return false
	for smartLock in starter.getInventory().getAllSmartLocks():
		if smartLock.has_method("releaseKeyholder") and not smartLock.canBeSimpleRemoved():
			return true
	return false
