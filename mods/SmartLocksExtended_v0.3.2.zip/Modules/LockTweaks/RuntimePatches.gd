extends Reference

# SmartLocks Extended ships no copies of game files. Instead, at pre-initialization
# (after every mod ZIP is mounted) it wraps a few game functions in memory:
#   1. the original function is renamed to _sle_original_<name>
#   2. a new function with the original name is appended, which calls the original
# This is applied to whichever version of each script is active - the game's own,
# or another mod's replacement - so other mods' changes are kept, and a game
# update never gets overwritten by stale copies. Each feature is applied only if
# every function it wraps is found exactly once; otherwise it is skipped and logged.

const MARKER = "# SmartLocksExtended runtime patch"
const PREFIX = "_sle_original_"
const STATUS_META = "SmartLocksExtendedPatches"
const SCRIPTS_META = "SmartLocksExtendedPatchedScripts"

const PATCHES = [
	{
		"feature": "factory",
		"path": "res://Inventory/SmartLocks/SmartLock.gd",
		"wrap": ["getAll", "getRandomSmartLock", "create"],
		"code": """
const SLE_SETTINGS = "res://Modules/LockTweaks/Settings.gd"

static func getAll():
	var result = _sle_original_getAll()
	for lock_id in load(SLE_SETTINGS).LOCKS:
		if not result.has(lock_id):
			result.append(lock_id)
	return result

static func getRandomSmartLock():
	return load(SLE_SETTINGS).choose_random()

static func create(_theID:String):
	if _theID in load(SLE_SETTINGS).LOCKS:
		return load("res://Modules/LockTweaks/Locks/" + _theID + ".gd").new()
	return _sle_original_create(_theID)
""",
	},
	{
		"feature": "random_selection",
		"path": "res://Inventory/ItemBase.gd",
		"wrap": ["addRandomSmartLock", "addSmartLock"],
		"code": """
func addRandomSmartLock(_forcer, _addMessage = true):
	if(_forcer is String):
		_forcer = GlobalRegistry.getCharacter(_forcer)
	var randomLock = load("res://Modules/LockTweaks/Settings.gd").choose_random(_forcer, getWearer())
	if(randomLock == ""):
		return false
	return addSmartLock(randomLock, _forcer, _addMessage)

func addSmartLock(_lockID, _forcer, _addMessage = true):
	if(!(_lockID in SmartLock.getAll())):
		return false
	return _sle_original_addSmartLock(_lockID, _forcer, _addMessage)
""",
	},
	{
		"feature": "keyholder_release",
		"path": "res://Game/BaseCharacter.gd",
		"wrap": ["unlockAllKeyholderLocksFrom"],
		"code": """
func unlockAllKeyholderLocksFrom(otherCharID:String) -> int:
	var howMany:int = 0
	for invSlot in getInventory().getEquippedItems().keys():
		var item = getInventory().getEquippedItem(invSlot)
		if(item == null || !item.isRestraint() || !item.getRestraintData().hasSmartLock()):
			continue
		var smartLock = item.getRestraintData().getSmartLock()
		if(!smartLock.has_method("releaseKeyholder") || !smartLock.isKeyholder(otherCharID)):
			continue
		smartLock.releaseKeyholder(otherCharID)
		if(smartLock.canBeSimpleRemoved()):
			getInventory().clearSlot(invSlot)
			howMany += 1
		elif(self == GM.pc && GM.main != null):
			GM.main.addMessage("One keyholder opened their lock. Other keyholders are still required.")
	# Released multi-keyholder locks no longer report this holder, so the original skips them.
	return howMany + _sle_original_unlockAllKeyholderLocksFrom(otherCharID)
""",
	},
	{
		"feature": "owner_retention",
		"path": "res://Game/BaseCharacter.gd",
		"wrap": ["canForgetCharacter"],
		"code": """
func canForgetCharacter() -> bool:
	if(GM.pc != null):
		if(GM.pc.hasKeyholderLocksFrom(getID())):
			return false
		for smartLock in GM.pc.getInventory().getAllSmartLocks():
			if(smartLock.has_method("isLockOwner") && smartLock.isLockOwner(getID())):
				return false
	return _sle_original_canForgetCharacter()
""",
	},
	{
		"feature": "taskmaster_goals",
		"path": "res://Game/BaseCharacter.gd",
		"wrap": ["getSexGoalSubWeightModifier"],
		"code": """
func getSexGoalSubWeightModifier(_sexGoalID:String, _domID:String) -> float:
	var result:float = _sle_original_getSexGoalSubWeightModifier(_sexGoalID, _domID)
	for smartLock in getInventory().getAllSmartLocks():
		if(smartLock.id == "TaskmasterLock"):
			result *= smartLock.getSexGoalWeightModifier(_sexGoalID)
	return result
""",
	},
]

static func status():
	if GlobalRegistry.has_meta(STATUS_META):
		return GlobalRegistry.get_meta(STATUS_META)
	return {}

static func is_active(feature):
	return bool(status().get(feature, false))

static func apply_all():
	var result = {}
	var scripts = []
	var paths = []
	for patch in PATCHES:
		if not paths.has(patch["path"]):
			paths.append(patch["path"])
	for path in paths:
		var applied = apply_to(path)
		for feature in applied:
			result[feature] = applied[feature]
		var script = load(path)
		if script != null:
			scripts.append(script)
	GlobalRegistry.set_meta(STATUS_META, result)
	# Keep patched scripts in the resource cache; otherwise a later load() could reread the file.
	GlobalRegistry.set_meta(SCRIPTS_META, scripts)
	return result

static func apply_to(path):
	var applied = {}
	var script = load(path)
	if script == null:
		return fail_all(path, applied, "script not found")
	var source = script.source_code
	if source.find(MARKER) >= 0:
		for patch in PATCHES:
			if patch["path"] == path:
				applied[patch["feature"]] = source.find(MARKER + ": " + patch["feature"]) >= 0
		return applied
	# Prefer the mounted file: the game caches some scripts before mods are mounted,
	# so the in-memory source may be the original even when another mod replaced it.
	var file = File.new()
	if file.open(path, File.READ) == OK:
		source = file.get_as_text()
		file.close()
	elif source == "":
		return fail_all(path, applied, "source not readable")
	var original = source
	var patched = source.replace("\r\n", "\n")
	for patch in PATCHES:
		if patch["path"] != path:
			continue
		var attempt = patched
		var ok = true
		for function_name in patch["wrap"]:
			var renamed = rename_function(attempt, function_name)
			if renamed == "":
				Log.printerr("[SmartLocks Extended] " + path + ": function '" + function_name + "' was not found exactly once; feature '" + patch["feature"] + "' disabled.")
				ok = false
				break
			attempt = renamed
		applied[patch["feature"]] = ok
		if ok:
			patched = attempt.trim_suffix("\n") + "\n\n" + MARKER + ": " + patch["feature"] + "\n" + patch["code"]
	if patched == original.replace("\r\n", "\n"):
		return applied
	script.source_code = patched
	if script.reload(true) != OK:
		Log.printerr("[SmartLocks Extended] " + path + ": patched script failed to compile; restoring the original.")
		script.source_code = original
		var _restored = script.reload(true)
		return fail_all(path, {}, "compile error")
	return applied

static func rename_function(source, function_name):
	var found = 0
	var result = source
	for prefix in ["\nfunc ", "\nstatic func "]:
		var needle = prefix + function_name + "("
		var position = source.find(needle)
		while position >= 0:
			found += 1
			position = source.find(needle, position + 1)
		result = result.replace(needle, prefix + PREFIX + function_name + "(")
	return result if found == 1 else ""

static func fail_all(path, applied, reason):
	Log.printerr("[SmartLocks Extended] Cannot patch " + path + " (" + reason + ").")
	for patch in PATCHES:
		if patch["path"] == path:
			applied[patch["feature"]] = false
	return applied
