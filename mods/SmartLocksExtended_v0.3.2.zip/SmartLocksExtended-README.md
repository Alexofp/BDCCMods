# SmartLocks Extended v0.3.2

A FoxLib mod for the supplied **BDCC 0.4.0**, built and tested with **Godot 3.6.3**.

Formerly **Lock Tweaks**. The development folder is now `Mods/SmartLocksExtended`, and the package is named `SmartLocksExtended`. Internal `LockTweaks` module IDs, resource paths, and settings keys are retained so existing settings, saves, and locks keep working. Replace the old Lock Tweaks ZIP; do not enable both names together. User-edited payment dialogue remains in `src/Modules/LockTweaks/Scenes/OwnerPaymentScene.gd`.

## Install

1. Start the supplied game and choose **Mods → Open mods folder**.
2. Copy these two ZIPs into that folder, without extracting them:
   - `Mods/Dependencies/FoxLib_v0.10.7.zip`
   - `Mods/SmartLocksExtended/dist/SmartLocksExtended_v0.3.2.zip`
3. Restart the game. Enable both mods in the launcher, with FoxLib before SmartLocks Extended, then launch with mods.
4. Open **Mods Options** on the title screen or in-game menu. SmartLocks Extended has exactly three sections: **Lock Types**, **Keys**, and **Tasks**.

When updating, replace the old SmartLocks Extended ZIP; do not enable multiple versions. Fully close and reopen the game. Existing lock-type/key settings and task toggles are retained. Task difficulty is shared; amount multipliers are grouped by task type. The general multiplier has been removed. When merging old controls, a group inherits the highest of its previous values. Newly added controls inherit their previous general-multiplier value. Once a group is configured, old values no longer affect it. Fresh installs default to 100% for each group.

Existing saved locks retain their progress, with two repairs: species tasks require one event, and inflated every-hole targets are converted to reachable counts per hole.

Version 0.1.2 fixes startup caching: Godot loads the original lock factory and related scripts before the mod launcher mounts the ZIP. A pre-initialization hook now refreshes those existing script resources, making the mod's behavior active for normal gameplay and the debug menu. Previous validation mounted the ZIP too early to catch this; tests now mount it after the game's autoloads and explicitly exercise **Force smart lock**.

The ZIPs can also be added through the game's **Import mod** button. Development files and the extracted FoxLib directory do not need to be installed.

Task toggles consistently use the internal task names, including **Enable PenetrateEveryHole**. The restraint progress description remains **Get fucked in every hole**.

## Included settings

- **Lock Types:** enable/disable each of seven types, selection weights, timed lock duration, multi-keyholder count, Taskmaster consecutive days, and Prostitution payment target/installments.
- **Keys:** ordinary-key bypass and key counts for each lock type. Each row names its lock type.
- **Tasks:** individual task toggles, task counts, repeated task types, shared difficulty range, and nine grouped amount controls covering every count-based task.

Enable switches and weights control **new random assignments**. Story scripts that explicitly request a lock type still get that type. This preserves the scripted scene's intended behavior. If all random types are disabled or have zero weight, random smart-lock application is skipped.

Lock-specific settings apply when a lock is created. Changing them does not rewrite existing deadlines, key counts, approvals, required streaks, or debts. Task settings apply when a new task list is generated, including future Taskmaster daily lists. FoxLib stores settings across game restarts; they are shared between saves in the same game profile.

Original task/key count behavior is kept by default for the three original lock types. The four added types are enabled with selection weight 1. Configurable ranges are sorted if entered backward and clamped to the limits shown in their tooltips. The interface may still display the value entered; the limits are applied when generating a lock.

## Optional starting perks

Select any combination of these in the game's normal **starting-perk picker** during character creation, or through the existing **Pick Perks!** option if that character has not used its one-time selection yet. They cost no skill points and follow the game's permanent, non-toggleable starting-perk rules. Existing characters do not receive them automatically.

- **Faulty Release:** each completed Slut Lock task list has a fixed 50% chance to reset and generate a new list instead of opening. Each completed list makes one decision; the resulting approved release or replacement list is saved, so inspecting again or reloading that saved result does not reroll it. Every replacement uses the current task settings. There is no reset limit. Ordinary restraint-key bypass still works if enabled.
- **Fine Print:** a Slut Lock reveals only its first unfinished task, with previously completed requirements kept in green above it. Only the current task can progress; completing it reveals the next, without revealing how many remain. Completed tasks and their displayed history survive saving/loading. Once all requirements are complete, the completed lines remain without an extra completion sentence. NPC task-related goal adjustments also use only the current task. Combined with Faulty Release, a failed release starts a new concealed sequence; its 50% roll occurs after the final requirement, rather than on intermediate revelations.
- **Uncertain Sentence:** Timed Locks conceal their countdown and release time while locked, showing “The timer appears to be broken.” Inspection still reports when a timer has completed. The real deadline and normal key-bypass rules remain unchanged.

Faulty Release and Fine Print apply to **Slut Locks only**, leaving Taskmaster daily lists and streak assessment unchanged. Uncertain Sentence applies to **Timed Locks only**. The three FoxLib settings sections remain Lock Types, Keys, and Tasks; perk selection lives in the game's starting-perk screen.

## Timed locks

Default duration is a random **6–24 in-game hours**. The deadline uses the game's day and time, so sleep and crossing midnight count. Real time spent paused or outside the game does not count. Once the timer expires, the restraint becomes removable through the usual restraint inspection/struggle screen. Ordinary restraint keys can bypass the timer by default; this can be disabled for newly created locks.

## Multi-keyholder locks

Each assigned NPC has a separate lock. **Every holder must use their own key**. A release stays completed while the other holders are sought, including after saving and loading. The final release removes the restraint using the existing keyholder interaction. The inspection description lists each holder and whether their lock is open.

Uses existing keyholder request/release interactions, including the game's existing ways of obtaining a holder's release. Ordinary restraint keys are disabled by default for this type. The optional bypass setting can enable them for new locks.

Holders are selected from persistent dynamic NPCs with an interaction-system pawn who are not excluded from encounters. An eligible NPC applying the restraint is included. The wearer, duplicate holders, and temporary NPCs are excluded. If there are fewer eligible holders than requested, all available holders are used; if none exist, random assignment skips this type. An explicit assignment with no holders is immediately removable.

Pending holders are protected from normal NPC forgetting while their locks are equipped on the player. Scripted deletion or removing a datapack can still make a holder unavailable; approvals are not automatically granted for missing holders. Resolve those locks before removing their NPC's content.

## Taskmaster Locks

Taskmaster Locks reuse the entire configured Slut Lock task pool, difficulty, amount multipliers, task count, and repeated-type setting. They assign an initial list immediately, then assess it at the next in-game morning reset. Finishing a list early does not release the restraint.

Each morning:

1. A fully completed previous list earns one consecutive successful day.
2. An incomplete list resets the streak to zero.
3. Reaching the configured streak opens the lock; otherwise a fresh daily list replaces the previous list.

The default base requirement is **two consecutive days**, configurable from 1-30 before scaling. On application, the configured difficulty range supplies a multiplier; the result is rounded to the nearest whole day with a minimum of one. At 200% difficulty, the default becomes four days. The chosen streak requirement is then saved and does not change during daily assessments or loading. Daily task requirements also continue to use the shared difficulty settings.

The initial application day can count if its list is completed before morning. A duplicate callback cannot advance the streak twice. A gap of multiple unassessed days resets the streak rather than awarding unearned days. If no enabled task is possible, that day's empty list counts as complete, but the morning/streak requirement still applies.

Streak, current task list, assessment day, and released state are saved with the restraint. Ordinary-key bypass is disabled by default and can be enabled for new locks in Keys.

## Prostitution Locks

An eligible persistent dynamic NPC owns the lock. The NPC applying the restraint is used when eligible; otherwise another eligible NPC is chosen. If no eligible owner exists, random assignment skips this type. Explicit assignment without an eligible owner produces a removable lock.

The default base debt is **50 credits**, configurable from 1-10000 before scaling. On application, the configured difficulty range supplies a multiplier; the result is rounded to the nearest whole credit with a minimum of one. At 200% difficulty, the default becomes 100 credits. The chosen debt is saved and does not rescale when settings change or a save is loaded.

Only payouts through the game's standard **Prostitution** interaction while wearing the lock qualify. Existing wallet funds, ordinary income, payments received from your own NPC workers, and paying an NPC as a client do not count. The standard interaction's refund events remove the matching qualifying earnings, including across saving and loading that interaction.

Return to the owner and choose **Pay lock owner** during the normal conversation. A payment panel lets you choose which restraint to pay toward. For owners whose special dialogue replaces the ordinary conversation, inspect your restraints while standing in the same room as the owner and choose **Pay [owner name]**. Both paths require the owner to be nearby at the time of payment.

Partial payments are enabled by default. Turn that option off to require the remaining debt in one payment. Each payment consumes both available qualifying earnings and actual credits from your wallet. Earning the target alone does not release the lock; final delivery to its owner removes that restraint. Asking for a key or defeating the owner does not bypass the debt. Ordinary-key bypass is disabled by default, with an optional setting for new locks.

When several Prostitution Locks are worn, new income is allocated across them in equipped-item order, capped by each remaining debt. A single earning is never credited to multiple locks. Debt, paid amounts, owner, and unspent qualifying earnings persist in the restraint's save data. Pending owners are protected from normal NPC forgetting; scripted deletion/datapack removal can still make an owner unavailable.

## Slut Lock tasks

Task filters affect Slut Lock and Taskmaster task generation, leaving the same task classes unchanged elsewhere in the game. If all enabled tasks are impossible, a Slut Lock has no tasks and is immediately removable; a Taskmaster Lock still needs its morning assessments. Repeated task types are **disabled by default**, so task count is limited by the number of eligible distinct types. Existing explicitly saved option values are retained; reset the relevant options to use the new defaults.

Difficulty is a multiplier: **100% = 1x**, **200% = 2x** the base requirement. Each task rolls between the configured bounds; the original range is 100-200%. Taskmaster streak length and Prostitution debt each also roll from that range once when a new lock is assigned. Consequently, the unchanged default difficulty range of 100-200% can produce streaks of 2-4 days and debts of 50-100 credits from the new base defaults. Each original task generator retains its own caps and exceptions. Its applicable amount multiplier is applied afterward; task amount controls do not additionally multiply the lock's streak/debt. The difficulty tooltips explain this in-game.

Amount controls are grouped as follows:

- **Fluids:** receiving fluids inside, receiving fluids on the body, and swallowing fluids.
- **Creampies / throatpies:** both event-count tasks.
- **Orgasms:** normal and chastity orgasm tasks.
- **Get fucked in every hole:** count per required hole.
- **Choking:** choking event count.
- **Pain:** total pain required.
- **Bodywritings:** newly required writings.
- **Spanking:** spanking event count.
- **Swallowing drugs:** required drug count.

Each task uses exactly one amount control after its difficulty calculation. There is no general multiplier. Existing starting progress is preserved when scaling new requirements. Additional count-based tasks registered by other mods receive their own amount control automatically; fixed-condition species and lactation tasks do not receive an amount control.

The species task always requires **one** qualifying event, regardless of difficulty or amount settings. Existing saved species tasks are normalized to one when loaded, with any already recorded success credited. The extra species progress footer is removed.

The every-hole task counts events separately for each required hole. Its amount multiplier sets the required count for each hole, rounded up with a minimum of one: 100% requires each once, 200% each twice. One hole cannot substitute for another. Its original generator ignores difficulty, so this task's count is controlled by its own amount setting. Progress is displayed in the task line and saved per hole. Old inflated targets are converted into counts per hole without discarding recorded once-per-hole flags; this repairs the previously unreachable target.

The lactation condition is unchanged because it is a single condition. Task toggles use the game's internal task IDs so they remain unambiguous, including tasks added by other mods before loading finishes.

## Compatibility and saves

This version **replaces no game files**. The ZIP contains only the mod's own `Modules/LockTweaks` folder.

Instead, at startup (after every mod is mounted), it wraps a few game functions in memory. Each original function is kept under a new name and still called, so other mods' changes to the same scripts are preserved:

| Game script | Wrapped functions | Purpose |
|---|---|---|
| `Inventory/SmartLocks/SmartLock.gd` | `getAll`, `getRandomSmartLock`, `create` | Adds the new lock types and the configurable random choice. Lock types added by other mods still load. |
| `Inventory/ItemBase.gd` | `addRandomSmartLock`, `addSmartLock` | Uses the settings when a random smart lock is applied; safely skips when every type is disabled. |
| `Game/BaseCharacter.gd` | `unlockAllKeyholderLocksFrom` | Lets each Multi-keyholder holder open only their own lock. Ordinary keyholder locks use the game's code. |
| `Game/BaseCharacter.gd` | `canForgetCharacter` | Hides the **Forget** option for pending holders and owners. |
| `Game/BaseCharacter.gd` | `getSexGoalSubWeightModifier` | Lets Taskmaster tasks guide NPC sex choices like Slut Lock tasks. |

This applies to whichever version of each script is active: the game's own or another mod's replacement. A game update is picked up directly, without stale copies. Each feature is applied only if its functions are found exactly once. Otherwise that feature is skipped and an error is logged. If the keyholder hook is unavailable, Multi-keyholder locks are not randomly assigned. The startup log line `[SmartLocks Extended] Runtime patches:` shows each feature's status.

The partial-release narration for keyholder requests comes from a registered subclass of the standard `AskingForKey` interaction. The text changes only while other holders' locks remain.

The mod also registers subclasses for the standard `Prostitution` and `AskingForKey` interactions. The Prostitution subclass observes its payment/refund events. Other mods registering a replacement for either interaction can conflict. Narrative encounters and third-party systems that grant credits directly without this interaction do not currently qualify.

**Known incompatible mods** (confirmed by the automated compatibility checks):

- **KeysMod** removes key counts from the game's Slut Lock and Keyholder lock. With it, Slut, Keyholder, and Taskmaster locks cannot be created, and random smart locks that pick those types fail.
- **KeyholdersGalore** rewrites the Slut Lock without a task list. With it, Slut and Taskmaster locks cannot be created, and random smart locks that pick those types fail.

**IntimidateProst** (replaces the Prostitution interaction) and **BrutalDreamsCorrectionalCenter** (replaces the restraint inspection screen) pass every compatibility check.

Existing original lock saves load with their existing key counts/tasks and the original ordinary-key policy. New lock IDs require this mod to restore them. Remove new locks before continuing a save without the mod. Back up a save before first testing any development mod.

## Build and verification

From the project folder:

```powershell
python Mods\SmartLocksExtended\build.py
python Mods\SmartLocksExtended\tests\run.py
python Mods\SmartLocksExtended\tests\run.py --quick
```

The build needs the sibling `BDCC` source folder. The mod release version and target game version are set once in `build.py` as `VERSION` and `GAME_VERSION`. The tests also need the supplied game PCK, Godot executable, and FoxLib ZIP. They mount the actual packages in an isolated test project/profile under `.test-runtime`, without using the player's saves or settings. Each run replaces its own test profile, keeping only the latest log and previews instead of accumulating profiles.

`run.py` runs three kinds of scenario, each a separate headless game with its own mod list:

1. **Old saves:** runs the released 0.3.1 mod (with its copied game files removed) to write a save for every lock type part-way through. It needs `SmartLocksExtended_v0.3.1.zip` in `dist/` or `BDCCMods/mods`; otherwise these checks are skipped.
2. **Main suite:** the full test suite, including loading those 0.3.1 saves, checking their progress, and completing each lock.
3. **Compatibility:** a baseline run, then one run per published mod that replaces scripts this mod builds on or wraps (KeysMod, KeyholdersGalore, IntimidateProst, BrutalDreamsCorrectionalCenter, taken from `BDCCMods/mods`). Each checks the runtime patches, creating/describing/saving every lock type, random assignment, Multi-keyholder and ordinary keyholder release, prostitution income and payment, and the inspection **Pay** button. These are reported as compatible or PROBLEMS and do not affect the exit code. `--quick` skips them.

The exit code reflects the old-save and main scenarios. A full run takes about a minute and a half.

The main suite also mounts a stand-in mod that replaces `Game/BaseCharacter.gd`, confirming both mods' changes stay active together. The automated checks cover loading the packaged mod after game autoloads, refreshing an already cached factory, the actual **Force smart lock** debug action, native FoxLib controls and settings persistence, random selection exclusions, timer boundaries/save data, distinct holder assignment, partial and final approvals through the actual inventory removal path, restraint serialization, original saves, and task filtering/scaling. They also cover the real FoxLib morning callback, Taskmaster daily reset/streak/release and save/load, the standard prostitution payment/refund methods, owner retention/proximity, payment event/scene actions, installment/full delivery, and nonduplicated income allocation across restraints. New perk checks exercise the actual starting-picker selection/confirmation, perk persistence, both Faulty Release outcomes and their saved decisions, Fine Print disclosure/progress gating, Taskmaster exclusions, and concealed timer deadlines. Settings screens are rendered for inspection. The harness currently emits resource cleanup warnings when the full game registry is torn down; there are no GDScript runtime errors in the passing run.

Manual acceptance for the new starting perks remains: select them during normal character creation, complete a Slut Lock list, save/quit/reopen after each outcome, and inspect a concealed timer before and after release. Only the published mods listed above have been checked automatically; other mod combinations have not been tested.

## Dependencies and credits

- BDCC by Alex K: <https://github.com/Alexofp/BDCC> (MIT; original notice included in the built ZIP).
- FoxLib 0.10.7 by Fox2Code, obtained from the official BDCC mod repository: <https://github.com/Alexofp/BDCCMods>. Its ZIP, license, bundled documentation, and extracted source are retained under `Mods/Dependencies`.

FoxLib is a separate dependency; its files are not bundled inside the SmartLocks Extended ZIP.
