# FoxLib Theming

FoxLib contain a very basic theme engine to allow you to make your own custom themes

It is a `.json` file that can be located at `res://FoxLib/Themes` and `user://foxlib/themes`.

The theme user path on Windows is: `%appdata%/Godot/app_userdata/BDCC/foxlib/themes`.

The theme user path on Linux is: `~/.local/share/godot/app_userdata/BDCC/foxlib/themes`.

Theme values have multiple types:
- String (Which are just text)
- Color (Which should be HTML color text like `#FFFFFF`, can have transparency like `#FFFFFF88`)
- Int (Which is just a whole number)

## Supported visible theme values

- `name` (String): The visible name of your theme in the selection menu. (Default: File name)
- `sidePanelsCornersSize` (Int): The corner size of the side panels (Default: 16)
- `adultAdvisoryCornersSize` (Int): The corner size of the adult advisory (Default: 32)
- `primaryBackground` (Color): Primary background color. (Default: #3f3e7d)
- `secondaryBackground` (Color): Secondary background color used by side panels. (Default: #35225d)
- `optionsHeaderBackground` (Color): Color used by option entries. (Default: #362f5f)
- `adultAdvisoryBackground` (Color): Background color used by adult advisory. (Default: #5d2254)
- `inventoryBackground` (Color): Background color used by the inventory screen. (Default: #1b0f42)
- `inventoryEntryActiveBackground` (Color): Background color used by selected inventory items. (Default: #0e004d)
- `inventoryEntryInactiveBackground` (Color): Background color used by unselected inventory items. (Default: #08002c)

## Supported invisible theme values

Theses are supported, but I'm not sure theses are visible by the user.

- `inventoryEntryBackground` (Color): Unsure if users can ever really see this (Default: #4a5d9f)

