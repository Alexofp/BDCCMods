extends Species

func _init():
	id = "redeyesblackdragon"
	
func getVisibleName():
	return "Red Eyes Black Dragon"

func getDefaultBody(_gender):
	return "redeyesbody"

func getDefaultLegs(_gender):
	return "redeyeslegs"

func getDefaultTail(_gender):
	return "redeyestail"

func isPlayable():
	return true

func getVisibleDescription():
	return "They roar and stuff"

func getDefaultArms(_gender):
	return "redeyesarms"

func getDefaultHorns(_gender):
	return "redeyeswings"

func getDefaultHead(_gender):
	return "redeyeshead"

func getDefaultEars(_gender):
	return null

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "redeyesmalebreasts"
	
	return "redeyesbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("More Dragon Penis" in GlobalRegistry.getModules()):
			return "DPB3"
		return "dragonpenis"
	else:
		return null

func npcGenerationWeight():
	return 1

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 3.0],
		[4, 1.0],
		[5, 0.4],
	]

func getSkinType():
	return SkinType.Scales

func onDynamicNpcCreation(_npc, _args):
	_npc.pickedSkinRColor = "#201F24"
#	_npc.pickedSkinGColor = Color.pink
#	_npc.pickedSkinBColor = Color.pink
