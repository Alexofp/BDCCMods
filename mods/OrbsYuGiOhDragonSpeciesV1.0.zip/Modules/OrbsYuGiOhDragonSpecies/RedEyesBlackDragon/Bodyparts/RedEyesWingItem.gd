extends ItemBase

func _init():
	id = "diredragonwings"

func getVisibleName():
	return "Dire Dragon Wings"
	
func getDescription():
	return "Cosmetic wings to match the dire dragon."

func getClothingSlot():
	return InventorySlot.Unique

func getPrice():
	return 10

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"wing": "res://Modules/LightnighDragonSpecies/Bodyparts/DiredragonWings/DiredragonWings.tscn",
	}

func canDye():
	return true

func getRequiredBodypart():
	return BodypartSlot.Body
