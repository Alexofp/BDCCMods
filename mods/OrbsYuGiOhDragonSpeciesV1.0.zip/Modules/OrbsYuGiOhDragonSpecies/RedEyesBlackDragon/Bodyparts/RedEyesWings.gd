extends BodypartHorns

func _init():
	visibleName = "red eyes wings"
	id = "redeyeswings"

func getCompatibleSpecies():
	return ["redeyesblackdragon"]

func getDoll3DScene():
	return "res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/Wings/RedEyesWings.tscn"
