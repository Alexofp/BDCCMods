extends BodypartBody

func _init():
	visibleName = "red eyes body"
	id = "redeyesbody"

func getCompatibleSpecies():
	return ["redeyesblackdragon"]

func getDoll3DScene():
	return "res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/Body/RedEyesBody.tscn"

func getVulgarName() -> String:
	return "scaled body"

func getAVulgarName() -> String:
	return "a scaled body"
