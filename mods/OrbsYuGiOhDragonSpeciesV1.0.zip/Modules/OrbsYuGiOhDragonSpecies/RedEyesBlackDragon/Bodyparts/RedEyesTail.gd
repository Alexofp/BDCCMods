extends BodypartTail

func _init():
	visibleName = "red eyes tail"
	id = "redeyestail"

func getCompatibleSpecies():
	return ["redeyesblackdragon"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/Tail/RedEyesTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
