extends BodypartHead

func _init():
	visibleName = "red eyes head"
	id = "redeyeshead"

func getCompatibleSpecies():
	return ["redeyesblackdragon"]

func getDoll3DScene():
	return "res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/Head/RedEyesHead.tscn"

func getHeadLength():
	return 0.7
