extends BodypartLeg

func _init():
	visibleName = "red eyes legs"
	id = "redeyeslegs"

func getCompatibleSpecies():
	return ["redeyesblackdragon"]

func getDoll3DScene():
	return "res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/Legs/RedEyesDigiLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
