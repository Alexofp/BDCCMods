extends BodypartArms

func _init():
	visibleName = "red eyes arms"
	id = "redeyesarms"

func getCompatibleSpecies():
	return ["redeyesblackdragon"]

func getDoll3DScene():
	return "res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/Arms/RedEyesArms.tscn"
