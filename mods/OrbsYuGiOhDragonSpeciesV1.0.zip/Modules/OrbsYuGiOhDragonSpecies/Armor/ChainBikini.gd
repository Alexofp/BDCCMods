extends ItemBase

func _init():
	id = "ChainBikini"

func getVisibleName():
	return "Chain Bikini"
	
func getDescription():
	return "A spiked chain bikini"

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your chain top and pulls down the panties"
	else:
		return "take off your chain top and pulls down the panties"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your chain top the panties"
	else:
		return "put on your chain top the panties"

func generateItemState():
	itemState = ShirtAndShortsState.new()

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"clothing": "res://Modules/OrbsYuGiOhDragonSpecies/Armor/ChainBikini/ChainBikini.tscn",
	}

func getInventoryImage():
	return "res://Modules/OrbsYuGiOhDragonSpecies/Armor/ChainBikini/ChainBikiniIcon.png"

func canDye():
	return false
