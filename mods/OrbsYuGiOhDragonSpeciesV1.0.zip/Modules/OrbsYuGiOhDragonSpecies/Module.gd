extends Module

func _init():
	id = "OrbsYuGiOhDragonSpecies"
	author = "Art by The Orb, Coding by Avery Winters"

	bodyparts = [
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesArms.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesBody.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesBreasts.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesHead.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesLegs.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesMaleBreasts.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesTail.gd",
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/Bodyparts/RedEyesWings.gd"
	]

	species = [
		"res://Modules/OrbsYuGiOhDragonSpecies/RedEyesBlackDragon/RedEyesBlackDragon.gd",
	]

	items = [
		"res://Modules/OrbsYuGiOhDragonSpecies/Armor/ChainBikini.gd",
		]
