extends Spatial
# PuppyRestraintsMod override of Stage3D.gd
#
# NOTE: class_name Stage3D is intentionally OMITTED here.
# In Godot 3.x resource pack overrides, if both the original script and this override
# declare the same class_name, Godot silently refuses to load this file.
# Removing class_name means the redirection logic below actually runs.
# Other code that needs Stage3D by class reference uses GM.ui.getStage3d() which
# returns the node directly — no class_name needed.

var currentScene: BaseStageScene3D
onready var animPlayer = $AnimationPlayer

func _ready():
	resetToNothing()

func _isPuppyWorn() -> bool:
	if GM.pc == null:
		return false
	var inv = GM.pc.getInventory()
	if inv == null:
		return false
	return inv.hasItemIDEquipped("puppy_restraints")

# Scene IDs where the PC pose is already correct (sex, devices, existing puppy scenes).
# Anything NOT in this list gets redirected to PuppySolo/PuppyDuo.
const PUPPY_PASS_THROUGH = [
	# Puppy scenes — already correct
	"PuppySolo", "PuppyDuo", "PuppySexAllFours", "PuppySexStart",
	"PuppySexCowgirl", "PuppySexOral", "PuppyPinned", "PuppyFeetCrotch",
	# Sex scenes — pose handled by the sex engine
	"SexStart", "SexStanding", "SexCowgirl", "SexCowgirlAlt",
	"SexCowgirlChoke", "SexCowgirlAmazon", "SexAllFours", "SexOral",
	"SexMissionary", "SexFaceSitting", "SexFreeStanding", "SexFeetPlay",
	"SexFullNelson", "SexLotus", "SexDoubleDown", "SexDP",
	"SexGangbang", "SexTrain", "SexStealth", "SexReverseCowgirl",
	"SexPortalMasturbation", "SexPortalOral", "SexPortalRide",
	"SexOverTable", "SexRimming", "SexTribadism", "SexHandjob", "Sex69",
	"SexBendOver", "SexLowDoggy", "SexAggressivePindown",
	# Restraint / device scenes
	"Stocks", "StocksSex", "StocksSexOral", "StocksSpitroast",
	"Slutwall", "SlutwallSex", "SlutwallSexOral", "SlutwallRide",
	"HangingSolo", "HangingDuo", "HangingSex", "HangingSexFuckmachine",
	"RopesSolo", "RopesOralSex",
	"WoodenHorseSolo", "WoodenHorseDuo",
	"BDSMMachineFuck", "BDSMMachineAltFuck",
	"MilkingStallSolo", "MilkingStallDuo",
	"MilkingProstate", "MilkingProstateFuck",
	"Sybian", "SybianOral",
	"Urinal", "UrinalPeeing", "UrinalSex",
	"FleshlightSit", "Hogtied",
	"ChairOral", "ChairCrotchSniff",
	"CanineDildoSex", "HorsecockDildoSex",
	"TentaclesSex", "TentaclesTease",
	"PawJobMutual", "PawJobUnderTable",
	"ButtStack", "ButtStackSex",
	"GeneratorOral", "BreastFeeding",
	"ArmsRaisedDuo", "ArmsRaisedSex", "DuoHypnoTied",
	"GivingBirth", "Cryopod", "Zonked", "Rekt",
	"Spanking", "Choking",
]

func play(sceneID, actionID, args = {}, skipFade = false, forceReset = false):
	# ── PuppyRestraintsMod redirect ──────────────────────────────────────────
	if _isPuppyWorn():
		var _sid = str(sceneID)
		if not (_sid in PUPPY_PASS_THROUGH):
			var player_id = "pc"  # Player.getID() always returns "pc"

			if _sid == "Solo" or not (args is Dictionary) or args.empty():
				# Solo or no-arg scene: show player alone in PuppySolo
				sceneID  = "PuppySolo"
				actionID = "walk" if actionID in ["walk", "jog"] else "paw"
				args     = {}
			else:
				# Two-character scene (Duo, Hug, Cuddling, Grope, etc.)
				# Redirect to PuppyDuo:
				#   doll  slot ("pc"  arg) = NPC  → upright Solo anim tree
				#   doll2 slot ("npc" arg) = PC   → Puppy anim tree (paw)
				var pc_arg  = str(args.get("pc",  ""))
				var npc_arg = str(args.get("npc", ""))

				var npc_id = ""
				if pc_arg == player_id or pc_arg == "":
					npc_id = npc_arg if npc_arg != "" else ""
				elif npc_arg == player_id or npc_arg == "":
					npc_id = pc_arg
				# else: NPC-NPC scene, npc_id stays ""

				if npc_id != "" and npc_id != player_id:
					sceneID  = "PuppyDuo"
					actionID = "stand"
					args     = {"pc": npc_id, "npc": player_id, "npcAction": "paw"}
				else:
					sceneID  = "PuppySolo"
					actionID = "paw"
					args     = {}
	# ── end PuppyRestraintsMod ───────────────────────────────────────────────

	if(currentScene != null && currentScene.id == sceneID && !forceReset && currentScene.canTransitionTo(actionID, args)):
		currentScene.playAnimationFinal(actionID, args)
		return
	
	if(currentScene != null):
		if(!skipFade):
			animPlayer.play("Fade")
			yield(animPlayer, "animation_finished")
			animPlayer.play_backwards("Fade")
		currentScene.queue_free()
		currentScene = null
	
	var newScene:BaseStageScene3D = GlobalRegistry.createStageScene(sceneID)
	if(newScene == null):
		Log.printerr("STAGE: Scene "+str(sceneID)+" wasn't found")
		return
	currentScene = newScene
	add_child(newScene)
	newScene.playAnimationFinal(actionID, args)

func updateSubAnims():
	if(currentScene != null):
		currentScene.updateSubAnims()

func resetToNothing():
	play(StageScene.Nothing, "", [], true)
