extends Spatial
class_name Stage3D

var currentScene: BaseStageScene3D
onready var animPlayer = $AnimationPlayer

func _ready():
	resetToNothing() # Player is created late
	#call_deferred("play", StageScene.Duo, "kneel", {npc="nova"}) # Player is created late
	#play(StageScene.Solo, "stand")

func _isPuppyWorn() -> bool:
	if GM.pc == null:
		return false
	var inv = GM.pc.getInventory()
	if inv == null:
		return false
	return inv.hasItemIDEquipped("puppy_restraints")

# Plain string literals — StageScene.Solo == "Solo" etc.
# Using class_name constants in a class-level const fails to parse in Godot 3.x
# resource pack overrides, so we use raw strings.
#
# Scenes where the PC pose is already handled by the scene itself.
# Everything NOT here gets redirected to PuppySolo.
const PUPPY_PASS_THROUGH = [
	# Puppy scenes — already correct
	"PuppySolo", "PuppyDuo", "PuppySexAllFours", "PuppySexStart",
	"PuppySexCowgirl", "PuppySexOral", "PuppyPinned", "PuppyFeetCrotch",
	# Sex scenes
	"SexStart", "SexStanding", "SexCowgirl", "SexCowgirlAlt",
	"SexCowgirlChoke", "SexCowgirlAmazon", "SexAllFours", "SexOral",
	"SexMissionary", "SexFaceSitting", "SexFreeStanding", "SexFeetPlay",
	"SexFullNelson", "SexLotus", "SexDoubleDown", "SexDP",
	"SexGangbang", "SexTrain", "SexStealth", "SexReverseCowgirl",
	"SexPortalMasturbation", "SexPortalOral", "SexPortalRide",
	"SexOverTable", "SexRimming", "SexTribadism", "SexHandjob", "Sex69",
	"SexBendOver", "SexLowDoggy", "SexAggressivePindown",
	# Restraint/device scenes
	"Stocks", "StocksSex", "StocksSexOral", "StocksSpitroast",
	"Slutwall", "SlutwallSex", "SlutwallSexOral", "SlutwallRide",
	"HangingSolo", "HangingDuo", "HangingSex", "HangingSexFuckmachine",
	"RopesSolo", "RopesOralSex",
	"WoodenHorseSolo", "WoodenHorseDuo",
	"BDSMMachineFuck", "BDSMMachineAltFuck",
	"MilkingStallSolo", "MilkingStallDuo",
	"MilkingProstate", "MilkingProstateFuck",
	"Sybian", "SybianOral",
	"Urinal", "UrinalPeeing", "UrinalSex",
	"FleshlightSit", "Hogtied",
	"ChairOral", "ChairCrotchSniff",
	"CanineDildoSex", "HorsecockDildoSex",
	"TentaclesSex", "TentaclesTease",
	"PawJobMutual", "PawJobUnderTable",
	"ButtStack", "ButtStackSex",
	"GeneratorOral", "BreastFeeding",
	"ArmsRaisedDuo", "ArmsRaisedSex", "DuoHypnoTied",
	"GivingBirth", "Cryopod", "Zonked", "Rekt",
	"Spanking", "Choking",
]

func play(sceneID, actionID, args = {}, skipFade = false, forceReset = false):
	if _isPuppyWorn():
		var _sid = str(sceneID)
		if not (_sid in PUPPY_PASS_THROUGH):
			var player_id = "pc"  # Player.getID() always returns "pc"

			if _sid == "Solo" or not (args is Dictionary) or args.empty():
				# Solo or no-arg: just show player in PuppySolo
				sceneID  = "PuppySolo"
				actionID = "walk" if actionID in ["walk", "jog"] else "paw"
				args     = {}

			else:
				# Any two-character scene (Duo, Hug, Cuddling, Grope, etc.)
				# Redirect to PuppyDuo so player uses PuppyAnimTree (doll2/npc slot)
				# and NPC uses SoloAnimTree (doll/pc slot) standing upright.
				var pc_arg  = str(args.get("pc",  ""))
				var npc_arg = str(args.get("npc", ""))

				var npc_id = ""
				if pc_arg == player_id or pc_arg == "":
					# Player in pc slot (or missing) — NPC is in npc slot
					npc_id = npc_arg if npc_arg != "" else ""
				elif npc_arg == player_id or npc_arg == "":
					# Player in npc slot — NPC is in pc slot
					npc_id = pc_arg
				# else: NPC-NPC scene, npc_id stays ""

				if npc_id != "" and npc_id != player_id:
					# PuppyDuo: doll = NPC (Solo, standing), doll2 = PC (Puppy, paw)
					sceneID  = "PuppyDuo"
					actionID = "stand"
					args     = {"pc": npc_id, "npc": player_id, "npcAction": "paw"}
				else:
					# No identifiable NPC, just show player in PuppySolo
					sceneID  = "PuppySolo"
					actionID = "paw"
					args     = {}


	if(currentScene != null && currentScene.id == sceneID && !forceReset && currentScene.canTransitionTo(actionID, args)):
		currentScene.playAnimationFinal(actionID, args)
		return
	
	if(currentScene != null):
		if(!skipFade):
			animPlayer.play("Fade")
			yield(animPlayer, "animation_finished")
			animPlayer.play_backwards("Fade")
		currentScene.queue_free()
		currentScene = null
	
	var newScene:BaseStageScene3D = GlobalRegistry.createStageScene(sceneID)
	if(newScene == null):
		Log.printerr("STAGE: Scene "+str(sceneID)+" wasn't found")
		return
	currentScene = newScene
	add_child(newScene)
	newScene.playAnimationFinal(actionID, args)

func updateSubAnims():
	if(currentScene != null):
		currentScene.updateSubAnims()

func resetToNothing():
	play(StageScene.Nothing, "", [], true)
