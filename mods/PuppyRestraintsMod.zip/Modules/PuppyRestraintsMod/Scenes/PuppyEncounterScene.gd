extends SceneBase
# PuppyEncounterScene
#
# NPC encounter triggered by PuppyEncounterEvent.
# Tone escalates with conditioning stage.
# Perfect Pet perk softens NPC tone at all stages.
# ConditionedReflex perk halves refusal lust cost.
# GoodPup perk: sets PuppyRestraintsMod.GoodPupActive flag on pleased endings.
#
# Awards PuppyConditioning skill XP on completion:
#   Refused:  2 XP
#   Pleased:  5 XP
#   Sex:      10 XP

var npc2ID: String = ""
var npc2
var _chosen: String = ""

func _init():
	sceneID = "PuppyEncounterScene"

func _initScene(_args = []):
	npc2ID = _args[0]

func _reactInit():
	npc2 = getCharacter(npc2ID)
	addCharacter(npc2ID)

func resolveCustomCharacterName(_charID):
	if _charID == "npc2":
		return npc2ID

# ── helpers ──────────────────────────────────────────────────────────────────

func _conditioning() -> float:
	if GM.pc == null:
		return 0.0
	var e = GM.pc.getEffect("puppy_conditioning")
	return e.conditioningLevel if e != null else 0.0

func _stage() -> int:
	var l = _conditioning()
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _perfectPet() -> bool:
	return GM.pc != null and GM.pc.hasPerk("PuppyPerk_PerfectPet")

func _addChoiceButtons(yesLabel: String, yesDesc: String, yesAction: String,
                       noAction: String):
	var s = _stage()
	addButton(yesLabel, yesDesc, yesAction)
	if s >= 4:
		addDisabledButton("Refuse", "The thought barely forms before dissolving.")
	elif s >= 3:
		addButton("Try to refuse...", "Every instinct fights you. (+40 lust)", noAction)
	elif s >= 2:
		addButton("Refuse", "You manage to hold back. (+20 lust)", noAction)
	else:
		addButton("Refuse", "No thanks.", noAction)

func _applyRefusalCost():
	var s = _stage()
	var half = GM.pc != null and GM.pc.hasPerk("PuppyPerk_ConditionedReflex")
	if s >= 3:
		var cost = 20 if half else 40
		GM.pc.addLust(cost)
		GM.main.addMessage("[color=orange]Fighting the urge costs you dearly.[/color]")
	elif s >= 2:
		var cost = 10 if half else 20
		GM.pc.addLust(cost)
		GM.main.addMessage("[color=yellow]Refusing takes real effort.[/color]")

func _approachLine(chosen: String) -> String:
	var s   = _stage()
	var pet = _perfectPet()
	match chosen:
		"paw":
			if pet:
				return RNG.pick(["Hey, good pup. Paw for me?", "Come on, let's see a trick. Paw?", "Paw please. I know you know how."])
			match s:
				1: return RNG.pick(["Hey pup, give me a paw?", "Oh cute. Paw?", "Let's see some tricks -- paw?"])
				2: return RNG.pick(["Give me a paw.", "Paw. Now.", "Come on. Paw."])
				3: return RNG.pick(["Give me your paw.", "Paw. Don't make me ask twice.", "You heard me. Paw."])
				_: return ""
		"pat":
			if pet:
				return RNG.pick(["Can I pet you? You look like a good pup.", "Come here, let me.", "Stay still for a second."])
			match s:
				1: return RNG.pick(["Mind if I pet you?", "Aww. Can I?", "Oh wow. Stay still a second?"])
				2: return RNG.pick(["Hold still.", "Come here. Let me.", "Stay."])
				3: return RNG.pick(["Get over here.", "Stay still. I'm not asking.", "I didn't ask. Come here."])
				_: return ""
		"lick":
			if pet:
				return RNG.pick(["You know what to do. Come here.", "Show me how trained you are.", "Come on. I know you want to."])
			match s:
				1: return RNG.pick(["Hey... you know what to do with that mouth, right?", "Think you could...?", "You look well-trained. Want to prove it?"])
				2: return RNG.pick(["Get to work.", "You know what I want. Come here.", "On your knees. Well -- more than usual."])
				3: return RNG.pick(["On me. Now.", "Don't waste my time. Get to work.", "You don't get a choice about this one."])
				_: return ""
		"feet":
			if pet:
				return RNG.pick(["Roll over for me. I want to see something.", "Lie back. I've been curious.", "Can I try something? Lie back."])
			match s:
				1: return RNG.pick(["Roll over? I want to try something.", "Can I...? Just curious.", "Lie back for a sec."])
				2: return RNG.pick(["Roll over.", "On your back.", "Lie back. I want to see something."])
				3: return RNG.pick(["On your back. Now.", "I'm going to put my foot on you. Stay still.", "You don't need to like it."])
				_: return ""
		"sex":
			if pet:
				return RNG.pick(["Come with me. You know what I want.", "I've had my eye on you. Come on.", "You're a good pup. Let me show you."])
			match s:
				3: return RNG.pick(["You're coming with me.", "I've been watching you crawl around. You know what happens next.", "On your back. We both know you can't say no."])
				_: return ""
	return ""

func _stage4Narration(chosen: String) -> String:
	if _perfectPet():
		match chosen:
			"paw":  return "{npc2.name} walks over and holds out a hand, calm and expectant."
			"pat":  return "{npc2.name} reaches down and takes your head in both hands like you belong there."
			"lick": return "{npc2.name} steps in front of you and unzips, glancing down with quiet ownership."
			"feet": return "{npc2.name} plants a foot against your crotch with practiced ease."
			"sex":  return "{npc2.name} crouches down, takes your collar, and leads you away without a word."
	match chosen:
		"paw":  return "{npc2.name} walks over without a word and holds out a hand, waiting."
		"pat":  return "{npc2.name} reaches down and grabs your head without asking, fingers working through your hair like you're property."
		"lick": return "{npc2.name} steps in front of you and unzips, not even looking down. The expectation is total."
		"feet": return "{npc2.name} plants a foot squarely against your crotch without a word, pressing steadily."
		"sex":  return "{npc2.name} crouches down, grabs your collar, and pulls you along without a word. You both know where this is going."
	return ""

# ── main run ─────────────────────────────────────────────────────────────────

func _run():

	if state == "":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		var s = _stage()

		if _chosen == "":
			var pool = []
			if s >= 4:
				pool = ["pat", "lick", "feet", "feet", "sex", "sex"]
			elif s >= 3:
				pool = ["pat", "lick", "lick", "feet", "feet", "sex"]
			elif s >= 2:
				pool = ["paw", "pat", "lick", "feet"]
			else:
				pool = ["paw", "paw", "pat"]
			_chosen = RNG.pick(pool)

		var chosen = _chosen

		if s >= 4:
			saynn("{npc2.name} clocks you from across the room and walks over.")
			saynn(_stage4Narration(chosen))
		else:
			var notice = ""
			if _perfectPet():
				notice = RNG.pick([
					"{npc2.name} spots you and smiles.",
					"{npc2.name} notices you and changes direction.",
					"{npc2.name} clocks you and walks over.",
				])
			elif s >= 3:
				notice = RNG.pick([
					"{npc2.name} spots you and their eyes go flat.",
					"{npc2.name} looks you over with undisguised contempt.",
					"{npc2.name} stares at you like something they found on the floor.",
				])
			elif s >= 2:
				notice = RNG.pick([
					"{npc2.name} spots you and slows down.",
					"{npc2.name} eyes you up and changes direction.",
					"{npc2.name} glances at your restraints and decides to stop.",
				])
			else:
				notice = RNG.pick([
					"{npc2.name} spots you crawling along and stops.",
					"{npc2.name} does a double take and comes over.",
					"{npc2.name} notices you and grins.",
				])
			saynn(notice)
			var line = _approachLine(chosen)
			if line != "":
				saynn("[say=npc2]" + line + "[/say]")

		if s >= 4:
			match chosen:
				"paw":  addButton("Give paw",   "", "do_paw")
				"pat":  addButton("Stay still", "", "do_pat")
				"lick": addButton("Obey",       "", "do_lick")
				"feet": addButton("Stay still", "", "do_feet")
				"sex":  addButton("...",        "You already know.", "do_sex")
		else:
			match chosen:
				"paw":  _addChoiceButtons("Give paw",         "Lift your paw.",       "do_paw",  "refuse_paw")
				"pat":  _addChoiceButtons("Let them pet you", "Stay still.",          "do_pat",  "refuse_pat")
				"lick": _addChoiceButtons("Obey",             "Get to work.",         "do_lick", "refuse_lick")
				"feet": _addChoiceButtons("Roll over",        "Expose yourself.",     "do_feet", "refuse_feet")
				"sex":  _addChoiceButtons("Comply",           "You can't say no.",    "do_sex",  "refuse_sex")

	# ── Paw ──────────────────────────────────────────────────────────────
	if state == "do_paw":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc", npcAction="paw"})
		var s = _stage()
		if s >= 4:
			saynn("You raise your paw without thinking. Your body just does it.")
			saynn("{npc2.name} glances down, gives a single nod, and walks away.")
		elif s >= 3:
			if _perfectPet():
				saynn("You lift your paw. They take it gently.")
				saynn("[say=npc2]" + RNG.pick(["Good pup.", "There it is.", "Perfect."]) + "[/say]")
			else:
				saynn("You lift your paw. You hate how quickly you do it.")
				saynn("[say=npc2]" + RNG.pick(["There it is.", "Obviously.", "Didn't take long."]) + "[/say]")
		else:
			saynn("You lift your front paw and press it against their hand.")
			saynn("[say=npc2]" + RNG.pick(["Good pup.", "Hah! Look at that.", "Good boy."]) + "[/say]")
		GM.pc.addLust(5)
		addButton("Continue", "", "end_pleased")

	if state == "refuse_paw":
		_applyRefusalCost()
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("You keep your paws on the floor, refusing.")
		saynn("[say=npc2]" + RNG.pick(["Stubborn. Fine.", "Not in the mood? Whatever.", "We'll try again later."]) + "[/say]")
		addButton("Continue", "", "end_refused")

	# ── Pat ──────────────────────────────────────────────────────────────
	if state == "do_pat":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc", npcAction="sit"})
		var s = _stage()
		if s >= 4:
			if _perfectPet():
				saynn("{npc2.name} strokes your head with both hands, slow and deliberate.")
				saynn("You lean into it. You can't help it.")
			else:
				saynn("{npc2.name} grips your head and scratches roughly behind your ear -- possessive, not gentle.")
				saynn("You press into it anyway. That's the worst part.")
		elif s >= 3:
			if _perfectPet():
				saynn("{npc2.name} pats your head firmly. Approving.")
				saynn("[say=npc2]" + RNG.pick(["Good pup.", "That's the one.", "Nice."]) + "[/say]")
			else:
				saynn("{npc2.name} grabs your head and gives it a rough pat like they're checking if you're real.")
				saynn("[say=npc2]" + RNG.pick(["Hm.", "Yeah, thought so.", "Good enough."]) + "[/say]")
		else:
			saynn("{npc2.name} reaches down and strokes your head slowly.")
			saynn("[say=npc2]" + RNG.pick(["There we go. Good puppy.", "Nice.", "You like that, don't you."]) + "[/say]")
		GM.pc.addLust(10)
		addButton("Continue", "", "end_pleased")

	if state == "refuse_pat":
		_applyRefusalCost()
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("You shuffle backward out of reach.")
		saynn("[say=npc2]" + RNG.pick(["Skittish thing.", "Suit yourself.", "Next time."]) + "[/say]")
		addButton("Continue", "", "end_refused")

	# ── Lick ─────────────────────────────────────────────────────────────
	if state == "do_lick":
		playAnimation(StageScene.PuppySexOral, "grind", {pc=npc2ID, npc="pc", npcBodyState={naked=true}})
		var s = _stage()
		if s >= 4:
			saynn("You crawl forward and get to work. There's no hesitation left in you.")
			if _perfectPet():
				saynn("{npc2.name} rests a hand on your head and sighs quietly.")
			else:
				saynn("{npc2.name} doesn't look down. Just rests a hand on your head like you're furniture.")
		elif s >= 3:
			saynn("You move forward. You don't even pause to think about it.")
			saynn("[say=npc2]" + RNG.pick(["There you go.", "Finally.", "Knew you would."]) + "[/say]")
		else:
			saynn("You crawl forward and nuzzle against their crotch, your tongue working.")
			saynn("[say=npc2]" + RNG.pick(["Mmh. Good pup.", "Yeah, just like that.", "Keep going."]) + "[/say]")
		GM.pc.addLust(25)
		addButton("Continue", "", "end_pleased")

	if state == "refuse_lick":
		_applyRefusalCost()
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("You pull back and look away.")
		saynn("[say=npc2]" + RNG.pick(["Not ready yet. Fine.", "You'll learn.", "Soon."]) + "[/say]")
		addButton("Continue", "", "end_refused")

	# ── Feet play ────────────────────────────────────────────────────────
	if state == "do_feet":
		playAnimation(StageScene.PuppyFeetCrotch, "crotch", {pc=npc2ID, npc="pc", npcBodyState={naked=true}})
		var s = _stage()
		if s >= 4:
			saynn("{npc2.name} presses their foot against you with casual, total ownership.")
			if GM.pc.isWearingChastityCage():
				saynn("The cage bites tight. You can't even squirm right.")
			elif GM.pc.hasReachablePenis():
				saynn("Your cock betrays you immediately, straining up against the sole.")
			elif GM.pc.hasReachableVagina():
				saynn("Your body answers before your mind can protest.")
			if _perfectPet():
				saynn("{npc2.name} watches you with warm, satisfied eyes.")
			else:
				saynn("{npc2.name} watches your reaction with flat, satisfied eyes.")
		elif s >= 3:
			saynn("{npc2.name} shoves a foot against your crotch without ceremony.")
			saynn("[say=npc2]" + RNG.pick(["Look at that.", "Pathetic.", "Knew it."]) + "[/say]")
		else:
			saynn("{npc2.name} plants a foot gently but firmly against your crotch.")
			saynn("[say=npc2]" + RNG.pick(["Good puppy.", "So responsive.", "I like that."]) + "[/say]")
		GM.pc.addLust(35)
		addButton("Continue", "", "end_pleased")

	if state == "refuse_feet":
		_applyRefusalCost()
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("You roll upright and shuffle away.")
		saynn("[say=npc2]" + RNG.pick(["We'll get there.", "Not ready. Fine.", "You'll let me next time."]) + "[/say]")
		addButton("Continue", "", "end_refused")

	# ── Sex narration (launch is in _react) ──────────────────────────────
	if state == "do_sex":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		var s = _stage()
		if s >= 4:
			if _perfectPet():
				saynn("{npc2.name} takes your collar and leads you somewhere quieter.")
				saynn("They don't need to explain. You already understand.")
			else:
				saynn("{npc2.name} drags you somewhere quiet. No words. No preamble.")
				saynn("You already know what's coming. So do they.")
		else:
			saynn("{npc2.name} grabs your collar and pulls you off the main path.")
			saynn("[say=npc2]" + RNG.pick([
				"You've been walking around like that all day. You had to know this was coming.",
				"Come on. We both know you don't have a choice.",
				"Don't make noise.",
			]) + "[/say]")
		addButton("Continue", "", "start_sex")

	if state == "refuse_sex":
		_applyRefusalCost()
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("You shrink back, shaking your head.")
		var s = _stage()
		if s >= 3:
			saynn("[say=npc2]" + RNG.pick([
				"Not yet. But soon you won't be able to say that.",
				"Fine. I'll be back.",
				"Enjoy the last time you get to say no.",
			]) + "[/say]")
		else:
			saynn("[say=npc2]" + RNG.pick(["Fine. Another time.", "Your loss.", "Suit yourself."]) + "[/say]")
		addButton("Continue", "", "end_refused")

	# ── Endings ───────────────────────────────────────────────────────────
	if state == "end_pleased":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		var s = _stage()
		if s >= 4:
			if _perfectPet():
				saynn("{npc2.name} gives your head a last pat and walks away looking satisfied.")
			else:
				saynn("{npc2.name} doesn't say anything. Just walks off like nothing happened.")
		elif s >= 3:
			if _perfectPet():
				saynn("[say=npc2]" + RNG.pick(["Good pup.", "That's what I like to see.", "See you around."]) + "[/say]")
			else:
				saynn("[say=npc2]" + RNG.pick(["That's what I thought.", "Good dog.", "See you around."]) + "[/say]")
		else:
			saynn("[say=npc2]" + RNG.pick(["Good pup. Go on.", "That's what I like to see.", "Nice."]) + "[/say]")
		# Award XP and set GoodPup flag
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 5, "puppy_encounter_pleased")
			if GM.pc.hasPerk("PuppyPerk_GoodPup"):
				GM.main.setFlag("PuppyRestraintsMod.GoodPupActive", true)
		addButton("Continue", "", "leave")

	if state == "end_refused":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		var s = _stage()
		if s >= 3:
			saynn("{npc2.name} looks at you like something they'll come back to later.")
		else:
			saynn("{npc2.name} shrugs and moves on.")
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 2, "puppy_encounter_refused")
		addButton("Continue", "", "leave")

func _react(_action: String, _args):
	if _action == "start_sex":
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 10, "puppy_encounter_sex")
		runScene("GenericSexScene", [npc2ID, "pc", SexType.BitchsuitSex, {}])
		endScene()
		return
	if _action == "leave":
		endScene()
		return
	setState(_action)

func saveData():
	var data = .saveData()
	data["npc2ID"]  = npc2ID
	data["_chosen"] = _chosen
	return data

func loadData(data):
	.loadData(data)
	npc2ID  = SAVE.loadVar(data, "npc2ID",  "")
	_chosen = SAVE.loadVar(data, "_chosen", "")
	if npc2ID != "":
		npc2 = GlobalRegistry.getCharacter(npc2ID)
