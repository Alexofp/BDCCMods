extends SceneBase
# Eating from a bowl in the Feed Room.
# No utensils. Flavour scales with conditioning.
# Awards XP and restores stamina.

func _init():
	sceneID = "PuppyFeedScene"

func _stage() -> int:
	if GM.pc == null: return 0
	var e = GM.pc.getEffect("puppy_conditioning")
	if e == null: return 0
	var l = e.conditioningLevel
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _run():
	if state == "":
		playAnimation(StageScene.PuppySolo, "paw")
		saynn("You lower yourself to the bowl. There is no other way to do this.")
		var s = _stage()
		if s >= 4:
			saynn("You eat without hesitation. It tastes fine. You finish it.")
		elif s >= 3:
			saynn("There is a moment of resistance. Then it passes and you eat.")
		elif s >= 2:
			saynn("It feels strange. Undignified. You eat anyway.")
		else:
			saynn("This is deeply uncomfortable. You eat slowly, aware of every detail of what you are doing.")
		addButton("Finish eating", "", "done")

	if state == "done":
		playAnimation(StageScene.PuppySolo, "stand")
		saynn("The bowl is empty. You feel fed. The floor is still at your level.")
		if GM.pc != null:
			GM.pc.addStamina(25)
			GM.pc.addLust(5)
			processTime(20 * 60)
			GM.pc.addSkillExperience("PuppyConditioning", 5, "puppy_feed")
		addButton("Continue", "", "leave")

func _react(_action, _args):
	if _action == "leave":
		endScene()
		return
	setState(_action)
