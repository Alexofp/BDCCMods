extends SceneBase
# PuppyLeashWalkScene
#
# NPC clips a leash to the player's collar and leads them through N rooms.
# Fires from PuppyEncounterEvent at conditioning 75%+ (stage 3+).
#
# Architecture follows PetWalkiesScene:
#   _run()   -- shows current state UI only, never moves the player
#   _react() -- does all movement, then calls setState() to update the view
#
# States:
#   ""          opening (NPC clips leash)
#   "walking"   mid-walk room view
#   "walk_done" NPC stops, end interaction
#   "escaped"   player slipped the leash (LeashBroken perk)
#   "end_kind"  pat and release
#   "end_mean"  oral demanded before release
#   "end_sex"   sex before release (stage 4+ or after end_sex narration)
#   "leave"     final goodbye, then done

var npc2ID: String = ""
var npc2
var _stepsTotal: int    = 3
var _stepsDone:  int    = 0
var _npcTone:    String = "kind"
var _lastDir:    String = ""   # label for the last step taken, used in "walking" text

func _init():
	sceneID = "PuppyLeashWalkScene"

func _initScene(_args = []):
	npc2ID = _args[0]

func _reactInit():
	npc2 = getCharacter(npc2ID)
	addCharacter(npc2ID)

	var personality = npc2.getPersonality()
	if personality.getStat(PersonalityStat.Mean) > 0.25:
		_npcTone = "mean"
	elif personality.getStat(PersonalityStat.Subby) > 0.25:
		_npcTone = "subby"
	else:
		_npcTone = "kind"

	_stepsTotal = 5 if _stage() >= 4 else 3

func resolveCustomCharacterName(_charID):
	if _charID == "npc2":
		return npc2ID

# ── helpers ──────────────────────────────────────────────────────────────────

func _conditioning() -> float:
	if GM.pc == null:
		return 0.0
	var e = GM.pc.getEffect("puppy_conditioning")
	return e.conditioningLevel if e != null else 0.0

func _stage() -> int:
	var l = _conditioning()
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	else:           return 1

func _repLevel() -> int:
	if GM.pc == null or GM.pc.getReputation() == null:
		return 0
	return GM.pc.getReputation().getRepLevel("PuppyRep")

# Rep-adjusted opener line by NPC
func _repOpener() -> String:
	var r = _repLevel()
	if r >= 3:
		return RNG.pick([
			"There you are. Come on, let's go for a walk.",
			"Oh good, it's you. I've been meaning to take you out.",
			"Perfect timing. Walk with me.",
		])
	elif r >= 2:
		return RNG.pick([
			"Hey, I recognise you. Come on.",
			"I've seen you around. Let me take your lead for a bit.",
		])
	return ""  # use tone-based opener

func _tryGift():
	if GM.pc == null:
		return
	var r = _repLevel()
	var chance = 0
	if   r >= 4: chance = 50
	elif r >= 3: chance = 30
	elif r >= 2: chance = 15
	if chance == 0 or not RNG.chance(chance):
		return
	var gift = RNG.randi_range(0, 1)
	match gift:
		0:
			GM.pc.addStamina(15)
			saynn("[color=yellow]They slip you a small energy tab before unclipping the lead.[/color]")
		1:
			GM.pc.addLust(-15)
			saynn("[color=yellow]They press something cool and soothing into your mitt. You feel calmer.[/color]")

func _pickDir():
	# Returns a GameWorld.Direction int, or -1 if no exits
	var roomID = GM.pc.location
	var dirs = [
		GameWorld.Direction.NORTH,
		GameWorld.Direction.SOUTH,
		GameWorld.Direction.EAST,
		GameWorld.Direction.WEST,
	]
	var valid = []
	for d in dirs:
		if GM.world.canGoID(roomID, d):
			valid.append(d)
	if valid.size() == 0:
		return -1
	return RNG.pick(valid)

func _dirLabel(d: int) -> String:
	match d:
		GameWorld.Direction.NORTH: return "north"
		GameWorld.Direction.SOUTH: return "south"
		GameWorld.Direction.EAST:  return "east"
		GameWorld.Direction.WEST:  return "west"
	return "forward"

# ── _run: show only, no movement, no setState ────────────────────────────────

func _run():

	# ── Opening ──────────────────────────────────────────────────────────
	if state == "":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("{npc2.name} stops in front of you and looks down.")

		# Rep-aware greeting overrides tone-based opener at rep 2+
		var _repLine = _repOpener()
		if _repLine != "":
			saynn("[say=npc2]" + _repLine + "[/say]")
		else:
			match _npcTone:
			"kind":
				saynn("[say=npc2]" + RNG.pick([
					"Oh, you're just wandering? Let me take you for a proper walk.",
					"Come on, pup. I'll show you around.",
					"Here, let me take that leash. We'll go for a little walk.",
				]) + "[/say]")
			"mean":
				saynn("[say=npc2]" + RNG.pick([
					"Stop crawling around like an idiot. I'll take you somewhere.",
					"Come on. You're coming with me.",
					"Clip. You're on my leash now. Move.",
				]) + "[/say]")
			"subby":
				saynn("[say=npc2]" + RNG.pick([
					"Oh, um -- can I? I just want to take you for a walk.",
					"You look like you need a guide. Could I hold your leash for a bit?",
					"Sorry -- is it okay if I take you? Just a short walk.",
				]) + "[/say]")

		saynn("{npc2.name} clips a lead to your collar. You feel the gentle tug.")

		if _stage() >= 4:
			addButton("Follow", "The leash pulls. You follow.", "walk_step")
		else:
			addButton("Follow", "The leash tugs you forward.", "walk_step")
			addDisabledButton("Resist", "The conditioning won't let you pull back.")

	# ── Mid-walk room view ────────────────────────────────────────────────
	if state == "walking":
		playAnimation(StageScene.PuppyDuo, "walk", {pc=npc2ID, npc="pc", npcAction="walk", flipNPC=true})

		var roomID   = GM.pc.location
		var roomInfo = GM.world.getRoomByID(roomID)
		aimCamera(roomID)
		setLocationName(roomInfo.getName())

		var stepLines = [
			"{npc2.name} tugs the leash " + _lastDir + ". You scramble to keep up.",
			"The lead pulls you " + _lastDir + ". Your knees scrape the floor.",
			"You're pulled " + _lastDir + " at a steady pace.",
			"{npc2.name} walks ahead. You crawl behind on the leash.",
			"The leash goes taut. You follow " + _lastDir + " without thinking.",
		]
		saynn(RNG.pick(stepLines))

		if GM.pc.isBlindfolded() and not GM.pc.canHandleBlindness():
			saynn(roomInfo.getBlindDescription())
		else:
			saynn(roomInfo.getDescription())

		if GM.main.IS.hasPawnsAtIgnorePC(roomID):
			setCharactersEasyList(GM.main.IS.getPawnIDsAt(roomID))
			saynn(RNG.pick([
				"A few people stop and stare as you're led past.",
				"Someone nearby watches you being walked. You feel their eyes.",
				"You pass others in the corridor. Nobody intervenes.",
			]))

		# Progress indicator
		saynn("[color=gray]Step " + str(_stepsDone) + " of " + str(_stepsTotal) + ".[/color]")

		if _stepsDone >= _stepsTotal:
			addButton("Continue", "", "walk_done")
		else:
			addButton("Keep up", "You have no choice.", "walk_step")
			# LeashBroken perk: 30% chance to offer escape each step
			if GM.pc != null and GM.pc.hasPerk("PuppyPerk_LeashBroken"):
				if RNG.chance(30):
					addButton("Slip the leash", "You see a moment of slack. Take it.", "escape")

	# ── Escaped ───────────────────────────────────────────────────────────
	if state == "escaped":
		playAnimation(StageScene.PuppySolo, "walk")
		saynn("You feel a moment of slack in the lead and lunge sideways.")
		saynn("{npc2.name} grabs at the leash but you're already scrambling away.")
		saynn("[say=npc2]" + RNG.pick(["Hey!", "Get back here!", "Oi!"]) + "[/say]")
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 3, "puppy_leash_escape")
		addButton("Keep going", "", "leave")

	# ── Walk done: NPC stops ──────────────────────────────────────────────
	if state == "walk_done":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("{npc2.name} slows and stops, looking down at you.")

		if _stage() >= 4:
			saynn("[say=npc2]" + RNG.pick([
				"You walked well. Time for your reward.",
				"Good pup. Now you're going to do something for me.",
				"That's enough walking. I want something now.",
			]) + "[/say]")
			addButton("...", "You already know what comes next.", "end_sex_narration")
		else:
			match _npcTone:
				"kind":
					saynn("[say=npc2]" + RNG.pick([
						"Good pup. That was a nice walk.",
						"You did well. Here, sit.",
						"See? A proper walk. Good dog.",
					]) + "[/say]")
					addButton("Continue", "", "end_kind")
				"mean":
					saynn("[say=npc2]" + RNG.pick([
						"Alright. Sit. I want something before I let you go.",
						"Not bad. Now you're going to do something for me.",
						"Good. Now get to work.",
					]) + "[/say]")
					addButton("Continue", "", "end_mean")
				"subby":
					saynn("[say=npc2]" + RNG.pick([
						"That was... nice. Thank you for letting me do that.",
						"Um. You're a really good pup. I liked that.",
						"Here -- sit. I'll unhook you in a second.",
					]) + "[/say]")
					addButton("Continue", "", "end_kind")

	# ── End: kind ─────────────────────────────────────────────────────────
	if state == "end_kind":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc", npcAction="sit"})
		saynn("{npc2.name} crouches and gives your head a pat, then unclips the lead.")
		saynn("[say=npc2]" + RNG.pick([
			"Good pup. Off you go.",
			"Good dog. See you around.",
			"There we go. You can go now.",
		]) + "[/say]")
		GM.pc.addLust(10)
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 8, "puppy_leash_complete")
			if GM.pc.hasPerk("PuppyPerk_GoodPup"):
				GM.main.setFlag("PuppyRestraintsMod.GoodPupActive", true)
			if GM.pc.getReputation() != null:
				GM.pc.getReputation().addRep("PuppyRep", 0.4)
		_tryGift()
		addButton("Continue", "", "leave")

	# ── End: mean ─────────────────────────────────────────────────────────
	if state == "end_mean":
		playAnimation(StageScene.PuppySexOral, "grind", {pc=npc2ID, npc="pc", npcBodyState={naked=true}})
		saynn("{npc2.name} pushes your head toward their crotch without ceremony.")
		saynn("[say=npc2]" + RNG.pick([
			"Earn it.",
			"You know what to do.",
			"Get to work. Then I'll unhook you.",
		]) + "[/say]")
		saynn("You obey. By the time they unclip the lead you're breathing hard and your lust is burning.")
		GM.pc.addLust(35)
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 8, "puppy_leash_complete")
			if GM.pc.getReputation() != null:
				GM.pc.getReputation().addRep("PuppyRep", 0.2)
		addButton("Continue", "", "leave")

	# ── End: sex narration (actual launch in _react) ──────────────────────
	if state == "end_sex_narration":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("{npc2.name} clips the lead to a hook on the wall and unzips.")
		saynn("There's nowhere to go. The leash holds you in place.")
		addButton("Continue", "", "start_sex")

	# ── Leave ─────────────────────────────────────────────────────────────
	if state == "leave":
		playAnimation(StageScene.PuppyDuo, "stand", {pc=npc2ID, npc="pc"})
		saynn("{npc2.name} pockets the lead and walks away without looking back.")
		addButton("Continue", "", "done")

# ── _react: all movement and transitions happen here ─────────────────────────

func _react(_action: String, _args):
	# Sex launch: runScene then endScene, always from _react
	if _action == "start_sex":
		if GM.pc != null:
			GM.pc.addSkillExperience("PuppyConditioning", 12, "puppy_leash_sex")
			if GM.pc.getReputation() != null:
				GM.pc.getReputation().addRep("PuppyRep", 0.5)
		runScene("GenericSexScene", [npc2ID, "pc", SexType.BitchsuitSex, {}])
		endScene()
		return

	if _action == "done":
		endScene()
		return

	# Movement step: pick direction, move player, update state
	if _action == "walk_step":
		var d = _pickDir()
		if d == -1:
			# Dead end -- skip straight to end
			setState("walk_done")
			return
		processTime(60)
		_lastDir = _dirLabel(d)
		GM.pc.setLocation(GM.world.applyDirectionID(GM.pc.location, d))
		_stepsDone += 1
		if _stepsDone >= _stepsTotal:
			setState("walking")   # show room, button will say "Continue" -> walk_done
		else:
			setState("walking")
		return

	if _action == "escape":
		setState("escaped")
		return

	setState(_action)

func saveData():
	var data = .saveData()
	data["npc2ID"]      = npc2ID
	data["_stepsTotal"] = _stepsTotal
	data["_stepsDone"]  = _stepsDone
	data["_npcTone"]    = _npcTone
	data["_lastDir"]    = _lastDir
	return data

func loadData(data):
	.loadData(data)
	npc2ID      = SAVE.loadVar(data, "npc2ID",      "")
	_stepsTotal = SAVE.loadVar(data, "_stepsTotal", 3)
	_stepsDone  = SAVE.loadVar(data, "_stepsDone",  0)
	_npcTone    = SAVE.loadVar(data, "_npcTone",    "kind")
	_lastDir    = SAVE.loadVar(data, "_lastDir",    "")
	if npc2ID != "":
		npc2 = GlobalRegistry.getCharacter(npc2ID)
