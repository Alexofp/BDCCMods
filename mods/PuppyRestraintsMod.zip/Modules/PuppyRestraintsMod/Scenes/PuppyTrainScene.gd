extends SceneBase
# Running the obstacle course in the Training Room.
# Picks a random set of obstacles each run.
# Awards conditioning XP and stamina.

func _init():
	sceneID = "PuppyTrainScene"

func _stage() -> int:
	if GM.pc == null: return 0
	var e = GM.pc.getEffect("puppy_conditioning")
	if e == null: return 0
	var l = e.conditioningLevel
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _run():
	if state == "":
		playAnimation(StageScene.PuppySolo, "walk")
		saynn("You survey the course. Low hurdles, crawl tunnels, a weave section.")
		var s = _stage()
		if s >= 4:
			saynn("You know what to do before you decide to start. Your body is already moving.")
		elif s >= 3:
			saynn("The layout makes sense to you in a way it did not before.")
		elif s >= 2:
			saynn("You study the markers on the floor. It is laid out logically. For something like you.")
		else:
			saynn("The scale of it is unsettling. Every obstacle is sized for someone on all fours.")
		addButton("Run the course", "", "run_course")
		addButton("Leave", "", "leave")

	if state == "run_course":
		playAnimation(StageScene.PuppySolo, "walk")
		var obstacles = ["hurdles", "tunnel", "weave", "stay marker", "recall line"]
		var chosen = []
		for i in range(3):
			var o = RNG.pick(obstacles)
			if not o in chosen:
				chosen.append(o)
		saynn("You work through: " + chosen[0] + ", " + chosen[1] + ", " + chosen[2] + ".")
		var s = _stage()
		if s >= 4:
			saynn("Clean. Fast. You finish without breaking pace.")
			saynn("Something in you settles afterward -- satisfied in a way you cannot name.")
		elif s >= 3:
			saynn("You finish it without stumbling. Your body knows how to move down here now.")
		elif s >= 2:
			saynn("You make it through. Clumsier than the course seems designed for, but you finish.")
		else:
			saynn("It takes longer than it should. Your instincts are not there yet.")
		if GM.pc != null:
			var xp = 4 + _stage() * 2
			GM.pc.addSkillExperience("PuppyConditioning", xp, "puppy_train")
			GM.pc.addStamina(-10)
			processTime(30 * 60)
		addButton("Run again", "", "run_course")
		addButton("Finish training", "", "leave")

func _react(_action, _args):
	if _action == "leave":
		endScene()
		return
	setState(_action)
