extends SceneBase
# Resting in one of the kennel beds.
# Restores stamina, reduces lust, awards XP.
# Longer rest at higher conditioning.

func _init():
	sceneID = "PuppyRestScene"

func _stage() -> int:
	if GM.pc == null: return 0
	var e = GM.pc.getEffect("puppy_conditioning")
	if e == null: return 0
	var l = e.conditioningLevel
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _run():
	if state == "":
		playAnimation(StageScene.PuppySolo, "sit")
		saynn("The bed is thick and warm. You curl up into it.")
		var s = _stage()
		if s >= 4:
			saynn("There is no resistance. You are asleep almost before you decide to rest.")
		elif s >= 3:
			saynn("Your body sinks in and the basement goes quiet around you. You sleep deeply.")
		elif s >= 2:
			saynn("It is more comfortable than your cell. You sleep for a while.")
		else:
			saynn("Stranger than expected. But your body is tired. You sleep.")
		addButton("Wake up", "", "wake")

	if state == "wake":
		playAnimation(StageScene.PuppySolo, "stand")
		saynn("You wake up rested. The basement is unchanged. Quiet.")
		if GM.pc != null:
			var s = _stage()
			var stamina  = 30 + s * 10
			var lustLoss = 10 + s * 5
			GM.pc.addStamina(stamina)
			GM.pc.addLust(-lustLoss)
			processTime(60 * 60)
			GM.pc.addSkillExperience("PuppyConditioning", 3, "puppy_rest")
		addButton("Get up", "", "leave")

func _react(_action, _args):
	if _action == "leave":
		endScene()
		return
	setState(_action)
