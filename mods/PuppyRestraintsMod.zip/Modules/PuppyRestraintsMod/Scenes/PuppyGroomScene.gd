extends SceneBase
# Grooming table in the basement Grooming Room.
# Awards conditioning XP. Restores some lust and stamina.
# Flavour varies with conditioning stage.

func _init():
	sceneID = "PuppyGroomScene"

func _conditioning() -> float:
	if GM.pc == null: return 0.0
	var e = GM.pc.getEffect("puppy_conditioning")
	return e.conditioningLevel if e != null else 0.0

func _stage() -> int:
	var l = _conditioning()
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _run():
	if state == "":
		playAnimation(StageScene.PuppySolo, "stand")
		saynn("You climb onto the grooming table and settle into position.")
		saynn("The station activates automatically. Warm air. Soft brushes. Something that smells faintly medicinal and clean.")
		var s = _stage()
		if s >= 4:
			saynn("You stop thinking almost immediately. Your body knows this. It sinks in and goes still.")
		elif s >= 3:
			saynn("It takes a moment to settle. Then your thoughts quiet down and there is only the warmth.")
		elif s >= 2:
			saynn("It is more comfortable than you expected. You find yourself leaning into it.")
		else:
			saynn("It feels strange. Clinical. But not unpleasant.")
		addButton("Continue", "", "finish")

	if state == "finish":
		playAnimation(StageScene.PuppySolo, "stand")
		saynn("When it finishes you feel clean and oddly calm. Your coat -- your restraints -- sit perfectly adjusted.")
		if GM.pc != null:
			GM.pc.addLust(-15)
			GM.pc.addStamina(15)
			GM.pc.addSkillExperience("PuppyConditioning", 4, "puppy_groom")
		addButton("Step down", "", "leave")

func _react(_action, _args):
	if _action == "leave":
		endScene()
		return
	setState(_action)
