extends SceneBase
# Examining the display cases in the Grand Hall.
# Flavour only -- no mechanics. Text varies by conditioning stage.

func _init():
	sceneID = "PuppyDisplayCasesScene"

func _stage() -> int:
	if GM.pc == null: return 0
	var e = GM.pc.getEffect("puppy_conditioning")
	if e == null: return 0
	var l = e.conditioningLevel
	if   l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _run():
	if state == "":
		playAnimation(StageScene.PuppySolo, "stand")
		saynn("You press close to the glass and look.")
		saynn("Collars of every size and material -- leather, rubber, metal. Leads of different lengths. Mitts, knee pads, harnesses. All tagged with small handwritten labels you cannot quite read from here.")

		var s = _stage()
		if s >= 4:
			saynn("You recognise most of it. Some of it you have worn. Your eyes move slowly and without hurry.")
			saynn("In the bottom corner of one case there is a collar that is unlabelled. It looks like it was made to be worn constantly.")
		elif s >= 3:
			saynn("Some of it you recognise. The sight of it does not disturb you the way it might have before.")
			saynn("One case has gear clearly sized for someone at your level. You look at it for a while.")
		elif s >= 2:
			saynn("Some of the gear is familiar. Some of it is not, and you are not sure you want to know what it is for.")
		else:
			saynn("Most of it you do not recognise. All of it makes you uneasy.")
			saynn("Whoever built this room expected it to be used.")
		addButton("Step back", "", "leave")

func _react(_action, _args):
	if _action == "leave":
		endScene()
		return
	setState(_action)
