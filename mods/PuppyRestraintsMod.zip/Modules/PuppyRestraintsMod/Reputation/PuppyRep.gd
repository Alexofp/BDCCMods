extends RepStatBase
# PuppyRep -- "Good Pup" reputation.
# Tracks how well-regarded the player is among people who frequent the basement
# and interact with players in puppy restraints.
#
# Level -1:  Difficult. Seen as resistant and uncooperative.
# Level  0:  Unknown. Nobody knows you yet.
# Level  1:  Noticed. A few people have seen you around.
# Level  2:  Familiar. You are known as a reasonably compliant pup.
# Level  3:  Well-trained. People expect good behaviour and are friendly about it.
# Level  4:  Perfect Pet. You are known as fully conditioned and eager. NPCs are warm.

func _init():
	id = "PuppyRep"

func getVisibleName():
	return "Pup Reputation"

func getMaxLevel() -> int:
	return 4

func getMinLevel() -> int:
	return -1

func getTextForLevel(_level: int, _rep) -> String:
	match _level:
		-1: return "Resistant"
		0:  return "Unknown Pup"
		1:  return "Noticed"
		2:  return "Familiar"
		3:  return "Well-Trained"
		4:  return "Perfect Pet"
	return "Unknown"

func getEffectsInfoForLevel(_level: int, _rep) -> Array:
	match _level:
		1: return ["NPCs who interact with you are slightly warmer."]
		2: return ["NPCs use a friendlier tone. Occasional small gifts after encounters."]
		3: return ["NPCs are noticeably kind. Gifts more frequent. Encounters slightly more often."]
		4: return ["NPCs treat you with warmth and ownership. Frequent gifts. Best encounter dialogue."]
	return []
