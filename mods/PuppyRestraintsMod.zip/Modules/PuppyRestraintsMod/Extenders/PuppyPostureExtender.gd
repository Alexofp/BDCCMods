extends GameExtender
# Fires on every pcUpdateNonBattleEffects call - which happens after every
# equip/unequip, buff change, room entry, and importantly after every
# pickOption (button click) via Player.updateNonBattleEffects().
# We call playAnimation directly here, same approach as the walk fix.

func _init():
	id = "PuppyPostureExtender"

func register(_GES: GameExtenderSystem):
	_GES.register(self, ExtendGame.pcUpdateNonBattleEffects)

func pcUpdateNonBattleEffects(_pc):
	if _pc == null or _pc.getInventory() == null:
		return
	if not _pc.getInventory().hasItemIDEquipped("puppy_restraints"):
		return
	if GM.main == null or GM.main.sceneStack.size() == 0:
		return
	
	var currentScene = GM.main.sceneStack.back()
	
	# Don't override sex/restraint scenes
	var currentStage = GM.ui.getStage3d().currentScene if GM.ui != null and GM.ui.getStage3d() != null else null
	if currentStage != null:
		var sid = currentStage.id
		if "Sex" in sid or "Puppy" in sid or "Stocks" in sid or "Slutwall" in sid or "Hanging" in sid or "Ropes" in sid or "Hogtied" in sid or "Milking" in sid or "Sybian" in sid or "Urinal" in sid or "BDSM" in sid or "WoodenHorse" in sid:
			return
	
	# Find NPC in current scene
	var npc_id = ""
	for charID in currentScene.currentCharactersVariants.keys():
		if charID != "pc":
			npc_id = charID
			break
	
	if npc_id != "":
		GM.main.playAnimation(StageScene.PuppyDuo, "stand", {"pc": npc_id, "npc": "pc", "npcAction": "paw"})
	else:
		GM.main.playAnimation(StageScene.PuppySolo, "paw")
