extends StatusEffectBase
# PuppyConditioning — builds while puppy restraints are worn.
#
# processTime() via Player.processTime() — receives SECONDS.
# alwaysCheckedForPlayer=true so it auto-applies when restraints are equipped.
#
# Build:  1 week  (604800 s)  to reach 1.0
# Decay:  2 weeks (1209600 s) to decay from 1.0 → 0.0 (half speed, no restraints)
# Cap:    1.25 (extra 1.75 days beyond 1.0 for stage 5)
#
# Stages and buffs:
#
#  Stage 0  (0–25%)    No buffs yet.
#
#  Stage 1  (25–50%)   +5  ambient lust
#                      +10 sensitivity
#                      Body adapting to all-fours.
#
#  Stage 2  (50–75%)   +15 ambient lust,  +10 sexiness
#                      +20 sensitivity
#                      +15 exposure       (crawling in public feels normal / shameful)
#                      +10 Subby          (psychological submission beginning)
#
#  Stage 3  (75–100%)  +25 ambient lust,  +20 sexiness,  passive lust drain
#                      +35 sensitivity
#                      +30 exposure
#                      +25 Subby
#                      +15 Coward         (fight instinct replaced by compliance)
#                      RestrainedLegsBuff (legs psychosomatically forget how to stand —
#                                          applies from the effect, not the item, so
#                                          persists even briefly without restraints)
#
#  Stage 4  (100–125%) +40 ambient lust,  ForcedObedience 50%
#                      +50 sensitivity
#                      +45 exposure
#                      +40 Subby
#                      +30 Coward
#                      RestrainedLegsBuff (keep)
#                      MinLoosenessAnusBuff [2]  (body physically adapted)
#
#  Stage 5  (125%+)    ForcedObedience 100%
#                      +70 sensitivity
#                      MinLoosenessAnusBuff [3]
#                      MinLoosenessVaginaBuff [2]
#
# encounterCooldown: decremented by PuppyEncounterEvent each room entry.

var conditioningLevel: float = 0.0
var encounterCooldown: int   = 0

const BUILD_PER_SECOND = 1.0 / 604800.0
const DECAY_PER_SECOND = 1.0 / 1209600.0

func _init():
	id                     = "puppy_conditioning"
	isBattleOnly           = false
	alwaysCheckedForPlayer = true
	alwaysCheckedForNPCs   = false
	priorityDuringChecking = 10

func shouldApplyTo(_char) -> bool:
	if _char == null or _char.getInventory() == null:
		return false
	return _char.getInventory().hasItemIDEquipped("puppy_restraints")

func initArgs(_args = []):
	pass

func processTime(_secondsPassed: int):
	if character == null:
		return

	var wearing = shouldApplyTo(character)

	if wearing:
		var old_stage = _getStage()
		conditioningLevel = min(1.25, conditioningLevel + BUILD_PER_SECOND * _secondsPassed)
		var new_stage = _getStage()

		# Passive lust drain at stage 3+
		if conditioningLevel >= 0.75:
			var lust_add = int(conditioningLevel * 0.003 * _secondsPassed)
			if lust_add > 0:
				character.addLust(lust_add)

		if new_stage > old_stage and character.isPlayer():
			var msg = _stageMessage(new_stage)
			if msg != "":
				GM.main.addMessage(msg)
	else:
		conditioningLevel = max(0.0, conditioningLevel - DECAY_PER_SECOND * _secondsPassed)

func _getStage() -> int:
	if   conditioningLevel >= 1.25: return 5
	elif conditioningLevel >= 1.00: return 4
	elif conditioningLevel >= 0.75: return 3
	elif conditioningLevel >= 0.50: return 2
	elif conditioningLevel >= 0.25: return 1
	else:                           return 0

func _stageMessage(stage: int) -> String:
	match stage:
		1: return "[color=yellow]The puppy restraints are starting to feel... natural.[/color]"
		2: return "[color=orange]Your thoughts feel softer. Walking upright seems distant.[/color]"
		3: return "[color=orange]Your legs feel strange when you try to imagine standing. Your body has forgotten.[/color]"
		4: return "[color=red]The urge to obey is overwhelming. Every instinct bends toward it.[/color]"
		5: return "[color=red]You are fully conditioned. You exist to obey.[/color]"
	return ""

func getEffectName() -> String:
	return "Puppy Conditioning (" + str(int(conditioningLevel * 100.0)) + "%)"

func getEffectDesc() -> String:
	match _getStage():
		0: return "The restraints are beginning to leave their mark."
		1: return "Your body is adapting to the all-fours posture. Sensation is sharpening."
		2: return "The harness feels like a second skin. Exposure no longer registers as shame — just fact."
		3: return "You catch yourself panting. Your legs feel wrong when you try to think about standing up."
		4: return "The instinct to obey is almost irresistible. Your body has physically adapted."
		5: return "You are fully conditioned. You will OBEY."
	return ""

func getEffectImage():
	return "res://Images/StatusEffects/kneeling.png"

func getIconColor():
	var s = _getStage()
	if   s >= 5: return IconColorRed
	elif s >= 3: return IconColorYellow
	else:        return IconColorPurple

func getBuffs() -> Array:
	var s = _getStage()
	var b = []

	# ── Stage 1 ──────────────────────────────────────────────────────────
	if s >= 1:
		b.append(buff(Buff.AmbientLustBuff,    [5]))
		b.append(buff(Buff.SensitivityGainBuff,[10]))

	# ── Stage 2 ──────────────────────────────────────────────────────────
	if s >= 2:
		b.append(buff(Buff.AmbientLustBuff,    [10]))
		b.append(buff(Buff.StatBuff,           [Stat.Sexiness, 10]))
		b.append(buff(Buff.SensitivityGainBuff,[20]))
		b.append(buff(Buff.ExposureBuff,       [15]))
		b.append(buff(Buff.StatBuff,           [Stat.Subby, 10]))

	# ── Stage 3 ──────────────────────────────────────────────────────────
	if s >= 3:
		b.append(buff(Buff.AmbientLustBuff,    [15]))
		b.append(buff(Buff.StatBuff,           [Stat.Sexiness, 20]))
		b.append(buff(Buff.SensitivityGainBuff,[35]))
		b.append(buff(Buff.ExposureBuff,       [30]))
		b.append(buff(Buff.StatBuff,           [Stat.Subby, 25]))
		b.append(buff(Buff.StatBuff,           [Stat.Coward, 15]))
		b.append(buff(Buff.RestrainedLegsBuff))

	# ── Stage 4 ──────────────────────────────────────────────────────────
	if s >= 4:
		b.append(buff(Buff.AmbientLustBuff,       [40]))
		b.append(buff(Buff.ForcedObedienceBuff,   [50]))
		b.append(buff(Buff.SensitivityGainBuff,   [50]))
		b.append(buff(Buff.ExposureBuff,          [45]))
		b.append(buff(Buff.StatBuff,              [Stat.Subby, 40]))
		b.append(buff(Buff.StatBuff,              [Stat.Coward, 30]))
		b.append(buff(Buff.MinLoosenessAnusBuff,  [2]))

	# ── Stage 5 ──────────────────────────────────────────────────────────
	if s >= 5:
		b.append(buff(Buff.ForcedObedienceBuff,    [100]))
		b.append(buff(Buff.SensitivityGainBuff,    [70]))
		b.append(buff(Buff.MinLoosenessAnusBuff,   [3]))
		b.append(buff(Buff.MinLoosenessVaginaBuff, [2]))

	return b

func combine(_args = []):
	pass

func saveData() -> Dictionary:
	return {
		"conditioningLevel": conditioningLevel,
		"encounterCooldown": encounterCooldown,
	}

func loadData(_data):
	conditioningLevel = SAVE.loadVar(_data, "conditioningLevel", 0.0)
	encounterCooldown = SAVE.loadVar(_data, "encounterCooldown", 0)
