extends StatusEffectBase
# PuppyConditioning
#
# Builds while puppy restraints are worn, decays when off.
# Build:  1 week  (604800 s) to reach 1.0
# Decay:  2 weeks (1209600 s) to reach 0.0 from 1.0 (halved with PackMentality perk)
# Cap:    1.25
#
# Stages:
#  Stage 0  (0-25%)     No effects.
#  Stage 1  (25-50%)    +5 lust aura, +10 sensitivity.
#                       NPC encounters begin (free refusal).
#  Stage 2  (50-75%)    +15 lust, +10 sexiness, +20 sensitivity,
#                       +15 exposure, +10 Subby.
#                       Refusal costs +20 lust.
#  Stage 3  (75-100%)   +25 lust, +20 sexiness, +35 sensitivity,
#                       +30 exposure, +25 Subby, +15 Coward,
#                       RestrainedLegsBuff, passive lust drain.
#                       Refusal costs +40 lust.
#                       Leash walk enters encounter pool (25%).
#  Stage 4  (100-125%)  +40 lust, ForcedObedience 50%, +50 sensitivity,
#                       +45 exposure, +40 Subby, +30 Coward,
#                       MinLoosenessAnusBuff [2].
#                       No refusal. Leash walk pool 40%.
#  Stage 5  (125%+)     ForcedObedience 100%, +70 sensitivity,
#                       MinLoosenessAnusBuff [3], MinLoosenessVaginaBuff [2].
#
# XP awards (PuppyConditioning skill):
#   - Per second worn: slow trickle
#   - Per room entered (via processTime each ~60s step): incremental
#   - Scenes award XP directly via GM.pc.addSkillExperience("PuppyConditioning", n)
#
# Flags managed:
#   PuppyRestraintsMod.GoodPupActive  -- set by PuppyEncounterScene on pleased ending,
#                                        cleared each new day here.

var conditioningLevel: float = 0.0
var encounterCooldown: int   = 0
var _secondsWornToday: float = 0.0   # tracks XP trickle per day

const BUILD_PER_SECOND = 1.0 / 604800.0
const DECAY_PER_SECOND = 1.0 / 1209600.0
# XP: ~1 XP every 5 minutes of wear (12 per hour, ~288 per day => ~level 1 per 1-2 days of wear)
const XP_PER_SECOND    = 1.0 / 300.0

func _init():
	id                     = "puppy_conditioning"
	isBattleOnly           = false
	alwaysCheckedForPlayer = true
	alwaysCheckedForNPCs   = false
	priorityDuringChecking = 10

func shouldApplyTo(_char) -> bool:
	# Keep the effect alive as long as:
	#   - restraints are worn (building), OR
	#   - conditioning level is above zero (decaying)
	# Without this, updateNonBattleEffects() destroys the effect the instant the
	# item is removed, wiping conditioningLevel no matter how high it was built.
	if _char == null:
		return false
	if _char.getInventory() != null and _char.getInventory().hasItemIDEquipped("puppy_restraints"):
		return true
	return conditioningLevel > 0.0

func initArgs(_args = []):
	pass

func processTime(_secondsPassed: int):
	if character == null:
		return

	var wearing = (character.getInventory() != null and
		character.getInventory().hasItemIDEquipped("puppy_restraints"))

	if wearing:
		var old_stage = _getStage()
		conditioningLevel = min(1.25, conditioningLevel + BUILD_PER_SECOND * _secondsPassed)
		var new_stage = _getStage()

		# Passive lust drain at stage 3+
		if conditioningLevel >= 0.75:
			var lust_add = int(conditioningLevel * 0.003 * _secondsPassed)
			if lust_add > 0:
				character.addLust(lust_add)

		# Award PuppyConditioning skill XP while wearing
		if character.isPlayer():
			var xp = XP_PER_SECOND * _secondsPassed
			_secondsWornToday += _secondsPassed
			if xp >= 1.0:
				character.addSkillExperience("PuppyConditioning", int(xp), "puppy_wear_time")

		# Stage transition message
		if new_stage > old_stage and character.isPlayer():
			var msg = _stageMessage(new_stage)
			if msg != "":
				GM.main.addMessage(msg)
	else:
		# Decay - halved if PackMentality perk is active
		var decay = DECAY_PER_SECOND
		if character.isPlayer() and character.hasPerk("PuppyPerk_PackMentality"):
			decay *= 0.5
		conditioningLevel = max(0.0, conditioningLevel - decay * _secondsPassed)

	# Reset GoodPup flag and daily XP tracker each new day
	# processTime is called with accumulated seconds; detect day boundary by checking
	# if _secondsWornToday has crossed 86400 (one game day)
	if _secondsWornToday >= 86400.0:
		_secondsWornToday -= 86400.0
		GM.main.setFlag("PuppyRestraintsMod.GoodPupActive", false)

func _getStage() -> int:
	if   conditioningLevel >= 1.25: return 5
	elif conditioningLevel >= 1.00: return 4
	elif conditioningLevel >= 0.75: return 3
	elif conditioningLevel >= 0.50: return 2
	elif conditioningLevel >= 0.25: return 1
	else:                           return 0

func _stageMessage(stage: int) -> String:
	match stage:
		1: return "[color=yellow]The puppy restraints are starting to feel... natural.[/color]"
		2: return "[color=orange]Your thoughts feel softer. Walking upright seems distant.[/color]"
		3: return "[color=orange]Your legs feel strange when you try to imagine standing. Your body has forgotten.[/color]"
		4: return "[color=red]The urge to obey is overwhelming. Every instinct bends toward it.[/color]"
		5: return "[color=red]You are fully conditioned. You exist to obey.[/color]"
	return ""

func getEffectName() -> String:
	return "Puppy Conditioning (" + str(int(conditioningLevel * 100.0)) + "%)"

func getEffectDesc() -> String:
	match _getStage():
		0: return "The restraints are beginning to leave their mark."
		1: return "Your body is adapting to the all-fours posture. Sensation is sharpening."
		2: return "The harness feels like a second skin. Exposure no longer registers as shame -- just fact."
		3: return "You catch yourself panting. Your legs feel wrong when you try to think about standing up."
		4: return "The instinct to obey is almost irresistible. Your body has physically adapted."
		5: return "You are fully conditioned. You will OBEY."
	return ""

func getEffectImage():
	return "res://Images/StatusEffects/kneeling.png"

func getIconColor():
	var s = _getStage()
	if   s >= 5: return IconColorRed
	elif s >= 3: return IconColorYellow
	else:        return IconColorPurple

func getBuffs() -> Array:
	var s = _getStage()
	var b = []

	if s >= 1:
		b.append(buff(Buff.AmbientLustBuff,    [5]))
		b.append(buff(Buff.SensitivityGainBuff,[10]))

	if s >= 2:
		b.append(buff(Buff.AmbientLustBuff,    [10]))
		b.append(buff(Buff.StatBuff,           [Stat.Sexiness, 10]))
		b.append(buff(Buff.SensitivityGainBuff,[20]))
		b.append(buff(Buff.ExposureBuff,       [15]))
		b.append(buff(Buff.StatBuff,           [Stat.Subby, 10]))

	if s >= 3:
		b.append(buff(Buff.AmbientLustBuff,    [15]))
		b.append(buff(Buff.StatBuff,           [Stat.Sexiness, 20]))
		b.append(buff(Buff.SensitivityGainBuff,[35]))
		b.append(buff(Buff.ExposureBuff,       [30]))
		b.append(buff(Buff.StatBuff,           [Stat.Subby, 25]))
		b.append(buff(Buff.StatBuff,           [Stat.Coward, 15]))
		b.append(buff(Buff.RestrainedLegsBuff))

	if s >= 4:
		b.append(buff(Buff.AmbientLustBuff,       [40]))
		b.append(buff(Buff.ForcedObedienceBuff,   [50]))
		b.append(buff(Buff.SensitivityGainBuff,   [50]))
		b.append(buff(Buff.ExposureBuff,          [45]))
		b.append(buff(Buff.StatBuff,              [Stat.Subby, 40]))
		b.append(buff(Buff.StatBuff,              [Stat.Coward, 30]))
		b.append(buff(Buff.MinLoosenessAnusBuff,  [2]))

	if s >= 5:
		b.append(buff(Buff.ForcedObedienceBuff,    [100]))
		b.append(buff(Buff.SensitivityGainBuff,    [70]))
		b.append(buff(Buff.MinLoosenessAnusBuff,   [3]))
		b.append(buff(Buff.MinLoosenessVaginaBuff, [2]))

	return b

func combine(_args = []):
	pass

func saveData() -> Dictionary:
	return {
		"conditioningLevel":  conditioningLevel,
		"encounterCooldown":  encounterCooldown,
		"_secondsWornToday":  _secondsWornToday,
	}

func loadData(_data):
	conditioningLevel  = SAVE.loadVar(_data, "conditioningLevel",  0.0)
	encounterCooldown  = SAVE.loadVar(_data, "encounterCooldown",  0)
	_secondsWornToday  = SAVE.loadVar(_data, "_secondsWornToday",  0.0)
