extends EventBase
# PuppyEncounterEvent — fires when the player enters a room wearing puppy restraints.
#
# IMPORTANT: uses react() not run().
# run()   fires synchronously mid-scene — calling runScene() from run() corrupts the
#         scene stack and empties the IS pawn list (minimap clears, next move softlocks).
# react() fires after the triggering scene finishes its current execution, so
#         runScene() works safely. See GuardOfflimitsCanSlipByEvent for the same pattern.
#
# Trigger: Trigger.EnteringRoom, args = [roomID]

func _init():
	id = "PuppyEncounterEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func react(_triggerID, _args):
	if GM.pc == null or GM.pc.getInventory() == null:
		return false
	if not GM.pc.getInventory().hasItemIDEquipped("puppy_restraints"):
		return false

	var effect = GM.pc.getEffect("puppy_conditioning")
	if effect == null:
		return false

	var level = effect.conditioningLevel
	if level < 0.25:
		return false  # Stage 0 — no encounters yet

	# Per-room cooldown stored on the effect so it persists across saves
	if effect.encounterCooldown > 0:
		effect.encounterCooldown -= 1
		return false

	# Encounter chance scales 20% → 60% with conditioning
	var chance = int(20.0 + (level / 1.25) * 40.0)
	if not RNG.chance(chance):
		return false

	# Need at least one NPC in the room
	var roomID = _args[0]
	var npcs = GM.main.IS.getPawnIDsAt(roomID)
	var candidates = []
	for nid in npcs:
		if nid != "pc":
			candidates.append(nid)
	if candidates.size() == 0:
		return false

	var npcID = RNG.pick(candidates)

	# Set cooldown — tightens as conditioning rises
	if   level < 0.50: effect.encounterCooldown = 5
	elif level < 0.75: effect.encounterCooldown = 4
	elif level < 1.00: effect.encounterCooldown = 3
	else:              effect.encounterCooldown = 2

	runScene("PuppyEncounterScene", [npcID])
	return true

func getPriority():
	return 10
