extends EventBase
# PuppyEncounterEvent
#
# Uses react() not run() -- fires after the current scene finishes.
#
# Skill tree effects:
#   LowProfile perk:   encounter chance -20 points
#   PerfectPet perk:   sex and leash walk weighted higher (NPCs more forward)
#   LeashBroken perk:  no effect on triggering, affects PuppyLeashWalkScene internally
#   ConditionedReflex: no effect on triggering, affects PuppyEncounterScene internally

func _init():
	id = "PuppyEncounterEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func react(_triggerID, _args):
	if GM.pc == null or GM.pc.getInventory() == null:
		return false
	if not GM.pc.getInventory().hasItemIDEquipped("puppy_restraints"):
		return false

	var effect = GM.pc.getEffect("puppy_conditioning")
	if effect == null:
		return false

	var level = effect.conditioningLevel
	if level < 0.25:
		return false

	if effect.encounterCooldown > 0:
		effect.encounterCooldown -= 1
		return false

	# Base chance 20% to 65% with conditioning
	var chance = int(20.0 + (level / 1.25) * 45.0)

	# LowProfile perk: -20 points
	if GM.pc.hasPerk("PuppyPerk_LowProfile"):
		chance -= 20

	if chance <= 0 or not RNG.chance(chance):
		return false

	var roomID = _args[0]
	var npcs   = GM.main.IS.getPawnIDsAt(roomID)
	var candidates = []
	for nid in npcs:
		if nid != "pc":
			candidates.append(nid)
	if candidates.size() == 0:
		return false

	var npcID  = RNG.pick(candidates)
	var stage  = _getStage(level)
	var hasPet = GM.pc.hasPerk("PuppyPerk_PerfectPet")

	# Set cooldown
	if   level < 0.50: effect.encounterCooldown = 5
	elif level < 0.75: effect.encounterCooldown = 4
	elif level < 1.00: effect.encounterCooldown = 3
	else:              effect.encounterCooldown = 2

	# Scene selection
	# PerfectPet perk: NPCs are more forward, so leash walk and sex weight up
	var leashChance    = 0
	if stage >= 4:
		leashChance = 50 if hasPet else 40
	elif stage >= 3:
		leashChance = 35 if hasPet else 25

	var sceneToRun = "PuppyEncounterScene"
	if leashChance > 0 and RNG.chance(leashChance):
		sceneToRun = "PuppyLeashWalkScene"

	runScene(sceneToRun, [npcID])
	return true

func _getStage(level: float) -> int:
	if   level >= 1.00: return 4
	elif level >= 0.75: return 3
	elif level >= 0.50: return 2
	elif level >= 0.25: return 1
	else:               return 0

func getPriority():
	return 10
