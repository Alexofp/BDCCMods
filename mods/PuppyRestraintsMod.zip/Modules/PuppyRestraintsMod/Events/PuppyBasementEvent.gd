extends EventBase

func _init():
	id = "PuppyBasementEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func run(_triggerID, _args):
	if GM.pc == null:
		return

	var loc  = GM.pc.location
	var worn = _wearingRestraints()

	match loc:
		"pup_basement_grooming":
			if worn:
				addButton("Use the grooming table", "Coming soon.", "noop")

		"pup_basement_training":
			if worn:
				addButton("Run the course", "Coming soon.", "noop")

		"pup_basement_kennel":
			addButton("Rest in one of the beds", "Coming soon.", "noop")

		"pup_basement_feedroom":
			addButton("Eat from a bowl", "Coming soon.", "noop")

		"pup_basement_hall":
			addButton("Examine the display cases", "Coming soon.", "noop")

func onButton(_method, _args):
	# All buttons are under construction -- do nothing
	pass

func getPriority():
	return 5

func _wearingRestraints() -> bool:
	if GM.pc == null or GM.pc.getInventory() == null:
		return false
	return GM.pc.getInventory().hasItemIDEquipped("puppy_restraints")
