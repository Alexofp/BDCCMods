extends EventBase
# PuppyPostureEvent — backup posture enforcer.
#
# Stage3D.play() is the primary fix (intercepts every playAnimation call).
# This event fires on Trigger.SceneAndStateHook (after each scene _run() completes)
# as a belt-and-suspenders fallback in case a scene bypasses Stage3D somehow.
#
# Priority 999 means it runs last, after any other hooks have fired.

func _init():
	id = "PuppyPostureEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook)

func run(_triggerID, _args):
	if GM.pc == null or GM.pc.getInventory() == null:
		return
	if not GM.pc.getInventory().hasItemIDEquipped("puppy_restraints"):
		return
	if GM.main == null or GM.main.sceneStack == null or GM.main.sceneStack.size() == 0:
		return

	var currentScene = GM.main.sceneStack.back()
	if currentScene == null:
		return

	# Find NPC in the scene (any character that isn't the player)
	var npc_id = ""
	if currentScene.get("currentCharactersVariants") != null:
		for charID in currentScene.currentCharactersVariants.keys():
			if charID != "pc":
				npc_id = charID
				break

	if npc_id != "":
		# PuppyDuo: NPC stands (doll/"pc" slot), player crawls (doll2/"npc" slot, paw)
		GM.main.playAnimation(StageScene.PuppyDuo, "stand", {"pc": npc_id, "npc": "pc", "npcAction": "paw"})
	else:
		GM.main.playAnimation(StageScene.PuppySolo, "paw")

func getPriority():
	return 999

func onButton(_method, _args):
	pass
