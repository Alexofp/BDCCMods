extends SkillBase
# PuppyConditioningSkill
#
# Tracks how practiced the player is at living in puppy restraints.
# XP is earned by:
#   - Wearing restraints over time (awarded by PuppyConditioning status effect)
#   - Completing NPC encounters (awarded by PuppyEncounterScene)
#   - Completing leash walks (awarded by PuppyLeashWalkScene)
#   - Sex scenes triggered via encounters (awarded by PuppyEncounterScene)
#
# Three tiers, unlocking at levels 0, 5, and 10.
# Level cap 20 (plenty of room for all perks without grinding forever).

func _init():
	id = "PuppyConditioning"

func getVisibleName():
	return "Puppy Conditioning"

func getShortName():
	return "Pup"

func getVisibleDescription():
	return "Measures how deeply the puppy restraints have shaped your instincts and body."

func getPerkTiers():
	return [
		[0],   # Tier 0: available immediately
		[5],   # Tier 1: unlocks at level 5
		[10],  # Tier 2: unlocks at level 10
	]

func getLevelCap():
	return 20

static func alwaysVisible() -> bool:
	return false
