extends ItemBase

func _init():
	id = "puppy_restraints"

func getVisibleName():
	return "Puppy Restraints"

func getDescription():
	var conditioning = 0.0
	if GM.pc != null:
		var effect = GM.pc.getEffect("puppy_conditioning")
		if effect != null:
			conditioning = effect.conditioningLevel
	var pct = int(conditioning * 100.0)
	return ("A full set of padded puppy restraints: arm binder mitts, knee-guards, "
		+ "collar and tail harness. Keeps the wearer on all fours.\n\n"
		+ "Arms bound, hands blocked, legs restrained — no attacks except biting.\n"
		+ "[color=yellow]Puppy Conditioning: " + str(pct) + "%[/color]")

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		buff(Buff.BlockedHandsBuff),
		buff(Buff.RestrainedArmsBuff),
		buff(Buff.RestrainedLegsBuff),    # blocks Kick/KickToBalls/StrongKick in combat
		buff(Buff.AmbientLustBuff, [15]),
	]

func getTakeOffScene():
	return "RestraintTakeOffNopeScene"

func getPrice():
	return 150

func getSellPrice():
	return 30

func canSell():
	return true

func getTags():
	return [
		ItemTag.BDSMRestraint,
		ItemTag.SoldByTheAnnouncer,
		ItemTag.CanBeForcedByGuards,
		ItemTag.CanBeForcedInStocks,
	]

func isRestraint():
	return true

func generateRestraintData():
	restraintData = RestraintStraitjacket.new()
	restraintData.setLevel(3)

func getRiggedParts(_character):
	return {
		"PuppyGear": "res://Inventory/RiggedModels/PuppyRestraints/PuppyRestraints.tscn",
	}

func updateDoll(doll: Doll3D):
	doll.setArmsPuppy(true)
	doll.setLegsPuppy(true)

func getTakingOffStringLong(withS):
	if withS:
		return "unbuckles the puppy restraints and helps you out of them"
	else:
		return "unbuckle the puppy restraints and climb out of them"

func getPuttingOnStringLong(withS):
	if withS:
		return "straps the puppy restraints onto you, buckling each piece tightly"
	else:
		return "strap the puppy restraints on, buckling each piece tightly"

func getForcedOnMessage(isPlayer = true):
	if isPlayer:
		return "The puppy restraints were strapped onto you. You drop to all fours."
	else:
		return "The puppy restraints were strapped onto {receiver.name}."

func getAIForceItemWeight(_whoForcesNpc, _targetNpc):
	return 0.15

func getInventoryImage():
	return null
