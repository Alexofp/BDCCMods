extends SubGameWorld
# PuppyBasement floor logic.
# Does NOT add any buttons here -- scene-launching buttons must go through
# EventBase.addButton() -> EVENTSYSTEM_BUTTON -> onButton(), which fires safely
# from WorldScene._react(). See PuppyBasementEvent.gd for all room buttons.
#
# Only immediate state changes (setLocation + reRun) are safe to do from
# onReact/onEnter. We use that for the emergency exit and the water bowl.

func _on_RestKennel_onEnter(_room):
	GM.ui.addButton("Drink from the bowl", "The water is clean and cold.", "roomCallback", ["pup_basement_kennel", "drink"])

func _on_RestKennel_onReact(_room, key):
	if key == "drink":
		if GM.pc != null:
			GM.pc.addLust(-10)
			GM.pc.addStamina(20)
		GM.main.addMessage("[color=gray]The water is cold and clean. You feel more alert.[/color]")
		GM.main.reRun()

func _on_GrandHall_onEnter(_room):
	GM.ui.addButton("Use emergency exit", "Green-lit hatch near the floor. Opens from this side.", "roomCallback", ["pup_basement_hall", "exit_hatch"])

func _on_GrandHall_onReact(_room, key):
	if key == "exit_hatch":
		GM.pc.setLocation("hall_elevator")
		GM.main.reRun()
