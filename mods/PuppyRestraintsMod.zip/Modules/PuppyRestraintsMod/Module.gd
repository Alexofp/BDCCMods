extends Module

func _init():
	id     = "PuppyRestraintsMod"
	author = "PuppyRestraintsMod"

	items = [
		"res://Modules/PuppyRestraintsMod/Items/PuppyRestraints.gd",
	]

	statusEffects = [
		"res://Modules/PuppyRestraintsMod/StatusEffects/PuppyConditioning.gd",
	]

	events = [
		"res://Modules/PuppyRestraintsMod/Events/PuppyPostureEvent.gd",
		"res://Modules/PuppyRestraintsMod/Events/PuppyEncounterEvent.gd",
	]

	scenes = [
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyEncounterScene.gd",
	]
