extends Module

func _init():
	id     = "PuppyRestraintsMod"
	author = "PuppyRestraintsMod"

	items = [
		"res://Modules/PuppyRestraintsMod/Items/PuppyRestraints.gd",
	]

	statusEffects = [
		"res://Modules/PuppyRestraintsMod/StatusEffects/PuppyConditioning.gd",
	]

	events = [
		"res://Modules/PuppyRestraintsMod/Events/PuppyPostureEvent.gd",
		"res://Modules/PuppyRestraintsMod/Events/PuppyEncounterEvent.gd",
		"res://Modules/PuppyRestraintsMod/Events/PuppyBasementEvent.gd",
	]

	scenes = [
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyEncounterScene.gd",
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyLeashWalkScene.gd",
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyGroomScene.gd",
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyRestScene.gd",
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyFeedScene.gd",
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyTrainScene.gd",
		"res://Modules/PuppyRestraintsMod/Scenes/PuppyDisplayCasesScene.gd",
	]

	skills = [
		"res://Modules/PuppyRestraintsMod/Skills/PuppyConditioningSkill.gd",
	]

	perks = [
		"res://Modules/PuppyRestraintsMod/Perks/T0_PupsInstincts.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T0_LowProfile.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T1_ConditionedReflex.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T1_GoodPup.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T1_LeashBroken.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T2_BrokenIn.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T2_PackMentality.gd",
		"res://Modules/PuppyRestraintsMod/Perks/T2_PerfectPet.gd",
	]

func register():
	.register()
	GlobalRegistry.registerMapFloor(
		"PuppyBasement",
		"res://Modules/PuppyRestraintsMod/World/BasementFloor.tscn"
	)

func getFlags():
	return {
		"GoodPupActive": flag(FlagType.Bool),
	}

func resetFlagsOnNewDay():
	setFlag("PuppyRestraintsMod.GoodPupActive", false)
