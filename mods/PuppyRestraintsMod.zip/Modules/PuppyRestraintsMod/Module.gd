extends Module

func _init():
	id     = "PuppyRestraintsMod"
	author = "PuppyRestraintsMod"

	items = [
		"res://Modules/PuppyRestraintsMod/Items/PuppyRestraints.gd",
	]
