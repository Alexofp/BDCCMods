extends PerkBase
# Tier 0 - Low Profile
# Reduces the chance of NPC encounters triggering.
# Stored as a module flag read by PuppyEncounterEvent.

func _init():
	id = "PuppyPerk_LowProfile"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Low Profile"

func getVisibleDescription():
	return "You have learned to move quietly and avoid drawing attention. NPCs are less likely to stop you."

func getMoreDescription():
	return "Reduces NPC encounter chance by 20 percentage points."

func getSkillTier():
	return 0

func getCost():
	return 1

func getPicture():
	return "res://Images/Perks/avoidance.png"
