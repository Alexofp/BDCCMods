extends PerkBase

func _init():
	id = "PuppyPerk_PerfectPet"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Perfect Pet"

func getVisibleDescription():
	return "You have internalised every lesson. NPCs recognise a fully trained pup when they see one, and treat you accordingly."

func getMoreDescription():
	return "+15 lust armor at stage 4+ conditioning.\nNPCs in encounters use a warmer tone at all stages.\nRequires: Good Pup and Pup's Instincts."

func getSkillTier():
	return 2

func getCost():
	return 3

func getRequiredPerks():
	return ["PuppyPerk_GoodPup", "PuppyPerk_PupsInstincts"]

func getPicture():
	return "res://Images/Perks/locked-heart.png"

func getBuffs():
	if npc == null:
		return []
	var e = npc.getEffect("puppy_conditioning")
	if e == null or e.conditioningLevel < 1.0:
		return []
	return [
		buff(Buff.LustArmorBuff, [15]),
	]
