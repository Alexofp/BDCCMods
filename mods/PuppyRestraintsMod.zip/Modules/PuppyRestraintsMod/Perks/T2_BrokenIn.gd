extends PerkBase

func _init():
	id = "PuppyPerk_BrokenIn"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Broken In"

func getVisibleDescription():
	return "At this point your body has fully adapted. What would exhaust others sustains you."

func getMoreDescription():
	return "+25 max stamina while conditioning is at stage 4 or above (100%+).\nRequires: Good Pup."

func getSkillTier():
	return 2

func getCost():
	return 3

func getRequiredPerks():
	return ["PuppyPerk_GoodPup"]

func getPicture():
	return "res://Images/Perks/andromeda-chain.png"

func getBuffs():
	if npc == null:
		return []
	var e = npc.getEffect("puppy_conditioning")
	if e == null or e.conditioningLevel < 1.0:
		return []
	return [
		buff(Buff.MaxStaminaBuff, [25]),
	]
