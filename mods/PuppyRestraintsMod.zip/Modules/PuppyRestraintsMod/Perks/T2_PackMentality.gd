extends PerkBase
# Tier 2 - Pack Mentality
# Conditioning decays 25% slower when restraints are off.
# Implemented by PuppyConditioning.processTime() checking hasPerk.
# Also gives +25% PuppyConditioning skill XP gain via SkillExperienceBuff.
# Requires: Conditioned Reflex.

func _init():
	id = "PuppyPerk_PackMentality"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Pack Mentality"

func getVisibleDescription():
	return "The conditioning runs deeper than the restraints. When you take them off, you do not forget as quickly."

func getMoreDescription():
	return "Conditioning decays 25% slower when restraints are not worn.\n+25% PuppyConditioning skill experience gain.\nRequires: Conditioned Reflex."

func getSkillTier():
	return 2

func getCost():
	return 3

func getRequiredPerks():
	return ["PuppyPerk_ConditionedReflex"]

func getPicture():
	return "res://Images/Perks/chained-heart.png"

func getBuffs():
	if npc == null:
		return []
	return [
		buff(Buff.SkillExperienceBuff, ["PuppyConditioning", 25]),
	]
