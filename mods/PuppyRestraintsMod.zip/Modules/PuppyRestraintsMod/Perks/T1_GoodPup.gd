extends PerkBase
# Tier 1 - Good Pup
# Completing encounters without refusing gives +20 max stamina for the day.
# PuppyEncounterScene sets "PuppyRestraintsMod.GoodPupActive" flag on pleased endings.
# PuppyConditioning.processTime clears it on new day.

func _init():
	id = "PuppyPerk_GoodPup"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Good Pup"

func getVisibleDescription():
	return "Obedience has its rewards. Completing an encounter without refusing leaves you energised for the rest of the day."

func getMoreDescription():
	return "+20 max stamina for the day after completing an encounter without refusing.\nRequires: Pup's Instincts."

func getSkillTier():
	return 1

func getCost():
	return 2

func getRequiredPerks():
	return ["PuppyPerk_PupsInstincts"]

func getPicture():
	return "res://Images/Perks/hearts.png"

func getBuffs():
	if npc == null:
		return []
	if not GM.main.getFlag("PuppyRestraintsMod.GoodPupActive", false):
		return []
	return [
		buff(Buff.MaxStaminaBuff, [20]),
	]
