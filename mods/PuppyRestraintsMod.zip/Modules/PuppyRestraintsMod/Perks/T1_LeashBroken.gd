extends PerkBase
# Tier 1 - Leash Broken
# During a leash walk the player gets a small chance each step to break away.
# PuppyLeashWalkScene checks hasPerk("PuppyPerk_LeashBroken") before offering the button.
# Requires: Low Profile.

func _init():
	id = "PuppyPerk_LeashBroken"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Leash Broken"

func getVisibleDescription():
	return "You have learned to read the slack in the leash. Sometimes you can slip free before the walk ends."

func getMoreDescription():
	return "Each step during a leash walk has a 30% chance to show an Escape button.\nRequires: Low Profile."

func getSkillTier():
	return 1

func getCost():
	return 2

func getRequiredPerks():
	return ["PuppyPerk_LowProfile"]

func getPicture():
	return "res://Images/Perks/breaking-chain.png"
