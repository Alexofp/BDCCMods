extends PerkBase

func _init():
	id = "PuppyPerk_PupsInstincts"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Pup's Instincts"

func getVisibleDescription():
	return "The all-fours posture has sharpened every nerve. Your body is more sensitive, and your bite draws blood more easily and hits harder."

func getMoreDescription():
	return "+15 sensitivity.\nBite: +4 damage, bleeding triggers on a lower threshold."

func getSkillTier():
	return 0

func getCost():
	return 1

func getPicture():
	return "res://Images/Perks/fangs.png"

func getBuffs():
	return [
		buff(Buff.SensitivityGainBuff, [15]),
	]
