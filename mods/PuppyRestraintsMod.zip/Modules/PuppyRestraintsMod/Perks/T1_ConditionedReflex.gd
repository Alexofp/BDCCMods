extends PerkBase
# Tier 1 - Conditioned Reflex
# Halves the lust penalty for refusing encounters at stages 2 and 3.
# PuppyEncounterScene checks hasPerk("PuppyPerk_ConditionedReflex") before applying cost.

func _init():
	id = "PuppyPerk_ConditionedReflex"
	skillGroup = "PuppyConditioning"

func getVisibleName():
	return "Conditioned Reflex"

func getVisibleDescription():
	return "You have practiced resisting. Saying no still costs you, but your body has learned to fight the urge more efficiently."

func getMoreDescription():
	return "Lust penalty for refusing NPC encounters is halved.\nRequires: Low Profile."

func getSkillTier():
	return 1

func getCost():
	return 2

func getRequiredPerks():
	return ["PuppyPerk_LowProfile"]

func getPicture():
	return "res://Images/Perks/breaking-chain.png"
