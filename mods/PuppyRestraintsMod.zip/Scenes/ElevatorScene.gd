extends "res://Scenes/SceneBase.gd"
# PuppyRestraintsMod override of ElevatorScene.gd
#
# When puppy restraints are worn the player cannot reach the panel buttons.
# They must wait for another inmate to enter and ask them to press a floor.
#
# RULE: _run() only renders UI. All setState() calls live in _react() only.
#
# NPC behaviour scales with PuppyConditioning stage:
#   Stage 0-2: NPC is helpful, player chooses the floor freely.
#   Stage 3:   40% chance NPC picks the floor themselves.
#   Stage 4+:  NPC always picks. Player has no say.

func _init():
	sceneID = "ElevatorScene"

const FLOORS = [
	["Cellblock",  "hall_elevator",   "Main level where all the inmate cells are"],
	["Mineshafts", "mining_elevator", "Lower level where the prison is attached to an asteroid"],
	["Medical",    "med_elevator",    "Floor that has all the medical and science facilities"],
]

var _npc2ID:   String = ""
var _npc2             = null
var _destRoom: String = ""
# Outcome of the NPC stage check, set in _react before calling setState("npc_arrived")
var _npcForces: bool  = false
var _waitTicks: int   = 0   # increments 3 min per tick; "Make noise" shows at 10 (30 min)

func resolveCustomCharacterName(_charID):
	if _charID == "npc2":
		return _npc2ID

# ── helpers ──────────────────────────────────────────────────────────────────

func _isWearingRestraints() -> bool:
	if GM.pc == null or GM.pc.getInventory() == null:
		return false
	return GM.pc.getInventory().hasItemIDEquipped("puppy_restraints")

func _conditioning() -> float:
	if GM.pc == null:
		return 0.0
	var e = GM.pc.getEffect("puppy_conditioning")
	return e.conditioningLevel if e != null else 0.0

func _stage() -> int:
	var l = _conditioning()
	if   l >= 1.25: return 5
	elif l >= 1.00: return 4
	elif l >= 0.75: return 3
	elif l >= 0.50: return 2
	elif l >= 0.25: return 1
	else:           return 0

func _registerNPC(npcID: String):
	_npc2ID    = npcID
	_npc2      = getCharacter(npcID)
	addCharacter(npcID)
	var s      = _stage()
	# Stage 5: always forces; stage 4: always forces; stage 3: 40% chance
	_npcForces = (s >= 4) or (s >= 3 and RNG.chance(40))

func _npcsHere() -> Array:
	var all = GM.main.IS.getPawnIDsAt(GM.pc.location)
	var result = []
	for nid in all:
		if nid != "pc":
			result.append(nid)
	return result

func _randomDestFloor() -> String:
	var options = []
	for fl in FLOORS:
		if fl[1] != GM.pc.location:
			options.append(fl[1])
	if options.size() == 0:
		return FLOORS[0][1]
	return RNG.pick(options)

func _addFloorButtons():
	for fl in FLOORS:
		if fl[1] == GM.pc.location:
			addDisabledButton(fl[0], "You are already here")
		else:
			addButton(fl[0], fl[2], "ask_floor", [fl[1]])
	addButton("Get out", "Never mind.", "endthescene")

# ── _run: render only, no setState, no logic ─────────────────────────────────

func _run():

	# ── Normal path (no restraints) ───────────────────────────────────────
	if state == "":
		if not _isWearingRestraints():
			saynn("You enter the lift and look at the panel, your inmate access allows you to go only to certain floors")
			saynn("Where do you want the lift to go?")
			for fl in FLOORS:
				if fl[1] == GM.pc.location:
					addDisabledButton(fl[0], "You are already here")
				else:
					addButton(fl[0], fl[2], "gofloor", [fl[1]])
			GM.ES.triggerRun(Trigger.InsideElevator)
			addButton("Get out", "You don't feel like going anywhere", "endthescene")
			return

		# Restraints: can't reach the panel
		saynn("You crawl into the lift. The panel is mounted at standing height.")
		saynn("You paw at the buttons uselessly. There is no way you can reach them.")
		# At stage 5 (125%+), being on all fours puts eyes level with the panel bottom
		if _stage() >= 5:
			saynn("[color=gray]This low down, your eyes are level with the bottom of the panel. There is a small unmarked button near the floor -- lower than all the others, almost flush with the housing. No label.[/color]")
			addButton("Press the unmarked button [Under Construction]", "There is somewhere down there. Coming soon.", "noop_basement")
		addButton("Wait for someone", "Maybe someone will come.", "check_npc")
		addButton("Get out", "Give up.", "endthescene")

	# ── Waiting: nobody here yet ──────────────────────────────────────────
	if state == "waiting":
		saynn("You sit back on your haunches and wait. The lift hums quietly. Nobody comes.")
		addButton("Keep waiting", "Time passes.", "wait_tick")
		addButton("Make noise", "Bark, scratch, do anything to get attention.", "make_noise")
		addButton("Get out", "Give up. Walk.", "endthescene")

	# ── NPC arrived, player chooses floor ────────────────────────────────
	if state == "npc_arrived":
		if _npc2ID != "":
			setCharactersEasyList([_npc2ID])
			playAnimation(StageScene.PuppyDuo, "stand", {pc=_npc2ID, npc="pc"})
		saynn("The doors slide open. Someone steps in.")
		if _npcForces:
			saynn("{npc2.name} sees you and glances at the panel.")
			var s = _stage()
			if s >= 4:
				saynn("{npc2.name} presses a button without a word. You have no idea which floor.")
				addButton("...", "You have no say.", "do_forced_floor")
			else:
				saynn("[say=npc2]" + RNG.pick([
					"I'll pick your floor.",
					"You're not in a position to choose, are you.",
					"Let me handle that.",
				]) + "[/say]")
				addButton("...", "You have no choice.", "do_forced_floor")
		else:
			saynn("{npc2.name} notices you pawing uselessly at the panel.")
			saynn("[say=npc2]" + RNG.pick([
				"Can't reach? Here, which floor do you need?",
				"Oh. Let me help. Where are you going?",
				"Need a hand? Which floor?",
			]) + "[/say]")
			_addFloorButtons()

	# ── NPC pressed the floor the player chose ────────────────────────────
	if state == "floor_chosen":
		if _npc2ID != "":
			playAnimation(StageScene.PuppyDuo, "stand", {pc=_npc2ID, npc="pc"})
		saynn("{npc2.name} presses the button for you.")
		saynn("With a screeching noise, the doors close and the lift begins to move.")
		saynn("You lean against the wall and wait. Eventually the doors open.")
		addButton("Step out", "", "endthescene")

	# ── NPC forced a floor ────────────────────────────────────────────────
	if state == "floor_forced":
		saynn("The lift moves. When the doors open you recognise where you are.")
		addButton("Step out", "", "endthescene")

	# ── Normal travel narration ───────────────────────────────────────────
	if state == "gofloor":
		saynn("With a screeching noise, the doors close and the lift begins to move towards some other floor")
		saynn("You lean against one of the walls and just wait for the lift to arrive which it eventually does")
		addButton("Continue", "Step out of the lift", "endthescene")

# ── _react: all logic and setState calls live here ────────────────────────────

func _react(_action: String, _args):

	if _action == "endthescene":
		endScene()
		return

	# Normal floor travel (no restraints)
	if _action == "gofloor":
		processTime(5 * 60)
		GM.pc.setLocation(_args[0])
		aimCamera(_args[0])
		setState("gofloor")
		return

	# Check if an NPC is present -- decide what happens, then setState
	if _action == "noop_basement":
		return

	if _action == "check_npc" or _action == "wait_tick":
		if _action == "wait_tick":
			processTime(3 * 60)
		var npcs = _npcsHere()
		if npcs.size() == 0:
			setState("waiting")
			return
		# NPC found -- register them and decide if they force the floor
		_registerNPC(npcs[0])
		setState("npc_arrived")
		return

	if _action == "make_noise":
		# Search nearby rooms (up to 5 steps) for any non-PC NPC
		var nearby = GM.main.IS.getPawnIDsNear(GM.pc.location, 5)
		var candidates = []
		for nid in nearby:
			if nid != "pc":
				candidates.append(nid)
		if candidates.size() == 0:
			# Nobody nearby -- search the entire IS
			for pawnID in GM.main.IS.getPawns().keys():
				if pawnID != "pc":
					candidates.append(pawnID)
		if candidates.size() == 0:
			GM.main.addMessage("[color=gray]Your noise echoes unanswered through empty corridors.[/color]")
			setState("waiting")
			return
		var npcID = RNG.pick(candidates)
		# Teleport them into the elevator
		var pawn = GM.main.IS.getPawn(npcID)
		if pawn != null:
			pawn.setLocation(GM.pc.location)
		_registerNPC(npcID)
		GM.main.addMessage("[color=gray]Your noise draws attention. Someone comes.[/color]")
		setState("npc_arrived")
		return

	# Player chose a floor, NPC presses it
	if _action == "ask_floor":
		_destRoom = _args[0]
		processTime(5 * 60)
		GM.pc.setLocation(_destRoom)
		aimCamera(_destRoom)
		setState("floor_chosen")
		return

	# NPC forced a random floor
	if _action == "do_forced_floor":
		_destRoom = _randomDestFloor()
		processTime(5 * 60)
		GM.pc.setLocation(_destRoom)
		aimCamera(_destRoom)
		setState("floor_forced")
		return

	setState(_action)

func supportsShowingPawns() -> bool:
	return true
