extends Attack
# PuppyRestraintsMod override of BitePCAttack.gd
#
# Adds a bonus to bite damage when the player has the PuppyPerk_PupsInstincts perk.
# All other behavior is identical to the original.

func _init():
	id = "BitePCAttack"
	category = Category.Special
	aiCategory = AICategory.Offensive

func getVisibleName(_context = {}):
	return "Bite"

func getVisibleDesc(_context = {}):
	var base = "Bite them for "+scaledDmgRangeStr(DamageType.Physical, 8, 14)+" damage.\n\nMay cause bleeding."
	if npc != null and npc.hasPerk("PuppyPerk_PupsInstincts"):
		base += "\n[color=yellow]Pup's Instincts: +4 damage, bleeding threshold lowered.[/color]"
	return base

func _doAttack(_attacker, _receiver, _context = {}):
	var hasInstincts = _attacker.hasPerk("PuppyPerk_PupsInstincts")

	if checkMissed(_attacker, _receiver, DamageType.Physical):
		return genericMissMessage(_attacker, _receiver, "bite")

	if checkDodged(_attacker, _receiver, DamageType.Physical):
		return genericDodgeMessage(_attacker, _receiver, "bite")

	var texts = [
		"{attacker.name} bites {receiver.name}.",
		"{attacker.name} sinks {attacker.his} teeth into {receiver.name}.",
	]
	var text = RNG.pick(texts)

	var minDmg = 8
	var maxDmg = 14
	if hasInstincts:
		minDmg += 4
		maxDmg += 4

	var dmg = RNG.randi_range(minDmg, maxDmg)

	# Bleeding threshold: 50% normally, 30% with perk
	var bleedChance = 30 if hasInstincts else 50
	if RNG.chance(100 - bleedChance):
		if _receiver.addEffect(StatusEffect.Bleeding):
			text += "\n[b]{receiver.name} is bleeding![/b]"

	return {
		text = text,
		pain = dmg,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return true

func getRequirements():
	return [AttackRequirement.CanBite]

func getAnticipationText(_attacker, _receiver):
	return "{attacker.name} bares {attacker.his} fangs and then suddenly lunges at you!"

func getAttackSoloAnimation():
	return "bite"

func getExperience():
	return [[Skill.Combat, 5]]
