extends EventBase

func _init():
	id = "QuinnAppleEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "med_lobbymain")
	

func run(_triggerID, _args):
	if(checkCharacterBusy("ElizaBusy", "She isn't here", "Dr. Quinn")):
		return
	
	if(getFlag("MedicalModule.Mental_PlayerEscaped") || getFlag("MedicalModule.Eliza_BusyDays", 0) > 0):
		addDisabledButton("Coward", "She is not here")
		return
	
	if GM.pc.getInventory().hasItemID("appleitem"):
		if GM.pc.hasEffect("KeepDrAway") or GM.pc.hasEffect("AppleThrowCooldown"):
			addDisabledButton("She gets a pass","For now")
		else:
			addButtonUnlessLate("An apple a day...", "Throw an apple at that bitch", "throwAppleQuinn")
		return
	
	addDisabledButton("You win this time","You don't have an apple to throw")
	

func getPriority():
	return 0
	

func onButton(_method, _args):
	if(_method == "throwAppleQuinn"):
		GM.pc.getInventory().removeXOfOrDestroy("appleitem",1)
		
		addMessage("You throw an apple at Dr. Quinn" + (" with such force that it breaks on impact with the "+RNG.pick(["desk","wall"]) if GM.pc.getStat(Stat.Strength)>=10 else "")+"\nShe hisses and ducks under her desk, before cautiously emerging a few moments later")
		
		GM.pc.addEffect("KeepDrAway", [60*60*3])
		
		GM.pc.addPain(-30)
		GM.pc.addSkillExperience("AppliedKnowledge", 35)
		GM.main.processTime(60)
		
		increaseModuleFlag("MedicalModule", "Eliza_BusyDays", 1)
	
