extends EventBase

func _init():
	id = "StoveEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringPlayerCell)

func run(_triggerID, _args):
	if !GlobalRegistry.getModules().has("CraftingLibReworked"):
		return
	var mod : Module = getModule("AnAppleADay")
	
	if(mod.hasStove()):
		addButton("Stove","We need to cook","cookmenu")
		return
	
	if(mod.canGetStove()):
		addButtonUnlessLate("Build stove", "It's time", "build", [], "They're sleeping")
		return
	
	elif GM.pc.getInventory().hasItemID("appleitem"):
		addButton("Store apples", "You're only just getting started", "storeapples")
	
	if(!mod.hasStove()):
		var apps = getFlag("AnAppleADay.storedApples", 0)
		if apps>0:
			saynn("There "+("are "+str(apps)+" apples" if apps>1 else "is 1 apple")+" stored here. You need "+str(mod.getStoveCost())+".")

func onButton(_method, _args):
	if _method == "cookmenu":
		runScene("StoveScene",[],"cellStove")
	elif _method == "build":
		runScene("BuildStoveScene")
	elif _method == "storeapples":
		addMessage("You stored an apple in your cell")
		GM.pc.getInventory().removeXOfOrDestroy("appleitem",1)
		increaseFlag("AnAppleADay.storedApples",1)


func getPriority():
	return 0
