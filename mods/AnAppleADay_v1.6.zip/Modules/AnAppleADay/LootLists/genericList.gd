extends LootList

# pies n apples

func _init():
	handlesIds = ["guard", "inmate", "engineer"]

func getLoot(_id, _characterID, _battleName):
	if(GM.pc == null || !is_instance_valid(GM.pc)):
		return []
	
	var chanceMod:float = 1.0
	if _id=="engineer":
		chanceMod+=0.2
	elif _id=="guard":
		chanceMod-=0.1
	

	chanceMod = clamp(chanceMod, 0.0, 1.0)
	
	return [
		[10.0*chanceMod, [["appletart", 1]]],
		[15.0*chanceMod, [["appleitem", 1]]],
		[7.5*chanceMod, [["appleitem", 1,2]]],
		[5.0*chanceMod,[["applepie",1]]],
		[1.0*chanceMod, [["appleitem", 3, 5]]], # jackpot
		[3.0*chanceMod, [["applecreampie",1]]]
	]
