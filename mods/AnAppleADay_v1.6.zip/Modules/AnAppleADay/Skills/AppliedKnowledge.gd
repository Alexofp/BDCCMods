extends SkillBase

func _init():
	id = "AppliedKnowledge"

func getVisibleName():
	return "Apple-ied Knowledge"

func getVisibleDescription():
	return "A measure of your know-how and passion for apples"

func getPerkTiers():
	return [
		[0],
		[3],
#		[10],
	]
