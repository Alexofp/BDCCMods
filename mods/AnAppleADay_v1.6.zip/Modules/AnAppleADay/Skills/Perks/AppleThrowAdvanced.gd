extends PerkBase

func _init():
	id = "AppleThrowAdvanced"
	skillGroup = "AppliedKnowledge"

func getVisibleName():
	return "Proverb disregard"

func getVisibleDescription():
	return "You can now throw apples at anyone."

func getMoreDescription():
	return "You, being the little rebel that you are, have decided to ignore the stereotype that apples are only to be hurled at medical personnel, and are now able to force anyone to taste your big red balls."

func getRequiredPerks():
	return ["AppleThrowBasic"]

func getSkillTier():
	return 1

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func addsAttacks():
	return []
