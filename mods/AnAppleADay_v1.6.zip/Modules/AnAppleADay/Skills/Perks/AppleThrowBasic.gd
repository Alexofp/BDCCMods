extends PerkBase

func _init():
	id = "AppleThrowBasic"
	skillGroup = "AppliedKnowledge"

func getVisibleName():
	return "Apple hurl"

func getVisibleDescription():
	return "You gain the ability to throw apples at nurses."

func getMoreDescription():
	return "Your consistent training throwing apples at Dr. Quinn has given you the ability to throw apples at any nurse.\nYou're not exactly sure why you can only throw apples at nurses, though. Maybe you just need more practice."

func getRequiredPerks():
	return []

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func addsAttacks():
	return ["AppleThrowAttack"]
