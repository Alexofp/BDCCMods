extends PerkBase

func _init():
	id = "AppleToTheKnee"
	skillGroup = "AppliedKnowledge"

func getVisibleName():
	return "Kneel before me"

func getVisibleDescription():
	return "Your apples now have a chance to hit someone in the knee, making them fall down and doing extra damage."

func getMoreDescription():
	return "Throwing apples during battle is fun, sure, but not very effective. The best way to remedy that, of course, is to make sure your opponent gets to kiss the ground a few times to remember their place. If anything, it should at least lower their confidence a bit."

func getRequiredPerks():
	return ["AppleThrowBasic"]

func getSkillTier():
	return 1

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func addsAttacks():
	return []
