extends Attack

func _init():
	id = "AppleThrowAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
#	isPlayerAttack = true
	attackPriority = 5
	
func getVisibleName(_context = {}):
	return "Throw apple"
	
func getVisibleDesc(_context = {}):
	return "Throw an apple at your opponent, causing "+scaledDmgRangeStr(DamageType.Physical,8,15)+" damage, with a 30% chance of dealing double damage.\nRequires an apple."
	
func _doAttack(_attacker, _receiver, _context = {}):
	_attacker.getInventory().removeXOfOrDestroy("appleitem",1)
#	var attModTags : Dictionary = _attacker.getModularDialogueTags(_receiver)
	var recModTags : Dictionary = _receiver.getModularDialogueTags(_attacker)
	if(checkMissed(_attacker, _receiver, DamageType.Physical, 1.0)):
		var bu = "Bless you." # generic
		if recModTags.keys().size()>0:
			match recModTags.keys()[0]:
				"subby":
					bu = RNG.pick( (["B-bless you..","U-um.. get well soon?..","W-we could stop if you're too sick.."] if _receiver.getLustLevel()<0.5 else ["U-um.. Bless you..!","Ngh~.. Bless you~.."]) )
				"dommy":
					bu = "Someone's thinking of you."+(" Can't blame them~." if _receiver.getLustLevel()>=0.5 else "")
				"mean":
					bu = "Bless you, sickly "+RNG.pick(["slut","bitch","fuck"])+"."
		var txt = RNG.pick([
			"{attacker.name} throws an apple at {receiver.name} but it misses because {attacker.he} {attacker.isAre} busy thinking about "+("apples" if _attacker.getLustLevel()<0.5 else "{_receiver.name}")+" and didn't aim well",
			"{attacker.nameS} apple flies magestically through the air towards {receiver.name}, but {receiver.he} {receiver.verb('duck')} to scratch {receiver.his} itchy leg, causing it to miss {receiver.him} completely",
			"{attacker.name} prepares to throw an apple at {receiver.name}, but {attacker.he} {attacker.verb('sneeze')} while throwing it and {attacker.verb('miss','misses')}. {receiver.name} is kind enough to say "+_receiver.formatSay(bu)
		])
		return {
			text = txt,
			missed = true,
		}
	
	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		var txt =  RNG.pick([
			"{attacker.name} hurls an apple in the direction of {receiver.name} masterfully, but {receiver.he} {receiver.verb('catch','catches')} it in the air and {receiver.verb('crush','crushes')} it between {receiver.his} "+("{receiver.masc}" if RNG.chance(50) else "{receiver.thick}")+" thighs"+( " while looking at {attacker.name} seductively" if +_receiver.getLustLevel()>=0.5 else ""),
			"{attacker.nameS} apple flies straight into {receiver.nameS} face, but {receiver.he} {receiver.verb('jump')} into the air and {receiver.verb('kick')} it at a nearby wall instead",
			"{attacker.name} starts spinning faster and faster before launching an apple at {receiver.name}, who, in {receiver.his} attempt to dodge it, trips and falls, and actually dodges it"
		])
		return {
			text = txt,
			dodged = true,
		}

	var texts = [
		"{attacker.name} throws an apple at {receiver.name}.",
		"{attacker.name} turns away for a bit, before suddenly facing towards {receiver.name} and hurling an apple at {receiver.him}."
	]
	
	var text = RNG.pick(texts)
	
	var mult = 1.0
	if RNG.chance(30):
		text+="\nThe pure passion in {attacker.nameS} throw will make the apple hurt even more!"
		mult += 1
	
	if(RNG.chance(20) && !_receiver.hasEffect(StatusEffect.Collapsed)) && _attacker.hasPerk("AppleToTheKnee"):
		if(_receiver.addEffect(StatusEffect.Collapsed)):
			mult += 0.5
			text += "\nThe apple hits {receiver.name} right in {receiver.his} knee, [b]making {receiver.him} collapse onto the floor[/b]!"
	
	
	return {
		text = text,
		pain = RNG.randi_range(int(8*mult), int(15*mult)),
	}
	
func _canUse(_attacker, _receiver, _context = {}):
	if !(_attacker.hasPerk("AppleThrowBasic") && _attacker.getInventory().hasItemID("appleitem")):
		return false
	return _receiver.getCharType()==CharacterType.Nurse or _attacker.hasPerk("AppleThrowAdvanced")
	

func getRequirements():
	return [AttackRequirement.FreeArms,AttackRequirement.FreeHands]

func getAnticipationText(_attacker, _receiver):
	return "{attacker.name} produces an apple and raises {attacker.his} arm behind {attacker.him}, preparing to throw it at you!"

func getAttackSoloAnimation():
	return "throw"

func getExperience():
	return [["AppliedKnowledge", 10]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 3.0
