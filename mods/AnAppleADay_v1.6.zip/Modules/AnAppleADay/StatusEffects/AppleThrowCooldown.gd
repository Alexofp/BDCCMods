extends StatusEffectBase

func _init():
	id = "AppleThrowCooldown"
	isBattleOnly = false
	

func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 60*60*9

func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()
	

func getEffectName():
	return "Apple cooldown"

func getEffectDesc():
	return "Despite your opinion of Dr. Quinn, you don't want to throw an apple at her again so soon. You do, however, have a schedule, so you'll be able to throw one at her again in "+Util.getTimeStringHumanReadable(turns)+"."

func getEffectImage():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
	]
	

func saveData():
	return {
		"turns": turns,
	}

func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 60*60)
	
