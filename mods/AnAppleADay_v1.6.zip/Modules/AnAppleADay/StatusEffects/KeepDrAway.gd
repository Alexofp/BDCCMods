extends StatusEffectBase

func _init():
	id = "KeepDrAway"
	isBattleOnly = false
	

func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 60*60*3

func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()
	

func getEffectName():
	return "...Keeps the Dr. away"

func getEffectDesc():
	return "You threw an apple at Dr. Quinn. You're feeling healthy. This karmic effect will unfortunately expire in "+Util.getTimeStringHumanReadable(turns)+"."

func getEffectImage():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func getIconColor():
	return IconColorCyan

func getBuffs():
	return [
		buff(Buff.PenisBallsVolumeBuff, [35]),
		
		buff(Buff.PenisCumProductionBuff, [35]),
		buff(Buff.BreastsMilkProductionBuff, [35]),
		
		buff(Buff.MaxPainBuff,[15]),
		buff(Buff.MaxStaminaBuff,[15]),
		buff(Buff.VirilityBuff,[25]),
		buff(Buff.FertilityBuff,[25]),
	
	]
	

func stop():
	if(!character):
		return
	
	character.removeEffect(id)
	character.addEffect("AppleThrowCooldown",[60*60*9])

func saveData():
	return {
		"turns": turns,
	}

func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 60*60)
	
