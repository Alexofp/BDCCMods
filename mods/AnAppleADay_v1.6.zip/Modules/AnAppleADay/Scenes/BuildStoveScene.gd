extends SceneBase

func _init():
	sceneID = "BuildStoveScene"

func exposedTextMethod():
	var exposed = GM.pc.getExposedPrivates()
	var isFem = GM.pc.getGender() == Gender.Female or GM.pc.getFemininity()>=50
	var indecentChest = (GM.pc.hasNonFlatBreasts() or isFem) && (BodypartSlot.Breasts in exposed)
	var indecentCrotch = (BodypartSlot.Penis in exposed) or (BodypartSlot.Vagina in exposed)
	
	var bits = []
	if indecentCrotch:
		bits.append("crotch")
	if indecentChest:
		bits.append("chest")
	if bits.empty():
		return ["", false] # bool is both hands occupied
	var exposedText = Util.humanReadableList(bits)
	var occupied = false
	if !GM.pc.hasBoundArms():
		exposedText = ("You quickly cover your exposed "+exposedText+" with your hands, as to not be indecent in front of the little rodent.")
		occupied = bits.size()>1
	else:
		exposedText = "You try to cover your "+exposedText+" with your hands, but your arms are bound, so you just endure being exposed in front of them"+("." if GM.pc.hasPerk(Perk.NakedNoShame) else ", your cheeks turning red from embarrassment.")
		occupied = true
	return [exposedText,occupied]

func _run():
	if state=="":
		saynn("It's finally time.")
		saynn("You knock on one of the walls of your cell a few times, and wait. A moment later, a sole rat comes out of a little hole in it, looking around. Their stare eventually rests on the pile of apples you have. They look at you excitedly, awaiting your response.")
		var pcmodtags = GM.pc.getModularDialogueTags("pc")
		if "rat" in GM.pc.getSpecies():
			var expose = exposedTextMethod()
			var txtbank = {
				"subby":{
					"occupied":"Oh! Um.. You can have the apples, they're for you..",
					"free":"U-um.. The apples are all yours, friend!..",
					"greet":"F-friend! Hi!",
				},
				"dommy":{
					"occupied":"Do you want my permission to take the apples? Go on ahead, sweetie, they're yours.",
					"free":"Such a cute rat. You've earned those apples.",
					"greet":"Hi there, cute thing.",
				},
				"mean":{
					"occupied":"What are you waiting for, little bandit?",
					"free":"Thanks to this, lucky you gets to go home with all those apples.",
					"greet":"Hey, little fella.",
				},
				"default":{
					"occupied":"Go on. The apples for you.",
					"free":"Good rat, go get those apples.",
					"greet":"Hey, distant cousin.",
				},
			}
			
			# calc personality dialog
			var key = "default"
			if pcmodtags.size()>0:
				key = pcmodtags.keys()[0]
			
			var pcgreet = txtbank[key]["greet"]
			var pcbyetxt = txtbank[key][("occupied" if(expose[1] or GM.pc.hasBlockedHands()) else "free")] 
			
			if expose[0]:
				saynn(expose[0])
			
			saynn("[say=pc]"+pcgreet+"[/say]")
			if expose[1] or GM.pc.hasBlockedHands(): # occupied, can't use arms or hands
				saynn("You sit on your bed and look at the little rat with adoration in your eyes.")
				saynn("[say=pc]"+pcbyetxt+"[/say]")
			else: # free arms & hands
				saynn("You squat on the floor and extend one of your hands to the little rat, who, after a brief moment of hesitation, runs up to you and leaps onto it, exploring and inspecting it.")
				saynn("They become accustomed to you quite fast and, after making their way back onto the floor of your {pc.inmateColor} cell, are very receptive to your touch, allowing you to pat them and stroke their fur, them in turn boggling slightly.")
				saynn("A moment of this later, you give them one last pat on the head and tell them..")
				saynn("[say=pc]"+pcbyetxt+"[/say]")
		
		else: # pc not rat
			var plrtxt = "Go on. They're for you."
			if pcmodtags.size()>0:
				match pcmodtags.keys()[0]:
					"subby":
						plrtxt = "Hi! Um.. I got these for you.."
					"mean":
						plrtxt = "You can have them, little fiend."
					"dommy":
						plrtxt = "Go ahead, little critter. Tell the others it's for them."
			
			saynn("[say=pc]"+plrtxt+"[/say]")
		
		# after pleasantries/interactions w/ lil rat
		saynn("The rat swiftly turns around and gets back into the dark hole.")
		saynn("A moment later, a swarm of rats, of various coat styles and colors, come out. They find the pile and start moving the apples into their home; rats running back and forth struggling to carry an apple each, others cooperating and carrying one as a team, and most colliding into each other a few times.")
		saynn("Before you know it, your cell is empty again. You wait, knowing it's not over yet.")
		saynn("The swarm returns, holding old pieces of metal and mismatched screws, chewed copper wires and foggy lightbulbs, and even tools of sorts, seemingly custom-made for their small frames and digits. They create scaffoldings with their bodies, like very industrious cheerleaders, the more sophesticated of their sort climbing around, building something.")
		saynn("When they're done, all of them leave. The rat who came here first appears out of the hole one last time, holding a huge (for their size) hardback book, with yellowed pages from age. They try to put it down gently, but its weight makes them lose their balance and they fall down, making a cute noise as the book finds its place on the ground with a thud. They get up, give you one last look, and run back to their folks.")
		saynn("Upon further inspection, the book is an operating manual for the kitchen-stove thing the swarm built, with a gray-ish, worn cover and desaturated lettering. You're sure it'll come in handy if you ever need a very short stool or a hard pillow, so you place it onto the newly-built countertop for when that time comes.")
		
		addButton("Continue", "That was nice", "end")


func _react(_action: String, _args):
	if _action=="end":
		endScene()
		return
	
	setState(_action)

func _reactInit():
	getModule("CraftingLibReworked").Workbench.createWorkbenchInstance("cellStove", "stove")
	increaseFlag("AnAppleADay.storedApples", -getModule("AnAppleADay").getStoveCost())
	processTime(60*15)
	GM.pc.addSkillExperience("AppliedKnowledge", 40)
	addMessage("You now have a stove!")
