extends "res://Modules/CraftingLibReworked/Scenes/testScene.gd"

func _init():
	sceneID = "StoveScene"

func _run():
	._run()
	
	if state == "":
		saynn("You stand in front of your trusty Stove.")
		playAnimation(StageScene.Solo,"stand",{
			pc="pc"})
		if GM.pc.hasPenis() && GM.pc.getBodypart(BodypartSlot.Penis).fluidType == "Cum":
			if GM.pc.isWearingCondom():
				addDisabledButton("Add homemade cream", "Chances are the condom will catch the cream")
			elif !GM.pc.hasReachablePenis():
				addDisabledButton("Add homemade cream", "You need to have a reachable penis")
			else:
				addButtonUnlessLate("Add homemade cream", "A proper chef makes "+GM.pc.hisHer()+" own cream", "makecream")
		return
	
	elif state=="makecream":
		playAnimation(StageScene.Solo,"stand",{
			pc="pc", npc="", pcCum=false,
			bodyState={showPenis=true,hard=true},
		})
		saynn("You position yourself in front of the cream tank, and expose your {pc.cock}. You take the lid off, and proceed to stroke yourself, your cock aimed at the tank.")
		saynn("The thought of using your own {pc.cum} as an ingredient excites you, your cock already leaking a bit of pre.")
		saynn("You keep rubbing your dick, your digits wrapped around it loosely and making slow, smooth movements. You caress the tip a bit, doing some circular motions and catching some of the pre on your hand, before spreading it along your shaft and continuing to stroke it.")
		saynn("You pick up the pace and tighten your grip, you letting out a quiet moan from the pleasure.")
		saynn("You start feeling a sensation build up in your {pc.cock}, warning you that you're close..")
		
		addButton("Cum","Ready~","cuminstove")
	elif state=="cuminstove":
		playAnimation(StageScene.Solo,"stand",{
			pc="pc", npc="", pcCum=false,
			bodyState={showPenis=true,hard=true},
		})

		saynn("You let out a moan as your cock starts throbbing and shooting thick ropes of {pc.cum} into the tank, filling it, while you hump your hand irregularly, trying to extract more pleasure that way..")

		saynn("Once you're done, you take a look at the fruit of your labor and put the lid back onto the tank, licking the {pc.cum} off of your digits after.")
		
		addButton("Continue", "Cream secured", "")
	
	elif state == "do":
		playAnimation(StageScene.Solo,"stand",{
			pc="pc"})

func _react(action,_args=[]):
	if action == "makecream":
		processTime(60*3)
	elif action == "cuminstove":
		var penis : BodypartPenis = GM.pc.getBodypart(BodypartSlot.Penis)
		var fl : Fluids = penis.getFluids()
		var spill = fl.drainPercent(RNG.randf_range(0, 0.1))
		var camount = fl.getFluidAmountByType().get("Cum", 0)
		
		getMod().Workbench.addIngredient(sceneTag, "Cum", camount)
		addMessage("You made "+str(camount).pad_decimals(2)+" ml of cream!")
		if spill:
			addMessage(str(spill).pad_decimals(2)+" ml was spilled")
		processTime(90)
	
	._react(action,_args)
