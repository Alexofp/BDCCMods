extends Module

func getFlags():
	return {
		"storedApples":flag(FlagType.Number),
	}

func _init():
	id = "AnAppleADay"
	author = "Selinoccino"
	
	lootLists = [
		"res://Modules/AnAppleADay/LootLists/genericList.gd",
	]
	
	events = GlobalRegistry.getScriptsInFolder("res://Modules/AnAppleADay/Events/")
	
	scenes = GlobalRegistry.getScriptsInFolder("res://Modules/AnAppleADay/Scenes/")
	
	items = GlobalRegistry.getScriptsInFolder("res://Modules/AnAppleADay/Items/")
	
	statusEffects = GlobalRegistry.getScriptsInFolder("res://Modules/AnAppleADay/StatusEffects/")
	
	skills = [
		"res://Modules/AnAppleADay/Skills/AppliedKnowledge.gd"
	]
	
	perks = GlobalRegistry.getScriptsInFolder("res://Modules/AnAppleADay/Skills/Perks/")
	
	attacks = GlobalRegistry.getScriptsInFolder("res://Modules/AnAppleADay/Attacks/")
	
	
	

func postInit():
	if GlobalRegistry.getModules().has("CraftingLibReworked"):
		scenes.append("res://Modules/AnAppleADay/Scenes/stoveScene.gd")
		GlobalRegistry.registerScene(scenes[scenes.size()-1])

func canGetStove() -> bool:
	return getFlag("AnAppleADay.storedApples",0)>=getStoveCost()

func hasStove() -> bool:
	var craftingLib = GlobalRegistry.getModules().get("CraftingLibReworked", null)
	if !craftingLib:
		return false
	return craftingLib.Workbench.getInstance("cellStove")!=null

func getStoveCost() -> int:
	return 20


func getAddedWorkbenchTypes() -> Dictionary:
	return {
		"stove": {
			"mod": id,
			"tagsCallback": "getStoveTags", # data: Dict
			"fluidsCallback": "getStoveFluids", # same
			"ingredientCapsCallback": "getStoveCaps", # same
			"defaultIngredientCap": -1.0, # float
		},
	}

func getStoveTags(_data) -> Array:
	return ["stove"]

func getStoveFluids(_data) -> Array:
	return ["Cum"]

func getStoveCaps(_data) -> Dictionary:
	return {}

func getAddedRecipes(): # allows CraftingLibReworked to draw recipes from here; since this is called every time it gets the recipes, you can adds conditions, eg. have a perk that allows you to make specific items. wtype is the workbench type, which you can also add your own
	var rs = {
		"applerecipe1":{
			"name":"Apple",
			"resultingItems":[["appleitem",1]],
			"requiredIngredients":{ # key is id, value is amounts, always draws from ingredients
				"applepowder":[69,420],
				"Cum":[10,20],
			},
		},
		"applepie1":{
			"name":"Apple Pie",
			"resultingItems":[  ["applepie",1]  ], # can have multiple items with any amount
			"requiredIngredients":{ # key is id, value is amounts
				"applepowder":[100,150],
				"applejuice":[200,300],
				"appleslices":[15,25],
			},
		},
		"applecreampie1":{
			"name":"Apple Cream Pie",
			"resultingItems":[  ["applecreampie",1]  ], # can have multiple items with any amount
			"requiredIngredients":{ # key is id, value is amounts
				"applepowder":[125,150],
				"applejuice":[100,175],
				"appleslices":[12,20],
				"Cum":[100,600], # virile, can be created from fluidToIngredient() func
			},
		},
		"appletart":{
			"name":"Apple Tart",
			"resultingItems":[  ["appletart",1]  ], # can have multiple items with any amount
			"requiredIngredients":{ # key is id, value is amounts
				"applepowder":[50,80],
				"applejuice":[35,50],
				"appleslices":[2,4],
				"Milk":[150,225],
			},
		},
		
		"appleslices1":{
			"name":"Apple Slices",
			"resultingIngredients":[["appleslices",8]],
			"requiredItems":{
				"appleitem":[1],
				},
		},
		"applejuice1":{
			"name":"Apple Juice",
			"resultingIngredients":[["applejuice",75]],
			"requiredItems":{
				"appleitem":[1],
				},
		},
		"applepowder1":{
			"name":"Apple Powder",
			"resultingIngredients":[["applepowder",100]],
			"requiredItems":{
				"appleitem":[1],
				},
		},
	}
	
	for recid in rs:
		rs[recid]["tags"] = ["stove"]
	
	return rs

func getAddedIngredients() -> Dictionary:
	var ings = {
		"appleslices":{
			"name":"Apple Slices",
			"measure":"",
		},
		"applejuice":{
			"name":"Apple Juice",
			"measure":"ml",
		},
		"applepowder":{
			"name":"Apple Powder",
			"measure":"ml",
		},
		"Cum":{ # built-in fluid, should be here ig
			"name":"Cream",
			"measure":"ml"
		},
		"Milk":{ # built-in fluid, should be here ig
			"name":"Milk",
			"measure":"ml"
		},
	}
	return ings
