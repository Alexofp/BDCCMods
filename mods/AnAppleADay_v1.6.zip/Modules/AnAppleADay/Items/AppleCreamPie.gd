extends ItemBase

const staminaBase : int = 50
const lustBase : int = 15
const painBase : int = 75
const priceBase : int = 9

var quality : float = 0.0

func _init():
	id = "applecreampie"
	quality = getQuality()

func getVisibleName():
	return "Apple Cream Pie ("+str(int(quality*100))+"% quality)"
	
func getDescription():
	return "An apple pie with cream stuffing. Restores "+str(int(staminaBase*quality))+" stamina, relieves "+str(int(painBase*quality))+" pain, and gives you "+str(int(lustBase*quality))+" lust. Quality depends on overall amount of cream as well as its richness.\nBase quality: "+str(quality*100).pad_decimals(0)+"%"

func setQuality(v) -> void:
	quality = v.baseQuality

func getQuality() -> float:
	return quality

func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	_attacker.addPain(-int(painBase*quality))
	_attacker.addStamina(int(staminaBase*quality))
	_attacker.addLust(int(lustBase*quality))
	removeXOrDestroy(1)
	
	var txt = "{_attacker.name} pulls out an apple pie with cream stuffing, sits down on the ground gently, and proceeds to eat it ve-e-ry slowly. "+(" {_attacker.He} {_attacker.verb('think')} it's meh." if quality<0.5 else " It's pretty good!")
	if _receiver==null:
		return txt
	
	var naiveteMult = 10.0
	var subbinessMult = 15.0
	var meanieMult = -15.0
	var bratMult = -20.0
	var pers = _attacker.getPersonality()
	var offerChance = 20 + naiveteMult*pers.getStat(PersonalityStat.Naive) + bratMult*pers.getStat(PersonalityStat.Brat)+subbinessMult*pers.getStat(PersonalityStat.Subby)+meanieMult*pers.getStat(PersonalityStat.Mean)
	if(RNG.chance(clamp(offerChance,0,100))):
		var poses = ["No, thanks.","No, I'm good.","I'm watching my figure."] if quality>=0.5 else ["No, that looks terrible. I'll pass.","..Really?","..You've got to change your priorities. We're literally fighting."]
		var recModTags = _receiver.getModularDialogueTags(_attacker)
		if recModTags.keys().size()>0:
			match recModTags.keys()[0]:
				"subby":
					if quality<0.5:
						poses = ["It, um.. doesn't look that good, I-I'll pass..","U-um.. I don't want to deprive you of it..","N-no thanks, I think I have some in my cell.."]
					else:
						poses = ["N-no, I'm full..", "I-I'll pass, sorry..","I ate earlier, thanks though!..","No, t-thanks.."]
					if _receiver.getLustLevel()>=0.5:
						poses.append_array(["S-sorry, no.. I'm already barely keeping myself together..","Although it does look very inviting, I-I'll pass.."])
				"mean":
					if quality<0.5:
						poses = ["No. That cream looks fucking store-bought.","You think I want your fucking trash?","Fuck no. That shit looks so watered-down, you might as well use pre instead."]
					else:
						poses = ["We're supposed to be fighting, you stupid bitch.","I'm not taking anything from sluts like you.","Me, accept your charity? What a sick joke."] # and HE gets to be a lawyer?!
					if _receiver.getLustLevel()>=0.5:
						poses.append_array(["You trying to take advantage of my horniness? Fucking try harder."])
				"dommy":
					if quality<0.5:
						poses = ["That's better suited for someone of your caliber, slut.","You'll have to do better than that, pet.","Maybe that's good enough for you, sweetie."]
					else:
						poses = ["I like watching you stuff your mouth with it more, pet.","No. You need that cream more than I do, cutie.","Are you trying to bribe me, slut?"]
		
		txt += "\n{_attacker.name} {_attacker.verb('offer')} "+_receiver.getName()+" a half-eaten slice, with some strings of cream still connected to it and {_attacker.his} mouth. "+_receiver.getName()+ " responds, " +_receiver.formatSay(RNG.pick(poses))
	return txt

func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Sustenance",
		},
	]

func getPrice():
	return max(1,int(priceBase*quality*1.5))

func getSellPrice():
	return max(1,int(getPrice()*0.75)) # make it unfair ig

func canSell():
	return true

func canCombine():
	return true

func tryCombine(_otherItem):
	if _otherItem.quality==quality:
		return .tryCombine(_otherItem)
	return false

func getTags():
	return []

func getItemCategory():
	return "Food"

func saveData():
	var data = .saveData()
	data["quality"] = quality
	return data
	
func loadData(data):
	.loadData(data)
	quality = SAVE.loadVar(data, "quality", RNG.randf_range(0.1, 0.7))

func getInventoryImage():
	return "res://Modules/AnAppleADay/Images/applepie.png"

func getInventoryGroupName():
	return "Apple Cream Pies"
