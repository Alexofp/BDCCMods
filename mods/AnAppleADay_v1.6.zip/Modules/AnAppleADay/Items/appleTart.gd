extends ItemBase

const staminaBase : int = 35
const painBase : int = 25
const priceBase : int = 3

var quality : float = 0.0

func _init():
	id = "appletart"
	quality = getQuality()

func getVisibleName():
	return "Apple Tart ("+str(int(quality*100))+"% quality)"
	
func getDescription():
	return "An apple tart with milk cream. Restores "+str(int(staminaBase*quality))+" stamina and relieves "+str(int(painBase*quality))+" pain. Quality depends on overall amount of cream.\nQuality: "+str(quality*100).pad_decimals(0)+"%"

func setQuality(v) -> void:
	quality = v.baseQuality

func getQuality():
	return quality

func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	_attacker.addPain(-int(painBase*quality))
	_attacker.addStamina(int(staminaBase*quality))
	removeXOrDestroy(1)
	
	var txt = "{_attacker.name} pulls out a slice of apple tart with milk cream, and starts eating it. "+(" {_attacker.He} {_attacker.verb('find')} it bland." if quality<0.5 else " It's pretty good!")
	return txt

func getPossibleActions():
	return [
		{
			"name": "Eat",
			"scene": "UseItemLikeInCombatScene",
			"description": "Eat the tart",
		},
	]

func getPrice():
	return int(max(1,priceBase*quality*1.5))

func getSellPrice():
	return int(max(1,getPrice()*0.75)) # make it unfair ig

func canSell():
	return true

func canCombine():
	return true

func tryCombine(_otherItem):
	if _otherItem.quality==quality:
		return .tryCombine(_otherItem)
	return false

func getTags():
	return []

func getItemCategory():
	return "Food"

func saveData():
	var data = .saveData()
	data["quality"] = quality
	return data
	
func loadData(data):
	.loadData(data)
	quality = SAVE.loadVar(data, "quality", RNG.randf_range(0.1, 0.7))

func getInventoryImage():
	return "res://Modules/AnAppleADay/Images/tart.png"

func getInventoryGroupName():
	return "Apple Tarts"
