extends ItemBase

const staminaBase : int = 40
const lustBase : int = 5
const painBase : int = 50
const priceBase : int = 4

var quality : float = 0.0

func _init():
	id = "applepie"

func getVisibleName():
	return "Apple Pie ("+str(int(getQuality()*100))+"% quality)"
	
func getDescription():
	return "An entire apple pie. Feel free to casually eat in the heat of battle to restore "+str(int(staminaBase*quality))+" stamina, relieve "+str(int(painBase*quality))+" pain, and gain "+str(int(lustBase*quality))+" lust."

func setQuality(v) -> void:
	quality = v.baseQuality

func getQuality():
	return quality

func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	_attacker.addPain(-int(painBase*quality))
	_attacker.addStamina(int(staminaBase*quality))
	_attacker.addLust(int(lustBase*quality))
	removeXOrDestroy(1)
	
	var txt = "{_attacker.name} takes an entire apple pie, sets it onto a little sheet on the ground that {_attacker.he} just so {_attacker.verb('happen')} to carry around with {_attacker.him}, and proceeds to casually eat it."
	if _receiver==null:
		return txt
	var naiveteMult = 10.0
	var subbinessMult = 15.0
	var meanieMult = -15.0
	var bratMult = -20.0
	var pers = _attacker.getPersonality()
	var offerChance = 20 + naiveteMult*pers.getStat(PersonalityStat.Naive) + bratMult*pers.getStat(PersonalityStat.Brat)+subbinessMult*pers.getStat(PersonalityStat.Subby)+meanieMult*pers.getStat(PersonalityStat.Mean)
	if(RNG.chance(clamp(offerChance,0,100))):
		var poses = ["No, thanks.","No, I'm good.","I'm watching my figure."]
		var recModTags = _receiver.getModularDialogueTags(_attacker)
		if recModTags.keys().size()>0:
			match recModTags.keys()[0]:
				"subby":
					poses = ["N-no, I'm full..", "I-I'll pass, sorry..","I ate earlier, t-thanks though!..","No, thanks.."]
				"mean":
					poses = ["Keep that shit for yourself.","The fuck makes you think I want anything from you?","I'd rather eat the slop at the canteen."]
				"dommy":
					poses = ["Think you have the right to feed me, slut?","I'd prefer a piece of your ass, bitch.","Did you forget you shouldn't feed the hand that hits you?"]
		
		txt += "\n{_attacker.He} {_attacker.verb('ask')} "+_receiver.getName()+" if "+_receiver.heShe()+ " "+_receiver.verbS('want')+" a piece, to which "+_receiver.heShe()+" "+_receiver.verbS('say')+" "+_receiver.formatSay(RNG.pick(poses))
	return txt

func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Sustenance",
		},
	]

func getPrice():
	return max(1,int(priceBase*quality*1.5))

func canSell():
	return true

func canCombine():
	return true

func tryCombine(_otherItem):
	if _otherItem.quality==quality:
		return .tryCombine(_otherItem)
	return false

func getTags():
	return []

func getItemCategory():
	return "Food"

func saveData():
	var data = .saveData()
	data["quality"] = quality
	return data
	
func loadData(data):
	.loadData(data)
	quality = SAVE.loadVar(data, "quality", 0.5)

func getInventoryImage():
	return "res://Modules/AnAppleADay/Images/applepie.png"

func getInventoryGroupName():
	return "Apple Pies"
