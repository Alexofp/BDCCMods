# mod version: 2.3
extends EventBase

var DEBUG = false

func isWearingPermanentChastityBelt(character):
	if(character.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		var item = character.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
		if "Permanent" in item.getVisibleName() && "Chastity Belt" in item.getVisibleName():
			return true
	return false

func _init():
	id = "ChastityForEveryoneLubeEvent"

func registerTriggers(es):
#	es.addTrigger(self, Trigger.EnteringRoom, "medical_confessionary")
	es.addTrigger(self, Trigger.EnteringRoom, "eng_near_storage")

func run(_triggerID, _args):
	var stockpileDaysSinceUsed = getModuleFlag("ChastityForEveryone", "Lube.StockpileDaysSinceUsed", 0)
	var stockpileUsedToday = getModuleFlag("ChastityForEveryone", "Lube.StockpileUsedToday", false)
	if DEBUG: print_debug("Days left to wait for the barrels: ", stockpileDaysSinceUsed)
	if DEBUG: print_debug("stockpileUsedToday: ", stockpileUsedToday)
	if(!getFlag("ChastityForEveryone.Lube.StockpileSearched", false)):
		addButton("Stockpile", "There are some crates and barells in the corner of the room", "stockpile")
	elif stockpileDaysSinceUsed > 0 && !(stockpileUsedToday && stockpileDaysSinceUsed > 0): # by design interaction can be done unrestricted ammount of time in one day, but since next day the timeout starts.
		addDisabledButton("Stockpile", "There's just junk here")
		saynn("Looks like the lubricant barrels are gone. Someone might have noticed the barrels being disturbed, or engineers used up all the lubricant. All you can do now is wait for resupply to appear.")
	elif "belt" in GM.main.getFlag("ChastityForEveryone.databasePC", {})["type"] && isWearingPermanentChastityBelt(GM.pc):
		addButton("Stockpile", "This lube barrel might come in handy", "stockpileUseLube")
	else:
		addDisabledButton("Stockpile", "It's just junk (at least to you currently)")

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "stockpile"):
		runScene("ChastityForEveryoneLubeWiggleOutScene")
	if(_method == "stockpileUseLube"):
		setFlag("ChastityForEveryone.Lube.StockpileUseLube", true)
		runScene("ChastityForEveryoneLubeWiggleOutScene")
