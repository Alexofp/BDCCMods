# mod version: 2.3
extends Module


var configModEnabled # 2.2 added

var configModUpdating # 2.21 added

#var configAffectDrugDen # 2.2 temp change

var configAffectGuards
var configAffectEngineers
var configAffectNurses

var configAffectHSI
var configAffectGBI
var configAffectSDI

var configAffectMales
var configAffectShemales
var configAffectHerms
var configAffectFemales

var configChance
var configChanceGuards
var configChanceEngineers
var configChanceNurses

var configFlatCageChance

var configGuardsInspect
var configEngineersInspect
var configNursesInspect

var configCheckChance

### 2.1

var configNonPermanentChance

const chastityLvlMin = 15
const chastityLvlMax = 50
var configChastityLvlMultip

### 2.3

var configMales
var configShemales
var configHerms
var configFemales
var configPeachboys

var configBeltChance
var configNonPermanentBeltChance

var configAffectDatapackChar

###

var interactions = []

func getFlags():
	return {
		"database": flag(FlagType.Dict),
		"databaseNew": flag(FlagType.Dict),
		"databasePC": flag(FlagType.Dict),
		"Lube.StockpileSearched": flag(FlagType.Bool),
		"Lube.StockpileUseLube": flag(FlagType.Bool),
		"Lube.StockpileDaysSinceUsed": flag(FlagType.Number),
		"Lube.stockpileUsedToday": flag(FlagType.Bool),
	}


func register():
	for interaction in interactions:
		GlobalRegistry.registerInteraction(interaction)
	for event in events:
		GlobalRegistry.registerEvent(event)
	for scene in scenes:
		GlobalRegistry.registerScene(scene)

func onFoxLibModInit(foxModuleAPI):
	var list10 = [
			[0, "0%"], [5, "5%"], [10, "10% (default)"], [15, "15%"], [20, "20%"], [25, "25%"], 
			[30, "30%"], [35, "35%"], [40, "40%"], [45, "45%"], [50, "50%"], 
			[55, "55%"], [60, "60%"], [65, "65%"], [70, "70%"], [75, "75%"],
			[80, "80%"], [85, "85%"], [90, "90%"], [95, "95%"], [100, "100%"] 
			]
#	var list100 = [
#			[0, "0%"], [5, "5%"], [10, "10%"], [15, "15%"], [20, "20%"], [25, "25%"], 
#			[30, "30%"], [35, "35%"], [40, "40%"], [45, "45%"], [50, "50%"], 
#			[55, "55%"], [60, "60%"], [65, "65%"], [70, "70%"], [75, "75%"],
#			[80, "80%"], [85, "85%"], [90, "90%"], [95, "95%"], [100, "100%  (default)"] 
#			]
	var list35 = [
			[0, "0%"], [5, "5%"], [10, "10%"], [15, "15%"], [20, "20%"], [25, "25%"], 
			[30, "30%"], [35, "35% (default)"], [40, "40%"], [45, "45%"], [50, "50%"], 
			[55, "55%"], [60, "60%"], [65, "65%"], [70, "70%"], [75, "75%"],
			[80, "80%"], [85, "85%"], [90, "90%"], [95, "95%"], [100, "100% "] 
			]
	var list90 = [
			[0, "0%"], [5, "5%"], [10, "10%"], [15, "15%"], [20, "20%"], [25, "25%"], 
			[30, "30%"], [35, "35%"], [40, "40%"], [45, "45%"], [50, "50%"], 
			[55, "55%"], [60, "60%"], [65, "65%"], [70, "70%"], [75, "75%"],
			[80, "80%"], [85, "85%"], [90, "90% (default)"], [95, "95%"], [100, "100%"] 
			]
	var list50 = [
			[0, "0%"], [5, "5%"], [10, "10%"], [15, "15%"], [20, "20%"], [25, "25%"], 
			[30, "30%"], [35, "35%"], [40, "40%"], [45, "45%"], [50, "50% (default)"], 
			[55, "55%"], [60, "60%"], [65, "65%"], [70, "70%"], [75, "75%"],
			[80, "80%"], [85, "85%"], [90, "90%"], [95, "95%"], [100, "100%"] 
			]
	var listMult = [
			[0.01, "1%"], [0.1, "10%"], [0.25, "25%"], [0.5, "50%"], [1, "100% (default)"], [1.25, "125%"], [1.5, "150%"], [2, "200%"],  [5, "500%"],  [1000, "1000%"],
			]
	#2.2
	var listMale = [
			["none", "None"], ["cage", "Chastity Cage"], ["beltP", "Chastity Belt"], ["cage&beltP", "Cages and Belts"]
			]
	var listFemale = [
			["none", "None"], ["beltV", "Chastity Belt"], #[] piercings
			]
	var listShemale = listMale
	var listHerm = [
			["none", "None"], 
			["cage", "Chastity Cage"], ["cage&beltP", "Both Cages and Penile Chastity Belts"], ["cages&beltV", "Chastity Cages and Vaginal Chastity Belts"],
			["beltP", "Only Penile Chastity Belt"],  
			["beltV", "Only Vaginal Chastity Belt"],
			["beltPV", "Only [i]2in1[/i] Penial and Vaginal Chastity Belt"],
			["beltA", "Only Chastity Belts of any type"],
			["any", "Cages and any type of Belt"],
			]
	var listPeachboy = listFemale
	
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configModEnabled", "Mod master switch", "Enable or disable the mod - that is, stop new NPCs form being caged (this WON'T reverse the effects)", true)
	
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectMales", "Affect males", "Decide if male NPCs should be affected", true)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectFemales", "Affect females", "Decide if female NPCs should be affected", true)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectShemales", "Affect shemales", "Decide if shemale NPCs  should be affected", true)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectHerms", "Affect herms", "Decide if herm NPCs should be affected", true)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectHerms", "Affect herms", "Decide if herm NPCs should be affected", true)
##	#foxModuleAPI.addBooleanOptionInCate"Who should be affected", "configAffectFemales", "Make female NPC wear Jackie's chastity piercing", "Decide if female NPCs should be affected, by making them wear Jackie's chastity piercing", false)
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configMales", "Male chastity types", listMale, "Decide how male NPCs should be affected", "cage&beltP")
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configFemales", "Female chastity types", listFemale, "Decide how female NPCs should be affected", "beltV")
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configShemales", "Shemale chastity types", listShemale, "Decide how shemale NPCs should be affected", "cage&beltP")
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configHerms", "Herm chastity types", listHerm, "Decide how herm NPCs should be affected", "any")
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configPeachboys", "Peachboy chastity types", listPeachboy, "Decide how peachboy NPCs should be affected", "beltV")
	
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectHSI", "Affect High Security inmates", "Decide if High Security inmates should be affected", true)
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectGBI", "Affect General Block inmates", "Decide if General Block inmates should be affected", true)
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectSDI", "Affect Sexual Deviant inmates", "Decide if Sexual Deviant inmates should be affected", true)
	
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configChance", "Inmate chastity spawn chance", list90, "Configure chance of selected genders and types of inmate NPCs being spawned with cages/belts", 90)
	
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectDrugDen", "Affect Dungeons (Drug Den)", "Decide if NPCs inside of Drug Den should also be caged", false)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectGuards", "Affect Guards", "Decide if random guards should be affected by the mod", false)
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configChanceGuards", "Guard chastity spawn chance", list10, "Configure chance of selected genders of guard NPCs being spawned with cages/belts", 10)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectEngineers", "Affect Engineers", "Decide if random engineers should be affected by the mod", false)
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configChanceEngineers", "Engineer chastity spawn chance", list10, "Configure chance of selected genders of engineer NPCs being spawned with cages/belts", 10)
#	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectNurses", "Affect Nurses", "Decide if random nurses should be affected by the mod", false)
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - basic settings", "configChanceNurses", "Nurse chastity spawn chance", list10, "Configure chance of selected genders of nurse NPCs being spawned with cages/belts", 10)
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - basic settings", "configAffectDatapackChar", "Affecting datapack characters", "Decide if characters from datapacks should be skipped or be affected by the mod", false)
	###
	
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - advanced settings", "configFlatCageChance", "Flat cage factor (chance)", list35, "Configure chance of cage being flat one. WARNING! If non-permanent flat cage item is not modded in, then NPC spawning and other interactions won't work properly.", 35).advanced()
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - advanced settings", "configNonPermanentChance", "Non permanent cage variants chance", list50, "Configure chance of selected types of inmate NPCs being spawned with non permanent variants of cages", 50).advanced()
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - advanced settings", "configBeltChance", "Chastity Belts chance", list35, "Configure chance of selected types of inmate NPCs being spawned with belts instead of cages. Only applies when both cages and belts are possible for selected NPC gender.", 35).advanced()
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - advanced settings", "configNonPermanentBeltChance", "Non permanent belt variants chance", list50, "Configure chance of selected types of inmate NPCs being spawned with non permanent variants of chastity belts", 50).advanced()
	
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - advanced settings", "configCheckChance", "Inspection chance", list35, "Configure chance of inspection (of player/NPCs that managed to take of their chastity)", 35).advanced()
	
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - advanced settings", "configGuardsInspect", "Guards inspect", "Decide if random guards should be checking for cages/belts", true).advanced()
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - advanced settings", "configEngineersInspect", "Engineers inspect", "Decide if random engineers should be checking for cages/belts", false).advanced()
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - advanced settings", "configNursesInspect", "Nurses inspect", "Decide if random nurses should be checking for cages/belts", true).advanced()
	
	foxModuleAPI.addListOptionInCategory("Chastity For Everyone - advanced settings", "configChastityLvlMultip", "Non-permanent chastity level multiplyer", listMult, "Lover or increase expected levels of generated non-permanent chastity variants", 1).advanced()
	
	foxModuleAPI.addBooleanOptionInCategory("Chastity For Everyone - advanced settings", "configModUpdating", "Re-evaluate NPCs with new settings", "Decide if setting changes would also apply to NPCs generated in the past (this WON'T uncage them). Disable after walking couple of tiles, as all of the NPC wil be updated by then.", false)


func resetFlagsOnNewDay():
	# not sure if this is the proper way to do it, but oh well
	var stockpileDaysSinceUsed = GM.main.getModuleFlag("ChastityForEveryone", "Lube.StockpileDaysSinceUsed", 0)
	if stockpileDaysSinceUsed > 0:
		GM.main.setModuleFlag("ChastityForEveryone", "Lube.StockpileDaysSinceUsed", stockpileDaysSinceUsed-1)
		GM.main.setModuleFlag("ChastityForEveryone", "Lube.StockpileUsedToday", false)
		


func _init():
	id = "ChastityForEveryone"
	author = "_noro_"
	
	interactions = [
		"res://Modules/ChastityForEveryone/ChastityPolice.gd",
	]
	events = [
		"res://Modules/ChastityForEveryone/ChastityBigBrother.gd",
		
		"res://Modules/ChastityForEveryone/ExtraScenes/LubeWiggleOutEvent.gd",
	]
	scenes = [
		"res://Modules/ChastityForEveryone/ExtraScenes/LubeWiggleOutScene.gd",
	]
#	gameExtenders = [
#		"res://Modules/ChastityForEveryone/SaveData.gd"
#	]
