# Added stuff

## Perks

1) Gambler Cum Stud (CumStudV3.gd)
2) Plot Twist (Dramaturgy.gd)

## Status effects

1) Perk Exhaustion (PerkExhaustion)
2) Dramaturgy Success (DramaturgySucess.gd)
3) Dramat Fail (DramaturgyFail.gd)

## Attacks

1) Dramaturgy (DramaturgyPC.gd)
2) Flashlight (FlashlightPCAttack.gd)

## Items

1) Flashlight (Flashlight.gd)

## Buffs

1) Buff.PenisCumGenRNGAfterOrgasmBuff (PenisCumGenRNGAfterOrgasmBuff.gd)

# Idea

this is where my notes are:

- [ ] Make dodge boost first then roll the effect
- [ ] probably other skill trees