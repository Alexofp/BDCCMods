extends Object

const ATTEMPT_DEFAULT:float = 67.0
const SUCCESS_DEFAULT:float = 70.0

static func setting(field:String, fallback:float) -> float:
	var knotModule = GlobalRegistry.getModules().get("OralKnotting")
	if(knotModule == null):
		return fallback
	var value = knotModule.get(field)
	if(value == null):
		return fallback
	return clamp(float(value), 0.0, 100.0)

static func actionScore(rivals:float) -> float:
	var wanted:float = setting("knotAttemptChance", ATTEMPT_DEFAULT)
	return rivals * wanted / max(100.0 - wanted, 0.5)

static func successChance(gameChance:float) -> float:
	return max(gameChance, setting("knotSuccessChance", SUCCESS_DEFAULT))
