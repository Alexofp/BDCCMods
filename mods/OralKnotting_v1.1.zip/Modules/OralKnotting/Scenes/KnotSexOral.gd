extends "res://Player/StageScene3D/Scenes/SexOral.gd"
const KnotClip := preload("res://Modules/OralKnotting/KnotClip.gd")
const KNOT_SEAT := 1.0
const STARTS_FROM := {
	"knotted": "sex",
}

func playAnimation(animID, _args = {}):
	if(!STARTS_FROM.has(animID)):
		.playAnimation(animID, _args)
		return
	.playAnimation(STARTS_FROM[animID], _args)
	if(animID == "knotted"):
		doll.clampPenisScale(0.95, 1.1)
		if(doll2.getState("mouth") in ["", null]):
			doll2.setTemporaryState("mouth", "open")
		KnotClip.knot([animationTree, animationTree2], ["Sex_Oral_1-loop", "Sex_Oral_2-loop"], [doll, doll2], [[doll, doll2]], KNOT_SEAT)

func getSupportedStates():
	return .getSupportedStates() + STARTS_FROM.keys()
