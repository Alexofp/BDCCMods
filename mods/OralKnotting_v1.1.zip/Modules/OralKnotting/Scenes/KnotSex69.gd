extends "res://Player/StageScene3D/Scenes2/Sex69.gd"
const KnotClip := preload("res://Modules/OralKnotting/KnotClip.gd")
const KNOT_SEAT := 1.0
const STARTS_FROM := {
	"FMknotted": "FM",
	"MFknotted": "MF",
	"MMknotted": "MM",
}

func playAnimation(animID, _args = {}):
	if(!STARTS_FROM.has(animID)):
		.playAnimation(animID, _args)
		return
	.playAnimation(STARTS_FROM[animID], _args)
	if(animID == "FMknotted"):
		doll.clampPenisScale(0.95, 1.2)
		if(doll2.getState("mouth") in ["", null]):
			doll2.setTemporaryState("mouth", "open")
		KnotClip.knot([animationTree, animationTree2], ["Sex69_1-loop", "Sex69_2-loop"], [doll, doll2], [[doll, doll2]], KNOT_SEAT)
	if(animID == "MFknotted"):
		doll2.clampPenisScale(0.95, 1.2)
		if(doll.getState("mouth") in ["", null]):
			doll.setTemporaryState("mouth", "open")
		KnotClip.knot([animationTree, animationTree2], ["Sex69MF_1-loop", "Sex69MF_2-loop"], [doll, doll2], [[doll2, doll]], KNOT_SEAT)
	if(animID == "MMknotted"):
		doll.clampPenisScale(0.95, 1.2)
		if(doll2.getState("mouth") in ["", null]):
			doll2.setTemporaryState("mouth", "open")
		doll2.clampPenisScale(0.95, 1.2)
		if(doll.getState("mouth") in ["", null]):
			doll.setTemporaryState("mouth", "open")
		KnotClip.knot([animationTree, animationTree2], ["Sex69MM_1-loop", "Sex69MM_2-loop"], [doll, doll2], [[doll, doll2], [doll2, doll]], KNOT_SEAT)

func getSupportedStates():
	return .getSupportedStates() + STARTS_FROM.keys()
