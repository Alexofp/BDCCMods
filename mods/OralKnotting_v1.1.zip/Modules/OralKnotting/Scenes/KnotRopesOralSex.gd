extends "res://Player/StageScene3D/Scenes2/RopesOralSex.gd"
const KnotClip := preload("res://Modules/OralKnotting/KnotClip.gd")
const KNOT_SEAT := 1.0
const STARTS_FROM := {
	"knotted": "sex",
}

func playAnimation(animID, _args = {}):
	if(!STARTS_FROM.has(animID)):
		.playAnimation(animID, _args)
		return
	.playAnimation(STARTS_FROM[animID], _args)
	if(animID == "knotted"):
		doll2.clampPenisScale(0.95, 1.1)
		if(doll.getState("mouth") in ["", null]):
			doll.setTemporaryState("mouth", "open")
		KnotClip.knot([animationTree, animationTree2], ["RopesOral_1-loop", "RopesOral_2-loop"], [doll, doll2], [[doll2, doll]], KNOT_SEAT)

func getSupportedStates():
	return .getSupportedStates() + STARTS_FROM.keys()
