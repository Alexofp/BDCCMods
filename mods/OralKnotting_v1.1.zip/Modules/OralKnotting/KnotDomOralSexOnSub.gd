extends "res://Game/SexEngine/SexActivity/DomOralSexOnSub.gd"
const KnotOdds := preload("res://Modules/OralKnotting/KnotOdds.gd")

func getTags(_indx:int) -> Array:
	var tags:Array = .getTags(_indx)
	if(_indx == DOM_0 && getState() == "knotting" && !(SexActivityTag.MouthUsed in tags)):
		tags.append(SexActivityTag.MouthUsed)
	return tags

func isActivityImpossibleShouldStop() -> bool:
	if(getState() == "knotting" && !getSub().hasReachablePenis() && !getSub().isWearingStrapon()):
		return true
	return .isActivityImpossibleShouldStop()

func knotting_processTurn():
	cockWarmer(DOM_0, SUB_0, BodypartSlot.Head, true)
	var freeRoom = getDom().getPenetrationFreeRoomBy(BodypartSlot.Head, getSubID(0))
	if(freeRoom <= 0.0):
		getDomInfo(0).addConsciousness(-RNG.randf_range(0.05, 0.15))
		addText(RNG.pick([
			"{dom.You} {dom.youVerb('choke')} and {dom.youVerb('gag')} because "+RNG.pick(["the knot is too big", "it's stuck too deep", "the knot blocks {dom.yourHis} airway"])+".",
			"{dom.You} "+RNG.pick(["{dom.youVerb('choke')}", "{dom.youVerb('suffocate')}", "can't get enough air"])+" with that knot in {dom.yourHis} throat!",
			" "+RNG.pick(["A few tears stream", "A single tear streams"])+" down {dom.yourHis} cheeks while the knot blocks {dom.yourHis} airway.",
		]))

func getActions(_indx:int):
	.getActions(_indx)
	if(getState() == "knotting"):
		for i in range(actionsResult.size() - 1, -1, -1):
			if(actionsResult[i].get("id") in ["stop", "pullaway"]):
				actionsResult.remove(i)
		if(_indx == DOM_0):
			addAction("pullknotout", 1.0, "Pull off", "Try to yank their knot out of your throat")
		return
	if(_indx != DOM_0):
		return
	var subCums:bool = getState() in ["subabouttocum", "subabouttocumcock", "subabouttocumHandjob"] \
		|| ((getState() in ["licking", "tonguefucking", "lickingcock", "blowjob", "handjob"]) \
			&& getSubInfo().isReadyToCum() && !getSubInfo().canDoActions())
	if(subCums && getState() in ["subabouttocumcock", "blowjob"] && getSexType() != SexType.SlutwallSex \
			&& getSub().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)):
		var takeknotScore:float = KnotOdds.actionScore(3.0)
		if(getDom().hasPerk(Perk.CumUniqueBiology)):
			takeknotScore *= 3.0
		addAction("takesubknot", takeknotScore, "Take the knot", "Let their knot swell inside your throat", {A_PRIORITY: 1001})

func doAction(_indx:int, _id:String, _action:Dictionary):
	if(_id == "takesubknot"):
		satisfyGoals()
		var knotSuccess:bool = RNG.chance(KnotOdds.successChance(getDom().getKnottingChanceBy(BodypartSlot.Head, getSubID(0))))
		doCumBJSub(false)
		if(knotSuccess):
			setState("knotting")
			getDom().gotOrificeStretchedBy(BodypartSlot.Head, getSubID(0), true, 0.2)
			addText(RNG.pick([
				" A large knot "+RNG.pick(["swells", "blooms", "inflates"])+" at the base of {sub.yourHis} "+RNG.pick(["cock", "dick", "shaft"])+" as {sub.youHe} {sub.youHeVerb('finish')}, [b]locking it deep in {dom.your} throat[/b]!",
			]))
		else:
			setState("")
		return
	if(_id == "pullknotout"):
		if(RNG.chance(30)):
			setState("")
			var text:String = RNG.pick([
				"{dom.You} "+RNG.pick(["{dom.youVerb('pull')}", "{dom.youVerb('yank')}"])+" {dom.yourHis} head back and {sub.yourHis} knot finally slips out of {dom.yourHis} throat.",
			])
			if(getDom().hasEffect(StatusEffect.HasCumInsideMouth)):
				text += RNG.pick([
					" Some "+RNG.pick(["cum", "seed", "semen"])+" leaks out of {dom.yourHis} mouth as it comes free.",
				])
			stimulateSex(SUB_0, DOM_0, S_MOUTH, I_NORMAL, SPEED_VERYSLOW)
			addText(text)
			return
		getDom().gotOrificeStretchedBy(BodypartSlot.Head, getSubID(0), true, 0.1)
		stimulateSex(SUB_0, DOM_0, S_MOUTH, I_TEASE)
		addText(RNG.pick([
			"{dom.You} {dom.youVerb('try', 'tries')} to "+RNG.pick(["pull", "yank"])+" {sub.yourHis} knot out but {dom.youVerb('fail')}. It is stuck fast.",
		]))
		return
	.doAction(_indx, _id, _action)

func getAnimation():
	if(getState() == "knotting"):
		return [StageScene.SexOral, "knotted", {pc=SUB_0, npc=DOM_0}]
	return .getAnimation()
