extends Module

var name = "Oral Knotting"

var knotAttemptChance:float = 67.0
var knotSuccessChance:float = 70.0

func _init():
	id = "OralKnotting"
	author = "xrob1"
	sexActivities = [
		"res://Modules/OralKnotting/KnotSexOral.gd",
		"res://Modules/OralKnotting/KnotDomOralSexOnSub.gd",
		"res://Modules/OralKnotting/KnotSixtyNine.gd",
	]
	stageScenes = [
		"res://Modules/OralKnotting/Scenes/KnotSexOral.tscn",
		"res://Modules/OralKnotting/Scenes/KnotPuppySexOral.tscn",
		"res://Modules/OralKnotting/Scenes/KnotStocksSexOral.tscn",
		"res://Modules/OralKnotting/Scenes/KnotSex69.tscn",
		"res://Modules/OralKnotting/Scenes/KnotRopesOralSex.tscn",
	]

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addSliderOption("knotAttemptChance", "Knot attempt chance",
		"How often a dom with a knot goes for the throat knot instead of just cumming inside or "
		+ "pulling out. Subs with Cum Unique Biology still get knotted more often than this.",
		int(knotAttemptChance))
	foxModuleAPI.addSliderOption("knotSuccessChance", "Knot success chance",
		"Lowest chance a knot attempt catches. The game's own roll is used instead whenever it is "
		+ "already higher than this, so 0 means vanilla odds.",
		int(knotSuccessChance))
