extends "res://Game/SexEngine/SexActivity/SixtyNine.gd"
const KnotOdds := preload("res://Modules/OralKnotting/KnotOdds.gd")

var knottedDom:bool = false
var knottedSub:bool = false

func getTags(_indx:int) -> Array:
	if(state != "knotting"):
		return .getTags(_indx)
	state = "sex"
	var tags:Array = .getTags(_indx)
	state = "knotting"
	return tags

func canKnotDom() -> bool:
	return subFocus == BodypartSlot.Penis && !knottedDom && !isWearingStrapon(DOM_0) && getDom().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)
func canKnotSub() -> bool:
	return domFocus == BodypartSlot.Penis && !knottedSub && !isWearingStrapon(SUB_0) && getSub().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)
func doKnot(_indx:int):
	var isDom:bool = (_indx == DOM_0)
	var knotter:BaseCharacter = getSub()
	var taker:BaseCharacter = getDom()
	if(isDom):
		knotter = getDom()
		taker = getSub()
	var knotSuccess:bool = RNG.chance(KnotOdds.successChance(taker.getKnottingChanceBy(BodypartSlot.Head, knotter.getID())))
	if(isDom):
		getSubInfo().stimulateArousalZone(0.05, domFocus, 0.5)
		var _ok = doCumBJDom()
	else:
		getDomInfo().stimulateArousalZone(0.05, subFocus, 0.5)
		var _ok = doCumBJSub(false)
	cumAmount += 1
	if(cumAmount >= 2):
		satisfyGoals()
	if(!knotSuccess):
		if(isDom):
			addText("The knot " + RNG.pick(["swells", "blooms"]) + " too late to catch and {dom.your} " + RNG.pick(["cock", "member"]) + " slips back out from between {sub.yourHis} lips.")
		else:
			addText("The knot " + RNG.pick(["swells", "blooms"]) + " too late to catch and {sub.your} " + RNG.pick(["cock", "member"]) + " slips back out from between {dom.yourHis} lips.")
		return
	state = "knotting"
	if(isDom):
		knottedDom = true
	else:
		knottedSub = true
	taker.gotOrificeStretchedBy(BodypartSlot.Head, knotter.getID(), true, 0.2)
	if(knottedDom && knottedSub):
		addText("Both knots " + RNG.pick(["swell", "inflate"]) + " at once and [b]neither of them can pull away[/b] now, each one locked in the other's throat.")
		return
	if(isDom):
		addText("The moment {dom.you} " + RNG.pick(["cum", "finish"]) + ", a large knot " + RNG.pick(["swells", "blooms", "inflates"]) + " at the base of {dom.yourHis} " + RNG.pick(["cock", "member"]) + " and {dom.yourHis} whole weight settles down onto {sub.youHim}, [b]trapping it deep in {sub.yourHis} throat[/b]!")
		return
	addText("{sub.Your} knot " + RNG.pick(["swells", "blooms", "inflates"]) + " while {sub.youHe} {sub.youHeVerb('cum', 'cums')}, [b]locking {sub.yourHis} " + RNG.pick(["cock", "member"]) + " in {dom.your} throat[/b] before {dom.youHe} can pull off!")
func knotTurn(_indxBottom:int, _indxTop:int):
	cockWarmer(_indxBottom, _indxTop, BodypartSlot.Head, true)
	var bottomInfo:SexInfoBase = getDomOrSubInfo(_indxBottom)
	var topChar:BaseCharacter = getDomOrSubInfo(_indxTop).getChar()
	if(bottomInfo.getChar().getPenetrationFreeRoomBy(BodypartSlot.Head, topChar.getID()) > 0.0):
		return
	bottomInfo.addConsciousness(-RNG.randf_range(0.05, 0.15))
	addTextTopBottom(RNG.pick([
		"{<BOTTOM>.You} {<BOTTOM>.youVerb('choke')} and {<BOTTOM>.youVerb('gag')} because " + RNG.pick(["the knot is too big", "it's stuck too deep", "the knot blocks {<BOTTOM>.yourHis} airway"]) + ".",
		"{<BOTTOM>.You} " + RNG.pick(["{<BOTTOM>.youVerb('choke')}", "can't get enough air"]) + " with that knot in {<BOTTOM>.yourHis} throat!",
	]), _indxTop, _indxBottom)
func knotting_processTurn():
	if(knottedDom):
		knotTurn(SUB_0, DOM_0)
	if(knottedSub):
		knotTurn(DOM_0, SUB_0)
func knotting_getActions(_indx:int):
	if(_indx == DOM_0):
		if(knottedDom):
			addAction("pullknotout", 1.0, "Pull out", "Try to yank your knot out of their throat")
		if(isReadyToCumHandled(DOM_0) && canKnotDom()):
			addAction("knotinside", KnotOdds.actionScore(1.0), "Knot their throat", "Swell your knot in that tight throat", {A_PRIORITY: 1001})
	if(_indx == SUB_0):
		if(knottedSub):
			addAction("pullknotout", 1.0, "Pull out", "Try to yank your knot out of their throat")
		if(isReadyToCumHandled(SUB_0) && canKnotSub()):
			addAction("knotinside", KnotOdds.actionScore(1.0), "Knot their throat", "Swell your knot in that tight throat", {A_PRIORITY: 1001})
func knotting_doAction(_indx:int, _id:String, _action:Dictionary):
	if(_id == "knotinside"):
		doKnot(_indx)
		return
	if(_id == "pullknotout"):
		var isDom:bool = (_indx == DOM_0)
		var knotter:BaseCharacter = getSub()
		var taker:BaseCharacter = getDom()
		var other:int = DOM_0
		if(isDom):
			knotter = getDom()
			taker = getSub()
			other = SUB_0
		if(!RNG.chance(30)):
			taker.gotOrificeStretchedBy(BodypartSlot.Head, knotter.getID(), true, 0.1)
			stimulateSex(_indx, other, S_MOUTH, I_TEASE)
			if(isDom):
				addText("{dom.You} {dom.youVerb('try', 'tries')} to " + RNG.pick(["pull", "yank"]) + " free but {dom.youVerb('fail')}. The knot slowly deflates.")
			else:
				addText("{sub.You} {sub.youVerb('try', 'tries')} to " + RNG.pick(["pull", "yank"]) + " free but {sub.youVerb('fail')}. The knot slowly deflates.")
			return
		if(isDom):
			knottedDom = false
		else:
			knottedSub = false
		if(!knottedDom && !knottedSub):
			state = "sex"
		stimulateSex(_indx, other, S_MOUTH, I_NORMAL, SPEED_VERYSLOW)
		if(isDom):
			addText("{dom.You} {dom.youVerb('pull')} {dom.yourHis} knot out of {sub.yourHis} throat.")
		else:
			addText("{sub.You} {sub.youVerb('pull')} {sub.yourHis} knot out of {dom.yourHis} throat.")
		return

func getActions(_indx:int):
	if(state == "knotting"):
		return
	.getActions(_indx)

func sex_getActions(_indx:int):
	.sex_getActions(_indx)
	if(_indx == DOM_0 && isReadyToCumHandled(DOM_0) && canKnotDom()):
		addAction("knotinside", KnotOdds.actionScore(1.0), "Knot their throat", "Swell your knot in that tight throat", {A_PRIORITY: 1001})
	if(_indx == SUB_0 && isReadyToCumHandled(SUB_0) && canKnotSub()):
		addAction("knotinside", KnotOdds.actionScore(1.0), "Knot their throat", "Swell your knot in their throat", {A_PRIORITY: 1001})

func sex_doAction(_indx:int, _id:String, _action:Dictionary):
	if(_id == "knotinside"):
		doKnot(_indx)
		return
	.sex_doAction(_indx, _id, _action)

func focusAnimName() -> String:
	var aName:String = "F"
	if(subFocus == BodypartSlot.Penis):
		aName = "M"
	if(domFocus == BodypartSlot.Penis):
		return aName + "M"
	return aName + "F"
func getAnimation():
	if(state == "knotting"):
		return [StageScene.Sex69, focusAnimName()+"knotted", {npc=DOM_0, pc=SUB_0, bodyState={hard=true}, npcBodyState={hard=true}}]
	return .getAnimation()

func saveData():
	var data = .saveData()
	data["knottedDom"] = knottedDom
	data["knottedSub"] = knottedSub
	return data

func loadData(data):
	.loadData(data)
	knottedDom = SAVE.loadVar(data, "knottedDom", false)
	knottedSub = SAVE.loadVar(data, "knottedSub", false)
