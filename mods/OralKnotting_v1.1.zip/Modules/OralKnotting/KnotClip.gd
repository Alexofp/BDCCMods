extends Reference

const MOUTH := Vector3(0.988838, 0.028142, -0.017185)

const SLOW := 0.6
const IN_TIME := 1.2
const HOLD := 3.0
const TUG_AT := 1.8
const TUG_TIME := 0.5
const TUG_DEPTH := 0.06
const KEY_STEP := 0.05
const XFADE := 0.5
const HOLD_TAG := "KnotInside"
const IN_TAG := "KnotInsideStart"
const ROOT_BONE := "Hips"

static func knot(trees:Array, loops:Array, dollsOfTrees:Array, seats:Array, amount:float) -> void:
	for i in range(trees.size()):
		var now:String = str(trees[i]["parameters/StateMachine/playback"].get_current_node())
		if(now == inName(loops[i]) || now == holdName(loops[i])):
			return
	var deep:float = deepest(trees, loops, dollsOfTrees, seats)
	var shifts:Array = seatShifts(trees, loops, dollsOfTrees, deep, seats, amount)
	for i in range(trees.size()):
		var tree:AnimationTree = trees[i]
		var loop:String = loops[i]
		var player:AnimationPlayer = tree.get_node(tree.anim_player)
		var skeleton:Skeleton = dollsOfTrees[i].getDollSkeleton().getSkeleton()
		var playback = tree["parameters/StateMachine/playback"]
		build(player, loop, deep, rootShift(skeleton, player.get_animation(loop), deep, shifts[i]))
		install(tree.tree_root.get_node("StateMachine"), loop)
		playback.travel(holdName(loop))

static func named(loop:String, tag:String) -> String:
	var cut:int = loop.find_last("_")
	if(cut < 0 || !loop.ends_with("-loop")):
		return loop + tag
	return loop.substr(0, cut) + tag + loop.substr(cut)
static func inName(loop:String) -> String:
	return named(loop, IN_TAG)
static func holdName(loop:String) -> String:
	return named(loop, HOLD_TAG)

static func build(player:AnimationPlayer, loop:String, deep:float, shift:Vector3) -> void:
	var source:Animation = player.get_animation(loop)
	var times:Array = []
	var inAt:Array = []
	var step:int = int(ceil(IN_TIME / KEY_STEP))
	for k in range(step + 1):
		var u:float = float(k) / float(step)
		times.append(u * IN_TIME)
		inAt.append([deep - SLOW + SLOW * (1.0 - (1.0 - u) * (1.0 - u)), smoothstep(0.0, 1.0, u)])
	replace(player, inName(loop), copyAt(source, times, inAt, shift, IN_TIME, false))
	times = []
	var holdAt:Array = []
	step = int(ceil(HOLD / KEY_STEP))
	for k in range(step + 1):
		var t:float = float(k) / float(step) * HOLD
		times.append(t)
		holdAt.append([deep - tugAt(t), 1.0])
	replace(player, holdName(loop), copyAt(source, times, holdAt, shift, HOLD, true))

static func tugAt(t:float) -> float:
	if(t < TUG_AT || t > TUG_AT + TUG_TIME):
		return 0.0
	return TUG_DEPTH * sin(PI * (t - TUG_AT) / TUG_TIME)

static func copyAt(source:Animation, times:Array, at:Array, shift:Vector3, length:float, loop:bool) -> Animation:
	var made := Animation.new()
	made.length = length
	made.loop = loop
	made.step = source.step
	for t in range(source.get_track_count()):
		if(source.track_get_type(t) != Animation.TYPE_TRANSFORM):
			continue
		var track:int = made.add_track(Animation.TYPE_TRANSFORM)
		var path:NodePath = source.track_get_path(t)
		made.track_set_path(track, path)
		var isRoot:bool = path.get_subname_count() > 0 && path.get_subname(0) == ROOT_BONE
		for k in range(times.size()):
			var value:Array = source.transform_track_interpolate(t, fposmod(float(at[k][0]), source.length))
			var location:Vector3 = value[0]
			if(isRoot):
				location += shift * float(at[k][1])
			made.transform_track_insert_key(track, float(times[k]), location, value[1], value[2])
	return made

static func replace(player:AnimationPlayer, name:String, anim:Animation) -> void:
	if(player.has_animation(name)):
		player.remove_animation(name)
	var _ok = player.add_animation(name, anim)

static func install(machine:AnimationNodeStateMachine, loop:String) -> void:
	var into:String = inName(loop)
	var held:String = holdName(loop)
	if(machine.has_node(held)):
		return
	var others:Array = []
	for name in stateNames(machine):
		others.append(name)
	for name in [into, held]:
		var node := AnimationNodeAnimation.new()
		node.animation = name
		machine.add_node(name, node)
	for other in others:
		machine.add_transition(other, into, fade(false))
		machine.add_transition(into, other, fade(false))
		machine.add_transition(held, other, fade(false))
	machine.add_transition(into, held, fade(true))

static func fade(atEnd:bool) -> AnimationNodeStateMachineTransition:
	var made := AnimationNodeStateMachineTransition.new()
	made.xfade_time = XFADE
	if(atEnd):
		made.xfade_time = 0.0
		made.switch_mode = AnimationNodeStateMachineTransition.SWITCH_MODE_AT_END
		made.auto_advance = true
	return made

static func stateNames(machine:AnimationNodeStateMachine) -> Array:
	var names:Array = []
	for property in machine.get_property_list():
		var key:String = str(property["name"])
		if(key.begins_with("states/") && key.ends_with("/node")):
			names.append(key.trim_prefix("states/").trim_suffix("/node"))
	return names

const DEEP_STEP := 1.0 / 120.0
static func deepest(trees:Array, loops:Array, dollsOfTrees:Array, seats:Array) -> float:
	var tree:AnimationTree = trees[0]
	var length:float = tree.get_node(tree.anim_player).get_animation(loops[0]).length
	var best:float = INF
	var bestAt:float = 0.0
	var steps:int = int(ceil(length / DEEP_STEP))
	for k in range(steps):
		var t:float = float(k) * DEEP_STEP
		var sum := Vector3.ZERO
		for pair in seats:
			sum += pointAt(trees, loops, dollsOfTrees, pair[1], "Head", MOUTH, t) 				- pointAt(trees, loops, dollsOfTrees, pair[0], "Penis", Vector3.ZERO, t)
		var left:float = sum.length() / float(seats.size())
		if(left < best):
			best = left
			bestAt = t
	return bestAt

static func seatShifts(trees:Array, loops:Array, dollsOfTrees:Array, deep:float, seats:Array, amount:float) -> Array:
	var shifts:Array = []
	for _i in range(trees.size()):
		shifts.append(Vector3.ZERO)
	var gaps:Array = []
	for pair in seats:
		var base:Vector3 = pointAt(trees, loops, dollsOfTrees, pair[0], "Penis", Vector3.ZERO, deep)
		var axis:Vector3 = (pointAt(trees, loops, dollsOfTrees, pair[0], "Penis3", Vector3.ZERO, deep) - base).normalized()
		var gap:Vector3 = pointAt(trees, loops, dollsOfTrees, pair[1], "Head", MOUTH, deep) - base
		gaps.append(axis * gap.dot(axis))
	if(seats.size() == 1):
		shifts[dollsOfTrees.find(seats[0][0])] = gaps[0] * amount
		return shifts
	var s:Vector3 = (gaps[0] - gaps[1]) * 0.25 * amount
	shifts[dollsOfTrees.find(seats[0][0])] = s
	shifts[dollsOfTrees.find(seats[1][0])] = -s
	return shifts

static func pointAt(trees:Array, loops:Array, dollsOfTrees:Array, doll, bone:String, offset:Vector3, deep:float) -> Vector3:
	var i:int = dollsOfTrees.find(doll)
	var tree:AnimationTree = trees[i]
	var player:AnimationPlayer = tree.get_node(tree.anim_player)
	var skeleton:Skeleton = doll.getDollSkeleton().getSkeleton()
	var idx:int = skeleton.find_bone(bone)
	if(idx < 0):
		return Vector3.ZERO
	return (skeleton.global_transform * poseAt(skeleton, player.get_animation(loops[i]), deep, idx)).xform(offset)

static func poseAt(skeleton:Skeleton, anim:Animation, t:float, idx:int) -> Transform:
	var chain:Array = []
	var at:int = idx
	while(at >= 0):
		chain.push_front(at)
		at = skeleton.get_bone_parent(at)
	var result := Transform.IDENTITY
	for bone in chain:
		result = result * skeleton.get_bone_rest(bone) * skeleton.get_bone_custom_pose(bone) \
			* trackPose(skeleton, anim, t, bone)
	return result

static func trackPose(skeleton:Skeleton, anim:Animation, t:float, bone:int) -> Transform:
	var name:String = skeleton.get_bone_name(bone)
	for track in range(anim.get_track_count()):
		var path:NodePath = anim.track_get_path(track)
		if(anim.track_get_type(track) == Animation.TYPE_TRANSFORM && path.get_subname_count() > 0 \
				&& path.get_subname(0) == name):
			var value:Array = anim.transform_track_interpolate(track, fposmod(t, anim.length))
			return Transform(Basis(value[1]).scaled(value[2]), value[0])
	return Transform.IDENTITY

static func rootShift(skeleton:Skeleton, anim:Animation, deep:float, world:Vector3) -> Vector3:
	var idx:int = skeleton.find_bone(ROOT_BONE)
	if(idx < 0 || world.length() < 0.000001):
		return Vector3.ZERO
	var frame:Transform = skeleton.get_bone_rest(idx) * skeleton.get_bone_custom_pose(idx)
	var parent:int = skeleton.get_bone_parent(idx)
	if(parent >= 0):
		frame = poseAt(skeleton, anim, deep, parent) * frame
	return (skeleton.global_transform.basis * frame.basis).inverse().xform(world)
