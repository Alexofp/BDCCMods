extends "res://Game/SexEngine/SexActivity/SexOral.gd"
const KnotOdds := preload("res://Modules/OralKnotting/KnotOdds.gd")

func getTags(_indx:int) -> Array:
	var tags:Array = .getTags(_indx)
	if(_indx == SUB_0 && state == "knotting" && !(SexActivityTag.MouthUsed in tags)):
		tags.append(SexActivityTag.MouthUsed)
	return tags

func processTurn():
	var result = .processTurn()
	if(state == "knotting" && !isForce && getSubInfo().isUnconscious()):
		isForce = true
	return result

func knotting_processTurn():
	cockWarmer(SUB_0, DOM_0, BodypartSlot.Head, true)

	var freeRoom = getSub().getPenetrationFreeRoomBy(BodypartSlot.Head, getDomID(0))
	if(freeRoom <= 0.0):
		getSubInfo(0).addConsciousness(-RNG.randf_range(0.05, 0.15))
		addText(RNG.pick([
			"{sub.You} {sub.youVerb('choke')} and {sub.youVerb('gag')} because "+RNG.pick(["the knot is too big", "it's stuck too deep", "the knot blocks {sub.yourHis} airway"])+".",
			"{sub.You} "+RNG.pick(["{sub.youVerb('choke')}", "{sub.youVerb('suffocate')}", "can't get enough air"])+" with that knot in {sub.yourHis} throat!",
			" "+RNG.pick(["A few tears stream", "A single tear streams"])+" down {sub.yourHis} cheeks while the knot blocks {sub.yourHis} airway.",
		]))

func getActions(_indx:int):
	.getActions(_indx)
	if(_indx != DOM_0):
		return
	if(state == "knotting"):
		for i in range(actionsResult.size() - 1, -1, -1):
			if(actionsResult[i].get("id") == "stop"):
				actionsResult.remove(i)
		addAction("pullknotout", 1.0, "Pull out", "Try to yank your knot out")
		return
	if(state in ["blowjob", "deepthroat"] && isReadyToCumHandled(DOM_0) \
			&& getDom().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)):
		var rivals:float = 1.0
		if(!isStraponSex()):
			rivals = 2.0
		var bjknotScore:float = KnotOdds.actionScore(rivals)
		if(getSub().hasPerk(Perk.CumUniqueBiology)):
			bjknotScore *= 3.0
		addAction("bjknotinside", bjknotScore, "Knot their throat", "Swell your knot in that tight throat", {A_PRIORITY: 1001})

func doAction(_indx:int, _id:String, _action:Dictionary):
	if(_id == "bjknotinside"):
		var isDeepthroat:bool = (state == "deepthroat")
		var knotSuccess:bool = RNG.chance(KnotOdds.successChance(getSub().getKnottingChanceBy(BodypartSlot.Head, getDomID(0))))

		cumInside(DOM_0, SUB_0, S_MOUTH, {isDeepthroat=isDeepthroat})
		if(isStraponSex()):
			getDomInfo().cum()

		if(knotSuccess):
			state = "knotting"
			getSub().gotOrificeStretchedBy(BodypartSlot.Head, getDomID(0), true, 0.2)
			addText(RNG.pick([
				"The moment {dom.you} "+RNG.pick(["cum", "finish"])+", a large knot "+RNG.pick(["swells", "blooms", "inflates"])+" at the base of {dom.yourHis} "+getDickName()+", [b]trapping it deep in {sub.yourHis} throat[/b]!",
			]))
		else:
			state = ""

		satisfyGoals()
		applyTallymarkIfNeeded(BodypartSlot.Head)
		return
	if(_id == "pullknotout"):
		if(RNG.chance(30)):
			state = ""
			var text:String = RNG.pick([
				"{dom.You} "+RNG.pick(["{dom.youVerb('pull')}", "{dom.youVerb('yank')}"])+" {dom.yourHis} knot out of {sub.yourHis} throat.",
			])

			if(getSub().hasEffect(StatusEffect.HasCumInsideMouth)):
				text += RNG.pick([
					" Some "+RNG.pick(["cum", "seed", "semen"])+" leaks out of {sub.yourHis} mouth as {dom.youHim} is pulled free.",
				])
			stimulateSex(DOM_0, SUB_0, S_MOUTH, I_NORMAL, SPEED_VERYSLOW)
			addText(text)
			return
		else:
			var text:String = RNG.pick([
				"{dom.You} {dom.youVerb('try', 'tries')} to "+RNG.pick(["pull", "yank"])+" {dom.yourHis} knot out but {dom.youVerb('fail')}. The knot slowly deflates.",
			])
			getSub().gotOrificeStretchedBy(BodypartSlot.Head, getDomID(), true, 0.1)
			stimulateSex(DOM_0, SUB_0, S_MOUTH, I_TEASE)
			addText(text)
			return
	.doAction(_indx, _id, _action)

const MOREPOSES_KNOTTED := {
	"POSE_TABLE": [StageScene.SexOralTable, "suckinside"],
	"POSE_CHAIR": [StageScene.ChairOral, "suckinside"],
}
func getAnimation():
	if(state != "knotting"):
		return .getAnimation()
	if(getSexType() == SexType.BitchsuitSex):
		return [StageScene.PuppySexOral, "knotted", {pc=DOM_0, npc=SUB_0}]
	if(isStocksSex()):
		return [StageScene.StocksSexOral, "knotted", {npc=DOM_0, pc=SUB_0}]
	var pose = get("currentPose")
	if(typeof(pose) == TYPE_STRING && MOREPOSES_KNOTTED.has(pose)):
		return [MOREPOSES_KNOTTED[pose][0], MOREPOSES_KNOTTED[pose][1], {pc=DOM_0, npc=SUB_0}]
	if(pose == "POSE_ROPES"):
		return [StageScene.RopesOralSex, "knotted", {pc=SUB_0, npc=DOM_0}]
	if(isForce):
		return [StageScene.SexOralForced, "suckinside", {pc=DOM_0, npc=SUB_0}]
	return [StageScene.SexOral, "knotted", {pc=DOM_0, npc=SUB_0}]

func isActivityImpossibleShouldStop() -> bool:
	if(state == "knotting" && !getDom().hasReachablePenis() && !getDom().isWearingStrapon()):
		return true
	return .isActivityImpossibleShouldStop()
