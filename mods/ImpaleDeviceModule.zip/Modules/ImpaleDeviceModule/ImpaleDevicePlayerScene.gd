extends SceneBase

func _init():
	sceneID = "ImpaleDevicePlayerScene"

func _run():
	if(state == ""):
		playAnimation("ImpaleDeviceStage", "idle", {noDoll=true})

		saynn("A strange transparent device stands here, fixed to the floor. The glass shell is open, showing off a thick pole inside.")

		addButton("Step inside", "Enter the device", "step_inside")
		addButton("Leave", "Not now", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "step_inside"):
		endScene()
		GM.main.IS.startInteraction("InImpaleDevice", {inmate="pc"})
		return
