extends Module

func _init():
	id = "ImpaleDeviceModule"
	author = "Doggo"

	scenes = [
		"res://Modules/ImpaleDeviceModule/ImpaleDevicePlayerScene.gd",
	]

	items = [
		"res://Modules/ImpaleDeviceModule/ImpaleDeviceStatic.gd",
	]

	events = [
		"res://Modules/ImpaleDeviceModule/ImpaleDeviceEvent.gd",
	]

	stageScenes = [
		"res://Modules/ImpaleDeviceModule/Player/StageScene3D/ImpaleDeviceStage.tscn",
	]

	worldEdits = [
		"res://Modules/ImpaleDeviceModule/ImpaleDeviceWorldEdit.gd",
	]

func register():
	.register()

	GlobalRegistry.registerInteraction("res://Modules/ImpaleDeviceModule/InImpaleDevice.gd")
	GlobalRegistry.registerInteraction("res://Modules/ImpaleDeviceModule/ImpalePunishInteractionPatch.gd")
