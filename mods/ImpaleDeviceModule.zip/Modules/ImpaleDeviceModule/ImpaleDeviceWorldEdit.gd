extends WorldEditBase

const DEVICE_ROOM = "main_hallroom8"
const DEVICE_DESC = "This section of the main hall has been modified into a small public punishment spot. A transparent impale device stands near the wall, bolted into the floor and impossible to miss. Its glass shell is open for now, showing a thick, polished pole waiting inside while passing inmates occasionally glance at it with curiosity."

func _init():
	id = "ImpaleDeviceWorldEdit"
	# Keep applying it so saves / reloads / map refreshes don't lose the icon or description.
	isRegular = true

func apply(_world: GameWorld):
	if(_world == null):
		return

	var room = _world.getRoomByID(DEVICE_ROOM)
	if(room == null):
		return

	room.roomName = "Main hall - public device"
	room.roomDescription = DEVICE_DESC
	room.blindRoomDescription = "You can hear the faint mechanical hum of a public device somewhere nearby."
	room.setRoomSprite(RoomStuff.RoomSprite.IMPORTANT)
