extends EventBase

func _init():
	id = "ImpaleDeviceEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "main_hallroom8")

func applyRoomVisuals():
	var room = GM.world.getRoomByID("main_hallroom8")
	if(room == null):
		return

	room.roomName = "Main hall - Impale Device"
	room.roomDescription = "This section of the main hall has been modified into a small public punishment spot. A transparent impale device stands near the wall, bolted into the floor and impossible to miss. Its glass shell is open for now, showing a thick, polished pole inside."
	room.blindRoomDescription = "You can hear the faint mechanical hum of a public device somewhere nearby."
	room.setRoomSprite(RoomStuff.RoomSprite.IMPORTANT)

func run(_triggerID, _args):
	applyRoomVisuals()
	addButtonUnlessLate("Impale device", "Inspect the public impale device", "impale_device")

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "impale_device"):
		runScene("ImpaleDevicePlayerScene")
