extends "res://Game/InteractionSystem/Interactions/PunishInteraction.gd"

const DEVICE_ROOM = "main_hallroom8"

func _init():
	id = "PunishInteraction"

func canGetToImpaleDevice() -> bool:
	var room = GM.world.getRoomByID(getLocation())
	if(room == null):
		return false

	var floorID:String = room.getFloorID()
	return floorID in ["MainHall", "Cellblock"]

func getImpaleDeviceScoreMult() -> float:
	if(isPlayerInvolved()):
		return 1.0

	var amount:int = GM.main.IS.getInteractionsOfTypeAmount("InImpaleDevice")

	if(amount >= 3):
		return 0.01
	if(amount >= 2):
		return 0.25

	return 1.0

func init_text():
	.init_text()

	var punisherRestraintsPreventPulling:bool = getRoleChar("punisher").hasBlockedHands() || getRoleChar("punisher").hasBoundArms()
	var targetHasCollar:bool = getRoleChar("target").getInventory().hasEquippedItemWithTag(ItemTag.AllowsEnslaving)

	if(!punisherRestraintsPreventPulling && targetHasCollar && canGetToImpaleDevice()):
		addAction("impale_device", "Impale device", "Force them into the public impale device!", "punishMean", 0.25 * getImpaleDeviceScoreMult(), 60, {})
	elif(punisherRestraintsPreventPulling):
		addDisabledAction("Impale device", "You can't do that with restraints on your arms..")
	else:
		addDisabledAction("Impale device", ""+("They need to be wearing a collar for this!" if canGetToImpaleDevice() else "The impale device is too far.."))

func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "impale_device"):
		setState("about_to_impale", "punisher")
		return

	.init_do(_id, _args, _context)

func about_to_impale_text():
	saynn("{punisher.name} clips a leash to {target.your} collar.")
	saynn("Looks like {punisher.he} {punisher.isAre} dragging {target.you} toward the public impale device.")

	addAction("impale", "Escort", "Escort them towards the public device", "default", 1.0, 60, {})

func about_to_impale_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "impale"):
		setState("pulling_to_impale", "punisher")
		goTowards(DEVICE_ROOM)

func pulling_to_impale_text():
	saynn("{punisher.name} is pulling {target.name} towards the public impale device.")

	addAction("impale", "Escort", "Pull them towards the device", "default", 1.0, 60, {})

func pulling_to_impale_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "impale"):
		goTowards(DEVICE_ROOM)

		if(getLocation() == DEVICE_ROOM):
			setState("about_to_lock_impale", "punisher")

func about_to_lock_impale_text():
	saynn("{punisher.name} guides {target.name} into the transparent device.")
	saynn("The pole inside it looks thick and unforgiving, positioned to spread {target.your} {target.anusStretch} anus open.")

	addAction("lock_them", "Lock them", "Force them onto the device", "punishMean", 1.0, 120, {})

func about_to_lock_impale_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "lock_them"):
		affectAffection("target", "punisher", -0.1)
		addRepScore("target", RepStat.Alpha, -3.0)
		setState("in_impale_device", "punisher")

func in_impale_device_text():
	saynn("{punisher.name} locks {target.name} inside the device.")
	saynn("The mechanism closes with a heavy click, forcing {target.your} body down until the thick pole stretches {target.your} {target.anusStretch} ass around it.")

	addAction("leave", "Leave", "Leave them there", "default", 1.0, 30, {})

func in_impale_device_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()
		startInteraction("InImpaleDevice", {inmate=getRoleID("target")}, {punisherID=getRoleID("punisher")})

func getAnimData() -> Array:
	if(getState() == "in_impale_device"):
		return ["ImpaleDeviceStage", "idle", {pc="target"}]

	if(getState() == "pulling_to_impale"):
		if(getLocation() != DEVICE_ROOM):
			return [StageScene.Duo, "walk", {pc="target", npc="punisher", npcAction="walk", flipNPC=true, bodyState={leashedBy="punisher"}}]

	return .getAnimData()

func isRoleOnALeash(_role:String) -> bool:
	if(_role == "target" && getState() in ["about_to_impale", "pulling_to_impale", "about_to_lock_impale"]):
		return true

	return .isRoleOnALeash(_role)

func isRoleLeashing(_role:String) -> bool:
	if(_role == "punisher" && getState() in ["about_to_impale", "pulling_to_impale", "about_to_lock_impale"]):
		return true

	return .isRoleLeashing(_role)
