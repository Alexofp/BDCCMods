extends BaseStageScene3D

const IMPALE_IDLE_ANIM = preload("res://Modules/ImpaleDeviceModule/Animations/ImpaleIdle.tres")
const IMPALE_POLE_TEXTURE_PATH = "res://Modules/ImpaleDeviceModule/Textures/impale_pole.png"

onready var doll = $Doll3D
onready var dollOriginalTranslation = $Doll3D.translation
onready var dollOriginalScale = $Doll3D.scale

var activeAnim := false
var activeAnimName := "ImpaleIdle"

func _init():
	id = "ImpaleDeviceStage"

func _ready():
	ensurePropTexture()

func getSupportedStates():
	return ["idle"]

func getVarNpcs():
	return ["pc"]

func ensurePropTexture():
	var prop = get_node_or_null("ImpalePole")
	if(prop == null):
		return

	# In exported ZIP mods, .import remaps for new PNGs can point to missing .stex files.
	# So we load the raw PNG manually and create the texture at runtime.
	var img = Image.new()
	var err = img.load(IMPALE_POLE_TEXTURE_PATH)
	if(err == OK):
		var tex = ImageTexture.new()
		tex.create_from_image(img, 0)
		prop.texture = tex
	else:
		prop.texture = createFallbackPoleTexture()

	prop.visible = true

func createFallbackPoleTexture():
	var img = Image.new()
	img.create(96, 512, false, Image.FORMAT_RGBA8)
	img.lock()

	for y in range(512):
		for x in range(96):
			var dx = abs(x - 48)
			if(dx < 10):
				img.set_pixel(x, y, Color(0.78, 0.78, 0.85, 1.0))
			elif(dx < 14):
				img.set_pixel(x, y, Color(0.25, 0.25, 0.35, 0.8))
			else:
				img.set_pixel(x, y, Color(0.0, 0.0, 0.0, 0.0))

	img.unlock()

	var tex = ImageTexture.new()
	tex.create_from_image(img, 0)
	return tex

func hideDollForPreview():
	activeAnim = false
	doll.visible = false
	doll.translation = dollOriginalTranslation + Vector3(0.0, -1000.0, 0.0)
	doll.scale = Vector3(0.001, 0.001, 0.001)

func showDollForScene():
	doll.translation = dollOriginalTranslation
	doll.scale = dollOriginalScale
	doll.visible = true

func playAnimation(animID, _args = {}):
	ensurePropTexture()

	if(animID != "idle"):
		Log.printerr("Action "+str(animID)+" is not found for stage "+str(id))
		return

	# Preview mode: show only the device, no character inside.
	if(_args.has("noDoll") && _args["noDoll"]):
		hideDollForPreview()
		return

	showDollForScene()

	if(_args.has("pc")):
		doll.prepareCharacter(_args["pc"])
	else:
		doll.prepareCharacter("pc")

	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})

	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)

	var ap = doll.getAnimPlayer()
	if(ap == null):
		Log.printerr("ImpaleDeviceStage: doll.getAnimPlayer() returned null")
		return

	ap.root_node = NodePath("..")

	if(ap.has_animation(activeAnimName)):
		ap.remove_animation(activeAnimName)

	var anim = IMPALE_IDLE_ANIM.duplicate(true)
	anim.loop = true
	ap.add_animation(activeAnimName, anim)

	ap.playback_process_mode = AnimationPlayer.ANIMATION_PROCESS_IDLE
	ap.stop()
	ap.seek(0.0, true)
	ap.play(activeAnimName, -1.0, 1.0)

	activeAnim = true

func _process(delta):
	if(!activeAnim):
		return

	var ap = doll.getAnimPlayer()
	if(ap == null):
		return

	if(!ap.has_animation(activeAnimName)):
		return

	ap.advance(delta)
