extends PawnInteractionBase

const DEVICE_ROOM = "main_hallroom8"

var punisherID:String = ""
var struggleText:String = ""
var savedHow:String = ""
var saveTryCount:int = 0
var shoutedForHelpCount:int = 0
var showCum:bool = false
var didInitialStretch:bool = false

func _init():
	id = "InImpaleDevice"

func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("inmate", _pawns["inmate"])

	if(_args.has("punisherID")):
		punisherID = _args["punisherID"]

	setLocation(DEVICE_ROOM)
	setState("", "inmate")

	getRoleChar("inmate").getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("ImpaleDeviceStatic"))

	if(!didInitialStretch):
		applyPoleStretch(0.8)
		didInitialStretch = true

func applyPoleStretch(stretchMult:float = 1.0):
	var inmate = getRoleChar("inmate")
	if(inmate == null):
		return
	if(!inmate.hasBodypart(BodypartSlot.Anus)):
		return

	# Big pole, but not absurd. This uses the same orifice-loosening system as penetration.
	inmate.gotOrificeStretchedWith(BodypartSlot.Anus, 18.0, false, stretchMult)

func init_text():
	saynn("{inmate.You} {inmate.youAre} locked inside the public impale device.")
	saynn("The transparent shell keeps {inmate.yourHis} body pinned in place while the thick pole keeps {inmate.yourHis} {inmate.anusStretch} ass stretched around it.")

	var inmate = getRoleChar("inmate")
	var thePawn = getRolePawn("inmate")

	if(!thePawn.isPlayer()):
		saynn("{inmate.name} has "+str(inmate.getStamina())+" stamina left.")

	addAction("rest", "Rest", "Rest for a few hours and recover stamina", "default", 0.05, 7200, {})
	addAction("yell", "Yell", "Yell to get someone's attention", "default", 2.0, 180, {})
	addAction("wait", "Wait", "Pass some time quietly", "default", 0.2, 900, {})

	if(inmate.getStamina() > 0):
		addAction("struggle", "Struggle", "Try to force the mechanism open", "default", 10.0, 300, {})
	else:
		addDisabledAction("Struggle", "You are too exhausted to struggle.")

	if(!inmate.getInventory().hasLockedStaticRestraints()):
		addAction("escape", "Escape", "Slip out of the device", "default", 1000.0, 0, {})
	else:
		addDisabledAction("Escape", "The device is still locked.")

func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "rest"):
		getRoleChar("inmate").addStamina(100)
		setState("after_rest", "inmate")
		checkSleep()
		return

	if(_id == "yell"):
		shoutedForHelpCount += 1
		setState("about_to_yell", "inmate")
		return

	if(_id == "wait"):
		setState("after_wait", "inmate")
		checkSleep()
		return

	if(_id == "struggle"):
		if(getRolePawn("inmate").isPlayer()):
			runScene("StrugglingScene", [false, false])
		else:
			setState("about_to_struggle", "inmate")
		return

	if(_id == "escape"):
		getRoleChar("inmate").getInventory().clearStaticRestraints()
		stopMe()
		return

func after_rest_text():
	saynn("{inmate.You} {inmate.youVerb('try', 'tries')} to rest inside the device. Hours pass slowly, but {inmate.yourHis} strength returns.")

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 0, {})

func after_rest_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		if(!shoutForInterruptions("inmate", 12, 10, 1.25, "You notice "+getRoleChar("inmate").getName()+" resting helplessly inside the public impale device.")):
			setState("", "inmate")

func about_to_yell_text():
	if(getRoleChar("inmate").isGagged()):
		saynn("{inmate.You} {inmate.youAre} gagged, but {inmate.youHe} still {inmate.youVerb('try', 'tries')} to make noise and get someone's attention.")
	else:
		saynn("{inmate.You} {inmate.youVerb('yell')} for someone to notice {inmate.youHim} trapped in the device.")

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 180, {})

func about_to_yell_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		getRoleChar("inmate").addStamina(20)

		if(!shoutForInterruptions("inmate", 14, 12, 1.5, "You hear "+getRoleChar("inmate").getName()+" yelling from inside the public impale device.")):
			setState("after_yell", "inmate")
			checkSleep()

func after_yell_text():
	saynn("No one comes after {inmate.your} yelling. At least {inmate.youHe} managed to catch {inmate.yourHis} breath.")

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 30, {})

func after_yell_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		setState("", "inmate")

func after_wait_text():
	saynn("{inmate.You} {inmate.youVerb('wait')} quietly as time passes around the device.")

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 0, {})

func after_wait_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		if(!shoutForInterruptions("inmate", 3, 3, 0.35, "You notice "+getRoleChar("inmate").getName()+" trapped inside the public impale device.")):
			setState("", "inmate")

func about_to_struggle_text():
	saynn("{inmate.name} is trying to struggle out of the device.")

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 60, {})

func about_to_struggle_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		var inmate = getRoleChar("inmate")
		var struggleData:Dictionary = inmate.doStruggleOutOfRestraints()

		if(struggleData.empty()):
			struggleText = "{inmate.You} {inmate.youVerb('struggle')}, but nothing happens."
		else:
			struggleText = struggleData["text"]

		setState("after_struggle", "inmate")

func after_struggle_text():
	saynn(struggleText)

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 60, {})

func after_struggle_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		setState("", "inmate")

func getInterruptActions(_pawn:CharacterPawn) -> Array:
	var result:Array = []

	# Blokujemy tylko aktywne używanie maszyny / pomoc.
	# Yell, wait, rest i struggle nadal pozwalają podejść.
	if(getState() in [
		"about_to_vibrate",
		"vibrating",
		"after_vibrate",
		"about_to_help",
		"help_after_try",
		"help_unlocked",
	]):
		return result

	if(_pawn.charID == getCharIDByRole("inmate")):
		return result

	if(getPawnAmount() == 1):
		if(!_pawn.isPlayer() || GM.pc.getCredits() >= 1):
			result.append({
				id = "vibrate",
				name = "Insert credit",
				desc = "Pay 1 credit to activate the device's vibration mode",
				score = 12.0,
				scoreType = "sexUse",
				scoreRole = "inmate",
				args = {},
			})

		result.append({
			id = "help",
			name = "Help",
			desc = "Spend some stamina to help loosen the device",
			score = 0.8,
			scoreType = "help",
			scoreRole = "inmate",
			args = {},
		})

	return result

func doInterruptAction(_pawn:CharacterPawn, _id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "vibrate"):
		doInvolvePawn("user", _pawn)
		setState("about_to_vibrate", "user")
		return

	if(_id == "help"):
		saveTryCount = 0
		doInvolvePawn("saver", _pawn)
		setState("about_to_help", "saver")
		return

func about_to_help_text():
	saynn("{saver.name} approaches the device and starts checking the lock.")
	saynn("Instead of opening it outright, {saver.he} can only help loosen the mechanism a little.")

	if(getRoleChar("saver").getStamina() > 0):
		addAction("help", "Help", "Spend some stamina helping", "help", 1.0, 120, {})
	else:
		addDisabledAction("Help", "You don't have enough stamina.")

	addAction("leave", "Leave", "Leave them there", "justleave", 1.0, 30, {})

func about_to_help_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "help"):
		helpUsingStamina()
		return

	if(_id == "leave"):
		doRemoveRole("saver")
		setState("", "inmate")
		return

func helpUsingStamina():
	saveTryCount += 1

	getRoleChar("saver").addStamina(-15)

	var inmate = getRoleChar("inmate")
	var struggleData:Dictionary = inmate.doStruggleOutOfRestraints(false, true, getRoleChar("saver"), 1.0)

	if(struggleData.empty()):
		struggleText = "{saver.name} tries to help, but the mechanism barely shifts."
	else:
		struggleText = struggleData["text"]

	if(inmate.getInventory().hasItemIDEquipped("ImpaleDeviceStatic")):
		setState("help_after_try", "inmate")
	else:
		savedHow = "help"
		setState("help_unlocked", "inmate")
		affectAffection("inmate", "saver", 0.1)

func help_after_try_text():
	saynn(struggleText)
	saynn("The device is a little looser now, but {inmate.you} {inmate.youAre} still trapped.")

	addAction("continue", "Continue", "Keep waiting", "default", 1.0, 60, {})

func help_after_try_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		doRemoveRole("saver")
		setState("", "inmate")

func help_unlocked_text():
	saynn(struggleText)
	saynn("The lock finally gives in. {inmate.You} can now slip out.")

	addAction("escape", "Escape", "Leave the device", "default", 1.0, 60, {})

func help_unlocked_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "escape"):
		getRoleChar("inmate").getInventory().clearStaticRestraints()
		stopMe()

func about_to_vibrate_text():
	saynn("{user.name} approaches the device and inserts a single credit. A low mechanical hum begins to build around {inmate.you}.")

	addAction("start", "Start", "Activate the vibration", "default", 1.0, 60, {})

func about_to_vibrate_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "start"):
		if(getRolePawn("user").isPlayer()):
			GM.pc.addCredits(-1)

		if(getRolePawn("inmate").isPlayer()):
			GM.pc.addCredits(1)
			addMessage("You received 1 credit from the device.")

		setState("vibrating", "inmate")

func vibrating_text():
	var inmate = getRoleChar("inmate")

	saynn("The device vibrates around {inmate.you}, sending steady waves of stimulation through {inmate.yourHis} trapped body.")
	saynn("The pole keeps spreading {inmate.yourHis} {inmate.anusStretch} hole while the vibration slowly pushes {inmate.youHim} closer to the edge.")
	saynn("Arousal: "+str(Util.roundF(inmate.getArousal() * 100.0, 1))+"%")

	if(inmate.getArousal() >= 1.0):
		addAction("cum", "Cum", "You can't endure it anymore", "default", 1.0, 60, {})
	else:
		addAction("endure", "Endure", "Try to hold back", "default", 1.0, 60, {})

func vibrating_do(_id:String, _args:Dictionary, _context:Dictionary):
	var inmate = getRoleChar("inmate")

	if(_id == "endure"):
		inmate.addLust(12)
		inmate.addArousal(0.16 + inmate.getLustLevel() * 0.14)
		applyPoleStretch(0.15)

		if(inmate.getArousal() > 1.0):
			inmate.setArousal(1.0)

		setState("vibrating", "inmate")
		return

	if(_id == "cum"):
		showCum = true
		inmate.orgasmFrom(getCharIDByRole("user"))
		inmate.setArousal(0.0)

		setState("after_vibrate", "user")
		return

func after_vibrate_text():
	saynn("The vibration finally dies down after forcing {inmate.you} over the edge. {user.name} steps away from the device.")

	addAction("continue", "Continue", "Recover", "default", 1.0, 60, {})

func after_vibrate_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		doRemoveRole("user")
		setState("", "inmate")

func checkSleep():
	if(GM.main.isVeryLate() && getRolePawn("inmate").isPlayer()):
		setState("about_to_sleep", "inmate")

func about_to_sleep_text():
	saynn("It's getting very late. The hall grows quiet.")
	saynn("Looks like nobody is going to let {inmate.you} out tonight.")

	addAction("sleep", "Sleep", "Try to sleep inside the device", "default", 1.0, 60, {})

func about_to_sleep_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "sleep"):
		GM.main.startNewDay()
		getRoleChar("inmate").addStamina(50)
		setState("after_sleep", "inmate")

func after_sleep_text():
	saynn("{inmate.You} {inmate.youVerb('wake')} up still trapped inside the device.")
	saynn("Welcome to day "+str(GM.main.getDays())+".")

	addAction("continue", "Continue", "See what happens next", "default", 1.0, 60, {})

func after_sleep_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "continue"):
		setState("", "inmate")

func getAnimData() -> Array:
	var inmate = getRoleChar("inmate")

	var args = {
		pc = "inmate",
	}

	var bodyState = {
		naked = true,
	}

	if(inmate != null && inmate.hasPenis()):
		if(getState() in ["vibrating", "after_vibrate"] || inmate.isReadyToPenetrate()):
			bodyState["hard"] = true

	if(!bodyState.empty()):
		args["bodyState"] = bodyState

	if(showCum && inmate != null && inmate.hasPenis()):
		args["pcCum"] = true

	return ["ImpaleDeviceStage", "idle", args]

func getActivityIconForRole(_role:String):
	if(_role == "inmate"):
		return RoomStuff.PawnActivity.Stocks
	return RoomStuff.PawnActivity.Chat

func getPreviewLineForRole(_role:String) -> String:
	if(_role == "inmate"):
		if(getState() in ["vibrating", "after_vibrate"]):
			return "{inmate.name} is vibrating inside the public impale device."
		if(getState() in ["about_to_help", "help_after_try", "help_unlocked"]):
			return "{inmate.name} is being helped by {saver.name}."
		return "{inmate.name} is locked inside the public impale device."

	if(_role == "user"):
		return "{user.name} is using the public impale device."

	if(_role == "saver"):
		return "{saver.name} is helping {inmate.name} with the public impale device."

	return .getPreviewLineForRole(_role)

func onStopped():
	if(hasRoleChar("inmate")):
		getRoleChar("inmate").getInventory().clearStaticRestraints()

func saveData():
	var data = .saveData()

	data["punisherID"] = punisherID
	data["struggleText"] = struggleText
	data["savedHow"] = savedHow
	data["saveTryCount"] = saveTryCount
	data["shoutedForHelpCount"] = shoutedForHelpCount
	data["showCum"] = showCum
	data["didInitialStretch"] = didInitialStretch

	return data

func loadData(_data):
	.loadData(_data)

	punisherID = SAVE.loadVar(_data, "punisherID", "")
	struggleText = SAVE.loadVar(_data, "struggleText", "")
	savedHow = SAVE.loadVar(_data, "savedHow", "")
	saveTryCount = SAVE.loadVar(_data, "saveTryCount", 0)
	shoutedForHelpCount = SAVE.loadVar(_data, "shoutedForHelpCount", 0)
	showCum = SAVE.loadVar(_data, "showCum", false)
	didInitialStretch = SAVE.loadVar(_data, "didInitialStretch", false)
