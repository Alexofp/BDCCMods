extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Fluffy sheathed humanoid penis"
	id = "humanpenisfluffsheath"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Human/HumanSheathPenis/HumanSheathFluffyPenis.tscn"

func getVulgarName() -> String:
	return "cock"

func generateRandomColors(_dynamicCharacter):
	pass
