extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Spiney dragon penis"
	id = "dragonpenisbarb"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getLewdAdjective():
	return RNG.pick(["knotted", "spined", "dragon", "barbed", "ridged",])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Ridged/RidgedBarbedPenis/RidgedBarbedPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisRidges: true,
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
	}
