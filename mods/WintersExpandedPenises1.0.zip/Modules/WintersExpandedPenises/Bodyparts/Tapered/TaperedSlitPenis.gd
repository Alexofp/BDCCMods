extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Tapered slitted penis"
	id = "taperedpenisslit"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getLewdAdjective():
	return RNG.pick(["slitted", "tapered", "smooth"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Tapered/TaperedSlitPenis/TaperedSlitPenis.tscn"

func getCharacterCreatorDesc():
	return "A tapered penis with a genital slit and no balls (visually, the game will still act like you have balls). Also the chastity cage variant is up to your intereptation."
