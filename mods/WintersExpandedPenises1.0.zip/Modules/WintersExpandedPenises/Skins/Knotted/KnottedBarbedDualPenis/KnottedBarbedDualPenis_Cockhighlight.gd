extends PartSkinBase

func _init():
	id = "caninebarbdualcockhighlight"
	partID = "caninepenisdualbarb"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedPenis_Cockhighlight.png"),
	}
