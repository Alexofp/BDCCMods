extends PartSkinBase

func _init():
	id = "knottedfluffytribal"
	partID = "knottedfluffypenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedPenis_Tribal.png"),
	}
