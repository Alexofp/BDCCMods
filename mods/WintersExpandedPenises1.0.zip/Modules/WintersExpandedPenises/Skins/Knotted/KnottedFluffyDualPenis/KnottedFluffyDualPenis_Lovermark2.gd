extends PartSkinBase

func _init():
	id = "knottedfluffyduallovermark2"
	partID = "knottedfluffydualpenis"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedDualPenis_Lovermark.png"),
	}
