extends PartSkinBase

func _init():
	id = "taperedslitlover"
	partID = "taperedpenisslit"

func getName():
	return "LoversMark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedSlitLoverMark.png"),
	}

