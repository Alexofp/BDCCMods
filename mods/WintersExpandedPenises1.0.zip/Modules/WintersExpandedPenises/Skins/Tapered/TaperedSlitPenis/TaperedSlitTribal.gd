extends PartSkinBase

func _init():
	id = "taperedslittribal"
	partID = "taperedpenisslit"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedSlitTribal.png"),
	}
	
	 
