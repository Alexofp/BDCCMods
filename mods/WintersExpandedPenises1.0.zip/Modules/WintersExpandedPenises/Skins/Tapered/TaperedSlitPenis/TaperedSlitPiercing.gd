extends PartSkinBase

func _init():
	id = "taperedslitpiercing"
	partID = "taperedpenisslit"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedSlitPiercing.png"),
	}
	
	 
