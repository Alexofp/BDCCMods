extends PartSkinBase

func _init():
	id = "taperedlargemottled1"
	partID = "taperedlargepenis"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineMottled1.png"),
	}
