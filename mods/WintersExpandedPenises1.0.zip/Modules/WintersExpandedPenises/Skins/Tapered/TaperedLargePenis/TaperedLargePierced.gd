extends PartSkinBase

func _init():
	id = "taperedlargepierced"
	partID = "taperedlargepenis"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquinePierced.png"),
	}
