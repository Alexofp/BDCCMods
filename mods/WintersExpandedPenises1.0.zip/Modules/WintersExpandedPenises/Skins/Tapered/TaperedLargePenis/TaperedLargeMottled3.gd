extends PartSkinBase

func _init():
	id = "taperedlargemottled3"
	partID = "taperedlargepenis"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineMottled3.png"),
	}
