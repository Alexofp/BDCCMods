extends PartSkinBase

func _init():
	id = "taperedlargetribal"
	partID = "taperedlargepenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineTribal.png"),
	}
