extends PartSkinBase

func _init():
	id = "taperedlongtribal"
	partID = "taperedlongpenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyTribal.png"),
	}
