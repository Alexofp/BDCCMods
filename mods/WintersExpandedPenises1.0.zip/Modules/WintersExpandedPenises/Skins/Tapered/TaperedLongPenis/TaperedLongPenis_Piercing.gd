extends PartSkinBase

func _init():
	id = "taperedlongpiercing"
	partID = "taperedlongpenis"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyPiercing.png"),
	}
