extends PartSkinBase

func _init():
	id = "taperedknottedscarred"
	partID = "knottedfluffypenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyScarred.png"),
	}
