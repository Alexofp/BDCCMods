extends PartSkinBase

func _init():
	id = "taperedknottedtribal"
	partID = "taperedpenisknot"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyTribal.png"),
	}
