extends PartSkinBase

func _init():
	id = "taperedknottedGradient"
	partID = "taperedpenisknot"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyGradient.png"),
	}
