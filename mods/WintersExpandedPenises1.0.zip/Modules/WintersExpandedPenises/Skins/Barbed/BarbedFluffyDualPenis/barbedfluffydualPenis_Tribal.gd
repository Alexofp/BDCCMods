extends PartSkinBase

func _init():
	id = "barbedfluffydualtribal"
	partID = "barbedfluffydualpenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedDualPenis_Tribal.png"),
	}
