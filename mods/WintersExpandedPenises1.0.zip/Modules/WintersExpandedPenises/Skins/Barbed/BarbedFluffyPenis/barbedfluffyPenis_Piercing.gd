extends PartSkinBase

func _init():
	id = "barbedfluffypiercing"
	partID = "barbedfluffypenis"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedPenis_Piercing.png"),
	}
