extends Module

var FoxLibLoad = ResourceLoader.exists("res://Modules/FoxLib/Module.gd")

var ConfigFluffyCanine = true
var ConfigFluffyEquine = true
var ConfigFluffyFeline = true
var ConfigScruffyCanine = false
var ConfigScruffyEquine = false
var ConfigScruffyFeline = false

func _init():
	id = "WintersFluffyBodyparts"
	author = "Art:Anon and Max-Maxou, Update: Avery Winters"

	bodyparts = [
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyArms.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBody.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBreasts.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyMaleBreasts.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBreastsExtra.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBuffArms.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyClawedArms.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyDigiLegs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofsSmall.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffySoftLegs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/SoftBody.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyArms.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyBackedLegs.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyBody.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyClawedArms.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigiLegs.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyHoofs.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffySoftLegs.gd",
	]

	if (FoxLibLoad == true):
		species = [
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/CanineFluffyFoxLib.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/EquineFluffyFoxLib.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/FelineFluffyFoxLib.gd",
		]
	else:
		species = [
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/CanineFluffy.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/EquineFluffy.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/FelineFluffy.gd",
		]

func onFoxLibModInit(_foxModuleAPI):
	_foxModuleAPI.addBooleanOption("ConfigFluffyCanine", "Canines spawn with fluffy parts?", "If on, dynamically generated canines will spawn with fluffy arms, legs and body.", true)
	_foxModuleAPI.addBooleanOption("ConfigScruffyCanine", "Canines spawn with Scruffy parts instead?", "If on, dynamically generated canines will spawn with scruffy parts.", false)
	_foxModuleAPI.addBooleanOption("ConfigFluffyEquine", "Equines spawn with fluffy parts?", "If on, dynamically generated equines will spawn with fluffy arms, legs and body.", true)
	_foxModuleAPI.addBooleanOption("ConfigScruffyEquine", "Equines spawn with Scruffy parts instead?", "If on, dynamically generated equines will spawn with scruffy parts.", false)
	_foxModuleAPI.addBooleanOption("ConfigFluffyFeline", "Felines spawn with fluffy parts?", "If on, dynamically generated felines will spawn with fluffy arms, legs and body.", true)
	_foxModuleAPI.addBooleanOption("ConfigScruffyFeline", "Felines spawn with Scruffy parts instead?", "If on, dynamically generated felines will spawn with scruffy parts.", false)
