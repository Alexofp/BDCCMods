extends "res://Species/Equine.gd"

const FoxGlobals = preload("res://FoxLib/Globals.gd")

func getDefaultBody(_gender):
	var FluffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyEquine
	var ScruffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyEquine
	if (FluffyEquine == true):
		if (ScruffyEquine == true):
			return "fluffbody"
		return "fluffybody"
	return "anthrobody"

func getDefaultLegs(_gender):
	var FluffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyEquine
	var ScruffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyEquine
	if (FluffyEquine == true):
		if (ScruffyEquine == true):
			return "scruffyhoofs"
		return "fluffyhoofs"
	return "hoofs"

func getDefaultArms(_gender):
	var FluffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyEquine
	var ScruffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyEquine
	if (FluffyEquine == true):
		if (ScruffyEquine == true):
			return "fluffarms"
		return "fluffyarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	var FluffyEquine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyEquine
	if (FluffyEquine == true):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
