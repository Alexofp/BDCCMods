extends "res://Species/Canine.gd"

const FoxGlobals = preload("res://FoxLib/Globals.gd")

#var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine

func getDefaultBody(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			return "fluffbody"
		return "fluffybody"
	return "anthrobody"

func getDefaultLegs(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			return "flufflegs"
		return "fluffylegs"
	return "digilegs"

func getDefaultArms(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			return "fluffarms"
		return "fluffyarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	if (FluffyCanine == true):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
