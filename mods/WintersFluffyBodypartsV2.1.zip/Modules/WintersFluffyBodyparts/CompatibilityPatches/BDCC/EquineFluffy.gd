extends "res://Species/Equine.gd"

func getDefaultBody(_gender):
	if ("MoldyFluffVariant" in GlobalRegistry.getModules()):
		return "fluffbody"
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffybody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("MoldyFluffVariant" in GlobalRegistry.getModules()):
		return "scruffyhoofs"
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffyhoofs"
	return "hoofs"

func getDefaultArms(_gender):
	if ("MoldyFluffVariant" in GlobalRegistry.getModules()):
		return "fluffarms"
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffyarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
