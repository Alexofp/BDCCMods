extends "res://Species/Canine.gd"

func getDefaultBody(_gender):
	if ("MoldyFluffVariant" in GlobalRegistry.getModules()):
		return "fluffbody"
	elif ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffybody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("MoldyFluffVariant" in GlobalRegistry.getModules()):
		return "flufflegs"
	elif ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffylegs"
	return "digilegs"

func getDefaultArms(_gender):
	if ("MoldyFluffVariant" in GlobalRegistry.getModules()):
		return "fluffarms"
	elif ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffyarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
