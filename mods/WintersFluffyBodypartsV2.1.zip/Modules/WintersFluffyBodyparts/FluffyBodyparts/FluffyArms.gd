extends BodypartArms

func _init():
	visibleName = "Fluffy clawless arms"
	id = "fluffyarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyArms/FluffyArms.tscn"
