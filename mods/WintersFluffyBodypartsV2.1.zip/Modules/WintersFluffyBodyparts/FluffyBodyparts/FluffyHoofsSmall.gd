extends BodypartLeg

func _init():
	visibleName = "fluffy small hoofs"
	id = "fluffyhoofssmall"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofsSmall/FluffyHoofsSmall.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
