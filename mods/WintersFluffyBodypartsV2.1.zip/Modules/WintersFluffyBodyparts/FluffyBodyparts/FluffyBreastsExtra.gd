extends BodypartBreasts

func _init():
	visibleName = "extra fluffy breasts"
	id = "fluffbreastsextra"
	size = BreastsSize.C


func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBreastsFlat/FluffyBreastsFlat.tscn"
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBreasts/FluffyBreastsExtra.tscn"


func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])
