extends BodypartLeg

func _init():
	visibleName = "Fluffy digi-legs"
	id = "fluffylegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyDigiLegs/FluffyDigiLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
