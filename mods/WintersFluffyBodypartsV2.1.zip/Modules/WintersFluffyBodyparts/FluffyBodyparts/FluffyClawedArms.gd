extends BodypartArms

func _init():
	visibleName = "Fluffy clawed arms"
	id = "fluffyclawedarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyClawedArms/FluffyClawedArms.tscn"
