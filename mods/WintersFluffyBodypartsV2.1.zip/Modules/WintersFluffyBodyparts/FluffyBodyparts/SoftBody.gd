extends BodypartBody

func _init():
	visibleName = "soft fluffy body"
	id = "softbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/SoftBody/SoftBody.tscn"
