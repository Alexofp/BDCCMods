extends BodypartLeg

func _init():
	visibleName = "Fluffy clawless legs"
	id = "softdigilegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffySoftLegs/FluffySoftLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
