extends BodypartBody

func _init():
	visibleName = "fluffy body"
	id = "fluffybody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBody/FluffyBody.tscn"
