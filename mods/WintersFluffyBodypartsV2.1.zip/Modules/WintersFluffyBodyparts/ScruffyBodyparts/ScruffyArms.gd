extends BodypartArms

func _init():
	visibleName = "Scruffy clawless arms"
	id = "fluffarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyArms/ScruffyArms.tscn"
