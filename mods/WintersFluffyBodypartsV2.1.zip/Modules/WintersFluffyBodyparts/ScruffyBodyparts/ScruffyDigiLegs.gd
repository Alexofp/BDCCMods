extends BodypartLeg

func _init():
	visibleName = "Scruffy digi-legs"
	id = "flufflegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigilegs/ScruffyDigiLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
