extends BodypartLeg

func _init():
	visibleName = "scruffy hoofs"
	id = "scruffyhoofs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyHoofs/ScruffyHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
