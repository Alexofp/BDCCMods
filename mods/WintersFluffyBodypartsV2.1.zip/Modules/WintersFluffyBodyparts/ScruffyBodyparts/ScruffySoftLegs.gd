extends BodypartLeg

func _init():
	visibleName = "Scruffy clawless legs"
	id = "scruffysoftlegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffySoftLegs/ScruffySoftLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
