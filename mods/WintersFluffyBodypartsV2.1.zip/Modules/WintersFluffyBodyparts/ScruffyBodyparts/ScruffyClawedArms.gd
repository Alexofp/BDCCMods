extends BodypartArms

func _init():
	visibleName = "Scruffy clawed arms"
	id = "scruffyclawedarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyClawedArms/ScruffyClawedArms.tscn"
