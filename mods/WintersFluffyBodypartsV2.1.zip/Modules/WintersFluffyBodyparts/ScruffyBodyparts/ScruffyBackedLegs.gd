extends BodypartLeg

func _init():
	visibleName = "Scruffy backed digi-legs"
	id = "scruffbackedlegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyBackedLegs/ScruffyBackedLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
