extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Tobikadachi penis"
	id = "sTobikadachiPenisHY"

func getCompatibleSpecies():
	return Species.Any

func getLewdAdjective():
	return RNG.pick(["knotted", "wyvern", "ribbed"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Penis/Tobikadachi_Penis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		"Hyperable": true,
	}

func getVulgarName() -> String:
	return "wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0
