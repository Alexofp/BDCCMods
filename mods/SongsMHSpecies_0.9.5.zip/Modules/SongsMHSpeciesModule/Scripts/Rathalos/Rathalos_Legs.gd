extends BodypartLeg

func _init():
	visibleName = "Rathalos legs"
	id = "sRathalosLegs"

func getCompatibleSpecies():
	return Species.Any

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Legs/Rathalos_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
