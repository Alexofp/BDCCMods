extends BodypartHead

func _init():
	visibleName = "Odogaron Head"
	id = "sOdogaronHead"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Head/Odogaron_Head.tscn"

func getHeadLength():
	return 0.75
