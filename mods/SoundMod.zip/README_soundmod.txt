Make sure that FoxLib comes first in the mod list! FoxLib, then SoundMod! SoundMod uses a custom importer to add .wav support, so if you don't have the correct mod load order the FoxLib importer will throw a fit and it won't load any sounds at all!

To create custom sounds:
1. Open the Mod Options menu
2. Under SoundMod settings, click the button to make empty folder
3. In the folder that just opened, paste your sound files according to the guidelines below
4. Rename the "pack_" folder to something that makes sense - but it MUST begin with "pack_"!
5. Restart the game

In terms of this mod, a sound pack is a folder with 8 subfolders, each subfolder contains a variant of a single sound.  The folder must start with "pack_", and anything after that will be used as the pack name. Recommended that you label a pack as feminine, masculine, or androgynous for organization. Also, credit the voicepack author by placing a link to their socials inside the pack folder if you share the voice pack online. Make a file with the format "@author.url" (link to their socials). For example:

pack_fem-1/                     <- "pack_" plus name, ideally fem/masc/andro then a unique name
    sounds_orgasm/              <- sound type folder, must have exact name given below
        soundclip.ogg           <- clips can be named whatever, but must be .ogg, .mp3, or .wav
        soundclip2.mp3
        bazinga.ogg

When a player sound is played, one clip is chosen at random. Only one player sound should play at a time. There are 4 sound effects as of current version. In order of priority, these are:
Struggle = plays when pc tries to remove a restraint
Orgasm = plays when pc has an orgasm
Pleasure = plays when pc's Arousal stat increases
Tease = plays when pc's Lust stat increases

(Try to choose shorter clips, FoxLib's audio manager always plays the full duration of the clip.)

A sound pack MUST have these subfolders with these exact names (it's okay if they are empty folders), or else the mod won't find it:
sounds_orgasm
sounds_orgasm_gagged
sounds_pleasure
sounds_pleasure_gagged
sounds_struggle
sounds_struggle_gagged
sounds_tease
sounds_tease_gagged

There is also a folder for sound effects. Effects play sound on a different audio channel so they can happen at the same time as player sounds. The triggers for these are kinda hack-y and each one is different, so I'm not going to try and explain those in here.
