extends SceneBase

const manager = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")


var Smod = GlobalRegistry.getModule("SoundModule")
var testAudio = manager.getFoxAudio("TestAudio")
var variance

func _init():
	sceneID = "soundTest"


func _run():
	
	variance = Smod.pitchVarianceOption/100
	
	if(state == ""):
		saynn("Debug sound test")
		addButton("Cancel", "Go back", "endthescene")
		addButton("Voice sounds","See all sounds from voice packs","voice")
		addButton("VFX sounds","See all sounds effects","effect")
		
	if(state == "effect"):
		addButton("Back", "Go back", "")
		var _things = manager.getAllAudioIDs()
		for entry in _things:
			if(entry == "" || entry == null || entry.begins_with("SoundModule:Sound")):
				continue
			var dummy = entry.substr(entry.find(":")+1,-1)
			var disp = dummy.trim_prefix("Effect")
			addButton(disp, dummy, entry, ["play"])
		
		
	if(state == "voice"):
		addButton("Back", "Go back", "")
		var _things = manager.getAllAudioIDs()
		for entry in _things:
			if(entry == "" || entry == null || entry.begins_with("SoundModule:Effect")):
				continue
			var dummy = entry.substr(entry.find(":")+1,-1)
			var disp = dummy.trim_prefix("Sound")
			addButton(disp, dummy, entry, ["play"])
		
	
func _react(_action: String, _args):

	if(_args.empty()):
		setState(_action)
	elif(manager.getAllAudioIDs().has(_action)):
		var wat = manager.getFoxAudio(_action)
		addMessage("Audio object:  " + wat.getId())
		addMessage("Author:  " + wat.getAuthor())
		wat.setPitchVariance(variance)
		wat.playAsSFX()

		return
	
	if(_action == "endthescene"):
		endScene()
		return
	

