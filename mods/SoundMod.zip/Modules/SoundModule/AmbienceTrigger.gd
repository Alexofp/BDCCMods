extends EventBase

const am = preload("res://Modules/SoundModule/ambience.gd")
const flam = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")
const Globals = preload("res://FoxLib/Globals.gd")
const fui = preload("res://FoxLib/FoxUIManager.gd")

var Smod = GlobalRegistry.getModule("SoundModule")


func _init():
	id = "Ambience"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func run(_triggerID, _args):
	var location = GM.pc.getLocation()
	var ref = GM.world.getRoomByID(location)

	
	var name = am.getAmb(ref)
	if(Smod.ambientOption):
		var _eep = flam.getCurrentBGM()
		var _oop = flam.getBGMId()
		if(flam.getCurrentBGM() != null && flam.getBGMId() == "SoundModule:"+name):
			return
		if(name==""):
			flam.playBGM(null)
		var sound = flam.getFoxAudio("SoundModule:"+name)
		if(sound == null):
			return
		sound.setPitchVariance(Smod.pitchVarianceOption)
		flam.setVolume(Smod.ambientVolume)
		flam.playBGM(sound)


func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "sounds"):
		runScene("soundTest")
