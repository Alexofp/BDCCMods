class_name Ambient

const flam = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")
const Globals = preload("res://FoxLib/Globals.gd")

var prison = [
	"hall_checkpoint",
	"hall_elevator",
	"hall_ne_corner",
	
	]



static func getAmb(_room:GameRoom) -> String:
	var name = ""
	if(_room.getFloorID()=="Cellblock"):
		name = "Ambientprison_ambience"
		
	if(_room.getFloorID()=="MainHall"):
		name = "Ambientcafe"
		if(_room.roomID == "main_laundry"):
			name = "Ambientlaundryroom"
		if(_room.roomID == "hall_canteen"):
			name = "Ambientcafe"
		if(_room.roomID == "main_laundry"):
			name = "Ambientlaundryroom"
		if(_room.loctag_Greenhouses):
			name = "Ambientgreenhouse"
			
	if(_room.getFloorID()=="FightClubFloor"):
		name = "Ambientfightclub"
		
	if(_room.getFloorID()=="DrugDenDungeon"):
		name = "Ambientdrug_den"
		
	if(_room.getFloorID()=="Medical"):
		name = "Ambientmedicalwing"
		if(_room.roomID == "med_researchlab"):
			name = "Ambientlaboratory"
		
	if(_room.getFloorID()=="MiningFloor"):
		name = "Ambientcafeteria"
		if(_room.loctag_EngineersEncounter):
			name = "Ambientengineering"

	return name

