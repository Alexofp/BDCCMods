extends "res://FoxLib/FoxModule.gd"

const FoxLibAudioManager = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")

const FoxLibModInitHelper = preload("res://Modules/FoxLib/Internal/FoxLibModInitHelper.gd")


var sound
var EffectSound
var AmSound


var Psoundoption:bool = true
var Osoundoption:bool = true
var Tsoundoption:bool = true
var Ssoundoption:bool = true
var gagsoundoption:bool = true
var pitchVarianceOption:float
var HypnoOption:bool = false
var cumEffect:bool = false
var squirtEffect:bool = false
var spankOption:bool = false
var punchOption:bool = false
var clothOption:bool = false
var chainOption:bool = false
var plapOption:bool = false
var audiotest:bool = true
var ambientOption:bool = true
var ambientVolume:int = 30
var voicepackoption = ""
var packReq = [
	"sounds_orgasm",
	"sounds_orgasm_gagged",
	"sounds_pleasure",
	"sounds_pleasure_gagged",
	"sounds_struggle",
	"sounds_struggle_gagged",
	"sounds_tease",
	"sounds_tease_gagged",
]
var effectReq = [
	"effects_sextoy",
	"effects_plaps",
	"effects_plaps2",
	"effects_oral",
	"effects_handjob",
	"effects_grind",
	"effects_chain",
	"effects_spank",
	"effects_slap",
	"effects_clothes",
	"effects_hum",
]
var folders = []

var helpString:String = ""

func _init():
	id = "SoundModule"
	author = "bringlebangul"	
	scenes = ["res://Modules/SoundModule/SoundTest.gd"]
	gameExtenders = [
		"res://Modules/SoundModule/PlaySounds.gd",
#		"res://Modules/SoundModule/EngineSounds.gd",
	]
	events = [
		"res://Modules/SoundModule/DebugEvent.gd",
		"res://Modules/SoundModule/AmbienceTrigger.gd",
	]
	
#	var _soundDir = OS.get_user_data_dir()
#	_soundDir += "/soundmod/"
	var soundDir = GlobalRegistry.getModsFolder().rstrip("mods").rstrip("BDCCMods").plus_file("soundmod")
#	var soundDir = "user://soundmod/"
	soundDir += "/"
	var dir = Directory.new()
	if !Util.folderExists(soundDir):
		var _er = dir.make_dir_recursive(soundDir)
		if _er != 0:
			helpString += "Could not write to sound directory. Likely a problem with your OS permissions.\n"
	var _err = dir.open(soundDir)
	if _err != 0:
		helpString += "Could not open sound directory. Likely a problem with your OS permissions.\n"
	folders = sub_dir(soundDir)
	var actualFolders = []
	var _blep = dir_contents(soundDir)
	for thing in _blep:
		if thing.ends_with(".zip"):
			helpString += "Found .zip file "+thing+" in sound directory. Did you extract it?\n"
			continue
	
	for packfolder in folders:
		if(packfolder.begins_with("Effects")):
			helpString += "Effects was extracted in correct location!\n"
			var effectDir = soundDir + "Effects/"
			var EffectTypes = sub_dir(effectDir)
			for type in EffectTypes:
				var name1 = type+"/"
				var dispName = name1.trim_prefix("effects_")
				dispName = dispName.trim_suffix("/")
				if(dir.dir_exists(effectDir+name1)):
					dir.open(effectDir+name1)
					dir.list_dir_begin()
					var file = dir.get_next()
					EffectSound = self.newAudio("Effect"+dispName, dir.get_current_dir()+file)
					var files = dir_contents_minus_first(effectDir+name1)
					for entry in files:
						if entry.ends_with(".import"):
							continue
						var _temp = effectDir + name1 + entry
						EffectSound.addAudioPath(_temp)
					dir.list_dir_end()
			continue
		if(packfolder.begins_with("Ambient")):
			helpString += "Ambiance was extracted in correct location!\n"
			var ambientDir = soundDir + "Ambient/"
			dir.open(ambientDir)
			dir.list_dir_begin()
			var files = dir_contents(ambientDir)
			for file in files:
				var dispName = file
				dispName.erase(dispName.length()-4,4)
				AmSound = self.newAudio("Ambient"+dispName, dir.get_current_dir()+file)
			dir.list_dir_end()
			continue
		if(!is_valid_pack(soundDir+packfolder)):
			printerr("[SoundMod] Error: Tried to read '"+soundDir+packfolder+"/' and did not find the correct directory structure.")
			helpString += "Recognized folder name, but "+packfolder+" did not have the correct directory structure. Was something renamed?\n"
			continue
		else:
			actualFolders.append(packfolder)
		if actualFolders.empty():
			helpString += "No valid folder names were found in sound directory. Are your files in the right place?\n"

		var pack = packfolder.substr(packfolder.find("_")+1,-1)
		helpString += "Pack "+pack+" was extracted in correct location!\n"
		var Voicetypes = sub_dir(soundDir + packfolder)
		var list = (dir_contents(soundDir + packfolder))
		var s:String = ""
		for item in list:
			if item.find("@") != -1:
				item = item.substr(item.find("@")+1,-1)
				item.erase(item.length()-4,4)
				s += item + ", "
		s.erase(s.length()-2,2)
		s = s.replacen("twitter","")
		for type in Voicetypes:
			var name1 = type + "/"
			var dispName = name1.trim_prefix("sounds_")
			dispName.erase(dispName.length()-1,1)
			name1 = packfolder + "/" + name1
			if(dir.dir_exists(soundDir+name1)):
				dir.open(soundDir+name1)
				dir.list_dir_begin()
				var file = dir.get_next()
				sound = self.newAudio("Sound"+dispName + pack, dir.get_current_dir()+file)
				var files = dir_contents_minus_first(soundDir+name1)
				for entry in files:
					if entry.ends_with(".import"):
						continue
					var _temp = soundDir + name1 + entry
					sound.addAudioPath(_temp)
				sound.setAuthor(s)
				dir.list_dir_end()
				
	folders = actualFolders
	if FoxLibAudioManager.getAllAudioIDs().size() > 1:
		helpString += "At least one audio stream was created successfully. \n"
		helpString += "The audio files seem to be in the right spot with the right names. Use the sound test menu to try it in-game.\n"
	FoxLibModInitHelper.callOnFoxLibModInit()


var fileDialog:FileDialog
var selected:String

func sound_file_manager(_args):
	var soundDir = OS.get_user_data_dir()+"/soundmod/"
	if(OS.get_name() == "Android"):
		#var permissions: Array = OS.get_granted_permissions() #for Godot 3 branch
		#if permissions.has("android.permission.READ_EXTERNAL_STORAGE"):
		var externalDir:String = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
		var finalDir = externalDir.plus_file("soundmod")
		soundDir = finalDir
	Util.fixed_shell_open(soundDir)


func makeFolders(_args):
	var userdata = OS.get_user_data_dir()+"/soundmod/"
	if(OS.get_name() == "Android"):
		#var permissions: Array = OS.get_granted_permissions() #for Godot 3 branch
		#if permissions.has("android.permission.READ_EXTERNAL_STORAGE"):
		var externalDir:String = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
		var finalDir = externalDir.plus_file("soundmod")
		userdata = finalDir
	var exist = sub_dir(userdata)
	var nom = "pack_[gender]-[uniqueID]"
	if exist.has(nom):
		var ii = 1
		while Util.folderExists(userdata+nom+String(ii)):
			ii = ii + 1
		nom = userdata+nom+String(ii)
	else:
		nom = userdata+nom
	var ddd = Directory.new()
	ddd.make_dir(nom)
	ddd.open(nom)
	for entry in packReq:
		ddd.make_dir(nom.plus_file(entry))
	Util.fixed_shell_open(nom)
	Util.fixed_shell_open(ProjectSettings.globalize_path("res://README_soundmod.txt"))

func validate(_args):
	var Dialog = AcceptDialog.new()
	Dialog._set_on_top(true)
	Dialog.dialog_text = helpString
	var viewport = FoxUIManager.getCurrentScene().get_viewport()
	viewport.add_child(Dialog)
	Dialog.popup_centered_clamped(Vector2(300,200))
	
	yield(Dialog, "confirmed")


#func on_file_selected(filename : String):
#	print(filename)
#	selected = filename
#	if (fileDialog != null):
#		fileDialog.queue_free()
#	return selected
	
func postInit():
	if(GlobalRegistry.getModule("FoxLib") == null):
		print("[SoundMod] Error: "+id+" requires FoxLib")
#	var _temp = FoxLibAudioManager.getAllAudioIDs()
	var test = sub_dir(OS.get_user_data_dir()+"/soundmod")
	if test.empty():
		OS.alert("SoundMod first-time setup! \nMake sure you installed FoxLib v0.10.4 or later, and make sure FoxLib is before (above) this mod in the mod list!", OS.get_executable_path())

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "openfiles", "Open audio folder", "Open the folder where sounds are saved").connect("option_changed", self, "sound_file_manager")
#	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "installzip", "Select a .zip to add sounds", "Extracts a zip file to "+OS.get_user_data_dir()+"/soundmod/  \nWill overwrite existing!").connect("option_changed", self, "unzip_sounds")
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Settings","audiotest", "Show sound test in Me menu", "Show the sound test menu in the 'Me' menu",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Psoundoption", "Pleasure sounds", "Sound plays on arousal stat change",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Osoundoption", "Orgasm sounds", "Sound plays at orgasm",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Tsoundoption", "Tease sounds", "Sound plays on lust stat change",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Ssoundoption", "Struggle sounds", "Sound plays on struggle attempt",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","gagsoundoption", "Gagged sounds", "Play variant sounds when gagged",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","HypnoOption", "Hypno Hum", "Subtle hum when being hypnotized",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "spankOption", "Spanking", "Play spanking sound effect when spanked", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "punchOption", "Spanking", "Play (mild) punching sound effect when beating up", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "clothOption", "Clothes rustle", "Play fabric noise when trying to remove clothing (will play even if removal gets resisted)", false)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "chainOption", "Chain noise", "Play metal clink when trying to leash or apply bondage (will play even if it gets resisted)", false)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "plapOption", "Plaps & glucks", "Play a short loop of plaps while fucking (timing will not sync)", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "cumEffect", "Cum effects", "Should ejaculation sounds play along with orgasm voice clips?", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "squirtEffect", "Squirting", "Should characters with a vagina and no penis replace ejaculating with squirting?", true)
	foxModuleAPI.addSliderOptionInCategory("SoundMod Settings","pitchVarianceOption","Pitch variance","Slightly change pitch so sounds aren't repetitive", float(10))
	var select = []
	var soundDir = GlobalRegistry.getModsFolder().rstrip("mods").rstrip("BDCCMods").plus_file("soundmod")+"/"
	var dir = Directory.new()
	if !Util.folderExists(soundDir):
		dir.make_dir_recursive(soundDir)
	dir.open(soundDir)
	folders = sub_dir(soundDir)
	var actualFolders = []
	for packfolder in folders:
		if(!is_valid_pack(soundDir+packfolder)):
			continue
		else:
			actualFolders.append(packfolder)
	for entry in actualFolders:
		select.append([entry, entry])
	select.append(["debug blank", "debug none"])
	foxModuleAPI.addListOptionInCategory("SoundMod Settings", "voicepackoption", "Voice Pack", select, "Select a voice pack. Packs are added by making a folder in the Modules/SoundMod directory within the mod .zip", "error")
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "diditwork","Did I do it right?","Checks to see if you put audio in the right place").connect("option_changed", self, "validate")
#	foxModuleAPI.addBooleanOptionInCategory("SoundMod Settings", "ambianceOption", "Ambience", "Play ambient sounds based on location", true)
#	foxModuleAPI.addSliderOptionInCategory("SoundMod Settings", "ambientVolume", "Ambiance volume","Volume for ambient sound", 30)
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "folders", "Example folder", "Create an empty folder where you can place your own files").connect("option_changed", self, "makeFolders")

func sub_dir(path):
	var dir = Directory.new()
	var _folds:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir() && file_name != "." && file_name != "..":
				_folds.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to access the folder " +path)
	dir.list_dir_end()
	return _folds
	
func is_valid_pack(folder):
	var dir = Directory.new()
	var valid = false
	if dir.open(folder + "/") == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir() && file_name != "." && file_name != "..":
				if packReq.has(file_name):
					valid = true
				else:
					valid = false
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to access the folder " +folder)
	dir.list_dir_end()
	return valid	

func dir_contents_minus_first(path):
	var dir = Directory.new()
	var _file_names:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		dir.get_next()
		var file_name = dir.get_next()
		while(file_name != ""):
			if (!file_name.ends_with("import") && file_name != "." && file_name != ".."):
				_file_names.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to get the contents of " +path)
	dir.list_dir_end()
	return _file_names
	

func dir_contents(path):
	var dir = Directory.new()
	var _file_names:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while(file_name != ""):
			if (file_name != "." && file_name != ".."):
				_file_names.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to get the contents of " +path)
	dir.list_dir_end()
	return _file_names
