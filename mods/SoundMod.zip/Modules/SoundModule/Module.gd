extends "res://FoxLib/FoxModule.gd"

const FoxLibAudioManager = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")

const FoxLibModInitHelper = preload("res://Modules/FoxLib/Internal/FoxLibModInitHelper.gd")

const popupwindow = preload("res://Modules/SoundModule/BGM_picker_popup.tscn")

var BGMDB = load("res://Modules/SoundModule/SoundModBGMDB.gd")

var sound
var EffectSound
var AmSound
var soundDir

var Psoundoption:bool = true
var Osoundoption:bool = true
var Tsoundoption:bool = true
var Ssoundoption:bool = true
var gagsoundoption:bool = true
var pitchVarianceOption:float
var HypnoOption:bool = false
var cumEffect:bool = false
var squirtEffect:bool = false
var spankOption:bool = false
var punchOption:bool = false
var clothOption:bool = false
var chainOption:bool = false
var plapOption:bool = false
var audiotest:bool = true
var BGMOption:bool = true
var BGMVolume:int = 30
var voicepackoption = ""
var packReq = [
	"sounds_orgasm",
	"sounds_orgasm_gagged",
	"sounds_pleasure",
	"sounds_pleasure_gagged",
	"sounds_struggle",
	"sounds_struggle_gagged",
	"sounds_tease",
	"sounds_tease_gagged",
]
var effectReq = [
	"effects_sextoy",
	"effects_plaps",
#	"effects_plaps2",
	"effects_oral",
#	"effects_handjob",
	"effects_grind",
	"effects_chain",
	"effects_spank",
	"effects_slap",
	"effects_clothes",
	"effects_hum",
	"effects_cum",
	"effects_squirt",
]
var folders = []

var helpString:String = ""
var validNames = ["SoundMod_Effects", "SoundMod_pack_", "SoundMod_BGM", "SoundMod_"]

func folderCheck(_names:Array):
	var result = []
	for each in _names:
		if(each.begins_with("SoundMod_")):
			result.append(true)
		else:
			result.append(false)
	return result
	

func _init():
	id = "SoundModule"
	author = "bringlebangul"	
	scenes = ["res://Modules/SoundModule/SoundTest.gd"]
	gameExtenders = [
		"res://Modules/SoundModule/PlaySounds.gd",
	]
	events = [
		"res://Modules/SoundModule/DebugEvent.gd",
		"res://Modules/SoundModule/BGMsystem.gd",
	]
	perks = [
#		"res://Modules/SoundModule/AudioTrigger.gd",
	]
	
	soundDir =  GlobalRegistry.getModsFolder()+"/"
	var dir = Directory.new()
	#search for folders in this order: user://mods, user://soundmod
	var _err = dir.open(GlobalRegistry.getModsFolder())
	folders = sub_dir(GlobalRegistry.getModsFolder())
	var _ok = folderCheck(folders)
	print("[SoundMod] Looking for audio files in "+ProjectSettings.globalize_path(soundDir)+"...")
	helpString += "Looking for audio files in "+ProjectSettings.globalize_path(soundDir)+"...\n"
	if(folders.empty() || not _ok.has(true)):
		soundDir = GlobalRegistry.getModsFolder().rstrip("mods").rstrip("BDCCMods").plus_file("soundmod")+"/"
		print("[SoundMod] Looking for audio files in "+ProjectSettings.globalize_path(soundDir)+"...")
		helpString += "Looking for audio files in "+ProjectSettings.globalize_path(soundDir)+"...\n"
		dir.open(soundDir)
		folders = sub_dir(soundDir)
		_ok = folderCheck(folders)
	if(folders.empty() || not _ok.has(true)): #check if the folders were mistakenly put in the mod itself
		var checkMistake = GlobalRegistry.getModsFolder()+"/SoundMod.zip"
		var unzip = GDUnzip.new()
		unzip.load(checkMistake)
		var list = unzip.files
		for path in list:
			if("SoundMod_" in path):
				printerr("[SoundMod] Found audio folders inside"+ProjectSettings.globalize_path(checkMistake)+". Please move audio folders.")
				helpString += "Error! Found audio folders inside"+ProjectSettings.globalize_path(checkMistake)+". Please move audio folders to:\n"+ProjectSettings.globalize_path(GlobalRegistry.getModsFolder())
				break
		dir.open(GlobalRegistry.getModsFolder())
		var _files = dir_contents(GlobalRegistry.getModsFolder())
		if(_files.has("Modules") || _files.has("SoundMod") || _files.has("SoundMod.json")): #check if the mod was extracted when it shouldn't be
			printerr("[SoundMod] It appears the mod itself was unzipped. Do not extract SoundMod.zip")
			helpString += "Error! It appears the mod itself was unzipped. Do not extract SoundMod.zip\n"
	if(folders.empty()): # if nothing was found at either location, let the user know
		printerr("[SoundMod] No audio files located. Check you have sounds downloaded and in the right location. Folder names have changed as of SoundMod v1.3.0, rename them so they all start with \"SoundMod_\".")
		helpString += "No audio files located. Check you have sounds downloaded and placed in\n\n" + (ProjectSettings.globalize_path(GlobalRegistry.getModsFolder()))+"\n\n or in \n\n"+ ProjectSettings.globalize_path(GlobalRegistry.getModsFolder().rstrip("mods").rstrip("BDCCMods").plus_file("soundmod")) + "/\n\nFolder names have changed as of SoundMod v1.3.0, if you previously downloaded them rename them so they all start with \"SoundMod_\".\n"
	else:
		print("[SoundMod] Located what looks like audio files in "+soundDir+", trying to import...")
		helpString += "Located what looks like audio files in "+soundDir+", trying to import...\n"
	var actualFolders = []
	var checks = 0 #keep track of number of FoxLib audio objects created
	for packfolder in folders:
		if(packfolder.begins_with("SoundMod_Effects")): #this is the folder for sound effects
			var effectDir = soundDir + "SoundMod_Effects/"
			var EffectTypes = sub_dir(effectDir)
#			_numEff = EffectTypes.size()
			for type in EffectTypes:
				var name1 = type+"/"
				var dispName = name1.trim_prefix("effects_")
				dispName = dispName.trim_suffix("/")
				if(dir.dir_exists(effectDir+name1)):
					dir.open(effectDir+name1)
					dir.list_dir_begin()
					var file = dir.get_next()
					EffectSound = self.newAudio("Effect"+dispName, dir.get_current_dir()+file)
					var files = dir_contents_minus_first(effectDir+name1)
					for entry in files:
						if entry.ends_with(".import"): #ignore .import files, they are only for use in the Godot editor
							continue
						var _temp = effectDir + name1 + entry
						EffectSound.addAudioPath(_temp) #FoxLib API to add audio
					dir.list_dir_end()
			print("[SoundMod] Added "+String(EffectTypes.size())+ " sound effects")
			helpString += "Added "+String(EffectTypes.size())+ " sound effects\n"
			checks += EffectTypes.size()
			continue
		if(packfolder.begins_with("SoundMod_BGM")): #this is the BGM folder
			var BGMDir = soundDir + "SoundMod_BGM/"
			dir.open(BGMDir)
			dir.list_dir_begin()
			var files = dir_contents(BGMDir)
			for file in files:
				var dispName = file
				dispName.erase(dispName.length()-4,4)
				AmSound = self.newAudio("BGM"+dispName, dir.get_current_dir()+file)
			dir.list_dir_end()
			print("[SoundMod] Added "+String(files.size())+ " BGM tracks")
			helpString += "Added "+String(files.size())+ " BGM tracks\n"
			checks += files.size()
			continue
		if(!is_valid_pack(soundDir+packfolder)):
			printerr("[SoundMod] Error: Tried to read '"+soundDir+packfolder+"/' and did not find the correct directory structure.")
			helpString += "Error: Tried to read '"+soundDir+packfolder+"/' and did not find the correct directory structure.\n"
			continue
		else:
			actualFolders.append(packfolder)
		if(packfolder.begins_with("SoundMod_pack")): #this is one of possibly many voice pack folders
			var pack = packfolder.get_slice("_",2)
#			substr(packfolder.find("_")+1,-1)
			var Voicetypes = sub_dir(soundDir + packfolder)
			var list = (dir_contents(soundDir + packfolder))
			var s:String = "" #credits to voice actors and such
			for item in list:
				if item == "credits.txt":
					var f = File.new()
					f.open(soundDir + packfolder + "credits.txt", File.READ)
					s = f.get_as_text()
					f.close()
			for type in Voicetypes:
				var name1 = type + "/"
				var dispName = name1.trim_prefix("sounds_")
				dispName.erase(dispName.length()-1,1)
				name1 = packfolder + "/" + name1
				if(dir.dir_exists(soundDir+name1)):
					dir.open(soundDir+name1)
					dir.list_dir_begin()
					var file = dir.get_next()
					sound = self.newAudio("Sound"+dispName + pack, dir.get_current_dir()+file)
					var files = dir_contents_minus_first(soundDir+name1)
					for entry in files:
						if entry.ends_with(".import"):
							continue
						var _temp = soundDir + name1 + entry
						sound.addAudioPath(_temp)
					sound.setAuthor(s)
					dir.list_dir_end()
			print("[SoundMod] Added voice "+packfolder.trim_prefix("SoundMod_")+" with "+String(Voicetypes.size())+ " sounds")
			helpString += "Added voice "+packfolder.trim_prefix("SoundMod_")+" with "+String(Voicetypes.size())+ " sounds\n"
			checks += Voicetypes.size()
	folders = actualFolders
	if FoxLibAudioManager.getAllAudioIDs().size() > 2:
		helpString += "FoxLib has created "+String(FoxLibAudioManager.getAllAudioIDs().size()-2)+" of "+String(checks)+" audio streams.\n" # minus two because the list given by FoxLib includes null and the FoxLib test audio
		helpString += "The audio files seem to be in the right spot with the right names. Use the sound test menu to try it in-game.\n"
#	Log.print(String(FoxLibAudioManager.getAllAudioIDs()))
	FoxLibModInitHelper.callOnFoxLibModInit()

# attempt automatic unzipping of the audio files
func do_it_for_me(_args):
	var Dialog = ConfirmationDialog.new() #creating the dialog box
	var viewport = FoxUIManager.getCurrentScene().get_viewport()
	viewport.add_child(Dialog)
	var dir = Directory.new()
	dir.open(GlobalRegistry.getModsFolder())
	var soundFiles = []
	for entry in dir_contents(GlobalRegistry.getModsFolder()):
		if(entry.begins_with("SoundMod_") && entry.ends_with(".zip")):
			soundFiles.append(entry) # find any files in mods directory that match the pattern "SoundMod_*.zip"
	var text = "The game will now attempt to extract the following:\n"
	for name in soundFiles:
		text += name+"\n"
	text += "\nThis will take several minutes and the game will freeze up during it.\nThere is no progress bar, you will have to wait."
	Dialog.dialog_text = text
	Dialog.popup_exclusive = true # lock the rest of the UI while dialog box is active
	Dialog.popup_centered_clamped() # show the dialog box
	Dialog.get_ok().connect("pressed", self, "do_Unzip", [soundFiles, Dialog]) #do the unzipping operation if confirm, nothing if cancel
	
func do_Unzip(_sf, dia):
	var problems = zipper(_sf) #the actual extraction
	var c = AcceptDialog.new() #creating the dialogue box
	dia.visible = false
	dia.queue_free() #allow the previous dialog box to be deleted, we're done with it
	var viewport = FoxUIManager.getCurrentScene().get_viewport()
	viewport.add_child(c)
	var text = "Completed!\n"
	if(problems.size()>=1): # list any files that failed
		text += "Errors occurred for the following files:\n"
	else:
		text += "No errors occurred. Yay!"
	if(problems.size()>=30):
		text += String(problems.size())+ " of them. That's a lot. Good luck."
	else:
		for line in problems:
			text += line+"\n"
	text += "Please restart the game and hopefully it will work."
	c.dialog_text = text
	c.popup_centered_clamped() #show the dialog box
	
func zipper(soundFiles):
	var problems = []
	for thezip in soundFiles:
		var unzip = GDUnzip.new() # GDunzip is an open-source module that is already part of the base game files
		unzip.load(GlobalRegistry.getModsFolder()+"/"+thezip) # must first load the .zip file
		var list = unzip.files # provides a list of all files and folders in the .zip
		var T = File.new() # initialize objects for file operations
		var dir = Directory.new()
		for relPath in list: # loop through the list
			var _dummy = unzip.uncompress(relPath) # try to extract this path from inside the .zip
			var _x = GlobalRegistry.getModsFolder()+"/"+relPath # get the full path for debugging purposes
			if(typeof(_dummy) != TYPE_RAW_ARRAY): # GDunzip will return a byte array if successful, and will return false if it failed
				problems.append(_x) #keep track of files that had errors
				Log.print("GDunzip error for "+_x)
				continue
			if(_dummy.empty()): # empty array means the path was a folder, we can skip it
				continue
			var fff = relPath.get_base_dir() # get the base of the relative path
			dir.make_dir_recursive(GlobalRegistry.getModsFolder()+"/"+fff) # if the relative path doesn't exist in the mods folder, make the folders
			
			var _err11 = T.open(_x,File.WRITE) # create a new file at the new path 
			T.store_buffer(_dummy) # write the raw bytes, the header and file extension should take care of the file type
			Log.print("Unpacked "+_x)
			T.close()
	print(problems)
	return problems
	
func open_mods_folder(_args):
		Util.fixed_shell_open(ProjectSettings.globalize_path(soundDir))
		Log.print("Tried to open "+ProjectSettings.globalize_path(soundDir))

# function to check if folder names and paths are correct
func validate(_args):
	Util.fixed_shell_open(ProjectSettings.globalize_path("res://Modules/SoundModule/README_soundmod.txt")) # in some OS this will open the README in the default text editor
	var finalString = helpString #the helpstring was generated during loading, start with that
	var _zip = "\nChecking for .zip files: \n"
	_zip += "(Ignore this if the unzipped folder was located above)\n"
	if(dir_contents(soundDir).empty()):
		soundDir = GlobalRegistry.getModsFolder()+"/"
	for bit in dir_contents(soundDir):
		if(bit.begins_with("SoundMod_")):
			if(not sub_dir(soundDir).has(bit)):
				_zip += bit+" is still zipped! \n"
			else:
				continue
	finalString += _zip
	finalString += """\nIf on Windows, check that it didn't add an extra folder when unzipping, for example:
""" +soundDir+"""SoundMod_Effects/SoundMod_Effects/ 
This will not work! Cut and paste the duplicate folder, and merge when prompted."""
	OS.alert(finalString, OS.get_executable_path())

# runs after the game loads but before reaching the main menu
func postInit():
#	Log.print(String(GlobalRegistry.sexActivities.keys()))
	if(GlobalRegistry.getModule("FoxLib") == null):
		print("[SoundMod] Error: "+id+" requires FoxLib")
		OS.alert("Error! SoundMod requires FoxLib! Please install the latest version of Foxlib.", OS.get_executable_path())
#	var _temp = FoxLibAudioManager.getAllAudioIDs()
	if(sub_dir(soundDir).empty()): #one last check if things went wrong
		OS.alert("""No audio files located. Check you have sounds downloaded and placed in\n""" + (ProjectSettings.globalize_path(GlobalRegistry.getModsFolder()))+"\n OR in \n"+ ProjectSettings.globalize_path(GlobalRegistry.getModsFolder().rstrip("mods").rstrip("BDCCMods").plus_file("soundmod")) + """/
		
		Folder names have changed as of SoundMod v1.3.0, if you downloaded them before this rename them so they all start with \"SoundMod_\".
		If on Windows, check that it didn't add an extra folder when unzipping, for example:
		""" +(ProjectSettings.globalize_path(GlobalRegistry.getModsFolder()))+"""/SoundMod_Effects/SoundMod_Effects/ 
		will not work! Cut and paste the duplicate folder, and merge when prompted.""", OS.get_executable_path())
	
	var jsonResult
	var f = File.new()
	var _err = f.open(soundDir+"SoundMod_BGM/settings.json",File.READ) #attempt to read any settings for the BGM system
	if(not _err == OK):printerr("[SoundMod] Didn't find BGM settings file, if you previously tried to use BGM then it's broken :(")
	jsonResult = JSON.parse(f.get_as_text())
	assert(typeof(jsonResult.result) == TYPE_DICTIONARY, "[SoundMod] Could not read saved data file. Ignore this if you're not using BGM.")
	Globals.of(BGMDB).data = jsonResult.result
	f.close()
	
	if(f.file_exists("res://Modules/SoundModule/.exists.txt")): #check for hidden file, if it exists then SoundMod has been loaded before
		pass
	else:
		helpString = "SoundMod first-time setup! \nMake sure you installed FoxLib v0.10.7 or later! Then do this:\n 1. Download the audio files from the Mod Browser, then click the Mods Folder button\n 2. Unzip the audio files in the mods folder\n\r" + helpString
		f.open("res://Modules/SoundModule/.exists.txt", File.WRITE) #empty file created to indicate that this module has been loaded before
		f.close()
		validate(true) #make sure we validate since this is the first time
	
# hook for FoxLib mod options integration
func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "openfiles", "Open audio folder", "Open the folder where sounds are saved").connect("option_changed", self, "open_mods_folder")
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "fixit", "Do it for me", "Try to unzip the audio files").connect("option_changed", self, "do_it_for_me")
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "diditwork","Help! There's no sound!","Checks to see if you put audio in the right place").connect("option_changed", self, "validate")
#	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "installzip", "Select a .zip to add sounds", "Extracts a zip file to "+OS.get_user_data_dir()+"/soundmod/  \nWill overwrite existing!").connect("option_changed", self, "unzip_sounds")
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Settings","audiotest", "Show sound test in Me menu", "Show the sound test menu in the 'Me' menu",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Psoundoption", "Pleasure sounds", "Sound plays on arousal stat change",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Osoundoption", "Orgasm sounds", "Sound plays at orgasm",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Tsoundoption", "Tease sounds", "Sound plays on lust stat change",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Ssoundoption", "Struggle sounds", "Sound plays on struggle attempt",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","gagsoundoption", "Gagged sounds", "Play variant sounds when gagged",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","HypnoOption", "Hypno Hum", "Subtle hum when being hypnotized",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "spankOption", "Spanking", "Play spanking sound effect when spanked", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "punchOption", "Spanking", "Play (mild) punching sound effect when beating up", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "clothOption", "Clothes rustle", "Play fabric noise when trying to remove clothing (will play even if removal gets resisted)", false)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "chainOption", "Chain noise", "Play metal clink when trying to leash or apply bondage (will play even if it gets resisted)", false)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "plapOption", "Plaps & glucks", "Play a short loop of plaps while fucking (timing will not sync)", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "cumEffect", "Cum effects", "Should ejaculation sounds play along with orgasm voice clips?", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "squirtEffect", "Squirting", "Should characters with a vagina and no penis replace ejaculating with squirting?", true)
	foxModuleAPI.addSliderOptionInCategory("SoundMod Settings","pitchVarianceOption","Pitch variance","Slightly change pitch so sounds aren't repetitive", float(10))
	var select = []
	var dir = Directory.new()
	if !Util.folderExists(soundDir):
		dir.make_dir_recursive(soundDir)
	dir.open(soundDir)
	folders = sub_dir(soundDir)
	var actualFolders = []
	for packfolder in folders:
		if(!is_valid_pack(soundDir+packfolder)):
			continue
		else:
			actualFolders.append(packfolder.trim_prefix("SoundMod_"))
	for entry in actualFolders:
		select.append([entry, entry])
	select.append(["debug blank", "debug none"])
	foxModuleAPI.addListOptionInCategory("SoundMod Settings", "voicepackoption", "Voice Pack", select, "Select a voice pack. Packs are added by making a folder in the audio folder", "error")
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Settings", "BGMOption", "Background Music (EXPERIMENTAL)", "Play BGM sounds based on location", false)
	foxModuleAPI.addSliderOptionInCategory("SoundMod Settings", "BGMVolume", "BGM volume (EXPERIMENTAL)","Volume for BGM sound", 50)
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "BGMassign", "Assign BGM (EXPERIMENTAL)", "Assign music to locations").connect("option_changed", self, "BGM_popup")
	

#returns all the directories within the given directory (ignores files)
func sub_dir(path):
	var dir = Directory.new()
	var _folds:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir() && file_name != "." && file_name != "..":
				_folds.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to access the folder " +path)
	dir.list_dir_end()
	return _folds
	
# is this an audio file?
func is_this_audio(_filepath):
	if(_filepath.ends_with(".mp3") || _filepath.ends_with(".ogg") || _filepath.ends_with(".wav")):
		return true
	else:
		return false
	
# checks if the given directory has the expected directory structure for voice packs
func is_valid_pack(folder):
	var dir = Directory.new()
	var valid = false
	if dir.open(folder + "/") == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir() && file_name != "." && file_name != "..":
				if packReq.has(file_name):
					valid = true
				else:
					valid = false
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to access the folder " +folder)
	dir.list_dir_end()
	return valid	

# lists all the files in the given directory except the first one (assuming the first file was imported as a test)
func dir_contents_minus_first(path):
	var dir = Directory.new()
	var _file_names:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		dir.get_next()
		var file_name = dir.get_next()
		while(file_name != ""):
			if (!file_name.ends_with("import") && file_name != "." && file_name != ".."):
				_file_names.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to get the contents of " +path)
	dir.list_dir_end()
	return _file_names
	
# lists all the files in the given directory
func dir_contents(path):
	var dir = Directory.new()
	var _file_names:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while(file_name != ""):
			if (file_name != "." && file_name != ".."):
				_file_names.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to get the contents of " +path)
	dir.list_dir_end()
	return _file_names

# code for UI dialog box used for editing BGM track settings
func BGM_popup(_args):
	var jsonResult
	var f = File.new()
	var _err = f.open(soundDir+"SoundMod_BGM/settings.json",File.READ) #read from file
	assert(_err == OK,"[SoundMod] Didn't find BGM settings file. Ignore this if not using BGM.")
	jsonResult = JSON.parse(f.get_as_text())
	assert(typeof(jsonResult.result) == TYPE_DICTIONARY, "[SoundMod] Could not read saved data file for BGM. Ignore this if not using BGM.")
	Globals.of(BGMDB).data = jsonResult.result #place the data in FoxLib's global variables
	
	var Dialog = popupwindow.instance()
	var viewport = FoxUIManager.getCurrentScene().get_viewport()
	viewport.add_child(Dialog)
	Dialog.popup_centered_clamped() #show the dialog box
	Dialog.connect("tree_exiting", self, "saveBGMsettings") #when the dialog is closed, run the save function

# save the BGM system settings to file
func saveBGMsettings():
	var f = File.new()
	var _temp:Dictionary = Globals.of(BGMDB).data
	f.open(soundDir+"SoundMod_BGM/settings.json",File.WRITE_READ)
	f.store_line(JSON.print(_temp, "\t", true)) # data is saved as human-readable json
	f.close()
