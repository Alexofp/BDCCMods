extends GameExtender

const manager = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")
const Globals = preload("res://FoxLib/Globals.gd")
const fui = preload("res://FoxLib/FoxUIManager.gd")

var Smod = GlobalRegistry.getModule("SoundModule")
var wasScene:SceneBase
var inSexEngine:bool
var pack
var playedThisUpdate = false
var played2ThisUpdate = false
var played3ThisUpdate = false
var variance = Smod.pitchVarianceOption
var sfxPlayer2:AudioStreamPlayer
var sfxPlayer3:AudioStreamPlayer

var acts = {
	"DomPutBreastPumpOnSub":"sextoy",
	"DomPutPenisPumpOnSub":"sextoy",
	"DomRidingSubAnal":"plaps",
	"DomRidingSubVaginal":"plaps",
	"SexVaginalOnAllFours":"plaps",
	"SexAnalOnAllFours":"plaps",
	"ThreeDDS_DP":"plaps2",
	"ThreeDDS_SpitroastAnal":"plaps2",
	"ThreeDDS_SpitroastVag":"plaps2",
	"ThreeDDS_Train":"plaps",
	"ThreeDSS_Buttstack":"plaps",
	"SixtyNine":"oral",
	"SexOral":"oral",
	"DomOralSexOnSub":"oral",
	"SexPawjobMutual":"handjob",
	"SexPawjob":"handjob",
	"DomRimSub":"oral",
	"HK_Hypnotize":"hum",
	"Tribadism":"grind",
	"SexFleshlight":"plaps",
	"SexRimming":"oral",
	
	"DomBondage":"chain",
	"DomLeashesSub":"chain",
	"Spanking":"spank",
	"BeatingUpWhenAngry":"slap",
	"DomUndressActions":"clothes",
	"DomUndressesSub":"clothes",
	"SubUndressActions":"clothes",
	
}

#var _eep = GlobalRegistry.getSexActivityReferences()

var output:String = ""
var lastOutput:String = ""

func _init():
	id = "SoundPlayer"
	# triggers sounds in response to player stats
	
	
func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.pcUpdateNonBattleEffects) # this will run SoundPlayer every time the player's status effects are checked

func pcUpdateNonBattleEffects(_pc:Player):
	playedThisUpdate = false # sound plays only once, no infinite looping
	played2ThisUpdate = false
	played3ThisUpdate = false
	var currentScene = fui.getCurrentScene() #get the current Godot scene
	sfxPlayer2 = AudioStreamPlayer.new() #inject audio player 2
	currentScene.add_child(sfxPlayer2)
	sfxPlayer3 = AudioStreamPlayer.new() #inject audio player 3
	currentScene.add_child(sfxPlayer3)

	if(GM.main.sceneStack.size() > 0): #wait until the game is loaded
		wasScene = GM.main.getCurrentScene() #get the current BDCC scene
	if not is_instance_valid(wasScene):
		return #check if scene was already deleted
	var _floop = Smod.voicepackoption #should retrieve the selected voicepack from options menu (set by FoxLib) but sometimes it doesn't work
	pack = _floop.substr(_floop.find("_")+1,-1)
	variance = Smod.pitchVarianceOption/100

	#are we in a dynamic sex scene?
	if(wasScene.sceneID == "GenericSexScene"):
		if(wasScene.sexEngine.isInvolved("pc")): #if pc is not involved, we do nothing
			inSexEngine = true 
			var engine:SexEngine = wasScene.sexEngine #get the current sexengine
			output = engine.getFinalOutput()
			if(output == lastOutput): #if text passage did not change, do nothing
				return #this means we are in a sub-menu and we didn't actually do a turn
			var test:SexActivityBase = engine.activities.back() #get the current activity
			if engine.activities.size() == 1: #if only one activity, then pick that one
				test = engine.activities[0]
			if test == null: #quit if no activities started
				return
			if(engine.hasSexEnded()): 
				inSexEngine = false #check if sex ended, i.e. we are on the results screen
			var meInfo:SexInfoBase = wasScene.sexEngine.getCharInfo("pc")
			if(meInfo.didJustCame()):
				PCorgasm()
			if(meInfo.hadStim ):
				PCpleased()
			handleSexEngine(engine,engine.activities)
			lastOutput = output
		else:
			return
			
	#are we struggling?
	if(wasScene.sceneID == "StrugglingScene"):
		if(wasScene.state == "startStruggleAgainst"):
			PCstruggled()
			
	#did the Lust stat change?
	if(!GM.pc.is_connected("lust_changed",self,"lustSound")):
		GM.pc.connect("lust_changed",self,"lustSound")
#	if(!GM.pc.is_connected("stamina_changed",self,"on_stamina")):
#		GM.pc.connect("stamina_changed",self,"on_stamina")
#	if(!GM.pc.is_connected("pain_changed",self,"ishurted")):
#		GM.pc.connect("pain_changed",self,"ishurted")

#func ishurted(pain, initialpain):
#	if !inSexEngine:
#		return
#	var engine:SexEngine = GM.main.getCurrentScene().sexEngine
#	var activity = engine.currentLastActivityID
#	var test:SexActivityBase = engine.getActivityWithUniqueID(activity-1)
#	if(test.id == "Spanking" && (pain > initialpain) && Smod.spankOption):
#		play_effect(engine, "spank")
#	elif(test.id == "BeatingUpWhenAngry" && pain > initialpain && Smod.punchOption):
#		play_effect(engine, "slap")

#sounds in response to player lust stat
func lustSound(lust, initialLust):
	if(initialLust-lust == GM.pc.lustThreshold()):
		PCorgasm()
	elif(GM.pc.getArousal() != 0 || inSexEngine):
		PCpleased()
	elif(lust > initialLust):
		PCteased()

#sounds that happen during dynamic sex
func handleSexEngine(_engine:SexEngine, _activities):
	var peeps = _engine.getCharIDList()
#	var doms = _engine.getDoms().keys()
#	var subs = _engine.getSubs().keys()
	var sigh:Dictionary = {}
#	var _dom_tags = []
#	var _sub_tags = []
	var tags = []
	#check for certain activities that have a sound to go with
	for _activity in _activities:
		if(_activity.id == "DomUndressActions" or _activity.id == "SubUndressActions" or _activity.id == "DomUndressesSub"):
			if(Smod.clothOption): #note: if sub resists and succeeds, the activity is removed and no sound is triggered
				var _to_play = acts[_activity.id]
				play_effect(_engine, _to_play)
		elif(_activity.id == "DomLeashesSub" && Smod.chainOption):
			if(_activity.state == ""):
				var _to_play = acts[_activity.id]
				play_effect(_engine, _to_play)
		elif(_activity.id == "DomBondage" && Smod.chainOption):
			var _to_play = acts[_activity.id]
			play_effect(_engine, _to_play)
		elif(_activity.id == "Spanking" && Smod.spankOption):
			if(not _activity.has_method("getAssDescriptionAfterImpact")):
				printerr("[SoundMod] Error parsing dynamic sex event:"+_activity.id)
			if(_activity.didSpankThisTime or _activity.didBigSpankThisTime):#only play sound when spank happens
				var _to_play = acts[_activity.id]
				play_effect(_engine, _to_play)
		elif(_activity.id == "BeatingUpWhenAngry" && Smod.punchOption):
			var _to_play = acts[_activity.id]
			play_effect(_engine, _to_play)
	#check activity tags to see if associated background sound should play
	if(not Smod.plapOption):
		return
	else:
		for _activity in _activities:
			tags = []
			var back = acts.get(_activity.id)
			for chID in peeps:
				var intag = []
				for ii in range(15):
					if(_engine.hasTag(chID, ii)): #get tags for participant
						tags.append(ii)
						intag.append(ii)
				sigh.get_or_add(chID,intag)
			if(skipPlapping(_engine, sigh)):
				break
			if(back == "plaps" and tags.has(4) and (tags.has(11) or tags.has(12)) and (_activity.state != "aftercumminginside") and _activity.state != "knotting"):
				play_background(_engine,"plaps")
				continue
			if(back == "oral" and tags.has(5)):
				play_background(_engine,"oral")
				continue
			if(back == "grind" and tags.has(1)):
				play_background(_engine,"grind")
				continue
			if(back == null && _engine.activities.size() > 1):
				var activity = _engine.currentLastActivityID #get the current activity
				var test:SexActivityBase = _engine.getActivityWithUniqueID(activity-2)
				if(test != null && (checkTag(_engine, sigh, 4) or checkTag(_engine, sigh, 5) )):
					play_background(_engine,acts[test.id]) #check if the previous activity is ongoing and play that sound if yes
					continue
	
	if(Smod.cumEffect):
		for pers in peeps: #search all participants 
			var _temp = _engine.getCharInfo(pers)
			if(_temp.didJustCame()): #check if anyone orgasmed
				cum(GM.main.getCharacter(pers))
				yield(wasScene.get_tree().create_timer(rand_range(0.5,1.0)),"timeout")
				cum(GM.main.getCharacter(pers))
				yield(wasScene.get_tree().create_timer(1.5),"timeout")
				cum(GM.main.getCharacter(pers))
	
	if(GM.pc.hasEffect(StatusEffect.UnderHypnosis) or GM.pc.hasEffect(StatusEffect.HypnoVisorActive)):
		manager.playNamedBGM("SoundModule:Effecthum")
	if(not (GM.pc.hasEffect(StatusEffect.UnderHypnosis) or GM.pc.hasEffect(StatusEffect.HypnoVisorActive))):
		manager.playBGM(null)
		
func checkTag(_engine, _tagDict, tag:int):
	for item in _tagDict:
		if _tagDict.get(item).has(tag):
			return true
	return false

func skipPlapping(_engine, _tagDict):
	for item in _tagDict:
		if _engine.getCharInfo(item).didJustCame() && _tagDict.get(item).has(4):
			return true
	return false

	
func PCorgasm():
	var sound
	if(Smod.Osoundoption && !playedThisUpdate):
		if(GM.pc.hasEffect(StatusEffect.Gagged) && Smod.gagsoundoption):
			sound = manager.getFoxAudio("SoundModule:Soundorgasm_gagged"+pack) #note that this name was determined at import; see the Module.gd
		else:
			sound = manager.getFoxAudio("SoundModule:Soundorgasm"+pack)
		if sound == null:
			Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
		else:
			sound.setPitchVariance(variance)
			sound.playAsSFX()
		Log.print("[SoundMod] Playing Audio Object: " + sound.getId())
		playedThisUpdate = true

func PCpleased():
	var sound
	if(Smod.Psoundoption && !playedThisUpdate):
		if(GM.pc.hasEffect(StatusEffect.Gagged) && Smod.gagsoundoption):
			sound = manager.getFoxAudio("SoundModule:Soundpleasure_gagged"+pack)
		else:sound = manager.getFoxAudio("SoundModule:Soundpleasure"+pack)
		if sound == null:
			Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
		else:
			sound.setPitchVariance(variance)
			sound.playAsSFX()
		Log.print("[SoundMod] Playing Audio Object: " + sound.getId())
		playedThisUpdate = true
	
func PCteased():
	var sound
	if(Smod.Tsoundoption && !playedThisUpdate):
		if(GM.pc.hasEffect(StatusEffect.Gagged) && Smod.gagsoundoption):
			sound = manager.getFoxAudio("SoundModule:Soundtease_gagged"+pack)
		else:sound = manager.getFoxAudio("SoundModule:Soundtease"+pack)
		if sound == null:
			Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
		else:
			sound.setPitchVariance(variance)
			sound.playAsSFX()
		Log.print("[SoundMod] Playing Audio Object: " + sound.getId())
		playedThisUpdate = true


func PCstruggled():
	var sound
	if(Smod.Ssoundoption && !playedThisUpdate):
		if(GM.pc.hasEffect(StatusEffect.Gagged) && Smod.gagsoundoption):
			sound = manager.getFoxAudio("SoundModule:Soundstruggle_gagged"+pack)
		else:sound = manager.getFoxAudio("SoundModule:Soundstruggle"+pack)
		if sound == null:
			Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
		else:
			sound.setPitchVariance(variance)
			sound.playAsSFX()
		Log.print("[SoundMod] Playing Audio Object: " + sound.getId())
		playedThisUpdate = true
	
# configure audio player 2
func playCh2(audioSample, pitchDiff=0.0):
	if audioSample != null and ((audioSample is AudioStreamOGGVorbis) or (audioSample is AudioStreamMP3)) and audioSample.loop:
		# Disable looping for incomming audio samples as we do not support looping audio properly.
		audioSample.loop = false
	if pitchDiff < -0.5:
		pitchDiff = -0.5
	elif pitchDiff > 0.5:
		pitchDiff = 0.5
	if sfxPlayer2.is_playing():
		sfxPlayer2.stop()
	if audioSample != null:
		sfxPlayer2.pitch_scale = 1.0 + pitchDiff
		sfxPlayer2.set_stream(audioSample)
		sfxPlayer2.play()
	else:
		sfxPlayer2.pitch_scale = 1.0

# configure audio player 3
func playCh3(audioSample, pitchDiff=0.0):
	if audioSample != null and ((audioSample is AudioStreamOGGVorbis) or (audioSample is AudioStreamMP3)) and audioSample.loop:
		# Disable looping for incomming audio samples as we do not support looping audio properly.
		audioSample.loop = false
	if pitchDiff < -0.5:
		pitchDiff = -0.5
	elif pitchDiff > 0.5:
		pitchDiff = 0.5
	if sfxPlayer3.is_playing():
		sfxPlayer3.stop()
	if audioSample != null:
		sfxPlayer3.pitch_scale = 1.0 + pitchDiff
		sfxPlayer3.set_stream(audioSample)
		sfxPlayer3.play()
	else:
		sfxPlayer3.pitch_scale = 1.0
		
#play background sounds on audioplayer3
func play_background(_engine:SexEngine, _tag):
	var sound
	sound = manager.getFoxAudio("SoundModule:Effect"+_tag)
	if sound == null: 
		Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
	elif(not played3ThisUpdate):
		playCh3(sound.getLoadedAudio(), variance)
		for x in [1,2,3,4]:
			yield(fui.getCurrentScene().get_tree().create_timer(0.5), "timeout")
			playCh3(sound.getLoadedAudio(), variance)
			played3ThisUpdate = true
		Log.print("[SoundMod] Playing Audio Object: " + sound.getId())

#play sound effects on audioplayer2
func play_effect(_engine:SexEngine, _activity):
	var sound
	sound = manager.getFoxAudio("SoundModule:Effect"+_activity)
	if sound == null: 
		Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
	elif(not played2ThisUpdate):
		playCh2(sound.getLoadedAudio(),variance)
		played2ThisUpdate = true
		Log.print("[SoundMod] Playing Audio Object: " + sound.getId())
			

#handle npc cumming and what sound is for which genitals
func cum(_ch):
	var sound = manager.getFoxAudio("SoundModule:Effectcum")
	if(_ch.hasBodypart(BodypartSlot.Vagina) and not _ch.hasBodypart(BodypartSlot.Penis)):
		if(Smod.squirtEffect):
			sound = manager.getFoxAudio("SoundModule:Effectsquirt")
	if sound == null:
		Log.printerr("[SoundMod] Failed to locate FoxAudio SoundModule: " + pack)
	else:
		playCh2(sound.getLoadedAudio(),variance)
		playedThisUpdate = true
