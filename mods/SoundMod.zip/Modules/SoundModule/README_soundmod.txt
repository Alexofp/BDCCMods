SoundMod consists of 2 major parts: the voice pack and the effects pack. The folders for audio files must all begin with "SoundMod_" or else the mod will ignore it. The mod itself (SoundMod.zip) must remain zipped.
The structure it expects to find is this:

user://
    mods/
        SoundMod.zip (DON'T UNZIP THIS. The game expects mods to be zipped.)
        SoundMod_Effects/
            effects_sextoy/
                example_sound.mp3
            effects_plaps/
            effects_oral/
            effects_grind/
            effects_chain/
            effects_spank/
            effects_slap/
            effects_clothes/
            effects_hum/
            effects_cum/
            effects_squirt/
        SoundMod_pack_fem-1/
            sounds_orgasm/
                example_sound.ogg
            sounds_orgasm_gagged/
            sounds_pleasure/
            sounds_pleasure_gagged/
            sounds_struggle/
            sounds_struggle_gagged/
            sounds_tease/
            sounds_tease_gagged/
        SoundMod_BGM/
            example_music.wav
            
"user://" is determined by the game engine and depends on what platform you are playing on. The "mods" folder is where all mods go. Note that SoundMod will also look in "user://soundmod/" to remain compatible with older versions of the mod. 

In terms of this mod, a voice pack is a folder with 8 subfolders, each subfolder represents a single sound. The folder must start with "pack_", and anything after that will be used as the pack name. Recommended that you label a pack as feminine, masculine, or androgynous for organization. If you share the voice pack online, credit the voicepack author by placing a link to their socials inside the pack folder.
For example:

SnudMod_pack_fem-1/                     <- "pack_" plus name, ideally fem/masc/andro then a unique name
    sounds_orgasm/              <- sound type folder, must have exact name shown above
        soundclip.ogg           <- clips can be named whatever, but must be .ogg, .mp3, or .wav
        soundclip2.mp3
        whatever.ogg

When a player sound is played, one clip is chosen at random. Only one player sound should play at a time. There are 4 voice sounds (with 4 gagged variants). In order of priority, these are:
Struggle = plays when pc tries to remove a restraint
Orgasm = plays when pc has an orgasm
Pleasure = plays when pc's Arousal stat increases
Tease = plays when pc's Lust stat increases

A voice pack MUST have these sounds (subfolders) with these exact names (it's okay if they are empty folders), or else the mod won't find it:

SoundMod_pack_fem-1/
    sounds_orgasm/
    sounds_orgasm_gagged/
    sounds_pleasure/
    sounds_pleasure_gagged/
    sounds_struggle/
    sounds_struggle_gagged/
    sounds_tease/
    sounds_tease_gagged/

To create custom sounds:
1. From the mod launcher, click "Mods Folder"
or, open the Mod Options menu, under SoundMod settings, click "open audio folder"
2. Open the appropriate folder that starts with "SoundMod_" (pack, Effect, or BGM), and paste your sound files according to the guidelines described in this document
3. If making a new voice option, make a new folder and name it something that makes sense - but it MUST begin with "pack_"!
4. Restart the game

(Try to choose shorter clips, FoxLib's audio manager always plays the full duration of the clip.)

There is also a folder for sound effects. You can place your own .mp3, .wav, .ogg files in here as well. Effects play sound on a different audio channel so they can happen at the same time as player sounds. The triggers for these are kinda hack-y and each one is different, so I'm not going to try and explain, but the name of each sound should hopefully be pretty obvious (see above).

Lastly, there is the BGM folder. It has no subfolders, because each audio file within is a looping background music track. You can place your own .mp3, .wav, .ogg files in here. You are responsible for making the track loop cleanly. The trigger for BGM is based on player location. Go to Mod Options and click "assign BGM", and you will be able to set the BGM for each floor and room. Note that setting a room BGM takes priority over the floor's BGM. It doesn't have to be music, either, ambient soundscapes can also work.
For example:

SoundMod_BGM/
    prison_ambience.ogg
    example_track.mp3


