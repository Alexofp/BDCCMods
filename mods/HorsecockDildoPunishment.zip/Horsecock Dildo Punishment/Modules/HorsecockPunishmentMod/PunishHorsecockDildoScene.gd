extends "res://Scenes/SceneBase.gd"

var npcID = ""
var npc:DynamicCharacter
var npcSlavery:NpcSlave

var isPussy = false
var hadContents = false
var uniqueItemID = ""

func _init():
	sceneID = "PunishHorsecockDildoScene"

func _initScene(_args = []):
	npcID = _args[0]
	npc = GlobalRegistry.getCharacter(npcID)
	npcSlavery = npc.getNpcSlavery()

	var item = GM.pc.getInventory().getFirstOf("HorsecockDildo")
	if(item != null):
		uniqueItemID = item.getUniqueID()

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _run():
	if(state == ""):
		addCharacter(npcID)
		playAnimation(StageScene.HorsecockDildoSex, "tease", {pc=npcID, bodyState={naked=true}})

		saynn("Feeling in a punishing mood, you grab {npc.name} and drag {npc.him} over to your horsecock dildo. You set it up on the floor and let the suction cup fix it in place. {npc.He} stares at the massive rubber shaft with obvious dread.")

		if(npcSlavery.isResistingSuperActively()):
			saynn("[say=npc]No- no, please, not that thing, it won't even fit![/say]")
			saynn("{npc.He} tries to bolt, but you're faster and drag {npc.him} right back.")
		elif(npcSlavery.isActivelyResisting()):
			saynn("[say=npc]Please.. I'll do anything else..[/say]")
			saynn("{npc.He} shrinks back from it, but nobody's coming to save {npc.him}.")
		elif(npcSlavery.getBrokenSpirit() >= 0.7):
			saynn("{npc.He} doesn't even protest, just stares at the toy with dead, resigned eyes.")
		else:
			saynn("[say=npc]C-can't we just.. talk about this?[/say]")

		saynn("You strip {npc.him} down and shove {npc.him} toward it. Which hole is going to take it?")

		if(npc.hasReachableVagina()):
			addButton("Pussy", "Force them to ride it with their pussy", "ride_pussy")
		if(npc.hasReachableAnus()):
			addButton("Anus", "Force them to ride it with their ass", "ride_anus")
		addButton("Never mind", "You changed your mind", "endthescene")

	if(state == "begin_riding"):
		playAnimation(StageScene.HorsecockDildoSex, "inside", {pc=npcID, bodyState={naked=true}})

		saynn("You force {npc.him} down onto {npc.his} knees over the toy, one hand pressed flat between {npc.his} shoulder blades to keep {npc.him} in place. The flared tip presses up against {npc.his} "+str("{npc.pussyStretch} pussy" if isPussy else "{npc.analStretch} tailhole")+", and it's immediately obvious {npc.he}'s going to need some convincing to take it.")

		if(npcSlavery.isActivelyResisting()):
			saynn("[say=npc]It's too big, I can't, please-[/say]")
			saynn("{npc.He} squirms and tries to pull away, but you just push {npc.him} back down, harder this time.")
		else:
			saynn("[say=npc]Ah- ah, it's too much..[/say]")
			saynn("{npc.He} whimpers but doesn't fight it, just grits {npc.his} teeth as you keep the pressure on.")

		saynn("The first few attempts don't get anywhere, {npc.his} "+str("pussy slit" if isPussy else "anal ring")+" refusing to stretch enough to let it in. You're not in a hurry. You just keep grinding {npc.his} hips down against it.")

		addButton("Keep pushing", "Force it inside", "begin_penetration")

	if(state == "begin_penetration"):
		playAnimation(StageScene.HorsecockDildoSex, "sex", {pc=npcID, bodyState={naked=true}})

		saynn("Eventually {npc.his} body gives up fighting it, the flared head popping past the tight ring of muscle and sinking into {npc.his} "+str("slit" if isPussy else "ass")+" with one firm shove from you.")

		saynn("[say=npc]Ah-! Ahh, it's- it's so deep..[/say]")

		saynn("You keep a hand on {npc.his} hip and start working {npc.him} up and down along the shaft yourself, not giving {npc.him} a say in the pace. Every drop forces the rubber cock a little deeper.")

		if (npc.hasPenis() && !isPussy):
			saynn("{npc.His} {npc.penis} betrays {npc.him}, hardening from the pressure on {npc.his} prostate no matter how much {npc.he} doesn't want it to.")

		saynn("You lean down close to {npc.his} ear.")

		saynn("[say=pc]You're going to ride this until I say stop.[/say]")

		addButton("Make them ride it hard", "Force the pace", "do_cum")

	if(state == "do_cum"):
		playAnimation(StageScene.HorsecockDildoSex, "fast", {pc=npcID, pcCum=true, bodyState={naked=true, hard=true}})

		saynn("You grab {npc.his} hips with both hands and start slamming {npc.him} down onto the toy at a brutal pace, not letting up even as {npc.he} claws at the floor.")

		saynn("[say=npc]Ah! Ah- ah, please, it's too much, I'm going to-[/say]")

		saynn("[say=pc]That's the idea.[/say]")

		if (npc.hasPenis()):
			saynn("{npc.His} neglected {npc.penis} is rock hard and leaking, twitching with every forced thrust, whether {npc.he} wants it to or not.")

		saynn("{npc.His} whole body locks up, back arching hard as the forced orgasm rips through {npc.him}, {npc.his} "+str("pussy" if isPussy else "tailhole")+" spasming helplessly around the rubber shaft while you keep {npc.him} riding through every last twitch of it.")

		var item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
		if(item != null && item.getFluids() != null && !item.getFluids().isEmpty()):
			hadContents = true
			saynn("Right as {npc.he} clenches down hardest, the toy gives way and empties everything you loaded it with straight into {npc.him}, drawing a broken, muffled moan out of {npc.him}.")
			if(isPussy):
				item.getFluids().transferTo(npc.getBodypart(BodypartSlot.Vagina), 1.0)
			else:
				item.getFluids().transferTo(npc.getBodypart(BodypartSlot.Anus), 1.0)

		npc.orgasmFrom("pc")
		if(isPussy):
			npc.gotOrificeStretchedWith(BodypartSlot.Vagina, 50, false)
		else:
			npc.gotOrificeStretchedWith(BodypartSlot.Anus, 50, false)

		addButton("Continue", "See what happens next", "afterglow")

	if(state == "afterglow"):
		playAnimation(StageScene.HorsecockDildoSex, "inside", {pc=npcID, bodyState={naked=true}})

		saynn("You leave {npc.him} impaled on it a while longer, shaking and oversensitive, before finally hauling {npc.him} up off of it. It comes free with a wet, obscene noise, leaving {npc.his} "+str("slit" if isPussy else "tailhole")+" gaping for a moment before it starts to close back up.")

		if(npcSlavery.isResistingSuperActively() || npcSlavery.isActivelyResisting()):
			saynn("{npc.He} curls up on the floor, glaring daggers at you between shaky breaths, but {npc.he} knows better than to say anything.")
		elif(npcSlavery.getFear() > 0.6 && npcSlavery.personalityScore({PersonalityStat.Coward: 1.0}) > 0.1):
			saynn("{npc.He} stays curled up where you left {npc.him}, too scared to even ask if it's over.")
			npcSlavery.addObedience(0.05)
		else:
			saynn("{npc.He} just lies there for a while, panting, clearly humiliated by how {npc.his} body reacted to all of it.")

		npcSlavery.handlePunishment(4)
		npcSlavery.addTired(1)

		addButton("Continue", "That'll teach them", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "ride_pussy"):
		isPussy = true
		setState("begin_riding")
		return

	if(_action == "ride_anus"):
		isPussy = false
		setState("begin_riding")
		return

	if(_action == "begin_penetration"):
		processTime(60*5)

	if(_action == "do_cum"):
		processTime(5*60)

	if(_action == "afterglow"):
		processTime(6*60)

	setState(_action)

func saveData():
	var data = .saveData()

	data["npcID"] = npcID
	data["isPussy"] = isPussy
	data["hadContents"] = hadContents
	data["uniqueItemID"] = uniqueItemID

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
	npc = GlobalRegistry.getCharacter(npcID)
	npcSlavery = npc.getNpcSlavery() if npc != null else null
	isPussy = SAVE.loadVar(data, "isPussy", false)
	hadContents = SAVE.loadVar(data, "hadContents", false)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
