extends SlaveActionBase

func _init():
	id = "PunishHorsecockDildo"
	actionType = Punishment
	sceneID = "PunishHorsecockDildoScene"
	slaveResistChanceMult = 1.0
	slaveOnlyActiveResist = true

	buttonPriority = 65
	rewardHint = -4

func getVisibleName():
	return "Horsecock dildo"

func getVisibleDesc():
	return "Force your slave to ride your giant horsecock dildo"

func checkCanDo(_slaveID, _extraSlavesIDs = {}):
	if(!GM.pc.getInventory().hasItemID("HorsecockDildo")):
		return [false, "You need to own a horsecock dildo first"]

	var character:DynamicCharacter = GlobalRegistry.getCharacter(_slaveID)
	if(!character.hasReachableVagina() && !character.hasReachableAnus()):
		return [false, "Your slave has no usable holes for this"]

	return [true]
