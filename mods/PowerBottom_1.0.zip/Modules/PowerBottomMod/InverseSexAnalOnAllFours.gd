extends "res://Modules/PowerBottomMod/InverseSexVaginalOnAllFours.gd"

func _init():
	id = "InverseSexAnalOnAllFours"
	usedBodypart = BodypartSlot.Anus
	usedTag = SexActivityTag.AnusUsed
	usedTagInside = SexActivityTag.AnusPenetrated
	fetishGiving = Fetish.AnalSexReceiving
	fetishReceiving = Fetish.AnalSexGiving
	usedBodypartNames = ["anus", "tailhole", "backdoor", "star", "anal ring"]
	switchHoleActivity = "InverseSexVaginalOnAllFours"
	otherHoleNames = ["pussy"]
	otherHoleBodypart = BodypartSlot.Vagina
	otherHoleTag = SexActivityTag.VaginaUsed
	otherHoleFetishGiving = Fetish.VaginalSexReceiving
	otherHoleFetishReceiving = Fetish.VaginalSexGiving
	otherGoal = SexGoal.FuckVaginal
	aboutToPenetrateReaction = SexReaction.AboutToPenetrateAnal
	sexReactionPullOut = SexReaction.BeggingToPullOutAnal
	isVag = false
	
	activityName = "Receive Anal"
	activityDesc = "Make them fuck your ass!"
	
func getGoals():
	if(currentPose == POSE_CHOKEFUCK):
		return {
			SexGoal.ChokeSexAnal: 1.0,
			SexGoal.FuckAnal: 1.0,
			SexGoal.StraponAnal: 1.0,
		}
	return {
		SexGoal.FuckAnal: 1.0,
		SexGoal.StraponAnal: 1.0,
	}
