extends "res://Game/SexEngine/SexActivityBase.gd"
var waitTimer:int = 0

var usedBodypart:String = BodypartSlot.Vagina
var usedTag:int = SexActivityTag.VaginaUsed
var usedTagInside:int = SexActivityTag.VaginaPenetrated
var fetishGiving:String = Fetish.VaginalSexReceiving
var fetishReceiving:String = Fetish.VaginalSexGiving
var aboutToRideReaction:int = SexReaction.AboutToRidePussy
var usedBodypartNames:Array = ["pussy", "pussy", "slit", "cunt", "kitty"]
var switchHoleActivity:String = "DomRidingSubAnal"
var otherHoleNames:Array = ["anus"]
var otherHoleBodypart:String = BodypartSlot.Anus
var otherHoleTag:int = SexActivityTag.AnusUsed
var otherHoleFetishGiving:String = Fetish.AnalSexReceiving
var otherHoleFetishReceiving:String = Fetish.AnalSexGiving
var otherGoal:String = SexGoal.FuckAnal
var currentPose:String = ""
var isVag:bool = true
var isMakingOut:bool = false

func _init():
	id = "SubRidingDomVaginal"
	
	activityName = "Cowgirl Vaginal (Bottom)"
	activityDesc = "Make them ride your cock with their pussy!"
	activityCategory = ["Fuck"]

func getGoals():
	return {
		SexGoal.FuckVaginal: 1.0,
		SexGoal.StraponVaginal: 1.0,
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.SlutwallSex: false,
		SexType.BitchsuitSex: false,
	}

const POSE_DEFAULT = "POSE_DEFAULT"
const POSE_COWGIRL = "POSE_COWGIRL"
const POSE_REVERSECOWGIRL = "POSE_REVERSECOWGIRL"
const POSE_COWGIRLALT = "POSE_COWGIRLALT"
const POSE_LOTUS = "POSE_LOTUS"
const POSE_COWGIRLAMAZON = "POSE_COWGIRLAMAZON"
const POSE_STANDRIDE = "POSE_STANDRIDE"

const PoseToName = {
	POSE_DEFAULT: "Default",
	POSE_COWGIRL: "Cowgirl",
	POSE_REVERSECOWGIRL: "Reverse Cowgirl",
	POSE_COWGIRLALT: "Cowgirl Alternative",
	POSE_LOTUS: "Lotus",
	POSE_STANDRIDE: "Standing",
	POSE_COWGIRLAMAZON: "Cowgirl amazon",
}
const PoseToAnimName = {
	POSE_DEFAULT: StageScene.SexCowgirl,
	POSE_COWGIRL: StageScene.SexCowgirl,
	POSE_REVERSECOWGIRL: StageScene.SexReverseCowgirl,
	POSE_COWGIRLALT: StageScene.SexCowgirlAlt,
	POSE_LOTUS: StageScene.SexLotus,
	POSE_STANDRIDE: StageScene.SexStandRide,
	POSE_COWGIRLAMAZON: StageScene.SexCowgirlAmazon,
}
func getAvaiablePoses() -> Array:
	
	if(getSexType() == SexType.DefaultSex):
		var possible:= [POSE_COWGIRL, POSE_REVERSECOWGIRL, POSE_COWGIRLALT, POSE_LOTUS, POSE_COWGIRLAMAZON]
		if(getSexEngine() != null && getSexEngine().hasWallsNearby()):
			possible.append(POSE_STANDRIDE)
		
		return possible
	
	return [POSE_DEFAULT]

func canStartActivity(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	if(!_domInfo.getChar().hasReachablePenis() && !_domInfo.getChar().isWearingStrapon()):
		return false
	if(usedBodypart == BodypartSlot.Vagina && !_subInfo.getChar().hasReachableVagina()):
		return false
	if(usedBodypart == BodypartSlot.Anus && !_subInfo.getChar().hasReachableAnus()):
		return false
	if(_domInfo.getCharID() != "pc"):
		return false
	return .canStartActivity(_sexEngine, _domInfo, _subInfo)

func isActivityImpossibleShouldStop() -> bool:
	if(!getDom().hasReachablePenis() && !getDom().isWearingStrapon()):
		return true
	if(usedBodypart == BodypartSlot.Vagina && !getSub().hasReachableVagina()):
		return true
	if(usedBodypart == BodypartSlot.Anus && !getSub().hasReachableAnus()):
		return true
		
	return false

func getTags(_indx:int) -> Array:
	if(_indx == DOM_0):
		var thetags:Array = [usedTag, SexActivityTag.HavingSex]
		if(getState() in ["fucking", "aftercumminginside", "knotting", "inside"]):
			thetags.append(usedTagInside)
		return thetags
	if(_indx == SUB_0):
		if(getState() in ["fucking", "aftercumminginside", "knotting", "inside"]):
			return [SexActivityTag.PenisUsed, SexActivityTag.PenisInside, SexActivityTag.HavingSex, SexActivityTag.PreventsSubViolence, SexActivityTag.PreventsSubTeasing]
		return [SexActivityTag.PenisUsed, SexActivityTag.HavingSex, SexActivityTag.PreventsSubViolence, SexActivityTag.PreventsSubTeasing]
	return []

func getCheckTagsDom() -> Array:
	return [SexActivityTag.OrderedToDoSomething, usedTag, SexActivityTag.HavingSex]

func getCheckTagsSub() -> Array:
	return [SexActivityTag.OrderedToDoSomething, SexActivityTag.PenisUsed, SexActivityTag.HavingSex]

func isStraponSex() -> bool:
	return getDom().isWearingStrapon()

#func subSensetivity() -> float:
#	var strapon = getSub().getWornStrapon()
#	if(strapon == null):
#		return 1.0
#
#	return strapon.getStraponPleasureForDom()

func getDickName(dickName = null) -> String:
	if(isStraponSex()):
		return "strapon"
	if(dickName == null):
		return RNG.pick(["cock", "dick", "member"])
	return dickName

func getUsedBodypartName() -> String:
	var theName = RNG.pick(usedBodypartNames)
	if(usedBodypart == BodypartSlot.Vagina):
		theName = "{sub.pussyStretch} "+theName
	if(usedBodypart == BodypartSlot.Anus):
		theName = "{sub.anusStretch} "+theName
	
	var _isNeedy:bool = getSub().getLustLevel() > 0.6
	var _isDry:bool = getSub().getLustLevel() < 0.1
	var _isLubedUp:bool = getSub().hasEffect(StatusEffect.LubedUp)
	var _hasCumInHole:bool = false
	if(usedBodypart == BodypartSlot.Vagina):
		_hasCumInHole = getSub().hasEffect(StatusEffect.HasCumInsideVagina)
	if(usedBodypart == BodypartSlot.Anus):
		_hasCumInHole = getSub().hasEffect(StatusEffect.HasCumInsideAnus)
	
	if(_hasCumInHole && RNG.chance(30)):
		theName = RNG.pick(["creamed", "stuffed"])+" "+theName
	elif(_isNeedy):
		if(usedBodypart == BodypartSlot.Vagina):
			theName = RNG.pick(["needy", "awaiting", "inviting"])+" "+theName
		if(usedBodypart == BodypartSlot.Anus):
			theName = RNG.pick(["needy", "awaiting", "drippy", "inviting", "wet", "slick", "aroused"])+" "+theName
	elif(_isLubedUp):
		theName = RNG.pick(["lubed up"])+" "+theName
	elif(_isDry && RNG.chance(50)):
		if(usedBodypart == BodypartSlot.Vagina):
			theName = RNG.pick(["dry"])+" "+theName
		if(usedBodypart == BodypartSlot.Anus):
			theName = RNG.pick(["dry"])+" "+theName
	return theName

func getStartTextForPose(thePose:String) -> String:
	var throughClothing = "."
	if(!hasBodypartUncovered(DOM_0, usedBodypart)):
		throughClothing = " through {dom.yourHis} clothing"
	
	var text:String = ""
	if(thePose == POSE_COWGIRL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} and {sub.youVerb('rub')} {sub.yourHis} "+getUsedBodypartName()+" against {dom.yourHis} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+throughClothing+".",
		])
	elif(thePose == POSE_REVERSECOWGIRL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} in a reverse cowgirl position and {sub.youVerb('rub')} {sub.yourHis} "+getUsedBodypartName()+" against {dom.yourHis} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+throughClothing+".",
		])
	elif(thePose == POSE_COWGIRLAMAZON):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} in a half-amazon cowgirl position and {sub.youVerb('rub')} {sub.yourHis} "+getUsedBodypartName()+" against {dom.yourHis} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+throughClothing+".",
		])
	elif(thePose == POSE_COWGIRLALT):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} and {dom.youVerb('tilt')} {sub.yourHis} body back while rubbing {sub.yourHis} "+getUsedBodypartName()+" against {dom.yourHis} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+throughClothing+".",
		])
	elif(thePose == POSE_LOTUS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('sink')} into {dom.your} lap, wrapping {sub.yourHis} legs around {dom.yourHis} waist, holding {dom.yourHis} shoulders for support. {sub.YourHis} "+getUsedBodypartName()+" {sub.youVerb('press', 'presses')} tightly against {dom.yourHis} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+throughClothing+" in the close, intimate embrace.",
		])
	elif(thePose == POSE_STANDRIDE):
		text = RNG.pick([
				"{sub.You} {sub.youVerb('raise')} one leg high and {sub.youVerb('pin')} {dom.you} against the nearby wall, {sub.yourHis} {sub.foot} brushing {dom.yourHis} shoulder. {sub.YourHis} "+getUsedBodypartName()+" {sub.youVerb('press', 'presses')} against {dom.yourHis} "+getDickName(RNG.pick(["dick", "penis", "cock"]))+throughClothing+".",
			])
	else:
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} and {sub.youVerb('rub')} {sub.yourHis} "+getUsedBodypartName()+" against {domyourHis} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+throughClothing+".",
		])
	return text
	
func getSwitchPoseTextForPose(thePose:String) -> String:
	var text:String = ""
	if(thePose == POSE_COWGIRL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} in cowgirl position, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_REVERSECOWGIRL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} in a reverse cowgirl position, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_COWGIRLAMAZON):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} in a half-amazon cowgirl position, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_COWGIRLALT):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} and {sub.youVerb('tilt')} {sub.yourHis} body back, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_LOTUS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you} in a lotus position, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_STANDRIDE):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} against a nearby wall with a vertical split, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	else:
		text = RNG.pick([
			"{sub.You} {sub.youVerb('straddle')} {dom.you}, {dom.your} "+getDickName(RNG.pick(["dick", "penis", "cock", "member"]))+" is still inside {sub.yourHis} "+getUsedBodypartName()+"!",
		])
	return text

func startActivity(_args):
	currentPose = RNG.pick(getAvaiablePoses())
	
	var text:String = getStartTextForPose(currentPose)
	addText(text)
	react(aboutToRideReaction)

func onSwitchFrom(_otherActivity, _args):
	currentPose = RNG.pick(getAvaiablePoses())

func processExtra():
	if(!isMakingOut):
		return
	
	var hasPC:bool = (getSubID() == "pc" || getDomID() == "pc")
	var text:String = ("You " if hasPC else "They ")+RNG.pick([
		"are making out.",
		"are still in a deep kiss.",
		"are still kissing.",
	])
	
	if(RNG.chance(30)):
		text += RNG.pick([
			" A faint moan escapes {sub.yourHis} throat.",
			" {dom.YourHis} teeth graze {sub.yourHis} lower lip, drawing a soft gasp.",
			" Tongues are exchanging saliva.",
			" Tongues are dancing and swirling against each other.",
			" Soft gasps and moans escape from both.",
		])
	
	if(OPTIONS.isContentEnabled(ContentType.CumStealing)):
		if(RNG.chance(20) && getDom().bodypartShareFluidsWith(BodypartSlot.Head, getSubID(), BodypartSlot.Head, 0.2)):
			text += RNG.pick([
				" {dom.You} and {sub.you} [b]share some cum[/b] while "+RNG.pick(["making out", "kissing", "kissing deeply"])+"!",
				" [b]Some cum gets shared[/b] between the two "+RNG.pick(["mouths", "tongues", "lovers"])+"!",
				" [b]Snowballing is happening, some cum gets shared around[/b].",
			])
	sendSexEvent(SexEvent.Kissing, SUB_0, DOM_0, {})
	
	addText(text)

func processTurn():

	if(isMakingOut && currentPose != POSE_LOTUS):
		isMakingOut = false
	
	if(getState() == "knotting" || getState() == "inside"):
		cockWarmer(SUB_0, DOM_0, usedBodypart, getState() == "knotting")
		processExtra()
		return
	
func fucking_processTurn():
	stimulateSexRide(SUB_0, DOM_0, usedBodypart, I_NORMAL)
#	affectSub(getSubInfo().fetishScore({fetishGiving: 1.0})+0.5, 0.1 * subSensetivity(), -0.1, -0.01)
#	affectDom(getDomInfo().fetishScore({fetishReceiving: 1.0})+0.3, 0.1, 0.0)
#	getSubInfo().stimulateArousalZone(0.2, BodypartSlot.Penis, 1.0)
#	getDomInfo().stimulateArousalZone(0.2, usedBodypart, 1.0)
	
	doProcessRide(SUB_0, DOM_0, usedBodypart)
	
	doProcessRideExtra(SUB_0, DOM_0, usedBodypart)

	processExtra()


func getActions(_indx:int):
	if(_indx == DOM_0):
		if(currentPose == POSE_LOTUS):
			if(!isMakingOut && !getDom().isMuzzled() && !getSub().isMuzzled()):
				var makeoutScore:float = getDomInfo().personalityScore({PersonalityStat.Mean:-0.1})
				addAction("makeout", makeoutScore, "Start kissing", "Start making out at the same time since this sex pose allows it")
			if(isMakingOut):
				addAction("stopmakeout", 0.01, "Stop kissing", "Enough sharing fluids!")
		
		if(state == "" || state == "inside"):
			addAction("rub", 1.0 - getStopScore(), "Rub", "Rub your "+getDickName()+" against their "+RNG.pick(usedBodypartNames), {A_PRIORITY: 4})
		if(state == ""):
			if(getSub().getFirstItemThatCoversBodypart(usedBodypart) == null && getDom().getFirstItemThatCoversBodypart(BodypartSlot.Penis) == null && getDomInfo().isReadyToPenetrate()):
				addAction("envelop", 1.0, "Penetrate", "Try to push them onto your "+getDickName(), {A_PRIORITY: 5})
					
			if(getSubInfo().getChar().hasBodypart(otherHoleBodypart) && !getSexEngine().hasTag(getSubID(), otherHoleTag)):
				var switchholeScore:float = 5.0 * (-getDomInfo().goalsScore(getGoals(), getSubID()) + getDomInfo().goalsScore({otherGoal: 1.0}, getSubID()))
				addAction("switchhole", switchholeScore, "Switch hole", "Switch to the sub's "+RNG.pick(otherHoleNames))
		if(state in ["fucking", "inside"]):
			addEggStuffButton(DOM_0, SUB_0, usedBodypart)
				
		if(state in ["fucking"]):
			if(isStraponSex() && getDom().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)):
				var subArousal:float = getSubInfo().getArousal()
				var straponForceKnotScore:float = 0.05
				if(subArousal > 0.8 || getSubInfo().isUnconscious()):
					straponForceKnotScore = 0.5
				addAction("straponForceKnot", straponForceKnotScore, "Force knot in", "Try to force the knot in!", {A_PRIORITY: 3})
			if(isReadyToCumHandled(DOM_0) && isStraponSex()):
				addAction("domstraponcum", 1.0, "Cum!", "You're about to cum!", {A_PRIORITY: 1001})
			if(isReadyToCumHandled(DOM_0) && !isStraponSex()):
				
				var hasKnot:bool = getDom().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)
				if(hasKnot):
					addAction("knotinside", 1.0, "Knot them", "Try to knot their "+RNG.pick(usedBodypartNames), {A_PRIORITY: 1001})
					
				addAction("cuminside", 1.0, "Cum inside", "Cum inside their "+RNG.pick(usedBodypartNames), {A_PRIORITY: 1001})
				addAction("cumpullout", 1.0, "Pull out (self)", "Cum on yourself", {A_PRIORITY: 1001})
				addAction("cumpulloutsub", 1.0, "Pull out (sub)", "Cum on them", {A_PRIORITY: 1001})
			elif(isReadyToCumHandled(SUB_0)):
				addAction("subcumDom", 1.0, "Sub's orgasm", "They are about to cum!", {A_PRIORITY: 1001})

#			var moanScore:float = max(0.1, getDomInfo().fetishScore({fetishReceiving: 1.0}) + getDomInfo().personalityScore({PersonalityStat.Subby: 1.0}))
#			addAction("moan", moanScore, "Moan", "Show how much you like it", {A_PRIORITY: 4})
#
#			addAction("slowdown", getPauseSexScore(DOM_0, SUB_0, S_PENIS, usedBodypart), "Slow down", "Stop fucking for a second..")
#
#			if(isStraponSex() && getSub().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)):
#				var domArousal:float = getDomInfo().getArousal()
#				var straponForceKnotScore:float = 0.01
#				if(domArousal > 0.8):
#					straponForceKnotScore = 0.5
#				addAction("straponForceKnot", straponForceKnotScore, "Force knot in", "Try to force their knot inside you!", {A_PRIORITY: 3})
#
#		if(getState() in ["subabouttocum"] || (getState() == "fucking" && getSubInfo().isReadyToCum() && !getSubInfo().canDoActions())):
#			var scoreToCumInside:float = 1.0
#			var scoreToPullOut:float = 1.0
#
#			if(getSexEngine().domNoPullingOut):
#				scoreToPullOut = 0.0
#
#			var hasKnot:bool = getSub().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)
#			if(hasKnot):
#				scoreToCumInside *= 0.5
#
#				addAction("letsubknotinside", scoreToCumInside, "Knot!", "Try to force the knot into your "+RNG.pick(usedBodypartNames), {A_PRIORITY: 1001})
#
#			addAction("letsubcuminside", scoreToCumInside, "Cum inside", "Let the sub cum inside you", {A_PRIORITY: 1001})
#			addAction("makesubcumoutside", scoreToPullOut, "Pull out", "Stop riding the sub", {A_PRIORITY: 1001})
		
		if(!(state in ["knotting"])):
			addAction("stop", getStopScore(), "Stop fucking", "Stop the sex activity")
		if(state in ["knotting"]):
			addAction("pullknotout", 1.0, "Pull out", "Try to yank your knot out")
		for pose in getAvaiablePoses():
			if(pose == currentPose):
				continue
			var poseName = "error"
			if(PoseToName.has(pose)):
				poseName = PoseToName[pose]
			addAction("switchpose", 0.0, poseName, "Change pose", {A_CATEGORY: ["Switch pose"], A_ARGS: [pose]})
		
		if(state == "inside"):
			if(getSub().getFirstItemThatCoversBodypart(usedBodypart) == null && getDom().getFirstItemThatCoversBodypart(BodypartSlot.Penis) == null):
				addAction("ridemore", getContinueSexScore(DOM_0, SUB_0, S_PENIS, usedBodypart)-getStopScore(), "Keep fucking", "Let them continue riding your "+getDickName("cock")+".")
			
			
#	if(_indx == SUB_0):
#		if(state in [""]):
#			addAction("rubSub", getSubInfo().getComplyScore()/2.0, "Tease", "Rub your dick against their "+RNG.pick(usedBodypartNames), {A_PRIORITY: 4})
#
#		if(state in ["fucking"]):
#			if(isReadyToCumHandled(SUB_0) && isStraponSex()):
#				addAction("subcumstrapon", 1.0, "Cum!", "You're about to cum", {A_PRIORITY: 1001})
#
#			if(isReadyToCumHandled(SUB_0) && !isStraponSex()):
#				addAction("warndom", 1.0, "Warn them", "Let them know that you're about to cum", {A_PRIORITY: 1001})
#				var cuminsideScore:float = getResistScore(SUB_0) + fetish(SUB_0, Fetish.Breeding)*0.5
#				addAction("cuminside", cuminsideScore, "Cum inside", "Cum inside their "+RNG.pick(usedBodypartNames), {A_PRIORITY: 1001})
#			var moanSubScore:float = max(0.1, getSubInfo().fetishScore({fetishGiving: 0.5}) + getSubInfo().personalityScore({PersonalityStat.Subby: 0.5}))
#			addAction("moanSub", moanSubScore, "Moan", "Show how much you like it", {A_PRIORITY: 2})
#
#		if(state in ["fucking", "", "inside"]):
#			addAction("throwoff", getResistScore(SUB_0), "Throw them off", "Resist their attempts to ride you", {A_CHANCE: getSubResistChance(30.0, 25.0)})

func doAction(_indx:int, _id:String, _action:Dictionary):
	if(_id == "stuffegg"):
		doReceiveEggFrom(SUB_0, DOM_0, usedBodypart)
	if(_id == "straponForceKnot"):
		# Need a tryKnot func?
		#if(tryPenetrate())
		stimulateSexRide(SUB_0, DOM_0, usedBodypart, I_NORMAL, SPEED_SLOW)
		#var subArousal:float = getSubInfo().getArousal()
		if(RNG.chance(getSub().getKnottingChanceBy(usedBodypart, getDomID()) * 0.25)):
			getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.2)
			addTextTopBottom(RNG.pick([
				#"{dom.You} {dom.youVerb('manage')} to knot {sub.you}!",
				"{<BOTTOM>.You} {<BOTTOM>.youVerb('ride')} {<TOP>.your} {<TOP>.penisShort} hard until {<TOP>.yourHis} knot suddenly slips inside, stretching {<BOTTOM>.yourHis} "+getNameHole(DOM_0, usedBodypart)+" wide!",
			]), DOM_0, SUB_0)
			state = "knotting"
			cumInside(DOM_0, SUB_0, usedBodypart)
			#satisfyGoals()
		else:
			getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.1)
			addTextPick([
				"{dom.You} {dom.youVerb('try', 'tries')} to shove the knot inside!",
				"{dom.You} {dom.youVerb('try', 'tries')} to stretch {sub.yourHis} "+getNameHole(SUB_0, usedBodypart)+" enough to slip the knot inside!",
				"{dom.You} {dom.youVerb('try', 'tries')} to knot {sub.you}!",
			])
		return
	if(_id == "makeout"):
		isMakingOut = true
		if(!getSubInfo().isResistingSlightly()):
			addText("{dom.You} {dom.youVerb('lean')} in closer, {dom.yourHis} lips locking with {sub.yourHis} in a deep, heated kiss. Kiss that keeps going. {sub.YouHe} {sub.youHeVerb('respond')}, opening {sub.yourHis} mouth to meet {dom.yourHis} tongue.")
		else:
			addText("{dom.You} {dom.youVerb('lean')} in closer and {dom.youVerb('force')} a deep kiss despite {sub.your} muffled protests. {dom.YourHis} tongue pushes into that mouth, claiming it as {sub.youHe} {sub.youHeVerb('squirm')} beneath.")
		return
	if(_id == "stopmakeout"):
		isMakingOut = false
		addText("{dom.You} {dom.youVerb('decide')} to stop making out.")
		return
	if(_id == "switchpose"):
		#switchedPoseOnce = true
		var newPose:String = _action["args"][0]
		var isInside:bool = true
		if(state in [""]):
			isInside = false
		
		if(isInside):
			addText(getSwitchPoseTextForPose(newPose))
		else:
			addText(getStartTextForPose(newPose))
		currentPose = newPose
		return
	if(_id == "switchhole"):
		switchCurrentActivityTo(switchHoleActivity)
		addText("{sub.You} {sub.youVerb('switch', 'switches')} holes, now rubbing {sub.yourHis} "+RNG.pick(otherHoleNames)+" against {dom.yourHis} "+getDickName()+".")
		return
	if(_id == "stop"):
		endActivity()
		addText("{dom.You} {dom.youVerb('pull')} {sub.youHim} away from {sub.your} "+getDickName()+" and {dom.youVerb('get')} up.")
		return
	if(_id == "domcum"):
		getDom().cumOnFloor()
		getDomInfo().cum()
		var straponText:String = ""
		if(isStraponSex()):
			satisfyGoals()
			var strapon = getDom().getWornStrapon()
			if(strapon.getFluids() != null && !strapon.getFluids().isEmpty()):
				getDom().cummedInBodypartByAdvanced(usedBodypart, getSubID())
				straponText = "{dom.Your} strapon gets squeezed by {sub.your} "+RNG.pick(usedBodypartNames)+" enough for it to suddenly [b]release its contents inside {sub.youHim}[/b]!"
		getSubInfo().stimulateArousalZone(0.2, BodypartSlot.Penis, 1.0)
		addGenericOrgasmText(DOM_0)
		if(straponText != ""):
			addText(straponText)
		return
	if(_id in ["cuminside", "knotinside"]):
		var wombText:String = RNG.pick([
			"womb", "womb",
			"babymaker",
		])
		if(usedBodypart == BodypartSlot.Anus):
			wombText = RNG.pick([
				"ass",
				"butt",
			])
		var text:String = ""

		var condomBroke:bool = false
		var knotSuccess:bool = false
		#var isTryingToKnot = false
		if(_id == "knotinside"):
			#isTryingToKnot = true
			getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.5)
			if(RNG.chance(getSub().getKnottingChanceBy(usedBodypart, getDomID()))):
				knotSuccess = true
			else:
				text += RNG.pick([
					"{dom.You} {dom.youVerb('try', 'tries')} to force {dom.your} knot inside {sub.youHim} but {sub.yourHis} hole is just too tight. ",
					"{sub.YouHe} {dom.youVerb('try', 'tries')} to force {dom.your} knot inside {sub.yourself} but {sub.yourHis} hole is just too tight. "
				])

		if(knotSuccess):
			text += RNG.pick([
				"{dom.You} pull {sub.youHim} down onto {dom.your} "+RNG.pick(["cock", "dick", "member"])+" hard until {dom.your} knot suddenly slips inside! [b]{dom.You} {dom.youVerb('moan')} as {dom.you} {dom.youHeVerb('cum')} inside {sub.yourHis} "+RNG.pick(usedBodypartNames)+"[/b]!",
			])
		else:
			text += RNG.pick([
				"{sub.YouHe} just {sub.youVerb('keep')} riding {dom.your} "+RNG.pick(["cock", "dick", "member"])+" until [b]{dom.youHe} {dom.youHeVerb('cum')} inside {sub.yourHis} "+RNG.pick(usedBodypartNames)+"[/b]!",
			])
		text += RNG.pick([
			" Waves after waves of sticky "+RNG.pick(["cum", "seed", "jizz", "semen"])+" flow into {sub.yourHis} "+wombText+".",
		])

		var condom:ItemBase = getDom().getWornCondom()
		if(condom != null):
			var breakChance = condom.getCondomBreakChance()
			condomBroke = getDom().shouldCondomBreakWhenFucking(getDom(), breakChance)
			if(condomBroke):
				text = "[b]The condom broke![/b] "+text
				condom.destroyMe()
				fetishUp(SUB_0, Fetish.Condoms, -15.0)
				fetishUp(DOM_0, Fetish.Condoms, -20.0)
			else:
				fetishAffect(SUB_0, Fetish.Condoms, 3.0)
				fetishAffect(DOM_0, Fetish.Condoms, 3.0)
				if(knotSuccess):
					text = RNG.pick([
						"{dom.You} pull {sub.youHim} down onto {dom.your} "+RNG.pick(["cock", "dick", "member"])+" hard until {dom.your} knot suddenly slips inside!",
					])
				else:
					text = RNG.pick([
						"{sub.YouHe} just {sub.youVerb('keep')} riding {dom.your} "+RNG.pick(["cock", "dick", "member"])+".",
					])
				text += RNG.pick([
					" {dom.You} {dom.youVerb('moan')} as {dom.you} {dom.youVerb('fill')} the condom inside {sub.youHis} "+RNG.pick(usedBodypartNames)+"!",
					" {dom.You} {dom.youVerb('moan')} as {dom.you} {dom.youVerb('stuff')} the condom in {sub.youHis} "+RNG.pick(usedBodypartNames)+" full of {sub.yourHis} "+RNG.pick(["cum", "seed", "jizz", "semen"])+"!",
				])
				var loadSize = getDom().cumInItem(condom)
				getDomInfo().cum()
				getSubInfo().addArousalSex(0.02)
				sendSexEvent(SexEvent.FilledCondomInside, DOM_0, SUB_0, {hole=usedBodypart,loadSize=loadSize,knotted=knotSuccess,engulfed=true})
				satisfyGoals()
				if(knotSuccess):
					state = "knotting"
				else:
					state = "inside"

				addText(text)
				return

		getSub().cummedInBodypartByAdvanced(usedBodypart, getDomID(), {knotted=knotSuccess,condomBroke=condomBroke,engulfed=true})
		getDomInfo().cum()

		satisfyGoals()
		if(knotSuccess):
			state = "knotting"
			getDomInfo().addArousalSex(0.05)
		else:
			state = "inside"
			getDomInfo().addArousalSex(0.02)

		addText(text)
		return
	if(_id == "subcumDom"):
		var straponText:String = ""
		if(isStraponSex()):
			satisfyGoals()
			
			var strapon = getDom().getWornStrapon()
			if(strapon.getFluids() != null && !strapon.getFluids().isEmpty()):
				getSub().cummedInBodypartByAdvanced(usedBodypart, getDomID())
				straponText="{dom.Your} strapon gets squeezed by {sub.your} "+RNG.pick(usedBodypartNames)+" enough for it to suddenly [b]release its contents inside {sub.youHim}[/b]!"
			
		getSub().cumOnFloor(getDomID())
		getSubInfo().cum()
		addGenericOrgasmText(SUB_0)
		if(straponText != ""):
			addText(straponText)
		return
	if(_id == "cumpullout"):
		var text:String = RNG.pick([
			"{sub.You} {sub.youVerb('ride')} {sub.yourHis} "+RNG.pick(["dick", "cock", "member"])+" until {dom.youHe} {dom.youAreHeIs} ready to cum. But {dom.you} {dom.youVerb('make')} {sub.youHim} pull off just in time!",
		])
		state = ""

		var condom:ItemBase = getDom().getWornCondom()
		if(condom != null):
			var breakChance = condom.getCondomBreakChance()

			if(RNG.chance(breakChance)):
				text = "[b]The condom broke![/b] "+text
				condom.destroyMe()
				fetishUp(SUB_0, Fetish.Condoms, -15.0)
				fetishUp(DOM_0, Fetish.Condoms, -20.0)
			else:
				fetishAffect(SUB_0, Fetish.Condoms, 3.0)
				fetishAffect(DOM_0, Fetish.Condoms, 3.0)
				text += RNG.pick([
					" {dom.You} "+RNG.pick(["{dom.youVerb('fill')}", "{dom.youVerb('stuff')}"])+" {dom.yourHis} condom!",
				])
				getDom().cumInItem(condom)
				getDomInfo().cum()
				satisfyGoals()

				addText(text)
				return

		text += RNG.pick([
			" {dom.You} [b]{dom.youVerb('cum')} all over {dom.yourself}[/b]! Strings of {dom.yourHis} own "+RNG.pick(["cum", "seed", "semen"])+" land on {dom.yourHis} chest, leaving a mess.",
		])

		getDom().cummedOnBy(getDomID(), FluidSource.Penis)
		getDomInfo().cum()
		satisfyGoals()

		addText(text)
		return
	if(_id == "cumpulloutsub"):
		cumOnto(DOM_0, SUB_0, {sex=true})
		satisfyGoals()
		state = ""
		applyTallymarkIfNeeded(usedBodypart)
		return
	if(_id == "pullknotout"):
		if(RNG.chance(30)):
			state = ""
			var text = RNG.pick([
				"{sub.You} {sub.youVerb('manage')} to raise {sub.yourself}. The knot "+RNG.pick(["falls out", "gets pulled out"])+" with a satisfying plop noise.",
			])
			
			if((getSub().hasEffect(StatusEffect.HasCumInsideVagina) && usedBodypart == BodypartSlot.Vagina) || (getSub().hasEffect(StatusEffect.HasCumInsideAnus) && usedBodypart == BodypartSlot.Anus)):
				if((getSub().getBuffsHolder().hasBuff(Buff.BlocksVaginaLeakingBuff) && usedBodypart == BodypartSlot.Vagina) || (getSub().getBuffsHolder().hasBuff(Buff.BlocksAnusLeakingBuff) && usedBodypart == BodypartSlot.Anus)):
					text += RNG.pick([
						" Some "+RNG.pick(["cum", "seed", "semen"])+" tries to leak out but {sub.you} quickly {sub.youVerb('plug')} {sub.yourHis} "+RNG.pick(usedBodypartNames)+" back.",
					])
				else:	
					text += RNG.pick([
						" Some "+RNG.pick(["cum", "seed", "semen"])+" leaks out of {sub.yourHis} used "+RNG.pick(usedBodypartNames)+".",
					])
			stimulateSexRide(SUB_0, DOM_0, usedBodypart, I_NORMAL, SPEED_VERYSLOW)
			addText(text)
			return
		else:
			var text = RNG.pick([
				"{sub.You} {sub.youVerb('try', 'tries')} to "+RNG.pick(["pull", "yank"])+" {dom.yourHis} "+RNG.pick(["cock", "dick"])+" out but {sub.youVerb('fail')}. The knot inside {sub.youHim} slowly deflates.",
			])
			getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.1)
			affectSub(getSubInfo().fetishScore({fetishGiving: 1.0}), 0.1, -0.3, 0.0)
			affectDom(getDomInfo().fetishScore({fetishReceiving: 1.0}), 0.1, -0.05)
			getSubInfo().addArousalForeplay(0.1)
			getDomInfo().addArousalForeplay(0.1)
			addText(text)
			return
	if(_id == "rub"):
		stimulateSexRide(SUB_0, DOM_0, usedBodypart, I_TEASE)
		#affectSub(getSubInfo().fetishScore({fetishGiving: 1.0}), 0.1 * subSensetivity(), 0.0, 0.0)
		#affectDom(getDomInfo().fetishScore({fetishReceiving: 1.0}), 0.1, -0.01)
		#getSubInfo().addArousalForeplay(0.05 * subSensetivity())
		#getDomInfo().addArousalForeplay(0.05)
		
		addText("{dom.You} {dom.youVerb('rub')} {dom.yourHis} "+getDickName()+" against {sub.yourHis} "+RNG.pick(usedBodypartNames)+".")
		return
	if(_id == "envelop"):
		if(!RNG.chance(getSub().getPenetrateChanceBy(usedBodypart, getDomID()))):
			getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.1)
			#affectSub(getSubInfo().fetishScore({fetishGiving: 1.0}), 0.1 * subSensetivity(), 0.0, 0.0)
			#affectDom(getDomInfo().fetishScore({fetishReceiving: 1.0}), 0.2, -0.01)
			stimulateSexRide(SUB_0, DOM_0, usedBodypart, I_TEASE)
			addText("{dom.You} {dom.youVerb('try', 'tries')} to pull {sub.youHim} onto {dom.yourHis} "+getDickName()+" but it's too big!")
			return
		
		sendSexEvent(SexEvent.HolePenetrated, DOM_0, SUB_0, {hole=usedBodypart,engulfed=true,strapon=isStraponSex()})
		#affectSub(getSubInfo().fetishScore({fetishGiving: 1.0}), 0.1 * subSensetivity(), 0.0, 0.0)
		#affectDom(getDomInfo().fetishScore({fetishReceiving: 1.0}), 0.1, -0.01)
		#getSubInfo().stimulateArousalZone(0.1, BodypartSlot.Penis, 0.5)
		#getDomInfo().stimulateArousalZone(0.1, usedBodypart, 0.5)
		stimulateSexRide(SUB_0, DOM_0, usedBodypart, I_LOW)
		
		#getSub().gotFuckedBy(usedBodypart, getDomID())
		getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.2)
		#gonnaCumOutside = false
		state = "fucking"
		addText("{dom.You} pull {sub.youHim} onto {dom.yourHis} "+getDickName()+", watching it penetrate {sub.yourHis} "+RNG.pick(usedBodypartNames)+".")
		return
	if(_id == "slowdown"):
		state = "inside"
		addText("{sub.You} {sub.youVerb('stop')} riding {dom.your} "+getDickName()+" and just {sub.youVerb('let')} it stay inside.")
		return
	if(_id == "moan"):
		var moanText:String = RNG.pick([
			"{dom.youVerb('moan')}"
		])
		if(getDom().isGagged()):
			moanText = RNG.pick([
				"{dom.youVerb('let')} out muffled moans",
			])
		addTextPick([
			"{dom.You} "+moanText+" while being ridden!",
			"{dom.You} "+moanText+" while {sub.you} rides {dom.you} with {sub.yourHis} "+RNG.pick(usedBodypartNames)+"!",
			"{dom.You} "+moanText+" eagerly!",
		])
		moan(DOM_0)
		#affectSub(getSubInfo().fetishScore({fetishGiving: 1.0}), 0.03 * subSensetivity(), -0.01, -0.0)
		#affectDom(getDomInfo().fetishScore({fetishReceiving: 1.0}), 0.05, -0.03)
		return
	if(_id == "ridemore"):
		getSub().gotOrificeStretchedBy(usedBodypart, getDomID(), true, 0.2)
		#gonnaCumOutside = false
		state = "fucking"
		addText("{sub.You} {sub.youVerb('continue')} to ride {dom.youHis} "+getDickName()+" with {sub.yourHis} "+RNG.pick(usedBodypartNames)+".")
		return

#	if(_id == "subcumstrapon"):
#		getSub().cumOnFloor(getDomID())
#		getSubInfo().cum()
#		addGenericOrgasmText(SUB_0)
#		return
	if(_id == "moanSub"):
		var moanText:String = RNG.pick([
			"{sub.youVerb('moan')}"
		])
		if(getSub().isGagged()):
			moanText = RNG.pick([
				"{sub.youVerb('let')} out muffled moans",
				"{sub.youVerb('let')} out a muffled moan",
				"{sub.youVerb('let')} out a muffled noise of pleasure",
			])
		
		addTextPick([
			"{sub.You} "+moanText+" while {dom.you} {dom.youVerb('ride')} {sub.youHim}!",
			"{sub.You} "+moanText+" while {sub.yourHis} "+getDickName()+" is used by {dom.you}!",
			"{sub.You} "+moanText+" eagerly!",
		])
		moan(SUB_0)
		return
	if(_id == "throwoff"):
		if(RNG.chance(getSubResistChance(30.0, 25.0))):
			if(state != ""):
				state = ""
				isMakingOut = false
			else:
				endActivity()
			
			addText("{sub.You} {sub.youVerb('manage')} to throw {dom.youHim} away from {sub.yourHis} "+getDickName()+".")
			reactSub(SexReaction.ActivelyResisting, [50])
			getDomInfo().addAnger(0.3)
			return
		else:
			addText("{sub.You} {sub.youVerb('try', 'tries')} to resist and "+RNG.pick(["shove", "push", "throw"])+" {dom.you} off but {sub.youVerb('fail')}.")
			getDomInfo().addAnger(0.1)
			reactSub(SexReaction.ActivelyResisting, [50])
			return
#	if(_id == "rubSub"):
#		stimulateSex(SUB_0, DOM_0, usedBodypart, I_TEASE)
		#affectSub(getSubInfo().fetishScore({fetishGiving: 1.0}), 0.05 * subSensetivity(), -0.1, 0.0)
		#affectDom(max(0.1, getDomInfo().fetishScore({fetishReceiving: 1.0})+1.0), 0.05, 0.0)
		
#		addText("{sub.You} {sub.youVerb('rub')} {sub.yourHis} "+getDickName()+" against {dom.your} "+RNG.pick(usedBodypartNames)+".")
#		return
	if(_id == "warndom"):
		state = "subabouttocum"
		getDomInfo().addAnger(-0.05)
		addText("{sub.You} {sub.youVerb('warn')} {dom.youHim} that {sub.youHe} {sub.youAreHeIs} "+RNG.pick(["about to cum", "close", "very close"])+".")
		reactSub(SexReaction.WarnAboutToCum)
		return
#	if(_id == "cuminside"):
#		var text:String = RNG.pick([
#			"{sub.You} {sub.youVerb('grunt')} as {sub.yourHis} "+RNG.pick(["cock", "dick", "member"])+" throbs and [b]"+RNG.pick(["cums inside {dom.yourHis} "+RNG.pick(usedBodypartNames), "stuffs {dom.yourHis} "+RNG.pick(usedBodypartNames)])+" without asking permission[/b]!",
#		])
#		if(usedBodypart == BodypartSlot.Vagina):
#			text += RNG.pick([
#				" Waves after waves of sticky "+RNG.pick(["cum", "seed", "jizz", "semen"])+" flow into {dom.yourHis} "+RNG.pick(["womb", "babymaker", "womb"])+".",
#			])
#		else:
#			text += RNG.pick([
#				" Waves after waves of sticky "+RNG.pick(["cum", "seed", "jizz", "semen"])+" get shoved into {dom.yourHis} "+RNG.pick(["ass", "butt"])+".",
#			])
#
#		var condomBroke = false
#		var condom:ItemBase = getSub().getWornCondom()
#		if(condom != null):
#			var breakChance = condom.getCondomBreakChance()
#			condomBroke = getSub().shouldCondomBreakWhenFucking(getDom(), breakChance)
#			if(condomBroke):
#				text = "[b]The condom broke![/b] "+text
#				condom.destroyMe()
#				fetishUp(SUB_0, Fetish.Condoms, -15.0)
#				fetishUp(DOM_0, Fetish.Condoms, -20.0)
#			else:
#				fetishAffect(SUB_0, Fetish.Condoms, 3.0)
#				fetishAffect(DOM_0, Fetish.Condoms, 3.0)
#				text = RNG.pick([
#					"{sub.You} {sub.youVerb('fill')} the condom inside {dom.your} "+RNG.pick(usedBodypartNames)+" [b]without asking for permission[/b]!",
#					"{sub.You} {sub.youVerb('stuff')} the condom in {dom.your} "+RNG.pick(usedBodypartNames)+" full of {sub.yourHis} "+RNG.pick(["cum", "seed", "jizz", "semen"])+" [b]without asking for permission[/b]!",
#				])
#				var loadSize = getSub().cumInItem(condom)
#				getSubInfo().cum()
#				getDomInfo().addArousalSex(0.02)
#				sendSexEvent(SexEvent.FilledCondomInside, SUB_0, DOM_0, {hole=usedBodypart,loadSize=loadSize,knotted=false})
#				satisfyGoals()
#				state = "inside"
#
#				addText(text)
#				return
#
#		var beingBredScore = getDomInfo().fetishScore({Fetish.BeingBred: 1.0})
#		if(beingBredScore < 0.0):
#			getDomInfo().addAnger(1.0)
#			text += RNG.pick([
#				" {dom.You} {dom.youAre} furious!",
#			])
#			getDomInfo().addFrustration(1.0)
#		else:
#			getDomInfo().addAnger(0.3)
#		getSub().cummedInBodypartByAdvanced(usedBodypart, getDomID(), {condomBroke=condomBroke})
#		getDomInfo().cum()
#		getSubInfo().addArousalSex(0.02)
#		satisfyGoals()
#		state = "inside"
#
#		addText(text)
#		return

func getSubResistChance(baseChance:float, domAngerRemoval:float) -> float:
	var theChance = baseChance - getDomInfo().getAngerScore()*domAngerRemoval
	if(getSub().hasBlockedHands()):
		theChance *= 0.6
	if(getSub().hasBoundArms()):
		theChance *= 0.6
	if(getSub().hasBoundLegs()):
		theChance *= 0.5
	if(getSub().isBlindfolded()):
		theChance *= 0.8
	if(getSexType() == SexType.SlutwallSex):
		theChance *= 0.5
	
	return max(theChance, 5.0)

func getAnimation():
	var shouldUncon = getSubInfo().isUnconscious()
#
#	if(getSexType() == SexType.BitchsuitSex):
#		if(state in [""]):
#			return [StageScene.PuppySexCowgirl, "tease", {npc=SUB_0, pc=DOM_0}]
#		if(state in ["knotting", "inside"]):
#			return [StageScene.PuppySexCowgirl, "inside", {npc=SUB_0, pc=DOM_0, bodyState={hard=true}}]
#		if(getSubInfo().isCloseToCumming() || (isStraponSex() && getDomInfo().isCloseToCumming())):
#			return [StageScene.PuppySexCowgirl, "fast", {npc=SUB_0, pc=DOM_0, bodyState={hard=true}}]
#		return [StageScene.PuppySexCowgirl, "sex", {npc=SUB_0, pc=DOM_0, bodyState={hard=true}}]
#
#	if(getSexType() == SexType.SlutwallSex):
#		if(state in [""]):
#			return [StageScene.SlutwallRide, "tease", {pc=SUB_0, npc=DOM_0}]
#		if(state in ["knotting", "inside"]):
#			return [StageScene.SlutwallRide, "inside", {pc=SUB_0, npc=DOM_0, bodyState={hard=true}}]
#		if(getSubInfo().isCloseToCumming() || (isStraponSex() && getDomInfo().isCloseToCumming())):
#			return [StageScene.SlutwallRide, "fast", {pc=SUB_0, npc=DOM_0, bodyState={hard=true}}]
#		return [StageScene.SlutwallRide, "sex", {pc=SUB_0, npc=DOM_0, bodyState={hard=true}}]
#
	var animToPlay = StageScene.SexCowgirl
	if(PoseToAnimName.has(currentPose)):
		animToPlay = PoseToAnimName[currentPose]
	var pcPoseID:int=DOM_0
	var npcPoseID:int=SUB_0
	var pcState:Dictionary = {hard=true}
	var npcState:Dictionary = {}
	if(currentPose == POSE_LOTUS):
		pcPoseID = SUB_0
		npcPoseID = DOM_0
		pcState = {hard=true}
		npcState = {}
	
	if(state in [""]):
		return [animToPlay, "tease", {pc=pcPoseID, npc=npcPoseID, uncon=shouldUncon}]
	if(state in ["knotting", "inside"]):
		return [animToPlay, "inside", {pc=pcPoseID, npc=npcPoseID, uncon=shouldUncon, bodyState=pcState, npcBodyState=npcState}]
	if(getSubInfo().isCloseToCumming() || (isStraponSex() && getDomInfo().isCloseToCumming())):
		if(currentPose == POSE_REVERSECOWGIRL):
			shouldUncon = false
		return [animToPlay, "fast", {pc=pcPoseID, npc=npcPoseID, uncon=shouldUncon, bodyState=pcState, npcBodyState=npcState}]
	return [animToPlay, "sex", {pc=pcPoseID, npc=npcPoseID, uncon=shouldUncon, bodyState=pcState, npcBodyState=npcState}]

func getDomSwitchHoleChance() -> float:
	if(getDomInfo().hasMemory("switchedHoles")):
		return 0.0
	
	var domLikesOtherHoleScore = getDomInfo().fetishScore({otherHoleFetishGiving:1.0, fetishGiving: -0.5})
	
	return max(5.0, domLikesOtherHoleScore * 100.0 * (1.0 - getDomInfo().getAngerScore()))

func getOrgasmHandlePriority(_indx:int) -> int:
	if(_indx == DOM_0):
		if(isStraponSex()):
			return 10
		return 5
	if(_indx == SUB_0):
		if(isStraponSex()):
			return 5
		return 10
	return -1

func getJoinActions(_sexInfo:SexInfoBase):
	if(!(_sexInfo is SexDomInfo)):
		return
	#var theChar:BaseCharacter = _sexInfo.getChar()
	
	if(canSwitchTo("ThreeDDS_Train", [_sexInfo, DOM_0], [SUB_0], [S_VAGINA, usedBodypart])):
		addJoinAction(["trainVag"], "+Train (vag)", "Join and fuck the sub's pussy at the same time!", getJoinActivityScore("ThreeDDS_Train", DOM_0, _sexInfo, getSubInfo(), [S_VAGINA]), {A_CATEGORY: ["Fuck"]})
	if(canSwitchTo("ThreeDDS_Train", [_sexInfo, DOM_0], [SUB_0], [S_ANUS, usedBodypart])):
		addJoinAction(["trainAnal"], "+Train (anal)", "Join and fuck the sub's ass at the same time!", getJoinActivityScore("ThreeDDS_Train", DOM_0, _sexInfo, getSubInfo(), [S_ANUS]), {A_CATEGORY: ["Fuck"]})
		
	if(canSwitchTo("ThreeDDS_RideGrind", [DOM_0, _sexInfo], [SUB_0], [usedBodypart])):
		addJoinAction(["rideAndGrind"], "+Grind face", "Join and grind the sub's face at the same time!", getJoinActivityScore("ThreeDDS_RideGrind", DOM_1, _sexInfo, getSubInfo()), {A_CATEGORY: ["Fuck"]})
		
		
func doJoinAction(_sexInfo:SexInfoBase, _args):
	if(_args[0] == "trainVag"):
		switchCurrentActivityTo("ThreeDDS_Train", [S_VAGINA, usedBodypart, _sexInfo.getCharID(), true])
	if(_args[0] == "trainAnal"):
		switchCurrentActivityTo("ThreeDDS_Train", [S_ANUS, usedBodypart, _sexInfo.getCharID(), true])
	
	if(_args[0] == "rideAndGrind"):
		switchCurrentActivityTo("ThreeDDS_RideGrind", [usedBodypart, _sexInfo.getCharID()])
	

func saveData():
	var data = .saveData()
	
	data["waitTimer"] = waitTimer
	data["currentPose"] = currentPose
	data["isMakingOut"] = isMakingOut

	return data
	
func loadData(data):
	.loadData(data)
	
	waitTimer = SAVE.loadVar(data, "waitTimer", 0)
	currentPose = SAVE.loadVar(data, "currentPose", "")
	isMakingOut = SAVE.loadVar(data, "isMakingOut", false)
	if(currentPose == ""):
		currentPose = RNG.pick(getAvaiablePoses())
