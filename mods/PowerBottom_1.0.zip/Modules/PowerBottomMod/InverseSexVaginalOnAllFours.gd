extends "res://Game/SexEngine/SexActivityBase.gd"
var times:int = 0
var gonnaCumOutside:bool = false

var usedBodypart:String = BodypartSlot.Vagina
var usedTag:int = SexActivityTag.VaginaUsed
var usedTagInside:int = SexActivityTag.VaginaPenetrated
var fetishGiving:String = Fetish.VaginalSexReceiving
var fetishReceiving:String = Fetish.VaginalSexGiving
var usedBodypartNames:Array = ["pussy", "pussy", "slit", "cunt", "kitty"]
var switchHoleActivity:String = "InverseSexAnalOnAllFours"
var otherHoleNames:Array = ["anus"]
var otherHoleBodypart:String = BodypartSlot.Anus
var otherHoleTag:int = SexActivityTag.AnusUsed
var otherHoleFetishGiving:String = Fetish.AnalSexReceiving
var otherHoleFetishReceiving:String = Fetish.AnalSexGiving
var otherGoal:String = SexGoal.FuckAnal
var aboutToPenetrateReaction:int = SexReaction.AboutToPenetratePussy
var sexReactionPullOut:int = SexReaction.BeggingToPullOutVaginal
var currentPose:String = ""
var switchedPoseOnce:bool = false
var isVag:bool = true
var straponTimer:int = 0

func _init():
	id = "InverseSexVaginalOnAllFours"
	activityName = "Receive Vaginal"
	activityDesc = "Make them fuck your pussy!"
	activityCategory = ["Fuck"]

func getGoals():
	if(currentPose == POSE_CHOKEFUCK):
		return {
			SexGoal.ChokeSexVaginal: 1.0,
			SexGoal.FuckVaginal: 1.0,
			SexGoal.StraponVaginal: 1.0,
		}
	
	return {
		SexGoal.FuckVaginal: 1.0,
		SexGoal.StraponVaginal: 1.0,
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: false,
		SexType.SlutwallSex: false,
		SexType.BitchsuitSex: false,
	}

func isStocksSex() -> bool:
	return getSexType() == SexType.StocksSex

func getPoseDescriptor() -> String:
	if(getSexType() == SexType.StocksSex):
		return " in stocks"
	if(getSexType() == SexType.SlutwallSex):
		return " in the slutwall"
	if(getSexType() == SexType.BitchsuitSex):
		return " on all fours"
	if(currentPose == POSE_ALLFOURS):
		return " on all fours"
	if(currentPose == POSE_FULLNELSON):
		return " in a full nelson pose"
	if(currentPose == POSE_MISSONARY):
		return " in a missionary pose"
	if(currentPose == POSE_STANDING):
		return " standing"
	if(currentPose == POSE_CHOKEFUCK):
		return " while also choking"
	if(currentPose == POSE_BEHIND):
		return " in a behind pose"
	if(currentPose == POSE_MATINGPRESS):
		return " in a mating press"
	if(currentPose == POSE_LOWDOGGY):
		return " on all fours"
	if(currentPose == POSE_LEGRAISED):
		return " with one leg raised"
	if(currentPose == POSE_AGAINSTWALL):
		return " against a wall"
	if(currentPose == POSE_PINNEDWALL):
		return " pinned against a wall"
	if(currentPose == POSE_WALLPRESS):
		return " pinned against a wall"
	return " [color=red]FIX DESCRIPTOR[/color]"

const POSE_DEFAULT = "POSE_DEFAULT"
const POSE_ALLFOURS = "POSE_ALLFOURS"
const POSE_STANDING = "POSE_STANDING"
const POSE_MISSONARY = "POSE_MISSONARY"
const POSE_FULLNELSON = "POSE_FULLNELSON"
const POSE_CHOKEFUCK = "POSE_CHOKEFUCK"
const POSE_BEHIND = "POSE_BEHIND"
const POSE_MATINGPRESS = "POSE_MATINGPRESS"
const POSE_LOWDOGGY = "POSE_LOWDOGGY"
const POSE_LEGRAISED = "POSE_LEGRAISED"
const POSE_AGAINSTWALL = "POSE_AGAINSTWALL"
const POSE_PINNEDWALL = "POSE_PINNEDWALL"
const POSE_WALLPRESS = "POSE_WALLPRESS"


const PoseToName = {
	POSE_DEFAULT: "Default",
	POSE_ALLFOURS: "All Fours",
	POSE_STANDING: "Standing",
	POSE_MISSONARY: "Missonary",
	POSE_FULLNELSON: "Full Nelson",
	POSE_CHOKEFUCK: "Choke fuck",
	POSE_BEHIND: "Behind",
	POSE_MATINGPRESS: "Mating Press",
	POSE_LOWDOGGY: "Low Doggy",
	POSE_LEGRAISED: "Raised leg",
	POSE_AGAINSTWALL: "Against a wall",
	POSE_PINNEDWALL: "Pinned into wall",
	POSE_WALLPRESS: "Wall Press",
}
const PoseToAnimName = {
	POSE_DEFAULT: StageScene.SexAllFours,
	POSE_ALLFOURS: StageScene.SexAllFours,
	POSE_STANDING: StageScene.SexFreeStanding,
	POSE_MISSONARY: StageScene.SexMissionary,
	POSE_FULLNELSON: StageScene.SexFullNelson,
	POSE_CHOKEFUCK: StageScene.Choking,
	POSE_BEHIND: StageScene.SexBehind,
	POSE_MATINGPRESS: StageScene.SexMatingPress,
	POSE_LOWDOGGY: StageScene.SexLowDoggy,
	POSE_LEGRAISED: StageScene.SexPawLick,
	POSE_AGAINSTWALL: StageScene.SexStanding,
	POSE_PINNEDWALL: StageScene.SexPinnedBehind,
	POSE_WALLPRESS: StageScene.SexAgainstWall,
}
func getAvaiablePoses() -> Array:
	if(currentPose == POSE_CHOKEFUCK):
		return [POSE_CHOKEFUCK]
	
	if(getSexType() == SexType.DefaultSex):
		if(getDomInfo().isUnconscious()):
			var possible:= [POSE_ALLFOURS, POSE_MISSONARY, POSE_FULLNELSON, POSE_BEHIND, POSE_MATINGPRESS, POSE_LOWDOGGY]
		
			if(getSexEngine() != null && getSexEngine().hasWallsNearby()):
				possible.append(POSE_WALLPRESS)
		
			return possible
		else:
			var possible:= [POSE_ALLFOURS, POSE_STANDING, POSE_MISSONARY, POSE_FULLNELSON, POSE_BEHIND, POSE_MATINGPRESS, POSE_LEGRAISED, POSE_LOWDOGGY]
			
			if(getSexEngine() != null && getSexEngine().hasWallsNearby()):
				possible.append(POSE_AGAINSTWALL)
				possible.append(POSE_PINNEDWALL)
				possible.append(POSE_WALLPRESS)
			
			return possible
	
	return [POSE_DEFAULT]

func canStartActivity(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	if(!_subInfo.getChar().hasReachablePenis() && !_subInfo.getChar().isWearingStrapon()):
		return false
	if(usedBodypart == BodypartSlot.Vagina && !_domInfo.getChar().hasReachableVagina()):
		return false
	if(usedBodypart == BodypartSlot.Anus && !_domInfo.getChar().hasReachableAnus()):
		return false
	if(_domInfo.getCharID() != "pc"):
		return false
	return .canStartActivity(_sexEngine, _domInfo, _subInfo)

func isActivityImpossibleShouldStop() -> bool:
	if(!getSub().hasReachablePenis() && !getSub().isWearingStrapon()):
		return true
	if(usedBodypart == BodypartSlot.Vagina && !getDom().hasReachableVagina()):
		return true
	if(usedBodypart == BodypartSlot.Anus && !getDom().hasReachableAnus()):
		return true
		
	return false

func getTags(_indx:int) -> Array:
	if(_indx == SUB_0):
		if(state in ["fucking", "aftercumminginside", "knotting"]):
			return [SexActivityTag.PenisUsed, SexActivityTag.PenisInside, SexActivityTag.HavingSex]
		return [SexActivityTag.PenisUsed, SexActivityTag.HavingSex]
	if(_indx == DOM_0):
		var thetags:Array = [usedTag, SexActivityTag.PreventsSubViolence, SexActivityTag.PreventsSubTeasing, SexActivityTag.HavingSex]
		if(state in ["fucking", "aftercumminginside", "knotting"]):
			thetags.append(usedTagInside)
		return thetags
	return []

func getCheckTagsDom() -> Array:
	return [SexActivityTag.OrderedToDoSomething, SexActivityTag.PenisUsed, SexActivityTag.HavingSex]

func getCheckTagsSub() -> Array:
	return [SexActivityTag.OrderedToDoSomething, usedTag, SexActivityTag.HavingSex]

func isStraponSex() -> bool:
	return getSub().isWearingStrapon()

func getDickName(dickName = null) -> String:
	if(isStraponSex()):
		return "strapon"
	if(dickName == null):
		return RNG.pick(["cock", "dick", "member"])
	return dickName

func getUsedBodypartName() -> String:
	var theName = RNG.pick(usedBodypartNames)
	if(usedBodypart == BodypartSlot.Vagina):
		theName = "{dom.pussyStretch} "+theName
	if(usedBodypart == BodypartSlot.Anus):
		theName = "{dom.anusStretch} "+theName
	
	var _isNeedy:bool = getDom().getLustLevel() > 0.6
	var _isDry:bool = getDom().getLustLevel() < 0.1
	var _isLubedUp:bool = getDom().hasEffect(StatusEffect.LubedUp)
	var _hasCumInHole:bool = false
	if(usedBodypart == BodypartSlot.Vagina):
		_hasCumInHole = getDom().hasEffect(StatusEffect.HasCumInsideVagina)
	if(usedBodypart == BodypartSlot.Anus):
		_hasCumInHole = getDom().hasEffect(StatusEffect.HasCumInsideAnus)
	
	if(_hasCumInHole && RNG.chance(30)):
		theName = RNG.pick(["creamed", "stuffed"])+" "+theName
	elif(_isNeedy):
		if(usedBodypart == BodypartSlot.Vagina):
			theName = RNG.pick(["needy", "awaiting", "inviting"])+" "+theName
		if(usedBodypart == BodypartSlot.Anus):
			theName = RNG.pick(["needy", "awaiting", "drippy", "inviting", "wet", "slick", "aroused"])+" "+theName
	elif(_isLubedUp):
		theName = RNG.pick(["lubed up"])+" "+theName
	elif(_isDry && RNG.chance(50)):
		if(usedBodypart == BodypartSlot.Vagina):
			theName = RNG.pick(["dry"])+" "+theName
		if(usedBodypart == BodypartSlot.Anus):
			theName = RNG.pick(["dry"])+" "+theName
	return theName

func getStartTextForPose(thePose) -> String:
	var throughClothing = "."
	if(!hasBodypartUncovered(DOM_0, usedBodypart)):
		throughClothing = " through {sub.yourHis} clothing."
	
	var text:String = ""
	if(thePose == POSE_ALLFOURS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('put')} {dom.you} on all fours and {sub.youVerb('position')} {sub.yourself} behind {dom.your} butt with {sub.yourHis} "+getDickName()+" out and {sub.youVerb('press', 'presses')} it against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_LOWDOGGY):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('put')} {dom.you} on all fours and {sub.youVerb('position')} {sub.yourself} behind {dom.your} butt with {sub.yourHis} "+getDickName()+" out and {sub.youVerb('press', 'presses')} it against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_STANDING):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('stand')} behind {dom.your} butt and {sub.youVerb('press', 'presses')} {sub.yourHis} "+getDickName()+" against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_MISSONARY):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.your} body against the floor, positioning {sub.yourself} between {dom.yourHis} legs. {sub.You} {sub.youVerb('align')} {sub.yourHis} "+getDickName()+" against {dom.yourHis} "+getUsedBodypartName()+".",
		])
	elif(thePose == POSE_FULLNELSON):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('wrap')} {sub.yourHis} arms under {dom.your} legs and {sub.youVerb('raise', 'raises')} {dom.youHim} above the floor, {sub.yourHis} hands locking {dom.yourHis} arms in a full nelson hold. {sub.YourHis} "+getDickName()+" is pressed against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_BEHIND):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.your} body against the floor, positioning {sub.yourself} behind. {sub.You} {sub.youVerb('align')} {sub.yourHis} "+getDickName()+" against {dom.yourHis} "+getUsedBodypartName()+".",
		])
	elif(thePose == POSE_MATINGPRESS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} firmly against the floor in a mating press position, folding {dom.yourHis} legs up toward {dom.yourHis} shoulders. {sub.You} {sub.youVerb('press', 'presses')} {sub.yourself} close, aligning {sub.yourHis} "+getDickName()+" against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_LEGRAISED):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('lift')} one of {dom.yourHis} legs, letting it dangle near {sub.yourHis} face, while {sub.youVerb('press', 'presses')} {sub.yourself} close. {sub.YourHis} "+getDickName()+" rubs against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_AGAINSTWALL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('press', 'presses')} {dom.you} firmly against the wall, {dom.yourHis} hands braced against it for support. {sub.You} {sub.youVerb('position')} {sub.yourself} behind, letting {sub.yourHis} "+getDickName()+" press against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_PINNEDWALL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} against the wall, {dom.yourHis} hands instinctively reaching up to grab it for stability. {sub.You} {sub.youVerb('get')} a hold of one of {dom.yourHis} legs and {sub.youVerb('press', 'presses')} {dom.yourHis} "+getDickName()+" against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	elif(thePose == POSE_WALLPRESS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} firmly against the wall, legs raised high, {dom.yourHis} hands reaching out to grab {sub.yourHis} shoulders. {sub.You} {sub.youVerb('press', 'presses')} {sub.yourHis} "+getDickName()+" against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	else:
		text = RNG.pick([
			"{sub.You} {sub.youVerb('position')} {sub.yourself} behind {dom.your} butt with {sub.yourHis} "+getDickName()+" out and {sub.youVerb('press', 'presses')} it against {dom.yourHis} "+getUsedBodypartName()+throughClothing,
		])
	return text
	
func getSwitchPoseTextForPose(thePose:String) -> String:
	var text:String = ""
	if(thePose == POSE_ALLFOURS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('put')} {dom.you} on all fours and {sub.youVerb('position')} {sub.yourself} behind {dom.your} butt, {sub.yourHis} "+getDickName()+" still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_LOWDOGGY):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('put')} {dom.you} on all fours and {sub.youVerb('position')} {sub.yourself} behind {dom.your} butt, {sub.yourHis} "+getDickName()+" still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_STANDING):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pick')} {dom.you} up, making {dom.youHim} stand on {dom.yourHis} feet. {sub.YourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_MISSONARY):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.your} body against the floor, {sub.yourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_FULLNELSON):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('wrap')} {sub.yourHis} arms under {dom.your} legs and {sub.youVerb('raise', 'raises')} {dom.youHim} above the floor, {sub.yourHis} hands locking {dom.yourHis} arms in a full nelson hold. {sub.YourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_BEHIND):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.your} body against the floor, {sub.yourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_MATINGPRESS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} firmly against the floor in a mating press position, folding {dom.yourHis} legs up toward {dom.yourHis} shoulders. {sub.YourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_LEGRAISED):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('lift')} one of {dom.yourHis} legs, letting it dangle near {sub.yourHis} face, while {sub.youVerb('press', 'presses')} {sub.yourself} close. {sub.YourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_AGAINSTWALL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('press', 'presses')} {dom.you} firmly against the wall, {dom.yourHis} hands braced against it for support. {sub.You} {sub.youVerb('position')} {sub.yourself} behind, {sub.yourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_PINNEDWALL):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} against the wall, {dom.yourHis} hands instinctively reaching up to grab it for stability. {sub.YourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	elif(thePose == POSE_WALLPRESS):
		text = RNG.pick([
			"{sub.You} {sub.youVerb('pin')} {dom.you} firmly against the wall, legs raised high, {dom.yourHis} hands reaching out to grab {sub.yourHis} shoulders. {sub.YourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	else:
		text = RNG.pick([
			"{sub.You} {sub.youVerb('position')} {sub.yourself} behind {dom.your} butt, {sub.yourHis} "+getDickName()+" is still inside {dom.yourHis} "+getUsedBodypartName()+"!",
		])
	return text
	
func startActivity(_args):
	currentPose = RNG.pick(getAvaiablePoses())
	
	addText(getStartTextForPose(currentPose))
	react(aboutToPenetrateReaction, [50, 50])

func onSwitchFrom(_otherActivity, _args):
	if(_args != null && _args == ["choke"]):
		currentPose = POSE_CHOKEFUCK
		return
	currentPose = RNG.pick(getAvaiablePoses())

#func processTurn():
#	if(currentPose == POSE_CHOKEFUCK):
#		choke(DOM_0, SUB_0, CHOKE_GENTLE)
#
func knotting_processTurn():
	cockWarmer(DOM_0, SUB_0, usedBodypart, true)

func fucking_processTurn():
	times += 1
	stimulateSex(SUB_0, DOM_0, usedBodypart, I_NORMAL)

	doProcessFuck(SUB_0, DOM_0, usedBodypart, getPoseDescriptor())
	
	if(currentPose == POSE_STANDING && getDomInfo().isUnconscious()):
		currentPose = POSE_ALLFOURS
		addText("Unable to continue standing, {dom.you} {dom.youVerb('fall')} to all fours!")
	
	doProcessFuckExtra(SUB_0, DOM_0, usedBodypart)
	
	if(isStraponSex() && !getDom().canZoneOrgasm(usedBodypart)): # If sub can't cum, just have some fun
		straponTimer += 1
		if(straponTimer > 5 && RNG.chance(5.0*straponTimer)):
			satisfyGoals()



func getActions(_indx:int):
	if(_indx == DOM_0):
		if(state in [""]):
			addAction("rub", 1.0, "Rub", "Rub your "+RNG.pick(usedBodypartNames)+" against their "+getDickName(), {A_PRIORITY: 4})
			if(getSubInfo().isReadyToPenetrate() && getDomInfo().getChar().getFirstItemThatCoversBodypart(usedBodypart) == null && getSubInfo().getChar().getFirstItemThatCoversBodypart(BodypartSlot.Penis) == null):
				addAction("envelop", fetish(SUB_0, fetishReceiving), RNG.pick(["Envelop cock"]), "Try to get this cock inside you", {A_PRIORITY: 5})
			if(getDomInfo().getChar().hasBodypart(otherHoleBodypart) && !getSexEngine().hasTag(getDomID(), otherHoleTag)):
				var switchholeScore:float = 5.0 * (-getDomInfo().goalsScore(getGoals(), getSubID()) + getDomInfo().goalsScore({otherGoal: 1.0}, getSubID()))
				addAction("switchhole", switchholeScore, "Switch hole", "Switch to your "+RNG.pick(otherHoleNames))
			addAction("stop", getStopScore(), "Stop fuck", "Stop fucking")
		
		if(state in ["fucking", "inside"]):
			addEggStuffButton(SUB_0, DOM_0, usedBodypart)
		if(state in ["fucking"]):
			addAction("slowdown", getPauseSexScore(SUB_0, DOM_0, usedBodypart), "Slow down", "Stop fucking for a second..", {A_PRIORITY: 1})
			
			if(isStraponSex() && getSub().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)):
				var subArousal:float = getDomInfo().getArousal()
				var straponForceKnotScore:float = 0.05
				if(subArousal > 0.8 || getDomInfo().isUnconscious()):
					straponForceKnotScore = 0.5
				addAction("straponForceKnot", straponForceKnotScore, "Force knot in", "Try to force the knot in!", {A_PRIORITY: 3})
			if(isReadyToCumHandled(SUB_0) && isStraponSex()):
				addAction("domstraponcum", 1.0, "Sub Orgasm!", "{sub.You} is about to cum!", {A_PRIORITY: 1001})
			if(isReadyToCumHandled(SUB_0) && !isStraponSex()):
				var condomScore:float = 0.0
				if(getSubCondom() != null):
					condomScore = 1.0
				
				var scoreToCumInside:float = max(condomScore, getDomInfo().fetishScore({Fetish.Breeding: 1.0}) + 0.5 - 20.0*float(gonnaCumOutside))
				if(getDom().hasPerk(Perk.FertilitySubmissiveAndBreedable) || getSexEngine().domNoPullingOut):
					scoreToCumInside = 1.0
				
				var hasKnot:bool = getSub().bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot)
				if(hasKnot):
					var knotinsideScore:float = scoreToCumInside * (3.0 if getDom().hasPerk(Perk.CumUniqueBiology) else 1.0)
					addAction("knotinside", knotinsideScore, "Get Knotted", "Try to force their knot inside your "+RNG.pick(usedBodypartNames), {A_PRIORITY: 1001})
					
				addAction("cuminside", scoreToCumInside, "Cum inside", "Let them cum inside your "+RNG.pick(usedBodypartNames), {A_PRIORITY: 1001})
				addAction("cumpullout", 1.0 - min(1.0, scoreToCumInside), "Pull out", "Make them pull out", {A_PRIORITY: 1001})
			elif(isReadyToCumHandled(DOM_0) && !getDomInfo().canDoActions()):
				addAction("subcumDom", 1.0, "Cum!", "You are about to cum!", {A_PRIORITY: 1001})

		if(state in ["aftercumminginside"]):
			addAction("continuefucking", getContinueSexScore(SUB_0, DOM_0, usedBodypart) - getStopScore(), "Continue fucking", "Continue fucking their "+getDickName())
		if(state in ["aftercumminginside", "fucking"]):
			if(!getSubInfo().isReadyToCum()):
				addAction("pullout", getStopScore(), "Pull out", "Pull their cock out and stop fucking them")
		if(state in ["knotting"]):
			addAction("pullknotout", 1.0, "Pull out", "Try to yank their knot out")
		for pose in getAvaiablePoses():
			if(pose == currentPose):
				continue
			var poseName = "error"
			if(PoseToName.has(pose)):
				poseName = PoseToName[pose]
			addAction("switchpose", 0.0 if switchedPoseOnce else 0.01, poseName, "Change pose", {A_CATEGORY: ["Switch pose"], A_ARGS: [pose]})
		
	if(_indx == SUB_0):
		if(state == ""):
			var rubSubScore:float = getSubInfo().getComplyScore() * fetish(SUB_0, fetishReceiving)
			addAction("rubSub", rubSubScore, "Rub", "Rub your cock against their "+RNG.pick(usedBodypartNames))
			addAction("resist", getSubInfo().getResistScore() / 2.0, RNG.pick(["Pull away"]), "Resist the attempts", {A_CHANCE: getSubResistChance(30.0, 25.0)})
			if(getDomInfo().getChar().getFirstItemThatCoversBodypart(usedBodypart) == null && getSub().getFirstItemThatCoversBodypart(BodypartSlot.Penis) == null && getSubInfo().isReadyToPenetrate()):
				addAction("insert", 1.0, "Penetrate", "Try to insert your "+getDickName()+" into their "+RNG.pick(usedBodypartNames))
		if(state in ["fucking"]):
			var moanScore:float = max(0.1, fetish(SUB_0, fetishReceiving)*0.5 + personality(SUB_0, PersonalityStat.Subby)*0.5)
			addAction("moan", moanScore, "Moan", "Show how much you like it", {A_PRIORITY: 3})
			addAction("resistduringfuck", getSubInfo().getResistScore() / 2.0, "Resist", "Try to stop them!", {A_CHANCE: getSubResistChance(20.0, 15.0), A_PRIORITY: 2})
		if(state in ["fucking", "knotting"]):
			if(isReadyToCumHandled(DOM_0)):
				addAction("subcum", 1.0, "Cum!", "You're about to cum!", {A_PRIORITY: 1001})
		
func doAction(_indx:int, _id:String, _action:Dictionary):
	if(_id == "stuffegg"):
		doStuffEggInto(SUB_0, DOM_0, usedBodypart)
	if(_id == "straponForceKnot"):
		# Need a tryKnot func?
		#if(tryPenetrate())
		stimulateSex(SUB_0, DOM_0, usedBodypart, I_NORMAL, SPEED_SLOW)
		#var subArousal:float = getSubInfo().getArousal()
		if(RNG.chance(getSub().getKnottingChanceBy(usedBodypart, getSubID()) * 0.25)):
			getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.2)
			addTextTopBottom(RNG.pick([
				#"{dom.You} {dom.youVerb('manage')} to knot {sub.you}!",
				"{<TOP>.You} "+RNG.pick(["{<TOP>.youVerb('ram')}", "{<TOP>.youVerb('shove')}", "{<TOP>.youVerb('slide')}"])+" {<TOP>.yourHis} {<TOP>.penisShort} deep inside {<BOTTOM>.your} "+getNameHole(SUB_0, usedBodypart)+" and force the knot in, stretching {<BOTTOM>.yourHis} "+getNameHole(SUB_0, usedBodypart)+" wide!",
				"{<TOP>.You} {<TOP>.youVerb('manage')} to force {<TOP>.yourHis} knot in, stretching {<BOTTOM>.you} out!",
				"{<TOP>.You} "+RNG.pick(["{<TOP>.youVerb('ram')}", "{<TOP>.youVerb('shove')}", "{<TOP>.youVerb('slide')}"])+" {<TOP>.yourHis} {<TOP>.penisShort} balls-deep. The knot stretches {<BOTTOM>.your} "+getNameHole(SUB_0, usedBodypart)+" until finally slipping in.",
			]), SUB_0, DOM_0)
			state = "knotting"
			cumInside(SUB_0, DOM_0, usedBodypart)
			satisfyGoals()
		else:
			getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.1)
			addTextPick([
				"{sub.You} {sub.youVerb('try', 'tries')} to shove the knot inside!",
				"{sub.You} {sub.youVerb('try', 'tries')} to stretch {dom.yourHis} "+getNameHole(DOM_0, usedBodypart)+" enough to slip the knot inside!",
				"{sub.You} {sub.youVerb('try', 'tries')} to knot {dom.you}!",
			])
		return
	if(_id == "slowdown"):
		state = "aftercumminginside"
		addText("{sub.You} {sub.youVerb('slow')} {sub.yourHis} pace down and just {sub.youVerb('let')} {sub.yourHis} "+getDickName()+" stay inside.")
		return
	if(_id == "switchpose"):
		switchedPoseOnce = true
		var newPose = _action["args"][0]
		var isInside:bool = true
		if(state in [""]):
			isInside = false
		
		if(isInside):
			addText(getSwitchPoseTextForPose(newPose))
		else:
			addText(getStartTextForPose(newPose))
		currentPose = newPose
		return
	if(_id == "subcumDom"):
		var straponText:String = ""
		if(isStraponSex()):
			satisfyGoals()
			
			var strapon = getSub().getWornStrapon()
			if(strapon.getFluids() != null && !strapon.getFluids().isEmpty()):
				getSub().cummedInBodypartByAdvanced(usedBodypart, getSubID())
				straponText="{sub.Your} strapon gets squeezed by {dom.your} "+RNG.pick(usedBodypartNames)+" enough for it to suddenly [b]release its contents inside {dom.youHim}[/b]!"
			
		getDom().cumOnFloor(getSubID())
		getDomInfo().cum()
		addGenericOrgasmText(DOM_0)
		if(straponText != ""):
			addText(straponText)
		return
	if(_id == "domstraponcum"):
		getSub().cumOnFloor()
		getSubInfo().cum()
		addGenericOrgasmText(SUB_0)
		return
	if(_id == "rub"):
		stimulateSex(SUB_0, DOM_0, usedBodypart, I_TEASE)
		#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.05, -0.1, 0.0)
		#affectDom(max(0.1, getDomInfo().fetishScore({fetishGiving: 1.0})+1.0), 0.05*domSensitivity(), 0.0)
		addText("{dom.You} {dom.youVerb('rub')} {dom.yourHis} "+RNG.pick(usedBodypartNames)+" against {sub.your} "+getDickName()+".")
		return
	if(_id == "insert"):
		if(RNG.chance(20)):
			stimulateSex(SUB_0, DOM_0, usedBodypart, I_TEASE)
			#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.01, -0.1, 0.0)
			#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.01*domSensitivity(), 0.01)
			
			addTextPick([
				"{sub.You} {sub.youVerb('attempt')} to sink {sub.yourHis} "+getDickName()+" into {dom.your} "+RNG.pick(usedBodypartNames)+".",
				"{sub.You} {sub.youVerb('try','tries')} to penetrate {dom.your} "+RNG.pick(usedBodypartNames)+" with {sub.yourHis} "+getDickName()+".",
				"{sub.You} {sub.youVerb('rub')} {sub.yourHis} "+getDickName()+" against {dom.your} "+RNG.pick(usedBodypartNames)+", trying to sink it in.",
			])
			return
		else:
			# Cock len vs Vagina depth check here
			if(!RNG.chance(getDom().getPenetrateChanceBy(usedBodypart, getSubID()))):
				getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.1)
				addText("{sub.Your} "+getDickName()+" stretches {dom.your} "+RNG.pick(usedBodypartNames)+" out while trying to fit inside.")
				#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.05, -0.2, -0.01)
				#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.05*domSensitivity(), -0.01)
				#getSubInfo().addArousalForeplay(0.05)
				#getDomInfo().addArousalForeplay(0.05*domSensitivity())
				stimulateSex(SUB_0, DOM_0, usedBodypart, I_TEASE)
				
				return
			else:
				sendSexEvent(SexEvent.HolePenetrated, SUB_0, DOM_0, {hole=usedBodypart,engulfed=false,strapon=isStraponSex()})
				gonnaCumOutside = false
				#getSub().gotFuckedBy(usedBodypart, getDomID())
				getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.2)
				state = "fucking"
				#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.1, -0.3, 0.0)
				#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.1*domSensitivity(), -0.05)
				#getSubInfo().addArousalForeplay(0.1)
				#getDomInfo().addArousalForeplay(0.1*domSensitivity())
				stimulateSex(SUB_0, DOM_0, usedBodypart, I_LOW)
				var text:String = RNG.pick([
					"{sub.You} {sub.youVerb('manage','manages')} to penetrate {dom.your} "+RNG.pick(usedBodypartNames)+"!",
					"{sub.You} {sub.youVerb('shove','shoves')} {sub.yourHis} "+getDickName()+" inside {dom.your} "+RNG.pick(usedBodypartNames)+"!",
				])
				if(usedBodypart == BodypartSlot.Anus && getDom().getInventory().hasSlotEquipped(InventorySlot.Anal)):
					var item = getDom().getInventory().getEquippedItem(InventorySlot.Anal)
					text = "{dom.You} temporarily {dom.youVerb('retrieve')} "+str(item.getAStackName())+" out of {dom.your} ass. "+text
				elif(usedBodypart == BodypartSlot.Vagina && getDom().getInventory().hasSlotEquipped(InventorySlot.Vagina)):
					var item = getDom().getInventory().getEquippedItem(InventorySlot.Vagina)
					text = "{dom.You} temporarily {dom.youVerb('retrieve')} "+str(item.getAStackName())+" out of {dom.your} pussy. "+text
				
				addText(text)
				
#				var freeRoom:float = getSub().getPenetrationFreeRoomBy(usedBodypart, getDomID())
#				var chanceToPain = -freeRoom * 2.0
#				if(RNG.chance(chanceToPain) || (getDomInfo().isAngry() && RNG.chance(20))):
#					doStretch(DOM_0, SUB_0, usedBodypart)

				return
	if(_id == "switchhole"):
		switchCurrentActivityTo(switchHoleActivity)
		addText("{dom.You} {dom.youVerb('switch', 'switches')} holes. {dom.YouHe} {sub.youAreHeIs} "+RNG.pick(["prodding", "teasing", "rubbing"])+" {dom.your} "+RNG.pick(otherHoleNames)+" now.")
		return
	if(_id in ["knotinside", "cuminside"]):
		var wombText:String = RNG.pick([
			"womb", "womb",
			"babymaker",
		])
		if(usedBodypart == BodypartSlot.Anus):
			wombText = RNG.pick([
				"ass",
				"butt",
			])
		var text:String = ""
		
		var condomBroke:bool = false
		var knotSuccess:bool = false
		#var isTryingToKnot = false
		if(_id == "knotinside"):
			#isTryingToKnot = true
			getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.5)
			if(RNG.chance(getDom().getKnottingChanceBy(usedBodypart, getSubID()))):
				knotSuccess = true
			else:
				text += RNG.pick([
					"{dom.You} {dom.youVerb('try', 'tries')} to "+RNG.pick(["force {sub.yourHis} knot inside {dom.youHim}", "get knotted by {dom.you}"])+" but {dom.yourHis} hole is just too tight. "
				])
		
		if(knotSuccess):
			text = RNG.pick([
				"{sub.You} {sub.youVerb('keep')} fucking {dom.your} "+RNG.pick(usedBodypartNames)+" hard until {sub.yourHis} knot suddenly slips inside! [b]{sub.You} {sub.youVerb('moan')} as {sub.youHe} {sub.youHeVerb('cum')} inside {dom.you}[/b]!",
			])
		else:
			text = RNG.pick([
				"{sub.You} {sub.youVerb('keep')} fucking {dom.your} "+RNG.pick(usedBodypartNames)+" until [b]{sub.youHe} {sub.youHeVerb('cum')} inside {dom.you}[/b]!",
			])
		text += RNG.pick([
			" Waves after waves of sticky "+RNG.pick(["cum", "seed", "jizz", "semen"])+" flow into {dom.yourHis} "+wombText+".",
		])
		
		var condom:ItemBase = getSub().getWornCondom()
		if(condom != null):
			var breakChance = condom.getCondomBreakChance()
			condomBroke = getSub().shouldCondomBreakWhenFucking(getDom(), breakChance)
			if(condomBroke):
				text = "[b]The condom broke![/b] "+text
				condom.destroyMe()
				fetishUp(SUB_0, Fetish.Condoms, -15.0)
				fetishUp(DOM_0, Fetish.Condoms, -20.0)
			else:
				fetishAffect(SUB_0, Fetish.Condoms, 3.0)
				fetishAffect(DOM_0, Fetish.Condoms, 3.0)
				if(knotSuccess):
					text = RNG.pick([
						"{sub.You} {sub.youVerb('keep')} fucking {dom.your} "+RNG.pick(usedBodypartNames)+" hard until {sub.yourHis} knot suddenly slips inside!",
					])
				else:
					text = RNG.pick([
						"{sub.You} {sub.youVerb('keep')} fucking {dom.your}  "+RNG.pick(["cock", "dick", "member"])+".",
					])
				text += RNG.pick([
					" {sub.You} {sub.youVerb('moan')} as {sub.youHe} {sub.youHeVerb('fill')} the condom inside {dom.your} "+RNG.pick(usedBodypartNames)+"!",
					" {sub.You} {sub.youVerb('moan')} as {sub.youHe} {sub.youHeVerb('stuff')} the condom in {dom.your} "+RNG.pick(usedBodypartNames)+" full of {sub.yourHis} "+RNG.pick(["cum", "seed", "jizz", "semen"])+"!",
				])
				var loadSize = getSub().cumInItem(condom)
				getSubInfo().cum()
				getDomInfo().addArousalSex(0.02)
				sendSexEvent(SexEvent.FilledCondomInside, SUB_0, DOM_0, {hole=usedBodypart,loadSize=loadSize,knotted=knotSuccess,engulfed=true})
				satisfyGoals()
				if(knotSuccess):
					state = "knotting"
				else:
					state = "aftercumminginside"
				
				addText(text)
				return
		
		getDom().cummedInBodypartByAdvanced(usedBodypart, getSubID(), {knotted=knotSuccess,condomBroke=condomBroke,engulfed=true})
		getSubInfo().cum()
		
		satisfyGoals()
		if(knotSuccess):
			state = "knotting"
			getDomInfo().addArousalSex(0.05)
		else:
			state = "aftercumminginside"
			getDomInfo().addArousalSex(0.02)
		
		addText(text)
		return
	if(_id == "cumpullout"):
		cumOnto(SUB_0, DOM_0, {sex=true})
		satisfyGoals()
		state = ""
		applyTallymarkIfNeeded(usedBodypart)
		return
	if(_id == "continuefucking"):
		gonnaCumOutside = false
		state = "fucking"
		var text:String = ""
		if(!getDom().isPlayer()):
			var randomNewPose = RNG.pick(getAvaiablePoses())
			if(currentPose != randomNewPose):
				currentPose = randomNewPose
				text = getSwitchPoseTextForPose(randomNewPose)+" "
		
		text += RNG.pick([
			"{sub.You} began moving {sub.yourHis} hips again, fucking {dom.your} "+RNG.pick(usedBodypartNames)+"!",
			"{sub.You} went for a second round, fucking {dom.your} "+RNG.pick(usedBodypartNames)+" again!",
		])
		addText(text)
		return
	if(_id == "pullknotout"):
		if(RNG.chance(30)):
			state = ""
			var text:String = RNG.pick([
				"{dom.You} "+RNG.pick(["{dom.youVerb('pull')}", "{dom.youVerb('yank')}"])+" {sub.yourHis} knot out.",
			])
			
			if((getDom().hasEffect(StatusEffect.HasCumInsideVagina) && usedBodypart == BodypartSlot.Vagina) || (getDom().hasEffect(StatusEffect.HasCumInsideAnus) && usedBodypart == BodypartSlot.Anus)):
				if((getDom().getBuffsHolder().hasBuff(Buff.BlocksVaginaLeakingBuff) && usedBodypart == BodypartSlot.Vagina) || (getDom().getBuffsHolder().hasBuff(Buff.BlocksAnusLeakingBuff) && usedBodypart == BodypartSlot.Anus)):
					text += RNG.pick([
						" Some "+RNG.pick(["cum", "seed", "semen"])+" tries to leak out but {dom.you} quickly {dom.youVerb('plug')} {dom.yourHis} "+RNG.pick(usedBodypartNames)+".",
					])
				else:	
					text += RNG.pick([
						" Some "+RNG.pick(["cum", "seed", "semen"])+" leaks out of {dom.yourHis} used "+RNG.pick(usedBodypartNames)+".",
					])
			stimulateSex(SUB_0, DOM_0, usedBodypart, I_NORMAL, SPEED_VERYSLOW)
			addText(text)
			return
		else:
			var text:String = RNG.pick([
				"{dom.You} {dom.youVerb('try', 'tries')} to "+RNG.pick(["pull", "yank"])+" {sub.yourHis} "+RNG.pick(["cock", "dick"])+" out but {dom.youVerb('fail')}. The knot slowly deflates.",
			])
			getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.1)
			#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.1, -0.3, 0.0)
			#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.1, -0.05)
			#getSubInfo().addArousalForeplay(0.1)
			#getDomInfo().addArousalForeplay(0.1)
			stimulateSex(SUB_0, DOM_0, usedBodypart, I_TEASE)
			addText(text)
			return
	if(_id == "pullout"):
		endActivity()
		var text:String = RNG.pick([
			"{dom.You} {dom.youVerb('pull')} {sub.yourHis} "+getDickName()+" away.",
		])
		
		addText(text)
		return
	if(_id == "stop"):
		endActivity()
		addText("{dom.You} {dom.youVerb('stop')} the fuck.")
		return
	
	if(_id == "subcum"):
		var straponText:String = ""
		if(isStraponSex()):
			satisfyGoals()
			var strapon = getSub().getWornStrapon()
			if(strapon.getFluids() != null && !strapon.getFluids().isEmpty()):
				getDom().cummedInBodypartByAdvanced(usedBodypart, getSubID())
				straponText="{sub.Your} strapon gets squeezed by {dom.your} "+RNG.pick(usedBodypartNames)+" enough for it to suddenly [b]release its contents inside {dom.youHim}[/b]!"
		getDom().cumOnFloor(getSubID())
		getDomInfo().cum()
		addGenericOrgasmText(DOM_0)
		if(straponText != ""):
			addText(straponText)
		return
	if(_id == "rubSub"):
		#switchCurrentActivityTo("SexFuckTest2")
		getDomInfo().addAnger(-0.05)
		stimulateSexRide(DOM_0, SUB_0, usedBodypart, I_TEASE)
		#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.1, 0.0, 0.0)
		#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.1*domSensitivity(), -0.01)
		#getSubInfo().addArousalForeplay(0.05)
		#getDomInfo().addArousalForeplay(0.05*domSensitivity())
		addText("{sub.You} {sub.youVerb('rub')} {sub.your} "+getDickName()+" against {dom.yourHis} "+RNG.pick(usedBodypartNames)+".")
		return
	if(_id == "envelop"):
		if(!RNG.chance(getDom().getPenetrateChanceBy(usedBodypart, getSubID()))):
			getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.1)
			#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.1, 0.0, 0.0)
			#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.2, -0.01)
			stimulateSexRide(DOM_0, SUB_0, usedBodypart, I_TEASE)
			addText("{dom.You} {dom.youVerb('try', 'tries')} to envelop {sub.yourHis} "+getDickName()+" but it's too big!")
			return
		
		sendSexEvent(SexEvent.HolePenetrated, SUB_0, DOM_0, {hole=usedBodypart,engulfed=true,strapon=isStraponSex()})
		#affectSub(getSubInfo().fetishScore({fetishReceiving: 1.0}), 0.1, 0.0, 0.0)
		#affectDom(getDomInfo().fetishScore({fetishGiving: 1.0}), 0.1*domSensitivity(), -0.01)
		#getSubInfo().stimulateArousalZone(0.1, usedBodypart, 0.5)
		#getDomInfo().stimulateArousalZone(0.1, BodypartSlot.Penis, 0.5)
		stimulateSexRide(DOM_0, SUB_0, usedBodypart, I_LOW)
		
		#getSub().gotFuckedBy(usedBodypart, getDomID())
		getDom().gotOrificeStretchedBy(usedBodypart, getSubID(), true, 0.2)
		gonnaCumOutside = false
		state = "fucking"
		addText("{dom.You} {dom.youVerb('engulf')} {sub.youHis} "+getDickName()+", letting it penetrate {dom.yourHis} "+RNG.pick(usedBodypartNames)+".")
		return
#	if(_id == "offerotherhole"):
#		var text:String = RNG.pick([
#			"{sub.You} {sub.youVerb('offer')} {sub.yourHis} other hole to {dom.you}.",
#		])
#		if(getDom().isPlayer()):
#			addText(text)
#			return
#
#		if(RNG.chance(getSubSwitchHoleChance())):
#			text += RNG.pick([
#				" {dom.You} {dom.youVerb('nod')}."
#			])
#			getDomInfo().remember("switchedHoles")
#
#			if(usedBodypart == BodypartSlot.Vagina):
#				replaceGoalsTo(SexGoal.FuckAnal)
#			else:
#				replaceGoalsTo(SexGoal.FuckVaginal)
#
#			addText(text)
#			return
#		else:
#			getDomInfo().addAnger(0.05)
#			text += RNG.pick([
#				" {dom.You} {dom.youVerb('ignore')} {sub.yourHis} offer."
#			])
#
#			addText(text)
#			return
	if(_id == "resist"):
		var howMuchPainAdded:int = RNG.randi_range(2, 6)
		getDomInfo().addPain(howMuchPainAdded)
		sendSexEvent(SexEvent.PainInflicted, SUB_0, DOM_0, {pain=howMuchPainAdded,isDefense=true,intentional=true})
		if(RNG.chance(getSubResistChance(30.0, 25.0))):
			getDomInfo().addAnger(0.4)
			endActivity()
			addText("{sub.You} {sub.youVerb('manage')} to kick {dom.you} off of {sub.youHim}.")
			return
		else:
			getDomInfo().addAnger(0.2)
			addText("{sub.You} {sub.youVerb('resist')} attempts to penetrate {sub.youHis} "+RNG.pick(usedBodypartNames)+".")
			reactSub(SexReaction.ActivelyResisting, [50])
			return
	if(_id == "moan"):
		var moanText:String = RNG.pick([
			"{sub.youVerb('moan')}"
		])
		if(getSub().isGagged()):
			moanText = RNG.pick([
				"{sub.youVerb('let')} out muffled moans",
				"{sub.youVerb('let')} out a muffled moan",
				"{sub.youVerb('let')} out a muffled noise of pleasure",
			])
		
		addTextPick([
			"{sub.You} "+moanText+" while fucking"+getPoseDescriptor()+"!",
			"{sub.You} "+moanText+" while having {sub.yourHis} "+getDickName()+" used!",
			"{sub.You} "+moanText+" eagerly!",
		])
		moan(SUB_0)
		return
	if(_id == "resistduringfuck"):
		if(RNG.chance(getSubResistChance(20.0, 15.0))):
			getDomInfo().addAnger(0.2)
			
			state = ""
			addText("{sub.You} {sub.youVerb('struggle')} enough for {dom.youHim} to pull out!")
			return
		else:
			getDomInfo().addAnger(0.1)
			addTextPick([
				"{sub.You} {sub.youVerb('try', 'tries')} to resist while being forced to fuck"+getPoseDescriptor()+"!",
				"{sub.You} {sub.youVerb('try', 'tries')} to resist while having {sub.yourHis} "+getDickName()+" used!",
				"{sub.You} {sub.youVerb('try', 'tries')} to pull out!",
			])
			reactSub(SexReaction.ActivelyResisting, [50])
			return
#	if(_id == "begtopullout"):
#		getDomInfo().addAnger(-0.02)
#		var text:String = RNG.pick([
#			"{sub.You} {sub.youVerb('beg')} {dom.youHim} not to cum inside.",
#			"{sub.You} {sub.youVerb('beg')} {dom.youHim} to pull out.",
#		])
#
#		if(RNG.chance(10 - 10 * getDomInfo().fetishScore({Fetish.Breeding: 1.0})) && !getDom().isPlayer()):
#			gonnaCumOutside = true
#			text += " {dom.you} listened!"
#
#		addText(text)
#		reactSub(sexReactionPullOut)
#		return
	
func getSubResistChance(baseChance:float, domAngerRemoval:float) -> float:
	var theChance = baseChance - getDomInfo().getAngerScore()*domAngerRemoval
	if(getSub().hasBlockedHands()):
		theChance *= 0.5
	if(getSub().hasBoundArms()):
		theChance *= 0.5
	if(getSub().isBlindfolded()):
		theChance *= 0.8
	if(isStocksSex() || getSexType() == SexType.SlutwallSex):
		theChance *= 0.5
	if(getSexType() == SexType.BitchsuitSex):
		theChance *= 0.3
	if(currentPose == POSE_FULLNELSON):
		theChance *= 0.5
	
	return max(theChance, 5.0)

func getAnimation():

	var animToPlay = StageScene.SexAllFours
	var supportsFlop = false
	if(PoseToAnimName.has(currentPose)):
		animToPlay = PoseToAnimName[currentPose]
	if(animToPlay == StageScene.SexAllFours):
		supportsFlop = true
	var shouldFlop = (getDom().hasBoundArms() || getDomInfo().isUnconscious()) && supportsFlop
	var shouldUncon = getDomInfo().isUnconscious()
	
	if(shouldFlop):
		if(state in [""]):
			return [animToPlay, "teaseflop", {pc=SUB_0, npc=DOM_0}]
		if(state in ["aftercumminginside", "knotting"]):
			return [animToPlay, "insideflop", {pc=SUB_0, npc=DOM_0}]
		if(getSubInfo().isCloseToCumming() || (isStraponSex() && getDomInfo().isCloseToCumming())):
			return [animToPlay, "fastflop", {pc=SUB_0, npc=DOM_0}]
			
		return [animToPlay, "sexflop", {pc=SUB_0, npc=DOM_0}]
	else:
		if(state in [""]):
			return [animToPlay, "tease", {pc=SUB_0, npc=DOM_0, uncon=shouldUncon}]
		if(state in ["aftercumminginside", "knotting"]):
			return [animToPlay, "inside", {pc=SUB_0, npc=DOM_0, uncon=shouldUncon}]
		if(getSubInfo().isCloseToCumming() || (isStraponSex() && getDomInfo().isCloseToCumming())):
			return [animToPlay, "fast", {pc=SUB_0, npc=DOM_0, uncon=shouldUncon}]
			
		return [animToPlay, "sex", {pc=SUB_0, npc=DOM_0, uncon=shouldUncon}]

func getSubCondom():
	return getSub().getWornCondom()

func getSubSwitchHoleChance() -> float:
	if(getSubInfo().hasMemory("switchedHoles")):
		return 0.0
	
	var domLikesOtherHoleScore:float = getDomInfo().fetishScore({otherHoleFetishGiving:1.0, fetishGiving: -0.5})
	
	return max(5.0, domLikesOtherHoleScore * 100.0 * (1.0 - getDomInfo().getAngerScore()))

func getOrgasmHandlePriority(_indx:int) -> int:
	if(_indx == SUB_0):
		if(isStraponSex()):
			return 5
		return 10
	if(_indx == DOM_0):
		if(isStraponSex()):
			return 10
		return 5
	return -1

func getJoinActions(_sexInfo:SexInfoBase):
	if(!(_sexInfo is SexDomInfo)):
		return
	#var theChar:BaseCharacter = _sexInfo.getChar()
	
	if(usedBodypart == S_ANUS && canSwitchTo("ThreeDDS_SpitroastAnal", [DOM_0, _sexInfo], [SUB_0])):
		addJoinAction(["spitroast"], "+Spitroast", "Join and fuck their mouth!", getJoinActivityScore("ThreeDDS_SpitroastAnal", DOM_1, _sexInfo, getSubInfo()), {A_CATEGORY: ["Fuck"]})
	elif(usedBodypart == S_VAGINA && canSwitchTo("ThreeDDS_SpitroastVag", [DOM_0, _sexInfo], [SUB_0])):
		addJoinAction(["spitroast"], "+Spitroast", "Join and fuck their mouth!", getJoinActivityScore("ThreeDDS_SpitroastVag", DOM_1, _sexInfo, getSubInfo()), {A_CATEGORY: ["Fuck"]})

	if(canSwitchTo("ThreeDDS_DP", [DOM_0, _sexInfo], [SUB_0])):
		var theDPHole:String = S_ANUS if usedBodypart == S_VAGINA else S_VAGINA
		if(!getSub().hasReachableVagina()):
			theDPHole = S_ANUS
		elif(getSub().hasReachableVagina() && !getSub().hasReachableAnus()):
			theDPHole = S_VAGINA
		
		if(theDPHole == S_ANUS):
			addJoinAction(["dp"], "+DP (anal)", "Join and fuck their ass at the same time!", getJoinActivityScore("ThreeDDS_DP", DOM_1, _sexInfo, getSubInfo()), {A_CATEGORY: ["Fuck"]})
		else:
			addJoinAction(["dp"], "+DP (vaginal)", "Join and fuck their pussy at the same time!", getJoinActivityScore("ThreeDDS_DP", DOM_0, _sexInfo, getSubInfo()), {A_CATEGORY: ["Fuck"]})
	
	if(canSwitchTo("ThreeDDS_Train", [DOM_0, _sexInfo], [SUB_0], [usedBodypart, S_VAGINA])):
		addJoinAction(["trainVag"], "+Train (vag, receive)", "Join and let the sub fuck your pussy at the same time!", getJoinActivityScore("ThreeDDS_Train", DOM_1, _sexInfo, getSubInfo(), [S_VAGINA]), {A_CATEGORY: ["Fuck"]})
	if(canSwitchTo("ThreeDDS_Train", [DOM_0, _sexInfo], [SUB_0], [usedBodypart, S_ANUS])):
		addJoinAction(["trainAnal"], "+Train (anal, receive)", "Join and let the sub fuck your ass at the same time!", getJoinActivityScore("ThreeDDS_Train", DOM_1, _sexInfo, getSubInfo(), [S_ANUS]), {A_CATEGORY: ["Fuck"]})
	
		
func doJoinAction(_sexInfo:SexInfoBase, _args):
	if(_args[0] == "spitroast"):
		if(usedBodypart == S_ANUS):
			switchCurrentActivityTo("ThreeDDS_SpitroastAnal", [_sexInfo.getCharID()])
		if(usedBodypart == S_VAGINA):
			switchCurrentActivityTo("ThreeDDS_SpitroastVag", [_sexInfo.getCharID()])
	if(_args[0] == "dp"):
		if(usedBodypart == S_ANUS):
			switchCurrentActivityTo("ThreeDDS_DP", ["vag", _sexInfo.getCharID()])
		if(usedBodypart == S_VAGINA):
			switchCurrentActivityTo("ThreeDDS_DP", ["anal", _sexInfo.getCharID()])
	if(_args[0] == "trainVag"):
		switchCurrentActivityTo("ThreeDDS_Train", [usedBodypart, S_VAGINA, _sexInfo.getCharID()])
	if(_args[0] == "trainAnal"):
		switchCurrentActivityTo("ThreeDDS_Train", [usedBodypart, S_ANUS, _sexInfo.getCharID()])
	
func saveData():
	var data = .saveData()
	
	data["times"] = times
	data["gonnaCumOutside"] = gonnaCumOutside
	data["switchedPoseOnce"] = switchedPoseOnce
	data["currentPose"] = currentPose
	data["straponTimer"] = straponTimer

	return data
	
func loadData(data):
	.loadData(data)
	
	times = SAVE.loadVar(data, "times", 0)
	gonnaCumOutside = SAVE.loadVar(data, "gonnaCumOutside", false)
	switchedPoseOnce = SAVE.loadVar(data, "switchedPoseOnce", false)
	currentPose = SAVE.loadVar(data, "currentPose", "")
	straponTimer = SAVE.loadVar(data, "straponTimer", 0)
	if(currentPose == ""):
		currentPose = RNG.pick(getAvaiablePoses())
