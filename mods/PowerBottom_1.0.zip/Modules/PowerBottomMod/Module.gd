extends Module


func _init():
	id = "PowerBottom"
	author = "harebrainedgoofball"
	sexActivities = [
		"res://Modules/PowerBottomMod/InverseSexVaginalOnAllFours.gd",
		"res://Modules/PowerBottomMod/InverseSexAnalOnAllFours.gd",
		"res://Modules/PowerBottomMod/SubRidingDomVaginal.gd",
		"res://Modules/PowerBottomMod/SubRidingDomAnal.gd"
	]
