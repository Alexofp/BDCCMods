extends "res://Modules/PowerBottomMod/SubRidingDomVaginal.gd"

func _init():
	id = "SubRidingDomAnal"
	usedBodypart = BodypartSlot.Anus
	usedTag = SexActivityTag.AnusUsed
	usedTagInside = SexActivityTag.AnusPenetrated
	fetishGiving = Fetish.AnalSexReceiving
	fetishReceiving = Fetish.AnalSexGiving
	usedBodypartNames = ["anus", "tailhole", "backdoor", "star", "anal ring"]
	switchHoleActivity = "SubRidingDomVaginal"
	otherHoleNames = ["pussy"]
	otherHoleBodypart = BodypartSlot.Vagina
	otherHoleTag = SexActivityTag.VaginaUsed
	otherHoleFetishGiving = Fetish.VaginalSexReceiving
	otherHoleFetishReceiving = Fetish.VaginalSexGiving
	otherGoal = SexGoal.FuckVaginal
	aboutToRideReaction = SexReaction.AboutToRideAnal
	isVag = false
	
	activityName = "Cowgirl Anal (Bottom)"
	activityDesc = "Make them ride your cock with their ass!"
	
func getGoals():	
	return {
		SexGoal.FuckAnal: 1.0,
		SexGoal.StraponAnal: 1.0,
	}
