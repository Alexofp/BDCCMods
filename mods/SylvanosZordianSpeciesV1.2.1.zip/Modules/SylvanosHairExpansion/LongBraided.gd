extends BodypartHair

func _init():
	visibleName = "long braided"
	id = "longbraided"

	maleWeight = 0.1
	femaleWeight = 1.0

func getDoll3DScene():
	return "res://Modules/SylvanosHairExpansion/LongBraided/LongBraided.tscn"

func getTraits():
	return {
		PartTrait.HairOvereye: true,
	}
