extends Module

func _init():
	id = "SylvanosHairExpansion"
	author = "Sylvanos & Avery Winters"
	
	bodyparts = [
		"res://Modules/SylvanosHairExpansion/LongBraided.gd",
		"res://Modules/SylvanosHairExpansion/ShortTop.gd",
	]
