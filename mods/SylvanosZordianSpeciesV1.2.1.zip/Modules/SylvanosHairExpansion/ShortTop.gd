extends BodypartHair

func _init():
	visibleName = "short top"
	id = "shorttop"

	maleWeight = 1.0
	femaleWeight = 0.1

func getDoll3DScene():
	return "res://Modules/SylvanosHairExpansion/ShortTop/ShortTop.tscn"

func getTraits():
	return {
		PartTrait.HairOvereye: true,
	}
