extends BodypartHorns

func _init():
	visibleName = "zordian spactors"
	id = "zordianhorns"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianHorns/ZordianHorns.tscn"
