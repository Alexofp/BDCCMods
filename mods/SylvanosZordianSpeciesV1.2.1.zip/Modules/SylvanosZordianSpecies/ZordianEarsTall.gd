extends BodypartEars

func _init():
	visibleName = "zordian ears tall"
	id = "zordianearstall"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianEarsTall/ZordianEarsTall.tscn"
