extends BodypartTail

func _init():
	visibleName = "zordian tail thin"
	id = "zordiantailthin"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianTailThin/ZordianTailThin.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
