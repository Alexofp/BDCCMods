extends BodypartBody

func _init():
	visibleName = "zordian body"
	id = "zordianbody"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianBody/ZordianBody.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
