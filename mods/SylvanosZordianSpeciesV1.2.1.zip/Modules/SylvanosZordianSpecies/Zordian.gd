extends Species

func _init():
	id = "zordian"
	
func getVisibleName():
	return "Zordian"

func getDefaultBody(_gender):
	return "zordianbody"

func getDefaultLegs(_gender):
	return "zordianlegs"

func getDefaultTail(_gender):
	return "zordiantailfluffy"

func isPlayable():
	return true

func getVisibleDescription():
	return "Something doesn’t seem right about this…"

func getDefaultHead(_gender):
	return "zordianheadlong"

func getDefaultHorns(_gender):
	return "zordianhorns"

func getDefaultArms(_gender):
	return "zordianarms"

func getDefaultEars(_gender):
	return "zordianearssharp"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "zordianpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]

func supportsMane():
	return true

func getAllowedBodyparts():
	return ["canineears", "canineears2", "canineears2tribal", "canineears3", "felineears", "felineears2", "fennecears", "lynxears", "lynxears2", "wolfears", "caninetail", "felinetail", "fennectail", "fluffyfelinetail", "foxtail", "huskytail"]

#func npcGenerationWeight():
#	return 0.0

