extends BodypartArms

func _init():
	visibleName = "zordian arms"
	id = "zordianarms"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianArms/ZordianArmsFluffy.tscn"
	else:
		return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianArms/ZordianArms.tscn"
