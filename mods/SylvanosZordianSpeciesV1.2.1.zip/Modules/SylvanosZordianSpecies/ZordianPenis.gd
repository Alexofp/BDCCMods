extends BodypartPenis

func _init():
	visibleName = "zordian penis"
	id = "zordianpenis"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "zordian"])

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianPenis/ZordianPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}

func getVulgarName() -> String:
	return "knotted zordian cock"
