extends BodypartEars

func _init():
	visibleName = "zordian ears sharp"
	id = "zordianearssharp"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianEarsSharp/ZordianEarsSharp.tscn"
