extends Module

func _init():
	id = "SylvanosZordianSpecies"
	author = "Sylvanos & Avery Winters"

	GlobalRegistry.registerSkin("res://Modules/SylvanosZordianSpecies/Skin/SylvanosSkin.gd","Sylvanos")

	bodyparts = [
		"res://Modules/SylvanosZordianSpecies/ZordianArms.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianBody.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianEarsSharp.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianEarsTall.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianHeadLong.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianHeadShort.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianHorns.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianLegs.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianPenis.gd",
		#"res://Modules/SylvanosZordianSpecies/ZordianTailFluffTip.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianTailFluffy.gd",
		"res://Modules/SylvanosZordianSpecies/ZordianTailThin.gd"
	]

	species = [
		"res://Modules/SylvanosZordianSpecies/Zordian.gd",
	]
