extends BodypartHead

func _init():
	visibleName = "zordian head long snout"
	id = "zordianheadlong"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianHeadLong/ZordianHeadLong.tscn"

func getHeadLength():
	return 0.5
