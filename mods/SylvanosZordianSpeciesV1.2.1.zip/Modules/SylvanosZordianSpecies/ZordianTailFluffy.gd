extends BodypartTail

func _init():
	visibleName = "zordian tail fluffy"
	id = "zordiantailfluffy"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianTailFluffy/ZordianTailFluffy.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
