extends BodypartLeg

func _init():
	visibleName = "zordian legs"
	id = "zordianlegs"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianLegs/ZordianLegsFluffy.tscn"
	else:
		return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianLegs/ZordianLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
