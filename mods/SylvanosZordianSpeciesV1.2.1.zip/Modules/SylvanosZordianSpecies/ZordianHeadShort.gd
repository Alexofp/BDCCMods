extends BodypartHead

func _init():
	visibleName = "zordian head shout snout"
	id = "zordianheadshort"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianHeadShort/ZordianHeadShort.tscn"

func getHeadLength():
	return 0.5
