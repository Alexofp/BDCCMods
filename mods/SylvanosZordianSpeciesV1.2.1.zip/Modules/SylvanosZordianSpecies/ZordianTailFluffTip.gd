extends BodypartTail

func _init():
	visibleName = "zordian tail fluff tip"
	id = "zordiantailflufftip"

func getCompatibleSpecies():
	return ["zordian"]

func getDoll3DScene():
	return "res://Modules/SylvanosZordianSpecies/Bodyparts/ZordianTailFluffTip/ZordianTailFluffTip.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
