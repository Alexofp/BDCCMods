extends SkinBase

func _init():
	id = "sylvanosskin"

func getName():
	return "Sylvanos"

func getPatternTexture():
	return preload("res://Modules/SylvanosZordianSpecies/Skin/Sylvanos_Skin1.png")

