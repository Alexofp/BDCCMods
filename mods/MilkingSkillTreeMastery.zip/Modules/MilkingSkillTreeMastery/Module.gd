extends "res://FoxLib/FoxModule.gd"

func _init():
	id = "MilkingSkillTreeMastery"
	author = "Bloxborne"
	
	perks = [
		#Miliking Enterprise
			"res://Modules/MilkingSkillTreeMastery/Perks/MilkingEnterpriseVA.gd",
			"res://Modules/MilkingSkillTreeMastery/Perks/MilkingEnterpriseVB.gd",
			"res://Modules/MilkingSkillTreeMastery/Perks/MilkingEnterpriseVC.gd",
			
		
	]
	
	FoxGameRegistry.addPerkTierLevel("Milking", 15)
