extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "MilkingEnterpriseVB"
	skillGroup = Skill.Milking

func getVisibleName():
	return "Milking Enterprise B"

func getVisibleDescription():
	return "You felt like your Udders could be bigger AND better, You just love having big bouncing Udders to flash to the public~. Your Udders began producing milk [b]250%[/b] faster! AND will grow an extra 3 Sizes while lactating~\n\n(To clerify, if you take this perk the other two perks will become locked)"

func getRequiredPerks():
	return [Perk.MilkFasterProductionV3]

func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)

func getCost():
	return 3

func getPicture():
	return "res://Images/Perks/udder.png"

func getBuffs():
	return [
		buff(Buff.BreastsMilkProductionBuff, [250]),
		buff(Buff.BreastsLactatingSizeLimitBuff, [3]),
	]

func hiddenWhenLocked() -> bool:
	if(GM.pc.hasPerk("MilkingEnterpriseVA") || GM.pc.hasPerk("MilkingEnterpriseVC")):
		return true
	return false

func toggleable() -> bool:
	return false
