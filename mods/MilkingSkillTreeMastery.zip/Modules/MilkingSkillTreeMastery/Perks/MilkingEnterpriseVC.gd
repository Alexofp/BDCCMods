extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "MilkingEnterpriseVC"
	skillGroup = Skill.Milking

func getVisibleName():
	return "Milking Enterprise C"

func getVisibleDescription():
	return "You felt like your Udders could be smaller but denser~, why go bigger when you can get smaller AND more Efficient with it. Your Udders began producing milk [b]250%[/b] faster! And your brests will be 3 Sizes Smaller than your normal max Size!~\n\n(To clerify, if you take this perk the other two perks will become locked)"

func getRequiredPerks():
	return [Perk.MilkFasterProductionV3]

func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)

func getCost():
	return 3

func getPicture():
	return "res://Images/Perks/udder.png"

func getBuffs():
	return [
		buff(Buff.BreastsLactatingSizeLimitBuff, [-3]),
		buff(Buff.BreastsMilkProductionBuff, [250])
	]

func hiddenWhenLocked() -> bool:
	if(GM.pc.hasPerk("MilkingEnterpriseVA") || GM.pc.hasPerk("MilkingEnterpriseVB")):
		return true
	return false

func toggleable() -> bool:
	return false
