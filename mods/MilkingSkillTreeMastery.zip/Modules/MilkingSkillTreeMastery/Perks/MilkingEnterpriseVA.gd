extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "MilkingEnterpriseVA"
	skillGroup = Skill.Milking

func getVisibleName():
	return "Milking Enterprise A"

func getVisibleDescription():
	return "You felt like your Udders could be better, why go bigger when you can get more Efficient with it. Your Udders began producing milk [b]500%[/b] faster!~\n\n(To clerify, if you take this perk the other two perks will become locked)"

func getRequiredPerks():
	return [Perk.MilkFasterProductionV3]

func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)

func getCost():
	return 3

func getPicture():
	return "res://Images/Perks/udder.png"

func getBuffs():
	return [
		buff(Buff.BreastsMilkProductionBuff, [500]),
	]

func hiddenWhenLocked() -> bool:
	if(GM.pc.hasPerk("MilkingEnterpriseVB") || GM.pc.hasPerk("MilkingEnterpriseVC")):
		return true
	return false

func toggleable() -> bool:
	return false
