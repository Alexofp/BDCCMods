extends BodypartLeg

func _init():
	visibleName = "Buff scaled clawed legs"
	id = "buffscaledlegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/ScaledBuff/BuffScaledDigilegs/BuffScaledDigilegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
