extends BodypartArms

func _init():
	visibleName = "Buff scaled clawless arms"
	id = "buffscaledarmsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/ScaledBuff/BuffScaledArmsClawless/BuffScaledArmsClawless.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
