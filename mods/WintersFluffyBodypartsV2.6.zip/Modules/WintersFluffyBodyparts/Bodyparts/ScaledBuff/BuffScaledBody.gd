extends BodypartBody

func _init():
	visibleName = "Buff scaled body"
	id = "buffscaledbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/ScaledBuff/BuffScaledBody/BuffScaledBody.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
