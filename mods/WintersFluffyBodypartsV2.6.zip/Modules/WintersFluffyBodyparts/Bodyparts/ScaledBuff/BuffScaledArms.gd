extends BodypartArms

func _init():
	visibleName = "Buff scaled clawed arms"
	id = "buffscaledarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/ScaledBuff/BuffScaledArms/BuffScaledArms.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
