extends BodypartLeg

func _init():
	visibleName = "Buff scaled clawless legs"
	id = "buffscaledlegsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/ScaledBuff/BuffScaledDigilegsClawless/BuffScaledDigilegsClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
