extends BodypartLeg

func _init():
	visibleName = "Buff fluffy clawless legs"
	id = "buffflufflegsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/FluffyBuff/BuffFluffyDigiLegs/BuffFluffyDigiLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
