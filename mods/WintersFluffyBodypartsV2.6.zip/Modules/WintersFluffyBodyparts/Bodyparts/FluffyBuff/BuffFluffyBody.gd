extends BodypartBody

func _init():
	visibleName = "Buff fluffy body"
	id = "bufffluffbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/FluffyBuff/BuffFluffyBody/BuffFluffyBody.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
