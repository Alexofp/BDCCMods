extends BodypartArms

func _init():
	visibleName = "Scaled clawless arms"
	id = "scaledarmsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/Scaled/ScaledArmsClawless/ScaledArmsClawless.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
