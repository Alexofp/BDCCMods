extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy breasts"
	id = "fluffbreasts"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersFluffyBodyparts/Bodyparts/Fluffy/FluffyBreasts/FluffyBreastsFlat.tscn"
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/Fluffy/FluffyBreasts/FluffyBreasts.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
