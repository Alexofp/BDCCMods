extends BodypartArms

func _init():
	visibleName = "Scruffy clawed arms"
	id = "scruffclawedarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/Scruffy/ScruffyArmsClawed/ScruffyArmsClawed.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
