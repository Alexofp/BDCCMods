extends BodypartBody

func _init():
	visibleName = "Scruffy body with neck fluff"
	id = "scruffbodyneckfluff"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/Scruffy/ScruffyBodyNeckFluff/ScruffyBodyNeckFluff.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
