extends BodypartArms

func _init():
	visibleName = "Scruffy clawless arms"
	id = "scruffarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/Bodyparts/Scruffy/ScruffyArms/ScruffyArms.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
