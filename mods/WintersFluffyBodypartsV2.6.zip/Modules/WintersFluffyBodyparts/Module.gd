extends Module

var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")

func _init():
	id = "WintersFluffyBodyparts"
	author = "Avery Winters (Code Improvements: Selinoccino)"

	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersFluffyBodyparts/Bodyparts/")

func getAddedRatArchetypes() -> Dictionary:
	var pathDir = "res://Modules/WintersCoreModule/CompatabilityPatches/RAT_BodypartArchetypes/"
	
	return {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)
	#Base Species Archetypes
	"canine": [pathDir+"ClawedArchetypes.json"],
	"feline": [pathDir+"ClawedArchetypes.json"],
	"equine": [pathDir+"HoofedArchetypes.json"],
	"dragon": [pathDir+"ScaledArchetypes.json"],
	}
