extends InteractionGoalBase

var action = ""

func getScore(_pawn:CharacterPawn) -> float:
	var listener = _pawn.getChar().skillsHolder.perks["MindMiscCondomListener"]
	if((listener.getAllCondoms().size() > 0)):
		return 0.5
	return 0.0

func getKeepScore() -> float:
	return 1.1

func getText():
	if(action == "pop"):
		return "{main.name} is popping a condom that was left inside them!"
	if(action == "remove"):
		return "{main.name} is carefuly removing a filled condom that was left inside them."
	return "{main.name} is deciding how to deal with the condoms that were left inside them."

func getActions() -> Array:
	var popScore = getPawn().scoreFetish({Fetish.BeingBred: 1.0})
	print("MindMiscModule DealWithCondoms: popScore = "+str(popScore))
	var removeScore = 1.0 - popScore
	return [
		{
			id = "pop",
			name = "Pop a condom",
			desc = "Pop a condom inside you",
			score = popScore,
			args = {},
			time = 60,
		},
		{
			id = "remove",
			name = "Remove a condom",
			desc = "Remove a condom inside you",
			score = removeScore,
			args = {},
			time = 5*60,
		},
	]
	

func doAction(_id:String, _args:Dictionary):
	var listener = getPawn().getChar().skillsHolder.perks["MindMiscCondomListener"]
	var allCondoms = listener.getAllCondomsIDs()
	
	# checking after we remove to stay an extra turn
	if (allCondoms.size() == 0):
		completeGoal()
		return
	
	if(_id == "pop"):
		action = "pop"
		listener.popCondomLiteByID(allCondoms[0])
	if(_id == "remove"):
		action = "remove"
		listener.popCondomLiteByID(allCondoms[0], true)
	
	# This is already handled in popCondomLiteByID
	#getPawn().getChar().addEffect("CondomInflated", ["unknown", allCondoms[0], "remove"])
	return

func getAnimData() -> Array:
	return [StageScene.TFLook, "crotch", {pc="main"}]

func getActivityIcon():
	return RoomStuff.PawnActivity.GiveBirth
