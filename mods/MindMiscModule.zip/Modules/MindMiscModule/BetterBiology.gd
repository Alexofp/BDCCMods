extends PerkBase

func _init():
	id = "MindMiscBetterBiology"
	skillGroup = Skill.CumLover
	dungeonWeight = 0

func getVisibleName():
	return "Better Biology"

func getVisibleDescription():
	return "You love cum too much to let a measly flare push out all of your hard earned liquid white gold."
	
func getMoreDescription():
	return 	"Replaces the Horse Cock effect from the Unique Biology "+\
			"perk\n(Dosen't add any replacement functionality yet)"

func getSkillTier():
	return 1

func getCost():
	return 0
	
func unlockable() -> bool:
	return false

func hiddenWhenLocked() -> bool:
	return true;

# we want to be disabled upon unlock
func runOnceWhenLearned():
	var ch = npc if npc != null else GM.pc
	ch.getSkillsHolder().togglePerk(self.id)

func getPicture():
	return "res://Images/Perks/fortune-cookie.png"

func onSexEvent(_event:SexEvent):
	if(_event.getTargetChar() != npc):
		return
	
	
