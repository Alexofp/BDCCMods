extends StatusEffectBase
# Handles the Visual Elements of CondomInflation

# slot : { Item ### : amount, Item ### : amount}
var condoms = {
	BodypartSlot.Anus : {},
	BodypartSlot.Vagina : {},
	BodypartSlot.Head : {},
}
var amount = 0.0
var MindMiscModule

func _init():
	id = "CondomInflated"
	isSexEngineOnly = false
	MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')

# BodypartSlot, Condom ID, Amount or remove
func initArgs(_args = []):
	if(_args.size() > 2):
		if(typeof(_args[2]) == TYPE_STRING):
			if(_args[2] == "remove"):
				Log.error("MindMiscModule: CondomInflated StatusEffect initArgs() got 'remove' command too early, Nothing to remove yet in init!")
				stop()
				return
			Log.error("MindMiscModule: CondomInflated StatusEffect initArgs() got unknown command: " + _args[2])
			stop()
			return
		if(_args[0] == "unknown"):
			Log.warning("MindMiscModule: CondomInflated StatusEffect initArgs() for condom for unknown hole, ignoring it.")
		condoms[_args[0]][_args[1]] = _args[2]
		updateAmount()
	else:
		Log.error("MindMiscModule: CondomInflated StatusEffect initArgs() got too few arguments")
		stop()

func combine(_args = []):
	if(_args.size() > 2):
		var hole = _args[0]
		var condomID = _args[1]
		var amountToAdd = _args[2]
		if(typeof(amountToAdd) == TYPE_STRING):
			if (amountToAdd == "remove"):
				var foundHole = true
				if(hole == "unknown"):
					foundHole = false
					for slot in condoms:
						if(condomID in condoms[slot].keys()):
							hole = slot
							foundHole = true
				if(foundHole):
					condoms[hole].erase(condomID)
					updateAmount()
				else:
					Log.print("MindMiscModule: CondomInflated StatusEffect combine() couldn't find condom with unique id "+condomID)
			else:
				Log.error("MindMiscModule: CondomInflated StatusEffect combine() got unknown command: " + amountToAdd)
		else:
			if !(condoms[hole].has(condomID)):
				condoms[hole][condomID] = amountToAdd
			else:
				condoms[hole][condomID] += amountToAdd
			updateAmount()
	else:
		Log.error("MindMiscModule: CondomInflated StatusEffect combine() got too few arguments")
		stop()

func updateAmount():
	amount = 0.0
	var foundOne = false
	for slot in condoms:
		for item in condoms[slot]:
			foundOne = true
			amount += condoms[slot][item]
			character.updateNonBattleEffects()
	if !(amount > 0.0):
		stop()
	if !foundOne:
		stop()

func getEffectName():
	return "Condom Inflated"

func getEffectDesc():
	var text:String = "You have an inflated condom in you!"
	var level = calculateBuffLevel()
	if(level > 1.5): text += "\n\nThe massive condom is making it hard to breathe\nThere's no way it can take much more"
	elif(level > 1.0): text += "\n\nThe bloated condom is really filling you"
	elif(level > 0): text += "\n\nIt's applying a nice pressure"
	else: text += "\n\nYou can hardly feel it."
	text += "\n\nIt has "+str(amount)+" ml in it."
	return text

func getEffectImage():
	if(MindMiscModule.extraCumInflationEffectImages):
		if(amount < 3000.0):
			return "res://Modules/MindMiscModule/Images/PleasureBelly.png"
		if(calculateBuffLevel() <= 1.0):
			return "res://Images/StatusEffects/belly.png"
		if(calculateBuffLevel() <= 1.5):
			return "res://Images/StatusEffects/bloating.png"
		return "res://Modules/MindMiscModule/Images/Gravid.png"
	else:
		print("\n"+str(calculateBuffLevel()*2)+"\n")
		if(calculateBuffLevel()*2 <= 4.5):
			return "res://Images/StatusEffects/belly.png"
		return "res://Images/StatusEffects/bloating.png"

func getIconColor():
	return IconColorGreen

func calculateBuffLevel():
	# 5000 = 0.5, 7000 = 1.0, ..., 17000 = 3.5
	return clamp(max(amount - 3000.0, 0.0) / 2000.0, 0.0, 10.0) / 2.0

func getBuffs(): # 3.5 max -> 350%
	return [buff(Buff.InflatedBellyBuff, [clamp(calculateBuffLevel(), 0.0, MindMiscModule.maxCumInflationLevel)*100.0])]

func processSexTurn():
	if(!MindMiscModule.enableCondomInflation):
		stop()
		character.updateNonBattleEffects()
	if(amount <= 0.0):
		stop()
		character.updateNonBattleEffects()

func saveData():
	return {
		"amount": amount,
		"condoms": condoms,
	}

func loadData(_data):
	amount = SAVE.loadVar(_data, "amount", 0.0)
	condoms = SAVE.loadVar(_data, "condoms", {})
	if !(amount > 0.0): updateAmount()
	if(character != null):
		character.updateNonBattleEffects()
	if(!MindMiscModule.enableCondomInflation):
		stop()
		character.updateNonBattleEffects()
