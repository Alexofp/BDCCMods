extends PerkBase

var MindMiscModule

# slot : { condom unique id : [ref, amount], condom unique id [ref, amount]}
var condoms = {
	BodypartSlot.Anus : {},
	BodypartSlot.Vagina : {},
	BodypartSlot.Head : {},
}

# caching, when HoleCreampied fires the condom is already destroyed
var lastUser = {
	BodypartSlot.Anus : "",
	BodypartSlot.Vagina : "",
	BodypartSlot.Head : "",
}
var lastFilled = {
	BodypartSlot.Anus : "",
	BodypartSlot.Vagina : "",
	BodypartSlot.Head : "",
}

# caching, contex dosen't tell us if the dom or sub was the source

func _init():
	id = "MindMiscCondomListener"
	# So it dosen't get wiped on resetPickedPerks
	# Side effect: it shows up as an option at the start of the game...
	skillGroup = Skill.Start
	dungeonWeight = 0
	MindMiscModule = GlobalRegistry.getModules().get("MindMiscModule")

func getVisibleName():
	return "MindMiscCondomListener (You shouldn't be able to see this!)"

func getVisibleDescription():
	return "Handles condom inflation based on SexEvents\n\n"+\
	"This perk should be invisible but pressent on every character\n\n"+\
	"It handles the logic for how many condoms are present, how much is in them, "+\
	"and where in a character they are\n\n"+\
	"This applies the CondomInflated StatusEffect for the visual portion\n\n"+\
	"For now, Only support one condom per orifice"

func getSkillTier():
	return 0

func getCost():
	return 0

func unlockable() -> bool:
	return false

func toggleable() -> bool:
	return false

func hiddenWhenLocked() -> bool:
	return true;

func hiddenWhenUnlocked() -> bool:
	return true

func getAllCondoms():
	var allCondoms = []
	for slot in condoms:
		for condomID in condoms[slot].keys():
			allCondoms.append(condoms[slot][condomID][0])
	return allCondoms

func getAllCondomsIDs():
	var allCondoms = []
	for slot in condoms:
		allCondoms.append_array(condoms[slot].keys())
	return allCondoms

func putCondom(hole, condom):
	if!(condoms.has(hole)):
		Log.error("MindMiscModule CondomListener putCondom(): Condoms dictionary does not have hole "+str(hole)+".")
		return
	if(condom == null):
		Log.error("MindMiscModule CondomListener putCondom(): Condom to put was null")
		return
	var amount = condom.fluids.getFluidAmount()
	condoms[hole][condom.uniqueID] = [condom, "leftIn"]
	npc.addEffect("CondomInflated", [hole, condom.uniqueID, amount])

func popCondomLiteByID(condom, take = false):
	var foundHole = false
	var hole
	for slot in condoms:
		if condom in condoms[slot].keys():
			hole = slot
			foundHole = true
	if !foundHole:
		Log.error("MindMiscModule CondomListener popCondomLite(): Could not find refrenced condom in any slots.")
		return ""
	if !(take):
		condoms[hole][condom][0].fluids.transferTo(npc.getBodypart(hole), 1.0, 0.0, npc.getID())
	npc.addEffect("CondomInflated", [hole, condom, "remove"])
	condoms[hole].erase(condom)
	lastUser[hole] = ""
	lastFilled[hole] = ""
	return hole

func popCondomLite(condom, take = false):
	var foundHole = false
	var hole
	for slot in condoms:
		if condom.uniqueID in condoms[slot].keys():
			hole = slot
			foundHole = true
	if !foundHole:
		Log.error("MindMiscModule CondomListener popCondomLite(): Could not find refrenced condom in any slots.")
		return ""
	if !(take):
		condom.fluids.transferTo(npc.getBodypart(hole), 1.0, 0.0, npc.getID())
	npc.addEffect("CondomInflated", [hole, condom.uniqueID, "remove"])
	condoms[hole].erase(condom.uniqueID)
	lastUser[hole] = ""
	lastFilled[hole] = ""
	return hole

func popCondom(event:SexEvent, hole, condom, popped:bool = false):
	var foundHole = false
	if!(condoms.has(hole)):
		for slot in condoms:
			if condom in condoms[slot].keys():
				hole = slot
				foundHole = true
		if !foundHole:
			Log.error("MindMiscModule CondomListener popCondom(): Condoms dictionary does not have hole "+str(hole)+" and could not find refrenced condom in any slots.")
			return
	if!(condoms[hole].has(condom)):
		Log.warning("MindMiscModule CondomListener popCondom(): Condoms dictionary does not have refrenced condom in hole "+hole+". It probably just popped imediately.")
		return
	var amount = condoms[hole][condom][1]
	condoms[hole][condom][0].fluids.transferTo(event.getTargetChar().getBodypart(hole), 1.0, 0.0, event.getSourceCharID())
	event.getTargetChar().addEffect("CondomInflated", [hole, condom, "remove"])
	condoms[hole][condom][0].destroyMe()
	condoms[hole].erase(condom)
	lastUser[hole] = ""
	lastFilled[hole] = ""
	
	var data = {
		hole = hole,
		loadSize = amount,
		knotted = event.data.knotted,
		MMM_CL_ShouldRun = false,
		}
	
	var newSexEvent:SexEvent = SexEvent.new()
	newSexEvent.type = event.getType()
	newSexEvent.sourceCharID = event.getSourceCharID()
	newSexEvent.targetCharID = event.getTargetCharID()
	newSexEvent.data = data
	newSexEvent.isSexEngine = event.isSexEngineEvent()
	if(event.isSexEngineEvent()):
		newSexEvent.sexEngine = event.getSexEngine()
	
	if(popped):
		event.getSexEngine().addTextRaw("[b]The condom popped![/b]\n")
		newSexEvent.type = SexEvent.HoleCreampied
	
	event.getSourceChar().sendSexEvent(newSexEvent)
	if(event.getTargetChar() != event.getSourceChar()):
		event.getTargetChar().sendSexEvent(newSexEvent)

# Custom SexEvent "CondomLeftIn"
# _sexEngine
# isSexEngine
# "CondomLeftIn"
# _sourceChar
# _targetChar
# data {
# 	_hole
# 	_condom
# }

func onSexEvent(_event:SexEvent):
	if !(_event.getType() in [SexEvent.HoleCreampied, SexEvent.StraponCreampied, SexEvent.FilledCondomInside, SexEvent.HolePenetrated, "CondomLeftIn"]):
		return
	
	var shouldRun = _event.data.get("MMM_CL_ShouldRun", true)
	if !(shouldRun): # Don't trigger on events we fired
		return
	
	if (npc != _event.getTargetChar()):
		return
	
	var _hole = _event.data.hole
	var _loadSize
	if !(_event.getType() in [SexEvent.HolePenetrated, "CondomLeftIn"]):
		_loadSize = _event.data.loadSize
	var condom = _event.getSourceChar().getWornCondom()
	
	# This variable is a peice of shit, I hate it, all inconsistent 'n shit
	var _condomBroke = false
	if(_event.data.get("condomBroke") != null):
		_condomBroke = _event.data.condomBroke
	elif(condom == null):
		_condomBroke = true
	
	match _event.getType():
		
		"CondomLeftIn": # Custom Sex Event
			condom = _event.data.condom
			# Oral dosen't fire SexEvent.FilledCondomInside
			# so we have to assum it isn't already in the condoms dictionary
			condoms[_hole][condom.uniqueID] = [condom, "leftIn"]
			if(_hole == BodypartSlot.Head):
				_event.getTargetChar().addEffect("CondomInflated", [_hole, condom.uniqueID, condom.fluids.getFluidAmount()])
			Log.print("MindMiscModule CondomListener: Marking condom in "+_event.getTargetCharID()+"'s "+_hole+" as 'left in'.")
		
		# Help with tracking
		SexEvent.HolePenetrated:
			var userLastFilled = lastUser.find_key(_event.getSourceCharID())
			if(userLastFilled != null):
				if(userLastFilled != _hole):
					var lastCondom = lastFilled[userLastFilled]
					if(condom.uniqueID == lastCondom):
						# move the condom, we switched holes
						if(condoms[userLastFilled].has(condom.uniqueID)):
							condoms[_hole][condom.uniqueID] = condoms[userLastFilled][condom.uniqueID]
						else:
							condoms[_hole][condom.uniqueID] = [condom, condom.fluids.getFluidAmount()]
						_event.getTargetChar().addEffect("CondomInflated", [_hole, condom.uniqueID, condoms[_hole][condom.uniqueID][1]])
						Log.print("MindMiscModule CondomListener: Moving condom from "+_event.getTargetCharID()+"'s "+userLastFilled+" to their "+_hole+".")
						_event.getTargetChar().addEffect("CondomInflated", [userLastFilled, lastCondom, "remove"])
						condoms[userLastFilled].erase(lastCondom)
					if(condoms[userLastFilled].has(lastCondom)):
						if(typeof(condoms[userLastFilled][lastCondom][1]) != TYPE_STRING):
							# remove the condom, it wasn't left in
							Log.print("MindMiscModule CondomListener: Removing condom from "+_event.getTargetCharID()+"'s "+userLastFilled+" because we think it was taken off.")
							_event.getTargetChar().addEffect("CondomInflated", [userLastFilled, lastCondom, "remove"])
							condoms[userLastFilled].erase(lastCondom)
						elif(condoms[userLastFilled][lastCondom][1] != "leftIn"):
							# remove the condom, it wasn't left in
							Log.print("MindMiscModule CondomListener: Removing condom from "+_event.getTargetCharID()+"'s "+userLastFilled+" because we think it was taken off.")
							_event.getTargetChar().addEffect("CondomInflated", [userLastFilled, lastCondom, "remove"])
							condoms[userLastFilled].erase(lastCondom)
					lastUser[userLastFilled] = ""
					lastFilled[userLastFilled] = ""
			if(condom != null):
				lastUser[_hole] = _event.getSourceCharID()
				lastFilled[_hole] = condom.uniqueID
		
		# if condom broke, release contents inside
		SexEvent.HoleCreampied, SexEvent.StraponCreampied:
			
			if !_condomBroke: return
			
			var userLastFilled = lastUser.find_key(_event.getSourceCharID())
			if (userLastFilled != _hole):
				Log.error("MindMiscModule CondomListener: Condom broke in "+_event.getTargetCharID()+"'s "+_hole+", but their partner's last filled condom was in their "+userLastFilled+"! "+_event.getTargetCharID()+" might have some stale data! Marking it as 'left in' so that it can be removed.")
				var strayCondom = lastFilled[userLastFilled]
				condoms[userLastFilled][strayCondom] = "leftIn"
			var brokenCondom = lastFilled[_hole]
			_event.getTargetChar().addEffect(
				"CondomInflated", [_hole, brokenCondom, "remove"])
			
			popCondom(_event, _hole, brokenCondom, false)
			Log.print("MindMiscModule CondomListener: Condom Broke in "+_event.getTargetCharID()+"'s "+_hole+".")
		
		# inflate belly with amount
		SexEvent.FilledCondomInside:
			if !(condoms[_hole].has(condom.uniqueID)):
				condoms[_hole][condom.uniqueID] = [condom, _loadSize]
			else:
				condoms[_hole][condom.uniqueID][0] = condom
				condoms[_hole][condom.uniqueID][1] += _loadSize
			lastUser[_hole] = _event.getSourceCharID()
			lastFilled[_hole] = condom.uniqueID
			_event.getTargetChar().addEffect("CondomInflated", [_hole, condom.uniqueID, _loadSize])
			
			if(MindMiscModule.condomPopping):
				var condomStressedAt = MindMiscModule.condomStressedAt
				var condomMax = MindMiscModule.condomMax
				var condomMod = (condomMax - condomStressedAt) / 100
				if(RNG.chance((condom.fluids.getFluidAmount() - condomStressedAt) / condomMod)):
					popCondom(_event, _hole, condom.uniqueID, true)
					return
			
			if(MindMiscModule.debug):
				print("MindMiscModule CondomListener DUBUG: characterID = "+_event.getTargetCharID()+", hole = "+_hole+", condomRef = "+str(condom)+", condomUniqueID = "+str(condom.uniqueID)+", loadSize = "+str(_loadSize)+", condomFluidAmount = "+str(condom.fluids.getFluidAmount()))
			Log.print("MindMiscModule CondomListener: Condom filled in "+_event.getTargetCharID()+"'s "+_hole+" with "+str(_loadSize)+" ml.")

func onSexEnded(_contex = {}):
	var _sexEngine:SexEngine = _contex["sexEngine"]
	
	for slot in condoms:
		for condomID in condoms[slot]:
			if(typeof(condoms[slot][condomID][1]) == TYPE_STRING):
				if(condoms[slot][condomID][1] != "leftIn"):
					npc.addEffect("CondomInflated", [slot, condomID, "remove"])
					Log.warning("MindMiscModule CondomListener: Removing Condom from "+npc.getID()+"'s "+slot+" because sex ended, but it was marked as "+condoms[slot][condomID][1]+".")
					condoms[slot].erase(condomID)
			else:
				npc.addEffect("CondomInflated", [slot, condomID, "remove"])
				Log.print("MindMiscModule CondomListener: Removing Condom from "+npc.getID()+"'s "+slot+" because sex ended, because it wasn't marked as 'leftIn'.")
				condoms[slot].erase(condomID)
	
	# Clear Cache
	lastUser = {
		BodypartSlot.Anus : "",
		BodypartSlot.Vagina : "",
		BodypartSlot.Head : "",
	}
	lastFilled = {
		BodypartSlot.Anus : "",
		BodypartSlot.Vagina : "",
		BodypartSlot.Head : "",
	}

func saveData():
	return {
		"condoms": condoms,
		"lastUser": lastUser,
		"lastFilled": lastFilled,
	}

func loadData(_data):
	condoms = SAVE.loadVar(_data, "condoms", {
			BodypartSlot.Anus : {},
			BodypartSlot.Vagina : {},
			BodypartSlot.Head : {},
		})
	lastUser = SAVE.loadVar(_data, "lastUser", {
			BodypartSlot.Anus : "",
			BodypartSlot.Vagina : "",
			BodypartSlot.Head : "",
		})
	lastFilled = SAVE.loadVar(_data, "lastFilled", {
			BodypartSlot.Anus : "",
			BodypartSlot.Vagina : "",
			BodypartSlot.Head : "",
		})
