extends GlobalTask

func _init():
	id = "TaskDealWithCondoms"
	goalID = "DealWithCondoms"
	maxAssignedUnscaled = 30

func canDoTask(_pawn:CharacterPawn) -> bool:
	var listener = _pawn.getChar().skillsHolder.perks["MindMiscCondomListener"]
	if(listener.getAllCondoms().size() > 0):
		return true
	return false
