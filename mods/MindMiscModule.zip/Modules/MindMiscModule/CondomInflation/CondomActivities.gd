extends SexActivityBase

func _init():
	id = "MindMiscModuleCondomActivities"
	startedByDom = true
	startedBySub = false
	
	activityName = "Condom Activities"
	activityDesc = "Activites involving Condoms from Mind Misc Module"
	activityCategory = []

func getGoals():
	return {
		#SexGoal.SubUndressDom: 1.0, # Custom sex goal?
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: true,
		SexType.SlutwallSex: true,
		SexType.BitchsuitSex: true,
	}

# This is AI goal stuff, not actually used yet
func getActivityBaseScore(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	var baseMod:float = 0.01
	if(_sexEngine.hasTag(_domInfo.charID, SexActivityTag.PenisUsed) || _sexEngine.hasTag(_domInfo.charID, SexActivityTag.VaginaUsed) || _sexEngine.hasTag(_domInfo.charID, SexActivityTag.AnusUsed)):
		baseMod = 1.0
	
	return baseMod + max(_domInfo.fetishScore({Fetish.Exhibitionism: 0.1}), 0.0)

func getStartActions(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	var dom:BaseCharacter = _domInfo.getChar()
	# Maybe I'll figure out SexGoals later 
	var theScore:float = 0.1 #getActivityScore(_sexEngine, _domInfo, _subInfo)
	
	# Kinda hacky, won't work if an activity uses a knotted state other than "knotting"
	# but I can add additional states to the list if I find them
	var knotted = false
	if(_sexEngine.activities.size() > 0):
		knotted = (_sexEngine.activities[0].getState() in ["knotting"])
	
	if(_domInfo.justCame && _sexEngine.hasTag(_domInfo.charID, SexActivityTag.PenisUsed) &&
		(dom.getWornCondom() != null)):
			addStartAction(["SourceTiedOff", knotted], "Leave Condom in", "Pull out and tie off the condom, leaving it inside them", theScore)
	
	if(_subInfo.justCame && _sexEngine.hasTag(_subInfo.charID, SexActivityTag.PenisUsed) &&
		(_subInfo.getChar().getWornCondom() != null)):
			addStartAction(["TargetTiedOff", knotted], "Leave Condom in", "Have them pull out and tie off the condom, leaving it inside you", theScore)

func startActivity(_args):
	var _theAction = _args[0]
	var knotting = _args[1]
	
	var pulloutVerb:String = RNG.pick(["'pull'", "'slide'",])
	var wombText:String = RNG.pick(["pussy", "vagina", "babymaker", "cunt",])
	var assText:String = RNG.pick(["ass", "butt",])
	var mouthText:String = RNG.pick(["mouth", "face", "maw",])
	var cockText:String = RNG.pick(["cock", "dick", "member",])
	if(knotting): cockText = RNG.pick(["cock", "dick", "member", "knot",])
	
	var text:String = ""
	var usedBodypart:String = BodypartSlot.Anus # fallback
	
	var _condom:ItemBase
	
	# Custom SexEvent "CondomLeftIn"
	# _sexEngine
	# isSexEngine
	# "CondomLeftIn"
	# _sourceChar
	# _targetChar
	# data {
	# 	_hole
	# 	_condom
	# }
	#sendSexEvent("CondomLeftIn", dom, sub, {usedBodypart, condom})
	
	# Dom wearing condom, Dom tying condom
	if(_theAction == "SourceTiedOff"):
		usedBodypart = getUsed(getSubID())
		if(usedBodypart == BodypartSlot.Anus):
			wombText = assText
		if(usedBodypart == BodypartSlot.Head):
			wombText = mouthText
		text += "{dom.You} {dom.youVerb("+pulloutVerb+")} {dom.yourHis} "+cockText+" out of {sub.your} "+wombText+" and {dom.youVerb('tie')} off the condom, leaving it inside {sub.youHim}."
		_condom = getDom().getWornCondom()
		sendSexEvent("CondomLeftIn", DOM_0, SUB_0, {hole = usedBodypart, condom = _condom})
		_condom.destroyMe()
		fetishAffect(SUB_0, Fetish.Condoms, 5.0)
		fetishAffect(DOM_0, Fetish.Condoms, 5.0)
		getSubInfo().addArousalSex(0.05)
		addText(text)
		endActivity()
		return
	
	# Sub wearing condom, Dom tying condom
	if(_theAction == "TargetTiedOff"):
		usedBodypart = getUsed(getDomID())
		if(usedBodypart == BodypartSlot.Anus):
			wombText = assText
		if(usedBodypart == BodypartSlot.Head):
			wombText = mouthText
		text += "{dom.You} {dom.youVerb("+pulloutVerb+")} {dom.yourself} off of {sub.your} "+cockText+" and {dom.youVerb('tie')} off the condom, leaving it inside {dom.youHim}"
		_condom = getSub().getWornCondom()
		sendSexEvent("CondomLeftIn", SUB_0, DOM_0, {hole = usedBodypart, condom = _condom})
		_condom.destroyMe()
		fetishAffect(SUB_0, Fetish.Condoms, 5.0)
		fetishAffect(DOM_0, Fetish.Condoms, 5.0)
		getDomInfo().addArousalSex(0.05)
		addText(text)
		endActivity()
		return
	
	endActivity()
	return

func getUsed(_id):
	if(getSexEngine().hasTag(_id, SexActivityTag.VaginaUsed)):
		return BodypartSlot.Vagina
	if(getSexEngine().hasTag(_id, SexActivityTag.AnusUsed)):
		return BodypartSlot.Anus
	return BodypartSlot.Head
