extends "res://Scenes/SceneBase.gd"

var inventoryScreenScene = preload("res://UI/Inventory/InventoryScreen.tscn")

var savedItemUniqueID = ""
var theSavedItem
var holeUsed = ""

func _init():
	sceneID = "MindMiscModuleCondomInteractionScene"

func _run():
	if(state == ""):
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		var allCondomsInside = condomListener.getAllCondoms()
		var allCondomsInventory = GM.pc.inventory.getAllOf("UsedCondom")
		
		GM.ui.say("Put a condom inside you or interact with condoms already inside you.")
		
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
		if(allCondomsInventory.size() > 0):
			addButton("Put in", "Put a condom inside you", "putIn")
		else:
			addDisabledButton("Put In", "You don't have any used condoms to put inside")
		if(allCondomsInside.size() > 0):
			addButton("Inside", "Interact with condoms already inside you", "inside")
		else:
			addDisabledButton("Inside", "You don't have any condoms inside you to interact with")
	
	if(state == "inside"):
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		var allCondomsInside = condomListener.getAllCondoms()
		var inventory = inventoryScreenScene.instance()
		GM.ui.addFullScreenCustomControl("inventory", inventory)
		inventory.shouldGroup = false
		var _ok = inventory.connect("onItemSelected", self, "onInventoryItemSelected")
		inventory.setItems(allCondomsInside, "")
		addButtonAt(3, "Back", "Stop interacting with condoms already inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(state == "insidePop"):
		var bodypartText:String = ""
		var vaginaText:String = RNG.pick(["vagina", "pussy",])
		var assText:String = RNG.pick(["ass", "butt",])
		var mouthText:String = RNG.pick(["mouth", "maw", "gullet"])
		
		match holeUsed:
			BodypartSlot.Vagina: bodypartText = vaginaText
			BodypartSlot.Anus: bodypartText = assText
			BodypartSlot.Head: bodypartText = mouthText
		
		GM.ui.say("You reach into your "+bodypartText+" for a condom...\n"+\
			"You find it and grab the end, pinching and pulling it to make it pop!")
		
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		var allCondomsInside = condomListener.getAllCondoms()
		if(allCondomsInside.size() > 0):
			addButton("Continue", "Keep interacting with condoms already inside you", "inside")
		else:
			addDisabledButton("Continue", "You don't have any more condoms inside you to interact with")
		addButtonAt(3, "Back", "Stop interacting with condoms already inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(state == "insideTake"):
		var bodypartText:String = ""
		var vaginaText:String = RNG.pick(["vagina", "pussy",])
		var assText:String = RNG.pick(["ass", "butt",])
		var mouthText:String = RNG.pick(["mouth", "maw", "gullet"])
		
		match holeUsed:
			BodypartSlot.Vagina: bodypartText = vaginaText
			BodypartSlot.Anus: bodypartText = assText
			BodypartSlot.Head: bodypartText = mouthText
		
		GM.ui.say("You reach into your "+bodypartText+" for a condom...\n"+\
			"You find it and grab the end, carefully pulling it out of you and putting it away.")
		
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		var allCondomsInside = condomListener.getAllCondoms()
		if(allCondomsInside.size() > 0):
			addButton("Continue", "Keep interacting with condoms already inside you", "inside")
		else:
			addDisabledButton("Continue", "You don't have any more condoms inside you to interact with")
		addButtonAt(3, "Back", "Stop interacting with condoms already inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(state == "putIn"):
		var allCondomsInventory = GM.pc.inventory.getAllOf("UsedCondom")
		var inventory = inventoryScreenScene.instance()
		GM.ui.addFullScreenCustomControl("inventory", inventory)
		inventory.shouldGroup = false
		var _ok = inventory.connect("onItemSelected", self, "onInventoryItemSelected")
		inventory.setItems(allCondomsInventory)
		addButtonAt(3, "Back", "Stop putting condoms inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(state == "putInAss"):
		var assText:String = RNG.pick(["ass", "butt",])
		
		GM.ui.say("You choose a condom from your loot and bring it toward your "+assText+".\n"+\
			"You relax your muscles and carefuly press it in, shoving it deep inside")
		
		var allCondomsInventory = GM.pc.inventory.getAllOf("UsedCondom")
		if(allCondomsInventory.size() > 0):
			addButton("Continue", "Keep putting condoms inside you", "putIn")
		else:
			addDisabledButton("Continue", "You don't have any more used condoms to put inside")
		addButtonAt(3, "Back", "Stop putting condoms inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(state == "putInVagina"):
		var vaginaText:String = RNG.pick(["vagina", "pussy", "snatch", "cunt",])
		
		GM.ui.say("You choose a condom from your loot and bring it toward your "+vaginaText+".\n"+\
			"You spread your folds and carefuly press it in, the rythmic movements of your inner walls pulling it deep inside")
		
		var allCondomsInventory = GM.pc.inventory.getAllOf("UsedCondom")
		if(allCondomsInventory.size() > 0):
			addButton("Continue", "Keep putting condoms inside you", "putIn")
		else:
			addDisabledButton("Continue", "You don't have any more used condoms to put inside")
		addButtonAt(3, "Back", "Stop putting condoms inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(state == "putInMouth"):
		var mouthText:String = RNG.pick(["mouth", "maw", "gullet", "face",])
		
		GM.ui.say("You choose a condom from your loot and bring it toward your "+mouthText+".\n"+\
			"You carefuly press it in, swallowing hard, letting it sink deep inside.")
		
		var allCondomsInventory = GM.pc.inventory.getAllOf("UsedCondom")
		if(allCondomsInventory.size() > 0):
			addButton("Continue", "Keep putting condoms inside you", "putIn")
		else:
			addDisabledButton("Continue", "You don't have any more used condoms to put inside")
		addButtonAt(3, "Back", "Stop putting condoms inside you", "back")
		addButtonAt(4, "Close", "Close the inventory", "endthescene")

func _react(_action:String, _args):
	
	if(_action == "back"):
		GM.ui.clearButtons()
		GM.ui.clearUItextboxes()
		savedItemUniqueID = ""
		state = ""
		return
	
	if(_action == "inside"):
		GM.ui.clearButtons()
		state = "inside"
		return
	
	if(_action == "insidePop"):
		GM.ui.clearButtons()
		GM.ui.clearUItextboxes()
		var condomToPop = theSavedItem
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		holeUsed = condomListener.popCondomLite(condomToPop)
		state = "insidePop"
		return
	
	if(_action == "insideTake"):
		GM.ui.clearButtons()
		GM.ui.clearUItextboxes()
		var condomToPop = theSavedItem
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		holeUsed = condomListener.popCondomLite(condomToPop, true)
		GM.pc.inventory.addItem(condomToPop)
		state = "insideTake"
		return
	
	if(_action == "putIn"):
		GM.ui.clearButtons()
		state = "putIn"
		return
	
	if(_action == "putInAss"):
		GM.ui.clearButtons()
		GM.ui.clearUItextboxes()
		var condomToPut = theSavedItem
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		condomListener.putCondom(BodypartSlot.Anus, condomToPut)
		GM.pc.inventory.removeItem(condomToPut)
		state = "putInAss"
		return
	
	if(_action == "putInVagina"):
		GM.ui.clearButtons()
		GM.ui.clearUItextboxes()
		var condomToPut = theSavedItem
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		condomListener.putCondom(BodypartSlot.Vagina, condomToPut)
		GM.pc.inventory.removeItem(condomToPut)
		state = "putInVagina"
		return
	
	if(_action == "putInMouth"):
		GM.ui.clearButtons()
		GM.ui.clearUItextboxes()
		var condomToPut = theSavedItem
		var condomListener = GM.pc.skillsHolder.perks["MindMiscCondomListener"]
		condomListener.putCondom(BodypartSlot.Head, condomToPut)
		GM.pc.inventory.removeItem(condomToPut)
		state = "putInMouth"
		return
	
	if(_action == "endthescene"):
		GM.ui.clearUItextboxes()
		endScene([false]) # Even more I dunno, probably to close or not to close the Me menu
		return

func _react_scene_end(_tag, _result):
	setState("")

func onInventoryItemSelected(item: ItemBase):
	GM.ui.clearButtons()
	addButtonAt(3, "Back", "Stop interacting with condoms already inside you", "back")
	addButtonAt(4, "Close", "Close the inventory", "endthescene")
	
	if(item == null):
		return
	theSavedItem = item
	savedItemUniqueID = item.getUniqueID()
	
	if(state == "inside"):
		addButton("Pop it", "Pop this condom to make it release it's contents inside you", "insidePop")
		addButton("Take it out", "Take this condom out of you and put it away", "insideTake")
	if(state == "putIn"):
		if(GM.pc.getBodypart(BodypartSlot.Anus) != null):
			addButton("Ass", "Put this condom in your ass", "putInAss")
		else:
			addDisabledButton("Ass", "You don't have an ass")
		if(GM.pc.getBodypart(BodypartSlot.Vagina) != null):
			addButton("Vagina", "Put this condom in your pussy", "putInVagina")
		else:
			addDisabledButton("Vagina", "You don't have a vagina")
		if(GM.pc.getBodypart(BodypartSlot.Head) != null):
			addButton("Mouth", "Put this condom in your mouth", "putInMouth")
		else:
			addDisabledButton("Mouth", "You don't have a... Head?")

func saveData():
	var data = .saveData()
	
	data["savedItemUniqueID"] = savedItemUniqueID
	data["holeUsed"] = holeUsed
	
	return data

func loadData(data):
	.loadData(data)
	
	savedItemUniqueID = SAVE.loadVar(data, "savedItemUniqueID", "")
	holeUsed = SAVE.loadVar(data, "holeUsed", "")
	theSavedItem = sceneSavedItemsInv.getItemByUniqueID(savedItemUniqueID)

func supportsShowingPawns() -> bool:
	return true
