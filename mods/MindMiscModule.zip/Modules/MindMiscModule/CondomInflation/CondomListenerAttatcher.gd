extends GameExtender
# Ensures the CondomListener Perk is added to all characters

func _init():
	id = "CondomListenerAttatcher"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.pcUpdateNonBattleEffects)
	_GES.register(self, ExtendGame.npcUpdateNonBattleEffects)

func pcUpdateNonBattleEffects(_pc:Player):
	if !(_pc.hasPerk("MindMiscCondomListener")):
		_pc.skillsHolder.addPerk("MindMiscCondomListener")

func npcUpdateNonBattleEffects(_npc:Character):
	if !(_npc.hasPerk("MindMiscCondomListener")):
		_npc.skillsHolder.addPerk("MindMiscCondomListener")
