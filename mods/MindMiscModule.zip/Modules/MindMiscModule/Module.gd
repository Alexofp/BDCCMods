extends Module

# Debug - save modified code to user folder
var debug = false

# defaults so we still work without FoxLib
var maxCumInflationLevel:float = 2.0
var enableCondomInflation:bool = true
var preventDisableChildPerks:bool = true
var extraCumInflationEffectImages:bool = true

# [ targetFile1, [
#	[ PlaceBeforeTarget1, Target1, PlaceAfterTarget1 ], 
#	[ PlaceBeforeTarget2, Target2, PlaceAfterTarget2 ],
#	]],
# [ targetFile2, [
#	[ PlaceBeforeTarget3, Target3, PlaceAfterTarget3 ],
#	]],
# ]

# make sure your \n and \t are correct or the script won't parse!
# you can use +\ to split the string over multiple lines making it easier to read

var hooks = [
	["res://Game/BaseCharacter.gd", [
		["var MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')"+\
		"\n\t#", "pregnancyValue += clamp(cumInflationLevel / 2.0, 0.0, 1.0)",
		"\n\tpregnancyValue += clamp(cumInflationLevel / 2.0, 0.0, MindMiscModule.maxCumInflationLevel)"],
	]],
	["res://Game/SexEngine/SexActivity/DomRidingSubVaginal.gd", [
		["if((state in ['knotting', 'inside']) and getDom().hasPerk('MindMiscInsatiableDesire')):"+\
		"\n\t\t\taddAction('milkknot', 5.0, 'Milk it', 'Keep them cumming')"+\
		"\n\t\t", 'if(state in ["knotting"]):', ""],
		['if(_id == "milkknot"):'+\
		'\n\t\tvar knotting:bool = state in ["knotting"]'+\
		'\n\t\tvar cockText:String = RNG.pick(["cock", "dick", "member"])'+\
		'\n\t\tif(knotting): cockText = RNG.pick(["cock", "dick", "member", "knot"])'+\
		'\n\t\tvar wombText:String = RNG.pick(["womb", "womb", "babymaker",])'+\
		'\n\t\tif(usedBodypart == BodypartSlot.Anus):'+\
		'\n\t\t\twombText = RNG.pick(["ass", "butt",])'+\
		'\n\t\tvar text:String = ""'+\
		'\n\t\tvar condomBroke:bool = false'+\
		'\n\t\tvar penis:BodypartPenis = getSub().getBodypart(BodypartSlot.Penis)'+\
		'\n\t\tif(penis == null): return'+\
		'\n\t\tvar cumProduction:FluidProduction = penis.getFluidProduction()'+\
		'\n\t\tif(cumProduction ==null): return'+\
		'\n\t\tcumProduction.fillPercent(0.2)'+\
		'\n\t\tgetDom().gotOrificeStretchedBy(usedBodypart, getSubID(), knotting, 0.2)'+\
		'\n\t\ttext += "{dom.You} "+RNG.pick(["{dom.youVerb(\'milk\')}", "{dom.youVerb(\'grind\')} on"])+" {sub.yourHis} "+cockText+" making {sub.youHim} cum again!"'+\
		'\n\t\ttext += " Waves after waves of sticky "+RNG.pick(["cum", "seed", "jizz", "semen"])+" flow into {dom.yourHis} "+wombText+"."'+\
		'\n\t\tvar condom:ItemBase = getSub().getWornCondom()'+\
		'\n\t\tif(condom != null):'+\
		'\n\t\t\tvar popped:bool = false'+\
		'\n\t\t\tvar condomFluids:Fluids = condom.fluids'+\
		'\n\t\t\tvar condomFluidAmount = condomFluids.getFluidAmount()'+\
		'\n\t\t\tvar breakChance = condom.getCondomBreakChance()'+\
		'\n\t\t\tcondomBroke = getSub().shouldCondomBreakWhenFucking(getDom(), breakChance)'+\
		'\n\t\t\tvar MindMiscModule = GlobalRegistry.getModules().get("MindMiscModule")'+\
		'\n\t\t\tif(MindMiscModule.enableCondomInflation):'+\
		'\n\t\t\t\tif(condomFluidAmount > 9500.0):'+\
		'\n\t\t\t\t\tif(RNG.chance((condomFluidAmount - 9500.0)/150)):'+\
		'\n\t\t\t\t\t\tpopped = true'+\
		'\n\t\t\t\t\t\tcondomBroke = true'+\
		'\n\t\t\t\tif(!getDom().hasEffect("CondomInflated")):'+\
		'\n\t\t\t\t\tif(condomFluidAmount > 0.0):'+\
		'\n\t\t\t\t\t\tgetDom().addEffect("CondomInflated", [condomFluidAmount])'+\
		'\n\t\t\tif(condomBroke):'+\
		'\n\t\t\t\tif(popped):'+\
		'\n\t\t\t\t\ttext = "[b]The condom popped![/b]\\n"+text'+\
		'\n\t\t\t\telse:'+\
		'\n\t\t\t\t\ttext = "[b]The condom broke![/b]\\n"+text'+\
		'\n\t\t\t\tif(MindMiscModule.enableCondomInflation):'+\
		'\n\t\t\t\t\tgetDom().addEffect("CondomInflated", [(condomFluidAmount*-1)])'+\
		'\n\t\t\t\t\tsendSexEvent(SexEvent.HoleCreampied, SUB_0, DOM_0, {hole=usedBodypart,loadSize=condomFluidAmount,knotted=knotting,engulfed=true})'+\
		'\n\t\t\t\t\tgetDom().updateNonBattleEffects()'+\
		'\n\t\t\t\t\tcondomFluids.transferTo(getDom().getBodypart(usedBodypart), 1.0, 0.0, getSubID())'+\
		'\n\t\t\t\tcondom.destroyMe()'+\
		'\n\t\t\t\tfetishUp(SUB_0, Fetish.Condoms, -15.0)'+\
		'\n\t\t\t\tfetishUp(DOM_0, Fetish.Condoms, -20.0)'+\
		'\n\t\t\telse:'+\
		'\n\t\t\t\tfetishAffect(SUB_0, Fetish.Condoms, 3.0)'+\
		'\n\t\t\t\tfetishAffect(DOM_0, Fetish.Condoms, 3.0)'+\
		'\n\t\t\t\tvar loadSize = getSub().cumInItem(condom)'+\
		'\n\t\t\t\tif(MindMiscModule.enableCondomInflation):'+\
		'\n\t\t\t\t\tgetDom().addEffect("CondomInflated", [loadSize])'+\
		'\n\t\t\t\t\tgetDom().updateNonBattleEffects()'+\
		'\n\t\t\t\tgetSubInfo().cum()'+\
		'\n\t\t\t\tgetDomInfo().addArousalSex(0.02)'+\
		'\n\t\t\t\tsendSexEvent(SexEvent.FilledCondomInside, SUB_0, DOM_0, {hole=usedBodypart,loadSize=loadSize,knotted=knotting,engulfed=true})'+\
		'\n\t\t\t\tsatisfyGoals()'+\
		'\n\t\t\t\taddText(text)'+\
		'\n\t\t\t\treturn'+\
		'\n\t\tgetDom().cummedInBodypartByAdvanced(usedBodypart, getSubID(), {knotted=knotting,condomBroke=condomBroke,engulfed=true})'+\
		'\n\t\tgetSubInfo().cum()'+\
		'\n\t\tsatisfyGoals()'+\
		'\n\t\tgetDomInfo().addArousalSex(0.05)'+\
		'\n\t\taddText(text)'+\
		'\n\t\treturn'+\
		"\n\t", 'if(_id == "rub"):', ""],
	]],
	["res://Skills/Perk/CumUniqueBiology.gd", [
		["func runOnceWhenLearned():"+\
		"\n\tif(!npc.getSkillsHolder().hasPerkDisabledOrNot('MindMiscBetterBiology')):"+\
		"\n\t\tnpc.getSkillsHolder().addPerk('MindMiscBetterBiology')\n\n"+\
		"func onPerkToggled(_isEnabledNow):"+\
		"\n\tif(!npc.getSkillsHolder().hasPerkDisabledOrNot('MindMiscBetterBiology')):"+\
		"\n\t\tnpc.getSkillsHolder().addPerk('MindMiscBetterBiology')"+\
		"\n\n", "func onSexEvent", ""],
		["if npc.hasPerk('MindMiscBetterBiology'): return\n\t\t\t", "if(hasFlare):", ""],
	]],
	["res://Skills/Skill/CumLover.gd", [
		["", "[10],", "\n\t\t[15],"],
	]],
	["res://Skills/SkillsHolder.gd", [
		["func NEWtogglePerk(perkID):"+\
		"\n\tif(!perks.has(perkID)): return"+\
		"\n\tif(disabledPerks.has(perkID) && disabledPerks[perkID]):"+\
		"\n\t\tvar perk = perks[perkID]"+\
		"\n\t\tdisabledPerks.erase(perkID)"+\
		"\n\t\tperk.onPerkToggled(true)"+\
		"\n\telse:"+\
		"\n\t\tdisabledPerks[perkID] = true"+\
		"\n\t\tperks[perkID].onPerkToggled(false)"+\
		"\n", "func togglePerk(perkID):", "\n\tvar MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')"+\
		"\n\tif(!MindMiscModule.preventDisableChildPerks):"+\
		"\n\t\tOGtogglePerk(perkID)"+\
		"\n\telse: NEWtogglePerk(perkID)"+\
		"\nfunc OGtogglePerk(perkID):"],
	]],
	["res://StatusEffect/CumInflated.gd", [
		["func NEWgetEffectImage():"+\
		"\n\tvar cumInflationLevel = character.getCumInflationLevel()"+\
		"\n\tif(cumInflationLevel <= 1.0): return 'res://Images/StatusEffects/belly.png'"+\
		"\n\tif(cumInflationLevel <= 1.5): return 'res://Images/StatusEffects/bloating.png'"+\
		"\n\treturn 'res://Modules/MindMiscModule/Images/Gravid.png'"+\
		"\n", "func getEffectImage():", "\n\tvar MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')"+\
		"\n\tif(!MindMiscModule.extraCumInflationEffectImages):"+\
		"\n\t\treturn OGgetEffectImage()"+\
		"\n\telse: return NEWgetEffectImage()"+\
		"\nfunc OGgetEffectImage():"],
	]]
]

var hooksHolder = []

func exportModifiedFile(fileName, fileContent):
	var file = File.new()
	var path = "user://MindHookDebugExports/"
	var fullPath = path + fileName
	print("Exporting to "+ fullPath)
	var error = file.open(fullPath, File.WRITE)
	if(!error):
		file.store_line(fileContent)
		file.close()
	else: print("Error "+str(error)+" opening path: "+fullPath)

func _init():
	id = "MindMiscModule"
	author = "Mindstormsman"
	
	if(debug):
		var dir = Directory.new()
		var error = dir.make_dir("user://MindHookDebugExports")
		if(error and (error != 32)):
			print("Error "+str(error)+" creating directory user://MindHookDebugExports")
			debug = false
	
	for target in hooks:
		var codeBase = load(target[0])
		var originalCode = codeBase.source_code
		var modifiedCode = originalCode
		for hook in target[1]:
			modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
		codeBase.source_code = modifiedCode
		codeBase.reload()
		hooksHolder.append(codeBase)
		if(debug): exportModifiedFile(target[0].get_file(), modifiedCode)
	
	print("Mind Misc Module: Hooks Applied")
	
	statusEffects = [
		"res://Modules/MindMiscModule/CondomInflated.gd",
	]
	perks = [
		"res://Modules/MindMiscModule/InsatiableDesire.gd",
		"res://Modules/MindMiscModule/BetterBiology.gd",
	]

# Hacky shit, FoxLib dosen't expose the float option type despite supporting it internally
func addFloatOption(foxModuleAPI, optionID, title, description=null, defaultValue=0):
	return self.addFloatOptionInCategory(foxModuleAPI, foxModuleAPI.getName(), optionID, title, description, defaultValue)

func addFloatOptionInCategory(foxModuleAPI, category, optionID, title, description=null, defaultValue=0):
	return foxModuleAPI.addOptionInCategoryInternal("float", category, optionID, title, description, defaultValue)

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "enableCondomInflation", "Enable Condom Inflation", "Only partially implemented, Inflates bellies in sex based on the amount of cum in condoms", true)
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "preventDisableChildPerks", "Disable Child Perks", "prevent forcibly disabling perks if one of their required perks is disabled, Vanilla behavior is False", true)
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "extraCumInflationEffectImages", "Extra Cum Inflation Images", "Adds an additional status effect image for the Cum Inflation Status and changes when they appear to align better with a higher Cum Inflation Level Limit", true)
	self.addFloatOptionInCategory(foxModuleAPI, "Mind Misc Module", "maxCumInflationLevel", "Max Cum Inflation Level", "How much can a character be Cum Inflated, Vanilla is 1.0", 3.5)
	
