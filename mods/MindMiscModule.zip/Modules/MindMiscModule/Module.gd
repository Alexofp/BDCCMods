extends Module

# Debug - save modified code to user folder
var debug = false

var GlobalTasks = [
	"res://Modules/MindMiscModule/CondomInflation/InteractionSystem/TaskDealWithCondoms.gd",
]

# defaults so we still work without FoxLib
var maxCumInflationLevel:float = 2.0
var enableCondomInflation:bool = true
var preventDisableChildPerks:bool = true
var extraCumInflationEffectImages:bool = true

var condomPopping:bool = true
var condomStressedAt:float = 9500.0
var condomMax:float = 24500.0
# (condomMax - condomStressedAt) / 100 = condomMod
# RNG.chance((condom.fluids.getFluidAmount() - condomStressedAt) / condomMod)

# [ targetFile1, [
#	[ PlaceBeforeTarget1, Target1, PlaceAfterTarget1 ], 
#	[ PlaceBeforeTarget2, Target2, PlaceAfterTarget2 ],
#	]],
# [ targetFile2, [
#	[ PlaceBeforeTarget3, Target3, PlaceAfterTarget3 ],
#	]],
# ]

# make sure your \n and \t are correct or the script won't parse!
# you can use +\ to split the string over multiple lines making it easier to read

var hooks = [
	["res://Game/BaseCharacter.gd", [
		
		# Comment out hard coded clamp, replace with value read from us
		["var MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')"+\
		"\n\t#", "pregnancyValue += clamp(cumInflationLevel / 2.0, 0.0, 1.0)",
		"\n\tpregnancyValue += clamp(cumInflationLevel / 2.0, 0.0, MindMiscModule.maxCumInflationLevel)"],
	]],
	
	["res://Skills/Perk/CumUniqueBiology.gd", [
		
		# Unlock MindMiscBetterBiology when CumUniqueBiolody is learned or toggled
		["func runOnceWhenLearned():"+\
		"\n\tif(!GM.pc.getSkillsHolder().hasPerkDisabledOrNot('MindMiscBetterBiology')):"+\
		"\n\t\tGM.pc.getSkillsHolder().addPerk('MindMiscBetterBiology')\n\n"+\
		"func onPerkToggled(_isEnabledNow):"+\
		"\n\tif(!GM.pc.getSkillsHolder().hasPerkDisabledOrNot('MindMiscBetterBiology')):"+\
		"\n\t\tGM.pc.getSkillsHolder().addPerk('MindMiscBetterBiology')"+\
		"\n\n", "func onSexEvent", ""],
		
		# Bail out before flare check if character has MindMiscBetterBiology enabled
		["if npc.hasPerk('MindMiscBetterBiology'): return\n\t\t\t", "if(hasFlare):", ""],
	]],
	
	["res://Skills/Skill/CumLover.gd", [
		
		# add a new level to existing skill
		["", "[10],", "\n\t\t[15],"],
	]],
	
	["res://Skills/Skill/Breeder.gd", [
		
		# add a new level to existing skill
		["", "[10],", "\n\t\t[15],"],
	]],
	
	["res://Skills/SkillsHolder.gd", [
		
		# Replace original togglePerk function
		# now checks us for flag to call NEWtogglePerk or OGtogglePerk
		["func NEWtogglePerk(perkID):"+\
		"\n\tif(!perks.has(perkID)): return"+\
		"\n\tif(disabledPerks.has(perkID) && disabledPerks[perkID]):"+\
		"\n\t\tvar perk = perks[perkID]"+\
		"\n\t\tdisabledPerks.erase(perkID)"+\
		"\n\t\tperk.onPerkToggled(true)"+\
		"\n\telse:"+\
		"\n\t\tdisabledPerks[perkID] = true"+\
		"\n\t\tperks[perkID].onPerkToggled(false)"+\
		"\n", "func togglePerk(perkID):",
		"\n\tvar MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')"+\
		"\n\tif(!MindMiscModule.preventDisableChildPerks):"+\
		"\n\t\tOGtogglePerk(perkID)"+\
		"\n\telse: NEWtogglePerk(perkID)"+\
		"\nfunc OGtogglePerk(perkID):"],
	]],
	
	["res://StatusEffect/CumInflated.gd", [
		
		# Replace original getEffectImage function
		# now checks us for flag to call NEWgetEffectImage or OGgetEffectImage
		["func NEWgetEffectImage():"+\
		"\n\tvar cumInflationLevel = character.getCumInflationLevel()"+\
		"\n\tif(cumInflationLevel <= 1.0): return 'res://Images/StatusEffects/belly.png'"+\
		"\n\tif(cumInflationLevel <= 1.5): return 'res://Images/StatusEffects/bloating.png'"+\
		"\n\treturn 'res://Modules/MindMiscModule/Images/Gravid.png'"+\
		"\n", "func getEffectImage():", "\n\tvar MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')"+\
		"\n\tif(!MindMiscModule.extraCumInflationEffectImages):"+\
		"\n\t\treturn OGgetEffectImage()"+\
		"\n\telse: return NEWgetEffectImage()"+\
		"\nfunc OGgetEffectImage():"],
	]],
	
	["res://Scenes/MeScene.gd", [
		
		# Add a button to interact with filled condoms inside you
		["", 'addButton("Tasks", "Look at your tasks", "tasks")', '\n\t\t'+\
		'addButton("Condoms", "Interact with any filled condoms inside you", "condoms")'],
		
		# handle that button's action
		['if(_action == "condoms"):\n\t\t'+\
		'runScene("MindMiscModuleCondomInteractionScene")\n\t\t'+\
		'return\n\n\t', 'if(_action == "domasturbate"):', '']
	]],
	
	["res://Game/SexEngine/SexEngine.gd", [
		
		# resetJustCame is called too early PT1
		# PR open https://github.com/Alexofp/BDCC/pull/366
		["#", "\tresetJustCame()", ""],
	]],
	
	["res://Scenes/GenericSexScene.gd", [
		
		# resetJustCame is called too early PT2
		# PR open https://github.com/Alexofp/BDCC/pull/366
		["", "func _react(_action: String, _args):", "\n\tsexEngine.resetJustCame()",],
	]],
	
	["res://Game/SexEngine/SexInfoBase.gd", [
		
		# resetJustCame is called too early PT3
		# PR open https://github.com/Alexofp/BDCC/pull/366
		["", '"fetishGain": fetishGain,', '\n\t\t"justCame": justCame,'],
		["", 'fetishGain = SAVE.loadVar(data, "fetishGain", {})', '\n\tjustCame = SAVE.loadVar(data, "justCame", false)']
	]]
]

# Hold them in memory, our changes don't exist on disk at res://
var hooksHolder = []

func exportModifiedFile(fileName, fileContent):
	var file = File.new()
	var path = "user://MindHookDebugExports/"
	var fullPath = path + fileName
	print("Exporting to "+ fullPath)
	var error = file.open(fullPath, File.WRITE)
	if(!error):
		file.store_line(fileContent)
		file.close()
	else: print("Error "+str(error)+" opening path: "+fullPath)

func _init():
	id = "MindMiscModule"
	author = "Mindstormsman"
	
	if OS.has_feature("editor"):
		debug = true
	
	if(debug):
		var dir = Directory.new()
		var error = dir.make_dir("user://MindHookDebugExports")
		if(error and (error != 32)):
			print("Error "+str(error)+" creating directory user://MindHookDebugExports")
			debug = false
	
	for target in hooks:
		var codeBase = load(target[0])
		var originalCode = codeBase.source_code
		var modifiedCode = originalCode
		for hook in target[1]:
			modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
		codeBase.source_code = modifiedCode
		var error = codeBase.reload()
		if( error != 0):
			print("Error code "+str(error)+" reloading target at path: "+target[0])
		hooksHolder.append(codeBase)
		if(debug): exportModifiedFile(target[0].get_file(), modifiedCode)
	
	print("Mind Misc Module: Hooks Applied")
	
	statusEffects = [
		"res://Modules/MindMiscModule/CondomInflation/CondomInflated.gd",
	]
	perks = [
		"res://Modules/MindMiscModule/PerkStuff/InsatiableDesire.gd",
		"res://Modules/MindMiscModule/PerkStuff/PerfectStallion.gd",
		"res://Modules/MindMiscModule/PerkStuff/BetterBiology.gd",
		"res://Modules/MindMiscModule/CondomInflation/CondomListener.gd",
	]
	gameExtenders = [
		"res://Modules/MindMiscModule/CondomInflation/CondomListenerAttatcher.gd",
	]
	scenes = [
		"res://Modules/MindMiscModule/CondomInflation/CondomInteractionScene.gd",
	]
	sexActivities = [
		"res://Modules/MindMiscModule/PerkStuff/PerkActivities.gd",
		"res://Modules/MindMiscModule/CondomInflation/CondomActivities.gd"
	]

func register():
	.register()
	
	for Task in GlobalTasks:
		GlobalRegistry.registerGlobalTask(Task)
	

# Hacky shit, FoxLib dosen't expose the float option type despite supporting it internally
func addFloatOption(foxModuleAPI, optionID, title, description=null, defaultValue=0):
	return self.addFloatOptionInCategory(foxModuleAPI, foxModuleAPI.getName(), optionID, title, description, defaultValue)

func addFloatOptionInCategory(foxModuleAPI, category, optionID, title, description=null, defaultValue=0):
	return foxModuleAPI.addOptionInCategoryInternal("float", category, optionID, title, description, defaultValue)

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "enableCondomInflation", "Enable Condom Inflation", "Inflates bellies in sex based on the amount of cum in condoms", true)
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "condomPopping", "Enable Condom Popping", "Should condoms become stressed and pop when overfilled?", true)
	self.addFloatOptionInCategory(foxModuleAPI, "Mind Misc Module", "condomStressedAt", "Condom Stress Level", "When should a condom become stressed? (in ml)", 9500.0)
	self.addFloatOptionInCategory(foxModuleAPI, "Mind Misc Module", "condomMax", "Max Condom Capacity", "How much should a Stressed Condom have to have a 100% chance to pop? (in ml)", 24500.0)
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "preventDisableChildPerks", "Disable Child Perks", "prevent forcibly disabling perks if one of their required perks is disabled, Vanilla behavior is False", true)
	foxModuleAPI.addBooleanOptionInCategory("Mind Misc Module", "extraCumInflationEffectImages", "Extra Cum Inflation Images", "Adds an additional status effect image for the Cum Inflation Status and changes when they appear to align better with a higher Cum Inflation Level Limit", true)
	self.addFloatOptionInCategory(foxModuleAPI, "Mind Misc Module", "maxCumInflationLevel", "Max Cum Inflation Level", "How much can a character be Cum Inflated, Vanilla is 1.0", 2.0)
	
