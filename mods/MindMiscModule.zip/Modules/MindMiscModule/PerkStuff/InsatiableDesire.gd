extends PerkBase

func _init():
	id = "MindMiscInsatiableDesire"
	skillGroup = Skill.CumLover
	dungeonWeight = 0

func getVisibleName():
	return "Insatiable Desire"

func getVisibleDescription():
	return "You love cum so much you've figured out how to coax more out of your partners!"
	
func getMoreDescription():
	return "Adds the ability to milk your partner's cock after they cum inside"

func getRequiredPerks():
	return [Perk.CumBreathV2]

func getSkillTier():
	return 3

func getCost():
	return 5

func getPicture():
	return "res://Modules/MindMiscModule/Images/InsatiableDesire.png"
