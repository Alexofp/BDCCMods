extends SexActivityBase

func _init():
	id = "MindMiscModulePerkActivities"
	startedByDom = true
	startedBySub = false
	
	activityName = "Perk Activities"
	activityDesc = "Activites for Perks from Mind Misc Module"
	activityCategory = []

func getGoals():
	return {
		#SexGoal.SubUndressDom: 1.0, # Custom sex goal?
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: true,
		SexType.SlutwallSex: true,
		SexType.BitchsuitSex: true,
		SexType.TentaclesSex: true,
	}

# This is AI goal stuff, not actually used yet
func getActivityBaseScore(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	var baseMod:float = 0.01
	if(_sexEngine.hasTag(_domInfo.charID, SexActivityTag.PenisUsed) || _sexEngine.hasTag(_domInfo.charID, SexActivityTag.VaginaUsed) || _sexEngine.hasTag(_domInfo.charID, SexActivityTag.AnusUsed)):
		baseMod = 1.0
	
	return baseMod + max(_domInfo.fetishScore({Fetish.Exhibitionism: 0.1}), 0.0)

func getStartActions(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	var dom:BaseCharacter = _domInfo.getChar()
	# Maybe I'll figure out SexGoals later 
	var theScore:float = 0.1 #getActivityScore(_sexEngine, _domInfo, _subInfo)
	
	# Kinda hacky, won't work if an activity uses a knotted state other than "knotting"
	# but I can add additional states to the list if I find them
	var knotted = false
	if(_sexEngine.activities.size() > 0):
		knotted = (_sexEngine.activities[0].getState() in ["knotting"])
	
	if(dom.hasPerk("MindMiscPerfectStallion") && _domInfo.justCame &&
		_sexEngine.hasTag(_domInfo.charID, SexActivityTag.PenisUsed) && (
			_sexEngine.hasTag(_subInfo.charID, SexActivityTag.VaginaUsed) ||
			_sexEngine.hasTag(_subInfo.charID, SexActivityTag.AnusUsed)
		)):
		addStartAction(["DomPerfectStallion", knotted], "Cum Again!", "You are a perfect stallion, you can cum again imediately after cumming!", theScore)
	
	if(dom.hasPerk("MindMiscInsatiableDesire") && _subInfo.justCame &&
		_sexEngine.hasTag(_subInfo.charID, SexActivityTag.PenisUsed) && (
			_sexEngine.hasTag(_domInfo.charID, SexActivityTag.VaginaUsed) ||
			_sexEngine.hasTag(_domInfo.charID, SexActivityTag.AnusUsed)
		)):
		addStartAction(["DomInsatiableDesire", knotted], "Milk it!", "You want more and you can coax it out of them right after they cum!", theScore)

func startActivity(_args):
	var _theAction = _args[0]
	var knotting = _args[1]
	
	var pulloutVerb:String = RNG.pick(["'yank'", "'pull'", "'slide'",])
	var putinVerb:String = RNG.pick(["'slam'", "'thrust'",])
	var wombText:String = RNG.pick(["womb", "womb", "babymaker",])
	var assText:String = RNG.pick(["ass", "butt",])
	var seedText:String = RNG.pick(["cum", "seed", "jizz", "semen",])
	var cockText:String = RNG.pick(["cock", "dick", "member",])
	if(knotting): cockText = RNG.pick(["cock", "dick", "member", "knot", "knot",])
	
	var text:String = ""
	var usedBodypart:String = BodypartSlot.Anus # fallback
	
	var condom:ItemBase
	var condomBroke:bool = false
	
	if(_theAction == "DomPerfectStallion"):
		usedBodypart = getUsed(getSubID())
		if(usedBodypart == BodypartSlot.Anus):
			wombText = assText
		text += "{dom.You} {dom.youVerb("+pulloutVerb+")} {dom.yourHis} "+cockText+" out of {sub.your} "+wombText+" and {dom.youVerb("+putinVerb+")} it back in, cumming again!\n"
		text += "Waves after waves of sticky "+seedText+" flow into {sub.yourHis} "+wombText+"."
		condom = getDom().getWornCondom()
		if(condom != null):
			var breakChance = condom.getCondomBreakChance()
			condomBroke = getDom().shouldCondomBreakWhenFucking(getSub(), breakChance)
			if(condomBroke):
				text = "[b]The condom broke![/b]\n"+text
				condom.destroyMe()
				fetishUp(DOM_0, Fetish.Condoms, -15.0)
				fetishUp(SUB_0, Fetish.Condoms, -20.0)
			else:
				fetishAffect(SUB_0, Fetish.Condoms, 3.0)
				fetishAffect(DOM_0, Fetish.Condoms, 3.0)
				var loadSize = getDom().cumInItem(condom)
				getDomInfo().cum()
				getSubInfo().addArousalSex(0.02)
				sendSexEvent(SexEvent.FilledCondomInside, DOM_0, SUB_0, {hole=usedBodypart,loadSize=loadSize,knotted=knotting,engulfed=true})
				satisfyGoals()
				addText(text)
				endActivity()
				return
		getSub().cummedInBodypartByAdvanced(usedBodypart, getDomID(), {knotted=knotting,condomBroke=condomBroke,engulfed=true})
		getDomInfo().cum()
		satisfyGoals()
		getSubInfo().addArousalSex(0.05)
		addText(text)
		endActivity()
		return
	
	if(_theAction == "DomInsatiableDesire"):
		usedBodypart = getUsed(getDomID())
		if(usedBodypart == BodypartSlot.Anus):
			wombText = assText
		text += "{dom.You} {dom.youVerb("+pulloutVerb+")} {dom.yourself} off of {sub.your} "+cockText+" and {dom.youVerb("+putinVerb+")} it back in, making {sub.youHim} cum again!\n"
		text += "Waves after waves of sticky "+seedText+" flow into {dom.yourHis} "+wombText+"."
		getSub().getBodypart(BodypartSlot.Penis).getFluidProduction().fillPercent(0.2)
		condom = getSub().getWornCondom()
		if(condom != null):
			var breakChance = condom.getCondomBreakChance()
			condomBroke = getSub().shouldCondomBreakWhenFucking(getDom(), breakChance)
			if(condomBroke):
				text = "[b]The condom broke![/b]\n"+text
				condom.destroyMe()
				fetishUp(SUB_0, Fetish.Condoms, -15.0)
				fetishUp(DOM_0, Fetish.Condoms, -20.0)
			else:
				fetishAffect(SUB_0, Fetish.Condoms, 3.0)
				fetishAffect(DOM_0, Fetish.Condoms, 3.0)
				var loadSize = getSub().cumInItem(condom)
				getSubInfo().cum()
				getDomInfo().addArousalSex(0.02)
				sendSexEvent(SexEvent.FilledCondomInside, SUB_0, DOM_0, {hole=usedBodypart,loadSize=loadSize,knotted=knotting,engulfed=true})
				satisfyGoals()
				addText(text)
				endActivity()
				return
		getDom().cummedInBodypartByAdvanced(usedBodypart, getSubID(), {knotted=knotting,condomBroke=condomBroke,engulfed=true})
		getSubInfo().cum()
		satisfyGoals()
		getDomInfo().addArousalSex(0.05)
		addText(text)
		endActivity()
		return
	
	endActivity()
	return

func getUsed(_id):
	if(getSexEngine().hasTag(_id, SexActivityTag.VaginaUsed)):
		return BodypartSlot.Vagina
	return BodypartSlot.Anus
