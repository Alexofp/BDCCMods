extends PerkBase

func _init():
	id = "MindMiscPerfectStallion"
	skillGroup = Skill.Breeder
	dungeonWeight = 0

func getVisibleName():
	return "Perfect Stallion"

func getVisibleDescription():
	return "You've perfected your diet and mastered your technique to become the perfect stallion."
	
func getMoreDescription():
	return "Adds the ability to cum again right after you cum!\n"+\
		"Also fills your balls by another 30% after every orgasm!"

func getRequiredPerks():
	return [Perk.BreedStudV2]

func getSkillTier():
	return 3

func getCost():
	return 5

func getBuffs():
	return [
		buff(Buff.PenisCumGenerationAfterOrgasmBuff, [30]),
	]

func getPicture():
	return "res://Modules/MindMiscModule/Images/PerfectStallion.png"
