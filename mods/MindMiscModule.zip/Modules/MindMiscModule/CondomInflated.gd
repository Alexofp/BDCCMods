extends StatusEffectBase

var amount = 0.0
var MindMiscModule

func _init():
	id = "CondomInflated"
	isSexEngineOnly = true
	MindMiscModule = GlobalRegistry.getModules().get('MindMiscModule')

func initArgs(_args = []):
	if(_args.size() > 0):
		amount = _args[0]
		if(amount <= 0.0):
			Log.printerr("CondomInflated Status Effect applied to "+str(character)+" with invalid amount, "+str(amount)+". Stack Trace:")
			Log.printerr(Util.getStackFunction())
	else:
		Log.printerr("CondomInflated Status Effect applied to "+str(character)+" without arguments. Stack Trace:")
		Log.printerr(Util.getStackFunction())

func getEffectName():
	return "Condom Inflated"

func getEffectDesc():
	var text:String = "You have an inflated condom in you!"
	var level = calculateBuffLevel()
	if(level > 1.5): text += "\n\nThe massive condom is making it hard to breathe\nThere's no way it can take much more"
	elif(level > 1.0): text += "\n\nThe bloated condom is really filling you"
	elif(level > 0): text += "\n\nIt's applying a nice pressure"
	else: text += "\n\nYou can hardly feel it."
	text += "\n\nIt has "+str(amount)+" ml in it."
	return text
	

func getEffectImage():
	if(MindMiscModule.extraCumInflationEffectImages):
		if(amount < 3000.0):
			return "res://Modules/MindMiscModule/Images/PleasureBelly.png"
		if(calculateBuffLevel() <= 1.0):
			return "res://Images/StatusEffects/belly.png"
		if(calculateBuffLevel() <= 1.5):
			return "res://Images/StatusEffects/bloating.png"
		return "res://Modules/MindMiscModule/Images/Gravid.png"
	else:
		print("\n"+str(calculateBuffLevel()*2)+"\n")
		if(calculateBuffLevel()*2 <= 4.5):
			return "res://Images/StatusEffects/belly.png"
		return "res://Images/StatusEffects/bloating.png"

func getIconColor():
	return IconColorGreen

func combine(_args = []):
	if(_args.size() > 0):
		amount += _args[0]
	if(amount <= 0.0):
		stop()
		character.updateNonBattleEffects()

func calculateBuffLevel():
	# 5000 = 0.5, 7000 = 1.0, ..., 17000 = 3.5
	return clamp(max(amount - 3000.0, 0.0) / 2000.0, 0.0, 10.0) / 2.0

func getBuffs(): # 3.5 max -> 350%
	return [buff(Buff.InflatedBellyBuff, [clamp(calculateBuffLevel(), 0.0, MindMiscModule.maxCumInflationLevel)*100.0])]

func onSexEnded(_contex = {}):
	stop()
	character.updateNonBattleEffects()

func processSexTurn():
	if(!MindMiscModule.enableCondomInflation):
		stop()
		character.updateNonBattleEffects()
	if(amount <= 0.0):
		stop()
		character.updateNonBattleEffects()

func saveData():
	return {
		"amount": amount,
	}
func loadData(_data):
	amount = SAVE.loadVar(_data, "amount", 0.0)
	if(amount <= 0.0): stop()
	if(character != null):
		character.updateNonBattleEffects()
	if(!MindMiscModule.enableCondomInflation):
		stop()
		character.updateNonBattleEffects()
