extends Module

var maxOtherPortraits : int = 0

func getFlags():
	return {
		"PortraitNameColor": flag(FlagType.Text),
		"PortraitsPath": flag(FlagType.Text),
	}

func _init():
	id = "PlayerPortrait"
	author = "Selinoccino"
	
	worldEdits = [
		"res://Modules/PlayerPortrait/PortraitWorldEdit.gd",
		"res://Modules/PlayerPortrait/PortraitInitWorldEdit.gd",
	]
	
	characters = [
		"res://Modules/PlayerPortrait/FakePlayer.gd",
	]
	
	scenes = [
		"res://Modules/PlayerPortrait/portraitOptionsScene.gd",
	]
	
	events = [
		"res://Modules/PlayerPortrait/OptionsEvent.gd",
	]
	

func postInit():
	GlobalRegistry.registerImagePack("res://Modules/PlayerPortrait/PlayerImagePack.gd")
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)
	#doReloadMyPackPleaseAndThankYou()

func doReloadMyPackPleaseAndThankYou():
	var pack = GlobalRegistry.imagePacks.get("RAT_PlayerPortrait")
	if !pack:
		Log.warning("PlayerPortrait: can't find imagepack!")
		return
	
	pack.reloadMyDataPleaseAndThankYou()

func onFoxLibModInit(_foxModuleAPI):
	_foxModuleAPI.addNumberOptionInCategory(id, "maxOtherPortraits", "Max Other Portraits", "Maximmum number of other portraits visible, not including the player's one. When there's more than this amount of characters in a tile/scene, the player portrait won't be visible.", 0)
#	return
