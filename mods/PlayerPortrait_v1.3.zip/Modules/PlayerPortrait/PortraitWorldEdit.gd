extends WorldEditBase

func _init():
	id = "RAT_PortraitEdit"
	isRegular = true

func apply(_world: GameWorld):
	dothething()

func dothething() -> void:
	var panel = GM.ui.smartCharacterPanel
	
	var maxOtherPortraits = GlobalRegistry.getModule("PlayerPortrait").maxOtherPortraits
	
	if panel.characters.size()<=maxOtherPortraits:
		
		panel.addCharacter("RAT_FakePlayer", getCurrentVariant())
	
	elif "RAT_FakePlayer" in panel.characters.keys()[0] && panel.characters.size()>maxOtherPortraits+1:
		
		panel.removeCharacter("RAT_FakePlayer")

func getCurrentVariant() -> Array:
	var pack = GlobalRegistry.imagePacks.get("RAT_PlayerPortrait", null)
	if !pack:
		return []
	return pack.getFinalVariantForCharacter()
	
