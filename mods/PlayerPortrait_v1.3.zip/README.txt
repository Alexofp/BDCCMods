Using PlayerPortrait:

Portrait files can be placed inside any directory, when unset defaults to this one: (BDCC user data folder, where your saves folder is)/PlayerPortraits/
Portraits folder and other options can be changed in the "me" menu, and are saved per savegame.

Image size used when testing is 700x895, but the vanilla dimensions (512x600 I think) should also work well.

The only required file(s) for the mod to "work" is either one .png file that begins with "naked" or one that begins with "normal". Those will be used when your character is clothed or naked appropriately or, if one is missing, the other will be used all the time.

Please note that the hurt, neutral and lust variants are all displayed on top of your normal/naked image; you can have the normal and naked images be a blank head shape and the variants be the facial expression.

To specify hurt variants, you can make any number of .png files that should all start with "hurt"; they'll be read alphabetically. The hurt variants that are alphabetically earlier will be displayed on lower pain levels, and the ones later on higher ones (I recommend naming them smth like "hurt1", "hurt2" etc.).

You can follow the same proccess to add lust variants, only difference being that the filenames have to start with "lust". You can currently only have one hurt/lust overlay active, and the lust one will only be displayed if your lust percentage is higher than your pain percentage.

You can also do the same for arousal variants, whose filenames have to start with "arousal".

You can also specify a neutral overlay that will be displayed when your character is not feeling too lusty or hurt, by adding a .png file that starts with "neutral".

The variant whose associated value is higher will always be chosen, so if lust is greater than all others then the lust one will show, etc. If two values or more are equal, this is the order of priority: pain -> arousal -> lust, from most to least important.

By default, the player portrait will only appear when no other characters are present. This can be changed with FoxLib, in the mod options.
