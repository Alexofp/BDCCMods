extends Module

func _init():
	id = "Fluidex"
	author = "Astro"
