extends TFBase

var switchedpenisfluid:bool = false
var switchedbreastsfluid:bool = false
var switchedvaginafluid:bool = false

#Targets are the ID's of what fluid said target should produce.
var penistarget:String = ""
var breaststarget:String = ""
var vaginatarget:String = ""

func _init():
	id = "ChangeFluidTypeTF"
	
	canStack = false
	pointsOnUnlock = 15

func getName() -> String:
	return "Alters produced fluids"

func getPillName() -> String:
	return "Fluidex"
	
func getUnlockData() -> Dictionary:
	return {
		eliza = "Intresting! This pill seems to contain DNA and tissue-altering agents that can target multiple parts of the body at once. I think this one can completely change what fluids your body produces to something else.. I will call it 'Fluidex'.",
	}

func getPillDatabaseDesc() -> String:
	return "This drug will morph what fluids the diferent parts of your body produces, one by one.\n\nThe first change will happen after a few minutes. After that, any others will happen roughly every hour. This could be accelerated by using the QuickShift drug.\n\nThis drug has a maximum amount of 3 stages."

func getTFCheckTags() -> Dictionary:
	return {
		"penis": true,
		"breasts": true,
		"vagina": true,
	}

func getPillFluidsRequired() -> Dictionary:
	return {
		"Cum": 1000.0,
		"WhiteGoo": 50.0,
		"BlackGoo": 50.0,
	}

func isPossibleFor(_char) -> bool:
	return true

func start(_args:Dictionary):
	if(_args.has("penistarget")):
		penistarget = _args["penistarget"]
	if(_args.has("breaststarget")):
		breaststarget = _args["breaststarget"]
	if(_args.has("vaginatarget")):
		vaginatarget = _args["vaginatarget"]


func getPillOptions() -> Dictionary:
	var fluids:Array = GlobalRegistry.getFluids().keys()
	if(OPTIONS.isContentEnabled(ContentType.Watersports)==false):
		fluids.erase("Piss")
	var fluidArray:Array = []
	for theFluid in fluids:
		fluidArray.append([theFluid, str(theFluid)])
	return {
		"penistarget": {
			name = "Penis Target Fluid",
			desc = "What fluid should the penis produce",
			value = "Cum",
			values = fluidArray,
		},
		"breaststarget": {
			name = "Breasts Target Fluid",
			desc = "What fluid should the breasts produce",
			value = "Milk",
			values = fluidArray,
		},
		"vaginatarget": {
			name = "Vagina Target Fluid",
			desc = "What fluid should the vagina produce",
			value = "GirlCum",
			values = fluidArray,
		},
	}

func getPossibleSteps(_char:BaseCharacter) -> Array: 
	var result:Array = []
	
	if(_char.hasBodypart(BodypartSlot.Penis) && !switchedpenisfluid && (penistarget != _char.getBodypart(BodypartSlot.Penis).getFluidType(FluidSource.Penis))): 
		result.append("changepenis")
		if(penistarget == ""): #This is for error prevention. 
			penistarget = "BlackGoo"
	
	if(_char.hasBodypart(BodypartSlot.Breasts) && (_char.getBodypart(BodypartSlot.Breasts).getSize() > 0) && !switchedbreastsfluid && (breaststarget != _char.getBodypart(BodypartSlot.Breasts).getFluidType(FluidSource.Breasts))):
		result.append("changebreasts")
		if(breaststarget == ""): #This is for error prevention. 
			breaststarget = "HealingGel"

	if(_char.hasBodypart(BodypartSlot.Vagina) && !switchedvaginafluid && (vaginatarget != _char.getBodypart(BodypartSlot.Vagina).getFluidType(FluidSource.Vagina))):
		result.append("changevagina")
		if(vaginatarget == ""): #This is for error prevention. 
			vaginatarget = "CumLube"
	return result

func canTransformFurther() -> bool:
	if(!getPossibleSteps(getChar()).empty()):
		return true
	return false

func getTimerForStage(_theStage:int) -> int:
	if(_theStage == 0):
		return 300
	return 60*60

func doProgress(_context:Dictionary) -> Dictionary:
	var allSteps:Array = getPossibleSteps(getChar())
	if(allSteps.empty()):
		return {}
	var nextStep:String = RNG.pick(allSteps)
	
	if(nextStep == "changepenis"):
		switchedpenisfluid = true
		return {
			step = nextStep,
			effects = [
				partEffect("penis", BodypartSlot.Penis, "FluidTypeChange", [penistarget]),
			],
		}
	
	if(nextStep == "changebreasts"):
		switchedbreastsfluid = true
		return {
			step = nextStep,
			effects = [
				partEffect("breasts", BodypartSlot.Breasts, "FluidTypeChange", [breaststarget]),
			],
		}	
	
	if(nextStep == "changevagina"):
		switchedvaginafluid = true
		return {
			step = nextStep,
			effects = [
				partEffect("vagina", BodypartSlot.Vagina, "FluidTypeChange", [vaginatarget]),
			],
		}		
	
	return {
	}

func saveData() -> Dictionary:
	var data:Dictionary = .saveData()
	data["spf"] = switchedpenisfluid
	data["sbf"] = switchedbreastsfluid
	data["svf"] = switchedvaginafluid
	data["pt"] = penistarget
	data["bt"] = breaststarget
	data["vt"] = vaginatarget
	
	return data

func loadData(_data:Dictionary):
	.loadData(_data)
	switchedpenisfluid = SAVE.loadVar(_data, "spf", false)
	switchedbreastsfluid = SAVE.loadVar(_data, "sbf", false)
	switchedvaginafluid = SAVE.loadVar(_data, "svf", false)
	penistarget = SAVE.loadVar(_data, "pt", "")
	breaststarget = SAVE.loadVar(_data, "bt", "")
	vaginatarget = SAVE.loadVar(_data, "vt", "")
