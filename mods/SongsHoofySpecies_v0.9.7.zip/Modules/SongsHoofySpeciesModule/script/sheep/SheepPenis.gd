extends BodypartPenis

func _init():
	visibleName = "sheep penis"
	id = "sheeppenis"

func getCompatibleSpecies():
	return ["sheep"]

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Penis/SheepPenis.tscn"

