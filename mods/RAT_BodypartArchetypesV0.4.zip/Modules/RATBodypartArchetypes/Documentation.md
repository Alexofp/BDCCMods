# Archetypes
An archetype is a dictionary with (up to) 4 keys, all of which are optional:
- `"strict"`: A Type, where bodyparts are added no matter what.
- `"normal`": A Type, where the bodyparts are only added if the bodypart slot is already taken; no bodyparts are added in empty slots.
- `"optionDisplay"`: A String, representing the text displayed in the Mod Options.
- `"display"`: A String that replaces the NPC's species text. All occurences of `{DEF}` here will be replaced by the old species text.

# Kinds of Types
## Normal
An array of strings representing bodypart IDs. This is the base for all other types.

Example: `[ "bodypart1", "bodypart2", "bodypart3" ]`
All bodypart IDs will be added if they exist or the type is strict.

## Randomized
A Normal Type with one or more other arrays of bodypart IDs in it. For every array in it, it will choose only one ID at random. All other IDs not in sub-arrays will be added as well.

Example: `[ "bp1", "bp2", [ "rng1", "rng2", "rng3" ], "bp3" ]`, where `bps` 1 to 3 will always be added, but only one `rng` will be chosen.

## Gendered
A Normal or Randomized Type, with one or more dictionaries with gender-specific Types. Can be nested and will accept any Type in them.

Example: ```
```
[ "bp1", "bp2", {
	"_": [..type..],
	"male": [..type..],
	"binary_female": [..type..], 
	"with_penis": [..type..],
	"with_vagina": [..type..],
} ]
```

Where:
- `"_"`: Other Types are added here and in any of the other keys, any kind. The `"_"` key is the fallback for undefined/unsupported genders, it's optional and is set to be empty by default.
- `"male"`: Same as above. `"male"`/`"female"`/etc. correspond to constants in the  NpcGender class. HOWEVER please note that this takes priority over binary genders! If the NPC's gender is found here, it won't check the binary ones.
- `"binary_female"`:  Same, but binary here means that the gender returned will be one from the Gender class instead, as returned from the `NpcGender.toNormal(gender)` function.
- `"with_penis"`: Added over the gendered stuff above. If your NPC is of an NpcGender that has a penis, this Type will be processed and its bodyparts will be added as well.
- `"with_vagina"`: # Same as `"with_penis"` but for vaginas. These two are NOT mutually exclusive; only NPC genders and binary genders are.

Valid values for NPC genders are:
- `"male"`
- `"female"`
- `"shemale"`
- `"peachboy"`
And valid values for binary genders are:
- `"male"`
- `"female"`
- `"androgynous"`
- `"other"`

# Kinds of bodypart IDs
## Normal
A string representing an ID of a bodypart. If it doesn't exist in the registry, it will not be added.

Example: `"caninehead"`
## Default bodyparts for species
A string representing which species to get default bodyparts from, and for which slot. A random bodypart ID will be chosen from these (the result of this is a Randomized type).

Example: `"defaults::speciesID::bodypartSlotID"`

## Method callback
A Normal bodypart ID that calls a chosen function on a chosen module. The bodypart will be added and the function will be called right after. Lenient, will never crash, even if the module or method doesn't exist.

Example: `"caninehead::moduleID.methodName"`, where the function `methodName()` will be called on the `moduleID` module.

The arguments for the method are as follows: `_ar, _bpid, _npc, _args`, where `_ar` is the Type this was called from, `_bpid` is the bodypart ID, `_npc` is the (usually) dynamic NPC that is being created, and `_args` are the arguments passed from the game for generation.