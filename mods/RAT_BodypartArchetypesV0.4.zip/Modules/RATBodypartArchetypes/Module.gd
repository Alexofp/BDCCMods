extends Module

var replacedSpecies : Array = []

var defaultTypeChance : float = 15.0

func _init():
	id = "RAT_FluffyArchetypes"
	author = "Selinoccino"
	

func a(_ar, _bpid, _npc, _args) -> void:
	_npc.npcChatColorOverride = "#ff0000"

func postInit():
	var pathDir = "res://Modules/RATBodypartArchetypes/SpeciesTypes/"
	var speciesMap = {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)

	#Base Game Archetypes
	"canine": [pathDir+"DefaultArchetypes.json", pathDir+"ClawedArchetypes.json", pathDir+"KemonomimiArchetypes.json"],
	"feline": [pathDir+"DefaultArchetypes.json", pathDir+"ClawedArchetypes.json", pathDir+"KemonomimiArchetypes.json"],
	"equine": [pathDir+"DefaultArchetypes.json", pathDir+"HoofedArchetypes.json", pathDir+"KemonomimiArchetypes.json"],
	"dragon": [pathDir+"DefaultArchetypes.json", pathDir+"ScaledArchetypes.json", pathDir+"KemonomimiArchetypes.json"],
	"demon": [pathDir+"DefaultArchetypes.json", pathDir+"DemonArchetypes.json"],
	#Modded Species
	"rabbit": [pathDir+"DefaultArchetypes.json", pathDir+"ClawlessArchetypes.json", pathDir+"KemonomimiArchetypes.json"]
	}
	
	for key in speciesMap:
		if typeof(speciesMap[key]) == TYPE_STRING:
			var old = speciesMap[key]
			speciesMap[key] = readJsonData(old)
			continue
		
		var res : Dictionary = {}
		for path in speciesMap[key]:
			res.merge(readJsonData(path), true)
		
		speciesMap[key] = res
	
	replaceAllSpecies(speciesMap) # replaceAllSpecies is just the current postInit func renamed, and its replaced var made into an argument


func replaceAllSpecies(replaced:Dictionary):
	#replaced = id: types dict (typeID: type array)
	
	var typesSpecies = load("res://Modules/RATBodypartArchetypes/TypedSpecies.gd")
	
	var allsps = GlobalRegistry.getAllSpecies()
	for species in replaced:
		if !species in allsps:
			continue
		
		var spobj = allsps[species]
		if !spobj:
			continue
		
		replacedSpecies.append(typesSpecies.new(spobj, replaced[species]))
	

func readJsonData(path:String, type:int=TYPE_DICTIONARY, nullval={}):
	var f = File.new()
	
	var e = f.open(path, File.READ)
	
	if e != OK:
		Log.error(id+": error accessing json data file %s, code %s" % [ path, e])
		return nullval
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		Log.error(id+": error reading json data from file %s, code %s at line %s, message: %s" % [ path, r.error, r.error_line, r.error_string ])
		return nullval
	
	if typeof(r.result) != type:
		Log.error(id+": error parsing json data from file %s, unexpected return type, type: %s, expected: %s" % [ path, typeof(r.result), type ])
		return nullval
	
	return r.result
	


var typesOptions : Dictionary = {
	# species::typeID: foxlib option
}

func onFoxLibModInit(foxModuleAPI):
	for species in replacedSpecies:
		foxifyTypedSpecies(species, foxModuleAPI)

func foxifyTypedSpecies(typedSpecies, foxModuleAPI):
	var types : Dictionary = typedSpecies.types
	var species : Species = typedSpecies.mimic
	
	for typeID in types:
		var type = types[typeID]
		var sptext = species.getVisibleName()
		var newID : String = species.id+"::"+typeID
		
		typesOptions[newID] = foxModuleAPI.addSliderOptionInCategory("FluffyArchetypes: "+sptext, newID, "Type %s" % typeID if !type.has("optionDisplay") else type["optionDisplay"].replace("{DEF}", sptext), "Chance for this type", getChanceForType(newID)).advanced()

func getChanceForType(typestr:String) -> float:
	var option = typesOptions.get(typestr, null)
	if option:
		return option.getOptionValue()
	
	var split = typestr.split("::", false, 2)
	var speciesID = split[0]
	if split.size()<2 or !GlobalRegistry.getAllSpecies().has(speciesID):
		return 0.0
	
	var typeID = split[1]
	return GlobalRegistry.getSpecies(speciesID).types.get(typeID, {}).get("defaultWeight", defaultTypeChance)
