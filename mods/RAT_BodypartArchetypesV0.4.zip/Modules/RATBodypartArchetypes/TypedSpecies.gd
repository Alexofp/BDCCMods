extends Species

var mimic : Species

var types : Dictionary


func _init(m:Species, ts:Dictionary):
	mimic = m
	id = m.id
	GlobalRegistry.allSpecies[id] = self
	
	types = ts
	
	fixTypes(types)
	

static func fixTypes(ts:Dictionary):
	for typeID in ts:
		var oldtype = ts[typeID]
		ts[typeID] = fixType(oldtype)
	

static func fixType(type:Dictionary) -> Dictionary:
	var r : Dictionary = type.duplicate()
	
	for key in ["normal", "strict"]: # arrays, like the old types
		var entry = type.get(key)
		if !entry:
			continue
		
		r[key] = fixOldTypeArray(entry)
	
	return r

static func fixOldTypeArray(ar:Array) -> Array:
	var r : Array = []
	
	var avs = GlobalRegistry.getBodypartRefs()
	
	for entry in ar:
		if typeof(entry) == TYPE_DICTIONARY:
			var newEntry : Dictionary = {}
			
			for key in entry.keys():
				newEntry[key] = fixOldTypeArray(entry[key])
			
			r.append(newEntry)
			continue
		
		if typeof(entry) == TYPE_ARRAY:
			var appended = []
			for subentry in entry:
				if isBodypartIDValid(subentry, avs):
					appended.append(subentry)
			
			if appended:
				r.append(appended if appended.size()>1 else appended[0])
			continue
		
		if entry.begins_with("defaults::"):
			var split = entry.split("::", false, 3)
			if split.size()<3:
				continue
			r.append(entry)
		
		if isBodypartIDValid(entry):
			r.append(entry)
		
	return r

static func isBodypartIDValid(bpid, avs=GlobalRegistry.getBodypartRefs()) -> bool:
	var r = bpid.get_slice("::",0)
	
	if r in avs:
		Log.print(bpid+" valid")
		return true
	
	return false

func applyType(type:Dictionary, _npc, _args) -> void:
	applyOldTypeArray(type.get("normal", []), _npc, _args)
	applyOldTypeArray(type.get("strict", []), _npc, _args, true)
	
	if type.has("display"):
		_npc.npcCustomSpeciesName = type["display"].replace("{DEF}", _npc.getSpeciesFullName())

func applyOldTypeArray(ar:Array, _npc, _args, strict:bool=false) -> void:
	for bodypartID in ar:
		if !bodypartID:
			continue
		
		if typeof(bodypartID) == TYPE_ARRAY:
			bodypartID = RNG.pick(bodypartID)
		
		if typeof(bodypartID) == TYPE_DICTIONARY:
			var currentGender = _npc.npcGender if _npc.npcGender else _npc.npcGeneratedGender
			
			var newApplied : Array = []
			
			if bodypartID.has("with_penis") or bodypartID.has("with_vagina"):
				if currentGender in NpcGender.getAllWithPenis():
					newApplied.append_array(bodypartID.get("with_penis"))
				
				if currentGender in NpcGender.getAllWithVagina():
					newApplied.append_array(bodypartID.get("with_vagina"))
			
			if bodypartID.has(currentGender):
				newApplied.append_array( bodypartID[currentGender] )
			else: # we don't have it, check normal "binary" genders
				currentGender = Gender.genderToString(NpcGender.toNormalGender(currentGender))
				
				newApplied.append_array( bodypartID.get("binary_"+currentGender, bodypartID.get("_", [])) )
			
			applyOldTypeArray(newApplied, _npc, _args, strict)
			continue
			
		
		
		if bodypartID == null:
				continue
		
		if bodypartID.begins_with("defaults::"):
			var split = bodypartID.split("::", false, 3)
			var species = split[1]
			var slot = split[2]
			
			if !species in GlobalRegistry.getAllSpecies():
				continue
			
			var bps = Bodypart.findPossibleBodypartIDs(slot, _npc, [species])
			
			for i in bps.size():
				bps[i] = bps[i][0]
			
			if !bps or !bps[0]:
				continue
			
			bodypartID = RNG.pick(bps)
		
		var method
		
		method = bodypartID.split("::", false, 2)
		bodypartID = method[0]
		method = method[1] if method.size()>1 else null
		
		var bpObject = GlobalRegistry.getBodypartRef(bodypartID)
		var slot = bpObject.getSlot()
		
		if !_npc.hasBodypart(slot):
			if strict: # didn't exist, add
				var new = bpObject.duplicate()
				new.generateDataFor(_npc)
				_npc.giveBodypart(new)
				
				callMethodTypeThing(ar, method, slot, _npc, _args)
				
			
			continue
		
		var oldBP = _npc.getBodypart(slot)
		
		var oldData = oldBP.saveData()
		_npc.removeBodypart(slot)
		
		var new = bpObject.duplicate()
		new.loadData(oldData)
		_npc.giveBodypart(new)
		if method:
			callMethodTypeThing(ar, method, slot, _npc, _args)

func callMethodTypeThing(ar:Array, method, slot:String, _npc, _args) -> void:
	if !method:
		return
	
	var split = method.split(".", false, 2)
	if split.size()!=2:
		return
	
	var mod = GlobalRegistry.getModules().get(split[0])
	if mod==null:
		return
	
	if !mod.has_method(split[1]):
		return
	
	mod.callv(split[1], [ ar, slot, _npc, _args ])

func onDynamicNpcCreation(_npc, _args):
	mimic.onDynamicNpcCreation(_npc, _args)
	
	var mod = GlobalRegistry.getModule("RAT_FluffyArchetypes")
	
	var weights = []
	
	for key in types:
		weights.append(mod.getChanceForType(id+"::"+key))
	
	applyType(RNG.pickWeighted(types.values(), weights), _npc, _args)


## crap default functions
func getVisibleName():
	return mimic.getVisibleName()
	
func getVisibleDescription():
	return mimic.getVisibleDescription()

func getDefaultLegs(_gender):
	return mimic.getDefaultLegs(_gender)

func getDefaultBreasts(_gender):
	return mimic.getDefaultBreasts(_gender)

func getDefaultHair(_gender):
	return mimic.getDefaultHair(_gender)
	
func getDefaultTail(_gender):
	return mimic.getDefaultTail(_gender)

func getDefaultBody(_gender):
	return mimic.getDefaultBody(_gender)

func getDefaultHead(_gender):
	return mimic.getDefaultHead(_gender)
	
func getDefaultArms(_gender):
	return mimic.getDefaultArms(_gender)

func getDefaultEars(_gender):
	return mimic.getDefaultEars(_gender)

func getDefaultHorns(_gender):
	return mimic.getDefaultHorns(_gender)

func getDefaultPenis(_gender):
	return mimic.getDefaultPenis(_gender)

func getDefaultVagina(_gender):
	return mimic.getDefaultVagina(_gender)

func getDefaultAnus(_gender):
	return mimic.getDefaultAnus(_gender)

func getDefaultForSlot(slot, _gender):
	return mimic.getDefaultForSlot(slot, _gender)

func getDefaultForSlotForNpcGender(slot, npcgender):
	return mimic.getDefaultForSlotForNpcGender(slot, npcgender)

func getAllowedBodyparts():
	return mimic.getAllowedBodyparts()

func getAllowedBodypartsFinal() -> Array:
	return mimic.getAllowedBodypartsFinal()

func getAllowedBodypartsForNPCGender(_npcGender:String, _isTF:bool) -> Array:
	return mimic.getAllowedBodypartsForNPCGender(_npcGender, _isTF)

func getAllDefaultBodypartIDsForNPCGender(_npcGender:String) -> Array:
	return mimic.getAllDefaultBodypartIDsForNPCGender(_npcGender)

func isPlayable():
	return mimic.isPlayable()

func getEggCellOvulationAmount():
	return mimic.getEggCellOvulationAmount()

func getEggsOvulationAmount() -> Array:
	return mimic.getEggsOvulationAmount()

func npcGenerationWeight():
	return mimic.npcGenerationWeight()

func canBeUsedForNPCType(_npcType):
	return mimic.canBeUsedForNPCType(_npcType)

func getSkinType():
	return mimic.getSkinType()

func generateSkinColors():
	return mimic.generateSkinColors()

func supportsMane():
	return mimic.supportsMane()

func calculateScoreForSpeciesCalculations(_npc) -> float:
	return mimic.calculateScoreForSpeciesCalculations(_npc)

func generateEggType(_laidEgg:EggLaid) -> int:
	return BigEggType.Fertilized

func generateEggColor(_laidEgg:EggLaid) -> Color:
	return mimic.generateEggColor(_laidEgg)

func onEggLaid(_laidEgg:EggLaid, _eggCell:EggCell):
	.onEggLaid(_laidEgg, _eggCell)

func getEggInventorySpritePath(_laidEgg:EggLaid) -> String:
	return mimic.getEggInventorySpritePath

