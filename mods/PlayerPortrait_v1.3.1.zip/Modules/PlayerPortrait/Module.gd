extends Module

var maxOtherPortraits : float = 0
var currentPortraitPath : String = "user://PlayerPortraits"
var portraitNameColor : Color = Color.white

func _init():
	id = "PlayerPortrait"
	author = "Selinoccino"
	
	worldEdits = [
		"res://Modules/PlayerPortrait/PortraitWorldEdit.gd",
		"res://Modules/PlayerPortrait/PortraitInitWorldEdit.gd",
	]
	
	characters = [
		"res://Modules/PlayerPortrait/FakePlayer.gd",
	]
	

func postInit():
	GlobalRegistry.registerImagePack("res://Modules/PlayerPortrait/PlayerImagePack.gd")
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)
	#doReloadMyPackPleaseAndThankYou()

func doReloadMyPackPleaseAndThankYou():
	var pack = GlobalRegistry.imagePacks.get("RAT_PlayerPortrait")
	if !pack:
		Log.warning(id+": can't find imagepack!")
		return
	
	pack.reloadMyDataPleaseAndThankYou()

func RatConfigure(ratc):
	ratc.overrideModConfigName(id, "Player Portrait (Rat)")
	
	ratc.addOptionNum(id, "maxOtherPortraits", "General", "Max Other Portraits", "Maximum number of other portraits visible, not including the player's one. When there's more than this amount of characters in a tile/scene, the player portrait won't be visible.", 0.0).setStep(1.0).setGreater().setMin(0.0)
	
	ratc.addOptionDirectory(id, "currentPortraitPath", "General", "Portrait Directory", "Points to the folder that contains the images.", "user://PlayerPortraits").setPlayer().setAccess(FileDialog.ACCESS_FILESYSTEM)
	
	ratc.addOptionColor(id, "portraitNameColor", "General", "Portrait Name Color", "Changes the color of your name under the portrait.", Color.white).setPlayer()
