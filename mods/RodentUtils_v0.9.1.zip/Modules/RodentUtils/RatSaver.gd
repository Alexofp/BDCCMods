extends GameExtender

const MOD : String = "RodentUtils"

func _init():
	id = "RAT_RatSaver"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.saveLoadData)

func onNewGameOrLoadStart():
	var rodent = GlobalRegistry.getModule(MOD)
	rodent.RatRegistry.resetData()

func saveData():
	var rodent = GlobalRegistry.getModule(MOD)
	var d : Dictionary = {
		"mods": {
			
		},
		"registry": rodent.RatRegistry.saveData(),
		"playerOptions": rodent.Options.getPlayerSpecificSavedData(),
	}
	
	for mod in rodent.RatRegistry.getSavedMods():
		d["mods"][mod.id] = mod.RatSave()
	
	return d

func loadData(_d):
	if GM.main == null:
		return
	
	var mod : Module = GlobalRegistry.getModule(MOD)
	var ratReg : Reference = mod.RatRegistry
	ratReg.loadData(SAVE.loadVar(_d, "registry"))
	mod.Options.loadPlayerSpecificData(SAVE.loadVar(_d, "playerOptions", {}))
	
	var mods : Dictionary = SAVE.loadVar(_d, "mods", {})
	for savedMod in ratReg.getSavedMods():
		if mods.has(savedMod.id):
			savedMod.RatLoad(mods[savedMod.id])
		else:
			savedMod.RatLoad({"RESET":true})
		
	
	GM.main.reRun()

func sendResetSignalToAll() -> void: # TODO: change when update extenders
	var rodent = GlobalRegistry.getModule(MOD)
	rodent.RatRegistry.loadData({"RESET":true})
	for mod in rodent.RatRegistry.getSavedMods():
		mod.RatLoad({"RESET":true})
