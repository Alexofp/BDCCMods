extends EventBase

func _init(): # TODO: remove when update extenders
	id = "RAT_RatResetter"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene",""])

func react(_id,_args):
	GlobalRegistry.getGameExtender("RAT_RatSaver").sendResetSignalToAll()
