extends Reference

var mods : Array = [] # modconfigs

var sortable : Reference

enum ValueTypes {
	NUM,
	BOOL,
	TEXT,
	DROPDOWN,
	COLOR,
	MULTILINE,
	DIRECTORY,
	FILE,
	
	TOTAL_SIZE
}

class ModConfig:
	var id : String = ""
	var options : Dictionary # category: array[option]
	var nameOverride : String = ""
	var authorOverride : String = ""
	
	func overrideName(n:String) -> ModConfig:
		nameOverride = n
		return self
	
	func overrideAuthor(n:String) -> ModConfig:
		authorOverride = n
		return self
	
	
	func getOptionsInCategory(cat:String) -> Array:
		return options.get(cat, [])
	
	func getAllOptions() -> Array:
		var n : Array = []
		
		for ar in options.values():
			n.append_array(ar)
		
		return n
	
	func hasCategory(cat:String) -> bool:
		return options.has(cat)
	

class Option:
	var id : String = ""
	var valueType : int = 0
	var variantType : int = 0 # godot
	
	var name : String = "Option"
	var desc : String = ""
	
	signal valueChanged
	
	var value = null
	var defaultValue = null
	
	var minValue : float = 0.0
	var maxValue : float = 100.0
	var step : float = 0.1
	var allowGreater : bool = false
	var allowLesser : bool = false
	
	var playerMode : int = 0 # all, player-based, main menu only
	
	var extraData : Dictionary
	
	var dropdowns : Array = []
	
	func restoreDefault() -> void:
		setValue(defaultValue)
	
	func noSlider() -> Option:
		extraData["slider"] = 0
		return self
	
	func alwaysSlider() -> Option:
		extraData["slider"] = 1
		return self
	
	func shouldHaveSlider() -> bool:
		if allowGreater or allowLesser:
			return false
		
		var values = abs(minValue - maxValue) * step
		
		var slidermode : int = getExtra("slider", -1)
		if slidermode==0:
			return false
		
		return slidermode==1 or values<=100.0
	
	func setAccess(access:int) -> Option:
		extraData["access"] = access
		return self
	
	func getExtra(key:String, nullv=null):
		return extraData.get(key, nullv)
	
	func addFileFilter(filter:String) -> void:
		var a : Array = extraData.get_or_add("filters", [])
		a.append(filter)
	
	func getValue():
		var v = getValueSimple()
		return defaultValue if v==null else v
	
	func getValueSimple():
		return value if typeof(value) == variantType else null
	
	func addDropdownOption(d:String) -> Option:
		if valueType == ValueTypes.DROPDOWN:
			dropdowns.append(d)
		return self
	
	func setMin(v:float) -> Option:
		minValue = v
		return self
	
	func setMax(v:float) -> Option:
		maxValue = v
		return self
	
	func setStep(v:float) -> Option:
		step = v
		return self
	
	func setLesser(v:bool=true) -> Option:
		allowLesser = v
		return self
	
	func setGreater(v:bool=true) -> Option:
		allowGreater = v
		return self
	
	func setPlayer() -> Option:
		playerMode = 1
		return self
	
	func setMainMenu() -> Option:
		playerMode = 2
		return self
	
	func setValue(v) -> Option:
		if typeof(v)!=variantType:
			return self
		
		if valueType==ValueTypes.NUM:
			if !allowGreater && v>maxValue:
				v = maxValue
			if !allowLesser && v<minValue:
				v = minValue
			value = stepify(v, step)
		else:
			value = v
		emit_signal("valueChanged", self)
		return self
	


func getMods() -> Array:
	return mods

func setOptionValue(mod:String, category:String, option:String, value) -> void:
	var opt = getOption(mod, category, option)
	
	if opt:
		opt.setValue(value)

func getOption(mod:String, category:String, option:String) -> Option:
	var conf : ModConfig = getModConfig(mod)
	if !conf:
		return null
	
	if !conf.hasCategory(category):
		return null
	
	var opt = sortable.getThing(option, conf.getOptionsInCategory(category))
	return opt


func getOptionValue(mod:String, category:String, option:String):
	var opt : Option = getOption(mod, category, option)
	
	return opt.getValue() if opt else null

func getActualTypeForValueType(valueType:int) -> int:
	if valueType == ValueTypes.BOOL:
		return TYPE_BOOL
	elif valueType == ValueTypes.NUM:
		return TYPE_REAL
	elif valueType in [ValueTypes.DROPDOWN, ValueTypes.TEXT, ValueTypes.MULTILINE, ValueTypes.FILE, ValueTypes.DIRECTORY]:
		return TYPE_STRING
	elif valueType == ValueTypes.COLOR:
		return TYPE_COLOR
	
	return TYPE_NIL

func addModConfig(mod:String) -> ModConfig:
	var m : ModConfig = ModConfig.new()
	m.id = mod
	sortable.addThing(m, mods)
	return m

func addOptionToCategory(op:Option, categoryContents:Array) -> void:
	sortable.addThing(op, categoryContents)

func getModConfig(mod:String) -> ModConfig:
	return sortable.getThing(mod, mods)



func saveToFile() -> bool:
	var f : File = File.new()
	
	var d := Directory.new()
	d.make_dir_recursive("user://RodentUtils")
	
	f.open("user://RodentUtils/RatConfig.json", File.WRITE)
	if !f:
		return false
	
	var res : Dictionary = {
		
	}
	
	for mod in mods:
		res[mod.id] = {}
		for cat in mod.options:
			res[mod.id][cat] = {}
			for op in mod.options[cat]:
				if op.playerMode==1:
					continue
				
				res[mod.id][cat][op.id] = doSaveOption(op)
			
		
	
	var data : String = JSON.print(res, "\t")
	f.store_string(data)
	f.close()
	
	return true

func getPlayerSpecificSavedData() -> Dictionary:
	var res : Dictionary = {}
	for mod in mods:
		res[mod.id] = {}
		for cat in mod.options:
			res[mod.id][cat] = {}
			for op in mod.options[cat]:
				if op.playerMode!=1:
					continue
				res[mod.id][cat][op.id] = doSaveOption(op)
			
		
	
	return res

func loadPlayerSpecificData(data:Dictionary) -> void:
	for mod in getMods():
		for category in mod.options:
			var has : bool = data.get(mod.id, {}).has(category)
			for option in mod.getOptionsInCategory(category):
				if option.playerMode!=1:
					continue
				
				if !has or typeof(data[mod.id][category])!=TYPE_DICTIONARY:
					option.restoreDefault()
					continue
				
				var ar = data[mod.id][category].get(option.id, null)
				if ar==null:
					option.restoreDefault()
					continue
				
				doLoadOption(option, ar)
#
#	for modID in data:
#		var config : ModConfig = getModConfig(modID)
#		if !config:
#			continue
#
#		for category in data[modID]:
#			if !config.hasCategory(category):
#				continue
#
#			# id, value
#			for optionArray in data[modID][category]:
#				var op : Option = getOption(modID, category, optionArray[0])
#				if op && op.isPlayerBased:
#					var v = optionArray[1]
#					doLoadOption(op, v)
		
	

func doSaveOption(option:Option):
	var v = option.getValue()
	if option.valueType == ValueTypes.COLOR:
		v = v.to_html()
	return v

func doLoadOption(option:Option, value) -> void:
	if option.valueType == ValueTypes.COLOR:
		value = Color(value) if value.is_valid_html_color() else option.defaultValue
	option.setValue(value)

func loadFromFile() -> void:
	var f : File = File.new()
	f.open("user://RodentUtils/RatConfig.json", File.READ)
	if !f:
		return
	
	var result = JSON.parse(f.get_as_text())
	if result.error:
		return
	
	var data = result.result
	if typeof(data) != TYPE_DICTIONARY:
		return
	
	for modID in data:
		var config : ModConfig = getModConfig(modID)
		if !config:
			continue
		
		for category in data[modID]:
			if !config.hasCategory(category):
				continue
			
			for key in data[modID][category]:
				var op : Option = getOption(modID, category, key)
				if op:
					var v = data[modID][category][key]
					doLoadOption(op, v)
		



### API
func getOrCreateModConfig(moduleid:String) -> ModConfig:
	var mc : ModConfig = getModConfig(moduleid)
	if !mc:
		mc = addModConfig(moduleid)
	
	return mc

func overrideModConfigName(moduleid:String, new:String) -> void:
	getOrCreateModConfig(moduleid).overrideName(new)

func overrideModConfigAuthor(moduleid:String, new:String) -> void:
	getOrCreateModConfig(moduleid).overrideAuthor(new)

func addOptionBase(moduleid:String, opid:String, cat:String, name:String, desc:String, default, type:int) -> Option:
	var mc : ModConfig = getModConfig(moduleid)
	if !mc:
		mc = addModConfig(moduleid)
	
	var option : Option = Option.new()
	option.id = opid
	option.desc = desc
	option.name = name
	option.valueType = type
	option.variantType = getActualTypeForValueType(type)
	option.defaultValue = default
	var mod : Module = GlobalRegistry.getModule(moduleid)
	if mod && option.id in mod:
		option.setValue(mod.get(option.id))
		option.connect("valueChanged", self, "onOptionChanged", [mod])
	else:
		option.setValue(default)
	
	addOptionToCategory(option, mc.options.get_or_add(cat, []))
	
	return option

func onOptionChanged(option:Option, module:Module) -> void:
	module.set(option.id, option.getValue())

func addCategory(modid:String, cat:String) -> void:
	var mc : ModConfig = getModConfig(modid)
	if !mc:
		mc = addModConfig(modid)
	
	if !mc.hasCategory(cat):
		mc.options[cat] = []

func clearModCategory(modid:String, cat:String) -> void:
	var mc : ModConfig = getModConfig(modid)
	if mc:
		mc.options.erase(cat)

func removeModConfig(modid:String) -> void:
	sortable.removeThing(modid, getMods())

func addOptionNum(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
	return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.NUM)

func addOptionBool(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
	return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.BOOL)

func addOptionText(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
	return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.TEXT)

func addOptionMultiline(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
	return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.MULTILINE)

func addOptionFile(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null, filters:Array=[]) -> Option:
	var op : Option = addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.FILE)
	
	for fil in filters:
		op.addFileFilter(fil)
	
	return op

func addOptionDirectory(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
	return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.DIRECTORY)

func addOptionDropdown(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
		return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.DROPDOWN)

func addOptionColor(moduleid:String, opid:String, cat:String, name:String, desc:String, default=null) -> Option:
	return addOptionBase(moduleid, opid, cat, name, desc, default, ValueTypes.COLOR)

