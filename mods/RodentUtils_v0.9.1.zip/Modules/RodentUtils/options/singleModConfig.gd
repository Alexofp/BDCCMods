extends Control

onready var optionsvb : VBoxContainer = $vb/contents/mod/sc/opsvb
var optionsRef : Reference = GlobalRegistry.getModule("RodentUtils").Options

var butt : PackedScene = load("res://Game/UI/Buttons/BetterButton.tscn")

func _ready() -> void:
	for n in [ $vb/contents/mod/sc, $vb/contents/tabs ]:
		n.connect("gui_input", self, "scroll_gui_input", [n])
	setToConfigAndModule(null, null)

func setToConfigAndModule(config, module:Module) -> void:
	clear()
	if !(config && module):
		$vb/Label.text = "No module selected"
		$vb/author.text = "No author"
		return
	$vb/Label.text = module.id if !config.nameOverride else config.nameOverride
	$vb/author.text = ("Created by %s" % (module.author if module.author else "(unknown)")) if !config.authorOverride else config.authorOverride
	
	var keys = config.options.keys()
	if keys:
		var c = keys.pop_front()
		newTab(c, config.options[c])
		newCategory(config.options[c])
	for cat in keys:
		newTab(cat, config.options[cat])
		
	

func newTab(id:String, options:Array) -> void:
	var t : BetterButton = butt.instance()
	
	t.connect("pressedActually", self, "newCategory", [options])
	
	$vb/contents/tabs/tabs.add_child(t)
	t.mouse_filter = Control.MOUSE_FILTER_PASS
	t.rect_min_size.x = 200
	t.setButtonText(id)
	t.key_label.text = ""

func newCategory(options:Array) -> void:
	Util.delete_children(optionsvb)
	
	var st : bool = GM.main!=null
	for option in options:
		newOption(option, st)
	

func newOption(option, doPlayer:bool=false) -> HBoxContainer:
	var hb := HBoxContainer.new()
	var thingy := Label.new()
	thingy.autowrap = true
	hb.add_child(thingy)
	hb.mouse_filter = Control.MOUSE_FILTER_PASS
	
	hb.rect_min_size.y = int(OPTIONS.isTouchFriendlyUI())*68.0
	
	thingy.mouse_filter = Control.MOUSE_FILTER_PASS
	thingy.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	thingy.size_flags_vertical = Control.SIZE_EXPAND_FILL
	thingy.valign = Label.VALIGN_CENTER
	
	if !option:
		thingy.text = "Bad option"
		return hb
	
	thingy.connect("mouse_entered", GlobalTooltip, "showTooltip", [thingy, option.name, option.desc, false, true])
	
	thingy.connect("mouse_exited", GlobalTooltip, "hideTooltip", [thingy])
	
	thingy.text = option.name
	
	optionsvb.add_child(hb)
	
	var valuesetter : Control = null
	
	var t : int = option.valueType
	var ts = optionsRef.ValueTypes
	var fvalue = option.getValue()
	var stretch : float = 0.25
	
	if (doPlayer && option.playerMode == 2) or (!doPlayer && option.playerMode == 1):
		valuesetter = Label.new()
		valuesetter.text = "Can only be edited from the main menu!" if doPlayer else "Can only be edited in-game!"
		valuesetter.autowrap = true
		valuesetter.self_modulate = Color.lightcoral
	
	elif t == ts.BOOL:
		valuesetter = CheckBox.new()
		valuesetter.pressed = fvalue
		valuesetter.connect("toggled", option, "setValue")
		valuesetter.connect("toggled", self, "updateToggle", [valuesetter])
		valuesetter.flat = true
		updateToggle(valuesetter.pressed, valuesetter)
	elif t == ts.TEXT:
		valuesetter = LineEdit.new()
		valuesetter.text = fvalue
		valuesetter.connect("text_changed", option, "setValue")
		stretch = 0.5
	elif t == ts.MULTILINE:
		valuesetter = TextEdit.new()
		valuesetter.wrap_enabled = true
		stretch = 0.75
		valuesetter.rect_min_size.y = 120
		valuesetter.text = fvalue
		valuesetter.connect("text_changed", self, "setValueForOptionMultiline", [option, valuesetter])
	elif t == ts.NUM:
		valuesetter = SpinBox.new()
		valuesetter.min_value = option.minValue
		valuesetter.max_value = option.maxValue
		valuesetter.step = option.step
		valuesetter.allow_greater = option.allowGreater
		valuesetter.allow_lesser = option.allowLesser
		
		if option.shouldHaveSlider():
			hb.add_child(configureSlider(option))
		
		valuesetter.value = fvalue
		valuesetter.connect("value_changed", option, "setValue")
		
	
	elif t == ts.DROPDOWN:
		valuesetter = OptionButton.new()
		for v in option.dropdowns:
			var idx : int = valuesetter.get_item_count()
			valuesetter.add_item(v)
			if v == fvalue:
				valuesetter.select(idx)
			
		valuesetter.connect("item_selected", self, "setValueForOptionDropdown", [option])
		
	elif t == ts.COLOR:
		valuesetter = ColorPickerButton.new()
		valuesetter.color = fvalue
		
		valuesetter.connect("color_changed", option, "setValue")
	
	elif t in [ts.FILE, ts.DIRECTORY]:
		valuesetter = FileDialog.new()
		valuesetter.access = option.getExtra("access", FileDialog.ACCESS_USERDATA)
		
		valuesetter.current_path = fvalue
		
		var vb := VBoxContainer.new()
		var lab := Label.new()
		var button : BetterButton = butt.instance()
		lab.autowrap = true
		lab.text = fvalue
		
		vb.add_child(button)
		vb.add_child(lab)
		hb.add_child(vb)
		
		button.key_label.text = ""
		
		if t == ts.FILE:
			valuesetter.mode = FileDialog.MODE_OPEN_FILE
			button.setButtonText("Browse files")
			valuesetter.set_filters(PoolStringArray(option.getExtra("filters", [])))
			valuesetter.connect("file_selected", option, "setValue")
		else:
			valuesetter.mode = FileDialog.MODE_OPEN_DIR
			button.setButtonText("Browse directories")
			valuesetter.connect("dir_selected", option, "setValue")
		
		button.connect("pressed", valuesetter, "popup_centered_ratio")
		
		
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vb.size_flags_vertical = Control.SIZE_EXPAND_FILL
		vb.size_flags_stretch_ratio = 0.5
		for node in [lab, button]:
			node.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		
		option.connect("valueChanged", self, "onOptionValueChanged2", [lab])
		lab.connect("tree_exited", option, "disconnect", ["valueChanged", self, "onOptionValueChanged2"])
		
	else:
		valuesetter = Label.new()
		valuesetter.text = "Invalid value type!"
		valuesetter.self_modulate = Color.lightcoral
		valuesetter.autowrap = true
	
	valuesetter.size_flags_stretch_ratio = stretch if stretch else 1.0
	if stretch:
		valuesetter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	valuesetter.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	hb.add_child(valuesetter)
	
	valuesetter.connect("tree_exited", option, "disconnect", ["valueChanged", self, "onOptionValueChanged"])
	
	if !option.is_connected("valueChanged", self, "onOptionValueChanged"):
		option.connect("valueChanged", self, "onOptionValueChanged", [valuesetter])
	
	var b : BetterButton = butt.instance()
	hb.add_child(b)
	
	b.setButtonText("Default")
	b.setTooltipText("Restore default", "")
	b.setIsDisabled(valuesetter is Label)
	b.size_flags_stretch_ratio = 0.25
	
	b.connect("pressedActually", option, "restoreDefault")
	
	b.key_label.text = ""
	
	
	return hb

func setValueForOptionMultiline(option, ml:TextEdit) -> void:
	option.setValue(ml.text)

func setValueForOptionDropdown(idx:int, option) -> void:
	if idx < option.dropdowns.size():
		option.setValue(option.dropdowns[idx])

func onOptionValueChanged(option, valuesetter) -> void:
	if !is_instance_valid(valuesetter):
		return
	var fv = option.getValue()
	if valuesetter is Range:
		valuesetter.value = fv
	elif valuesetter is LineEdit or valuesetter is TextEdit or valuesetter is Label:
		if valuesetter.text != fv:
			valuesetter.text = fv
	elif valuesetter is CheckBox:
		valuesetter.set_pressed_no_signal(bool(fv))
		updateToggle(valuesetter.pressed, valuesetter)
	elif valuesetter is OptionButton:
		var idx : int = option.dropdowns.find(fv)
		if idx!=-1:
			valuesetter.select(idx)
			valuesetter.text = option.dropdowns[idx]
	elif valuesetter is ColorPickerButton:
		valuesetter.color = fv 
	elif valuesetter is FileDialog:
		valuesetter.current_path = fv

func updateToggle(state:bool, cbutt) -> void:
	cbutt.text = "Yes" if state else "No"

func clear() -> void:
	Util.delete_children($vb/contents/tabs/tabs)
	Util.delete_children(optionsvb)
	GlobalTooltip.resetTooltips()

func configureSlider(option) -> HSlider:
	var h := HSlider.new()
	
	h.min_value = option.minValue
	h.max_value = option.maxValue
	h.value = option.getValue()
	h.step = option.step
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	h.connect("tree_exiting", h, "disconnect", ["value_changed", self, "onSliderValueChanged"])
	
	h.connect("value_changed", self, "onSliderValueChanged", [option])
	
	if !option.is_connected("valueChanged", self, "onOptionValueChanged2"):
		option.connect("valueChanged", self, "onOptionValueChanged2", [h])
		h.connect("tree_exited", option, "disconnect", ["valueChanged", self, "onOptionValueChanged2"])
	
	return h

func onOptionValueChanged2(option, vs) -> void:
	onOptionValueChanged(option, vs)

func onSliderValueChanged(value:float, option) -> void:
	if $Timer.is_stopped():
		print("aa")
		option.setValue(value)
		$Timer.start()
	

func scroll_gui_input(event: InputEvent, sc:ScrollContainer) -> void:
	if event is InputEventMouseMotion:
		if event.pressure>0.5:
			sc.scroll_horizontal -= event.relative.x*2
			sc.scroll_vertical -= event.relative.y*2
	

