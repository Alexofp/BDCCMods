extends Control

onready var modst : VBoxContainer = $hb/vb/hb/vb/pc/sc/modsvb

var optionsRef : Reference = GlobalRegistry.getModule("RodentUtils").Options

var butt : PackedScene = load("res://Game/UI/Buttons/BetterButton.tscn")

func _exit_tree() -> void:
	GlobalRegistry.getModule("RodentUtils").emit_signal("configClosed")

func _ready() -> void:
	if GM.main:
		$hb/vb/hb/vb/back.setButtonText("<- Back")
		$hb/vb/hb/vb/back.myTooltipName = "Back"
	popMods()
	$hb/vb/hb/vb/back.key_label.text = ""

func popMods() -> void:
	Util.delete_children(modst)
	GlobalTooltip.resetTooltips()
	
	for mod in optionsRef.getMods(): # modconfigs
		var module : Module = GlobalRegistry.getModule(mod.id)
		createModEntry(module, mod)
	


func createModEntry(mod:Module, config) -> BetterButton:
	var t : BetterButton = butt.instance()
	
	modst.add_child(t)
	
	t.align = Button.ALIGN_LEFT
	
	t.mouse_filter = Control.MOUSE_FILTER_PASS
	t.key_label.text = ""
	
	if !(mod && config):
		t.setButtonText("Bad mod")
		t.myTooltipDesc = "Bad mod description"
		return t
	
	var disp : String = mod.id if !config.nameOverride else config.nameOverride
	t.setButtonText(disp)
	t.setTooltipText(disp, disp)
	t.myTooltipDesc = "Created by: %s" % (mod.author if mod.author else "(unknown)")
	
	t.connect("pressed", self, "onModButtonPressed", [config, mod])
	
	return t


func onModButtonPressed(config, mod:Module) -> void:
	$hb/vb/hb/vb2/singleModConfig.setToConfigAndModule(config, mod)


func saveToFile() -> void:
	optionsRef.saveToFile()

func _on_back_pressed() -> void:
	saveToFile()
	queue_free()



func drag(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if event.pressure>0.5:
			$hb/vb/hb/vb/pc/sc.scroll_horizontal -= event.relative.x
			$hb/vb/hb/vb/pc/sc.scroll_vertical -= event.relative.y
	

