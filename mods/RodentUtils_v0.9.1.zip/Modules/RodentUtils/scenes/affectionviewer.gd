extends SceneBase

var currentaffection : String = ""

var quickref : Reference

func _init():
	sceneID = "RAT_AffectionMenu"
	if GM.main:
		quickref = getModule("RodentUtils").RatRegistry

func displayOneAffection(affection:Reference) -> void:
	if affection:
		saynn(affection.getDisplay())
	else:
		saynn("ERROR: No such affection!")

func getRatRegistry() -> Reference:
	return quickref

func _run():
	if state == "":
		saynn("Your affections:")
		
		addButton("Done", "", "end")
		
		for affection in getRatRegistry().affections:
			saynn(affection.getVisibleName())
#			displayOneAffection(affection)
			addButton("View %s" % affection.getVisibleName(), "View this affection\n\n"+affection.getDescription(), "selectaffection", [affection.id])
			
		
		return
	
	if state == "viewaffection":
		var af = getRatRegistry().getAffection(currentaffection)
		displayOneAffection(af)
		if af:
			for fieldid in af.fields:
				var field = af.fields[fieldid]
				addButton("add %s" % field.name, "add 5", "addfield", [af, fieldid, 5])
				addButton("remove %s" % field.name, "remove 3", "addfield", [af, fieldid, -3])
		addButton("Back", "", "")

func _react(action:String, _args):
	if action == "end":
		endScene()
		return
	
	if action == "addfield":
		_args[0].addValue(_args[1], _args[2])
		
		setState("viewaffection")
		return
	
	if action == "selectaffection":
		if !_args:
			setState("")
			return
		
		currentaffection = _args[0]
		
		setState("viewaffection")
		return
	
	setState(action)

func saveData():
	var d = .saveData()
	d["currentaffection"] = currentaffection
	return d

func loadData(d):
	.loadData(d)
	currentaffection = SAVE.loadVar(d, "currentaffection", "")
