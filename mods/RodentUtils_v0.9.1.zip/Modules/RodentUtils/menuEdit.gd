extends WorldEditBase

var rb : Button = null

func _init():
	id = "RAT_RUMenu"
	
func apply(_world: GameWorld):
		if GM.ui && !is_instance_valid(rb):
			rb = Button.new()
			rb.text = "RatConfig"
			
			var resume = GM.ui.ingameMenuScreen.resume_button
			resume.connect("resized", self, "updthingy", [resume])
			updthingy(resume)
			
			rb.connect("pressed", self, "onPress")
			
			resume.get_parent().add_child(rb)


func updthingy(thing:Control) -> void:
	if rb:
		rb.rect_min_size = thing.rect_size

func onPress() -> void:
	if !GM.ui:
		return
	
	GM.ui.hideAllScreens()
	GM.ui.ingameMenuScreen.show()
	GM.ui.ingameMenuScreen.hideAllMenus()
	for button in [GM.ui.load_button, GM.ui.save_button, GM.ui.skillsButton, GM.ui.rollbackButton, GM.ui.debugPanelButton]:
		button.disabled = true
	
	var a : Control = load("res://Modules/RodentUtils/options/modsListAndMenuYayColonThree.tscn").instance()
	
	GM.ui.get_node("%MenuButton").connect("pressed", a, "queue_free")
	
	GM.ui.ingameMenuScreen.add_child(a)
	a.connect("tree_exiting", self, "onExit")

func onExit() -> void:
#	GM.ui.ingameMenuScreen.hideAllMenus()
#	GM.ui.ingameMenuScreen.mainMenuScreen.show()
	GM.ui.updateButtons()
	GM.ui.debugPanelButton.disabled = !OPTIONS.isDebugPanelEnabled()
	GM.ui.ingameMenuScreen.mainMenuScreen.visible = true
