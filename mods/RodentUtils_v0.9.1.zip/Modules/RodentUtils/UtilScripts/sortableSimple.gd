extends Reference

func getNewIdx(id, dar:Array) -> int:
	return dar.bsearch(id)

func getThing(id, dar:Array, nullv=null):
	var idx : int = getIdx(id, dar)
	
	return nullv if idx==-1 else dar[idx]

func getIdx(id, dar:Array) -> int:
	var idx : int = getNewIdx(id, dar)
	if idx >= dar.size():
		return -1
	
	return idx if id==dar[idx] else -1

func addThing(entry, dar:Array) -> void: # replace if need be
	var idx : int = getNewIdx(entry, dar)
	if idx>=dar.size() or entry!=dar[idx]:
		dar.insert(idx, entry)
		return
	dar[idx] = entry

func removeThing(id, dar:Array) -> void:
	var idx : int = getIdx(id, dar)
	if idx!=-1:
		dar.remove(idx)

func getOrAddThing(id, dar, nullv=null):
	var idx : int = getNewIdx(id, dar)
	if idx >= dar.size():
		dar.insert(idx, nullv)
		return dar[idx]
	
	if id==dar[idx]:
		return dar[idx]
	
	# not right
	dar.insert(idx, nullv)
	return dar[idx]
	
