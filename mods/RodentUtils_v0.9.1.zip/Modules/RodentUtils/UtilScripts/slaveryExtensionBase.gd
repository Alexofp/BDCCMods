extends Reference

func getID() -> String:
	return ""

func onSlaveryStart() -> void:
	return

func onSlaveryEnd() -> void:
	return

func processTurn() -> void:
	return

func getLateActions() -> Array:
	return []

func getActions() -> Array:
	return []

func doAction(_action) -> bool:
	return false

func createIcons() -> void:
	return

func clearIcons() -> void:
	return

func onNewDay() -> void:
	return

func saveData() -> Dictionary:
	return {}

func loadData(_d:Dictionary) -> void:
	return
