extends "res://Modules/RodentUtils/UtilScripts/slaveryExtensionBase.gd"

class Item:
	var id : String
	var name : String = "Item"
	
	var texture : String
	var location : String
	
	var extraData : Dictionary = {}
	
	func _init(i:String):
		self.id = i
	
	func setName(n:String) -> Item:
		self.name = n
		return self
	
	func setTexture(n:String) -> Item:
		self.texture = n
		return self
	
	func setData(d:Dictionary) -> Item:
		self.extraData = d
		return self
	
	func saveData() -> Dictionary:
		return {
			id = id,
			name = name,
			texture = texture,
			location = location,
			extraData = extraData
		}
	
	func loadData(d:Dictionary) -> void:
		id = SAVE.loadVar(d, "id", "")
		name = SAVE.loadVar(d, "name", "")
		location = SAVE.loadVar(d, "location", "")
		texture = SAVE.loadVar(d, "texture", "")
		extraData = SAVE.loadVar(d, "extraData", {})
	
	func setLoc(_newLoc:String) -> void:
		location = _newLoc
		GM.world.moveEntity(id, location)
	
	func setLocVariable(n:String) -> Item:
		self.location = n
		return self
	
	func createIcon() -> bool:
		if !id:
			return false
		
		GM.world.createEntity(id, load(texture), location)
		return true
	

var items : Array = [
	
]

var itemSortable : Reference = GlobalRegistry.getModule("RodentUtils")\
	.createSortable().setObject(self)\
	.setComparison("are_items_same").setSort("sort_items")

func are_items_same(a, b) -> bool:
	if a is Item:
		a = a.id
	if b is Item:
		b = b.id
	
	return a == b

func sort_items(a, b) -> bool:
	if a is Item:
		a = a.id
	if b is Item:
		b = b.id
	
	return a < b

func getItem(id:String, dar:Array=items) -> Item:
	return itemSortable.getThing(id, dar)

func removeItem(id:String, dar:Array=items) -> void:
	itemSortable.removeThing(id, dar)

func addItem(item:Item, dar:Array=items) -> void:
	itemSortable.addThing(item, dar)

func onSlaveryStart() -> void:
	createItemsFull()

func createItemsFull() -> void:
	clearIcons()
	items.clear()
	createItems()

func createItems() -> void:
	return

func getLateActions() -> Array:
	return []

func getActions() -> Array:
	var acts : Array = []
	var loc : String = GM.pc.getLocation()
	var slv : PlayerSlaveryBase = GM.main.PS
	for item in items:
		if item.location == loc && slv.getPlayerItem(item.id)==null:
			acts.append(slv.Action.new("pickup").setName("Pick up %s" % item.name).setDesc("Pick this item up").setArgs([item]))
	
	return acts

func clearIcons() -> void:
	for item in items:
		GM.world.deleteEntity(item.id)

func saveData() -> Dictionary:
	var d : Dictionary = {
		"items":[]
	}
	
	for item in items:
		d["items"].append(item.saveData())
	
	return d

func loadData(d:Dictionary) -> void:
	items.clear()
	
	for itemdict in SAVE.loadVar(d, "items", []):
		var it : Item = Item.new("")
		it.loadData(itemdict)
		if it.createIcon():
			items.append(it)
		
	
	items.sort_custom(self, "sort_items")
