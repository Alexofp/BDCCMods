extends Reference

var sort_obj : Object
var sort_method : String
var comparison_method : String

func setObject(o:Object) -> Reference:
	self.sort_obj = o
	return self

func setSort(s:String) -> Reference:
	self.sort_method = s
	return self

func setComparison(c:String) -> Reference:
	self.comparison_method = c
	return self

func getNewIdx(id, dar:Array) -> int:
	return dar.bsearch_custom(id, sort_obj, sort_method)

func getThing(id, dar:Array, nullv=null):
	var idx : int = getIdx(id, dar)
	
	return nullv if idx==-1 else dar[idx]

func getIdx(id, dar:Array) -> int:
	var idx : int = getNewIdx(id, dar)
	if idx >= dar.size():
		return -1
	
	return idx if sort_obj.callv(comparison_method, [id, dar[idx]]) else -1

func addThing(entry, dar:Array) -> void: # replace if need be
	var idx : int = getNewIdx(entry, dar)
	if idx>=dar.size() or !sort_obj.callv(comparison_method, [entry, dar[idx]]):
		dar.insert(idx, entry)
		return
	dar[idx] = entry

func removeThing(id, dar:Array) -> void:
	var idx : int = getIdx(id, dar)
	if idx!=-1:
		dar.remove(idx)

func getOrAddThing(id, dar, nullv=null):
	var idx : int = getNewIdx(id, dar)
	if idx >= dar.size():
		dar.insert(idx, nullv)
		return dar[idx]
	
	if sort_obj.callv(comparison_method, [id, dar[idx]]):
		return dar[idx]
	
	# not right
	dar.insert(idx, nullv)
	return dar[idx]
	
