extends Reference

var id : String

var fields : Dictionary = {
	# id : Field
}

class Field:
	var name : String
	var value : int = 0
	var maxValue : int = -1 # no max
	var minValue : int = 0 # min always there
	var hidden : bool = false
	
	func setName(n:String) -> Field:
		self.name = n
		return self
	
	func setValue(n:int) -> Field:
		self.value = n
		return self
	
	func setMaxValue(n:int) -> Field:
		self.maxValue = n
		return self
	
	func setMinValue(n:int) -> Field:
		self.minValue = n
		return self
	
	func setHidden(b:bool=true) -> Field:
		self.hidden = b
		return self
	

func _init() -> void:
	createFields()

func getDisplay() -> String:
	var v : String = "%s\n[i]%s[/i]\n" % [ getVisibleName(), getDescription() ]
	
	for field in fields.values():
		if field.hidden:
			continue
		v += "\n%s: %s" % [ field.name, field.value ]
		if field.maxValue>=0:
			v += "/%s" % field.maxValue
	
	return v

func resetData() -> void:
	fields.clear()
	createFields()

func createFields() -> void:
	return

func addValue(fid:String, v:int) -> void:
	var field : Field = fields.get(fid, null)
	if field:
		addValueDirect(field, v, !field.hidden)

func addValueManual(fid:String, v:int, message:bool=false) -> void:
	var f : Field = fields.get(fid, null)
	if f:
		addValueDirect(f, v, message)

func addValueDirect(f:Field, v:int, message:bool=false) -> void:
	var fv : int = Util.maxi(f.minValue, v + f.value)
	
	if f.maxValue>=0:
		fv = Util.mini(f.maxValue, fv)
	var diff = fv - f.value
	f.setValue(fv)
	if message:
		var text : String = "remained unchanged"
		if diff != 0:
			text = "%s by %s" % [("decreased" if diff<0 else "increased"), abs(diff)]
		GM.main.addMessage("Your %s %s has %s" % [
			getVisibleName(), f.name, text
		])

func setValue(fid:String, v:int) -> void:
	var f : Field = fields.get(fid, null)
	if fid:
		f.setValue(v)

func getVisibleName() -> String:
	return "Bad affection"

func getDescription() -> String:
	return "BAD RAT FILL IN"

func getValue(fid:String) -> int:
	var f : Field = fields.get(fid, null)
	return f.value if f else 0

func saveData() -> Dictionary:
	var d : Dictionary = {}
	for fieldid in fields:
		d[fieldid] = fields[fieldid].value
	return d

func loadData(_d:Dictionary) -> void:
	if _d.get("RESET", false):
		resetData()
		return
	
	for fieldid in fields:
		fields[fieldid].setValue(SAVE.loadVar(_d, fieldid, 0))
