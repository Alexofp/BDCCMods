extends PartSkinBase

func _init():
	id = "equinetaperedscarred"
	partID = "equinepenistapered"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineScarred.png"),
	}
