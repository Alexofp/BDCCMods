extends PartSkinBase

func _init():
	id = "equinetaperedpierced"
	partID = "equinepenistapered"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquinePierced.png"),
	}
