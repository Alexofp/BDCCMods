extends PartSkinBase

func _init():
	id = "equinetaperedtribal"
	partID = "equinepenistapered"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineTribal.png"),
	}
