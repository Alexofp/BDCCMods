extends PartSkinBase

func _init():
	id = "equineknotmottled1"
	partID = "equinepenisknot"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedMottled1.png"),
	}
