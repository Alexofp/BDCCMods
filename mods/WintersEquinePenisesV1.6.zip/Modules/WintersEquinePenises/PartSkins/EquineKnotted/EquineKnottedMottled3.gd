extends PartSkinBase

func _init():
	id = "equineknotmottled3"
	partID = "equinepenisknot"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedMottled3.png"),
	}
