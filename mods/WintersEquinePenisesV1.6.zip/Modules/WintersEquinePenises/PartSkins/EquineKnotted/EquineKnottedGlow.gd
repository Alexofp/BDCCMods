extends PartSkinBase

func _init():
	id = "equineknotglow"
	partID = "equinepenisknot"

func getName():
	return "Glow"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedGlow.png"),
		"limp": load("res://Player/Player3D/SkinsParts/Penis/OviPenis/Gradient_limp.png"),
	}
