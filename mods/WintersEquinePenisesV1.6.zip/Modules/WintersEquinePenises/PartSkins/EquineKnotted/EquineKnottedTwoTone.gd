extends PartSkinBase

func _init():
	id = "equineknottwotone"
	partID = "equinepenisknot"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedTwoTone.png"),
	}
