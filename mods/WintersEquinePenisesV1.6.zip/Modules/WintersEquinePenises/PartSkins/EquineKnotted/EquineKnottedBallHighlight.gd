extends PartSkinBase

func _init():
	id = "equineknothighlight"
	partID = "equinepenisknot"

func getName():
	return "Ball Highlight"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedBallHighlight.png"),
		"limp": load("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineBalls_limp.png"),
	}
	
	 
