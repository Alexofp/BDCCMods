extends PartSkinBase

func _init():
	id = "equineknotmottled2"
	partID = "equinepenisknot"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedMottled2.png"),
	}
