extends PartSkinBase

func _init():
	id = "equinebarbgradient"
	partID = "equinepenisbarb"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineGradient.png"),
	}
