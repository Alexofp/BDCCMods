extends PartSkinBase

func _init():
	id = "equinebarbglow"
	partID = "equinepenisbarb"

func getName():
	return "Glow"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineGlow.png"),
		"limp": load("res://Player/Player3D/SkinsParts/Penis/OviPenis/Gradient_limp.png"),
	}
