extends PartSkinBase

func _init():
	id = "equinebarbknotmottled2"
	partID = "equinepenisbarbknot"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedMottled2.png"),
	}
