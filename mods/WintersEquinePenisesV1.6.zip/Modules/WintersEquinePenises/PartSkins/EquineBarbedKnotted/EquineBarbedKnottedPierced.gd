extends PartSkinBase

func _init():
	id = "equinebarbknotpierced"
	partID = "equinepenisbarbknot"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/PartSkins/Assets/EquineKnottedPierced.png"),
	}
