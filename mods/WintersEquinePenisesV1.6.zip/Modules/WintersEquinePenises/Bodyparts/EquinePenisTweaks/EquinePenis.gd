extends "res://Player/Bodyparts/Penis/EquinePenis.gd"

func getDoll3DScene():
	return "res://Modules/WintersEquinePenises/Bodyparts/EquinePenisTweaks/EquinePenis.tscn"
