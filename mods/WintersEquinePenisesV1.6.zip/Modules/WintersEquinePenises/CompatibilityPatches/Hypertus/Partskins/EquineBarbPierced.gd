extends PartSkinBase

func _init():
	id = "equinebarbpiercedhyperable"
	partID = "equinepenisbarbhyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbPierced.png"),
	}
	
	 
