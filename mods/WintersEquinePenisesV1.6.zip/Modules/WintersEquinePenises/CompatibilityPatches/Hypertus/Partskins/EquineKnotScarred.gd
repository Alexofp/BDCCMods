extends PartSkinBase

func _init():
	id = "equineknotscarredhyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotScarred.png"),
	}
	
	 
