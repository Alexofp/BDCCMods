extends PartSkinBase

func _init():
	id = "equinebarbknotmottled2hyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPattern2.png"),
	}
	
	 
