extends PartSkinBase

func _init():
	id = "equineknottribalhyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotTribal.png"),
	}
	
	 
