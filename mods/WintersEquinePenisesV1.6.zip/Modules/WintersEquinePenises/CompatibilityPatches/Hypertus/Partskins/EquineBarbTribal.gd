extends PartSkinBase

func _init():
	id = "equinebarbtribalhyperable"
	partID = "equinepenisbarbhyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbTribal.png"),
	}
	
	 
