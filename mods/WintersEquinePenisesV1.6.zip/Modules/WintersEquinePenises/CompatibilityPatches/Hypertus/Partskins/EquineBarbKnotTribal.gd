extends PartSkinBase

func _init():
	id = "equinebarbknottribalhyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotTribal.png"),
	}
	
	 
