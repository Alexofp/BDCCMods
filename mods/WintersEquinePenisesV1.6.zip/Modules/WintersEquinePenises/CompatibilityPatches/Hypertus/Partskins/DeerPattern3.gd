extends PartSkinBase

func _init():
	id = "deermottled3hyperable"
	partID = "equinepenistaperedhyperable"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineMottled3.png"),
	}
	
	 
