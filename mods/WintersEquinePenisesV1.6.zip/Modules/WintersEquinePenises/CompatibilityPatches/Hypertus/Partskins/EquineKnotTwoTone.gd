extends PartSkinBase

func _init():
	id = "equineknottwotonehyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotTwoTone.png"),
	}
	
	 
