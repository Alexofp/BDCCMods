extends DialogueFormBank

func getForms() -> Dictionary:
	return {
		"BrutalDreamsAttack": form("I'm gonna enjoy this!", {Reacter=CHAR, Starter=CHAR}, "Starter", "Reacter"),
		"BrutalDreamsFight": form("A feisty one! Good...", {Reacter=CHAR, Starter=CHAR}, "Starter", "Reacter"),
		"BrutalDreamsSurrender": form("Damn, I was looking forward to beating your sorry ass.", {Reacter=CHAR, Starter=CHAR}, "Starter", "Reacter"),
		"BrutalDreamsMercy": form("Don't hurt me!", {Starter=CHAR, Reacter=CHAR}, "Reacter", "Starter"),
		"BrutalDreamsCocky": form("Bring it on asshole!", {Starter=CHAR, Reacter=CHAR}, "Reacter", "Starter")
	}
