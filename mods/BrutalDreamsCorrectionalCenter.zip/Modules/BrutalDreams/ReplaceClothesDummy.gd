extends GlobalTask

func _init():
	id = "ReplaceClothesDummy"
	goalID = "ReplaceClothes"
	maxAssignedUnscaled = 30

func canDoTask(_pawn:CharacterPawn) -> bool:
	return !_pawn.isPlayer()
