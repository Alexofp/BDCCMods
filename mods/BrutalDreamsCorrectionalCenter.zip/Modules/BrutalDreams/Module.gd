extends Module

var formBanks = [
	"res://Modules/BrutalDreams/BrutalDreams.gd",
]

var GlobalTasks = [
	"res://Modules/BrutalDreams/BrutalDreamsChase.gd",
	"res://Modules/BrutalDreams/ReplaceClothesDummy.gd",
]

var Interactions = [
	"res://Modules/BrutalDreams/BrutalDreamsAttack.gd",
]

# [ PlaceBeforeTarget, Target, PlaceAfterTarget ]
#var DomHooks = [
#	["", "itemState.remove()", "\n\t\ttheitem.removeXOrDestroy(1)"],
#]

#var PlayerHooks = [
#	["#", "for item in getInventory().getEquppedRestraints():", ""],
#	["#", "item.getRestraintData().resetOnNewDay()", ""],
#]

# [ targetFile1, [
#	[ PlaceBeforeTarget1, Target1, PlaceAfterTarget1 ], 
#	[ PlaceBeforeTarget2, Target2, PlaceAfterTarget2 ],
#	]],
# [ targetFile2, [
#	[ PlaceBeforeTarget3, Target3, PlaceAfterTarget3 ],
#	]],
# ]
var hooks = [
	["res://Player/Player.gd", [
		["#", "for item in getInventory().getEquppedRestraints():\n\t\titem.getRestraintData().resetOnNewDay()", "\n\tprint(\"Brutal Dreams: Prevented Restraint Tightening on sleep\")"],
		["#", "item.getRestraintData().resetOnNewDay()", ""],
	]],
	["res://Game/SexEngine/SexActivity/DomUndressesSub.gd", [
		["", "itemState.remove()", "\n\t\ttheitem.removeXOrDestroy(1)\n\t\tprint(\"Brutal Dreams: Removed item during DomUndressesSub\")"],
		["#", "print(\"Brutal Dreams: Failed to remove item in DomUndressesSub\")", "",]
	]],
]

var hooksHolder = []

func _init():
	id = "BrutalDreams"
	author = "Mindstormsman"
	
	for target in hooks:
		var codeBase = load(target[0])
		var originalCode = codeBase.source_code
		var modifiedCode = originalCode
		for hook in target[1]:
			modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
		codeBase.source_code = modifiedCode
		codeBase.reload()
		hooksHolder.append(codeBase)
	
	print("Brutal Dreams: Hooks Applied")

func register():
	.register()
	
	for formBank in formBanks:
		var theBank = load(formBank).new()
		ModularDialogue.registerFormBank(theBank)
	
	for Task in GlobalTasks:
		GlobalRegistry.registerGlobalTask(Task)
	
	for Interaction in Interactions:
		GlobalRegistry.registerInteraction(Interaction)
