extends Module

var formBanks = [
	"res://Modules/BrutalDreams/BrutalDreams.gd",
]

var GlobalTasks = [
	"res://Modules/BrutalDreams/BrutalDreamsChase.gd",
	"res://Modules/BrutalDreams/ReplaceClothesDummy.gd",
]

var Interactions = [
	"res://Modules/BrutalDreams/BrutalDreamsAttack.gd",
]

func _init():
	id = "BrutalDreams"
	author = "Mindstormsman"

func register():
	.register()
	
	for formBank in formBanks:
		var theBank = load(formBank).new()
		ModularDialogue.registerFormBank(theBank)
	
	for Task in GlobalTasks:
		GlobalRegistry.registerGlobalTask(Task)
	
	for Interaction in Interactions:
		GlobalRegistry.registerInteraction(Interaction)
