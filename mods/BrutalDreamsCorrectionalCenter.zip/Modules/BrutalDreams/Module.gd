extends Module

# Debug - save modified code to user folder
var debug = false
var debugExportPath = "user://BrutalDreamsDebugExports/"

var formBanks = [
	"res://Modules/BrutalDreams/BrutalDreams.gd",
]

var GlobalTasks = [
	"res://Modules/BrutalDreams/BrutalDreamsChase.gd",
	"res://Modules/BrutalDreams/ReplaceClothesDummy.gd",
]

var Interactions = [
	"res://Modules/BrutalDreams/BrutalDreamsAttack.gd",
]

# [ targetFile1, [
#	[ PlaceBeforeTarget1, Target1, PlaceAfterTarget1 ],
#	[ PlaceBeforeTarget2, Target2, PlaceAfterTarget2 ],
#	]],
# [ targetFile2, [
#	[ PlaceBeforeTarget3, Target3, PlaceAfterTarget3 ],
#	]],
# ]

# make sure your \n and \t are correct or the script won't parse!
# you can use +\ to split the string over multiple lines making it easier to read

var hooks = [
	["res://Player/Player.gd", [
		["pass #", "item.getRestraintData().resetOnNewDay()", "\n\tprint(\"Brutal Dreams: Prevented Restraint Tightening on sleep\")"],
	]],
	["res://Game/SexEngine/SexActivity/DomUndressesSub.gd", [
		["", "itemState.remove()", "\n\t\ttheitem.removeXOrDestroy(1)\n\t\tprint(\"Brutal Dreams: Removed item during DomUndressesSub\")"],
	]],
]

# Hold them in memory, our changes don't exist on disk at res://
var hooksHolder = []

func exportModifiedFile(fileName, fileContent):
	var file = File.new()
	var path = debugExportPath
	var fullPath = path + fileName
	print("Exporting to "+ fullPath)
	var error = file.open(fullPath, File.WRITE)
	if(!error):
		file.store_line(fileContent)
		file.close()
	else: print("Error "+str(error)+" opening path: "+fullPath)

func applyHooks():

	if OS.has_feature("editor"):
		debug = true

	if(debug):
		var dir = Directory.new()
		var error = dir.make_dir(debugExportPath)
		if(error and (error != 32)):
			print("Error "+str(error)+" creating directory "+debugExportPath)
			debug = false

	for target in hooks:
		var codeBase = load(target[0])
		var originalCode = codeBase.source_code
		var modifiedCode = originalCode
		for hook in target[1]:
			modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
		codeBase.source_code = modifiedCode
		var error = codeBase.reload()
		if( error != 0):
			print("Error code "+str(error)+" reloading target at path: "+target[0])
		hooksHolder.append(codeBase)
		if(debug): exportModifiedFile(target[0].get_file(), modifiedCode)

	print("Brutal Dreams: Hooks Applied")

func _init():
	id = "BrutalDreams"
	author = "Mindstormsman"
	
	applyHooks()

func register():
	.register()
	
	for formBank in formBanks:
		var theBank = load(formBank).new()
		ModularDialogue.registerFormBank(theBank)
	
	for Task in GlobalTasks:
		GlobalRegistry.registerGlobalTask(Task)
	
	for Interaction in Interactions:
		GlobalRegistry.registerInteraction(Interaction)
