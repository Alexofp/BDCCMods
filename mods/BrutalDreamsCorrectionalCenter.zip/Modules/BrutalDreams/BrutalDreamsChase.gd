extends GlobalTask

var BadLoc:Array = ["main_punishment_spot", "gym_secret", "yard_novaspot",
"main_stairs1", "main_stairs2", "hall_checkpoint", "hall_elevator", "mining_elevator"]
var BadFloor:Array = ["FightClubFloor", "Cellblock", "Medical"]

func _init():
	id = "BrutalDreamsChase"
	goalID = "Chase"
	maxAssignedUnscaled = 0

func canDoTask(_pawn:CharacterPawn) -> bool:
	var loc:String = GM.pc.getLocation()
	var playerFloor = GM.world.getRoomByID(loc).getFloorID()
	var pawnName = _pawn.getChar().getName()
	
	if !_pawn.isInmate():
		# Don't print to avoid spam
		#print(pawnName + " can't chase, not an inmate.")
		return false
	
	if !GM.main.playerCanBeInterrupted():
		print(pawnName + " can't chase, player busy.")
		return false 
	
	if _pawn.isPlayer():
		# Don't chase yourself, silly
		return false
	
	for i in BadLoc:
		if loc == i:
			print(pawnName + " can't chase, player in " + i + ".")
			return false
	
	for i in BadFloor:
		if playerFloor == i:
			print(pawnName + " can't chase, player on floor " + i + ".")
			return false
	
	return true

func configureGoal(_pawn:CharacterPawn, _goal):
	_goal.pawnIDTarget = "pc"
