extends PawnInteractionBase

func _init():
	id = "BrutalDreamsAttack"

func start(_pawns:Dictionary, _args:Dictionary):
	print("Brutal Attack!")
	doInvolvePawn("Starter", _pawns["Starter"])
	doInvolvePawn("Reacter", _pawns["Reacter"])
	setState("", "Reacter")

func shouldRunOnMeet(_pawn1, _pawn2, _pawn2Moved:bool):
	
	if(!_pawn1.canBeInterrupted() || !_pawn2.canBeInterrupted()):
		return [false]
	
	if(_pawn2.isInmate() && _pawn1.isPlayer()):
		var pawnTemp = _pawn1
		_pawn1 = _pawn2
		_pawn2 = pawnTemp
	
	if(_pawn1.isInmate() && _pawn2.isPlayer()):
		return [RNG.chance(5), {Starter=_pawn1.charID, Reacter=_pawn2.charID}, {}]
	
	return [false]

func getActivityIconForRole(_role:String):
	return RoomStuff.PawnActivity.Chat

func init_text():
	sayLine("Starter", "BrutalDreamsAttack", {Starter="Starter", Reacter="Reacter"})
	sayLine("Reacter", "AttackReact", {main="Reacter", target="Starter"})

	addAction("fight", "Fight!", "Protect yourself!", "fight", 1.0, 60, {})
	addAction("surrender", "Surrender", "Maybe they won't be mean", "surrender", 1.0, 60, {})

func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "fight"):
		setState("about_to_fight", "Reacter")
	if(_id == "surrender"):
		setState("surrendered", "Starter")

func about_to_fight_text():
	saynn("{Reacter.you} prepare for a fight.")
	sayLine("Reacter", "BrutalDreamsCocky", {Reacter="Reacter", Starter="Starter"})
	sayLine("Starter", "BrutalDreamsFight", {Starter="Starter", Reacter="Reacter"})

	addAction("fight", "Fight", "Begin the fight", "fight", 1.0, 600, {start_fight=["Reacter", "Starter"],})
	addAction("surrender", "Surrender", "You changed your mind", "surrender", 1.0, 30, {})

func about_to_fight_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "fight"):
		var fightResult = getFightResult(_args)
		
		if(fightResult["won"]):
			setState("Reacter_won", "Reacter")
		else:
			setState("Starter_won", "Starter")
	if(_id == "surrender"):
		setState("surrendered", "Starter")

func surrendered_text():
	saynn("{Reacter.you} raise {Reacter.your} hands and give up.")
	sayLine("Reacter", "BrutalDreamsMercy", {Reacter="Reacter", Starter="Starter"})
	sayLine("Starter", "BrutalDreamsSurrender", {Starter="Starter", Reacter="Reacter"})
	saynn("{Starter.name} approaches {Reacter.you}.")

	addAction("punish", "Punish", "They gotta serve a punishment!", "punish", 1.0, 60, {})
	addAction("sex", "Sex!", "Take what you want from this slut!", "default", 1.0, 600, {start_sex=["Starter", "Reacter"]})

func surrendered_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("Starter"), target=getRoleID("Reacter")})
	if(_id == "sex"):
		stopMe()

func Reacter_won_text():
	saynn("{Starter.name} hits the floor. {Reacter.you} won!")
	sayLine("Starter", "FightLostGeneric", {winner="Reacter", loser="Starter"})

	addAction("leave", "Leave", "Just leave while you can", "justleave", 1.0, 30, {})
	addAction("punish", "Punish", "Find a way to punish them", "punishMean", 1.0, 30, {})
	addAction("sex", "Sex!", "Have some fun with the bully", "default", 1.0, 600, {start_sex=["Reacter", "Starter"]})

	addDefeatButtons("Reacter", "Starter")

func Reacter_won_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		setState("about_to_leave", "Reacter")
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("Reacter"), target=getRoleID("Starter")})
	if(_id == "sex"):
		stopMe()

func about_to_leave_text():
	saynn("{Reacter.you} decide to just leave while {Reacter.you} still can.")

	addAction("leave", "Continue", "See what happens next.", "default", 1.0, 30, {})

func about_to_leave_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		makeRoleExhausted("Starter")
		stopMe()


func Starter_won_text():
	saynn("{Reacter.you} hit the floor. {Starter.name} won!")
	sayLine("Starter", "FightWonGeneric", {winner="Starter", loser="Reacter"})

	addAction("punish", "Punish", "They gotta serve a punishment!", "punishMean", 1.0, 60, {})
	addAction("sex", "Sex!", "Have some fun with the slut", "default", 1.0, 600, {start_sex=["Starter", "Reacter"]})

	addDefeatButtons("Starter", "Reacter")

func Starter_won_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("Starter"), target=getRoleID("Reacter")})
	if(_id == "sex"):
		stopMe()

func getAnimData() -> Array:
	if(getCurrentAction() == "fight"):
		return [StageScene.Duo, "shove", {pc="Reacter", npc="Starter", npcAction="hurt"}]
	return [StageScene.Duo, "stand", {pc="Reacter", npc="Starter"}]

func getPreviewLineForRole(_role:String) -> String:
	return "This shouldn't ever be seen"

func saveData():
	var data = .saveData()
	return data

func loadData(_data):
	.loadData(_data)

