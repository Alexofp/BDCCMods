extends InteractionGoalBase

var pawnIDTarget:String = ""
var BadLoc:Array = ["main_punishment_spot", "gym_secret", "yard_novaspot",
"main_stairs1", "main_stairs2", "hall_checkpoint", "hall_elevator", "mining_elevator"]
var BadFloor:Array = ["FightClubFloor", "Cellblock", "Medical"]

func getScore(_pawn:CharacterPawn) -> float:
	if(globalTask != ""):
		return 1.0
	return 0.0

func getKeepScore() -> float:
	return 1.1

func getText():
	return "{main.name} is chasing someone!"

func getActions() -> Array:
	return [
		{
			id = "go",
			name = "Go!",
			desc = "Chase the person",
			score = 1.0,
			args = {},
			time = 30,
		},
	]
	

func doAction(_id:String, _args:Dictionary):
	if(_id == "go"):
		var pawn = GM.main.IS.getPawn(pawnIDTarget)
		var loc:String = pawn.getLocation()
		var playerFloor = GM.world.getRoomByID(loc).getFloorID()
		var myName = getPawn().getChar().getName()
		
		if(pawn == null):
			completeGoal()
			return
		
		if !pawn.canBeInterrupted():
			print(myName + " is abandoning chase, player busy.")
			completeGoal()
			return
		
		for i in BadLoc:
			if loc == i:
				print(myName + " is abandoning chase, player in " + i + ".")
				completeGoal()
				return
		
		for i in BadFloor:
			if playerFloor == i:
				print(myName + " is abandoning chase, player on floor " + i + ".")
				completeGoal()
				return
		
		if(RNG.chance(30)):
			print(myName + " is abandoning chase, RNG.")
			completeGoal()
			return
		
		# Spammy...
		print(myName + " is chasing player!")
		goTowards(loc)
		
		if(getLocation() == loc):
			print(myName + " caught player!")
			GM.main.IS.startInteraction("BrutalDreamsAttack", {Starter=getPawn().charID, Reacter=pawnIDTarget})

func getAnimData() -> Array:
	return [StageScene.Solo, "jog", {pc="main"}]

func getActivityIcon():
	return RoomStuff.PawnActivity.None

func saveData():
	var data = .saveData()
	
	data["p"] = pawnIDTarget
	return data

func loadData(_data):
	.loadData(_data)
	
	pawnIDTarget = SAVE.loadVar(_data, "p", "")
