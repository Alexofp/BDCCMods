extends InteractionGoalBase
# from user Mindstormsman and his mod 'Brutal Dreams'

func getScore(_pawn:CharacterPawn) -> float:
	if(_pawn.getCharacter().hasBoundArms() || _pawn.getCharacter().hasBlockedHands()):
		return 0.0
	
	# if pawn still has an item equipped on InventorySlot.Body, disables goal
	# prevents goal from triggering if the inmate only has underwear or weapons missing
	if(_pawn.getCharacter().getInventory().getEquippedItem(InventorySlot.Body) != null):
		return 0.0
		
	# datapack character check
	# fixes bug where datapack characters forever loop the Replace Clothes goal
	# disables this goal for datapack characters
	if(!"dynamicnpc" in _pawn.getCharacter().getID()):
		return 0.0
		
	
	var itemsCurrent:Array = _pawn.getCharacter().getInventory().getItemsAndEquippedItemsTogether()
	var itemsCompare:Array = []
	for i in itemsCurrent:
		itemsCompare.append(i.id)
	var itemsDefault = _pawn.getCharacter().getDefaultEquipment()
	for i in itemsDefault:
		if !itemsCompare.has(i):
			if(_pawn.isInmate()):
				return 0.5 # default value 0.5
			else:
				return 1.0 # default value 1.0
	return 0.0

func getKeepScore() -> float:
	return 0.7

func getText():
	return "{main.name} is heading to the laundry room to replace lost clothing!"

func getActions() -> Array:
	return [
		{
			id = "go",
			name = "Go",
			desc = "Do something",
			score = 1.0,
			args = {},
			time = 60,
		},
	]

func doAction(_id:String, _args:Dictionary):
	if(_id == "go"):
		if(getLocation() == "main_laundry"):
			var itemsCurrent:Array = getPawn().getCharacter().getInventory().getItemsAndEquippedItemsTogether()
			var itemsCompare:Array = []
			for i in itemsCurrent:
				itemsCompare.append(i.id)
			var itemsDefault = getPawn().getCharacter().getDefaultEquipment()
			for i in itemsDefault:
				if !itemsCompare.has(i):
					getPawn().getCharacter().getInventory().forceEquipItemID(i)
			completeGoal()
		goTowards("main_laundry")
		

func getAnimData() -> Array:
	return [StageScene.Solo, "walk", {pc="main"}]

func getActivityIcon():
	return RoomStuff.PawnActivity.None
