extends InteractionGoalBase

func getScore(_pawn:CharacterPawn) -> float:
	if(_pawn.getCharacter().hasBoundArms() || _pawn.getCharacter().hasBlockedHands()):
		return 0.0
	var IaE:Array = _pawn.getCharacter().getInventory().getItemsAndEquippedItemsTogether()
	var Items:Array = []
	for i in IaE:
		Items.append(i.id)
	var Default = _pawn.getCharacter().getDefaultEquipment()
	for i in Default:
		if !Items.has(i):
			return 0.5
	return 0.0

func getKeepScore() -> float:
	return 0.7

func getText():
	return "{main.name} is heading to laundry room to replace lost clothing!"

func getActions() -> Array:
	return [
		{
			id = "go",
			name = "Go",
			desc = "Do something",
			score = 1.0,
			args = {},
			time = 60,
		},
	]

func doAction(_id:String, _args:Dictionary):
	if(_id == "go"):
		if(getLocation() == "main_laundry"):
			var IaE:Array = getPawn().getCharacter().getInventory().getItemsAndEquippedItemsTogether()
			var Items:Array = []
			for i in IaE:
				Items.append(i.id)
			var Default = getPawn().getCharacter().getDefaultEquipment()
			for i in Default:
				if !Items.has(i):
					getPawn().getCharacter().getInventory().forceEquipItemID(i)
			completeGoal()
		goTowards("main_laundry")
		

func getAnimData() -> Array:
	return [StageScene.Solo, "walk", {pc="main"}]

func getActivityIcon():
	return RoomStuff.PawnActivity.None
