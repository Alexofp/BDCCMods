extends Species

func _init():
	id = "sugerrscolipede"

func isPlayable():
	return true

func getVisibleName():
	return "Scolipede"

func getVisibleDescription():
	return "Quick and Venomous"

func getDefaultHead(_gender):
	return "sugerrscolipedehead"

func getDefaultEars(_gender):
	return "sugerrscolipedeears"

func getDefaultHorns(_gender):
	return "sugerrscolipedehornsv1"

func getDefaultBody(_gender):
	return "sugerrscolipedebody"

func getDefaultArms(_gender):
	return "sugerrscolipedearms"
	
func getDefaultLegs(_gender):
	return "sugerrscolipedelegs"

func getDefaultTail(_gender):
	return "sugerrscolipedetail"
	
#func getDefaultBreasts(_gender):
#	if(_gender in [Gender.Male]):
#		return "sugerrscolipedpecs"
#	else: 
#		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sugerrscolipedepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]
