extends BodypartTail

func _init():
	visibleName = "scolipede tail"
	id = "sugerrscolipedetail"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getLewdSizeAdjective():
	return RNG.pick(["double"])

func getLewdAdjective():
	return RNG.pick(["pointy", "insect"])

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeTail/ScolipedeTail.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
