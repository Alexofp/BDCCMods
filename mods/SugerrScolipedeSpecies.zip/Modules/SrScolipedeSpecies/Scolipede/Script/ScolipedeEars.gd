extends BodypartEars

func _init():
	visibleName = "scolipede ears"
	id = "sugerrscolipedeears"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getDoll3DScene():
	return null
	
func getCharacterCreatorDesc():
	return "(Scolipede Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
