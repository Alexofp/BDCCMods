extends BodypartHead

func _init():
	visibleName = "scolipede head"
	id = "sugerrscolipedehead"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeHead/ScolipedeHead.tscn"

func getHeadLength():
	return 0.55
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
