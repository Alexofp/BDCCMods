extends BodypartArms

func _init():
	visibleName = "scolipede arms (skin)"
	id = "sugerrscolipedearmsskin"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeArms/ScolipedeArms_Skin.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
