extends BodypartArms

func _init():
	visibleName = "scolipede arms"
	id = "sugerrscolipedearms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeArms/ScolipedeArms.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
