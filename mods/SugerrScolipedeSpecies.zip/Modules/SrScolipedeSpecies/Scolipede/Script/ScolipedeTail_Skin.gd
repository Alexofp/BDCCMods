extends BodypartTail

func _init():
	visibleName = "scolipede tail (skin)"
	id = "sugerrscolipedetailskin"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getLewdSizeAdjective():
	return RNG.pick(["double"])

func getLewdAdjective():
	return RNG.pick(["pointy", "insect"])

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeTail/ScolipedeTail_Skin.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"

func npcGenerationWeight(_dynamicCharacter):
	return 0.0
