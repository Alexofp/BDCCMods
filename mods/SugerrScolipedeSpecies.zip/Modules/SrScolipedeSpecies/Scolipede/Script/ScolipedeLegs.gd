extends BodypartLeg

func _init():
	visibleName = "scolipede legs"
	id = "sugerrscolipedelegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeLegs/ScolipedeLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
