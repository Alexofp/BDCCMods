extends BodypartHorns

func _init():
	visibleName = "scolipede horns v2"
	id = "sugerrscolipedehornsv2"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeHornsV2/ScolipedeHorns.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func generateRandomColors(_dynamicCharacter):
	var theHue = pickedRColor
	if(_dynamicCharacter != null):
		theHue = _dynamicCharacter.pickedSkinRColor.h
	pickedRColor = Color.from_hsv(theHue, RNG.randf_range(0.1, 0.1), RNG.randf_range(0.1, 0.1))
	pickedGColor = pickedGColor
	pickedBColor = pickedBColor
