extends BodypartArms

func _init():
	visibleName = "buff scolipede arms"
	id = "sugerrscolipedearmsbuff"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeArmsBuff/BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
