extends BodypartArms

func _init():
	visibleName = "scolipede arms v2"
	id = "sugerrscolipedearmsv2"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeArmsV2/ScolipedeArms.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
