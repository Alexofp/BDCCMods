extends BodypartArms

func _init():
	visibleName = "scolipede arms v2 (skin)"
	id = "sugerrscolipedearmsv2skin"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeArmsV2/ScolipedeArms_Skin.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
