extends BodypartHead

func _init():
	visibleName = "scolipede head (skin)"
	id = "sugerrscolipedeheadskin"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeHead/ScolipedeHead_Skin.tscn"

func getHeadLength():
	return 0.55
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
