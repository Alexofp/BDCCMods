extends BodypartTail

func _init():
	visibleName = "scolipede tail v2"
	id = "sugerrscolipedetailv2"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getLewdSizeAdjective():
	return RNG.pick(["double"])

func getLewdAdjective():
	return RNG.pick(["pointy", "insect"])

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeTailV2/ScolipedeTail.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
