extends BodypartLeg

func _init():
	visibleName = "scolipede legs v2 (skin)"
	id = "sugerrscolipedelegsv2skin"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeLegsV2/ScolipedeLegs_Skin.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
