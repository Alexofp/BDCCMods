extends BodypartLeg

func _init():
	visibleName = "scolipede legs v2"
	id = "sugerrscolipedelegsv2"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeLegsV2/ScolipedeLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
