extends BodypartBody

func _init():
	visibleName = "scolipede body v2 (skin)"
	id = "sugerrscolipedebodyv2skin"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeBodyV2/ScolipedeBody_Skin.tscn"

func getVulgarName() -> String:
	return "segmented body"

func getAVulgarName() -> String:
	return "a segmented body"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
