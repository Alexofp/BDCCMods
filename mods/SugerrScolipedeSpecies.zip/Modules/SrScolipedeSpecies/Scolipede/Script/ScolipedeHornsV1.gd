extends BodypartHorns

func _init():
	visibleName = "scolipede horns v1"
	id = "sugerrscolipedehornsv1"

func getCompatibleSpecies():
	return ["sugerrscolipede"]

func getDoll3DScene():
	return "res://Modules/SrScolipedeSpecies/Scolipede/PNG/ScolipedeHornsV1/ScolipedeHorns.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Scolipede Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func generateRandomColors(_dynamicCharacter):
	var theHue = pickedRColor
	if(_dynamicCharacter != null):
		theHue = _dynamicCharacter.pickedSkinRColor.h
	pickedRColor = Color.from_hsv(theHue, RNG.randf_rangeX2(0.0, 0.3), RNG.randf_rangeX2(0.0, 0.5))
	pickedGColor = pickedGColor
	pickedBColor = pickedBColor

	
	
#¤func generateRandomColors(_dynamicCharacter):
#	var theHue = RNG.randf_range(0.0, 0.1)
#	if(_dynamicCharacter != null):
#		theHue = _dynamicCharacter.pickedSkinRColor.h
#	
#	pickedRColor = Color.from_hsv(theHue, RNG.randf_rangeX2(0.0, 0.3), RNG.randf_rangeX2(0.0, 0.5))
#	pickedGColor = pickedRColor
#	pickedGColor.v += RNG.randf_range(0.1, 0.2)
#	if(_dynamicCharacter != null && (Species.Demon in _dynamicCharacter.getSpecies())):
#		pickedBColor = ColorUtils.generateRandomVibrantColor()
#	else:
#		pickedBColor = pickedGColor
#		pickedBColor.v += RNG.randf_range(-0.1, 0.2)
#		pickedBColor.s += RNG.randf_range(-0.2, 0.2)
