extends Module

func _init():
	id = "sugerrscolipedespecies"
	author = "Sugerør"
	
	species = [
		"res://Modules/SrScolipedeSpecies/Scolipede/Scolipede.gd",
	]
	bodyparts = [
		#Xenomorph
		# - Head + Horns + "Ears"
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeHead.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeHead_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeEars.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeHornsV1.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeHornsV2.gd",
		# - Body + Breasts
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeBody.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeBody_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeBodyV2.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeBodyV2_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/BigPecs.gd",
		# - Arms
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeArms.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeArms_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeArmsBuff.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeArmsBuff_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeArmsV2.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeArmsV2_Skin.gd",
		# - Legs
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeLegs.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeLegs_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeLegsV2.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeLegsV2_Skin.gd",
		# - Tail
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeTail.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeTail_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeTailV2.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeTailV2_Skin.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeTailV3.gd",
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/ScolipedeTailV3_Skin.gd",
		# - Penis
		"res://Modules/SrScolipedeSpecies/Scolipede/Script/SolipedePenis.gd",
	]
