extends Module

var BallsExtraLoad = ResourceLoader.exists("res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd")

func _init():
	id = "OvipositorEggEdit"
	author = "Lazarus"
	
	if (BallsExtraLoad == true):
		bodyparts = [
			"res://Modules/OviEggEditor/OvipositorPenisBE.gd",
		]

	if (BallsExtraLoad == false):
		bodyparts = [
			"res://Modules/OviEggEditor/OvipositorPenis.gd",
		]
