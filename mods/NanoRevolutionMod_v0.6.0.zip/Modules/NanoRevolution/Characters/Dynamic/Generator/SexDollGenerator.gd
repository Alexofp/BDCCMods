extends CharacterGeneratorBase
class_name SexDollGenerator

func are_keys_equal(dict1: Dictionary, dict2: Dictionary) -> bool:
	var keys1 = dict1.keys()
	var keys2 = dict2.keys()
	if keys1.size() != keys2.size():
		return false
	for key in keys1:
		if not keys2.has(key):
			return false
	return true

func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = "SexDoll"

func pickGender(character:DynamicCharacter, _args = {}):
	var allgenders = NpcGender.getAll()
	var baseGenderDict = {}
	for gender in allgenders:
		baseGenderDict[gender] = NpcGender.getDefaultWeight(gender)
	var nanoGenderDict = GM.main.getModuleFlag("NanoRevolutionModule", "NanoAndroidGenderDistr",baseGenderDict)
	var stuff = []
	for gender in NpcGender.getAll():
		var weight = nanoGenderDict[gender]
		
		stuff.append([gender, weight])
	var pickedGender = RNG.pickWeightedPairs(stuff)

	character.npcGeneratedGender = pickedGender

func pickSpecies(character:DynamicCharacter, _args = {}):
	# so, we use default species here xwx, and change part in next
	# character.npcSpecies = [randomSpecies]

	
	character.npcSpecies = ["nanoAndroid"]
	
	
func createBodyparts(character:DynamicCharacter, _args = {}):
	# original pick species
	if(_args.has(NpcGen.Species)):
		character.npcSpecies = [_args[NpcGen.Species]]
		return
	
	var speciesType = pickedSpeciesType(_args)
	var allSpecies = GlobalRegistry.getAllSpecies()
	var possibleSpecies = []
	for speciesID in allSpecies:
		var specie = allSpecies[speciesID]
		if(!specie.canBeUsedForNPCType(speciesType)):
			continue
		
		var weight = GM.main.getEncounterSettings().getSpeciesWeight(speciesID)
		if(weight != null && weight > 0.0):
			possibleSpecies.append([speciesID, weight])
	
	var randomSpecies = RNG.pickWeightedPairs(possibleSpecies)
	if(randomSpecies == null):
		randomSpecies = Species.Canine

	# put the random Species here for generation
	var theSpecies:Array = [randomSpecies]
	
	for bodypartSlot in BodypartSlot.getAll():
		var possible := Bodypart.findPossibleBodypartIDs(bodypartSlot, character, theSpecies, character.npcGeneratedGender)
		var fullWeight:float = 0.0
		for pairs in possible:
			fullWeight += max(0.0, pairs[1])
		
		#print(bodypartSlot, " ", possible) # Uncomment for debug
		if(possible.size() > 0):
			if(!RNG.chance(fullWeight * 100.0)):
				continue
			
			var bodypartID = RNG.pickWeightedPairs(possible)
			if(bodypartID != null && bodypartID != ""):
				var bodypart = GlobalRegistry.createBodypart(bodypartID)
				if(!bodypart):
					continue
				character.giveBodypartUnlessSame(bodypart)
				bodypart.generateDataFor(character)


func getAttacks():
	return ["SentinelHeatGrenade", "SentinelLatexBarrage", "SentinelLatexStrike", "SentinelLatexSlam", "SentinelLatexRegeneration", "trygetupattack"]

func getPossibleAttacks():
	return ["DoubleCuffPC", "CuffPCHands", "ForceGagPC", "ForceMuzzlePC"]

func pickEquipment(character:DynamicCharacter, _args = {}):
	
	var theEquipment = []
	
	character.npcDefaultEquipment = theEquipment

func pickLustInterests(character:DynamicCharacter, _args = {}):
	var interestWeights = [
		[Interest.Hates, 0],
		[Interest.ReallyDislikes, 0],
		[Interest.Dislikes, 0],
		[Interest.SlightlyDislikes, 0],
		[Interest.KindaLikes, 0],
		[Interest.Likes, 0.0],
		[Interest.ReallyLikes, 1.0],
		[Interest.Loves, 1.0],
	]
	
	for topicA in GlobalRegistry.getLustTopicObjects():
		var topic: TopicBase = topicA
		var handlesIDs = topic.handles_ids
		for id in handlesIDs:
			var pickedInterest = RNG.pickWeightedPairs(interestWeights)
			
			if(pickedInterest != Interest.Neutral):
				character.getLustInterests().addInterest(id, pickedInterest)

func pickPersonality(character:DynamicCharacter, _args = {}):
	var personality = character.getPersonality()
	
	personality.clear()
	for statID in PersonalityStat.getAll():
		personality.setStat(statID, RNG.randf_range(-0.3, 0.3))
		if(RNG.chance(5)):
			personality.setStat(statID, RNG.randf_range(-0.3, 0.3)*5.0)
	
	for archetype in character.npcArchetypes:
		var personalityChanges = CharacterArchetype.getPersonalityChanges(archetype)
		for personalityStat in personalityChanges:
			var howMuchMax = personalityChanges[personalityStat]
			
			if(howMuchMax > 0.0):
				personality.addStat(personalityStat, RNG.randf_range(0.0, howMuchMax))
			elif(howMuchMax < 0.0):
				personality.addStat(personalityStat, -RNG.randf_range(0.0, -howMuchMax))
	personality.setStat("Brat", -1.0)



func pickSmallDescription(character:DynamicCharacter, _args = {}):
	var text = "One of the sex doll."+str(.pickSmallDescription(character, _args))

	var level = character.npcLevel
	
	var possibleRanks = []
	
	if(level <= 6):
		possibleRanks.append_array([
			NpcRank.Spacer,
			NpcRank.SpaceCadet,
		])
	
	if(level >= 5 && level <= 10):
		possibleRanks.append_array([
			NpcRank.Inspector,
			NpcRank.ChiefInspector,
			NpcRank.Sergeant,
		])
	
	if(level >= 8 && level <= 15):
		possibleRanks.append_array([
			NpcRank.PettyOfficer,
			NpcRank.ChiefPettyOfficer,
		])

	if(level >= 13):
		possibleRanks.append_array([
			NpcRank.Lieutenant,
			NpcRank.Executor,
		])
	
	var pickedRank = RNG.pick(possibleRanks)
	if(pickedRank == null):
		pickedRank = NpcRank.Spacer
	
	character.setFlag(CharacterFlag.Rank, pickedRank)
	
	text = text
	return text
