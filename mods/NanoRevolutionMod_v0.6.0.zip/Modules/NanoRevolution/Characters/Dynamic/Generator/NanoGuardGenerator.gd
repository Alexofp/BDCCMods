extends CharacterGeneratorBase
class_name NanoGuardGenerator

func are_keys_equal(dict1: Dictionary, dict2: Dictionary) -> bool:
	var keys1 = dict1.keys()
	var keys2 = dict2.keys()
	if keys1.size() != keys2.size():
		return false
	for key in keys1:
		if not keys2.has(key):
			return false
	return true

func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = "NanoGuard"

func pickGender(character:DynamicCharacter, _args = {}):
	var allgenders = NpcGender.getAll()
	var baseGenderDict = {}
	for gender in allgenders:
		baseGenderDict[gender] = NpcGender.getDefaultWeight(gender)
	var nanoGenderDict = GM.main.getModuleFlag("NanoRevolutionModule", "NanoAndroidGenderDistr",baseGenderDict)
	var stuff = []
	for gender in NpcGender.getAll():
		var weight = nanoGenderDict[gender]
		
		stuff.append([gender, weight])
	var pickedGender = RNG.pickWeightedPairs(stuff)

	character.npcGeneratedGender = pickedGender

func pickSpecies(character:DynamicCharacter, _args = {}):
	# so, we use default species here xwx, and change part in next
	# character.npcSpecies = [randomSpecies]

	
	character.npcSpecies = ["nanoAndroid"]
	
	
func createBodyparts(character:DynamicCharacter, _args = {}):
	# original pick species
	if(_args.has(NpcGen.Species)):
		character.npcSpecies = [_args[NpcGen.Species]]
		return
	
	var speciesType = pickedSpeciesType(_args)
	var allSpecies = GlobalRegistry.getAllSpecies()
	var possibleSpecies = []
	for speciesID in allSpecies:
		var specie = allSpecies[speciesID]
		if(!specie.canBeUsedForNPCType(speciesType)):
			continue
		
		var weight = GM.main.getEncounterSettings().getSpeciesWeight(speciesID)
		if(weight != null && weight > 0.0):
			possibleSpecies.append([speciesID, weight])
	
	var randomSpecies = RNG.pickWeightedPairs(possibleSpecies)
	if(randomSpecies == null):
		randomSpecies = Species.Canine

	# put the random Species here for generation
	var theSpecies:Array = [randomSpecies]
	
	for bodypartSlot in BodypartSlot.getAll():
		var possible := Bodypart.findPossibleBodypartIDs(bodypartSlot, character, theSpecies, character.npcGeneratedGender)
		var fullWeight:float = 0.0
		for pairs in possible:
			fullWeight += max(0.0, pairs[1])
		
		#print(bodypartSlot, " ", possible) # Uncomment for debug
		if(possible.size() > 0):
			if(!RNG.chance(fullWeight * 100.0)):
				continue
			
			var bodypartID = RNG.pickWeightedPairs(possible)
			if(bodypartID != null && bodypartID != ""):
				var bodypart = GlobalRegistry.createBodypart(bodypartID)
				if(!bodypart):
					continue
				character.giveBodypartUnlessSame(bodypart)
				bodypart.generateDataFor(character)


func getAttacks():
	return ["SentinelHeatGrenade", "SentinelLatexBarrage", "SentinelLatexStrike", "SentinelLatexSlam", "SentinelLatexRegeneration", "trygetupattack"]

func getPossibleAttacks():
	return ["DoubleCuffPC", "CuffPCHands", "ForceGagPC", "ForceMuzzlePC"]

func pickEquipment(character:DynamicCharacter, _args = {}):
	
	var theEquipment = []
	
	character.npcDefaultEquipment = theEquipment

func pickLustInterests(character:DynamicCharacter, _args = {}):
	var interestWeights = [
		[Interest.Hates, 0],
		[Interest.ReallyDislikes, 0],
		[Interest.Dislikes, 0],
		[Interest.SlightlyDislikes, 0],
		[Interest.KindaLikes, 0],
		[Interest.Likes, 1.0],
		[Interest.ReallyLikes, 1.0],
		[Interest.Loves, 1.0],
	]
	
	for topicA in GlobalRegistry.getLustTopicObjects():
		var topic: TopicBase = topicA
		var handlesIDs = topic.handles_ids
		for id in handlesIDs:
			var pickedInterest = RNG.pickWeightedPairs(interestWeights)
			
			if(pickedInterest != Interest.Neutral):
				character.getLustInterests().addInterest(id, pickedInterest)



func pickSmallDescription(character:DynamicCharacter, _args = {}):
	var text = "One of the guards. "+str(.pickSmallDescription(character, _args))


	return text
