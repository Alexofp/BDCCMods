# NanoRevolution Mod
This is the mod of a kinky game [BDCC](https://github.com/Alexofp/BDCC)

If you meet any bug, and have any suggestions. Feel free to add a new [issue](https://github.com/Humoiww/BDCC_NanoRevolution_MOD/issues)

## How to use
### Option 1
Check [this tutorial](https://github.com/Alexofp/BDCC/wiki/User-Support) for install most recent stable version mod. 
### Option 2 (if you want to build something base on this mod or if you want to try newest test version, not recommend for normal user)
Down load zip file of this repo, unzip into a folder, rename the root folder in name: **NanoRevolution**. Clone the git repo (download also work) [BDCC](https://github.com/Alexofp/BDCC), put this NanoRevolution folder under Modules folder. You should get something like this:
```shell
BDCC
|---some_other_folder
|---Modules
    |---some_other_in_game_mods
    |---NanoRevolution
        |---Characters
        |---Events
        |---...
        |---Module.gd
    |---...
```
Then, use godot 3.x to open this project. Start debug, and you can try the mod now.  




## TODO List

- [x] Add option at start of encounter
- [x] Add a new character to handle the option part
- [x] make sure the options are working without bug
- [x] Fully developed nano engineering skill tree. You can make something really powerful with this skill.
- [ ] More nano android type. nano engineers, nurses, and even android sextoys, enrich the BDCC life. 
- [ ] A new floor that only allow android enter?
- [ ] Mature nano species side path. A new skill tree that is closely related to how to use your new body.
- - [ ] New transformation path, instead of touching the weird stuff in engineering bay.  
- - - [ ] Contamination technique your skin color will change depending on your contamination. UI changes
- - [x] Ability to turn other into nano android
- - [ ] Possible new endings with this new form, including bad ends, good ends 
- - [ ] Reduce Alex reliance for the story. Since Alex path is ended, instead of extending his story, a better way is to further explain humoi, which could be more user-friendly.
- - - [ ] To be honest, directly delete the Alex content, we will work by our self!


## Change Log

Remove the Alex content related to the android.
- The main reason for this is I think it's risky to integrate my oc content with other oc. Even though theoratically they may have relation in the plot, it's actually block how I will design the story line, so I just directly deleted the realted content and make the new one.
- The old tranformation path is removed, instead of finding the android in the engineering bay now you only need to learn how to extract robot core. And you will get contamination during the extraction and progressively transform into nano form. Currently this feature is still WIP. This only content a trigger when you get fully contaminated. You will see the simple scene to indicate you are nano android now.
- WIP ON NEW transform scene.

