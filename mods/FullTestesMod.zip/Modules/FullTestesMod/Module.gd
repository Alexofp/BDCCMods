extends Module

# Модуль-обёртка. Регистрирует новый статус-эффект.
# ВАЖНО: имя поля `statusEffects` проверьте в res://Modules/Module.gd вашей версии игры
# (если оно называется иначе - поправьте здесь, остальной код не меняется).

func _init():
	id = "FullTestesMod"
	author = "Discis"

	statusEffects = [
		"res://Modules/FullTestesMod/TestesFullStatus.gd",
	]
