extends StatusEffectBase

# Мод "Переполненные яички" v1.6
#
# Как это работает:
#   * мод НИЧЕГО не наполняет сам - он читает реальное количество жидкости в яичках
#     персонажа и сравнивает его с индивидуальной ёмкостью (у каждого она своя)
#   * эффект вешается только на персонажей с пенисом (любым)
#   * две стадии:
#       Empty        - яички (почти) пусты: чуть больше ловкости, чуть меньше сексуальности,
#                      Virility -25%, Cum production -50%
#       Overflowing  - яички полны под завязку: штрафы (Strength -1, Vitality -2), рост похоти,
#                      Virility +50%, Cross species compatibility +50%
#     между ними (середина шкалы) эффекта нет
#   * облегчение даёт сама игра: когда жидкость тратится, стадия меняется или эффект снимается

# ======================= НАСТРОЙКИ БАЛАНСА =======================
const EMPTY_AT = 0.10        # Empty: заполнение яичек <= 10% (включая совсем пустые)
const OVERFLOW_AT = 0.995    # Overflowing: практически "под завязку"

# Индекс = номер стадии (0 не используется): 1 = Empty, 2 = Overflowing
const LUST_PER_HOUR = [0.0, 0.0, 25.0]      # похоть в игровой час
const LUST_PER_BATTLE_TURN = [0, 0, 5]      # похоть за каждый ход боя

const LUST_CAP_LEVEL = 0.85          # мод сам не поднимает похоть выше 85% порога
const AFFECT_NPC_LUST = false        # true = похоть меняется и у NPC

# Дополнительные баффы (проценты, как в игре: -25.0 = -25%)
const EMPTY_VIRILITY = -25.0
const EMPTY_CUM_PRODUCTION = -50.0
const OVERFLOW_VIRILITY = 50.0
const OVERFLOW_CROSS_SPECIES = 50.0

# Если в тултипе эффекта проценты выглядят неправильно (например "-0.25%" вместо "-25%"),
# значит игра ждёт доли, а не проценты - поставьте здесь 0.01.
const PERCENT_SCALE = 1.0

const STAGE_NAMES = ["", "Empty", "Overflowing"]
const STAGE_DESCS = [
	"",
	"Nothing left in them - light, drained and a little numb down there. Quicker on your feet, but far less alluring.",
	"Completely full and agonizingly tight - leaking, trembling and barely able to focus. Only a real release will help now.",
]

# ======================= ДАННЫЕ (идут в сейв) =======================
var lustBuffer = 0.0


func _init():
	id = "TestesFull"
	isBattleOnly = false
	alwaysCheckedForPlayer = true
	alwaysCheckedForNPCs = true


# ======================= АДАПТЕРЫ К ДВИЖКУ =======================
# Всё, что зависит от внутренностей игры, собрано здесь. Игра - на Godot 3.6,
# а точные имена методов жидкости в яичках мне проверить не удалось, поэтому
# чтение сделано "по списку кандидатов". Если ни одно имя не подошло, мод
# НЕ падает: эффект просто не вешается, а в консоль один раз печатается список
# подходящих методов - впишите нужное имя в списки ниже.
const FLUID_SOURCE_GETTERS = ["getFluidProduction", "getCumProduction", "getFluidSource"]
const FILL_PERCENT_GETTERS = ["getFluidAmountPercent", "getFillPercent", "getFillLevel", "getFullness", "getPercentFull"]
const AMOUNT_GETTERS = ["getFluidAmount", "getCurrentAmount", "getAmount", "getCumAmount"]
const AMOUNT_PROPS = ["fluidAmount", "currentAmount", "amount"]
const CAPACITY_GETTERS = ["getCapacity", "getFluidCapacity", "getMaxAmount", "getMaxFluidAmount"]
const CAPACITY_PROPS = ["capacity", "maxAmount"]

# Пенис персонажа (любой) или null. `bodyparts` - Dictionary[BodypartSlot, Bodypart] (описан в вики).
func _getPenis(c):
	if(c == null || !("bodyparts" in c)):
		return null
	if(!c.bodyparts.has(BodypartSlot.Penis)):
		return null
	return c.bodyparts[BodypartSlot.Penis]

func _tryRead(obj, methods, props):
	if(typeof(obj) != TYPE_OBJECT || obj == null):
		return null
	for m in methods:
		if(obj.has_method(m)):
			return obj.call(m)
	for p in props:
		if(p in obj):
			return obj.get(p)
	return null

# Индивидуальная заполненность яичек 0..1 или -1, если пениса нет / данные не прочитать.
func _getFill(c):
	var part = _getPenis(c)
	if(part == null):
		return -1.0

	var source = null
	for m in FLUID_SOURCE_GETTERS:
		if(part.has_method(m)):
			source = part.call(m)
			break
	if(source == null):
		source = part

	# вариант 1: игра сама отдаёт процент заполнения
	var pct = _tryRead(source, FILL_PERCENT_GETTERS, [])
	if(pct != null):
		var p = float(pct)
		if(p > 1.0):
			p = p / 100.0
		return clamp(p, 0.0, 1.0)

	# вариант 2: текущее количество жидкости / индивидуальная ёмкость
	var amount = _tryRead(source, AMOUNT_GETTERS, AMOUNT_PROPS)
	var capacity = _tryRead(source, CAPACITY_GETTERS, CAPACITY_PROPS)
	if(amount != null && capacity != null && float(capacity) > 0.0):
		return clamp(float(amount) / float(capacity), 0.0, 1.0)

	_reportApiProblem(part, source)
	return -1.0

func _methodHints(obj):
	var res = []
	if(typeof(obj) != TYPE_OBJECT || obj == null):
		return res
	for m in obj.get_method_list():
		var n = String(m["name"]).to_lower()
		if(n.find("fluid") >= 0 || n.find("cum") >= 0 || n.find("capac") >= 0 || n.find("amount") >= 0 || n.find("fill") >= 0 || n.find("full") >= 0):
			res.append(m["name"])
	return res

# Один раз за запуск игры (флаг хранится в Engine, а не в эффекте - иначе спам по каждому NPC).
func _reportApiProblem(part, source):
	if(Engine.has_meta("FullTestesMod_api_warned")):
		return
	Engine.set_meta("FullTestesMod_api_warned", true)
	print("[FullTestesMod] Cannot read the fluid amount from the penis bodypart - edit the adapter lists in TestesFullStatus.gd.")
	print("[FullTestesMod] Penis bodypart methods that look relevant: ", _methodHints(part))
	if(source != part):
		print("[FullTestesMod] Fluid source object methods that look relevant: ", _methodHints(source))

func _isPlayer():
	return character != null && character.getID() == "pc"

func _canAffectLust():
	return AFFECT_NPC_LUST || _isPlayer()


# ======================= СТАДИИ =======================
# 0 = эффекта нет, 1 = Empty, 2 = Overflowing
func _stageFromFill(_fill):
	if(_fill < 0.0):
		return 0
	if(_fill >= OVERFLOW_AT):
		return 2
	if(_fill <= EMPTY_AT):
		return 1
	return 0

func getStage():
	return _stageFromFill(_getFill(character))

func shouldApplyTo(_npc):
	# только персонажи с пенисом и только на крайних стадиях
	return _stageFromFill(_getFill(_npc)) > 0


# ======================= ЭФФЕКТЫ =======================
func _addLustCapped(_amount):
	var headroom = int(character.lustThreshold() * LUST_CAP_LEVEL) - character.getLust()
	var toAdd = int(min(_amount, headroom))
	if(toAdd > 0):
		character.addLust(toAdd)

func processTime(_secondsPassed: int):
	var stage = getStage()
	if(stage == 0):
		stop()   # жидкость пришла в "середину" или пенис пропал - эффект снимается
		return
	if(!_canAffectLust()):
		return

	var hours = float(_secondsPassed) / 3600.0
	lustBuffer += LUST_PER_HOUR[stage] * hours
	if(lustBuffer >= 1.0):
		var wholeLust = int(lustBuffer)
		lustBuffer -= wholeLust
		_addLustCapped(wholeLust)

func processBattleTurn():
	var stage = getStage()
	if(stage == 0 || !_canAffectLust()):
		return
	_addLustCapped(LUST_PER_BATTLE_TURN[stage])

func getBuffs():
	var result = []
	match getStage():
		1:
			result.append(buff(Buff.StatBuff, [Stat.Agility, 1]))
			result.append(buff(Buff.StatBuff, [Stat.Sexiness, -1]))
			_appendExtraBuff(result, "virility", EMPTY_VIRILITY)
			_appendExtraBuff(result, "cum_production", EMPTY_CUM_PRODUCTION)
		2:
			result.append(buff(Buff.StatBuff, [Stat.Strength, -1]))
			result.append(buff(Buff.StatBuff, [Stat.Vitality, -2]))
			result.append(buff(Buff.StatBuff, [Stat.Sexiness, 4]))
			_appendExtraBuff(result, "virility", OVERFLOW_VIRILITY)
			_appendExtraBuff(result, "cross_species", OVERFLOW_CROSS_SPECIES)
	return result


# ======================= ДОП. БАФФЫ: ПОИСК ПО ID =======================
# Точные id баффов Virility / Cum production / Cross species compatibility мне
# проверить не удалось, поэтому (как и с жидкостью выше) они ищутся "по списку
# кандидатов", а затем - по ключевым словам среди всех зарегистрированных баффов.
# Если бафф не найден, мод НЕ падает: этот бафф просто пропускается, а в консоль
# один раз печатается список похожих id - впишите нужный в BUFF_CANDIDATES.
const BUFF_CANDIDATES = {
	"virility": ["VirilityBuff"],
	"cum_production": ["CumProductionBuff", "CumProductionMultBuff", "CumProduceBuff"],
	"cross_species": ["CrossSpeciesCompatibilityBuff", "CrossSpeciesBuff", "CrossSpeciesBreedingBuff", "SpeciesCompatibilityBuff"],
}
# Запасной поиск: id (в нижнем регистре) должен содержать ВСЕ слова хотя бы одного набора
const BUFF_KEYWORDS = {
	"virility": [["viril"]],
	"cum_production": [["cum", "prod"]],
	"cross_species": [["cross", "species"], ["species", "compat"]],
}
const BUFF_CACHE_META = "FullTestesMod_buff_cache"
const BUFF_HINT_WORDS = ["viril", "fertil", "cum", "species", "breed", "fluid", "prod", "compat"]

func _appendExtraBuff(_list, _key, _amount):
	var buffID = _resolveBuffID(_key)
	if(buffID == ""):
		return
	_list.append(buff(buffID, [_amount * PERCENT_SCALE]))

# Результат поиска кэшируется на весь запуск игры (в Engine, а не в эффекте).
func _resolveBuffID(_key):
	var cache = {}
	if(Engine.has_meta(BUFF_CACHE_META)):
		cache = Engine.get_meta(BUFF_CACHE_META)
	if(cache.has(_key)):
		return cache[_key]

	var registered = GlobalRegistry.buffs
	if(registered.empty()):
		return ""   # реестр ещё не заполнен - не кэшируем, попробуем в следующий раз

	var found = ""
	for candidate in BUFF_CANDIDATES[_key]:
		if(registered.has(candidate)):
			found = candidate
			break

	if(found == ""):
		for kwGroup in BUFF_KEYWORDS[_key]:
			for bid in registered.keys():
				var low = String(bid).to_lower()
				var allMatch = true
				for kw in kwGroup:
					if(low.find(kw) < 0):
						allMatch = false
						break
				if(allMatch):
					found = String(bid)
					break
			if(found != ""):
				break

	cache[_key] = found
	Engine.set_meta(BUFF_CACHE_META, cache)

	if(found == ""):
		_reportMissingBuff(_key)
	else:
		print("[FullTestesMod] Buff '", _key, "' -> ", found)
	return found

func _reportMissingBuff(_key):
	var hints = []
	for bid in GlobalRegistry.buffs.keys():
		var low = String(bid).to_lower()
		for kw in BUFF_HINT_WORDS:
			if(low.find(kw) >= 0):
				hints.append(bid)
				break
	print("[FullTestesMod] Buff '", _key, "' not found - skipped. Add its id to BUFF_CANDIDATES in TestesFullStatus.gd.")
	print("[FullTestesMod] Registered buff ids that look relevant: ", hints)


# ======================= ОТОБРАЖЕНИЕ =======================
func getEffectName():
	return STAGE_NAMES[getStage()] + " Balls"

func getEffectDesc():
	var fill = _getFill(character)
	return STAGE_DESCS[_stageFromFill(fill)] + "\nFullness: " + str(int(round(max(fill, 0.0) * 100.0))) + "%"

func getIconColor():
	if(getStage() >= 2):
		return IconColorRed
	return IconColorBlue


# ======================= ИКОНКА =======================
# Почему не просто путь к png: в ручном zip файл лежит "сырым", без импорта движком
# (.import / .stex), и игровой load() его не читает - иконка пустая. Поэтому текстура
# собирается из png прямо при запуске и регистрируется в кэше ресурсов под виртуальным
# путём. Если мод собран через "Make mod" и png импортирован - используется обычный путь.
# Индекс = номер стадии, как в STAGE_NAMES
const ICON_FILES = [
	"",
	"res://Modules/FullTestesMod/icon_empty.png",
	"res://Modules/FullTestesMod/icon_full.png",
]
const ICON_KEYS = [
	"",
	"res://Modules/FullTestesMod/icon_empty_runtime.res",
	"res://Modules/FullTestesMod/icon_full_runtime.res",
]
const ICON_META_PREFIX = "FullTestesMod_icon_"

# Путь, по которому игра сможет загрузить картинку стадии
func _getIconPath(_stage):
	var metaName = ICON_META_PREFIX + str(_stage)
	if(!Engine.has_meta(metaName)):
		var path = ICON_FILES[_stage]
		var img = Image.new()
		if(img.load(ICON_FILES[_stage]) == OK):
			var tex = ImageTexture.new()
			tex.create_from_image(img, Texture.FLAG_FILTER)
			path = ICON_KEYS[_stage]
			tex.take_over_path(path)
			# кэш ресурсов держит только слабую ссылку - без этой строки текстуру сразу удалят
			Engine.set_meta(metaName + "_tex", tex)
		Engine.set_meta(metaName, path)
	return Engine.get_meta(metaName)

func getEffectImage():
	if(getStage() >= 2):
		return _getIconPath(2)
	return _getIconPath(1)


# ======================= СОХРАНЕНИЕ =======================
func saveData():
	return {
		"lustBuffer": lustBuffer,
	}

func loadData(_data):
	lustBuffer = SAVE.loadVar(_data, "lustBuffer", 0.0)
