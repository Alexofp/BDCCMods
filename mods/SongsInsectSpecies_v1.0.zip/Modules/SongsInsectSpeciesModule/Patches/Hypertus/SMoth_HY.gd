extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "smoth"
	
func getVisibleName():
	return "Moth"

func getDefaultLegs(_gender):
	return "smothlegs1"

func getDefaultTail(_gender):
	return "smothtail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "Tinker Bells"

func getDefaultHead(_gender):
	return "smothhead1"

func getDefaultArms(_gender):
	return "smotharms1"

func getDefaultEars(_gender):
	return "songindummyears"

func getDefaultHorns(_gender):
	return "smothhorns1"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
			return "humanpenishyperable"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[3, 2.0],
		[4, 2.0],
		[5, 4.0],
		[6, 4.0],
	]
