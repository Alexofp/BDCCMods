extends BodypartBody

func _init():
	visibleName = "Fluffy Insect body"
	id = "sfinsectbody"

func getCompatibleSpecies():
	return []

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Uni/InsectFluffyBody/FluffBackup/InsectFluffyBody_Backup.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"

func getCharacterCreatorDesc():
	return "From Insect Species"
