extends BodypartHorns

func _init():
	visibleName = "beetle antenas 1"
	id = "sbeetlehorns1"

func getCompatibleSpecies():
	return ["sbeetle"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleHorns1/sBeetlehorns1.tscn"

func getCharacterCreatorDesc():
	return "From Insect Species"

