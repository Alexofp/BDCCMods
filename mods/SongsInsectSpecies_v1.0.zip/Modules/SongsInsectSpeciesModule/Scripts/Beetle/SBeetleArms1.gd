extends BodypartArms

func _init():
	visibleName = "Beetle Arms"
	id = "sbeetlearms1"

func getCompatibleSpecies():
	return ["sbeetle"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleArms/BeetleArms1.tscn"
