extends BodypartLeg

func _init():
	visibleName = "Beetle legs"
	id = "sbeeltelegs1"

func getCompatibleSpecies():
	return ["sbeetle"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleLegs/BeeLegs1.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
