extends BodypartHorns

func _init():
	visibleName = "beetle antenas 2"
	id = "sbeetlehorns2"

func getCompatibleSpecies():
	return ["sbeetle"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleHorns2/sBeetlehorns2.tscn"

func getCharacterCreatorDesc():
	return "From Insect Species"

