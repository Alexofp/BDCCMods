extends BodypartTail

func _init():
	visibleName = "beetle tail1"
	id = "sbeetletail1"

func getCompatibleSpecies():
	return ["sbeetle"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleTail1/SBeetletail1.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
