extends BodypartHead

func _init():
	visibleName = "beetle head 2"
	id = "sbeetlehead2"

func getCompatibleSpecies():
	return ["sbeetle"]

func getCharacterCreatorDesc():
	return "From Insect Species"

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleHead2/SBeetleHead2.tscn"

func getHeadLength():
	return 0.6

func npcGenerationWeight(_dynamicCharacter):
	return 0.1
