extends BodypartHead

func _init():
	visibleName = "beetle head 1"
	id = "sbeetlehead1"

func getCompatibleSpecies():
	return ["sbeetle"]

func getCharacterCreatorDesc():
	return "From Insect Species"

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Beetle/BeetleHead1/SBeetleHead1.tscn"

func getHeadLength():
	return 0.4
