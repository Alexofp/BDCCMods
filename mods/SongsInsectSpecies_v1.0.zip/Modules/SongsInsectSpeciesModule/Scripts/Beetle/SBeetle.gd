extends Species

func _init():
	id = "sbeetle"
	
func getVisibleName():
	return "Beetle"

func getDefaultLegs(_gender):
	return "sbeeltelegs1"

func getDefaultTail(_gender):
	return "sbeetletail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "the famous band"

func getDefaultHead(_gender):
	return "sbeetlehead1"

func getDefaultArms(_gender):
	return "sbeetlearms1"

func getDefaultEars(_gender):
	return "songindummyears"

func getDefaultHorns(_gender):
	return "sbeetlehorns1"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
			return "dragonpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 10.0],
		[2, 1.5],
		[3, 0.5],
	]
