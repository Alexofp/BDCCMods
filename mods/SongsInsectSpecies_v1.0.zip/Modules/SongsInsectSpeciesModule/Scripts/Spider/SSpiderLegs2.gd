extends BodypartLeg

func _init():
	visibleName = "Spider legs 2"
	id = "sspiderlegs2"

func getCompatibleSpecies():
	return ["sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Spider/SpiderLegs2/SpiderLegs2.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
