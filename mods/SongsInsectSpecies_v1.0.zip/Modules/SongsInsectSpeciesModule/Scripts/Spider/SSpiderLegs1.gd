extends BodypartLeg

func _init():
	visibleName = "Spider legs 1"
	id = "sspiderlegs1"

func getCompatibleSpecies():
	return ["sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Spider/SpiderLegs1/SpiderLegs1.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
