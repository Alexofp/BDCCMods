extends BodypartHead

func _init():
	visibleName = "Spider head1"
	id = "sspiderhead1"

func getCompatibleSpecies():
	return ["sspider"]

func getCharacterCreatorDesc():
	return "From Insect Species"

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Spider/SpiderHead1/SpiderHead1.tscn"

func getHeadLength():
	return 0.1
