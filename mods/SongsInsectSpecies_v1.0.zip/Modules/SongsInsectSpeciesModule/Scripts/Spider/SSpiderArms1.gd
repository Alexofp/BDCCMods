extends BodypartArms

func _init():
	visibleName = "Spider Arms"
	id = "sspiderarms1"

func getCompatibleSpecies():
	return ["sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Spider/SpiderArms/SpiderArms1.tscn"
