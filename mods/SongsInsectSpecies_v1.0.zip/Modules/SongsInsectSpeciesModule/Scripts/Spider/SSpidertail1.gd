extends BodypartTail

func _init():
	visibleName = "Spider tail"
	id = "sspidertail1"

func getCompatibleSpecies():
	return ["sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Spider/SpiderTail1/Spidertail1.tscn"
