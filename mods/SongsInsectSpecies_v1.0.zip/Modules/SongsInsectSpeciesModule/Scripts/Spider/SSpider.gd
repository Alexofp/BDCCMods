extends Species

func _init():
	id = "sspider"
	
func getVisibleName():
	return "Spider"

func getDefaultLegs(_gender):
	return "sspiderlegs1"

func getDefaultTail(_gender):
	return "sspidertail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "With great power comes great responsibility"

func getDefaultHead(_gender):
	return "sspiderhead1"

func getDefaultArms(_gender):
	return "sspiderarms1"

func getDefaultEars(_gender):
	return "songindummyears"

func getDefaultHorns(_gender):
	return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
			return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[3, 2.0],
		[4, 2.0],
		[5, 4.0],
		[6, 4.0],
	]
