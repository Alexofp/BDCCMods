extends BodypartEars

func _init():
	visibleName = "Insect Flufffs"
	id = "sinsectflufffs"

func getCompatibleSpecies():
	return ["sbee", "smoth", "sbeetle", "sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Uni/InsectFluffyBody/InsectFluffyBody.tscn"

func getCharacterCreatorDesc():
	return "From Insect Species"
