extends BodypartTail

func _init():
	visibleName = "Bee tail 2"
	id = "sbeetail2"

func getCompatibleSpecies():
	return ["sbee"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeTail2/SBeetail2.tscn"
