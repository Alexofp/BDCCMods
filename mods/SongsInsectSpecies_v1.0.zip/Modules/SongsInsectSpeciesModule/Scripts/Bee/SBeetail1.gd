extends BodypartTail

func _init():
	visibleName = "Bee tail"
	id = "sbeetail1"

func getCompatibleSpecies():
	return ["sbee"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeTail1/SBeetail1.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
