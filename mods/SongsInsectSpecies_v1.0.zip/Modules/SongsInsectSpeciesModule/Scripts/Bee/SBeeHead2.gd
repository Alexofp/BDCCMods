extends BodypartHead

func _init():
	visibleName = "bee head 2"
	id = "sbeehead2"

func getCompatibleSpecies():
	return ["sbee"]

func getCharacterCreatorDesc():
	return "From insect Species"

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeHead2/SBeeHead2.tscn"

func getHeadLength():
	return 0.1
