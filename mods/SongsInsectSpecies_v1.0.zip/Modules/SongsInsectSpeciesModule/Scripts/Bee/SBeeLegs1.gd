extends BodypartLeg

func _init():
	visibleName = "Bee legs"
	id = "sbeelegs1"

func getCompatibleSpecies():
	return ["sbee"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeLegs/BeeLegs1.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
