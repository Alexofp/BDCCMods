extends BodypartHead

func _init():
	visibleName = "bee head 1"
	id = "sbeehead1"

func getCompatibleSpecies():
	return ["sbee"]

func getCharacterCreatorDesc():
	return "From insect Species"

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeHead1/SBeeHead1.tscn"

func getHeadLength():
	return 0.1
