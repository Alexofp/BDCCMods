extends Species

func _init():
	id = "sbee"
	
func getVisibleName():
	return "Bee"

func getDefaultLegs(_gender):
	return "sbeelegs1"

func getDefaultTail(_gender):
	return "sbeetail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "Stingers"

func getDefaultHead(_gender):
	return "sbeehead1"

func getDefaultArms(_gender):
	return "sbeearms1"

func getDefaultEars(_gender):
	return "songindummyears"

func getDefaultHorns(_gender):
	return "sbeehorns1"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
			return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[3, 2.0],
		[4, 2.0],
		[5, 4.0],
		[6, 4.0],
	]

func generateSkinColors():
	var palettes = [
		["#F29E35", "#F29E35", "#F29E35"],
		["#E0BA36", "#E0BA36", "#E0BA36"],
		["#E57C43", "#E57C43", "#E57C43"],
		["#FCF25D", "#FCF25D", "#FCF25D"],
		["#FFD200", "#FFD200", "#FFD200"],
	]

	return palettes.pick_random()
