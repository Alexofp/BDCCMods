extends BodypartHorns

func _init():
	visibleName = "bee antenas1"
	id = "sbeehorns1"

func getCompatibleSpecies():
	return ["sbee"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeHorns1/sBeehorns1.tscn"

func getCharacterCreatorDesc():
	return "From Insect Species"
