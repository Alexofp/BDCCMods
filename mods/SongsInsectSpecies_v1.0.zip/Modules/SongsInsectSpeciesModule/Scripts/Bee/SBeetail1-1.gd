extends BodypartTail

func _init():
	visibleName = "Bee tail(Sting)"
	id = "sbeetail1-1"

func getCompatibleSpecies():
	return ["sbee"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeTail1-1/SBeetail1-1.tscn"
