extends BodypartArms

func _init():
	visibleName = "Bee Arms"
	id = "sbeearms1"

func getCompatibleSpecies():
	return ["sbee"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Bee/BeeArms/BeeArms1.tscn"
