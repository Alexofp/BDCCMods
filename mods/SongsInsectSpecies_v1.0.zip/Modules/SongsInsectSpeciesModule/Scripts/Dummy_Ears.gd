extends BodypartEars

func _init():
	visibleName = "No Ears"
	id = "songindummyears"

func getCompatibleSpecies():
	return ["sbee", "smoth", "sbeetle"]
