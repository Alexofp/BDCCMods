extends BodypartLeg

func _init():
	visibleName = "Moth legs"
	id = "smothlegs1"

func getCompatibleSpecies():
	return ["smoth", "sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Moth/MothLegs/MothLegs1.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
