extends BodypartTail

func _init():
	visibleName = "Moth tail1"
	id = "smothtail1"

func getCompatibleSpecies():
	return ["smoth"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Moth/MothTail1/Mothtail1.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
