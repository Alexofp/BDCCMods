extends BodypartArms

func _init():
	visibleName = "Moth Arms"
	id = "smotharms1"

func getCompatibleSpecies():
	return ["smoth", "sspider"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Moth/MothArms/MothArms1.tscn"
