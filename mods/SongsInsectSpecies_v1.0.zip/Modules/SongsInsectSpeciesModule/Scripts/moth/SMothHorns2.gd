extends BodypartHorns

func _init():
	visibleName = "Moth antenas 2"
	id = "smothhorns2"

func getCompatibleSpecies():
	return ["smoth"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Moth/MothHorns2/Mothhorns2.tscn"

func getCharacterCreatorDesc():
	return "From Insect Species"

