extends BodypartHorns

func _init():
	visibleName = "Moth antenas 1"
	id = "smothhorns1"

func getCompatibleSpecies():
	return ["smoth"]

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Moth/MothHorns1/Mothhorns1.tscn"

func getCharacterCreatorDesc():
	return "From Insect Species"

