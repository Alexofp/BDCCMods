extends BodypartHead

func _init():
	visibleName = "Moth head1"
	id = "smothhead1"

func getCompatibleSpecies():
	return ["smoth"]

func getCharacterCreatorDesc():
	return "From Insect Species"

func getDoll3DScene():
	return "res://Modules/SongsInsectSpeciesModule/Pngs/Moth/MothHead1/MothHead1.tscn"

func getHeadLength():
	return 0.1
