extends Module

func _init():
	id = "sinsectspecies"
	author = "Songjo"
	
	bodyparts = [
	#All(27)
	#Bee(7)
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeeHead1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeeHead2.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeeHorns1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeetail1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeetail1-1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeetail2.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeeArms1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBeeLegs1.gd",
	#Moth(6)
	"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMothArms1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMothHead1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMothHorns1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMothHorns2.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMothLegs1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMothtail1.gd",
	#Beetle(7)
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetleHead1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetleHead2.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetleHorns1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetleHorns2.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetletail1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetleLegs1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetleArms1.gd",
	#Spider(5)
	"res://Modules/SongsInsectSpeciesModule/Scripts/Spider/SSpiderHead1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Spider/SSpidertail1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Spider/SSpiderLegs1.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Spider/SSpiderLegs2.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/Spider/SSpiderArms1.gd",

	#Universal(2)
	"res://Modules/SongsInsectSpeciesModule/Scripts/Dummy_Ears.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/InsectFluffs_Backup.gd",
	"res://Modules/SongsInsectSpeciesModule/Scripts/InsectFluffs.gd",
	]
	
	species = [
		"res://Modules/SongsInsectSpeciesModule/Scripts/Bee/SBee.gd",
		"res://Modules/SongsInsectSpeciesModule/Scripts/moth/SMoth.gd",
		"res://Modules/SongsInsectSpeciesModule/Scripts/Beetle/SBeetle.gd",
		"res://Modules/SongsInsectSpeciesModule/Scripts/Spider/SSpider.gd",
	]
