extends SceneBase

var chosenItemUID : String = ""

func _init():
	sceneID = "BaseWorkbenchScene"
	# use sceneTag to set workbench id

func _run():
	var craftingLibMod = getModule("CraftingLib")
	var wb = craftingLibMod.getWorkbenchInstanceFromId(sceneTag)
	if !wb:
		saynn("ERROR: workbench with id "+sceneTag+" doesn't exist!")
		addButton("End","idk","endthescene")
		return
	if(state == ""):
		playAnimation(StageScene.Solo,"stand",{
			pc="pc", npc="", pcCum=false,
			bodyState={},
		})
		saynn("You stand in front of your trusty "+craftingLibMod.getWorkbenchTypeData(getType()).get("name","thing")+".")
		sayn("It has:")
		displayIngredients()
		saynn("What do you wanna do?")
		
		addButton("Step away","Enough work","endthescene")
		addButton("Add liquid ingredient from item","Do the thing","addfluiditem")
		
		addButton("Throw away ingredient..","Choose what has to go","choosethrow")
		addButtonUnlessLate("Craft","See what you can craft","craftoptions")
		
	elif state=="choosethrow":
		sayn("You have:")
		displayIngredients()
		saynn("\nWhat do you want to get rid of?")
		addButton("Nevermind","You changed your mind","")
		var ings = getStores()
		for key in ings.keys():
			var n = craftingLibMod.getIngredientData(key).get("name","Unknown")
			addButton(n,"Throw all of it away","throwaway",[key])
	elif state=="craftoptions":
		saynn("You prepare to craft something.")
		sayn("You have:")
		displayIngredients()
		sayn("\nRecipes:")
		var wtype = getType()
		var recs = craftingLibMod.getRecipesForType(wtype)
		for id in recs.keys():
			var rec = recs[id]
			var n = rec.get("name","Unknown")
			sayn("[color=yellow]"+n+"[/color]")
			sayn("Requires items:")
			var itemings = rec.get("itemIngredients",{})
			var itemStr = "\n".join(craftingLibMod.getIngredientsRequiredArray({},itemings,GM.pc.getInventory()))
			sayn((itemStr if itemStr else "(none)"))
			sayn("Requires ingredients:")
			var ingings = rec.get("ingIngredients",{})
			var ingStr = "\n".join(craftingLibMod.getIngredientsRequiredArray(ingings,{}))
			saynn((ingStr if ingStr else "(none)"))
		
		
		addButton("Nevermind","You changed your mind","")
		addAvailRecipesButtons(GM.pc.getInventory())
	elif state=="addfluiditem":
		saynn("Choose an item to transfer the ingredient from (you'll be prompted to choose the fluid type):")
		addButton("Nevermind","You changed your mind","")
		var equippedItems = GM.pc.getInventory().getAllEquippedItems()
		for slot in equippedItems:
			var equippedItem:ItemBase = equippedItems[slot]
			
			if(equippedItem.getFluids() != null):
				if(equippedItem.getFluids().isEmpty()):
					addDisabledButton(equippedItem.getStackName(), "(This item is empty)\n\n"+equippedItem.getVisisbleDescription())
				else:
					addButton(equippedItem.getStackName(), equippedItem.getVisisbleDescription(), "addfluidfrom", [equippedItem.getUniqueID()])
		for theitem in GM.pc.getInventory().getItems():
			
			if(theitem.getFluids() != null):
				if(theitem.getFluids().isEmpty()):
					addDisabledButton(theitem.getStackName(), "(This item is empty)\n\n"+theitem.getVisisbleDescription())
				else:
					addButton(theitem.getStackName(), "Choose a fluid to transfer from this item.\n\n"+theitem.getVisisbleDescription(), "addfluidfrom", [theitem.getUniqueID()])
	
	elif state=="addfluidfrom":
		if !chosenItemUID:
			setState("")
			return
		var it = GM.pc.getInventory().getItemByUniqueID(chosenItemUID)
		var fl : Fluids = it.getFluids()
		saynn("Select fluid type to transfer to workbench from %s." % it.getVisibleName())
#		var fls = []
		addButton("Nevermind","","addfluiditem")
		for ingid in craftingLibMod.getValidWorkbenchTypeAllowedFluids(getType()):
			var amount = fl.getFluidAmountByType().get(ingid,0.0)
			if amount!=0:
				var iname = craftingLibMod.getIngredientData(ingid).get("name","Unknown")
				addButton(iname,"Add this fluid type from the item","addfluidtypefrom",[chosenItemUID,ingid])
			else:
				print(ingid)
	

func _react(_action: String, _args):
	var craftingLibMod = getModule("CraftingLib")
	if(_action == "endthescene"):
		endScene()
		return
	if _action == "dbAddVcum":
		var fl = Fluids.new()
		var dna = FluidDNA.new()
		dna.virility = 1.0
		fl.addFluid("Cum",100,dna)
		craftingLibMod.addCream(fl)
		setState("")
		return
	if _action == "dbAddScum":
		var fl = Fluids.new()
		var dna = FluidDNA.new()
		dna.virility = 0.0
		fl.addFluid("Cum",100,dna)
		craftingLibMod.addCream(fl)
		setState("")
		return
	if _action=="throwaway":
		var ingDict = getStores().get(_args[0],{})
		var odata = ingDict.get("data",{})
		var initAmount = ingDict.get("amount",0)
		craftingLibMod.addIngredient(sceneTag,_args[0],-initAmount,odata)
		var n = craftingLibMod.getIngredientData(_args[0]).get("name","Unknown")
		addMessage("You threw all of the "+n+" away")
		processTime(60)
		setState("choosethrow")
		return
	if _action=="craftRecipe":
		var res = craftingLibMod.fullerCraftRecipe(_args[0],sceneTag,_args[1])
		craftingLibMod.addCraftedItemsToInv(res.get("items",[]),_args[1])
		for ing in res.get("ingredients",[]):
			craftingLibMod.addIngredient(sceneTag,ing[0],ing[1])
		
		addMessage("You crafted:\n%s" % res.get("message",""))
		processTime(60*45)
		setState("craftoptions")
		return
	if _action=="addfluidfrom":
		chosenItemUID = _args[0]
#				craftingLibMod.addFluidType(sceneTag,fl,ingid)
#				fl.removeFluidType(ingid)
#				fls.append([ingid,amount])
#		var list = []
#		for ar in fls:
#			var iname = craftingLibMod.getIngredientData(ar[0]).get("name","Unknown")
#			list.append(str(ar[1]).pad_decimals(2)+" ml "+iname)
#		var lflStr = list.pop_back()
#		var listStr = ", ".join(list)+(" and " if list else "")+lflStr
		
#		addMessage("You stored "+listStr+" from "+it.getVisibleName())
		setState(_action)
		return
	if _action=="addfluidtypefrom":
		var it = GM.pc.getInventory().getItemByUniqueID(_args[0])
		var fl : Fluids = it.getFluids()
		
		var ingid = _args[1]
		var amount = fl.getFluidAmountByType().get(ingid,0.0)
		
		
		var iname = craftingLibMod.getIngredientData(ingid).get("name","Unknown")
		
		
		craftingLibMod.addFluidType(sceneTag,fl,ingid)
		fl.removeFluidType(ingid)
		addMessage("You stored "+str(amount).pad_decimals(2)+" ml "+iname+" from "+it.getVisibleName())
		setState("")
		return
	
	setState(_action)

func loadData(data):
	.loadData(data)
	chosenItemUID = data.get("chosenItemUID","")

func saveData():
	var d = .saveData()
	d["chosenItemUID"] = chosenItemUID
	return d

func displayIngredients():
	var ings = getStores()
	if !ings:
		sayn("(none)")
		return
	for key in ings.keys():
		var idata = getModule("CraftingLib").getIngredientData(key)
		sayn(idata.get("name","Unknown")+": "+str(ings[key].get("amount",0.0)).pad_decimals(2)+" "+idata.get("measure",""))

func getStores() -> Dictionary:
	return getModule("CraftingLib").getWorkbenchStores(sceneTag)

func getType():
	return getModule("CraftingLib").getWorkbenchInstanceType(sceneTag)

func addAvailRecipesButtons(inv:Inventory=GM.pc.getInventory()):
	var craftingLibMod = getModule("CraftingLib")
	var avails = craftingLibMod.getRecipesCanMakeType(sceneTag,inv)
	for recid in avails.keys():
		var wtype = getType()
		var rec = craftingLibMod.getRecipeFromId(recid,wtype)
		if avails[recid]:
			addButtonUnlessLate(rec.get("name","Unknown Recipe"),"Try to make this","craftRecipe",[recid,GM.pc.getInventory()])
		else:
			addDisabledButton(rec.get("name","Unknown Recipe"),"You can't make this")
	
