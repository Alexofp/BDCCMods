extends Module

var workbenchTypes = {} # dict of string keys, loaded once. this is what we use to get the recipe, name, etc. data from. must include key for name. valid keys are: name, allowedFluids (string of fluid ids, like so: "flId,flId2,flId3...")

var modulesWithData : Dictionary # we draw data from these

func getFlags():
	return {
		"workbenches":flag(FlagType.Dict), # key is id, value is dict w/ data. this is for instances, eg. different workbenches of the same type in different rooms
	}

func _init():
	id = "CraftingLib"
	author = "Selinoccino"

	scenes = [
		"res://Modules/CraftingLib/Scenes/baseWorkbench.gd",
	]

func postInit(): # Called after everything is registered
	var modules = GlobalRegistry.getModules()
	for module in modules.keys():
		var mo : Module = modules[module]
		var modAddsRecs = mo.has_method("getAddedRecipes")
		var modAddsIngs = mo.has_method("getAddedIngredients")
		if mo.has_method("getAddedWorkbenchTypes"):
			workbenchTypes.merge(mo.getAddedWorkbenchTypes(),true)
		if modAddsIngs or modAddsRecs:
			modulesWithData[module]={
				"recipes":modAddsRecs, # if it adds stuff, set that value
				"ingredients":modAddsIngs,
			}


func getValidWorkbenchTypeAllowedFluids(wtype:String) -> Array: # same as below, but only gets fluids that are valid fluid ingredients
	var res = []
	var validflids = getIngredientFluids()
	for wbflid in getWorkbenchTypeAllowedFluids(wtype):
		if wbflid in validflids:
			res.append(wbflid)
			validflids.erase(wbflid)
		
	return res

func getWorkbenchTypeAllowedFluids(wtype:String) -> Array: # array constructed from string like so: "fluidId,fluidId2,fluidId3..."
	return getWorkbenchTypeData(wtype).get("allowedFluids","").split(",",false)

func getWorkbenchTypeData(wtype:String) -> Dictionary:
	return getAllWorkbenchTypes().get(wtype,{})

# dict or null
func getWorkbenchInstanceFromId(wid:String):
	if !wid:
		return null
	return getWorkbenchInstances().get(wid,null)

## dict or null
func getWorkbenchStores(wid:String):
	var wb = getWorkbenchInstanceFromId(wid)
	if !wb: # no such workbench
		return null

	return wb.get("stores",{})

func addIngredient(wid:String,ingid:String,amount:float,data:Dictionary={}) -> float: # returns new amount or 0
	var ings = getWorkbenchStores(wid)
	if ings==null:
		return 0.0
	var storedAmount = ings.get(ingid,{}).get("amount",0.0)
	var odata = ings.get(ingid,{}).get("data",{})
	var ndata = odata.duplicate(true)
	for key in data.keys():
		ndata[key] = (str(data[key]).to_float()+str(odata.get(key,0)).to_float())/2.0 # avg of the values
	var nam = max(0,amount+storedAmount)
	ings[ingid]={"amount":nam,"data":ndata} # no negatives
	
	saveWorkbenchInstanceStores(wid,ings)
	return nam

func saveWorkbenchInstanceStores(wid:String,stores:Dictionary) -> void:
	var instances = getWorkbenchInstances()
	var data = instances.get(wid,{})
	data["stores"]=stores
	instances[wid]=data
	saveWorkbenchInstances(instances)

func getAvgVirility(fluids:Fluids) -> float:
	if fluids.getFluidAmount()==0:
		return 0.0
	var virileAmount = 0.0
	for fluidData in fluids.contents:
		var fluidDNA = fluidData["fluidDNA"] if fluidData.has("fluidDNA") else null
		if(!fluidDNA):
			continue
		var fluidType:String = fluidData["fluidType"]
		var theFluid:FluidBase = GlobalRegistry.getFluid(fluidType)
		if(!theFluid):
			continue

		if(theFluid.canImpregnate() && fluidDNA.getVirility() > 0.01):
			virileAmount += fluidData["amount"]*fluidDNA.getVirility() # the more virile, the better; can go more than 100% quality

	return virileAmount/fluids.getFluidAmount()

func getAvgTypeVirility(fluids:Fluids,type:String="Cum") -> float:
	if !fluids.hasFluidType(type):
		return 0.0
	var virileAmount : float = 0.0
	for fluidData in fluids.contents:
		var fluidDNA = fluidData["fluidDNA"] if fluidData.has("fluidDNA") else null
		var fluidType:String = fluidData["fluidType"]
		if !fluidDNA or fluidType!=type: # continue if invalid
			continue

		var theFluid:FluidBase = GlobalRegistry.getFluid(fluidType)
		if(!theFluid):
			continue
		if(theFluid.canImpregnate() && fluidDNA.getVirility() > 0.00):
			virileAmount += fluidData["amount"]*fluidDNA.getVirility() # the more virile, the better; can go more than 100% quality
	var avg : float = virileAmount/fluids.getFluidAmountByType().get(type,0.0)
	return avg

func isFluidTypeValidIngredient(ftype:String) -> bool:
	return ftype in getAllIngredients().keys()

func addFluidType(wid:String,fl:Fluids,type:String="Cum") -> float: # wid is workbench instance id, returns new amount or 0
	if !isFluidTypeValidIngredient(type):
		return 0.0
	var wb = getWorkbenchInstanceFromId(wid)
	if !wb:
		return 0.0
	var avgVir = getAvgTypeVirility(fl,type)
	var amount = fl.getFluidAmountByType().get(type,0.0)
	var ings = getWorkbenchStores(wid)
	var storedFluidData = ings.get(type,{})
	var finalData = storedFluidData.get("data",{}) # to keep other old data

	var finalAmount : float = amount+storedFluidData.get("amount",0.0)
	if finalAmount==0: # impossible div
		return 0.0
	var newFluidShare = amount/finalAmount
	var oldFluidShare = storedFluidData.get("amount",0.0)/finalAmount

	finalData["virility"] = finalData.get("virility",0.0)*oldFluidShare+avgVir*newFluidShare
	ings[type] = {
		"amount":amount+storedFluidData.get("amount",0.0),
		"data":finalData,
		}

	saveWorkbenchInstanceStores(wid,ings) # saves data ig
	return finalAmount

func fluidToIngredient(fl:Fluids,type:String) -> Dictionary: # returns dict to be put in other ings dict
	var amount = fl.getFluidAmountByType().get(type,0.0)
	var avgVir = getAvgTypeVirility(fl,type)
	var dat = {}
	if avgVir:
		dat["virility"]=avgVir
	return {"amount":amount,"data":dat}

func getAllIngredients() -> Dictionary:
	var ings = {}
	for modId in modulesWithData.keys():
		if modulesWithData[modId].get("ingredients",false):
			ings.merge(GlobalRegistry.getModule(modId).getAddedIngredients(),true)

	return ings

func getIngredientData(id:String) -> Dictionary:
	var ings = getAllIngredients()

	return ings.get(id,{})

func getAllRecipes() -> Dictionary: # returns all recipes, overwriting if same id
	var res = {}
	for type in getAllWorkbenchTypes():
		res.merge(getRecipesForType(type),true)
	return res

func getRecipesForType(wtype:String) -> Dictionary: # wtype is workbench type
	var recs = {}
	for modId in modulesWithData.keys():
		if modulesWithData[modId].get("recipes",false):
			recs.merge(GlobalRegistry.getModule(modId).getAddedRecipes(wtype),true)

	return recs

func getRecipeFromIdGlobal(recid:String) -> Dictionary:
	return getAllRecipes().get(recid,{})

func getRecipeFromId(recid:String,wtype:String) -> Dictionary:
	return getRecipesForType(wtype).get(recid,{})

func getRecipeQuality(rec:Dictionary,ings:Dictionary,inv:Inventory=null) -> Dictionary: # recipe is the dict itself, as are the ingredients, and inv is the inventory of the char using it, if any
	if !rec:
		return {}
	var q = {}

	var ingredients = rec.get("ingIngredients",{})
	var correctIngs = 0
	for givenIng in ings.keys(): # count given ings that are also base, ignoring extras
		correctIngs += int(givenIng in ingredients.keys())

	var itemIngs = rec.get("itemIngredients",{})
	if inv:
		for itemid in itemIngs.keys():
			correctIngs += int(inv.hasItemID(itemid))

	if correctIngs!=ingredients.keys().size()+itemIngs.keys().size(): # wrong correct ings, some are missing
#		print("incorrect ing pop for "+rec.get("name"))
		return {}

	var ingQualityData = {} # if some ingredient is worth different, it's put there (key is ingredient id, value is final quality for ingredient)

	var qpercsum := 0.0 # quality percentage sum, to find avg quality from each ingkey quality

	var count = 0 # only counts stuff that's normal in quality calcs
	for ingkey in ingredients.keys(): # for given ingredients, checks against base ingredients since we know they exist
		var reqamount = ingredients[ingkey]
		var givenamount = ings[ingkey].get("amount",0)
		var m = reqamount[0]
		if givenamount<m: # an ingredient isn't enough
			return {}

		var perc = 0.0 # satisfaction perc, pretty much float 0-1 between min-max if req range, otherwise for static req amount 1.0 if correct
		var percMult = 1.0 # this is set sepending on special ingredient quality data


		if reqamount.size()>1: # req amount range
			var M = reqamount[1]
			perc = min(inverse_lerp(m,M,givenamount),1.0)
		else: # enough if no req range; static req amount
			perc = float(givenamount>=m)

		var fqual = percMult*perc # this is for avg. quality or ing quality
		if rec.get("specQualities",{}).has(ingkey): # has special quality data
			var qdata = rec.get("specQualities",{}).get(ingkey,[]) # the quality data must have only an array of the names of the keys found in the data dict of the ingredient. for cum this would be [avgVirility] as found by getAvgVirilityType func, for example. all keys have the same weight and their average is returned for this ingredient. value of each element in the array should be a float, and counts as a percentage
			var qvarsum = 0.0 # sum of all qdata qvars, to calc avg.
			for qvar in qdata:
				qvarsum+=ings[ingkey].get("data",{}).get(qvar,0.0)
			if qdata.empty(): # we have an entry but no values, do regular stuff
				fqual = perc*percMult
			else:
				fqual = perc*(qvarsum/float(qdata.size()))
			ingQualityData[ingkey]=fqual # save the special quality
		else:
			qpercsum += perc*percMult
			count+=1


	for itemid in itemIngs.keys(): # for inv, checks against required items since we know they exist
		var reqamount = itemIngs[itemid]
		var givenamount = inv.getAmountOf(itemid)
		var m = reqamount[0]
		if givenamount<m: # an item isn't enough
			return {}

		var perc = 0.0 # satisfaction perc, pretty much float 0-1 between min-max if req range, otherwise for static req amount 1.0 if correct


		if reqamount.size()>1: # req amount range
			var M = reqamount[1]
			perc = min(inverse_lerp(m,M,givenamount),1.0)
		else: # enough if no req range; static req amount
			perc = float(givenamount>=m)

		qpercsum += perc
		count+=1


	q = qpercsum/float(count)

	return {"quality":q,"ingredientQualities":ingQualityData}

func getAvailRecipesForInstance(wid:String,inv:Inventory=null) -> Array: # array of recipe ids
	var avails = []
	var wb = getWorkbenchInstanceFromId(wid)
	if !wb:
		return []
	var allrecs = getRecipesForType(wb.get("type"))
	for rec in allrecs:
		var q = getRecipeQuality(rec,getWorkbenchStores(wid),inv)
		if q.get("quality",0.0)!=0: # can make
			avails.append(rec)

	return avails

func getRecipesCanMakeType(wid,inv:Inventory=null) -> Dictionary: # returns dict w/ all recipes for workbench type as keys, and all values as doable or not (have min. ingredients/items)
	var res = {} # key is recid for rec, value is can be made bool (true means you can make it)
	var wb = getWorkbenchInstanceFromId(wid)
	if !wb:
		return {}
	var allRecs = getRecipesForType(wb.get("type")) # all recipes
	for id in allRecs.keys():
		var q = getRecipeQuality(allRecs[id],getWorkbenchStores(wid),inv)
		res[id]=q.get("quality",0.0)!=0
	return res

func getIngredientsRequiredArray(ingredients:Dictionary,itemIngredients:Dictionary={}, fromInv:Inventory=null) -> Array: # to display recipe requirements, array of strings
	var lines = []
	for ing in ingredients.keys():
		var idata = getIngredientData(ing)
		var a = "-".join(PoolStringArray(ingredients[ing]))
		var t = a+" "+idata.get("measure","")+" "+idata.get("name","Unknown")
		lines.append(t)

	for itemid in itemIngredients.keys():
		var tempItem = GlobalRegistry.createItemNoID(itemid)
		var a = "-".join(PoolStringArray(itemIngredients[itemid]))
		var t = "%sx %s%s" % [a, tempItem.getVisibleName(), ( "[color=grey] (you have %s)[/color]" % fromInv.getXOfTotal(itemid) if fromInv else "" )]
		lines.append(t)
	return lines

func getWorkbenchInstanceType(wid:String):
	var wb = getWorkbenchInstanceFromId(wid)
	if !wb:
		return null
	return wb.get("type",null)

func craftRecipe(recid:String,wid:String,inv:Inventory=null) -> Dictionary: # always assumes can be made, recid is recipeid for rec (key in recipes dict), returns dict of items/ingredients
	var wb = getWorkbenchInstanceFromId(wid)
	if !wb:
		print("no such workbench "+wid)
		return {}
	var rec = getRecipeFromId(recid,wb.get("type"))
	if !rec:
		print("no such recipe "+recid+" for wb id "+wid)
		return {}

	var ings = getWorkbenchStores(wid)
	var resultingItems : Array = []

	var reqings = rec.get("ingIngredients",{})
	var qdata = getRecipeQuality(rec,ings,inv)
	for itArray in rec.get("itemids",[]):
		var it : ItemBase = GlobalRegistry.createItem(itArray[0]) # index 0 is id
		if it.has_method("getQuality"): # don't set quality for items that don't have any, such as basegame items
			if it.get("qdata"): # item quality depends on various ingredients' qualities
				it.qdata["baseQuality"] = qdata["quality"]
				it.qdata["ingredientQualities"] = qdata["ingredientQualities"]
				it.quality = it.getQuality()
			else: # no nuanced quality calcs in item
				it.quality = qdata["quality"]
		it.setAmount(itArray[1])
		resultingItems.append(it)

	for ing in reqings.keys():
		var remVal = 0
		var givenAmount = ings[ing].get("amount",0.0)
		var reqAmount = reqings[ing]
		if reqAmount.size()>1: # req amount range
			remVal = min(givenAmount,reqAmount[1])
		else: # req amount static
			remVal = min(givenAmount,reqAmount[0]) # since always can make
		var na = max(0,givenAmount-remVal) # decrease stores
		ings[ing]["amount"]=na

	var reqItems = rec.get("itemIngredients",{})
	for itemid in reqItems.keys():
		var remVal = 0
		var reqAmount = reqItems[itemid]
		if reqAmount.size()>1: # req amount range
			remVal = reqAmount[1] # get max
		else: # req amount static
			remVal = reqAmount[0] # since always can make
		inv.removeXOfOrDestroy(itemid,remVal)

	saveWorkbenchInstanceStores(wid,ings)
	var resultingIngredients = rec.get("ingIds",[])
	var res = {"items":resultingItems,"ingredients":resultingIngredients}
	return res

func fullerCraftRecipe(recid:String,wid:String,inv:Inventory=null) -> Dictionary: # returns dict {items=array(object), ings=array(id,amount),message=string}, doesn't add items to inv
	var finv = inv if inv else GM.pc.getInventory()
	var craftResult = craftRecipe(recid,wid,finv)
	var items : Array = craftResult.get("items",[]) # one-dimensional array of items
	var resultingIngs = craftResult.get("ingredients",[]) # [[id,amount],...]
	
	var list = []
	for item in items:
		list.append(item.getAStackName())
	for ing in resultingIngs:
		var idata = getIngredientData(ing[0])
		var m = idata.get("measure","")
		var iname = idata.get("name","Unknown")
		list.append(str(ing[1])+(" "+m if m else "")+" "+iname)
		addIngredient(wid,ing[0],ing[1])
	
	var listStr = "nothing"
	if list.size()>0:
		var lastStr = list.pop_back()
		listStr = ", ".join(list)+(" and " if list else "")+lastStr
	
	return {
		"items":items,
		"ings":resultingIngs,
		"message":listStr,
	}


func addCraftedItemsToInv(craftedIts:Array,inv:Inventory) -> void: # this is to easily add the items from craftRecipe() func
	if !inv:
		return
	for it in craftedIts:
		if it.getAmount()<1:
			continue
		inv.addItem(it)

func getIngredientFluids() -> Array: # returns an array of all fluidTypes that have the same id as an ingredient, this is why the cream ingredient has the id "Cum"
	var res = []
	var ings = getAllIngredients()
	var fluidIds = GlobalRegistry.getFluids().keys()
	for fluid in fluidIds:
		if ings.has(fluid):
			res.append(fluid)
	return res

func fullCraftRecipe(recid:String,wid:String,inv:Inventory=null) -> void: # this does everything, use when crafting simple recipes. always assumes can be made
	var recipeResultData = fullerCraftRecipe(recid,wid,inv)
	for ingArray in recipeResultData.get("ingredients",[]):
		addIngredient(wid,ingArray[0],ingArray[1])
	if !inv:
		return
	addCraftedItemsToInv(recipeResultData.get("items",[]),inv)
	GM.main.addMessage(recipeResultData.get("message",""))

func getAllWorkbenchTypes() -> Dictionary:
	return workbenchTypes

func getAllWorkbenchData(): # key is type, value is dict with name and recipes
	return {}

func createWorkbenchInstance(id:String,type:String,stores:Dictionary={}) -> bool: # stores is ingredients that are included; returns true if succeeds, false otherwise
	if !type in getAllWorkbenchTypes(): # if type is invalid, we don't have recipes; abort
		return false
	var instances = getWorkbenchInstances()
	instances[id]={"type":type,"stores":stores}
	saveWorkbenchInstances(instances)
	return true

func getWorkbenchInstances() -> Dictionary:
	return getFlag("CraftingLib.workbenches",{})

func saveWorkbenchInstances(newData:Dictionary) -> void:
	setFlag("CraftingLib.workbenches",newData)
