extends Species

func _init():
	id = "sugerrorc"

func isPlayable():
	return true

func getVisibleName():
	return "Orc"

func getVisibleDescription():
	return "Orc orc"

func getAllowedBodyparts():
	return ["humanears"]

func getDefaultLegs(_gender):
	return "plantilegs"

func getDefaultTail(_gender):
	return null

func getDefaultHead(_gender):
	return "sugerrorchead3"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "sugerrorcearsv1"
	
func getDefaultBody(_gender):
	return "anthrobody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null
	
func getSkinType():
	return SkinType.SkinHuman

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]

func generateSkinColors():
	var tonesorc = [
		["#a2be80", "#778d3e", "#30461e"],  # pale green-yellow
		["#a5daa4", "#78a266", "#7fbd63"],  # pale green
		["#86B8A1", "#67996C", "#77C792"],  # pale green-blue
		["#7dad56", "#609C4E", "#A5CC6C"],  # green-yellow
		["#5E9456", "#557339", "#80A65D"],  # green
		["#418d56", "#2c6230", "#4d9952"],  # green-blue
		["#677D47", "#415C2F", "#677841"],  # medium green-yellow
		["#3f783b", "#3c692e", "#588434"],  # medium green
		["#3c6f4f", "#29543d", "#397d5f"],  # medium green-blue
		["#3a5125", "#233e23", "#4a621c"],  # dark green-yellow
		["#3a5736", "#1F3B24", "#4C6E3D"],  # dark green
		["#346140", "#2F5746", "#487553"],  # dark green-blue
		["#2a391a", "#18210c", "#2e421a"],  # very dark green-yellow
		["#153611", "#132710", "#294b18"],  # very dark green
		["#1a3f2d", "#143218", "#1c6341"],  # very dark green-blue
	]
	
	var randomSkinTone = RNG.pick(tonesorc)
	return [Color(randomSkinTone[0]), Color(randomSkinTone[1]), Color(randomSkinTone[2])]
