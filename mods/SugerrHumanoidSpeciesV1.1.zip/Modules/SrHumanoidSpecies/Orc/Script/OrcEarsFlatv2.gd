extends BodypartEars

func _init():
	visibleName = "orc ears flat v.2"
	id = "sugerrorcearsflatv2"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrHumanoidSpecies/Orc/PNG/OrcEarsFlatv2/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Humanoid Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
