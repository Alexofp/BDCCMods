extends BodypartHead

func _init():
	visibleName = "orc head 3"
	id = "sugerrorchead3"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrHumanoidSpecies/Orc/PNG/OrcHead3/OrcHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Humanoid Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
