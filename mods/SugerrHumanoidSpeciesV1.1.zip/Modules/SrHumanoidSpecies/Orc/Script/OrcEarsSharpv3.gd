extends BodypartEars

func _init():
	visibleName = "orc ears sharp v.3"
	id = "sugerrorcearsv3"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrHumanoidSpecies/Orc/PNG/OrcEarsSharpv3/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Humanoid Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
