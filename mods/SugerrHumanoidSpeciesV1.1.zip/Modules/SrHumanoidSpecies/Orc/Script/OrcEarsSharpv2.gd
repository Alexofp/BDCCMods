extends BodypartEars

func _init():
	visibleName = "orc ears sharp v.2"
	id = "sugerrorcearsv2"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrHumanoidSpecies/Orc/PNG/OrcEarsSharpv2/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Humanoid Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
