extends BodypartEars

func _init():
	visibleName = "orc ears flat v.1"
	id = "sugerrorcearsflatv1"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrHumanoidSpecies/Orc/PNG/OrcEarsFlatv1/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Humanoid Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
