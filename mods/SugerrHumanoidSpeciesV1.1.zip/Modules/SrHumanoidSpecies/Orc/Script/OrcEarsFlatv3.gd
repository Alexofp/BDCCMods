extends BodypartEars

func _init():
	visibleName = "orc ears flat v.3"
	id = "sugerrorcearsflatv3"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrHumanoidSpecies/Orc/PNG/OrcEarsFlatv3/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Humanoid Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
