extends Module

func _init():
	id = "sugerrhumanoidspecies"
	author = "Sugerør"
	
	species = [
		"res://Modules/SrHumanoidSpecies/Orc/Orc.gd",
	]
	bodyparts = [
		#Orc
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcHead1.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcHead2.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcHead3.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcEarsSharpv1.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcEarsSharpv2.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcEarsSharpv3.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcEarsFlatv1.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcEarsFlatv2.gd",
		"res://Modules/SrHumanoidSpecies/Orc/Script/OrcEarsFlatv3.gd",
	]

