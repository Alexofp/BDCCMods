extends Module

#var FoxLibLoad = ResourceLoader.exists("res://Modules/FoxLib/Module.gd")
var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")

#var ConfigScaleyDragon = true
#var ConfigFluffyCanine = true
#var ConfigFluffyEquine = true
#var ConfigFluffyFeline = true
#var ConfigScruffyCanine = false
#var ConfigScruffyEquine = false
#var ConfigScruffyFeline = false

func _init():
	id = "WintersFluffyBodyparts"
	author = "Avery Winters"

	bodyparts = [
		#Fluffy Bodyparts
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyArms.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyArmsClawed.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBody.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBreasts.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyMaleBreasts.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyDigiLegs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyDigiLegsClawed.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofsSmall.gd",
		#Buff Fluffy Bodyparts
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyArms.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyArmsClawed.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyBody.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyDigiLegs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyDigiLegsClawed.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyHoofs.gd",
		"res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffySmallHoofs.gd",
		#Scaled Bodyparts
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledArms.gd",
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledArmsClawless.gd",
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBody.gd",
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBreasts.gd",
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBreastsMale.gd",
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledDigiLegs.gd",
		"res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledDigiLegsClawless.gd",
		#Scruffy Bodyparts
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyArms.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyArmsClawed.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyBody.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyBodyNeckFluff.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigiLegs.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigiLegsClawed.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigiLegsFluffy.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyHoofs.gd",
		"res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyHoofsSmall.gd",
		#Buff Scaled Bodyparts
		
	]

	if (RAT_ArchetypeLoad == false):
		species = [
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/DragonScaley.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/CanineFluffy.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/EquineFluffy.gd",
			"res://Modules/WintersFluffyBodyparts/CompatibilityPatches/BDCC/FelineFluffy.gd",
		]

func getAddedRatArchetypes() -> Dictionary:
	var pathDir = "res://Modules/WintersFluffyBodyparts/CompatibilityPatches/RAT_BodypartArchetypes/"
	
	return {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)
	#Base Species Archetypes
	"canine": [pathDir+"ClawedArchetypes.json"],
	"feline": [pathDir+"ClawedArchetypes.json"],
	"equine": [pathDir+"HoofedArchetypes.json"],
	"dragon": [pathDir+"ScaledArchetypes.json"],
	#Modded Species Archetypes
	"rabbit": [pathDir+"ClawlessArchetypes.json"],
	}
