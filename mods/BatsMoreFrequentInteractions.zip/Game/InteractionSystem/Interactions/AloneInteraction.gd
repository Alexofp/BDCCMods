extends PawnInteractionBase

var goal:InteractionGoalBase
var nextGoalTestIn:int = 200

func saveData():
	var data = .saveData()

	data["ngti"] = nextGoalTestIn
	if(goal != null):
		data["goal"] = {
			id = goal.id,
			data = goal.saveData(),
		}
	else:
		data["goal"] = {
			id = "",
		}
	return data

func loadData(_data):
	.loadData(_data)

	nextGoalTestIn = SAVE.loadVar(_data, "ngti", 200)
	goal = null
	var goalData = SAVE.loadVar(_data, "goal", {})
	var goalID = SAVE.loadVar(goalData, "id", "")
	if(goalID != ""):
		var newGoal:InteractionGoalBase = InteractionGoal.create(goalID)
		if(newGoal != null):
			newGoal.pawnID = getRoleID("main")
			newGoal.interaction = self
			goal = newGoal
			goal.loadData(SAVE.loadVar(goalData, "data", {}))

func _init():
	id = "AloneInteraction"

func processTime(_howMuch:int):
	nextGoalTestIn -= _howMuch
	if(nextGoalTestIn <= 0):
		nextGoalTestIn = 300
		calculateBestGoal()

func getGoalsWithScores(aboveKeepScore:bool = true) -> Array:
	var goals = InteractionGoal.getAllAlone()
	var pawn = getRolePawn("main")
	
	var keepScore:float = 0.0
	if(goal != null && aboveKeepScore):
		keepScore = goal.getKeepScore()
		keepScore = pawn.getProcessedGoalScore(goal.id, keepScore, true)
	
	#GM.PROFILE.start("ALONE GOALS")
	var possibleNew := []
	for goalID in goals:
		if(goal != null && goalID == goal.id):
			continue
		var newGoalRef:InteractionGoalBase = InteractionGoal.getRef(goalID)
		
		var newScore = newGoalRef.getScore(pawn)
		newScore = pawn.getProcessedGoalScore(goalID, newScore, false)
		if(newScore > keepScore || goal == null):
			possibleNew.append([goalID, newScore])
	#GM.PROFILE.finish("ALONE GOALS")
	
	#GM.PROFILE.start("GLOBAL TASKS")
	for globalTaskID in GM.main.IS.getGlobalTasks():
		#GM.PROFILE.start(globalTaskID)
		var globalTask:GlobalTask = GM.main.IS.getGlobalTask(globalTaskID)
		
		if(!globalTask.canDoTaskFinal(pawn)):
			#GM.PROFILE.finish(globalTaskID)
			continue
		
		var goalID = globalTask.getGoalID(pawn)
		var newgoal = InteractionGoal.create(goalID)
		if(newgoal == null):
			#GM.PROFILE.finish(globalTaskID)
			continue
		
		globalTask.configureGoalFinal(pawn, newgoal)
		var newScore = newgoal.getScore(pawn)
		newScore = pawn.getProcessedGoalScore(goalID, newScore, false)
		if(newScore > keepScore || newgoal == null):
			possibleNew.append([newgoal, newScore])
		#GM.PROFILE.finish(globalTaskID)
	#GM.PROFILE.finish("GLOBAL TASKS")
	
	return possibleNew

func calculateBestGoal():
	var possibleNew := getGoalsWithScores()

	if(possibleNew.size() <= 0):
		return
	
	var newGoalID = RNG.pickWeightedPairs(possibleNew)
	if(newGoalID is String):
		switchGoalTo(newGoalID)
	else:
		switchGoalToObject(newGoalID)

func getGoal() -> InteractionGoalBase:
	if(goal == null):
		calculateBestGoal()
	return goal

func completeGoal():
	if(goal == null):
		calculateBestGoal()
		return
	goal = null
	calculateBestGoal()

func switchGoalTo(goalID:String):
	if(goalID == ""):
		goal = null
		return true
	var newGoal:InteractionGoalBase = InteractionGoal.create(goalID)
	return switchGoalToObject(newGoal)
	
func switchGoalToObject(newGoal:InteractionGoalBase):
	if(newGoal == null):
		return false
	var thePawn := getRolePawn("main")
	if(goal):
		if(!goal.globalTask.empty()):
			var theGlobalTask:GlobalTask = GM.main.IS.getGlobalTask(goal.globalTask)
			if(theGlobalTask):
				theGlobalTask.onPawnStoppedDoingTask(thePawn)
	
	newGoal.pawnID = thePawn.charID
	newGoal.interaction = self
	goal = newGoal
	goal.onGoalStart()
	
	if(!goal.globalTask.empty()):
		var theGlobalTask:GlobalTask = GM.main.IS.getGlobalTask(goal.globalTask)
		if(theGlobalTask):
			theGlobalTask.onPawnStartedDoingTask(thePawn)
	#print("NEW GOAL FOR PAWN "+str(newGoal.pawnID)+": "+str(newGoal.id))
	return true

func onStopped():
	var thePawn := getRolePawn("main")
	if(goal):
		if(!goal.globalTask.empty()):
			var theGlobalTask:GlobalTask = GM.main.IS.getGlobalTask(goal.globalTask)
			if(theGlobalTask):
				theGlobalTask.onPawnStoppedDoingTask(thePawn)

func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("main", _pawns["main"])
	setCurrentRole("main")
	setLocation(getRolePawn("main").getLocation())

func getOutputText() -> String:
	var theGoal = getGoal()
	if(theGoal != null):
		return theGoal.getText()
	return "Something something"

func getActions() -> Array:
	var theGoal = getGoal()
	if(theGoal != null):
		return theGoal.getActions()
	return []

# bat
# we can't override this in PawnInteractionBase but we can override it here
# it's not an ideal solution and will interact weirdly with other mods but that's not my problem
func getScoreTypeValueGenericInternal(_scoreType:String, curPawn:CharacterPawn, dirToPawn:CharacterPawn):
	if(curPawn == null || dirToPawn == null):
		return 1.0
	#var curID:String = curPawn.charID
	#var dirToID:String = dirToPawn.charID
	
	if(_scoreType == "approach"):
		
		var social:float = curPawn.getSocialClamped()
		var anger:float = curPawn.getAngerClamped()
		
		var targetIsPlayer:bool = dirToPawn.isPlayer()
		var targetSocial:float = dirToPawn.getSocialClamped()
		
		var exposure:float = dirToPawn.scoreExposed()
		var canGrabAndFuck:bool = dirToPawn.canGrabAndFuck()
		var ourCanGrabAndFuck:bool = curPawn.canGrabAndFuck()
		
		if(ourCanGrabAndFuck):
			return 0.0
		
		if(canGrabAndFuck):
			return 3.0 * getScoreTypeValueGeneric("sexUse", curPawn, dirToPawn) * (1.0 + exposure) * (1.0 if max(social, anger) > 0.2 else 0.0)
		
		# i know that socialScore/lustScore are entirely redundant right now
		# i intend to fix that but not right now
		var socialScore:float = 0.0
		var angerScore:float = 0.0
		var lustScore:float = 0.0
		
		if(social > 0.2):
			lustScore += social * 0.2
			socialScore += social * 0.2
		
		if(anger > 0.2):
			angerScore += anger * 0.2
		
		lustScore *= (1.0 + exposure)
		
		var calcScore:float = [socialScore, angerScore, lustScore, 0.0].max()
		
		# inflate the score for player characters
		if(targetIsPlayer && calcScore > 0):
			calcScore += targetSocial * 0.2
			calcScore *= 1.5
		
		return calcScore
	
	# otherwise get default
	return .getScoreTypeValueGenericInternal(_scoreType, curPawn, dirToPawn)

func doAction(_id:String, _args:Dictionary, _context:Dictionary):
	var theGoal = getGoal()
	if(theGoal != null):
		return theGoal.doAction(_id, _args)

#	var pawn = getRolePawn("main")
#
#	if(pawn.getHunger() <= 0.2):
#		if(getLocation() == "hall_canteen"):
#			pawn.hunger = 1.0
#		else:
#			goTowards("hall_canteen")
#		return
#
#	if(!doWanderGurantee()):
#		return {time = 0}
#	return {time = 60}

func doesStealControlFromPC() -> bool:
	return false

func getDebugInfo():
	var res:Array = .getDebugInfo()
	
	if(goal != null):
		res.append("")
		res.append("Current goal: "+str(goal.id))
		res.append("Goal keep score: "+str(Util.roundF(getRolePawn("main").getProcessedGoalScore(goal.id, goal.getKeepScore(), true), 2)))
		res.append("")
	
	res.append("All goal weights:")
	var goalEntries = getGoalsWithScores(false)
	for goalEntry in goalEntries:
		var goalID = goalEntry[0]
		if(!(goalID is String)):
			goalID = goalID.id
		
		var thegoal = goalEntry[0]
		if(thegoal is String):
			thegoal = InteractionGoal.getRef(goalID)
		
		if(goal != null && goalID == goal.id):
			continue
		
		var newScore = goalEntry[1]
		res.append((thegoal.globalTask+":" if thegoal.globalTask != "" else "")+goalID+" score: "+str(Util.roundF(newScore, 2)))
	
	return res

func getAnimData() -> Array:
	if(goal == null):
		return []
	return goal.getAnimData()

func isDoingTask(_taskID:String) -> bool:
	if(goal == null):
		return false
	return (goal.globalTask == _taskID)

func getInterruptActions(_pawn:CharacterPawn) -> Array:
	var mainIsPlayer:bool = getRolePawn("main").isPlayer()
	if(mainIsPlayer && !getRolePawn("main").canBeInterrupted()): # Fixes the problem where talking interactions were getting queued up while you were walking a leashed slave around
		return []
	if(mainIsPlayer && _pawn.getSpecialRelationship() && !_pawn.getSpecialRelationship().canTalkWithPlayer()):
		return []
	
	var result:Array = []
	
	
	if(!mainIsPlayer && goal && goal.id == InteractionGoal.LayEggs):
		result.append({
			id = "helpEggs",
			name = "Help lay eggs",
			desc = "Help them lay their eggs!",
			score = 0.0,
			scoreType = "approach",
			scoreRole = "main",
			args = {},
		})
		return result
	
	result.append({
		id = "talk",
		name = "Talk",
		desc = "Talk with them",
		score = 1.0,
		scoreType = "approach",
		scoreRole = "main",
		args = {},
	})
	if(getRolePawn("main").canGrabAndFuck() && _pawn.getChar().canStartSex()):
		result.append({
			id = "grab_and_fuck",
			name = "Grab&Fuck",
			desc = "They have so many restraints that you can just fuck them..",
			score = 1.0,
			scoreType = "sexUse",
			scoreRole = "main",
			args = {},
		})
	return result

func doInterruptAction(_pawn:CharacterPawn, _id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "talk"):
		if(_pawn.isPlayer()):
			if(triggerTalkReactEvents("main")):
				return
				
		startInteraction("Talking", {starter=_pawn.charID, reacter=getRoleID("main")})
		#startInteraction("Talking", {reacter=_pawn.charID, starter=getRoleID("main")})
	if(_id == "grab_and_fuck"):
		startInteraction("Talking", {starter=_pawn.charID, reacter=getRoleID("main")}, {grab_and_fuck=true})
	if(_id == "helpEggs"):
		startInteraction("HelpLayEggs", {main=_pawn.charID, target=getRoleID("main")})
	
func canRoleBeInterrupted(_role:String) -> bool:
	return true
	
func canCharIDBeInterrupted(_charID:String) -> bool:
	return true

func getPreviewLineForRole(_role:String) -> String:
	if(_role == "main"):
		if(goal != null):
			return goal.getText().split("\n")[0]
		else:
			return "{main.name} is deciding what to do next.."
	return .getPreviewLineForRole(_role)

func getActivityIconForRole(_role:String):
	if(isPlayerInvolved()):
		return RoomStuff.PawnActivity.None
	if(goal == null):
		return .getActivityIconForRole(_role)
	
	return goal.getActivityIcon()
