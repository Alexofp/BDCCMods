extends "res://Species/Human.gd"

var maleBoobs = [] 
var femaleBoobs = []

func _init():
	id = Species.Human
	var hasBoob = ("WintersBreastExpansion" in GlobalRegistry.getModules())

	if hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_gender):
	return "plantilegs"

func getDefaultEars(_gender):
	return "humanears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs
	return femaleBoobs
