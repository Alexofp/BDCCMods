extends "res://Species/Canine.gd"

var maleBoobs = [] 
var femaleBoobs = []

func _init():
	var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())
	var hasBoob = ("WintersBreastExpansion" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & BreastsExpanded
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "caninetail"

func getDefaultHead(_gender):
	return "caninehead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "canineears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs
	return femaleBoobs

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersExpandedPenises" in GlobalRegistry.getModules()):
			return "knottedfluffypenis"
		else:
			return "caninepenis"
	else:
		return null
