extends "res://Species/Demon.gd"

var maleBoobs = [] 
var femaleBoobs = []

func _init():
	id = Species.Demon
	var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())
	var hasBoob = ("WintersBreastExpansion" in GlobalRegistry.getModules())
	var hasBeast = ("WintersHellBeastsSpecies" in GlobalRegistry.getModules())

	if hasFluff && hasBoob && hasBeast: #FluffyBodyparts & BreastsExpanded & HellbeastSpecies
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff && hasBeast: #FluffyBodyparts & HellbeastSpecies
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_gender):
	return "hoofs"

func getDefaultTail(_gender):
	return "demontail"

func getDefaultHorns(_gender):
	return "demonhorns"

func getDefaultHead(_gender):
	return "humanhead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "humanears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs
	return femaleBoobs

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "equinepenis"
	else:
		return null

func npcGenerationWeight():
	return 0.0
