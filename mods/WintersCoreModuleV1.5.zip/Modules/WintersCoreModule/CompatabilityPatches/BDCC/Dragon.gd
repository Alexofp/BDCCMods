extends "res://Species/Dragon.gd"

var maleBoobs = [] 
var femaleBoobs = []

func _init():
	id = Species.Dragon
	var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())
	var hasBoob = ("WintersBreastExpansion" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & BreastsExpanded
		maleBoobs = ["scaledmalebreastsnipple", "scaledmalebreastsnippleinv", "scaledmalebreastspuffy", "scaledmalebreastspuffyinv"]
		femaleBoobs = ["scaledbreastsnipple", "scaledbreastsnippleinv", "scaledbreastspuffy", "scaledbreastspuffyinv"]
	elif hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "dragontail"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultHorns(_gender):
	return "dragonhorns"

func getDefaultHead(_gender):
	return "dragonhead"

func getDefaultEars(_gender):
	return "dragonears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs
	return femaleBoobs

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "dragonpenis"
	else:
		return null
