extends Control

onready var animPlayer = $AnimationPlayer



func _on_AnimationPlayer_animation_finished(anim_name):
	if(anim_name == "SlowFade"):
		self.queue_free()
