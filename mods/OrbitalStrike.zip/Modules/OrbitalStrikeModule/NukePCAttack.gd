extends Attack

var flashbang = load("res://Modules/OrbitalStrikeModule/nuke.tscn")

func _init():
	id = "NukePCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isPlayerAttack = true
	attackPriority = 30

func canScratch(_pc) -> bool:
	if(_pc.hasPerk(Perk.CombatScratching) && !_pc.hasBlockedHands()):
		return true
	return false

func getVisibleName(_context = {}):
	return "Orbital Strike"
	
func getVisibleDesc(_context = {}):
	return "I want that twink obliterated."
	
func gottem(animPlayer):
	animPlayer.play("Fade")
	yield(animPlayer, "animation_finished")
	animPlayer.play("SlowFade")
	yield(animPlayer, "animation_finished")	
	
func _doAttack(_attacker, _receiver, _context = {}):
	connect("attack_over", self, "_on_attack_over")
	var replace = StreamTexture.new()
	replace.load_path = "res://.import/explodedplatform.png-81e584da98c89a9ca2c63e2deefa9db3.stex"
	var screen = GM.ui
	var thing = flashbang.instance()
	screen.add_child(thing)
	var animPlayer = thing.animPlayer
	var scene3d = GM.ui.getStage3d().currentScene
	if(scene3d.id == StageScene.Duo):
		var sprite = scene3d.get_node("Sprite3D")
		sprite.texture = replace
		scene3d.doll2.doll_skeleton.visible = false
		scene3d.doll2.bone_attachments.visible = false
		scene3d.doll2.doll_attachment_zones.visible = false
	gottem(animPlayer)
	var _scene = GM.main.getCurrentFightScene()
#	_scene.doDebugAction("instantWin")

	var texts = [
		"{attacker.name} calls for an orbital strike and completely obliterates {receiver.name}.",
	]
	var text = RNG.pick(texts)

	return {
		text = text,
		pain = 10000,
#		"receiverAnimation":{"npcBodyState":{"hide":true}}
	}
	
	
func getAttackHitReactAnimation(_attacker, _receiver, _result):
	return ""
	
func _canUse(_attacker, _receiver, _context = {}):
	return true

func getRequirements():
	return []

func getAttackSoloAnimation():
	return "block"

func getExperience():
	return [[Skill.Combat, 0]]

func getAnticipationText(_attacker, _receiver):
	return "{attacker.name} is about to punch {receiver.name}!"

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 30.0
