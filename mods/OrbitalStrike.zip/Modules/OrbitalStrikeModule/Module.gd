extends Module


func _init():
	id = "OrbitalStrike"
	author = "bringulbangul"
	scenes = []
	events = []
	gameExtenders = []
	attacks = [
		"res://Modules/OrbitalStrikeModule/NukePCAttack.gd"
	]
	
	
	
func getFlags():
	return {}


func preInit(): # Called before anything gets registered
	pass

