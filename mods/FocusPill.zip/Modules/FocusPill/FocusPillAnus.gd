extends "res://Modules/FocusPill/FocusPillVagina.gd"

func _init():
	id 			 = "FocusPillAnus"
	bodypartSlot = BodypartSlot.Anus
	slotName 	 = "Anus"

func getPrice():
	return 2

func getSexEngineInfo(_sexEngine, _domInfo, _subInfo):
	return {
		"name": 		 "Focus Pill Anus",
		"usedName": 	 "a Anus focus pill",
		"desc": 		 "Make Anus only sensitive part.",
		"scoreOnSub":    0.0,
		"scoreOnSelf":   0.0,
		"scoreSubScore": _subInfo.fetishScore({Fetish.DrugUse: 1.0}),
		"canUseOnDom":   true,
		"canUseOnSub":   true,
		"maxUsesByNPC":  1,
	}