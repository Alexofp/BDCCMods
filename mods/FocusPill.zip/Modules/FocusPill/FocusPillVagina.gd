extends ItemBase

var bodypartSlot: String
var slotName:     String

func _init():
	id  		 = "FocusPillVagina"
	bodypartSlot = BodypartSlot.Vagina
	slotName	 = "Pussy"

func getVisibleName():
	return "Focus Pill - "+ slotName
	
func getDescription():
	return "Shifting sensitivity to " + slotName + " from other body parts"

func canUseInCombat():
	return true

func consume(_receiver: BaseCharacter) -> String:
	#var sensitiveZones:Array = _receiver.getSensitiveZones()
	if !_receiver.hasBodypart(bodypartSlot):
		return "It seems like nothing happened."
	_receiver.addEffect("SensitivityFocus", [4*60*60, bodypartSlot])
	# for zone in sensitiveZones:
	# 	if zone.getName() != slotName:
	# 		zone.addSensitivity(-1 * zone.getRawSensitivity())
	# 	else:
	# 		zone.addSensitivity(1 - clamp(zone.getRawSensitivity(),0,1) + 0.4)
	return _receiver.getName()+"'s "+ slotName + " feels more sensual now."

func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	return consume(_attacker)

func getPossibleActions():
	return [
		{
			"name": 	   "Consume",
			"scene": 	   "UseItemLikeInCombatScene",
			"description": "Take the pill",
		},
	]

func getPrice():
	return 5

func canSell():
	return true

func canCombine():
	return true

func addsIntoxication():
	return 0.0

func getTimedBuffs():
	return []	
	# return [
	# 	buff(Buff.SensitivityGainBuff,    [BodypartSlot.Vagina,60]),
	# 	buff(Buff.SensitivityGainBuff,    [BodypartSlot.Penis,-500]),
	# 	buff(Buff.SensitivityRestoreBuff, [BodypartSlot.Penis,-500]),
	# 	buff(Buff.SensitivityGainBuff,    [BodypartSlot.Breasts,-500]),
	# 	buff(Buff.SensitivityRestoreBuff, [BodypartSlot.Breasts,-500]),
	# 	buff(Buff.SensitivityGainBuff,    [BodypartSlot.Anus,-500]),
	# 	buff(Buff.SensitivityRestoreBuff, [BodypartSlot.Anus,-500]),
	# ]

func getBuffsDurationSeconds():
	return[] #60*60*3

func getTimedBuffsTurns():
	return []

func getBuffsDurationTurns():
	return 0

func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SexEngineDrug,
		]

func getBuyAmount():
	return 1

func getSexEngineInfo(_sexEngine, _domInfo, _subInfo):
	return {
		"name": 		 "Focus Pill Vagina",
		"usedName": 	 "a Vagina focus pill",
		"desc": 		 "Make Vagina only sensitive part.",
		"scoreOnSub":    0.0,
		"scoreOnSelf":   0.0,
		"scoreSubScore": _subInfo.fetishScore({Fetish.DrugUse: 1.0}),
		"canUseOnDom":   true,
		"canUseOnSub":   true,
		"maxUsesByNPC":  1,
	}

func useInSex(_receiver):
	#_receiver.addTimedBuffs(getTimedBuffs(), getBuffsDurationSeconds())
	consume(_receiver)

func getItemCategory():
	return ItemCategory.Medical
