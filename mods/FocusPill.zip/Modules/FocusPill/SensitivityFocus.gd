extends StatusEffectBase
#todo check if loosing body part wile affected cause bugs
#var effectTimer = 60*60*3
var pussyFocus  = false
var analFocus   = false
var penisFocus  = false
var breastFocus = false
var activeZonesCount

func _init():
	id = "SensitivityFocus"
	removedOnDungeonStart = true
	priorityDuringChecking = 67

func initArgs(_args = []): 
	if(_args[0] > 0):
		turns = _args[0]
	else:
		turns = 3*60*60
	addBodyPartAffected(_args[1])
	

func combine(_args = []): #too garbaged for this use case but will work
	if(_args.size() > 0):
		turns = max(_args[0],turns)
	else:
		turns = max(3*60*60,turns)
	addBodyPartAffected(_args[1])

func addBodyPartAffected(arg):
	if(arg == BodypartSlot.Vagina && character.hasBodypart(BodypartSlot.Vagina)): #why no switch, why "match" only in 4.0  
			pussyFocus = true
			character.getBodypart(BodypartSlot.Vagina).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Vagina).sensitiveZone.getRawSensitivity(),0,1) + 0.4) #make it shorter ???
	if(arg == BodypartSlot.Penis && character.hasBodypart(BodypartSlot.Penis)):
			penisFocus = true
			character.getBodypart(BodypartSlot.Penis).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Penis).sensitiveZone.getRawSensitivity(),0,1) + 0.4)
	if(arg == BodypartSlot.Anus && character.hasBodypart(BodypartSlot.Anus)):
			analFocus = true
			character.getBodypart(BodypartSlot.Anus).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Anus).sensitiveZone.getRawSensitivity(),0,1) + 0.4)
	if(arg == BodypartSlot.Breasts && character.hasBodypart(BodypartSlot.Breasts)):
			breastFocus = true
			character.getBodypart(BodypartSlot.Breasts).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Breasts).sensitiveZone.getRawSensitivity(),0,1) + 0.4)

	activeZonesCount = int(pussyFocus) + int(analFocus) + int(penisFocus) + int(breastFocus)
	if (activeZonesCount >= character.getSensitiveZones().size()): #no reason for if all body parts affected
		stop()

func processTime(_secondsPassed: int):
	if(!pussyFocus && character.hasBodypart(BodypartSlot.Vagina)):
		character.getBodypart(BodypartSlot.Vagina).sensitiveZone.addSensitivity(-0.1) #mayby just -1 it still wil be capped at .1 or make it -.1  to show gradual work|-1 * character.getBodypart(BodypartSlot.Vagina).sensitiveZone.getRawSensitivity()
	if(!penisFocus && character.hasBodypart(BodypartSlot.Penis)):
		character.getBodypart(BodypartSlot.Penis).sensitiveZone.addSensitivity(-0.1)
	if(!analFocus && character.hasBodypart(BodypartSlot.Anus)):
		character.getBodypart(BodypartSlot.Anus).sensitiveZone.addSensitivity(-0.1)
	if(!breastFocus && character.hasBodypart(BodypartSlot.Breasts)):
		character.getBodypart(BodypartSlot.Breasts).sensitiveZone.addSensitivity(-0.1)
	
	turns -= _secondsPassed
	if (turns <= 0):
		#reset sens
		if(!pussyFocus && character.hasBodypart(BodypartSlot.Vagina)):
			character.getBodypart(BodypartSlot.Vagina).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Vagina).sensitiveZone.getRawSensitivity(),0,1))
		if(!analFocus && character.hasBodypart(BodypartSlot.Anus)):
			character.getBodypart(BodypartSlot.Anus).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Anus).sensitiveZone.getRawSensitivity(),0,1))
		if(!penisFocus && character.hasBodypart(BodypartSlot.Penis)):
			character.getBodypart(BodypartSlot.Penis).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Penis).sensitiveZone.getRawSensitivity(),0,1))
		if(!breastFocus && character.hasBodypart(BodypartSlot.Breasts)):
			character.getBodypart(BodypartSlot.Breasts).sensitiveZone.addSensitivity(1 - clamp(character.getBodypart(BodypartSlot.Breasts).sensitiveZone.getRawSensitivity(),0,1))
		stop()

func getEffectName():
	return "Sensitivity Focus%s" %(" x"+str(activeZonesCount) if activeZonesCount > 1 else "")#todo change

func getEffectDesc():
	return "Shift sensitivity for "+Util.getTimeStringHumanReadable(turns)

func getEffectImage():
	return "res://Images/StatusEffects/nested-hearts.png"

func getIconColor():
	return IconColorBrightPurple

func saveData():
	return {
		"turns":       turns,
		"pussyFocus":  pussyFocus,
		"analFocus":   analFocus,
		"penisFocus":  penisFocus, 
		"breastFocus": breastFocus
	}
	
func loadData(_data):
	turns       = SAVE.loadVar(_data, "turns", 60*60)
	pussyFocus  = SAVE.loadVar(_data, "pussyFocus", false)
	analFocus   = SAVE.loadVar(_data, "analFocus", false)
	penisFocus  = SAVE.loadVar(_data, "penisFocus", false)
	breastFocus = SAVE.loadVar(_data, "breastFocus", false)
	activeZonesCount = int(pussyFocus) + int(analFocus) + int(penisFocus) + int(breastFocus)
	
