extends "res://Modules/FocusPill/FocusPillVagina.gd"

func _init():
	id 			 = "FocusPillPenis"
	bodypartSlot = BodypartSlot.Penis
	slotName 	 = "Penis"

func getPrice():
	return 2

func getSexEngineInfo(_sexEngine, _domInfo, _subInfo):
	return {
		"name": 		 "Focus Pill Penis",
		"usedName": 	 "a Penis focus pill",
		"desc": 		 "Make Penis only sensitive part.",
		"scoreOnSub":    0.0,
		"scoreOnSelf":   0.0,
		"scoreSubScore": _subInfo.fetishScore({Fetish.DrugUse: 1.0}),
		"canUseOnDom":   true,
		"canUseOnSub":   true,
		"maxUsesByNPC":  1,
	}
