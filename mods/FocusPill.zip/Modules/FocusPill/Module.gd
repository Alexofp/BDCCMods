extends Module

func _init():
	id = "FocusPill"
	author = "Broslan"
	
	items = [
		"res://Modules/FocusPill/FocusPillVagina.gd",
        "res://Modules/FocusPill/FocusPillPenis.gd",
        "res://Modules/FocusPill/FocusPillAnus.gd",
        "res://Modules/FocusPill/FocusPillBreasts.gd",
        "res://Modules/FocusPill/SensitivityReset.gd",
	]
	statusEffects = [
		"res://Modules/FocusPill/SensitivityFocus.gd"
	]