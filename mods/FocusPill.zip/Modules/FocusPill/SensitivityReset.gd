extends ItemBase

func _init():
	id = "SensitivityReset"

func getVisibleName():
	return "Sensitivity Reset"
	
func getDescription():
	return "Return body sensitivity to normal levels"

func canUseInCombat():
	return true

func consume(_receiver: BaseCharacter) -> String:
	var sensitiveZones:Array = _receiver.getSensitiveZones()
	for zone in sensitiveZones:
			zone.addSensitivity(1 - zone.getRawSensitivity()) #redo
	return _receiver.getName()+"'s sensitivity returns to normal"

func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	return consume(_attacker)

func getPossibleActions():
	return [
		{
			"name": 	   "Consume",
			"scene": 	   "UseItemLikeInCombatScene",
			"description": "Take the pill",
		},
	]

func getPrice():
	return 2

func canSell():
	return true

func canCombine():
	return true

func addsIntoxication():
	return 0.0

func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SexEngineDrug,
		]

func getBuyAmount():
	return 1

func getSexEngineInfo(_sexEngine, _domInfo, _subInfo):
	return {
		"name": 		 "Sensitivity Reset",
		"usedName": 	 "a Sensitivity Reset",
		"desc": 		 "Restore Sensitivity of all body parts.",
		"scoreOnSub":    0.0,
		"scoreOnSelf":   0.0,
		"scoreSubScore": _subInfo.fetishScore({Fetish.DrugUse: 1.0}),
		"canUseOnDom":   true,
		"canUseOnSub":   true,
		"maxUsesByNPC":  1,
	}

func useInSex(_receiver):
	#_receiver.addTimedBuffs(getTimedBuffs(), getBuffsDurationSeconds())
	consume(_receiver)

func getItemCategory():
	return ItemCategory.Medical
