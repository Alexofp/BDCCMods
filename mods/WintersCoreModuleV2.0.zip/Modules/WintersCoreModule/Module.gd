extends Module

var defaultArchetypeWeight : float = 10.0

func _init():
	id = "WintersCoreModule"
	author = "Avery Winters & Selinoccino"

func register():

	var mod = GlobalRegistry.getModules().get("RodentUtils")
	if !mod:
		Log.printerr("%s: Can't load mod because of missing dependency RodentUtils" % id)
		GlobalRegistry.getModules().erase(self.id)
		return
	
	if mod.SlopWatch.flagged:
		Log.warning("%s: Disabling self due to Author not supporting AI Coded mod" % id)
		mod.SlopWatch.pleaseRemoveMe(self)
		return
	
	GlobalRegistry.registerBodypartSlot("res://Modules/WintersCoreModule/CustomBodypartSlots/CustomBodypartSlot_BodyOverlay.gd")
	GlobalRegistry.registerBodypartSlot("res://Modules/WintersCoreModule/CustomBodypartSlots/CustomBodypartSlot_Wings.gd")

func createCodegen() -> Reference:
	return load("res://Modules/WintersCoreModule/codegen.gd").new()

func createCodegenSimple() -> Reference:
	return load("res://Modules/WintersCoreModule/codegenSimple.gd").new()

func purifyArray(array, all=null):
	var type : int = typeof(array)
	if type == TYPE_DICTIONARY:
		for val in array:
			array[val] = purifyArray(array[val], all)
		return array
	
	if type == TYPE_ARRAY:
		var new : Array = []
		for bp in array:
			if typeof(bp)!=TYPE_STRING:
				new.append(purifyArray(bp, all))
			else:
				var actualall = all if all!=null else GlobalRegistry.getBodypartRefs().keys()
				if bp.begins_with("defaults::") or bp in actualall:
					new.append(bp)
				else:
					Log.warning("%s: %s is invalid" % [id, bp])
		return new
	

func kemonomimify(npc, _args) -> void:
	if Species.Human in npc.getSpecies():
		return
	
	npc.npcSpecies.insert(0, Species.Human)
	var Human : Species = GlobalRegistry.getSpecies(Species.Human)
	
	var colors = Human.generateSkinColors()
	
	var newskinID = TFUtil.getRandomSkinForSpecies([Species.Human])
	var finalBodypartData : Dictionary = {}
	
	var entry : Dictionary = {
		"skin": newskinID,
		"r": colors[0],
		"g": colors[1],
		"b": colors[2],
	}
	var bs := BodypartSlot
	for slot in [bs.Head, bs.Arms, bs.Legs, bs.Breasts]:
		finalBodypartData[slot] = entry
		
		var bpID = Human.getDefaultForSlotForNpcGender(slot, npc.getGender())
		if !bpID:
			continue
		
		var bp = GlobalRegistry.createBodypart(bpID)
		
		if !npc.hasBodypart(slot):
			bp.generateDataFor(npc)
			npc.giveBodypart(bp)
			continue
		
		var old = npc.getBodypart(slot).saveData()
		npc.removeBodypart(slot)
		npc.giveBodypart(bp)
		bp.loadData(old)
	
	npc.applyBodypartsSkinData(finalBodypartData)

func applySimple(d:Dictionary, _npc, _args) -> void:
	applyNormalArray(d.get("normal", []), _npc, _args)
	applyStrictArray(d.get("strict", []), _npc, _args)
	if d.has("display"):
		_npc.npcCustomSpeciesName = d["display"].replace("{DEF}", _npc.getSpeciesFullName())

func getFinalBodypartID(bodypart:String, _npcGender) -> String:
	if bodypart.begins_with("defaults::"):
		var parts := bodypart.split("::", false, 3)
		if parts.size()<3:
			return ""
		
		var species = GlobalRegistry.getAllSpecies().get(parts[1], null)
		if !species:
			return ""
		
		return species.getDefaultForSlotForNpcGender(parts[2], _npcGender)
	
	return bodypart

func applyNormalArray(ar:Array, _npc, _args) -> void:
	for normal in ar:
		if typeof(normal)==TYPE_ARRAY:
			normal = RNG.pick(normal)
		elif typeof(normal) == TYPE_DICTIONARY:
			if normal.has("penis") &&_npc.hasPenis():
				applyNormalArray(normal["penis"], _npc, _args)
			
			if normal.has("vagina") &&_npc.hasVagina():
				applyNormalArray(normal["vagina"], _npc, _args)
			
			var genderkey : String = Gender.genderToString(_npc.getGender())
			if normal.has(genderkey):
				applyNormalArray(normal[genderkey], _npc, _args)
			else:
				applyNormalArray(normal.get("_", []), _npc, _args)
			
			continue
		
		var finalID : String = getFinalBodypartID(normal, _npc.getGender())
		if !finalID:
			return
		
		var bp = GlobalRegistry.createBodypart(finalID)
		if _npc.hasBodypart(bp.getSlot()):
			var old = _npc.getBodypart(bp.getSlot()).saveData()
			
			_npc.removeBodypart(bp.getSlot())
			_npc.giveBodypart(bp)
			bp.loadData(old)

func applyStrictArray(ar:Array, _npc, _args) -> void:
	for strict in ar:
		if typeof(strict)==TYPE_ARRAY:
			strict = RNG.pick(strict)
		elif typeof(strict) == TYPE_DICTIONARY:
			if strict.has("penis") &&_npc.hasPenis():
				applyStrictArray(strict["penis"], _npc, _args)
			
			if strict.has("vagina") &&_npc.hasVagina():
				applyStrictArray(strict["vagina"], _npc, _args)
			
			var genderkey : String = Gender.genderToString(_npc.getGender())
			if strict.has(genderkey):
				applyStrictArray(strict[genderkey], _npc, _args)
			else:
				applyStrictArray(strict.get("_", []), _npc, _args)
			
			continue
		var bp = GlobalRegistry.createBodypart(strict)
		var slot = bp.getSlot()
		if !_npc.hasBodypart(slot):
			bp.generateDataFor(_npc)
			_npc.giveBodypart(bp)
			continue
		
		var old = _npc.getBodypart(slot).saveData()
		_npc.removeBodypart(slot)
		_npc.giveBodypart(bp)
		bp.loadData(old)

func RatArchetify() -> void:
	var p : String = "res://Modules/WintersCoreModule/CompatibilityPatches/RAT_Archetypes/CallableRegisters/"
	GlobalRegistry.getModule("RAT_Archetypes").defaultArchetypeWeight = 0.0
	
	### SPECIES CALLABLES
	var d : Dictionary = {
		Species.Canine: p+"Canine.gd",
		Species.Demon: p+"Demon.gd",
		Species.Dragon: p+"Dragon.gd",
		Species.Equine: p+"Equine.gd",
		Species.Feline: p+"Feline.gd",
		Species.Human: p+"Human.gd",
	}
	
	for id in d:
		var species = GlobalRegistry.getSpecies(id)
		if !species:
			continue
		
		load(d[id]).new().registerToSpecies(species)
	
	var modsToLookFor : Array = [ # modules, you control order; this is arbitrary and we can use code to populate and sort
		self
	]

	var finalTypes : Dictionary = {
		# species : Dict[id:Dict(Type)]
	}
	for mod in modsToLookFor:
		var speciesTypeDict = mod.getAddedRatArchetypes()
		# total should look like {speciesID: {...id:type...} }
		# ^ each should look like:
		#	id: { name: thing, description: thing2,
		#		strict: [...], normal: [...],
		#		where array can have:
		#		dict{penis/vagina/Gender class constant: 			[...] (recursive) }
		#		array (one picked randomly, recursive)
		for speciesID in speciesTypeDict:
			var existing : Dictionary = finalTypes.get_or_add(speciesID, {})
			existing.merge(speciesTypeDict[speciesID], true)
			# ^ result is finalTypes[species] has merged all types for each mod
		
	
	var allbps : Array = GlobalRegistry.getBodypartRefs().keys()
	
	var all : Dictionary = GlobalRegistry.getAllSpecies()
	for speciesID in finalTypes:
		if !all.has(speciesID):
			continue
		
		var species = all[speciesID]
		
		for type in finalTypes[speciesID]:
			var typeDict : Dictionary = finalTypes[speciesID][type]
			
			for key in ["normal", "strict"]:
				if typeDict.has(key):
					typeDict[key] = purifyArray(typeDict[key], allbps)
			
			var callable = species.createCallable(self, "applySimple")\
				.setArgs([typeDict])
			
			var archetype = species.createArchetype(type, callable, typeDict.get("defaultWeight", defaultArchetypeWeight))
			archetype.optionDisplay = typeDict.get("optionDisplay", "Archetype %s" % type)
			archetype.description = typeDict.get("description", "")
			
			species.addArchetype(archetype)
	
	for species in [Species.Canine, Species.Feline, Species.Equine, Species.Dragon, "rabbit", "hellhound", "hellkitty", "hellpony", "seahorse", "shark"]:
		if !all.has(species):
			continue
		
		var spo = all[species]
		
		var callable = spo.createCallable(self, "kemonomimify")
		var archetype = spo.createArchetype("kemonomimi", callable, 0)
		archetype.optionDisplay = "Kemonomimi"
		archetype.description = "Yep"
		spo.addArchetype(archetype)

func getAddedRatArchetypes() -> Dictionary:
	var basePath:String = "res://Modules/WintersCoreModule/CompatibilityPatches/RAT_Archetypes/"
	
	var speciesDict : Dictionary = {
		Species.Canine: [basePath+"ClawedArchetypes.json"], # filenames
		Species.Feline: [basePath+"ClawedArchetypes.json"],
		Species.Equine: [basePath+"HoofedArchetypes.json"],
		Species.Dragon: [basePath+"ScaledArchetypes.json"],
	}
	
	return getArchetypesBase(speciesDict)

func getArchetypesBase(d:Dictionary={}) -> Dictionary:
	var mod : Module = GlobalRegistry.getModule("RodentUtils")
	
	for species in d:
		var old : Array = d[species]
		var new : Dictionary = {}
		for path in old:
			var dict : Dictionary = mod.readJsonData(path, TYPE_DICTIONARY, {})
			new.merge(dict, true)
		d[species] = new
	
	return d

func postInit():
	if !("RAT_Archetypes" in GlobalRegistry.getModules()):
		for p in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersCoreModule/CompatibilityPatches/BDCC/"):
			GlobalRegistry.registerSpecies(p)
