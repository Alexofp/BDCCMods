extends "res://Game/SexEngine/SexActivity/Spanking.gd"

func getActions(indx: int):
	if indx == DOM_0:
		return.getActions(indx)
	
	if indx == SUB_0:
		if (state in ["", "rimming"]):
			addAction("pullaway", getResistScore(SUB_0), "Pull away", "Try to pull away", {A_CHANCE: getSubResistChance(10.0, 5.0)})

		if (coverButtTimer <= 0 && !getSub().hasBoundArms()):
			addAction("coverbutt", 0.05 - fetish(SUB_0, Fetish.Masochism) * 0.1, "Cover butt", "Try to avoid some of the pain")

		if (isReadyToCumHandled(SUB_0)):
			addAction("cum", 1.0, "Cum!", "You're gonna cum.", {A_PRIORITY: 1001})

		if (subShouldCount && awaitsAnswer):
			var answers = []
			if correctSpankAmount == 7:
				answers.append(["6 7", true])
			else:
				answers.append([correctSpankAmount, true])
			
			while (answers.size() < 3):
				var randomNumber = RNG.randi_range(Util.maxi(correctSpankAmount - 3, 0), correctSpankAmount + 3)
				if (!answers.has(randomNumber)):
					answers.append([randomNumber, false])
			answers.shuffle()
			
			for answer in answers:
				var isCorrect = answer[1]
				if (isFakeSpank):
					isCorrect = false
				var mult = 1.0
				if (isFakeSpank):
					mult *= max(0.05, getSubInfo().personalityScore({PersonalityStat.Naive: 0.2}))
				elif (!isCorrect):
					mult *= max(0.05, getSubInfo().personalityScore({PersonalityStat.Brat: 0.3}))
				addAction(("correctnumber" if isCorrect else "badnumber"), getComplyScore(SUB_0) * mult, str(answer[0]), "Say this", {A_ARGS: [answer]})

func doAction(indx: int, id: String, action: Dictionary):
	if id == "spank":
		didSpankThisTime = true
		if (subShouldCount):
			if (awaitsAnswer):
				if (isFakeSpank):
					needToSayAvoidedTrap = true
				else:
					needToSayTooLate = true
			awaitsAnswer = true
			correctSpankAmount += 1
			isFakeSpank = false
		
		var text: String
		if subShouldCount && correctSpankAmount == 6:
			correctSpankAmount += 1
			text = RNG.pick([
				"{dom.You} quickly {dom.youVerb('spank')} {sub.your} {butt} twice!",
				"{dom.You} rapidly {dom.youVerb('smack')} {sub.your} {butt} twice!",
				"{dom.You} {dom.youVerb('hit')} {sub.your} rear twice rapidly!",
				"{dom.You} {dom.youVerb('deliver')} an impact on {sub.your} {butt}, then {dom.youVerb('deliver')} another one quickly!",
				"{dom.You} {dom.youVerb('make')} {sub.your} {butt} jiggle from a smack! {dom.You} then {dom.youVerb('give')} it another smack soon after.",
				"{dom.You} {dom.youVerb('spank')} {sub.your} {butt} lightly, first once and then twice!",
			])
			affectSub(getSubInfo().fetishScore({Fetish.Masochism: 1.0}) + 0.3, 0.05, -0.1, -0.01)
		else:
			text = RNG.pick([
				"{dom.You} {dom.youVerb('spank')} {sub.your} {butt}!",
				"{dom.You} {dom.youVerb('smack')} {sub.your} {butt}!",
				"{dom.You} {dom.youVerb('hit')} {sub.your} rear!",
				"{dom.You} {dom.youVerb('deliver')} an impact on {sub.your} {butt}!",
				"{dom.You} {dom.youVerb('make')} {sub.your} {butt} jiggle from a smack!",
				"{dom.You} {dom.youVerb('spank')} {sub.your} {butt} lightly!",
			])
		affectSub(getSubInfo().fetishScore({Fetish.Masochism: 1.0}) + 0.3, 0.05, -0.1, -0.01)

		if (coverButtTimer > 0):
			coverButtTimer -= 1
			if (coverButtTimer <= 0):
				text += " {sub.YourHis} hands hurt too much to keep covering."
			else:
				text += " {sub.YourHis} hands softened the blow."
		else:
			getSubInfo().addPain(1)
			sendSexEvent(SexEvent.PainInflicted, DOM_0, SUB_0, {pain = 1, isDefense = false, intentional = true})
		
		if (RNG.chance(50)):
			text += " " + getAssDescriptionAfterImpact(true)
		
		affectSub(getSubInfo().fetishScore({Fetish.Masochism: 1.0}, -0.5), 0.1, -0.2, 0.0)
		affectDom(getDomInfo().fetishScore({Fetish.Sadism: 0.5}, 0.5), 0.1, 0.0)
		
		getSubInfo().addArousalSex(max(0.0, getSubInfo().fetishScore({Fetish.Masochism: 0.1}) + 0.02))
		
		sendSexEvent(SexEvent.Spanked, DOM_0, SUB_0, {strongSpank = false, pain = (0 if coverButtTimer > 0 else 1)})
		
		addText(text)
		return
	elif id == "bigspank":
		didBigSpankThisTime = true
		if (subShouldCount):
			if (awaitsAnswer):
				if (isFakeSpank):
					needToSayAvoidedTrap = true
				else:
					needToSayTooLate = true
			awaitsAnswer = true
			correctSpankAmount += 1
			isFakeSpank = false
		
		var text: String
		if subShouldCount && correctSpankAmount == 6:
			correctSpankAmount += 1
			text = RNG.pick([
				"{dom.You} {dom.youVerb('spank')} {sub.your} {butt} [b]hard[/b], and then {dom.youVerb('do', 'does')} it again for good measure!",
				"{dom.You} {dom.youVerb('smack')} {sub.your} {butt} with [b]full force[/b], and then {dom.youVerb('do', 'does')} it again!",
				"{dom.You} {dom.youVerb('hit')} {sub.your} rear [b]sadistically[/b], and then {dom.youVerb('do', 'does')} it again with no pause!",
			])
		else:
			text = RNG.pick([
				"{dom.You} {dom.youVerb('spank')} {sub.your} {butt} [b]hard[/b]!",
				"{dom.You} {dom.youVerb('smack')} {sub.your} {butt} with [b]full force[/b]!",
				"{dom.You} {dom.youVerb('hit')} {sub.your} rear [b]sadistically[/b]!",
			])
		var damageDivider = 1
		if (coverButtTimer > 0):
			damageDivider = 2
			coverButtTimer -= 2
			if (coverButtTimer <= 0):
				text += " {sub.YourHis} hands hurt too much to keep covering."
			else:
				text += " {sub.YourHis} hands softened the blow."
		
		affectSub(getSubInfo().fetishScore({Fetish.Masochism: 1.0}, -0.5), 0.1, -0.05, 0.0)
		affectDom(getDomInfo().fetishScore({Fetish.Sadism: 0.5}, 0.5), 0.2, 0.0)
		
		if (RNG.chance(50)):
			text += " " + getAssDescriptionAfterImpact(true)
		
		var addPain: int = int(round(10 / damageDivider))
		getSubInfo().addPain(addPain)
		sendSexEvent(SexEvent.PainInflicted, DOM_0, SUB_0, {pain = addPain, isDefense = false, intentional = true})
		affectSub(getSubInfo().fetishScore({Fetish.Masochism: 1.0}) - 0.6, 0.05, -0.1, -0.01)
		affectDom(getSubInfo().fetishScore({Fetish.Sadism: 1.0}) + 0.3, 0.05, -0.01)
		
		getSubInfo().addArousalSex(max(0.0, getSubInfo().fetishScore({Fetish.Masochism: 0.2}) + 0.02))
		
		sendSexEvent(SexEvent.Spanked, DOM_0, SUB_0, {strongSpank = true, pain = addPain})
		
		addText(text)
		return
	elif id == "correctnumber":
		correctTimer = 2

		awaitsAnswer = false
		getDomInfo().addAnger(-0.1)
			
		var domSay: String = ""
		if (correctSpankAmount >= targetSpanks):
			satisfyGoals()
			if (!getDom().isPlayer()):
				domSay = RNG.pick([
					"Good job, that's enough.",
				])
				endActivity()

		var randomAddition: String = RNG.pick([
			"Ngh..",
			"I think..",
			"Agh..",
			"ARgh..",
			"Ow..",
			"Fuck..",
		])

		var text: String
		var subSay: String
		if correctSpankAmount == 7:
			text = RNG.pick([
				"{sub.You} {sub.youVerb('shout')} the correct numbers."
			])
			
			subSay = RNG.pick([
				"6! 7! "
			]) + randomAddition
		else:
			text = RNG.pick([
				"{sub.You} {sub.youVerb('say')} the correct number.",
			])

			subSay = str(correctSpankAmount) + "! " + randomAddition

		addText(text)
		talkText(SUB_0, subSay)
		talkText(DOM_0, domSay)
		return
	elif id == "badnumber":
		wrongTimer = 2
		var saidNumber = action["args"][0][0]
		
		var text: String = RNG.pick([
			"{sub.You} {sub.youVerb('say')} the [b]WRONG[/b] number!",
		])
		if (isFakeSpank):
			text = RNG.pick([
				"{sub.You} got fooled and said a number [b]without getting spanked[/b]!",
			])
		
		awaitsAnswer = false
		getDomInfo().addAnger(0.4)
		
		var randomAddition = RNG.pick([
			"Probably..",
			"I think.. wait..",
			"Agh.. No.. wait..",
			"ARgh.. Please..",
			"Ow.. Yeah?..",
			"Fuck.. Oh no..",
		])
		
		addText(text)
		talkText(SUB_0, str(saidNumber) + "! " + randomAddition)
		#talkText(DOM_0, "Wrong!")
		return
	else:
		return.doAction(indx, id, action)