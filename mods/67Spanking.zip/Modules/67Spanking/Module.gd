extends Module

func _init():
	id = "Frivolous_67Spanking"
	author = "Frivolous"

	# I will not apologize for making art.
	sexActivities = [
		"res://Modules/67Spanking/Spanking.gd"
	]