extends Module

func _init():
    id = "HangingRopes"
    author = "Mimi"
    
    items = [
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesStatic.gd",
    ]
    
    scenes = [
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesPunishmentScene.gd",
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesStruggleScene.gd",
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesWillingDynNpcScene.gd",
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesSexScene.gd",
    ]

    events = [
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesEvent.gd",
        "res://Modules/HangingRopesModule/HangingRopes/HangingRopesWillingDynNpcEvent.gd",
        "res://Modules/HangingRopesModule/TryHangingRopesEvent.gd",
    ]