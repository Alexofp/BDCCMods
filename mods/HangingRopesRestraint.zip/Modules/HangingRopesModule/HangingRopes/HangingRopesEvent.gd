extends EventBase

func _init():
    id = "HangingRopesEvent"

func registerTriggers(es):
    es.addTrigger(self, Trigger.EnteringRoom)
    es.addTrigger(self, Trigger.Waiting)

func react(_triggerID, _args):
    if !GM.pc.getInventory().hasItemIDEquipped("HangingRopesStatic"):
        return false
    if GM.main.getCurrentScene().sceneID == "HangingRopesPunishmentScene":
        return false
    
    runScene("HangingRopesPunishmentScene")
    return true

func getPriority():
    return 15