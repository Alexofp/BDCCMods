extends EventBase

func _init():
    id = "HangingRopesEvent"

func registerTriggers(es):
    es.addTrigger(self, Trigger.EnteringRoom)
    es.addTrigger(self, Trigger.Waiting)

func run(_triggerID, _args):
    if _triggerID == Trigger.EnteringRoom and _args.size() > 0 and _args[0] == "main_punishment_spot":
        if !GM.pc.getInventory().hasItemIDEquipped("HangingRopesStatic"):
            addButtonUnlessLate("Try Rope Bondage", "Voluntarily get suspended in the thick ropes", "try_hanging_ropes")

func react(_triggerID, _args):
    if !GM.pc.getInventory().hasItemIDEquipped("HangingRopesStatic"):
        return false
    if GM.main.getCurrentScene().sceneID == "HangingRopesPunishmentScene":
        return false
    
    runScene("HangingRopesPunishmentScene")
    return true

func getPriority():
    return 5

func onButton(_method, _args):
    if _method == "try_hanging_ropes":
        runScene("HangingRopesPunishmentScene")