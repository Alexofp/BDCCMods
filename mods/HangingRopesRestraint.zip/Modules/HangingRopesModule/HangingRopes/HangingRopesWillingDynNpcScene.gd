extends "res://Scenes/SceneBase.gd"

var npcID = ""
var sawBefore = false
var npcVariation = ""
var visitCount = 0

func _init():
    sceneID = "HangingRopesWillingDynNpcScene"

func _initScene(_args = []):
    npcID = _args[0]
    var npc = GlobalRegistry.getCharacter(npcID)
    
    if npc and npc.getFlag(CharacterFlag.Introduced):
        sawBefore = true
    elif npc:
        npc.setFlag(CharacterFlag.Introduced, true)
    
    visitCount = npc.getFlag("HangingRopesVisitCount", 0) + 1
    npc.setFlag("HangingRopesVisitCount", visitCount)

    var personality:Personality = npc.getPersonality()
    npcVariation = ""
    if personality.getStat(PersonalityStat.Mean) > 0.3 or personality.getStat(PersonalityStat.Subby) < -0.6:
        npcVariation = "mean"
    elif personality.getStat(PersonalityStat.Mean) < -0.3:
        npcVariation = "kind"
    elif personality.getStat(PersonalityStat.Subby) > 0.6 or personality.getStat(PersonalityStat.Coward) > 0.8:
        npcVariation = "subby"

func resolveCustomCharacterName(_charID):
    if _charID == "npc":
        return npcID
    return null

func _run():
    if state == "":
        addCharacter(npcID)
        playAnimation(StageScene.RopesSex, "tease", {"pc": "pc", "npc": npcID})

        saynn(RNG.pick([
            "{npc.name} walks up to your helplessly hanging body, clearly turned on by the view.",
            "{npc.name} approaches with a hungry look, eyes roaming over your exposed form."
        ]))

        if visitCount >= 5:
            saynn("[say=npc]Again? You're such a needy hanging slut...[/say]")
        elif visitCount >= 3:
            saynn("[say=npc]Back for more already?[/say]")

        if npcVariation == "mean":
            saynn(RNG.pick([
                "[say=npc]Look at you, all tied up and ready to be used like a fucktoy.[/say]",
                "[say=npc]Perfect position. I'm taking what's mine.[/say]",
            ]))
        else:
            saynn("[say=npc]You look perfect hanging there...[/say]")

        addButton("Let them", "Allow them to fuck you", "startsex")
        addButton("Refuse", "Try to shake your head", "shake_head")

    elif state == "shake_head_success":
        saynn("{npc.name} looks disappointed but walks away.")
        addButton("Continue", "", "endthescene")

    elif state == "shake_head_fail":
        saynn("{npc.name} ignores your refusal.")
        addButton("Get used", "", "startsex")

    elif state == "after_sex":
        saynn("{npc.name} finishes with you and leaves you hanging there.")
        addButton("Continue", "See what happens next", "endthescene")

func _react(_action: String, _args):
    if _action == "startsex":
        removeBlockingSexItems()
        getCharacter(npcID).prepareForSexAsDom()
        GlobalRegistry.getCharacter(npcID).addPain(-50)
        
        runScene("HangingRopesSexScene", [npcID, "pc"], "subbysex")
        return

    if _action == "shake_head":
        if npcVariation in ["subby", "kind"] or RNG.chance(40):
            setState("shake_head_success")
        else:
            setState("shake_head_fail")
        return

    if _action == "endthescene":
        endScene()
        return

    setState(_action)

func removeBlockingSexItems():
    var inv = GM.pc.getInventory()
    var slots = [InventorySlot.Penis, InventorySlot.Vagina, InventorySlot.Anus, InventorySlot.Mouth]
    for slot in slots:
        if inv.hasSlotEquipped(slot):
            inv.unequipSlot(slot)

func _react_scene_end(_tag, _result):
    if _tag == "subbysex":
        setState("after_sex")