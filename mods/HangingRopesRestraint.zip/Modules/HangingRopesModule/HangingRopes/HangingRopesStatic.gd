extends ItemBase

func _init():
    id = "HangingRopesStatic"

func getVisibleName():
    return "Hanging Ropes"

func getDescription():
    return "Thick sturdy ropes that suspend the wearer in a fully exposed hanging position. Arms pulled high above the head, legs spread wide apart."

func getEquippedDescription(_slot):
    return "You are helplessly suspended in mid-air by thick ropes. Your arms are stretched high above your head and your legs are spread wide apart, leaving you completely exposed."

func getClothingSlot():
    return InventorySlot.Static1

func getBuffs():
    return [
        buff(Buff.RestrainedArmsBuff),
        buff(Buff.RestrainedLegsBuff),
        buff(Buff.RestEffectivenessBuff, [-85]),
        buff(Buff.ExposureBuff, [80]),
        buff(Buff.AmbientLustBuff, [40]),
    ]

func getTakeOffScene():
    return "RestraintTakeOffNopeScene"

func getTags():
    return [
        ItemTag.BDSMRestraint,
        ItemTag.CanBeForcedByGuards,
    ]

func isRestraint():
    return true

func generateRestraintData():
    restraintData = load("res://Modules/HangingRopesModule/HangingRopes/RestraintHangingRopes.gd").new()
    restraintData.setLevel(10)

func alwaysSavedWhenStruggledOutOf():
    return false

func shouldBeKeptAfterStruggle():
    return false