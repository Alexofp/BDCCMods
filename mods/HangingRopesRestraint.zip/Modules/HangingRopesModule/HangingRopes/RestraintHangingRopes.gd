extends RestraintData
class_name RestraintHangingRopes

func _init():
    restraintType = RestraintType.Harness
    setLevel(10)  

func getVisibleName():
    return "Hanging Ropes"

func getDesc():
    return "You are helplessly suspended in the air by thick ropes, arms stretched high above your head, legs spread wide apart."

func canUnlockWithKey():
    return false

func shouldDoStruggleMinigame(_pc):
    return true

func doStruggle(_pc, _minigame: MinigameResult):
    var text = ""
    var damage = 0.0
    var lust = 0
    var stamina = 0
    var pain = 0

    var _handsFree = !_pc.hasBlockedHands()
    var _armsFree = !_pc.hasBoundArms()
    var _legsFree = !_pc.hasBoundLegs()

    if _handsFree && _armsFree && _legsFree:
        text = "{user.name} twists and pulls hard against the hanging ropes with full strength."
        damage = calcDamage(_pc, _minigame, 1.4)
        stamina = RNG.randi_range(8, 12)
        lust = scaleDamage(6)
    elif _armsFree:
        text = "{user.name} pulls and yanks on the ropes with {user.his} arms, causing {user.himself} to sway violently."
        damage = calcDamage(_pc, _minigame, 0.9)
        stamina = RNG.randi_range(10, 15)
        lust = scaleDamage(8)
    elif _handsFree:
        text = "{user.name} tugs desperately at the ropes using {user.his} hands."
        damage = calcDamage(_pc, _minigame, 0.6)
        stamina = RNG.randi_range(12, 16)
        lust = scaleDamage(7)
    else:
        text = "{user.name} struggles helplessly in the hanging ropes, only managing to make {user.himself} swing and spin."
        damage = calcDamage(_pc, _minigame, 0.25)
        stamina = RNG.randi_range(14, 20)
        lust = scaleDamage(10)
        pain = 3

    # GirlCum Collector interaction
    if RNG.chance(35) && _pc.getInventory().hasItemIDEquipped("GirlCumDildo"):
        _pc.getBodypart(BodypartSlot.Vagina).addFluidOrifice("GirlCum", RNG.randf_range(40, 90))
        text += " The violent swinging activates the GirlCum Collector inside {user.him}!"

    return {
        "text": text,
        "damage": damage,
        "lust": lust,
        "pain": pain,
        "stamina": stamina
    }

func processStruggleTurn(_pc, _isActivelyStruggling):
    var text = "The ropes creak loudly as {user.name} {user.verbS('hang')} and sway."
    var lust = scaleDamage(8)
    
    if RNG.chance(35) && _pc.getInventory().hasItemIDEquipped("GirlCumDildo"):
        _pc.getBodypart(BodypartSlot.Vagina).addFluidOrifice("GirlCum", RNG.randf_range(35, 80))
        text = "The GirlCum Collector suddenly milks {user.name} while {user.he} {user.verbS('hang')} helplessly!"
        lust = scaleDamage(14)
    
    return {
        "text": text,
        "lust": lust
    }

func onStruggleOut(_pc):
    return {
        "text": "{user.name} finally breaks free from the hanging ropes and drops heavily to the ground!",
        "lust": scaleDamage(15),
        "pain": 12,
        "stamina": 30
    }

func alwaysSavedWhenStruggledOutOf():
    return false

func shouldBeKeptAfterStruggle():
    return false


func alwaysBreaksWhenStruggledOutOf():
    return true