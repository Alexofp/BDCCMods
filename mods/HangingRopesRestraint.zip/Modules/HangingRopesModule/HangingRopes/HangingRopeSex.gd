extends SexTypeBase

func _init():
    id = SexType.HangingRopesSex

func getDefaultAnimation():
    return [StageScene.RopesSex, "tease", {
        "pc": "pc",
        "npc": "npc"
    }]

func getPossibleAnimations():
    return [
        [StageScene.RopesSex, "tease", {"pc": "pc", "npc": "npc"}],
        [StageScene.RopesSex, "sex", {"pc": "pc", "npc": "npc"}],
        [StageScene.RopesSex, "fast", {"pc": "pc", "npc": "npc"}],
        [StageScene.RopesOralSex, "tease", {"pc": "pc", "npc": "npc"}],
    ]

func getSexTypeName():
    return "Hanging Ropes"