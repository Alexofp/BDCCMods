extends BodypartTail

func _init():
	visibleName = "taokaka tail"
	id = "taokakatail"

func getCompatibleSpecies():
	return ["taokaka"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["feline", "fluffy"])

func getDoll3DScene():
	return "res://Modules/OrbsTaokakaSpecies/Bodyparts/Tail/TaokakaTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func generateRandomColors(_dynamicCharacter):
#	pickedRColor = ColorUtils.generateGenericFurryColors()
#	pickedGColor = ColorUtils.generateRandomPleasingFurColor()
	pickedGColor = Color("ff2B2B2B")
	pickedBColor = ColorUtils.generateRandomVibrantColor()
