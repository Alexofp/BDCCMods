extends BodypartBody

func _init():
	visibleName = "taokaka body"
	id = "taokakabody"

func getCompatibleSpecies():
	return ["taokaka"]

func getDoll3DScene():
	return "res://Modules/OrbsTaokakaSpecies/Bodyparts/Body/TaokakaBody.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
