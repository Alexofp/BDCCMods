extends BodypartHead

func _init():
	visibleName = "taokaka head"
	id = "taokakahead"

func getCompatibleSpecies():
	return ["taokaka"]

func getDoll3DScene():
	return "res://Modules/OrbsTaokakaSpecies/Bodyparts/Head/TaokakaHead.tscn"

func getHeadLength():
	return 0.0
