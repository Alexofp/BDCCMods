extends BodypartLeg

func _init():
	visibleName = "taokaka legs"
	id = "taokakalegs"

func getCompatibleSpecies():
	return ["taokaka"]

func getDoll3DScene():
	return "res://Modules/OrbsTaokakaSpecies/Bodyparts/Legs/TaokakaLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
