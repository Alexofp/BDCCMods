extends BodypartArms

func _init():
	visibleName = "taokaka arms"
	id = "taokakaarms"

func getCompatibleSpecies():
	return ["taokaka"]

func getDoll3DScene():
	return "res://Modules/OrbsTaokakaSpecies/Bodyparts/Arms/TaokakaArms.tscn"
