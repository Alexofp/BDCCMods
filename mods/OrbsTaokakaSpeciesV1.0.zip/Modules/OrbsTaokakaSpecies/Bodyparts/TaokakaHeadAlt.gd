extends BodypartHead

func _init():
	visibleName = "taokaka head alt"
	id = "taokakaheadalt"

func getCompatibleSpecies():
	return ["taokaka"]

func getDoll3DScene():
	return "res://Modules/OrbsTaokakaSpecies/Bodyparts/HeadAlt/TaokakaHeadAlt.tscn"

func getHeadLength():
	return 0.0
