extends Species

func _init():
	id = "taokaka"
	
func getVisibleName():
	return "Taokaka"

func getDefaultBody(_gender):
	return "taokakabody"

func getDefaultLegs(_gender):
	return "taokakalegs"

func getDefaultTail(_gender):
	return "taokakatail"

func isPlayable():
	return true

func getVisibleDescription():
	return "The shadowy boys and girls"

func getDefaultHead(_gender):
	return "taokakahead"

func getDefaultArms(_gender):
	return "taokakaarms"

func getDefaultEars(_gender):
	return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "malebreasts"
	return "taokakabreasts"

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]

func getSkinType():
	return SkinType.SkinHuman

func generateSkinColors():
	return ColorUtils.generateGenericHumanSkinColors()
