extends Module

func _init():
	id = "OrbsTaokakaSpecies"
	author = "Art by The Orb, Coding by Avery Winters"

	bodyparts = [
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaArms.gd",
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaBody.gd",
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaBreasts.gd",
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaHead.gd",
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaHeadAlt.gd",
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaLegs.gd",
		"res://Modules/OrbsTaokakaSpecies/Bodyparts/TaokakaTail.gd",
	]

	species = [
		"res://Modules/OrbsTaokakaSpecies/TaokakaSpecies.gd",
	]

	items = [
		"res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaBoots.gd",
		"res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaBra.gd",
		"res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaHood.gd",
		"res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaJacket.gd",
		"res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaPanties.gd",
		]
