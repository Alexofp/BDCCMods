extends ItemBase

func _init():
	id = "taokakahood"

func getVisibleName():
	return "Taokaka's Hood"
	
func getDescription():
	return "A comfy hood"

func getClothingSlot():
	return InventorySlot.Eyes

func getBuffs():
	return [
		]

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your hood"
	else:
		return "take off your hood"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your hood"
	else:
		return "put on your hood"

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"helmet": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaHood/TaokakaHood.tscn",
	}

func getHidesParts(_character):
	if(itemState.isRemoved()):
		return null
	var removed = {
		BodypartSlot.Hair: true,
#		BodypartSlot.Head: true,
		BodypartSlot.Ears: true,
		BodypartSlot.Horns: true,
	}
	
	return removed

func getInventoryImage():
	return "res://Images/Items/equipment/guardhelmet.png"
