extends ItemBase

func _init():
	id = "taokakaboots"

func getVisibleName():
	return "Taokaka's Boots"
	
func getDescription():
	return "comfy pair of boots"

func getClothingSlot():
	return InventorySlot.Ankles

func getBuffs():
	return [
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your boots"
	else:
		return "take off your boots"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your boots"
	else:
		return "put on your boots"

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func updateDoll(doll: Doll3D):
	doll.setState("boots", "hard")

#func getInventoryImage():
#	return "res://Modules/FelliniModule/Clothing/felliniBoots/icon.png"

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"boots": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaBoots/TaokakaBoots.tscn"
	}
