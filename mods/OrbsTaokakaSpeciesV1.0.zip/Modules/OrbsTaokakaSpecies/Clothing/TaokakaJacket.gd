extends ItemBase

func _init():
	id = "taokakajacket"

func getVisibleName():
	return "Taokaka's Jacket"

func getDescription():
	var text = "A long sleeved jacket and some side tie panties"
	return text

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		]

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your jacket and pulls down the panties"
	else:
		return "take off your jacket and pull down the panties"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your jacket and the panties"
	else:
		return "put on your jacket and the panties"

func generateItemState():
	itemState = ShirtAndShortsState.new()
	itemState.canActuallyBeDamaged = true # Is hack because there are many clothes that use this state already and don't support damaging..

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	if(itemState.isSuperDamaged()):
		return {
			"clothing": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaJacket/Damaged/TaokakaJacketSuperDamaged.tscn",
		}
	if(itemState.isDamaged()):
		return {
			"clothing": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaJacket/Damaged/TaokakaJacketDamaged.tscn",
		}
	if(itemState.isHalfDamaged()):
		return {
			"clothing": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaJacket/Damaged/TaokakaJacketHalfDamaged.tscn",
		}
	return {
		"clothing": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaJacket/TaokakaJacket.tscn",
	}

func getInventoryImage():
	return "res://Images/Items/equipment/shirtorange.png"
