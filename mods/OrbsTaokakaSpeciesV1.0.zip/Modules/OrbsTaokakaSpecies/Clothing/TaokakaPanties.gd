extends ItemBase

func _init():
	id = "taokakapanties"

func getVisibleName():
	return "Taokaka's Panties"
	
func getDescription():
	var text = "side tie panties."

	return text

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getBuffs():
	return [
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "slips down your panties"
	else:
		return "slip down your panties"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the panties"
	else:
		return "put on the panties"


func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func generateItemState():
	itemState = PantiesState.new()
	itemState.canActuallyBeDamaged = true

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	if(itemState.isDamaged()):
		return {
			"panties": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaPanties/TaokakaPantiesDamaged.tscn",
		}
	return {
		"panties": "res://Modules/OrbsTaokakaSpecies/Clothing/TaokakaPanties/TaokakaPanties.tscn",
	}

func getInventoryImage():
	return "res://Images/Items/underwear/pinkpanties.png"
	
func canDye():
	return false
