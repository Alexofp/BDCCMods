extends Module

func _init():
	id = "WintersManeTweaks"
	author = "Avery Winters"

	GlobalRegistry.registerBodypartSlot("res://Modules/WintersManeTweaks/CustomScripts/ManeBodypartSlot.gd")

	bodyparts = [
		"res://Modules/WintersManeTweaks/BodyParts/ManeTweaks.gd",
	]
