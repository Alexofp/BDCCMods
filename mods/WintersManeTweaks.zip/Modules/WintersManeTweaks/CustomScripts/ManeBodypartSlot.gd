extends CustomBodypartSlot

func _init():
	id = "mane"

func getVisibleName() -> String:
	return getVisibleNameNoCap().capitalize()

func getVisibleNameNoCap() -> String:
	return "mane"

func isEssential() -> bool:
	return false
