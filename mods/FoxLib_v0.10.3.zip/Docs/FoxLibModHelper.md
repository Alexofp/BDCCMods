# FoxLib ModHelper (Aka. FLMH)

FoxLib ModHelper is a tool bundled with each FoxLib release, it allows you to make mods without wasting time on packaging.

To use this tool you will need to install python 3 onto your computer: <https://www.python.org/downloads/>

## Setting up FoxLib ModHelper

There is 2 supported ways of doing mod development with FoxLib ModHelper, with an editor by using BDCC project source code, or in a new empty folder.

While I recommend use an empty folder to make your mods, I respect that some peoples want to do modding inside BDCC project source code to get the godot editor.

For either case, you need to do the following:
- Copy `FLMH.py` from your `FoxLib.zip` into the folder you want to do modding in.
- Copy your `FoxLib.zip` either to the `libs` subfolder or the same folder as `FLMH.py`  
  (FoxLib ModHelper will only load other mods definitions if they are in the `libs` subfolder)
- create your mod info json, `ModName.json` (Replace ModName with your actual mod name)
- Inside your `ModName.json` create `"name"`, `"description"`, `"author"`, `"modversion"`, `"gameversion"`

An example of valid mod info `.json` would be:
```json
{
	"name": "ModName",
	"description": "I'm a cool mod",
	"author": "Me",
	"modversion": "0.1",
	"gameversion": "*"
}

```

### Using FoxLib ModHelper in a project

To install FoxLib inside BDCC game project, you should run `./FLMH.py foxlib`, as FoxLib need to be patched to be able to run in the editor.

When using FoxLib ModHelper in a project, you can only put files inside your module folder in `Modules/MyModule/*` (`MyModule` is the module name you picked)

If you want to add files outside your Module, you will have to move your mod files outside BDCC project.

## Building & Testing

To build your mod, just do `./FLMH.py build`

When developing you often want to test your code in rapid iteration, just run `./FLMH.py test` to build and run your mod inside BDCC quickly.

You can also specify a game version to `./FLMH.py test`, for example `./FLMH.py test 0.1.7` will launch BDCC 0.1.7,
and `./FLMH.py test dev` will grab the git build from the git dev branch to test your mods against upcoming releases.

FoxLib ModHelper will report to you when some inconsistencies are found.

## Mod info extensions

"raw", "parsed", "trimmed"

FoxLib ModHelper can be configured via your `ModName.json` file, the following options are supported:
- `FLMH_source_mode`: Configure how FoxLib ModHelper will treat your source code:
  - `raw`: Means your code will ship as-is, disabling the preprocessor and it's features.
  - `parsed`: Like `raw`, but your code will be parsed to generate `.fldef` definitions.
  - `processed`: Means the preprocessor will be applied (Default)
  - `trimmed`: Remove comments from the release zip file
- `FLMH_resource_mode`: Configure how FoxLib ModHelper will treat your resources such as png:
  - `raw`: Don't auto-import resources (May cause mod images to not appear in game)
  - `duplicate`: Create a duplicate import of the resource (Default)
  - `imported`: Create an import of the resource then delete the original resource
- `FLMH_definition_mode`: Tell FoxLib ModHelper how they should make FoxLib definition file (Aka. `.fldef`)
  - `none`: Do not make `.fldef` under any circumstances.
  - `standard`: Will populate definitions with public APIs only (Default)
  - `extended`: Will populate definitions with public and private APIs
- `FLMH_foxlib_verify_mode`: Tell FoxLib ModHelper if they should inject a script ensuring FoxLib is installed.
  - `auto`: Enable the verifier only if FLMH thinks your mod hard depends on FoxLib to function. (Default)
  - `none`: Never enable the FoxLib verifier for your mod.
  - `verify`: Always enable the FoxLib verifier for your mod.
- `FLMH_run_game_test_on`:
  - `never`: Don't run a quick game test on run (Default)
  - `test`: Run a quick game test when executing the test command
- `FLMH_mod_menu_display`: Allow to tweak how your mod will display in BDCC mod launcher and mod browser
  - `vanilla`: Use default vanilla mod menu display (Default)
  - `simple`: Use simpler display, remove the "Description:" line and prevent "Game Version:" from appearing red. 
- `FLMH_mod_menu_display_game_version`: Override displayed game version if mod menu display isn't vanilla
- `FLMH_rahi_changelog`: Tell FoxLib to add preview changelog file when generating `.rahi.json`
- `FLMH_rahi_preview`: Tell FoxLib to add preview image link when generating `.rahi.json`


## Preprocessor

Preprocessor has some useful features, designed to help you make your mod more easily.

The `#import` statement is a helper tool that you can use to import a named class file (Defined with `class_name YourClassName`).

This can be useful when modding inside the editor, as the editor may auto import named classes while the real game don't.

for example, you can add the line `#import FoxUIManager` before a function calling `FoxUIManager.showGameConsole()` to make sure it's still imported on the full game version, for example.

If you are making a library, you can use `#public_api` to tell FoxLib ModHelper the class is a public API to be used by other mods

## Macro extensions

FoxLib ModHelper has macros that allow compile-time compute of some mod properties, marked as `%FLMH_*%`, to get macro as a string please use `"%FLMH_*%"`
- `%FLMH_mod_name%`: Current mod name string
- `%FLMH_mod_description%`: Current mod description
- `%FLMH_mod_author%`: Current mod authors
- `%FLMH_mod_version%`: Current mod version
- `%FLMH_mod_version%` also has semver variants, for `X.Y.Z`, `X` is major, `Y` is minor, and `Z` is patch:
  - `%FLMH_mod_version_major%`: Current mod version major version or `0` if unsupported, will always be a number.
  - `%FLMH_mod_version_minor%`: Current mod version minor version or `0` if unsupported, will always be a number.
  - `%FLMH_mod_version_patch%`: Current mod version patch version or `0` if unsupported, will always be a number.
- `%FLMH_game_version%`: Current game version defined in mod info
- `%FLMH_current_path%`: path of current source file.

You can also use any supported mod info extensions, such as `%FLMH_source_mode%` to get it's current value.

