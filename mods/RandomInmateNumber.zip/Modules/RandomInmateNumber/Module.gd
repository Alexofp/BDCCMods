extends Module


var padding : int = 5
var minValue : int = 10000
var maxVaue : int = 25000
var excludeCanon : bool = true

# exposed so you can add your own characters' inmate numbers in your module's postInit function, if this one is loaded as well. Value should be an int preferably, as padding can mess up things. Strings will be converted to ints upon generation of new inmate numbers, so if your string can be converted, it will be
var takenNumbers : Array = [
	12406,
]

func getFlags():
	return {
		"pcInmateNumber":flag(FlagType.Text)
	}

func _init():
	id = "RandomInmateNumber"
	author = "Selinoccino"

	worldEdits = [ # just so we can detect when the game loads reliably
		"res://Modules/RandomInmateNumber/RandomNumberWorldEdit.gd",
	]

func generateAndSetNewNumber() -> void:
	var newn = RNG.randi_range(minValue,maxVaue)
	
	if !excludeCanon:
		var res = str(newn).pad_zeros(padding)
		GM.pc.inmateNumber = res
		setFlag("RandomInmateNumber.pcInmateNumber",res)
		return
	
	var newTakens : Array = []
	for num in takenNumbers:
		newTakens.append(int(num))
	
	
	while newn in newTakens:
		newn = RNG.randi_range(minValue,maxVaue)
	
	var res = str(newn).pad_zeros(padding)
	GM.pc.inmateNumber = res
	setFlag("RandomInmateNumber.pcInmateNumber",res)

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addNumberOptionInCategory("Random Inmate Number","padding", "Zeroes padding", "Number of min. digits the player's inmate number should have, enforced by adding zeroes at the beginning of it. Set to 0 to disable.",5)
	
	foxModuleAPI.addNumberOptionInCategory("Random Inmate Number","minValue", "Minimum number", "Minimum value of player's inmate number. Default is 10000.",10000)
	
	foxModuleAPI.addNumberOptionInCategory("Random Inmate Number","maxValue", "Maximum number", "Maximum value of player's inmate number. Default is 25000.",25000)
	
	foxModuleAPI.addBooleanOptionInCategory("Random Inmate Number","excludeCanon", "Exclude canonically taken numbers", "Excludes canonically taken inmate numbers, such as Rahi's 12406. Be aware that by setting this to true and the minimum and maximum values to 12406 (or other taken numbers), the game will get stuck in an infinite loop and likely crash.",true)
	
