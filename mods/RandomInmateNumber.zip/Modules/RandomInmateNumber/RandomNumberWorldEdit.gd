extends WorldEditBase

func _init():
	id = "RandomNumberWorldEdit"

func apply(_world: GameWorld):
	var mod = GlobalRegistry.getModule("RandomInmateNumber")
	var inm = getFlag("RandomInmateNumber.pcInmateNumber",null)
	if !inm:
		mod.generateAndSetNewNumber()
	else:
		GM.pc.inmateNumber = inm
		GM.main.reRun()
		print("woo")
