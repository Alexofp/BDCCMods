extends BaseStageScene3D

onready var animationTree = $AnimationTree
onready var animationTree2 = $AnimationTree2
onready var doll = $Doll3D
onready var doll2 = $Doll3D2

func _init():
	id = StageScene.Sex69

# The knotted poses. Like the other oral scenes, 69 has no baked "fully inside" clip, so a knot is
# its own sex loop stopped dead on the frame that leaves the least shaft outside the mouth - which
# is also the frame where the top doll has settled furthest down onto the one below, which is what
# a stuck knot should look like. One constant per configuration, because each loop is its own
# animation and the best frame of one says nothing about the others:
#
#   MF  only the top doll's cock is in a mouth      Doll3D2's crotch to Doll3D's lips
#   FM  only the bottom doll's cock is in a mouth   Doll3D's crotch to Doll3D2's lips
#   MM  both at once, so the frame that leaves the two of them equally short
#
# None of the three closes the gap on its own - see KNOT_SEAT below. KnotPoseCheck.gd re-derives
# all three and fails if any drifts off its best frame.
const KNOT_FREEZE_MF := 0.822917
const KNOT_FREEZE_FM := 0.625
const KNOT_FREEZE_MM := 0.686458

# How much of the leftover gap to close by sliding the dolls together after the freeze, 0 leaving
# them exactly where the clip puts them. Modules/OralKnotting/KnotSeat.gd says why this is needed
# and where it aims; in 69 it matters most, because the two are knotted into each other and no
# translation closes both gaps at once. Turn it down if the bodies overlap more than the pose can
# carry.
const KNOT_SEAT := 1.0
const KnotSeat := preload("res://Modules/OralKnotting/KnotSeat.gd")
var knotSeat # built in _ready, once the dolls are where the scene puts them

# Same freeze the other three scenes use: start() cuts straight into the state instead of
# travel()'s half second cross-fade, the advances walk to the frozen frame, and MANUAL process mode
# means nothing advances the trees again until the next playAnimation puts them back on IDLE.
func freezeOn(_sm, _sm2, _state:String, _state2:String, _freezeTime:float):
	animationTree.process_mode = AnimationTree.ANIMATION_PROCESS_MANUAL
	animationTree2.process_mode = AnimationTree.ANIMATION_PROCESS_MANUAL
	animationTree.advance(0.0)
	animationTree2.advance(0.0)
	_sm.start(_state)
	_sm2.start(_state2)
	animationTree.advance(0.0)
	animationTree2.advance(0.0)
	animationTree.advance(_freezeTime)
	animationTree2.advance(_freezeTime)

# Getting into it. freezeOn() on its own snaps - it cuts straight to the frozen frame with no
# blend, while every other pose change in this scene cross-fades. So travel() first like the other
# poses do, let the loop run on until it is actually on the frozen frame, and only then pin it: the
# freeze lands on the frame the dolls are already showing, so nothing jumps. A frozen frame that
# comes round before the blend has finished waits one more lap.
const KNOT_XFADE := 0.5 # what every transition in this scene's state machine cross-fades for

var knotFrozenOn:String = ""      # the pose the trees are pinned on
var knotFreezePending:String = "" # the pose a freeze is on its way to

func travelThenFreeze(_sm, _sm2, _state:String, _state2:String, _cockDoll, _mouthDoll, _freezeTime:float, _mutual:bool = false):
	var key:String = _state + "@" + str(_freezeTime)
	if(knotFrozenOn == key):
		# Already there. playAnimation put the trees back on IDLE on its way in, so pin them again.
		freezeOn(_sm, _sm2, _state, _state2, _freezeTime)
		knotSeat.seat(_cockDoll, _mouthDoll, _mutual, KNOT_SEAT)
		return
	if(knotFreezePending == key):
		return # on its way already, and restarting the wait would land it on the wrong frame
	knotFreezePending = key

	_sm.travel(_state)
	_sm2.travel(_state2)

	var waitTime:float = _freezeTime
	var animPlayer = doll.getAnimPlayer2()
	var loopLength:float = animPlayer.get_animation(_state).length if animPlayer.has_animation(_state) else 0.0
	while(waitTime < KNOT_XFADE && loopLength > 0.0):
		waitTime += loopLength

	yield(get_tree().create_timer(waitTime), "timeout")
	if(knotFreezePending != key):
		return # a different pose took over while this one was on its way
	knotFreezePending = ""
	knotFrozenOn = key
	freezeOn(_sm, _sm2, _state, _state2, _freezeTime)
	knotSeat.seat(_cockDoll, _mouthDoll, _mutual, KNOT_SEAT)

func _ready():
	knotSeat = KnotSeat.new(doll, doll2)
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer2())
	animationTree.active = true
	animationTree2.anim_player = animationTree2.get_path_to(doll2.getAnimPlayer2())
	animationTree2.active = true

func updateSubAnims():
	if(true):
		return
	if(doll.getArmsCuffed()):
		animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree["parameters/CuffsBlend/blend_amount"] = 0.0
	
	if(doll2.getArmsCuffed()):
		animationTree2["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree2["parameters/CuffsBlend/blend_amount"] = 0.0

# The cock owner gets its scale clamped, the mouth owner gets an open mouth - the same pairing the
# unfrozen states use, kept in one place because the knotted states need it too.
func dressForOral(cockDoll, mouthDoll):
	cockDoll.clampPenisScale(0.95, 1.2)
	if(mouthDoll.getState("mouth") in ["", null]):
		mouthDoll.setTemporaryState("mouth", "open")

# StageScene.Duo, "kneel", {npc="nova", pc="pc"}
func playAnimation(animID, _args = {}):
	#var fullAnimID = animID
	#if(animID is Array):
	#	animID = animID[0]
	
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	doll2.prepareCharacter(secondDoll)
	
	#doll.forceSlotToBeVisible(BodypartSlot.Penis)
	
	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	
	if(_args.has("npcBodyState")):
		doll2.applyBodyState(_args["npcBodyState"])
	else:
		doll2.applyBodyState({})
	
	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)
	if(_args.has("npcCum") && _args["npcCum"]):
		startCumPenis(doll2)
	
	updateSubAnims()
	
	# The previous animation may have left the trees frozen for a knot
	animationTree.process_mode = AnimationTree.ANIMATION_PROCESS_IDLE
	animationTree2.process_mode = AnimationTree.ANIMATION_PROCESS_IDLE
	knotSeat.unseat()
	if(!("knot" in animID)):
		knotFrozenOn = ""
		knotFreezePending = ""
	
	var state_machine = animationTree["parameters/StateMachine/playback"]
	var state_machine2 = animationTree2["parameters/StateMachine/playback"]

	if(animID == "tease"):
		state_machine.travel("Sex69Tease_1-loop")
		state_machine2.travel("Sex69Tease_2-loop")
	if(animID == "FM"):
		state_machine.travel("Sex69_1-loop")
		state_machine2.travel("Sex69_2-loop")
		dressForOral(doll, doll2)
	if(animID == "MF"):
		state_machine.travel("Sex69MF_1-loop")
		state_machine2.travel("Sex69MF_2-loop")
		dressForOral(doll2, doll)
	if(animID == "FF"):
		state_machine.travel("Sex69FF_1-loop")
		state_machine2.travel("Sex69FF_2-loop")
	if(animID == "MM"):
		state_machine.travel("Sex69MM_1-loop")
		state_machine2.travel("Sex69MM_2-loop")
		dressForOral(doll, doll2)
		dressForOral(doll2, doll)
	if(animID == "FMknotted"):
		dressForOral(doll, doll2)
		travelThenFreeze(state_machine, state_machine2, "Sex69_1-loop", "Sex69_2-loop", doll, doll2, KNOT_FREEZE_FM)
	if(animID == "MFknotted"):
		dressForOral(doll2, doll)
		travelThenFreeze(state_machine, state_machine2, "Sex69MF_1-loop", "Sex69MF_2-loop", doll2, doll, KNOT_FREEZE_MF)
	if(animID == "MMknotted"):
		dressForOral(doll, doll2)
		dressForOral(doll2, doll)
		travelThenFreeze(state_machine, state_machine2, "Sex69MM_1-loop", "Sex69MM_2-loop", doll, doll2, KNOT_FREEZE_MM, true)

func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
		
	if(doll.getCharacterID() != firstDoll || doll2.getCharacterID() != secondDoll):
		return false
	return true

func getSupportedStates():
	return ["tease", "FM", "MF", "FF", "MM", "FMknotted", "MFknotted", "MMknotted"]

func getVarNpcs():
	return ["pc", "npc"]
