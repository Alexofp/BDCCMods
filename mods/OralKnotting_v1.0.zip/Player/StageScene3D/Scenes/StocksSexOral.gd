extends BaseStageScene3D

onready var animationTree = $AnimationTree
onready var animationTree2 = $AnimationTree2
onready var doll = $Doll3D
onready var doll2 = $Doll3D2

func _init():
	id = StageScene.StocksSexOral

# The knotted pose. This pose family has no baked "fully inside" clip - only SexOralForced,
# ChairOral and SexOralTable ever got one - so it is the sex loop stopped dead on the frame where
# the cock sits deepest in the mouth. Measured rather than guessed: the frame that leaves the least
# shaft between the crotch and the other doll's lips. It does not get all the way there on its own -
# see KNOT_SEAT below. MOD/OralKnotting_v1.0/KnotPoseCheck.gd re-measures it and fails if this
# number drifts off the best frame.
const KNOT_FREEZE_TIME := 0.563542
# How much of the leftover gap to close by sliding the dolls together after the freeze, 0 leaving
# them exactly where the clip puts them. Modules/OralKnotting/KnotSeat.gd says why this is needed
# and where it aims. Turn it down if the bodies overlap more than the pose can carry.
const KNOT_SEAT := 1.0
const KnotSeat := preload("res://Modules/OralKnotting/KnotSeat.gd")
var knotSeat # built in _ready, once the dolls are where the scene puts them

# The first advance only makes sure the state machine has actually started - on a tree that has
# never processed, start() is dropped on the floor. start() then cuts straight into the state,
# because travel() would cross-fade for half a second and land on whatever frame it liked. The
# advance after it commits the state at phase 0, and the last one walks to the frozen frame.
# process_mode MANUAL means nothing advances the trees again, so the dolls hold still until the
# next playAnimation puts them back on IDLE.
func freezeOn(_sm, _sm2, _state:String, _state2:String, _freezeTime:float = KNOT_FREEZE_TIME):
	animationTree.process_mode = AnimationTree.ANIMATION_PROCESS_MANUAL
	animationTree2.process_mode = AnimationTree.ANIMATION_PROCESS_MANUAL
	animationTree.advance(0.0)
	animationTree2.advance(0.0)
	_sm.start(_state)
	_sm2.start(_state2)
	animationTree.advance(0.0)
	animationTree2.advance(0.0)
	animationTree.advance(_freezeTime)
	animationTree2.advance(_freezeTime)

# Getting into it. freezeOn() on its own snaps - it cuts straight to the frozen frame with no
# blend, while every other pose change in this scene cross-fades. So travel() first like the other
# poses do, let the loop run on until it is actually on the frozen frame, and only then pin it: the
# freeze lands on the frame the dolls are already showing, so nothing jumps. A frozen frame that
# comes round before the blend has finished waits one more lap.
const KNOT_XFADE := 0.5 # what every transition in this scene's state machine cross-fades for

var knotFrozenOn:String = ""      # the pose the trees are pinned on
var knotFreezePending:String = "" # the pose a freeze is on its way to

func travelThenFreeze(_sm, _sm2, _state:String, _state2:String, _cockDoll, _mouthDoll, _freezeTime:float = KNOT_FREEZE_TIME):
	var key:String = _state + "@" + str(_freezeTime)
	if(knotFrozenOn == key):
		# Already there. playAnimation put the trees back on IDLE on its way in, so pin them again.
		freezeOn(_sm, _sm2, _state, _state2, _freezeTime)
		knotSeat.seat(_cockDoll, _mouthDoll, false, KNOT_SEAT)
		return
	if(knotFreezePending == key):
		return # on its way already, and restarting the wait would land it on the wrong frame
	knotFreezePending = key

	_sm.travel(_state)
	_sm2.travel(_state2)

	var waitTime:float = _freezeTime
	var animPlayer = doll.getAnimPlayer()
	var loopLength:float = animPlayer.get_animation(_state).length if animPlayer.has_animation(_state) else 0.0
	while(waitTime < KNOT_XFADE && loopLength > 0.0):
		waitTime += loopLength

	yield(get_tree().create_timer(waitTime), "timeout")
	if(knotFreezePending != key):
		return # a different pose took over while this one was on its way
	knotFreezePending = ""
	knotFrozenOn = key
	freezeOn(_sm, _sm2, _state, _state2, _freezeTime)
	knotSeat.seat(_cockDoll, _mouthDoll, false, KNOT_SEAT)

func _ready():
	knotSeat = KnotSeat.new(doll, doll2)
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer())
	animationTree.active = true
	animationTree2.anim_player = animationTree2.get_path_to(doll2.getAnimPlayer())
	animationTree2.active = true
	
func updateSubAnims():
	#if(doll.getArmsCuffed()):
	#	animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	#else:
	#	animationTree["parameters/CuffsBlend/blend_amount"] = 0.0
	
	if(doll2.getArmsCuffed()):
		animationTree2["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree2["parameters/CuffsBlend/blend_amount"] = 0.0

# StageScene.Duo, "kneel", {npc="nova", pc="pc"}
func playAnimation(animID, _args = {}):
	#var fullAnimID = animID
	#if(animID is Array):
	#	animID = animID[0]
	
	#print("Playing duo: "+str(animID))
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	doll2.prepareCharacter(secondDoll)
	
	#doll.forceSlotToBeVisible(BodypartSlot.Penis)
	
	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	
	if(_args.has("npcBodyState")):
		doll2.applyBodyState(_args["npcBodyState"])
	else:
		doll2.applyBodyState({})
	
	updateSubAnims()
	
	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)
	if(_args.has("npcCum") && _args["npcCum"]):
		startCumPenis(doll2)
	
	# The previous animation may have left the trees frozen for the knot
	animationTree.process_mode = AnimationTree.ANIMATION_PROCESS_IDLE
	animationTree2.process_mode = AnimationTree.ANIMATION_PROCESS_IDLE
	knotSeat.unseat()
	if(!("knot" in animID)):
		knotFrozenOn = ""
		knotFreezePending = ""

	var state_machine = animationTree["parameters/StateMachine/playback"]
	var state_machine2 = animationTree2["parameters/StateMachine/playback"]

	if(animID == "knotted"):
		doll2.clampPenisScale(0.95, 1.1)
		if(doll.getState("mouth") in ["", null]):
			doll.setTemporaryState("mouth", "open")
		travelThenFreeze(state_machine, state_machine2, "StocksSex_1-loop", "StocksSex_3-loop", doll2, doll)
	if(animID == "tease"):
		state_machine.travel("StocksSexTease_1-loop")
		state_machine2.travel("StocksSexTease_3-loop")
	if(animID == "pussy"):
		state_machine.travel("StocksSexPussy_1-loop")
		state_machine2.travel("StocksSexPussy_3-loop")
	if(animID == "sex"):
		state_machine.travel("StocksSex_1-loop")
		state_machine2.travel("StocksSex_3-loop")
		doll2.clampPenisScale(0.95, 1.1)
		if(doll.getState("mouth") in ["", null]):
			doll.setTemporaryState("mouth", "open")
	if(animID == "fast"):
		state_machine.travel("StocksSexFast_1-loop")
		state_machine2.travel("StocksSexFast_3-loop")
		doll2.clampPenisScale(0.95, 1.1)
		if(doll.getState("mouth") in ["", null]):
			doll.setTemporaryState("mouth", "open")


func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	
	if(doll.getCharacterID() != firstDoll || doll2.getCharacterID() != secondDoll):
		return false
	return true

func getSupportedStates():
	return ["tease", "pussy", "sex", "fast", "knotted"]

func getVarNpcs():
	return ["pc", "npc"]
