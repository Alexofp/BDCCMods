extends Reference
# Sliding the dolls together so a knotted cock is actually inside the mouth.
#
# None of the oral scenes has a baked "fully inside" clip, so a knot is the scene's own sex loop
# stopped on its deepest frame - and even that frame leaves a fifth of a shaft outside the mouth in
# most of them. A cock stuck fast in a throat cannot hang half out, so after the freeze the dolls
# are slid the rest of the way together. Four scenes do it, which is why it lives here.
#
# The mouth is where the animations say it is: in the three clips the game authored as a cock fully
# inside a mouth - suckinside on SexOralForced, SexOralTable and ChairOral - the crotch is at the
# lips, so there the cock's base bone IS the mouth. Averaged in the head bone's own frame the three
# agree to within a few hundredths, and that point is what everything below aims the crotch at.
# KnotPoseCheck.gd re-derives it from those same clips and fails if it drifts.
const MOUTH := Vector3(0.988838, 0.028142, -0.017185)

var dollA
var dollB
var homeA:Vector3
var homeB:Vector3

func _init(_dollA, _dollB):
	dollA = _dollA
	dollB = _dollB
	homeA = _dollA.translation
	homeB = _dollB.translation

# Back where the scene puts them, which is where every pose but a knot wants them.
func unseat():
	dollA.translation = homeA
	dollB.translation = homeB

func bonePoint(_doll, _bone:String, _offset:Vector3 = Vector3.ZERO) -> Vector3:
	var skeleton:Skeleton = _doll.getDollSkeleton().getSkeleton()
	var idx:int = skeleton.find_bone(_bone)
	if(idx < 0):
		return Vector3.ZERO
	return (skeleton.global_transform * skeleton.get_bone_global_pose(idx)).xform(_offset)

# What is still showing: crotch to lips, in world units. A shaft is a bit under one of those.
func exposed(_cockDoll, _mouthDoll) -> float:
	return gap(_cockDoll, _mouthDoll).length()

func gap(_cockDoll, _mouthDoll) -> Vector3:
	return bonePoint(_mouthDoll, "Head", MOUTH) - bonePoint(_cockDoll, "Penis")

# Moves the cock's owner onto the mouth. Relative, so the scene unseats before posing again.
# _amount is the knob: 0 leaves the dolls exactly where the clip put them.
func seat(_cockDoll, _mouthDoll, _mutual:bool = false, _amount:float = 1.0):
	var theGap:Vector3 = gap(_cockDoll, _mouthDoll)
	if(!_mutual):
		_cockDoll.translation += theGap * _amount
		return
	# Knotted into each other. Only the difference between the two moves matters to either gap, so
	# no translation closes both; this is the split that leaves them equally short.
	var otherGap:Vector3 = gap(_mouthDoll, _cockDoll)
	var shift:Vector3 = (theGap - otherGap) * 0.25 * _amount
	_cockDoll.translation += shift
	_mouthDoll.translation -= shift
