extends Object
# The two knot settings, read in one place because three activities ask for them. The values live
# on Modules/OralKnotting/Module.gd, where FoxLib turns them into 0-100 sliders; this reads them
# back through the game's own registry, so nothing here depends on FoxLib being installed, and a
# missing module just means the defaults below.

const ATTEMPT_DEFAULT:float = 67.0
const SUCCESS_DEFAULT:float = 70.0

static func setting(field:String, fallback:float) -> float:
	var knotModule = GlobalRegistry.getModules().get("OralKnotting")
	if(knotModule == null):
		return fallback
	var value = knotModule.get(field)
	if(value == null):
		return fallback
	return clamp(float(value), 0.0, 100.0)

# The AI weight-picks between the priority-1001 actions, and the ones a knot competes with are all
# scored 1.0, so wanting the knot picked p percent of the time out of rivals+1 choices means
# scoring it rivals*p/(100-p). The clamp keeps p=100 out of a division by zero; there the knot
# outweighs the rest a few hundred to one, which is as close to always as this AI gets.
static func actionScore(rivals:float) -> float:
	var wanted:float = setting("knotAttemptChance", ATTEMPT_DEFAULT)
	return rivals * wanted / max(100.0 - wanted, 0.5)

# A floor under the game's own knotting roll, which bottoms out at 30% for a throat far too small.
static func successChance(gameChance:float) -> float:
	return max(gameChance, setting("knotSuccessChance", SUCCESS_DEFAULT))
