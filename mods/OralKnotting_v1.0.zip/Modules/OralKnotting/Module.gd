extends Module
# The mod's settings. FoxLib turns the two fields below into 0-100 sliders under its mod options
# screen; without FoxLib onFoxLibModInit() is never called and the fields keep the defaults here,
# which are the numbers the mod shipped with. Game/SexEngine/SexActivity/SexOral.gd reads them
# through GlobalRegistry.getModules(), so it needs neither this module nor FoxLib to be present.

var name = "Oral Knotting" # FoxLib titles the options category with this

# Percent. How often a knotted dom goes for the throat knot on the turn it cums.
var knotAttemptChance:float = 67.0
# Percent. Floor under the game's own knotting roll, which bottoms out at 30 for a small throat.
var knotSuccessChance:float = 70.0

func _init():
	id = "OralKnotting"
	author = "xrob1"

func onFoxLibModInit(foxModuleAPI):
	# Each slider binds to the field of the same name on its own, because the ids match.
	foxModuleAPI.addSliderOption("knotAttemptChance", "Knot attempt chance",
		"How often a dom with a knot goes for the throat knot instead of just cumming inside or "
		+ "pulling out. Subs with Cum Unique Biology still get knotted more often than this.",
		int(knotAttemptChance))
	foxModuleAPI.addSliderOption("knotSuccessChance", "Knot success chance",
		"Lowest chance a knot attempt catches. The game's own roll is used instead whenever it is "
		+ "already higher than this, so 0 means vanilla odds.",
		int(knotSuccessChance))
