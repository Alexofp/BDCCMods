extends NpcOwnerEventBase

var tryCount:int
var enough:bool
var struggleText:String
var restraintItemID
#var deterministicOrderHashInt = RNG.randi_range(1, 1000000)

func _init():
	id = "HelpOwnerRestraints"
	reactsToTags = [E_APPROACH]
	eventMinLevel = 0
#	if(!self.getOwner() == null):
#		var temp = self.getOwner().getRestraintsToStruggleOutOf()
#		if(!temp.empty()):
#			eventWeight = 10
#	else:
	eventWeight = 10
		
func canEventBeUsedAsSubEvent(_event) -> bool:
	var _diii = _event.getOwner().getRestraintsToStruggleOutOf()
	if(_diii.possible.size()==0):
		return false
	else:
		return true

func trySubEventStart(_event, _tag:String, _args:Array, _context:Dictionary) -> bool:
	var owner = getChar(0)
	var temp = owner.getRestraintsToStruggleOutOf()
	if(temp.empty()):
		return false
	var fetishScore:float = ownerFetish(Fetish.Bondage)
	var this = clamp(abs(1.0 + (fetishScore))/2, 0.0, 0.8)*100
	if(RNG.chance(this)):
		return false
	else: return true
	


func start():
	var owner = getChar(0)
	var temp = owner.getRestraintsToStruggleOutOf()
	if(temp.empty()):
		getRunner().removeEndedEvent(self)
	playAnimation(StageScene.Duo, "stand", {npc=getRoleID(C_OWNER)})
	
	saynn("Your owner approaches you while wiggling in a non-sexy way. Clearly they are annoyed by a restraint.")
	talkModularOwnerToPC("SoftSlaveryHelpingStart") #I feel like marking my {npc.npcSlave}. So stand still while I do this.
	saynn("Looks like {npc.he} {npc.isAre} is going to require your help.")
	
	if(GM.pc.getStamina() > 0 && !GM.pc.hasBlockedHands() && !GM.pc.hasBoundArms()):
		addButton("Agree", "Agree to help them with their restraints", "help")
		addButton("Deny", "You'd rather not","deny")
	elif(GM.pc.getStamina()==0 && !GM.pc.hasBlockedHands() && !GM.pc.hasBoundArms() && (GM.pc.hasPerk(Perk.SexLustPassion) || GM.pc.getInventory().hasItemID("appleitem") || GM.pc.getInventory().hasItemID("EnergyDrink") || GM.pc.getInventory().hasItemID("PlantEgg"))):
		addDisabledButton("Agree", "You're too tired...")
		addButton("Tired","You're out of stamina, but maybe...","restoreStam")
		addButton("Deny", "You'd rather not","deny")
	elif(GM.pc.hasBlockedHands() || GM.pc.hasBoundArms()):
		addDisabledButton("Agree", "You can't help them while in your current stat...")
		addButton("Deny","You can't help them while in your current state...","cantHelp")



func start_do(_id:String, _args:Array):
	if(_id == "cantHelp"):
		setState("cantHelp")
	if(_id == "help"):
		setState("eager_to_help")
	if(_id == "restoreStam"):
		setState("restoreStam")
	if(_id == "deny"):
		if(smartChance(max(10.0 - ownerPersonality(PersonalityStat.Mean)*80.0, 10.0)+getOwnerNOM(NOM.Kind)*30.0, 0.0)):
			setState("restraints_deny")
		else:
			runResist()


func cantHelp():
	saynn("You glance at your owner, then pitifully show your own restraints.")
	talkModularOwnerToPC("SoftSlaveryHelpingUnable")

	addContinue("setState", ["fineEnough"])
		

func restraints_agree():
	saynn("{pc.name} starts tugging on {npc.name}'s restraints.")
	addButton("Help", "Start helping..", "help")

func restraints_agree_do(_id:String, _args:Array):
	if(_id == "help"):
		doHelpStruggleForStarter()
#		getRolePawn(-1).afterSocialInteraction()
#		getRolePawn(0).afterSocialInteraction()
		
func restraints_deny():
	saynn("You shake your head.")
	saynn("Your owner looks a little upset...")
	addButton("Continue", "Oh well..", "fineEnough")


func restraints_helping():
	saynn(struggleText)

	if(getChar(0).getInventory().hasRemovableRestraintsNoLockedSmartlocks() && getChar(-1).getStamina() > 0 && !getChar(-1).hasBlockedHands() && !getChar(-1).hasBoundArms()):
		addButton("Help", "Continue helping..", "help")
	else:
		addDisabledButton("Help", "Can't help anymore..")
	addButton("Stop", "Enough helping..", "stop")

func restraints_helping_do(_id:String, _args:Array):
	if(_id == "help"):
		doHelpStruggleForStarter()
	if(_id == "stop"):
		setState("fineEnough")


func doHelpStruggleForStarter():
	var restraintData = getChar(0).getNextRestraintToStruggleOutOf(12)
	restraintItemID = restraintData.item.id if(restraintData != null) else ""
#	restraintData.item.level
	
	var theStarter = getChar(0)
	var struggleData:Dictionary = theStarter.doStruggleOutOfRestraints(false, true, getChar(-1), 1.0, 0)
	if(struggleData.empty()):
		struggleText = "Something happened.."
	else:
		struggleText = struggleData["text"]
		addInfluenceObey(0.01)
		
	tryCount += 1

	if(!getChar(0).getInventory().hasItemIDEquipped(restraintItemID) && getChar(0).getInventory().hasRemovableRestraintsNoLockedSmartlocks() && getChar(-1).getStamina() > 0):
		setState("eager_to_help")
	else:
		setState("restraints_helping")


func eager_to_help():
	if(struggleText != ""):
		saynn(struggleText)

	var restraintData = getChar(0).getNextRestraintToStruggleOutOf(12)
	var restraintVisibleName = restraintData.item.getVisibleName() if(restraintData != null) else "the restraint"
	saynn("{pc.You} {pc.youAre} about to help {npc.you} remove "+ restraintVisibleName + ".")

	if(struggleText == ""):
		talkModularOwnerToPC("SoftSlaveryHelpingStart")
	addContinue("setState", ["restraints_agree"])





func restoreStam():
	saynn("You can think of a few ways to restore your stamina...")
	if(GM.pc.hasPerk(Perk.SexLustPassion)):
		addButton("Sex?", "You [i]do[/i] get some energy back after sex...", "fuck")
	else:
		addDisabledButton("Sex?", "That only tires you out more.")
		
	if(GM.pc.getInventory().hasItemID("appleitem")):
		addButton("Eat Apple", "Have a snack", "eatapple")
	elif(GM.pc.getInventory().hasItemID("PlantEgg")):
		addButton("Eat Egg", "Have a snack", "eategg")
	else:
		addDisabledButton("Eat Apple", "You have none!")
	if(GM.pc.getInventory().hasItemID("EnergyDrink")):
		addButton("Energy Drink", "Have a drink", "eatdrink")
	else:
		addDisabledButton("Energy Drink", "You have none!")


func restoreStam_do(_id:String, _args:Array):
	if(_id == "fuck"):
		setState("sex")
	if(_id == "eatapple"):
		var theitem = GM.pc.getInventory().getFirstOf("appleitem")
		if(!theitem == null):
			GM.main.runScene("UseItemLikeInCombatScene",[theitem.uniqueID])
		setState("eager_to_help")
	if(_id == "eategg"):
		var theitem = GM.pc.getInventory().getFirstOf("PlantEgg")
		if(!theitem == null):
			theitem.useInCombat(GM.pc, GM.pc)
		setState("eager_to_help")
	if(_id == "eatdrink"):
		var theitem = GM.pc.getInventory().getFirstOf("EnergyDrink")
		if(!theitem == null):
			theitem.useInCombat(GM.pc, GM.pc)
		setState("eager_to_help")
		
	

func sex():
	playAnimation(StageScene.Duo, "kneel", {npc=getRoleID(C_OWNER)})
	saynn("You submit to your owner!")
	addButton("Continue", "See what happens next", "startSex", [getRoleID(C_OWNER), "pc", SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}])
	

func sex_sexResult(_sexResult:SexEngineResult):
	setState("eager_to_help")
	

func fineEnough():
	playAnimation(StageScene.Duo, "stand", {npc=getRoleID(C_OWNER)})
	if(tryCount >= 1):
		saynn("You tell your owner that you can't help any more.")
		talkModularOwnerToPC("SoftSlaveryHelpingThank")
	else:
		saynn("You tell your owner that you can't help.")
		talkModularOwnerToPC("SoftSlaveryHelpingFinish") #Alright. I guess this is enough for now.
	addButton("Leave","There's nothing more you can do.","endEvent")


func fight():
	if(tryCount <= 0):
		saynn("You tell your owner that you don't wanna help.")
	else:
		saynn("You tell your owner that this is all you can do.")
	saynn("But {npc.name} doesn't back down.")
	talkModularOwnerToPC("SoftSlaveryResist")
	addButton("Resist", "Resist it", "runResist")
#
#
#func fight_do(_id:String, _args:Array):
#	if(_id == "resist"):
#		runResist()



func saveData() -> Dictionary:
	var data := .saveData()
	
	data["tryCount"] = tryCount
	
	return data

func loadData(_data:Dictionary):
	.loadData(_data)
	
	tryCount = SAVE.loadVar(_data, "tryCount", 0)
