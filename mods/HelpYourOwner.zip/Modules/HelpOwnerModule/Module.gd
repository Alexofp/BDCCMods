extends Module

func _init():
	id = "HelpOwnerModule"
	author = "bringlebangul"
	
	scenes = []
	characters = []
	items = []
	events = []
	quests = []
	GlobalRegistry.registerNpcOwnerEvent("res://Modules/HelpOwnerModule/HelpOwnerRestraints.gd")
	var f = File.new()
	f.open("res://Game/ModularDialogue/FormBanks/SoftSlavery.gd",3)
	f.seek_end(-521)

	if(not f.get_line().begins_with("SoftSlaveryHelpingStart\"")):
		f.seek_end(-4)
		f.store_string('\n\t\t\"SoftSlaveryHelpingStart\": form(\"Come here, {npc.npcSlave}. You\'re going to remove these restraints for me.\", {main=CHAR, target=CHAR}, \"main\", \"target\"),\n')
		f.store_string('\t\t\"SoftSlaveryHelpingThank\": form(\"That\'s a good {npc.npcSlave}.\", {main=CHAR, target=CHAR}, \"main\", \"target\"),\n')
		f.store_string('\t\t\"SoftSlaveryHelpingFinish\": form(\"Alright, slave, you can go now.\", {main=CHAR, target=CHAR}, \"main\", \"target\"),\n')
		f.store_string('\t\t\"SoftSlaveryHelpingUnable\": form(\"Looks like my {npc.npcSlave} is a bit tied up, huh...\", {main=CHAR, target=CHAR}, \"main\", \"target\"),\n\t}')
		f.seek(0)
	f.close()

	
#		"SoftSlaveryHelpingStart": form("Come here, {npc.npcSlave}. You're going to remove these restraints for me.", {main=CHAR, target=CHAR}, "main", "target"),
#		"SoftSlaveryHelpingThank": form("That's a good {npc.npcSlave}.", {main=CHAR, target=CHAR}, "main", "target"),
#		"SoftSlaveryHelpingFinish": form("Alright, slave, you can go now.", {main=CHAR, target=CHAR}, "main", "target"),
#		"SoftSlaveryHelpingUnable": form("Looks like my {npc.npcSlave} is a bit tied up, huh...", {main=CHAR, target=CHAR}, "main", "target"),
		
