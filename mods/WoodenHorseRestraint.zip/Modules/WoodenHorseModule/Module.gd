extends Module

func _init():
    id = "WoodenHorse"
    author = "Mimi"
    
    items = [
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorseStatic.gd",
    ]
    
    scenes = [
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorsePunishmentScene.gd",
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorseStruggleScene.gd",
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorseWillingDynNpcScene.gd",
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorseSexScene.gd",
    ]

    events = [
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorseEvent.gd",
        "res://Modules/WoodenHorseModule/WoodenHorse/WoodenHorseWillingDynNpcEvent.gd",
        "res://Modules/WoodenHorseModule/TryWoodenHorseEvent.gd",
    ]