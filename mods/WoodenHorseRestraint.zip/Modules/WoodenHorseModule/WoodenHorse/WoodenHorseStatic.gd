extends ItemBase

func _init():
    id = "WoodenHorseStatic"

func getVisibleName():
    return "Wooden Horse"

func getDescription():
    return "A classic wooden horse restraint. Forces the rider to straddle a sharp edge, putting intense pressure on the crotch while arms and legs can be bound."

func getEquippedDescription(_slot):
    return "You are painfully straddling a wooden horse. The sharp ridge presses hard into your crotch, making every movement agonizing."

func getClothingSlot():
    return InventorySlot.Static1

func getBuffs():
    return [
        buff(Buff.RestrainedArmsBuff),
        buff(Buff.RestrainedLegsBuff),
        buff(Buff.RestEffectivenessBuff, [-70]),
        buff(Buff.ExposureBuff, [60]),
        buff(Buff.AmbientLustBuff, [50]),
        buff(Buff.PainBuff, [30]),
    ]

func getTakeOffScene():
    return "RestraintTakeOffNopeScene"

func getTags():
    return [
        ItemTag.BDSMRestraint,
        ItemTag.CanBeForcedByGuards,
    ]

func isRestraint():
    return true

func generateRestraintData():
    restraintData = load("res://Modules/WoodenHorseModule/WoodenHorse/RestraintWoodenHorse.gd").new()
    restraintData.setLevel(9)

func alwaysBreaksWhenStruggledOutOf():
    return true

func alwaysSavedWhenStruggledOutOf():
    return false

func shouldBeKeptAfterStruggle():
    return false