extends EventBase

func _init():
    id = "TryWoodenHorseEvent"

func registerTriggers(es):
    es.addTrigger(self, Trigger.EnteringRoom)
    es.addTrigger(self, Trigger.Waiting)

func run(_triggerID, _args):
    if _triggerID == Trigger.EnteringRoom and _args.size() > 0 and _args[0] == "main_punishment_spot":
        addButtonUnlessLate("Try Wooden Horse", "Voluntarily ride the wooden horse", "try_wooden_horse")

func onButton(_method, _args):
    if _method == "try_wooden_horse":
        runScene("WoodenHorsePunishmentScene")