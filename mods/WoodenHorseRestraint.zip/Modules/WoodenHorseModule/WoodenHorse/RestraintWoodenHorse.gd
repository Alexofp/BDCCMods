extends RestraintData
class_name RestraintWoodenHorse

func _init():
    restraintType = RestraintType.Harness
    setLevel(9)

func getVisibleName():
    return "Wooden Horse"

func getDesc():
    return "You are forced to straddle a sharp wooden horse. The ridge digs painfully into your sensitive areas."

func canUnlockWithKey():
    return false

func shouldDoStruggleMinigame(_pc):
    return true

func doStruggle(_pc, _minigame: MinigameResult):
    var text = ""
    var damage = 0.0
    var lust = 0
    var stamina = 0
    var pain = RNG.randi_range(4, 8)

    var _handsFree = !_pc.hasBlockedHands()
    var _armsFree = !_pc.hasBoundArms()
    var _legsFree = !_pc.hasBoundLegs()

    if _handsFree && _armsFree && _legsFree:
        text = "{user.name} desperately tries to lift {user.himself} off the sharp edge."
        damage = calcDamage(_pc, _minigame, 1.2)
        stamina = RNG.randi_range(10, 14)
        lust = scaleDamage(12)
    elif _armsFree:
        text = "{user.name} pulls hard with {user.his} arms, trying to ease the pressure on {user.his} crotch."
        damage = calcDamage(_pc, _minigame, 0.8)
        stamina = RNG.randi_range(12, 16)
        lust = scaleDamage(10)
    else:
        text = "{user.name} squirms helplessly on the wooden horse, only making the pain worse."
        damage = calcDamage(_pc, _minigame, 0.3)
        stamina = RNG.randi_range(14, 18)
        lust = scaleDamage(15)
        pain += 2

    return {
        "text": text,
        "damage": damage,
        "lust": lust,
        "pain": pain,
        "stamina": stamina
    }

func processStruggleTurn(_pc, _isActivelyStruggling):
    var text = "The wooden horse creaks as {user.name} {user.verbS('shift')} uncomfortably."
    var lust = scaleDamage(10)
    var pain = RNG.randi_range(2, 5)
    
    return {
        "text": text,
        "lust": lust,
        "pain": pain
    }

func onStruggleOut(_pc):
    return {
        "text": "{user.name} finally slides off the wooden horse with a groan of relief!",
        "lust": scaleDamage(20),
        "pain": 15,
        "stamina": 25
    }

func alwaysBreaksWhenStruggledOutOf():
    return true

func alwaysSavedWhenStruggledOutOf():
    return false

func shouldBeKeptAfterStruggle():
    return false