extends "res://Scenes/SceneBase.gd"

var amountOfEventsPassed = 0
var lastCharName = ""
var lastItemName = ""
var lastNpcID = ""

var sawBefore = false
var npcVariation = ""

func _init():
    sceneID = "WoodenHorsePunishmentScene"

func _reactInit():
    GM.pc.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("WoodenHorseStatic"))
    
    GM.pc.setLocation("main_punishment_spot")
    aimCamera("main_punishment_spot")
    
    playAnimation(StageScene.WoodenHorseSolo, "idle", {
        "pc": "pc",
        "bodyState": {"naked": true}
    })

func _run():
    if state == "":
        playAnimation(StageScene.WoodenHorseSolo, "idle", {
            "pc": "pc",
            "bodyState": {"naked": true}
        })

        saynn("You are painfully straddling the wooden horse. The sharp wooden ridge presses hard into your crotch and sensitive areas, making even the slightest movement send waves of discomfort through your body.")

        showNearbyCharacters()

        addButton("Wait", "Stay quiet and endure the pain", "wait")
        addButton("Be loud", "Call for help (more risky)", "be_loud")
        addButton("Struggle", "Try to get off the horse", "struggle")
        
        if !GM.pc.getInventory().hasLockedStaticRestraints():
            addButton("Escape", "You're already free!", "endthescene")
        else:
            addDisabledButton("Escape", "The wooden horse keeps you firmly in place")

    elif state == "wait":
        saynn("You try to stay as still as possible on the wooden horse...")
        addButton("Continue", "", "after_wait")

    elif state == "be_loud":
        saynn("You shout loudly for attention, your voice echoing through the punishment area...")
        addButton("Continue", "", "after_beloud")

    elif state == "restraint_added_quiet":
        addCharacter(lastNpcID)
        sayn(lastCharName + " casually walks up to you.")
        saynn('"Well well... look at you riding that thing so pathetically."')
        sayn(lastCharName + " puts " + lastItemName + " on you with a grin.")
        saynn('"There. Much better."')
        saynn("You are now even more restricted.")
        addButton("Continue", "", "back_to_idle")

    elif state == "restraint_added_loud":
        addCharacter(lastNpcID)
        sayn(lastCharName + " storms over, clearly irritated by your shouting.")
        saynn('"You never learn, do you?"')
        sayn(lastCharName + " forcefully applies " + lastItemName + " on you.")
        saynn('"Maybe this will finally shut you up."')
        saynn("You are now even more restricted.")
        addButton("Continue", "", "back_to_idle")

    elif state == "after_wait":
        saynn("Time passes slowly as you continue to suffer on the wooden horse...")
        showNearbyCharacters()
        addButton("Continue", "", "back_to_idle")

    elif state == "after_beloud":
        saynn("Your loud shouts echo through the area...")
        showNearbyCharacters()
        addButton("Continue", "", "back_to_idle")

    elif state == "sleeping":
        saynn("It has gotten very late. All the lights turn off one by one.\n\nYou are left painfully riding the wooden horse in complete darkness...")
        addButton("Sleep", "Endure the night like this", "aftersleep")

func showNearbyCharacters():
    var activeChars = []
    if GM.main and GM.main.has_method("getCurrentLocationCharacters"):
        activeChars = GM.main.getCurrentLocationCharacters()
    
    if activeChars.size() > 1: 
        saynn("Around you, you can see:")
        for ch in activeChars:
            if ch == GM.pc or !ch:
                continue
            var displayName = ch.getName()
            saynn("• " + displayName)
    else:
        saynn("The punishment area feels quite empty right now...")

func _react(_action: String, _args):
    if _action in ["wait", "be_loud"]:
        processTime(30 * 60)
        if GM.main.isVeryLate():
            setState("sleeping")
            return

    if _action == "after_wait":
        GM.pc.addStamina(35)
        setState("after_wait")
        triggerRandomEvent(getEscapeChance(false))
        maybeAddRandomRestraint(0.50, false)   
        amountOfEventsPassed += 1
        return

    if _action == "after_beloud":
        GM.pc.addStamina(25)
        setState("after_beloud")
        triggerRandomEvent(getEscapeChance(true))
        maybeAddRandomRestraint(0.70, true)    
        amountOfEventsPassed += 1
        return

    if _action == "back_to_idle":
        removeCharacter(lastNpcID)
        setState("")
        return

    if _action == "aftersleep":
        GM.main.startNewDay()
        GM.pc.afterSleeping()
        setState("")
        return

    if _action == "struggle":
        runScene("WoodenHorseStruggleScene")
        setState("")
        return

    if _action == "endthescene":
        endScene()
        return

    setState(_action)

func getRandomNpcID() -> String:
    var candidates = []
    
    if GM.main and GM.main.has_method("getCurrentLocationCharacters"):
        var activeChars = GM.main.getCurrentLocationCharacters()
        for ch in activeChars:
            if !ch or ch == GM.pc:
                continue
            var name = ch.getName()
            if name in ["Guard Raine", "Raine", "Guard Marcus", "Marcus", "Guard Lena", "Lena",
                        "Officer Vale", "Vale", "Guard Torres", "Torres", "Inmate Jax", "Jax",
                        "Inmate Kira", "Kira", "Vion", "Eliza Quinn", "Eliza"]:
                continue
            if ch.isGuard() or ch.isStaff() or ch.isInmate():
                candidates.append(ch.getID())

    if candidates.size() < 2:
        for charID in GlobalRegistry.getCharacters():
            var ch = GlobalRegistry.getCharacter(charID)
            if !ch or ch == GM.pc:
                continue
            var name = ch.getName()
            if name in ["Guard Raine", "Raine", "Guard Marcus", "Marcus", "Guard Lena", "Lena",
                        "Officer Vale", "Vale", "Guard Torres", "Torres", "Inmate Jax", "Jax",
                        "Inmate Kira", "Kira", "Vion", "Eliza Quinn", "Eliza"]:
                continue
            if ch.isGuard() or ch.isStaff() or ch.isInmate():
                candidates.append(charID)
    
    if candidates.size() > 0:
        return RNG.pick(candidates)
    
    return ""

func maybeAddRandomRestraint(chance: float, isLoud: bool):
    if !RNG.chance(chance * 100):
        return
    
    var possibleRestraints = {
        "ballgag": "a ball gag",
        "ringgag": "a ring gag",
        "blindfold": "a blindfold",
        "basketmuzzle": "a basket muzzle",
        "leathermuzzle": "a leather muzzle",
        "bondagemittens": "bondage mittens",
        "buttplug": "a buttplug",
        "vaginalplug": "a vaginal plug",
        "ZiptiesAnkle": "zip ties on the ankles",
        "ChastityCage": "a chastity cage",
        "ropeharness": "a rope harness",
        "harness": "a leather harness",
    }
    
    var chosenID = RNG.pick(possibleRestraints.keys())
    lastItemName = possibleRestraints[chosenID]
    
    var item = GlobalRegistry.createItem(chosenID)
    if !item:
        return
    
    lastNpcID = getRandomNpcID()
    
    if lastNpcID != "":
        var npc = GlobalRegistry.getCharacter(lastNpcID)
        lastCharName = npc.getName() if npc else "Someone"
        
        sawBefore = npc.getFlag(CharacterFlag.Introduced) if npc and npc.has_method("getFlag") else false
        if npc and npc.has_method("setFlag"):
            npc.setFlag(CharacterFlag.Introduced, true)
        
        var personality = npc.getPersonality()
        npcVariation = ""
        if personality.getStat(PersonalityStat.Mean) > 0.3 or personality.getStat(PersonalityStat.Subby) < -0.6:
            npcVariation = "mean"
        elif personality.getStat(PersonalityStat.Mean) < -0.3:
            npcVariation = "kind"
        elif personality.getStat(PersonalityStat.Subby) > 0.6 or personality.getStat(PersonalityStat.Coward) > 0.8:
            npcVariation = "subby"
    else:
        lastCharName = "A random inmate"
        npcVariation = "mean"
        sawBefore = false
    
    GM.pc.getInventory().forceEquipRemoveOther(item)
    
    if isLoud:
        setState("restraint_added_loud")
    else:
        setState("restraint_added_quiet")

func resolveCustomCharacterName(_charID):
    if _charID == "npc" or _charID == lastNpcID:
        return lastNpcID
    return null

func triggerRandomEvent(escapeChance):
    var choices = ["Escape", "Event", "WillingSex", ""]
    var weights = [escapeChance, 20, 25, 55]
    var eventType = RNG.pickWeighted(choices, weights)
    
    if eventType == "Escape":
        if GM.ES.triggerReact("WoodenHorseEscape"):
            endScene()
            return true
    elif eventType == "Event":
        if GM.ES.triggerReact("WoodenHorseEvent"):
            return true
    elif eventType == "WillingSex":
        if GM.ES.triggerReact("WoodenHorseWillingSex"):
            return true

    playAnimation(StageScene.WoodenHorseSolo, "idle", {
        "pc": "pc",
        "bodyState": {"naked": true}
    })
    saynn(RNG.pick([
        "Someone walks by and smirks at your painful predicament.",
        "A group of inmates laugh and point as they pass.",
        "The wooden horse creaks loudly as you shift uncomfortably.",
        "Your crotch throbs from the constant pressure."
    ]))

func getEscapeChance(isLoud = false):
    if amountOfEventsPassed < 8:
        return 0.0
    if isLoud:
        return max(4.0, amountOfEventsPassed / 7.0)
    return max(2.0, amountOfEventsPassed / 9.0)

func _onSceneEnd():
    GM.pc.getInventory().clearStaticRestraints()
    removeCharacter(lastNpcID)

func saveData():
    var data = .saveData()
    data["amountOfEventsPassed"] = amountOfEventsPassed
    data["lastNpcID"] = lastNpcID
    data["sawBefore"] = sawBefore
    data["npcVariation"] = npcVariation
    return data

func loadData(data):
    .loadData(data)
    amountOfEventsPassed = SAVE.loadVar(data, "amountOfEventsPassed", 0)
    lastNpcID = SAVE.loadVar(data, "lastNpcID", "")
    sawBefore = SAVE.loadVar(data, "sawBefore", false)
    npcVariation = SAVE.loadVar(data, "npcVariation", "")