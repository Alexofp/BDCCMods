extends SexTypeBase

func _init():
    id = SexType.WoodenHorseSex

func getDefaultAnimation():
    return [StageScene.WoodenHorseDuo, "idle", {
        "pc": "pc",
        "npc": "npc"
    }]

func getPossibleAnimations():
    return [
        [StageScene.WoodenHorseDuo, "idle", {"pc": "pc", "npc": "npc"}],
        [StageScene.WoodenHorseDuo, "lightstruggle", {"pc": "pc", "npc": "npc"}],
        [StageScene.WoodenHorseDuo, "struggle", {"pc": "pc", "npc": "npc"}],
    ]

func getSexTypeName():
    return "Wooden Horse"