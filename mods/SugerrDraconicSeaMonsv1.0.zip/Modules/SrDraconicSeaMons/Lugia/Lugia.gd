extends Species

func _init():
	id = "sugerrlugia"

func isPlayable():
	return true

func getVisibleName():
	return "Lugia"

func getVisibleDescription():
	return "Bringer of Storms"

func getDefaultHead(_gender):
	return "sugerrlugiahead"

func getDefaultEars(_gender):
	return "sugerrlugiaears"

func getDefaultBody(_gender):
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"
	
func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "sugerrlugiatail"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sugerrlugiapenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]
