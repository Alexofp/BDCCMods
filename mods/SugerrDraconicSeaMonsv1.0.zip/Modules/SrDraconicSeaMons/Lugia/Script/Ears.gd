extends BodypartEars

func _init():
	visibleName = "lugia ears"
	id = "sugerrlugiaears"

func getCompatibleSpecies():
	return ["sugerrlugia"]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Lugia/PNG/LugiaEars/Ears.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Lugia Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
