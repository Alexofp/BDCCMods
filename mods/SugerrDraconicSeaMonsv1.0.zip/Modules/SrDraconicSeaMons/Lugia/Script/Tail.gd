extends BodypartTail

func _init():
	visibleName = "lugia tail"
	id = "sugerrlugiatail"

func getCompatibleSpecies():
	return ["sugerrlugia"]

func getLewdSizeAdjective():
	return RNG.pick(["double"])

func getLewdAdjective():
	return RNG.pick(["pointy", "insect"])

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Lugia/PNG/LugiaTail/Tail.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Lugia Species)"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
