extends BodypartPenis

func _init():
	visibleName = "lugia penis"
	id = "sugerrlugiapenis"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Lugia/PNG/LugiaPenis/Penis.tscn"
	
func getLewdAdjective():
	return RNG.pick(["big", "dragonite"])

func getVulgarName() -> String:
	return "humanoid cock"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Lugia Species)"
	

