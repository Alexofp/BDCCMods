extends BodypartHead

func _init():
	visibleName = "lugia head"
	id = "sugerrlugiahead"

func getCompatibleSpecies():
	return ["sugerrlugia"]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Lugia/PNG/LugiaHead/Head.tscn"

func getHeadLength():
	return 0.55
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Lugia Species)"
