extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "hyperable lugia penis"
	id = "sugerrlugiapenishyperable"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Lugia/PNG/LugiaPenis/Penis.tscn"

func generateRandomColors(_dynamicCharacter):
	pass

func getLewdAdjective():
	return RNG.pick(["big", "lugia"])

func getVulgarName() -> String:
	return "humanoid cock"
	
func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"
	
func getTraits():
	return {
		"Hyperable": true,
	}


