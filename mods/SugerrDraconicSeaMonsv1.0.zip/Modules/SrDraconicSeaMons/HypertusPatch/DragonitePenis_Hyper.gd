extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "hyperable dragonite penis"
	id = "sugerrdragonitepenishyperable"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Dragonite/PNG/DragonitePenis/Penis.tscn"

func generateRandomColors(_dynamicCharacter):
	pass

func getLewdAdjective():
	return RNG.pick(["flared", "horse-shaped", "dragonite"])

func getVulgarName() -> String:
	return "flared cock"
	
func getPenisScale():
	return max(0.1 + (lengthCM - 5.0) / 21.0, 0.3)
	
func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"
	
func getTraits():
	return {
		PartTrait.PenisFlare: true,
		"Hyperable": true,
	}
	
func shouldUseBigPump():
	return true
