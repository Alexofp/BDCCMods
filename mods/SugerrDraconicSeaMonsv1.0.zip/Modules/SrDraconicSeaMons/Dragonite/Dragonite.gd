extends Species

func _init():
	id = "sugerrdragonite"

func isPlayable():
	return true

func getVisibleName():
	return "Dragonite"

func getVisibleDescription():
	return "Flies through storms"

func getDefaultHead(_gender):
	return "sugerrdragonitehead"

func getDefaultEars(_gender):
	return "sugerrdragoniteears"

func getDefaultHorns(_gender):
	return "sugerrdragonitehorns"

func getDefaultBody(_gender):
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"
	
func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "sugerrdragonitetail"
	

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sugerrdragonitepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]
