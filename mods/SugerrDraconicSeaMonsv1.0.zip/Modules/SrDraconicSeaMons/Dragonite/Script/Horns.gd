extends BodypartHorns

func _init():
	visibleName = "dragonite horns"
	id = "sugerrdragonitehorns"

func getCompatibleSpecies():
	return ["sugerrdragonite"]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Dragonite/PNG/DragoniteHorns/Horns.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Dragonite Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
