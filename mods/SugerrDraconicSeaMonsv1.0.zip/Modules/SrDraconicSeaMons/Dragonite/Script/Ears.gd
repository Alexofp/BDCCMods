extends BodypartEars

func _init():
	visibleName = "dragonite ears"
	id = "sugerrdragoniteears"

func getCompatibleSpecies():
	return ["sugerrdragonite"]

func getDoll3DScene():
	return null
	
func getCharacterCreatorDesc():
	return "(Dragonite Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
