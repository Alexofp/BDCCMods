extends BodypartBody

func _init():
	visibleName = "dragonite body"
	id = "sugerrdragonitebody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Dragonite/PNG/DragoniteBody/Body.tscn"

func getVulgarName() -> String:
	return "big body"

func getAVulgarName() -> String:
	return "a big body"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Dragonite Species)"
