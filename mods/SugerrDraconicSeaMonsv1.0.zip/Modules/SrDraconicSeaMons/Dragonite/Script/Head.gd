extends BodypartHead

func _init():
	visibleName = "dragonite head"
	id = "sugerrdragonitehead"

func getCompatibleSpecies():
	return ["sugerrdragonite"]

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Dragonite/PNG/DragoniteHead/Head.tscn"

func getHeadLength():
	return 0.55
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Dragonite Species)"
