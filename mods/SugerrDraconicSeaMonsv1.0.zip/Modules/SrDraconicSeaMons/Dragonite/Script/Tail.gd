extends BodypartTail

func _init():
	visibleName = "dragonite tail"
	id = "sugerrdragonitetail"

func getCompatibleSpecies():
	return ["sugerrdragonite"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SrDraconicSeaMons/Dragonite/PNG/DragoniteTail/Tail.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Dragonite Species)"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
