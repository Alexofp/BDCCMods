extends Module

func _init():
	id = "sugerrdraconicseamonsspecies"
	author = "Sugerør"
	
	species = [
		"res://Modules/SrDraconicSeaMons/Lugia/Lugia.gd",
		"res://Modules/SrDraconicSeaMons/Dragonite/Dragonite.gd",
	]
	bodyparts = [
		#Lugia
			# - Head + Ears
		"res://Modules/SrDraconicSeaMons/Lugia/Script/Head.gd",
		"res://Modules/SrDraconicSeaMons/Lugia/Script/Ears.gd",
			# - Tail
		"res://Modules/SrDraconicSeaMons/Lugia/Script/Tail.gd",
			# - Penis
		"res://Modules/SrDraconicSeaMons/Lugia/Script/Penis.gd",
		#Dragonite
			# - Head + Horns + Ears
		"res://Modules/SrDraconicSeaMons/Dragonite/Script/Head.gd",
		"res://Modules/SrDraconicSeaMons/Dragonite/Script/Ears.gd",
		"res://Modules/SrDraconicSeaMons/Dragonite/Script/Horns.gd",
			# - Body
		"res://Modules/SrDraconicSeaMons/Dragonite/Script/Body.gd",
			# - Tail
		"res://Modules/SrDraconicSeaMons/Dragonite/Script/Tail.gd",
			# - Penis
		"res://Modules/SrDraconicSeaMons/Dragonite/Script/Penis.gd",
		
	]
