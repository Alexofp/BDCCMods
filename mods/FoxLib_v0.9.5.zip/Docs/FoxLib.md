# FoxLib

This is the all-purpose documentation, this will go you over most FoxLib mod features, but only at a surface level.

Also, please check out: <https://github.com/Alexofp/BDCC/blob/main/Modules/Module.gd>

To add basic content you can do:
```gdscript
func _init():
	fetishes = ["res://Modules/MyModule/MyFetish.gd"]
```

Also, you can check [FoxLib ModHelper documentation](FoxLibModHelper.md) if you want an easy way to make zips of your mods.

## Getting started

To use most FoxLib APIs you should either replace `extends Module` with `extends "res://FoxLib/FoxModule.gd"`,
or have your module have a `func onFoxLibModInit(foxModuleAPI):` method,
the documentations will explicitly tell you if and when you don't need to do that.  
(If you use [FoxLib ModHelper](FoxLibModHelper.md), you can use `extends FoxModule` instead)

`FoxModule` auto imports `FoxGameRegistry` for you inside your module, to call `FoxGameRegistry` outside of your module, you need to add 
`const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")` at the beginning of your code, just under your `extends` statement.

## CrotchBlocks

To make a crotch block you want to extend `extends "res://FoxLib/FoxCrotchBlock.gd"` and check existing implementations, you can check the `CrotchBlocks` folder in `FoxLib`.

Then, when you made your crotch block, register them by adding this line in the `_init` part of your module:
- `crotchBlocks = [ "res://Modules/MyModule/CrotchBlocks/MyBlock.gd", ]`

Note: Internal Modules IDs are derived by file name, renaming files may break existing datapacks using custom blocks from your mod.

### CrotchBlocks removal/deprecation

When your block is deprecated for removal, you should keep the file name, but don't register it, this will hide the block from the editor sidebar.

Then make the block use the special theme designed for such an event:
```gdscript
func getVisualBlockTheme():
	return themeDeprecated
```

This will help datapack creators migrate away from your block before it's fully removed.

## Skill perk tiers

To make a custom skill perk tier, you just have to call the following in your module:
- `FoxGameRegistry.addPerkTierLevel(skillID, tierLevelRequirement)` (Example: `FoxGameRegistry.addPerkTierLevel("Fertility", 15)`)

Note: FoxLib can handle multiple mods register the same perk tier level.

When getting the skill tier, you should use the `getPerkTierForLevel` API, example:
```gdscript
func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)
```

You may need to add `const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")` under `extends PerkBase` statement to use `FoxGameRegistry`

## UI Elements

To use `FoxUIManager` outside of your module, you should add `const FoxUIManager = preload("res://FoxLib/FoxUIManager.gd")` to your script file.

FoxLib will open the console on game load, and close it automatically when loading finished, 
if some noteworthy error appear in the console, you can keep the console open after the game has finished loading with:
- `FoxUIManager.setHideConsoleAfterLoading(false)`

If you have an error that would prevent the game from starting, you can use the following API to show an error screen to the user:
- `FoxUIManager.fatalError("Something went terribly wrong in my mod")`

You can use [Godot 3.5 supported BBCodes](https://docs.godotengine.org/en/3.5/tutorials/ui/bbcode_in_richtextlabel.html) to format your error message however you want.

## Config

Sometimes you want to allow users to configure your mod, `FoxModule` has you covered.

You can register a config option like this:

```gdscript
extends "res://FoxLib/FoxModule.gd"

# If a var matches with your config ID, the config option will be sycronized with the config value
var configID
var configNumber
var configDrink

func _init():
    id = "MyModule"
    self.addBooleanOption("configID", "Config name", "Config Description")
    self.addNumberOption("configNumber", "Config number", "Coolnumber option description", 10)
    self.addListOption("configDrink", "Drink?", [["water", "Water"], ["tea", "Tea"], ["beer", "Beer"], ["coffee", "Coffee"]], "Pick a drink", "water")
```

Note: `self.` is optional, but is present in this example to make the code more explicit.

Or if you do not want to hard depends on FoxLib, you can do the following:

```gdscript
extends Module

# If a var matches with your config ID, the config option will be sycronized with the config value
var configID = false
var configNumber = 10
var configDrink = "water"

func _init():
    id = "MyModule"

func onFoxLibModInit(foxModuleAPI):
    foxModuleAPI.addBooleanOption("configID", "Config name", "Config Description")
    foxModuleAPI.addNumberOption("configNumber", "Config number", "Coolnumber option description", 10)
    foxModuleAPI.addListOption("configDrink", "Drink?", [["water", "Water"], ["tea", "Tea"], ["beer", "Beer"], ["coffee", "Coffee"]], "Pick a drink", "water")
```

Note: `onFoxLibModInit()` will only be called when FoxLib 0.4.0+ is present.

All of these return a `FoxModule` object and can be used to further customize your custom Option.

You can use the following API on FoxOption to customize it:
- `.advanced()`: Tell to only show this option is "Show advanced mod options is checked"
- `.bindToField(instance, field)`: Allow to bind the option to a specific field (Currently: only one field can be bound to an option at a time)

Example where advanced options must be checked to be able to pick how much they like some fruits:
```gdscript
extends "res://FoxLib/FoxModule.gd"

# If a var matches with your config ID, the config option will be sycronized with the config value
var fruits = ["Banana", "Apples", "Oranges"]
var fruistTastes = {} 

func _init():
    id = "MyModule"
    var tasteList = [[-2, "Terrible"], [-1, "Bad"], [0, "IDK"], [1, "Good"], [2, "Great"]]
    for fruit in fruits:
        self.addListOption("taste" + fruit, "Taste of " + fruit, tasteList, "How much you like " + fruit, 0).bindToField(fruistTastes, fruit).advanced()
```

And if you want to check for the config option in another class you can use `Globals`:

```gdscript
const Globals = preload("res://FoxLib/Globals.gd")

func doSomething():
    if Globals.ofModule("MyModule").configID:
        Log.print("ConfigID is active")
    Log.print("Doing number: " + str(Globals.ofModule("MyModule").configNumber))
    Log.print("I like " + Globals.ofModule("MyModule").configDrink)
```

FoxLib will manage the storage and display of your configuration options, to store your own option on your own, you can override the `FoxOption` class

To control a FoxLib option, you can use the following methods:
- `getOptionValue()`: Get the current option value
- `setOptionValue(newValue)`: Set option value
- `resetOptionValue()`: Reset the option to its default value

## Prevent your mod from being loaded twice

FoxLib has a function to prevent your mod from being loaded twice, if you named your manifest `MyModule.json`,
you can call `swapLoadedModNameOrShowError("MyModule")` on `foxModuleAPI` or your `FoxModule`,
if your module id match your json name `swapLoadedModNameOrShowError()` is an equivalent to `swapLoadedModNameOrShowError(self.id)`.

This will aditionally replace your mod name by an unversioned version of it, to allow datapack depending on
your mod to not be forced to depend on a specific version of your mod.

## Events

Events are functions that can be added into your Module, these don't require you to extends `res://FoxLib/FoxModule.gd`

- `onLoadingFinishing()` is called after game has finished loading game data
  (Useful to register items or game content at the last minute)
- `onLoadingFinished()` is called after game and mods has finished loading game data
- `onGameLoading()` is called when the game is loading a save file
  (This is may be called early in data loading, so all data may not be loaded yet)
- `onNewDay(pc)` is called when a new day passes (only called on player)
- `onFightStart(npc, context)` called when fight is starting. (called for player and NPCs)
- `onProcessBattleTurnContex(npc, context)` called when processing battle turn. (called for player and NPCs)
- `onFightEnd(npc, context)` called when fight has ended. (called for player and NPCs)
- `onSexStarted(npc, context)` called when sex is starting. (called for player and NPCs)
- `onProcessSexTurnContex(npc, context)` called when processing sex turn. (called for player and NPCs)
- `onSexEvent(npc, context)` called when a sex has been triggered. (called for player and NPCs)
- `onSexEnded(npc, context)` called when sex has ended. (called for player and NPCs)
- `onSceneChanged(newScene)` called when the current Godot scene has changed.
- `onModsOptionScreenClosed()` called when the mods options screen is closed.
- `onFoxLibModInit(foxModuleAPI)` called when FoxLib is present, allow to use FoxLib Module APIs without extending FoxModule.

