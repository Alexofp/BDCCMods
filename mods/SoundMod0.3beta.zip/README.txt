In terms of this mod, a sound pack is a folder with 8 subfolders, each subfolder contains a variant of a single sound effect. Also, credit the voicepack author by placing a link to their socials inside the pack folder. For example:

pack_fem-1/                     <- pack will be named whatever is after _ in this case "fem-1"
    Credit @author name.url    <- format for crediting voicepack author (link to their socials)
    sounds_orgasm/              <- sound effect, must have exact name
        soundclip.ogg           <- clips can be named whatever, but must be .ogg or .mp3
        soundclip2.mp3
        bazinga.ogg

When a sound effect is played, one clip is chosen at random. Only one sound effect should play at a time, and the highest priority sound effect is played. There are 4 sound effects as of version 1.0. In order of priority, these are:
Struggle = plays when pc tries to remove a restraint
Orgasm = plays when pc has an orgasm
Pleasure = plays when pc's Arousal stat increases
Tease = plays when pc's Lust stat increases

Try to choose shorter clips, FoxLib's audio manager always plays the full duration of the clip. Also, no looping is possible for now. Sound files will probably need to be imported by Godot so use the editor for that. Check https://github.com/Alexofp/BDCC/wiki for how to get it.

A sound pack MUST have these subfolders with these exact names (it's okay if they are empty folders), or else the mod won't find it:
sounds_orgasm
sounds_orgasm_gagged
sounds_pleasure
sounds_pleasure_gagged
sounds_struggle
sounds_struggle_gagged
sounds_tease
sounds_tease_gagged
