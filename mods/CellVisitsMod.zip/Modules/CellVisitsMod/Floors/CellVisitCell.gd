extends SubGameWorld

func _on_CellRoom_onEnter(room):
	var npcID = GM.main.getModuleFlag("CellVisitsMod", "cellNpcID", "")
	var npcName = GM.main.getModuleFlag("CellVisitsMod", "cellNpcName", "someone")
	var isNight = GM.main.isVeryLate()
	var isSleeping = GM.main.getModuleFlag("CellVisitsMod", "cellNpcSleeping", false)

	if npcID != "":
		if !GM.main.IS.hasPawn(npcID):
			var _p = GM.main.IS.spawnPawnIfNeeded(npcID)
		var pawn = GM.main.IS.getPawn(npcID)
		if pawn != null:
			pawn.setLocation("cellvisits_cell_interior")

	if npcID != "" and npcName != "":
		if isNight and isSleeping:
			room.sayn("You slip inside " + npcName + "'s cell. The door clicks shut behind you. " + npcName + " is fast asleep on the bunk, oblivious to your presence.")
		elif isNight:
			room.sayn("You step inside " + npcName + "'s cell. The door clicks shut behind you. " + npcName + " is sitting on the edge of their bed, looking at you in the dim light.")
		else:
			room.sayn("You step inside " + npcName + "'s cell. " + npcName + " is here, watching you from across the small room.")
	else:
		room.sayn("You step into the cell. It's cramped and bare.")

	if npcID != "" and isNight and isSleeping:
		room.addButton("Approach " + npcName, "Quietly step up to the sleeping " + npcName, "approach_sleeping")

	room.addButton("Leave cell", "Step back out into the corridor", "leave_cell")

func _on_CellRoom_onReact(_room, key):
	if key == "approach_sleeping":
		var npcID = GM.main.getModuleFlag("CellVisitsMod", "cellNpcID", "")
		if npcID != "":
			_room.runScene("CellVisitSleepingNpcScene", [npcID])
		return

	if key == "leave_cell":
		var returnLoc = GM.main.getModuleFlag("CellVisitsMod", "cellReturnLocation", "")

		var npcID = GM.main.getModuleFlag("CellVisitsMod", "cellNpcID", "")
		if npcID != "" and GM.main.IS.hasPawn(npcID):
			var pawn = GM.main.IS.getPawn(npcID)
			if pawn != null:
				pawn.setLocation(returnLoc)

		GM.main.setModuleFlag("CellVisitsMod", "cellNpcID", "")
		GM.main.setModuleFlag("CellVisitsMod", "cellNpcName", "")
		GM.main.setModuleFlag("CellVisitsMod", "cellNpcSleeping", false)
		GM.main.setModuleFlag("CellVisitsMod", "cellReturnLocation", "")

		if returnLoc != "":
			GM.pc.setLocation(returnLoc)
		else:
			GM.pc.setLocation("cellblock_orange_nearcell")
		GM.main.reRun()
