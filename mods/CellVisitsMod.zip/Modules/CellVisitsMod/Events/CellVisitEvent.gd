extends EventBase

const RAID_ROOMS = [
	"cellblock_orange_nearcell",
	"cellblock_lilac_nearcell",
	"cellblock_red_nearcell",
]

const ROOM_TO_BLOCK = {
	"cellblock_orange_nearcell": "orange",
	"cellblock_lilac_nearcell": "lilac",
	"cellblock_red_nearcell": "red",
}

const BLOCK_NAMES = {
	"orange": "General-security cellblock",
	"lilac": "Lilac cellblock",
	"red": "High-security cellblock",
}

func _init():
	id = "CellVisitEvent"

func registerTriggers(es):
	for roomID in RAID_ROOMS:
		es.addTrigger(self, Trigger.EnteringRoom, roomID)

func run(_triggerID, _args):
	var currentRoom = GM.pc.getLocation()
	if !(currentRoom in RAID_ROOMS):
		return
	if GM.main.isInDungeon():
		return
	var blockID = ""
	if ROOM_TO_BLOCK.has(currentRoom):
		blockID = ROOM_TO_BLOCK[currentRoom]
	if blockID == "":
		return
	var blockName = "Unknown block"
	if BLOCK_NAMES.has(blockID):
		blockName = BLOCK_NAMES[blockID]
	addButton("Inspect cells", "Look through the cells in the " + blockName, "cell_raid_start", [blockID])

func onButton(_method, _args):
	if _method == "cell_raid_start":
		if _args.size() > 0:
			runScene("CellVisitScene", [_args[0]])
		else:
			runScene("CellVisitScene")

func getPriority():
	return 5
