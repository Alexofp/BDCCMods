extends Module

func _init():
	id = "CellVisitsMod"
	author = "bebrenkov"

	GlobalRegistry.registerMapFloor("CellVisitsCellFloor", "res://Modules/CellVisitsMod/Floors/CellVisitCell.tscn")

	scenes = [
		"res://Modules/CellVisitsMod/Scenes/CellVisitScene.gd",
		"res://Modules/CellVisitsMod/Scenes/CellVisitSleepingNpcScene.gd",
	]
	events = [
		"res://Modules/CellVisitsMod/Events/CellVisitEvent.gd",
	]

func getFlags():
	return {
		"cellNpcID": flag(FlagType.Text),
		"cellNpcName": flag(FlagType.Text),
		"cellReturnLocation": flag(FlagType.Text),
		"cellNpcSleeping": flag(FlagType.Bool),
	}
