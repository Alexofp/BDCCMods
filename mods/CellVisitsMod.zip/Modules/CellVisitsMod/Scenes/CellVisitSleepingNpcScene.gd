extends "res://Scenes/SceneBase.gd"

var npcID: String = ""
var npcName: String = "them"
var wokeByItem: bool = false

func _init():
	sceneID = "CellVisitSleepingNpcScene"

func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	var character = GlobalRegistry.getCharacter(npcID)
	if character != null and character.has_method("getName"):
		npcName = character.getName()

func _getPills() -> Array:
	var result = []
	var inv = GM.pc.getInventory()
	if inv == null:
		return result
	for item in inv.getItems():
		if item.has_method("canUseInCombat") && item.canUseInCombat():
			result.append(item)
	return result

func _run():
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		saynn("The bunk is empty now. Whoever slept here is gone.")
		addButton("Leave", "Step back out", "endthescene")
		return

	addCharacter(npcID)
	if state == "woke":
		playAnimation(StageScene.Duo, "stand", {npc = npcID, npcAction = "sit"})
	else:
		playAnimation(StageScene.Sleeping, "sleep", {pc = npcID, hideNPC = true})

	if state == "":
		saynn("[b]" + npcName + "[/b] is fast asleep, curled up on the narrow cell bunk. Their chest rises and falls slowly -- they have no idea you're standing over them.")
		saynn("What do you want to do?")

		addButton("Leave", "Slip back out without waking " + npcName, "endthescene")
		addButton("Wake up", "Shake " + npcName + " awake so you can talk to them", "wake_up")
		addButton("Start sex scene", "Quietly climb onto the sleeping " + npcName, "start_sex")

		var pills = _getPills()
		if pills.size() > 0:
			addButton("Give item... (" + str(pills.size()) + " available)", "Force a pill or usable item into the sleeping " + npcName + "'s mouth.", "open_pill")
		else:
			addDisabledButton("Give item...", "You have no usable items in your inventory.")
		return

	if state == "woke":
		if wokeByItem:
			saynn(npcName + " coughs, splutters and jolts upright on the bunk, eyes wide open. They blink at you in the dim light, trying to work out what just happened.")
		else:
			saynn("You grab " + npcName + " by the shoulder and shake them until their eyes flutter open. They blink up at you in the dim light, confused at first, then sit up on the bunk.")
		saynn("[b]" + npcName + ":[/b] \"Wh.. what? How did you get in here?\"")
		saynn(npcName + " is awake now. You can talk to them like usual.")
		addButton("Continue", "Step back", "endthescene")
		return

	if state == "pill":
		saynn("You fish through your belongings for something to slip into the sleeping " + npcName + "'s mouth.")
		var pills = _getPills()
		if pills.size() == 0:
			saynn("You have no usable items left.")
			addButton("Back", "Never mind", "go_main")
			return
		for i in range(pills.size()):
			var pill = pills[i]
			var desc = pill.getDescription() if pill.has_method("getDescription") else ""
			addButton(pill.getVisibleName(), desc, "give_pill", [i])
		addButton("Back", "Put your items away", "go_main")
		return

func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return

	if _action == "go_main":
		setState("")
		return

	if _action == "open_pill":
		setState("pill")
		return

	if _action == "wake_up":
		_doWakeUp()
		return

	if _action == "start_sex":
		runScene("GenericSexScene", ["pc", npcID])
		return

	if _action == "give_pill":
		if _args.size() >= 1:
			_doGivePill(int(_args[0]))
		if state != "woke":
			setState("")
		return

	setState(_action)

func _doGivePill(pillIndex: int):
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		addMessage("Couldn't find that character.")
		return

	var pills = _getPills()
	if pillIndex < 0 || pillIndex >= pills.size():
		addMessage("That item is no longer in your inventory.")
		return

	var pill = pills[pillIndex]
	var resultMsg = pill.useInCombat(GM.pc, character)
	if resultMsg == null || resultMsg == "":
		resultMsg = pill.getVisibleName() + " was used."
	addMessage("You carefully tip " + pill.getVisibleName() + " into the sleeping " + character.getName() + "'s mouth. " + resultMsg)
	if RNG.chance(30):
		_markAwake()
		wokeByItem = true
		setState("woke")
		return

func _doWakeUp():
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		endScene()
		return
	GM.main.setModuleFlag("CellVisitsMod", "cellNpcSleeping", false)
	processTime(60)
	setState("woke")

func _markAwake():
	GM.main.setModuleFlag("CellVisitsMod", "cellNpcSleeping", false)

func supportsShowingPawns() -> bool:
	return false

func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["npcName"] = npcName
	data["wokeByItem"] = wokeByItem
	return data

func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npcName = SAVE.loadVar(data, "npcName", "them")
	wokeByItem = SAVE.loadVar(data, "wokeByItem", false)
