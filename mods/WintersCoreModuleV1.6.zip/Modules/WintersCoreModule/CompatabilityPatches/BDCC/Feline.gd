extends "res://Species/Feline.gd"

var maleBoobs = [] 
var femaleBoobs = []

func _init():
	var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())
	var hasBoob = ("WintersBreastExpansion" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & BreastsExpanded
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "felinetail"

func getDefaultHead(_gender):
	return "felinehead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "felineears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return RNG.pick(maleBoobs)
	return RNG.pick(femaleBoobs)

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersExpandedPenises" in GlobalRegistry.getModules()):
			return "barbedfluffypenis"
		else:
			return "felinepenis"
	else:
		return null
