extends BodypartPenis

func _init():
	visibleName = "knotted barbed penis"
	id = "caninepenisbarb"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine", "barbed",])

func getDoll3DScene():
	return "res://Modules/WintersCanineBarbedPenis/Penis/CaninePenisBarb.tscn"
	
func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "knotted and barbed hybrid cock"
