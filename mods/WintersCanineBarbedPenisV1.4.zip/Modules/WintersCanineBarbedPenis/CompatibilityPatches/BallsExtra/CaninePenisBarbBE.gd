extends "res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd"

func _init():
	visibleName = "Barbed canine penis"
	id = "caninepenisbarb"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine", "barbed",])

func getDoll3DScene():
	return "res://Modules/WintersCanineBarbedPenis/Penis/CaninePenisBarb.tscn"
	
func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
	}

func generateRandomColors(_dynamicCharacter):
	pass
