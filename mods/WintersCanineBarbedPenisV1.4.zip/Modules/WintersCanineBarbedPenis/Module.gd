extends Module

func _init():
	id = "WintersCanineBarbed"
	author = "Avery Winters (Code Improvements: Selinoccino)"

	partSkins = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersCanineBarbedPenis/Skins/")

func register(): # best to do it here
	.register() # call our parent script's one first

	var modules = GlobalRegistry.getModules().keys() # to avoid calling too many times, and also only getting the keys for performance reasons kinda

	#Bodyparts
	if ("BallsExtra" in modules):
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersCanineBarbedPenis/CompatibilityPatches/BallsExtra/"):
			GlobalRegistry.registerBodypart(bp)
	else:
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersCanineBarbedPenis/Penis/"):
			GlobalRegistry.registerBodypart(bp)
