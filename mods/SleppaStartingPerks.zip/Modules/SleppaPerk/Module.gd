extends Module

func _init():
	id = "SleppaPerk"
	author = "Sleppa"

	perks = [
		
		"res://Modules/SleppaPerk/Perk/StartBreedResist.gd",
		"res://Modules/SleppaPerk/Perk/StartDominatable.gd",
		"res://Modules/SleppaPerk/Perk/StartFalteringResiliance.gd",
		"res://Modules/SleppaPerk/Perk/StartHypersensitive.gd",
		"res://Modules/SleppaPerk/Perk/StartNoMilk.gd",
		"res://Modules/SleppaPerk/Perk/StartPartnerCum.gd",
		"res://Modules/SleppaPerk/Perk/StartPitiful.gd",
		"res://Modules/SleppaPerk/Perk/StartQuenchableHeat.gd",
		"res://Modules/SleppaPerk/Perk/StartResilient.gd",
		"res://Modules/SleppaPerk/Perk/StartShame.gd",
	]

	statusEffects = [
		"res://Modules/SleppaPerk/StatusEffect/ExhaustedBalls.gd",
		"res://Modules/SleppaPerk/StatusEffect/OveractiveBalls.gd",
		"res://Modules/SleppaPerk/StatusEffect/PainfulShame.gd",
		"res://Modules/SleppaPerk/StatusEffect/Dominance.gd",
	]
