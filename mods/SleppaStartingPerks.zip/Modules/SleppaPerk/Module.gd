extends Module

func _init():
	id = "SleppaPerk"
	author = "Sleppa"

	perks = [
		
		"res://Modules/SleppaPerk/Perk/StartBreedResist.gd",
		"res://Modules/SleppaPerk/Perk/StartNoMilk.gd",
		"res://Modules/SleppaPerk/Perk/StartPitiful.gd",
		"res://Modules/SleppaPerk/Perk/StartResilient.gd",
		"res://Modules/SleppaPerk/Perk/StartShame.gd",
		"res://Modules/SleppaPerk/Perk/StartPartnerCum.gd",
	]

	statusEffects = [
		"res://Modules/SleppaPerk/StatusEffect/ExhaustedBalls.gd",
		"res://Modules/SleppaPerk/StatusEffect/OveractiveBalls.gd",
		"res://Modules/SleppaPerk/StatusEffect/PainfulShame.gd",
	]
