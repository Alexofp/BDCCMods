extends StatusEffectBase

func _init():
	id = "SleppaOveractiveBalls"
	isBattleOnly = false

func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 1.5*60*60

func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		character.addEffect("SleppaExhaustedBalls")
		stop()

func getEffectName():
	return "Overactive balls"

func getEffectDesc():
	return "Your balls are in overdrive.. "+Util.getTimeStringHumanReadable(turns)

func getEffectImage():
	return "res://Modules/SleppaPerk/Images/balls-swell.png"

func getIconColor():
	return DamageType.getColor(DamageType.Lust)

func combine(_args = []):
	turns = turns + (30*60)
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	return [
		buff(Buff.PenisCumProductionBuff, [900]),
		buff(Buff.PenisBallsVolumeBuff, [20]),
	]

func saveData():
	return {
		"turns": turns,
	}
	
func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 60*60)
