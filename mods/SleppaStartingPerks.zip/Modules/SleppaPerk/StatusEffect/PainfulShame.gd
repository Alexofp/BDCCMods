extends StatusEffectBase

func _init():
	id = "SleppaShame"
	isBattleOnly = false

func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 4*60*60

func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()

func getEffectName():
	return "Painful shame"

func getEffectDesc():
	return "Overwhelming shame is taking a toll on you.. "

func getEffectImage():
	return "res://Modules/SleppaPerk/Images/shame.png"

func getIconColor():
	return IconColorRed

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	return [
		buff(Buff.AmbientPainBuff, [90.0])
		]

func saveData():
	return {
		"turns": turns,
	}
	
func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 60*60)
