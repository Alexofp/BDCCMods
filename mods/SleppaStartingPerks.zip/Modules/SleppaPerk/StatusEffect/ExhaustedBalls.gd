extends StatusEffectBase

func _init():
	id = "SleppaExhaustedBalls"
	isBattleOnly = false

func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 8*60*60

func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()

func getEffectName():
	return "Exhausted balls"

func getEffectDesc():
	return "Your balls are recovering.. "+Util.getTimeStringHumanReadable(turns)

func getEffectImage():
	return "res://Modules/SleppaPerk/Images/balls_hurt.png"

func getIconColor():
	return IconColorRed

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	return [
		buff(Buff.PenisCumProductionBuff, [-50]),
		buff(Buff.PenisBallsVolumeBuff, [-50]),
		buff(Buff.MaxStaminaBuff, [-20]),
	]

func saveData():
	return {
		"turns": turns,
	}
	
func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 60*60)
