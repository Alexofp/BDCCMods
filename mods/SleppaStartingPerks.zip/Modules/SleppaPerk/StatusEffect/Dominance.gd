extends StatusEffectBase

var stacks = 0

func _init():
	id = "SleppaDominance"
	isBattleOnly = false
	isSexEngineOnly = false
	
func initArgs(_args = []):
	if(_args.size() > 0):
		stacks = _args[0]
	else:
		stacks = 1
	
func processBattleTurn():
	pass
	
func processTime(_secondsPassed: int):
	pass

func getEffectName():
	return "Dominance x"+str(stacks)

func getEffectDesc():
	if(stacks <= 1):
		return "You feel powerful after dominating someone"
	if(stacks <= 4):
		return "You really put someone in their place. You feel very powerful"
	
	return "You are a mighty, dominating beast!"

func getEffectImage():
	return "res://Modules/SleppaPerk/Images/domination.png"

func getIconColor():
	if(stacks <= 3):
		return IconColorGreen
	if(stacks <= 5):
		return IconColorYellow
	return IconColorRed

func combine(_args = []):
	if(_args.size() > 0):
		stacks += _args[0]
	else:
		stacks += 1

	if(stacks <= 0):
		stop()

func saveData():
	return {
		"stacks": stacks,
	}
	
func loadData(_data):
	stacks = SAVE.loadVar(_data, "stacks", 1)

func getBuffs():
	return [
		buff(Buff.VirilityBuff, [10*(stacks)]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [10*stacks]),
		buff(Buff.PenisBallsVolumeBuff, [5*stacks]),
		buff(Buff.PenisCumProductionBuff, [10*stacks]),
		#buff(Buff.PenisCumGenerationAfterOrgasmBuff, [5*stacks]),
		buff(Buff.LustArmorBuff, [2.5*stacks]),
		buff(Buff.LustDamageBuff, [2.5*stacks]),
		buff(Buff.PhysicalArmorBuff, [2.5*stacks]),
		buff(Buff.PhysicalDamageBuff, [2.5*stacks]),
		buff(Buff.DodgeChanceBuff, [2*stacks]),
		#buff(Buff.MeleeDamageBuff, [5*stacks]),
		buff(Buff.MaxLustBuff, [10*stacks]),
		buff(Buff.MaxPainBuff, [10*stacks]),
		buff(Buff.MaxStaminaBuff, [15*stacks]),
		buff(Buff.RestraintForcingSuccessBuff, [7.5*stacks]),
		buff(Buff.StaminaRecoverAfterSexBuff, [10*stacks]),
		]
		
#func onSexStarted(_contex = {}):
#	if(stacks >= 5):
#		character.addEffect("SexAngry")
	
func onFightStart(_contex = {}):
	if(stacks >= 5):
		character.addEffect(StatusEffect.AuraOfDominance)
	#GM.main.addMessage("Fight Started")

func onSexEvent(_event:SexEvent):
	# Does this actually work? Fuck if I know! :D
	if(_event.getType() == SexEvent.Orgasmed):
		var targetChar = _event.getTargetChar()
		if targetChar != character or not _event.targetIsDom():
			return
		var cumAgainChance = stacks*10
		if cumAgainChance > 50:
			cumAgainChance = 50
		if(RNG.chance(cumAgainChance)):
			var theSexEngine = GM.main.getSexEngineForCharacterID(character.getID())
			var domInfo = theSexEngine.getDomInfo(character.getID())
			domInfo.hasAnyCumGoals = true

func processSexTurn():
	var theSexEngine = GM.main.getSexEngineForCharacterID(character.getID())
	var domInfo = theSexEngine.getDomInfo(character.getID())
	if not theSexEngine.isDom(character.getID()):
		return
	var anger = domInfo.anger
	var angerLimit = (stacks/20)
	#GM.main.addMessage("Anger:"+str(anger)+" and limit:"+str(angerLimit))
	if angerLimit > .75:
		angerLimit = .75
	if anger > (1 - angerLimit):
		character.addEffect("SexAngry")
		GM.main.addMessage(str(character.getName())+" has lost patience with you, and is now extremely angry!")
		
	#GM.main.addMessage(str()+" This exists")
func onFightEnd(_contex = {}):
	var fightScene = GM.main.getCurrentFightScene()
	var battleState = fightScene.battleState
	
	if battleState == "win" and not character.isPlayer():
		if stacks > 1:
			stacks = stacks - 1
			GM.main.addMessage(str(character.getName())+" lost a level of dominance!")
		else:
			GM.main.addMessage(str(character.getName())+" has had their dominance extinguished!")
			character.removeEffect("SleppaDominance")
	elif battleState == "lost" and character.isPlayer():
		if stacks > 1:
			stacks = stacks - 1
			GM.main.addMessage("You lost a level of dominance!")
		else:
			GM.main.addMessage("You had your dominance extinguished!")
			character.removeEffect("SleppaDominance")
