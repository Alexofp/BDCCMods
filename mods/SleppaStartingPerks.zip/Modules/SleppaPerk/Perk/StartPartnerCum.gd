extends PerkBase

func _init():
	id = "SleppaStartPartnerCum"
	skillGroup = Skill.Start

func getVisibleName():
	return "Stimulating hormones"

func getVisibleDescription():
	return "When someone penetrates you in a hole with a womb, their balls will be sent into overdrive, producing cum at an excessive rate for a short time"

func getSkillTier():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"

func getBuffs():
	return [
	]
			
func onSexEvent(_event:SexEvent):
	if(_event.getType() != SexEvent.HolePenetrated):
		return
		
	if(_event.getTargetChar() != npc):
		return
	
	if(not _event.getTargetChar().hasWombIn(_event.getField("hole", BodypartSlot.Vagina))):
		return
		
	if(_event.getSourceChar().getWornCondom() != null):
		return
	
	if(_event.getSourceChar().isWearingStrapon()):
		return
	
	if(_event.getSourceChar().hasEffect("SleppaExhaustedBalls")):
		return
		

	
	if(_event.getSourceChar().hasEffect("SleppaOveractiveBalls")):
		_event.getSourceChar().addEffect("SleppaOveractiveBalls")
		if(_event.getTargetChar().isPlayer()):
			GM.main.addMessage("A fresh, invigorating surge flows through their balls!")
		elif(_event.getSourceChar().isPlayer()):
			GM.main.addMessage("A fresh, invigorating surge flows through your balls!")
			
	else:
		if(_event.getTargetChar().isPlayer()):
			_event.getSourceChar().addEffect("SleppaOveractiveBalls")
			GM.main.addMessage("Your hormones invigorate their balls! They rapidly fill with cum")
		elif(_event.getSourceChar().isPlayer()):
			GM.main.addMessage("Powerful hormones invigorate your balls! They rapidly fill with cum")
