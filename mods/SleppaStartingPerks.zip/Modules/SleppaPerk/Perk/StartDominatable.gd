extends PerkBase

func _init():
	id = "SleppaStartDominatable"
	skillGroup = Skill.Start

func getVisibleName():
	return "Satisfying to Dominate"

func getVisibleDescription():
	return "When a dom cums inside of you, they gain multiple permanent stacking buffs and perks. Can you withstand the ever-increasing onslaught from your fellow prisoners?"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0
	
func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/SleppaPerk/Images/domination.png"

func getBuffs():
	return [
	]

func add_dom_level(sourcechar):
	if(sourcechar.hasEffect("SleppaDominance")):
		GM.main.addMessage(sourcechar.getName()+" gains a new level of dominance!")
	else:
		GM.main.addMessage(sourcechar.getName()+" feels a surge of dominance over you!")\
		
	sourcechar.getSkillsHolder().setLevel(sourcechar.getSkillsHolder().getLevel() + 1)
	sourcechar.getPersonality().addStat(PersonalityStat.Subby, RNG.randf_range(-0.075, -0.025))
	sourcechar.addEffect("SleppaDominance")
	
func give_perks(sourcechar):
	var perkchance = 4 + sourcechar.getSkillsHolder().getLevel()
	
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumProductionV2) && not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumProductionV3):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedCumProductionV3)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumProductionV3).getVisibleName()+" perk!")
		elif sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumProduction) && not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumProductionV2):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedCumProductionV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumProductionV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumProduction):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedCumProduction)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumProduction).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumVolumeV2) && not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumVolumeV3):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedCumVolumeV3)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumVolumeV3).getVisibleName()+" perk!")
		elif sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumVolume) && not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumVolumeV2):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedCumVolumeV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumVolumeV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumVolume):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedCumVolume)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumVolume).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BreedRapidConception):
		sourcechar.getSkillsHolder().addPerk(Perk.BreedRapidConception)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedRapidConception).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BreedBreedersBliss):
		sourcechar.getSkillsHolder().addPerk(Perk.BreedBreedersBliss)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedBreedersBliss).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCockSlap):
		sourcechar.getSkillsHolder().addPerk(Perk.BreedCockSlap)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCockSlap).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BreedCumInflationHeat):
		sourcechar.getSkillsHolder().addPerk(Perk.BreedCumInflationHeat)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedCumInflationHeat).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BreedStreak):
		sourcechar.getSkillsHolder().addPerk(Perk.BreedStreak)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedStreak).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.BreedStud) && not sourcechar.getSkillsHolder().hasPerk(Perk.BreedStudV2):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedStudV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedStudV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.BreedStud):
			sourcechar.getSkillsHolder().addPerk(Perk.BreedStud)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BreedStud).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.SexLustPassionV2) && not sourcechar.getSkillsHolder().hasPerk(Perk.SexLustPassionV3):
			sourcechar.getSkillsHolder().addPerk(Perk.SexLustPassionV3)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.SexLustPassionV3).getVisibleName()+" perk!")
		elif sourcechar.getSkillsHolder().hasPerk(Perk.SexLustPassion) && not sourcechar.getSkillsHolder().hasPerk(Perk.SexLustPassionV2):
			sourcechar.getSkillsHolder().addPerk(Perk.SexLustPassionV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.SexLustPassionV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.SexLustPassion):
			sourcechar.getSkillsHolder().addPerk(Perk.SexLustPassion)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.SexLustPassion).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.SexIntoxicationBonus):
		sourcechar.getSkillsHolder().addPerk(Perk.SexIntoxicationBonus)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.SexIntoxicationBonus).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.SexBiter):
		sourcechar.getSkillsHolder().addPerk(Perk.SexBiter)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.SexBiter).getVisibleName()+" perk!")
		
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.NakedNoShame):
		sourcechar.getSkillsHolder().addPerk(Perk.NakedNoShame)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.NakedNoShame).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.NakedExtraStamina) && not sourcechar.getSkillsHolder().hasPerk(Perk.NakedExtraStaminaV2):
			sourcechar.getSkillsHolder().addPerk(Perk.NakedExtraStaminaV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.NakedExtraStaminaV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.NakedExtraStamina):
			sourcechar.getSkillsHolder().addPerk(Perk.NakedExtraStamina)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.NakedExtraStamina).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.NakedDodgingV2) && not sourcechar.getSkillsHolder().hasPerk(Perk.NakedDodgingV3):
			sourcechar.getSkillsHolder().addPerk(Perk.NakedDodgingV3)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.NakedDodgingV3).getVisibleName()+" perk!")
		elif sourcechar.getSkillsHolder().hasPerk(Perk.NakedDodging) && not sourcechar.getSkillsHolder().hasPerk(Perk.NakedDodgingV2):
			sourcechar.getSkillsHolder().addPerk(Perk.NakedDodgingV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.NakedDodgingV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.NakedDodging):
			sourcechar.getSkillsHolder().addPerk(Perk.NakedDodging)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.NakedDodging).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.MilkNoSoreNipples):
		sourcechar.getSkillsHolder().addPerk(Perk.MilkNoSoreNipples)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.MilkNoSoreNipples).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.FertilityPainTolerance):
		sourcechar.getSkillsHolder().addPerk(Perk.FertilityPainTolerance)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.FertilityPainTolerance).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.FertilityBroodmother):
		sourcechar.getSkillsHolder().addPerk(Perk.FertilityBroodmother)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.FertilityBroodmother).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.CumWhoreStreak):
		sourcechar.getSkillsHolder().addPerk(Perk.CumWhoreStreak)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CumWhoreStreak).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.CumSlut):
		sourcechar.getSkillsHolder().addPerk(Perk.CumSlut)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CumSlut).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.CumSloppySeconds):
		sourcechar.getSkillsHolder().addPerk(Perk.CumSloppySeconds)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CumSloppySeconds).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.CumBreathV1) && not sourcechar.getSkillsHolder().hasPerk(Perk.CumBreathV2):
			sourcechar.getSkillsHolder().addPerk(Perk.CumBreathV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CumBreathV2).getVisibleName()+" perk!")
		elif sourcechar.getSkillsHolder().hasPerk(Perk.CumBreath) && not sourcechar.getSkillsHolder().hasPerk(Perk.CumBreathV1):
			sourcechar.getSkillsHolder().addPerk(Perk.CumBreathV1)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CumBreathV1).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.CumBreath):
			sourcechar.getSkillsHolder().addPerk(Perk.CumBreath)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CumBreath).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.CombatScratching):
		sourcechar.getSkillsHolder().addPerk(Perk.CombatScratching)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CombatScratching).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.CombatDrunkenMaster):
		sourcechar.getSkillsHolder().addPerk(Perk.CombatDrunkenMaster)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CombatDrunkenMaster).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.CombatFullStaminaBonus):
		sourcechar.getSkillsHolder().addPerk(Perk.CombatFullStaminaBonus)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.CombatFullStaminaBonus).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BDSMBondageSlut):
		sourcechar.getSkillsHolder().addPerk(Perk.BDSMBondageSlut)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BDSMBondageSlut).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance) and not sourcechar.getSkillsHolder().hasPerk(Perk.BDSMTallyMarks):
		sourcechar.getSkillsHolder().addPerk(Perk.BDSMTallyMarks)
		GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BDSMTallyMarks).getVisibleName()+" perk!")
			
	if RNG.chance(perkchance):
		if sourcechar.getSkillsHolder().hasPerk(Perk.BDSMRiggerV2) && not sourcechar.getSkillsHolder().hasPerk(Perk.BDSMRiggerV3):
			sourcechar.getSkillsHolder().addPerk(Perk.BDSMRiggerV3)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BDSMRiggerV3).getVisibleName()+" perk!")
		elif sourcechar.getSkillsHolder().hasPerk(Perk.BDSMRigger) && not sourcechar.getSkillsHolder().hasPerk(Perk.BDSMRiggerV2):
			sourcechar.getSkillsHolder().addPerk(Perk.BDSMRiggerV2)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BDSMRiggerV2).getVisibleName()+" perk!")
		elif not sourcechar.getSkillsHolder().hasPerk(Perk.BDSMRigger):
			sourcechar.getSkillsHolder().addPerk(Perk.BDSMRigger)
			GM.main.addMessage(sourcechar.getName()+" has gained the "+GlobalRegistry.getPerk(Perk.BDSMRigger).getVisibleName()+" perk!")
			
	
var fainted = false

func onSexStarted(_contex = {}):
	#fainted = false
	var consciousness = npc.getConsciousness()
	#GM.main.addMessage("Consciousness = "+str(consciousness))
	if consciousness <= 0:
		fainted = true
		#GM.main.addMessage("Is already fainted")
	else:
		fainted = false
		#GM.main.addMessage("Not already fainted")

func onSexEvent(_event:SexEvent):
	var sourcechar = _event.getSourceChar()
	
	if(_event.getTargetChar() != npc):
		return
	
	if(_event.sourceIsSub()):
		#GM.main.addMessage("Source is sub")
		return
	
	if(_event.targetIsDom()):
		#GM.main.addMessage("Target is dom")
		return
	#GM.main.addMessage("Event")
	
	if(_event.getType() == SexEvent.HoleCreampied):
		if(not _event.getTargetChar().hasWombIn(_event.getField("hole"))):
			#GM.main.addMessage("no womb")
			return
		#GM.main.addMessage("Got here")
		if(sourcechar.hasBodypart(BodypartSlot.Penis)):
			#GM.main.addMessage("Has Penis")
			var penis = sourcechar.getBodypart(BodypartSlot.Penis)
			var cumProduction = penis.getFluidProduction()
			var loadSize = _event.getField("loadSize", 0.0)
			if(cumProduction != null):
				#GM.main.addMessage("Produces cum")
				if(loadSize >= cumProduction.getCapacity()/2 or loadSize >= 500):
					#GM.main.addMessage("Has enough cum to dominate")
					#GM.main.addMessage(str(loadSize)+" of "+str(cumProduction.getCapacity()))
					add_dom_level(sourcechar)
					give_perks(sourcechar)
					
	elif (_event.getType() == SexEvent.PainInflicted) and fainted == false:
		var intentional = _event.getField("intentional", "")
		if(not intentional):
			return
		var consciousness = _event.getTargetChar().getConsciousness()
		if consciousness <= 0:
			#GM.main.addMessage("Do the stuff")
			fainted = true
			add_dom_level(sourcechar)
			give_perks(sourcechar)
	elif (_event.getType() == SexEvent.Choking) and fainted == false:
		var consciousness = _event.getTargetChar().getConsciousness()
		if consciousness <= 0:
			#GM.main.addMessage("Do the stuff")
			fainted = true
			add_dom_level(sourcechar)
			give_perks(sourcechar)

func onFightEnd(_contex = {}):
	var fightScene = GM.main.getCurrentFightScene()
	var battleState = fightScene.battleState
	var enemy = fightScene.enemyCharacter
	if battleState == "lost":
		add_dom_level(enemy)
		give_perks(enemy)
#	elif battleState == "win":
