extends PerkBase

func _init():
	id = "SleppaStartBreedResist"
	skillGroup = Skill.Start

func getVisibleName():
	return "Resistant to breeding"

func getVisibleDescription():
	return "You are not built for being bred. You start with decreased fertility. However, as soon as you give birth, this is replaced with decreased health and stamina (-5 each per child). Can you escape before someone puts a litter in you?"

func getSkillTier():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"

func getBuffs():
	var childcount = GM.CS.getChildrenAmountOfOnlyMother("pc")
	if(childcount > 0):
		return [
			buff(Buff.MaxPainBuff, [-5 * childcount]),
			buff(Buff.MaxStaminaBuff, [-5 * childcount]),
		]
	else:
		return [
			buff(Buff.OvulationEggsAmountBuff, [-50]),
			buff(Buff.FertilityBuff, [-85]),
		]
