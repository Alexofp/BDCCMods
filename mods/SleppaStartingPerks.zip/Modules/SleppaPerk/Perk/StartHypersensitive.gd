extends PerkBase

func _init():
	id = "SleppaStartHypersensitive"
	skillGroup = Skill.Start

func getVisibleName():
	return "Hypersensitive"

func getVisibleDescription():
	return "Every touch feels so much more intense to you"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/speedometer.png"

func getBuffs():
	return [
		buff(Buff.OverstimulationThresholdBuff, [-50.0]),
		buff(Buff.SensitivityGainBuff, [500.0]),
	]
