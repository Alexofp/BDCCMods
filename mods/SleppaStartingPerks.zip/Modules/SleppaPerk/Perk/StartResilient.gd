extends PerkBase

func _init():
	id = "SleppaStartResilient"
	skillGroup = Skill.Start

func getVisibleName():
	return "Resilient holes"

func getVisibleDescription():
	return "Your holes are more resistant to stretching"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/SleppaPerk/Images/Resilient.png"

func getBuffs():
	return [
		buff(Buff.GenitalResistanceBuff, [80.0]),
		buff(Buff.MinLoosenessVaginaBuff, [-20.0]),
		buff(Buff.MinLoosenessAnusBuff, [-20.0]),
		buff(Buff.MinLoosenessThroatBuff, [-20.0]),
		buff(Buff.GenitalElasticityBuff, [-50.0]),
	]
