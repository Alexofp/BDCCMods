extends PerkBase

func _init():
	id = "SleppaQuenchableHeat"
	skillGroup = Skill.Start

func getVisibleName():
	return "Quenchable Heat"

var cum_requirement = 1000

func getVisibleDescription():
	return "Your body can be tricked into ending heat early, but this requires flooding your womb with cum... Receiving "+str(cum_requirement)+"ml of cum in your womb will instantly end your heat"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0
	
func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/SleppaPerk/Images/extinguish.png"

func getBuffs():
	if not npc.isInHeat():
		return
	var menstrualCycle: MenstrualCycle = npc.getMenstrualCycle()
	if menstrualCycle == null:
		return
	if not menstrualCycle.hasAnyWomb():
		return
		
	var cumvolume = 0
	
	if(npc.hasBodypart(BodypartSlot.Anus)):
		var ass = npc.getBodypart(BodypartSlot.Anus)
		if ass.hasWomb():
			var assOrifice = ass.getOrifice()
			cumvolume = cumvolume + assOrifice.getFluidAmount()

	if(npc.hasBodypart(BodypartSlot.Vagina)):
		var pussy = npc.getBodypart(BodypartSlot.Vagina)
		if pussy.hasWomb():
			var pussyOrifice = pussy.getOrifice()
			cumvolume = cumvolume + pussyOrifice.getFluidAmount()
			
	var cumvolumeRounded = ceil(cumvolume)
	
	if cumvolumeRounded >= cum_requirement:
		npc.menstrualCycle.cycleProgress = 0
		if(npc.isPlayer()):
			GM.main.addMessage("The overflow of cum calms your heat!")
		else:
			GM.main.addMessage("The overflow of cum calms "+str(npc.getName())+"'s heat!")
