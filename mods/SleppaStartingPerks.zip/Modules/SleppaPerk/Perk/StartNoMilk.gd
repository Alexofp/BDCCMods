extends PerkBase

func _init():
	id = "SleppaStartNoMilk"
	skillGroup = Skill.Start

func getVisibleName():
	return "Regressed mammaries"

func getVisibleDescription():
	return "Milk production is greatly reduced"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/SleppaPerk/Images/dry.png"

func getBuffs():
	return [
		buff(Buff.BreastsMilkProductionBuff, [-100.0]),
	]
