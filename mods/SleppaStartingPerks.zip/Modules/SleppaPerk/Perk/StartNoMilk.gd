extends PerkBase

func _init():
	id = "SleppaStartNoMilk"
	skillGroup = Skill.Start

func getVisibleName():
	return "Regressed mammaries"

func getVisibleDescription():
	return "Milk production is greatly reduced"

func getSkillTier():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"

func getBuffs():
	return [
		buff(Buff.BreastsMilkProductionBuff, [-100.0]),
	]
