extends PerkBase

func _init():
	id = "SleppaStartPitiful"
	skillGroup = Skill.Start

func getVisibleName():
	return "Pitiful"

func getVisibleDescription():
	return "You are fragile and exhaust easily. Everything will be harder for you"

func getSkillTier():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"

func getBuffs():
	return [
		buff(Buff.MaxPainBuff, [-70 - npc.getStat(Stat.Vitality)]),
		buff(Buff.MaxStaminaBuff, [-70 - npc.getStat(Stat.Agility)]),
		buff(Buff.MaxLustBuff, [-50.0]),
	]
