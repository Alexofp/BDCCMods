extends PerkBase

func _init():
	id = "SleppaFalteringResiliance"
	skillGroup = Skill.Start

func getVisibleName():
	return "Faltering Resiliance"

func getVisibleDescription():
	return "What starts as a powerful defense against being bred can be overwhelmed by large volumes of cum, leaving you potentially exponentially more fertile: Fertility -300+((cumvolume/2)*(cumvolume/1000))"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0
	
func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/SleppaPerk/Images/felled_sperm.png"

func getBuffs():
	
	var cumvolume = 0
	
	if(npc.hasBodypart(BodypartSlot.Anus)):
		var ass = npc.getBodypart(BodypartSlot.Anus)
		if ass.hasWomb():
			var assOrifice = ass.getOrifice()
			cumvolume = cumvolume + assOrifice.getFluidAmount()

	if(npc.hasBodypart(BodypartSlot.Vagina)):
		var pussy = npc.getBodypart(BodypartSlot.Vagina)
		if pussy.hasWomb():
			var pussyOrifice = pussy.getOrifice()
			cumvolume = cumvolume + pussyOrifice.getFluidAmount()
			
	var cumvolumeRounded = ceil((cumvolume/2)*(cumvolume/1000))
	
	return [
		buff(Buff.FertilityBuff, [-300.0 + cumvolumeRounded]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [-150 + ceil(cumvolumeRounded/2)]),
		buff(Buff.OvulationEggsAmountBuff, [-90.0 + ceil(cumvolumeRounded/3.5)]),
	]
