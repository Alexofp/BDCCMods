extends PerkBase

func _init():
	id = "SleppaStartShame"
	skillGroup = Skill.Start

func getVisibleName():
	return "Painful Shame"

func getVisibleDescription():
	return "Being fully naked causes ambient pain"

func getSkillTier():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"

func getBuffs():
	if(not npc.isFullyNaked()):
		npc.removeEffect("SleppaShame")
		return []
	
	if(not npc.hasEffect("SleppaShame")):
		npc.addEffect("SleppaShame")
		return []
		
	return []
