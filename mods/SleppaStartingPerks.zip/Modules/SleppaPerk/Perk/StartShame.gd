extends PerkBase

func _init():
	id = "SleppaStartShame"
	skillGroup = Skill.Start

func getVisibleName():
	return "Painful Shame"

func getVisibleDescription():
	return "Being fully naked causes ambient pain"

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/SleppaPerk/Images/shame.png"

func getBuffs():
	if(not npc.isFullyNaked()):
		npc.removeEffect("SleppaShame")
		return []
	
	if(not npc.hasEffect("SleppaShame")):
		npc.addEffect("SleppaShame")
		return []
		
	return []
