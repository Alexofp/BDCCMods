extends Reference

var extendData : Array = []
var idFormat : String = "%s"
var nameFormat : String = "%s"
var newTraits : Dictionary = {}

var newpathFormat : String = ""


func setTraits(t:Dictionary) -> Reference:
	newTraits = t
	return self

func formatId(i:String) -> Reference:
	idFormat = i
	return self

func formatPath(i:String) -> Reference:
	newpathFormat = i
	return self

func formatName(i:String) -> Reference:
	nameFormat = i
	return self

func setExtend(old:String, new:String) -> Reference:
	extendData = [old, new]
	return self

func addLinesToInit(ls:PoolStringArray, source:String) -> String:
	var f : String = source
	
	var idx : int = f.find("func _init():")
	if idx == -1:
		return f
	
	var remaining := f.substr(idx).split("\n")
	var remidx : int = 1
	while remidx < remaining.size() && remaining[remidx].begins_with("\t"):
		remidx += 1
	
	remaining.insert(remidx, "\n\t".join(ls))
	
	f = f.substr(0, idx) + "\n".join(remaining)
	
	return f

func replaceExtends(old:String, new:String, source:String) -> String: # returns source
	var fsource : String = source
	
	if !new:
		return fsource
	
	var extend : Array = getExtend(fsource)
	if !extend[1]:
		return fsource
	
	
	var classStr : String = extend[1].trim_prefix("extends ").strip_edges()
	
	var trimmedold : String = classStr.trim_prefix('"').trim_suffix('"')
	
	var actualNewPlease : String = new\
		.replace("{OLD_PATH}", trimmedold.get_basename())\
		.replace("{OLD_FILE}", trimmedold.get_file().get_basename())
	
	if !old or classStr==old:
		fsource = fsource.substr(extend[0] + extend[1].length())
		fsource = "extends %s\n%s" % [actualNewPlease, fsource]
	
	return fsource


func doPartSkins(paths:Array) -> void:
	for skinpath in paths:
		var skin = load(skinpath).new()
		if !skin:
			continue
		skin.id = idFormat % skin.id
		skin.partID += nameFormat % skin.partID
		
		if(!GlobalRegistry.partSkins.has(skin.partID)):
			GlobalRegistry.partSkins[skin.partID] = {}
		GlobalRegistry.partSkins[skin.partID][skin.id] = skin


func getExtend(source:String) -> Array: # idx, line
	var idx : int = source.find("extends ")
	if idx == -1:
		return [-1, ""]
	return [idx, source.substr(idx, source.find("\n"))]


func do(paths:Array, extend:bool=false, replace:bool=false, doTraits:bool=false) -> void:
	for path in paths:
		var dc = load(path).new()
		var scrp = dc.get_script()
		var src = scrp.source_code
		
		if extend:
			src = replaceExtends(extendData[0], extendData[1], src)
		
		if doTraits:
			src = removeGetTraits(src)
			src = addGetTraits(src, dc.getTraits(), newTraits)
		
		
		var lines : PoolStringArray = [
			'\t' + ('visibleName = "%s"' % (nameFormat % dc.visibleName)) if nameFormat else "",
			'id = "%s"' % (idFormat % dc.id),
		]
		
		src = addLinesToInit(lines, src)
		
		var file : Resource = scrp.duplicate()
		file.source_code = src
		OS.set_clipboard(src)
		if newpathFormat:
			file.take_over_path(newpathFormat % path.get_file().get_basename())
		file.reload()
		
		var nbpo = file.new()
		#Log.warning(nbpo.visibleName)
		
		
		if replace:
			var old = GlobalRegistry.bodyparts.get(dc.id)
			if old:
				old.free()
		
		GlobalRegistry.bodyparts[idFormat % dc.id] = nbpo
		#Log.warning(nbpo.id)
		GlobalRegistry.bodypartStorageNode.add_child(nbpo)
		


func addGetTraits(source:String, traits, newOnes:Dictionary) -> String:
	var ftraits = traits
	if !ftraits:
		ftraits = newOnes
	else:
		ftraits.merge(newOnes, true)
	
	var returned : String
	var final : String = source
	
	
	returned = "{"
	for trait in ftraits:
		returned += "%s: %s, " % ['"%s"' % trait if typeof(trait)==TYPE_STRING else trait, "true" if ftraits[trait] else "false"]
	returned += "}"
	
	var function : String = "\nfunc getTraits():\n\treturn "+returned+"\n"
	
	final += function
	
	return final

func removeGetTraits(source:String) -> String:
	var f : String = source
	
	var idx : int = source.find("func getTraits():")
	var l : int = 0
	if idx == -1:
		return f
	
	var remaining = source.substr(idx)
	
	var lines = Array(remaining.split("\n"))
	if lines:
		l += lines[0].length()
	
	var currentLineIdx : int = 1
	
	while currentLineIdx<lines.size() && lines[currentLineIdx].begins_with("\t"):
		l += lines[currentLineIdx].length() + 2 # 2=newline
		currentLineIdx += 1
	
	
#	var removed : String = source.substr(idx, l)
#
#	Log.warning("FOUND FUNCTION:\n"+removed+"\nEND")
	
	f.erase(idx, l - 3)
	return f
