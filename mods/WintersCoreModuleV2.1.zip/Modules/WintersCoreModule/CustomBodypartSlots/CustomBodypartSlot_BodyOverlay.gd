extends CustomBodypartSlot

func _init():
	id = "slot_bodyoverlay"

func getVisibleName() -> String:
	return getVisibleNameNoCap().capitalize()

func getVisibleNameNoCap() -> String:
	return "body overlay"

func isEssential() -> bool:
	return false
