extends "res://Species/Human.gd"

var maleBoobs = [] 
var femaleBoobs = []

var mascIndexes : Array = []
var femIndexes : Array = []

func repopBoobs() -> void:
	femIndexes.clear()
	mascIndexes.clear()
	var mod : Module = GlobalRegistry.getModules().get("WintersExpandedBreasts")
	if !mod:
		return
	for i in maleBoobs.size():
		if mod.isBreastEnabled(maleBoobs[i]):
			mascIndexes.append(i)
	for i in femaleBoobs.size():
		if mod.isBreastEnabled(femaleBoobs[i]):
			femIndexes.append(i)

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())
	
	if ("RodentUtils" in GlobalRegistry.getModules()):
		GlobalRegistry.getModule("RodentUtils").connect("configClosed", self, "repopBoobs")

	if hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]
	
	repopBoobs()

func getDefaultLegs(_gender):
	return "plantilegs"

func getDefaultEars(_gender):
	return "humanears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs[RNG.pick(mascIndexes)] if mascIndexes else null
	return femaleBoobs[RNG.pick(femIndexes)] if femIndexes else null
