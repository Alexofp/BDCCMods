extends "res://Modules/WintersCoreModule/CompatibilityPatches/RAT_Archetypes/SpeciesBase.gd"

func getRegisteredMethods() -> Array:
	var a : Array = []
	for suffix in [
		"Tail", "Head", "Ears", "Body", "Legs", "Arms", "Breasts", "Penis", "Horns"
	]:
		a.append("getDefault"+suffix)
	
	return a

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())

	if hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_old, _gender):
	return "hoofs"

func getDefaultTail(_old, _gender):
	return "demontail"

func getDefaultHorns(_old, _gender):
	return "demonhorns"

func getDefaultHead(_old, _gender):
	return "humanhead"

func getDefaultArms(_old, _gender):
	return "anthroarms"

func getDefaultEars(_old, _gender):
	return "humanears"

func getDefaultPenis(_old, _gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if (hasPenis):
			return RNG.pick(["equinepenis", "equinepenisbarbknot", "equinepenisbarb", "equinepenisknot", "equinepenistapered"])
		return "equinepenis"
	else:
		return null

func npcGenerationWeight():
	return 0.0
