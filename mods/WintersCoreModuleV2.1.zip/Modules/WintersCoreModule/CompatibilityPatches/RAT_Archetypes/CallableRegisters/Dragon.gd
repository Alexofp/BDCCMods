extends "res://Modules/WintersCoreModule/CompatibilityPatches/RAT_Archetypes/SpeciesBase.gd"

var allowedDicks : Array = ["dragonpenis"]

func getRegisteredMethods() -> Array:
	var a : Array = []
	for suffix in [
		"Tail", "Head", "Ears", "Body", "Legs", "Arms", "Breasts", "Penis", "Vagina", "Horns"
	]:
		a.append("getDefault"+suffix)
	
	return a

func _init():
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())
	var hasPenis = ("WintersExpandedPenises" in GlobalRegistry.getModules())
	var hasDragonPenis = ("More Dragon Penis" in GlobalRegistry.getModules())

	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	if hasFluff && hasBoob: #FluffyBodyparts & ExpandedBreasts
		maleBoobs = ["scaledmalebreastsnipple", "scaledmalebreastsnippleinv", "scaledmalebreastspuffy", "scaledmalebreastspuffyinv"]
		femaleBoobs = ["scaledbreastsnipple", "scaledbreastsnippleinv", "scaledbreastspuffy", "scaledbreastspuffyinv"]
	elif hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]
	# Get Default Penises - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	if (hasPenis): #ExpandedPenises Only
		allowedDicks.append_array(["dragonpenisbarb"])
	if (hasDragonPenis): #MoreDragonPenises Only
		allowedDicks.append_array(["DPB1", "DPB2", "DPB3"])

func getDefaultTail(_old, _gender):
	return "dragontail"

func getDefaultHorns(_old, _gender):
	return "dragonhorns"

func getDefaultHead(_old, _gender):
	return "dragonhead"

func getDefaultEars(_old, _gender):
	return "dragonears"

func getDefaultBody(_old, _gender):
	if (hasFluff):
		return "scaledbody"
	return "anthrobody"

func getDefaultLegs(_old, _gender):
	if (hasFluff):
		return "scaledlegs"
	return "digilegs"

func getDefaultArms(_old, _gender):
	if (hasFluff):
		return "scaledarms"
	return "anthroarms"

func getDefaultPenis(_old, _gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return RNG.pick(allowedDicks)
	else:
		return null

func getDefaultVagina(_old, _gender):
	if(_gender in [Gender.Female, Gender.Androgynous]):
		return "vaginaEggs"
	else:
		return null
