extends Module

var BallsExtra = ResourceLoader.exists("res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd")

func _init():
	id = "songjohorseparts"
	author = "Songjo"

	bodyparts = [
		#All(45)
		#Horse(7)
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorseHead.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorseHoofs.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorseTail.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorseTail2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorseTail3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorsePenis.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Horse/SHorseHorn1.gd",
		#Canine(7)
		"res://Modules/SongsVanillaPartsModule/Script/Canine/SHeadCanine1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Canine/SHeadCanine2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Canine/SHeadCanine3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Canine/SHeadCanine4.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Canine/sEarsCanine1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Canine/sEarsCanine2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Canine/STailCanine1.gd",
		#Dragon(16)
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHeadDragon1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHeadDragon2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHeadDragon3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHeadDragon4.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sEarsDragon1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sEarsDragon2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sEarsDragon3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sEarsDragon4.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sEarsDragon5.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sEarsDragon6.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHornsDragon1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHornsDragon2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sHornsDragon3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sLegsDragon1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sLegsDragon1f.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Dragon/sTailDragon1.gd",
		#Feline(4)
		"res://Modules/SongsVanillaPartsModule/Script/Feline/SHeadFeline1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Feline/SHeadFeline2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Feline/SHeadFeline3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Feline/sEarsFeline1.gd",
		#Humanoid(Yet)
		#"res://Modules/SongsVanillaPartsModule/Script/Humanoid(Yet)/sHumanhead1.gd",
		
		#Universal(11)
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniFeet1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniFeet2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniHands1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniHands1_buffed.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniHands2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniHands2_buffed.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SUniTail1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SuniTail2.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SuniTail3.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SuniBreasts1.gd",
		"res://Modules/SongsVanillaPartsModule/Script/Universal/SuniBreasts2.gd",
		]

	#Penis
	if BallsExtra == true:
		bodyparts.erase("res://Modules/SongsVanillaPartsModule/Script/Horse/SHorsePenis.gd")
		bodyparts.insert(0,"res://Modules/SongsVanillaPartsModule/Patch/ballsextra/SongPenisHorseBallsextra.gd")

	#Skins
	partSkins = [
		#Horsepenis(3)
		"res://Modules/SongsVanillaPartsModule/Skins/Spotted/Spotted.gd",
		"res://Modules/SongsVanillaPartsModule/Skins/Singlecolor/singlecolor.gd",
		"res://Modules/SongsVanillaPartsModule/Skins/Twotone/Twotone.gd",
	]
