extends Module

const Jumpscare = preload("res://Modules/FnafJumpscare/Jumpscare.tscn")

var jumpscareRunning: bool = false

var chancePerAction: int = 1000
var playAudio = true

var audioVolume: int = 100

func _init():
    id = "Frivolous_FnafJumpscare"
    author = "Frivolous"

    gameExtenders = [
        "res://Modules/FnafJumpscare/Extender.gd",
    ]

    Console.addCommand("jumpscare", self, "runJumpscare", [], "Run the FNAF jumpscare")

func onFoxLibModInit(foxLib):
    foxLib.addNumberOption("chancePerAction", "Chance Per Action", "What chance the jumpscare has to occur every action (1 = 1/1 times, so 100%, 100 = 1/100, so 1%)", 1000)
    foxLib.addBooleanOption("playAudio", "Play Noise", "Whether to play the jumpscare sound. Leave on for the authentic experience.", true)
    foxLib.addSliderOption("audioVolume", "Audio Volume", "How loud the jumpscare is. Unaffected by global FoxLib sound setting.", 100)

func chanceToOccur() -> int:
    return chancePerAction

func runJumpscare():
    if jumpscareRunning:
        return
    jumpscareRunning = true

    var jumpscare = Jumpscare.instance()
    jumpscare.shouldScream(playAudio)
    jumpscare.setVolume(audioVolume)

    jumpscare.connect("finished", self, "onJumpscareFinished")

    GM.main.add_child(jumpscare)

func onJumpscareFinished():
    jumpscareRunning = false