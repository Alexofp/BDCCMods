extends Control

onready var animation = $AnimatedSprite
onready var audio = $AudioStreamPlayer

signal finished()

var playAudio: bool = true
var volume: float = 100

const MARGIN: int = 25

func shouldScream(play_audio: bool):
	playAudio = play_audio

func setVolume(new_volume: int):
	volume = new_volume

func _ready():
	var viewport_size = get_viewport().size
	var texture_size = animation.frames.get_frame("default", 0).get_size()

	animation.position = viewport_size / 2

	var scale = viewport_size.y / texture_size.y
	scale = scale - (MARGIN / viewport_size.y)

	animation.scale = Vector2(scale, scale)

	animation.connect("animation_finished", self, "_on_animation_finished")

	audio.volume_db = linear2db(volume / 100)

	animation.play()
	if playAudio:
		audio.play()

func _on_animation_finished():
	emit_signal("finished")
	self.queue_free()

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass
