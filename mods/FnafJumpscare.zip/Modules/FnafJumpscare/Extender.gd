extends GameExtender

func _init():
    id = "Frivolous_FnafJumpscare_Extender"

func register(ges: GameExtenderSystem):
    ges.register(self, ExtendGame.pcProcessTime)

func pcProcessTime(_pc: Player, _seconds: int):
    var module = GlobalRegistry.getModule("Frivolous_FnafJumpscare")
    if module == null:
        return

    if RNG.randi_range(1, module.chanceToOccur()) == 1:
        module.runJumpscare()