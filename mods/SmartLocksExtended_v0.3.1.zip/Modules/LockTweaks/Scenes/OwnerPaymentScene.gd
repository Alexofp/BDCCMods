extends "res://Scenes/SceneBase.gd"

var ownerID:String = ""

func _init():
	sceneID = "LockTweaksOwnerPaymentScene"

func _initScene(args = []):
	if not args.empty():
		ownerID = str(args[0])

func _run():
	var module = GlobalRegistry.getModule("LockTweaks")
	addButton("Back", "Return to the conversation", "back")
	if not module.owner_present(ownerID):
		saynn("The lock owner is no longer nearby.")
		return
	var locks = module.owner_locks(GM.pc, ownerID)
	if locks.empty():
		saynn("Good, now go bother someone else.")
		return
	saynn("Do you have something for me, whore?")
	for lock in locks:
		var item = lock.getItem()
		if item == null:
			continue
		saynn(item.getVisibleName() + ": " + str(lock.paidCredits) + "/" + str(lock.targetCredits) + " delivered; " + str(lock.qualified_credits()) + " qualifying credits available.")
		var amount = lock.payment_amount(GM.pc)
		if amount > 0:
			addButton("Pay " + str(amount), "Pay toward " + item.getVisibleName(), "pay", [item.getUniqueID()])
		else:
			addDisabledButton("Pay " + item.getVisibleName(), "You need credits in your wallet earned from prostitution.")

func _react(action:String, args):
	if action == "back":
		endScene()
	elif action == "pay" and not args.empty():
		GlobalRegistry.getModule("LockTweaks").pay_owner(ownerID, str(args[0]))

func saveData():
	var data = .saveData()
	data["ownerID"] = ownerID
	return data

func loadData(data):
	.loadData(data)
	ownerID = str(SAVE.loadVar(data, "ownerID", ""))
