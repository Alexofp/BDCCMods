extends Reference

# Autoload type references cache these scripts before the mod launcher mounts ZIPs.
# Reload the existing resources so already-parsed callers see the patched methods.
func _init():
	for path in ["res://Inventory/SmartLocks/SmartLock.gd", "res://Game/BaseCharacter.gd", "res://Inventory/ItemBase.gd"]:
		var script = load(path)
		var file = File.new()
		var error = file.open(path, File.READ)
		if error != OK:
			push_error("[SmartLocks Extended] Cannot read patched script: " + path)
			continue
		var source = file.get_as_text()
		file.close()
		if script.source_code == source:
			continue
		script.source_code = source
		error = script.reload(true)
		if error != OK:
			push_error("[SmartLocks Extended] Cannot activate patched script: " + path + " (" + str(error) + ")")
