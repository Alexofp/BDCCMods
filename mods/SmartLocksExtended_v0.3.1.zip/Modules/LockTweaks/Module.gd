extends "res://FoxLib/FoxModule.gd"

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var taskOptionsRegistered = false

func _init():
	id = "LockTweaks"
	name = "SmartLocks Extended"
	author = "AltGitsa"
	events = ["res://Modules/LockTweaks/Events/OwnerPaymentEvent.gd"]
	scenes = ["res://Modules/LockTweaks/Scenes/OwnerPaymentScene.gd"]
	perks = [
		"res://Modules/LockTweaks/Perks/FaultyRelease.gd",
		"res://Modules/LockTweaks/Perks/FinePrint.gd",
		"res://Modules/LockTweaks/Perks/UncertainSentence.gd",
	]
	Settings.migrate_amounts()
	for index in range(Settings.LOCKS.size()):
		var lock_id = Settings.LOCKS[index]
		var category = "SmartLocks Extended - Lock Types"
		var label = Settings.NAMES[index]
		addBooleanOptionInCategory(category, lock_id + "Enabled", "Enable " + label, "Affects new random locks. Scripted story locks and saved locks remain available.", true)
		addNumberOptionInCategory(category, lock_id + "Weight", label + ": selection weight", "Relative chance among enabled locks. Zero excludes this type. Range: 0-10000.", Settings.WEIGHTS[index])
		if lock_id == "TimedLock":
			addNumberOptionInCategory(category, "TimedHoursMin", "Timed lock: minimum game hours", "Time advances through gameplay, including sleep. Range: 1-720 hours.", 6)
			addNumberOptionInCategory(category, "TimedHoursMax", "Timed lock: maximum game hours", "The chosen deadline is saved with the lock. Range: 1-720 hours.", 24)
		elif lock_id == "MultiKeyholderLock":
			addNumberOptionInCategory(category, "Keyholders", "Multi-keyholder lock: number of holders", "Every holder must use their own key. Range: 2-10. Uses fewer if the world has too few eligible holders.", 3)
		elif lock_id == "TaskmasterLock":
			addNumberOptionInCategory(category, "TaskmasterDays", "Taskmaster Lock: base consecutive days", "Base streak before difficulty scaling. At 200% difficulty, 2 days becomes 4. Rolled once on application, rounded to the nearest day, minimum one. Morning assessment, missed-day reset, and shared task settings still apply. Base range: 1-30 days.", 2)
		elif lock_id == "ProstitutionLock":
			addNumberOptionInCategory(category, "ProstitutionCredits", "Prostitution Lock: base required credits", "Base debt before difficulty scaling. At 200% difficulty, 50 credits becomes 100. Rolled once on application, rounded to the nearest credit, minimum one. Earn through the standard prostitution interaction, then deliver to the owner. Base range: 1-10000 credits.", 50)
			addBooleanOptionInCategory(category, "ProstitutionPartial", "Prostitution Lock: allow partial payments", "Allow delivery in installments. Payments consume wallet credits and qualifying earnings; the owner releases the lock after full payment.", true)
	for index in range(Settings.LOCKS.size()):
		var lock_id = Settings.LOCKS[index]
		var category = "SmartLocks Extended - Keys"
		var label = Settings.NAMES[index]
		addBooleanOptionInCategory(category, lock_id + "KeysAllowed", label + ": allow ordinary keys", "Applied when a new lock is assigned. Multi-keyholder, Taskmaster, and Prostitution locks have this bypass disabled by default.", not lock_id in ["MultiKeyholderLock", "TaskmasterLock", "ProstitutionLock"])
		addBooleanOptionInCategory(category, lock_id + "VanillaKeys", label + ": use original key counts", "Use the game's normal/hard-mode counts. Turn off to use the minimum and maximum below.", true)
		addNumberOptionInCategory(category, lock_id + "KeysMin", label + ": minimum keys", "Used with original key counts off. Range: 1-100.", 2)
		addNumberOptionInCategory(category, lock_id + "KeysMax", label + ": maximum keys", "Used with original key counts off. Range: 1-100. Reversed bounds are automatically sorted.", 5)
	var category = "SmartLocks Extended - Tasks"
	addBooleanOptionInCategory(category, "VanillaTaskCount", "Use original task counts", "Keep the original 1-2 tasks with occasional 3- or 5-task locks. Turn off to use the range below.", true)
	addNumberOptionInCategory(category, "TasksMin", "Minimum tasks", "Range: 1-20. If no enabled task is possible, the lock is immediately removable.", 1)
	addNumberOptionInCategory(category, "TasksMax", "Maximum tasks", "Range: 1-20. Repeated tasks are allowed only when enabled below.", 2)
	addBooleanOptionInCategory(category, "RepeatTasks", "Allow repeated task types", "Allow multiple tasks of the same type on one lock or daily list. Disabled by default.", false)
	var difficulty_help = "Difficulty multiplies base requirements: 100% = 1x, 200% = 2x. Each task rolls between the bounds; its amount multiplier applies afterward. Also scales Taskmaster required days and Prostitution debt once when assigned. Some fixed-condition tasks ignore it. Original range: 100-200%. Limits: 10-1000%."
	addNumberOptionInCategory(category, "DifficultyMin", "Minimum difficulty multiplier (%)", difficulty_help, 100)
	addNumberOptionInCategory(category, "DifficultyMax", "Maximum difficulty multiplier (%)", difficulty_help, 200)
	for group_id in Settings.AMOUNT_GROUPS:
		var help = "Applies to every task in this group, after difficulty: 100% = unchanged, 200% = double. Range: 10-1000%."
		if group_id == "AmountEveryHole":
			help += " Each required hole must be used this many times (rounded up, minimum one)."
		addNumberOptionInCategory(category, group_id, Settings.AMOUNT_GROUPS[group_id][0] + ": amount multiplier (%)", help, 100).alwaysInitialize()

func onLoadingFinishing():
	register_task_options()
	GlobalRegistry.registerInteraction("res://Modules/LockTweaks/Interactions/ProstitutionIncome.gd")

func getFlags():
	return {"incomeSequence": flag(FlagType.Number)}

func onNewDay(pc):
	if pc == null or GM.main == null:
		return
	for lock in pc.getInventory().getAllSmartLocks():
		if lock.has_method("morning_check"):
			lock.morning_check(GM.main.getDays())

func next_income_transaction():
	var sequence = int(GM.main.getModuleFlag(id, "incomeSequence", 0)) + 1
	GM.main.setModuleFlag(id, "incomeSequence", sequence)
	return str(sequence)

func record_prostitution_income(transaction:String, amount:int):
	if GM.pc == null or transaction == "" or amount == 0:
		return
	var locks = GM.pc.getInventory().getAllSmartLocks()
	if amount < 0:
		locks.invert()
	var remaining = int(abs(amount))
	for lock in locks:
		if lock.id != "ProstitutionLock":
			continue
		if amount > 0:
			remaining -= lock.add_income(transaction, remaining)
		else:
			remaining -= lock.refund_income(transaction, remaining)
		if remaining <= 0:
			break

func owner_locks(pc, owner_id:String):
	var result = []
	if pc != null:
		for lock in pc.getInventory().getAllSmartLocks():
			if lock.id == "ProstitutionLock" and lock.isLockOwner(owner_id):
				result.append(lock)
	return result

func owner_present(owner_id:String):
	if GM.main == null or GM.pc == null:
		return false
	var pawn = GM.main.IS.getPawn(owner_id)
	return pawn != null and pawn.getLocation() == GM.pc.getLocation()

func pay_owner(owner_id:String, item_id:String):
	if not owner_present(owner_id):
		return 0
	for lock in owner_locks(GM.pc, owner_id):
		var item = lock.getItem()
		if item == null or item.getUniqueID() != item_id:
			continue
		var paid = lock.pay(GM.pc, owner_id)
		if paid > 0:
			GM.main.addMessage("Delivered " + str(paid) + " credits to the lock owner.")
			if lock.canBeSimpleRemoved():
				GM.pc.getInventory().clearSlot(item.getClothingSlotSafe())
				GM.main.addMessage("The owner releases the fully paid restraint.")
		return paid
	return 0

func register_task_options():
	if taskOptionsRegistered:
		return
	taskOptionsRegistered = true
	var task_ids = GlobalRegistry.getSlaveBreakTaskRefs().keys()
	task_ids.sort()
	var ordered_ids = ["Bodywritings", "Orgasms", "ChastityOrgasm", "Choke", "ForceLactation", "HaveSexWithSpecies", "InflictPain", "PenetrateEveryHole", "ReceiveFluidsInside", "ReceiveFluidsOnBody", "SwallowFluids", "ReceiveCreampies", "ReceiveThroatpies", "Spank", "SwallowDrugs"]
	# Keep additional tasks from other mods after the arranged built-in tasks.
	for task_id in task_ids:
		if not ordered_ids.has(task_id):
			ordered_ids.append(task_id)
	for task_id in ordered_ids:
		if not task_ids.has(task_id):
			continue
		var task_ref = GlobalRegistry.getSlaveBreakTaskRef(task_id)
		if task_ref.getSlutlockWeight() <= 0:
			continue
		var help = "Affects new Slut Lock tasks only. Uses the difficulty and applicable amount settings above."
		if task_id == "HaveSexWithSpecies":
			help += " Always requires one qualifying event, regardless of multipliers."
		addBooleanOptionInCategory("SmartLocks Extended - Tasks", "TaskEnabled_" + task_id, "Enable " + task_id, help, true)
		var amount_id = Settings.amount_option(task_id)
		if amount_id != "" and not Settings.AMOUNT_GROUPS.has(amount_id):
			# Give additional mod-added count tasks their own control too.
			addNumberOptionInCategory("SmartLocks Extended - Tasks", amount_id, task_id + ": amount multiplier (%)", "Applied after difficulty. 100% = unchanged, 200% = double. Range: 10-1000%.", 100)
