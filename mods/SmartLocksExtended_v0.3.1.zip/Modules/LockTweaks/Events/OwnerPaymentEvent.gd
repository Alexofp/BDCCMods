extends EventBase

func _init():
	id = "LockTweaksOwnerPayment"

func registerTriggers(es):
	es.addTrigger(self, Trigger.TalkingToDynamicNPC)
	es.addTrigger(self, Trigger.SceneAndStateHook, ["StrugglingScene", ""])

func run(trigger_id, args):
	if args.empty() or GM.pc == null:
		return
	var module = GlobalRegistry.getModule("LockTweaks")
	if trigger_id == Trigger.SceneAndStateHook:
		# Also available during inspection beside an owner whose special dialogue
		# replaces the ordinary conversation screen.
		var seen = {}
		for lock in GM.pc.getInventory().getAllSmartLocks():
			if lock.id != "ProstitutionLock" or lock.canBeSimpleRemoved() or seen.has(lock.ownerID):
				continue
			if module.owner_present(lock.ownerID):
				seen[lock.ownerID] = true
				var owner = GlobalRegistry.getCharacter(lock.ownerID)
				addButton("Pay " + owner.getName(), "Deliver qualifying earnings to this lock owner nearby", "pay", [lock.ownerID])
	else:
		var owner_id = str(args[0])
		if not module.owner_locks(GM.pc, owner_id).empty():
			addButton("Pay lock owner", "Deliver qualifying prostitution earnings toward your locked restraints", "pay", [owner_id])

func onButton(method, args):
	if method == "pay" and not args.empty():
		var module = GlobalRegistry.getModule("LockTweaks")
		if module.owner_present(str(args[0])):
			runScene("LockTweaksOwnerPaymentScene", [str(args[0])])
