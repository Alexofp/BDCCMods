extends "res://Modules/LockTweaks/Perks/StartingLockPerk.gd"

func _init():
	id = "SLEFinePrint"

func getVisibleName():
	return "Fine Print"

func getVisibleDescription():
	return "Slut Locks reveal only one unfinished task at a time. Only that task can progress; completing it reveals the next and keeps completed requirements visible above it. The remaining task count is concealed. Does not affect Taskmaster daily lists."
