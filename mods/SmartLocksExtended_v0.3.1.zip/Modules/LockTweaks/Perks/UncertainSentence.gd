extends "res://Modules/LockTweaks/Perks/StartingLockPerk.gd"

func _init():
	id = "SLEUncertainSentence"

func getVisibleName():
	return "Uncertain Sentence"

func getVisibleDescription():
	return "Timed Locks conceal how much time remains. You can inspect whether the timer has completed, but its countdown and release time stay hidden. The actual duration is unchanged."
