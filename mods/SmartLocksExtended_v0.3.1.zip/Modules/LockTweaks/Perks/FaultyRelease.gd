extends "res://Modules/LockTweaks/Perks/StartingLockPerk.gd"

func _init():
	id = "SLEFaultyRelease"

func getVisibleName():
	return "Faulty Release"

func getVisibleDescription():
	return "Each completed Slut Lock task list has a 50% chance to reset and generate a new list instead of opening. Each list rolls once; inspection and saving/loading cannot reroll the result. Ordinary-key bypass still works if allowed. Does not affect Taskmaster Locks."
