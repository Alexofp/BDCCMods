extends PerkBase

func _init():
	skillGroup = Skill.Start

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false

func unlockable() -> bool:
	return false

func getCost():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"
