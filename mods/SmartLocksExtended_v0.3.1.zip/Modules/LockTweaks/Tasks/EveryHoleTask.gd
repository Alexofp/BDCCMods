extends "res://Game/NpcSlavery/BreakTask/PenetrateEveryHole.gd"

var requiredSlots:Array = []
var slotCounts:Dictionary = {}
var perSlotRequired:int = 1

func generateFor(wearer, _isSlaveLevelup, _difficulty = 1.0):
	requiredSlots = slots_for(wearer)
	slotCounts = {}
	perSlotRequired = 1
	currentAmount = 0
	taskIsCompleted = false
	refresh_counts()

func slots_for(wearer):
	var result = [BodypartSlot.Head]
	if wearer != null:
		if wearer.hasReachableVagina():
			result.append(BodypartSlot.Vagina)
		if wearer.hasReachableAnus():
			result.append(BodypartSlot.Anus)
	return result

func set_amount_scale(multiplier):
	perSlotRequired = int(max(1, ceil(multiplier)))
	refresh_counts()

func refresh_counts():
	needAmount = requiredSlots.size() * perSlotRequired
	currentAmount = 0
	for slot in requiredSlots:
		currentAmount += int(min(slotCounts.get(slot, 0), perSlotRequired))
	fuckedMouth = slotCounts.get(BodypartSlot.Head, 0) >= perSlotRequired
	fuckedVag = slotCounts.get(BodypartSlot.Vagina, 0) >= perSlotRequired
	fuckedAnus = slotCounts.get(BodypartSlot.Anus, 0) >= perSlotRequired

func onSexEvent(wearer, event:SexEvent):
	if event.getType() != SexEvent.HolePenetrated or event.getTargetChar() != wearer:
		return false
	return record_slot(event.getField("hole", BodypartSlot.Vagina))

func record_slot(slot):
	if not requiredSlots.has(slot) or slotCounts.get(slot, 0) >= perSlotRequired:
		return false
	slotCounts[slot] = int(slotCounts.get(slot, 0)) + 1
	refresh_counts()
	if currentAmount >= needAmount:
		completeSelf()
	return true

func getTaskStringSlutLock():
	var progress = []
	var labels = {BodypartSlot.Head: "mouth", BodypartSlot.Vagina: "vagina", BodypartSlot.Anus: "anus"}
	for slot in requiredSlots:
		progress.append(labels.get(slot, str(slot)) + " " + str(slotCounts.get(slot, 0)) + "/" + str(perSlotRequired))
	return "Get fucked in every hole: " + PoolStringArray(progress).join(", ")

func getTaskString():
	return getTaskStringSlutLock()

func saveData():
	var data = .saveData()
	data["requiredSlots"] = requiredSlots.duplicate()
	data["slotCounts"] = slotCounts.duplicate()
	data["perSlotRequired"] = perSlotRequired
	return data

func loadData(data):
	.loadData(data)
	requiredSlots = SAVE.loadVar(data, "requiredSlots", []).duplicate()
	slotCounts = SAVE.loadVar(data, "slotCounts", {}).duplicate()
	perSlotRequired = int(max(1, SAVE.loadVar(data, "perSlotRequired", 1)))
	if not requiredSlots.empty():
		refresh_counts()

func migrate_for(wearer):
	if not requiredSlots.empty():
		return
	# Old tasks stored only once-per-slot flags and could have inflated targets.
	# Retain the target as a reachable per-slot count and credit recorded progress.
	requiredSlots = slots_for(wearer)
	perSlotRequired = int(max(1, ceil(float(needAmount) / requiredSlots.size())))
	slotCounts = {BodypartSlot.Head: 1 if fuckedMouth else 0, BodypartSlot.Vagina: 1 if fuckedVag else 0, BodypartSlot.Anus: 1 if fuckedAnus else 0}
	if taskIsCompleted:
		for slot in requiredSlots:
			slotCounts[slot] = perSlotRequired
	refresh_counts()
	if currentAmount >= needAmount:
		taskIsCompleted = true
