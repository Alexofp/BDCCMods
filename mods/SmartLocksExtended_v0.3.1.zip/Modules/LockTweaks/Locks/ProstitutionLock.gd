extends SmartLockBase

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var ownerID:String = ""
var targetCredits:int = 50
var paidCredits:int = 0
var earnings:Dictionary = {}
var partialPayments:bool = true
var keysAllowed:bool = false
var keyAmount:int = 5

func _init():
	id = "ProstitutionLock"

func getName():
	return "Prostitution Lock"

func onLocked(context):
	targetCredits = Settings.scaled_requirement("ProstitutionCredits", 50, 1, 10000)
	partialPayments = bool(Settings.value("ProstitutionPartial", true))
	paidCredits = 0
	earnings = {}
	ownerID = ""
	var possible = Settings.candidates(getWearer())
	var forcer = context.get("forcer", null)
	if forcer is String:
		forcer = GlobalRegistry.getCharacter(forcer)
	if forcer != null and possible.has(forcer.getID()):
		ownerID = forcer.getID()
	elif not possible.empty():
		ownerID = RNG.pick(possible)
	keysAllowed = Settings.keys_allowed(id)
	keyAmount = Settings.key_count(id, RNG.randi_range(2, 5))

# Deliberately not a keyholder: asking for keys or winning a fight cannot bypass payment.
func isLockOwner(char_id:String):
	return ownerID == char_id and not canBeSimpleRemoved()

func canBeSimpleRemoved() -> bool:
	return ownerID == "" or paidCredits >= targetCredits

func canBeUnlockedWithKeys() -> bool:
	return keysAllowed

func getKeysAmountToUnlock() -> int:
	return keyAmount

func qualified_credits():
	var total = 0
	for amount in earnings.values():
		total += int(amount)
	return total

func add_income(transaction:String, amount:int):
	if canBeSimpleRemoved() or transaction == "" or amount <= 0:
		return 0
	var accepted = int(min(amount, max(0, targetCredits - paidCredits - qualified_credits())))
	if accepted > 0:
		earnings[transaction] = int(earnings.get(transaction, 0)) + accepted
	return accepted

func refund_income(transaction:String, amount:int):
	var removed = int(min(max(0, amount), earnings.get(transaction, 0)))
	if removed > 0:
		earnings[transaction] -= removed
		if earnings[transaction] <= 0:
			earnings.erase(transaction)
	return removed

func payment_amount(player):
	var remaining = targetCredits - paidCredits
	var available = int(min(remaining, min(qualified_credits(), max(0, player.getCredits()))))
	if not partialPayments and available < remaining:
		return 0
	return available

func pay(player, owner_id:String):
	if not isLockOwner(owner_id) or player != getWearer():
		return 0
	var amount = payment_amount(player)
	if amount <= 0:
		return 0
	var left = amount
	for transaction in earnings.keys():
		left -= refund_income(transaction, left)
		if left <= 0:
			break
	player.addCredits(-amount)
	paidCredits += amount
	return amount

func getUnlockDescription():
	var owner = GlobalRegistry.getCharacter(ownerID) if ownerID != "" else null
	var owner_name = owner.getName() if owner != null else "Unavailable owner"
	var text = "Owner: %s. Delivered: %d/%d credits.\nQualifying prostitution earnings available: %d credits.\nEarn credits through prostitution, then talk to the owner to deliver them." % [owner_name, paidCredits, targetCredits, qualified_credits()]
	if ownerID == "":
		text = "No eligible owner was available. The lock can be removed."
	elif not partialPayments:
		text += "\nThe remaining amount must be paid in full."
	if keysAllowed:
		text += "\nAlternatively, use %d ordinary restraint keys." % keyAmount
	return text

func saveData():
	return {"ownerID": ownerID, "targetCredits": targetCredits, "paidCredits": paidCredits, "earnings": earnings.duplicate(), "partialPayments": partialPayments, "keysAllowed": keysAllowed, "keyAmount": keyAmount}

func loadData(data):
	ownerID = str(SAVE.loadVar(data, "ownerID", ""))
	targetCredits = int(max(1, SAVE.loadVar(data, "targetCredits", 50)))
	paidCredits = int(clamp(SAVE.loadVar(data, "paidCredits", 0), 0, targetCredits))
	earnings = {}
	var saved_earnings = SAVE.loadVar(data, "earnings", {})
	for transaction in saved_earnings:
		var amount = int(max(0, saved_earnings[transaction]))
		if amount > 0:
			earnings[str(transaction)] = amount
	partialPayments = bool(SAVE.loadVar(data, "partialPayments", true))
	keysAllowed = bool(SAVE.loadVar(data, "keysAllowed", false))
	keyAmount = int(max(1, SAVE.loadVar(data, "keyAmount", 5)))
