extends "res://Inventory/SmartLocks/Locks/TightLock.gd"

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var keysAllowed:bool = true

func onLocked(context):
	.onLocked(context)
	keyAmount = Settings.key_count(id, keyAmount)
	keysAllowed = Settings.keys_allowed(id)

func canBeUnlockedWithKeys() -> bool:
	return keysAllowed

func getUnlockDescription():
	var text = .getUnlockDescription()
	if not keysAllowed:
		text = text.split("Alternatively,")[0] + "Ordinary restraint keys are disabled."
		var required = GlobalRegistry.getItemRef(getRestraintData().getTightLockRequiredItemID())
		if required != null:
			text += "\nRequired item: " + required.getVisibleName()
	return text

func saveData():
	var data = .saveData()
	data["keysAllowed"] = keysAllowed
	return data

func loadData(data):
	.loadData(data)
	keysAllowed = bool(SAVE.loadVar(data, "keysAllowed", true))
