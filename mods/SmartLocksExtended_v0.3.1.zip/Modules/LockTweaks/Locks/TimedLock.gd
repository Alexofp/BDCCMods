extends SmartLockBase

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var unlockAt:int = 0
var keyAmount:int = 3
var keysAllowed:bool = true

func _init():
	id = "TimedLock"

func getName():
	return "Timed lock"

func onLocked(_context):
	var low = int(Settings.number("TimedHoursMin", 6, 1, 720))
	var high = int(Settings.number("TimedHoursMax", 24, 1, 720))
	var duration = RNG.randi_range(int(min(low, high)), int(max(low, high))) * 3600
	unlockAt = now() + duration
	keyAmount = Settings.key_count(id, RNG.randi_range(2, 5))
	keysAllowed = Settings.keys_allowed(id)

func now():
	return GM.main.getTimeInGlobalSeconds() if GM.main != null else 0

func canBeSimpleRemoved() -> bool:
	return now() >= unlockAt

func canBeUnlockedWithKeys() -> bool:
	return keysAllowed

func getKeysAmountToUnlock() -> int:
	return keyAmount

func getUnlockDescription():
	var remaining = max(0, unlockAt - now())
	var minutes = int(ceil(remaining / 60.0))
	var text = "Timer complete. The lock can be removed." if remaining <= 0 else "Time remaining: %dh %dm (in-game time)." % [int(minutes / 60), minutes % 60]
	if remaining > 0 and Settings.has_starting_perk(getWearer(), Settings.UNCERTAIN_SENTENCE):
		text = "Timer still locked. The timer appears to be broken."
	if keysAllowed:
		text += "\nAlternatively, use %d ordinary restraint keys." % keyAmount
	return text

func saveData():
	return {"unlockAt": unlockAt, "keyAmount": keyAmount, "keysAllowed": keysAllowed}

func loadData(data):
	unlockAt = int(SAVE.loadVar(data, "unlockAt", now()))
	keyAmount = int(SAVE.loadVar(data, "keyAmount", 3))
	keysAllowed = bool(SAVE.loadVar(data, "keysAllowed", true))
