extends SmartLockBase

const Settings = preload("res://Modules/LockTweaks/Settings.gd")
var holders:Array = []
var released:Array = []
var keyAmount:int = 5
var keysAllowed:bool = false

func _init():
	id = "MultiKeyholderLock"

func getName():
	return "Multi-keyholder lock"

func onLocked(context):
	holders = []
	released = []
	var possible = Settings.candidates(getWearer())
	var forcer = context.get("forcer", null)
	if forcer is String:
		forcer = GlobalRegistry.getCharacter(forcer)
	if Settings.is_candidate(forcer, getWearer()) and possible.has(forcer.getID()):
		holders.append(forcer.getID())
		possible.erase(forcer.getID())
	var wanted = int(Settings.number("Keyholders", 3, 2, 10))
	while holders.size() < wanted and not possible.empty():
		var char_id = RNG.pick(possible)
		holders.append(char_id)
		possible.erase(char_id)
	keyAmount = Settings.key_count(id, RNG.randi_range(2, 8))
	keysAllowed = Settings.keys_allowed(id)

func isKeyholder(char_id:String):
	return holders.has(char_id) and not released.has(char_id)

# Returns true only for a NEW release. Repeated interactions cannot count twice.
func releaseKeyholder(char_id:String):
	if not isKeyholder(char_id):
		return false
	released.append(char_id)
	return true

func canBeSimpleRemoved() -> bool:
	for char_id in holders:
		if not released.has(char_id):
			return false
	return true

func canBeUnlockedWithKeys() -> bool:
	return keysAllowed

func getKeysAmountToUnlock() -> int:
	return keyAmount

func getUnlockDescription():
	var lines = ["Each holder must open their own lock. Releases: %d/%d." % [released.size(), holders.size()]]
	for char_id in holders:
		var character = GlobalRegistry.getCharacter(char_id)
		var holder_name = character.getName() if character != null else "Unavailable holder (" + char_id + ")"
		lines.append(("[OPEN] " if released.has(char_id) else "[LOCKED] ") + holder_name)
	if holders.empty():
		lines.append("No eligible keyholders were available. The lock can be removed.")
	if keysAllowed:
		lines.append("Alternatively, use %d ordinary restraint keys." % keyAmount)
	return PoolStringArray(lines).join("\n")

func saveData():
	return {"holders": holders.duplicate(), "released": released.duplicate(), "keyAmount": keyAmount, "keysAllowed": keysAllowed}

func loadData(data):
	holders = []
	released = []
	for char_id in SAVE.loadVar(data, "holders", []):
		if char_id is String and char_id != "" and not holders.has(char_id):
			holders.append(char_id)
	for char_id in SAVE.loadVar(data, "released", []):
		if holders.has(char_id) and not released.has(char_id):
			released.append(char_id)
	keyAmount = int(SAVE.loadVar(data, "keyAmount", 5))
	keysAllowed = bool(SAVE.loadVar(data, "keysAllowed", false))
