extends "res://Game/InteractionSystem/Interactions/Prostitution.gd"

var incomeTransaction:String = ""

func sendSlaveryActivityEvent(role:String, event_id:String, args:Dictionary):
	.sendSlaveryActivityEvent(role, event_id, args)
	if role != "main" or getRoleID(role) != "pc":
		return
	var amount = int(args.get("credits", 0))
	if amount <= 0:
		return
	var module = GlobalRegistry.getModule("LockTweaks")
	if event_id == "slutPaid":
		if incomeTransaction == "":
			incomeTransaction = module.next_income_transaction()
		module.record_prostitution_income(incomeTransaction, amount)
	elif event_id == "slutReturnedCredits" and incomeTransaction != "":
		module.record_prostitution_income(incomeTransaction, -amount)

func doRemoveRole(role:String):
	if role == "client":
		incomeTransaction = ""
	return .doRemoveRole(role)

func saveData():
	var data = .saveData()
	data["lockTweaksIncomeTransaction"] = incomeTransaction
	return data

func loadData(data):
	.loadData(data)
	incomeTransaction = str(SAVE.loadVar(data, "lockTweaksIncomeTransaction", ""))
