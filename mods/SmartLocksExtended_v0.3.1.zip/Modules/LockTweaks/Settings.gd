extends Reference

const MODULE_ID = "LockTweaks"
const FAULTY_RELEASE = "SLEFaultyRelease"
const FINE_PRINT = "SLEFinePrint"
const UNCERTAIN_SENTENCE = "SLEUncertainSentence"
const LOCKS = ["TightLock", "SlutLock", "KeyholderLock", "TimedLock", "MultiKeyholderLock", "TaskmasterLock", "ProstitutionLock"]
const NAMES = ["Tight lock", "Slut Lock", "Keyholder lock", "Timed lock", "Multi-keyholder lock", "Taskmaster Lock", "Prostitution Lock"]
const WEIGHTS = [1, 5, 1, 1, 1, 1, 1]
const AMOUNT_GROUPS = {
	"AmountFluids": ["Fluids (inside/body/swallow)", ["ReceiveFluidsInside", "ReceiveFluidsOnBody", "SwallowFluids"]],
	"AmountPies": ["Creampies / throatpies", ["ReceiveCreampies", "ReceiveThroatpies"]],
	"AmountOrgasms": ["Orgasms (normal/chastity)", ["Orgasms", "ChastityOrgasm"]],
	"AmountEveryHole": ["Get fucked in every hole", ["PenetrateEveryHole"]],
	"AmountChoking": ["Choking", ["Choke"]],
	"AmountPain": ["Pain", ["InflictPain"]],
	"AmountBodywritings": ["Bodywritings", ["Bodywritings"]],
	"AmountSpanking": ["Spanking", ["Spank"]],
	"AmountDrugs": ["Swallowing drugs", ["SwallowDrugs"]],
}
const FIXED_TASKS = ["HaveSexWithSpecies", "ForceLactation"]
const LEGACY_INDIVIDUALS = ["ReceiveFluidsInside", "ReceiveFluidsOnBody", "SwallowFluids", "ReceiveCreampies", "ReceiveThroatpies", "Orgasms", "ChastityOrgasm", "PenetrateEveryHole", "Choke", "InflictPain"]

static func amount_option(task_id):
	if FIXED_TASKS.has(task_id):
		return ""
	for group_id in AMOUNT_GROUPS:
		if AMOUNT_GROUPS[group_id][1].has(task_id):
			return group_id
	return "TaskAmount_" + task_id

static func task_amount(task_id):
	var option_id = amount_option(task_id)
	return number(option_id, 100, 10, 1000) / 100.0 if option_id != "" else 1.0

static func has_starting_perk(wearer, perk_id):
	return wearer != null and wearer.isPlayer() and wearer.hasPerk(perk_id)

static func migrate_amounts():
	var manager = load("res://Modules/FoxLib/Internal/FoxOptionsManager.gd")
	for group_id in AMOUNT_GROUPS:
		if value(group_id, null) != null:
			continue
		var migrated = 10.0
		for task_id in AMOUNT_GROUPS[group_id][1]:
			var fallback = 100 if LEGACY_INDIVIDUALS.has(task_id) else value("TaskAmount", 100)
			migrated = max(migrated, number("TaskAmount_" + task_id, fallback, 10, 1000))
		# If old controls disagree, retain their highest setting for the new group.
		manager.setOption(MODULE_ID, group_id, int(migrated))

static func value(key, fallback):
	if not ResourceLoader.exists("res://Modules/FoxLib/Internal/FoxOptionsManager.gd"):
		return fallback
	return load("res://Modules/FoxLib/Internal/FoxOptionsManager.gd").getOption(MODULE_ID, key, fallback)

static func number(key, fallback, minimum, maximum):
	return clamp(float(value(key, fallback)), minimum, maximum)

static func roll_difficulty():
	var low = number("DifficultyMin", 100, 10, 1000) / 100.0
	var high = number("DifficultyMax", 200, 10, 1000) / 100.0
	return RNG.randf_rangeX2(min(low, high), max(low, high))

static func scaled_requirement(key, fallback, minimum, maximum):
	return int(max(1, round(number(key, fallback, minimum, maximum) * roll_difficulty())))

static func enabled(lock_id):
	return bool(value(lock_id + "Enabled", true))

static func weight(lock_id):
	var index = LOCKS.find(lock_id)
	return number(lock_id + "Weight", WEIGHTS[index] if index >= 0 else 1, 0, 10000)

static func key_count(lock_id, vanilla_count):
	if value(lock_id + "VanillaKeys", true):
		return vanilla_count
	var low = int(number(lock_id + "KeysMin", 2, 1, 100))
	var high = int(number(lock_id + "KeysMax", 5, 1, 100))
	return RNG.randi_range(int(min(low, high)), int(max(low, high)))

static func keys_allowed(lock_id):
	return bool(value(lock_id + "KeysAllowed", not lock_id in ["MultiKeyholderLock", "TaskmasterLock", "ProstitutionLock"]))

static func is_candidate(character, wearer = null):
	if character == null or character == wearer or character.isPlayer():
		return false
	if character.shouldBeExcludedFromEncounters():
		return false
	if character is DynamicCharacter and character.temporaryCharacter:
		return false
	return GM.main != null and GM.main.IS.hasPawn(character.getID())

static func candidates(wearer = null):
	var result = []
	if GM.main != null:
		for char_id in GM.main.dynamicCharacters:
			var character = GlobalRegistry.getCharacter(char_id)
			if is_candidate(character, wearer):
				result.append(char_id)
	return result

static func choose_random(forcer = null, wearer = null):
	var choices = []
	for lock_id in LOCKS:
		if not enabled(lock_id):
			continue
		if lock_id == "KeyholderLock" and forcer != null and forcer.shouldBeExcludedFromEncounters():
			continue
		if lock_id in ["MultiKeyholderLock", "ProstitutionLock"] and candidates(wearer).empty():
			continue
		var chance = weight(lock_id)
		if chance > 0:
			choices.append([lock_id, chance])
	return RNG.pickWeightedPairs(choices) if not choices.empty() else ""
