extends Object
class_name SmartLock

const TightLock = "TightLock"
const SlutLock = "SlutLock"
const KeyholderLock = "KeyholderLock"
const TimedLock = "TimedLock"
const MultiKeyholderLock = "MultiKeyholderLock"
const TaskmasterLock = "TaskmasterLock"
const ProstitutionLock = "ProstitutionLock"

static func getAll():
	return [TightLock, SlutLock, KeyholderLock, TimedLock, MultiKeyholderLock, TaskmasterLock, ProstitutionLock]

static func getRandomSmartLock():
	return load("res://Modules/LockTweaks/Settings.gd").choose_random()

static func create(the_id:String):
	if not the_id in getAll():
		return null
	return load("res://Modules/LockTweaks/Locks/" + the_id + ".gd").new()
