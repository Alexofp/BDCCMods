extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "knotted barbed dual penis"
	id = "caninepenisdualbarb"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func isWinteredDefault() -> bool:
	return false # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine", "barbed",])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Knotted/KnottedBarbedDualPenis/KnottedBarbedDualPenis.tscn"
	
func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "knotted and barbed hybrid cock"
