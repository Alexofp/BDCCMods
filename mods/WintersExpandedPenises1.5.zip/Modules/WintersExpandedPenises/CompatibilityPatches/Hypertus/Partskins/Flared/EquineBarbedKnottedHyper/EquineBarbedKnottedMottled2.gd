extends PartSkinBase

func _init():
	id = "equinebarbknotmottled2hyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedMottled2.png"),
	}
