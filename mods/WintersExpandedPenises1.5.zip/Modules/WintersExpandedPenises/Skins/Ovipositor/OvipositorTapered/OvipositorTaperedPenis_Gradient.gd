extends PartSkinBase

func _init():
	id = "ovipositortaperedGradient"
	partID = "ovipositortaperedpenis"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyGradient.png"),
	}
