extends PartSkinBase

func _init():
	id = "ovipositortaperedtribal"
	partID = "ovipositortaperedpenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyTribal.png"),
	}
