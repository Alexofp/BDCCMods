extends PartSkinBase

func _init():
	id = "ovipositortaperedhighlight"
	partID = "ovipositortaperedpenis"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyCockHighlight.png"),
	}
