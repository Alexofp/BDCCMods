extends PartSkinBase

func _init():
	id = "ovipositortaperedpiercing"
	partID = "ovipositortaperedpenis"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyPiercing.png"),
	}
