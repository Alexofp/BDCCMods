extends PartSkinBase

func _init():
	id = "ovipositortaperedlovermark2"
	partID = "ovipositortaperedpenis"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyLoverMark.png"),
	}
