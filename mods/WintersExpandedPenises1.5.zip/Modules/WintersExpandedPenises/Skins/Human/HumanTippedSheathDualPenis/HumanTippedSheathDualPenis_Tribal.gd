extends PartSkinBase

func _init():
	id = "humantippedsheathtribal"
	partID = "humantippedsheathpenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanTippedSheathPenis_Tribal.png"),
	}
