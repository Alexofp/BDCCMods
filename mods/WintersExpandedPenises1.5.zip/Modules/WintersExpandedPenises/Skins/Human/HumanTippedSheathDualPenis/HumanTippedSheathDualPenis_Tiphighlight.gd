extends PartSkinBase

func _init():
	id = "humantippedsheathhighlight"
	partID = "humantippedsheathpenis"

func getName():
	return "Tip Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanTippedSheathPenis_Tiphighlight.png"),
	}
