extends PartSkinBase

func _init():
	id = "humantippedsheathshaftfade"
	partID = "humantippedsheathpenis"

func getName():
	return "Shaft Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanTippedSheathPenis_Shaft.png"),
	}
