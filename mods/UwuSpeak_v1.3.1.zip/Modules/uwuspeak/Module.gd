extends Module

var doNpcs : bool = false
var reqLust : float = 50
var subWeight : float = 1.0
var lustWeight : float = 1.0
var pcNoPerk : bool = false
var consciousnessThreshold : float = 15
var perkWeight : float = 1.0
var reqSubby : float = 50
var nyaChainNum : float = 2
var nyaChanceMult : float= 100
var hornySymbolMult : float = 100
var doubleMarksMult : float = 100
var stutterMult : float = 100
var ellipsisReplaceMult : float = 100
var wReplaceMult : float = 100
var moanMult : float = 100
var staticNpcLustFix : bool = true
var mustLust : bool = false
var mustSubby : bool = false
var mustConsciousness : bool = false


func _init():
	id = "UwuSpeak"
	author = "Selinoccino"
	
	perks = [
		"res://Modules/uwuspeak/Perks/Silly.gd",
	]
	
	speechModifiers = [
		"res://Modules/uwuspeak/SpeechModifiers/uwuspeak.gd",
	]
	
	gameExtenders = [
		"res://Modules/uwuspeak/GameExtenders/StaticCharLustExtender.gd",
	]

func RatConfigure(ratconf):
	ratconf.overrideModConfigName(id, "UwU-Speak (Rat)")
	
	ratconf.addOptionBool(id, "staticNpcLustFix", "Fixes", "Fix static NPCs' lust after battle", "Resets static NPCs' lust to 0 after battle, since the game doesn't reset it itself, causing the NPCs affected to always use UwuSpeak if eligible because of lust.", false)
	
	var elig : String = "Eligibility"
	
	ratconf.addOptionBool(id, "doNpcs", elig, "UwuSpeak affects NPCs?", "Allows UwuSpeak to affect NPCs under certain conditions, which are configurable below.", false)
	ratconf.addOptionBool(id, "pcNoPerk", elig, "UwuSpeak affects player without perk?", "Allows UwuSpeak to affect the player under the same conditions as above", false)
	ratconf.addOptionNum(id, "reqLust", elig, "Required lust level (%)", "Lust level should be this percentage or above to affect NPCs or player", 50.0).setMin(0).setMax(100)
	ratconf.addOptionNum(id, "reqSubby", elig, "Required subbiness level (%)", "Subbiness level should be this percentage or above to affect NPCs or player", 50.0).setMin(0).setMax(100)
	ratconf.addOptionNum(id, "consciousnessThreshold", elig, "Consciousness threshold (%)", "If a character's consciousness is at or below this percentage, they're eligible for concussion-induced UwuSpeak. Set to 0 to disable.", 15.0).setMin(0).setMax(100)
	
	
	ratconf.addOptionBool(id, "mustConsciousness", elig, "Strict Consciousness", "NPCs MUST be concussed enough to use UwuSpeak.", false)
	ratconf.addOptionBool(id, "mustSubby", elig, "Strict Subbiness", "NPCs MUST be subby enough to use UwuSpeak.", false)
	ratconf.addOptionBool(id, "mustLust", elig, "Strict Lust", "NPCs MUST be lusty enough to use UwuSpeak.", false)
	
	
	var weigh : String = "Weights"
	
	ratconf.addOptionNum(id, "subWeight", weigh, "Subbiness weight", "How much subbiness affects characers' speech if they're eligible to speak in UwuSpeak, relative to other weights. Set to 0 to disable.", 1.0).setMin(0).setGreater()
	
	ratconf.addOptionNum(id, "lustWeight", weigh, "Lust weight", "How much lust affects characers' speech if they're eligible to speak in UwuSpeak, relative to other weights. Set to 0 to disable.", 1.0).setMin(0).setGreater()
	
	ratconf.addOptionNum(id, "perkWeight", weigh, "Perk weight", "How much the \"Silly\" perk affects characers' speech if they're eligible to speak in UwuSpeak, relative to other weights. Set to 0 to disable. Since having a perk or not is a boolean, the final weight will only ever be 0 or this value.", 1.0).setMin(0).setGreater()
	
	var spch : String = "Speech"
	
	
	ratconf.addOptionNum(id, "nyaChainNum", spch, "Nya chain max. length", "Maximum length of a nya chain. A nya chain can only happen if the sentence ends with an exclamation mark", 2).setStep(1.0).setGreater().setMin(0)
	ratconf.addOptionNum(id, "nyaChanceMult", spch, "Nya chance multiplier (%)", "Multiplies chance of a nya appearing by this percentage.", 100.0).setMin(0).setGreater()
	ratconf.addOptionNum(id, "hornySymbolMult", spch, "\"~\" chance multiplier (%)", "Multiplies chance of that symbol appearing before punctuation by this percentage.", 100.0).setMin(0).setGreater()
	ratconf.addOptionNum(id, "doubleMarksMult", spch, "Double puntuation marks chance multiplier (%)", "Multiplies chance of question/exclamation marks being doubled by this percentage.", 100.0).setMin(0).setGreater()
	ratconf.addOptionNum(id, "stutterMult", spch, "Stutter chance multiplier (%)", "Multiplies chance of stuttering by this percentage.", 100.0).setMin(0).setGreater()
	ratconf.addOptionNum(id, "ellipsisReplaceMult", spch, "Ellipsis replacement chance multiplier (%)", "Multiplies chance of an ellipsis replacing a period, semi-colon or comma by this percentage.", 100.0).setMin(0).setGreater()
	ratconf.addOptionNum(id, "wReplaceMult", spch, "Letter replacement chance multiplier (%)", "Multiplies chance of some characters being replaced by a \"w\" by this percentage.", 100.0).setMin(0).setGreater()
	ratconf.addOptionNum(id, "moanMult", spch, "Moan chance multiplier (%)", "Multiplies chance of a word that's already said with a stutter having a moan added before it by this percentage.", 100.0).setMin(0).setGreater()
	
