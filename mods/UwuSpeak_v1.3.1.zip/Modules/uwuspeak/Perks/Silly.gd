extends PerkBase

func _init():
	id = "SillyUwu"
	skillGroup = Skill.Start

func getVisibleName():
	return "Silly"

func getVisibleDescription():
	return "You're silly and talk weird! Also, most people can't really stand you."

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0
	
func getSkillTier():
	return 0

func getPicture():
	return "res://Images/StatusEffects/headache.png"

