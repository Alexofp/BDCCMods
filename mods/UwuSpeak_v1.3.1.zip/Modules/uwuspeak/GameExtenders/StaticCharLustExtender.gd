extends GameExtender

func _init():
	id = "StaticCharLustExtender"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.npcAfterFightEnded)

func npcAfterFightEnded(_npc:Character):
	if !_npc.isDynamicCharacter() && GlobalRegistry.getModule("UwuSpeak").staticNpcLustFix:
		_npc.addLust(-_npc.getLust())
