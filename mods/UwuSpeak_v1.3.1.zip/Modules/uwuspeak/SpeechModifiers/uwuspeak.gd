extends SpeechModifierBase

var mod = GlobalRegistry.getModule("UwuSpeak")

func _init():
	id = "UwuSpeech"
	priority = 999
	
func appliesTo(_speaker: BaseCharacter) -> bool:
	if _speaker.hasPerk("SillyUwu"):
		return true
	
	var pers = _speaker.getPersonality()
	var subby = 0.0
	if pers:
		subby = pers.getStat(PersonalityStat.Subby)
	
	var affectNoPerk = (_speaker.getID()!="pc" && mod.doNpcs) or (_speaker.getID()=="pc" && mod.pcNoPerk)
	
	var eligSubby = subby*100>=mod.reqSubby # true if elig bc of subbiness
	var eligLust = _speaker.getLustLevel()>=mod.reqLust*0.01
	var eligConsciousness = _speaker.getConsciousness()<=mod.consciousnessThreshold*0.01
	
	var finalIsEligible = (eligSubby or eligLust or eligConsciousness)
	if mod.mustSubby:
		finalIsEligible = finalIsEligible && eligSubby
	if mod.mustLust:
		finalIsEligible = finalIsEligible && eligLust
	if mod.mustConsciousness:
		finalIsEligible = finalIsEligible && eligConsciousness
	
	return finalIsEligible && affectNoPerk


func modify(_text: String, _speaker: BaseCharacter) -> String:
	var res = ""
	
	var ignore = false
	var lastCharacters = "" # add at the end of loop, should be one char in most cases
	
	var subby = _speaker.getPersonality().getStat(PersonalityStat.Subby)
	var totalWeight = mod.perkWeight+mod.subWeight+mod.lustWeight
	if totalWeight==0.0:
		return _text
	var intensity = (mod.perkWeight*int(_speaker.hasPerk("SillyUwu"))+subby*mod.subWeight+mod.lustWeight*_speaker.getLustLevel()) / float(totalWeight)
	var wifiedConsonants = "lrh"
	var words = _text.split(" ")
	var endedWithPunc = true
	for widx in words.size():
		
		var newWord = ""
		var word : String = words[widx]
#		var lastWord : String = (words[widx-1] if widx>0 else "")
#		var nextWord : String = (words[widx+1] if words.size()>widx+1 else "")
		
		var dontAddStutter = false
		if word.length()>2:
			dontAddStutter = word[1]=="-" && word[0].to_lower()==word[2].to_lower()
		
		var dontAddWs = ( (word != word.get_slice("’",0) or word != word.get_slice("'",0)) && word.length()<4 ) or word.length()<3
		for cidx in word.length():
			var ch = word[cidx]
			if(ch == "{"):
				ignore = true
				res += ch
				continue
			if(ignore):
				if(ch == "}"):
					ignore = false
				
				res += ch
				continue
			
			var newChar = ch # added character
			
			var nextChar = (word[cidx+1] if word.length()>cidx+1 else "")
			
			
			if ch.to_lower() in wifiedConsonants && RNG.chance(((intensity*20)+40)*mod.wReplaceMult*0.01) && !nextChar.to_lower() in wifiedConsonants+"w" && !lastCharacters.to_lower() in "w"+ch.to_lower() && !dontAddWs:
				newChar = "w"
				if nextChar==ch.to_lower(): # for will or stuff like that
					newChar+=newChar
					cidx+=1
			
			
			
			if newChar=="":
				newChar = ch
			
			newWord += newChar
			
			lastCharacters=newChar.right(newChar.length()-1)
		# end of char loop, still in word loop
		if !newWord:
			continue
		newWord = newWord.replace("…","..") # no
		var puncs = ""
		var pidxs = []
		var marks = ".?,;!"
		for cid in marks.length(): # find start of punctuation
			var idx = newWord.find(marks[cid])
			if idx!=-1:
				pidxs.append(idx)
		if !pidxs.empty():
			pidxs.sort()
			puncs = newWord.substr((pidxs[0]))
#			print(puncs+" is puncs")
		
		if puncs: 
			if puncs.ends_with("!") or puncs.begins_with("!"):
				var reps = 0
				var pos = pidxs[0]
				while reps<mod.nyaChainNum && RNG.chance((20+intensity*15)*mod.nyaChanceMult*0.01):
					reps += 1
					var txt = ", "+RNG.pick(["nya","nyah","nyaah","maaw","huh","mraaaw","mrow"])
					newWord = newWord.insert(pos,txt)
					pos += txt.length()
			elif puncs in [",",";","."] && RNG.chance((intensity*20+25)*0.01*mod.ellipsisReplaceMult):
				newWord = newWord.trim_suffix(puncs)+".."
			
			var prevPuncs = ("" if pidxs[0]==0 else newWord[pidxs[0]-1])
			if RNG.chance((5+10*intensity)*0.01*mod.hornySymbolMult) && ("." in puncs or "?" in puncs) && prevPuncs!="~" && !puncs.ends_with("~"): # question marks and periods have a ~ added to them if not already there
				newWord = newWord.insert(pidxs[0],"~")
			
			
			
			if RNG.chance((intensity*10+40)*0.01*mod.doubleMarksMult):# double punctuation marks ig
				var lastChar = puncs[puncs.length()-1]
				if lastChar in ["?","!"]:
					newWord+=lastChar
			
			
		
		if !dontAddStutter && newWord[0]!=" " && (endedWithPunc or widx==0) && RNG.chance((intensity*15+30)*0.01*mod.stutterMult): # add stutter
			newWord = newWord.insert(0,newWord[0]+"-")
		elif dontAddStutter && RNG.chance((intensity*10+15)*0.01*mod.moanMult): # stutter subby thing again
			newWord = RNG.pick(["mmfph~..","ah~..","nghh~.","ooh~..","a-ah~.."])+" "+newWord
		
		if word.to_upper()==word: # all caps
			newWord = newWord.to_upper()
		elif word[0].to_upper()==word[0]: # capital first
			newWord[0] = newWord[0].to_upper()
		
		res += (" " if widx>0 else "")+newWord # spaces
		endedWithPunc = bool(puncs)
	
	
	return res
