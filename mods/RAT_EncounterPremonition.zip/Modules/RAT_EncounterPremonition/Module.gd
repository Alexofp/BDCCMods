extends Module

func _init():
	id = "RAT_EncounterPremonition"
	author = "Selinoccino"
	
	events = [
		"res://Modules/RAT_EncounterPremonition/menuevent.gd",
		"res://Modules/RAT_EncounterPremonition/menueventstart.gd"
	]
	
	scenes =[
		"res://Modules/RAT_EncounterPremonition/scene.gd"
	]

func getSavePath() -> String:
	return "user://EncounterPresets.json"

func readSaved() -> Dictionary:
	var f = File.new()
	
	var e = f.open(getSavePath(), File.READ)
	
	if e != OK:
		return {}
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		return {}
	
	if typeof(r.result) != TYPE_DICTIONARY:
		return {}
	
	return r.result

func replaceCurrent() -> void:
	var d : Dictionary = readSaved()
	var def : String = d.get("default", "")
	var pres : Dictionary = d.get("presets", {})
	if !pres or !pres.has(def):
		return
	
	GM.main.encounterSettings.loadData(pres[def])
