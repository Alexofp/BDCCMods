extends Module

func _init():
	id = "RAT_EncounterPremonition"
	author = "Selinoccino"
	
	events = [
		"res://Modules/RAT_EncounterPremonition/menuevent.gd",
	]
	
	scenes =[
		"res://Modules/RAT_EncounterPremonition/scene.gd"
	]

func getSavePath() -> String:
	return "user://EncounterPresets.json"

func readSaved() -> Dictionary:
	return GlobalRegistry.getModule("RodentUtils").readJsonData(getSavePath(), TYPE_DICTIONARY, {})

func replaceCurrent() -> void:
	var d : Dictionary = readSaved()
	var def : String = d.get("default", "")
	var pres : Dictionary = d.get("presets", {})
	if !pres or !pres.has(def):
		return
	
	GM.main.encounterSettings.loadData(pres[def])
