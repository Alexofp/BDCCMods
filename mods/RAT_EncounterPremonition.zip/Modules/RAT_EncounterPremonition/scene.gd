extends SceneBase

func _init():
	sceneID = "RAT_EncounterPremonition_scene"
	

func _run():
	GM.ui.addFullScreenCustomControl("presets", load("res://Modules/RAT_EncounterPremonition/EncounterPresets.tscn").instance())
	addButton("Done", "Don't forget to save!", "end")

func _react(_action:String, _args):
	if _action=="end":
		endScene()
		return
	
	setState(_action)
