extends Tree

var encounterSettings : EncounterSettings

func _ready():
	set_column_title(0, "Restricted Goals")
	popGoals()

func setSettings(s:EncounterSettings) -> void:
	encounterSettings = s
	popGoals()

func popGoals() -> void:
	self.clear()
	self.create_item()
	if !encounterSettings:
		return
	var allGoals = GlobalRegistry.getSexGoals()
	for goalID in allGoals:
		var dis : bool = encounterSettings.isGoalDisabledForSubPC(goalID)
		
		var goal: SexGoalBase = GlobalRegistry.getSexGoal(goalID)
		if(goal == null):
			continue
			
		addGoalItem(goal, dis, false)

func addGoalItem(goal:SexGoalBase, dis:bool=false, upd:bool=true) -> TreeItem:
	var i : TreeItem = create_item()
	i.set_metadata(0, [goal, dis])
	
	updateGoalItem(i, [goal, dis], upd)
	
	return i


func _on_disabledgoals_item_activated():
	var sel : TreeItem = get_selected()
	if sel:
		var mt = sel.get_metadata(0)
		mt[1] = !mt[1]
		
		updateGoalItem(sel, mt)

func updateGoalItem(item:TreeItem, meta=null, upd:bool=true) -> void:
	if !meta:
		meta = item.get_metadata(0)
	
	item.set_text(0, "%s%s" % [meta[0].getVisibleName(), " (disabled)" if meta[1] else ""])
	item.set_custom_color(0, Color.red if meta[1] else Color.white)
	if upd && encounterSettings:
		if meta[1]:
			encounterSettings.disableGoalForSubPC(meta[0].id)
		else:
			encounterSettings.enableGoalForSubPC(meta[0].id)
