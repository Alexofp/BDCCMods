extends VBoxContainer

var encounterSettings : EncounterSettings

func setSettings(s:EncounterSettings) -> void:
	encounterSettings = s
	pop()

func pop() -> void:
	for node in get_children():
		node.free()
	
	_pop()

func _pop() -> void:
	return

func createEntry(id:String, display:String, weight:float) -> HBoxContainer:
	var hb := HBoxContainer.new()
	hb.set_meta("id", id)
	
	var lab : Label = Label.new()
	lab.text = display
	lab.mouse_filter = Control.MOUSE_FILTER_STOP
	
	var spin := SpinBox.new()
	spin.value = weight
	spin.connect("value_changed", self, "onEntryChanged", [id])
	
	for a in [hb, lab, spin]:
		a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	
	for a in [lab, spin]:
		hb.add_child(a)
	
	return hb

func onEntryChanged(_new:float, _id:String) -> void:
	return

func getAllData() -> Dictionary:
	var d : Dictionary = {}
	for hb in get_children():
		d[hb.get_meta("id")] = hb.get_child(1).value
	
	return d
