extends "res://Modules/RAT_EncounterPremonition/weightedvb.gd"

func _pop() -> void:
	if !encounterSettings:
		return
	
	for gender in NpcGender.getAll():
		var genderName = NpcGender.getVisibleName(gender)
#		var extraInfo = ""
		var genderExlanation = NpcGender.getGenderExplanation(gender)
#		if(genderExlanation != null && genderExlanation != ""):
#			extraInfo = " ("+str(genderExlanation)+")"
		
		var weight = encounterSettings.getGenderWeight(gender)
		
		var entry = createEntry(gender, genderName, 0.0)
		var sp : SpinBox = entry.get_child(1)
		sp.max_value = 100
		sp.value = weight*100
		sp.suffix = "%"
		entry.get_child(0).self_modulate = Color(NpcGender.getColorString(gender))
		if genderExlanation:
			entry.get_child(0).hint_tooltip = genderExlanation
		add_child(entry)
		

func onEntryChanged(_new:float, _id:String) -> void:
	if encounterSettings:
		encounterSettings.setGenderWeight(_id, _new*0.01)

func getAllData() -> Dictionary:
	var d := .getAllData()
	for key in d:
		d[key] = d[key]*0.01
	
	return d
