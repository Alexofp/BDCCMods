extends "res://Modules/RAT_EncounterPremonition/weightedvb.gd"

func _pop() -> void:
	if !encounterSettings:
		return
	
	var allTFs = GlobalRegistry.getTransformationRefs()
	for tfID in allTFs:
		var tf: TFBase = GlobalRegistry.getTransformationRef(tfID)
		if(tf == null || !tf.canChangeWeight()):
			continue
		var tfWeight = encounterSettings.getTFWeight(tfID, tf.getPillGenWeight())
		
		var pillName:String = tf.getPillName()
		var tfName:String = tf.getName()
		
		var entry = createEntry(tfID, (tfName if tfName==pillName else "%s (%s)" % [pillName, tfName]), 0.0)
		var sp : SpinBox = entry.get_child(1)
		sp.max_value = 500
		sp.value = tfWeight*100
		sp.suffix = "%"
		add_child(entry)
		

func onEntryChanged(_new:float, _id:String) -> void:
	if encounterSettings:
		encounterSettings.setTFWeight(_id, _new*0.01)

func getAllData() -> Dictionary:
	var d := .getAllData()
	for key in d:
		d[key] = d[key]*0.01
	
	return d
