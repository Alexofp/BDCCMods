extends Control

var settings : EncounterSettings

func setSettings(s:EncounterSettings) -> void:
	for n in [
		$sc/goals/disabledgoals,
		$sc/goals/genders/vb/sc/vb,
		$sc/goals/species/vb/sc/vb,
		$sc/goals/tfs/vb/sc/vb,
		$sc/goals/goals/vb/sc/vb,
	]:
		n.setSettings(s)
	
	settings = s
	_on_subthreesomes_pressed(false)
	_on_preferknown_pressed(false)


func _on_subthreesomes_pressed(upd:bool=true):
	if upd && settings:
		settings.subThreesomes = !settings.subThreesomes
	
	$optshb/subthreesomes.text = "Sub threesomes: " + ("Yes" if settings.subThreesomes else "No")


func _on_preferknown_pressed(upd:bool=true):
	if upd && settings:
		settings.preferKnownEncounters = !settings.preferKnownEncounters
	
	$optshb/preferknown.text = "Prefer known encounters: " + ("Yes" if settings.preferKnownEncounters else "No")
