extends "res://Modules/RAT_EncounterPremonition/weightedvb.gd"

func _pop() -> void:
	if !encounterSettings:
		return
	
	var allGoals = GlobalRegistry.getSexGoals()
	for goalID in allGoals:
		var goal: SexGoalBase = GlobalRegistry.getSexGoal(goalID)
		if !goal:
			continue
		var goalWeight = encounterSettings.getGoalWeight(goalID, goal.getGoalDefaultWeight())
		
		var entry = createEntry(goalID, goal.getVisibleName(), 0.0)
		var sp : SpinBox = entry.get_child(1)
		sp.max_value = 500
		sp.value = goalWeight*100
		sp.suffix = "%"
		
		add_child(entry)
		

func onEntryChanged(_new:float, _id:String) -> void:
	if encounterSettings:
		encounterSettings.setGoalWeight(_id, _new*0.01)

func getAllData() -> Dictionary:
	var d := .getAllData()
	for key in d:
		d[key] = d[key]*0.01
	
	return d
