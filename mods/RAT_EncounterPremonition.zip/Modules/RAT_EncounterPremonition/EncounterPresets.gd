extends Control

onready var presetsTree : Tree = $tc/pc/hb/presetstree

var default : String

func displayPresets(presetsDict : Dictionary) -> void:
	presetsTree.clear()
	presetsTree.create_item()
	for preset in presetsDict:
		newPresetItem(preset, presetsDict[preset])
	

func newPresetItem(id:String, contents:Dictionary) -> TreeItem:
	var it : TreeItem = presetsTree.create_item()
	it.set_text(0, id)
	it.set_metadata(0, contents)
	
	return it

func readSaved() -> Dictionary:
	return GlobalRegistry.getModule("RAT_EncounterPremonition").readSaved()

func setDefault(d:String) -> void:
	default = d
	$tc/pc/hb/actionstree/vb/defaultLabel.text = "Default: %s" % (d if d else "(none)")

func loadFromSaved() -> void:
	var data : Dictionary = readSaved()
	
	setDefault(data.get("default", ""))
	displayPresets(data.get("presets", {}))

func _ready():
	$tc.set_tab_title(0, "Presets")
	$tc.set_tab_title(1, "Edit/view current")
	if !GM.main:
		$tc/view.queue_free()
		$tc/pc/hb/actionstree/vb/savecurrent.disabled = true
		$tc/pc/hb/actionstree/vb/useselected.disabled = true
		$tc/pc/hb/actionstree/vb/replace.disabled = true
	else:
		$tc/view.setSettings(GM.main.encounterSettings)
	
	loadFromSaved()


func _on_useselected_pressed():
	var sel : TreeItem = presetsTree.get_selected()
	if !sel:
		return
	
	GM.main.encounterSettings.loadData(sel.get_metadata(0))
	$tc/view.setSettings(GM.main.encounterSettings)

func _on_replace_pressed():
	var sel : TreeItem = presetsTree.get_selected()
	if !sel:
		return
	
	sel.set_metadata(0, GM.main.getEncounterSettings().saveData())


func _on_setasdefault_pressed():
	var sel : TreeItem = presetsTree.get_selected()
	if !sel:
		return
	
	setDefault(sel.get_text(0))


func _on_ok_pressed():
	var new : String = $idthing/cc/pc/vb/LineEdit.text
	if new.is_valid_filename():
		newPresetItem(new, GM.main.getEncounterSettings().saveData())
		$idthing.hide()

func getDictionaryOfData() -> Dictionary:
	var d : Dictionary = {}
	var child = presetsTree.get_root().get_children()
	while child!=null:
		d[child.get_text(0)] = child.get_metadata(0)
		child = child.get_next()
	
	return d

func saveToFile(notify:bool=true) -> void:
	var f : File = File.new()
	f.open(GlobalRegistry.getModule("RAT_EncounterPremonition").getSavePath(), File.WRITE)
	if f:
		var data : Dictionary = {
			"presets": getDictionaryOfData(),
			"default": default,
		}
		var d : String = JSON.print(data, "\t")
		f.store_string(d)
		f.close()
		
		if notify:
			$idthing/cc/AcceptDialog.dialog_text = "Presets saved!"
	elif notify:
		$idthing/cc/AcceptDialog.dialog_text = "Failed to save presets. %s" % f.get_error()
	
	if notify:
		$idthing.show()
		$idthing/cc/AcceptDialog.popup_centered()
	


func _on_savecurrent_pressed():
	$idthing.show()
	$idthing/cc/pc.show()


func _on_deleteselected_pressed():
	var sel : TreeItem = presetsTree.get_selected()
	if sel:
		sel.free()


func _on_deleteall_pressed():
	setDefault("")
	presetsTree.clear()


func _on_saveall_pressed():
	saveToFile()


func _on_deleteall2_pressed():
	var p : String = GlobalRegistry.getModule("RAT_EncounterPremonition").getSavePath()
	OS.move_to_trash(ProjectSettings.globalize_path(p))
	loadFromSaved()
