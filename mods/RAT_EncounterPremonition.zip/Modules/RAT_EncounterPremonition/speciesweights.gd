extends "res://Modules/RAT_EncounterPremonition/weightedvb.gd"

func _pop() -> void:
	if !encounterSettings:
		return
	
	var species = GlobalRegistry.getAllPlayableSpecies()
	for speciesID in species:
		var speciesObject:Species = species[speciesID]
		var speciesName = speciesObject.getVisibleName()
		
		var weight = encounterSettings.getSpeciesWeight(speciesID)
		
		var entry = createEntry(speciesID, speciesName, 0.0)
		var sp : SpinBox = entry.get_child(1)
		sp.max_value = 300
		sp.value = weight*100
		sp.suffix = "%"
		entry.get_child(0).hint_tooltip = speciesObject.getVisibleDescription()
		add_child(entry)
		

func onEntryChanged(_new:float, _id:String) -> void:
	if encounterSettings:
		encounterSettings.setSpeciesWeight(_id, _new*0.01)

func getAllData() -> Dictionary:
	var d := .getAllData()
	for key in d:
		d[key] = d[key]*0.01
	
	return d
