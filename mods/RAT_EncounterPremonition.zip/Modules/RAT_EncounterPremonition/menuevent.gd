extends EventBase

func _init():
	id = "RAT_EncounterPremonition_event"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["EncountersMenuScene",""])

func run(_id,_args):
	addButton("Edit presets", "Edit your encounter presets", "dopresets")


func onButton(_method, _args):
	if(_method == "dopresets"):
		runScene("RAT_EncounterPremonition_scene")
