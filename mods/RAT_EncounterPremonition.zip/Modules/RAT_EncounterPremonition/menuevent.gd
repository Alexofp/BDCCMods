extends EventBase
var rr : WeakRef

func _init():
	id = "RAT_EncounterPremonition_event"
	rr = weakref(GM.main)

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["EncountersMenuScene",""])
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene",""])

func run(_id,_args):
	addButton("Edit presets", "Edit your encounter presets", "dopresets")
	if !(_args && _args[0]=="IntroScene" && !_args[1]):
		return
	if !(rr && rr.get_ref()==GM.main):
		rr = weakref(GM.main)
		do()

func do() -> void:
	getModule("RAT_EncounterPremonition").replaceCurrent()
	Log.warning("did!")


func onButton(_method, _args):
	if(_method == "dopresets"):
		runScene("RAT_EncounterPremonition_scene")
