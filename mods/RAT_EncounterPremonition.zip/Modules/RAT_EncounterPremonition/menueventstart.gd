extends "res://Modules/RAT_EncounterPremonition/menuevent.gd"

func _init():
	id = "RAT_EncounterPremonition_event2"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["IntroScene",""])

func run(_triggerID, _args):
	.run(_triggerID, _args)
	
	getModule("RAT_EncounterPremonition").replaceCurrent()
