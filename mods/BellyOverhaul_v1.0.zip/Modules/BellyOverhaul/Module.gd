extends Module
const Belly := preload("res://Modules/BellyOverhaul/Belly.gd")

var options := []


func _init():
	id = "BellyOverhaul"
	author = "xrob1"


func onFoxLibModInit(api):
	var knobs:Dictionary = Belly.KNOBS
	for row in Belly.ROWS:
		var made = null
		if(row["type"] == Belly.T_SLIDER):
			made = api.addSliderOptionInCategory(Belly.CAT, row["id"], row["title"], row["desc"], row["default"])
		else:
			made = api.addButtonOptionInCategory(Belly.CAT, row["id"], row["title"], row["desc"])
		if(made == null):
			continue
		if(row["type"] == Belly.T_BUTTON):
			made.connect("option_changed", self, "onButton", [row["id"]])
		else:
			made.bindToField(knobs, row["id"])
			made.connect("option_changed", self, "onOptionChanged")
			options.append(made)


func onOptionChanged(_value = null):
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		Belly.reapplyAll(tree)


func onButton(_value, id:String):
	if(id == Belly.TESTBENCH_ID):
		var tree = Engine.get_main_loop()
		if(tree is SceneTree):
			tree.root.add_child(load("res://Modules/BellyOverhaul/TestBench.gd").new())
	else:
		onRestore()


func onRestore():
	for option in options:
		option.resetOptionValue()
	onOptionChanged()
