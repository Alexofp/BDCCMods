extends CanvasLayer


const Belly := preload("res://Modules/BellyOverhaul/Belly.gd")
const FOX_OPTIONS := "res://Modules/FoxLib/Internal/FoxOptionsManager.gd"
const FOX_SCREEN := "res://Modules/FoxLib/UI/FoxLibModOptionsScreen.gd"
const MODULE_ID := "BellyOverhaul"
const CAMERA_SIZE := 9.0
const CAMERA_AT := Vector3(0.0, 4.6, 50.0)

var doll
var before := {}
var sliders := {}
var belly := 1.0
var random
var who:Label


func _ready():
	layer = 120
	for row in Belly.ROWS:
		if(row["type"] == Belly.T_SLIDER):
			before[row["id"]] = Belly.knob(row["id"])
	var root := Control.new()
	root.theme = load("res://GlobalTheme.tres")
	root.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	add_child(root)
	var shade := ColorRect.new()
	shade.color = Color(0.03, 0.03, 0.04)
	shade.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	root.add_child(shade)
	var line := HBoxContainer.new()
	line.set_anchors_and_margins_preset(Control.PRESET_WIDE, Control.PRESET_MODE_MINSIZE, 24)
	root.add_child(line)
	line.add_child(dollView())
	line.add_child(controls())
	if(player() != null):
		onPlayer()
	else:
		onRandom()


func player():
	if(GM.main == null || !is_instance_valid(GM.main) || GM.pc == null || !is_instance_valid(GM.pc)):
		return null
	return GM.pc


func dollView() -> Control:
	var box := ViewportContainer.new()
	box.stretch = true
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var view := Viewport.new()
	view.own_world = true
	view.hdr = false
	box.add_child(view)
	var stage := Spatial.new()
	view.add_child(stage)
	doll = load("res://Player/Player3D/Doll3D.tscn").instance()
	stage.add_child(doll)
	var camera := Camera.new()
	camera.projection = Camera.PROJECTION_ORTHOGONAL
	camera.size = CAMERA_SIZE
	camera.translation = CAMERA_AT
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.1, 0.1, 0.12)
	camera.environment = env
	view.add_child(camera)
	camera.current = true
	return box


func controls() -> Control:
	var box := VBoxContainer.new()
	box.rect_min_size.x = 420
	box.add_constant_override("separation", 10)
	box.add_child(label("Belly Overhaul: try it on"))
	who = label("")
	box.add_child(who)
	var pick := HBoxContainer.new()
	var mine := button("Your character", "onPlayer")
	mine.disabled = player() == null
	if(mine.disabled):
		mine.hint_tooltip = "Start or load a game to see your own character here."
	pick.add_child(mine)
	pick.add_child(button("Random character", "onRandom"))
	box.add_child(pick)
	for row in Belly.ROWS:
		if(row["type"] == Belly.T_SLIDER):
			box.add_child(sliderLine(row["id"], row["title"], row["desc"], 0.0, 100.0, 1.0, Belly.knob(row["id"]), "%"))
	box.add_child(sliderLine("", "Belly size (preview only)", "How big the belly is in this window: 1 = full term." \
		+ " Not a setting: it only lets you see the shape at any size.", 0.0, 5.0, 0.05, belly, ""))
	var buttons := HBoxContainer.new()
	buttons.add_child(button("Save", "onSave"))
	buttons.add_child(button("Defaults", "onDefaults"))
	buttons.add_child(button("Cancel", "onCancel"))
	box.add_child(buttons)
	return box


func label(text:String) -> Label:
	var made := Label.new()
	made.text = text
	made.autowrap = true
	return made


func button(text:String, method:String) -> Button:
	var made := Button.new()
	made.text = text
	made.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	made.connect("pressed", self, method)
	return made


func sliderLine(id:String, title:String, desc:String, from:float, to:float, step:float, at:float, unit:String) -> Control:
	var box := VBoxContainer.new()
	var tag := label("")
	var slider := HSlider.new()
	slider.min_value = from
	slider.max_value = to
	slider.step = step
	slider.value = at
	slider.hint_tooltip = desc
	tag.hint_tooltip = desc
	tag.mouse_filter = Control.MOUSE_FILTER_PASS
	slider.connect("value_changed", self, "onSlider", [id, title, unit, tag])
	onSlider(at, id, title, unit, tag)
	if(id != ""):
		sliders[id] = slider
	box.add_child(tag)
	box.add_child(slider)
	return box


func onSlider(value:float, id:String, title:String, unit:String, tag:Label) -> void:
	tag.text = title + ": " + str(value) + unit
	if(id == ""):
		belly = value
	else:
		var knobs:Dictionary = Belly.KNOBS
		knobs[id] = int(value)
	if(doll != null && doll.is_inside_tree()):
		Belly.apply(doll, belly)


func onPlayer() -> void:
	showCharacter(player(), "your character")


func onRandom() -> void:
	var old = random
	random = randomCharacter()
	showCharacter(random, "a random character")
	if(old != null):
		old.queue_free()


func showCharacter(character, text:String) -> void:
	doll.prepareCharacter(character)
	who.text = "Shown: " + text + ". Nothing is saved until you press Save."
	Belly.apply(doll, belly)


func randomCharacter():
	var made = DynamicCharacter.new()
	made.id = "bellyOverhaulPreview"
	add_child(made)
	var species:Array = []
	var all:Dictionary = GlobalRegistry.getAllSpecies()
	for id in all:
		if(all[id].canBeUsedForNPCType("inmate")):
			species.append(id)
	if(species.empty()):
		species = all.keys()
	made.npcSpecies = [RNG.pick(species)]
	made.npcGeneratedGender = NpcGender.generate()
	var gender = NpcGender.toNormalGender(made.npcGeneratedGender)
	if(gender == Gender.Male):
		made.npcThickness = RNG.randi_range(0, 60)
		made.npcFeminity = RNG.randi_range(0, 50)
	elif(gender == Gender.Female):
		made.npcThickness = RNG.randi_range(0, 110)
		made.npcFeminity = RNG.randi_range(50, 100)
	else:
		made.npcThickness = RNG.randi_range(0, 100)
		made.npcFeminity = RNG.randi_range(25, 75)
	for slot in BodypartSlot.getAll():
		var possible:Array = Bodypart.findPossibleBodypartIDs(slot, made, made.npcSpecies, made.npcGeneratedGender)
		var fullWeight:float = 0.0
		for pair in possible:
			fullWeight += max(0.0, pair[1])
		if(possible.empty() || !RNG.chance(fullWeight * 100.0)):
			continue
		var partID = RNG.pickWeightedPairs(possible)
		if(partID == null || str(partID) == ""):
			continue
		var part = GlobalRegistry.createBodypart(partID)
		if(part == null):
			continue
		made.giveBodypartUnlessSame(part)
		part.generateDataFor(made)
	made.applyRandomSkinAndColors()
	for slot2 in made.bodyparts:
		if(made.bodyparts[slot2] != null):
			made.bodyparts[slot2].generateRandomColors(made)
			made.bodyparts[slot2].generateRandomSkinIfCan(made)
	for one in made.getSpecies():
		var speciesObject = GlobalRegistry.getSpecies(one)
		if(speciesObject != null):
			speciesObject.onDynamicNpcCreation(made, {})
	made.updateNonBattleEffects()
	return made


func onDefaults() -> void:
	for row in Belly.ROWS:
		if(sliders.has(row["id"])):
			sliders[row["id"]].value = row["default"]


func onSave() -> void:
	if(ResourceLoader.exists(FOX_OPTIONS)):
		var fox = load(FOX_OPTIONS)
		for id in sliders:
			var option = fox.getOptionInternal(MODULE_ID, id)
			if(option != null):
				option.setOptionValue(int(sliders[id].value))
		fox.optionalySave()
		refreshScreens(get_tree().root)
	queue_free()


func onCancel() -> void:
	var knobs:Dictionary = Belly.KNOBS
	for id in before:
		knobs[id] = before[id]
	Belly.reapplyAll(get_tree())
	queue_free()


func refreshScreens(node:Node) -> void:
	var script = node.get_script()
	if(script != null && script.resource_path == FOX_SCREEN && node.is_visible_in_tree()):
		node.updateOptions()
	for child in node.get_children():
		refreshScreens(child)
