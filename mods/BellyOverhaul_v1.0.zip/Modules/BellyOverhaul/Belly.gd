
const BONE := "DeformBelly"
const BELLY_OUT := 0.706324
const POSITION_RANGE := 0.35
const DROOP_MAX := 0.6
const ROUND_RANGE := 0.75
const ROUND_PIVOT := 0.44
const GAME_MAX := 5.0
const GROUP := "bellyOverhaulDolls"
const META_P := "bellyOverhaulP"
const META_POSE := "bellyOverhaulPose"

const CAT := "Belly Overhaul"
const T_SLIDER := "slider"
const T_BUTTON := "button"
const RESTORE_ID := "bellyRestore"
const TESTBENCH_ID := "bellyTestBench"
const ROWS := [
	{"id": TESTBENCH_ID, "type": T_BUTTON, "title": "Try it on a character",
		"desc": "Opens a window with your character (a test one from the main menu) where every option below changes" 			+ " the belly at once. Save keeps the new values, Cancel leaves them as they were."},
	{"id": "bellyOut", "type": T_SLIDER, "default": 50, "title": "Sticks out",
		"desc": "How far the belly reaches forward. 50% = the game's own look, 0% = it barely comes out, 100% = twice as far."},
	{"id": "bellyRound", "type": T_SLIDER, "default": 50, "title": "Roundness",
		"desc": "How full and round the belly is: it swells forward from its middle. 50% = the game's own look," 			+ " less = flatter, more = rounder."},
	{"id": "bellyHeight", "type": T_SLIDER, "default": 50, "title": "Height",
		"desc": "How tall the belly is, from top to bottom. 50% = the game's own look."},
	{"id": "bellyPosition", "type": T_SLIDER, "default": 50, "title": "Position",
		"desc": "Moves the belly up or down the body. 50% = where the game puts it, less = lower, more = higher."},
	{"id": "bellyDroop", "type": T_SLIDER, "default": 0, "title": "Droop",
		"desc": "Tilts the belly down, like a heavy belly hanging. 0% = the game's own look."},
	{"id": "bellyWobble", "type": T_SLIDER, "default": 50, "title": "Wobble",
		"desc": "How much the belly jiggles when the body moves. 50% = the game's own, 0% = still." \
			+ " The game's own jiggle options still apply."},
	{"id": RESTORE_ID, "type": T_BUTTON, "title": "Restore defaults",
		"desc": "Puts every Belly Overhaul option back to its default: the game's own belly."},
]
const KNOBS := {}


static func knob(id:String) -> float:
	if(KNOBS.has(id)):
		return float(KNOBS[id])
	for row in ROWS:
		if(row["id"] == id):
			return float(row["default"])
	return 0.0


static func gamePose(p:float) -> Transform:
	p = min(5.0, p)
	var hs:float = 1.0 + max(0.0, p - 1.0)
	var vs:float = clamp(hs, 0.0, 2.0)
	return Transform.IDENTITY.scaled(Vector3(vs, hs, hs)).translated(Vector3(0.0, BELLY_OUT, 0.0) * clamp(p, -0.1, 1.0))


static func pose(p:float) -> Transform:
	p = min(GAME_MAX, p)
	var grown:float = clamp(p, 0.0, 1.0)
	var hs:float = 1.0 + max(0.0, p - 1.0)
	var vs:float = clamp(hs, 0.0, 2.0)
	var height:float = 1.0 + (knob("bellyHeight") - 50.0) / 100.0 * grown
	var round_:float = 1.0 + (knob("bellyRound") - 50.0) / 50.0 * ROUND_RANGE * grown
	var up:float = (knob("bellyPosition") - 50.0) / 50.0 * POSITION_RANGE * grown
	var out:float = BELLY_OUT * clamp(p, -0.1, 1.0) * knob("bellyOut") / 50.0
	var t:Transform = Transform.IDENTITY.scaled(Vector3(vs * height, hs, hs)).translated(Vector3(-up, out, 0.0))
	t = t * Transform(Basis.IDENTITY.scaled(Vector3(1.0, round_, 1.0)), Vector3(0.0, ROUND_PIVOT * (round_ - 1.0), 0.0))
	var droop:float = knob("bellyDroop") / 100.0 * DROOP_MAX * grown
	return Transform(Basis(Vector3(0.0, 0.0, 1.0), -droop), Vector3.ZERO) * t


static func gameP(t:Transform) -> float:
	if(t.basis.y.y > 1.0001):
		return t.basis.y.y
	return t.origin.y / BELLY_OUT


static func follow(doll) -> void:
	if(!doll.is_inside_tree() || doll.bellyJiggleBone == null):
		return
	var skeleton:Skeleton = doll.getDollSkeleton().getSkeleton()
	var bone:int = skeleton.find_bone(BONE)
	if(bone < 0):
		return
	var now:Transform = skeleton.get_bone_custom_pose(bone)
	if(doll.has_meta(META_POSE) && now == doll.get_meta(META_POSE)):
		return
	apply(doll, gameP(now))


static func apply(doll, p:float) -> void:
	if(doll.bellyJiggleBone == null):
		return
	var skeleton:Skeleton = doll.getDollSkeleton().getSkeleton()
	var bone:int = skeleton.find_bone(BONE)
	if(bone < 0):
		return
	var t:Transform = pose(p)
	skeleton.set_bone_custom_pose(bone, t)
	doll.set_meta(META_P, p)
	doll.set_meta(META_POSE, t)
	var stiffness:float = 0.1 / ((clamp(p, 0.0, 1.0) + 0.2) / 1.2)
	doll.bellyJiggleBone.stiffness = min(100.0, stiffness / max(0.001, knob("bellyWobble") / 50.0))


static func reapplyAll(tree:SceneTree) -> void:
	for doll in tree.get_nodes_in_group(GROUP):
		if(doll.has_meta(META_P)):
			apply(doll, float(doll.get_meta(META_P)))
