extends Node

const Belly := preload("res://Modules/BellyOverhaul/Belly.gd")


func _ready():
	process_priority = 1000
	var _ok = get_tree().connect("node_added", self, "onNodeAdded")


func onNodeAdded(node:Node) -> void:
	if(node is Doll3D):
		node.add_to_group(Belly.GROUP)


func _process(_delta):
	for doll in get_tree().get_nodes_in_group(Belly.GROUP):
		Belly.follow(doll)
