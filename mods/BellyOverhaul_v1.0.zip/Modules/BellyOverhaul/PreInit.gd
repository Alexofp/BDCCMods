func _init():
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		var watcher:Node = load("res://Modules/BellyOverhaul/Watcher.gd").new()
		watcher.name = "BellyOverhaulWatcher"
		tree.root.call_deferred("add_child", watcher)
