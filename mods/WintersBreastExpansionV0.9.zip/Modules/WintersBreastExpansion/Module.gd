extends Module

func _init():
	id = "WintersBreastExpansion"
	author = "Avery Winters (Code Improvements: Selinoccino) (Assets by Anon)"

	species = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/")

	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/")

func register(): # best to do it here
	.register() # call our parent script's one first

	var modules = GlobalRegistry.getModules().keys() # to avoid calling too many times, and also only getting the keys for performance reasons kinda

	#Bodyparts
	if ("WintersFluffyBodyparts" in modules):
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/"):
			GlobalRegistry.registerBodypart(bp)
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/"):
			GlobalRegistry.registerBodypart(bp)

	if ("songjohorseparts" in modules):
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersBreastExpansion/CompatabilityPatches/SongsVanillaParts/"):
			GlobalRegistry.registerBodypart(bp)
