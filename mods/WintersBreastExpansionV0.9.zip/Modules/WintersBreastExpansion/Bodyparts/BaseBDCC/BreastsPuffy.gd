extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Puffy breasts"
	id = "breastspuffy"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastPuffy/BreastPuffyFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastPuffy/BreastPuffy.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
