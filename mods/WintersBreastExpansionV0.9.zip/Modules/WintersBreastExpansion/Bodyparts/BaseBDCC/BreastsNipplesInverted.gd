extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Inverted nipple breasts"
	id = "breastsnippleinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNippleInverted/BreastNippleInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNippleInverted/BreastNippleInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
