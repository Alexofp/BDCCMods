extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Inverted puffy breasts"
	id = "breastspuffyinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastPuffyInverted/BreastPuffyInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastPuffyInverted/BreastPuffyInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
