extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy puffy breasts"
	id = "fluffbreastspuffy"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffy/FluffyBreastsPuffyFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffy/FluffyBreastsPuffy.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
