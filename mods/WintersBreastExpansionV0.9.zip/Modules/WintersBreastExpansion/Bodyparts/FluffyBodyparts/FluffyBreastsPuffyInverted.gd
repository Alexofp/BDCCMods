extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy inverted puffy breasts"
	id = "fluffbreastspuffyinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted/FluffyBreastsPuffyInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted/FluffyBreastsPuffyInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
