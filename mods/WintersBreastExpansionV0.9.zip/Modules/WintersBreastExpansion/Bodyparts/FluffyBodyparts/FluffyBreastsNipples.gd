extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy nipple breasts"
	id = "fluffbreasts"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsNipples/FluffyBreastsNippleFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsNipples/FluffyBreastsNipple.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
