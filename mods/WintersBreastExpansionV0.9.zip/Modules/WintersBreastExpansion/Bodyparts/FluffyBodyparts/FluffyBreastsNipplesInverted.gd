extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy inverted nipple breasts"
	id = "fluffbreastsnippleinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsNipplesInverted/FluffyBreastsNipplesInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsNipplesInverted/FluffyBreastsNipplesInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
