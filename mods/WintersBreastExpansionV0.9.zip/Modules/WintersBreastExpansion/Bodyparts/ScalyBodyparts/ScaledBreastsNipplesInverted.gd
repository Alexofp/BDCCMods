extends "res://Modules/WintersCoreModule/CustomTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Inverted nipple breasts"
	id = "scaledbreastsnippleinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastNipplesInverted/ScaledBreastNippleInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastNipplesInverted/ScaledBreastNippleInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
