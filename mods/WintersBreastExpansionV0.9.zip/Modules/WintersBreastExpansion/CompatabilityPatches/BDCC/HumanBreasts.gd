extends "res://Species/Human.gd"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return RNG.pick(["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv",])
	return RNG.pick(["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv",])
