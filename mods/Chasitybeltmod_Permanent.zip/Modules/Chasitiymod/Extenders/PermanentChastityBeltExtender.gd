extends GameExtender

func _init():
	id = "PermanentChastityBeltExtender"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.npcUpdateNonBattleEffects)
	_GES.register(self, ExtendGame.npcProcessTime)
	_GES.register(self, ExtendGame.npcHoursPassed)

func _restoreLockedBelt(_npc):
	if(_npc == null || !_npc.has_method("getInventory")):
		return

	var inv = _npc.getInventory()
	if(inv == null):
		return

	var worn = inv.getEquippedItem(InventorySlot.UnderwearBottom)
	if(worn != null && worn.id == "PermanentChastityBelt" && worn.has_method("hasLockPassword") && worn.hasLockPassword()):
		return

	var lockedBelt = null
	for item in inv.getItems():
		if(item.id == "PermanentChastityBelt" && item.has_method("hasLockPassword") && item.hasLockPassword()):
			lockedBelt = item
			break

	if(lockedBelt == null):
		return

	# If another game system unequips a locked belt into the NPC inventory,
	# put it back on. Anything that replaced the underwear slot is stored.
	inv.removeItem(lockedBelt)
	var ok = inv.forceEquipStoreOther(lockedBelt)
	if(!ok):
		inv.addItem(lockedBelt)
		return

	if(_npc.has_method("updateAppearance")):
		_npc.updateAppearance()

func npcUpdateNonBattleEffects(_npc:Character):
	_restoreLockedBelt(_npc)

func npcProcessTime(_npc:Character, _seconds):
	_restoreLockedBelt(_npc)

func npcHoursPassed(_npc:Character, _hours):
	_restoreLockedBelt(_npc)
