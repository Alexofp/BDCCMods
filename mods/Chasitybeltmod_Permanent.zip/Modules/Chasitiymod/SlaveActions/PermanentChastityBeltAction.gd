extends SlaveActionBase

func _init():
	id = "PermanentChastityBeltAction"
	actionType = Action
	sceneID = "PermanentChastityBeltActionScene"
	buttonPriority = 33
	slaveMinLevel = 0

func getVisibleName():
	return "Permanent chastity belt"

func getVisibleDesc():
	return "Lock a permanent chastity belt onto this slave with a password, or unlock an existing one."

func _getWornBelt(_slaveID):
	var npc = GlobalRegistry.getCharacter(_slaveID)
	if(npc == null):
		return null
	var item = npc.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
	if(item != null && item.id == "PermanentChastityBelt"):
		return item
	return null

func isActionVisible(_slaveID):
	if(_getWornBelt(_slaveID) != null):
		return true
	if(GM.pc != null && GM.pc.getInventory().hasItemID("PermanentChastityBelt")):
		return true
	return false

func checkCanDo(_slaveID, _extraSlavesIDs = {}):
	var npc = GlobalRegistry.getCharacter(_slaveID)
	if(npc == null):
		return [false, "NPC not found."]

	if(_getWornBelt(_slaveID) != null):
		return [true]

	if(GM.pc == null || !GM.pc.getInventory().hasItemID("PermanentChastityBelt")):
		return [false, "You need a Permanent Chastity Belt in your inventory."]

	if(!npc.invCanEquipSlot(InventorySlot.UnderwearBottom)):
		return [false, "This NPC cannot use the Underwear Bottom clothing slot."]

	if(npc.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		return [false, "Remove the item currently occupying the Underwear Bottom slot first."]

	return [true]
