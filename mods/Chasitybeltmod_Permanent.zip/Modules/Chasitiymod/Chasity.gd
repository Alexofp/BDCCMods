extends ItemBase


func _init():
	id = "Chasitybelt"

func getVisibleName():
	return "Chasitybelt"

func getDescription():
	return "A Chasitycage. The same as from the Straitjacket"

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getBuffs():
	return [
		]

func getTags():
	return [ItemTag.BDSMRestraint]

func isRestraint():
	return true

func coversBodyparts():
	return {
		BodypartSlot.Body: true,
		BodypartSlot.Vagina: true,
		BodypartSlot.Penis: true,
		}

func generateRestraintData():
	restraintData = RestraintStraitjacket.new()
	restraintData.setLevel(5)

func getRiggedParts(_character):
	return {
		"straitjacket": "res://Modules/Chasitiymod/Chasity.tscn",
	}

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
	}

func getInventoryImage():
	return "res://Modules/Chasitiymod/justjacket.png"
