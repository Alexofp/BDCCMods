extends ItemBase

const PASSWORD_SALT = "BDCC_PERMANENT_CHASTITY_BELT_MOD_V1|"
var lockPasswordHash:String = ""

func _init():
	id = "PermanentChastityBelt"

func getVisibleName():
	return "Permanent Chastity Belt"

func getDescription():
	var text = "A password-locked chastity belt based on the original Chasitybelt mod. Once locked onto an NPC, the NPC cannot struggle out of it or remove it with restraint keys."
	if(hasLockPassword()):
		text += "\n[color=yellow]Password lock: ACTIVE[/color]"
	else:
		text += "\n[color=gray]Password lock: not configured[/color]"
	text += "\nUse the 'Permanent chastity belt' slave action to apply or unlock it."
	return text

func getInventoryName():
	var result = .getInventoryName()
	if(hasLockPassword()):
		result += " (PASSWORD LOCKED)"
	return result

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getBuffs():
	return []

func getTags():
	return [
		ItemTag.BDSMRestraint,
		ItemTag.SoldByTheAnnouncer,
	]

func getPrice():
	return 100

func getSellPrice():
	return 50

func generateRestraintData():
	restraintData = RestraintUnremovable.new()
	restraintData.aiWontResist = true

# Password configuration is mandatory, so normal NPC force-equipping is disabled.
func canForceOntoNpc():
	return false

func canForceOntoStaticNpc():
	return false

# Prevent normal player inventory toggling. Use the dedicated slave action instead.
func getPutOnScene():
	return "PermanentChastityBeltCannotSelfEquipScene"

func getTakeOffScene():
	return "PermanentChastityBeltCannotSelfEquipScene"

func canBeEasilyRemovedByDom():
	return false

func isImportant():
	return true

func isPersistent():
	return true

func coversBodyparts():
	return {
		BodypartSlot.Body: true,
		BodypartSlot.Vagina: true,
		BodypartSlot.Penis: true,
	}

# Reuse the exact 3D model supplied by the original Chasitybelt mod.
func getRiggedParts(_character):
	return {
		"straitjacket": "res://Modules/Chasitiymod/Chasity.tscn",
	}

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
	}

func getInventoryImage():
	return "res://Modules/Chasitiymod/justjacket.png"

func hasLockPassword() -> bool:
	return lockPasswordHash != ""

func _hashPassword(password:String) -> String:
	return (PASSWORD_SALT + password).sha256_text()

func setLockPassword(password:String) -> bool:
	if(password.length() < 4):
		return false
	lockPasswordHash = _hashPassword(password)
	return true

func verifyLockPassword(password:String) -> bool:
	if(!hasLockPassword()):
		return false
	return _hashPassword(password) == lockPasswordHash

func clearLockPassword():
	lockPasswordHash = ""

func saveData():
	var data = .saveData()
	data["lockPasswordHash"] = lockPasswordHash
	return data

func loadData(_data):
	.loadData(_data)
	lockPasswordHash = SAVE.loadVar(_data, "lockPasswordHash", "")
