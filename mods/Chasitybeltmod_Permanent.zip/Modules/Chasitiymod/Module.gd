extends Module

func _init():
	id = "Chasitybeltmod"
	author = "KaitheredTiger (original) + permanent-lock extension"

	# Keep the original chastity belt available and add a separate permanent variant.
	items = [
		"res://Modules/Chasitiymod/Chasity.gd",
		"res://Modules/Chasitiymod/Items/PermanentChastityBelt.gd",
	]

	scenes = [
		"res://Modules/Chasitiymod/Scenes/PermanentChastityBeltActionScene.gd",
		"res://Modules/Chasitiymod/Scenes/PermanentChastityBeltCannotSelfEquipScene.gd",
	]

	slaveActions = [
		"res://Modules/Chasitiymod/SlaveActions/PermanentChastityBeltAction.gd",
	]

	gameExtenders = [
		"res://Modules/Chasitiymod/Extenders/PermanentChastityBeltExtender.gd",
	]
