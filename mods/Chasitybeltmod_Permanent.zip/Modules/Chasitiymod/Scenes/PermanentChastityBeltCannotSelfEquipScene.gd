extends "res://Scenes/SceneBase.gd"

func _init():
	sceneID = "PermanentChastityBeltCannotSelfEquipScene"

func _run():
	if(state == ""):
		saynn("This Permanent Chastity Belt is controlled through the slave action added by its mod.")
		saynn("For safety, it cannot be equipped on the player or applied through normal inventory toggling because a password must be configured first.")
		addButton("Continue", "Leave it in your inventory", "endthescene")

func _react(_action:String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	setState(_action)
