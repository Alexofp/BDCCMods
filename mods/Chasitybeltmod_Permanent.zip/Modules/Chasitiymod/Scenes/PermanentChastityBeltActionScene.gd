extends "res://Scenes/SceneBase.gd"

var npcID:String = ""
var npc:DynamicCharacter
var errorText:String = ""

func _init():
	sceneID = "PermanentChastityBeltActionScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		npcID = _args[0]
	npc = GlobalRegistry.getCharacter(npcID)

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _getWornBelt():
	if(npc == null):
		return null
	var item = npc.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
	if(item != null && item.id == "PermanentChastityBelt"):
		return item
	return null

func _getPlayerBelt():
	if(GM.pc == null):
		return null
	for item in GM.pc.getInventory().getItems():
		if(item.id == "PermanentChastityBelt"):
			return item
	return null

func _showError():
	if(errorText != ""):
		saynn("[color=red]" + errorText + "[/color]")

func _run():
	if(npc == null):
		saynn("The NPC could not be found.")
		addButton("Close", "Return", "endthescene")
		return

	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID})

	if(state == ""):
		var worn = _getWornBelt()
		if(worn != null):
			saynn("{npc.name} is wearing a password-locked Permanent Chastity Belt.")
			saynn("Enter the password to unlock and remove it. The NPC cannot remove it alone, struggle out of it, or use restraint keys on it.")
			_showError()
			var unlockBox:LineEdit = addTextbox("pcb_unlock_password")
			unlockBox.secret = true
			unlockBox.max_length = 64
			addButton("Unlock", "Remove the chastity belt if the password is correct", "unlock")
			addButton("Cancel", "Leave it locked", "endthescene")
			return

		var belt = _getPlayerBelt()
		if(belt == null):
			saynn("You do not have a Permanent Chastity Belt in your inventory.")
			addButton("Close", "Return", "endthescene")
			return

		if(!npc.invCanEquipSlot(InventorySlot.UnderwearBottom)):
			saynn("{npc.name} cannot use the Underwear Bottom clothing slot.")
			addButton("Close", "Return", "endthescene")
			return

		if(npc.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
			saynn("The Underwear Bottom slot is already occupied. Remove that item first.")
			addButton("Close", "Return", "endthescene")
			return

		saynn("Choose the password for the Permanent Chastity Belt before locking it onto {npc.name}.")
		saynn("The password must contain at least 4 characters. You will need the exact same password to remove it later.")
		_showError()

		say("Password: ")
		var passwordBox:LineEdit = addTextbox("pcb_password")
		passwordBox.secret = true
		passwordBox.max_length = 64
		say("\nConfirm password: ")
		var confirmBox:LineEdit = addTextbox("pcb_password_confirm")
		confirmBox.secret = true
		confirmBox.max_length = 64

		addButton("Lock it", "Set the password and equip the permanent chastity belt", "apply")
		addButton("Cancel", "Do not equip it", "endthescene")
		return

	if(state == "applied"):
		saynn("You secure the Permanent Chastity Belt around {npc.name} and engage its password lock.")
		saynn("[color=yellow]{npc.name} cannot struggle out of it, remove it with a restraint key, or take it off through normal inventory management.[/color]")
		addButton("Continue", "Finish", "endthescene")
		return

	if(state == "unlocked"):
		saynn("Password accepted. You unlock the Permanent Chastity Belt and remove it from {npc.name}.")
		saynn("The lock has been reset and the belt was returned to your inventory.")
		addButton("Continue", "Finish", "endthescene")
		return

func _react(_action:String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "apply"):
		var password:String = str(getTextboxData("pcb_password"))
		var confirmation:String = str(getTextboxData("pcb_password_confirm"))

		if(password.length() < 4):
			errorText = "The password must contain at least 4 characters."
			setState("")
			return
		if(password != confirmation):
			errorText = "The two passwords do not match."
			setState("")
			return

		var belt = _getPlayerBelt()
		if(belt == null):
			errorText = "The Permanent Chastity Belt is no longer in your inventory."
			setState("")
			return
		if(npc.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
			errorText = "The Underwear Bottom slot became occupied. Remove that item first."
			setState("")
			return
		if(!belt.setLockPassword(password)):
			errorText = "The password could not be configured."
			setState("")
			return

		GM.pc.getInventory().removeItem(belt)
		var equippedOk = npc.getInventory().equipItem(belt)
		if(!equippedOk):
			belt.clearLockPassword()
			GM.pc.getInventory().addItem(belt)
			errorText = "The restraint could not be equipped."
			setState("")
			return

		belt.onEquippedBy(GM.pc, true)
		npc.updateAppearance()
		npc.updateNonBattleEffects()
		errorText = ""
		setState("applied")
		return

	if(_action == "unlock"):
		var belt = _getWornBelt()
		if(belt == null):
			errorText = "The locked chastity belt is no longer equipped."
			setState("")
			return

		var password:String = str(getTextboxData("pcb_unlock_password"))
		if(!belt.verifyLockPassword(password)):
			errorText = "Incorrect password. The chastity belt remains locked."
			setState("")
			return

		if(!npc.getInventory().unequipItem(belt)):
			errorText = "The password was correct, but the restraint could not be removed."
			setState("")
			return

		npc.getInventory().removeItem(belt)
		belt.clearLockPassword()
		GM.pc.getInventory().addItem(belt)
		npc.updateAppearance()
		npc.updateNonBattleEffects()
		errorText = ""
		setState("unlocked")
		return

	setState(_action)

func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["errorText"] = errorText
	return data

func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	errorText = SAVE.loadVar(data, "errorText", "")
	npc = GlobalRegistry.getCharacter(npcID)
