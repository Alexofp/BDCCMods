BDCC - Chasitybelt mod + Permanent Chastity Belt
================================================

Este paquete sigue siendo un MOD independiente. No reemplaza ni modifica archivos
originales de BDCC.

Contenido
---------
1. Conserva el objeto original del mod:
   - Chasitybelt

2. Añade una variante nueva:
   - Permanent Chastity Belt
   - ID: PermanentChastityBelt
   - Slot: UnderwearBottom
   - Reutiliza exactamente Chasity.tscn y justjacket.png del mod original.

Funcionamiento de la variante permanente
----------------------------------------
- Se administra desde la acción de esclavo "Permanent chastity belt".
- Al colocarla en un NPC esclavizado, pide crear y confirmar una contraseña.
- Contraseña mínima: 4 caracteres.
- La contraseña NO se guarda en texto plano; se guarda un hash SHA-256 con salt.
- El NPC no puede quitársela forcejeando.
- Las restraint keys no pueden abrirla.
- No puede retirarse mediante el inventario normal.
- Si un proceso normal del NPC la desequipa y la deja en su inventario, el
  GameExtender del mod vuelve a colocarla automáticamente.
- Para retirarla hay que usar la misma acción e introducir la contraseña correcta.
- Al desbloquearla correctamente, vuelve al inventario del jugador y se borra
  la contraseña para poder configurarla de nuevo.
- El hash de la contraseña se conserva en las partidas guardadas.
- No puede autoequiparse al jugador por accidente.

Obtencion
---------
La variante permanente tiene la etiqueta SoldByTheAnnouncer y precio de 100 créditos,
igual que el enfoque utilizado para el mod de la camisa de fuerza permanente.

Instalacion
-----------
Usa el ZIP como mod de BDCC de la misma manera que otros paquetes .zip/.pck.
El ZIP contiene una carpeta Modules/Chasitiymod/ en su raiz.

IMPORTANTE
----------
Esta implementacion se integra con el sistema de NPC esclavizados de BDCC porque ese
sistema ofrece SlaveActions sin modificar el juego base.

No se modifican archivos como GlobalRegistry.gd, Inventory.gd, MainScene.gd ni ningun
otro archivo original de BDCC.

Validacion
----------
Se revisaron las APIs y firmas utilizadas contra el codigo de BDCC 0.1.7 fix1.
No se pudo ejecutar Godot 3.6 en este entorno, por lo que se recomienda probar una
copia de la partida antes de usarla en una partida principal.
