extends EventBase


func _init():
	id = "removeAttackEvent"
	
func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["MeScene", ""])

func run(_triggerID, _args):
	addButton("Remove attacks", "Remove modded attack moves so you can uninstall the mod without breaking your save.", "sounds")

func getPriority():
	return 0

func onButton(_method, _args):
	var list = GM.main.getDynamicCharacters()
	for pers in list:
		var _test = GlobalRegistry.getCharacter(pers)
		_test.npcAttacks.erase("aiLustStrip")
		_test.npcAttacks.erase("aiLustWeak")
		_test.npcAttacks.erase("aiLustStrong")
	
