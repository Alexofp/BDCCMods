extends Module

var heightList = {}
var data = {}
var hack

func _init():
	id = "LustierCombat"
	author = "bringulbangul"
	scenes = []
	events = [
		"res://Modules/LustierCombat/add_move.gd",
#		"res://Modules/LustierCombat/Erase_move_fix_save.gd",
	]
	gameExtenders = []
	attacks = [
		"res://Modules/LustierCombat/LustActions/aiLustStrip.gd",
		"res://Modules/LustierCombat/LustActions/aiLustStrong.gd",
		"res://Modules/LustierCombat/LustActions/aiLustWeak.gd",
	]
	perks = []
	
func getFlags():
	return {}


func preInit(): # Called before anything gets registered
	pass


