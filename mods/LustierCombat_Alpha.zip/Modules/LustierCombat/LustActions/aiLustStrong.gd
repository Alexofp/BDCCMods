extends Attack

func _init():
	id = "aiLustStrong"
	aiCategory = AICategory.Lust
	isPlayerAttack = false
	aiScoreMultiplier = 1
	
# sway hips, lick lips, tease cock, tease pussy, tease boobs

func _canUse(_attacker, _receiver, _context = {}):
	if(_attacker.getLust()+5 >= _attacker.lustThreshold()):
		return false
	if(!_attacker.getExposedPrivates().empty() && !_attacker.hasBoundArms()):
		return true
	else:
		return false

func getVisibleName(_context = {}):
	return "LustCombatStrong"

func getVisibleDesc(_context = {}):
	return "You shouldn't see this"
	
func canBeDodgedByPlayer(_attacker, _receiver):
	return true

func getRequirements():
	return []

func canSeeAnticipationTextWhenBlind():
	return true
	

func _doAttack(_attacker:BaseCharacter, _receiver, _context = {}):
	#_lustState.getCharacter().addLust(3)
	var _attackerName = _attacker.getName()
	var _receiverName = _receiver.getName()
	_attacker.addLust(RNG.randi_range(2,5))
	var options = _attacker.getExposedPrivates()
	var text = ""
	match RNG.pick(options):
		BodypartSlot.Breasts:
			if(RNG.chance(50)):
				if(RNG.chance(50)):
					text += "{attacker.name} poses and frames {attacker.his} chest with {attacker.his} arms."
				else:
					text += "{attacker.name} throws {attacker.his} arms wide, presenting {attacker.his} chest."
				
				text += RNG.pick([
					"You throw your arms wide to present  your chest, the harness tight around your [pc.chest]. You flex and stretch in the harness, showing how it constrains you. You flaunt your",
					"You peel open your _ to expose your [pc.chest] and [pc.nipples], running a hand up your [pc.skinFurScales] to one as you lock eyes with your target. You make sure that every bit of your musculature is open and on display before you bother to cover back up.",
					"Naked as you are, there’s nothing you need to do to expose your [pc.chest] and [pc.nipples], and running a hand up your [pc.skinFurScales] only enhances the delicious exposure. You make sure that every bit of your musculature is open and on display before you adopt a less sensual pose.",
					"Want to see just how perky these are? You give your target a sly smile while opening up your [pc.upperGarments], bouncing lightly on your [pc.feet] to make your [pc.fullChest] jiggle. Once the jiggle subsides a bit you pass a hand across the space under your tits, showing off how they return to sitting good and high on your chest once they stop bouncing. <i>Isn’t modern medicine great? No need for a bra with these big girls.</i> You flash a coy wink as you cover back up."
				])
#				boob size is -1 to 15
				if(_attacker.getBreastsSize() >= 10):
					text += "With a slow pivot and sultry look, you reach up to your [pc.upperGarments] and peel away the offending coverings with deliberate slowness. With each inch of breast-flesh you expose, your smile grows wider. You pause above your [pc.nipples] before letting them out with a flourish, digging your hands in to your soft, incredibly well-endowed chest in a display of mammary superiority. You cover up after a moment with a knowing smile."
					text += "Your [pc.fullChest] is already completely uncovered, but that doesn’t stop you from bringing your hands up to the more-than-ample cleavage and enhancing it by pressing down from each side. Your fingers sink deeply into your busty bosom as you look up at your chosen target, then, with a smile, you gentle shake them, making your titanic mammaries wobble oh-so-enticingly."
				elif(_attacker.getBreastsSize() >= 3):
					text += "You peel away your [pc.upperGarments] with careful, slow tugs to expose your [pc.fullChest]. Only after you’ve put yourself on display do you look back at your target and truly begin to tease, starting with a knowing wink. Then, you grab hold of your [pc.chest] and cup them to enhance your cleavage, lifting one then the other in a slow, sensuous display. Covering them up is something you do a little a regretfully."
					text += "You delicately trace a finger up your [pc.belly] to your exposed cleavage, slowing as it nestles in place. Your motion causes your breasts to gently sway as you explore yourself, and you pause to look at your target. With one hand, you squeeze your left tit, crushing your other hand’s finger into it while you grope yourself. With your erotic display complete, you release yourself and stretch, glad to be uncovered."
				elif(_attacker.getBreastsSize() >= 0):
					text += "You remove your [pc.upperGarments] with ease to free the perfectly rounded, perky breasts. You run your hands across the [pc.skinFurScales] to thumb at your nipples and grace your target with a lascivious look before putting the girls away a little regretfully."
					text += "With your [pc.fullChest] on complete display, you arch your back to present yourself as pleasingly as possible. Your hands wind their way up to your [pc.nipples] and give them a little tweak, sliding down the supple curve of your underbust. You give your target a smile before you stop, but even now, your bared [pc.skinFurScales] will taunt "
				
				if(RNG.chance(50)):
					text += "{receiver.name} is watching {attacker.name} and {attacker.name} hopes {attacker.name}’s offering a good show for them."
					text += "\n\n"
				if(RNG.chance(30) && _attacker.hasVagina()):
					text += "Having {attacker.his} nips rubbed makes {attacker.his} cute {pc.pussyStretch} pussy get wet with even more pussy juices."
					text += "\n\n"
				if(RNG.chance(20) && !_attacker.canBeMilked()):
					text += "{attacker.name} are not lactating but {attacker.name} feel like {attacker.name} can get used to these kinds of sensations, it feels so good to have {attacker.his} nips stimulated like this."
					text += "Drawing your hands sensuously up your [pc.belly], you cup your milky tits, giving one a firm squeeze as you let out a low, lusty moan. With gaze firmly captured, you pull away your [pc.upperGarments], releasing your [pc.fullChest] to the world, the fresh air blowing across your [pc.nipples]. You aren’t done teasing yet; a delicious idea slips into your devious mind."
				if(_attacker.stimulateLactation()):
					text += "[b]{attacker.his} {attacker.breasts} leak with some {pc.milk}, {attacker.name} began lactating![/b]"
					text += "Fumbling with your [pc.upperGarments] you release your [pc.chest], letting your bounty free with an enticing jiggle. You can feel s eyes on you, running over your [pc.chest], and you take advantage of that, swaying your shoulders to set off all kinds of pleasant jiggles. It’s not until you feel your [pc.milk] start to dribble out of your [pc.nipples] that you realize just what you’ve done. Reaching up, you grab the swells of your [pc.chest] to put them away, but you only succeed in coating yourself in your [pc.milk]. You can’t help but feel a little embarrassed and maybe a little aroused as you tuck your [pc.fullChest] away."
			else:
				if(RNG.chance(50)):
					text += "Feeling very turned on, {attacker.name} sink {attacker.his} fingers deeper into {attacker.his} {attacker.breasts} before proceeding to eagerly grope and squeeze them. Hard nipples press against {attacker.his} palms as {attacker.name} knead {attacker.his} chest and produce quiet moans."
					text += "\n\n"
				else:
					text += "{attacker.name} get a better grasp on {attacker.his} {attacker.breasts} and passionately massage them, pressing {attacker.his} digits harder into {attacker.his} soft flesh and brushing over the nips with {attacker.his} palms. It feels so good, {attacker.name} let out some quiet moans and keep fondling {attacker.his} chest."
					text += "\n\n"
				if(RNG.chance(30)):
					text += "{attacker.name} make sure to show off {attacker.his} nice tits to {attacker.his} opponent, groping them harder to let the enemy know what they are missing out on."
					text += "\n\n"
				if(RNG.chance(50) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
					text += "{attacker.name} are covered in cum, including {attacker.his} tits, it feels so good to knead them while little drops of cum slide down {attacker.his} fingers."
					text += "\n\n"
				if(RNG.chance(50) && _attacker.hasVagina() && _attacker.getLust() >= 50):
					text += "Teasing {attacker.his} breasts makes {attacker.name} so wet down there, {attacker.his} pussy is leaking with so much female juices.. {attacker.name} don’t stop and let out another quiet moan."
					text += "\n\n"
				if(RNG.chance(40) && _attacker.canBeMilked()):
					text += "{attacker.his} breasts seem to have quite some weight to them. As {attacker.name} grope yourself, {attacker.name} spot a few drops of {pc.milk} streaming down {attacker.his} tits. They are so itching to be milked properly."
					text += "\n\n"
				if(_attacker.stimulateLactation()):
					text += "[b]{attacker.his} {attacker.breasts} leak with some {pc.milk}, {attacker.name} began lactating![/b]"
					text += "\n\n"

		BodypartSlot.Penis:
			if(RNG.chance(50)):
				if(RNG.chance(50)):
					text += "A muffled moan escapes from {attacker.his} lips as {attacker.name} eagerly slide {attacker.his} {pc.masc} fingers along the length of {attacker.his} {pc.cock}."
					text += "\n\n"
				else:
					text += "Feeling horny, {attacker.name}’re giving the tip of {attacker.his} {pc.cock} a rub before focusing on stroking yourself closer to {attacker.his} climax."
					text += "\n\n"
				if(RNG.chance(50)):
					text += "{attacker.name} offer the enemy a good view of {attacker.his} cock as {attacker.name} jerk off. {attacker.name} smirk, hoping that they like the show."
					text += "\n\n"
				if(RNG.chance(10) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
					text += "So much cum on {attacker.his} body.. {attacker.name} catch some with {attacker.his} fingers and use it as lube, don’t wanna waste the good stuff."
					text += "\n\n"
				if(RNG.chance(50) && _attacker.getLust() >= 50):
					text += "{attacker.name} feel that {attacker.name}’re not that far, {attacker.his} cock is so throbbing and twitching a lot, each time {attacker.name} stroke {attacker.his} shaft a drop of precum appears at the tip and slides down {attacker.his} fingers."
					text += "\n\n"
				if(RNG.chance(20) && _attacker.hasVagina()):
					text += "As {attacker.name} tease {attacker.his} cock, {attacker.his} slit is getting more needy and wet, {attacker.name} feel it dripping juices as {attacker.name} focus on {attacker.his} other set of bits. {attacker.name} can’t hide the moans."
					text += "\n\n"
			else:
				if(RNG.chance(50)):
					text += "Focusing on {attacker.his} pleasure, {attacker.name} give {attacker.his} balls a gentle squeeze while still masturbating with the other hand. {attacker.name} produce a muffled noise of pleasure and keep massaging {attacker.his} balls while {attacker.his} {pc.cock} leaks more of {attacker.his} precum."
					text += "\n\n"
				else:
					text += "{attacker.his} {pc.cock} trickles with precum while {attacker.name} wrap {attacker.his} fingers around the balls and give them a squeeze."
					text += "\n\n"
				if(RNG.chance(50)):
					text += "{attacker.name} make sure to show off {attacker.his} balls and how {attacker.name}’re fondling them to the opponent."
					text += "\n\n"
				if(RNG.chance(10) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
					text += "{attacker.name}’re so messy, the cum of {attacker.his} previous lovers trickles down {attacker.his} body and drips from the tip of {attacker.his} cock."
					text += "\n\n"
				if(RNG.chance(50) && _attacker.getLust() >= 50):
					text += "{attacker.name} feel that {attacker.name}’re not that far, {attacker.his} cock is so throbbing and twitching a lot, each time {attacker.name} squeeze {attacker.his} nuts a drop of precum appears at the tip and slides down {attacker.his} fingers."
					text += "\n\n"
				if(RNG.chance(20) && _attacker.hasVagina()):
					text += "As {attacker.name} tease {attacker.his} cock, {attacker.his} slit is getting more needy and wet, {attacker.name} feel it dripping juices as {attacker.name} focus on {attacker.his} other set of bits. {attacker.name} can’t hide the moans."
					text += "\n\n"
			#stroke, cup
		BodypartSlot.Anus:
			if(RNG.chance(50)):
				text += "Turning away at an opportune moment, "
			else:
				text += "Suddenly, {attacker.name} twirls around, and you find yourself facing {receiver.name}'s rear. A cunning smile slaps itself across {attacker.his} face as "

				text += RNG.pick([
					"{attacker.name} reaches back, slapping {attacker.his} ass into a bounce before shaking it for {receiver.name}. ",
					"{attacker.name} begins to shake {attacker.his} booty, bouncing and tempting {receiver.name} with the goods. ",
					"{attacker.name} bounces {attacker.his} ass hypnotically, making it jiggle delightfully. {receiver.name} even gets a few glimpses of the asshole between {attacker.his} cheeks. ",
					"{attacker.name} starts to bounce {attacker.his} butt masterfully, even reaching back and spreading {attacker.his} cheeks, giving {receiver.name} an excellent view! ",
					"{attacker.name} spreads {attacker.his} buttcheeks and then uses two of {attacker.his} fingers to stretch {attacker.his} {pc.analStretch} butthole open. ",
					"{attacker.name} can’t hide {attacker.his} excitement. {attacker.name} turns around and bends {attacker.his} body forward, taking {attacker.his} time, holding {attacker.his} legs together until the moment {attacker.his} tailhole and other privates become visible! Then {attacker.name} spreads {attacker.his} legs and uses {attacker.his} arms to spread open {attacker.his} butt, showing off everything. ",
				])
				if(_attacker.getLust() >= 50):
					text += RNG.pick([
						"Then, {attacker.name} sticks {attacker.his} thumb inside {attacker.his} anus, beginning to lightly finger {attacker.his} backdoor. After a moment, {attacker.name} pulls {attacker.his} fingers away, looking over {attacker.his} shoulder at {receiver.name} seductively. ",
						"With a smirk, {attacker.name} easily plunges two fingers inside, burying them up to the base knuckle inside {attacker.his} anus. {attacker.name} gives it a quick few strokes, watching {receiver.name} over {attacker.his} shoulder while moaning lustily, being sure to give a good show. ",
						"{attacker.name} makes sure to give {receiver.name} the best view of {attacker.his} ass and thighs as {attacker.name} fingers {attacker.his} tight pucker. ",
						"{attacker.name} are so horny that {attacker.name} start to sway {attacker.his} hips and moan just from the thought of somebody using {attacker.his} tailhole. ",
				])
				
				
				if(RNG.chance(30) && _attacker.hasEffect(StatusEffect.HasCumInsideAnus)):
					text += "{attacker.his} digits get coated with cum of {attacker.his} previous lovers, it acts great as a lube, allowing {attacker.name} to thrust {attacker.his} fingers in and out with greater force."
				
				if(RNG.chance(30) && _attacker.hasPenis()):
					text += RNG.pick([
						"{attacker.his} {pc.cock} is throbbing as {attacker.name} occasionally brushes over {attacker.his} pleasure spot. ",
						"{attacker.his} {pc.cock} is hanging between {attacker.his} legs, looking very erect. ",
					])
					
				
				if(RNG.chance(50) && _attacker.hasBodypart(BodypartSlot.Vagina) && !_attacker.isBodypartCovered(BodypartSlot.Vagina)):
					text += RNG.pick([
						"{attacker.his} pussy is out on display, it looks spread open too, very inviting. ",
						"{attacker.name} is practically dripping by this point, {receiver.name} catches a glimpse of {attacker.his} sensitive folds. ",
					])
				


			#finger, clit, spread
		BodypartSlot.Vagina:
			match RNG.randi_range(1,3):
				1:
					if(RNG.chance(50)):
						text += "{attacker.name} slide a digit in and out of {attacker.his} {pc.pussyStretch} pussy, coating it in {attacker.his} juices while doing so. It feels good, {attacker.name} let out a noise of pleasure and keep finger-fucking yourself for anyone who might been lucky to see."
						text += "\n\n"
					else:
						text += "{attacker.name} thrust a few fingers in and out {attacker.his} {pc.pussyStretch} slit, shoving them nice and deep, pounding at the G-spot. {attacker.his} juices make it easy for {attacker.his} digits to slide inside and fuck {attacker.his} needy pussy."
						text += "\n\n"
					
					if(RNG.chance(30) && _attacker.hasEffect(StatusEffect.HasCumInsideVagina)):
						text += "As {attacker.name} finger yourself towards the orgasm, cum leaks out of {attacker.his} cunt and mixes with {attacker.his} girly fluids, so messy."
						text += "\n\n"
					
					if(RNG.chance(50)):
						text += "{attacker.name} make sure to show off how much pleasure this brings {attacker.name} to make {attacker.his} opponent jealous."
						text += "\n\n"
					
					if(RNG.chance(30) && _attacker.hasPenis()):
						text += "{attacker.his} {pc.cock} is throbbing and leaking pre as {attacker.name} pleasure {attacker.his} other set of bits."
						text += "\n\n"
					
					if(RNG.chance(50) && _attacker.getLust() >= 50):
						text += "{attacker.name} feel really close, {attacker.his} drippy cunt squirts with {attacker.his} juices, soft inner walls clench around {attacker.his} fingers as {attacker.name} push yourself further."
						text += "\n\n"
				2:
					if(RNG.chance(50)):
						text += "{attacker.his} finger switches focus to {attacker.his} cute clit and rubs it in a smooth circular motion. It makes {attacker.his} neglected pussy folds get wet with even more fluids. The desire fills {attacker.his} mind."
						text += "\n\n"
					else:
						text += "{attacker.name} quickly rub {attacker.his} nub from side to side, producing a cute moan as {attacker.his} pussy juices drip down {attacker.his} {pc.masc} thighs."
						text += "\n\n"
					
					if(RNG.chance(50)):
						text += "{attacker.name} make sure to show off how much pleasure teasing {attacker.his} clit brings {attacker.name} to hopefully drive {attacker.his} opponent desperate."
						text += "\n\n"
					
					if(RNG.chance(30) && _attacker.hasEffect(StatusEffect.HasCumInsideVagina)):
						text += "As {attacker.name} play with {attacker.his} pussy, old cum leaks out of {attacker.his} used fuckhole, creating a mess."
						text += "\n\n"
					
					if(RNG.chance(30) && _attacker.hasPenis()):
						text += "{attacker.his} {pc.cock} is throbbing and leaking pre as {attacker.name} pleasure {attacker.his} other set of bits."
						text += "\n\n"
					
					if(RNG.chance(50) && _attacker.getLust() >= 50):
						text += "{attacker.name} feel really close, {attacker.his} drippy cunt visibly pulsates and squirts with {attacker.his} juices."
						text += "\n\n"
				3:
					if(RNG.chance(50)):
						text += "Feeling incredibly lusty, {attacker.name} put two fingers onto {attacker.his} folds and spread them open. There is a visible line of transparent fluids connecting them as {attacker.name} hold {attacker.his} pussy spread for anyone who might be lucky to see it."
						text += "\n\n"
					else:
						text += "{attacker.name} use two digits to spread {attacker.his} needy pussy open, giving an incredible view of {attacker.his} pussy with strings of juices stretching down lower the longer {attacker.name} hold {attacker.his} fingers like that."
						text += "\n\n"
					
					if(RNG.chance(50)):
						text += "{attacker.name} provide such a great view of {attacker.his} fuckhole, there is no way {attacker.his} opponent’s attention wasn’t stolen by {attacker.his} lewd action."
						text += "\n\n"
					
					if(RNG.chance(60) && _attacker.hasEffect(StatusEffect.HasCumInsideVagina)):
						text += "Wow, as {attacker.name} hold {attacker.his} slit spread open, more and more jizz leaks out of it, messing up {attacker.his} thighs and dripping down to the floor."
						text += "\n\n"
					
					if(RNG.chance(50) && _attacker.getLust() >= 50):
						text += "{attacker.name} is so horny that {attacker.name} move {attacker.his} digits down to {attacker.his} pussy entering directly and stretch that one instead. {attacker.his} digits slip due to the amount of juices there but {attacker.name} manage to provide a great view of {attacker.his} inner walls being all drippy and even show off the fuckable cervix."
						text += "\n\n"
			#finger, spread, spank
	#########################


	return {
		text = text,
		lust = getLustDamageAmount(_attacker, _receiver),
	}

func getLustDamageAmount(_attacker, _receiver):
	var base_dmg = RNG.randi_range(5,10)
	var sexy_dmg = round(_attacker.getSkillsHolder().getStat("sexiness")/2)
	var pson0 = _receiver.getPersonality()
	var pson1 = _attacker.getPersonality()
	var chart = [
		[-1,0,1,-1,0,0],
		[0,-1, 1,0,0,1],
		[0,1,1,0,0,1],
		[1,0,0,1,1,0],
		[0,1,0,-1,-1,0],
		[-1,0,0,0,1,1]
	]
	var types = ["Brat", "Mean", "Subby", "Impatient", "Naive", "Coward"]
	var weights = []
	for _ii in range(types.size()):
		var row = chart[_ii]
		var best = []
		for _jj in range(row.size()):
			best.append( pson1.getStat(types[_ii])*-1 + pson0.getStat(types[_jj])*row[_jj] )
		weights.append(best.max())
	var factor = 1.0
	for each in weights:
		if(each < 1.0):
			each = 1.0
		factor = factor*each
	factor = clamp(factor, 1, 10)
	return round(base_dmg + sexy_dmg * factor)
	

func getAIScore(_attacker, _receiver):
	if(_receiver.painThreshold() >= _attacker.painThreshold() && _receiver.lustThreshold() <= _attacker.lustThreshold()):
		aiScoreMultiplier += 1
		
	if(_receiver.lustThreshold() <= _attacker.lustThreshold()):
		aiScoreMultiplier += 0.25
		
	if(_attacker.getSkillsHolder().getStat("sexiness") >= _receiver.getSkillsHolder().getStat("sexiness")):
		aiScoreMultiplier += 0.5
	
	# we want the enemy to have high lust
	if(aiCategory == AICategory.Lust):
		var enemyLustFraction = _receiver.getLustLevel()
		enemyLustFraction = clamp(enemyLustFraction, 0.0, 1.0)
		
		var score = 1.0 + pow(enemyLustFraction, 0.35)
		
		# if we're lusty we will prioritise lust attacks
		var lustFraction = _attacker.getLustLevel()
		lustFraction = clamp(lustFraction, 0.0, 1.0)
		if(lustFraction <= 70):
			score -= lustFraction
		else:
			score += lustFraction
		
		return score * aiScoreMultiplier
		
	return 0.0
	
func checkDodged(_attacker, _receiver, _damageType, _customDodgeMult = 1, _minChangeToDodge = 0.0, _playDodgeAnimation = true):
	return false

func getAnticipationText(_attacker, _receiver):
	if(_receiver.getLustLevel() >= 0.5):
		return "Both of you are getting close to the edge. {attacker.name}, determined to win, is going to start showing off the goods!"
	return "{attacker.name} prepares to flaunt {attacker.his} body, knowing that {receiver.name} is getting distracted by it."

func getPriority():
	return 4


func getExperience():
	return []
