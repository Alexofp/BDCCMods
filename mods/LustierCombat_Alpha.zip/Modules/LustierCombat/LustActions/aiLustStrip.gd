extends Attack

func _init():
	id = "aiLustStrip"
	aiCategory = AICategory.Lust
	isPlayerAttack = false
	aiScoreMultiplier = 1
	

func _canUse(_attacker, _receiver, _context = {}):
	if(_attacker.getLust() <= 10):
		return false
	if(_attacker.getLust()+5 >= _attacker.lustThreshold()):
		return false
	if(_attacker.isFullyNaked()):
		return false
	
	return true

func getVisibleName(_context = {}):
	return "LustCombatStrip"

func getVisibleDesc(_context = {}):
	return "You shouldn't see this"
	
func canBeDodgedByPlayer(_attacker, _receiver):
	return true

func getRequirements():
	return []

func canSeeAnticipationTextWhenBlind():
	return true
	
func calcFetishBonus(_attacker, _receiver:Player, _context = {}):
	var _u = _receiver.getFetishHolder()
	

func _doAttack(_attacker, _receiver, _context = {}):
	var _attackerName = _attacker.getName()
	var _receiverName = _receiver.getName()
	var attinv:Inventory = _attacker.getInventory()
	var text = ""
	var picker = []
	_attacker.addLust(RNG.randi_range(2,5))
	if(attinv.canUndressSlotSexEngine(InventorySlot.Body)):
		var itemState: ShirtAndShortsState = attinv.getEquippedItem(InventorySlot.Body).getItemState()
		if(!itemState.areShortsPulledDown()):
			picker.append("bottom")
		if(!itemState.isShirtOpened()):
			picker.append("top")
		match RNG.pick(picker):
			"bottom":
				itemState.pullDownShorts()
				if(_attacker.hasBoundArms() || _attacker.hasBlockedHands()):
					if(!_attacker.isBodypartCovered(BodypartSlot.Anus)):
						text += " {attacker.name} sways {attacker.his} {pc.masc} hips to the sides, trying to get the shorts to come off. Eventually {attacker.name} start to make progress! The shorts slowly slide down, exposing {attacker.his} {pc.thick} butt. {receiver.name} can only stare, surprised at {attacker,name}'s boldness."
						if(_attacker.hasPenis()):
							text += " As {attacker.name} does it, the tip of {attacker.his} cock catches on the ribbon, gets tugged down by it and then springs back as {attacker.his} shorts fall onto the floor. It's highly distracting for {receiver.name}!"
						elif(_attacker.hasVagina()):
							text += " As {attacker.his} shorts are pulled down, {attacker.his} wet needy slit gets completely exposed too. {receiver.name} is getting turned on just at the sight!"
					else:
						text += "{attacker.name} sway {attacker.his} {pc.masc} hips to the sides, trying to get the shorts to come off. The shorts slowly slide down, exposing {attacker.his} underwear. {receiver.name} can only stare, surprised at {attacker,name}'s boldness."
				else:
					if(!_attacker.isBodypartCovered(BodypartSlot.Anus)):
						text += "{attacker.name} sneaks two digits under {attacker.his} shorts and proceed to teasingly pull it down, exposing {attacker.his} {pc.thick} {pc.masc} butt. The erotic striptease has {receiver.name} feeling flushed."
						if(_attacker.hasPenis()):
							text += "As {attacker.name} does it, the tip of {attacker.his} cock catches on the ribbon, gets tugged down by it and then springs back as {attacker.his} shorts fall onto the floor. The motion is highly distracting for {receiver.name}!"
						elif(_attacker.hasVagina()):
							text += "As {attacker.his} shorts are pulled down, {attacker.his} wet needy slit gets completely exposed too. {receiver.name} is getting turned on just at the sight!"
					else:
						text += "{attacker.name} sneak two digits under {attacker.his} shorts and proceed to teasingly pull them down, exposing {attacker.his} underwear. {receiver.name} can only stare, surprised at {attacker,name}'s boldness."
				if(_attacker.hasEffect(StatusEffect.CoveredInCum)):
					text += "Pulling down the shorts reveals how much cum {attacker.name} also has underneath, {receiver.name} starts to fantasize about getting glazed too!"
				if(!_attacker.isBodypartCovered(BodypartSlot.Anus) && (_attacker.hasEffect(StatusEffect.HasCumInsideVagina) || _attacker.hasEffect(StatusEffect.HasCumInsideAnus))):
					text += "And {attacker.his} used fuckhole seems to be stuffed with someone’s cum. {receiver.name} is having a hard time controlling {receiver.his} lust!"
				
			"top":
				itemState.openShirt()
				if(!_attacker.isBodypartCovered(BodypartSlot.Breasts)):
					text += "{attacker.name} grabs onto {attacker.his} uniform’s shirt and tugs it out of the way, enjoying {receiver.name}'s reaction as {attacker.his} chest is slowly getting exposed. Eventually {attacker.name} finishes the striptease, exposing {attacker.his} {attacker.breasts} completely!"
				else:
					text += "{attacker.name} grabs onto {attacker.his} uniform’s shirt and tugs it out of the way, enjoying {receiver.name}'s reaction as {attacker.name} exposes what's beneath."
				if(_attacker.hasEffect(StatusEffect.CoveredInCum)):
					text += "Opening the shirt up how much cum {attacker.name} also has underneath, {receiver.name} starts to fantasize about getting glazed too!"
				if(RNG.chance(50) && _attacker.isVisiblyPregnant()):
					text += "{attacker.his} belly is looking quite pregnant, with no shirt it’s even more obvious. The thought of getting knocked up causes {receiver.name} to blush!"
		return {text = text, lust = getLustDamageAmount(_attacker, _receiver),}
	elif(attinv.canUndressSlotSexEngine(InventorySlot.UnderwearTop) || attinv.canUndressSlotSexEngine(InventorySlot.UnderwearBottom)):
		if(attinv.canUndressSlotSexEngine(InventorySlot.UnderwearTop)):
			picker.append("utop")
		if(attinv.canUndressSlotSexEngine(InventorySlot.UnderwearBottom)):
			picker.append("ubottom")
		match RNG.pick(picker):
			"utop":
				var itemState: BraState = attinv.getEquippedItem(InventorySlot.UnderwearTop).getItemState()
				if(!itemState.isBraPulledUp() || !itemState.isRemoved()):
					itemState.pullBraUp()
					if(_attacker.hasBlockedHands()):
						if(_attacker.hasNonFlatBreasts()):
							text += "{attacker.name} acts quickly and uses an opening to try and shake off {attacker.his} <casualName>. {receiver.name} seems to be quite intrigued by what {attacker.name} is trying to do. {attacker.his} {attacker.breasts} sway in the air and playfully bounce until finally escaping from under the fabric!"
						elif(!_attacker.hasNonFlatBreasts()):
							text += "{attacker.name} acts quickly and uses an opening to try and shake off {attacker.his} <casualName>. {receiver.name} seems to be quite intrigued by what {attacker.name} is trying to do. It is quite a struggle but in the end {attacker.name} manages to make the cloth slip up enough to uncover {attacker.his} {attacker.breasts}."
						if(RNG.chance(40) && _attacker.canBeMilked()):
							text += "{attacker.his} breasts seem to have quite some weight to them, {receiver.name} can spot a few drops of milk streaming down them."
						if(RNG.chance(20) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
							text += "Cum is dripping from {attacker.his} {attacker.breasts} as {attacker.name} stands still, it’s obvious at a glance that {attacker.name} had quite some fun with others, and {receiver.name} gets horny imagining what could have happened."
						text.replace("<casualName>", itemState.casualName)
					else:
						if(_attacker.hasNonFlatBreasts()):
							text += "{attacker.name} makes sure to get {receiver.name}'s attention by cupping {attacker.his} {attacker.breasts}, emphasizing their volume. Then {attacker.name} sinks {attacker.his} fingers under the <casualName> and casually pulls it up, making {attacker.his} lovely tits pop out from underneath it!"
						elif(!_attacker.hasNonFlatBreasts()):
							text += "{attacker.name} makes sure to get {receiver.name}'s attention by cupping {attacker.his} {attacker.breasts}, emphasizing their volume. Then {attacker.name} sinks {attacker.his} fingers under the <casualName> and casually pulls it up, exposing {attacker.his} flat chest with nice little nipples!"
						if(RNG.chance(40) && _attacker.canBeMilked()):
							text += "{attacker.his} breasts seem to have quite some weight to them, {receiver.name} can spot a few drops of milk streaming down them."
						if(RNG.chance(20) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
							text += "Cum is dripping from {attacker.his} {attacker.breasts} as {attacker.name} stands still, it’s obvious at a glance that {attacker.name} had quite some fun with others, and {receiver.name} gets horny imagining what could have happened."
						text.replace("<casualName>", itemState.casualName)
				
			"ubottom":
				var itemState: PantiesState = attinv.getEquippedItem(InventorySlot.UnderwearBottom).getItemState()
				if(!itemState.arePantiesShiftedAside() || !itemState.isRemoved()):
					itemState.shiftPantiesAside()
					if(_attacker.hasBlockedHands()):
						if(true):
							text += "{attacker.name} sways {attacker.his} {pc.thick} thighs and tries to shake off {attacker.his} <casualName>. {attacker.his} <casualName> slowly slide down {attacker.his} legs until {attacker.his} privates finally get exposed for {receiver.name} to see!"
						if(_attacker.hasPenis()):
							text += "{attacker.his} cock quickly springs up after it is freed, a drop of precum shines as it slides down from the tip. {Receiver.name} can practically taste it from here."
						if(_attacker.hasVagina()):
							text += "{attacker.his} cute pussy slit is now totally exposed for {receiver.name}! {attacker.his} inviting sensitive folds almost seem to radiate desire at {receiver.name}!"
						if(RNG.chance(50) && (_attacker.hasEffect(StatusEffect.HasCumInsideVagina) || _attacker.hasEffect(StatusEffect.HasCumInsideAnus))):
							text += "As soon as {attacker.name} succeeds, cum starts leaking from {attacker.his} used fuckhole, causing {receiver.name} to get very turned on!"
						if(RNG.chance(70) && _attacker.getLust() >= 50 && _attacker.hasVagina()):
							text += "{attacker.his} pussy is very much drenched with {attacker.his} juices, the anticipation only makes {receiver.name} more aroused."
						text.replace("<casualName>", itemState.casualName)
					else:
						if(true):
							text += "Overwhelmed with lust, {attacker.name} slide two fingers under {attacker.his} <casualName>. {attacker.his} <casualName> slowly slide down {attacker.his} legs until {attacker.his} privates finally get exposed for {receiver.name} to see!"
						if(_attacker.hasPenis()):
							text += "{attacker.his} cock quickly springs up after it is freed, a drop of precum shines as it slides down from the tip. {Receiver.name} can practically taste it from here."
						if(_attacker.hasVagina()):
							text += "{attacker.his} cute pussy slit is now totally exposed for {receiver.name}! {attacker.his} inviting sensitive folds almost seem to radiate desire at {receiver.name}!"
							text += "\n\n"
						if(RNG.chance(50) && (_attacker.hasEffect(StatusEffect.HasCumInsideVagina) || _attacker.hasEffect(StatusEffect.HasCumInsideAnus))):
							text += "As soon as {attacker.name} succeeds, cum starts leaking from {attacker.his} used fuckhole, causing {receiver.name} to get very turned on!"
						if(RNG.chance(70) && _attacker.getLust() >= 50 && _attacker.hasVagina()):
							text += "{attacker.his} pussy is very much drenched with {attacker.his} juices, the anticipation only makes {receiver.name} more aroused."
						text.replace("<casualName>", itemState.casualName)
		return {text = text, lust = getLustDamageAmount(_attacker, _receiver),}
			
	#########################

	return {
		text = text,
		lust = getLustDamageAmount(_attacker, _receiver),
	}

func getLustDamageAmount(_attacker, _receiver):
	var base_dmg = RNG.randi_range(3,8)
	var sexy_dmg = round(_attacker.getSkillsHolder().getStat("sexiness")/2)
	var pson0 = _receiver.getPersonality()
	var pson1 = _attacker.getPersonality()
	var chart = [
		[-1,0,1,-1,0,0],
		[0,-1, 1,0,0,1],
		[0,1,1,0,0,1],
		[1,0,0,1,1,0],
		[0,1,0,-1,-1,0],
		[-1,0,0,0,1,1]
	]
	var types = ["Brat", "Mean", "Subby", "Impatient", "Naive", "Coward"]
	var weights = []
	for _ii in range(types.size()):
		var row = chart[_ii]
		var best = []
		for _jj in range(row.size()):
			best.append( pson1.getStat(types[_ii])*-1 + pson0.getStat(types[_jj])*row[_jj] )
		weights.append(best.max())
	var factor = 1.0
	for each in weights:
		if(each < 1.0):
			each = 1.0
		factor = factor*each
	factor = clamp(factor, 1, 10)
	return round(base_dmg + sexy_dmg * factor)
	
	
func getAIScore(_attacker, _receiver):
	if(_receiver.painThreshold() >= _attacker.painThreshold() && _receiver.lustThreshold() <= _attacker.lustThreshold()):
		aiScoreMultiplier += 0.7
		
	if(_receiver.lustThreshold() <= _attacker.lustThreshold()):
		aiScoreMultiplier += 0.15
		
	if(_attacker.getSkillsHolder().getStat("sexiness") >= _receiver.getSkillsHolder().getStat("sexiness")):
		aiScoreMultiplier += 0.30
	
	# we want the enemy to have high lust
	if(aiCategory == AICategory.Lust):
		var enemyLustFraction = _receiver.getLustLevel()
		enemyLustFraction = clamp(enemyLustFraction, 0.0, 1.0)
		
		var score = 1.0 + pow(enemyLustFraction, 0.5) * 0.8
		
		# if we're lusty we will prioritise lust attacks
		var lustFraction = _attacker.getLustLevel()
		lustFraction = clamp(lustFraction, 0.0, 1.0)
		if(lustFraction <= 40):
			score -= lustFraction
		else:
			score += lustFraction
		
		return score * aiScoreMultiplier
		
	return 0.0
	
func checkDodged(_attacker, _receiver, _damageType, _customDodgeMult = 1, _minChangeToDodge = 0.0, _playDodgeAnimation = true):
	return false

func getAnticipationText(_attacker, _receiver):
	if(_receiver.getLustLevel() >= 0.5):
		return "{attacker.name} can tell they're having an effect on {receiver.name}, and {attacker.name} is about to show some skin."
	return "{attacker.name} looks ready to strip, increasing the effectiveness of their teasing!"

func getPriority():
	return 4


func getExperience():
	return []
