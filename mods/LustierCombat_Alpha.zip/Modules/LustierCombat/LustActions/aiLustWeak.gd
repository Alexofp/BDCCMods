extends Attack

func _init():
	id = "aiLustWeak"
	aiCategory = AICategory.Lust
	isPlayerAttack = false
	aiScoreMultiplier = 1
	
# sway hips, lick lips, tease cock, tease pussy, tease boobs

func _canUse(_attacker:BaseCharacter, _receiver, _context = {}):
	if(_attacker.getLust()+5 >= _attacker.lustThreshold()):
		return false
	return true

func getVisibleName(_context = {}):
	return "LustCombatWeak"

func getVisibleDesc(_context = {}):
	return "You shouldn't see this"
	
func canBeDodgedByPlayer(_attacker, _receiver):
	return true

func getRequirements():
	return []

func canSeeAnticipationTextWhenBlind():
	return true
	

func _doAttack(_attacker, _receiver, _context = {}):
	#_lustState.getCharacter().addLust(3)
	var _attackerName = _attacker.getName()
	var _receiverName = _receiver.getName()
	_attacker.addLust(RNG.randi_range(2,5))
	var text = ""
	match RNG.randi_range(0,4):
		0:
			if(RNG.chance(50)):
				text += "{attacker.name} spreads {attacker.his} legs apart and proceeds to sway {attacker.his} {pc.masc} rear to the sides, causing {attacker.his} thighs and buttcheeks to jiggle enticingly in {receiver.name}'s direction."
			else:
				text += "{attacker.name} puts some extra swing into {attacker.his} hip motions. {attacker.name} sways {attacker.his} {pc.thick} {pc.masc} hips to the sides, inviting {receiver.name} to watch while showing off all {attacker.his} curves."
			if(RNG.chance(50) && _attacker.isFullyNaked()):
				text += "{attacker.name}'s nudity is very distracting for {receiver.name}. The extra exposure heightens the erotic mood."
			if(RNG.chance(50) && _attacker.hasEffect(StatusEffect.HasBodyWritings)):
				text += "Someone left writings on {attacker.his}'s body and {receiver.name} is a little turned on by it."
		1:
			if(RNG.chance(50)):
				text += "{attacker.name} parts {attacker.his} lips and let {attacker.his} tongue peek out. {attacker.name} drags it full circle around {attacker.his} mouth and then blows {receiver.name} a kiss."
			else:
				text += "{attacker.name} teasingly bites {attacker.his} lower lip and shifts {attacker.his} gaze to the side, putting on a cute lewd expression that momentarily distracts {receiver.name}."
			if(RNG.chance(70) && _attacker.hasEffect(StatusEffect.HasCumInsideMouth)):
				text += "Some cum is dripping down from {attacker.his} lip, causing {receiver.name} to fantasize about oral."
			if(RNG.chance(50) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
				text += "{attacker.his} face is covered with someone’s fluids, a tease of what's to come should {receiver.name} surrender."
			if(RNG.chance(50) && _attacker.isBlindfolded()):
				text += "The fact that {attacker.name}’re blindfolded only makes {attacker.his} actions look more hot."
		2:
			if(_attacker.isWearingChastityCage() && not _attacker.getExposedPrivates().has(BodypartSlot.Penis)):
				if(RNG.chance(50)):
					text += "{attacker.name} move {attacker.his} hand down to {attacker.his} crotch and give {attacker.his} {pc.cock} a little rub through the clothing. {attacker.his} cage makes it impossible to stroke, making {attacker.name} take out {attacker.his} frustration on {receiver.name}."
				else:
					text += "{attacker.name} gets a feel for {attacker.his} covered up {pc.cock} and strokes {attacker.his} cage slightly through the clothing. All that built-up lust is directed at {receiver.name}."
			else:
				if(RNG.chance(50)):
					text += "{attacker.name} moves {attacker.his} hand down to {attacker.his} crotch and gives {receiver.name} a show. {attacker.his} {pc.cock} bulges out more in the process."
				elif(not _attacker.getExposedPrivates().has(BodypartSlot.Penis)):
					text += "{attacker.name} gets a feel for {attacker.his} covered up {pc.cock} and strokes it slightly through the clothing. The outline of {attacker.his} shaft becomes bigger as {receiver.name} can't help but watch."
			if(RNG.chance(50) && not _attacker.getExposedPrivates().has(BodypartSlot.Penis)):
				text += "{attacker.name} offers {receiver.name} a good view of {attacker.his} bulge. {attacker.name} smirks, hoping that they like the show."
		3:
			if(RNG.chance(50) && not _attacker.getExposedPrivates().has(BodypartSlot.Breasts)):
				text += "Feeling lusty, {attacker.name} grabs {attacker.his} covered {pc.breasts} and gently squeeze them, letting {receiver.name} see {attacker.name}'s hard nips, now poking through the clothing."
			elif(not _attacker.getExposedPrivates().has(BodypartSlot.Breasts)):
				text += "{attacker.name} runs {attacker.his} hands along {attacker.his} {pc.masc} sides and cups {attacker.his} {pc.breasts}. Still partially hidden by the fabric that covers them, {receiver.name} is distracted by the anticipation."
			if(RNG.chance(30)):
				text += "{attacker.name} turns slightly away, teasing {receiver.name} up until they are fully absorbedin the sight. {attacker.name}'s noises alone would make anyone horny."
			if(RNG.chance(50) && _attacker.hasEffect(StatusEffect.CoveredInCum)):
				text += "{attacker.name} is covered in cum, including {attacker.his} tits, it looks so delicious, little drops of cum slide down {attacker.his} fingers."

		4:
			if(RNG.chance(50) && not _attacker.getExposedPrivates().has(BodypartSlot.Vagina)):
				text += "{attacker.his}'s hand slides down to {attacker.his} covered up crotch and hovers there. {receiver.name} is reminded that behind all the cloth there are some needy pussy lips and a cute clit. {attacker.his} fingers outline {attacker.his} slit in a way intended to entice."
			elif(not _attacker.getExposedPrivates().has(BodypartSlot.Vagina)):
				text += "{attacker.name} sneaks {attacker.his} hand down to {attacker.his} slit. {attacker.name} begins rubbing it through all the cloth, and {attacker.his} little sounds of pleasure implant horny thoughts in {receiver.name}."
			if(RNG.chance(30)):
				text += "{attacker.name} smirks at {receiver.name} as {attacker.name} continues to tease {attacker.his} slit. {attacker.name}’re making it clear that if they want this they gotta work for it."
			if(RNG.chance(50) && _attacker.hasEffect(StatusEffect.HasCumInsideVagina) && not _attacker.getExposedPrivates().has(BodypartSlot.Vagina)):
				text += "As {attacker.name} continues to rub {attacker.his} slit through the clothing, some fluids leak out, they leave dark spots on the cloth and slide down {attacker.his} {pc.masc} thighs."
			if(RNG.chance(20) && _attacker.hasPenis()):
				text += "As {attacker.name} teases {attacker.his} cunt, {attacker.his} {pc.cock} is only getting harder and leaking more precum. {receiver.name} can't help but get aroused at the sight."
				
	#########################


	return {
		text = text,
		lust = getLustDamageAmount(_attacker, _receiver),
	}

func getLustDamageAmount(_attacker, _receiver):
	var base_dmg = RNG.randi_range(1,4)
	var sexy_dmg = round(_attacker.getSkillsHolder().getStat("sexiness")/2)
	var pson0 = _receiver.getPersonality()
	var pson1 = _attacker.getPersonality()
	var chart = [
		[-1,0,1,-1,0,0],
		[0,-1, 1,0,0,1],
		[0,1,1,0,0,1],
		[1,0,0,1,1,0],
		[0,1,0,-1,-1,0],
		[-1,0,0,0,1,1]
	]
	
	var types = ["Brat", "Mean", "Subby", "Impatient", "Naive", "Coward"]
	var weights = []
	for _ii in range(types.size()):
		var row = chart[_ii]
		var best = []
		for _jj in range(row.size()):
			best.append( pson1.getStat(types[_ii])*-1 + pson0.getStat(types[_jj])*row[_jj] )
		weights.append(best.max())
	var factor = 1.0
	for each in weights:
		if(each < 1.0):
			each = 1.0
		factor = factor*each
	factor = clamp(factor, 1, 10)
	return round(base_dmg + sexy_dmg * factor)

#	
#	high coward, impatience = move weight increases


func getAIScore(_attacker, _receiver):
	if(_receiver.painThreshold() >= _attacker.painThreshold() && _receiver.lustThreshold() <= _attacker.lustThreshold()):
		aiScoreMultiplier += 1
	
	if(_receiver.lustThreshold() <= _attacker.lustThreshold()):
		aiScoreMultiplier += 0.25
		
	if(_attacker.getSkillsHolder().getStat("sexiness") >= _receiver.getSkillsHolder().getStat("sexiness")):
		aiScoreMultiplier += 0.5
	
	# we want the enemy to have high lust
	if(aiCategory == AICategory.Lust):
		var enemyLustFraction = _receiver.getLustLevel()
		enemyLustFraction = clamp(enemyLustFraction, 0.0, 1.0)
		
		var score = 1.0 + pow(enemyLustFraction, 0.35)
		
		# if we're lusty we will prioritise lust attacks
		var lustFraction = _attacker.getLustLevel()
		lustFraction = clamp(lustFraction, 0.0, 1.0)
		score += lustFraction
		if(lustFraction >= 0.5): #decrease score at high lust to increase probability of stronger lust attacks
			score = score - lustFraction*2
		else:
			score = score + lustFraction*5
		
		return score * aiScoreMultiplier
		
	return 0.0

func checkDodged(_attacker, _receiver, _damageType, _customDodgeMult = 1, _minChangeToDodge = 0.0, _playDodgeAnimation = true):
	return false

func getAnticipationText(_attacker, _receiver):
	if(_receiver.getLustLevel() >= 0.5):
		return "{attacker.name} notices {receiver.name}'s lusty state and begins to tease {receiver.name}!"
	return "{attacker.name} has a teasing gleam in their eye, and they take a more seductive approach."

func getPriority():
	return 4

func isTease():
	return true

func getExperience():
	return []
