extends EventBase

var runOnce = true

func _init():
	id = "grantAttackEvent"
	
func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["WorldScene", ""]) # this is the base scene of the game

func run(_triggerID, _args):
	if(runOnce):
		var list = GM.main.getDynamicCharacters()
		for pers in list:
			var _test = GlobalRegistry.getCharacter(pers)
			var atks = _test._getAttacks()
			if(not atks.has("aiLustStrip") || not atks.has("aiLustWeak") || not atks.has("aiLustStrong")):
				_test.npcAttacks.append_array(["aiLustStrip", "aiLustWeak", "aiLustStrong",])
		
		runOnce = false


func addsAttacks():
	return [
		"aiLustStrip", "aiLustWeak", "aiLustStrong",
	]
