extends "res://Modules/MedicalModule/ElizaTalkScene.gd"

var DEBUG = false
var current_menu_scenes = []

func _init():
	sceneID = "ElizaTalkScene"

func _add_scene_to_menu(scene_name: String, scene_desc: String, scene_id: String, is_unlocked: bool = true, disabled_text: String = ""):
	current_menu_scenes.append({
		"name": scene_name,            # button text
		"desc": scene_desc,            # button tooltip
		"scene_id": scene_id,          # related scene
		"is_unlocked": is_unlocked,    #     condition(s) (optional)
		"disabled_text": disabled_text #     disabled button tooltip (if condition(s) is/are specified)
	})

func _build_scenes_list(bodypart: String, category: String) -> Array:
	current_menu_scenes.clear()
	
	# Here are the vanilla scenes with modified access conditions
	if bodypart == "breasts":
		if category == "manual":
			_add_scene_to_menu("Hand-milking",
			"Let Eliza milk your breasts with her hands",
			"ElizaMilkingBreastsHandScene"
			)
		elif category == "industrial":
			_add_scene_to_menu("Stall Hand-milking",
			"Let Eliza milk your breasts while in a milking stall",
			"ElizaMilkingBreastsStallScene",
				GM.main.SCI.hasMilkingTier1(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option."
			)
			_add_scene_to_menu("Breast pumps",
			"Let Eliza use industrial breast pumps",
			"ElizaMilkingBreastsPumpsScene",
				GM.main.SCI.hasMilkingTier1(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option."
			)
		elif category == "advanced":
			_add_scene_to_menu("Milking machine",
			"Let Eliza use a milking machine",
			"ElizaMilkingBreastsBDSMMachineScene",
				GM.main.SCI.hasMilkingTier2(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option."
			)
	elif bodypart == "penis":
		if category == "manual":
			_add_scene_to_menu("Hand-milking",
				"Let Eliza milk your cock with her hands",
				"ElizaMilkingSeedHandScene",
					GM.pc.hasReachablePenis(),
					"You need your cock to be reachable."
			)
			_add_scene_to_menu("Prostate milking",
				"Let Eliza milk your cock by milking your prostate directly",
				"ElizaMilkingProstateHandScene",
					GM.pc.hasReachableAnus(),
					"You need your anus to be reachable."
			)
			_add_scene_to_menu("Pawjob",
			"Let Eliza milk your cock with her hind paws",
			"ElizaMilkingSeedPawjobScene",
				getFlag("ElizaModule.s5hap", false) and GM.pc.hasReachablePenis(),
				"Earn Eliza's trust by following her storyline. You will also need your cock to be reachable."
			)
			_add_scene_to_menu("Fleshlight",
			"Invite someone else to milk you with a fleshlight",
			"ElizaMilkingSeedFleshlightScene",
				getFlag("SocketModule.h5completed", false) and GM.pc.hasReachablePenis(),
				"You need to complete Socket's storyline to unlock this option. You will also need your cock to be reachable."
			)
		elif category == "industrial":
			_add_scene_to_menu("Penis pump",
			"Let Eliza milk your cock with a penis pump",
			"ElizaMilkingSeedPumpScene",
				GM.main.SCI.hasMilkingTier1() and GM.pc.hasReachablePenis(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option. You will also need your cock to be reachable."
			)
			_add_scene_to_menu("Strapon milking",
			"Let Eliza milk your cock by pegging you",
			"ElizaMilkingProstateStraponScene",
				GM.main.SCI.hasMilkingTier1() and GM.pc.hasReachableAnus(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option. You will also need your anus to be reachable."
			)
		elif category == "advanced":
			_add_scene_to_menu("Milking machine",
			"Let Eliza use a milking machine",
			"ElizaMilkingSeedBDSMMachineScene",
				GM.main.SCI.hasMilkingTier2() and GM.pc.hasReachablePenis(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option. You will also need your cock to be reachable."
			)
	elif bodypart == "vagina":
		if category == "industrial":
			_add_scene_to_menu("Sybian",
			"Let Eliza use a sybian machine",
			"ElizaMilkingGirlcumSybianScene",
				GM.main.SCI.hasMilkingTier1(),
				"You need to become Eliza's assistant and upgrade the lab enough to use this option."
			)
	elif bodypart == "quick":
		if category == "all":
			_add_scene_to_menu("Quick Milking",
			"Ask Eliza to milk everything at once and fast!",
			"ElizaQuickMilkingScene",
				GM.main.SCI.hasMilkingTier3()
			)
	
	# Scenes added via the MMR API are placing here.
	var mmr = GlobalRegistry.getModule("MilkingMenuReorganizerModule")
	if mmr != null:
		var mod_scenes = mmr.milking_scenes[bodypart][category]
		for s in mod_scenes:
			var is_unlocked = true
			if s["obj"] != null and s["method"] != "":
				if s["obj"].has_method(s["method"]):
					is_unlocked = s["obj"].call(s["method"])
			
			_add_scene_to_menu(s["name"], s["desc"], s["scene_id"], is_unlocked, s["disabled_text"])
	
	return current_menu_scenes.duplicate()

func _get_randomable_scenes(bodypart: String) -> Array:
	var unlocked = []
	var categories = ["all"] if bodypart == "quick" else ["manual", "industrial", "advanced"]
	
	for category in categories:
		var scenes = _build_scenes_list(bodypart, category)
		for s in scenes:
			if s["is_unlocked"]: unlocked.append(s["scene_id"])
	return unlocked

func _draw_category_menu(bodypart: String, category: String, action_id: String, back_state: String):
	var scenes = _build_scenes_list(bodypart, category)
	if scenes.size() == 0:
		saynn("Actually... they don't exist. But they can be added by mods that use \"Milking Menu Reorganization\" mod.")
	else:
		for s in scenes:
			if s["is_unlocked"]: addButton(s["name"], s["desc"], action_id, [s["scene_id"]])
			else: addDisabledButton(s["name"], s["disabled_text"])
	addButton("Back", "Go back", back_state)

func _run():
	
	if(state == "milk_breasts_menu"):
		saynn("How do you want Eliza to milk your {pc.breasts}?")
		if(getModule("ElizaModule").hasLabAccess()):
			sayTanksVolume()
				
		addButton("Manual", "Hand-milking", "milking_breasts_manual")
		
		if(getModule("ElizaModule").hasLabAccess()):
			if(GM.main.SCI.hasMilkingTier1()):
				addButton("Industrial", "Pumps and stalls", "milking_breasts_industrial")
			else:
				addDisabledButton("Industrial", "You need to become Eliza's assistant and upgrade the lab enough to use this option.")
			if(GM.main.SCI.hasMilkingTier2()):
				addButton("Advanced", "Hi-tech machines", "milking_breasts_advanced")
			else:
				addDisabledButton("Advanced", "You need to become Eliza's assistant and upgrade the lab enough to use this option.")
		
		if _get_randomable_scenes("breasts").size() > 0:
			addButton("Random", "Let fate decide how your breasts will be milked!", "do_random_milking", ["breasts", "MedicalModule.Milked_Breasts"])
		else:
			addDisabledButton("Random", "No scenes available")
			
		addButton("Back", "Go back", "milking_menu")
		return 
	
	if(state == "milk_penis_menu"):		
		saynn("How do you want Eliza to milk your {pc.penis}?")
		if(getModule("ElizaModule").hasLabAccess()):
			sayTanksVolume()
				
		addButton("Manual", "Hands and... maybe legs?", "milking_penis_manual")
		
		if(getModule("ElizaModule").hasLabAccess()):
			if(GM.main.SCI.hasMilkingTier1()):
				addButton("Industrial", "Even more pleasant ways...", "milking_penis_industrial")
			else:
				addDisabledButton("Industrial", "You need to become Eliza's assistant and upgrade the lab enough to use this option.")
			if(GM.main.SCI.hasMilkingTier2()):
				addButton("Advanced", "Hi-tech machines", "milking_penis_advanced")
			else:
				addDisabledButton("Advanced", "You need to become Eliza's assistant and upgrade the lab enough to use this option.")
		
		if _get_randomable_scenes("penis").size() > 0:
			addButton("Random", "Let fate decide how your cock will be milked!", "do_random_milking", ["penis", "MedicalModule.Milked_Penis"])
		else:
			addDisabledButton("Random", "No scenes available")
			
		addButton("Back", "Go back", "milking_menu")
		return
	
	if(state == "milk_vagina_menu"):
		saynn("How do you want Eliza to milk your pussy?")
		if(getModule("ElizaModule").hasLabAccess()):
			sayTanksVolume()
				
		addButton("Manual", "Manual ways to milk pussy", "milking_vagina_manual")
		
		if(getModule("ElizaModule").hasLabAccess()):
			if(GM.main.SCI.hasMilkingTier1()):
				addButton("Industrial", "Even more pleasant ways...", "milking_vagina_industrial")
			else:
				addDisabledButton("Industrial", "You need to become Eliza's assistant and upgrade the lab enough to use this option.")
			if(GM.main.SCI.hasMilkingTier2()):
				addButton("Advanced", "Hi-tech machines", "milking_vagina_advanced")
			else:
				addDisabledButton("Advanced", "You need to become Eliza's assistant and upgrade the lab enough to use this option.")
		
		if _get_randomable_scenes("vagina").size() > 0:
			addButton("Random", "Let fate decide how your pussy will be milked!", "do_random_milking", ["vagina", "MedicalModule.Milked_Pussy"])
		else:
			addDisabledButton("Random", "No scenes available")
			
		addButton("Back", "Go back", "milking_menu")
		return
	if(state == "milk_quick_menu"):
		saynn("Eliza prepares the equipment for a full-body extraction. How should the automated systems process you today?")
		
		_draw_category_menu("quick", "all", "do_start_quick_milking_modded", "milking_menu")
		
		if _get_randomable_scenes("quick").size() > 0:
			addButton("Random", "Let fate decide your full-body milking experience", "do_random_milking", ["quick", "quick"])
		else:
			addDisabledButton("Random", "No scenes available")
		return
	
	# Breasts category
	if(state == "milking_breasts_manual"):
		saynn("How do you want Eliza to milk your {pc.breasts} manually?")
		_draw_category_menu("breasts", "manual", "do_start_milking_scene_breasts", "milk_breasts_menu")
		return	
	if(state == "milking_breasts_industrial"):
		saynn("How do you want Eliza to milk your {pc.breasts} by using industrial equipment?")
		_draw_category_menu("breasts", "industrial", "do_start_milking_scene_breasts", "milk_breasts_menu")
		return
	if(state == "milking_breasts_advanced"):
		saynn("How do you want Eliza to milk your {pc.breasts} by using modern, hi-tech equipment?")
		_draw_category_menu("breasts", "advanced", "do_start_milking_scene_breasts", "milk_breasts_menu")
		return
	
	# Penis category
	if(state == "milking_penis_manual"):
		saynn("How do you want Eliza to milk your {pc.penis} manually?")
		_draw_category_menu("penis", "manual", "do_start_milking_scene_seed", "milk_penis_menu")
		return
	if(state == "milking_penis_industrial"):
		saynn("How do you want Eliza to milk your {pc.penis} by using industrial equipment?")
		_draw_category_menu("penis", "industrial", "do_start_milking_scene_seed", "milk_penis_menu")
		return
	if(state == "milking_penis_advanced"):
		saynn("How do you want Eliza to milk your {pc.penis} by using modern, hi-tech equipment?")
		_draw_category_menu("penis", "advanced", "do_start_milking_scene_seed", "milk_penis_menu")
		return
	
	# Vagina category
	if(state == "milking_vagina_manual"):
		saynn("How do you want Eliza to milk your pussy manually?")
		_draw_category_menu("vagina", "manual", "do_start_milking_scene_girlcum", "milk_vagina_menu")
		return
	if(state == "milking_vagina_industrial"):
		saynn("How do you want Eliza to milk your pussy by using industrial equipment?")
		_draw_category_menu("vagina", "industrial", "do_start_milking_scene_girlcum", "milk_vagina_menu")
		return
	if(state == "milking_vagina_advanced"):
		saynn("How do you want Eliza to milk your pussy by using modern, hi-tech equipment?")
		_draw_category_menu("vagina", "advanced", "do_start_milking_scene_girlcum", "milk_vagina_menu")
		return
	
	if(state == "milking_menu"):
		if DEBUG == true:
			addButton("DEBUG", "Show debug options for milking features", "debug")
	
	if(state == "debug"):
		saynn("Lab access: " + str(getFlag("ElizaModule.s2hap")))
		saynn("Player have penis: " + str(GM.pc.getBodypart(BodypartSlot.Penis) != null))
		saynn("Player have vagina: " + str(GM.pc.getBodypart(BodypartSlot.Vagina) != null))
		
		var b = GM.pc.getBodypart(BodypartSlot.Breasts)
		var lactating = "No"
		if b != null and b.getFluidProduction() != null:
			lactating = str(b.getFluidProduction().getProductionSpeedPerHour()) + " ml/h"
		saynn("Player is lactating: " + lactating)
		
		saynn("Science points: " + str(GM.main.SCI.points))
		saynn("Pills discovered: " + str(GM.main.SCI.unlockedTFs.size()))
		saynn("Daily flags:")
		saynn("    Penis milked: " + str(getFlag("MedicalModule.Milked_Penis", false)))
		saynn("    Vagina milked: " + str(getFlag("MedicalModule.Milked_Pussy", false)))
		saynn("    Breasts milked: " + str(getFlag("MedicalModule.Milked_Breasts", false)))
		saynn("Eliza's storyline complete: " + str(getFlag("ElizaModule.s5hap", false)))
		saynn("Socket's storyline complete: " + str(getFlag("SocketModule.h5completed", false)))
		
		addButton("Switch lab access", "Turning on/off player\'s lab access", "debug_lab_access")
		addButton("Switch penis", "Turning on/off player\'s penis", "debug_switch_penis")
		addButton("Switch vagina", "Turning on/off player\'s vagina", "debug_switch_vagina")
		addButton("Induce lactation", "Inducing player\'s breasts lactation", "debug_induce_lactation")
		addButton("Give science points: 1000", "Give 1000 science points for player", "debug_give_science_points")
		addButton("Study unknown pill", "Add +1 non-real pill to unlock some upgrades", "debug_study_pill")
		addButton("Reset daily flags", "It allows you to be milked again today", "debug_reset_daily_flags")
		addButton("Switch Eliza's pawjob scene", "Turning on/off access to scene", "debug_eliza_access")
		addButton("Switch Socket's flashlight scene", "Turning on/off access to scene", "debug_socket_access")
		addButton("Back", "Go back", "milking_menu")
	
	._run()

func _react(_action: String, _args):
	if _action in [
		"milking_breasts_manual", "milking_breasts_industrial", "milking_breasts_advanced",
		"milking_penis_manual", "milking_penis_industrial", "milking_penis_advanced",
		"milking_vagina_manual", "milking_vagina_industrial", "milking_vagina_advanced",
		"debug"
		]:
		setState(_action)
		return
	
	if(_action == "do_start_milking_scene_quick"):
		setState("milk_quick_menu")
		return
	
	if(_action == "do_start_quick_milking_modded"):
		var scene_id = _args[0]
		setFlag("MedicalModule.Milked_Breasts", true)
		setFlag("MedicalModule.Milked_Penis", true)
		setFlag("MedicalModule.Milked_Pussy", true)
		runScene(scene_id)
		endScene()
		return
	
	if(_action == "do_random_milking"):
		var bodypart = _args[0]
		var vanilla_flag = _args[1]
		
		var available = _get_randomable_scenes(bodypart)
		if available.size() > 0:
			var random_scene_id = available[RNG.randi_range(0, available.size() - 1)]
			
			if bodypart == "quick":
				setFlag("MedicalModule.Milked_Breasts", true)
				setFlag("MedicalModule.Milked_Penis", true)
				setFlag("MedicalModule.Milked_Pussy", true)
			else:
				setFlag(vanilla_flag, true)
				
			runScene(random_scene_id)
			endScene()
		return
	
	if(_action == "debug_lab_access"):
		setFlag("ElizaModule.s2hap", !getFlag("ElizaModule.s2hap", false))
		return
	
	if(_action == "debug_switch_penis"):
		if GM.pc.hasBodypart(BodypartSlot.Penis):
			GM.pc.clearOrificeFluids()
			GM.pc.removeBodypart(BodypartSlot.Penis)
		else:
			var new_penis = GlobalRegistry.createBodypart("felinepenis")
			GM.pc.giveBodypart(new_penis)
			GM.pc.fillBalls()
		GM.pc.updateAppearance()
		return
	
	if(_action == "debug_switch_vagina"):
		if GM.pc.hasBodypart(BodypartSlot.Vagina):
			GM.pc.clearOrificeFluids()
			GM.pc.removeBodypart(BodypartSlot.Vagina)
		else:
			var new_vagina = GlobalRegistry.createBodypart("vagina")
			GM.pc.giveBodypart(new_vagina)
		GM.pc.updateAppearance()
		return
	
	if(_action == "debug_induce_lactation"):
		var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
		if breasts != null:
			breasts.induceLactation()
			if breasts.fluidProduction != null:
				breasts.fluidProduction.fillPercent(1.0)
		return
	
	if(_action == "debug_give_science_points"):
		GM.main.SCI.addPoints(1000)
		return
	
	if(_action == "debug_study_pill"):
		var base_name = "DebugPill"
		var num = 1
		var pill = base_name + str(num)
		while GM.main.SCI.unlockedTFs.has(pill):
			num += 1
			pill = base_name + str(num)
		GM.main.SCI.unlockedTFs[pill] = true
		setState(state)
		return
	
	if(_action == "debug_reset_daily_flags"):
		setFlag("MedicalModule.Milked_Breasts", false)
		setFlag("MedicalModule.Milked_Penis", false)
		setFlag("MedicalModule.Milked_Pussy", false)
		if GM.pc.hasEffect(StatusEffect.SoreNipplesAfterMilking):
			GM.pc.removeEffect(StatusEffect.SoreNipplesAfterMilking)
		return
	
	if(_action == "debug_eliza_access"):
		setFlag("ElizaModule.s5hap", !getFlag("ElizaModule.s5hap", false))
		return
	
	if(_action == "debug_socket_access"):
		setFlag("SocketModule.h5completed", !getFlag("SocketModule.h5completed", false))
		return
	
	._react(_action, _args)
