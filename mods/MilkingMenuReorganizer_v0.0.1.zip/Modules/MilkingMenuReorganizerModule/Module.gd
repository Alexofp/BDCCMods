extends Module

var milking_scenes = {
	"breasts": {"manual": [], "industrial": [], "advanced": []},
	"penis":   {"manual": [], "industrial": [], "advanced": []},
	"vagina":  {"manual": [], "industrial": [], "advanced": []},
	"quick":   {"all": []}
}

func getFlags():
	return {}

func _init():
	id = "MilkingMenuReorganizerModule"
	author = "Rahi"
	
	scenes = [
		"res://Modules/MilkingMenuReorganizerModule/ElizaTalkScenePatch.gd",
	]
	characters = []
	items = []
	events = []

func postInit():
	GlobalRegistry.registerScene("res://Modules/MilkingMenuReorganizerModule/ElizaTalkScenePatch.gd")

# API
func register_milking_scene(bodypart: String, category: String, scene_name: String, scene_desc: String, scene_id: String, condition_obj: Object = null, condition_method: String = "", disabled_text: String = ""):
	
	if not milking_scenes.has(bodypart) or not milking_scenes[bodypart].has(category):
		push_error("MMRModule Error: Invalid bodypart or category!")
		return
		
	milking_scenes[bodypart][category].append({
		"name": scene_name,
		"desc": scene_desc,
		"scene_id": scene_id,
		"obj": condition_obj,
		"method": condition_method,
		"disabled_text": disabled_text
	})
