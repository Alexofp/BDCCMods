extends "res://Species/Canine.gd"

var maleBoobs : Array = [] 
var femaleBoobs : Array = []
var hasArchetype = ("RAT_FluffyArchetypes" in GlobalRegistry.getModules())
var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersBreastExpansion" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & BreastsExpanded
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultTail(_gender):
	return "caninetail"

func getDefaultHead(_gender):
	return "caninehead"

func getDefaultEars(_gender):
	return "canineears"

# Default Fluffy / Scruffy Parts - We use the variables above to confirm that fluffybodyparts is installed but Rat_Archetypes is not make species fluffy
func getDefaultBody(_gender):
	if (hasFluff && !hasArchetype):
		return "scruffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if (hasFluff && !hasArchetype):
		return "scrufflegs"
	return "digilegs"

func getDefaultArms(_gender):
	if (hasFluff && !hasArchetype):
		return "scruffarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return RNG.pick(maleBoobs)
	return RNG.pick(femaleBoobs)

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersExpandedPenises" in GlobalRegistry.getModules()):
			return "knottedfluffypenis"
		else:
			return "caninepenis"
	else:
		return null
