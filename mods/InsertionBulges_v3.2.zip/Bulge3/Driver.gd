extends Reference
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const SnapReplayer := preload("res://Bulge3/Infer/SnapReplayer.gd")
const Lifetime := preload("res://Bulge3/Commit/Lifetime.gd")
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const Spring := preload("res://Bulge3/Commit/Spring.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const Resistance := preload("res://Bulge3/Stage/Resistance.gd")
const Fits := preload("res://Bulge3/Infer/Fits.gd")
const Squeeze := preload("res://Bulge3/Stage/Squeeze.gd")
const FieldMath := preload("res://Bulge3/Present/Field.gd")
const EFFECT_LAG := "lag"
const EFFECT_RESISTANCE := "resistance"
const EFFECT_SQUEEZE := "squeeze"
const PIPELINE_CLASSIC := "classic"
const PIPELINE_RESISTANCE := "resistance"
const PIPELINE_SQUEEZE := "squeeze"
const PIPELINE_FULL := "full"
const PIPELINE_BAKE := "bake"
const EFFECT_BAKED := "baked"
const PIPELINE_BRUSH := "brush"
const EFFECT_BRUSH := "brush"
const BRUSH_SAMPLES := 33
const EFFECT_BELLY := "belly"
const PIPELINES := {
	PIPELINE_CLASSIC: [],
	PIPELINE_RESISTANCE: [EFFECT_RESISTANCE],
	PIPELINE_SQUEEZE: [EFFECT_SQUEEZE],
	PIPELINE_FULL: [EFFECT_RESISTANCE, EFFECT_SQUEEZE],
	PIPELINE_BAKE: [EFFECT_BAKED],
	PIPELINE_BRUSH: [EFFECT_BAKED, EFFECT_BRUSH],
}
const PIPELINE_NAMES := [PIPELINE_CLASSIC, PIPELINE_RESISTANCE, PIPELINE_SQUEEZE,
	PIPELINE_FULL, PIPELINE_BAKE, PIPELINE_BRUSH]
const Belly := preload("res://Bulge3/Present/Belly.gd")
const PIPELINE := {"name": PIPELINE_CLASSIC, "read_at": -1000000, "forced": null}
const Backends := preload("res://Bulge3/Present/Backends.gd")
const LAG := {"read_at": -1000000, "on": true, "forced": null}
const LAG_READ_FRAMES := 30
static func setLag(value) -> void:
	LAG["forced"] = value
static func lagOn() -> bool:
	if(LAG["forced"] != null):
		return bool(LAG["forced"])
	var now:int = Engine.get_idle_frames()
	if(now - int(LAG["read_at"]) >= LAG_READ_FRAMES || now < int(LAG["read_at"])):
		LAG["read_at"] = now
		LAG["on"] = bool(Settings.value("bulgeLag"))
		var _ok = Spring.setRates(Spring.hzFor(float(Settings.value("bulgeLagInflate"))),
			Spring.hzFor(float(Settings.value("bulgeLagDeflate"))))
		FieldMath.setUnionOverlap(float(Settings.value("bulgeUnionOverlap")))
		var _tuned = FieldMath.setTuning(clamp(float(Settings.value("bulgeShapeFidelity")), 0.0, 1.0),
			clamp(float(Settings.value("bulgeRimShape")), 0.0, 1.0))
		var _damped = Spring.setZeta(1.0 - 0.5 * clamp(float(Settings.value("bulgeLagWobble")), 0.0, 1.0))
	return bool(LAG["on"])
const BELLY := {"read_at": -1000000, "variant": "off", "forced": null}
static func bellyVariant() -> String:
	if(BELLY["forced"] != null):
		return str(BELLY["forced"])
	var now:int = Engine.get_idle_frames()
	if(now - int(BELLY["read_at"]) >= LAG_READ_FRAMES || now < int(BELLY["read_at"])):
		BELLY["read_at"] = now
		BELLY["variant"] = str(Settings.value("bulgeBellyVariant"))
		var tuning:Dictionary = Belly.TUNING
		tuning["gain"] = 2.0 * clamp(float(Settings.value("bulgeBellyGain")), 0.0, 1.0)
	return str(BELLY["variant"])
static func runs(effect:String) -> bool:
	if(effect == EFFECT_LAG):
		return lagOn()
	if(effect == EFFECT_BELLY):
		return bellyVariant() != Belly.VARIANT_OFF
	var effects = PIPELINES.get(pipeline())
	if(typeof(effects) != TYPE_ARRAY):
		return false
	return effects.has(effect)
static func pipeline() -> String:
	if(PIPELINE["forced"] != null):
		return str(PIPELINE["forced"])
	var now:int = Engine.get_idle_frames()
	if(now - int(PIPELINE["read_at"]) >= LAG_READ_FRAMES || now < int(PIPELINE["read_at"])):
		PIPELINE["read_at"] = now
		PIPELINE["name"] = playable(str(Settings.value("bulgePipeline")))
	return str(PIPELINE["name"])
static func playable(name:String) -> String:
	if(!PIPELINES.has(name)):
		return PIPELINE_CLASSIC
	var gles2:bool = OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2
	if(PIPELINES[name].has(EFFECT_BAKED) && Backends.refusalFor(Backends.H6, gles2, !gles2) != ""):
		return PIPELINE_CLASSIC
	return name
static func setPipeline(name:String) -> bool:
	if(!PIPELINE_NAMES.has(name) || !PIPELINES.has(name)):
		push_error("Driver: no pipeline named '" + name + "'; still " + pipeline())
		return false
	PIPELINE["forced"] = name
	return true
const H1 := preload("res://Bulge3/Present/H1.gd")
const H6 := preload("res://Bulge3/Present/H6.gd")
const BakePool := preload("res://Bulge3/Doll/BakePool.gd")
const Eyes := preload("res://Bulge3/Observe/Eyes.gd")
const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const META_FRAME := "bdccBulge3Frame"
const META_REPORT := "bdccBulge3Report"
const META_PREVIOUS := "bdccBulge3Previous"
const META_POSE := "bdccBulge3Pose"
const META_POSE_SINCE := "bdccBulge3PoseSince"
const META_SPRING := "bdccBulge3Spring"
const META_POOL := "bdccBulge3BakePool"
const META_ITEMS := "bdccBulge3Items"
const META_CROTCH := "bdccBulge3Crotch"
static func tick(stageScene, frame:int, now:float):
	if(stageScene == null || !is_instance_valid(stageScene)):
		return null
	if(!Boot.mayRun("Bulge3/Driver.tick")):
		return null
	if(stageScene.has_meta(META_FRAME) && stageScene.get_meta(META_FRAME) == frame):
		if(stageScene.has_meta(META_REPORT)):
			return stageScene.get_meta(META_REPORT)
		return null
	stageScene.set_meta(META_FRAME, frame)
	var poseID = stageScene.get("currentAnim")
	var pose:String = ""
	if(poseID != null):
		pose = str(poseID)
	var age:float = ageOf(stageScene, pose, now)
	var wantedSamples:int = Fits.SHAPE_SAMPLES_V2
	if(runs(EFFECT_BRUSH)):
		wantedSamples = BRUSH_SAMPLES
	if(Fits.samples() != wantedSamples):
		var _set = Fits.setSamples(wantedSamples)
	var snapshot = Snapshot.build(stageScene, pose)
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var inferred:Dictionary = SnapReplayer.infer(snapshot, age)
	stageScene.set_meta(META_ITEMS, inferred["items"])
	var previous = null
	if(stageScene.has_meta(META_PREVIOUS)):
		previous = stageScene.get_meta(META_PREVIOUS)
	var engagements:Array = Lifetime.commit(previous, snapshot, inferred["items"], now, age)
	stageScene.set_meta(META_PREVIOUS, engagements)
	var rigs:Dictionary = {}
	if(typeof(snapshot.get("rig")) == TYPE_DICTIONARY):
		rigs = snapshot["rig"]
	var crotchWas:Dictionary = {}
	if(stageScene.has_meta(META_CROTCH)):
		crotchWas = stageScene.get_meta(META_CROTCH)
	var entries:Array = entriesFor(snapshot, engagements, rigs, crotchWas)
	var crotchNow:Dictionary = {}
	for one in entries:
		if(typeof(one["measures"]) == TYPE_DICTIONARY && one["measures"].has("crotch_hole")):
			crotchNow[Lifetime.relationKey(one["engagement"])] = one["measures"]["crotch_hole"]
	stageScene.set_meta(META_CROTCH, crotchNow)
	if(runs(EFFECT_RESISTANCE)):
		Resistance.apply(entries)
	if(runs(EFFECT_SQUEEZE)):
		Squeeze.apply(entries)
	if(runs(EFFECT_LAG)):
		var springWas = null
		if(stageScene.has_meta(META_SPRING)):
			springWas = stageScene.get_meta(META_SPRING)
		stageScene.set_meta(META_SPRING, Spring.settle(springWas, entries, now))
	var eyes = Eyes.new(stageScene)
	if(runs(EFFECT_BELLY)):
		Belly.apply(entries, eyes, bellyVariant())
	else:
		Belly.release(eyes)
	var report:Dictionary
	if(runs(EFFECT_BAKED)):
		report = H6.run(snapshot, entries, rigs, eyes, poolOn(stageScene))
	else:
		report = H1.run(snapshot, entries, rigs, eyes)
	stageScene.set_meta(META_REPORT, report)
	return report
static func poolOn(stageScene):
	if(stageScene.has_meta(META_POOL)):
		var had = stageScene.get_meta(META_POOL)
		if(had != null && is_instance_valid(had)):
			return had
	var pool = BakePool.new()
	pool.name = "Bulge3BakePool"
	stageScene.add_child(pool)
	stageScene.set_meta(META_POOL, pool)
	return pool
static func ageOf(stageScene, pose:String, now:float) -> float:
	if(!stageScene.has_meta(META_POSE) || str(stageScene.get_meta(META_POSE)) != pose):
		stageScene.set_meta(META_POSE, pose)
		stageScene.set_meta(META_POSE_SINCE, now)
	return now - float(stageScene.get_meta(META_POSE_SINCE))
static func entriesFor(snapshot:Dictionary, engagements:Array, rigs:Dictionary,
		crotchWas:Dictionary = {}) -> Array:
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	var crotchCount:Dictionary = {}
	for one in engagements:
		if(str(one["hole"]) == Intent.HOLE_VAGINA):
			crotchCount[str(one["hole_owner"])] = int(crotchCount.get(str(one["hole_owner"]), 0)) + 1
	var entries:Array = []
	for engagement in engagements:
		var measures = Intent.measuresFor(snapshot, engagement,
			str(crotchWas.get(Lifetime.relationKey(engagement), "")))
		if(typeof(measures) == TYPE_DICTIONARY && int(crotchCount.get(str(engagement["hole_owner"]), 0)) > 1 \
				&& measures.has("crotch_hole")):
			measures["anchor_hole"] = measures["crotch_hole"]
		var intent = null
		if(typeof(measures) == TYPE_DICTIONARY):
			intent = Intent.buildFor(rigs.get(engagement["hole_owner"]), measures,
				shafts.get(engagement["shaft"]), str(engagement["hole"]))
		if(typeof(intent) == TYPE_DICTIONARY && measures.has("anchor_hole")):
			var reachKeep:float = float(intent["reach"])
			intent = Intent.withAmplitude(intent, float(intent["amplitude"]) / (1.0 + FieldMath.unionOverlap()))
			intent["reach_keep"] = reachKeep
			intent["reach"] = max(float(intent["reach"]), reachKeep)
		entries.append({"engagement": engagement, "measures": measures, "intent": intent})
	return entries
