extends Reference
const Fits := preload("res://Bulge3/Infer/Fits.gd")
const PortalScenes := preload("res://Bulge3/Infer/PortalScenes.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const BulgeUtils := preload("res://Bulge3/Doll/BulgeUtils.gd")
const CROTCH_SWITCH_MARGIN := 0.1
static func measuresFor(snapshot, engagement:Dictionary, prefer:String = ""):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var shaftOwner = engagement.get("shaft")
	var holeOwner = engagement.get("hole_owner")
	var holeID:String = str(engagement.get("hole"))
	if(PortalScenes.owns(snapshot, shaftOwner, holeOwner)):
		return PortalScenes.measuresFor(snapshot, shaftOwner, holeOwner, holeID)
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	var card = shafts.get(shaftOwner)
	if(!Fits.isShaft(card)):
		return null
	var length:float = float(card["length"])
	if(length < Fits.MIN_SHAFT_LENGTH):
		return null
	var base:Vector3 = card["base"]
	var tip:Vector3 = card["tip"]
	var dir:Vector3 = (tip - base) / length
	var holes:Dictionary = {}
	if(typeof(snapshot.get("holes")) == TYPE_DICTIONARY):
		holes = snapshot["holes"]
	var candidate = Fits.measure(holes, shaftOwner, holeOwner, holeID, base, tip, dir, length, false)
	if(holeID == HOLE_VAGINA):
		var best = null
		var kept = null
		for crotch in [HOLE_VAGINA, HOLE_ANUS]:
			var open = Fits.measure(holes, shaftOwner, holeOwner, crotch, base, tip, dir, length, false)
			if(open != null && (best == null || looseFit(open, base, dir) < looseFit(best, base, dir))):
				best = open
			if(open != null && crotch == prefer):
				kept = open
		if(kept != null && best != null \
				&& looseFit(kept, base, dir) <= looseFit(best, base, dir) + CROTCH_SWITCH_MARGIN):
			best = kept
		if(best != null):
			candidate = best
	if(candidate == null):
		return null
	var oversize:Dictionary = {}
	if(typeof(snapshot.get("oversize")) == TYPE_DICTIONARY):
		oversize = snapshot["oversize"]
	var measures:Dictionary = Fits.measuresOf(candidate, card, oversize)
	measures["crotch_hole"] = str(candidate.get("hole", holeID))
	return measures
static func looseFit(candidate:Dictionary, base:Vector3, dir:Vector3) -> float:
	var entry:Vector3 = candidate["entry"]
	var lateral:float = (entry - (base + dir * (entry - base).dot(dir))).length()
	return (1.0 - dir.dot(candidate["axis"])) + lateral * Fits.LATERAL_WEIGHT
const HOLE_VAGINA := "vagina"
const HOLE_ANUS := "anus"
const HOLE_MOUTH := "mouth"
const CLIP_SKIN_OFFSET := 0.35
const ENTRY_DEADZONE := CLIP_SKIN_OFFSET
const FULL_DEPTH_FRACTION := 0.65
const FULLDEPTH_FLOOR_OVER_DEADZONE := 0.2
const BUMP_HEIGHT_MULT := 3.0
const BUMP_HEIGHT_MAX := 1.6
const SPREAD_OVERSIZE_CLAMP := [0.6, 1.4]
const BUMP_PUSH_MULT := 1.5
const BUMP_REACH_MIN := 0.25
const BUMP_REACH_MAX := 0.5
const BUMP_REACH_DEEPEST := 1.0
const AMPLITUDE_NO_FOLD_FRACTION = BulgeUtils.NO_FOLD_FRACTION
const BUMP_REACH_RATIO = 1.0 / AMPLITUDE_NO_FOLD_FRACTION
const BUMP_PUSH_MAX := 0.34
const MARGIN_USE := 0.85
const BUMP_TRAVEL := 1.0
const SOFT_LIMIT_KNEE := 0.75
const BUMP_COLUMN := 0.85
const BUMP_FRONT_PLANE := {"vagina": -0.35, "anus": -0.35}
const BUMP_FRONT_TILT := {"vagina": 0.0, "anus": 0.0}
const BUMP_FRONT_DIR := Vector3(-1.0, 0.0, 0.0)
const MAX_INSIDE_LENGTH := {"vagina": 3.0, "anus": 3.0}
const GIRTH_REFERENCE := 0.110
const SIZE_RESPONSE := 0.5
const SIZE_RESPONSE_MAX := 3.0
const MIN_AMPLITUDE := 0.005
const SHAPE_GAIN_MAX := 1.35
const SHAFT_AXIS_MIN_IN_PLANE := 0.5
const SHAFT_AXIS_MIN_FORWARD := 0.5
const SHADE_DEPTH_GAIN := 0.9
const ORIFICE_INWARD := {
	"vagina": Vector3(0.45, 0.89, 0.0),
	"anus": Vector3(-0.33, 0.94, 0.0),
	"mouth": Vector3(0.8, -0.6, 0.0),
}
const BUMP_TRAVEL_DIR := {"vagina": 1.0, "anus": 1.0, "mouth": -1.0}
static func buildFor(rig, measures:Dictionary, card, zone:String):
	if(typeof(rig) != TYPE_DICTIONARY || typeof(rig.get("hips")) != TYPE_TRANSFORM):
		return null
	if(!Fits.isShaft(card)):
		return null
	var anchorRest = bulgeOriginFor(rig, zone)
	if(typeof(measures.get("anchor_hole")) == TYPE_STRING && typeof(rig.get("origin")) == TYPE_DICTIONARY \
			&& rig["origin"].get(measures["anchor_hole"]) != null):
		anchorRest = rig["origin"][measures["anchor_hole"]]
	if(anchorRest == null):
		return null
	var base:Vector3 = card["base"]
	var tip:Vector3 = card["tip"]
	if(typeof(measures.get("shaft_base")) == TYPE_VECTOR3 \
			&& typeof(measures.get("shaft_tip")) == TYPE_VECTOR3):
		base = measures["shaft_base"]
		tip = measures["shaft_tip"]
	var length:float = float(card["length"])
	if(length < Fits.MIN_SHAFT_LENGTH):
		return null
	var hips:Transform = rig["hips"]
	var tipRest:Vector3 = hips.xform(tip)
	var baseRest:Vector3 = hips.xform(base)
	var shaftFlat:Vector3 = Vector3(tipRest.x - baseRest.x, tipRest.y - baseRest.y, 0.0)
	var depth:float = float(measures.get("depth", 0.0))
	var oversize:float = float(measures.get("oversize", 0.0))
	var along:float = length - depth
	var deadzone:float = float(measures.get("deadzone", ENTRY_DEADZONE))
	var fullDepth:float = max(length * FULL_DEPTH_FRACTION, deadzone + FULLDEPTH_FLOOR_OVER_DEADZONE)
	var depthAmount:float = clamp((depth - deadzone) / max(fullDepth - deadzone, 0.01), 0.0, 1.0)
	depthAmount = depthAmount * depthAmount * (3.0 - 2.0 * depthAmount)
	var mouthLimit:float = float(Settings.value("bulgeMouthReach"))
	var mouthRise:float = 0.0
	if(zone == HOLE_MOUTH):
		mouthRise = max(depth - ENTRY_DEADZONE, 0.0)
		if(bool(Settings.value("bulgeMouthAxisTravel"))):
			var axis = rig.get("neck_axis")
			if(typeof(axis) == TYPE_DICTIONARY):
				mouthRise = max(axisRise(axis, measures.get("entry"), tip) - ENTRY_DEADZONE, 0.0)
	var girth:float = insertedGirth(measures, zone)
	if(zone == HOLE_MOUTH):
		girth = girth * float(Settings.value("bulgeMouthShape"))
	var sizeResponse:float = clamp(SIZE_RESPONSE * girth / GIRTH_REFERENCE, 0.0, SIZE_RESPONSE_MAX)
	var spread:float = min(girth * BUMP_HEIGHT_MULT \
		* clamp(oversize, SPREAD_OVERSIZE_CLAMP[0], SPREAD_OVERSIZE_CLAMP[1]), BUMP_HEIGHT_MAX)
	var amplitude:float = girth * BUMP_PUSH_MULT * sizeResponse * depthAmount * oversize \
		* float(Settings.value("bulgeSizeModifier"))
	var shade:float = clamp(depthAmount * oversize * SHADE_DEPTH_GAIN, 0.0, 1.0) \
		* float(Settings.value("bulgeShade"))
	var travelAxis:Vector3 = travelAxisFor(zone, shaftFlat)
	var tipAlong:float = (tipRest - anchorRest).dot(travelAxis)
	var travel:float = 0.0
	if(zone == HOLE_MOUTH):
		travel = softLimit(mouthRise, mouthLimit) * BUMP_TRAVEL
	else:
		var rise:float = max(tipAlong - deadzone, 0.0)
		travel = softLimit(rise, float(MAX_INSIDE_LENGTH.get(zone, 1.0))) * BUMP_TRAVEL
	var column:float = BUMP_COLUMN
	if(zone == HOLE_MOUTH):
		column = float(Settings.value("bulgeMouthColumn"))
	var columnHalf:float = abs(travel) * column * 0.5
	var frontAxis:Vector3 = frontOf(travelAxis).normalized()
	var alongAxis:Vector3 = anchorRest + travelAxis * (travel * (1.0 - column * 0.5))
	var bandFrom:float = 0.0
	var bandTo:float = 1.0
	if(tipAlong > 0.0001):
		bandFrom = clamp(travel * (1.0 - column) / tipAlong, 0.0, 1.0)
		bandTo = clamp(travel / tipAlong, 0.0, 1.0)
	measures = withOtherHalf(measures, card, hips, frontAxis)
	amplitude = amplitude * shapeGain(measures, zone, bandFrom, bandTo)
	var contour:Array = []
	if(typeof(rig.get("contour")) == TYPE_ARRAY):
		contour = rig["contour"]
	var here = contourAt(contour, alongAxis.y)
	var frontPlane:float = float(BUMP_FRONT_PLANE.get(zone, -0.35))
	if(here != null):
		frontPlane = here.x
	var tilt:float = float(BUMP_FRONT_TILT.get(zone, 0.0))
	if(zone == HOLE_MOUTH):
		frontPlane = float(Settings.value("bulgeMouthFrontPlane"))
		tilt = float(Settings.value("bulgeMouthTilt"))
	var centreRest:Vector3 = Vector3(frontPlane, alongAxis.y, alongAxis.z)
	var frontDir:Vector3 = (frontAxis + Vector3(0.0, tilt, 0.0)).normalized()
	var margins:Array = []
	if(typeof(rig.get("margins")) == TYPE_ARRAY):
		margins = rig["margins"]
	var ceiling:float = min(pushCeiling(margins, here), reachMax() * AMPLITUDE_NO_FOLD_FRACTION)
	amplitude = softLimit(amplitude, ceiling)
	var reach:float = clamp(amplitude * BUMP_REACH_RATIO, BUMP_REACH_MIN, reachMax())
	amplitude = min(amplitude, reach * AMPLITUDE_NO_FOLD_FRACTION)
	return {
		"zone": zone,
		"centre_rest": centreRest,
		"front_dir_rest": frontDir,
		"travel_dir_rest": travelAxis,
		"reach": reach,
		"spread": spread,
		"amplitude": amplitude,
		"shade": shade,
		"column_half": columnHalf,
		"band_from": bandFrom,
		"band_to": bandTo,
		"shape": normalisedShape(measures, zone, bandFrom, bandTo),
		"axis_depth": axisDepthBelow(centreRest, baseRest, tipRest, frontDir),
		"clip_on_axis": clipOnAxis(along, measures),
		"visible": amplitude > MIN_AMPLITUDE,
	}
static func clipOnAxis(along:float, measures:Dictionary) -> float:
	var at:float = float(measures.get("clip_along", along))
	return max(at + float(measures.get("clip_skin", CLIP_SKIN_OFFSET)), CLIP_SKIN_OFFSET)
static func withAmplitude(intent:Dictionary, amplitude:float) -> Dictionary:
	var out:Dictionary = intent.duplicate()
	var reach:float = clamp(amplitude * BUMP_REACH_RATIO, BUMP_REACH_MIN, reachMax())
	reach = max(reach, float(intent.get("reach_keep", 0.0)))
	out["amplitude"] = min(amplitude, reach * AMPLITUDE_NO_FOLD_FRACTION)
	out["reach"] = reach
	out["visible"] = out["amplitude"] > MIN_AMPLITUDE
	return out
static func bulgeOriginFor(rig:Dictionary, zone:String):
	var origin:Dictionary = {}
	if(typeof(rig.get("origin")) == TYPE_DICTIONARY):
		origin = rig["origin"]
	if(zone == HOLE_MOUTH):
		return origin.get(HOLE_MOUTH)
	var vagina = origin.get(HOLE_VAGINA)
	var anus = origin.get(HOLE_ANUS)
	if(vagina == null):
		return anus
	if(anus == null):
		return vagina
	return (vagina + anus) * 0.5
static func insertedGirth(measures:Dictionary, zone:String) -> float:
	var entry:float = float(measures.get("girth_at_entry", 0.0))
	if(zone == HOLE_MOUTH):
		return entry
	var shape = measures.get("shape")
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 1):
		return entry
	var total:float = 0.0
	for girthHere in shape:
		total += float(girthHere)
	var mean:float = total / float(shape.size())
	if(mean <= 0.0):
		return entry
	return lerp(entry, mean, clamp(float(Settings.value("bulgeInsertedGirth")), 0.0, 1.0))
static func withOtherHalf(measures:Dictionary, card, hips:Transform, frontAxis:Vector3) -> Dictionary:
	if(typeof(measures.get("shape_up")) != TYPE_ARRAY || typeof(card.get("up")) != TYPE_VECTOR3):
		return measures
	var follow:float = clamp(float(Settings.value("bulgeOtherHalfFollow")), 0.0, 1.0)
	var add:float = clamp(float(Settings.value("bulgeOtherHalfAdd")), 0.0, 1.0)
	if(follow <= 0.0 && add <= 0.0):
		return measures
	var key:String = "shape_up"
	if(hips.basis.xform(card["up"]).dot(frontAxis) < 0.0):
		key = "shape_down"
	var out:Dictionary = measures.duplicate()
	out["shape"] = otherHalfShape(measures["shape"], measures[key], follow, add)
	return out
static func otherHalfShape(shape:Array, half:Array, follow:float, add:float) -> Array:
	if(half.size() != shape.size() || half.empty()):
		return shape
	var mean:float = 0.0
	for one in half:
		mean += float(one)
	mean = mean / float(half.size())
	var out:Array = []
	for i in range(shape.size()):
		out.append(max(lerp(float(shape[i]), float(half[i]), follow) + add * (float(half[i]) - mean), 0.0))
	return out
static func shapeGain(measures:Dictionary, zone:String, fromF:float, toF:float) -> float:
	if(zone == HOLE_MOUTH):
		return 1.0
	var band:Array = bandSamples(measures, fromF, toF)
	if(band.empty()):
		return 1.0
	var base:float = insertedGirth(measures, zone)
	if(base <= 0.0):
		return 1.0
	var peak:float = base
	for girthHere in band:
		peak = max(peak, girthHere)
	var fidelity:float = clamp(float(Settings.value("bulgeShapeFidelity")), 0.0, 1.0)
	return lerp(1.0, min(peak / base, SHAPE_GAIN_MAX), fidelity)
static func normalisedShape(measures:Dictionary, zone:String, fromF:float, toF:float) -> Array:
	if(zone == HOLE_MOUTH):
		return []
	var band:Array = bandSamples(measures, fromF, toF)
	if(band.empty()):
		return []
	var peak:float = 0.0
	for girthHere in band:
		peak = max(peak, girthHere)
	if(peak <= 0.0):
		return []
	var out:Array = []
	for girthHere in band:
		out.append(girthHere / peak)
	return out
static func bandSamples(measures:Dictionary, fromF:float, toF:float) -> Array:
	var shape = measures.get("shape")
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 1):
		return []
	if(shape.size() == 1):
		return [float(shape[0])]
	var out:Array = []
	for i in range(shape.size()):
		out.append(sampleAt(shape, lerp(fromF, toF, float(i) / float(shape.size() - 1))))
	return out
static func sampleAt(shape:Array, f:float) -> float:
	var last:int = shape.size() - 1
	if(last <= 0):
		return float(shape[0])
	var at:float = clamp(f, 0.0, 1.0) * float(last)
	var low:int = int(floor(at))
	var high:int = int(min(low + 1, last))
	return lerp(float(shape[low]), float(shape[high]), at - low)
static func anatomicalAxisFor(zone:String) -> Vector3:
	var inward = null
	if(zone != HOLE_MOUTH):
		inward = ORIFICE_INWARD.get(zone)
	if(inward != null):
		var flat:Vector3 = Vector3(inward.x, inward.y, 0.0)
		if(flat.length() > 0.0001):
			return flat.normalized()
	return Vector3(0.0, float(BUMP_TRAVEL_DIR.get(zone, 1.0)), 0.0)
static func travelAxisFor(zone:String, shaftFlat:Vector3) -> Vector3:
	var anatomical:Vector3 = anatomicalAxisFor(zone)
	if(zone == HOLE_MOUTH):
		return anatomical
	if(shaftFlat.length() < SHAFT_AXIS_MIN_IN_PLANE):
		return anatomical
	var candidate:Vector3 = shaftFlat.normalized()
	if(candidate.dot(anatomical) <= 0.0):
		return anatomical
	var blend:float = clamp(frontOf(candidate).length() / SHAFT_AXIS_MIN_FORWARD, 0.0, 1.0)
	return anatomical.linear_interpolate(candidate, blend).normalized()
static func frontOf(axis:Vector3) -> Vector3:
	return BUMP_FRONT_DIR - axis * BUMP_FRONT_DIR.dot(axis)
static func reachMax() -> float:
	return lerp(BUMP_REACH_MAX, BUMP_REACH_DEEPEST, clamp(float(Settings.value("bulgeReachDeeper")), 0.0, 1.0))
static func softLimit(value:float, limit:float) -> float:
	var knee:float = limit * SOFT_LIMIT_KNEE
	if(value <= knee):
		return value
	var rest:float = max(limit - knee, 0.001)
	return knee + rest * tanh((value - knee) / rest)
static func axisRise(axis, mouthAnchor:Vector3, tip:Vector3) -> float:
	var origin:Vector3 = axis["origin"]
	var dir:Vector3 = axis["dir"]
	return (mouthAnchor - origin).dot(dir) - (tip - origin).dot(dir)
static func axisDepthBelow(centreRest:Vector3, baseRest:Vector3, tipRest:Vector3, frontDir:Vector3) -> float:
	var line:Vector3 = tipRest - baseRest
	var lengthSq:float = line.length_squared()
	var nearest:Vector3 = baseRest
	if(lengthSq > 0.0001):
		nearest = baseRest + line * clamp((centreRest - baseRest).dot(line) / lengthSq, 0.0, 1.0)
	return max((centreRest - nearest).dot(frontDir), 0.0)
static func contourAt(contour:Array, restY:float):
	if(contour.empty()):
		return null
	var first:Vector3 = contour[0]
	if(restY <= first.x):
		return Vector2(first.y, first.z)
	var last:Vector3 = contour[contour.size() - 1]
	for i in range(1, contour.size()):
		var above:Vector3 = contour[i]
		if(above.x < restY):
			continue
		var below:Vector3 = contour[i - 1]
		var span:float = above.x - below.x
		var t:float = 0.0
		if(span > 0.0001):
			t = (restY - below.x) / span
		return Vector2(lerp(below.y, above.y, t), lerp(below.z, above.z, t))
	return Vector2(last.y, last.z)
static func pushCeiling(margins:Array, here) -> float:
	if(here != null && here.y > 0.0):
		return here.y * MARGIN_USE
	var room:float = -1.0
	for one in margins:
		var margin:float = float(one)
		if(margin <= 0.0):
			continue
		if(room < 0.0):
			room = margin
		else:
			room = min(room, margin)
	if(room <= 0.0):
		return BUMP_PUSH_MAX
	return room * MARGIN_USE
