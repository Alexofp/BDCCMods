extends Reference
const TUNING := {"knee": 0.35, "top": 1.7, "squeeze": 0.15}
static func squeeze() -> float:
	return float(TUNING["squeeze"])
static func setTuning(kneeValue:float, topValue:float, squeezeValue:float) -> bool:
	if(topValue <= kneeValue || squeezeValue < 0.0 || squeezeValue >= 1.0):
		push_error("Squeeze: need top > knee and squeeze in [0, 1); still " \
			+ str(TUNING["knee"]) + "/" + str(TUNING["top"]) + "/" + str(squeeze()))
		return false
	TUNING["knee"] = kneeValue
	TUNING["top"] = topValue
	TUNING["squeeze"] = squeezeValue
	return true
static func factorFor(oversize:float) -> float:
	var knee:float = float(TUNING["knee"])
	var top:float = float(TUNING["top"])
	var over:float = clamp(oversize, knee, top)
	return 1.0 - squeeze() * (over - knee) / (top - knee)
static func apply(entries:Array) -> void:
	if(squeeze() <= 0.0):
		return
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var measures = entry.get("measures")
		if(typeof(measures) != TYPE_DICTIONARY || !measures.has("oversize")):
			continue
		entry["squeeze"] = factorFor(float(measures["oversize"]))
