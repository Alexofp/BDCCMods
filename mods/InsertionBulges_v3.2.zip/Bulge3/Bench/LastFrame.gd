extends Node
const Eyes := preload("res://Bulge3/Observe/Eyes.gd")
const Driver := preload("res://Bulge3/Driver.gd")
const WAIT_FRAMES := 180
const SLOT_BODY := "body"
const NO_SCENE := "no stage scene in the tree with a getDolls() on it - this reports on a SEX SCENE" \
	+ " and there is none running. Start one and type it again."
const NO_REPORT := "the stage scene is there but Driver.tick has never stored a report on it. The" \
	+ " tick is driven from the carried Parts/MeshWithPattern.gd _process on the BODY mesh, so this" \
	+ " is the mod not being reached at all - check the boot line says backend=H1."
func run():
	yield(get_tree(), "idle_frame")
	var scene = stageIn(get_tree())
	if(scene == null):
		return NO_SCENE
	var waited:int = 0
	while(waited < WAIT_FRAMES):
		if(drewThisFrame(scene)):
			return block(get_tree())
		yield(get_tree(), "idle_frame")
		waited += 1
		if(!is_instance_valid(scene)):
			return NO_SCENE
	return "waited " + str(WAIT_FRAMES) + " frame(s) and NOT ONE of them carried a bulge row." \
		+ " What follows is the last of them - the skip reasons below are the finding, and they are" \
		+ " the same reasons on every frame of that wait:\n" + block(get_tree())
static func drewThisFrame(scene) -> bool:
	if(scene == null || !is_instance_valid(scene) || !scene.has_meta(Driver.META_REPORT)):
		return false
	var report = scene.get_meta(Driver.META_REPORT)
	if(typeof(report) != TYPE_DICTIONARY):
		return false
	return !listOf(report, "bulges").empty()
static func block(tree) -> String:
	var scene = stageIn(tree)
	if(scene == null):
		return NO_SCENE
	var out:Array = []
	out.append("scene " + scene.name + "   frame " + str(frameOf(scene)) \
		+ "   pose '" + str(scene.get("currentAnim")) + "'")
	var eyes = Eyes.new(scene)
	out.append(rosterBlock(scene, eyes))
	if(!scene.has_meta(Driver.META_REPORT)):
		return PoolStringArray(out).join("\n") + "\n" + NO_REPORT
	var report = scene.get_meta(Driver.META_REPORT)
	if(typeof(report) != TYPE_DICTIONARY):
		return PoolStringArray(out).join("\n") + "\n" + NO_REPORT
	out.append("report: bulges " + str(sizeOf(report, "bulges")) \
		+ "   clips " + str(sizeOf(report, "clips")) \
		+ "   drops " + str(sizeOf(report, "drops")) \
		+ "   skips " + str(sizeOf(report, "skips")) \
		+ "   cleared " + str(sizeOf(report, "cleared")))
	for key in ["skips", "drops"]:
		for row in listOf(report, key):
			if(typeof(row) == TYPE_DICTIONARY):
				out.append("  " + key + ": " + str(row.get("hole_owner", row.get("participant"))) \
					+ "/" + str(row.get("hole")) + " - " + str(row.get("reason")))
	var bulges:Array = listOf(report, "bulges")
	if(bulges.empty()):
		out.append("NO BULGE ROW THIS FRAME. Nothing below H1 can be at fault: STAGE produced none.")
		return PoolStringArray(out).join("\n")
	for row in bulges:
		if(typeof(row) != TYPE_DICTIONARY):
			continue
		out.append("")
		var participant = row.get("participant")
		var hole:String = str(row.get("hole"))
		var slot:int = int(row.get("slot"))
		out.append("bulge " + str(participant) + "/" + hole + " slot " + str(slot) \
			+ "   strength " + str(row.get("strength")) + "   radius " + str(row.get("radius")))
		out.append(chainFor(eyes, participant, hole, slot))
	return PoolStringArray(out).join("\n")
const HINT_ORDER := ["taper", "engine", "oralhint", "declaration", "clipname",
	"dollstate", "cuminside", "portal", "overlap", "geometry"]
static func hintsBlock(tree) -> String:
	var scene = stageIn(tree)
	if(scene == null):
		return NO_SCENE
	if(!scene.has_meta(Driver.META_ITEMS)):
		return NO_REPORT
	var items = scene.get_meta(Driver.META_ITEMS)
	var won:Array = []
	if(scene.has_meta(Driver.META_PREVIOUS) && typeof(scene.get_meta(Driver.META_PREVIOUS)) == TYPE_ARRAY):
		for one in scene.get_meta(Driver.META_PREVIOUS):
			if(typeof(one) == TYPE_DICTIONARY && typeof(one.get("provenance")) == TYPE_DICTIONARY):
				won.append(str(one["provenance"].get("source")) + " " + str(one.get("shaft")) + ">" \
					+ str(one.get("hole_owner")) + "/" + str(one.get("hole")))
	var said:Dictionary = {}
	if(typeof(items) == TYPE_ARRAY):
		for one in items:
			if(typeof(one) != TYPE_DICTIONARY):
				continue
			var source:String = str(one.get("source"))
			if(!said.has(source)):
				said[source] = []
			said[source].append(hintLine(one, won))
	var lines:Array = ["hints, pose '" + str(scene.get("currentAnim")) + "'"]
	var order:Array = HINT_ORDER.duplicate()
	for source in said:
		if(!order.has(source)):
			order.append(source)
	for source in order:
		if(!said.has(source)):
			lines.append("  " + source + ": -")
			continue
		lines.append("  " + source + ": " + PoolStringArray(said[source]).join(" | "))
	var eyes = Eyes.new(scene)
	for propID in eyes.propByID:
		var bodies:Dictionary = eyes.overlapOf(propID)
		var parts:Array = []
		for dollID in bodies:
			parts.append(str(dollID) + " " + str(stepify(float(bodies[dollID]), 0.01)))
		lines.append("  (" + str(propID) + " drawn over: " + PoolStringArray(parts).join(", ") \
			+ ", shaft=" + str(eyes.propShaftOf(propID) != null) + ")")
	return PoolStringArray(lines).join("\n")
static func hintLine(one:Dictionary, won:Array) -> String:
	var subject = one.get("subject")
	if(typeof(subject) != TYPE_DICTIONARY):
		subject = {}
	var what:String = str(subject.get("shaft", "?"))
	if(subject.has("hole_owner")):
		what += ">" + str(subject["hole_owner"])
	if(subject.has("hole")):
		what += "/" + str(subject["hole"])
	if(str(one.get("claim")) == "mouth_shaft"):
		what += " in a mouth"
	if(one.get("holds") != true):
		what = "NOT " + what
	what += " c" + str(one.get("confidence"))
	if(won.has(str(one.get("source")) + " " + str(subject.get("shaft")) + ">" \
			+ str(subject.get("hole_owner")) + "/" + str(subject.get("hole")))):
		what += " WON"
	return what
static func rosterBlock(scene, eyes) -> String:
	var dolls:Array = scene.getDolls()
	var lines:Array = ["dolls: " + str(dolls.size()) + " on stage   script " \
		+ str(eyes.sceneScriptPath())]
	for index in range(dolls.size()):
		var theDoll = dolls[index]
		var id:String = "doll" + str(index)
		if(theDoll == null || !is_instance_valid(theDoll)):
			lines.append("  " + id + ": GONE - the index stays taken, nobody shifts")
			continue
		var charID = null
		if(theDoll.has_method("getCharacterID")):
			charID = theDoll.getCharacterID()
		var inTree = null
		if(theDoll.has_method("is_visible_in_tree")):
			inTree = theDoll.is_visible_in_tree()
		var line:String = "  " + id + ": " + str(theDoll.get("name")) \
			+ "   visible=" + str(theDoll.get("visible")) \
			+ " inTree=" + str(inTree) \
			+ " onlyPenis=" + str(theDoll.get("isOnlyPenis")) \
			+ "   char=" + str(charID)
		if(eyes.dollFor(id) != theDoll):
			lines.append(line + "   EYES CANNOT REACH IT under this id")
			continue
		var helper = eyes.helperFor(id)
		if(helper == null):
			lines.append(line + "   no BulgeDoll helper - nothing readable off it")
			continue
		var holes:Array = []
		for holeID in Eyes.DOLL_HOLES:
			if(helper.getOrificeInfo(holeID) != null):
				holes.append(holeID)
		lines.append(line + "   shaft=" + str(helper.getShaftInfo() != null) \
			+ " holes=" + str(holes))
	return PoolStringArray(lines).join("\n")
static func chainFor(eyes, participant, hole:String, slot:int) -> String:
	var theDoll = eyes.dollFor(participant)
	if(theDoll == null):
		return "  GATE 1 doll: NONE for this participant - H1 skipped the write (H1.run:193)"
	var helper = eyes.helperFor(participant)
	if(helper == null):
		return "  GATE 1 helper: NONE - Bulge3/Doll/BulgeDoll.gd would not attach (H1.run:193)"
	var skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return "  GATE 2 skeleton: NONE - applyBulge returned (BulgeDoll.gd:317)"
	var all:Array = helper.getPatternMeshesForSlot(SLOT_BODY)
	var drawable:Array = helper.getBulgeMeshesForZone(hole)
	var lines:Array = ["  body meshes: " + str(all.size()) + " total, " + str(drawable.size()) \
		+ " able to take a bulge"]
	for themesh in all:
		lines.append("    " + str(themesh.name) + ": visible=" + str(themesh.visible) \
			+ " fancyMaterial=" + str(themesh.get("fancyMaterial") != null) \
			+ " uvFit=" + str(themesh.get("uvFit") != null) \
			+ " supportsBulges=" + str(themesh.supportsBulges()) \
			+ "   bulge_par" + str(slot) + "=" + readBack(themesh, slot))
	if(drawable.empty()):
		lines.append("  GATE 3 meshes: NONE able to take it - applyBulge returned" \
			+ " (BulgeDoll.gd:314). A fancyMaterial of false is the carried" \
			+ " Parts/MeshWithPattern.gd never building one, which is advanced shaders off.")
	return PoolStringArray(lines).join("\n")
static func readBack(themesh, slot:int) -> String:
	var material = themesh.get("fancyMaterial")
	if(material == null):
		return "(no material)"
	return str(material.get_shader_param("bulge_par" + str(slot)))
static func stageIn(tree):
	if(tree == null || !tree.has_method("get_root")):
		return null
	return withDolls(tree.get_root())
static func withDolls(node):
	if(node == null || !is_instance_valid(node)):
		return null
	if(node.has_method("getDolls")):
		return node
	for child in node.get_children():
		var found = withDolls(child)
		if(found != null):
			return found
	return null
static func frameOf(scene) -> int:
	if(!scene.has_meta(Driver.META_FRAME)):
		return -1
	return int(scene.get_meta(Driver.META_FRAME))
static func listOf(report:Dictionary, key:String) -> Array:
	if(typeof(report.get(key)) != TYPE_ARRAY):
		return []
	return report[key]
static func sizeOf(report:Dictionary, key:String) -> int:
	return listOf(report, key).size()
