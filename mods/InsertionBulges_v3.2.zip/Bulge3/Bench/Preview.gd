extends Node
const Bake := preload("res://Bulge3/Present/Bake.gd")
const FieldMath := preload("res://Bulge3/Present/Field.gd")
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const MAGIC := "bulge3-preview"
const MATERIAL_PATH := "res://Player/Player3D/Skins/MaterialForPartWithSkin.tres"
const BAKED_TEX_PARAM := "bulge_baked"
const BAKED_ON_PARAM := "bulge_baked_on"
const OLD_PATH_PARAM := "bulge_seg0"
const REASON_NO_BAKED := "the skin material in force declares no bulge_baked uniform"
const REASON_NO_SHADER := "the skin material in force carries no shader at all"
const REASON_NO_MATERIAL := "there is no ShaderMaterial at res://Player/Player3D/Skins/MaterialForPartWithSkin.tres"
const OLD_SLOTS := 3
const RESOLUTIONS := [64, 128, 256]
const MAX_SLOTS := 16
const OUT_PATH := "user://bulge3_preview.png"
const PANELS := ["OLD(v2, 3 slots)", "NEW(H6, baked)", "DIFF x%d"]
const DIFF_GAIN := 8.0
const SHEET_BG := Color(0.35, 0.35, 0.35, 1.0)
const GUTTER := 8
const REACH := 0.26
const SPREAD := 0.055
const COLUMN_HALF := 0.035
const SHADE := 0.5
const AXIS_DEPTH := 0.06
const FLAT_SHAPE := [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
const BAND_X := 0.30
const FIRST_Y := 0.12
const LAST_Y := 0.88
const SLOT_STEP := 0.16
static func slotAt(cy:float, depth:float, width:float, shade:float) -> Dictionary:
	return {
		"centre": Vector2(BAND_X, cy),
		"front": Vector2(BAND_X - REACH, cy),
		"spread": SPREAD * width,
		"amplitude": REACH * Intent.AMPLITUDE_NO_FOLD_FRACTION * depth,
		"shade": SHADE * shade,
		"column_half": COLUMN_HALF * width,
		"shape": FLAT_SHAPE,
		"axis_depth": AXIS_DEPTH,
	}
static func slotsFor(count:int, depth:float, width:float, shade:float) -> Array:
	var step:float = SLOT_STEP
	if(count > 1):
		step = min(SLOT_STEP, (LAST_Y - FIRST_Y) / float(count - 1))
	var top:float = 0.5 - step * float(count - 1) * 0.5
	var out:Array = []
	for i in range(count):
		out.append(slotAt(top + step * float(i), depth, width, shade))
	return out
static func uniformsFor(slot:Dictionary) -> Array:
	var centre:Vector2 = slot["centre"]
	var front:Vector2 = slot["front"]
	var shape:Array = slot["shape"]
	return [
		Plane(centre.x, centre.y, front.x, front.y),
		Plane(float(slot["spread"]), float(slot["amplitude"]), float(slot["shade"]),
			float(slot["column_half"])),
		Plane(Bake.sampleOf(shape, 0), Bake.sampleOf(shape, 1), Bake.sampleOf(shape, 2),
			float(slot["axis_depth"])),
		Plane(Bake.sampleOf(shape, 3), Bake.sampleOf(shape, 4), Bake.sampleOf(shape, 5),
			Bake.sampleOf(shape, 6)),
	]
static func refusalFor(shader) -> String:
	if(shader == null || !(shader is Shader)):
		return REASON_NO_SHADER
	if(!shader.has_param(BAKED_TEX_PARAM) || !shader.has_param(BAKED_ON_PARAM)):
		return REASON_NO_BAKED
	return ""
static func refusalBlock(reason:String, shader) -> String:
	var found:String = "no shader"
	if(shader != null && shader is Shader):
		found = BAKED_TEX_PARAM + "=" + ("yes" if shader.has_param(BAKED_TEX_PARAM) else "NO") \
			+ " " + BAKED_ON_PARAM + "=" + ("yes" if shader.has_param(BAKED_ON_PARAM) else "NO") \
			+ " " + OLD_PATH_PARAM + "=" + ("yes" if shader.has_param(OLD_PATH_PARAM) else "NO") \
			+ " code=" + str(shader.code.length()) + " chars md5=" + str(shader.code.md5_text())
	return MAGIC + " REFUSED - " + reason + ".\n" \
		+ "  at " + MATERIAL_PATH + ": " + found + "\n" \
		+ "  NOTHING WAS DRAWN, on purpose. set_shader_param on an undeclared uniform is a SILENT" \
		+ " NO-OP (Parts/MeshWithPattern.gd:35-37), so both panels would have shown the UNBAKED" \
		+ " picture and the difference would have been perfectly flat - a preview claiming H6 works" \
		+ " while proving only that v2 still does.\n" \
		+ "  WHICH COPY WON: v3 ships its own " + MATERIAL_PATH + " carrying " + BAKED_TEX_PARAM \
		+ "; v2 ships the same path without it; LAST PACK LOADED WINS. Mount v3's pack AFTER v2's," \
		+ " or unmount v2. Under MOD/bulge-harness.sh add v3's ship tree, which is not part of the" \
		+ " mod overlay: BULGE_MOD=InsertionBulges_v3.0/mod:InsertionBulges_v3.0/ship"
var canvas:Viewport = null
var surface:ColorRect = null
var panel:Viewport = null
var quad:MeshInstance = null
var eye:Camera = null
var skin:ShaderMaterial = null
var inspected = null
func build(side:int, material:ShaderMaterial) -> void:
	canvas = Viewport.new()
	canvas.usage = Viewport.USAGE_3D
	canvas.hdr = true
	canvas.transparent_bg = true
	canvas.size = Vector2(side, side)
	surface = ColorRect.new()
	surface.rect_size = canvas.size
	canvas.add_child(surface)
	add_child(canvas)
	skin = material
	panel = Viewport.new()
	panel.size = Vector2(side, side)
	panel.transparent_bg = true
	panel.hdr = true
	panel.own_world = true
	eye = Camera.new()
	eye.projection = Camera.PROJECTION_ORTHOGONAL
	eye.size = 1.0
	eye.near = 0.05
	eye.far = 10.0
	eye.translation = Vector3(0.0, 0.0, 1.0)
	eye.current = true
	quad = MeshInstance.new()
	quad.mesh = QuadMesh.new()
	quad.material_override = skin
	panel.add_child(eye)
	panel.add_child(quad)
	add_child(panel)
	eye.make_current()
func release() -> void:
	if(canvas != null):
		canvas.queue_free()
		canvas = null
		surface = null
	if(panel != null):
		panel.queue_free()
		panel = null
		quad = null
		eye = null
	skin = null
func shoot(target:Viewport):
	target.render_target_update_mode = Viewport.UPDATE_ONCE
	yield(get_tree(), "idle_frame")
	yield(VisualServer, "frame_post_draw")
	return Bake.imageFrom(target.get_texture())
static func differenceOf(old:Image, fresh:Image) -> Dictionary:
	var width:int = old.get_width()
	var height:int = old.get_height()
	var picture := Image.new()
	picture.create(width, height, false, Image.FORMAT_RGBA8)
	var gap:float = 0.0
	var at:Vector2 = Vector2.ZERO
	var peak:float = 0.0
	var over:int = 0
	old.lock()
	fresh.lock()
	picture.lock()
	for x in range(width):
		for y in range(height):
			var here:Color = old.get_pixel(x, y)
			var there:Color = fresh.get_pixel(x, y)
			var mine:Array = [here.r, here.g, here.b, here.a]
			var yours:Array = [there.r, there.g, there.b, there.a]
			var worst:float = 0.0
			for c in range(4):
				peak = max(peak, abs(float(mine[c])))
				worst = max(worst, abs(float(mine[c]) - float(yours[c])))
			if(worst > gap):
				gap = worst
				at = Vector2(x, y)
			if(worst * DIFF_GAIN >= 1.0):
				over += 1
			var lit:float = clamp(worst * DIFF_GAIN, 0.0, 1.0)
			picture.set_pixel(x, y, Color(lit, lit * 0.15, lit * 0.15, 1.0))
	picture.unlock()
	fresh.unlock()
	old.unlock()
	return {"gap": gap, "at": at, "peak": peak, "over": over, "picture": picture}
static func sheetOf(oldRaw:Image, freshRaw:Image, diff:Image) -> Image:
	var old:Image = oldRaw
	var fresh:Image = freshRaw
	if(old.get_format() != Image.FORMAT_RGBA8):
		old = oldRaw.duplicate()
		old.convert(Image.FORMAT_RGBA8)
	if(fresh.get_format() != Image.FORMAT_RGBA8):
		fresh = freshRaw.duplicate()
		fresh.convert(Image.FORMAT_RGBA8)
	var width:int = old.get_width()
	var height:int = old.get_height()
	var sheet := Image.new()
	sheet.create(width * 3 + GUTTER * 2, height, false, Image.FORMAT_RGBA8)
	sheet.fill(SHEET_BG)
	var whole := Rect2(0, 0, width, height)
	sheet.blend_rect(old, whole, Vector2(0, 0))
	sheet.blend_rect(fresh, whole, Vector2(width + GUTTER, 0))
	sheet.blit_rect(diff, whole, Vector2((width + GUTTER) * 2, 0))
	return sheet
const RESULT_KEYS := ["refused", "resolution", "slots", "depth", "width", "shade", "old_slots",
	"gap", "gap_at", "peak", "over", "texels", "format", "path", "bytes"]
static func argumentRefusal(resolution:int, slots:int, depth:float, width:float, shade:float) -> String:
	if(!RESOLUTIONS.has(resolution)):
		return "resolution " + str(resolution) + " is not one of " + str(RESOLUTIONS) \
			+ " - 512 is deliberately absent, being the size Bench/Cost.gd measured costing a" \
			+ " second frame live"
	if(slots < 1 || slots > MAX_SLOTS):
		return "slots " + str(slots) + " is outside 1.." + str(MAX_SLOTS) \
			+ " - the cap is a LOOKING limit and not a maths one; the bake loops to a plain int"
	if(depth <= 0.0 || width <= 0.0 || shade < 0.0):
		return "depth " + str(depth) + ", width " + str(width) + " and shade " + str(shade) \
			+ " are multipliers on 1.0 = the reference slot; depth and width must be above zero" \
			+ " (a slot with either at zero is one bulgeField early-outs on and draws nothing)"
	return ""
func run(resolution:int, slots:int, depth:float, width:float, shade:float, material = null,
		slotsOverride = null):
	yield(get_tree(), "idle_frame")
	var result:Dictionary = {
		"refused": "", "resolution": resolution, "slots": slots, "depth": depth, "width": width,
		"shade": shade, "old_slots": int(min(slots, OLD_SLOTS)), "gap": 0.0,
		"gap_at": Vector2.ZERO, "peak": 0.0, "over": 0, "texels": 0, "format": -1, "path": "",
		"bytes": 0,
	}
	result["refused"] = argumentRefusal(resolution, slots, depth, width, shade)
	if(str(result["refused"]) != ""):
		return result
	var loaded = material
	if(loaded == null):
		var onDisk = load(MATERIAL_PATH)
		if(onDisk == null || !(onDisk is ShaderMaterial)):
			result["refused"] = REASON_NO_MATERIAL
			return result
		loaded = onDisk.duplicate()
	inspected = loaded.shader
	result["refused"] = refusalFor(inspected)
	if(str(result["refused"]) != ""):
		return result
	var all:Array = slotsFor(slots, depth, width, shade)
	if(typeof(slotsOverride) == TYPE_ARRAY && !slotsOverride.empty()):
		all = slotsOverride
		result["slots"] = all.size()
		result["old_slots"] = int(min(all.size(), OLD_SLOTS))
	build(resolution, loaded)
	skin.set_shader_param("bulge_aspect", Vector2(1, 1))
	skin.set_shader_param("bulge_expanded", 0.0)
	skin.set_shader_param("shaft_clip", 2.0)
	skin.set_shader_param("random_shift", 0.0)
	skin.set_shader_param("bulge_shape_fidelity", FieldMath.fidelity())
	skin.set_shader_param("bulge_rim_shape", FieldMath.rim())
	surface.material = Bake.materialFor(all)
	var bakedRaw = yield(shoot(canvas), "completed")
	var baked:Image = bakedRaw
	result["texels"] = 0
	if(baked != null):
		result["texels"] = baked.get_width() * baked.get_height()
	for i in range(OLD_SLOTS):
		var box:Array = [Plane(0, 0, 0, 0), Plane(0, 0, 0, 0), Plane(1, 1, 1, 1), Plane(1, 1, 1, 1)]
		if(i < all.size()):
			box = uniformsFor(all[i])
		skin.set_shader_param("bulge_seg" + str(i), box[0])
		skin.set_shader_param("bulge_par" + str(i), box[1])
		skin.set_shader_param("bulge_shp" + str(i), box[2])
		skin.set_shader_param("bulge_shp" + str(i) + "b", box[3])
	skin.set_shader_param(BAKED_ON_PARAM, 0.0)
	var oldRaw = yield(shoot(panel), "completed")
	var old:Image = oldRaw
	var bakedTex:Texture = canvas.get_texture()
	bakedTex.flags = 0
	skin.set_shader_param(BAKED_TEX_PARAM, bakedTex)
	skin.set_shader_param(BAKED_ON_PARAM, 1.0)
	var freshRaw = yield(shoot(panel), "completed")
	var fresh:Image = freshRaw
	if(old == null || fresh == null):
		result["refused"] = "a panel read back null - the render target was never drawn"
		release()
		return result
	result["format"] = old.get_format()
	var apart:Dictionary = differenceOf(old, fresh)
	result["gap"] = float(apart["gap"])
	result["gap_at"] = apart["at"]
	result["peak"] = float(apart["peak"])
	result["over"] = int(apart["over"])
	var sheet:Image = sheetOf(old, fresh, apart["picture"])
	release()
	if(sheet.save_png(OUT_PATH) != OK):
		result["refused"] = "could not write " + OUT_PATH
		return result
	result["path"] = ProjectSettings.globalize_path(OUT_PATH)
	var f := File.new()
	if(f.open(OUT_PATH, File.READ) == OK):
		result["bytes"] = f.get_len()
		f.close()
	return result
static func block(result:Dictionary) -> String:
	var head:String = MAGIC + " res=" + str(result["resolution"]) + " slots=" + str(result["slots"]) \
		+ " depth=" + str(result["depth"]) + " width=" + str(result["width"]) \
		+ " shade=" + str(result["shade"])
	if(str(result["refused"]) != ""):
		return head + "\n" + MAGIC + " REFUSED - " + str(result["refused"]) + ". Nothing was drawn."
	var out := PoolStringArray()
	out.append(head + " -> " + str(result["path"]) + " (" + str(result["bytes"]) + " bytes)")
	out.append("  panels, left to right: " + str(PANELS[0]) + " | " + str(PANELS[1]) + " | " \
		+ (str(PANELS[2]) % int(DIFF_GAIN)) \
		+ "   - one material, one mesh, one uniform different between the two renders.")
	out.append("  worst channel gap between the panels: " + str(result["gap"]) + " at pixel " \
		+ str(result["gap_at"]) + "; " + str(result["over"]) + " of " + str(result["texels"]) \
		+ " pixels SATURATED in the diff panel at x" + str(int(DIFF_GAIN)) \
		+ "; brightest channel in OLD " + str(result["peak"]) \
		+ "; panel format " + str(result["format"]) + " (RGBA8 is " + str(Image.FORMAT_RGBA8) + ").")
	if(int(result["slots"]) <= OLD_SLOTS):
		out.append("  AT " + str(result["slots"]) + " SLOTS THE DIFF PANEL MUST BE BLACK. Bake.shader" \
			+ " is a port of this material's own bulgeField and Checks/Bake.gd pins the two" \
			+ " numerically, so the only thing left between the panels is that the baked field made" \
			+ " a round trip through a half float. Anything you can SEE in the right hand panel is a" \
			+ " real defect, not a rounding artefact.")
	else:
		out.append("  " + str(result["slots"]) + " SLOTS, AND THE OLD PATH CAN ONLY HOLD " \
			+ str(OLD_SLOTS) + ". The diff panel is the " + str(int(result["slots"]) - OLD_SLOTS) \
			+ " slot(s) v2 has no uniforms for, and that is H6's whole claim made visible: the cap" \
			+ " is a count of uniform sets and nothing else. The first " + str(OLD_SLOTS) \
			+ " and the two panels were handed the SAME slot array, so nothing else in the picture" \
			+ " moved.")
	return out.join("\n")
