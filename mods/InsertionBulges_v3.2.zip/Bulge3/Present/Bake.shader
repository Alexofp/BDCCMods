shader_type canvas_item;
render_mode blend_disabled, unshaded;
uniform sampler2D bulge_slots;
uniform int bulge_slot_count = 0;
uniform vec2 bulge_aspect = vec2(1.0, 1.0);
uniform float bulge_shape_fidelity = 0.55;
uniform float bulge_rim_shape = 1.0;
uniform float bulge_ramp_slope_peak = 1.5;
uniform float bulge_band_plateau = 0.25;
uniform float bulge_union_overlap = 0.3;
vec4 slotTexel(int slot, int col) {
	ivec2 size = textureSize(bulge_slots, 0);
	return texture(bulge_slots, vec2((float(col) + 0.5) / float(size.x),
		(float(slot) + 0.5) / float(bulge_slot_count)));
}
float sampleOf(int slot, int at) {
	if(at < 3) {
		vec4 shp = slotTexel(slot, 2);
		return at == 0 ? shp.x : (at == 1 ? shp.y : shp.z);
	}
	if(at < 7) {
		vec4 shp2 = slotTexel(slot, 3);
		int k = at - 3;
		return k == 0 ? shp2.x : (k == 1 ? shp2.y : (k == 2 ? shp2.z : shp2.w));
	}
	int past = at - 7;
	vec4 extra = slotTexel(slot, 5 + past / 4);
	int lane = past - (past / 4) * 4;
	return lane == 0 ? extra.x : (lane == 1 ? extra.y : (lane == 2 ? extra.z : extra.w));
}
float shapeAt(int slot, int knots, float u) {
	if(knots < 2) {
		return 1.0;
	}
	float f = clamp(u, 0.0, 1.0) * float(knots - 1);
	int low = int(floor(f));
	if(low >= knots - 1) {
		return sampleOf(slot, knots - 1);
	}
	return mix(sampleOf(slot, low), sampleOf(slot, low + 1),
		smoothstep(0.0, 1.0, f - float(low)));
}
vec4 bulgeField(vec2 uv, int slot, vec4 seg, vec4 par, float axis_depth, int knots) {
	if(par.x <= 0.0001 || par.y <= 0.0001) {
		return vec4(0.0);
	}
	vec2 p = uv * bulge_aspect;
	vec2 c = seg.xy * bulge_aspect;
	vec2 reach = seg.zw * bulge_aspect - c;
	float ramp = max(length(reach), 0.0001);
	vec2 outward = reach / ramp;
	vec2 rel = p - c;
	float along = dot(rel, outward);
	float across = dot(rel, vec2(-outward.y, outward.x));
	float plateau = across < 0.0 ? par.w : par.w * bulge_band_plateau;
	float h = clamp(1.0 - max(abs(across) - plateau, 0.0) / (par.x + par.w - plateau), 0.0, 1.0);
	h = h * h * (3.0 - 2.0 * h);
	float u = clamp(0.5 + across / max(2.0 * par.w, 0.0001), 0.0, 1.0);
	float profile = shapeAt(slot, knots, u);
	h = h * mix(1.0, profile, bulge_shape_fidelity);
	float g = smoothstep(-ramp, 0.0, along);
	vec2 push = outward;
	float weight = h * g;
	float axis = -axis_depth;
	float r = max(axis_depth + par.y, 0.0001);
	float tube = clamp(1.0 - abs(along - axis) / r, 0.0, 1.0);
	float lit = mix(weight, h * tube, bulge_rim_shape);
	return vec4(push * (par.y * weight) / bulge_aspect, weight, lit);
}
void fragment() {
	vec2 offset = vec2(0.0);
	float field = 0.0;
	float shade = 0.0;
	float bound = 0.0;
	int contributors = 0;
	float pushSum = 0.0;
	float pushMost = 0.0;
	float strongest = 0.0;
	for(int s = 0; s < bulge_slot_count; s++) {
		vec4 seg = slotTexel(s, 0);
		vec4 par = slotTexel(s, 1);
		float axis_depth = slotTexel(s, 2).w;
		int knots = int(slotTexel(s, 4).x + 0.5);
		vec4 one = bulgeField(UV, s, seg, par, axis_depth, knots);
		offset += one.xy;
		pushSum += length(one.xy);
		pushMost = max(pushMost, length(one.xy));
		field = max(field, one.w);
		shade = max(shade, one.w * par.z);
		if(one.x == 0.0 && one.y == 0.0) {
			continue;
		}
		contributors += 1;
		float push = length(one.xy * bulge_aspect);
		if(contributors == 1 || push > strongest) {
			strongest = push;
			bound = max(length(seg.zw * bulge_aspect - seg.xy * bulge_aspect), 0.0001)
				/ bulge_ramp_slope_peak;
		}
	}
	if(pushSum > 0.0) {
		offset *= (pushMost + bulge_union_overlap * (pushSum - pushMost)) / pushSum;
	}
	float len = length(offset * bulge_aspect);
	if(bound > 0.0 && len > bound) {
		offset *= bound / len;
	}
	COLOR = vec4(offset, field, shade);
}
