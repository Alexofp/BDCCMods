extends Reference
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const VARIANT_OFF := "off"
const VARIANT_FADE := "fade"
const VARIANT_BONE := "bone"
const VARIANT_BLEND := "blend"
const VARIANTS := [VARIANT_OFF, VARIANT_FADE, VARIANT_BONE, VARIANT_BLEND]
const BONE := "DeformBelly"
const RISE := 0.706324
const P_FULL := 2.0
const META_GAME := "bdccBulge3Belly"
const TUNING := {"gain": 2.0}
static func gain() -> float:
	return float(TUNING["gain"])
static func skeletonOf(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll) || !theDoll.has_method("getDollSkeleton")):
		return null
	var holder = theDoll.getDollSkeleton()
	if(holder == null):
		return null
	return holder.getSkeleton()
static func decode(pose:Transform) -> float:
	var wide:float = pose.basis.get_scale().y
	if(wide > 1.0001):
		return wide
	return pose.origin.y / RISE
static func poseOf(theDoll):
	var skeleton = skeletonOf(theDoll)
	if(skeleton == null):
		return null
	var bone:int = skeleton.find_bone(BONE)
	if(bone < 0):
		return null
	return skeleton.get_bone_custom_pose(bone)
static func pregnancyOf(theDoll) -> float:
	var pose = poseOf(theDoll)
	if(pose == null):
		return 0.0
	if(theDoll.has_meta(META_GAME)):
		var had:Dictionary = theDoll.get_meta(META_GAME)
		if(pose.is_equal_approx(had["wrote"])):
			return float(had["p"])
	return decode(pose)
static func heatOf(p:float) -> float:
	return clamp(p / P_FULL, 0.0, 1.0)
static func apply(entries:Array, eyes, variant:String) -> void:
	var pushed:Dictionary = {}
	var heatByOwner:Dictionary = {}
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY || typeof(entry.get("intent")) != TYPE_DICTIONARY \
				|| typeof(entry.get("engagement")) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		if(str(engagement.get("hole")) == Intent.HOLE_MOUTH):
			continue
		var owner:String = str(engagement.get("hole_owner"))
		if(!heatByOwner.has(owner)):
			heatByOwner[owner] = heatOf(pregnancyOf(eyes.dollFor(owner)))
		var heat:float = heatByOwner[owner]
		if(heat <= 0.0):
			continue
		var amplitude:float = float(entry["intent"]["amplitude"])
		if(variant == VARIANT_BONE || variant == VARIANT_BLEND):
			pushed[owner] = max(float(pushed.get(owner, 0.0)), gain() * amplitude * heat)
		if(variant == VARIANT_FADE || variant == VARIANT_BLEND):
			entry["intent"] = Intent.withAmplitude(entry["intent"], amplitude * (1.0 - heat))
	for owner in eyes.byID:
		var theDoll = eyes.dollFor(owner)
		if(theDoll == null):
			continue
		if(pushed.has(owner)):
			push(theDoll, float(pushed[owner]))
		elif(theDoll.has_meta(META_GAME)):
			restore(theDoll)
static func release(eyes) -> void:
	for owner in eyes.byID:
		var theDoll = eyes.dollFor(owner)
		if(theDoll != null && theDoll.has_meta(META_GAME)):
			restore(theDoll)
static func push(theDoll, extra:float) -> void:
	var p:float = pregnancyOf(theDoll)
	theDoll.setPregnancy(p + extra)
	theDoll.set_meta(META_GAME, {"p": p, "wrote": poseOf(theDoll)})
static func restore(theDoll) -> void:
	var had:Dictionary = theDoll.get_meta(META_GAME)
	theDoll.remove_meta(META_GAME)
	var pose = poseOf(theDoll)
	if(pose != null && pose.is_equal_approx(had["wrote"])):
		theDoll.setPregnancy(float(had["p"]))
