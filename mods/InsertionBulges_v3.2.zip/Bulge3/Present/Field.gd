extends Reference
const RAMP_SLOPE_PEAK := 1.5
const TUNING := {"fidelity": 0.55, "rim": 1.0}
static func fidelity() -> float:
	return float(TUNING["fidelity"])
static func rim() -> float:
	return float(TUNING["rim"])
static func setTuning(fidelityValue:float, rimValue:float) -> bool:
	if(fidelityValue < 0.0 || fidelityValue > 1.0 || rimValue < 0.0 || rimValue > 1.0):
		push_error("Field: fidelity and rim must both be within 0..1; still " \
			+ str(fidelity()) + "/" + str(rim()))
		return false
	TUNING["fidelity"] = fidelityValue
	TUNING["rim"] = rimValue
	return true
const EPSILON := 0.0001
static func jacobianDet(slots:Array, uv:Vector2, bulge_aspect:Vector2 = Vector2(1, 1),
		clamped:bool = true, h:float = 0.001) -> float:
	var key:String = "clamped_offset"
	if(!clamped):
		key = "offset"
	var dx:Vector2 = compose(slots, uv + Vector2(h, 0.0), bulge_aspect)[key] \
		- compose(slots, uv - Vector2(h, 0.0), bulge_aspect)[key]
	var dy:Vector2 = compose(slots, uv + Vector2(0.0, h), bulge_aspect)[key] \
		- compose(slots, uv - Vector2(0.0, h), bulge_aspect)[key]
	dx = dx / (2.0 * h)
	dy = dy / (2.0 * h)
	return (1.0 - dx.x) * (1.0 - dy.y) - dy.x * dx.y
static func shapeAt(shape:Array, u:float) -> float:
	var knots:int = shape.size()
	if(knots < 2):
		return 1.0
	var f:float = clamp(u, 0.0, 1.0) * float(knots - 1)
	var low:int = int(floor(f))
	if(low >= knots - 1):
		return float(shape[knots - 1])
	return lerp(float(shape[low]), float(shape[low + 1]), smoothstep(0.0, 1.0, f - float(low)))
static func rampOf(slot:Dictionary, bulge_aspect:Vector2 = Vector2(1, 1)) -> float:
	var centre:Vector2 = slot["centre"] * bulge_aspect
	var reach:Vector2 = slot["front"] * bulge_aspect - centre
	return max(reach.length(), EPSILON)
const BAND_PLATEAU := 0.25
static func bulgeField(uv:Vector2, slot:Dictionary, bulge_aspect:Vector2 = Vector2(1, 1)) -> Dictionary:
	var par_x:float = float(slot["spread"])
	var par_y:float = float(slot["amplitude"])
	var par_w:float = float(slot["column_half"])
	if(par_x <= EPSILON || par_y <= EPSILON):
		return {"offset": Vector2.ZERO, "weight": 0.0, "lit": 0.0}
	var p:Vector2 = uv * bulge_aspect
	var c:Vector2 = slot["centre"] * bulge_aspect
	var reach:Vector2 = slot["front"] * bulge_aspect - c
	var ramp:float = max(reach.length(), EPSILON)
	var outward:Vector2 = reach / ramp
	var rel:Vector2 = p - c
	var along:float = rel.dot(outward)
	var across:float = rel.dot(Vector2(-outward.y, outward.x))
	var plateau:float = par_w * BAND_PLATEAU
	if(across < 0.0):
		plateau = par_w
	var h:float = clamp(1.0 - max(abs(across) - plateau, 0.0) / (par_x + par_w - plateau), 0.0, 1.0)
	h = h * h * (3.0 - 2.0 * h)
	var u:float = clamp(0.5 + across / max(2.0 * par_w, EPSILON), 0.0, 1.0)
	var profile:float = shapeAt(slot["shape"], u)
	h = h * lerp(1.0, profile, fidelity())
	var g:float = smoothstep(-ramp, 0.0, along)
	var push:Vector2 = outward
	var weight:float = h * g
	var axis:float = -float(slot["axis_depth"])
	var r:float = max(float(slot["axis_depth"]) + par_y, EPSILON)
	var tube:float = clamp(1.0 - abs(along - axis) / r, 0.0, 1.0)
	var lit:float = lerp(weight, h * tube, rim())
	return {"offset": push * (par_y * weight) / bulge_aspect, "weight": weight, "lit": lit}
const UNION_OVERLAP := 0.3
const UNION := {"overlap": UNION_OVERLAP}
static func unionOverlap() -> float:
	return float(UNION["overlap"])
static func setUnionOverlap(value:float) -> void:
	var live:Dictionary = UNION
	live["overlap"] = clamp(value, 0.0, 1.0)
static func unionOf(offsets:Array) -> Vector2:
	var total:Vector2 = Vector2.ZERO
	var sum:float = 0.0
	var most:float = 0.0
	for one in offsets:
		total += one
		sum += one.length()
		most = max(most, one.length())
	if(sum <= 0.0):
		return total
	return total * ((most + unionOverlap() * (sum - most)) / sum)
static func compose(slots:Array, uv:Vector2, bulge_aspect:Vector2 = Vector2(1, 1)) -> Dictionary:
	var offset:Vector2 = Vector2.ZERO
	var offsets:Array = []
	var field:float = 0.0
	var shade:float = 0.0
	var bound:float = 0.0
	var strongest:float = 0.0
	var contributors:int = 0
	for slot in slots:
		var one:Dictionary = bulgeField(uv, slot, bulge_aspect)
		offsets.append(one["offset"])
		field = max(field, float(one["lit"]))
		shade = max(shade, float(one["lit"]) * float(slot["shade"]))
		if(one["offset"] == Vector2.ZERO):
			continue
		contributors += 1
		var push:float = (one["offset"] * bulge_aspect).length()
		if(contributors == 1 || push > strongest):
			strongest = push
			bound = rampOf(slot, bulge_aspect) / RAMP_SLOPE_PEAK
	offset = unionOf(offsets)
	var length:float = (offset * bulge_aspect).length()
	var clamped:Vector2 = offset
	if(bound > 0.0 && length > bound):
		clamped = offset * (bound / length)
	var ratio:float = 0.0
	if(bound > 0.0):
		ratio = length / bound
	return {
		"offset": offset, "clamped_offset": clamped, "field": field, "shade": shade,
		"bound": bound, "length": length, "ratio": ratio, "contributors": contributors,
	}
