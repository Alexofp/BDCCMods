extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const CONF_TO_HIDE := Evidence.CONF_RUNTIME
const Engagement := preload("res://Bulge3/Commit/Engagement.gd")
const MAX_BULGES_PER_DOLL = Intent.BulgeUtils.BULGE_SLOTS
static func build(entries:Array) -> Dictionary:
	var report:Dictionary = {"bulges": [], "clips": [], "drops": [], "skips": []}
	var usedSlots:Dictionary = {}
	var slotWinners:Dictionary = {}
	for entry in rank(entries):
		var engagement:Dictionary = entry["engagement"]
		var shaftOwner = engagement["shaft"]
		var holeOwner = engagement["hole_owner"]
		var zone:String = str(engagement["hole"])
		var provenance:Dictionary = engagement["provenance"]
		var source:String = str(provenance["source"])
		var confidence:int = int(provenance["confidence"])
		var held:bool = str(engagement["state"]) != "stated"
		var intent = entry.get("intent")
		if(typeof(intent) != TYPE_DICTIONARY):
			skipped(report, engagement, "the relation carries no measurements")
			continue
		var ownerKey:String = str(holeOwner)
		var slot:int = int(usedSlots.get(ownerKey, 0))
		var bulged:bool = false
		var dropped:bool = false
		if(bool(intent["visible"])):
			if(slot >= MAX_BULGES_PER_DOLL):
				dropped = true
				var depth:float = depthOf(entry)
				report["drops"].append({
					"participant": holeOwner,
					"hole": zone,
					"reason": "no bulge slot left on " + ownerKey + ", all " \
						+ str(MAX_BULGES_PER_DOLL) + " taken by " \
						+ str(slotWinners.get(ownerKey, [])) + "; " + str(shaftOwner) \
						+ " ranks below them on depth, at " + str(depth),
					"source": source,
					"held": held,
					"confidence": confidence,
				})
			else:
				usedSlots[ownerKey] = slot + 1
				var winners:Array = slotWinners.get(ownerKey, [])
				winners.append(shaftOwner)
				slotWinners[ownerKey] = winners
				bulged = true
				report["bulges"].append({
					"participant": holeOwner,
					"hole": zone,
					"shaft": shaftOwner,
					"slot": slot,
					"strength": float(intent["amplitude"]),
					"radius": float(intent["spread"]),
					"band_from": float(intent["band_from"]),
					"band_to": float(intent["band_to"]),
					"source": source,
					"held": held,
					"confidence": confidence,
				})
		if(!bulged && !dropped):
			var why:String = "the swelling came out below the visible threshold: amplitude " \
				+ str(intent["amplitude"]) + " under " + str(Intent.MIN_AMPLITUDE)
			if(!mayHide(confidence)):
				why += ", and confidence " + str(confidence) + " may not hide the shaft"
			skipped(report, engagement, why)
		if(str(engagement["state"]) == Engagement.STATE_SETTLING):
			continue
		if(!mayHide(confidence)):
			continue
		report["clips"].append({
			"participant": shaftOwner,
			"hole_owner": holeOwner,
			"hole": zone,
			"clip_on_axis": float(intent["clip_on_axis"]),
			"source": source,
			"held": held,
			"confidence": confidence,
		})
	return report
static func rowKey(shaft, holeOwner, hole) -> String:
	return str(shaft) + " -> " + str(holeOwner) + "/" + str(hole)
static func mayHide(confidence:int) -> bool:
	return confidence >= CONF_TO_HIDE
static func rank(entries:Array) -> Array:
	var ordered:Array = []
	for entry in entries:
		var at:int = 0
		while(at < ordered.size() && !comesFirst(entry, ordered[at])):
			at += 1
		ordered.insert(at, entry)
	return ordered
static func comesFirst(entry:Dictionary, other:Dictionary) -> bool:
	var mine:float = depthOf(entry)
	var theirs:float = depthOf(other)
	if(mine != theirs):
		return mine > theirs
	return int(entry["engagement"]["provenance"]["confidence"]) \
		> int(other["engagement"]["provenance"]["confidence"])
static func depthOf(entry:Dictionary) -> float:
	var measures = entry.get("measures")
	if(typeof(measures) != TYPE_DICTIONARY || !measures.has("depth")):
		return -INF
	return float(measures["depth"])
static func skipped(report:Dictionary, engagement:Dictionary, reason:String) -> void:
	report["skips"].append({
		"shaft": engagement["shaft"],
		"hole_owner": engagement["hole_owner"],
		"hole": str(engagement["hole"]),
		"reason": reason,
	})
