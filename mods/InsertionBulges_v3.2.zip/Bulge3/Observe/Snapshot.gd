extends Reference
const Eyes := preload("res://Bulge3/Observe/Eyes.gd")
const CAP_ENGINE_FOR := "engineFor"
const CAP_SCENE_SOURCE := "sceneSource"
const CAP_SCENE_PATH := "sceneScriptPath"
const CAP_TAPER_OF := "taperOf"
const CAP_HELPER_FOR := "helperFor"
const CAP_CLIP_OF := "clipOf"
const CAP_DOLL_STATE_OF := "dollStateOf"
const CAP_CUM_STATE_OF := "cumStateOf"
const MESHES_KEY := "meshes"
static func observe(view:Dictionary, providers) -> Dictionary:
	var roster:Array = []
	if(typeof(view.get("participants")) == TYPE_ARRAY):
		roster = view["participants"]
	var snapshot:Dictionary = {
		"pose": str(view.get("pose", "")),
		"gated": view.get("gated", false) == true,
		"participants": roster,
		"context": view.get("context", {}),
		"scene_source": null,
		"scene_path": null,
		"shafts": {},
		"holes": {},
		"tapers": {},
		"engines": [],
		"oversize": {},
		"unread": [],
		"rig": {},
		"props": {},
		"overlap": {},
		"clips": {},
		"doll_state": {},
		"cum_state": {},
	}
	var unread:Array = []
	if(providers == null || !providers.has_method("engineFor")):
		unread.append(CAP_ENGINE_FOR)
	if(providers == null || !providers.has_method("taperOf")):
		unread.append(CAP_TAPER_OF)
	if(providers == null || !providers.has_method("helperFor")):
		unread.append(CAP_HELPER_FOR)
	if(providers == null || !providers.has_method("clipOf")):
		unread.append(CAP_CLIP_OF)
	if(providers == null || !providers.has_method("dollStateOf")):
		unread.append(CAP_DOLL_STATE_OF)
	if(providers == null || !providers.has_method("cumStateOf")):
		unread.append(CAP_CUM_STATE_OF)
	if(providers == null || !providers.has_method("sceneSource")):
		unread.append(CAP_SCENE_SOURCE)
	else:
		var text = providers.sceneSource()
		if(typeof(text) == TYPE_STRING):
			snapshot["scene_source"] = text
		elif(text != null):
			unread.append(CAP_SCENE_SOURCE)
	if(providers == null || !providers.has_method("sceneScriptPath")):
		unread.append(CAP_SCENE_PATH)
	else:
		var path = providers.sceneScriptPath()
		if(typeof(path) == TYPE_STRING):
			snapshot["scene_path"] = path
		elif(path != null):
			unread.append(CAP_SCENE_PATH)
	unread.sort()
	snapshot["unread"] = unread
	if(providers == null):
		return snapshot
	for entry in roster:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		var pid = entry["id"]
		snapshot["shafts"][pid] = shaftCardOf(providers, pid)
		snapshot["tapers"][pid] = null
		if(providers.has_method("taperOf")):
			snapshot["tapers"][pid] = providers.taperOf(pid)
		snapshot["rig"][pid] = null
		if(providers.has_method("rigOf")):
			snapshot["rig"][pid] = providers.rigOf(pid)
		snapshot["clips"][pid] = null
		if(providers.has_method("clipOf")):
			snapshot["clips"][pid] = providers.clipOf(pid)
		snapshot["doll_state"][pid] = null
		if(providers.has_method("dollStateOf")):
			snapshot["doll_state"][pid] = providers.dollStateOf(pid)
		snapshot["cum_state"][pid] = null
		if(providers.has_method("cumStateOf")):
			snapshot["cum_state"][pid] = providers.cumStateOf(pid)
		var holes:Dictionary = {}
		for holeID in holesOf(entry):
			holes[str(holeID)] = null
			if(providers.has_method("holeOf")):
				holes[str(holeID)] = providers.holeOf(pid, str(holeID))
		snapshot["holes"][pid] = holes
		snapshot["props"][pid] = {}
		if(providers.has_method("propsOf")):
			snapshot["props"][pid] = providers.propsOf(pid)
	if(providers.has_method("overlapOf")):
		for entry in roster:
			if(typeof(entry) == TYPE_DICTIONARY && entry.get("kind") == Eyes.KIND_PROP):
				snapshot["overlap"][entry["id"]] = providers.overlapOf(entry["id"])
	snapshot["engines"] = engineRecords(roster, providers)
	if(providers.has_method("oversize")):
		for top in roster:
			if(typeof(top) != TYPE_DICTIONARY || top.get("id") == null || top.get("has_shaft") != true):
				continue
			for bottom in roster:
				if(typeof(bottom) != TYPE_DICTIONARY || bottom.get("id") == null):
					continue
				for holeID in holesOf(bottom):
					var key:String = oversizeKey(top["id"], bottom["id"], str(holeID))
					snapshot["oversize"][key] = float(providers.oversize(top["id"], bottom["id"], str(holeID)))
	return snapshot
static func build(stageScene, poseID):
	var bulgeDoll = load(Eyes.BULGE_DOLL_PATH)
	if(bulgeDoll == null):
		return null
	return observe(viewOf(stageScene, poseID, bulgeDoll, load(Eyes.BULGE_UTILS_PATH)), Eyes.new(stageScene))
static func viewOf(stageScene, poseID, bulgeDoll, bulgeUtils) -> Dictionary:
	var pose:String = ""
	if(poseID != null):
		pose = str(poseID)
	var view:Dictionary = {
		"participants": [],
		"context": {},
		"pose": pose,
		"gated": false,
	}
	if(pose == "" || bulgeUtils == null || !bulgeUtils.poseAllowed(pose)):
		view["gated"] = true
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("getDolls")):
		return view
	if(bulgeDoll == null):
		return view
	var dolls:Array = stageScene.getDolls()
	for index in range(dolls.size()):
		var doll = dolls[index]
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = bulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		var holes:Array = []
		for holeID in Eyes.DOLL_HOLES:
			if(helper.getOrificeInfo(holeID) != null):
				holes.append(holeID)
		view["participants"].append({
			"id": "doll" + str(index),
			"kind": Eyes.KIND_DOLL,
			"char_id": charIDOf(doll),
			"has_shaft": helper.getShaftInfo() != null,
			"holes": holes,
		})
	var toys:Array = Eyes.propsIn(stageScene)
	if(toys.empty()):
		return view
	var eyes = Eyes.new(stageScene)
	for index in range(toys.size()):
		var propID:String = Eyes.KIND_PROP + str(index)
		view["participants"].append({
			"id": propID,
			"kind": Eyes.KIND_PROP,
			"char_id": null,
			"has_shaft": eyes.propShaftOf(propID) != null,
			"holes": [],
		})
	return view
static func charIDOf(doll):
	if(!doll.has_method("getCharacterID")):
		return null
	var charID = doll.getCharacterID()
	if(!(charID is String) || charID == ""):
		return null
	return charID
static func shaftCardOf(providers, participantID):
	if(providers == null || !providers.has_method("helperFor")):
		return null
	if(str(participantID).begins_with(Eyes.KIND_PROP) && providers.has_method("propShaftOf")):
		return providers.propShaftOf(participantID)
	var helper = providers.helperFor(participantID)
	if(helper == null || !helper.has_method("getShaftInfo")):
		return null
	var info = helper.getShaftInfo()
	if(typeof(info) != TYPE_DICTIONARY):
		return null
	var card:Dictionary = {}
	for key in info:
		if(str(key) == MESHES_KEY):
			continue
		if(typeof(info[key]) == TYPE_ARRAY):
			card[key] = info[key].duplicate()
		else:
			card[key] = info[key]
	return card
static func engineRecords(roster:Array, providers) -> Array:
	var records:Array = []
	if(providers == null || !providers.has_method("engineFor")):
		return records
	var seen:Dictionary = {}
	for entry in roster:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null || entry.get("char_id") == null):
			continue
		var engine = providers.engineFor(entry["id"])
		if(typeof(engine) != TYPE_OBJECT):
			continue
		var key:int = engine.get_instance_id()
		if(seen.has(key)):
			continue
		seen[key] = true
		var activities = engine.get("activities")
		if(typeof(activities) != TYPE_ARRAY):
			records.append({"activities": null})
			continue
		var listed:Array = []
		for activity in activities:
			if(typeof(activity) != TYPE_OBJECT):
				listed.append(null)
				continue
			listed.append(activityRecord(activity))
		records.append({"activities": listed})
	return records
static func activityRecord(activity) -> Dictionary:
	var record:Dictionary = {
		"id": null,
		"ended": false,
		"readable": false,
		"participants": [],
		"dom0_slot": null,
		"dom1_slot": null,
		"used_slot": null,
	}
	if(typeof(activity) != TYPE_OBJECT):
		return record
	var theID = activity.get("id")
	if(theID != null):
		record["id"] = str(theID)
	record["ended"] = activity.get("hasEnded") == true
	if(activity.has_method("getDom0Hole")):
		record["dom0_slot"] = slotValue(activity.getDom0Hole())
	if(activity.has_method("getDom1Hole")):
		record["dom1_slot"] = slotValue(activity.getDom1Hole())
	record["used_slot"] = slotValue(activity.get("usedBodypart"))
	record["readable"] = activity.has_method("convertCharIDToIndx") && activity.has_method("getTags")
	if(!record["readable"]):
		return record
	for group in [activity.get("doms"), activity.get("subs")]:
		if(typeof(group) != TYPE_ARRAY):
			continue
		for info in group:
			if(typeof(info) != TYPE_OBJECT || !info.has_method("getCharID")):
				continue
			var charID:String = str(info.getCharID())
			var indx:int = int(activity.convertCharIDToIndx(charID))
			var tags = activity.getTags(indx)
			var kept = null
			if(typeof(tags) == TYPE_ARRAY):
				kept = tags.duplicate()
			record["participants"].append({
				"char_id": charID,
				"indx": indx,
				"tags": kept,
			})
	return record
static func slotValue(slot):
	if(typeof(slot) != TYPE_STRING):
		return null
	return slot
static func holesOf(entry) -> Array:
	if(typeof(entry) != TYPE_DICTIONARY || typeof(entry.get("holes")) != TYPE_ARRAY):
		return []
	return entry["holes"]
static func cannotRead(snapshot, capability:String) -> bool:
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return false
	var unread = snapshot.get("unread", [])
	if(typeof(unread) != TYPE_ARRAY):
		return false
	return unread.has(capability)
const FALLBACK_GIRTH:float = 0.0
const PROFILE_MAX:float = 1.6
static func girthFrom(card, along, key:String = "profile") -> float:
	if(typeof(card) != TYPE_DICTIONARY):
		return FALLBACK_GIRTH
	var length:float = float(card.get("length", 0.0))
	if(length <= 0.0):
		return FALLBACK_GIRTH
	if(!card.has("skip")):
		return FALLBACK_GIRTH
	var t:float = clamp(float(along) / length, 0.0, 1.0)
	var shape:float = profileAt(card.get(key, []), t, float(card["skip"]))
	return float(card.get("radius", 0.0)) * min(shape, PROFILE_MAX)
static func profileAt(profile:Array, t:float, skip:float) -> float:
	if(profile.empty()):
		return 1.0
	var last:int = profile.size() - 1
	var span:float = max(1.0 - skip, 0.001)
	var local:float = clamp((t - skip) / span, 0.0, 1.0) * last
	var low:int = int(floor(local))
	var high:int = int(min(low + 1, last))
	return lerp(profile[low], profile[high], local - low)
static func oversizeKey(shaftOwner, holeOwner, holeID) -> String:
	return str(shaftOwner) + " " + str(holeOwner) + " " + str(holeID)
