extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const OVERLAP_MIN := 0.5
static func contribute(snapshot, _notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var overlap = snapshot.get("overlap")
	if(typeof(overlap) != TYPE_DICTIONARY):
		return []
	var items:Array = []
	for propID in overlap:
		var bodies = overlap[propID]
		if(typeof(bodies) != TYPE_DICTIONARY):
			continue
		for dollID in bodies:
			var drawn:float = float(bodies[dollID])
			if(drawn < OVERLAP_MIN):
				continue
			items.append(Evidence.item(
				Evidence.SRC_OVERLAP,
				Evidence.CLAIM_INSIDE,
				{
					Evidence.SUBJ_SHAFT: propID,
					Evidence.SUBJ_HOLE_OWNER: dollID,
				},
				true,
				Evidence.CONF_RUNTIME,
				{"drawn": drawn}
			))
	return items
