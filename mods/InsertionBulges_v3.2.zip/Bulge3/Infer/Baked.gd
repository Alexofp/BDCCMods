extends Reference
const BakedSources := preload("res://Bulge3/Infer/BakedSources.gd")
const Oral := preload("res://Bulge3/Infer/Oral.gd")
const Declaration := preload("res://Bulge3/Infer/Declaration.gd")
static func oralContribute(snapshot, notes:Array):
	var baked = bakedEntry(snapshot)
	if(baked != null):
		return baked["oral"].duplicate(true)
	return Oral.contribute(snapshot, notes)
static func declarationContribute(snapshot, notes:Array):
	var baked = bakedEntry(snapshot)
	if(baked != null):
		return baked["declaration"].duplicate(true)
	return Declaration.contribute(snapshot, notes)
static func bakedEntry(snapshot):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !BakedSources.TABLE.has(path)):
		return null
	var byPose = BakedSources.TABLE[path]
	var pose:String = str(snapshot.get("pose", ""))
	if(typeof(byPose) != TYPE_DICTIONARY || !byPose.has(pose)):
		return null
	return byPose[pose]
