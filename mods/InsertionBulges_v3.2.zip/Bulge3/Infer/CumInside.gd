extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("cum_state")) != TYPE_DICTIONARY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_CUM_STATE_OF)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_CUM_INSIDE)
		return []
	var items:Array = []
	for pid in snapshot["cum_state"]:
		var data = snapshot["cum_state"][pid]
		if(typeof(data) != TYPE_DICTIONARY):
			continue
		var intensity = data.get("cummed_inside")
		if(typeof(intensity) != TYPE_REAL && typeof(intensity) != TYPE_INT):
			continue
		if(float(intensity) <= 0.0):
			continue
		items.append(cumInsideItem(pid, float(intensity)))
	return items
static func cumInsideItem(pid, intensity:float) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_CUM_INSIDE,
		Evidence.CLAIM_INSIDE,
		{Evidence.SUBJ_HOLE_OWNER: pid},
		true,
		Evidence.CONF_RUNTIME,
		{"cummed_inside": intensity}
	)
