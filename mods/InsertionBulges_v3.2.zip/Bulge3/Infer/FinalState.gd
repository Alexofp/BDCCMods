extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const HOLE_MOUTH:String = "mouth"
const MOUTH_OPEN:String = "open"
const COCK_NEGATING_STATES:Array = ["limp", "caged"]
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("doll_state")) != TYPE_DICTIONARY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_DOLL_STATE_OF)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_DOLL_STATE)
		return []
	var items:Array = []
	for pid in snapshot["doll_state"]:
		var data = snapshot["doll_state"][pid]
		if(typeof(data) != TYPE_DICTIONARY):
			continue
		if(str(data.get("mouth")) == MOUTH_OPEN):
			items.append(mouthItem(pid))
		var cock = data.get("cock")
		if(typeof(cock) == TYPE_STRING && COCK_NEGATING_STATES.has(cock)):
			items.append(cockItem(pid, cock))
	return items
static func mouthItem(pid) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_DOLL_STATE,
		Evidence.CLAIM_PAIRING,
		{
			Evidence.SUBJ_HOLE_OWNER: pid,
			Evidence.SUBJ_HOLE: HOLE_MOUTH,
		},
		true,
		Evidence.CONF_RUNTIME,
		{"mouth_state": MOUTH_OPEN}
	)
static func cockItem(pid, cockState:String) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_DOLL_STATE,
		Evidence.CLAIM_INSIDE,
		{Evidence.SUBJ_SHAFT: pid},
		false,
		Evidence.CONF_RUNTIME,
		{"cock_state": cockState}
	)
