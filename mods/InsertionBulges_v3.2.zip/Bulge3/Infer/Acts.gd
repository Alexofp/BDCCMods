extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const DOM_0:int = 0
const DOM_1:int = 1
const INDX_NONE:int = -99
const HOLE_VAGINA:String = "vagina"
const HOLE_ANUS:String = "anus"
const TAG_SCRIPT := "res://Game/SexEngine/SexActivityTag.gd"
const TAG_FALLBACK := {"PenisInside": 4, "VaginaPenetrated": 11, "AnusPenetrated": 12}
const TAG_CACHE := {}
static func tagValue(name:String) -> int:
	if(!TAG_CACHE.has(name)):
		var value:int = int(TAG_FALLBACK[name])
		var script = load(TAG_SCRIPT)
		if(script is Script):
			var constants:Dictionary = script.get_script_constant_map()
			if(constants.has(name)):
				value = int(constants[name])
		TAG_CACHE[name] = value
	return int(TAG_CACHE[name])
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("engines")) != TYPE_ARRAY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_ENGINE_FOR)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_ENGINE)
		return []
	var byCharID:Dictionary = {}
	for entry in rosterOf(snapshot):
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null || entry.get("char_id") == null):
			continue
		byCharID[str(entry["char_id"])] = entry["id"]
	var items:Array = []
	for record in snapshot["engines"]:
		if(typeof(record) != TYPE_DICTIONARY):
			continue
		var activities = record.get("activities")
		if(typeof(activities) != TYPE_ARRAY):
			notes.append(READ_FAILED + ": " + Evidence.SRC_ENGINE)
			continue
		for activity in activities:
			readActivity(activity, byCharID, items, notes)
	return items
static func readActivity(activity, byCharID:Dictionary, items:Array, notes:Array) -> void:
	if(typeof(activity) != TYPE_DICTIONARY):
		return
	if(activity.get("ended") == true):
		return
	if(activity.get("readable") != true):
		notes.append("engine: unreadable activity " + activityName(activity))
		return
	var shafts:Array = []
	var occupied:Array = []
	for info in participantsIn(activity):
		if(typeof(info) != TYPE_DICTIONARY):
			continue
		var charID:String = str(info.get("char_id"))
		if(!byCharID.has(charID)):
			continue
		var indx:int = int(info.get("indx"))
		if(indx <= INDX_NONE):
			continue
		var tags = info.get("tags")
		if(typeof(tags) != TYPE_ARRAY):
			continue
		var pid = byCharID[charID]
		if(tagValue("PenisInside") in tags):
			shafts.append([pid, indx])
		if(tagValue("VaginaPenetrated") in tags):
			occupied.append([pid, HOLE_VAGINA])
		if(tagValue("AnusPenetrated") in tags):
			occupied.append([pid, HOLE_ANUS])
	if(occupied.empty()):
		return
	if(shafts.size() == 1 && occupied.size() == 1):
		items.append(pairing(shafts[0][0], occupied[0][0], occupied[0][1], activity))
		return
	for shaft in shafts:
		var holeID:String = holeOfShaft(activity, int(shaft[1]))
		var owners:Dictionary = {}
		if(holeID != ""):
			for occ in occupied:
				if(occ[1] == holeID):
					owners[str(occ[0])] = occ[0]
		if(owners.size() > 1):
			notes.append("engine: hole " + holeID + " is occupied on more than one participant in " + activityName(activity))
			continue
		var holeOwner = null
		for key in owners:
			holeOwner = owners[key]
		if(holeOwner == null):
			notes.append("engine: cannot place shaft " + str(shaft[0]) + " in " + activityName(activity))
			continue
		items.append(pairing(shaft[0], holeOwner, holeID, activity))
static func pairing(shaftOwner, holeOwner, holeID:String, activity:Dictionary) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_ENGINE,
		Evidence.CLAIM_PAIRING,
		{
			Evidence.SUBJ_SHAFT: shaftOwner,
			Evidence.SUBJ_HOLE_OWNER: holeOwner,
			Evidence.SUBJ_HOLE: holeID,
		},
		true,
		Evidence.CONF_ENGINE,
		{"activity": activityName(activity)}
	)
static func holeOfShaft(activity:Dictionary, indx:int) -> String:
	if(indx == DOM_0 && activity.get("dom0_slot") != null):
		return slotToHole(activity["dom0_slot"])
	if(indx == DOM_1 && activity.get("dom1_slot") != null):
		return slotToHole(activity["dom1_slot"])
	var slot = activity.get("used_slot")
	if(slot != null):
		return slotToHole(slot)
	return ""
static func slotToHole(slot) -> String:
	if(slot == HOLE_VAGINA):
		return HOLE_VAGINA
	if(slot == HOLE_ANUS):
		return HOLE_ANUS
	return ""
static func activityName(activity:Dictionary) -> String:
	var theID = activity.get("id")
	if(theID == null):
		return "(unnamed activity)"
	return str(theID)
static func rosterOf(snapshot:Dictionary) -> Array:
	if(typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return []
	return snapshot["participants"]
static func participantsIn(activity:Dictionary) -> Array:
	if(typeof(activity.get("participants")) != TYPE_ARRAY):
		return []
	return activity["participants"]
