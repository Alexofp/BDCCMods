extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const MOUTH_TAPER_MAX := 0.99
const BLEND_SETTLE := 1.5
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, poseAge:float, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("tapers")) != TYPE_DICTIONARY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_TAPER_OF)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_TAPER)
		return []
	var readings:Dictionary = snapshot["tapers"]
	var items:Array = []
	for entry in rosterOf(snapshot):
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		var pid = entry["id"]
		if(!readings.has(pid)):
			continue
		var reading = readings[pid]
		if(reading == null):
			continue
		if(typeof(reading) != TYPE_REAL && typeof(reading) != TYPE_INT):
			notes.append("taper: " + str(pid) + " read back as " + str(reading))
			continue
		var pinched:bool = float(reading) < MOUTH_TAPER_MAX
		if(!pinched && poseAge < BLEND_SETTLE):
			continue
		items.append(Evidence.item(
			Evidence.SRC_TAPER,
			Evidence.CLAIM_MOUTH_SHAFT,
			{Evidence.SUBJ_SHAFT: str(pid)},
			pinched,
			Evidence.CONF_RUNTIME,
			{"taper": float(reading), "pose_age": poseAge}
		))
	return items
static func rosterOf(snapshot:Dictionary) -> Array:
	if(typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return []
	return snapshot["participants"]
