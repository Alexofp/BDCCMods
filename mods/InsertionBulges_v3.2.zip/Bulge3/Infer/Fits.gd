extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const HOLE_MOUTH := "mouth"
const LATERAL_TOLERANCE:Dictionary = {
	"vagina": 0.55,
	"anus": 0.55,
	"mouth": 0.8,
}
const LATERAL_TOLERANCE_OTHER:float = 0.42
const MIN_INWARD_DOT:Dictionary = {
	"vagina": 0.6,
	"anus": 0.6,
	"mouth": 0.4,
}
const MIN_INWARD_DOT_OTHER:float = 0.6
const MIN_TIP_INSIDE:float = 0.2
const MIN_SHAFT_LENGTH:float = 0.05
const LATERAL_WEIGHT:float = 0.1
const BulgeUtils := preload("res://Bulge3/Doll/BulgeUtils.gd")
const SHAPE_SAMPLES_V2:int = BulgeUtils.SHAPE_TRANSPORT
const SHAPE := {"samples": SHAPE_SAMPLES_V2}
static func samples() -> int:
	return int(SHAPE["samples"])
static func setSamples(count:int) -> bool:
	if(count < 2):
		push_error("Fits: shape samples must be >= 2; still " + str(samples()))
		return false
	SHAPE["samples"] = count
	return true
const DEFAULT_OVERSIZE:float = Snapshot.Eyes.DEFAULT_OVERSIZE
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, items:Array, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_HELPER_FOR)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_GEOMETRY)
		return []
	var mouthShaft:Dictionary = Evidence.mouthShaftMap(items)
	var declared:Dictionary = declaredPenetrations(Evidence.declaredPairs(items))
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	var holes:Dictionary = {}
	if(typeof(snapshot.get("holes")) == TYPE_DICTIONARY):
		holes = snapshot["holes"]
	var oversize:Dictionary = {}
	if(typeof(snapshot.get("oversize")) == TYPE_DICTIONARY):
		oversize = snapshot["oversize"]
	var ordered:Array = []
	for topEntry in rosterOf(snapshot):
		if(typeof(topEntry) != TYPE_DICTIONARY || topEntry.get("id") == null):
			continue
		var shaftOwner = topEntry["id"]
		var card = shafts.get(shaftOwner)
		if(!isShaft(card)):
			continue
		var length:float = float(card["length"])
		if(length < MIN_SHAFT_LENGTH):
			continue
		var base:Vector3 = card["base"]
		var tip:Vector3 = card["tip"]
		var dir:Vector3 = (tip - base) / length
		var tapered = taperSaid(mouthShaft, shaftOwner)
		for bottomEntry in rosterOf(snapshot):
			if(typeof(bottomEntry) != TYPE_DICTIONARY || bottomEntry.get("id") == null):
				continue
			var holeOwner = bottomEntry["id"]
			for holeID in holesOf(holes, holeOwner):
				if(str(holeID) == HOLE_MOUTH && tapered != null && !tapered):
					continue
				var candidate = measure(holes, shaftOwner, holeOwner, str(holeID), base, tip, dir,
					length)
				if(candidate != null):
					insertByFit(ordered, candidate)
	return assign(ordered, shafts, oversize, mouthShaft, declared)
static func assign(ordered:Array, shafts:Dictionary, oversize:Dictionary, mouthShaft:Dictionary,
		declared:Dictionary) -> Array:
	var items:Array = []
	for candidate in ordered:
		var shaftOwner = candidate["shaft"]
		var holeOwner = candidate["hole_owner"]
		var vouched:bool = false
		var tapered = taperSaid(mouthShaft, shaftOwner)
		if(str(candidate["hole"]) == HOLE_MOUTH && tapered != null && tapered):
			vouched = true
		if(declaredPenetration(declared, shaftOwner, holeOwner)):
			vouched = true
		if(!vouched):
			continue
		var confidence:int = Evidence.CONF_RUNTIME
		items.append(Evidence.item(
			Evidence.SRC_GEOMETRY,
			Evidence.CLAIM_PAIRING,
			{
				Evidence.SUBJ_SHAFT: shaftOwner,
				Evidence.SUBJ_HOLE_OWNER: holeOwner,
				Evidence.SUBJ_HOLE: str(candidate["hole"]),
			},
			true,
			confidence,
			measuresOf(candidate, shafts.get(shaftOwner), oversize)
		))
	return items
static func measuresOf(candidate:Dictionary, card, oversize:Dictionary) -> Dictionary:
	var shape:Array = shapeOf(candidate, card)
	var measures:Dictionary = {
		"entry": candidate["entry"],
		"depth": candidate["depth"],
		"axis": candidate["axis"],
		"girth_at_entry": shape[0],
		"shape": shape,
		"oversize": float(oversize.get(
			Snapshot.oversizeKey(candidate["shaft"], candidate["hole_owner"], candidate["hole"]),
			DEFAULT_OVERSIZE)),
	}
	if(typeof(card) == TYPE_DICTIONARY && typeof(card.get("edge_up")) == TYPE_ARRAY \
			&& !card["edge_up"].empty()):
		measures["shape_up"] = shapeOf(candidate, card, "edge_up")
		measures["shape_down"] = shapeOf(candidate, card, "edge_down")
	return measures
static func shapeOf(candidate:Dictionary, card, key:String = "profile") -> Array:
	var along:float = float(candidate["along"])
	var depth:float = float(candidate["depth"])
	var out:Array = []
	var count:int = samples()
	for i in count:
		out.append(Snapshot.girthFrom(card, along + depth * float(i) / float(count - 1), key))
	return out
static func measure(holes:Dictionary, shaftOwner, holeOwner, holeID:String, base:Vector3,
		tip:Vector3, dir:Vector3, length:float, gated:bool = true):
	var hole = holeAt(holes, holeOwner, holeID)
	if(!isHole(hole)):
		return null
	var pos:Vector3 = hole["pos"]
	var inward:Vector3 = hole["inward"]
	var along:float = (pos - base).dot(dir)
	var lateral:float = (pos - (base + dir * along)).length()
	var inwardDot:float = dir.dot(inward)
	var tipInside:float = (tip - pos).dot(inward)
	var fit:float = 0.0
	if(gated):
		if(lateral > lateralLimit(holeID)):
			return null
		if(inwardDot < inwardLimit(holeID)):
			return null
		if(tipInside < MIN_TIP_INSIDE):
			return null
		fit = (1.0 - inwardDot) + lateral * LATERAL_WEIGHT
	return {
		"shaft": shaftOwner,
		"hole_owner": holeOwner,
		"hole": holeID,
		"along": along,
		"depth": length - along,
		"entry": pos,
		"axis": inward,
		"fit": fit,
	}
static func taperSaid(mouthShaft:Dictionary, shaftOwner):
	var said = mouthShaft.get(str(shaftOwner))
	if(typeof(said) != TYPE_BOOL):
		return null
	return said
static func declaredPenetrations(pairs) -> Dictionary:
	var declared:Dictionary = {}
	if(typeof(pairs) != TYPE_ARRAY):
		return declared
	for pair in pairs:
		if(typeof(pair) != TYPE_DICTIONARY || pair.get("shaft") == null \
				|| pair.get("hole_owner") == null):
			continue
		var shaftOwner:String = str(pair["shaft"])
		if(!declared.has(shaftOwner)):
			declared[shaftOwner] = {}
		declared[shaftOwner][str(pair["hole_owner"])] = true
	return declared
static func declaredPenetration(declared:Dictionary, shaftOwner, holeOwner) -> bool:
	return declared.has(str(shaftOwner)) && declared[str(shaftOwner)].has(str(holeOwner))
static func insertByFit(ordered:Array, candidate:Dictionary) -> void:
	var at:int = 0
	while(at < ordered.size() && float(ordered[at]["fit"]) <= float(candidate["fit"])):
		at += 1
	ordered.insert(at, candidate)
static func rosterOf(snapshot:Dictionary) -> Array:
	if(typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return []
	return snapshot["participants"]
static func holesOf(holes:Dictionary, participantID) -> Array:
	if(typeof(holes.get(participantID)) != TYPE_DICTIONARY):
		return []
	return holes[participantID].keys()
static func holeAt(holes:Dictionary, participantID, holeID:String):
	if(typeof(holes.get(participantID)) != TYPE_DICTIONARY):
		return null
	return holes[participantID].get(holeID)
static func isShaft(card) -> bool:
	if(typeof(card) != TYPE_DICTIONARY):
		return false
	if(typeof(card.get("base")) != TYPE_VECTOR3 || typeof(card.get("tip")) != TYPE_VECTOR3):
		return false
	var length = card.get("length")
	return typeof(length) == TYPE_REAL || typeof(length) == TYPE_INT
static func isHole(hole) -> bool:
	if(typeof(hole) != TYPE_DICTIONARY):
		return false
	return typeof(hole.get("pos")) == TYPE_VECTOR3 && typeof(hole.get("inward")) == TYPE_VECTOR3
static func lateralLimit(holeID:String) -> float:
	if(LATERAL_TOLERANCE.has(holeID)):
		return float(LATERAL_TOLERANCE[holeID])
	return LATERAL_TOLERANCE_OTHER
static func inwardLimit(holeID:String) -> float:
	if(MIN_INWARD_DOT.has(holeID)):
		return float(MIN_INWARD_DOT[holeID])
	return MIN_INWARD_DOT_OTHER
