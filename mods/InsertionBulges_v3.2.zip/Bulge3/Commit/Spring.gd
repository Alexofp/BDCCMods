extends Reference
const Lifetime := preload("res://Bulge3/Commit/Lifetime.gd")
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const Engagement := preload("res://Bulge3/Commit/Engagement.gd")
const TUNING := {"hz": 3.0, "hz_down": 3.0, "zeta": 0.85}
const RATE_SLOW := 0.5
const RATE_FAST := 5.5
const MAX_STEP := 1.0 / 30.0
static func hz() -> float:
	return float(TUNING["hz"])
static func zeta() -> float:
	return float(TUNING["zeta"])
static func hzDown() -> float:
	return float(TUNING["hz_down"])
static func hzFor(share:float) -> float:
	return lerp(RATE_SLOW, RATE_FAST, clamp(share, 0.0, 1.0))
static func setRates(upHz:float, downHz:float) -> bool:
	if(upHz <= 0.0 || downHz <= 0.0):
		push_error("Spring: rates must be > 0; still " + str(hz()) + "/" + str(hzDown()))
		return false
	TUNING["hz"] = upHz
	TUNING["hz_down"] = downHz
	return true
static func setZeta(zetaValue:float) -> bool:
	if(zetaValue <= 0.0):
		push_error("Spring: zeta must be > 0; still " + str(zeta()))
		return false
	TUNING["zeta"] = zetaValue
	return true
static func setTuning(hzValue:float, zetaValue:float) -> bool:
	if(hzValue < 0.0 || zetaValue <= 0.0):
		push_error("Spring: hz must be >= 0 (0 is off) and zeta > 0; still " \
			+ str(hz()) + "/" + str(zeta()))
		return false
	TUNING["hz"] = hzValue
	TUNING["hz_down"] = hzValue
	TUNING["zeta"] = zetaValue
	return true
static func settle(previous, entries:Array, now:float) -> Dictionary:
	var was:Dictionary = {}
	var dt:float = 0.0
	if(typeof(previous) == TYPE_DICTIONARY):
		if(typeof(previous.get("slots")) == TYPE_DICTIONARY):
			was = previous["slots"]
		dt = clamp(now - float(previous.get("now", now)), 0.0, MAX_STEP)
	var slots:Dictionary = {}
	var seen:Dictionary = {}
	for one in entries:
		if(typeof(one) == TYPE_DICTIONARY && typeof(one.get("engagement")) == TYPE_DICTIONARY):
			seen[Lifetime.relationKey(one["engagement"])] = true
	var inherited:Dictionary = {}
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var intent = entry.get("intent")
		var engagement = entry.get("engagement")
		if(typeof(engagement) != TYPE_DICTIONARY):
			continue
		if(typeof(intent) != TYPE_DICTIONARY):
			continue
		var target:float = float(intent["amplitude"])
		if(hz() <= 0.0):
			slots[Lifetime.relationKey(engagement)] = {"amplitude": target, "velocity": 0.0,
				"engagement": engagement, "intent": intent}
			continue
		var key:String = Lifetime.relationKey(engagement)
		var value:float = 0.0
		var velocity:float = 0.0
		var from = was.get(key)
		if(typeof(from) != TYPE_DICTIONARY):
			for oldKey in was:
				if(seen.has(oldKey) || inherited.has(oldKey) || typeof(was[oldKey]) != TYPE_DICTIONARY \
						|| typeof(was[oldKey].get("engagement")) != TYPE_DICTIONARY):
					continue
				if(holeKey(was[oldKey]["engagement"]) == holeKey(engagement)):
					inherited[oldKey] = true
					from = was[oldKey]
					break
		if(typeof(from) == TYPE_DICTIONARY):
			value = float(from.get("amplitude", 0.0))
			velocity = float(from.get("velocity", 0.0))
		var omega:float = TAU * hz()
		if(target < value):
			omega = TAU * hzDown()
		velocity += (omega * omega * (target - value) - 2.0 * zeta() * omega * velocity) * dt
		value = max(value + velocity * dt, 0.0)
		if(value <= 0.0):
			velocity = max(velocity, 0.0)
		slots[key] = {"amplitude": value, "velocity": velocity, "engagement": engagement,
			"intent": intent}
		entry["intent"] = Intent.withAmplitude(intent, value)
	for oldKey in inherited:
		seen[oldKey] = true
	settleTails(was, seen, slots, entries, dt)
	return {"now": now, "slots": slots}
static func settleTails(was:Dictionary, seen:Dictionary, slots:Dictionary, entries:Array,
		dt:float) -> void:
	if(hz() <= 0.0 || dt <= 0.0):
		return
	var omega:float = TAU * hzDown()
	for key in was:
		if(seen.has(key)):
			continue
		var old = was[key]
		if(typeof(old) != TYPE_DICTIONARY || typeof(old.get("intent")) != TYPE_DICTIONARY \
				|| typeof(old.get("engagement")) != TYPE_DICTIONARY):
			continue
		var value:float = float(old.get("amplitude", 0.0))
		var velocity:float = float(old.get("velocity", 0.0))
		velocity += (omega * omega * (0.0 - value) - 2.0 * zeta() * omega * velocity) * dt
		value = max(value + velocity * dt, 0.0)
		if(value <= Intent.MIN_AMPLITUDE):
			continue
		slots[key] = {"amplitude": value, "velocity": velocity,
			"engagement": old["engagement"], "intent": old["intent"]}
		entries.append({
			"engagement": settlingOf(old["engagement"]),
			"measures": null,
			"intent": Intent.withAmplitude(old["intent"], value),
		})
static func holeKey(engagement:Dictionary) -> String:
	return str(engagement.get("hole_owner")) + "/" + str(engagement.get("hole"))
static func settlingOf(engagement:Dictionary) -> Dictionary:
	var out:Dictionary = engagement.duplicate()
	out["state"] = Engagement.STATE_SETTLING
	return out
