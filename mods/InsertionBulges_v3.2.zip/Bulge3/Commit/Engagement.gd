extends Reference
const STATE_STATED := "stated"
const STATE_LATCHED := "latched"
const STATE_GRACED := "graced"
const STATE_SETTLING := "settling"
const INTENSITY_PRESENT := 1.0
static func engagement(relation:Dictionary, state:String, firstSeen:float, lastSeen:float,
		poseAge:float, pose:String, roster:String) -> Dictionary:
	var refused = relation.get("refused")
	if(typeof(refused) != TYPE_ARRAY):
		refused = []
	return {
		"shaft": relation["shaft"],
		"hole_owner": relation["hole_owner"],
		"hole": str(relation["hole"]),
		"provenance": {
			"source": str(relation["source"]),
			"confidence": int(relation["confidence"]),
			"refused": refused,
		},
		"state": state,
		"intensity": INTENSITY_PRESENT,
		"first_seen": firstSeen,
		"last_seen": lastSeen,
		"pose": pose,
		"pose_age": poseAge,
		"roster": roster,
	}
