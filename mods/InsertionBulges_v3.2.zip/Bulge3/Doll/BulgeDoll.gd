extends Node
const BulgeUtils = preload("res://Bulge3/Doll/BulgeUtils.gd")
const SLOT_PENIS := "penis"
const SLOT_STRAPON := "strapon"
const SLOT_HEAD := "head"
const SLOT_BODY := "body"
const NODE_NAME:String = "BulgeHelper"
const ANCHOR_BONE:Dictionary = {
	"vagina": "Hips",
	"anus": "Hips",
	"mouth": "Head",
}
const BULGE_BONE:Dictionary = {
	"vagina": "Hips",
	"anus": "Hips",
	"mouth": "Hips",
}
const BULGE_ORIGIN_BONE:Dictionary = {
	"mouth": "Neck",
}
const ANUS_OFFSET:Vector3 = Vector3(0.90518, -0.0511401, 0.0)
const MOUTH_OFFSET:Vector3 = Vector3(-0.31, -0.36, 0.0)
const SHAFT_RADIUS_FACTOR:float = 0.16
const TIP_EXTEND:float = 0.3
const ORIFICE_INWARD:Dictionary = {
	"vagina": Vector3(0.45, 0.89, 0.0),
	"anus": Vector3(-0.33, 0.94, 0.0),
	"mouth": Vector3(0.8, -0.6, 0.0),
}
var doll = null
var dirtyMeshes:Array = []
var zoneMemory:Dictionary = {}
var lastSizeResponse:float = 0.0
var straponScaleAsked:float = -1.0
var scaleOverride:float = 0.0
var taperCancelled:bool = false
static func forDoll(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll)):
		return null
	var existing = theDoll.get_node_or_null(NODE_NAME)
	if(existing != null):
		return existing
	var helper = load("res://Bulge3/Doll/BulgeDoll.gd").new()
	helper.name = NODE_NAME
	helper.doll = theDoll
	theDoll.add_child(helper)
	return helper
func getSkeletonNode() -> Skeleton:
	return doll.getDollSkeleton().getSkeleton()
func getPatternMeshesForSlot(slot) -> Array:
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return []
	var part = doll.parts[slot]
	var meshes = part.get("meshesThatUpdateMaterial")
	if(typeof(meshes) != TYPE_ARRAY):
		return []
	return meshes
func hasVisibleSlot(slot) -> bool:
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return false
	return doll.parts[slot].visible
func getShaftMeshesForSlot(slot) -> Array:
	var pattern:Array = getPatternMeshesForSlot(slot)
	if(!pattern.empty()):
		return pattern
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return []
	var found:Array = []
	collectShaftMeshes(doll.parts[slot], found)
	return found
func collectShaftMeshes(node, found:Array) -> void:
	for child in node.get_children():
		if(child is MeshInstance && child.mesh != null && "penis" in child.name.to_lower()):
			found.append(child)
		collectShaftMeshes(child, found)
func shaftMeshUsable(themesh) -> bool:
	if(themesh.has_method("supportsBulges")):
		return themesh.supportsBulges()
	return BulgeUtils.fitOf(themesh) != null
func getShaftInfo():
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var meshes:Array = []
	var radius:float = 0.0
	var profile:Array = []
	var skip:float = BulgeUtils.PROFILE_SKIP_BASE
	var edges:Array = [[], []]
	for slot in [SLOT_PENIS, SLOT_STRAPON]:
		if(!hasVisibleSlot(slot)):
			continue
		for themesh in getShaftMeshesForSlot(slot):
			if(!themesh.is_visible_in_tree() || !shaftMeshUsable(themesh)):
				continue
			meshes.append(themesh)
			if(profile.empty()):
				profile = BulgeUtils.getShaftProfile(themesh)
				skip = BulgeUtils.getShaftSkip(themesh)
				edges = BulgeUtils.getShaftEdges(themesh)
			var measured:float = BulgeUtils.getShaftGirth(themesh)
			if(measured > 0.0001):
				radius = max(radius, measured)
			else:
				var fit:Dictionary = BulgeUtils.fitOf(themesh)
				radius = max(radius, (fit["restMax"].y - fit["restMin"].y) * SHAFT_RADIUS_FACTOR)
		if(!meshes.empty()):
			break
	if(meshes.empty()):
		return null
	var basePos = getBoneWorldPos("Penis")
	var midPos = getBoneWorldPos("Penis2")
	var endPos = getBoneWorldPos("Penis3")
	if(basePos == null || midPos == null || endPos == null):
		return null
	var tipPos:Vector3 = endPos + (endPos - midPos) * TIP_EXTEND
	var drawnLength:float = getDrawnShaftLength(meshes)
	var scale:float = max(doll.rememberedPenisScale, 0.01)
	if(drawnLength > 0.01):
		tipPos = basePos + (tipPos - basePos).normalized() * drawnLength * scale
	return {
		"base": basePos,
		"tip": tipPos,
		"length": basePos.distance_to(tipPos),
		"radius": radius * scale,
		"meshes": meshes,
		"profile": profile,
		"skip": skip,
		"edge_up": edges[0],
		"edge_down": edges[1],
		"up": shaftUpWorld(skeleton, basePos, tipPos),
	}
func shaftUpWorld(skeleton:Skeleton, basePos:Vector3, tipPos:Vector3) -> Vector3:
	var along:Vector3 = tipPos - basePos
	var across:Vector3 = Vector3(-along.y, along.x, 0.0).normalized()
	var restBase:Vector3 = BulgeUtils.worldToRest(skeleton, "Penis", basePos)
	var restSide:Vector3 = BulgeUtils.worldToRest(skeleton, "Penis", basePos + across * 0.1)
	if(restSide.y < restBase.y):
		return -across
	return across
func getDrawnShaftLength(meshes:Array) -> float:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null || meshes.empty()):
		return 0.0
	var boneIdx:int = skeleton.find_bone("Penis")
	if(boneIdx < 0):
		return 0.0
	var rootRestX:float = BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).origin.x
	var longest:float = 0.0
	for themesh in meshes:
		var span:Vector2 = BulgeUtils.getShaftSpan(themesh)
		if(span == Vector2.ZERO):
			continue
		longest = max(longest, abs(rootRestX - span.y))
	return longest
func getBoneWorldPos(boneName:String):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return null
	return (skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)).origin
func getOrificeAnchor(zone:String):
	if(zone == "mouth"):
		var headNode = doll.get_node_or_null("BoneAttachments/HeadBoneAttachment")
		if(headNode == null || !hasVisibleSlot(SLOT_HEAD)):
			return null
		return headNode.global_transform.xform(MOUTH_OFFSET)
	var crotchNode = doll.get_node_or_null("BoneAttachments/VaginaBoneAttachment")
	if(crotchNode == null):
		return null
	if(zone == "anus"):
		return crotchNode.global_transform.xform(ANUS_OFFSET)
	if(zone == "vagina"):
		return crotchNode.global_transform.origin
	return null
func getOrificeInfo(zone:String):
	var anchor = getOrificeAnchor(zone)
	if(anchor == null):
		return null
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	return {
		"pos": anchor,
		"inward": BulgeUtils.restDirToWorld(skeleton, ANCHOR_BONE.get(zone, "Hips"), ORIFICE_INWARD.get(zone, Vector3(0.0, 1.0, 0.0))),
	}
func getBulgeMeshesForZone(_zone:String) -> Array:
	var result:Array = getPatternMeshesForSlot(SLOT_BODY)
	var filtered:Array = []
	for themesh in result:
		if(themesh.visible && themesh.supportsBulges()):
			filtered.append(themesh)
	return filtered
func getFrontContour(zone:String) -> Array:
	for themesh in getBulgeMeshesForZone(zone):
		if(!themesh.is_visible_in_tree()):
			continue
		var contour:Array = BulgeUtils.getFrontContour(themesh)
		if(!contour.empty()):
			return contour
	return []
func getBulgeOriginRest(zone:String):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	if(BULGE_ORIGIN_BONE.has(zone)):
		var boneIdx:int = skeleton.find_bone(BULGE_ORIGIN_BONE[zone])
		if(boneIdx >= 0):
			return BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).origin
	var anchor = getOrificeAnchor(zone)
	if(anchor == null):
		return null
	return BulgeUtils.worldToRest(skeleton, BULGE_BONE.get(zone, "Hips"), anchor)
func applyBulge(zone:String, index:int, entryWorld:Vector3, tipWorld:Vector3, radius:float, strength:float, shade:float, halfLength:float = 0.0, shape = null, bandEndWorld = null, axisDepth:float = 0.0):
	var meshes:Array = getBulgeMeshesForZone(zone)
	if(meshes.empty()):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	var boneName:String = BULGE_BONE.get(zone, "Hips")
	var restEntry:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, entryWorld)
	var restTip:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, tipWorld)
	var restBandEnd:Vector3 = restTip
	if(bandEndWorld != null):
		restBandEnd = BulgeUtils.worldToRest(skeleton, boneName, bandEndWorld)
	for themesh in meshes:
		var meshStrength:float = strength
		var fit = BulgeUtils.fitOf(themesh)
		if(typeof(fit) == TYPE_DICTIONARY):
			meshStrength = BulgeUtils.unfoldedAmplitude(strength,
				BulgeUtils.restToUV(fit, Vector2(restEntry.x, restEntry.y)),
				BulgeUtils.restToUV(fit, Vector2(restTip.x, restTip.y)), fit["aspect"])
		themesh.setBulge(index, Vector2(restEntry.x, restEntry.y), Vector2(restTip.x, restTip.y), radius, meshStrength, shade, halfLength, shape, Vector2(restBandEnd.x, restBandEnd.y), axisDepth)
		if(!dirtyMeshes.has(themesh)):
			dirtyMeshes.append(themesh)
func applyShaftClip(entryWorld:Vector3):
	if(BulgeUtils.option("bulgeShowShaft", false)):
		return
	var shaftInfo = getShaftInfo()
	if(shaftInfo == null):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	var restEntryX:float = BulgeUtils.worldToRest(skeleton, "Penis", entryWorld).x
	for themesh in shaftInfo["meshes"]:
		if(themesh.has_method("setShaftClipAtRestX")):
			themesh.setShaftClipAtRestX(restEntryX)
		else:
			BulgeUtils.setPlainShaftClip(themesh, restEntryX)
		if(!dirtyMeshes.has(themesh)):
			dirtyMeshes.append(themesh)
func clearBulgeState():
	for themesh in dirtyMeshes:
		if(!is_instance_valid(themesh)):
			continue
		if(themesh.has_method("clearBulges")):
			themesh.clearBulges()
			themesh.clearShaftClip()
			setBakedOn(themesh, false)
		else:
			BulgeUtils.clearPlainShaftClip(themesh)
	dirtyMeshes.clear()
func getNeckAxisWorld():
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var neckIdx:int = skeleton.find_bone("Neck")
	var headIdx:int = skeleton.find_bone("Head")
	if(neckIdx < 0 || headIdx < 0):
		return null
	var neckWorld:Vector3 = (skeleton.global_transform * skeleton.get_bone_global_pose(neckIdx)).origin
	var headWorld:Vector3 = (skeleton.global_transform * skeleton.get_bone_global_pose(headIdx)).origin
	var along:Vector3 = headWorld - neckWorld
	if(along.length() < 0.0001):
		return null
	return {"origin": neckWorld, "dir": along.normalized()}
func restorePenisScale() -> void:
	if(scaleOverride > 0.0):
		if(wouldChangeScale(scaleOverride)):
			doll.setPenisScale(scaleOverride)
		return
	var character = getCharacter()
	if(character == null):
		return
	var worn = character.getWornStrapon() if character.has_method("getWornStrapon") else null
	if(worn != null):
		if(worn.has_method("updateDoll") && abs(doll.rememberedPenisScale - straponScaleAsked) > 0.001):
			worn.updateDoll(doll)
			straponScaleAsked = doll.rememberedPenisScale
		return
	var intended:float = 1.0
	if(character.hasBodypart(SLOT_PENIS)):
		var penis = character.getBodypart(SLOT_PENIS)
		if(penis != null && penis.has_method("getPenisScale")):
			intended = penis.getPenisScale()
	if(wouldChangeScale(intended)):
		doll.setPenisScale(intended)
func wouldChangeScale(value:float) -> bool:
	return abs(doll.rememberedPenisScale - value) > 0.001
func getCharacter():
	if(doll == null || !is_instance_valid(doll) || !doll.has_method("getCharacterID")):
		return null
	var charID = doll.getCharacterID()
	if(charID is String):
		if(charID == ""):
			return null
		return GlobalRegistry.getCharacter(charID)
	return charID
func restBulgePoints(zone:String, entryWorld:Vector3, tipWorld:Vector3, bandEndWorld):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var boneName:String = BULGE_BONE.get(zone, "Hips")
	var restEntry:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, entryWorld)
	var restTip:Vector3 = BulgeUtils.worldToRest(skeleton, boneName, tipWorld)
	var restBandEnd:Vector3 = restTip
	if(bandEndWorld != null):
		restBandEnd = BulgeUtils.worldToRest(skeleton, boneName, bandEndWorld)
	return {
		"a": Vector2(restEntry.x, restEntry.y),
		"b": Vector2(restTip.x, restTip.y),
		"band": Vector2(restBandEnd.x, restBandEnd.y),
	}
func bulgeMeshesFor(zone:String) -> Array:
	return getBulgeMeshesForZone(zone)
func setBakedBulge(themesh, texture) -> void:
	if(themesh == null || !is_instance_valid(themesh) || !themesh.has_method("supportsBulges")):
		return
	if(!themesh.supportsBulges()):
		return
	themesh.fancyMaterial.set_shader_param("bulge_baked", texture)
	setBakedOn(themesh, true)
	if(!dirtyMeshes.has(themesh)):
		dirtyMeshes.append(themesh)
func setBakedOn(themesh, on:bool) -> void:
	if(themesh == null || !is_instance_valid(themesh) \
			|| themesh.get("fancyMaterial") == null):
		return
	var value:float = 0.0
	if(on):
		value = 1.0
	themesh.fancyMaterial.set_shader_param("bulge_baked_on", value)
const TAPER_BONES:Array = ["Penis2", "Penis3"]
func getShaftTaper() -> float:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return 1.0
	var smallest:float = 1.0
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx < 0):
			continue
		smallest = min(smallest, skeleton.get_bone_pose(boneIdx).basis.get_scale().y)
	return smallest
func unTaperShaftBones(squeeze:float = 1.0) -> void:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx < 0):
			continue
		var poseScale:Vector3 = skeleton.get_bone_pose(boneIdx).basis.get_scale()
		var worst:float = min(min(poseScale.x, poseScale.y), poseScale.z)
		if(worst <= 0.001):
			continue
		var inverse:Vector3 = Vector3(squeeze / poseScale.x, 1.0 / poseScale.y,
			squeeze / poseScale.z)
		skeleton.set_bone_custom_pose(boneIdx, Transform.IDENTITY.scaled(inverse))
	taperCancelled = true
func restoreShaftTaper() -> void:
	if(!taperCancelled):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx >= 0):
			skeleton.set_bone_custom_pose(boneIdx, Transform.IDENTITY)
	taperCancelled = false
