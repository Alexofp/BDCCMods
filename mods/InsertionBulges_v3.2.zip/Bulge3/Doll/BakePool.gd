extends Node
const Bake := preload("res://Bulge3/Present/Bake.gd")
const SIDE := 256
var targets := {}
func textureFor(key:String, slots:Array, aspect:Vector2):
	var entry = targets.get(key)
	if(entry == null):
		entry = build()
		targets[key] = entry
	entry["surface"].material = Bake.materialFor(slots, aspect)
	return entry["viewport"].get_texture()
func build() -> Dictionary:
	var viewport := Viewport.new()
	viewport.usage = Viewport.USAGE_3D
	viewport.hdr = true
	viewport.transparent_bg = true
	viewport.size = Vector2(SIDE, SIDE)
	viewport.own_world = true
	viewport.render_target_update_mode = Viewport.UPDATE_ALWAYS
	var surface := ColorRect.new()
	surface.rect_size = viewport.size
	viewport.add_child(surface)
	add_child(viewport)
	return {"viewport": viewport, "surface": surface}
