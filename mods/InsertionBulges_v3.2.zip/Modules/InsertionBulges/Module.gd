extends Module
const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const Commands := preload("res://Bulge3/Bench/Commands.gd")
const FoxLibOptions := preload("res://Modules/InsertionBulges/FoxLibOptions.gd")
func _init():
	id = "InsertionBulges"
	author = "xrob1"
func preInit():
	var _printed:bool = Boot.sayBootLineOnce()
	var _backends:bool = Boot.sayBackendsLineOnce()
	var _host = Commands.install("Module")
func onFoxLibModInit(foxModuleAPI):
	if(!Boot.mayRun("onFoxLibModInit")):
		return
	var _ids:Array = FoxLibOptions.declare(foxModuleAPI, self)
func onRestoreDefaults(_pressed = null):
	var _cleared:int = FoxLibOptions.restoreDefaults()
