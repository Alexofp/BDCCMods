const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const T_BOOL := "boolean"
const T_PERCENT := "slider"
const T_CHOICE := "choice"
const T_BUTTON := "button"
const CAT_MAIN := "Insertion Bulges"
const CAT_SHAPE := "Insertion Bulges: Shape"
const CAT_MOTION := "Insertion Bulges: Motion"
const CAT_THROAT := "Insertion Bulges: Throat"
const CATEGORIES := [CAT_MAIN, CAT_SHAPE, CAT_MOTION, CAT_THROAT]
const RESTORE_ID := "bulgeRestoreDefaults"
const OPTIONS := [
{
	"id": "bulgesEnabled", "cat": CAT_MAIN, "type": T_BOOL, "advanced": false,
	"title": "Show bulges",
	"desc": "Swell the body where something is inside it. Off turns the whole mod off.",
},
{
	"id": "bulgeSizeModifier", "cat": CAT_MAIN, "type": T_PERCENT, "advanced": false,
	"title": "Size",
	"desc": "How big the bulges are. 80% is the recommended size, 0% turns them off.",
},
{
	"id": "bulgePipeline", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["brush", "Detailed (recommended)"], ["classic", "Simple"]],
	"title": "Drawing quality",
	"desc": "Detailed: the bulge copies the real outline of the cock. Simple: a smooth bulge, lighter" \
		+ " on old graphics cards. Where the card cannot draw Detailed, Simple is used automatically.",
},
{
	"id": "bulgeLag", "cat": CAT_MAIN, "type": T_BOOL, "advanced": false,
	"title": "Soft, fleshy motion",
	"desc": "Bulges swell and settle like flesh instead of snapping from one frame to the next.",
},
{
	"id": "bulgeBellyVariant", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["off", "Off"], ["fade", "Bulge fades"], ["bone", "Belly grows"],
		["blend", "Belly grows, bulge fades"]],
	"title": "Pregnant belly",
	"desc": "On a pregnant or cum-filled body. Off: nothing changes. Bulge fades: the bulge melts" \
		+ " into the round belly. Belly grows: each thrust pushes the whole belly out. Both together.",
},
{
	"id": RESTORE_ID, "cat": CAT_MAIN, "type": T_BUTTON, "advanced": false,
	"title": "Restore recommended settings",
	"desc": "Puts every Insertion Bulges option back to the recommended value. Other mods'" \
		+ " options are not touched. Reopen this screen to see the controls move back.",
},
{
	"id": "bulgeShapeFidelity", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Show the shape of the cock",
	"desc": "0% is a smooth, round bulge; 100% shows the cock's real outline: knot, flare, head.",
},
{
	"id": "bulgeOtherHalfAdd", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Show knots and ridges",
	"desc": "Makes knots and ridges stand out more, so the bulge peaks higher where they are.",
},
{
	"id": "bulgeOtherHalfFollow", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Follow the belly-facing side",
	"desc": "A cock's top and bottom differ. 0% uses their average; 100% copies the side facing" \
		+ " the belly, bump for bump.",
},
{
	"id": "bulgeInsertedGirth", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Thicker toward the base",
	"desc": "0% sizes the bulge by the girth at the entrance; 100% by the whole length inside, so a" \
		+ " tapered cock looks thicker.",
},
{
	"id": "bulgeReachDeeper", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Allow taller bulges",
	"desc": "Lets big cocks raise taller bulges. Too high and the skin can look stretched from too" \
		+ " deep inside.",
},
{
	"id": "bulgeShade", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Shading",
	"desc": "Painted light and shadow on the bulge. 0% is the shape alone.",
},
{
	"id": "bulgeLagInflate", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Swell-up speed",
	"desc": "How fast a bulge grows. Needs \"Soft, fleshy motion\".",
},
{
	"id": "bulgeLagDeflate", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Settle-down speed",
	"desc": "How fast it goes down. Lower lets it linger after a pose change.",
},
{
	"id": "bulgeLagWobble", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Wobble",
	"desc": "How much the flesh overshoots and jiggles before it settles. 0% is none.",
},
{
	"id": "bulgeUnionOverlap", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Two at once: merge the bulges",
	"desc": "With two cocks inside: 0% keeps two separate bulges, 100% merges them into one.",
},
{
	"id": "bulgeBellyGain", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Belly push strength",
	"desc": "How far each thrust pushes a pregnant belly. Needs \"Pregnant belly\" set to one of" \
		+ " the \"Belly grows\" choices.",
},
{
	"id": "bulgeMouthAxisTravel", "cat": CAT_THROAT, "type": T_BOOL, "advanced": true,
	"title": "Follow the neck",
	"desc": "A throat bulge travels along the neck. Off places it like a crotch bulge, which looks" \
		+ " wrong on long muzzles.",
},
{
	"id": "bulgeMouthShape", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true,
	"title": "Throat bulge thickness",
	"desc": "Thinner throat bulges below 100%.",
},
{
	"id": "bulgeMouthColumn", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true,
	"title": "Swell the whole throat",
	"desc": "100% swells the throat in one piece from mouth to tip; lower leaves a lump that travels" \
		+ " with the tip.",
},
]
static func shipped(row:Dictionary):
	return Settings.compiled(str(row["id"]))
static func percentOf(row:Dictionary) -> int:
	return int(round(float(shipped(row)) * 100.0))
static func settingFor(row:Dictionary) -> String:
	if(str(row["type"]) == T_BUTTON || Settings.declaration(str(row["id"])) == null):
		return ""
	return str(row["id"])
static func rowFor(name:String) -> Dictionary:
	for row in OPTIONS:
		if(settingFor(row) == name):
			return row
	return {}
static func decode(row:Dictionary, raw):
	if(str(row["type"]) != T_PERCENT):
		return raw
	if(typeof(raw) != TYPE_INT && typeof(raw) != TYPE_REAL):
		return raw
	return float(raw) / 100.0
static func encode(row:Dictionary, given):
	if(str(row["type"]) != T_PERCENT):
		return given
	if(typeof(given) != TYPE_INT && typeof(given) != TYPE_REAL):
		return given
	return int(round(float(given) * 100.0))
const MANAGER_PATH := "res://Modules/FoxLib/Internal/FoxOptionsManager.gd"
const SECTION := Boot.MARKER_MOD
const STORE_LABEL := "FoxLib's mod options (section " + SECTION + " of user://foxlib/mod_options.cfg)"
const ABSENT := "insertionbulges-v3-no-such-foxlib-key"
const CACHE := {"looked": false, "manager": null}
static func manager():
	if(!CACHE["looked"]):
		CACHE["looked"] = true
		if(ResourceLoader.exists(MANAGER_PATH)):
			CACHE["manager"] = load(MANAGER_PATH)
	return CACHE["manager"]
static func live() -> bool:
	return manager() != null
static func storeLabel() -> String:
	return STORE_LABEL
static func forget() -> void:
	CACHE["looked"] = false
	CACHE["manager"] = null
static func stored(mgr = manager()) -> Dictionary:
	var out:Dictionary = {}
	if(mgr == null):
		return out
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name == ""):
			continue
		var raw = mgr.getOption(SECTION, str(row["id"]), ABSENT)
		if(typeof(raw) == TYPE_STRING && str(raw) == ABSENT):
			continue
		var vetted:Array = Settings.vetSetting(name, decode(row, raw))
		if(!vetted[0].empty()):
			Boot.loud("FoxLibOptions: " + STORE_LABEL + " holds '" + str(row["id"]) + "' = " \
				+ str(raw) + ", which this build cannot use - " \
				+ PoolStringArray(vetted[0]).join("; ") + ". THAT ONE SETTING IS IGNORED this run" \
				+ " and falls back to the bench or the compiled default; every other setting is" \
				+ " unaffected. Reset that option in FoxLib's mod options screen.")
			continue
		out[name] = vetted[1]
	return out
static func store(name:String, given, mgr = manager()) -> bool:
	if(mgr == null):
		Boot.loud("FoxLibOptions: asked to store '" + name + "' with FoxLib not installed. Nothing" \
			+ " written. This is a bug in the caller: Settings.store() must route to its own file" \
			+ " when FoxLib is absent.")
		return false
	var row:Dictionary = rowFor(name)
	if(row.empty()):
		Boot.loud("FoxLibOptions: '" + name + "' is not on FoxLib's options screen, so there is" \
			+ " nowhere in " + STORE_LABEL + " to put it. NOTHING WRITTEN and the value is NOT" \
			+ " saved. Add a row for it in FoxLibOptions.OPTIONS, or set it through the Bench.")
		return false
	mgr.setOption(SECTION, str(row["id"]), encode(row, given))
	mgr.optionalySave()
	return true
static func clear(name:String, mgr = manager()) -> bool:
	if(mgr == null || rowFor(name).empty()):
		return false
	mgr.clearOption(SECTION, str(rowFor(name)["id"]))
	mgr.optionalySave()
	return true
static func restoreDefaults(mgr = manager()) -> int:
	var cleared := 0
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name != "" && clear(name, mgr)):
			cleared += 1
	Boot.say("InsertionBulges v3: " + str(cleared) + " option(s) back to the recommended settings.")
	return cleared
static func declare(api, host = null) -> Array:
	var ids:Array = []
	if(api == null):
		Boot.loud("FoxLibOptions: FoxLib called onFoxLibModInit with no API object. NO OPTION IS" \
			+ " REGISTERED and the mod has no menu this run; it still draws.")
		return ids
	for row in OPTIONS:
		var id:String = str(row["id"])
		var cat:String = str(row["cat"])
		var kind:String = str(row["type"])
		var made = null
		if(kind == T_BOOL):
			made = api.addBooleanOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				bool(shipped(row)))
		elif(kind == T_PERCENT):
			made = api.addSliderOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				percentOf(row))
		elif(kind == T_CHOICE):
			made = api.addListOptionInCategory(cat, id, str(row["title"]), row["values"],
				str(row["desc"]), str(shipped(row)))
		elif(kind == T_BUTTON):
			made = api.addButtonOptionInCategory(cat, id, str(row["title"]), str(row["desc"]))
			if(made != null && host != null && made.has_signal("option_changed")):
				made.connect("option_changed", host, "onRestoreDefaults")
		if(made == null):
			Boot.loud("FoxLibOptions: FoxLib answered nothing for option '" + id + "', so that one" \
				+ " row is not on the screen. The rest are. This is a FoxLib API change - re-read" \
				+ " FoxLib/FoxModuleAPI.gd.")
			continue
		if(bool(row.get("advanced", false))):
			made = made.advanced()
		ids.append(id)
	return ids
