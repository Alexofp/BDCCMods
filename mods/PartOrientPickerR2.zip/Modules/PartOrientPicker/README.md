# Part Orient Picker

## How to use

1) add this repo as a submodule to `./Modules/PartOrientPicker`
2) add the picker with Instance Child Scene (CTRL + SHIFT + A) to your bodypart/clothing scene
3) add the part orient as a child to picker with Instance Child Scene
4) set the option in the part orient child scene, false for visible when doll is facing left (player default pose), true for visible when doll is facing right.
5) profit

