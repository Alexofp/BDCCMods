extends CumProduction

func getCapacity() -> float:
	var penis = getBodypart()
	var lenCM = penis.getLength()
	var ballMult = penis.getRawBallsScale()
	
	var mult = 1.0
	var pc = getCharacter()
	if(pc != null):
		mult += pc.getCustomAttribute(BuffAttribute.PenisBallsVolume)

	if(penis && penis.has_method("getOverrideCumCapacity")):
		return penis.getOverrideCumCapacity(mult)

	return max(round((50.0 + pow(lenCM, 2.0)) * mult), 0.0) * ballMult

func getProductionSpeedPerHour() -> float:
	var penis = getBodypart()
	var ballsDensity = penis.getBallsDensity()
	
	if(!shouldProduce()):
		return 0.0
		
	var mult = 1.0
	var pc = getCharacter()
	if(pc != null):
		mult += pc.getCustomAttribute(BuffAttribute.PenisCumProduction)

	return 100.0 * ballsDensity * mult

func getFluidSource():
	return FluidSource.Penis
