extends BodypartPenis

var sensitivity: float = 1.0
var ballsDensity: float = 1.0
var inward = false

#func _init():
	#var BetterCumProduction = preload("res://Modules/BallsExtraModule/Base/BetterCumProduction.gd")
	#limbSlot = LimbTypes.Penis
	#fluidProduction = BetterCumProduction.new()
	#fluidProduction.bodypart = weakref(self)
	#sensitiveZone = preload("res://Modules/BallsExtraModule/Base/SensitiveBetterPenis.gd").new()
	#sensitiveZone.setBodypart(self)
	#needsProcessing = true

func _init():
	limbSlot = LimbTypes.Penis
	initFluidProduction()
	setupSensitiveZone()
	needsProcessing = true

func initFluidProduction():
	var BetterCumProduction = preload("res://Modules/BallsExtraModule/Base/BetterCumProduction.gd")
	fluidProduction = BetterCumProduction.new()
	fluidProduction.bodypart = weakref(self)

func setupSensitiveZone():
	sensitiveZone = preload("res://Modules/BallsExtraModule/Base/SensitiveBetterPenis.gd").new()
	sensitiveZone.setBodypart(self)

func saveData():
	var data = .saveData()
	data["lengthCM"] = lengthCM
	data["sensitivity"] = sensitivity
	data["ballsScale"] = ballsScale
	data["ballsDensity"] = ballsDensity
	data["inwardTesties"] = inward
	
	return data

func loadData(_data):
	lengthCM = SAVE.loadVar(_data, "lengthCM", 15)
	sensitivity = SAVE.loadVar(_data, "sensitivity", 1.0)
	ballsScale = SAVE.loadVar(_data, "ballsScale", 1.0)
	ballsDensity = SAVE.loadVar(_data, "ballsDensity", 1.0)
	inward = SAVE.loadVar(_data, "inwardTesties", false)
	
	.loadData(_data)

func getPickableAttributes():
	var result = .getPickableAttributes()
	result["cocksize"] = {
		"text": "Pick your cock's length (slightly affects balls volume)",
		"textButton": "Length",
		"buttonDesc": "Pick the cock's length",
		"options": [
			[5, Util.cmToString(5), "Pick this length"],
			[8, Util.cmToString(8), "Pick this length"],
			[10, Util.cmToString(10), "Pick this length"],
			[13, Util.cmToString(13), "Pick this length"],
			[15, Util.cmToString(15), "Pick this length"],
			[18, Util.cmToString(18), "Pick this length"],
			[22, Util.cmToString(22), "Pick this length"],
			[25, Util.cmToString(25), "Pick this length"],
			[30, Util.cmToString(30), "Pick this length"],
			[40, Util.cmToString(40), "Pick this length"],
			[50, Util.cmToString(50), "Pick this length"],
		],
		"default": 15,
		"floatinput": true,
	}
	result["sensitivity"] = {
		"text": "Pick your cock's sensitivity (slightly affects balls volume)",
		"textButton": "Nerve density",
		"buttonDesc": "Pick the cock's sensitivity",
		"options": [
			[0.2, "Unresponsive", "Pick this sensitivity"],
			[0.33, "Desensitized", "Pick this sensitivity"],
			[0.5, "Numb", "Pick this sensitivity"],
			[1.0, "Normal", "Pick this sensitivity"],
			[2.0, "Sensitive", "Pick this sensitivity"],
			[3.0, "Delicate", "Pick this sensitivity"],
			[5.0, "Hypersensitive", "Pick this sensitivity"],
		],
		"default": 15,
		"floatinput": true,
	}
	result["ballsscale"] = {
		"text": "Pick your balls scale (affects balls volume)",
		"textButton": "Balls",
		"buttonDesc": "Pick the cock's balls scale",
		"options": [
			[0.0, "0%", "Pick this scale"],
			[0.3, "30%", "Pick this scale"],
			[0.5, "50%", "Pick this scale"],
			[0.8, "80%", "Pick this scale"],
			[1.0, "100%", "Pick this scale"],
			[1.2, "120%", "Pick this scale"],
			[1.5, "150%", "Pick this scale"],
			[1.8, "180%", "Pick this scale"],
			[2.0, "200%", "Pick this scale"],
			[2.5, "250%", "Pick this scale"],
			[3.0, "300%", "Pick this scale"],
			[4.0, "400%", "Pick this scale"],
			[5.0, "500%", "Pick this scale"],
		],
		"default": 1.0,
		"floatinput": true,
	}
	result["ballsdensity"] = {
		"text": "Pick your balls density (affects cum production speed)",
		"textButton": "Density",
		"buttonDesc": "Pick the cock's balls density",
		"options": [
			[0.1, "10%", "Pick this density"],
			[0.2, "20%", "Pick this density"],
			[0.5, "50%", "Pick this density"],
			[0.8, "80%", "Pick this density"],
			[1.0, "100%", "Pick this density"],
			[1.2, "120%", "Pick this density"],
			[1.5, "150%", "Pick this density"],
			[1.8, "180%", "Pick this density"],
			[2.0, "200%", "Pick this density"],
			[4.0, "400%%", "Pick this density"],
			[6.0, "600%", "Pick this density"],
			[8.0, "800%", "Pick this density"],
			[10.0, "1000%", "Pick this density"],
		],
		"default": 1.0,
		"floatinput": true,
	}
	result["inwardtesties"] = {
		"text": "Set your scrotum type (purely visual)",
		"textButton": "Scrotum",
		"buttonDesc": "Set internal/external balls",
		"options": [
			[true, "Internal", "Keep them warm inside"],
			[false, "External", "Let everyone see what you're packing"],
		],
		"default": false,
	}
	return result
	
func applyAttribute(_attrID: String, _attrValue):
	.applyAttribute(_attrID, _attrValue)
	match(_attrID):
		"cocksize":
			lengthCM = _attrValue
		"sensitivity":
			sensitivity = _attrValue
		"ballsscale":
			ballsScale = _attrValue
		"ballsdensity":
			ballsDensity = _attrValue
		"inwardtesties":
			inward = _attrValue

func getAttributesText():
	return [
		["Penis length", Util.cmToString(lengthCM)],
		["Sensitivity", str(Util.roundF(sensitivity*100.0, 1))+"%"],
		["Balls scale", str(Util.roundF(ballsScale*100.0, 1))+"%"],
		["Balls density", str(Util.roundF(ballsDensity*100.0, 1))+"%"],
		["Scrotum", "internal" if inward else "external"],
	]
	
func getCharCreatorData():
	return [
		["lengthCM", lengthCM],
		["sensitivity", sensitivity],
		["ballsScale", ballsScale],
		["ballsDensity", ballsDensity],
		["inwardTesties", inward],
	]

func getBallsScale():
	if inward: return 0.0
	return ballsScale

func getRawBallsScale():
	return ballsScale

func getBallsDensity():
	return ballsDensity

func getSensitivity():
	return sensitivity

func generateDataFor(_dynamicCharacter):
	var mod = GlobalRegistry.getModule("BallsExtra")
	
	lengthCM = max(Util.roundF(mod.generateFromDict("length"), 1), 5)
	sensitivity = mod.generateFromDict("sensitivity") / 100.0
	ballsScale = mod.generateFromDict("bscale") / 100.0
	ballsDensity = mod.generateFromDict("bdensity") / 100.0
	inward = RNG.chance(mod.getVal("inward", "Chance"))
	
	if(fluidProduction != null):
		fluidProduction.fillPercent(min(1.0, RNG.randf_range(0.8, 1.2)))
	generateRandomColors(_dynamicCharacter)
