extends Module

var FoxOption

var length = {
	"Min": 10,
	"Max": 25,
	"RareDev": 5,
	"RareChance": 10,
	"RareSkew": 50
}
var sensitivity = {
	"Min": 0.8,
	"Max": 1.2,
	"RareDev": 0,
	"RareChance": 0,
	"RareSkew": 50
}
var bscale = {
	"Min": 80,
	"Max": 120,
	"RareDev": 0,
	"RareChance": 0,
	"RareSkew": 50
}
var bdensity = {
	"Min": 80,
	"Max": 120,
	"RareDev": 0,
	"RareChance": 0,
	"RareSkew": 50
}
var inward = {
	"Chance": 10
}

func _init():
	id = "BallsExtra"
	author = "NatiM6"
	
	if(File.new().file_exists("res://FoxLib/FoxOption.gd")):
		FoxOption = load("res://FoxLib/FoxOption.gd")
		
		addOption("int", "length.Min", "Minimal penis length (cm)", "Minimal length of the dick", 10)
		addOption("int", "length.Max", "Maximal penis length (cm)", "Maximal length of the dick", 25)
		addOption("int", "length.RareDev", "Rare length deviation (cm)", "How far can the rare value deviate from the extremas", 0)
		addOption("int", "length.RareChance", "Rare length chance (%)", "How likely are rare sizes", 0)
		addOption("list", "length.RareSkew", "Rare length skew", "Which extreme is rarer", 50, [[100, "Small Only"], [75, "Small"], [50, "None"], [25, "Big"], [0, "Big Only"]])
		
		addOption("int", "sensitivity.Min", "Minimal penis sensitivity (%)", "Minimal sensitivity of the dick", 80)
		addOption("int", "sensitivity.Max", "Maximal penis sensitivity (%)", "Maximal sensitivity of the dick", 120)
		addOption("int", "sensitivity.RareDev", "Rare sensitivity deviation (%)", "How far can the rare value deviate from the extremas", 0)
		addOption("int", "sensitivity.RareChance", "Rare sensitivity chance (%)", "How likely are rare sensitivities", 0)
		addOption("list", "sensitivity.RareSkew", "Rare sensitivity skew", "Which extreme is rarer", 50, [[100, "Numb Only"], [75, "Numb"], [50, "None"], [25, "Sensitive"], [0, "Sensitive Only"]])
		
		addOption("int", "bscale.Min", "Minimal balls scale (%)", "Minimal scale of the balls", 80)
		addOption("int", "bscale.Max", "Maximal balls scale (%)", "Maximal scale of the balls", 120)
		addOption("int", "bscale.RareDev", "Rare scale deviation (%)", "How far can the rare value deviate from the extremas", 0)
		addOption("int", "bscale.RareChance", "Rare scale chance (%)", "How likely are rare scales", 0)
		addOption("list", "bscale.RareSkew", "Rare scale skew", "Which extreme is rarer", 50, [[100, "Small Only"], [75, "Small"], [50, "None"], [25, "Big"], [0, "Big Only"]])
		
		addOption("int", "bscale.Shrink", "Minimum fill scale (%)", "Percent of selected scale the balls shrink to when empty", 80)
		
		addOption("int", "bdensity.Min", "Minimal balls density (%)", "Minimal density of the balls", 80)
		addOption("int", "bdensity.Max", "Maximal balls density (%)", "Maximal density of the balls", 120)
		addOption("int", "bdensity.RareDev", "Rare density deviation (%)", "How far can the rare value deviate from the extremas", 0)
		addOption("int", "bdensity.RareChance", "Rare density chance (%)", "How likely are rare densities", 0)
		addOption("list", "bdensity.RareSkew", "Rare density skew", "Which density is rarer", 50, [[100, "Low Only"], [75, "Low"], [50, "None"], [25, "High"], [0, "High Only"]])
		
		addOption("int", "inward.Chance", "Inward scrotum chance (%)", "Chance of scrotum being hidden in %", 10)
	
	bodyparts = [
		"res://Modules/BallsExtraModule/Bodyparts/Penis/BetterCaninePenis.gd",
		"res://Modules/BallsExtraModule/Bodyparts/Penis/BetterDragonPenis.gd",
		"res://Modules/BallsExtraModule/Bodyparts/Penis/BetterEquinePenis.gd",
		"res://Modules/BallsExtraModule/Bodyparts/Penis/BetterFelinePenis.gd",
		"res://Modules/BallsExtraModule/Bodyparts/Penis/BetterHumanPenis.gd",
		"res://Modules/BallsExtraModule/Bodyparts/Penis/BetterOvipositorPenis.gd",
	]

func addOption(type, optionID, title, description=null, defaultValue=false, values=null):
	var newOption = FoxOption.new()
	newOption.moduleID = self.id
	newOption.category = self.id
	newOption.optionID = optionID
	newOption.title = title
	newOption.description = description
	newOption.type = type
	if defaultValue == null and values != null and not values.empty():
		defaultValue = values[0][0]
	newOption.defaultValue = defaultValue
	newOption.values = values
	
	newOption = newOption.register()
	
	var binder = optionID.split(".")
	self[binder[0]][binder[1]] = newOption

func generateFromDict(dict):
	var data = {}
	for el in ["Min", "Max", "RareDev", "RareChance", "RareSkew"]:
		data[el] = getVal(dict, el)
	
	var result
	if(RNG.chance(data.RareChance)):
		if(RNG.chance(data.RareSkew)):
			result = RNG.randf_range(data.Min - data.RareDev, data.Min)
		else:
			result = RNG.randf_range(data.Max, data.Max + data.RareDev)
	else:
		result = RNG.randf_range(data.Min, data.Max)
	return result

func getVal(dict, key):
	return self[dict][key].getOptionValue() if FoxOption else self[dict][key]
