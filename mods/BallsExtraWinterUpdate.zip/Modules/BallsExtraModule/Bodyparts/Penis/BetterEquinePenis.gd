extends "res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd"

func _init():
	visibleName = "flared penis"
	id = "equinepenis"
	lengthCM = 22
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["flared", "horse-shaped", "horse"])

func getDoll3DScene():
	return "res://Player/Player3D/Parts/Penis/EquinePenis/EquinePenis.tscn"

func getPenisScale():
	return max(0.1 + (lengthCM - 5.0) / 21.0, 0.3)

func getTraits():
	return {
		PartTrait.PenisFlare: true,
	}

func shouldUseBigPump():
	return true
