extends BodypartBreasts

func _init():
	visibleName = "hyperable scaled puffy breasts"
	id = "scaledbreastspuffyhyperable"
	size = BreastsSize.C

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastPuffy/ScaledBreastPuffyFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastPuffy/ScaledBreastPuffy.tscn"

func getTraits():
	return {
		"Hyperable": true,
	}

func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
