extends Module

func _init():
	id = "UndressFix_v0.5"
	author = "ChadStevens"
	
	sexActivities = [
		"res://Modules/UndressFix_v0.5/DomUndressesSub.gd",
	]

func postInit():
	for p in sexActivities:
		if ResourceLoader.exists(p):
			GlobalRegistry.registerSexActivity(p)
			print("[UndressFix_v0.5] Force-registered " + p.get_file())
		else:
			print("[UndressFix_v0.5] MISSING " + p)
