extends Module

var curve : Curve = Curve.new()

func _init():
	id = "RAT_DomEndurance"
	author = "Selinoccino"
	
	scenes = [
		"res://Modules/RAT_DomEndurance/editorScene.gd"
	]
	
	events = [
		"res://Modules/RAT_DomEndurance/editorEvent.gd"
	]
	

func RatRegister(ratreg) -> void:
	ratreg.registerSavedMod(self)

func postInit():
	GlobalRegistry.registerScene("res://Modules/RAT_DomEndurance/newGenericSexScene.gd")

func setCurve(c:Curve) -> void:
	curve = c

func getCurve() -> Curve:
	return curve


func RatSave() -> Dictionary:
	var cv : Curve = getCurve()
	var cdata : Dictionary = SexToyEffectEntry.new().saveCurve(cv)
	cdata["max_value"] = cv.max_value
	return {
		"curve": cdata
	}

func RatLoad(_d) -> void:
	if _d.get("RESET", false):
		setCurve(Curve.new())
		return
	
	var cdata : Dictionary = SAVE.loadVar(_d, "curve", {})
	var cv : Curve = SexToyEffectEntry.new().loadCurve(cdata)
	cv.max_value = cdata.get("max_value", 1.0)
	setCurve(cv)
