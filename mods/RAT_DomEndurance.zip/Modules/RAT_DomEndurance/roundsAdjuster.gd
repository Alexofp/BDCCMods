extends VBoxContainer

onready var curvitor = $hb/curvitor

func _ready():
	var c : Curve = getCurve()
	curvitor.set_curve(c)
	
	$maxhb/max.max_value = c.max_value
	$maxhb/max.get_line_edit().text = "%s" % c.max_value
	$maxhb/max.apply()
	$maxhb/max.connect("value_changed", self, "_on_max_value_changed")

func getCurve() -> Curve:
	return GlobalRegistry.getModule("RAT_DomEndurance").getCurve()

func saveCurve() -> void:
	GlobalRegistry.getModule("RAT_DomEndurance").setCurve(curvitor._curve)


func _on_max_value_changed(value):
	curvitor._curve.set_max_value(value)
	curvitor.update()


func save():
	saveCurve()
