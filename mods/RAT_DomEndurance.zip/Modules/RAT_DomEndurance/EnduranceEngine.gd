extends SexEngine

func getRounds(characterID:String) -> int:
	var curve : Curve = GlobalRegistry.getModule("RAT_DomEndurance").getCurve()
	
	var largestLust : float = 0.0
	for sub in subs:
		var newLust : float = GM.main.RS.getLust(sub, characterID) # for char, from/of char
		if newLust > largestLust:
			largestLust = newLust
	
	return int(curve.interpolate(largestLust))

func generateGoals():
	var amountToGenerate = subs.size()-1
	var generatedAnyGoals:bool = false
	
	for domID in doms:
		if(generateGoalsFor(domID, getRounds(domID) + amountToGenerate)):
			generatedAnyGoals = true

	if(!isDom("pc") && !generatedAnyGoals && !doms.empty() && !pcControlsDoms):
		addTextRaw("Dom couldn't decide what to do with the sub, none of their fetishes apply.")
		talkText(RNG.pick(doms), "You are a lucky slut.")

func checkIfDomsNeedMoreGoals():
	if(!shouldDomsKeepGeneratingTasks()):
		return
	if(sexEnded):
		return
	
	for domID in doms:
		var domInfo:SexDomInfo = doms[domID]
		if(!domInfo.hasGoals() && !domInfo.isDynamicJoiner()):
			generateGoalsFor(domID, getRounds(domID))

func addDynamicDomParticipant(_charID:String):
	if(doms.has(_charID) || subs.has(_charID)):
		return
	var domInfo := SexDomInfo.new()
	domInfo.initInfo(_charID, self)
	domInfo.setDynamicJoiner(true)
	doms[_charID] = domInfo
	checkRevealedFor(_charID)
	generateGoalsFor(_charID, getRounds(_charID))
	addTextRaw("[b]NEW DOMINANT![/b] "+domInfo.getChar().getName()+" joins in on the fun.")
	participatedDoms[_charID] = true
	if(GM.main):
		if(_charID != "pc" && GM.main.IS.hasPawn(_charID)):
			var sexLoc:String = getLocation()
			if(sexLoc != ""):
				GM.main.IS.getPawn(_charID).setLocation(sexLoc)
			GM.main.IS.startInteraction("InSex", {main=_charID})
