extends SceneBase

func _init():
	sceneID = "RAT_DomEndurance_Editor"
	

func _run():
	GM.ui.addFullScreenCustomControl("roundsEditor", load("res://Modules/RAT_DomEndurance/roundsAdjuster.tscn").instance())
	addButton("Done", "Yup", "end")

func _react(_action:String, _args):
	if _action == "end":
		endScene()
		return
	
	setState(_action)
