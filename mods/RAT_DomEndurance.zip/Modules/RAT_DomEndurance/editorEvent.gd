extends EventBase

func _init():
	id = "RAT_DomEndurance_EditorEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook,["MeScene",""])

func run(_id,_args):
	addButton("Adjust DomEndurance", "Give em more or less endurance", "doCurvitor")


func onButton(_method, _args):
	if(_method == "doCurvitor"):
		runScene("RAT_DomEndurance_Editor")
