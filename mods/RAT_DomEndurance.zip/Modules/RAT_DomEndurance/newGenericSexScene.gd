extends "res://Scenes/GenericSexScene.gd"

func _initScene(_args = []):
	sexEngine = load("res://Modules/RAT_DomEndurance/EnduranceEngine.gd").new()
	sexEngine.setInventoryToUse(sceneSavedItemsInv)
	
	var tops = _args[0]
	var bottoms = _args[1]
	if(tops is String):
		tops = [tops]
	if(bottoms is String):
		bottoms = [bottoms]
	
	for top in tops:
		if(top != "pc"):
			addCharacter(top)
	for bottom in bottoms:
		if(bottom != "pc"):
			addCharacter(bottom)
	
	sexEngine.initPeople(tops, bottoms)
	if(_args.size() > 2):
		var typeargs = {}
		if(_args.size() > 3):
			typeargs = _args[3]
		sexEngine.initSexType(_args[2], typeargs)
	else:
		sexEngine.initSexType(SexType.DefaultSex)
	
	sexEngine.start()

func loadData(data):
	.loadData(data)
	
	sexEngine = load("res://Modules/RAT_DomEndurance/EnduranceEngine.gd").new()
	sexEngine.setInventoryToUse(sceneSavedItemsInv)
	currentCategory = SAVE.loadVar(data, "currentCategory", [])
	sexEngine.loadData(SAVE.loadVar(data, "sexEngine", {}))
