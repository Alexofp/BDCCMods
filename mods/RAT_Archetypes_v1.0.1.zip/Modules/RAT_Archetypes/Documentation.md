# First things first
All code that adds/modifies Archetypes/Callables or in any way has to do with the mod, has to be done using a function called `RatArchetify` (void) inside your `Module.gd`. This isn't a rule but it's best to use that unless you know what you're doing.
# Callables
A Callable is the standard way to extend/override functionality for a species.
## Creation
A Callable can be created in two ways:
1. `TypedSpecies.createCallable(object, method)`
2. `TypedSpecies.Callable.new(object, method)`
In either case, `object` must be an Object with a String variable called `id`, and `method` must be a String and a function inside `object`.
You can then further specify the Callable's properties, by chaining, like so:
```gdscript
var callable = TypedSpecies.createCallable(self, "testMethod")\
	.setArgs(["string", 1.0]).setUnbind(1)\
	.setPriority(10)
```
## Priority
Callables with a lower priority are called first. Callables with the same priority are called alphabetically based on the object's `id` variable.
Adding a Callable with the same object `id` and priority as another will replace the Callable.
## Args
Arguments are called in this order:
1. Base arguments (defined by you)
2. Previous returned value (for return Callables; ignore for void ones)
3. Default method arguments (eg. `_npc, _args` for `onDynamicNpcCreation`)
Unbinding arguments will cull the last `x` number of default method arguments, where `x` is the amount of unbound arguments.
## Void or return?
A Callable's return type is always defined by its method. The method are always base BDCC species functions.
## Registering
A Callable can be registered in one or more species functions, and/or one or more [[#Archetypes]]. Registering is done like so for functions:
```gdscript
TypedSpecies.addCallableToMethod(callable, method)
```
Where `method` is a String and corresponds to a base BDCC function name.
## Non-standard methods
You can also add Callables to a few new/modified methods as well, for now those are only two:
- `onPreDynamicNpcCreation(_npc, _args)`: Called before an Archetype is applied when a Dynamic NPC is created
- `onDynamicNpcCreation(_npc, _args)`: Called after an Archetype is applied when a Dynamic NPC is created
# Archetypes
The difference between Archetypes and [[#Callables]] is that only one Archetype can be applied/used for any NPC, while Callables are always called for every NPC of a species.
## Creation
Archetypes, too, can be created in two ways:
1. `TypedSpecies.createArchetype(id, callable, defaultWeight)`
2. `TypedSpecies.Archetype.new(id)`
Where `id` is a String, `callable` is a Callable, and `defaultWeight` is a float.
It is recommend to use the first way. Unlike [[#Callables]], Archetypes can't be chained. Setting their properties is done like a normal object:
```gdscript
var arch = TypedSpecies.createArchetype("arch123", callable, 1.0)
arch.optionDisplay = "Archetype X"
arch.description = "Does things"
```
This creates an Archetype that displays as "Archetype X" in the RodentUtils options, and has the description "Does things" (pretty self-explanatory), which calls the `callable` Callable when selected.
Once you're done and have your Archetype ready, simply call `TypedSpecies.addArchetype(archetype)` to add it, where `archetype` is an Archetype object.