extends Module

var replacedSpecies : Array = []

var defaultArchetypeWeight : float = 15.0
var maxArchetypesPerNpc : float = 1.0

func _init():
	id = "RAT_Archetypes"
	author = "Selinoccino"
	

func loadModContent(mod:Module) -> void:
	if mod.has_method("RatArchetify"):
		mod.RatArchetify()

func postInit():
	replaceAllSpecies()
	
	for mod in GlobalRegistry.getModules().values():
		loadModContent(mod)
	
	Defaultify()


func replaceAllSpecies():
	var typesSpecies = load("res://Modules/RAT_Archetypes/TypedSpecies.gd")
	
	var allsps = GlobalRegistry.getAllSpecies()
	for species in allsps:
		var spobj = allsps[species]
		if spobj:
			typesSpecies.new(spobj)
	

func defaultifyDynamicNpc(_npc, _args):
	return

func Defaultify() -> void:
	for species in GlobalRegistry.getAllSpecies().values():
		if species.archetypes.empty():
			continue
		var callable = species.createCallable(self, "defaultifyDynamicNpc")
		var archetype = species.createArchetype("default", callable, defaultArchetypeWeight)
		
		archetype.optionDisplay = "Default Archetype"
		archetype.description = "All bodyparts kept the same"
		
		species.addArchetype(archetype)

func readJsonData(path:String, type:int=TYPE_DICTIONARY, nullval={}):
	var f = File.new()
	
	var e = f.open(path, File.READ)
	
	if e != OK:
		Log.error(id+": error accessing json data file %s, code %s" % [ path, e])
		return nullval
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		Log.error(id+": error reading json data from file %s, code %s at line %s, message: %s" % [ path, r.error, r.error_line, r.error_string ])
		return nullval
	
	if typeof(r.result) != type:
		Log.error(id+": error parsing json data from file %s, unexpected return type, type: %s, expected: %s" % [ path, typeof(r.result), type ])
		return nullval
	
	return r.result
	


var typesOptions : Dictionary = {
	# species::typeID: foxlib option
}

func RatConfigure(rac):
	rac.overrideModConfigName(id, "Archetypes (Rat)")
	rac.addOptionNum(id, "maxArchetypesPerNpc", "General", "Advanced: Max applied Archetypes", "Maximum number of applied Archetypes on any given Dynamic NPC.", 1.0)\
		.setStep(1.0).setMin(0.0).setGreater()
	
	for species in GlobalRegistry.getAllSpecies().values():
		ratifyTypedSpecies(species, rac)

func ratifyTypedSpecies(typedSpecies, ratc):
	var archetypes : Array = typedSpecies.archetypes
	var species : Species = typedSpecies.mimic
	
	for archetype in archetypes:
		var sptext = species.getVisibleName()
		var newID : String = species.id+"::"+archetype.id
		
		var desc = archetype.description
		
		typesOptions[newID] = ratc.addOptionNum(id, newID, sptext + " Weights", "Archetype %s" % archetype.id if !archetype.optionDisplay else archetype.optionDisplay.replace("{DEF}", sptext), "Weight for this archetype" + ("\n\n"+desc if desc else ""), getDefaultForArchetype(newID))

func getDefaultForArchetype(typestr:String) -> float:
	var split = typestr.split("::", false, 2)
	var speciesID = split[0]
	if split.size()<2 or !GlobalRegistry.getAllSpecies().has(speciesID):
		return 0.0
	
	var archetypeID = split[1]
	var archetype = GlobalRegistry.getSpecies(speciesID).getArchetype(archetypeID)
	if !archetype:
		return defaultArchetypeWeight
	
	return archetype.defaultWeight

func getWeightForArchetype(typestr:String) -> float:
	var option = typesOptions.get(typestr, null)
	if option:
		return option.getValue()
	
	return getDefaultForArchetype(typestr)
