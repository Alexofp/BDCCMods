extends SceneBase

func _init():
	sceneID = "YefimReturnNoList"


func _run():
	if(state == ""):
		addCharacter("yefim")
		playAnimation(StageScene.Duo, "stand", {npc="yefim"})
		
		saynn("Against your better judgement, you decide to approach the fox again")
		
		saynn("[say=pc]Hello again?[/say]")

		saynn("[say=yefim]What do you want? Oh, its you again.[/say]")
		saynn("He looks you up and down, the tall lanky fox imposing over you.")
		saynn("[say=yefim] Look, I'm not gonna say much. You interested or no?[/say]")
		saynn("The vixen seems to be irritated with you bothering them.")

		addButton("Listen", "Listen to his proposition", "listen")
		addButton("Nah", "Show your disinterest", "nah")


	if(state == "nah"):
		saynn("[say=pc]Nah, sorry, I'm not interested.[/say]")

		saynn("You show your clear lack of interest, as you hear a sigh, and what seems like a sneer from the old fox.")

		saynn("[say=yefim]Whatever, stop bothering me unless you're going to hear what I say.[/say]")

		saynn("As he finished saying that, you are already out of earshot. Better not get involved into something shady. He seems relieve that you have stopped bothering him.")
		
		addButton("Leave", "Get away from the shady fox.", "endthescene")

		setFlag("YefimExpansionModule.ReturnNoList", true)
		setFlag("YefimExpansionModule.DispositionAppleQ", false)

	if(state == "listen"):
		saynn("You decide it would be harmless to at least hear them out. After all, they're proposing what seems like work. And he seems irritated at being bothered for no reason, so why not?")

		saynn("[say=pc]Yeah, sure.. I'm interested, what kind of proposition do you have?[/say]")
		
		saynn("[say=yefim]First things first, what's your name?[/say]")
		
		saynn("[say=pc]My name is {pc.name}, what about you?[/say]")

		saynn("[say=yefim]I don't have to give you my name, now great to have you interested {pc.name}. I have a decent chit of credits, but first...[/say]")

		saynn("He would straighten his back from leaning on the wall which was hunched, as he would stare down at you. He was a bit taller now that he wasn't hunched over leaning against the wall. His eyes seem to gaze straight into you with scrutiny.")

		saynn("[say=yefim]First things first. Get me an apple from the Greenhouse. You do that, and I'll fill you in on the job.[/say]")

		saynn("[say=pc]But why? Can't you just fill me in on it right now?[/say]")

		saynn("[say=yefim]I need proof you can at least get things done, {pc.name}. If you can't do even this, I'm not risking my neck out for someone who can't do something as simple as that.[/say]")
		
		setFlag("YefimExpansionModule.DispositionAppleQ", false)

		addButton("Accept", "Accept the task of acquiring an apple from the greenhouse", "accept")
		addButton("Refuse", "Refuse the task of acquiring an apple from the greenhouse", "refuse")


	if(state == "accept"):
		saynn("[say=pc]Alright. I'll get the apple.[/say]")
		
		saynn("[say=yefim]Good to have you onboard with this, {pc.name}. Greenhouse is in the yard, you'll know when you see it.[/say]")
		
		saynn("The old fox would cross their arms, looking sternly at you as he shook his head, grumbling about something inaudible. ")
		
		saynn("You could only nod in awknowledgement.")
		
		saynn("[say=pc]Alright. I'll come back to you with news once I get it.[/say]")
		
		saynn("The fox cackles for a moment, giving you a crooked smile. He clearly already hates your guts.")
		
		saynn("[say=yefim]Good luck.[/say]")
		
		addButton("Continue", "Go off on your own.", "endthescene")
		
		setFlag("YefimExpansionModule.Quest3Accept", true)

		


	if(state == "refuse"):
		saynn("[say=pc]No, I'll pass.[/say]")
		
		saynn("His face seemed to scrunch quite a bit, seemingly a bit irritated before sighing.")
		
		saynn("[say=yefim]Well, I'm not too surprised. I don't really care though, if you bring the apple to me, I'll fill you in, since clearly that means you've changed your mind.[/say]")
		
		saynn("You could only nod as you walk away from the fox, who returned to leaning on the wall, as you move on with your day.")
		
		addButton("Continue", "Leave", "endthescene")
		
		setFlag("YefimExpansionModule.Quest3Accept", true)

		


func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
