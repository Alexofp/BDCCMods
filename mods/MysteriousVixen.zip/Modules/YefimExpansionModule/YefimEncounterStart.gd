extends EventBase

func _init():
	id = "YefimEncounterStart"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "main_hall_west")

func run(_triggerID, _args):
	if getFlag("YefimExpansionModule.CH1Comp"):
		return

	if getFlag("YefimExpansionModule.AppleQuestComp"):
		saynn("The wall you met the fox at. He's not around anymore.")
		return

	if not getFlag("YefimExpansionModule.FirstEncounterHappened"):
		saynn("There seems to be a rather tall, lanky fox, a Red from High Security, leaning against the wall.")
		addButtonUnlessLate("Approach", "Greet the fox and see what's up.", "yefStart")
	else:
		saynn("The tall fox is leaning against the wall again.")

		if getFlag("YefimExpansionModule.Quest1Accept"):
			addButtonUnlessLate("Approach", "Speak to Yefim about the job.", "yefQuest")
		if getFlag("YefimExpansionModule.Quest3Accept"):
			addButtonUnlessLate("Approach", "Speak to Yefim about the job.", "yefQuest2")
		elif getFlag("YefimExpansionModule.FirstEncounterResult2"):
			addButtonUnlessLate("Approach", "Speak to the fox again.", "yefReturn")
		elif getFlag("YefimExpansionModule.ReturnNoList"):
			addButtonUnlessLate("Approach", "Bother the fox again.", "yefReturnNoListen")

func getPriority():
	return 5

func onButton(_method, _args):
	if _method == "yefStart":
		runScene("YefimFirstEncounter")
	elif _method == "yefReturnNoListen":
		runScene("YefimReturnNoList")
	elif _method == "yefReturn":
		runScene("YefimReturnEncounter")
	elif _method == "yefQuest":
		runScene("YefimQuestDiscussion")
	elif _method == "yefQuest2":
		runScene("YefimQuestDiscussion2")

