extends SkinBase

func _init():
	id = "YefimSkin"

func getName():
	return "YefimSkin"

func getPatternTexture():
	return preload("res://Modules/YefimExpansionModule/YefimSkin/yefim.png")
	
