extends SceneBase

func _init():
	sceneID = "YefimQuestDiscussion"

func _run():
	if state == "":
		addCharacter("yefim")
		playAnimation(StageScene.Duo, "stand", {npc="yefim"})


		saynn("You decide to approach the fox leaning against the wall in his usual spot.")

		saynn("[say=yefim] Hey there, you're back. Got my apple?[/say]")
		
		addButton("Nope", "No apple just yet", "Nope")
		addButton("Leave", "Get away from the shady fox.", "endthescene")

		if(GM.pc.getInventory().hasItemID("appleitem")):
			addButton("Yup!", "Give him the Apple", "Complete")
		
		
	if(state == "Nope"):
		saynn("[say=pc]Nah, sorry, I haven't gotten it yet.[/say]")

		saynn("A sneer from the old fox, before a chuckle.")

		saynn("[say=yefim]Well, alright.[/say]")

		if getFlag("YefimExpansionModule.Encounter1Trust") == true:
			saynn("As he finished saying that, he has something to say, though he doesnt seem to make it that obvious that he does..")
		
			addButton("Listen", "Hear him out.", "listen")
			addButton("Leave", "Leave him be.", "endthescene")

	if(state == "listen"):
		saynn("You decide it would be harmless to at least hear them out. Seeing you not walk away, he chuckles, seems to be ready to tell you something.")
		
		saynn("[say=yefim]Take it slowly. The guards patrol, but often enough inconsistent, and they usually couldn't be bothered if you don't resist if you get caught aside from kicking you out. One of the guards, Nova, usually hangs around the area with apple trees. West of that, theres a place you can leap off from to return into the yard. As for Nova, you probably could convince her to play nice. She's a former inmate, afterall.[/say]")
		
		saynn("The fox cackles, staring at you as you are a bit in shock. He gave  you quite decent advice and information, some things you probably would have probably not known. You wonder how he got his hands on this knowledge.")
		
		saynn("[say=pc]Thanks, I'll keep that in mind.[/say]")

		saynn("He only nods in awknowledgement, not saying anymore.")
		addButton("Leave", "Set off.", "endthescene")
		

		

		


	if(state == "Complete"):
		saynn("[say=pc]Here it is.[/say]")
		
		saynn("His face seemed to soften, before cracking a smile.")
		
		saynn("[say=yefim]Well, I'm not too surprised... crafty.[/say]")
		
		saynn("He would take a bite of of the apple, a rather loud crunch as he bit off almost half of the apple in a single bite. It was a bit mesmerising.. and scary.")
		
		saynn("[say=yefim]Good stuff.[/say]")
		
		saynn("[say=pc]So, do I get the gracious knowledge of who you are, and the actual job you pro-[/say]")
		
		saynn("Before you could finish, he placed a hand on your face, gently pressing your lips together to silence you. ")
		
		saynn("[say=yefim]Not here. I'll meet you at... the area near the pond, at... say 20:00.. I'll be there up until 21:00. If you're a no show, I'll be there at another time.[/say]")
		
		saynn("Before you could say anything else, the fox lets go of your face, as he walks off towards the cellblocks. Something tells you that trying to follow him is a very bad idea.")
		
		
		addButton("Continue", "Leave", "endthescene")
		GM.pc.getInventory().removeXOfOrDestroy("appleitem", 1)
		setFlag("YefimExpansionModule.AppleQuestComp", true)
		setFlag("YefimExpansionModule.DispositionAppleQ", true)
	

func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return

	setState(_action)
