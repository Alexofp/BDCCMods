extends SceneBase

func _init():
	sceneID = "YefimReturnEncounter"

func _run():
	if state == "":
		addCharacter("yefim")
		playAnimation(StageScene.Duo, "stand", {npc="yefim"})


		saynn("You decide to approach the fox leaning against the wall in his usual spot.")

		saynn("[say=yefim] Hey there, you're back. Interested in my proposition?[/say]")

		addButton("Listen", "Listen to his proposition", "listen")
		addButton("Nah", "Show your disinterest", "nah")
		addButton("Leave", "Leave Yefim alone.", "endthescene")
		
	if(state == "nah"):
		saynn("[say=pc]Nah, sorry, I'm not interested.[/say]")

		saynn("You show your clear lack of interest, as you hear a sigh, and what seems like a sneer from the old fox.")

		saynn("[say=yefim]Suit yourself. But if you ever are interested, I'll be here on occasion.[/say]")

		saynn("As he finished saying that, you are already out of earshot. Better not get involved into something shady.")
		
		addButton("Leave", "Get away from the shady fox.", "endthescene")

		setFlag("YefimExpansionModule.FirstEncounterResult2", true)

	if(state == "listen"):
		saynn("You decide it would be harmless to at least hear them out. After all, they're proposing what seems like work.")

		saynn("[say=pc]Yeah, sure. I guess. I'm interested, what kind of proposition do you have?[/say]")
		
		saynn("[say=yefim]First things first, what's your name?[/say]")
		
		saynn("[say=pc]My name is {pc.name}, what about you?[/say]")

		saynn("[say=yefim]I'll save my name for another time, now great to have you interested {pc.name}. Now, I don't have too many credits on hand, but I can offer something else in exchange, a tool perhaps, which will help you out, but first....[/say]")

		saynn("He would straighten his back from leaning on the wall which was hunched, as he would stare down at you. He was a bit taller now that he wasn't hunched over leaning against the wall.")

		saynn("[say=yefim]First things first. Get me an apple from the Greenhouse. You do that, and I'll fill you in on the job.[/say]")

		saynn("[say=pc]But why? Can't you just fill me in on it right now?[/say]")

		saynn("[say=yefim]I need proof you can at least get things done. If you can't do even this, I'm not risking my neck out for someone who can't do something as simple as that. So are you in?[/say]")
		

		addButton("Accept", "Accept the task of acquiring an apple from the greenhouse", "accept")
		addButton("Refuse", "Refuse the task of acquiring an apple from the greenhouse", "refuse")
		
		setFlag("YefimExpansionModule.FirstEncounterResult2", false)


	if(state == "accept"):
		saynn("[say=pc]Alright. I'll get the apple.[/say]")
		
		saynn("[say=yefim]Good to have you onboard with this, {pc.name}. If you don't already know, you can get to the greenhouse, after exiting the Main Platform, go left, and you'll eventually reach the entrance, which will be marked.[/say]")
		
		saynn("The old fox would cross their arms, looking sternly at you as he shook his head, grumbling about something inaudible before speaking up. ")
		
		saynn("[say=yefim]Just to let you know, guards are about. It is a restricted area afterall. Do take care, or use whatever wiles you have to get out of a situationn if you get into one.[/say]")
		
		saynn("You could only nod in awknowledgement. Guards are going to stand in your way obviously, it indeed is a restricted area. You should probably heed his warnings.")
		
		saynn("[say=pc]Alright, thanks for the heads up. I'll come back to you with news once I get it.[/say]")
		
		saynn("The fox cackles for a moment, giving you a sly smile.")
		
		saynn("[say=yefim]Take care {pc.name}.[/say]")
		
		addButton("Continue", "Go off on your own.", "endthescene")
		
		setFlag("YefimExpansionModule.Quest1Accept", true)
		setFlag("YefimExpansionModule.DispositionAppleQ", true)

		


	if(state == "refuse"):
		saynn("[say=pc]No, I'll pass.[/say]")
		
		saynn("His face seemed to scrunch a little, but he sighed, crossing his arms.")
		
		saynn("[say=yefim]Well, I'm not too surprised. If you reconsider {pc.name}, I'll be here on occasion, and if you get me an apple from the Greenhouse still, I'll take it as confirmation.[/say]")
		
		saynn("You could only nod as you walk away from the fox, who returned to leaning on the wall, as you move on with your day.")
		
		addButton("Continue", "Leave", "endthescene")
		
		setFlag("YefimExpansionModule.Quest2Accept", true)
		setFlag("YefimExpansionModule.DispositionAppleQ", false)

func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return

	setState(_action)
