extends Character

func _init():
	id = "yefim"
	
	npcLevel = 10
	npcBasePain = 130
	npcBaseLust = 400
	npcCharacterType = CharacterType.Inmate
	
	pickedSkin="YefimSkin"
	pickedSkinRColor=Color("C6935E")
	pickedSkinGColor=Color("DDDAD5")
	pickedSkinBColor=Color("44353C")
	npcSkinData={
	"hair": {"r": Color("C6935E"),"g": Color("C6935E"),"b": Color("C6935E"),},
	"penis": {"r": Color("ed8989"),"g": Color("DDDAD5"),},
	"ears":{"r": Color("44353C"), "g": Color("DDDAD5"), "b":("DDDAD5"),}
	}
	
	
	npcLustInterests = {
		InterestTopic.TallyMarks: Interest.Hates,
		InterestTopic.Bodywritings: Interest.Dislikes,
		InterestTopic.Gags: Interest.Dislikes,
		InterestTopic.Blindfolds: Interest.Likes,
		InterestTopic.ButtPlugs: Interest.SlightlyDislikes,
		InterestTopic.VaginalPlugs: Interest.SlightlyDislikes,
		InterestTopic.FeminineBody: Interest.Loves,
		InterestTopic.AndroBody: Interest.KindaLikes,
		InterestTopic.MasculineBody: Interest.KindaLikes,
		InterestTopic.AverageMassBody: Interest.Likes,
		InterestTopic.SlimBody: Interest.ReallyLikes,
		InterestTopic.AverageButt: Interest.KindaLikes,
		InterestTopic.SlimButt: Interest.Likes,
		InterestTopic.NoBreasts: Interest.Loves,
		InterestTopic.SmallBreasts: Interest.ReallyLikes,
		InterestTopic.MediumBreasts: Interest.Likes,
		InterestTopic.BigBreasts: Interest.Dislikes,
		InterestTopic.LactatingBreasts: Interest.Dislikes,
		InterestTopic.StuffedPussy: Interest.SlightlyDislikes,
		InterestTopic.StuffedAss: Interest.KindaLikes,
		InterestTopic.StuffedPussyOrAss: Interest.SlightlyDislikes,
		InterestTopic.Pregnant: Interest.KindaLikes,
		InterestTopic.StuffedThroat: Interest.SlightlyDislikes,
		InterestTopic.CoveredInCum: Interest.Dislikes,
		InterestTopic.FullyNaked: Interest.SlightlyDislikes,
		InterestTopic.ExposedPussy: Interest.SlightlyDislikes,
		InterestTopic.ExposedAnus: Interest.SlightlyDislikes,
		InterestTopic.ExposedBreasts: Interest.SlightlyDislikes,
		InterestTopic.ExposedCock: Interest.SlightlyDislikes,
		InterestTopic.ExposedPanties: Interest.KindaLikes,
		InterestTopic.ExposedBra: Interest.KindaLikes,
		InterestTopic.LooseAnus: Interest.Dislikes,
		InterestTopic.LoosePussy: Interest.Dislikes,
		InterestTopic.TightAnus: Interest.Likes,
		InterestTopic.TightPussy: Interest.Likes,
		InterestTopic.HasVaginaAndCock: Interest.ReallyDislikes,
		InterestTopic.BigCock: Interest.SlightlyDislikes,
		InterestTopic.SmallCock: Interest.Likes,
	}
	npcFetishes = {
	Fetish.AnalSexGiving: FetishInterest.ReallyLikes,
	Fetish.AnalSexReceiving: FetishInterest.ReallyLikes,
	Fetish.BeingBred: FetishInterest.Hates,
	Fetish.Bodywritings: FetishInterest.Neutral,
	Fetish.Bondage: FetishInterest.SlightlyLikes,
	Fetish.Breeding: FetishInterest.ReallyLikes,
	Fetish.Choking: FetishInterest.ReallyLikes,
	Fetish.Condoms: FetishInterest.Neutral,
	Fetish.DrugUse: FetishInterest.Neutral,
	Fetish.Exhibitionism: FetishInterest.Dislikes,
	Fetish.FeetplayGiving: FetishInterest.Hates,
	Fetish.FeetplayReceiving: FetishInterest.Hates,
	Fetish.Lactation: FetishInterest.Hates,
	Fetish.OralSexGiving: FetishInterest.SlightlyLikes,
	Fetish.OralSexReceiving: FetishInterest.ReallyLikes,
	Fetish.Rigging: FetishInterest.SlightlyLikes,
	Fetish.RimmingGiving: FetishInterest.Hates,
	Fetish.RimmingReceiving: FetishInterest.Hates,
	Fetish.Sadism: FetishInterest.ReallyLikes,
	Fetish.SeedMilking: FetishInterest.Neutral,
	Fetish.UnconsciousSex: FetishInterest.ReallyLikes,
	Fetish.VaginalSexGiving: FetishInterest.ReallyLikes,
	Fetish.HypnosisHypnotist: FetishInterest.ReallyLikes,
	Fetish.HypnosisSubject: FetishInterest.Hates,
}
	npcHasMenstrualCycle = false
	
func _getName():
	return "Yefim"

func getGender():
	return Gender.Female
	
func getSmallDescription() -> String:
	return "Red block inmate. A very tall vixen with a lanky build, and has an eyepatch."

func getSpecies():
	return ["canine"]

func _getAttacks():
	return [""] # put regular attacks here

func getFightIntro(_battleName):
	return getName() + " gets into an awkward combat stance and prepares for a fight. "+formatSay("Fuck off would you?")

func getThickness() -> int:	
	return 40

func getFemininity() -> int:
	return 20

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("foxhead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("SongHair1"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("felineears2"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthroarms"))
	var penis = GlobalRegistry.createBodypart("caninepenis")
	penis.lengthCM = 18
	penis.ballsScale = 0.8
	giveBodypartUnlessSame(penis)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("digilegs"))
	var tail = GlobalRegistry.createBodypart("foxtail")
	tail.tailScale = 0.5
	giveBodypartUnlessSame(tail)

func getLootTable(_battleName):
	return InmateLoot.new()

func getDefaultEquipment():
	return ["inmatecollar", "inmateuniformHighsec"]
