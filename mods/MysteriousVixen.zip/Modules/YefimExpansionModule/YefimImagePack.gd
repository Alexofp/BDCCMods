extends ImagePack

func _init():
	id = "yefim"
	artist = "syn924"

	addCharacter(
		"yefim",
		[],
		"res://Modules/YefimExpansionModule/YefimImagePack/YefimPortrait.png"
	)
