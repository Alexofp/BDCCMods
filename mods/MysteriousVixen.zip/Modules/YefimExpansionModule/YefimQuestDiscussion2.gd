extends SceneBase

func _init():
	sceneID = "YefimQuestDiscussion2"

func _run():
	if state == "":
		addCharacter("yefim")
		playAnimation(StageScene.Duo, "stand", {npc="yefim"})


		saynn("You decide to approach the fox leaning against the wall in his usual spot. He makes eyecontact with you. Clearly you set off on the wrong foot.")
		
		saynn("[say=yefim]Got my apple, or what?[/say]")
		
		addButton("Nope", "No apple just yet", "Nope")
		addButton("Leave", "Get away from the shady fox.", "endthescene")

		if(GM.pc.getInventory().hasItemID("appleitem")):
			addButton("Yup!", "Give him the Apple", "Complete")
		
		
	if(state == "Nope"):
		saynn("[say=pc]Nah, I haven't gotten it yet.[/say]")

		saynn("A sneer from the old fox, He doesn't seem interested in replying to you at all..")

		saynn("[say=yefim]Well, alright.[/say]")
		addButton("Leave", "Leave him be.", "endthescene")
		
	if(state == "Complete"):
		saynn("[say=pc]Here it is.[/say]")
		
		saynn("His face seemed to soften, but not by a whole lot..")
		
		saynn("[say=yefim]Well, I'm not too surprised....[/say]")
		
		saynn("He would take a bite of of the apple, a rather loud crunch as he bit off almost half of the apple in a single bite, all while maintaining eyecontact with you. It was as if he was staring down your soul down during the bit, chills rising from your spine.")
		
		saynn("[say=yefim]Good enough.[/say]")
		
		saynn("[say=pc]So, do I get the gracious knowledge of who you are, and the actual job you pro-[/say]")
		
		saynn("Before you could finish, he placed a hand on your face, rather roughly  pressing your lips together to silence you. ")
		
		saynn("[say=yefim]Near the Pond in the yard at 20:00.. I'll be there up until 21:00. If you're a no show, I'll be there at another time.[/say]")
		
		saynn("Before you could say anything else, the fox lets go of your face, as he walks off towards the cellblocks. Something tells you that trying to follow him is a very bad idea. And that he really doesn't like you.")
		
		
		addButton("Continue", "Leave", "endthescene")
		GM.pc.getInventory().removeXOfOrDestroy("appleitem", 1)
		setFlag("YefimExpansionModule.AppleQuestComp", true)
		setFlag("YefimExpansionModule.DispositionAppleQ", false)
	

func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return

	setState(_action)
