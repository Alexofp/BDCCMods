extends Module

func _init():
	id = "YefimExpansionModule"
	author = "syn924"

	characters = [
		"res://Modules/YefimExpansionModule/Yefim.gd"
	]

	scenes = [
		"res://Modules/YefimExpansionModule/YefimFirstEncounter.gd",
		"res://Modules/YefimExpansionModule/YefimReturnEncounter.gd",
		"res://Modules/YefimExpansionModule/YefimQuestDiscussion.gd",
		"res://Modules/YefimExpansionModule/YefimReturnNoList.gd",
		"res://Modules/YefimExpansionModule/YefimQuestDiscussion2.gd",
	]

	events = [
		"res://Modules/YefimExpansionModule/YefimEncounterStart.gd"
	]


func getFlags():
	return {
		"FirstEncounterHappened": flag(FlagType.Bool),
		"FirstEncounterResult2": flag(FlagType.Bool), # polite refusal
		"ReturnNoList": flag(FlagType.Bool),  #Rudely refuse bro
		"DispositionAppleQ": flag(FlagType.Bool),  # Apple Quest Disp
		"Encounter1Trust": flag(FlagType.Bool), #Apple Quest trust
		"Quest1Accept": flag(FlagType.Bool),  # Apple Quest
		"Quest2Accept": flag(FlagType.Bool), # Apple Quest Refusal
		"Quest3Accept": flag(FlagType.Bool), # Irritated Apple Quest
		"AppleQuestComp": flag(FlagType.Bool), #Quest Completion
		"CH1Comp": flag(FlagType.Bool), #ch1 complete
		
		
	}


func register():
	.register()
	GlobalRegistry.registerImagePack("res://Modules/YefimExpansionModule/YefimImagePack.gd")
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)
	GlobalRegistry.registerSkin("res://Modules/YefimExpansionModule/YefimSkin/YefimSkin.gd","syn924")
