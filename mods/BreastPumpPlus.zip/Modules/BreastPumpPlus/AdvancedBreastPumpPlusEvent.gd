extends EventBase

func _init():
	id = "AdvancedBreastPumpPlusEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)
	es.addTrigger(self, Trigger.WakeUpInCell)
	es.addTrigger(self, Trigger.TakingAShower)

func react(_triggerID, _args):
	if GlobalRegistry.modules.has("BreastPumpPlus"):
		var mod = GlobalRegistry.modules["BreastPumpPlus"]
		if mod.has_method("getEnableAutoMilking") and not mod.getEnableAutoMilking():
			return false
	
	var currentTime = GM.main.getTimeInGlobalSeconds()
	var lastTimeMilked = getFlag("BreastPumpPlus.AdvBreastPumpPlusLastMilked", 0)
	
	if(currentTime >= (lastTimeMilked + 60*30) || _triggerID == Trigger.WakeUpInCell):
		setFlag("BreastPumpPlus.AdvBreastPumpPlusLastMilked", currentTime)
	else:
		return false
	
	if(!GM.pc.getInventory().hasItemIDEquipped("BreastPumpPlus")):
		return false
	
	var breastPump = GM.pc.getInventory().getEquippedItemByID("BreastPumpPlus")
	if(breastPump == null):
		return false
	
	var freeSpace = breastPump.getFluids().getCapacity() - breastPump.getFluids().getFluidAmount()
	if(freeSpace <= 0.0):
		return false
		
	var maxMilk = 10000.0
	if(_triggerID == Trigger.WakeUpInCell):
		maxMilk = 50000.0
	if(_triggerID == Trigger.Waiting && _args.size() > 0):
		maxMilk = min(10000.0 * _args[0], 50000.0)
		
	maxMilk = min(maxMilk, freeSpace)
	
	var lactation = GM.pc.getBodypart(BodypartSlot.Breasts).getFluidProduction()
	if(lactation == null):
		return false
	
	if(lactation is Lactation && lactation.getFluidLevelForOptimalSize() < 0.9 && GM.pc.canBeMilked()):
		return false
	
	var beganLactating = GM.pc.stimulateLactation()
	
	if (GM.pc.canBeMilked()):
		GM.pc.addSkillExperience(Skill.Milking, 10)
		var howMuchTransferred = GM.pc.getBodypart(BodypartSlot.Breasts).getFluids().transferAmountTo(breastPump, maxMilk)
		if(howMuchTransferred > 0.0):
			GM.main.addMessage("Your breast pumps engage, milking your breasts for "+str(Util.roundF(howMuchTransferred))+" ml")
			
			if(breastPump.getFluids().isFull()):
				GM.main.addMessage("Your breast pumps are now full!")
	else:
		if(beganLactating):
			GM.main.addMessage("Your breast pumps engage, stimulating your breasts for a few minutes until you suddenly [b]begin lactating[/b]!")
		else:
			GM.main.addMessage("Your breast pumps engage, stimulating your breasts for a few minutes but not getting any milk.")
	return false
	
func getPriority():
	return 20
