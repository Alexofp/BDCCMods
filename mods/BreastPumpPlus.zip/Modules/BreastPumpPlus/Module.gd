extends Module

var pumpCapacity = 100000.0
var requireResearch = true
var enableAutoMilking = true

func getFlags():
	return {
		"AdvBreastPumpPlusLastMilked": flag(FlagType.Number),
	}

func _init():
	id = "BreastPumpPlus"
	author = "interlamer"
	
	items = [
		"res://Modules/BreastPumpPlus/BreastPumpPlus.gd",
	]
	events = [
		"res://Modules/BreastPumpPlus/AdvancedBreastPumpPlusEvent.gd",
	]
func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addNumberOption(
		"pumpCapacity",
		"Breast Pump Mk3 Capacity (mL)",
		"How much milk should the Breast Pump Mk3 hold? Default: 100,000 mL. WARNING: Changes will only appear after reloading the game!",
		100000.0
	)
	
	foxModuleAPI.addBooleanOption(
		"requireResearch",
		"Require research to unlock?",
		"If enabled, the Mk3 pump appears in the Medical Vendomat after the same research as the Mk2 pump. Disable this if you want it available immediately.",
		true
	)
	
	foxModuleAPI.addBooleanOption(
		"enableAutoMilking",
		"Enable automatic milking",
		"When enabled, the Mk3 will automatically milk you roughly every 30 minutes (same behaviour as the vanilla Mk2).",
		true
	)
	
func getPumpCapacity() -> float:
	if GlobalRegistry.modules.has("FoxLib"):
		var FoxOptionsManager = load("res://Modules/FoxLib/Internal/FoxOptionsManager.gd")
		if FoxOptionsManager != null:
			return float(FoxOptionsManager.getOption("BreastPumpPlus", "pumpCapacity", pumpCapacity))
			
	return pumpCapacity
	
func getRequireResearch() -> bool:
	if GlobalRegistry.modules.has("FoxLib"):
		var FoxOptionsManager = load("res://Modules/FoxLib/Internal/FoxOptionsManager.gd")
		if FoxOptionsManager != null:
			return FoxOptionsManager.getOption("BreastPumpPlus", "requireResearch", requireResearch) == true
			
	return requireResearch
	
func getEnableAutoMilking() -> bool:
	if GlobalRegistry.modules.has("FoxLib"):
		var FoxOptionsManager = load("res://Modules/FoxLib/Internal/FoxOptionsManager.gd")
		if FoxOptionsManager != null:
			return FoxOptionsManager.getOption("BreastPumpPlus", "enableAutoMilking", enableAutoMilking) == true
	return enableAutoMilking
