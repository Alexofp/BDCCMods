extends "res://Inventory/Items/BreastPumpAdvanced.gd"

func _init():
	id = "BreastPumpPlus"

func getVisibleName():
	return "Breast Pump Mk3"

func getDescription():
	return "A tool that can extract milk out of lactating breasts. This is an upgraded version with a much larger reservoir.\nIf put on during sex it extracts "+str(getMilkSpeedPerMinuteMin())+"-"+str(getMilkSpeedPerMinuteMax())+" of milk per minute."

func getPrice():
	return 100

func getTags():
	var tags = [ItemTag.BreastPump]
	
	var needsResearch = true
	if GlobalRegistry.modules.has("BreastPumpPlus"):
		var mod = GlobalRegistry.modules["BreastPumpPlus"]
		if mod.has_method("getRequireResearch"):
			needsResearch = mod.getRequireResearch()
			
	if needsResearch:
		if GM.main != null && GM.main.SCI != null && GM.main.SCI.hasUpgrade("advBreastPump"):
			tags.append(ItemTag.SoldByMedicalVendomat)
	else:
		tags.append(ItemTag.SoldByMedicalVendomat)
	return tags

func generateFluids():
	.generateFluids()
	var capacity = 100000.0
	
	if GlobalRegistry.modules.has("BreastPumpPlus"):
		var mod = GlobalRegistry.modules["BreastPumpPlus"]
		if mod.has_method("getPumpCapacity"):
			capacity = mod.getPumpCapacity()

	fluids.setCapacity(capacity)
