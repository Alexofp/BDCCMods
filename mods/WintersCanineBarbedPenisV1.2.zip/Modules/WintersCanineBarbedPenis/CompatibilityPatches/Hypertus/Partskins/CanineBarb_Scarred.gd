extends PartSkinBase

func _init():
	id = "caninebarbscarredhyperable"
	partID = "caninepenisbarbhyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Scarred.png"),
	}
	
