extends PartSkinBase

func _init():
	id = "caninebarbcockhighlighthyperable"
	partID = "caninepenisbarbhyperable"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Cockhighlight.png"),
	}
	
