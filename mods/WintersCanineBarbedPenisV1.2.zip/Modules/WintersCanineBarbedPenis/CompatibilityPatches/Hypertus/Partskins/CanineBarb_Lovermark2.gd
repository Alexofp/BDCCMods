extends PartSkinBase

func _init():
	id = "caninebarblovermark2hyperable"
	partID = "caninepenisbarbhyperable"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Lovermark2.png"),
	}
	
