extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable Barbed canine penis"
	id = "caninepenisbarbhyperable"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0
	else:
		return 1

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine", "barbed",])

func getDoll3DScene():
	return "res://Modules/WintersCanineBarbedPenis/Penis/CaninePenisBarb.tscn"
	
func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
		"Hyperable": true,
	}

func generateRandomColors(_dynamicCharacter):
	pass
