extends PartSkinBase

func _init():
	id = "caninebarbtribal"
	partID = "caninepenisbarb"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Tribal.png"),
	}
	
