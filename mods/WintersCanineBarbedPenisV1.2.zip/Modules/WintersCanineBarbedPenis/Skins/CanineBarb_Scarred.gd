extends PartSkinBase

func _init():
	id = "caninebarbscarred"
	partID = "caninepenisbarb"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Scarred.png"),
	}
	
