extends PartSkinBase

func _init():
	id = "caninebarbcockhighlight"
	partID = "caninepenisbarb"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Cockhighlight.png"),
	}
	
