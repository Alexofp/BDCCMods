extends Module

#This assigns true or false depending on wether Balls Extra is loaded so we can refer to it when loading bodyparts below.
var BallsExtraLoad = ResourceLoader.exists("res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd")

func _init():
	id = "WintersCanineBarbed"
	author = "Avery Winters"
	
	#If the Balls Extra mod is loaded this should load the compatible .gd files to extend the modified penis bodypart allowing ball density changes
	if (BallsExtraLoad == true):
		bodyparts = [
		#Start Canine Barbed BE compatible Files
		"res://Modules/WintersCanineBarbedPenis/CompatibilityPatches/BallsExtra/CaninePenisBarbBE.gd",
	]
	
	#If the Balls Extra mod is loaded this should load the regular .gd files
	elif (BallsExtraLoad == false):
		bodyparts = [
		#Start Canine Barbed Files
		"res://Modules/WintersCanineBarbedPenis/CaninePenisBarb.gd",
	]

	partSkins = [
		#Start Canine Barbed Files
		"res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Cockhighlight.gd",
		"res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Lovermark2.gd",
		"res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Piercing.gd",
		"res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Scarred.gd",
		"res://Modules/WintersCanineBarbedPenis/Skins/CanineBarb_Tribal.gd",
	]
