extends BodypartLeg

func _init():
	visibleName = "Fluffy small hoofs"
	id = "fluffhoofssmall"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofsSmall/FluffyHoofsSmall.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
