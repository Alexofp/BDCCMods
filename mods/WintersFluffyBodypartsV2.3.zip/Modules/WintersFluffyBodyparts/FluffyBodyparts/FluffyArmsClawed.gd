extends BodypartArms

func _init():
	visibleName = "Fluffy clawed arms"
	id = "fluffclawedarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyArmsClawed/FluffyArmsClawed.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
