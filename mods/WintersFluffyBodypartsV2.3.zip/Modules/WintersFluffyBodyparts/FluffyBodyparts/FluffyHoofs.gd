extends BodypartLeg

func _init():
	visibleName = "Fluffy hoofs"
	id = "fluffhoofs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyHoofs/FluffyHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
