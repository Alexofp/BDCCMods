extends BodypartLeg

func _init():
	visibleName = "Fluffy clawed legs"
	id = "flufflegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyDigiLegsClawed/FluffyDigiLegsClawed.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
