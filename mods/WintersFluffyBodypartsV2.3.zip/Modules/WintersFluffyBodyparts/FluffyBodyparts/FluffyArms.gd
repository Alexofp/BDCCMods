extends BodypartArms

func _init():
	visibleName = "Fluffy clawless arms"
	id = "fluffarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyArms/FluffyArms.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
