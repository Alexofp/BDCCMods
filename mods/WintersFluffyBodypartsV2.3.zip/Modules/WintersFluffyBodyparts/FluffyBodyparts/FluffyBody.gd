extends BodypartBody

func _init():
	visibleName = "Fluffy body"
	id = "fluffbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBodyparts/FluffyBody/FluffyBody.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
