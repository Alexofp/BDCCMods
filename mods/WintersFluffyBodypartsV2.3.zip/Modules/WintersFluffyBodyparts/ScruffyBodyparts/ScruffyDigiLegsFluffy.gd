extends BodypartLeg

func _init():
	visibleName = "Scruffy clawed legs with extra fluff"
	id = "scrufflegsfluffy"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigiLegsFluffy/ScruffyDigiLegsFluffy.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
