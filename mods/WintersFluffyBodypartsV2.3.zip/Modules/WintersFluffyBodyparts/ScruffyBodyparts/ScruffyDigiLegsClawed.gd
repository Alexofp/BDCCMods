extends BodypartLeg

func _init():
	visibleName = "Scruffy clawed legs"
	id = "scrufflegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigilegsClawed/ScruffyDigilegsClawed.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
