extends BodypartLeg

func _init():
	visibleName = "Scruffy clawless legs"
	id = "scrufflegsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyDigiLegs/ScruffyDigiLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
