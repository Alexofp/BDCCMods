extends BodypartLeg

func _init():
	visibleName = "Scruffy hoofs"
	id = "scruffhoofs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyHoofs/ScruffyHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
