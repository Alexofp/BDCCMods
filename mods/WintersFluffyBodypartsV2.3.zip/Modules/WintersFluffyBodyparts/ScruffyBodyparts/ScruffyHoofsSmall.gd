extends BodypartLeg

func _init():
	visibleName = "Scruffy small hoofs"
	id = "scruffhoofssmall"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyHoofsSmall/ScruffyHoofsSmall.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
