extends BodypartBody

func _init():
	visibleName = "Scruffy body"
	id = "scruffbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyBody/ScruffyBody.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
