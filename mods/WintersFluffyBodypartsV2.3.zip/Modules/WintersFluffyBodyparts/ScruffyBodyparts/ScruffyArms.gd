extends BodypartArms

func _init():
	visibleName = "Scruffy clawless arms"
	id = "scruffarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScruffyBodyparts/ScruffyArms/ScruffyArms.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
