extends BodypartLeg

func _init():
	visibleName = "Scaled clawless legs"
	id = "scaledlegsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledLegsClawless/ScaledLegsClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
