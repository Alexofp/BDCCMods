extends BodypartBody

func _init():
	visibleName = "Scaled body"
	id = "scaledbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBody/ScaledBody.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
