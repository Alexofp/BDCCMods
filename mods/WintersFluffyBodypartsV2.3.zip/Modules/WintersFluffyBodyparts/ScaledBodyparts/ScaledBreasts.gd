extends BodypartBreasts

func _init():
	visibleName = "Scaled breasts"
	id = "scaledbreasts"
	size = BreastsSize.C


func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBreasts/ScaledBreastsFlat.tscn"
	return "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBreasts/ScaledBreasts.tscn"


func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
