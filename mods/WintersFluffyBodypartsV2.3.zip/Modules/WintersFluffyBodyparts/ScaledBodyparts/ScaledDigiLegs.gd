extends BodypartLeg

func _init():
	visibleName = "Scaled clawed legs"
	id = "scaledlegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledLegs/ScaledLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
