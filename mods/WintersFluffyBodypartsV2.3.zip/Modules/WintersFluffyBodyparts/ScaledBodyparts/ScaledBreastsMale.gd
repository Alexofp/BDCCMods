extends "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledBreasts.gd"

func _init():
	visibleName = "Scaled flat chest"
	id = "scaledmalebreasts"
	size = BreastsSize.FOREVER_FLAT

func getLewdAdjective():
	return RNG.pick(["firm", "strong", "scaled", "scaley"])

func getLewdName():
	if(size <= BreastsSize.A):
		return "fluffy pecs"

	return RNG.pick(["manbreasts", "manboobs", "mantits", "jugs", "orbs"])

func safeWhenExposed():
	if(size <= BreastsSize.A):
		return true
	
	return false

func generateDataFor(_dynamicCharacter):
	pass

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
