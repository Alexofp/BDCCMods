extends BodypartArms

func _init():
	visibleName = "Scaled clawed arms"
	id = "scaledarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/ScaledBodyparts/ScaledArms/ScaledArms.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
