extends BodypartLeg

func _init():
	visibleName = "Buff fluffy small hoofs"
	id = "bufffluffhoofssmall"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffySmallHoofs/BuffFluffySmallHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
