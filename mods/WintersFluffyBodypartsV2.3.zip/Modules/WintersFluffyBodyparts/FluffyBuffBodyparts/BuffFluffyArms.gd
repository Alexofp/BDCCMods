extends BodypartArms

func _init():
	visibleName = "Buff fluffy clawless arms"
	id = "bufffluffarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyArms/BuffFluffyArms.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
