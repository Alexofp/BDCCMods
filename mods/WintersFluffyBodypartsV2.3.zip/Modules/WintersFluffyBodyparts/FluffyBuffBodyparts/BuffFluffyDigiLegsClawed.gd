extends BodypartLeg

func _init():
	visibleName = "Buff fluffy clawed legs"
	id = "buffflufflegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyDigiLegsClawed/BuffFluffyDigiLegsClawed.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
