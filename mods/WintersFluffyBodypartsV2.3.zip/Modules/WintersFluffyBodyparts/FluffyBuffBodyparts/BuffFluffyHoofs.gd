extends BodypartLeg

func _init():
	visibleName = "Buff fluffy hoofs"
	id = "bufffluffhoofs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyHoofs/BuffFluffyHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
