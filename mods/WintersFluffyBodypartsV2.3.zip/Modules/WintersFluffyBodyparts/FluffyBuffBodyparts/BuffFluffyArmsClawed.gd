extends BodypartArms

func _init():
	visibleName = "Buff fluffy clawed arms"
	id = "bufffluffclawedarms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersFluffyBodyparts/FluffyBuffBodyparts/BuffFluffyArmsClawed/BuffFluffyArmsClawed.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
