extends "res://Species/Feline.gd"

const FoxGlobals = preload("res://FoxLib/Globals.gd")

func getDefaultBody(_gender):
	var FluffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyFeline
	var ScruffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyFeline
	if (FluffyFeline == true):
		if (ScruffyFeline == true):
			return "scruffbody"
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	var FluffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyFeline
	var ScruffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyFeline
	if (FluffyFeline == true):
		if (ScruffyFeline == true):
			return "scrufflegsclawless"
		return "flufflegsclawless"
	return "digilegs"

func getDefaultArms(_gender):
	var FluffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyFeline
	var ScruffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyFeline
	if (FluffyFeline == true):
		if (ScruffyFeline == true):
			return "scruffclawedarms"
		return "fluffclawedarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	var FluffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyFeline
	var ScruffyFeline = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyFeline
	if (FluffyFeline == true):
		if (ScruffyFeline == true):
			if(_gender in [Gender.Male]):
				return "fluffmalebreasts"
			return "fluffbreasts"
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"

	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
