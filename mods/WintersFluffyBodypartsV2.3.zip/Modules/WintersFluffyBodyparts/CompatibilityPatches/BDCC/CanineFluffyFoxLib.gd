extends "res://Species/Canine.gd"

const FoxGlobals = preload("res://FoxLib/Globals.gd")

func getDefaultBody(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			return "scruffbody"
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			return "scrufflegs"
		return "flufflegs"
	return "digilegs"

func getDefaultArms(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			return "scruffarms"
		return "fluffarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	var FluffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigFluffyCanine
	var ScruffyCanine = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScruffyCanine
	if (FluffyCanine == true):
		if (ScruffyCanine == true):
			if(_gender in [Gender.Male]):
				return "fluffmalebreasts"
			return "fluffbreasts"
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"

	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
