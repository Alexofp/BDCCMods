extends "res://Species/Equine.gd"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffhoofs"
	return "hoofs"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
