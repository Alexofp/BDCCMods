extends "res://Species/Dragon.gd"

const FoxGlobals = preload("res://FoxLib/Globals.gd")

func getDefaultBody(_gender):
	var ScaleyDragon = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScaleyDragon
	if (ScaleyDragon == true):
		return "scaledbody"
	return "anthrobody"


func getDefaultLegs(_gender):
	var ScaleyDragon = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScaleyDragon
	if (ScaleyDragon == true):
		return "scaledlegs"
	return "digilegs"

func getDefaultArms(_gender):
	var ScaleyDragon = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScaleyDragon
	if (ScaleyDragon == true):
		return "scaledarms"
	return "anthroarms"
	
func getDefaultBreasts(_gender):
	var ScaleyDragon = FoxGlobals.ofModule("WintersFluffyBodyparts").ConfigScaleyDragon
	if (ScaleyDragon == true):
		if(_gender in [Gender.Male]):
			return "scaledmalebreasts"
		return "scaledbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("More Dragon Penis" in GlobalRegistry.getModules()):
			return RNG.pick(["dragonpenis", "DPB1", "DPB2", "DPB3"])
		return "dragonpenis"
	else:
		return null

func getDefaultVagina(_gender):
	if(_gender in [Gender.Female, Gender.Androgynous]):
		return "vaginaEggs"
	else:
		return null
