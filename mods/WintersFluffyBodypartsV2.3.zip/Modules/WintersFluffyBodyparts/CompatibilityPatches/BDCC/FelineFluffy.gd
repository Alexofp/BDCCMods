extends "res://Species/Feline.gd"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegsclawless"
	return "digilegs"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffclawedarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
