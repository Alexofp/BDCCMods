extends "res://Species/Dragon.gd"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "scaledbody"
	return "anthrobody"


func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "scaledlegs"
	return "digilegs"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "scaledarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "scaledmalebreasts"
		return "scaledbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("More Dragon Penis" in GlobalRegistry.getModules()):
			return RNG.pick(["dragonpenis", "DPB1", "DPB2", "DPB3"])
		return "dragonpenis"
	else:
		return null

func getDefaultVagina(_gender):
	if(_gender in [Gender.Female, Gender.Androgynous]):
		return "vaginaEggs"
	else:
		return null
