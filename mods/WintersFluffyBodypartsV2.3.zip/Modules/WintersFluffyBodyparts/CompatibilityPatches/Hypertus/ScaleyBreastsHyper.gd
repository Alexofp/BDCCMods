extends "res://Modules/Z_Hypertus/Misc/ModBodypartBreasts.gd"

func _init():
	visibleName = "hyperable scaley breasts"
	id = "scaledbreastshyperable"
	size = breastSizeModClass.G

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return breastSizeModClass.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= breastSizeModClass.FLAT):
		return "res://Modules/WintersFluffyBodyparts/SpeciesDragon/Bodyparts/DragonBreasts/DragonBreastsFlat.tscn"
	return "res://Modules/WintersFluffyBodyparts/SpeciesDragon/Bodyparts/DragonBreasts/DragonBreasts.tscn"

func getTraits():
	return {
		"Hyperable": true,
	}
