extends Reference

# Adds GunMod's two-handed rifle poses to the game at runtime, instead of
# shipping edited copies of Player/Player3D/Doll3D.tscn and
# Player/StageScene3D/Scenes/DollSoloAnimationTree.tres.
#
# Shipping whole copies of those two core files froze every doll for players
# on a newer BDCC build (upstream dev added a DollSkeletonCombat node that its
# own combat code needs; our older Doll3D.tscn copy replaced it). Doing it at
# runtime layers on top of whatever version the player has.
#
#  - The three clips live in Modules/GunMod/Animations/*.tres and get added to
#    every doll's $DollSkeleton/AnimationPlayer as it enters the scene tree
#    (SceneTree "node_added").
#  - The matching states + transitions get added once to the shared
#    DollSoloAnimationTree.tres resource (every AnimationTree using it shares
#    the same loaded object, which this class keeps referenced so it stays
#    cached).
#  - Playing them: see play() below. No core file is overridden at all.

const TreePath = "res://Player/StageScene3D/Scenes/DollSoloAnimationTree.tres"

const Clips = {
	"WeaponGunDualHold-loop": "res://Modules/GunMod/Animations/WeaponGunDualHold-loop.tres",
	"WeaponGunDualAim-loop": "res://Modules/GunMod/Animations/WeaponGunDualAim-loop.tres",
	"WeaponGunDualShoot": "res://Modules/GunMod/Animations/WeaponGunDualShoot.tres",
}

# Same graph positions the old edited .tres used (only matter in the editor)
const StatePositions = {
	"WeaponGunDualHold-loop": Vector2(-600.453, -142),
	"WeaponGunDualAim-loop": Vector2(-600.453, -209),
	"WeaponGunDualShoot": Vector2(-600.453, -272),
}

# [from, to, xfade_time, switch_mode, auto_advance] - copied from the old
# edited DollSoloAnimationTree.tres
const Transitions = [
	["WeaponGunDualHold-loop", "WeaponGunDualAim-loop", 0.4, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, false],
	["WeaponGunDualAim-loop", "WeaponGunDualHold-loop", 0.4, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, false],
	["WeaponGunDualAim-loop", "WeaponGunDualShoot", 0.4, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, false],
	["WeaponGunDualHold-loop", "Standing-loop", 0.5, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, false],
	["Standing-loop", "WeaponGunDualHold-loop", 0.5, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, false],
	["WeaponGunDualShoot", "WeaponGunDualHold-loop", 0.4, AnimationNodeStateMachineTransition.SWITCH_MODE_AT_END, true],
]

var clipResources = {}
var treeResource

func install(tree:SceneTree):
	for clipName in Clips:
		clipResources[clipName] = load(Clips[clipName])
	patchStateMachine()
	var _ok = tree.connect("node_added", self, "onNodeAdded")

func patchStateMachine():
	treeResource = load(TreePath)
	if(treeResource == null || !(treeResource is AnimationNodeStateMachine)):
		Log.printerr("GunMod: couldn't load "+TreePath+", rifle poses won't play")
		return
	for clipName in Clips:
		if(treeResource.has_node(clipName)):
			continue
		var animNode = AnimationNodeAnimation.new()
		animNode.animation = clipName
		treeResource.add_node(clipName, animNode, StatePositions[clipName])
	for tr in Transitions:
		if(!treeResource.has_node(tr[0]) || !treeResource.has_node(tr[1])):
			continue
		if(treeResource.has_transition(tr[0], tr[1])):
			continue
		var transition = AnimationNodeStateMachineTransition.new()
		transition.xfade_time = tr[2]
		transition.switch_mode = tr[3]
		transition.auto_advance = tr[4]
		treeResource.add_transition(tr[0], tr[1], transition)

# --- Playing the rifle poses -------------------------------------------------
# The base game's stage script (BaseStageScene3D.gd) doesn't know the
# "holdrifle"/"aimrifle"/"firerifle" IDs, and a mod can't override it in the
# exported game (it has a class_name, so it's compiled at startup before the
# launcher loads any mod - verified in the official 0.3.2 exe). So GunMod plays
# these poses itself: it asks the stage for a plain "stand" first, then moves
# that doll's state machine into the rifle state and puts the model in its hand.
# Use GunModStage.play() (or FightScene, which BRATSFightScene routes here).

const RifleStates = {
	"holdrifle": "WeaponGunDualHold-loop",
	"aimrifle": "WeaponGunDualAim-loop",
	"firerifle": "WeaponGunDualShoot",
}
const DefaultRifleModel = "res://Modules/GunMod/Models/ServiceRifle.tscn"

func isRifleAction(action) -> bool:
	var actionID = action
	if(action is Array):
		if(action.empty()):
			return false
		actionID = action[0]
	return (actionID is String) && RifleStates.has(actionID)

func hasRifleAction(actionID, args:Dictionary) -> bool:
	return isRifleAction(actionID) || (args.has("npcAction") && isRifleAction(args["npcAction"]))

func play(sceneID, actionID, args = {}):
	var pcRifle = null
	var npcRifle = null
	var newAction = actionID
	var newArgs = args.duplicate()
	if(isRifleAction(actionID)):
		pcRifle = actionID
		newAction = "stand"
	if(args.has("npcAction") && isRifleAction(args["npcAction"])):
		npcRifle = args["npcAction"]
		newArgs["npcAction"] = "stand"
	GM.main.playAnimation(sceneID, newAction, newArgs)
	if(pcRifle != null || npcRifle != null):
		applyRifles(sceneID, pcRifle, npcRifle, 0)

func applyRifles(sceneID, pcRifle, npcRifle, attempt:int):
	var stageScene = null
	if(GM.ui != null && GM.ui.getStage3d() != null):
		stageScene = GM.ui.getStage3d().currentScene
	if(stageScene == null || !is_instance_valid(stageScene) || stageScene.is_queued_for_deletion() || stageScene.id != sceneID):
		# The stage fades out before switching scenes, try again once it's in
		if(attempt < 4 && GM.main != null):
			var timer = GM.main.get_tree().create_timer(0.5)
			var _ok = timer.connect("timeout", self, "applyRifles", [sceneID, pcRifle, npcRifle, attempt + 1])
		return
	if(pcRifle != null && ("doll" in stageScene) && ("animationTree" in stageScene)):
		applyToDoll(stageScene.doll, stageScene.animationTree, pcRifle)
	if(npcRifle != null && ("doll2" in stageScene) && ("animationTree2" in stageScene)):
		applyToDoll(stageScene.doll2, stageScene.animationTree2, npcRifle)

func applyToDoll(doll, animTree, action):
	var actionID = action
	var model = DefaultRifleModel
	if(action is Array):
		actionID = action[0]
		if(action.size() > 1):
			model = action[1]
	elif(GM.main != null && GM.main.isInSpecificPlayerSlavery("WarDraft") && doll.savedCharacterID == "pc"):
		model = GM.main.PS.getOwnFactionWeaponModelPath()
	var playback = findPlayback(animTree)
	if(playback != null):
		playback.travel(RifleStates[actionID])
	doll.attachTemporaryUnriggedPart("hand.L", model)
	doll.setTemporaryState("hands", "fists")

func findPlayback(animTree):
	if(animTree == null):
		return null
	for prop in animTree.get_property_list():
		if(str(prop.name).ends_with("/playback")):
			var playback = animTree.get(prop.name)
			if(playback != null):
				return playback
	return null

func onNodeAdded(node:Node):
	if(!(node is AnimationPlayer) || node.name != "AnimationPlayer"):
		return
	var parent = node.get_parent()
	if(parent == null || parent.name != "DollSkeleton"):
		return
	for clipName in clipResources:
		if(!node.has_animation(clipName)):
			var _err = node.add_animation(clipName, clipResources[clipName])
