extends Reference

# Drop-in for playAnimation()/GM.main.playAnimation() whenever the pc or npc
# action might be one of GunMod's rifle poses ("holdrifle"/"aimrifle"/
# "firerifle", optionally as [id, modelPath]). The base game's stage can't
# play those IDs itself - see GunModRifleAnims.gd.
#
#   const GunModStage = preload("res://Modules/GunMod/Animations/GunModStage.gd")
#   GunModStage.play(StageScene.Duo, "holdrifle", {npc=npcID, npcAction=["holdrifle", model]})

static func play(sceneID, actionID, args = {}):
	var gunMod = GlobalRegistry.getModule("GunMod")
	if(gunMod != null && gunMod.rifleAnims != null):
		gunMod.rifleAnims.play(sceneID, actionID, args)
	elif(GM.main != null):
		GM.main.playAnimation(sceneID, actionID, args)
