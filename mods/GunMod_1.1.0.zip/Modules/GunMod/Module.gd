extends Module

func getFlags():
	return {
		"LastSoapDropDay": flag(FlagType.Number),
	}

func _init():
	id = "GunMod"
	author = "Adria"

	characters = [
		"res://Modules/GunMod/WarDraft/Drask.gd",
		"res://Modules/GunMod/WarDraft/Vex.gd",
		"res://Modules/GunMod/WarDraft/TrainingDummy.gd",
	]

	scenes = [
		"res://Modules/GunMod/WarDraft/WarDraftStart.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDraskTalkScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftVexTalkScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftFinalPushScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftPatrolEncounterScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftCapturedScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftSyndicateOfferScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftPrisonScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftRescueObjectiveScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftBombObjectiveScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftAmbushScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftCapturedSoldierScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftKidlatCameoScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDetentionFightScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDetentionEscapeScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftStocksPunishmentScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftSoapDropScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDishonorableDischargeScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDraskMoraleCommentScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftVexCorruptionCommentScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDefeatedSoldierScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftRescuedByAlliesScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftFiringSquadScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftSyndicateFinalPushScene.gd",
	]

	events = [
		"res://Modules/GunMod/WarDraft/WarDraftPatrolEvent.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDetentionEvent.gd",
		"res://Modules/GunMod/WarDraft/WarDraftBlockCellEventsEvent.gd",
	]

	items = [
		"res://Modules/GunMod/Items/Pistol.gd",
		"res://Modules/GunMod/Items/LaserPistol.gd",
		"res://Modules/GunMod/Items/ServiceRifle.gd",
		"res://Modules/GunMod/Items/EnergyRifle.gd",
		"res://Modules/GunMod/Items/MarauderRifle.gd",
		"res://Modules/GunMod/Items/ConscriptArmor.gd",
		"res://Modules/GunMod/Items/ConscriptHelmet.gd",
	]

	attacks = [
		"res://Modules/GunMod/Attacks/PistolModFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/PistolModLaserPreciseShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/PistolModLaserRapidFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModServiceRifleAimedShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModServiceRifleBurstFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModEnergyRifleFocusedShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModEnergyRifleSuppressingFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModMarauderRifleAimedShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModMarauderRifleSprayFirePCAttack.gd",
	]

	lootTables = [
		"res://Modules/GunMod/WarDraft/Loot/WarDraftSoldierLoot.gd",
	]

	lootLists = [
		"res://Modules/GunMod/LootLists/PistolModWeaponsList.gd",
	]

	# B.R.A.T.S. (Ballistic Reflex-Assisted Targeting System) - called shots in
	# every fight. See Modules/GunMod/BRATS/BRATS.gd for the rules and
	# BRATSFightScene.gd for how it hooks FightScene without copying it.
	scenes.append("res://Modules/GunMod/BRATS/BRATSFightScene.gd")
	attacks.append_array([
		"res://Modules/GunMod/BRATS/Attacks/GunModBRATSCalledShot.gd",
		"res://Modules/GunMod/BRATS/Attacks/GunModBRATSEnemyCalledShot.gd",
		"res://Modules/GunMod/WarDraft/GunModDummyIdle.gd",
	])
	statusEffects = [
		"res://Modules/GunMod/BRATS/StatusEffects/GunModCrippledArm.gd",
		"res://Modules/GunMod/BRATS/StatusEffects/GunModCrippledLeg.gd",
		"res://Modules/GunMod/BRATS/StatusEffects/GunModTenderChest.gd",
		"res://Modules/GunMod/BRATS/StatusEffects/GunModCalledShotDamageMod.gd",
	]
	skills = [
		"res://Modules/GunMod/BRATS/Skills/GunModPrecisionSkill.gd",
	]
	perks = [
		"res://Modules/GunMod/BRATS/Perks/GunModPerkBRATS.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkSteadyHands.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkKneecapper.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkButterfingers.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkCheapShot.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkHeartbreaker.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkBullseye.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkEconomyOfMotion.gd",
		"res://Modules/GunMod/BRATS/Perks/GunModPerkCalledIt.gd",
	]

	# Acquisition, all additive - no overrides needed:
	#  - All seven items are tagged ItemTag.SoldByMirri, and MirriBuySellScene
	#    (Modules/SlaveAuctionModule/Mirri/MirriBuySellScene.gd) scans all
	#    registered items for that tag automatically. All three rifles also
	#    drop from the Drug Den's junkieWeaponsLocker/junkieStash loot tables
	#    now (5%/6%/1% locker, 1%/2%/- stash for service/marauder/laser rifle
	#    respectively) - kept off the common guard/junkie combat drop pools
	#    though, unlike the pistol, so they stay rarer than a random mugging.
	#  - PistolModWeaponsList (lootLists above) registers itself under the
	#    existing "guard"/"junkie" pawn-loot ids (Inventory/LootTable/GuardLoot.gd,
	#    JunkieLoot.gd) and the Drug Den's own "junkieWeaponsLocker"/"junkieStash"
	#    dungeon loot table ids (Inventory/LootTable/JunkieWeaponsLockerLoot.gd,
	#    JunkieStashLoot.gd) - GlobalRegistry.registerLootList() just appends to
	#    a list keyed by these id strings (see LootTableBase.getPossibleLoot()),
	#    so any mod can extend any loot table/pawn archetype this way without
	#    touching the file that owns it. The laser pistol also drops as an
	#    8% signature reward specifically off the Captain (handlesCharacters).
	#
	# Reuses base-game assets that already exist but were never wired to a
	# player-usable item: the "firepistol" animation id, and the
	# Inventory/UnriggedModels/Pistol/ and EnergyPistol/ model/icon pairs
	# (previously only used by Mirri's NPC-only MirriPistolShot attack and the
	# Captain's NPC-only CapEnergyBlast/CapRapidFire attacks, respectively).
	# The laser pistol's damage/armor-scaling numbers and flavor text are
	# lifted directly from CapEnergyBlast/CapRapidFire for balance parity with
	# the Captain's own version of the same weapon.
	#
	# The rifle/laser rifle's two-handed "holdrifle"/"aimrifle"/"firerifle"
	# poses are fully additive now (Animations/GunModRifleAnims.gd): the three
	# clips live in Animations/*.tres and get added to every doll at runtime,
	# the states get added to the shared DollSoloAnimationTree.tres at startup,
	# and GunMod travels the doll into them itself (GunModStage.play(), and
	# BRATSFightScene for fight attacks). Earlier versions edited Doll3D.tscn,
	# DollSoloAnimationTree.tres and BaseStageScene3D.gd directly and shipped
	# copies of them - in the official exported game those copies never took
	# effect (BaseStageScene3D has a class_name, so it's compiled before the
	# launcher loads mods), which is why players saw no rifle poses at all.
	# Don't ship those three core files again.
	#
	# ConscriptArmor/ConscriptHelmet are the first "War Draft" scenario assets:
	# a recolored copy of the base game's GuardArmor/GuardHelmet rigged models
	# (Inventory/RiggedModels/GuardClothes/, .../GuardHelmet/) living under
	# Modules/GunMod/Models/ConscriptUniform/ - copied rather than overriding
	# the originals so regular prison guards don't get recolored too. Currently
	# tagged SoldByMirri purely as a debug/testing convenience so they're easy
	# to pull up in-game; revisit that tag once the actual War Draft scenario
	# exists and decides how conscripts should really acquire this gear.

# Kept alive for the whole session: it listens for new dolls to give them the
# rifle clips (see Animations/GunModRifleAnims.gd)
var rifleAnims

func postInit():
	# Two-handed rifle poses, added at runtime instead of shipping edited
	# copies of Doll3D.tscn/DollSoloAnimationTree.tres
	rifleAnims = preload("res://Modules/GunMod/Animations/GunModRifleAnims.gd").new()
	rifleAnims.install(GlobalRegistry.get_tree())

	# PlayerSlaveryDef has no Module array to register into (see
	# GlobalRegistry.registerPlayerSlaveryDef) - has to happen here instead.
	GlobalRegistry.registerPlayerSlaveryDef("res://Modules/GunMod/WarDraft/WarDraftDef.gd")

	# Same story for GlobalTask/PawnInteraction - no Module array for either,
	# both individually-callable the same way (see registerInteraction() in
	# GlobalRegistry.gd). These two together are what makes the detention
	# floor's jailers real patrolling pawns (the base game's own
	# GlobalTask/InteractionGoal.Patrol/WorldZone machinery, same system
	# Cellblock's own guards patrol with) instead of a per-room dice roll:
	# WarDraftJailerPatrolTask assigns WarDraftBase's own jailer pawns to
	# patrol the "wardraftdetention" zone (see WarDraftDetentionFloor.tscn's
	# zone_wardraftdetention room groups), WarDraftJailerSpotsPlayer detects
	# the real spatial catch when a jailer and the player end up in the same
	# room and hands off to WarDraftDetentionFightScene.
	GlobalRegistry.registerGlobalTask("res://Modules/GunMod/WarDraft/WarDraftJailerPatrolTask.gd")
	GlobalRegistry.registerInteraction("res://Modules/GunMod/WarDraft/WarDraftJailerSpotsPlayer.gd")
	GlobalRegistry.registerPawnType("res://Modules/GunMod/WarDraft/WarDraftSyndicateJailerPawnType.gd")

	# --- TEST-ONLY DEBUG COMMANDS, remove before packaging a release build ---
	Console.addCommand("psmenu", self, "consoleShowSlaveryPicker", [], "Open the PlayerSlavery picker menu directly (lists all soft bad ends, including War Draft)")
	Console.addCommand("vextalk", self, "consoleShowVexTalk", [], "Open WarDraftVexTalkScene directly - now has a real trigger too (the 'final push?' option once corruption hits 100 while defected)")
	Console.addCommand("moralegoal", self, "consoleSetMoraleGoal", [], "Set WarDraft morale to the final push threshold - must already be in the WarDraft scenario")
	Console.addCommand("moralebad", self, "consoleSetMoraleBad", [], "Set WarDraft morale to the dishonorable-discharge threshold - must already be in the WarDraft scenario, then click Extract to trigger it")
	Console.addCommand("corruptionbad", self, "consoleSetCorruptionBad", [], "Set WarDraft corruption to the firing-squad threshold - must already be in the WarDraft scenario and defected, then click Extract to trigger it")
	Console.addCommand("corruptiongoal", self, "consoleSetCorruptionGoal", [], "Set WarDraft corruption to the Syndicate final push threshold - must already be in the WarDraft scenario and defected")
	Console.addCommand("bratsunlock", self, "consoleBRATSUnlock", [], "Give the player Precision level 15 and every B.R.A.T.S. perk, for testing called shots")

func consoleBRATSUnlock():
	var holder = GM.pc.getSkillsHolder()
	holder.ensureSkillExists("GunModPrecision")
	holder.getSkill("GunModPrecision").setLevel(15)
	for perkID in GlobalRegistry.getPerksIDsBySkill("GunModPrecision"):
		holder.addPerk(perkID)
	GM.main.addMessage("B.R.A.T.S. unlocked: Precision 15, all perks.")

func consoleShowSlaveryPicker():
	GM.main.runScene("PlayerSlaveryPickScene")
	GM.main.runCurrentScene()

func consoleSetMoraleGoal():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addMorale(GM.main.PS.MoraleThresholdForDischarge - GM.main.PS.morale)

func consoleSetMoraleBad():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addMorale(GM.main.PS.MoraleThresholdForDischargeBad - GM.main.PS.morale)

func consoleSetCorruptionBad():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addCorruption(GM.main.PS.CorruptionThresholdForFiringSquad - GM.main.PS.corruption)

func consoleSetCorruptionGoal():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addCorruption(GM.main.PS.CorruptionThresholdForFinalPush - GM.main.PS.corruption)

func consoleShowVexTalk():
	GM.main.runScene("WarDraftVexTalkScene")
	GM.main.runCurrentScene()
