extends Character

# The practice dummy Drask has you shoot during the War Draft intake
# (WarDraftStart.gd, dummy_intro -> FightScene "gunmod_dummy"). A plain pale
# mannequin in captured Syndicate armor. It never fights back (its only
# attack is GunModDummyIdle) and drops no loot.

func _init():
	id = "gunmoddummy"
	npcLevel = 1
	npcBasePain = 90
	npcBaseLust = 999
	npcCharacterType = CharacterType.Generic

	pickedSkin = "EmptySkin"
	pickedSkinRColor = Color("ffe9dfb8")
	pickedSkinGColor = Color("ffd8cc9e")
	pickedSkinBColor = Color("ffc9bb88")

func _getName():
	return "Training Dummy"

func getChatColor():
	return "#E9DFB8"

func getGender():
	return Gender.Androgynous

func getSmallDescription() -> String:
	return "A pale mannequin on a post, zipped into a set of captured Syndicate armor. It has seen things."

func getSpecies():
	return [Species.Human]

func _getAttacks():
	return ["GunModDummyIdle"]

func getFightIntro(_battleName):
	return "The training dummy stands on its post, perfectly still. It's not going anywhere."

func getThickness() -> int:
	return 50

func getFemininity() -> int:
	return 50

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthroarms"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("plantilegs"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanhead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanears"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func getDefaultEquipment():
	# No helmet, so the pale mannequin head shows (and head shots can stun)
	return ["SyndiArmor"]

# It's a mannequin, it doesn't bleed. Refusing quietly (instead of a status
# immunity) keeps the "X managed to avoid Bleeding" message out of the log
func addEffect(effectID: String, args = []):
	if(effectID == StatusEffect.Bleeding):
		return false
	return .addEffect(effectID, args)
