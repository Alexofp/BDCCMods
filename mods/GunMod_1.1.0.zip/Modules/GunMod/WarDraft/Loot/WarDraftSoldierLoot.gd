extends GuardLoot

# Loot for War Draft enemies. Inherits the whole guard pool (GuardLoot's own
# lines plus anything registered to the "guard" loot id, like GunMod's pistol
# list) and adds the enemy's own rifle, so a dropped rifle shows up on the
# normal post-fight looting screen with everything else.
#
# Which rifle: set weaponID directly (Vex/Drask), or leave it empty and the
# table reads the defeated character's "GunModLootWeapon" flag, which the
# soldier generators set (flags are saved, unlike npcLootOverride).

const WeaponFlag = "GunModLootWeapon"
const RifleDropChance = 35

var weaponID = ""

func _init():
	id = "GunModWarDraftSoldier"

func getPossibleLoot(characterID, battleName):
	var result = .getPossibleLoot(characterID, battleName)

	# Keep what other mods add to the regular guard pool
	for lootList in GlobalRegistry.getLootLists("guard"):
		var extraLoot = lootList.getLoot("guard", characterID, battleName)
		if(extraLoot is Array):
			result.append_array(extraLoot)

	var weapon = weaponID
	if(weapon == "" && characterID != null):
		var character = GlobalRegistry.getCharacter(characterID)
		if(character != null && character.has_method("getFlag")):
			weapon = str(character.getFlag(WeaponFlag, ""))
	if(weapon != ""):
		result.append([RifleDropChance, [weapon]])
	return result
