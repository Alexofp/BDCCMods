extends SceneBase

# Syndicate-side mirror of WarDraftDraskMoraleCommentScene: Vex reacts to the
# player's corruption tier (WarDraftBase.getCorruptionTier()) when they walk
# into syndicate_outpost, only when the tier has changed since last time.

func _init():
	sceneID = "WarDraftVexCorruptionCommentScene"

func _run():
	if(state == ""):
		addCharacter("vex")
		playAnimation(StageScene.Solo, "stand", {pc="vex"})

		var tier = GM.main.PS.getCorruptionTier()
		if(tier == "great"):
			saynn("[say=vex]There it is. That's the look I wanted on you~ Come find me, sweetheart. I've got something big planned, and you're coming with me.[/say]")
		elif(tier == "good"):
			saynn("[say=vex]You're getting mean out there. I love it~ Don't you dare go soft on me now.[/say]")
		elif(tier == "fine"):
			saynn("[say=vex]People are starting to talk about you, honey. The prisoners too~ That's the good kind of talk.[/say]")
		elif(tier == "decent"):
			saynn("[say=vex]Look at you, getting your hands dirty~ Keep it up, sweetie. I like watching you learn.[/say]")
		elif(tier == "bad"):
			saynn("[say=vex]I keep hearing you let them walk. Or that my people had to drag your sorry ass back here. Stop embarrassing me, bitch.[/say]")
		elif(tier == "critical"):
			saynn("[say=vex]You're fucking useless to me like this. One more screwup and I'll put you in front of the wall myself. And I'll enjoy every second of it.[/say]")

		addButton("...", "Get moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
