extends SceneBase

# Shown after every won fight against a War Draft soldier (BRATSFightScene
# runs it right before the fight scene ends, after looting). "Move on" is
# always the first button so it costs nothing to skip.
#  - AlphaCorp side: "Use them" costs morale (same as the other abuse choices).
#  - Syndicate side: "Use them" gives corruption, "Take them in" sends the
#    soldier to the Prison room (WarDraftBase.addPrisoner) for corruption.
# args: [npcID, battleEndedHow ("pain"/"lust"/...)]

var npcID:String = ""
var endedHow:String = ""

func _init():
	sceneID = "WarDraftDefeatedSoldierScene"

func _initScene(_args = []):
	npcID = _args[0]
	if(_args.size() > 1):
		endedHow = str(_args[1])

func _reactInit():
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID, npcAction="defeat"})

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _run():
	var ps = GM.main.PS
	if(state == ""):
		if(endedHow == "lust"):
			saynn("{npc.name} is down on {npc.his} knees, flushed and panting, rifle forgotten in the dirt. {npc.He} {npc.isAre} in no state to fight you anymore.")
		else:
			saynn("{npc.name} is down in the dirt, rifle kicked out of reach, too hurt to get back up.")

		if(ps.defected):
			saynn("Out here, nobody's going to ask what you did with {npc.him}. Vex would like it either way.")
		else:
			saynn("Nobody from your squad is close enough to see. Somebody always hears about it anyway.")

		addButton("Move on", "Leave them there and keep going", "endthescene")
		if(ps.defected):
			addButton("Use them", "Have your way with them (+"+str(ps.CorruptionPerAbuse)+" corruption)", "do_use")
			addButton("Take them in", "Zip-tie them and hand them off to a runner heading back. They'll end up in the Syndicate prison (+"+str(ps.PrisonerStatBonus)+" corruption, +"+str(ps.PrisonerBounty)+" credits)", "do_take")
		else:
			addButton("Use them", "Have your way with them. Command won't like it ("+str(ps.MoralePenaltyForAbuse)+" morale)", "do_use")
			addButton("Take them prisoner", "Hand them off to the MPs for questioning. Command pays for live prisoners (+"+str(ps.PrisonerStatBonus)+" morale, +"+str(ps.PrisonerBounty)+" credits)", "do_take")

	if(state == "after_use"):
		if(ps.defected):
			saynn("You leave {npc.him} where {npc.he} fell, used and shaking. Word will get back to Vex, and she'll enjoy hearing it.")
		else:
			saynn("You leave {npc.him} where {npc.he} fell and get moving before anyone comes looking. It still ends up in somebody's report.")
		addButton("Continue", "Keep moving", "endthescene")

	if(state == "taken_in"):
		if(ps.defected):
			saynn("You zip-tie {npc.his} wrists and hand {npc.him} off to a Syndicate runner heading back to the lines. {npc.He} doesn't fight it.")
			saynn("You'll find {npc.him} in the prison when you get back.")
		else:
			saynn("You zip-tie {npc.his} wrists and radio it in. A pair of MPs trailing the patrol come up and take {npc.him} off your hands for questioning.")
			saynn("Command pays out for every live one. Drask will hear you brought one in instead of leaving a body.")
		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "do_use"):
		runScene("GenericSexScene", ["pc", npcID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "use_sex")
		return

	if(_action == "do_take"):
		var ps = GM.main.PS
		if(ps.defected):
			ps.addPrisoner(npcID)
			ps.addCorruption(ps.PrisonerStatBonus)
		else:
			ps.addMorale(ps.PrisonerStatBonus)
		GM.pc.addCredits(ps.PrisonerBounty)
		setState("taken_in")
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "use_sex"):
		if(GM.main.PS.defected):
			GM.main.PS.addCorruption(GM.main.PS.CorruptionPerAbuse)
		else:
			GM.main.PS.addMorale(GM.main.PS.MoralePenaltyForAbuse)
		GM.pc.getFetishHolder().addFetish(Fetish.Sadism, RNG.randf_range(0.05, 0.15))
		setState("after_use")

func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["endedHow"] = endedHow
	return data

func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	endedHow = SAVE.loadVar(data, "endedHow", "")
