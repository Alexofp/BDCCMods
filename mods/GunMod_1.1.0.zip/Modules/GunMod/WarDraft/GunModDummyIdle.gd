extends Attack

# The training dummy's whole move set. Does nothing, can't be dodged (so it
# never pops the Dodge/Block prompt), and gives no experience.

func _init():
	id = "GunModDummyIdle"
	category = Category.Physical
	aiCategory = AICategory.Unspecified

func getVisibleName(_context = {}):
	return "Wobble"

func getVisibleDesc(_context = {}):
	return "The dummy wobbles on its post."

func canBeUsedByPlayer():
	return false

func canBeDodgedByPlayer(_attacker, _receiver):
	return false

func _doAttack(_attacker, _receiver, _context = {}):
	return {
		text = RNG.pick([
			"The dummy wobbles on its post.",
			"The dummy creaks and sways a little.",
			"The dummy stares at nothing.",
		]),
	}

func canDoWhileStunned():
	return true
