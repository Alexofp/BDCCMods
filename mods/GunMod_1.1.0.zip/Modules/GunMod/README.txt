Mod name: GunMod
Category: Weapons / PlayerSlavery Scenario
Game Version: 0.3.2
Mod Version: 1.1.0

Description:
Adds a bunch of firearms and a full PlayerSlavery scenario built around them: "War Draft", a conscription story between AlphaCorp and the Syndicate. Gameplay loop is similar to the Drug Den, but WITH GUNZ.

War Draft: you get conscripted into AlphaCorp's war against the Syndicate, whether you like it or not. Run patrols and objectives for AlphaCorp under Sergeant Drask, or end up defecting to the Syndicate and Commander Vex instead. Each side tracked with its own stat, each with its own hub, and each building toward its own real finale fight.

Features:
- 5 new weapons: Pistol, Laser Pistol (taken from base game), Service Rifle, Energy Rifle, Marauder Rifle
- Sold by Mirri; the 3 rifles also drop (rarely) from Drug Den junkie loot
- New two-handed rifle hold/aim/fire animations
- New "War Draft" scenario in the PlayerSlavery picker
- Two full sides to play: stay loyal to AlphaCorp under Sergeant Drask, or defect to the Syndicate under Commander Vex
- Each side tracked with its own stat (AlphaCorp morale / Syndicate corruption)
- Real patrol loop: patrols, ambushes, bomb/rescue objectives, captured-soldier encounters
- Armory restock that also heals your pain
- Kidlat cameo
- Conscript uniform gear
- Two full finale boss fights, one per faction, with reactive dialogue
- Hand scripted cool and awesome sex scenes
- 4 distinct endings
- B.R.A.T.S. targeting mode in every fight: aim any physical attack at a body part (head, eyes, chest, torso, arms, groin, legs) on the enemy's own doll, each with its own hit chance and effect
- New Precision skill tree with 9 perks built around B.R.A.T.S.
- Beaten soldiers can be left, used, or taken prisoner, with consequences for your side

1.1.0 update:

New: B.R.A.T.S. (Ballistic Reflex-Assisted Targeting System)
- A new B.R.A.T.S. button in every fight, anywhere in the game. It opens a targeting screen showing the enemy's own doll with a green outline. Pick a body part, pick any physical attack (guns, fists, kicks, melee weapons), and fire.
- 7 zones, each with its own hit chance, stamina cost and effect: head (stun), eyes (blind), chest (winded, tender breasts), torso (bleeding), arms (weaker attacks), groin (low blow stun) and legs (can't dodge, may go down).
- A new Precision skill tree that levels from every physical attack. B.R.A.T.S. itself is the free first perk, followed by 8 upgrades like Kneecapper, Cheap Shot, Bullseye and Called It.
- Gun-carrying War Draft enemies aim at you too. You get a warning first ("lines up a shot at your legs!"), so you can dodge or block.

New in War Draft
- Sergeant Drask teaches you B.R.A.T.S. during the intake, then has you practice on a training dummy. Don't fuck the dummy.
- After you beat a soldier, you choose what happens to them: move on, use them, or take them prisoner.
  - AlphaCorp: using them costs morale. Taking them prisoner hands them to the MPs for a small morale bonus and a bounty.
  - Syndicate: using them raises corruption. Taking them in gives corruption and a bounty, and you'll find them later in the Syndicate prison.
- Commander Vex now reacts to your corruption when you walk into the Syndicate outpost, the same way Drask reacts to your morale. She gets nasty when you slip.
- The holding cell you wake up in after capture now has a cot, so you can sleep and get your stamina back instead of getting stuck.

Changes
- Rifles dropped by beaten enemies now show up on the normal loot screen with the rest of their loot, instead of a separate message.
- The finale threshold for both sides is now 80 (was 100). Both bad ends now trigger at -20 (AlphaCorp's was -30).
- Enemies keep their rifle in hand after you hit them, instead of it vanishing until their next shot.

Fixes
- The two-handed rifle hold/aim/fire animations now work in the released game. Earlier versions shipped edited copies of base-game animation files that the game never actually loaded, so dolls just stood still. GunMod now adds its animations without replacing any base-game animation files.

Saves: existing saves work. If you're already past the War Draft intake you won't see Drask's lesson or the dummy, but B.R.A.T.S. is free to unlock from the Precision skill tree.

1.0.4 fixes: the rifle hold/aim/fire animations didn't work at all for most players, due to a packaging mistake that pulled in a file from an unrelated mod. Should work properly now.

1.0.3 fixes: regular prison guards could randomly and permanently show up red on the world map caused by the Syndicate detention jailer's map color fix leaking into the game's normal ambient guard spawner (already red guards on existing saves stay red until they respawn).

1.0.2 fixes: Commander Vex's sex scenes (talk-hub "Sex?" option, and claiming a defeated Drask during the Syndicate finale) had the pose backwards from the dialogue - Vex now actually tops like she's supposed to. The rifle idle/aim holds didn't loop and would freeze on the last frame. Those same sex scenes, plus claiming a defeated Vex during the AlphaCorp finale, now actually step through separate tease/sex/fast/finish stages instead of jumping straight to one frozen pose. Also fixed a soft lock where an unrelated quest's periodic "wake up in your cell" event (e.g. Eliza's chastity content) could teleport you off the War Draft map mid-scenario without properly ending it.

[This is my biggest project yet. Please let me know if you hit anything broken. The War Draft map rooms are added by editing one base-game map file directly, so this could conflict with another mod that touches the same file. B.R.A.T.S. also replaces the fight screen with an extended version of it, so it could conflict with another mod that replaces the fight screen too.]
