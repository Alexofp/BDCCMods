extends Attack

# Enemy-only B.R.A.T.S. shot: gun-carrying GunMod enemies aim at a specific
# part of the player. The zone is picked when the player first sees the
# "lining up a shot at your legs" warning (getAnticipationText) and kept until
# the shot resolves, so the warning always matches what actually gets hit and
# the player gets a real Dodge/Block decision. Same zone effects as the
# player's version (BRATS.applyZoneEffect), no player-only perk bonuses.
#
# Attack objects are shared singletons, so the pending zone is keyed by the
# attacker's character ID.

const BRATS = preload("res://Modules/GunMod/BRATS/BRATS.gd")

const DamageRange = [40, 60]

var pendingZones = {}

func _init():
	id = "GunModBRATSEnemyCalledShot"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	aiScoreMultiplier = 0.7

func getVisibleName(_context = {}):
	return "Called Shot"

func getVisibleDesc(_context = {}):
	return "Lines up a shot at a specific body part."

func canBeUsedByPlayer():
	return false

func getZoneWord(zone:String) -> String:
	if(zone == BRATS.Torso):
		return "stomach"
	if(zone == BRATS.Arms):
		return "arm"
	if(zone == BRATS.Legs):
		return "legs"
	return BRATS.getZoneName(zone).to_lower()

func getPendingZone(attacker) -> String:
	var charID = attacker.getID()
	if(!pendingZones.has(charID)):
		pendingZones[charID] = BRATS.pickEnemyZone()
	return pendingZones[charID]

func getAnticipationText(_attacker, _receiver):
	var zone = getPendingZone(_attacker)
	return "{attacker.name} steadies {attacker.his} weapon and lines up a shot at {receiver.your} "+getZoneWord(zone)+"!"

func _doAttack(_attacker, _receiver, _context = {}):
	var zone = getPendingZone(_attacker)
	var _erased = pendingZones.erase(_attacker.getID())

	if(checkMissed(_attacker, _receiver, DamageType.Physical)):
		return genericMissMessage(_attacker, _receiver, "shoot")
	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver, "shot")

	var landed = RNG.chance(BRATS.getZoneChance(_attacker, _receiver, zone))
	var pain = RNG.randi_range(DamageRange[0], DamageRange[1])
	var text = "{attacker.name} fires a carefully aimed shot at {receiver.your} "+getZoneWord(zone)+"."
	if(landed):
		pain = int(round(pain * BRATS.Zones[zone]["dmg"]))
		text += BRATS.applyZoneEffect(_attacker, _receiver, zone)
	else:
		pain = int(round(pain * BRATS.GlanceDamageMult))
		text += " It goes wide and only grazes {receiver.youHim}."

	if(GM.main.isInSpecificPlayerSlavery("WarDraft")):
		pain = int(round(pain * 0.4))

	return {
		text = text,
		pain = pain,
	}

func doAttack(_attacker, _receiver, _context = {}):
	var result = .doAttack(_attacker, _receiver, _context)
	result["attackerAnimation"] = ["firerifle", getWeaponModel(_attacker)]
	return result

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.7

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]

func getWeaponModel(attacker) -> String:
	var model = BRATS.getRifleModel(attacker)
	if(model == ""):
		return "res://Modules/GunMod/Models/MarauderRifle.tscn"
	return model
