extends Attack

# The player's B.R.A.T.S. called shot. Never listed in a normal attack menu
# (isPlayerAttack stays false) - BRATSFightScene builds the context for it:
#   {attackID, zone, inner = <the chosen physical attack's own attackData>, calledIt}
#
# The inner attack runs through its own full doAttack() (own miss/dodge roll,
# ammo, stamina, damage, text). Around it, B.R.A.T.S. rolls zone placement and
# scales the damage with a temporary received-damage status effect on the
# target, so the damage numbers the inner attack prints stay correct.

const BRATS = preload("res://Modules/GunMod/BRATS/BRATS.gd")

func _init():
	id = "GunModBRATSCalledShot"
	category = Category.Physical
	aiCategory = AICategory.Offensive

func getVisibleName(_context = {}):
	return "B.R.A.T.S. Called Shot"

func getVisibleDesc(_context = {}):
	return "An attack aimed at a specific body part."

func canBeUsedByPlayer():
	return false

func doAttack(_attacker, _receiver, _context = {}):
	var zone = _context.get("zone", BRATS.Torso)
	var innerData = _context.get("inner", {})
	var inner = GlobalRegistry.getAttack(innerData.get("attackID", ""))
	if(inner == null || inner.id == id):
		return {
			text = "The targeting system glitches out.",
			attackerAnimation = "",
			receiverAnimation = "",
		}

	_attacker.addStamina(-BRATS.getStaminaCost(_attacker, zone))

	var calledIt = _context.get("calledIt", false)
	if(calledIt):
		# Double down reuses this same dictionary, it shouldn't get a second free shot
		_context["calledIt"] = false

	var landed = RNG.chance(BRATS.getZoneChance(_attacker, _receiver, zone, calledIt))
	var crit = landed && RNG.chance(BRATS.getCritChance(_attacker, zone))
	var mult = BRATS.GlanceDamageMult
	if(landed):
		mult = BRATS.Zones[zone]["dmg"]
		if(crit):
			mult *= BRATS.getCritMult(_attacker)

	_receiver.addEffect(BRATS.EffectZoneDamage, [mult - 1.0])
	var result = inner.doAttack(_attacker, _receiver, innerData)
	_receiver.removeEffect(BRATS.EffectZoneDamage)

	var header = "[color=#5f9][b]B.R.A.T.S. // "+BRATS.getZoneName(zone).to_upper()+"[/b][/color]\n"
	var missed = result.get("missed", false) || result.get("dodged", false)
	var text = header + str(result.get("text", ""))
	if(!missed):
		if(landed):
			text += " [color=#5f9][b]Called shot lands![/b][/color]"
			if(crit):
				text += " [color=#ff6][b]Critical![/b][/color]"
			text += BRATS.applyZoneEffect(_attacker, _receiver, zone)
		else:
			text += " [i]It goes wide of the "+BRATS.getZoneName(zone).to_lower()+" and only glances.[/i]"
	result["text"] = text

	if(_attacker.isPlayer()):
		for expData in inner.getExperience():
			_attacker.addSkillExperience(expData[0], expData[1])

	return result

func getExperience():
	return [[BRATS.SkillID, 8]]
