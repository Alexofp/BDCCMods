extends "res://Scenes/FightScene.gd"

# GunMod B.R.A.T.S. hook into every fight.
#
# This is NOT a copy of FightScene.gd - it extends the real one and keeps
# its sceneID ("FightScene", set by the parent _init). Module scenes are
# registered after the core Scenes/ folder and GlobalRegistry.registerScene()
# just overwrites scenes[sceneID], so every runScene("FightScene", ...) in the
# game builds this subclass instead. Base-game updates to FightScene.gd flow
# through automatically. Only conflict: another mod that also replaces the
# "FightScene" id - last one registered wins.
#
# What it adds:
#  - a "B.R.A.T.S." button in the main fight menu, once the player has the
#    GunModPerkBRATS perk (root of the Precision tree)
#  - the "brats" state, which shows BRATSPanel as a full-screen custom control
#  - "brats_fire": wraps the chosen physical attack in GunModBRATSCalledShot and
#    hands it to the normal "doattack" flow (enemy turn etc. unchanged)
#  - Precision XP for every physical attack the player uses in any fight

const BRATS = preload("res://Modules/GunMod/BRATS/BRATS.gd")
const BRATSPanelScript = preload("res://Modules/GunMod/BRATS/BRATSPanel.gd")

var bratsZone = ""
var bratsAttackKey = ""
var bratsCalledItUsed = false

func _run():
	if(state == "brats"):
		runBRATS()
		return

	._run()

	if((state == "" || state == "fighting") && GM.pc.hasPerk(BRATS.PerkBRATS)):
		addButtonWithChecks("B.R.A.T.S.", "Open the targeting system and aim a physical attack at a specific body part", "brats_open", [], [ButtonChecks.NotStunned])

func isCalledItReady() -> bool:
	return GM.pc.hasPerk(BRATS.PerkCalledIt) && !bratsCalledItUsed

func getAttackKey(attackData:Dictionary) -> String:
	return str(attackData.get("attackID", ""))+"|"+str(attackData.get("itemID", ""))

func runBRATS():
	var calledIt = isCalledItReady()
	var zoneInfo = {}
	for zone in BRATS.ZoneOrder:
		zoneInfo[zone] = {
			chance = BRATS.getZoneChance(GM.pc, enemyCharacter, zone, calledIt),
			stamina = BRATS.getStaminaCost(GM.pc, zone),
			desc = BRATS.getZoneEffectDesc(GM.pc, enemyCharacter, zone),
		}

	var entries = []
	var preselect = -1
	for entry in BRATS.getUsableInnerAttacks(GM.pc, enemyCharacter, battleName):
		if(getAttackKey(entry["attackData"]) == bratsAttackKey):
			preselect = entries.size()
		entries.append({
			label = BRATS.getInnerAttackLabel(entry),
			canUse = entry["canUse"],
			attackData = entry["attackData"],
		})

	var panel = BRATSPanelScript.new()
	panel.setup(enemyID, enemyCharacter.getName(), zoneInfo, entries, bratsZone, preselect, calledIt)
	GM.ui.addFullScreenCustomControl("brats", panel)
	var _ok = panel.connect("selectionChanged", self, "onBRATSSelectionChanged")

	addButton("Fire", "Fire the locked-in called shot (uses your turn)", "brats_fire")
	addButton("Cancel", "Back to fighting", "return")

func onBRATSSelectionChanged(zone, _attackIndex):
	bratsZone = zone
	var panel = GM.ui.getCustomControl("brats")
	if(panel != null):
		var sel = panel.getSelection()
		if(sel.size() >= 2):
			bratsAttackKey = getAttackKey(sel[1])

func _react(_action: String, _args):
	if(_action == "brats_open"):
		setState("brats")
		return

	if(_action == "brats_fire"):
		var zone = ""
		var innerData = null
		if(_args.size() >= 2):
			zone = _args[0]
			innerData = _args[1]
		else:
			var panel = GM.ui.getCustomControl("brats")
			if(panel != null):
				var sel = panel.getSelection()
				if(sel.size() >= 2):
					zone = sel[0]
					innerData = sel[1]

		if(zone == "" || innerData == null):
			addMessage("Lock a zone and pick an attack first.")
			return

		var innerAttack = GlobalRegistry.getAttack(innerData["attackID"])
		if(innerAttack == null || !innerAttack.canUse(GM.pc, enemyCharacter, innerData)):
			addMessage("You can't use that attack right now.")
			return
		var staminaCost = BRATS.getStaminaCost(GM.pc, zone)
		if(GM.pc.getStamina() < staminaCost):
			addMessage("Not enough stamina to line up that shot ("+str(staminaCost)+" needed).")
			return

		bratsZone = zone
		bratsAttackKey = getAttackKey(innerData)

		var calledIt = isCalledItReady()
		if(calledIt):
			bratsCalledItUsed = true

		var wrapped = {
			"attackID": BRATS.PlayerAttackID,
			"zone": zone,
			"inner": innerData,
			"calledIt": calledIt,
		}
		._react("doattack", [wrapped])
		return

	._react(_action, _args)

func doPlayerAttack(attackData):
	var text = .doPlayerAttack(attackData)

	# Precision levels from any physical attack; the called-shot wrapper
	# hands out its own (bigger) XP through getExperience().
	var attack = GlobalRegistry.getAttack(attackData["attackID"])
	if(attack != null && attack.category == Attack.Category.Physical && attack.id != BRATS.PlayerAttackID):
		var xp = 3
		if(attack.isWeaponAttack):
			xp = 5
		GM.pc.addSkillExperience(BRATS.SkillID, xp)

	return text

# Every stage call rebuilds both dolls (Duo.playAnimation -> prepareCharacter
# clears temporary parts), so after the player's attack plays the enemy's
# plain "hurt"/"dodge" reaction, a rifle-carrying enemy used to stand there
# empty-handed until its next shot. Put the rifle back in its hand for those
# plain reaction/idle poses. Weapon poses (arrays like ["firerifle", model])
# attach their own prop, and other named actions (baton swings, kicks with
# their own props) are left alone.
const KeepRifleForActions = ["", "hurt", "dodge", "block", "stand", "defocus"]

func playAnimation(theSceneID, theActionID, args = {}):
	# Rifle attack poses ("firerifle" etc.) can't be played by the base stage,
	# GunMod plays them itself (Animations/GunModRifleAnims.gd)
	var gunMod = GlobalRegistry.getModule("GunMod")
	if(gunMod != null && gunMod.rifleAnims != null && gunMod.rifleAnims.hasRifleAction(theActionID, args)):
		gunMod.rifleAnims.play(theSceneID, theActionID, args)
	else:
		.playAnimation(theSceneID, theActionID, args)
	if(theSceneID != StageScene.Duo || !args.has("npc") || args["npc"] != enemyID):
		return
	var npcAction = args.get("npcAction", "")
	if(!(npcAction is String) || !(npcAction in KeepRifleForActions)):
		return
	var model = BRATS.getRifleModel(enemyCharacter)
	if(model == ""):
		return
	if(!attachEnemyRifle(model)):
		# The stage was switching scenes (it fades first), try again after it
		yield(get_tree().create_timer(0.8), "timeout")
		if(is_instance_valid(self)):
			var _ok = attachEnemyRifle(model)

func attachEnemyRifle(model:String) -> bool:
	if(GM.ui == null):
		return false
	var stage = GM.ui.getStage3d()
	if(stage == null || stage.currentScene == null || !is_instance_valid(stage.currentScene)):
		return false
	var stageScene = stage.currentScene
	if(stageScene.id != StageScene.Duo || stageScene.is_queued_for_deletion()):
		return false
	stageScene.doll2.attachTemporaryUnriggedPart("hand.L", model)
	return true

# --- War Draft: what to do with a beaten soldier ---------------------------
# After a won fight against a War Draft soldier (the generated ones carry the
# GunModLootWeapon flag; Vex/Drask/jailers don't), show
# WarDraftDefeatedSoldierScene before the fight actually ends. FightScene ends
# through endScene([battleState, battleEndedHow]) both after the looting
# screen and when there's nothing to loot, so hooking endScene covers both,
# and the encounter scene that started the fight gets the same result as
# before once the choice is done.
var gunModDefeatShown = false
var gunModPendingEnd = []

func shouldOfferDefeatedSoldier(result) -> bool:
	if(gunModDefeatShown || !(result is Array) || result.empty() || result[0] != "win"):
		return false
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return false
	if(enemyCharacter == null || !enemyCharacter.has_method("isDynamicCharacter") || !enemyCharacter.isDynamicCharacter()):
		return false
	return str(enemyCharacter.getFlag("GunModLootWeapon", "")) != ""

func endScene(result = []):
	if(shouldOfferDefeatedSoldier(result)):
		gunModDefeatShown = true
		gunModPendingEnd = result
		runScene("WarDraftDefeatedSoldierScene", [enemyID, battleEndedHow], "gunmod_defeated")
		return
	.endScene(result)

func _react_scene_end(_tag, _result):
	if(_tag == "gunmod_defeated"):
		.endScene(gunModPendingEnd)
		return
	._react_scene_end(_tag, _result)

func saveData():
	var data = .saveData()
	data["gunModDefeatShown"] = gunModDefeatShown
	data["gunModPendingEnd"] = gunModPendingEnd
	data["bratsZone"] = bratsZone
	data["bratsAttackKey"] = bratsAttackKey
	data["bratsCalledItUsed"] = bratsCalledItUsed
	return data

func loadData(data):
	.loadData(data)
	bratsZone = SAVE.loadVar(data, "bratsZone", "")
	bratsAttackKey = SAVE.loadVar(data, "bratsAttackKey", "")
	bratsCalledItUsed = SAVE.loadVar(data, "bratsCalledItUsed", false)
	gunModDefeatShown = SAVE.loadVar(data, "gunModDefeatShown", false)
	gunModPendingEnd = SAVE.loadVar(data, "gunModPendingEnd", [])
