extends Control

# B.R.A.T.S. targeting screen. Shown by BRATSFightScene through
# GM.ui.addFullScreenCustomControl(), which swaps it in for the fight text.

const BRATS = preload("res://Modules/GunMod/BRATS/BRATS.gd")
const DollScene = preload("res://Player/Player3D/Doll3D.tscn")
const OutlineShader = preload("res://Modules/GunMod/BRATS/BRATSOutline.shader")

signal selectionChanged(zone, attackIndex)

const ColGreen = Color(0.3, 1.0, 0.5)
const ColDim = Color(0.15, 0.55, 0.28)
const ColYellow = Color(1.0, 0.9, 0.3)
const ColRed = Color(1.0, 0.35, 0.3)
const ColBG = Color(0.02, 0.06, 0.03, 0.97)

# RETICLE POSITIONS - edit these to move a reticle.
const Anchors = {
	"head": [["Head", Vector3(-0.04, 0.14, 0)]],
	"eyes": [["Head", Vector3(0.09, 0.09, 0)]],
	"chest": [["DeformBreasts", Vector3(0.05, -0.02, 0)]],
	"torso": [["__torso__", Vector3(0.035, 0, 0)]],
	"arms": [["Hand.near", Vector3(0, 0, 0)]], # only the near arm is visible side-on
	"groin": [["Penis", Vector3(0, 0, 0)]],
	"legs": [["LegDown.L", Vector3(0, 0, 0)], ["LegDown.R", Vector3(0, 0, 0)]],
}

const DollFacesRight = true
const DollYawDegrees = 25.0

const PickRadius = 26.0

var enemyID = ""
var zoneInfo = {} # zone -> {chance, stamina, desc}
var attackEntries = [] # [{label, canUse, attackData}]
var lockedZone = ""
var hoveredZone = ""
var attackIndex = -1
var targetName = ""
var calledItReady = false

var viewport:Viewport
var camera:Camera
var doll
var dollRect:TextureRect
var overlay:Control
var zoneListBox:VBoxContainer
var zoneButtons = {}
var infoLabel:RichTextLabel
var attackBox:VBoxContainer
var attackButtons = []
var fireButton:Button
var pulseTime = 0.0
var screenAnchors = {} # zone -> [Vector2 in dollRect local coords]
var dollReady = false
var dollHolder:Spatial
var dollHeight = 2.0
var framedFrames = 0

func setup(_enemyID:String, _targetName:String, _zoneInfo:Dictionary, _attackEntries:Array, _lockedZone:String, _attackIndex:int, _calledItReady:bool):
	enemyID = _enemyID
	targetName = _targetName
	zoneInfo = _zoneInfo
	attackEntries = _attackEntries
	lockedZone = _lockedZone
	attackIndex = _attackIndex
	calledItReady = _calledItReady
	if(attackIndex < 0 || attackIndex >= attackEntries.size() || !attackEntries[attackIndex]["canUse"]):
		attackIndex = -1
		for i in range(attackEntries.size()):
			if(attackEntries[i]["canUse"]):
				attackIndex = i
				break

func getSelection() -> Array:
	if(lockedZone == "" || attackIndex < 0):
		return []
	return [lockedZone, attackEntries[attackIndex]["attackData"]]

func _ready():
	anchor_right = 1.0
	anchor_bottom = 1.0
	size_flags_horizontal = SIZE_EXPAND_FILL
	size_flags_vertical = SIZE_EXPAND_FILL
	rect_min_size = Vector2(0, 420)

	var bg = ColorRect.new()
	bg.color = ColBG
	bg.anchor_right = 1.0
	bg.anchor_bottom = 1.0
	bg.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(bg)

	var margin = MarginContainer.new()
	margin.anchor_right = 1.0
	margin.anchor_bottom = 1.0
	for side in ["left", "right", "top", "bottom"]:
		margin.add_constant_override("margin_"+side, 8)
	add_child(margin)

	var root = VBoxContainer.new()
	margin.add_child(root)

	var header = Label.new()
	header.text = "B.R.A.T.S. // TARGET: "+targetName.to_upper()
	header.add_color_override("font_color", ColGreen)
	header.clip_text = true
	root.add_child(header)

	var hbox = HBoxContainer.new()
	hbox.size_flags_vertical = SIZE_EXPAND_FILL
	hbox.add_constant_override("separation", 10)
	root.add_child(hbox)

	buildDollSide(hbox)
	buildReadoutSide(hbox)

	updateAll()

func buildDollSide(parent:Control):
	var wrapper = Control.new()
	wrapper.size_flags_horizontal = SIZE_EXPAND_FILL
	wrapper.size_flags_vertical = SIZE_EXPAND_FILL
	wrapper.size_flags_stretch_ratio = 1.1
	wrapper.rect_clip_content = true
	parent.add_child(wrapper)

	viewport = Viewport.new()
	viewport.own_world = true
	viewport.transparent_bg = true
	viewport.render_target_v_flip = true
	viewport.render_target_update_mode = Viewport.UPDATE_ALWAYS
	viewport.msaa = Viewport.MSAA_4X
	viewport.size = Vector2(400, 500)
	wrapper.add_child(viewport)

	camera = Camera.new()
	camera.projection = Camera.PROJECTION_ORTHOGONAL
	camera.size = 10.5
	camera.transform = Transform(Basis(), Vector3(0, 4.2, 50))
	var env = Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.7
	camera.environment = env
	viewport.add_child(camera)
	camera.current = true

	var light = DirectionalLight.new()
	light.transform = Transform(Basis(Vector3(1, 0, 0), deg2rad(-30)).rotated(Vector3(0, 1, 0), deg2rad(20)), Vector3(0, 10, 20))
	light.light_energy = 0.9
	viewport.add_child(light)

	# Doll3D expects a Spatial parent (checkDirection() reads its scale)
	dollHolder = Spatial.new()
	dollHolder.rotation_degrees = Vector3(0, DollYawDegrees, 0)
	if(DollFacesRight):
		dollHolder.scale = Vector3(-1, 1, 1)
	viewport.add_child(dollHolder)
	doll = DollScene.instance()
	dollHolder.add_child(doll)

	dollRect = TextureRect.new()
	dollRect.anchor_right = 1.0
	dollRect.anchor_bottom = 1.0
	dollRect.expand = true
	dollRect.stretch_mode = TextureRect.STRETCH_SCALE
	dollRect.mouse_filter = MOUSE_FILTER_IGNORE
	dollRect.texture = viewport.get_texture()
	var mat = ShaderMaterial.new()
	mat.shader = OutlineShader
	dollRect.material = mat
	wrapper.add_child(dollRect)

	overlay = Control.new()
	overlay.anchor_right = 1.0
	overlay.anchor_bottom = 1.0
	overlay.mouse_filter = MOUSE_FILTER_STOP
	var _ok = overlay.connect("draw", self, "onOverlayDraw")
	var _ok2 = overlay.connect("gui_input", self, "onOverlayInput")
	var _ok3 = overlay.connect("mouse_exited", self, "onOverlayMouseExited")
	wrapper.add_child(overlay)

	call_deferred("initDoll")

func initDoll():
	if(doll == null || !is_instance_valid(doll)):
		return
	doll.prepareCharacter(enemyID)
	var animPlayer = doll.getAnimPlayer()
	if(animPlayer != null && animPlayer.has_animation("Standing-loop")):
		doll.playAnimation("Standing-loop", 0.0)
	dollReady = true

# Keeps the offscreen viewport the same pixel size as the panel area showing it
func syncViewportSize():
	var s = dollRect.rect_size
	if(s.x < 8 || s.y < 8):
		return
	var wanted = Vector2(round(s.x), round(s.y))
	if(viewport.size != wanted):
		viewport.size = wanted

func frameDoll(skeleton:Skeleton):
	var head = getBoneWorldPos(skeleton, "Head")
	var footL = getBoneWorldPos(skeleton, "Foot.L")
	var footR = getBoneWorldPos(skeleton, "Foot.R")
	var hips = getBoneWorldPos(skeleton, "Hips")
	if(head == null || footL == null || footR == null || hips == null):
		return
	var footY = min(footL.y, footR.y)
	dollHeight = max(head.y - footY, 0.1)
	camera.keep_aspect = Camera.KEEP_HEIGHT
	var s = dollRect.rect_size
	var aspect = (s.x / s.y) if s.y > 0 else 1.0
	# tall narrow panels need more vertical room so the arms still fit
	var fit = 1.35
	if(aspect < 0.55):
		fit = 1.35 * 0.55 / max(aspect, 0.2)
	camera.size = dollHeight * fit
	camera.transform = Transform(Basis(), Vector3(hips.x, footY + dollHeight * 0.56, hips.z + 50.0))

func buildReadoutSide(parent:Control):
	var right = VBoxContainer.new()
	right.size_flags_horizontal = SIZE_EXPAND_FILL
	right.size_flags_vertical = SIZE_EXPAND_FILL
	right.add_constant_override("separation", 4)
	parent.add_child(right)

	var zonesTitle = Label.new()
	zonesTitle.text = "ZONES"
	zonesTitle.add_color_override("font_color", ColDim)
	right.add_child(zonesTitle)

	zoneListBox = VBoxContainer.new()
	zoneListBox.add_constant_override("separation", 1)
	right.add_child(zoneListBox)
	for zone in BRATS.ZoneOrder:
		var b = Button.new()
		b.toggle_mode = true
		b.flat = true
		b.align = Button.ALIGN_LEFT
		b.add_color_override("font_color", ColGreen)
		b.add_color_override("font_color_hover", Color(0.7, 1.0, 0.8))
		b.add_color_override("font_color_pressed", Color(1.0, 1.0, 0.6))
		var _ok = b.connect("pressed", self, "onZonePressed", [zone])
		var _ok2 = b.connect("mouse_entered", self, "setHover", [zone])
		var _ok3 = b.connect("mouse_exited", self, "setHover", [""])
		zoneListBox.add_child(b)
		zoneButtons[zone] = b

	infoLabel = RichTextLabel.new()
	infoLabel.bbcode_enabled = true
	infoLabel.fit_content_height = true
	infoLabel.rect_min_size = Vector2(0, 70)
	infoLabel.mouse_filter = MOUSE_FILTER_IGNORE
	right.add_child(infoLabel)

	var attTitle = Label.new()
	attTitle.text = "ATTACK"
	attTitle.add_color_override("font_color", ColDim)
	right.add_child(attTitle)

	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = SIZE_EXPAND_FILL
	scroll.scroll_horizontal_enabled = false
	right.add_child(scroll)
	attackBox = VBoxContainer.new()
	attackBox.size_flags_horizontal = SIZE_EXPAND_FILL
	scroll.add_child(attackBox)
	if(attackEntries.empty()):
		var none = Label.new()
		none.text = "No physical attacks available."
		none.add_color_override("font_color", ColRed)
		attackBox.add_child(none)
	for i in range(attackEntries.size()):
		var entry = attackEntries[i]
		var b = Button.new()
		b.toggle_mode = true
		b.flat = true
		b.align = Button.ALIGN_LEFT
		b.clip_text = true
		b.text = entry["label"]
		b.disabled = !entry["canUse"]
		b.add_color_override("font_color", ColGreen)
		b.add_color_override("font_color_disabled", Color(0.3, 0.4, 0.3))
		b.add_color_override("font_color_pressed", Color(1.0, 1.0, 0.6))
		var _ok = b.connect("pressed", self, "onAttackPressed", [i])
		attackBox.add_child(b)
		attackButtons.append(b)

	var btnRow = HBoxContainer.new()
	btnRow.add_constant_override("separation", 8)
	right.add_child(btnRow)
	fireButton = Button.new()
	fireButton.text = "  FIRE  "
	fireButton.size_flags_horizontal = SIZE_EXPAND_FILL
	fireButton.add_color_override("font_color", ColGreen)
	var _ok = fireButton.connect("pressed", self, "onFirePressed")
	btnRow.add_child(fireButton)
	var cancel = Button.new()
	cancel.text = "  CANCEL  "
	cancel.size_flags_horizontal = SIZE_EXPAND_FILL
	var _ok2 = cancel.connect("pressed", self, "onCancelPressed")
	btnRow.add_child(cancel)

func chanceColor(chance:int) -> Color:
	if(chance >= 60):
		return ColGreen
	if(chance >= 35):
		return ColYellow
	return ColRed

func updateAll():
	for zone in zoneButtons:
		var b:Button = zoneButtons[zone]
		var info = zoneInfo[zone]
		var prefix = "> " if zone == lockedZone else "  "
		b.text = prefix + padRight(BRATS.getZoneName(zone).to_upper(), 7) + padLeft(str(info["chance"]), 3) + "%   " + str(info["stamina"]) + " stam"
		b.pressed = (zone == lockedZone)
		b.add_color_override("font_color", chanceColor(info["chance"]))
	for i in range(attackButtons.size()):
		attackButtons[i].pressed = (i == attackIndex)
		attackButtons[i].text = ("> " if i == attackIndex else "  ") + attackEntries[i]["label"]

	var showZone = hoveredZone if hoveredZone != "" else lockedZone
	var t = ""
	if(showZone == ""):
		t = "[color=#4c8]Click a body part on the target, or a zone in the list, to lock it.[/color]"
	else:
		var info = zoneInfo[showZone]
		var col = "#"+chanceColor(info["chance"]).to_html(false)
		t = "[color=#6f8][b]"+BRATS.getZoneName(showZone).to_upper()+"[/b][/color]"
		if(showZone == lockedZone):
			t += " [color=#6f8](LOCKED)[/color]"
		t += "  [color="+col+"]"+str(info["chance"])+"% to land[/color]\n"
		t += "[color=#6c8]"+info["desc"]+"[/color]"
		if(calledItReady):
			t += "\n[color=#ff6][Called It] This shot can't miss the zone.[/color]"
	infoLabel.bbcode_text = t

	fireButton.disabled = (lockedZone == "" || attackIndex < 0)
	if(overlay != null):
		overlay.update()

func onZonePressed(zone):
	if(lockedZone == zone):
		lockedZone = ""
	else:
		lockedZone = zone
	emit_signal("selectionChanged", lockedZone, attackIndex)
	updateAll()

func onAttackPressed(i):
	attackIndex = i
	emit_signal("selectionChanged", lockedZone, attackIndex)
	updateAll()

func setHover(zone):
	if(hoveredZone == zone):
		return
	hoveredZone = zone
	updateAll()

func onFirePressed():
	if(lockedZone == "" || attackIndex < 0):
		return
	GM.main.pickOption("brats_fire", [lockedZone, attackEntries[attackIndex]["attackData"]])

func onCancelPressed():
	GM.main.pickOption("return", [])

func _process(delta):
	pulseTime += delta
	if(!dollReady || doll == null || !is_instance_valid(doll)):
		return
	syncViewportSize()
	if(framedFrames < 10):
		framedFrames += 1
		var dollSkel = doll.getDollSkeleton()
		if(dollSkel != null):
			frameDoll(dollSkel.getSkeleton())
	updateScreenAnchors()
	updateShader()
	overlay.update()

func getBoneWorldPos(skeleton:Skeleton, boneName:String):
	var idx = skeleton.find_bone(boneName)
	if(idx < 0):
		return null
	return (skeleton.global_transform * skeleton.get_bone_global_pose(idx)).origin

func updateScreenAnchors():
	var dollSkel = doll.getDollSkeleton()
	if(dollSkel == null):
		return
	var skeleton:Skeleton = dollSkel.getSkeleton()
	if(skeleton == null):
		return
	var vpSize = viewport.size
	if(vpSize.x <= 0 || vpSize.y <= 0):
		return
	var scale = dollRect.rect_size / vpSize
	screenAnchors.clear()
	for zone in Anchors:
		var pts = []
		for anchorData in Anchors[zone]:
			var boneName = anchorData[0]
			var worldPos
			if(boneName == "__torso__"):
				var a = getBoneWorldPos(skeleton, "Chest")
				var b = getBoneWorldPos(skeleton, "Hips")
				if(a == null || b == null):
					continue
				worldPos = a.linear_interpolate(b, 0.5)
			else:
				worldPos = getBoneWorldPos(skeleton, resolveBoneName(boneName))
				if(worldPos == null):
					continue
			var off = anchorData[1]
			worldPos += Vector3(off.x * getForwardSign(), off.y, off.z) * dollHeight
			pts.append(camera.unproject_position(worldPos) * scale)
		screenAnchors[zone] = pts

func toUV(p:Vector2) -> Vector2:
	var s = dollRect.rect_size
	if(s.x <= 0 || s.y <= 0):
		return Vector2(-10, -10)
	return p / s

func zoneUVs(zone) -> Array:
	var res = [Vector2(-10, -10), Vector2(-10, -10)]
	if(zone == "" || !screenAnchors.has(zone)):
		return res
	var pts = screenAnchors[zone]
	for i in range(min(2, pts.size())):
		res[i] = toUV(pts[i])
	return res

func updateShader():
	var mat = dollRect.material
	var s = dollRect.rect_size
	mat.set_shader_param("aspect", (s.x / s.y) if s.y > 0 else 1.0)
	mat.set_shader_param("pulse", 0.5 + 0.5 * sin(pulseTime * 5.0))
	var h = zoneUVs(hoveredZone)
	mat.set_shader_param("hover_uv", h[0])
	mat.set_shader_param("hover_uv2", h[1])
	var l = zoneUVs(lockedZone)
	mat.set_shader_param("lock_uv", l[0])
	mat.set_shader_param("lock_uv2", l[1])

func zoneAt(pos:Vector2) -> String:
	var best = ""
	var bestDist = PickRadius
	for zone in screenAnchors:
		for p in screenAnchors[zone]:
			var d = p.distance_to(pos)
			if(d < bestDist):
				bestDist = d
				best = zone
	return best

func onOverlayInput(event):
	if(event is InputEventMouseMotion):
		setHover(zoneAt(event.position))
	elif(event is InputEventMouseButton && event.pressed && event.button_index == BUTTON_LEFT):
		var z = zoneAt(event.position)
		if(z != ""):
			onZonePressed(z)
			overlay.accept_event()

func onOverlayMouseExited():
	setHover("")

func onOverlayDraw():
	var font = overlay.get_font("font")
	var pulse = 0.5 + 0.5 * sin(pulseTime * 5.0)
	for zone in screenAnchors:
		var info = zoneInfo[zone]
		var col = chanceColor(info["chance"])
		var isLocked = (zone == lockedZone)
		var isHover = (zone == hoveredZone)
		var r = 9.0
		if(isHover):
			r = 12.0
		if(isLocked):
			r = 13.0 + pulse * 2.0
		var i = 0
		for p in screenAnchors[zone]:
			var a = 0.55
			if(isHover):
				a = 0.9
			if(isLocked):
				a = 1.0
			var c = Color(col.r, col.g, col.b, a)
			overlay.draw_arc(p, r, 0, TAU, 32, c, 2.0 if !isLocked else 3.0, true)
			overlay.draw_line(p + Vector2(-r - 5, 0), p + Vector2(-r + 3, 0), c, 1.5)
			overlay.draw_line(p + Vector2(r - 3, 0), p + Vector2(r + 5, 0), c, 1.5)
			overlay.draw_line(p + Vector2(0, -r - 5), p + Vector2(0, -r + 3), c, 1.5)
			overlay.draw_line(p + Vector2(0, r - 3), p + Vector2(0, r + 5), c, 1.5)
			if(isLocked):
				drawLockBrackets(p, r + 9.0, c)
			if(i == 0 && font != null && (isHover || isLocked)):
				var label = BRATS.getZoneName(zone).to_upper()+" "+str(info["chance"])+"%"
				overlay.draw_string(font, p + Vector2(r + 7, -r * 0.5), label, c)
			i += 1

func drawLockBrackets(p:Vector2, s:float, c:Color):
	var l = s * 0.45
	for sx in [-1, 1]:
		for sy in [-1, 1]:
			var corner = p + Vector2(sx * s, sy * s)
			overlay.draw_line(corner, corner - Vector2(sx * l, 0), c, 2.0)
			overlay.draw_line(corner, corner - Vector2(0, sy * l), c, 2.0)

func padRight(s:String, width:int) -> String:
	while(s.length() < width):
		s += " "
	return s

func padLeft(s:String, width:int) -> String:
	while(s.length() < width):
		s = " " + s
	return s

func getForwardSign() -> float:
	return 1.0 if DollFacesRight else -1.0

func resolveBoneName(boneName:String) -> String:
	if(boneName.ends_with(".near")):
		return boneName.trim_suffix(".near") + (".L" if DollFacesRight else ".R")
	if(boneName.ends_with(".far")):
		return boneName.trim_suffix(".far") + (".R" if DollFacesRight else ".L")
	return boneName
