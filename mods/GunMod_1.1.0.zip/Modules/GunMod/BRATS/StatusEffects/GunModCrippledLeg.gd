extends StatusEffectBase

# B.R.A.T.S. leg shot.

func _init():
	id = "GunModCrippledLeg"
	isBattleOnly = true

func initArgs(_args = []):
	turns = 3
	if(_args.size() > 0):
		turns = _args[0]

func processBattleTurn():
	turns -= 1
	if(turns <= 0):
		stop()

func processTime(_secondsPassed: int):
	pass

func getEffectName():
	return "Crippled leg"

func getEffectDesc():
	return "A leg won't take weight properly. Dodging is much harder. " + str(turns) + " more turns"

func getEffectImage():
	return "res://Images/StatusEffects/ragged-wound.png"

func getIconColor():
	return IconColorRed

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff, [-40.0]),
	]

func saveData():
	return {
		"turns": turns,
	}

func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 3)
