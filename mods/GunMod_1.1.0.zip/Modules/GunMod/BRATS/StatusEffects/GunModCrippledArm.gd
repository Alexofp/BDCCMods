extends StatusEffectBase

# B.R.A.T.S. arm shot. Butterfingers (player perk) passes strong = true.

var strong = false

func _init():
	id = "GunModCrippledArm"
	isBattleOnly = true

func initArgs(_args = []):
	turns = 3
	if(_args.size() > 0):
		turns = _args[0]
	if(_args.size() > 1):
		strong = _args[1]

func processBattleTurn():
	turns -= 1
	if(turns <= 0):
		stop()

func processTime(_secondsPassed: int):
	pass

func getEffectName():
	return "Crippled arm"

func getEffectDesc():
	if(strong):
		return "An arm hangs useless. Attacks are much weaker and aim is off. " + str(turns) + " more turns"
	return "An arm hangs useless. Attacks are weaker and aim is off. " + str(turns) + " more turns"

func getEffectImage():
	return "res://Images/StatusEffects/open-wound.png"

func getIconColor():
	return IconColorRed

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)
	if(_args.size() > 1 && _args[1]):
		strong = true

func getBuffs():
	if(strong):
		return [
			buff(Buff.PhysicalDamageBuff, [-50.0]),
			buff(Buff.AccuracyBuff, [-30.0]),
		]
	return [
		buff(Buff.PhysicalDamageBuff, [-30.0]),
		buff(Buff.AccuracyBuff, [-20.0]),
	]

func saveData():
	return {
		"turns": turns,
		"strong": strong,
	}

func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 3)
	strong = SAVE.loadVar(_data, "strong", false)
