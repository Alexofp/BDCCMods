extends StatusEffectBase

# B.R.A.T.S. chest shot on a target with breasts.

func _init():
	id = "GunModTenderChest"
	isBattleOnly = true

func initArgs(_args = []):
	turns = 3
	if(_args.size() > 0):
		turns = _args[0]

func processBattleTurn():
	turns -= 1
	if(turns <= 0):
		stop()

func processTime(_secondsPassed: int):
	pass

func getEffectName():
	return "Tender chest"

func getEffectDesc():
	return "Sore, throbbing breasts. Moving fast hurts and every touch goes straight to the head. " + str(turns) + " more turns"

func getEffectImage():
	return "res://Images/StatusEffects/breasts-pain.png"

func getIconColor():
	return IconColorPurple

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff, [-15.0]),
		buff(Buff.ReceivedLustDamageBuff, [25.0]),
	]

func saveData():
	return {
		"turns": turns,
	}

func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 3)
