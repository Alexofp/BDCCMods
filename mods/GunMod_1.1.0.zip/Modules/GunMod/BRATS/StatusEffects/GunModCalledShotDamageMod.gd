extends StatusEffectBase

# Invisible helper for GunModBRATSCalledShot: added to the target right
# before the inner attack runs and removed right after, so the zone damage
# multiplier goes through the normal receiveDamage() math and the damage
# numbers in the attack text stay correct. Never survives past one attack.

var mod = 0.0

func _init():
	id = "GunModCalledShotDamageMod"
	isBattleOnly = true

func initArgs(_args = []):
	if(_args.size() > 0):
		mod = _args[0]

func combine(_args = []):
	if(_args.size() > 0):
		mod = _args[0]

func processBattleTurn():
	stop()

func processTime(_secondsPassed: int):
	pass

func getRecievedDamageMod(_damageType):
	if(_damageType == DamageType.Physical):
		return mod
	return 0.0

func getEffectName():
	return "Targeted"

func getEffectDesc():
	return "Lined up in someone's sights."

func getEffectImage():
	return "res://Images/StatusEffects/crosshair.png"

func getIconColor():
	return IconColorYellow

func saveData():
	return {
		"mod": mod,
	}

func loadData(_data):
	mod = SAVE.loadVar(_data, "mod", 0.0)
