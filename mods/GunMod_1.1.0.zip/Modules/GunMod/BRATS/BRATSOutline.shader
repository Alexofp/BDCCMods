shader_type canvas_item;

// B.R.A.T.S. doll outline. Runs only on the targeting panel's TextureRect
// (the doll is rendered into its own transparent Viewport), so it never
// touches the doll's 3D materials or anything outside the panel.
//
// Whole doll: thin dim-green stroke + slight green CRT tint.
// Near the hovered zone: brighter stroke.
// Near the locked zone: thick, bright, pulsing stroke + green glow on the body.

uniform vec4 line_color : hint_color = vec4(0.25, 1.0, 0.45, 1.0);
uniform float line_width = 1.5;
uniform vec2 hover_uv = vec2(-10.0, -10.0);
uniform vec2 hover_uv2 = vec2(-10.0, -10.0);
uniform vec2 lock_uv = vec2(-10.0, -10.0);
uniform vec2 lock_uv2 = vec2(-10.0, -10.0);
uniform float zone_radius = 0.09;
uniform float aspect = 1.0;
uniform float pulse = 0.0;

float zoneFactor(vec2 uv, vec2 p) {
	vec2 d = uv - p;
	d.x *= aspect;
	return 1.0 - smoothstep(zone_radius * 0.55, zone_radius, length(d));
}

float sampleRing(sampler2D tex, vec2 uv, vec2 px, float w) {
	float m = 0.0;
	for (int i = 0; i < 12; i++) {
		float ang = float(i) * 0.5235988;
		vec2 o = vec2(cos(ang), sin(ang)) * w * px;
		m = max(m, texture(tex, uv + o).a);
	}
	return m;
}

void fragment() {
	vec4 c = texture(TEXTURE, UV);
	vec2 px = TEXTURE_PIXEL_SIZE;

	float lockF = max(zoneFactor(UV, lock_uv), zoneFactor(UV, lock_uv2));
	float hovF = max(zoneFactor(UV, hover_uv), zoneFactor(UV, hover_uv2));

	float w = line_width * (1.0 + lockF * 1.8 + hovF * 0.6);
	float ring = max(sampleRing(TEXTURE, UV, px, w), sampleRing(TEXTURE, UV, px, w * 0.5));
	float edge = clamp(ring - c.a, 0.0, 1.0);

	float bright = 0.4 + 0.4 * hovF + (0.7 + 0.3 * pulse) * lockF;
	vec4 outlineCol = vec4(line_color.rgb * min(bright, 1.4), edge * clamp(bright + 0.25, 0.0, 1.0));

	float lum = dot(c.rgb, vec3(0.3, 0.59, 0.11));
	vec3 body = mix(c.rgb, vec3(lum) * line_color.rgb, 0.4) * 0.85;
	body += line_color.rgb * (lockF * (0.22 + 0.12 * pulse) + hovF * 0.1);

	COLOR = mix(outlineCol, vec4(body, 1.0), c.a);
}
