extends Reference

# B.R.A.T.S. - Ballistic Reflex-Assisted Targeting System.
#
# Shared rules for the called-shot mode. Everything that needs zone data,
# hit chances or zone effects goes through here: the targeting panel
# (BRATSPanel.gd), the fight screen hook (BRATSFightScene.gd), the player's
# called-shot wrapper attack and the enemy called-shot attack.
#
# How a player called shot resolves (see GunModBRATSCalledShot.gd):
#  1. The chosen physical attack runs exactly like it normally would - its own
#     miss/dodge roll, ammo, stamina, damage.
#  2. Separately, B.R.A.T.S. rolls "did it land on the called zone?" (the %
#     shown on the panel). Landed = zone damage mult + zone effect. Not landed
#     = glancing hit at GlanceDamageMult, no effect.
#  3. The zone's stamina cost is paid on top of the attack's own cost.

const SkillID = "GunModPrecision"

const PerkBRATS = "GunModPerkBRATS"
const PerkSteadyHands = "GunModPerkSteadyHands"
const PerkKneecapper = "GunModPerkKneecapper"
const PerkButterfingers = "GunModPerkButterfingers"
const PerkCheapShot = "GunModPerkCheapShot"
const PerkHeartbreaker = "GunModPerkHeartbreaker"
const PerkBullseye = "GunModPerkBullseye"
const PerkEconomy = "GunModPerkEconomyOfMotion"
const PerkCalledIt = "GunModPerkCalledIt"

const EffectCrippledArm = "GunModCrippledArm"
const EffectCrippledLeg = "GunModCrippledLeg"
const EffectTenderChest = "GunModTenderChest"
const EffectZoneDamage = "GunModCalledShotDamageMod"

const PlayerAttackID = "GunModBRATSCalledShot"
const EnemyAttackID = "GunModBRATSEnemyCalledShot"

const GlanceDamageMult = 0.5

const Head = "head"
const Eyes = "eyes"
const Chest = "chest"
const Torso = "torso"
const Arms = "arms"
const Groin = "groin"
const Legs = "legs"

const ZoneOrder = [Head, Eyes, Chest, Torso, Arms, Groin, Legs]

# base: zone placement chance (0-100) before bonuses
# dmg: damage multiplier when the called shot lands
# stamina: extra stamina cost on top of the attack's own
# crit: base crit chance (0-100) when the zone is hit
const Zones = {
	Head: {name = "Head", base = 50, dmg = 1.35, stamina = 12, crit = 10},
	Eyes: {name = "Eyes", base = 20, dmg = 1.1, stamina = 18, crit = 25},
	Chest: {name = "Chest", base = 65, dmg = 0.9, stamina = 8, crit = 5},
	Torso: {name = "Torso", base = 85, dmg = 1.0, stamina = 5, crit = 5},
	Arms: {name = "Arms", base = 60, dmg = 0.8, stamina = 8, crit = 5},
	Groin: {name = "Groin", base = 35, dmg = 1.3, stamina = 12, crit = 10},
	Legs: {name = "Legs", base = 65, dmg = 0.8, stamina = 8, crit = 5},
}

# How often the enemy AI picks each zone when it aims at the player
const EnemyZoneWeights = [
	[Torso, 30.0], [Legs, 20.0], [Arms, 15.0], [Chest, 15.0], [Head, 12.0], [Groin, 5.0], [Eyes, 3.0],
]

static func getZoneName(zone:String) -> String:
	if(!Zones.has(zone)):
		return "?"
	return Zones[zone]["name"]

static func hasHeadProtection(target) -> bool:
	if(target == null):
		return false
	var inv = target.getInventory()
	if(!inv.hasSlotEquipped(InventorySlot.Eyes)):
		return false
	var item = inv.getEquippedItem(InventorySlot.Eyes)
	if(item == null):
		return false
	var hides = item.getHidesParts(target)
	if(hides == null):
		return false
	return hides.has(BodypartSlot.Head)

static func getPrecisionLevel(attacker) -> int:
	if(attacker == null):
		return 0
	if(attacker.isPlayer()):
		var skill = attacker.getSkillsHolder().getSkill(SkillID)
		if(skill == null):
			return 0
		return skill.getLevel()
	# NPCs don't level skills; use their combat level as a stand-in
	return int(attacker.getLevel() / 2)

# Final zone placement chance, 0-100. This is the number shown on the panel.
static func getZoneChance(attacker, target, zone:String, calledItFree:bool = false) -> int:
	if(!Zones.has(zone)):
		return 0
	if(calledItFree):
		return 100
	var chance = float(Zones[zone]["base"])
	chance += min(getPrecisionLevel(attacker), 20)
	if(attacker != null && attacker.isPlayer() && attacker.hasPerk(PerkSteadyHands)):
		chance += 10.0
	if(attacker != null && (attacker.isBlindfolded() || attacker.hasEffect(StatusEffect.Blindness))):
		chance *= 0.5
	if(target != null):
		if(target.hasEffect(StatusEffect.Collapsed)):
			chance += 20.0
		if(target.hasEffect(StatusEffect.Stunned)):
			chance += 15.0
		if(target.hasEffect(EffectCrippledLeg)):
			chance += 5.0
	return int(clamp(round(chance), 5, 95))

static func getStaminaCost(attacker, zone:String) -> int:
	if(!Zones.has(zone)):
		return 0
	var cost = int(Zones[zone]["stamina"])
	if(attacker != null && attacker.isPlayer() && attacker.hasPerk(PerkEconomy)):
		cost = int(ceil(cost / 2.0))
	return cost

static func getCritChance(attacker, zone:String) -> int:
	var crit = int(Zones[zone]["crit"])
	if(attacker != null && attacker.isPlayer() && attacker.hasPerk(PerkBullseye) && (zone == Head || zone == Eyes)):
		crit += 15
	return crit

static func getCritMult(attacker) -> float:
	if(attacker != null && attacker.isPlayer() && attacker.hasPerk(PerkBullseye)):
		return 2.0
	return 1.5

static func getZoneEffectDesc(attacker, target, zone:String) -> String:
	var isPC = (attacker != null && attacker.isPlayer())
	if(zone == Head):
		if(hasHeadProtection(target)):
			return "Heavy damage. Helmet makes a stun unlikely."
		return "Heavy damage, may stun."
	if(zone == Eyes):
		return "Blinds for 3 turns. Big crit chance."
	if(zone == Chest):
		var t = "Knocks the wind out (stamina loss)."
		if(target != null && target.hasNonFlatBreasts()):
			t += " Leaves their breasts tender: they dodge worse and take more lust damage."
		if(isPC && attacker.hasPerk(PerkHeartbreaker)):
			t += " (Heartbreaker: doubled)"
		return t
	if(zone == Torso):
		return "Solid damage, best bleed chance."
	if(zone == Arms):
		var t = "Cripples an arm: weaker attacks and worse aim for 3 turns."
		if(isPC && attacker.hasPerk(PerkButterfingers)):
			t += " (Butterfingers: stronger, lasts 5)"
		return t
	if(zone == Groin):
		var t = "Low Blow: huge pain, may stun."
		if(isPC && attacker.hasPerk(PerkCheapShot)):
			t += " (Cheap Shot: stun almost certain)"
		return t
	if(zone == Legs):
		var t = "Cripples a leg: can barely dodge, may collapse."
		if(isPC && attacker.hasPerk(PerkKneecapper)):
			t += " (Kneecapper: collapse far more likely)"
		return t
	return ""

# Applies the zone's lasting effect after a landed called shot.
# Returns extra text to append to the attack message.
static func applyZoneEffect(attacker, target, zone:String) -> String:
	# Text uses the player-aware tags ({receiver.You}/{receiver.Your}/youVerb)
	# since enemies aim at the player with the same effects.
	var isPC = (attacker != null && attacker.isPlayer())
	var text = ""
	var turns = 3
	var stunChance = 0
	if(zone == Head):
		stunChance = 35
		if(hasHeadProtection(target)):
			stunChance = 10
			text += " The hit rings off {receiver.your} helmet."
		else:
			text += " {receiver.Your} head snaps back."
		if(RNG.chance(stunChance) && target.addEffect(StatusEffect.Stunned, [1])):
			text += " [b]{receiver.You} {receiver.youAreHeIs} stunned![/b]"
	elif(zone == Eyes):
		text += " {receiver.You} {receiver.youVerb('reel')} back, clutching {receiver.yourHis} face."
		if(target.addEffect(StatusEffect.Blindness, [3])):
			text += " [b]{receiver.You} {receiver.youAreHeIs} blinded![/b]"
	elif(zone == Chest):
		var drain = 15
		if(isPC && attacker.hasPerk(PerkHeartbreaker)):
			drain = 30
		target.addStamina(-drain)
		if(target.hasNonFlatBreasts()):
			text += " It lands square on {receiver.your} chest and {receiver.yourHis} breasts bounce hard from the impact. {receiver.You} {receiver.youVerb('wheeze')} and {receiver.youVerb('fold')} an arm over them."
			if(isPC && attacker.hasPerk(PerkHeartbreaker)):
				turns = 6
			if(target.addEffect(EffectTenderChest, [turns])):
				text += " [b]{receiver.Your} chest is tender![/b]"
		else:
			text += " It lands square on {receiver.your} chest and knocks the air out of {receiver.youHim}."
		text += " [b]{receiver.You} {receiver.youVerb('lose')} "+str(drain)+" stamina![/b]"
	elif(zone == Torso):
		if(RNG.chance(60) && target.addEffect(StatusEffect.Bleeding)):
			text += " [b]{receiver.You} {receiver.youVerb('start')} bleeding![/b]"
	elif(zone == Arms):
		var strong = false
		if(isPC && attacker.hasPerk(PerkButterfingers)):
			turns = 5
			strong = true
		text += " {receiver.Your} arm jerks and goes limp."
		if(target.addEffect(EffectCrippledArm, [turns, strong])):
			text += " [b]{receiver.Your} arm is crippled![/b]"
	elif(zone == Groin):
		text += " {receiver.You} {receiver.youVerb('double')} over with a strangled noise."
		stunChance = 50
		if(isPC && attacker.hasPerk(PerkCheapShot)):
			stunChance = 90
		if(RNG.chance(stunChance) && target.addEffect(StatusEffect.Stunned, [1])):
			text += " [b]{receiver.You} {receiver.youAreHeIs} stunned![/b]"
	elif(zone == Legs):
		var collapseChance = 30
		if(isPC && attacker.hasPerk(PerkKneecapper)):
			turns = 5
			collapseChance = 60
		text += " {receiver.Your} knee buckles."
		if(target.addEffect(EffectCrippledLeg, [turns])):
			text += " [b]{receiver.Your} leg is crippled![/b]"
		if(!target.hasEffect(StatusEffect.Collapsed) && RNG.chance(collapseChance)):
			target.addEffect(StatusEffect.Collapsed)
			text += " [b]{receiver.You} {receiver.youVerb('go', 'goes')} down![/b]"
	return text

static func pickEnemyZone() -> String:
	return RNG.pickWeightedPairs(EnemyZoneWeights)

# The Physical attacks the player could throw through B.R.A.T.S. right now.
# Returns attackData dictionaries in the same format FightScene uses.
static func getUsableInnerAttacks(pc, enemy, battleName) -> Array:
	var result = []
	for attackDataOrString in pc.getAttacks(battleName):
		var attackData:Dictionary
		if(attackDataOrString is String):
			attackData = {"attackID": attackDataOrString}
		else:
			attackData = attackDataOrString
		var attack = GlobalRegistry.getAttack(attackData["attackID"])
		if(attack == null):
			continue
		if(attack.category != Attack.Category.Physical):
			continue
		if(attack.id == PlayerAttackID):
			continue
		result.append({
			attackData = attackData,
			attack = attack,
			canUse = attack.canUse(pc, enemy, attackData),
		})
	return result

static func getInnerAttackLabel(entry:Dictionary) -> String:
	var attack = entry["attack"]
	var attackData = entry["attackData"]
	var label = attack.getVisibleName(attackData)
	var item = attack.getItem(attackData)
	if(item != null):
		label = item.getVisibleName()+": "+label
		if(item.has_method("getCharges")):
			label += " ("+str(item.getCharges())+")"
	return label

# The rifle model a GunMod gun-carrying NPC holds, going by its attack list,
# or "" if it doesn't carry one of GunMod's rifles.
static func getRifleModel(character) -> String:
	if(character == null):
		return ""
	var attacks = character.getAttacks("")
	if(attacks == null):
		return ""
	for attackID in attacks:
		var s = str(attackID)
		if(s.begins_with("GunModEnergyRifle")):
			return "res://Modules/GunMod/Models/EnergyRifle.tscn"
		if(s.begins_with("GunModServiceRifle")):
			return "res://Modules/GunMod/Models/ServiceRifle.tscn"
		if(s.begins_with("GunModMarauderRifle")):
			return "res://Modules/GunMod/Models/MarauderRifle.tscn"
	return ""
