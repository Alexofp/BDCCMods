extends PerkBase

func _init():
	id = "GunModPerkBRATS"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "B.R.A.T.S."

func getVisibleDescription():
	return "Ballistic Reflex-Assisted Targeting System. Adds a B.R.A.T.S. button to every fight: lock onto a body part and throw any physical attack at it. Each zone has its own hit chance, stamina cost and effect, from crippled legs to blinded eyes."

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/StatusEffects/crosshair.png"

func getRequiredPerks():
	return []

# Free, so B.R.A.T.S. can be unlocked as soon as the tree is opened (the
# Precision skill is visible from the start, but at level 0 it has 0 points)
func getCost():
	return 0
