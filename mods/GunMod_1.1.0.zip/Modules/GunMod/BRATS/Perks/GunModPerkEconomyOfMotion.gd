extends PerkBase

func _init():
	id = "GunModPerkEconomyOfMotion"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Economy of Motion"

func getVisibleDescription():
	return "Lining up a called shot costs half as much stamina."

func getSkillTier():
	return 3

func getPicture():
	return "res://Images/Perks/speedometer.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
