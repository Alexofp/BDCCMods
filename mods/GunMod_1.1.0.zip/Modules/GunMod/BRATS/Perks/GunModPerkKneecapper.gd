extends PerkBase

func _init():
	id = "GunModPerkKneecapper"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Kneecapper"

func getVisibleDescription():
	return "Leg shots cripple for 5 turns instead of 3 and knock the target down twice as often."

func getSkillTier():
	return 1

func getPicture():
	return "res://Images/StatusEffects/kneeling.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
