extends PerkBase

func _init():
	id = "GunModPerkBullseye"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Bullseye"

func getVisibleDescription():
	return "Head and eye shots crit 15% more often, and every called-shot crit does double damage instead of 1.5x."

func getSkillTier():
	return 3

func getPicture():
	return "res://Images/Perks/warlock-eye.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
