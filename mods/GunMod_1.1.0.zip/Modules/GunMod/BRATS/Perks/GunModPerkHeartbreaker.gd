extends PerkBase

func _init():
	id = "GunModPerkHeartbreaker"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Heartbreaker"

func getVisibleDescription():
	return "Chest shots knock twice as much stamina out of the target, and a tender chest lasts twice as long."

func getSkillTier():
	return 2

func getPicture():
	return "res://Images/StatusEffects/breasts-pain.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
