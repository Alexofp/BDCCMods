extends PerkBase

func _init():
	id = "GunModPerkSteadyHands"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Steady Hands"

func getVisibleDescription():
	return "Your called shots are 10% more likely to land on the zone you picked."

func getSkillTier():
	return 1

func getPicture():
	return "res://Images/Perks/augmentation.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
