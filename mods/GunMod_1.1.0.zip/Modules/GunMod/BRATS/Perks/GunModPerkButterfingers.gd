extends PerkBase

func _init():
	id = "GunModPerkButterfingers"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Butterfingers"

func getVisibleDescription():
	return "Arm shots cripple for 5 turns instead of 3, and the crippled arm hits even weaker and aims even worse."

func getSkillTier():
	return 2

func getPicture():
	return "res://Images/Perks/grasping-claws.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
