extends PerkBase

func _init():
	id = "GunModPerkCalledIt"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Called It"

func getVisibleDescription():
	return "Your first B.R.A.T.S. shot in every fight is guaranteed to land on the zone you picked. The attack itself can still miss or be dodged."

func getSkillTier():
	return 4

func getPicture():
	return "res://Images/Perks/badge.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
