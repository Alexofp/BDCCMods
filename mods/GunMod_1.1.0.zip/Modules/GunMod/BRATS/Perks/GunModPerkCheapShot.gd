extends PerkBase

func _init():
	id = "GunModPerkCheapShot"
	skillGroup = "GunModPrecision"
	dungeonWeight = 0.0

func getVisibleName():
	return "Cheap Shot"

func getVisibleDescription():
	return "Groin shots stun the target almost every time."

func getSkillTier():
	return 2

func getPicture():
	return "res://Images/StatusEffects/knockout.png"

func getRequiredPerks():
	return ["GunModPerkBRATS"]
