extends SkillBase

# Precision - the B.R.A.T.S. perk tree. Levels from every physical attack the
# player makes in any fight (BRATSFightScene.doPlayerAttack), more from guns,
# most from B.R.A.T.S. called shots. The first level comes fast so the root
# perk (B.R.A.T.S. itself) unlocks early.

func _init():
	id = "GunModPrecision"

func getVisibleName():
	return "Precision"

func getVisibleDescription():
	return "How well you can put a hit exactly where you want it. Unlocks and improves B.R.A.T.S. called shots."

# Show the tree from the start (new games and old saves, see Player.gd) so
# the player can find B.R.A.T.S. before ever earning Precision XP.
static func alwaysVisible() -> bool:
	return true

static func getRequiredExperience(_level) -> int:
	if(_level <= 0):
		return 40
	return 100 + _level * 10 + int(sqrt(max(0,_level))) * 10

func getRequiredExperienceNextLevel():
	return getRequiredExperience(level)

func getPerkTiers():
	return [
		[0],
		[2],
		[5],
		[9],
		[14],
	]
