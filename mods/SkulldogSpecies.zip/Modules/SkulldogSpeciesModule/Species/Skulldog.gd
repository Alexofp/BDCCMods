extends Species

func _init():
	id = "skulldog"
	
func getVisibleName():
	return "Skulldog"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "caninetail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Exciting and interactive"

func getDefaultHead(_gender):
	return RNG.pick([
		"skulldogHeadA",
		"skulldogHeadB",
		"skulldogHeadC",
	])

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "canineears"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "caninepenis"
	else:
		return null

# Allows to pick these bodyparts even if they're from another species. Useful for mods
func getAllowedBodyparts():
	return [
		# ears
		"canineears",
		"canineears2",
		"canineears2tribal",
		"canineears3",
		"fennecears",
		# tails
		"caninetail",
		"fennectail",
		"foxtail",
		"huskytail",
	]

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]

# How often is this species will show up in procedural encounters. 0 = never, 0-1 = less often, 1 = default chance, >1 = more often
func npcGenerationWeight():
	if(!isPlayable() || id == "error"):
		return 0.0
	return 0.2

func supportsMane():
	return true
