extends Module
class_name SkulldogSpeciesModule

func _init():
	id = "SkulldogSpeciesModule"
	author = "keerifox"

	bodyparts = [
		"res://Modules/SkulldogSpeciesModule/Player/Bodyparts/Head/SkulldogHeadA.gd",
		"res://Modules/SkulldogSpeciesModule/Player/Bodyparts/Head/SkulldogHeadB.gd",
		"res://Modules/SkulldogSpeciesModule/Player/Bodyparts/Head/SkulldogHeadC.gd",
	]
	species = [
		"res://Modules/SkulldogSpeciesModule/Species/Skulldog.gd",
	]
