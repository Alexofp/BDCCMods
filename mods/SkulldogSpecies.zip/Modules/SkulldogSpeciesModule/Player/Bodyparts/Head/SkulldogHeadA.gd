extends BodypartHead

func _init():
	visibleName = "skulldog head A"
	id = "skulldogHeadA"

func getCompatibleSpecies():
	return ["skulldog"]

func getDoll3DScene():
	return "res://Modules/SkulldogSpeciesModule/Player/Player3D/Parts/Head/SkulldogHeadA/SkulldogHeadA.tscn"

func getHeadLength():
	return 0.7
