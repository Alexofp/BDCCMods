extends BodypartHead

func _init():
	visibleName = "skulldog head C"
	id = "skulldogHeadC"

func getCompatibleSpecies():
	return ["skulldog"]

func getDoll3DScene():
	return "res://Modules/SkulldogSpeciesModule/Player/Player3D/Parts/Head/SkulldogHeadC/SkulldogHeadC.tscn"

func getHeadLength():
	return 0.7
