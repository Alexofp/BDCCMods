extends BodypartHead

func _init():
	visibleName = "skulldog head B"
	id = "skulldogHeadB"

func getCompatibleSpecies():
	return ["skulldog"]

func getDoll3DScene():
	return "res://Modules/SkulldogSpeciesModule/Player/Player3D/Parts/Head/SkulldogHeadB/SkulldogHeadB.tscn"

func getHeadLength():
	return 0.7
