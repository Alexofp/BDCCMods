extends Module



func _init():
	id = "MorePoses"
	author = "bringulbangul"
	scenes = []
	events = []
	gameExtenders = []
	bodyparts = []
	sexActivities = [
		"res://Modules/MorePosesModule/SexOralMore.gd",
		"res://Modules/MorePosesModule/SexVaginalOnAllFoursMore.gd",
	]
