extends SceneBase

func _init():
	sceneID = "testScene"
	
func _run():
	if(state == ""):
		saynn(GlobalRegistry.getModule("ForemanModule").sceneError)
		saynn(GlobalRegistry.getModule("ForemanModule").stateError)
		saynn(GlobalRegistry.getModule("ForemanModule").lineError)
		addButton("Done Test", "End The Scene", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
