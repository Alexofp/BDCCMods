extends Module

const sceneError = "[say=foreman]Hi, I'm the author of the no futa mod. If you're seeing this scene that means either you or I did something wrong (or something right)[/say]"
const stateError = "[say=foreman]Hi, I'm the author of the no futa mod. If you're seeing this state that means either you or I did something wrong (or something right)[/say]"
const lineError = "[say=foreman]Hi, I'm the author of the no futa mod. If you're seeing this that means either you or I did something wrong (or something right)[/say]"

func getFlags():
	return {
		"Error Scene Message": flag(FlagType.Text),
		"Error State Message": flag(FlagType.Text),
		"Error Line Message": flag(FlagType.Text),
	}

func _init():
	id = "ForemanModule"
	author = "Foreman"
	
	characters = [
		"res://Modules/ForemanModule/ForemanCharater.gd",
	]
	
	scenes = [
		"res://Modules/ForemanModule/testScene.gd"
	]
