extends Character


func _init():
	id = "foreman"
	npcCharacterType = CharacterType.Inmate
	
	pickedSkin = "HumanSkin"
	pickedSkinRColor=Color("c69e50")
	pickedSkinGColor=Color("a38341")
	pickedSkinBColor=Color("a36d00")
	
func _getName():
	return "Foreman"

func getGender():
	return Gender.Male

func getSpecies():
	return ["human"]

func getChatColor():
	return '#19FF00'

func getThickness() -> int:
	return 50

func getFemininity() -> int:
	return 00

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanoldhead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanears"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthroarms"))
	var breasts = GlobalRegistry.createBodypart("malebreasts")
	breasts.size = -1
	giveBodypartUnlessSame(breasts)
	var penis = GlobalRegistry.createBodypart("humanpenis")
	penis.lengthCM = 14
	penis.ballsScale = 1
	giveBodypartUnlessSame(penis)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("plantilegs"))

func getDefaultEquipment():
	return ["inmatecollar", "inmateuniform", "sportyBriefs"]
