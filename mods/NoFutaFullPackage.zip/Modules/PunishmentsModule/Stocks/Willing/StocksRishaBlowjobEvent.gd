#Modified by Foreman
extends EventBase

func _init():
	id = "StocksRishaBlowjobEvent"

func registerTriggers(es):
	es.addTrigger(self, "StocksWillingSex")

func react(_triggerID, _args):
	if getCharacter("risha").hasPenis:
		runScene("StocksRishaBlowjob")
	return true

func getPriority():
	return 10

func getSceneCreator():
	return .getSceneCreator()+", modified by Foreman"
