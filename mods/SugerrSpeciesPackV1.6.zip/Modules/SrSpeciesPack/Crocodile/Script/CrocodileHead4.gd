extends BodypartHead

func _init():
	visibleName = "crocodile head 4"
	id = "sugerrcrocodilehead4"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileHead4/CrocodileHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) Art by TheGaltor"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
