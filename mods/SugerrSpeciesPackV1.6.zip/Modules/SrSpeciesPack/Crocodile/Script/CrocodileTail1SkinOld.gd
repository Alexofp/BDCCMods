extends BodypartTail

func _init():
	visibleName = "crocodile tail (skin) Old"
	id = "sugerrcrocodiletailskin"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "crocodile"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileTail1Old/CrocodileTailSkin.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) Does not generate on NPCs"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
