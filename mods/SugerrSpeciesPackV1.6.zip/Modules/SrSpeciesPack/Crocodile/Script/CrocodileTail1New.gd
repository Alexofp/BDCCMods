extends BodypartTail

func _init():
	visibleName = "crocodile tail 1"
	id = "sugerrcrocodiletail3"

func getCompatibleSpecies():
	return ["sugerrcrocodile", Species.Dragon]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "crocodile"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileTail1New/CrocodileTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
