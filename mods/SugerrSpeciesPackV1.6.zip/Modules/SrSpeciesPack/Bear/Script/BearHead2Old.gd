extends BodypartHead

func _init():
	visibleName = "bear head 2 Old"
	id = "sugerrbearhead2"

func getCompatibleSpecies():
	return ["sugerrbear"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearHead2Old/BearHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) Does not generate on NPCs"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
