extends Species

func _init():
	id = "sugerrbear"

func isPlayable():
	return true

func getVisibleName():
	return "Bear"

func getVisibleDescription():
	return "Bear-y big"

func getAllowedBodyparts():
	return ["shorttail"]

func getDefaultLegs(_gender):
		return "sugerrbearlegs"

func getDefaultTail(_gender):
	return "sugerrbeartail1"

func getDefaultHead(_gender):
	return "sugerrbearhead5"

func getDefaultArms(_gender):
		return "sugerrbeararms"

func getDefaultEars(_gender):
	return "sugerrbearears1"
	
func getDefaultBody(_gender):
		return "sugerrbearbody"
	
func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "sugerrmalebearbreasts"
	else: 
		return "sugerrbearbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else: 
			return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]
