extends SceneBase

var room_id = ""
var graffiti = []
var selected_player_nick = ""

func _init():
	sceneID = "AsyncGraffitiScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		room_id = _args[0]

	if(_args.size() > 1 && _args[1] is Array):
		graffiti = _args[1]

func safe_text(text) -> String:
	return str(text).replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace("\"", "'")

func color_to_bbcode(style_color:String) -> String:
	if(style_color == "gold"):
		return "#ffd700"
	if(style_color == "red"):
		return "#ff4444"
	if(style_color == "green"):
		return "#44ff44"
	if(style_color == "blue"):
		return "#66aaff"
	if(style_color == "yellow"):
		return "#ffff66"
	if(style_color == "black"):
		return "#111111"
	return "#ffffff"

func font_to_bbcode(style_font:String) -> String:
	if(style_font == "mono"):
		return "res://Fonts/normalconsolefont.tres"
	if(style_font == "serif"):
		return "res://Fonts/smallconsolefont.tres"
	if(style_font == "scratch"):
		return "res://Fonts/BodyWritingsFont.tres"
	return ""

func is_doggo(entry:Dictionary) -> bool:
	return get_player_nick(entry) == "Doggo"

func format_message(message:String, entry:Dictionary) -> String:
	var text = safe_text(message)

	var style_color = str(entry.get("style_color", "white"))
	if(is_doggo(entry)):
		style_color = "gold"

	var style_font = str(entry.get("style_font", "default"))
	var style_bold = bool(entry.get("style_bold", false))
	var style_italic = bool(entry.get("style_italic", false))

	text = "[color=" + color_to_bbcode(style_color) + "]" + text + "[/color]"

	var font_path = font_to_bbcode(style_font)
	if(font_path != ""):
		text = "[font=" + font_path + "]" + text + "[/font]"

	if(style_bold):
		text = "[b]" + text + "[/b]"
	if(style_italic):
		text = "[i]" + text + "[/i]"

	return text

func parse_supabase_time(created_at:String) -> int:
	if(created_at.length() < 19):
		return 0

	var dt = {
		"year": int(created_at.substr(0, 4)),
		"month": int(created_at.substr(5, 2)),
		"day": int(created_at.substr(8, 2)),
		"hour": int(created_at.substr(11, 2)),
		"minute": int(created_at.substr(14, 2)),
		"second": int(created_at.substr(17, 2)),
	}

	return OS.get_unix_time_from_datetime(dt)

func unit_text(amount:int, singular:String, plural:String) -> String:
	if(amount == 1):
		return "1 " + singular
	return str(amount) + " " + plural

func time_ago(created_at:String) -> String:
	var then_time = parse_supabase_time(created_at)
	if(then_time <= 0):
		return created_at

	var diff = max(0, OS.get_unix_time() - then_time)

	if(diff < 60):
		return "just now"

	var minutes = int(diff / 60)
	if(minutes < 60):
		return unit_text(minutes, "minute", "minutes") + " ago"

	var hours = int(minutes / 60)
	var rem_minutes = minutes % 60
	if(hours < 24):
		if(rem_minutes > 0):
			return unit_text(hours, "hour", "hours") + " and " + unit_text(rem_minutes, "minute", "minutes") + " ago"
		return unit_text(hours, "hour", "hours") + " ago"

	var days = int(hours / 24)
	var rem_hours = hours % 24
	if(rem_hours > 0):
		return unit_text(days, "day", "days") + " and " + unit_text(rem_hours, "hour", "hours") + " ago"
	return unit_text(days, "day", "days") + " ago"

func get_player_nick(entry:Dictionary) -> String:
	return safe_text(entry.get("player_nick", entry.get("nick", "unknown")))

func get_unique_player_nicks() -> Array:
	var result = []

	for entry in graffiti:
		var player_nick = get_player_nick(entry)
		if(player_nick == ""):
			player_nick = "unknown"

		if(!(player_nick in result)):
			result.append(player_nick)

	return result

func get_graffiti_by_player(player_nick:String) -> Array:
	var result = []

	for entry in graffiti:
		if(get_player_nick(entry) == player_nick):
			result.append(entry)

	return result

func player_nick_label(entry:Dictionary) -> String:
	var player_nick = get_player_nick(entry)
	if(is_doggo(entry)):
		return "[color=#ffd700][b]" + player_nick + "[/b][/color]"
	return "[b]" + player_nick + "[/b]"

func show_graffiti_entry(entry:Dictionary):
	var character_name = safe_text(entry.get("character_name", "Unknown character"))
	var message = str(entry.get("message", ""))
	var created_at = str(entry.get("created_at", ""))

	saynn(player_nick_label(entry) + " left a graffiti")
	saynn("[b]" + character_name.to_upper() + " WROTE:[/b]")
	saynn("\"" + format_message(message, entry) + "\"")
	saynn("[i]" + time_ago(created_at) + "[/i]")
	saynn("")

func _run():
	if(room_id != ""):
		aimCameraAndSetLocName(room_id)

	if(state == ""):
		saynn("There is graffiti in this room.")

		var player_nicks = get_unique_player_nicks()
		if(player_nicks.size() <= 0):
			saynn("[i]There is no graffiti here yet.[/i]")
			addButton("Back", "Stop looking", "endthescene")
			return

		saynn("Pick whose graffiti you want to read:")

		for player_nick in player_nicks:
			var count = get_graffiti_by_player(player_nick).size()
			addButton(player_nick, "Read graffiti left by " + player_nick + " (" + str(count) + ")", "pick_player", [player_nick])

		addButton("Back", "Stop looking", "endthescene")

	if(state == "player"):
		var entries = get_graffiti_by_player(selected_player_nick)

		saynn("Graffiti left by [b]" + safe_text(selected_player_nick) + "[/b]:")

		if(entries.size() <= 0):
			saynn("[i]No graffiti found.[/i]")
		else:
			for entry in entries:
				show_graffiti_entry(entry)

		addButton("Back", "Return to graffiti list", "")
		addButton("Leave", "Stop looking", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "pick_player"):
		selected_player_nick = _args[0]
		setState("player")
		return

	setState(_action)
