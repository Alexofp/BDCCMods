extends "res://Scenes/SceneBase.gd"

const LocalSettings = preload("res://Modules/AsyncGraffiti/GraffitiLocalSettings.gd")
const APIClass = preload("res://Modules/AsyncGraffiti/GraffitiAPI.gd")

const DOGGO_COLOR = "#ffd700"

var room_id:String = ""
var graffiti:Array = []

var player_page:int = 0
var selected_player:String = ""
var profile_nick:String = ""
var profile_data:Dictionary = {}

var result_text:String = ""
var is_busy:bool = false

const PLAYERS_PER_PAGE = 10

func _init():
	sceneID = "AsyncGraffitiScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		room_id = str(_args[0])

	if(_args.size() > 1 && _args[1] is Array):
		graffiti = _args[1]

func _run():
	if(state == ""):
		show_player_list()

	if(state == "player"):
		show_player_graffiti()

	if(state == "profile"):
		show_profile()

func show_player_list():
	saynn("[b]Graffiti in this room[/b]")

	if(result_text != ""):
		profile_say("[i]" + safe_text(result_text) + "[/i]")

	if(is_drug_den_room()):
		saynn("[color=yellow]Drug Den rooms are randomly generated, so leaving graffiti here is disabled for now.[/color]")
		addDisabledButton("Leave graffiti", "Drug Den rooms are randomly generated.")
	else:
		addButton("Leave graffiti", "Leave graffiti in this room", "leave_graffiti")

	if(get_my_nick() != ""):
		addButton("My profile", "See your Async Graffiti profile", "my_profile")
	else:
		addDisabledButton("My profile", "You need to register a nick first.")

	addButton("Leaderboards", "See Async Graffiti leaderboards", "leaderboards")

	var nicks = get_unique_player_nicks()

	if(nicks.empty()):
		saynn("There is no graffiti here.")
	else:
		saynn("Pick whose graffiti you want to view:")

	var start_index = player_page * PLAYERS_PER_PAGE
	var end_index = min(start_index + PLAYERS_PER_PAGE, nicks.size())

	for i in range(start_index, end_index):
		var nick = nicks[i]
		var count = get_graffiti_count_for_player(nick)
		addButton(nick + " (" + str(count) + ")", "View graffiti left by " + nick, "pick_player", [nick])

	if(player_page > 0):
		addButton("Previous", "Previous page", "prev_page")

	if(end_index < nicks.size()):
		addButton("Next", "Next page", "next_page")

	addButton("Back", "Close graffiti", "endthescene")

func show_player_graffiti():
	saynn("[b]Graffiti by " + nick_label(selected_player) + "[/b]")

	if(result_text != ""):
		saynn("[i]" + safe_text(result_text) + "[/i]")

	var shown:int = 0

	for i in range(graffiti.size()):
		var entry = graffiti[i]
		if(get_player_nick(entry) != selected_player):
			continue

		shown += 1
		show_graffiti_entry(entry, shown)

		if(can_like_entry(entry)):
			addButton("Like #" + str(shown), "Like or unlike this graffiti", "like", [i])
		elif(get_player_nick(entry) == get_my_nick()):
			addDisabledButton("Own #" + str(shown), "You can't like your own graffiti.")
		else:
			addDisabledButton("Like #" + str(shown), "You need to register a nick first.")

	if(shown <= 0):
		saynn("No graffiti found.")

	addButton("See account", "View this player's Async Graffiti profile", "see_account", [selected_player])

	if(!is_drug_den_room()):
		addButton("Leave graffiti", "Leave graffiti in this room", "leave_graffiti")

	addButton("Back", "Back to graffiti list", "back_to_players")
	addButton("Close", "Close graffiti", "endthescene")

func is_doggo_nick(nick:String) -> bool:
	return safe_text(nick) == "Doggo"

func gold_if_doggo(nick:String, text:String) -> String:
	if(is_doggo_nick(nick)):
		return "[color=" + DOGGO_COLOR + "]" + text + "[/color]"

	return text

func nick_label(nick:String) -> String:
	var safe_nick = safe_text(nick)

	if(is_doggo_nick(safe_nick)):
		return "[color=" + DOGGO_COLOR + "][b]" + safe_nick + "[/b][/color]"

	return "[b]" + safe_nick + "[/b]"

func profile_say(text:String):
	saynn(gold_if_doggo(profile_nick, text))

func show_profile():
	profile_say("[b]Async Graffiti player profile[/b]")

	if(result_text != ""):
		profile_say("[i]" + safe_text(result_text) + "[/i]")

	if(profile_data.empty()):
		profile_say("Could not load this profile.")
	else:
		var nick = safe_text(str(profile_data.get("player_nick", profile_nick)))

		profile_say("[b]Nick:[/b] " + nick_label(nick))


		profile_say("[b]Active since:[/b] " + format_date(str(profile_data.get("active_since", ""))))
		profile_say("[b]First graffiti:[/b] " + format_date(str(profile_data.get("first_graffiti_at", ""))))
		profile_say("[b]Last graffiti:[/b] " + format_date(str(profile_data.get("last_graffiti_at", ""))))

		profile_say("[b]Graffiti left:[/b] " + str(profile_data.get("graffiti_count", 0)))
		profile_say("[b]Total likes:[/b] " + str(profile_data.get("total_likes", 0)))
		profile_say("[b]Followers:[/b] " + str(profile_data.get("followers_count", 0)))

	addButton("See followers", "See who follows this player", "open_account_scene", [profile_nick])

	if(profile_nick != get_my_nick() && get_my_nick() != "" && get_my_client_id() != ""):
		addButton("Follow", "Follow this player. Click again to unfollow.", "toggle_follow", [profile_nick])
	elif(profile_nick == get_my_nick()):
		addDisabledButton("Follow", "You can't follow yourself.")
	else:
		addDisabledButton("Follow", "You need to register a nick first.")

	addButton("Back", "Back to graffiti", "back_to_player")
	addButton("Close", "Close graffiti", "endthescene")

func show_graffiti_entry(entry:Dictionary, number:int):
	var text = ""

	text += "[b]#" + str(number) + " - " + player_nick_label(entry) + "[/b]\n"

	var character_name = safe_text(str(entry.get("character_name", "")))
	if(character_name != ""):
		text += "[b]" + character_name + " wrote:[/b]\n"

	text += "\"" + format_message(entry) + "\"\n"

	text += "[i]" + time_ago(str(entry.get("created_at", ""))) + "[/i]"
	text += "\nLikes: " + str(entry.get("like_count", 0))

	saynn(text)

func get_unique_player_nicks() -> Array:
	var result = []
	var seen = {}

	for entry in graffiti:
		var nick = get_player_nick(entry)
		if(nick == ""):
			continue

		if(!seen.has(nick)):
			seen[nick] = true
			result.append(nick)

	return result

func get_graffiti_count_for_player(nick:String) -> int:
	var result:int = 0

	for entry in graffiti:
		if(get_player_nick(entry) == nick):
			result += 1

	return result

func get_player_nick(entry:Dictionary) -> String:
	return safe_text(str(entry.get("player_nick", entry.get("nick", ""))))

func get_my_nick() -> String:
	var settings = LocalSettings.load_settings()
	return safe_text(str(settings.get("nick", "")))

func get_my_client_id() -> String:
	var settings = LocalSettings.load_settings()
	return safe_client_id(str(settings.get("client_id", "")))

func can_like_entry(entry:Dictionary) -> bool:
	if(!entry.has("id")):
		return false

	if(get_my_nick() == "" || get_my_client_id() == ""):
		return false

	if(get_player_nick(entry) == get_my_nick()):
		return false

	return true

func is_doggo(entry:Dictionary) -> bool:
	return get_player_nick(entry) == "Doggo"

func player_nick_label(entry:Dictionary) -> String:
	var nick = safe_text(get_player_nick(entry))

	if(is_doggo(entry)):
		return "[color=" + DOGGO_COLOR + "][b]" + nick + "[/b][/color]"

	return "[b]" + nick + "[/b]"

func format_message(entry:Dictionary) -> String:
	var text = safe_text(str(entry.get("message", "")))

	var color = str(entry.get("style_color", "white"))
	if(is_doggo(entry)):
		color = "gold"

	var result = text

	if(str(entry.get("style_font", "default")) == "mono"):
		result = "[font=res://Fonts/normalconsolefont.tres]" + result + "[/font]"
	elif(str(entry.get("style_font", "default")) == "serif"):
		result = "[font=res://Fonts/smallconsolefont.tres]" + result + "[/font]"
	elif(str(entry.get("style_font", "default")) == "scratch"):
		result = "[font=res://Fonts/BodyWritingsFont.tres]" + result + "[/font]"

	if(bool(entry.get("style_bold", false))):
		result = "[b]" + result + "[/b]"

	if(bool(entry.get("style_italic", false))):
		result = "[i]" + result + "[/i]"

	result = "[color=" + color_to_bbcode(color) + "]" + result + "[/color]"

	return result

func color_to_bbcode(color:String) -> String:
	if(color == "red"):
		return "#ff5555"
	if(color == "green"):
		return "#55ff55"
	if(color == "blue"):
		return "#5599ff"
	if(color == "yellow"):
		return "#ffff55"
	if(color == "black"):
		return "#999999"
	if(color == "gold"):
		return DOGGO_COLOR

	return "#ffffff"

func safe_text(text) -> String:
	var result = str(text)

	result = result.replace("[", "")
	result = result.replace("]", "")
	result = result.replace("{", "")
	result = result.replace("}", "")
	result = result.replace("\"", "'")
	result = result.replace("\\", "")
	result = result.replace("\n", " ")
	result = result.replace("\r", " ")
	result = result.replace("\t", " ")

	result = result.strip_edges()

	if(result.length() > 300):
		result = result.substr(0, 300)

	return result

func safe_client_id(text) -> String:
	var result = str(text)
	var allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-"
	var final_text = ""

	for i in range(result.length()):
		var ch = result.substr(i, 1)
		if(allowed.find(ch) >= 0):
			final_text += ch

	if(final_text.length() > 128):
		final_text = final_text.substr(0, 128)

	return final_text

func is_drug_den_room() -> bool:
	return room_id.begins_with("drugDenRoom")

func time_ago(timestamp:String) -> String:
	var unix_time = parse_timestamp(timestamp)

	if(unix_time <= 0):
		return "unknown time"

	var diff = max(0, OS.get_unix_time() - unix_time)

	if(diff < 60):
		return "just now"

	if(diff < 3600):
		var minutes = int(diff / 60)
		return str(minutes) + " minute" + ("s" if minutes != 1 else "") + " ago"

	if(diff < 86400):
		var hours = int(diff / 3600)
		var minutes_left = int((diff % 3600) / 60)

		if(minutes_left > 0):
			return str(hours) + " hour" + ("s" if hours != 1 else "") + " and " + str(minutes_left) + " minute" + ("s" if minutes_left != 1 else "") + " ago"

		return str(hours) + " hour" + ("s" if hours != 1 else "") + " ago"

	var days = int(diff / 86400)
	var hours_left = int((diff % 86400) / 3600)

	if(hours_left > 0):
		return str(days) + " day" + ("s" if days != 1 else "") + " and " + str(hours_left) + " hour" + ("s" if hours_left != 1 else "") + " ago"

	return str(days) + " day" + ("s" if days != 1 else "") + " ago"

func format_date(timestamp:String) -> String:
	if(timestamp == "" || timestamp == "null"):
		return "unknown"

	var clean = timestamp.replace("T", " ")

	var dot_pos = clean.find(".")
	if(dot_pos >= 0):
		clean = clean.substr(0, dot_pos)

	var plus_pos = clean.find("+")
	if(plus_pos >= 0):
		clean = clean.substr(0, plus_pos)

	clean = clean.replace("Z", "")
	clean = clean.strip_edges()

	if(clean.length() >= 16):
		return clean.substr(0, 16)

	return clean

func parse_timestamp(timestamp:String) -> int:
	if(timestamp == "" || timestamp == "null"):
		return 0

	var clean = timestamp.replace("T", " ")

	var dot_pos = clean.find(".")
	if(dot_pos >= 0):
		clean = clean.substr(0, dot_pos)

	var plus_pos = clean.find("+")
	if(plus_pos >= 0):
		clean = clean.substr(0, plus_pos)

	clean = clean.replace("Z", "")
	clean = clean.strip_edges()

	var parts = clean.split(" ")
	if(parts.size() < 2):
		return 0

	var date_parts = parts[0].split("-")
	var time_parts = parts[1].split(":")

	if(date_parts.size() < 3 || time_parts.size() < 2):
		return 0

	var data = {
		year = int(date_parts[0]),
		month = int(date_parts[1]),
		day = int(date_parts[2]),
		hour = int(time_parts[0]),
		minute = int(time_parts[1]),
		second = int(time_parts[2]) if time_parts.size() > 2 else 0,
	}

	return OS.get_unix_time_from_datetime(data)

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "leave_graffiti"):
		runScene("AsyncGraffitiLeaveScene")
		return

	if(_action == "my_profile"):
		runScene("AsyncGraffitiAccountScene", [get_my_nick()])
		return

	if(_action == "leaderboards"):
		runScene("AsyncGraffitiLeaderboardsScene")
		return

	if(_action == "open_account_scene"):
		runScene("AsyncGraffitiAccountScene", [str(_args[0])])
		return

	if(_action == "pick_player"):
		selected_player = str(_args[0])
		result_text = ""
		state = "player"
		return

	if(_action == "back_to_players"):
		state = ""
		result_text = ""
		return

	if(_action == "back_to_player"):
		state = "player"
		result_text = ""
		return

	if(_action == "next_page"):
		player_page += 1
		return

	if(_action == "prev_page"):
		player_page -= 1
		if(player_page < 0):
			player_page = 0
		return

	if(_action == "like"):
		if(!is_busy):
			var _state = async_toggle_like(int(_args[0]))
		return

	if(_action == "see_account"):
		runScene("AsyncGraffitiAccountScene", [str(_args[0])])
		return

	if(_action == "toggle_follow"):
		if(!is_busy):
			var _state = async_toggle_follow(str(_args[0]))
		return

	setState(_action)

func async_toggle_like(entry_index:int):
	if(entry_index < 0 || entry_index >= graffiti.size()):
		result_text = "Invalid graffiti."
		return

	var entry = graffiti[entry_index]

	if(!can_like_entry(entry)):
		result_text = "You can't like this graffiti."
		return

	is_busy = true
	result_text = "Updating like..."

	var api = APIClass.new()
	add_child(api)

	var response = yield(api.toggle_like_graffiti(str(entry.get("id", "")), get_my_nick(), get_my_client_id()), "completed")
	api.queue_free()

	is_busy = false

	if(response.ok):
		var old_count = int(entry.get("like_count", 0))

		if(response.has("liked") && response["liked"]):
			entry["like_count"] = old_count + 1
			result_text = "Liked."
		else:
			entry["like_count"] = max(0, old_count - 1)
			result_text = "Unliked."

		graffiti[entry_index] = entry
	else:
		result_text = "Could not update like."

	GM.main.reRun()

func async_load_profile(nick:String):
	is_busy = true
	result_text = "Loading profile..."

	var api = APIClass.new()
	add_child(api)

	var data = yield(api.get_profile(nick), "completed")
	api.queue_free()

	is_busy = false

	profile_nick = nick
	profile_data = data
	result_text = ""
	state = "profile"

	GM.main.reRun()

func async_toggle_follow(nick:String):
	if(nick == "" || nick == get_my_nick()):
		result_text = "You can't follow this profile."
		return

	if(get_my_nick() == "" || get_my_client_id() == ""):
		result_text = "You need to register a nick first."
		return

	is_busy = true
	result_text = "Updating follow..."

	var api = APIClass.new()
	add_child(api)

	var response = yield(api.toggle_follow_player(nick, get_my_nick(), get_my_client_id()), "completed")

	if(response.ok):
		profile_data = yield(api.get_profile(nick), "completed")

		if(response.has("following") && response["following"]):
			result_text = "Followed."
		else:
			result_text = "Unfollowed."
	else:
		result_text = "Could not update follow."

	api.queue_free()
	is_busy = false

	GM.main.reRun()
