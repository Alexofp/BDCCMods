extends "res://Scenes/SceneBase.gd"

const APIClass = preload("res://Modules/AsyncGraffiti/GraffitiAPI.gd")

const DOGGO_COLOR = "#ffd700"

var player_likes:Array = []
var top_graffiti:Array = []
var followers:Array = []

var loaded:bool = false
var loading:bool = false
var result_text:String = ""

func _init():
	sceneID = "AsyncGraffitiLeaderboardsScene"

func _run():
	saynn("[b]Async Graffiti leaderboards[/b]")

	if(result_text != ""):
		saynn("[i]" + safe_text(result_text) + "[/i]")

	if(!loaded && !loading):
		loading = true
		result_text = "Loading leaderboards..."

		var _state = async_load_leaderboards()

		saynn("Loading leaderboards...")
		addButton("Back", "Close leaderboards", "endthescene")
		return

	if(!loaded):
		saynn("Loading leaderboards...")
		addButton("Back", "Close leaderboards", "endthescene")
		return

	show_player_likes()
	show_top_graffiti()
	show_followers()

	addButton("Refresh", "Reload leaderboards", "refresh")
	addButton("Back", "Close leaderboards", "endthescene")

func show_player_likes():
	saynn("[b]Most liked players[/b]")

	if(player_likes.empty()):
		saynn("No likes yet.")
		return

	for entry in player_likes:
		var line = "#" + str(entry.get("rank", "?"))
		line += " " + nick_label(str(entry.get("player_nick", "")))
		line += " - " + str(entry.get("total_likes", 0)) + " likes"
		line += ", " + str(entry.get("graffiti_count", 0)) + " graffiti"
		saynn(line)

func show_top_graffiti():
	saynn("[b]Most liked graffiti[/b]")

	if(top_graffiti.empty()):
		saynn("No liked graffiti yet.")
		return

	for entry in top_graffiti:
		var line = "#" + str(entry.get("rank", "?"))
		line += " " + nick_label(str(entry.get("player_nick", "")))
		line += " - " + str(entry.get("like_count", 0)) + " likes"
		line += " | \"" + short_text(str(entry.get("message", "")), 70) + "\""
		saynn(line)

func show_followers():
	saynn("[b]Most followed players[/b]")

	if(followers.empty()):
		saynn("No followers yet.")
		return

	for entry in followers:
		var line = "#" + str(entry.get("rank", "?"))
		line += " " + nick_label(str(entry.get("player_nick", "")))
		line += " - " + str(entry.get("followers_count", 0)) + " followers"
		line += ", " + str(entry.get("total_likes", 0)) + " likes"
		saynn(line)

func is_doggo_nick(nick:String) -> bool:
	return safe_text(nick) == "Doggo"

func nick_label(nick:String) -> String:
	var safe_nick = safe_text(nick)

	if(is_doggo_nick(safe_nick)):
		return "[color=" + DOGGO_COLOR + "][b]" + safe_nick + "[/b][/color]"

	return safe_nick

func safe_text(text) -> String:
	var result = str(text)

	result = result.replace("[", "")
	result = result.replace("]", "")
	result = result.replace("{", "")
	result = result.replace("}", "")
	result = result.replace("\"", "'")
	result = result.replace("\\", "")
	result = result.replace("\n", " ")
	result = result.replace("\r", " ")
	result = result.replace("\t", " ")

	result = result.strip_edges()

	if(result.length() > 300):
		result = result.substr(0, 300)

	return result

func short_text(text:String, limit:int) -> String:
	var result = safe_text(text)

	if(result.length() > limit):
		result = result.substr(0, limit) + "..."

	return result

func async_load_leaderboards():
	var api = APIClass.new()
	add_child(api)

	player_likes = yield(api.get_leaderboard_player_likes(), "completed")
	top_graffiti = yield(api.get_leaderboard_top_graffiti(), "completed")
	followers = yield(api.get_leaderboard_followers(), "completed")

	api.queue_free()

	loaded = true
	loading = false
	result_text = ""

	GM.main.reRun()

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "refresh"):
		loaded = false
		loading = false
		result_text = ""
		return

	setState(_action)
