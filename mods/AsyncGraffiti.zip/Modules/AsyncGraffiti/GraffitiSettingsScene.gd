extends SceneBase

const LocalSettings = preload("res://Modules/AsyncGraffiti/GraffitiLocalSettings.gd")

var result_text = ""

func _init():
	sceneID = "AsyncGraffitiSettingsScene"

func _initScene(_args = []):
	migrate_old_save_flags_to_local_file()

func migrate_old_save_flags_to_local_file():
	var local = LocalSettings.load_settings()
	if(local.get("nick", "") != "" && local.get("client_id", "") != ""):
		return

	var old_nick = getModuleFlag("AsyncGraffiti", "PlayerNick", "")
	var old_client_id = getModuleFlag("AsyncGraffiti", "ClientID", "")

	if(old_nick != "" && old_client_id != ""):
		LocalSettings.save_settings(old_nick, old_client_id)

func get_player_nick() -> String:
	var local = LocalSettings.load_settings()
	return str(local.get("nick", ""))

func get_client_id() -> String:
	var local = LocalSettings.load_settings()
	var client_id = str(local.get("client_id", ""))

	if(client_id != ""):
		return client_id

	client_id = LocalSettings.generate_client_id()
	LocalSettings.save_settings(str(local.get("nick", "")), client_id)

	return client_id

func _run():
	if(state == ""):
		saynn("Async Graffiti settings.")

		var current_nick = get_player_nick()
		if(current_nick == ""):
			saynn("You don't have a player nick yet.")
			saynn("Pick one. It has to be unique.")

			var textBox:LineEdit = addTextbox("player_nick")
			textBox.text = ""
			var _ok = textBox.connect("text_entered", self, "onNickTextBoxEnterPressed")

			addButton("Register nick", "Register this nick in the graffiti database", "register_nick")
		else:
			saynn("Your player nick is:")
			saynn("[b]" + current_nick + "[/b]")

		addButton("Back", "Return", "endthescene")

	if(state == "registering"):
		saynn("[i]Registering nick...[/i]")

	if(state == "done"):
		saynn(result_text)
		addButton("Back", "Return", "endthescene")

func onNickTextBoxEnterPressed(_new_text:String):
	GM.main.pickOption("register_nick", [])

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "register_nick"):
		var nick = LocalSettings.clean_nick(getTextboxData("player_nick"))
		if(nick.length() < 3):
			result_text = "[color=red]Nick has to be at least 3 characters long.[/color]"
			setState("done")
			return

		setState("registering")
		call_deferred("_register_nick", nick)
		return

	setState(_action)

func _register_nick(nick:String):
	var client_id = get_client_id()

	var api = preload("res://Modules/AsyncGraffiti/GraffitiAPI.gd").new()
	add_child(api)

	var result = api.register_player(nick, client_id)
	if(result is GDScriptFunctionState):
		result = yield(result, "completed")

	api.queue_free()

	if(result is Dictionary && result.get("ok", false)):
		LocalSettings.save_settings(nick, client_id)

		setModuleFlag("AsyncGraffiti", "PlayerNick", "")
		setModuleFlag("AsyncGraffiti", "ClientID", "")

		result_text = "Nick registered: [b]" + nick + "[/b]"
	else:
		var status = -1
		var body = ""
		if(result is Dictionary):
			status = int(result.get("status", -1))
			body = str(result.get("body", ""))

		if(status == 409):
			result_text = "[color=red]This nick is already taken, or this install already registered another nick.[/color]"
		else:
			result_text = "[color=red]Could not register nick.[/color]\n" + body

	setState("done")
	GM.main.reRun()
