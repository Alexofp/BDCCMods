extends EventBase

var graffiti_by_room = {}
var loading_rooms = {}

func _init():
	id = "AsyncGraffitiRoomEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func run(_triggerID, _args):
	if(_args.size() <= 0):
		return

	var room_id = _args[0]

	if(graffiti_by_room.has(room_id)):
		addEventButtonAt(5, "Graffiti", "Look at graffiti or leave your own", "look", [room_id])
		return

	if(!loading_rooms.has(room_id)):
		loading_rooms[room_id] = true
		call_deferred("_load_room_graffiti", room_id)

func addEventButtonAt(slot:int, text:String, tooltip:String, method:String, args = []):
	GM.ui.addButtonAt(slot, text, tooltip, "EVENTSYSTEM_BUTTON", [self, method, args])

func _load_room_graffiti(room_id:String):
	var api = preload("res://Modules/AsyncGraffiti/GraffitiAPI.gd").new()
	GM.ES.add_child(api)

	var result = api.get_graffiti(room_id)
	if(result is GDScriptFunctionState):
		result = yield(result, "completed")

	api.queue_free()
	loading_rooms.erase(room_id)

	if(result is Array):
		graffiti_by_room[room_id] = result
	else:
		graffiti_by_room[room_id] = []

	if(GM.pc != null && GM.pc.getLocation() == room_id):
		GM.main.reRun()

func add_local_graffiti(room_id:String, entry:Dictionary):
	if(!graffiti_by_room.has(room_id) || !(graffiti_by_room[room_id] is Array)):
		graffiti_by_room[room_id] = []

	graffiti_by_room[room_id].push_front(entry)

func onButton(_method, _args):
	if(_method == "look"):
		var room_id = _args[0]
		runScene("AsyncGraffitiScene", [room_id, graffiti_by_room.get(room_id, [])])

func getPriority():
	return 0
