extends Reference

const SETTINGS_PATH = "user://async_graffiti_settings.json"

static func load_settings() -> Dictionary:
	var result = {
		"nick": "",
		"client_id": "",
	}

	var file = File.new()
	if(!file.file_exists(SETTINGS_PATH)):
		return result

	if(file.open(SETTINGS_PATH, File.READ) != OK):
		return result

	var content = file.get_as_text()
	file.close()

	var parsed = JSON.parse(content)
	if(parsed.error != OK || !(parsed.result is Dictionary)):
		return result

	result["nick"] = str(parsed.result.get("nick", ""))
	result["client_id"] = str(parsed.result.get("client_id", ""))

	return result

static func save_settings(nick:String, client_id:String) -> bool:
	var file = File.new()
	if(file.open(SETTINGS_PATH, File.WRITE) != OK):
		return false

	var data = {
		"nick": nick,
		"client_id": client_id,
	}

	file.store_string(JSON.print(data))
	file.close()
	return true

static func clean_nick(raw:String) -> String:
	var text = str(raw)
	text = text.replace("[", "")
	text = text.replace("]", "")
	text = text.replace("{", "")
	text = text.replace("}", "")
	text = text.replace("\"", "")
	text = text.strip_edges()

	if(text.length() > 32):
		text = text.substr(0, 32)

	return text

static func generate_client_id() -> String:
	var rng = RandomNumberGenerator.new()
	rng.randomize()

	return "ag_" + str(OS.get_unix_time()) + "_" + str(rng.randi())
