extends Module

func getFlags():
	return {
		"PlayerNick": flag(FlagType.Text),
		"ClientID": flag(FlagType.Text),

		"StyleFont": flag(FlagType.Text),
		"StyleColor": flag(FlagType.Text),
		"StyleBold": flag(FlagType.Bool),
		"StyleItalic": flag(FlagType.Bool),
	}

func _init():
	id = "AsyncGraffiti"
	author = "Doggo"

	events = [
		"res://Modules/AsyncGraffiti/GraffitiRoomEvent.gd",
	]

	scenes = [
		"res://Modules/AsyncGraffiti/GraffitiScene.gd",
		"res://Modules/AsyncGraffiti/GraffitiLeaveScene.gd",
		"res://Modules/AsyncGraffiti/GraffitiSettingsScene.gd",
		"res://Modules/AsyncGraffiti/AsyncGraffitiMeScene.gd",
	]
