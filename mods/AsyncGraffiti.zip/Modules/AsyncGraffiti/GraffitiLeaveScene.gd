extends SceneBase

const LocalSettings = preload("res://Modules/AsyncGraffiti/GraffitiLocalSettings.gd")

var room_id = ""
var message = ""
var result_text = ""

func _init():
	sceneID = "AsyncGraffitiLeaveScene"

func _initScene(_args = []):
	if(GM.pc != null):
		room_id = GM.pc.getLocation()

func clean_message_live(text) -> String:
	var result = str(text)

	result = result.replace("[", "")
	result = result.replace("]", "")
	result = result.replace("{", "")
	result = result.replace("}", "")
	result = result.replace("\"", "'")
	result = result.replace("\\", "")
	result = result.replace("\n", " ")
	result = result.replace("\r", " ")
	result = result.replace("\t", " ")

	if(result.length() > 200):
		result = result.substr(0, 200)

	return result

func safe_text(text) -> String:
	var result = clean_message_live(text)
	result = result.strip_edges()

	if(result.length() > 200):
		result = result.substr(0, 200)

	return result

func get_message_char_count(text) -> int:
	return safe_text(text).length()

func update_message_counter(textBox):
	var cleaned = clean_message_live(textBox.text)

	if(cleaned != textBox.text):
		textBox.text = cleaned
		textBox.cursor_set_line(0)
		textBox.cursor_set_column(cleaned.length())

	var counter = GM.ui.getCustomControl("graffiti_message_counter")
	if(counter != null):
		counter.text = "Characters used: " + str(get_message_char_count(cleaned)) + "/200"

func onGraffitiMessageChanged(textBox):
	update_message_counter(textBox)

func get_player_nick() -> String:
	var local = LocalSettings.load_settings()
	return str(local.get("nick", ""))

func get_client_id() -> String:
	var local = LocalSettings.load_settings()
	return str(local.get("client_id", ""))

func get_character_name() -> String:
	if(GM.pc == null):
		return "Unknown"
	return safe_text(GM.pc.getName())

func get_style_font() -> String:
	var value = getModuleFlag("AsyncGraffiti", "StyleFont", "default")
	if(!(value in ["default", "serif", "mono", "scratch"])):
		return "default"
	return value

func get_style_color() -> String:
	var value = getModuleFlag("AsyncGraffiti", "StyleColor", "white")
	if(!(value in ["red", "green", "blue", "yellow", "black", "white"])):
		return "white"
	return value

func get_style_bold() -> bool:
	return getModuleFlag("AsyncGraffiti", "StyleBold", false)

func get_style_italic() -> bool:
	return getModuleFlag("AsyncGraffiti", "StyleItalic", false)

func color_to_bbcode(style_color:String) -> String:
	if(style_color == "red"):
		return "#ff4444"
	if(style_color == "green"):
		return "#44ff44"
	if(style_color == "blue"):
		return "#66aaff"
	if(style_color == "yellow"):
		return "#ffff66"
	if(style_color == "black"):
		return "#111111"
	return "#ffffff"

func font_to_bbcode(style_font:String) -> String:
	if(style_font == "mono"):
		return "res://Fonts/normalconsolefont.tres"
	if(style_font == "serif"):
		return "res://Fonts/smallconsolefont.tres"
	if(style_font == "scratch"):
		return "res://Fonts/BodyWritingsFont.tres"
	return ""

func format_preview(text:String) -> String:
	var result = safe_text(text)

	result = "[color=" + color_to_bbcode(get_style_color()) + "]" + result + "[/color]"

	var font_path = font_to_bbcode(get_style_font())
	if(font_path != ""):
		result = "[font=" + font_path + "]" + result + "[/font]"

	if(get_style_bold()):
		result = "[b]" + result + "[/b]"
	if(get_style_italic()):
		result = "[i]" + result + "[/i]"

	return result

func style_label() -> String:
	var result = "Color: " + get_style_color()
	result += ", Font: " + get_style_font()
	result += ", Bold: " + ("yes" if get_style_bold() else "no")
	result += ", Italic: " + ("yes" if get_style_italic() else "no")
	return result

func _run():
	if(state == ""):
		if(room_id != ""):
			aimCameraAndSetLocName(room_id)

		var player_nick = get_player_nick()
		if(player_nick == "" || get_client_id() == ""):
			saynn("You need to register your player nick before leaving graffiti.")

			addButton("Graffiti settings", "Set your player nick", "settings")
			addButton("Back", "Return", "endthescene")
			return

		saynn("You look at the nearest wall.")

		saynn("Player nick:")
		saynn("[b]" + player_nick + "[/b]")

		saynn("Character name:")
		saynn("[b]" + get_character_name() + "[/b]")

		saynn("Current style:")
		saynn("[i]" + style_label() + "[/i]")

		saynn("Characters used: " + str(get_message_char_count(message)) + "/200")

		saynn("Preview:")
		if(message == ""):
			saynn("[i]No message written yet.[/i]")
		else:
			saynn("\"" + format_preview(message) + "\"")

		addButton("Message", "Edit graffiti message", "edit_message")
		addButton("Color", "Pick text color", "pick_color")
		addButton("Font", "Pick font", "pick_font")
		addButton("Bold", "Toggle bold", "toggle_bold")
		addButton("Italic", "Toggle italic", "toggle_italic")
		addButton("Leave graffiti", "Write this graffiti on the wall", "do_leave")
		addButton("Back", "Don't write anything", "endthescene")

	if(state == "edit_message"):
		saynn("Write your graffiti message. Max 200 characters.")

		var textBox = addBigTextbox("graffiti_message")
		textBox.text = clean_message_live(message)
		var _ok = textBox.connect("text_changed", self, "onGraffitiMessageChanged", [textBox])

		var counter = Label.new()
		counter.text = "Characters used: " + str(get_message_char_count(textBox.text)) + "/200"
		GM.ui.addCustomControl("graffiti_message_counter", counter)

		addButton("Confirm", "Use this message", "confirm_message")
		addButton("Back", "Return", "")

	if(state == "pick_color"):
		saynn("Pick graffiti color.")

		addButton("Red", "Red text", "set_color", ["red"])
		addButton("Green", "Green text", "set_color", ["green"])
		addButton("Blue", "Blue text", "set_color", ["blue"])
		addButton("Yellow", "Yellow text", "set_color", ["yellow"])
		addButton("Black", "Black text", "set_color", ["black"])
		addButton("White", "White text", "set_color", ["white"])
		addButton("Back", "Return", "")

	if(state == "pick_font"):
		saynn("Pick graffiti font.")

		addButton("Default", "Default font", "set_font", ["default"])
		addButton("Serif", "Small console font", "set_font", ["serif"])
		addButton("Mono", "Normal console font", "set_font", ["mono"])
		addButton("Scratch", "Body writing font", "set_font", ["scratch"])
		addButton("Back", "Return", "")

	if(state == "sending"):
		saynn("[i]Leaving graffiti...[/i]")

	if(state == "done"):
		saynn(result_text)
		addButton("Back", "Return", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "settings"):
		runScene("AsyncGraffitiSettingsScene")
		return

	if(_action == "confirm_message"):
		message = safe_text(getTextboxData("graffiti_message"))
		setState("")
		return

	if(_action == "set_color"):
		setModuleFlag("AsyncGraffiti", "StyleColor", _args[0])
		setState("")
		return

	if(_action == "set_font"):
		setModuleFlag("AsyncGraffiti", "StyleFont", _args[0])
		setState("")
		return

	if(_action == "toggle_bold"):
		setModuleFlag("AsyncGraffiti", "StyleBold", !get_style_bold())
		setState("")
		return

	if(_action == "toggle_italic"):
		setModuleFlag("AsyncGraffiti", "StyleItalic", !get_style_italic())
		setState("")
		return

	if(_action == "do_leave"):
		if(safe_text(message) == ""):
			result_text = "[color=red]Write a message first.[/color]"
			setState("done")
			return

		setState("sending")
		call_deferred("_post_graffiti")
		return

	setState(_action)

func _post_graffiti():
	var api = preload("res://Modules/AsyncGraffiti/GraffitiAPI.gd").new()
	add_child(api)

	var result = api.post_graffiti(
		room_id,
		get_player_nick(),
		get_client_id(),
		get_character_name(),
		safe_text(message),
		get_style_font(),
		get_style_color(),
		get_style_bold(),
		get_style_italic()
	)

	if(result is GDScriptFunctionState):
		result = yield(result, "completed")

	api.queue_free()

	if(result is Dictionary && result.get("ok", false)):
		var data = result.get("data", [])
		result_text = "You left graffiti in this room."

		if(data is Array && data.size() > 0):
			var event = GlobalRegistry.getEvent("AsyncGraffitiRoomEvent")
			if(event != null && event.has_method("add_local_graffiti")):
				event.add_local_graffiti(room_id, data[0])
	else:
		var body = ""
		if(result is Dictionary):
			body = str(result.get("body", ""))

		if(body.find("Graffiti limit reached") >= 0):
			result_text = "[color=red]You can only leave 10 graffiti per hour on this nick.[/color]"
		else:
			result_text = "[color=red]Could not leave graffiti.[/color]"

	setState("done")
	GM.main.reRun()
