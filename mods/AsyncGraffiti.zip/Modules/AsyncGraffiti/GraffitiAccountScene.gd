extends "res://Scenes/SceneBase.gd"

const LocalSettings = preload("res://Modules/AsyncGraffiti/GraffitiLocalSettings.gd")
const APIClass = preload("res://Modules/AsyncGraffiti/GraffitiAPI.gd")

const DOGGO_COLOR = "#ffd700"

var profile_nick:String = ""
var profile_data:Dictionary = {}
var followers:Array = []

var result_text:String = ""
var is_busy:bool = false
var profile_requested:bool = false
var followers_requested:bool = false

func _init():
	sceneID = "AsyncGraffitiAccountScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		profile_nick = safe_text(str(_args[0]))

	if(profile_nick == ""):
		profile_nick = get_my_nick()

func _run():
	if(state == ""):
		show_profile()
		return

	if(state == "followers"):
		show_followers()
		return

func is_doggo_nick(nick:String) -> bool:
	return safe_text(nick) == "Doggo"

func gold_if_doggo(nick:String, text:String) -> String:
	if(is_doggo_nick(nick)):
		return "[color=" + DOGGO_COLOR + "]" + text + "[/color]"

	return text

func nick_label(nick:String) -> String:
	var safe_nick = safe_text(nick)

	if(is_doggo_nick(safe_nick)):
		return "[color=" + DOGGO_COLOR + "][b]" + safe_nick + "[/b][/color]"

	return "[b]" + safe_nick + "[/b]"

func profile_say(text:String):
	saynn(gold_if_doggo(profile_nick, text))

func show_profile():
	profile_say("[b]Async Graffiti player profile[/b]")

	if(result_text != ""):
		profile_say("[i]" + safe_text(result_text) + "[/i]")

	if(profile_nick == ""):
		profile_say("You don't have an Async Graffiti nick yet.")
		addButton("Settings", "Register your Async Graffiti nick", "settings")
		addButton("Back", "Close profile", "endthescene")
		return

	if(!profile_requested):
		profile_requested = true
		result_text = "Loading profile..."

		var _state = async_load_profile(profile_nick)

		profile_say("Loading profile...")
		addButton("Back", "Close profile", "endthescene")
		return

	if(profile_data.empty()):
		profile_say("Could not load this profile.")
		addButton("Refresh", "Try loading this profile again", "refresh_profile")
		addButton("Back", "Close profile", "endthescene")
		return

	var nick = safe_text(str(profile_data.get("player_nick", profile_nick)))
	profile_say("[b]Nick:[/b] " + nick_label(nick))


	profile_say("[b]Active since:[/b] " + format_date(str(profile_data.get("active_since", ""))))
	profile_say("[b]First graffiti:[/b] " + format_date(str(profile_data.get("first_graffiti_at", ""))))
	profile_say("[b]Last graffiti:[/b] " + format_date(str(profile_data.get("last_graffiti_at", ""))))

	profile_say("[b]Graffiti left:[/b] " + str(profile_data.get("graffiti_count", 0)))
	profile_say("[b]Total likes:[/b] " + str(profile_data.get("total_likes", 0)))
	profile_say("[b]Followers:[/b] " + str(profile_data.get("followers_count", 0)))

	if(profile_nick != get_my_nick() && get_my_nick() != "" && get_my_client_id() != ""):
		addButton("Follow", "Follow this player. Click again to unfollow.", "toggle_follow", [profile_nick])
	elif(profile_nick == get_my_nick()):
		addDisabledButton("Follow", "You can't follow yourself.")
	else:
		addDisabledButton("Follow", "You need to register a nick first.")

	addButton("See followers", "See who follows this player", "followers")
	addButton("Refresh", "Reload this profile", "refresh_profile")
	addButton("Back", "Close profile", "endthescene")

func show_followers():
	profile_say("[b]Followers of " + nick_label(profile_nick) + "[/b]")

	if(result_text != ""):
		profile_say("[i]" + safe_text(result_text) + "[/i]")

	if(!followers_requested):
		followers_requested = true
		result_text = "Loading followers..."

		var _state = async_load_followers(profile_nick)

		profile_say("Loading followers...")
		addButton("Back", "Back to profile", "back_to_profile")
		return

	if(followers.empty()):
		profile_say("This player has no followers yet.")
	else:
		for i in range(followers.size()):
			var entry = followers[i]
			var follower_nick = safe_text(str(entry.get("follower_nick", "")))

			if(follower_nick == ""):
				continue

			profile_say(str(i + 1) + ". " + nick_label(follower_nick) + " - since " + format_date(str(entry.get("created_at", ""))))

			if(i < 10):
				addButton("Profile " + str(i + 1), "Open follower profile", "open_follower", [follower_nick])

	addButton("Refresh", "Reload followers", "refresh_followers")
	addButton("Back", "Back to profile", "back_to_profile")

func get_my_nick() -> String:
	var settings = LocalSettings.load_settings()
	return safe_text(str(settings.get("nick", "")))

func get_my_client_id() -> String:
	var settings = LocalSettings.load_settings()
	return safe_client_id(str(settings.get("client_id", "")))

func safe_text(text) -> String:
	var result = str(text)

	result = result.replace("[", "")
	result = result.replace("]", "")
	result = result.replace("{", "")
	result = result.replace("}", "")
	result = result.replace("\"", "'")
	result = result.replace("\\", "")
	result = result.replace("\n", " ")
	result = result.replace("\r", " ")
	result = result.replace("\t", " ")

	result = result.strip_edges()

	if(result.length() > 300):
		result = result.substr(0, 300)

	return result

func safe_client_id(text) -> String:
	var result = str(text)
	var allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-"
	var final_text = ""

	for i in range(result.length()):
		var ch = result.substr(i, 1)
		if(allowed.find(ch) >= 0):
			final_text += ch

	if(final_text.length() > 128):
		final_text = final_text.substr(0, 128)

	return final_text

func format_date(timestamp:String) -> String:
	if(timestamp == "" || timestamp == "null"):
		return "unknown"

	var clean = timestamp.replace("T", " ")

	var dot_pos = clean.find(".")
	if(dot_pos >= 0):
		clean = clean.substr(0, dot_pos)

	var plus_pos = clean.find("+")
	if(plus_pos >= 0):
		clean = clean.substr(0, plus_pos)

	clean = clean.replace("Z", "")
	clean = clean.strip_edges()

	if(clean.length() >= 16):
		return clean.substr(0, 16)

	return clean

func async_load_profile(nick:String):
	is_busy = true

	var api = APIClass.new()
	add_child(api)

	var data = yield(api.get_profile(nick), "completed")
	api.queue_free()

	profile_data = data
	result_text = ""
	is_busy = false

	GM.main.reRun()

func async_load_followers(nick:String):
	is_busy = true

	var api = APIClass.new()
	add_child(api)

	var data = yield(api.get_followers(nick), "completed")
	api.queue_free()

	if(data is Array):
		followers = data
	else:
		followers = []

	result_text = ""
	is_busy = false

	GM.main.reRun()

func async_toggle_follow(nick:String):
	if(nick == "" || nick == get_my_nick()):
		result_text = "You can't follow this profile."
		return

	if(get_my_nick() == "" || get_my_client_id() == ""):
		result_text = "You need to register a nick first."
		return

	is_busy = true
	result_text = "Updating follow..."

	var api = APIClass.new()
	add_child(api)

	var response = yield(api.toggle_follow_player(nick, get_my_nick(), get_my_client_id()), "completed")

	if(response.ok):
		profile_data = yield(api.get_profile(nick), "completed")
		followers_requested = false
		followers = []

		if(response.has("following") && response["following"]):
			result_text = "Followed."
		else:
			result_text = "Unfollowed."
	else:
		result_text = "Could not update follow."

	api.queue_free()
	is_busy = false

	GM.main.reRun()

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "settings"):
		runScene("AsyncGraffitiSettingsScene")
		return

	if(_action == "refresh_profile"):
		profile_requested = false
		profile_data = {}
		result_text = ""
		return

	if(_action == "followers"):
		state = "followers"
		followers_requested = false
		followers = []
		result_text = ""
		return

	if(_action == "refresh_followers"):
		followers_requested = false
		followers = []
		result_text = ""
		return

	if(_action == "back_to_profile"):
		state = ""
		result_text = ""
		return

	if(_action == "open_follower"):
		profile_nick = safe_text(str(_args[0]))
		profile_data = {}
		followers = []
		profile_requested = false
		followers_requested = false
		state = ""
		result_text = ""
		return

	if(_action == "toggle_follow"):
		if(!is_busy):
			var _state = async_toggle_follow(str(_args[0]))
		return

	setState(_action)
