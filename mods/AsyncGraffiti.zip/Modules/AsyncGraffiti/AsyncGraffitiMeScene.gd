extends "res://Scenes/MeScene.gd"

const LocalSettings = preload("res://Modules/AsyncGraffiti/GraffitiLocalSettings.gd")

func _init():
	sceneID = "MeScene"

func getSceneCreator():
	return "Doggo"

func _run():
	._run()

	if(state == ""):
		addButton("Leave graffiti", "Leave graffiti in your current room", "asyncgraffiti_leave")
		addButton("My profile", "See your Async Graffiti profile", "asyncgraffiti_profile")
		addButton("Leaderboards", "See Async Graffiti leaderboards", "asyncgraffiti_leaderboards")
		addButton("Graffiti settings", "Set your async graffiti player nick", "asyncgraffiti_settings")

func _react(_action: String, _args):
	if(_action == "asyncgraffiti_leave"):
		runScene("AsyncGraffitiLeaveScene")
		return

	if(_action == "asyncgraffiti_profile"):
		var settings = LocalSettings.load_settings()
		var nick = str(settings.get("nick", ""))

		if(nick == ""):
			runScene("AsyncGraffitiSettingsScene")
		else:
			runScene("AsyncGraffitiAccountScene", [nick])
		return

	if(_action == "asyncgraffiti_leaderboards"):
		runScene("AsyncGraffitiLeaderboardsScene")
		return

	if(_action == "asyncgraffiti_settings"):
		runScene("AsyncGraffitiSettingsScene")
		return


	._react(_action, _args)
