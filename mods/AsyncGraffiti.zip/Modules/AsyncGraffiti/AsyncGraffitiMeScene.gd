extends "res://Scenes/MeScene.gd"

func _init():
	sceneID = "MeScene"

func _run():
	._run()

	if(state == ""):
		addButton("Leave graffiti", "Leave a premade graffiti in your current room", "asyncgraffiti_leave")

func _react(_action: String, _args):
	if(_action == "asyncgraffiti_leave"):
		runScene("AsyncGraffitiLeaveScene")
		return

	._react(_action, _args)
