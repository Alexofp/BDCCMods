extends Node
class_name GraffitiAPI

const SUPABASE_URL = "https://cijoghvbvuswnycdjaum.supabase.co"
const SUPABASE_KEY = "sb_publishable_ar1K_AScGKDLecK_H4FTNw_3FAAayP0"

func _make_headers(content_type := false, prefer_minimal := false) -> Array:
	var headers = [
		"apikey: " + SUPABASE_KEY,
		"Authorization: Bearer " + SUPABASE_KEY,
		"Accept: application/json",
	]

	if(content_type):
		headers.append("Content-Type: application/json")

	if(prefer_minimal):
		headers.append("Prefer: return=minimal")

	return headers

func _request_json(url:String, method:int, payload = null, prefer_minimal := false) -> Dictionary:
	var req = HTTPRequest.new()
	add_child(req)

	var body := ""
	var headers = _make_headers(payload != null, prefer_minimal)

	if(payload != null):
		body = JSON.print(payload)

	var err = req.request(url, headers, true, method, body)
	if(err != OK):
		req.queue_free()
		return {
			ok = false,
			status = 0,
			body = "request() error: " + str(err),
			data = null,
		}

	var result = yield(req, "request_completed")
	var response_code = result[1]
	var response_body: String = result[3].get_string_from_utf8()
	req.queue_free()

	var parsed_data = null
	if(response_body != ""):
		var parsed = JSON.parse(response_body)
		if(parsed.error == OK):
			parsed_data = parsed.result

	return {
		ok = response_code >= 200 && response_code < 300,
		status = response_code,
		body = response_body,
		data = parsed_data,
	}

func get_graffiti(room_id: String):
	var url = SUPABASE_URL + "/rest/v1/graffiti_public"
	url += "?room_id=eq." + room_id.percent_encode()
	url += "&select=id,room_id,player_nick,character_name,message,created_at,style_font,style_color,style_bold,style_italic,doggo_priority,like_count"
	url += "&order=doggo_priority.asc,created_at.desc"
	url += "&limit=50"

	var result = yield(_request_json(url, HTTPClient.METHOD_GET), "completed")

	if(!result.ok):
		print("AsyncGraffiti GET failed: " + str(result.status) + " " + result.body)
		return []

	if(result.data is Array):
		return result.data

	return []

func post_graffiti(room_id: String, player_nick: String, client_id: String, character_name: String, message: String, style_font: String, style_color: String, style_bold: bool, style_italic: bool) -> Dictionary:
	var payload = {
		"room_id": room_id,
		"nick": player_nick,
		"player_nick": player_nick,
		"client_id": client_id,
		"character_name": character_name,
		"message": message,
		"style_font": style_font,
		"style_color": style_color,
		"style_bold": style_bold,
		"style_italic": style_italic,
	}

	var result = yield(_request_json(
		SUPABASE_URL + "/rest/v1/graffiti",
		HTTPClient.METHOD_POST,
		payload,
		true
	), "completed")

	if(!result.ok):
		print("AsyncGraffiti POST failed: " + str(result.status) + " " + result.body)

	return result

func register_player(nick: String, client_id: String) -> Dictionary:
	var payload = {
		"nick": nick,
		"client_id": client_id,
	}

	return yield(_request_json(
		SUPABASE_URL + "/rest/v1/graffiti_players",
		HTTPClient.METHOD_POST,
		payload,
		true
	), "completed")

func like_graffiti(graffiti_id: String, player_nick: String, client_id: String) -> Dictionary:
	var payload = {
		"graffiti_id": graffiti_id,
		"player_nick": player_nick,
		"client_id": client_id,
	}

	return yield(_request_json(
		SUPABASE_URL + "/rest/v1/graffiti_likes",
		HTTPClient.METHOD_POST,
		payload,
		true
	), "completed")

func unlike_graffiti(graffiti_id: String, player_nick: String, client_id: String) -> Dictionary:
	var url = SUPABASE_URL + "/rest/v1/graffiti_likes"
	url += "?graffiti_id=eq." + graffiti_id.percent_encode()
	url += "&player_nick=eq." + player_nick.percent_encode()
	url += "&client_id=eq." + client_id.percent_encode()

	return yield(_request_json(
		url,
		HTTPClient.METHOD_DELETE,
		null,
		true
	), "completed")

func toggle_like_graffiti(graffiti_id: String, player_nick: String, client_id: String) -> Dictionary:
	var like_result = yield(like_graffiti(graffiti_id, player_nick, client_id), "completed")

	if(like_result.ok):
		like_result["liked"] = true
		return like_result

	if(like_result.status == 409):
		var unlike_result = yield(unlike_graffiti(graffiti_id, player_nick, client_id), "completed")
		unlike_result["liked"] = false
		return unlike_result

	return like_result

func follow_player(followed_nick: String, follower_nick: String, follower_client_id: String) -> Dictionary:
	var payload = {
		"followed_nick": followed_nick,
		"follower_nick": follower_nick,
		"follower_client_id": follower_client_id,
	}

	return yield(_request_json(
		SUPABASE_URL + "/rest/v1/graffiti_follows",
		HTTPClient.METHOD_POST,
		payload,
		true
	), "completed")

func unfollow_player(followed_nick: String, follower_nick: String, follower_client_id: String) -> Dictionary:
	var url = SUPABASE_URL + "/rest/v1/graffiti_follows"
	url += "?followed_nick=eq." + followed_nick.percent_encode()
	url += "&follower_nick=eq." + follower_nick.percent_encode()
	url += "&follower_client_id=eq." + follower_client_id.percent_encode()

	return yield(_request_json(
		url,
		HTTPClient.METHOD_DELETE,
		null,
		true
	), "completed")

func toggle_follow_player(followed_nick: String, follower_nick: String, follower_client_id: String) -> Dictionary:
	var follow_result = yield(follow_player(followed_nick, follower_nick, follower_client_id), "completed")

	if(follow_result.ok):
		follow_result["following"] = true
		return follow_result

	if(follow_result.status == 409):
		var unfollow_result = yield(unfollow_player(followed_nick, follower_nick, follower_client_id), "completed")
		unfollow_result["following"] = false
		return unfollow_result

	return follow_result

func get_profile(player_nick: String) -> Dictionary:
	var url = SUPABASE_URL + "/rest/v1/graffiti_profiles_public"
	url += "?player_nick=eq." + player_nick.percent_encode()
	url += "&select=player_nick,active_since,account_created_at,first_graffiti_at,last_graffiti_at,graffiti_count,total_likes,followers_count"
	url += "&limit=1"

	var result = yield(_request_json(url, HTTPClient.METHOD_GET), "completed")

	if(!result.ok):
		print("AsyncGraffiti profile GET failed: " + str(result.status) + " " + result.body)
		return {}

	if(result.data is Array && result.data.size() > 0):
		return result.data[0]

	return {}

func get_leaderboard_player_likes():
	var url = SUPABASE_URL + "/rest/v1/graffiti_leaderboard_player_likes"
	url += "?select=rank,player_nick,total_likes,graffiti_count,followers_count"
	url += "&order=rank.asc"
	url += "&limit=10"

	var result = yield(_request_json(url, HTTPClient.METHOD_GET), "completed")

	if(result.ok && result.data is Array):
		return result.data

	return []

func get_leaderboard_top_graffiti():
	var url = SUPABASE_URL + "/rest/v1/graffiti_leaderboard_top_graffiti"
	url += "?select=rank,id,player_nick,character_name,message,room_id,created_at,like_count"
	url += "&order=rank.asc"
	url += "&limit=10"

	var result = yield(_request_json(url, HTTPClient.METHOD_GET), "completed")

	if(result.ok && result.data is Array):
		return result.data

	return []

func get_leaderboard_followers():
	var url = SUPABASE_URL + "/rest/v1/graffiti_leaderboard_followers"
	url += "?select=rank,player_nick,followers_count,total_likes,graffiti_count"
	url += "&order=rank.asc"
	url += "&limit=10"

	var result = yield(_request_json(url, HTTPClient.METHOD_GET), "completed")

	if(result.ok && result.data is Array):
		return result.data

	return []

func get_followers(followed_nick: String):
	var url = SUPABASE_URL + "/rest/v1/graffiti_followers_public"
	url += "?followed_nick=eq." + followed_nick.percent_encode()
	url += "&select=follower_nick,created_at"
	url += "&order=created_at.desc"
	url += "&limit=50"

	var result = yield(_request_json(url, HTTPClient.METHOD_GET), "completed")

	if(!result.ok):
		print("AsyncGraffiti followers GET failed: " + str(result.status) + " " + result.body)
		return []

	if(result.data is Array):
		return result.data

	return []
