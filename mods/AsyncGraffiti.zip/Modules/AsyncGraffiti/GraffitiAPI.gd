extends Node
class_name GraffitiAPI

const SUPABASE_URL = "https://cijoghvbvuswnycdjaum.supabase.co"
const SUPABASE_KEY = "sb_publishable_ar1K_AScGKDLecK_H4FTNw_3FAAayP0"

func _make_headers(content_type := false, prefer_minimal := false) -> Array:
	var headers = [
		"apikey: " + SUPABASE_KEY,
		"Authorization: Bearer " + SUPABASE_KEY,
		"Accept: application/json",
	]

	if(content_type):
		headers.append("Content-Type: application/json")

	if(prefer_minimal):
		headers.append("Prefer: return=minimal")

	return headers

func get_graffiti(room_id: String):
	var req = HTTPRequest.new()
	add_child(req)

	var url = SUPABASE_URL + "/rest/v1/graffiti_public"
	url += "?room_id=eq." + room_id.percent_encode()
	url += "&select=room_id,player_nick,character_name,message,created_at,style_font,style_color,style_bold,style_italic,doggo_priority"
	url += "&order=doggo_priority.asc,created_at.desc"
	url += "&limit=50"

	var err = req.request(url, _make_headers(), true, HTTPClient.METHOD_GET)
	if(err != OK):
		req.queue_free()
		print("AsyncGraffiti GET request() error: " + str(err))
		return []

	var data = yield(req, "request_completed")
	var response_code = data[1]
	var body: String = data[3].get_string_from_utf8()
	req.queue_free()

	if(response_code < 200 || response_code >= 300):
		print("AsyncGraffiti GET failed: " + str(response_code) + " " + body)
		return []

	var parsed = JSON.parse(body)
	if(parsed.error != OK):
		print("AsyncGraffiti GET JSON parse failed: " + parsed.error_string)
		return []

	if(parsed.result is Array):
		return parsed.result

	return []

func post_graffiti(room_id: String, player_nick: String, client_id: String, character_name: String, message: String, style_font: String, style_color: String, style_bold: bool, style_italic: bool) -> Dictionary:
	var req = HTTPRequest.new()
	add_child(req)

	var payload = {
		"room_id": room_id,
		"nick": player_nick,
		"player_nick": player_nick,
		"client_id": client_id,
		"character_name": character_name,
		"message": message,
		"style_font": style_font,
		"style_color": style_color,
		"style_bold": style_bold,
		"style_italic": style_italic,
	}

	var err = req.request(
		SUPABASE_URL + "/rest/v1/graffiti",
		_make_headers(true, true),
		true,
		HTTPClient.METHOD_POST,
		JSON.print(payload)
	)

	if(err != OK):
		req.queue_free()
		return {
			ok = false,
			status = 0,
			body = "request() error: " + str(err),
		}

	var data = yield(req, "request_completed")
	var response_code = data[1]
	var body: String = data[3].get_string_from_utf8()
	req.queue_free()

	if(response_code < 200 || response_code >= 300):
		print("AsyncGraffiti POST failed: " + str(response_code) + " " + body)

	return {
		ok = response_code >= 200 && response_code < 300,
		status = response_code,
		body = body,
	}

func register_player(nick: String, client_id: String) -> Dictionary:
	var req = HTTPRequest.new()
	add_child(req)

	var payload = {
		"nick": nick,
		"client_id": client_id,
	}

	var err = req.request(
		SUPABASE_URL + "/rest/v1/graffiti_players",
		_make_headers(true, true),
		true,
		HTTPClient.METHOD_POST,
		JSON.print(payload)
	)

	if(err != OK):
		req.queue_free()
		return {
			ok = false,
			status = 0,
			body = "request() error: " + str(err),
		}

	var data = yield(req, "request_completed")
	var response_code = data[1]
	var body: String = data[3].get_string_from_utf8()
	req.queue_free()

	return {
		ok = response_code >= 200 && response_code < 300,
		status = response_code,
		body = body,
	}
