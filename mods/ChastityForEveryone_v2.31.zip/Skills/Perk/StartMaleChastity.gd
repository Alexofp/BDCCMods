extends PerkBase

func _init():
	id = Perk.StartMaleChastity
	skillGroup = Skill.Start

func getVisibleName():
	return "Permanent Chastity"

func getVisibleDescription():
	return "A [b]permanent[/b] chastity gear will be forced upon you during the intake process."

func hiddenWhenLocked() -> bool:
	return true

func hiddenWhenUnlocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0
	
func getSkillTier():
	return 0

func getPicture():
	return "res://UI/StatusEffectsPanel/images/cuffshands.png"

