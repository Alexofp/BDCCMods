# mod version: 2.3
extends EventBase
#extends GameExtender

const DEBUG = false
const DEBUG_PLUS = false
const DEBUG_23 = false # made for game version 2.3

const FoxGlobals = preload("res://FoxLib/Globals.gd")

var chastityNpcsOld = {}
var chastityNpcs = {}

# idk, I don't get it, I just did it through flags
#func saveData():
#	var data = .saveData()
#	data["WasPutInChastity"] = chastityNpcs
#	return data
#
#func loadData(_data):
#	chastityNpcs = SAVE.loadVar(_data, "WasPutInChastity", {"test": "from load"})


func _init():
	id = "ChastityBigBrother"


func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)


func shouldBeChecked(characterID):
#	if !FoxGlobals.ofModule("ChastityForEveryone").configModEnabled:
#		return "skip"

#	 TODO if
	
#	var configAffectMales = FoxGlobals.ofModule("ChastityForEveryone").configAffectMales
#	var configAffectFemales = FoxGlobals.ofModule("ChastityForEveryone").configAffectFemales
#	var configAffectShemales = FoxGlobals.ofModule("ChastityForEveryone").configAffectShemales
#	var configAffectHerms = FoxGlobals.ofModule("ChastityForEveryone").configAffectHerms#
	var configAffectDatapackChar = FoxGlobals.ofModule("ChastityForEveryone").configAffectDatapackChar
	var configMales = FoxGlobals.ofModule("ChastityForEveryone").configMales
	var configFemales = FoxGlobals.ofModule("ChastityForEveryone").configFemales
	var configShemales = FoxGlobals.ofModule("ChastityForEveryone").configShemales
	var configHerms = FoxGlobals.ofModule("ChastityForEveryone").configHerms
	var configPeachboys = FoxGlobals.ofModule("ChastityForEveryone").configPeachboys
	
	var configChanceInmates =  FoxGlobals.ofModule("ChastityForEveryone").configChance
	var configChanceEngineers = FoxGlobals.ofModule("ChastityForEveryone").configChanceEngineers
	var configChanceGuards = FoxGlobals.ofModule("ChastityForEveryone").configChanceGuards
	var configChanceNurses = FoxGlobals.ofModule("ChastityForEveryone").configChanceNurses
	
	var configAffectGBI = FoxGlobals.ofModule("ChastityForEveryone").configAffectGBI
	var configAffectHSI = FoxGlobals.ofModule("ChastityForEveryone").configAffectHSI
	var configAffectSDI = FoxGlobals.ofModule("ChastityForEveryone").configAffectSDI
	
	var configBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configBeltChance
	
	var character = GlobalRegistry.getCharacter(characterID)
	var charGender = character.npcGeneratedGender
	var charType = character.getCharacterType()
	var _name = character.getName()
	
	if !("dynamicnpc" in characterID):
		if !configAffectDatapackChar:
			return "none"
	
	if (!character.hasPenis() and !character.hasVagina()):
		return "none"
	
#	var isGenderOk = false
#	if(charGender == NpcGender.Male):
#		isGenderOk = configAffectMales
#	if(charGender == NpcGender.Female):
#		isGenderOk = configAffectFemales
#	if(charGender == NpcGender.Shemale):
#		isGenderOk = configAffectShemales
#	if(charGender == NpcGender.Herm):
#		isGenderOk = configAffectHerms
#	
#	if !isGenderOk:
#		return false
	var typeFromGender = "none"
	if(charGender == NpcGender.Male):
		typeFromGender = configMales
	if(charGender == NpcGender.Female):
		typeFromGender = configFemales
	if(charGender == NpcGender.Shemale):
		typeFromGender = configShemales
	if(charGender == NpcGender.Herm):
		typeFromGender = configHerms
	if(charGender == NpcGender.Peachboy):
		typeFromGender = configPeachboys
	
	if typeFromGender == "none":
		return "none"
	
	if charType == CharacterType.Inmate:
		if RNG.chance(configChanceInmates): 
			var inmateType = character.getInmateType()
			if !(
			(configAffectGBI && inmateType == InmateType.General) or \
			(configAffectHSI && inmateType == InmateType.HighSec) or \
			(configAffectSDI && inmateType == InmateType.SexDeviant)
			):
				return "none"
		else:
			return "none"
			
	if !(
		charType == CharacterType.Guard && RNG.chance(configChanceGuards) or \
		charType == CharacterType.Engineer && RNG.chance(configChanceEngineers) or \
		charType == CharacterType.Nurse && RNG.chance(configChanceNurses)
		) && charType != "Inmate": 
			return "none"
	
	match typeFromGender:
		"beltA":
			return RNG.pick(["beltP", "beltV", "beltPV"])
		"cage&beltP":
			if RNG.chance(configBeltChance):
				return "beltP"
			else:
				return "cage"
		"cages&beltV":
			if RNG.chance(configBeltChance):
				return "beltV"
			else:
				return "cage"
		"any":
			if RNG.chance(configBeltChance):
				return RNG.pick(["beltP", "beltV", "beltPV"])
			else:
				return "cage"
		_: return typeFromGender
	
#	return "none"

func putInChastity(characterID):
	var character = GlobalRegistry.getCharacter(characterID)
#	if DEBUG: print_debug("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
	if DEBUG_PLUS: print_debug("Inside PutNpcInChastity func")
	if DEBUG_PLUS: print_debug(character.getName())
	if DEBUG_PLUS: print_debug(character.getCharacterType())
	if DEBUG_PLUS: print_debug(character.npcGeneratedGender)

	var typeOfChastity = shouldBeChecked(characterID)
#	if typeOfChastity == "skip":
#		return
	if DEBUG_PLUS && (DEBUG || DEBUG_23): print_debug(typeOfChastity)
	if typeOfChastity != "none":
		cageThem(character, characterID, typeOfChastity)
		chastityNpcs[characterID] = {
				"name": character.getName(),
				"isCaged": true,
				"type": typeOfChastity
			}
	else:
		chastityNpcs[characterID] = {
			"name": character.getName(),
			"isCaged": false,
			"type": typeOfChastity # should always be "none"
		}
	if DEBUG_PLUS: print_debug(chastityNpcs.get(characterID))


func cageThem(character, _characterID, typeOfChastity):
	if DEBUG: print_debug("Locking up: "+str(character.getName()))
	var chastityCageItem
	var configFlatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var variantNonPermaChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentChance
	var variantNonPermaBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentBeltChance
	var level = RNG.randi_range(FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMin,
								FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMax)
	level = level * FoxGlobals.ofModule("ChastityForEveryone").configChastityLvlMultip
	if level < 1: level=1
	
	if typeOfChastity == "cage":
		#cage
		if(RNG.chance(configFlatCageChance)):	
			if RNG.chance(variantNonPermaChance): 
				chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
				chastityCageItem.setRestraintLevel(level)
			else: 
				chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
		else:
			if RNG.chance(variantNonPermaChance):
				chastityCageItem = GlobalRegistry.createItem("ChastityCage")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
	#belt
	elif typeOfChastity == "beltPV":
		if RNG.chance(variantNonPermaBeltChance):
			chastityCageItem = GlobalRegistry.createItem("GenitalChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		else:
			chastityCageItem = GlobalRegistry.createItem("PermanentGenitalChastityBelt")
	elif typeOfChastity == "beltV":
		if RNG.chance(variantNonPermaBeltChance):
			chastityCageItem = GlobalRegistry.createItem("ChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		else:
			chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltVagina")
	elif typeOfChastity == "beltP":
		if RNG.chance(variantNonPermaBeltChance):
			chastityCageItem = GlobalRegistry.createItem("PenisChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		else:
			chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltPenis")

	character.getInventory().forceEquipRemoveOther(chastityCageItem)


func react(_triggerID, _args):
	if !FoxGlobals.ofModule("ChastityForEveryone").configModEnabled:
		return
#	loadData()
	chastityNpcsOld = GM.main.getFlag("ChastityForEveryone.database", {}) # Legacy for backwards compatibility
	chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {}) # new dict structure
	# changes in 2.3, first run if the version 2.2 has been run before on the save game:
	if DEBUG_23: print_debug("chastityNpcsOld size")
	if DEBUG_23: print_debug(chastityNpcsOld.size())
	if !chastityNpcsOld.empty():
		if DEBUG || DEBUG_23: print_debug("Processing Legacy Player Chastity")
		var wasPlayerCaged = (
				GM.pc.hasPerk(Perk.StartMaleChastity) || ( GM.main.getFlag("MedicalModule.PC_ReceivedPermanentCage")==true && GM.main.getFlag("MedicalModule.Chastity_Event5LockedForever")!=false )
		)
		GM.main.setFlag("ChastityForEveryone.databasePC", {
			"name": GM.pc.getName(),
			"isCaged": wasPlayerCaged,
			"type": "cage" if wasPlayerCaged else "none"
		})
		if DEBUG || DEBUG_23: print_debug(GM.main.getFlag("ChastityForEveryone.databasePC"))
		if DEBUG || DEBUG_23: print_debug("Processing Legacy Database")
		for characterID in chastityNpcsOld.keys():
			if characterID == null: continue #2.4
			chastityNpcs[characterID] = {
				"name": GlobalRegistry.getCharacter(characterID).getName(),
				"isCaged": chastityNpcsOld.get(characterID),
# warning-ignore:incompatible_ternary
				"type": "cage" if chastityNpcsOld.get(characterID) else null #belts added in 2.3
			}
		chastityNpcsOld = {}
		GM.main.setFlag("ChastityForEveryone.database", {})
#			
	
	var FoxGlobals = preload("res://FoxLib/Globals.gd") 
	var configModEnabled = FoxGlobals.ofModule("ChastityForEveryone").configModEnabled
	var configModUpdating = FoxGlobals.ofModule("ChastityForEveryone").configModUpdating
	
	if DEBUG: print_debug("INSIDE BIG BROTHER")
	if DEBUG: print_debug("INSIDE BIG BROTHER: configModEnabled = "+str(configModEnabled))
	if !configModEnabled: return false

	var dynamicNpcs = GM.main.getDynamicCharacters()
	if DEBUG || DEBUG_23: print_debug("chastityNpcs in Big Brother size:")
	if DEBUG || DEBUG_23: print_debug(dynamicNpcs.keys().size())
	if DEBUG || DEBUG_23: print_debug("chastityNpcs in Big Brother size:")
	if DEBUG || DEBUG_23: print_debug(chastityNpcs.keys().size())

#	var equalsOrMoreNpcsInArray = true
#	for item in dynamicNpcs.keys():
#		if !chastityNpcs.keys().has(item):
#			 equalsOrMoreNpcsInArray = false
#		if array2.count(item) != array1.count(item):
#			 equalsOrMoreNpcsInArray = false
#
##	if chastityNpcs.keys() == dynamicNpcs.keys(): 
#	if equalsOrMoreNpcsInArray
#		if DEBUG: print_debug("EVERYONE IS ALREADY PROCESSED BY BIG BROTHER !!!!!")
#		return
#	else:
#		chastityNpcs = {} # if some NPC has been deleted
#		chastityNpcsGear = {}
	for characterID in dynamicNpcs.keys():
		if DEBUG_PLUS: print_debug("INSIDE BIG BROTHER, processing: "+characterID)
		if characterID == null: continue
#		if DEBUG_23 && chastityNpcs.has(characterID): print_debug("NAME CHECK: "+chastityNpcs.get(characterID)["name"])
#		if DEBUG_23 && chastityNpcs.has(characterID): print_debug(GlobalRegistry.getCharacter(characterID).getName())
		if configModUpdating or \
		!chastityNpcs.has(characterID) or \
		(
			# if npc was deleted and has been replaced on the same ID, and is not currently a player slave - since player can change slave names
			chastityNpcs.has(characterID) and \
			(chastityNpcs.get(characterID)["name"] != GlobalRegistry.getCharacter(characterID).getName()) and !GlobalRegistry.getCharacter(characterID).isSlaveToPlayer()
			
		): 
			putInChastity(characterID)
		if DEBUG_PLUS && (DEBUG || DEBUG_23): print_debug(chastityNpcs.get(characterID))
#		print_debug(chastityNpcs[characterID])
	
	GM.main.setFlag("ChastityForEveryone.databaseNew", chastityNpcs)
	return


func getPriority():
	return 100

# 2.31
static func shouldBeCheckedStatic(characterID):
#	if !FoxGlobals.ofModule("ChastityForEveryone").configModEnabled:
#		return "skip"

#	 TODO if
	
#	var configAffectMales = FoxGlobals.ofModule("ChastityForEveryone").configAffectMales
#	var configAffectFemales = FoxGlobals.ofModule("ChastityForEveryone").configAffectFemales
#	var configAffectShemales = FoxGlobals.ofModule("ChastityForEveryone").configAffectShemales
#	var configAffectHerms = FoxGlobals.ofModule("ChastityForEveryone").configAffectHerms#
	var configAffectDatapackChar = FoxGlobals.ofModule("ChastityForEveryone").configAffectDatapackChar
	var configMales = FoxGlobals.ofModule("ChastityForEveryone").configMales
	var configFemales = FoxGlobals.ofModule("ChastityForEveryone").configFemales
	var configShemales = FoxGlobals.ofModule("ChastityForEveryone").configShemales
	var configHerms = FoxGlobals.ofModule("ChastityForEveryone").configHerms
	var configPeachboys = FoxGlobals.ofModule("ChastityForEveryone").configPeachboys
	
	var configChanceInmates =  FoxGlobals.ofModule("ChastityForEveryone").configChance
	var configChanceEngineers = FoxGlobals.ofModule("ChastityForEveryone").configChanceEngineers
	var configChanceGuards = FoxGlobals.ofModule("ChastityForEveryone").configChanceGuards
	var configChanceNurses = FoxGlobals.ofModule("ChastityForEveryone").configChanceNurses
	
	var configAffectGBI = FoxGlobals.ofModule("ChastityForEveryone").configAffectGBI
	var configAffectHSI = FoxGlobals.ofModule("ChastityForEveryone").configAffectHSI
	var configAffectSDI = FoxGlobals.ofModule("ChastityForEveryone").configAffectSDI
	
	var configBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configBeltChance
	
	var character = GlobalRegistry.getCharacter(characterID)
	var charGender = character.npcGeneratedGender
	var charType = character.getCharacterType()
	var _name = character.getName()
	
	if !("dynamicnpc" in characterID):
		if !configAffectDatapackChar:
			return "none"
	
	if (!character.hasPenis() and !character.hasVagina()):
		return "none"
	
#	var isGenderOk = false
#	if(charGender == NpcGender.Male):
#		isGenderOk = configAffectMales
#	if(charGender == NpcGender.Female):
#		isGenderOk = configAffectFemales
#	if(charGender == NpcGender.Shemale):
#		isGenderOk = configAffectShemales
#	if(charGender == NpcGender.Herm):
#		isGenderOk = configAffectHerms
#	
#	if !isGenderOk:
#		return false
	var typeFromGender = "none"
	if(charGender == NpcGender.Male):
		typeFromGender = configMales
	if(charGender == NpcGender.Female):
		typeFromGender = configFemales
	if(charGender == NpcGender.Shemale):
		typeFromGender = configShemales
	if(charGender == NpcGender.Herm):
		typeFromGender = configHerms
	if(charGender == NpcGender.Peachboy):
		typeFromGender = configPeachboys
	
	if typeFromGender == "none":
		return "none"
	
	if charType == CharacterType.Inmate:
		if RNG.chance(configChanceInmates): 
			var inmateType = character.getInmateType()
			if !(
			(configAffectGBI && inmateType == InmateType.General) or \
			(configAffectHSI && inmateType == InmateType.HighSec) or \
			(configAffectSDI && inmateType == InmateType.SexDeviant)
			):
				return "none"
		else:
			return "none"
			
	if !(
		charType == CharacterType.Guard && RNG.chance(configChanceGuards) or \
		charType == CharacterType.Engineer && RNG.chance(configChanceEngineers) or \
		charType == CharacterType.Nurse && RNG.chance(configChanceNurses)
		) && charType != "Inmate": 
			return "none"
	
	match typeFromGender:
		"beltA":
			return RNG.pick(["beltP", "beltV", "beltPV"])
		"cage&beltP":
			if RNG.chance(configBeltChance):
				return "beltP"
			else:
				return "cage"
		"cages&beltV":
			if RNG.chance(configBeltChance):
				return "beltV"
			else:
				return "cage"
		"any":
			if RNG.chance(configBeltChance):
				return RNG.pick(["beltP", "beltV", "beltPV"])
			else:
				return "cage"
		_: return typeFromGender


static func putInChastityStatic(characterID):
	if (DEBUG): print_debug("Static put in chastity")
	var character = GlobalRegistry.getCharacter(characterID)
#	if DEBUG: print_debug("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
	if DEBUG_PLUS: print_debug("Inside PutNpcInChastity func")
	if DEBUG_PLUS: print_debug(character.getName())
	if DEBUG_PLUS: print_debug(character.getCharacterType())
	if DEBUG_PLUS: print_debug(character.npcGeneratedGender)

	var typeOfChastity = shouldBeCheckedStatic(characterID)
#	if typeOfChastity == "skip":
#		return
	if DEBUG_PLUS && (DEBUG || DEBUG_23): print_debug(typeOfChastity)
	var chastityNpcsStatic = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	if typeOfChastity != "none":
		cageThemStatic(character, characterID, typeOfChastity)
		chastityNpcsStatic[characterID] = {
				"name": character.getName(),
				"isCaged": true,
				"type": typeOfChastity
			}
	else:
		chastityNpcsStatic[characterID] = {
			"name": character.getName(),
			"isCaged": false,
			"type": typeOfChastity # should always be "none"
		}
	if DEBUG_PLUS: print_debug(chastityNpcsStatic.get(characterID))
	GM.main.setFlag("ChastityForEveryone.databaseNew", chastityNpcsStatic)


static func cageThemStatic(character, _characterID, typeOfChastity):
	if DEBUG: print_debug("Locking up: "+str(character.getName()))
	var chastityCageItem
	var configFlatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var variantNonPermaChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentChance
	var variantNonPermaBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentBeltChance
	var level = RNG.randi_range(FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMin,
								FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMax)
	level = level * FoxGlobals.ofModule("ChastityForEveryone").configChastityLvlMultip
	if level < 1: level=1
	
	if typeOfChastity == "cage":
		#cage
		if(RNG.chance(configFlatCageChance)):	
			if RNG.chance(variantNonPermaChance): 
				chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
				chastityCageItem.setRestraintLevel(level)
			else: 
				chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
		else:
			if RNG.chance(variantNonPermaChance):
				chastityCageItem = GlobalRegistry.createItem("ChastityCage")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
	#belt
	elif typeOfChastity == "beltPV":
		if RNG.chance(variantNonPermaBeltChance):
			chastityCageItem = GlobalRegistry.createItem("GenitalChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		else:
			chastityCageItem = GlobalRegistry.createItem("PermanentGenitalChastityBelt")
	elif typeOfChastity == "beltV":
		if RNG.chance(variantNonPermaBeltChance):
			chastityCageItem = GlobalRegistry.createItem("ChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		else:
			chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltVagina")
	elif typeOfChastity == "beltP":
		if RNG.chance(variantNonPermaBeltChance):
			chastityCageItem = GlobalRegistry.createItem("PenisChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		else:
			chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltPenis")

	character.getInventory().forceEquipRemoveOther(chastityCageItem)

