# mod version: 2.31
# this class generally covers the interaction when the inmate is NOT wearing chastity, but should be
extends PawnInteractionBase

var DEBUG = false

const FoxGlobals = preload("res://FoxLib/Globals.gd") 
#var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
#var guardsInspect = FoxGlobals.ofModule("ChastityForEveryone").configGuardsInspect
#var engineersInspect = FoxGlobals.ofModule("ChastityForEveryone").configEngineersInspect
#var nursesInspect = FoxGlobals.ofModule("ChastityForEveryone").configNursesInspect

#var checkChance = FoxGlobals.ofModule("ChastityForEveryone").configCheckChance
var inspectorUnwillingChance = 50
var inspectorUnwilling = false
var globalInmateOutranInspector = false
var flatCage = false

var chastityNpcs = {}

var loopBrakerFailsafe = 0
var rng

var badLocations:Array = ["medical_confessionary", "eng_breakroom", "eng_workshop", "mining_taviroom", "mining_shafts_entering"]

#2.3
var chastityNpcsOld
var chastityPC
var chastityString
var inspectorBelted = "beltPV"
func isWearingChastityCageOrBelt(character):
	if (DEBUG): print_debug(character.getName())
	var toReturn = false
	if(character.getInventory().hasSlotEquipped(InventorySlot.Penis)):
		var item = character.getInventory().getEquippedItem(InventorySlot.Penis)
		if(item.hasTag(ItemTag.ChastityCage)):
			toReturn = true
	elif(character.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		var item = character.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
		if item.hasTag(ItemTag.ChastityCage) || "Chastity Belt" in item.getVisibleName(): #todo: remove when ChastityBelts all have the tag "ChastityCage"
			toReturn = true
	return toReturn
	
func pickBelt(character, forced = false):
	var configMales = FoxGlobals.ofModule("ChastityForEveryone").configMales
	var configFemales = FoxGlobals.ofModule("ChastityForEveryone").configFemales
	var configShemales = FoxGlobals.ofModule("ChastityForEveryone").configShemales
	var configHerms = FoxGlobals.ofModule("ChastityForEveryone").configHerms
	var configPeachboys = FoxGlobals.ofModule("ChastityForEveryone").configPeachboys
	var pcDatabaseString = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"]
	
	var charGender
	var typeFromGender = "beltPV" #failsafe	
	
	if(character.isPlayer()):
		if(character.hasPenis() && !character.hasVagina()):
			typeFromGender = "beltP"
		if(!character.hasPenis() && character.hasVagina()):
			typeFromGender = "beltV"
		if(character.hasPenis() && character.hasVagina()):
			if "belt" in pcDatabaseString: #2.31
				typeFromGender = pcDatabaseString
			else:
				typeFromGender = configHerms
				if typeFromGender == "cage" || typeFromGender == "cage&beltP":
					typeFromGender = "beltP"
				if  typeFromGender == "cages&beltV":
					typeFromGender = "beltV"
				if typeFromGender == "any":
					typeFromGender = RNG.pick(["beltP", "beltV", "beltPV"])
	else:
		charGender = character.npcGeneratedGender
	
		if(charGender == NpcGender.Male):
			typeFromGender = configMales
			if typeFromGender == "cage" || typeFromGender == "cage&beltP":
				typeFromGender = "beltP"
			elif forced:
				typeFromGender = "beltP"
		if(charGender == NpcGender.Female):
			typeFromGender = configFemales
			if forced:
				typeFromGender = "beltV"
		if(charGender == NpcGender.Peachboy):
			typeFromGender = configPeachboys
			if forced:
				typeFromGender = "beltV"
		if(charGender == NpcGender.Shemale) || typeFromGender == "cage&beltP":
			typeFromGender = configShemales
			if typeFromGender == "cage" || typeFromGender == "cage&beltP":
				typeFromGender = "beltP"
			if forced:
				typeFromGender = "beltP"
		if(charGender == NpcGender.Herm):
			typeFromGender = configHerms
			if typeFromGender == "cage" || typeFromGender == "cage&beltP":
				typeFromGender = "beltP"
			if  typeFromGender == "cages&beltV":
				typeFromGender = "beltV"
			if typeFromGender == "any" || forced:
				typeFromGender = RNG.pick(["beltP", "beltV", "beltPV"])
	
	return typeFromGender


func makeChastityString(characterID, isPlayer, full=false):
	if(isPlayer):
		chastityString = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"]
	else:
		chastityString = GM.main.getFlag("ChastityForEveryone.databaseNew", {}).get(characterID)["type"]
	if !full && "belt" in chastityString:
		chastityString = "belt" #strips P, V or A from the name
	return chastityString


# idk, I don't get it, I just did it through flags
#func saveData():
#	var data = .saveData()
#	data["WasPutInChastity"] = chastityNpcs
#	return data
#
#func loadData(_data):
#	chastityNpcs = SAVE.loadVar(_data, "WasPutInChastity", {"test": "from load"})


func _init():
	id = "ChastityPolice"


func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("inspector", _pawns["inspector"])
	doInvolvePawn("inmate", _pawns["inmate"])
	setState("", "inmate")	


func getActivityIconForRole(_role:String):
	return RoomStuff.PawnActivity.Struggle


func shouldRunOnMeet(_pawn1, _pawn2, _pawn2Moved:bool):
	# 2.31
	if !FoxGlobals.ofModule("ChastityForEveryone").configModEnabled:
		return [false]	
	#
	
	chastityNpcsOld = GM.main.getFlag("ChastityForEveryone.database", {})
	chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	chastityPC = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})

# THIS IS HOW IT LOOKED IN 2.3 I'M SO FUCING SILLY -> IF I actually added the return [false], which I thankfully forgot, the scene would NEVER run X_X
#	if(chastityNpcsOld=={} || chastityNpcs=={} || chastityPC=={}): 
#		print_debug("ChastityForEveryone: Mod not yet ready, skipping ChastityPolice scene for now.")
	if((chastityNpcsOld=={} && chastityNpcs=={}) || chastityPC=={}):
		print_debug("ChastityForEveryone: Mod not yet ready, skipping "+id+" scene for now.")
		return ["false"]
	# 2.31
	if !_pawn1.isPlayer() && !(_pawn1.charID in chastityNpcs.keys()):
		if (DEBUG): print_debug("!!", _pawn1.charID)
		preload("res://Modules/ChastityForEveryone/ChastityBigBrother.gd").putInChastityStatic(_pawn1.charID)
		chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	if !_pawn2.isPlayer() && !(_pawn2.charID in chastityNpcs.keys()):
		if (DEBUG): print_debug("!!", _pawn2.charID)
		preload("res://Modules/ChastityForEveryone/ChastityBigBrother.gd").putInChastityStatic(_pawn2.charID)
		chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	#
	
	var guardsInspect = FoxGlobals.ofModule("ChastityForEveryone").configGuardsInspect
	var engineersInspect = FoxGlobals.ofModule("ChastityForEveryone").configEngineersInspect
	var nursesInspect = FoxGlobals.ofModule("ChastityForEveryone").configNursesInspect	
	var checkChance = FoxGlobals.ofModule("ChastityForEveryone").configCheckChance
	
	
	if (DEBUG): print_debug("!"+_pawn1.getChar().getName()+"!+!"+_pawn2.getChar().getName()+"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1")
#	if (DEBUG): print_debug("chastityNpcs in Chastity Police")
	if (DEBUG): print_debug("chastityNpcs.size()", chastityNpcs.size())
	if(!_pawn1.getChar().isPlayer() && !_pawn2.getChar().isPlayer()):
		if (DEBUG): print_debug(_pawn1.getCharType())
		if (DEBUG): print_debug(chastityNpcs.get(_pawn1.charID))
		if (DEBUG): print_debug(_pawn2.getCharType())
		if (DEBUG): print_debug(chastityNpcs.get(_pawn2.charID))
	#if (DEBUG): print_debug("?"+_pawn1.getChar().getFlag(CharacterFlag.WasPutInChastity)+"?+?"+_pawn2.getChar().getFlag(CharacterFlag.WasPutInChastity)+"?????????????????????????????????????????????????????????????????????")
	
	var location = _pawn1.getLocation()
	if badLocations.has(location):
		if (DEBUG): print_debug("bad location")
		return [false]
	
	if(!_pawn1.canBeInterrupted() || !_pawn2.canBeInterrupted()):
		if (DEBUG): print_debug("one of them can't be interupted")
		return [false]
		
	#stop if either is unconscious
	if(_pawn1.getChar().getConsciousness() <= 0.0 || _pawn2.getChar().getConsciousness() <= 0.0):
		if (DEBUG): print_debug("stop if either is unconscious")
		return [false]
		
	# one has to NOT be an inmate
	if(_pawn1.isInmate() && _pawn2.isInmate()):
		if (DEBUG): print_debug("one has to not be an inmate")
		return [false]

	# Not two staff members... currently
	if(_pawn1.isStaff() && _pawn2.isStaff()):
		if (DEBUG): print_debug("both are staff")
		return [false]
	
	# pawn 1 is the innmate from now on
	if(!_pawn1.isInmate() && _pawn2.isInmate()):
		var temp = _pawn1
		_pawn1 = _pawn2
		_pawn2 = temp
		
	# check FoxLib settings
	#no xor in godot :(
	if(_pawn2.isGuard()): 
		if !guardsInspect: 
			if (DEBUG): print_debug("this type of staff should not inspect")
			return [false]
	if(_pawn2.isEngineer()):
		if !engineersInspect: 
			if (DEBUG): print_debug("this type of staff should not inspect")
			return [false]
	if(_pawn2.isNurse()):
		if !nursesInspect: 
			if (DEBUG): print_debug("this type of staff should not inspect")
			return [false]
	
#	# is non inmate pawn part of the staff?
#	if(!_pawn2.isStaff()):
#		if (DEBUG): print_debug("is non inmate pawn part of the staff?")
#		return [false]
		
#	#stop if inmate doesn't have a penis
#	if(!_pawn1.getChar().hasPenis()):
#		if (DEBUG): print_debug("stop if inmate does not have a penis")
#		return [false]

	#2.31 cooldown
	var currentTime = GM.main.getTime()
	var moduleCooldown = GM.main.getModuleFlag("ChastityForEveryone", "inspectionCooldown", 6*60*60 + 20*60)
#	print_debug("currentTime: ", currentTime)
#	print_debug("moduleCooldown: ", moduleCooldown)
	if currentTime < moduleCooldown:
		return [false]
	#

	#2.3
	if(_pawn1.isPlayer()):
		# stop if pc wasn't put in chastity on game start OR didn't do eliza obidience training
		if GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"]==null && ( !GM.pc.hasPerk(Perk.StartMaleChastity) || !( GM.main.getFlag("MedicalModule.PC_ReceivedPermanentCage")==true && GM.main.getFlag("MedicalModule.Chastity_Event5LockedForever")!=false) ):
			if (DEBUG): print_debug("stop if player wasn't put into forced chastity or finished questline as breeder")
			return [false]
		# stop if pc was put in chastity and wears the cage/belt
		if( 
			(
				GM.pc.hasPerk(Perk.StartMaleChastity) 
				|| ( GM.main.getFlag("MedicalModule.PC_ReceivedPermanentCage")==true 
				&& GM.main.getFlag("MedicalModule.Chastity_Event5LockedForever")!=false) 
			)
			&& isWearingChastityCageOrBelt(_pawn1.getChar())
		):
			if (DEBUG): print_debug("stop if player was put into forced chastity and wears the cage")
			return [false]
		# previous two conditions not met, so player should be locked in:
		chastityString = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"]
	else:
		chastityString = chastityNpcs.get(_pawn1.charID)["type"]
	if (DEBUG): print_debug("chastityString: ", chastityString)
	
	if(chastityString==null): #idk, somethings broken
		chastityString="none"
		
	# stop if inmate doesn't have the locked bodypart:
	match chastityString:
		"none":
			return [false]
		"cage":
			if(!_pawn1.getChar().hasPenis()):
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
		"beltP":
			if(!_pawn1.getChar().hasPenis()):
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
		"beltV":
			if(!_pawn1.getChar().hasVagina()):
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
		"beltPV":
			if(!_pawn1.getChar().hasPenis() && !_pawn1.getChar().hasVagina()): # one remaining is still enough >:)
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
	
	if DEBUG: print_debug("!"+_pawn1.getChar().getName()+"!+!"+_pawn2.getChar().getName()+"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1")
	if DEBUG: print_debug(GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"])
	if "belt" in chastityString:
		chastityString = "belt" #strips P, V or A from the name

	if(!_pawn1.isPlayer()):
		# stop if character wasn't put in chastity on generation
#		if(!GlobalRegistry.getCharacter(_pawn1.charID).getFlag(CharacterFlag.WasPutInChastity)):
		if(chastityNpcs.get(_pawn1.charID)["type"] == "none"):
			if (DEBUG): print_debug("stop if character wasn't put into forced chastity")
			return [false]
		# stop if character was put in chastity on generation and wears the cage
		if(chastityNpcs.get(_pawn1.charID)["type"] != "none" && isWearingChastityCageOrBelt(_pawn1.getChar())):
			if (DEBUG): print_debug("stop if character was put into forced chastity and wears the cage/belt")
			return [false]
	
	if(_pawn1.isPlayer()):
		if checkChance != 0:
			checkChance = GM.pc.getExposure()+checkChance
		if(RNG.chance(checkChance)):
			#2.31
			GM.main.setModuleFlag( "ChastityForEveryone", "inspectionCooldown",(GM.main.getTime()+(1.5*60*60)) )
			#
			return [true, {inmate=_pawn1.charID, inspector=_pawn2.charID}, {}]
	else:
		if(RNG.chance(checkChance)):
			#2.31
			GM.main.setModuleFlag( "ChastityForEveryone", "inspectionCooldown",(GM.main.getTime()+(20*60)) )
			#
			return [true, {inmate=_pawn1.charID, inspector=_pawn2.charID}, {}]
		
	return[false]
	

func getPreviewLineForRole(_role:String) -> String:
	if(_role == "inspector"):
		return "{inspector.name} stopped {inmate.name} to inspect {inmate.hisHer} chastity cage."
	if(_role == "inmate"):
		return "{inmate.name} is having their chastity cage inspected by {inspector.name}."
	return .getPreviewLineForRole(_role)


func init_text():
	if (DEBUG): print_debug("Chastity Police Event is running!!!!!!!!!!!!!!")
	if (DEBUG): print_debug(getRolePawn("inmate").getChar().getName())
	if (DEBUG): print_debug(getRolePawn("inspector").getChar().getName())
	chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {}) #sometimes it's Nil, this seems to fix it...?
	if(RNG.chance(inspectorUnwillingChance) && (getRolePawn("inspector").getChar().isInHeat() || chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none")):
		inspectorUnwilling = true
		if (DEBUG): print_debug("inspectorUnwilling TRUE")
	if (DEBUG): print_debug(inspectorUnwilling)
	saynn("[say=inspector]You there, stop for the inspection immediately![/say]")
	saynn("{inspector.name} approches {inmate.you}.")
	addAction("innitialDialogue", "(continue)", "", "default", 1.0, 60, {})
#	addAction("innitialRan", "(Run!)", "You won't get me!", "default", 1.0, 60, {})

func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	rng = RNG.chance(50) # used in inmateResists_text()
	if(_id == "innitialDialogue"):
		setState("confrontation", "inmate")
#	if(_id == "innitialRan"):
#		setState("pcStartedRunning", "inmate")


func confrontation_text():
	saynn("[say=inspector]Chastity inspection! Database records indicate you are supposed to be wearing your mandated chastity gear...[/say]")
	if(inspectorUnwilling):
		if(chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none"):
			saynn("[say=inspector]...So do I, to be frank. Stupid pieces of crap...[/say]")
		else:
			saynn("[say=inspector]It's... kinda dumb... hehe... he.[/say]")
			saynn("{inspector.name} rubs {inspector.hisHer} legs together.")
	else:
		saynn("[say=inspector]...Are you?![/say]")
	addAction("confrontationInmateResists", "You’re wrong!", "", "default", 1.0, 60, {})
	addAction("confrontationInmateResists", "It's a mistake!", "", "default", 1.0, 60, {})
	addAction("confrontationInmateComplies", "Well...", "", "default", 1.0, 60, {})
	addAction("confrontationInmateComplies", "Ugh, I guess", "", "default", 1.0, 60, {})
	addAction("confrontationInmateComplies", "You're right", "You like being caged anyways.", "default", 1.0, 60, {})
	addAction("confrontationInmateStartedRunning", "(Run!)", "You won’t be made to wear this stupid thing again!", "default", 1.0, 60, {})
	addAction("confrontationInmateStartedFightFirst", "(Punch!)", "Catch the inspector by surprise!", "default", 1.0, 60, {})

func confrontation_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "confrontationInmateResists"):
		setState("inmateResists", "inmate")
	if(_id == "confrontationInmateComplies"):
		setState("inmateComplies", "inmate")
	if(_id == "confrontationInmateStartedRunning"):
		setState("inmateRuns", "inmate")
	if(_id == "confrontationInmateStartedFightFirst"):
		setState("inmateFightsFirst", "inmate")


func inmateResists_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	chastityString = makeChastityString(getRolePawn("inmate").getID(), isPlayer) #doesn't seem to work globally :(
	if (!isPlayer): saynn("[say=inmate]Bullshit![/say]")
	if(!inspectorUnwilling):
		saynn("[say=inspector]Don't try to trick me. Where's your "+chastityString+"?![/say]")
		addAction("resistsComplies", "(Obey)", "", "default", 1.0, 60, {})
		addAction("resistsFights", "(Fight!)", "Fight for your (genital's) freedom!", "default", 1.0, 60, {})
	else:
		if(rng): # if it was randomized here, the code would print one thing to the screen and do other, probably similar to the reason why the sex scenes werent working for me in the first place and I had to split it into two stages, I might fix it later, so TODO
			if(chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none"):
				saynn("[say=inspector]You know what? Fuck this, I have enough of them anyways. You are free to go, but please, don’t tell anyone, especially that fucking bitch doctor, alright?[/say]")
			else:
				saynn("[say=inspector]You know what? Fuck this, I have enough of them anyways - they make it harder for me to get rid of this damn heat, you know?[/say]")
			if rng: addAction("resistsEnding", "(Leave)", "", "default", 1.0, 60, {}) #redundant if, to clean-up at other time TODO
		else:
			if(getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) < 1.3):
				saynn("[say=inspector]Tell you what, if you let me play with that uncaged bits of yours I’d let you go, what do you say?[/say]")
				if(getRolePawn("inspector").scorePersonality({PersonalityStat.Subby:1.0}) > 0.2):
					saynn("{inspector.name} wants {inmate.you} to top {inspector.himHer}.")
					if !rng: addAction("resistsInmateTops", "Agree (Be top)", "", "default", 1.0, 60, {})
				else:
					saynn("{inspector.name} wants {inmate.you} to bottom for {inspector.himHer}.")
					if !rng: addAction("resistsInmateBottoms", "Agree (Be bottom)", "", "default", 1.0, 60, {})
				addAction("resistsInmateRuns", "(Run away!)", "Try to run now!", "default", 1.0, 60, {})
			else:
				saynn("[say=inspector]I honestly envy you being able to run cage-free like that. Fuck it. You are free to go.[/say]")
				if(!getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) < 1.3):
					addAction("resistsEnding", "(Leave)", "", "default", 1.0, 60, {})

func inmateResists_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "resistsComplies"):
		setState("inmateComplies", "inmate")
	if(_id == "resistsFights"):
		setState("inmateFights", "inmate")
	if(_id == "resistsEnding"):
		setState("inmateFree", "inmate")
	if(_id == "resistsInmateTops"):
		setState("inmateTops", "inmate")
	if(_id == "resistsInmateBottoms"):
		setState("inmateBottoms", "inmate")
	if(_id == "resistsInmateRuns"):
		setState("inmateRuns", "inmate")


func inmateTops_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	saynn("{inspector.name} wants {inmate.you} to top {inspector.himHer}.")
	if (!isPlayer): saynn("[say=inmate]Fine.[/say]")
	addAction("inmateTopsSex", "(Sex)", "","default", 1.0, 600, {start_sex=["inmate", "inspector", SexType.DefaultSex, {SexMod.DisableDynamicJoiners: true}],})
		
func inmateTops_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateTopsSex"):
		var theInspectorID = getRolePawn("inspector").getChar().getID()
		var sexResult = getSexResult(_args)
		var subSatisfaciton:float = sexResult.getSubSatisfaction(theInspectorID)
		var gotUncon:bool = sexResult.isSubUnconscious(theInspectorID)
		if(gotUncon):
			setState("inspectorGotRekt", "inmate")
		elif(subSatisfaciton >= 0.8):
			setState("inspectorSatisfied", "inmate")
		else:
			setState("inspectorNotSatisfied", "inmate")


func inmateBottoms_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	saynn("{inspector.name} wants {inmate.you} to be a bottom for {inmate.himHer}.")
	if (!isPlayer): saynn("[say=inmate]Fine.[/say]")
	addAction("inmateBottomsSex", "(Sex)", "", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})

func inmateBottoms_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateBottomsSex"):
		var theInspectorID = getRolePawn("inspector").getChar().getID()
		var sexResult = getSexResult(_args)
		var domSatisfaciton:float = sexResult.getDomSatisfaction(theInspectorID)
		#var gotUncon:bool = sexResult.isDomUnconscious(theInspectorID) doesn't exist :V
		#if(gotUncon):
		#	setState("inspectorGotRekt", "inmate")
		if(domSatisfaciton >= 0.8):
			setState("inspectorSatisfied", "inmate")
		else:
			setState("inspectorNotSatisfied", "inmate")


func inspectorGotRekt_text():
	saynn("Well, it seems that {inspector.name} is now unconscious. At least they can’t bother {inmate.you} currently.")
	addAction("inspectorGotRektUps", "Whoops...", "You really didn't mean it...", "default", 1.0, 60, {})

func inspectorGotRekt_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inspectorGotRektUps"):
		setState("inmateFree", "inmate")


func inspectorSatisfied_text():
	saynn("{inspector.name} is satisfied with {inmate.your} performance.")
	saynn("[say=inspector]"+RNG.pick([
			"Not bad for a cheap whore.",
			"You're free to go, whore.",
			"You earned it, slut. Go.",
			"I hope I will run into you again, little slut.",
		])+"[/say]")
	addAction("inspectorSatisfiedEnd", "(continue)", "", "default", 1.0, 60, {})

func inspectorSatisfied_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inspectorSatisfiedEnd"):
		setState("inmateFree", "inmate")


func inspectorNotSatisfied_text():
	saynn("[say=inspector]"+RNG.pick([
			"That sucked! Fuck you, the deal is off.",
			"You're such a bad whore, why would I be lenient? You're getting locked up, right now.",
			"Fuck off, you suck as a whore. It'll be beter for everyone to lock you up.",
		])+"[/say]")
	addAction("inspectorNotSatisfiedReleasedCaged", "(Get locked up)", "", "default", 1.0, 60, {})
	addAction("inspectorNotSatisfiedFight", "(Fight!)", "If not by kindness, then by force", "default", 1.0, 60, {})

func inspectorNotSatisfied_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inspectorNotSatisfiedReleasedCaged"):
		setState("releasedCaged", "inmate")
	if(_id == "inspectorNotSatisfiedFight"):
		setState("inmateFights", "inmate")


func inmateComplies_text():
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var configBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configBeltChance
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	chastityString = makeChastityString(getRolePawn("inmate").getID(), isPlayer) #doesn't seem to work globally :(
	if (!isPlayer): saynn("[say=inmate]Well, hehe, I.. I... I can explain![/say]")
	if (!isPlayer): saynn("[say=inspector]For sure.[/say]")
	saynn("[say=inspector]Now, let me see. Present your crotch, now.[/say]")
	if (isPlayer): saynn("You let your genitals be inspected.")
	if (!isPlayer): saynn("{inmate.You} {inmate.youVerb('let')} {inmate.hisHer} genitals be inspected.")
	if(isPlayer):
		GM.pc.addLust(15)
	if(getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) > 0.2):
		saynn("[say=inspector]Hah! I knew it, you little cheater![/say]")
	else:
		saynn("[say=inspector]Oh, your "+chastityString+" is missing![/say]")
	if(getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.3):
		saynn("[say=inspector]That’s unacceptable, good inmates should be wearing their chastity![/say]")
		if getRolePawn("inmate").getChar().hasPenis() && (chastityString == "cage" || !configBeltChance>0):
			addAction("compliesCagedRandom", "(Get locked up)", "", "default", 1.0, 60, {})
		else:
			addAction("compliesBelted", "(Get locked up)", "", "default", 1.0, 60, {})
	else:
		saynn("[say=inspector]I’m sorry, but rules are rules. I have to lock you up.[/say]")
#		if(flatCageChance < 100):
#			if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular one?[/say]")
#			addAction("compliesCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
#			addAction("compliesCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
#			addAction("compliesCagedRandom", "Any will do", "", "default", 1.0, 60, {})
#		else:
#			addAction("compliesCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
		if getRolePawn("inmate").getChar().hasPenis() && (chastityString == "cage" || !configBeltChance>0):
			if(flatCageChance < 100):
				if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular cage?[/say]")
				addAction("compliesCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
				addAction("compliesCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
				addAction("compliesCagedRandom", "Any will do", "", "default", 1.0, 60, {})
			else:
				addAction("compliesCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
		elif !getRolePawn("inmate").getChar().hasPenis():
			if (isPlayer): saynn("[say=inspector]Get ready to be belted back up[/say]")
			addAction("compliesBelted", "Get locked up", "", "default", 1.0, 60, {})
		else:
			if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: belt or cage?[/say]")
			addAction("compliesBelted", "Belt", "Bulkier, but more practical", "default", 1.0, 60, {})
			if RNG.chance(flatCageChance):
				addAction("compliesCagedFlat", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
			else: 
				addAction("compliesCagedRegular", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
			
	if (!isPlayer): saynn("[say=inmate]Let’s just get this over with...[/say]")

func inmateComplies_do(_id:String, _args:Dictionary, _context:Dictionary):
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var nonPermanentChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentChance
	var NonPermanentBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentBeltChance
	var level = RNG.randi_range(FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMin,
								FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMax)
	level = level * FoxGlobals.ofModule("ChastityForEveryone").configChastityLvlMultip
	var chastityCageItem = GlobalRegistry.createItem("ChastityCage")
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	if level < 1: level=1
	if(_id == "compliesCagedRegular"):
		if RNG.chance(nonPermanentChance) && !isPlayer: 
			chastityCageItem = GlobalRegistry.createItem("ChastityCage")
			chastityCageItem.setRestraintLevel(level)
		else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
		var theInmate = getRolePawn("inmate").getChar()
		theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "compliesCagedFlat"):
		if RNG.chance(nonPermanentChance) && !isPlayer: 
			chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
			chastityCageItem.setRestraintLevel(level)
		else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
		var theInmate = getRolePawn("inmate").getChar()
		theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "compliesCagedRandom"):
		if(RNG.chance(flatCageChance)):
			if RNG.chance(nonPermanentChance) && !isPlayer: 
				chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
				chastityCageItem.setRestraintLevel(level)
			else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
			var theInmate = getRolePawn("inmate").getChar()
			theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		else:
			if RNG.chance(nonPermanentChance) && !isPlayer: 
				chastityCageItem = GlobalRegistry.createItem("ChastityCage")
				chastityCageItem.setRestraintLevel(level)
			else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
			var theInmate = getRolePawn("inmate").getChar()
			theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "compliesBelted"):
		var theInmate = getRolePawn("inmate").getChar()
		var belt = pickBelt(theInmate)
		if belt == "beltPV":
			if RNG.chance(NonPermanentBeltChance) && !isPlayer:
				chastityCageItem = GlobalRegistry.createItem("GenitalChastityBelt")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("PermanentGenitalChastityBelt")
		elif belt == "beltV":
			if RNG.chance(NonPermanentBeltChance) && !isPlayer:
				chastityCageItem = GlobalRegistry.createItem("ChastityBelt")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltVagina")
		elif belt == "beltP":
			if RNG.chance(NonPermanentBeltChance) && !isPlayer:
				chastityCageItem = GlobalRegistry.createItem("PenisChastityBelt")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltPenis")

		theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "compliesEnd"): #2.31, RCHI only
		setState("inmateAllGood", "inmate")


func inmateRuns_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	var theInmate = getRolePawn("inmate").getChar()
	var theInspector = getRolePawn("inspector").getChar()
	var inmateOutranInspector = true
	if(theInmate.getStamina() <= 5 ||
	   theInmate.hasBoundLegs() ||
	   theInmate.isBlindfolded()):
		inmateOutranInspector = false
	if(!theInmate.isPlayer() && RNG.chance(50)):
		inmateOutranInspector = false
	if(theInmate.isPlayer() && RNG.chance(50-GM.pc.getStat(Stat.Agility)*2)):
		inmateOutranInspector = false
	if(!theInmate.isPlayer() && !inmateOutranInspector && #extra chance for inmate
	   (theInspector.getStamina()+10 < theInmate.getStamina()) ||
	   (theInspector.hasBoundLegs() && !theInmate.hasBoundLegs()) ||
	   (theInspector.isBlindfolded() && !theInmate.isBlindfolded()) ):
		inmateOutranInspector = true
	saynn("{inmate.You} decided that running is {inmate.your} best option.")
	if (!isPlayer): saynn("[say=inmate]You won’t get me so easily![/say]")
	saynn("[say=inspector]Hey, get beck here![/say]")
	if(inmateOutranInspector == true):
		addAction("inmateRunsRunsSuccess", "(continue)", "", "default", 1.0, 60, {})
	else:
		addAction("inmateRunsRunsFail", "(continue)", "", "default", 1.0, 60, {})

func inmateRuns_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateRunsRunsSuccess"):
		setState("inmateRunsSuccess", "inmate")
	elif(_id == "inmateRunsRunsFail"):
		setState("inmateRunsFail", "inmate")
	else:
		# something went wrong
		print_debug("inmateRuns ERROR!")
		stopMe() 
		#setState("releasedCaged", "inmate")


func inmateRunsSuccess_text():
	saynn("{inmate.You} managed to run away from the inspection!")
	addAction("inmateRunsSuccessContinue", "(continue)", "", "default", 1.0, 60, {})

func inmateRunsSuccess_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateRunsSuccessContinue"):
		setState("inmateFree", "inmate")

func inmateRunsFail_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	saynn("Despite the best effort {inmate.you} got caught by the staff.")
	if (!isPlayer): saynn("[say=inmate]Ugh! Let me go![/say]")
	saynn("[say=inspector]*pants* Heh, I got you, no more funny business![/say]")
	addAction("inmateRunsFailContinue", "(continue)", "", "default", 1.0, 60, {})

func inmateRunsFail_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateRunsFailContinue"):
		setState("releasedCaged", "inmate")


func inmateFightsFirst_text():
	saynn("Not wanting to go down so easily, {inmate.you} caught {inspector.name} off guard and sneaked a punch to the stomach.")
	#var theInmate = getRolePawn("inmate").getChar()
	var theInspector = getRolePawn("inspector").getChar()
	#theInspector.addPain(15)
	theInspector.addEffect(StatusEffect.Stunned)
#	theInspector.addEffect(StatusEffect.Wounded)
	saynn("[say=inspector]Ouch! You fucker![/say]")
	sayLine("inspector", "AttackStart", {main="inspector", target="inmate"})
	#addAction("firstFight", "Fight!", "Begin the fight", "default", 1.0, 60, {}) debug
	addAction("firstFight", "Fight!", "Begin the fight", "fight", 1.0, 600, {start_fight=["inmate", "inspector"],})

func inmateFightsFirst_do(_id:String, _args:Dictionary, _context:Dictionary):
	var fightResult = getFightResult(_args)
	if(fightResult["won"]):
		sendSocialEvent("inmate", "inspector", SocialEventType.LostFight)
		if(getRolePawn("inmate").isPlayer()):
			GM.pc.addExperience(20)
		setState("inmateWonFight", "inmate")
	else:
		sendSocialEvent("inspector", "inmate", SocialEventType.LostFight)
		setState("inmateLostFight", "inspector")


func inmateFights_text():
	sayLine("inspector", "AttackStart", {main="inspector", target="inmate"})
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	if(!isPlayer): saynn("[say=inmate]I won't let do anything to me![/say]")
	addAction("firstFight", "Fight!", "Begin the fight", "fight", 1.0, 600, {start_fight=["inmate", "inspector"],})

func inmateFights_do(_id:String, _args:Dictionary, _context:Dictionary):
	var fightResult = getFightResult(_args)
	if(fightResult["won"]):
		sendSocialEvent("inmate", "inspector", SocialEventType.LostFight)
		if(getRolePawn("inmate").isPlayer()):
			GM.pc.addExperience(20)
		setState("inmateWonFight", "inmate")
	else:
		sendSocialEvent("inspector", "inmate", SocialEventType.LostFight)
		setState("inmateLostFight", "inspector")


func inmateWonFight_text():
	saynn("{inspector.name} hits the floor. {inmate.name} won!")
	sayLine("inspector", "FightLostGeneric", {winner="inmate", loser="inspector"})
	addAction("inmateWonLeave", "(Leave)", "You've had your victory", "default", 1.0, 60, {})
	if(getRolePawn("inmate").getChar().canStartSex()):
		addAction("inmateWonPunish", "(Punish)", "Make them pay for bothering you!", "default", 1.0, 60, {})
	else:
		addDisabledAction("(Punish)", "You can’t fuck them with your restrains...")
	if(getRolePawn("inspector").getChar().hasReachablePenis() && getRolePawn("inspector").getChar().hasReachableVagina()):
		addAction("inmateWonCage", "(cage) Role reversal! ", "Cage them!", "default", 1.0, 60, {})
		addAction("inmateWonBelt", "(belt) Role reversal! ", "Lock them up!", "default", 1.0, 60, {})
	elif(getRolePawn("inspector").getChar().hasReachablePenis()):
		addAction("inmateWonCage", "(cage) Role reversal!", "Cage them!", "default", 1.0, 60, {})
		addAction("inmateWonBelt", "(belt) Role reversal! ", "Lock them up!", "default", 1.0, 60, {})
	elif(getRolePawn("inspector").getChar().hasReachableVagina()):
		addAction("inmateWonBelt", "Role reversal!", "Lock them up!", "default", 1.0, 60, {})
	else:
		addDisabledAction("Role reversal!", "They have to have reachable genitalia")

func inmateWonFight_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateWonLeave"):
		setState("inmateFree", "inmate")
	if(_id == "inmateWonPunish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("inmate"), target=getRoleID("inspector")})
	if(_id == "inmateWonCage"):
		setState("cageTheInspector", "inmate")
	if(_id == "inmateWonBelt"):
		setState("beltTheInspector", "inmate")


func cageTheInspector_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	saynn("Reaching out to {inspector.hisHer} pocket {inmate.you} found...")
	if(RNG.chance(flatCageChance)):
		saynn("... a flat chastity cage!")
		flatCage = true
	else:
		saynn("... a regular chastity cage!")
		flatCage = false
	if (!isPlayer): saynn("[say=inmate]And what do we have here![/say]")
	saynn("[say=inspector]What are you going to… No! Please, leave me alone![/say]")
	saynn("{inmate.You} {inmate.youVerb('grab')} {inspector.himHer} by {inspector.hisHer} {inspector.penis} and start forcing chastity on it. It’s not easy, as {inspector.heShe} {inspector.youVerb('keep')} resisting. Yet, after a while, {inmate.you} successfully {inmate.youVerb('lock')} ‘em up, and {inmate.youVerb('break')} the key right in front of {inspector.himHer}.")
	saynn("[say=inspector]What are you going to… No! Please, leave me alone![/say]")
	addAction("inmateCages", "(Leave them)", "", "default", 1.0, 60, {})

func cageTheInspector_do(_id:String, _args:Dictionary, _context:Dictionary):
#	var nonPermanentChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentChance
#	var NonPermanentBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentBeltChance
	var level = RNG.randi_range(FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMin,
								FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMax)
	level = level * FoxGlobals.ofModule("ChastityForEveryone").configChastityLvlMultip
	if level < 1: level=1
	var chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
	if flatCage:
#		if RNG.chance(nonPermanentChance): # removed 2.3
		chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
		chastityCageItem.setRestraintLevel(level)
#		else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
	else:
#		if RNG.chance(nonPermanentChance): # removed 2.3
		chastityCageItem = GlobalRegistry.createItem("ChastityCage")
		chastityCageItem.setRestraintLevel(level)
#		else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
	var theInspector = getRolePawn("inspector").getChar()
	theInspector.getInventory().forceEquipStoreOther(chastityCageItem)
	if(_id == "inmateCages"):
		setState("inmateFree", "inmate")


func beltTheInspector_text():
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	var theInspector = getRolePawn("inspector").getChar()
	var noBeltsForGender = false #2.31
	saynn("Shaking up the guard {inmate.you} found...")
	inspectorBelted = pickBelt(theInspector, true)
	match inspectorBelted:
		"beltPV": saynn("... a Genital Chastity Belt")
		"beltP": saynn("... a Penis Chastity Belt")
		"beltV": saynn("... a Vaginal Chastity Belt")
		_: #failsafe
			saynn("... no chastity belts. Shame.")
			noBeltsForGender = true
	if !noBeltsForGender:
		if (!isPlayer): saynn("[say=inmate]And what do we have here![/say]")
		saynn("[say=inspector]What are you going to… No! Please, leave me alone![/say]")
		saynn("{inmate.You} start forcing chastity belt on {inspector.himHer}. It’s not easy, as {inspector.heShe} {inspector.youVerb('keep')} resisting. Yet, after a while, {inmate.you} successfully {inmate.youVerb('lock')} ‘em up, and {inmate.youVerb('break')} the key right in front of {inspector.himHer}.")
		addAction("inmateCages", "(Leave them)", "", "default", 1.0, 60, {})
	else:
		addAction("inmateNoItems", "(Leave them)", "", "default", 1.0, 60, {})

func beltTheInspector_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateCages"):
		var level = RNG.randi_range(FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMin,
								FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMax)
		level = level * FoxGlobals.ofModule("ChastityForEveryone").configChastityLvlMultip
		if level < 1: level=1
		var chastityCageItem = GlobalRegistry.createItem("GenitalChastityBelt")
		if inspectorBelted == "beltPV":
			chastityCageItem = GlobalRegistry.createItem("GenitalChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		elif inspectorBelted == "beltV":
			chastityCageItem = GlobalRegistry.createItem("ChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		elif inspectorBelted == "beltP":
			chastityCageItem = GlobalRegistry.createItem("PenisChastityBelt")
			chastityCageItem.setRestraintLevel(level)
		var theInspector = getRolePawn("inspector").getChar()
		theInspector.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("inmateFree", "inmate")
	if(_id == "inmateNoItems"):
		setState("inmateFree", "inmate")


func inmateLostFight_text():
	saynn("{inmate.name} hits the floor. {inspector.name} won!")
	sayLine("inmate", "FightLostGeneric", {winner="inspector", loser="inmate"})

	addAction("inmateLostPunish", "Punish", "They gotta serve a punishment!", "punishMean", 1.0, 60, {})
	addAction("inmateLostCage", "Cage them", "Force chastity back on them", "punish", 1.0, 60, {})

	addDefeatButtons("inspector", "inmate")

func inmateLostFight_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateLostPunish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("inspector"), target=getRoleID("inmate")})
	if(_id == "inmateLostCage"):
		setState("releasedCaged", "inmate")


func releasedCaged_text():
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var configBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configBeltChance
	var theInmate = getRolePawn("inmate").getChar()
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	chastityString = makeChastityString(getRolePawn("inmate").getID(), isPlayer) #doesn't seem to work globally :(
	var chastityStringFull = makeChastityString(getRolePawn("inmate").getID(), isPlayer, true) #doesn't seem to work globally :(
	print_debug(isWearingChastityCageOrBelt(theInmate))
	if(loopBrakerFailsafe<=2 && !isWearingChastityCageOrBelt(theInmate)): # chastity on if inmate didn't comply and lost or didn't manage to run away
#		loopBrakerFailsafe += 1 #transformation during the scene or some other weird thing, is it a real possibility? idk
#		saynn("[say=inspector]Let me take a closer look at you now...[/say]")
#		if(getRolePawn("inmate").getChar().isPlayer()):
#			GM.pc.addLust(15)
#		if(getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) > 0.2):
#			saynn("[say=inspector]Hah! I knew it, you little cheater![/say]")
#		else:
#			saynn("[say=inspector]Oh, your cage is missing![/say]")
#		if(getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.3):
#			saynn("[say=inspector]That’s unacceptable, good inmates should be wearing their cages![/say]")
#			addAction("releasedCagedCagedRandom", "(Get caged)", "", "default", 1.0, 60, {})
#		else:
#			saynn("[say=inspector]I’m sorry, but rules are rules. I have to lock you up.[/say]")
#			if(inspectorUnwilling && flatCageChance < 100):
#				if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular one?[/say]")
#				addAction("releasedCagedCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
#				addAction("releasedCagedCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
#				addAction("releasedCagedCagedRandom", "Any will do", "", "default", 1.0, 60, {})
#			else:
#				saynn("[say=inspector]For all of this trouble you coused me, I think flat cage would suit you best.[/say]")
#				addAction("releasedCagedCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
#		if (!isPlayer): saynn("[say=inmate]Fuck, you will pay me for that![/say]")
		loopBrakerFailsafe += 1 #transformation during the scene or some other weird thing, is it a real possibility? idk
		saynn("[say=inspector]Let me take a closer look at you now...[/say]")
		if(isPlayer):
			GM.pc.addLust(15)
		if(getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) > 0.2):
			saynn("[say=inspector]Hah! I knew it, you little cheater![/say]")
		else:
			saynn("[say=inspector]Oh, your "+chastityString+" is missing![/say]")
		if(getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.3):
			saynn("[say=inspector]That’s unacceptable, good inmates should be wearing their chastity![/say]")
			addAction("releasedCagedCagedRandom", "(Get locked up)", "", "default", 1.0, 60, {})
		else:
			saynn("[say=inspector]I’m sorry, but rules are rules. I have to lock you up.[/say]")
			if chastityString == "cage":
				if(inspectorUnwilling && flatCageChance < 100):
					if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular one?[/say]")
					addAction("releasedCagedCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
					addAction("releasedCagedCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
					addAction("releasedCagedCagedRandom", "Any will do", "", "default", 1.0, 60, {})
				else:
					saynn("[say=inspector]For all of this trouble you coused me, I think flat cage would suit you best.[/say]")
					addAction("releasedCagedCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
			elif !getRolePawn("inmate").getChar().hasPenis() || (chastityString == "belt" && chastityStringFull!="beltP"):
				if (isPlayer): saynn("[say=inspector]Get ready to be belted back up![/say]")
				addAction("releasedCagedCagedBelted", "Get locked up", "", "default", 1.0, 60, {})
			else:
				if(inspectorUnwilling && configBeltChance<100):
					if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: belt or cage?[/say]")
					addAction("releasedCagedCagedBelted", "Belt", "Bulkier, but more practical", "default", 1.0, 60, {})
					if RNG.chance(flatCageChance):
						addAction("releasedCagedCagedFlat", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
					else: 
						addAction("releasedCagedCagedRegular", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
				else:
					saynn("[say=inspector]For all of this trouble you coused me, I think belt would suit you best.[/say]")
					addAction("releasedCagedCagedBelted", "(Get locked)", "", "default", 1.0, 60, {})
		if (!isPlayer): saynn("[say=inmate]Fuck, you will pay me for that![/say]")
	else: #got caged in scene already
		saynn("[say=inspector]Stand still now.[/say]")
		saynn("{inspector.name} takes out the chastity gear and starts forcing it on {inmate.you}. They are not as careful nor as skilled, as was the doctor. Or they simply don’t care.")
		saynn("After {inmate.your} genitals get put in chastity, {inspector.name} turns the key on the lock and hides it in {inspector.hisHer} pocket.")
		var tempString = "[say=inspector]Aaaand finished. I’ll make sure this key gets to Eliza.[/say]"
		
		print_debug("femininintiniti", theInmate.getFemininity())
		if(!theInmate.hasPenis() || theInmate.getFemininity() > 40):
			if(theInmate.isPlayer()):
				GM.pc.addPain(5)
				GM.pc.addLust(20)
				saynn(tempString)
				saynn("With your little clitty safely locked up, {inspector.name} leaves you alone.")
			else:
				saynn(tempString)
				saynn("{inmate.name} got {inmate.hisHer} clitty locked up, after that {inspector.name} leaves them alone.")
		else:
			if(theInmate.isPlayer()):
				GM.pc.addPain(5)
				GM.pc.addLust(20)
				saynn(tempString)
				saynn("With {inmate.your} genitals safely locked up, {inspector.name} leaves you alone.")
			else:
				saynn(tempString)
				saynn("{inmate.name} got {inmate.hisHer} genitals locked up, after that {inspector.name} leaves them alone.")
		addAction("releasedCagedEnd", "(Leave)", "", "default", 1.0, 60, {})
	
func releasedCaged_do(_id:String, _args:Dictionary, _context:Dictionary):
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var nonPermanentChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentChance
	var NonPermanentBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configNonPermanentBeltChance
	var level = RNG.randi_range(FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMin,
								FoxGlobals.ofModule("ChastityForEveryone").chastityLvlMax)
	level = level * FoxGlobals.ofModule("ChastityForEveryone").configChastityLvlMultip
	var chastityCageItem = GlobalRegistry.createItem("ChastityCage")
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	if level < 1: level=1
	if(_id == "releasedCagedEnd"):
		print_debug(isWearingChastityCageOrBelt(getRolePawn("inmate").getChar()))
		stopMe()
	if(_id == "releasedCagedCagedRegular"):
		if RNG.chance(nonPermanentChance) && !isPlayer: # potentially, given infinite time, all inmates will be in permanent variants (they won't struggle out of them anymore) - let's say the prison had better and better locks, so inmates slowly lost the ability to struggle out of chastity ;)
			chastityCageItem = GlobalRegistry.createItem("ChastityCage")
			chastityCageItem.setRestraintLevel(level)
		else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
		var theInmate = getRolePawn("inmate").getChar()
		theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "releasedCagedCagedFlat"):
		if RNG.chance(nonPermanentChance): 
			chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
			chastityCageItem.setRestraintLevel(level)
		else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
		var theInmate = getRolePawn("inmate").getChar()
		theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "releasedCagedCagedRandom"):
		if(RNG.chance(flatCageChance)):
			if RNG.chance(nonPermanentChance) && !isPlayer: 
				chastityCageItem = GlobalRegistry.createItem("ChastityCageFlat")
				chastityCageItem.setRestraintLevel(level)
			else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanent")
			var theInmate = getRolePawn("inmate").getChar()
			theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		else:
			if RNG.chance(nonPermanentChance) && !isPlayer: 
				chastityCageItem = GlobalRegistry.createItem("ChastityCage")
				chastityCageItem.setRestraintLevel(level)
			else: chastityCageItem = GlobalRegistry.createItem("ChastityCagePermanentNormal")
			var theInmate = getRolePawn("inmate").getChar()
			theInmate.getInventory().forceEquipStoreOther(chastityCageItem)
		setState("releasedCaged", "inmate")
	if(_id == "releasedCagedCagedBelted"):
		var theInmate = getRolePawn("inmate").getChar()
		var belt = pickBelt(theInmate)
		if belt == "beltPV":
			if RNG.chance(NonPermanentBeltChance) && !isPlayer:
				chastityCageItem = GlobalRegistry.createItem("GenitalChastityBelt")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("PermanentGenitalChastityBelt")
		elif belt == "beltV":
			if RNG.chance(NonPermanentBeltChance && !isPlayer):
				chastityCageItem = GlobalRegistry.createItem("ChastityBelt")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltVagina")
		elif belt == "beltP":
			if RNG.chance(NonPermanentBeltChance):
				chastityCageItem = GlobalRegistry.createItem("PenisChastityBelt")
				chastityCageItem.setRestraintLevel(level)
			else:
				chastityCageItem = GlobalRegistry.createItem("PermanentChastityBeltPenis")
		theInmate.getInventory().forceEquipStoreOther(chastityCageItem)


func inmateFree_text():
	saynn("In the end, {inmate.you} came out victorious from the encounter.")
	addAction("leave", "(Leave)", "", "default", 1.0, 60, {})

func inmateFree_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()



func getAnimData() -> Array:
	var theInmate = getRolePawn("inmate").getChar()
	if(getState() == "confrontation"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=true}]
	if(getState() == "inmateResists"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=false}]
	if(getState() in ["inmateTops", "inmateBottoms", "inspectorSatisfied", "inspectorNotSatisfied"]):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=false}]
	if(getState() == "inspectorGotRekt"):
		return [StageScene.SexStart, "defeated", {pc="inmate", npc="inspector"}]
	if(getState() == "inmateComplies"):
		return [StageScene.Grope, "grope", {pc="inmate", npc="inspector", bodyState={exposedCrotch=true}}]
	if(getState() == "inmateRuns"):
		return [StageScene.Duo, "jog", {pc="inspector", npc="inmate", npcAction="jog", further=false, flipNPC=true}]
	if(getState() == "inmateRunsSuccess"):
		return [StageScene.Grope, "gropefast", {pc="inmate", onlyPC=true}]
	if(getState() == "inmateRunsFail"):
		return [StageScene.Duo, "hurt", {pc="inmate", npc="inspector", npcAction="stunbaton"}]
	if(getState() == "inmateFightsFirst"):
		return [StageScene.Duo, "punch", {pc="inmate", npc="inspector", npcAction="hurt"}]
	if(getState() == "inmateFights"):
		return [StageScene.Duo, "dodge", {pc="inmate", npc="inspector", npcAction="stunbaton"}]
	if(getState() == "inmateWonFight"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="defeat"}]
	if(getState() == "cageTheInspector"):
		return [StageScene.BreastFeeding, "tease", {pc="inspector", npc="inmate", bodyState={exposedCrotch=true}}]
	if(getState() == "inmateLostFight"):
		return [StageScene.Duo, "defeat", {pc="inmate", npc="inspector", npcAction="stand"}]
	if(getState() == "releasedCaged" && !theInmate.isWearingChastityCage()):
		return [StageScene.BreastFeeding, "tease", {pc="inmate", npc="inspector", bodyState={exposedCrotch=true, hard=true}}]
	if(getState() == "releasedCaged" && theInmate.isWearingChastityCage()):
		return [StageScene.TFLook, "crotch", {pc="inmate", bodyState={exposedCrotch=true, hard=false}}]
	if(getState() == "inmateFree"):
		return [StageScene.TFLook, "start", {pc="inmate"}]
	return [StageScene.Solo, "jog", {pc="inspector"}]
