# mod version: ?.??
extends "res://Scenes/SceneBase.gd"

var DEBUG = false

func isWearingPermanentChastityBelt(character):
	if(character.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		var item = character.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
		if "Permanent" in item.getVisibleName() && "Chastity Belt" in item.getVisibleName():
			return true
	return false

func _init():
	sceneID = "ChastityForEveryoneChastityShowOff"

func _run():
	# hey adventurer, if you wondered this deep already, maybe write this scene yourself, hehe
	endScene()
