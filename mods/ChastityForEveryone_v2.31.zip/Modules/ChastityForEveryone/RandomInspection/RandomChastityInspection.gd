# mod version: 2.31
#
# this class generally covers the interaction when inmate wears the chastity
# it runs no matter if inmate wears the chastity, with hooks to the ChastityPolice class if they don't
extends "res://Modules/ChastityForEveryone/ChastityPolice.gd" # anything not redifined/used here is in that class

# set DEBUG in line 61

const RESIST_INSPECTOR_LETS_GO_CHANCE = 30
const MEAN_PERSONALITY_TR = 1.3

func isWearingChastityX(character, x:String):
	var toReturn = false
	if(character.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		var item = character.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
		if x in item.getVisibleName():
			toReturn = true
	if(character.getInventory().hasSlotEquipped(InventorySlot.Penis)):
		var item = character.getInventory().getEquippedItem(InventorySlot.Penis)
		if x in item.getVisibleName():
			toReturn = true
	if(character.getInventory().hasSlotEquipped(InventorySlot.Vagina)):
		var item = character.getInventory().getEquippedItem(InventorySlot.Vagina)
		if x in item.getVisibleName():
			toReturn = true
	return toReturn

func isWearingProperChastityCageOrBelt(character): #to check if it covers any parts.
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	var assginedToNPC = ""
	if isPlayer:
		assginedToNPC = GM.main.getFlag("ChastityForEveryone.databasePC", {"type": "none"})["type"]
	else:
		assginedToNPC = GM.main.getFlag("ChastityForEveryone.databaseNew", {}).get(character.getID())["type"]
	if (DEBUG): print_debug(character.getName())
	var toReturn = false
	if(character.getInventory().hasSlotEquipped(InventorySlot.Penis)):
		var item = character.getInventory().getEquippedItem(InventorySlot.Penis)
		if(item.hasTag(ItemTag.ChastityCage) && "cage" in assginedToNPC):
			toReturn = true
	elif(character.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		var item = character.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
		if (item.hasTag(ItemTag.ChastityCage) || "Chastity Belt" in item.getVisibleName()):
			match assginedToNPC:
				"beltP":
					toReturn = "Penis Chastity Belt" in item.getVisibleName()
				"beltV":
					toReturn = "Vagina Chastity Belt" in item.getVisibleName()
				"beltPV":
					toReturn = "Genital Chastity Belt" in item.getVisibleName()
			# new
			if ("Penis Chastity Belt" in item.getVisibleName() && !character.hasPenis()) \
				&& ("Vagina Chastity Belt" in item.getVisibleName() && !character.hasVagina()):
				toReturn = false
	return toReturn


func _init():
	id = "RandomChastityInspection"
	rng = RNG.chance(RESIST_INSPECTOR_LETS_GO_CHANCE)
	DEBUG = false

func shouldRunOnMeet(_pawn1, _pawn2, _pawn2Moved:bool):
	
	# 2.31
	if !FoxGlobals.ofModule("ChastityForEveryone").configModEnabled:
		return [false]	
	#
	chastityNpcsOld = GM.main.getFlag("ChastityForEveryone.database", {})
	chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	chastityPC = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})
	
	var guardsInspect = FoxGlobals.ofModule("ChastityForEveryone").configGuardsInspect
	var engineersInspect = FoxGlobals.ofModule("ChastityForEveryone").configEngineersInspect
	var nursesInspect = FoxGlobals.ofModule("ChastityForEveryone").configNursesInspect	
	var checkChance = FoxGlobals.ofModule("ChastityForEveryone").configRandomCheckChance
	
	if((chastityNpcsOld=={} && chastityNpcs=={}) || chastityPC=={}):
		print_debug("ChastityForEveryone: Mod not yet ready, skipping "+id+" scene for now.")
		return ["false"]
	#
	if !_pawn1.isPlayer() && !(_pawn1.charID in chastityNpcs.keys()):
		print_debug("!!", _pawn1.charID)
		preload("res://Modules/ChastityForEveryone/ChastityBigBrother.gd").putInChastityStatic(_pawn1.charID)
		chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	if !_pawn2.isPlayer() && !(_pawn2.charID in chastityNpcs.keys()):
		print_debug("!!", _pawn2.charID)
		preload("res://Modules/ChastityForEveryone/ChastityBigBrother.gd").putInChastityStatic(_pawn2.charID)
		chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	#
	
	if (DEBUG): print_debug("!"+_pawn1.getChar().getName()+"!+!"+_pawn2.getChar().getName()+"!"+id+"<<<<!")
	
	var location = _pawn1.getLocation()
	if badLocations.has(location):
		if (DEBUG): print_debug("bad location")
		return [false]
	
	if(!_pawn1.canBeInterrupted() || !_pawn2.canBeInterrupted()):
		if (DEBUG): print_debug("one of them can't be interupted")
		return [false]
	
	#stop if either is unconscious
	if(_pawn1.getChar().getConsciousness() <= 0.0 || _pawn2.getChar().getConsciousness() <= 0.0):
		if (DEBUG): print_debug("stop if either is unconscious")
		return [false]
	
	# one has to NOT be an inmate
	if(_pawn1.isInmate() && _pawn2.isInmate()):
		if (DEBUG): print_debug("one has to not be an inmate")
		return [false]

	# Not two staff members... currently
	if(_pawn1.isStaff() && _pawn2.isStaff()):
		if (DEBUG): print_debug("both are staff")
		return [false]
	
	if(_pawn2.isGuard()): 
		if !guardsInspect: 
			if (DEBUG): print_debug("this type of staff should not inspect")
			return [false]
	if(_pawn2.isEngineer()):
		if !engineersInspect: 
			if (DEBUG): print_debug("this type of staff should not inspect")
			return [false]
	if(_pawn2.isNurse()):
		if !nursesInspect: 
			if (DEBUG): print_debug("this type of staff should not inspect")
			return [false]
	
	# pawn 1 is the innmate from now on
	if(!_pawn1.isInmate() && _pawn2.isInmate()):
		var temp = _pawn1
		_pawn1 = _pawn2
		_pawn2 = temp

	# cooldown
	var currentTime = GM.main.getTime()
	var moduleCooldown = GM.main.getModuleFlag("ChastityForEveryone", "inspectionCooldown", 6*60*60 + 20*60)
#	print_debug("currentTime: ", currentTime)
#	print_debug("moduleCooldown: ", moduleCooldown)
	if currentTime < moduleCooldown:
		return [false]
	#

	if(_pawn1.isPlayer()):
		# stop if pc wasn't put in chastity on game start OR didn't do eliza obidience training
		if GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"]==null && ( !GM.pc.hasPerk(Perk.StartMaleChastity) || !( GM.main.getFlag("MedicalModule.PC_ReceivedPermanentCage")==true && GM.main.getFlag("MedicalModule.Chastity_Event5LockedForever")!=false) ):
			if (DEBUG): print_debug("stop if player wasn't put into forced chastity or finished questline as breeder")
			return [false]
		# previous two conditions not met, so player should be locked in:
		chastityString = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"]
	else:
		chastityString = chastityNpcs.get(_pawn1.charID)["type"]
	if (DEBUG): print_debug(chastityString)
	
	if(chastityString==null): #idk, something's broken
		chastityString="none"
		
	# stop if inmate doesn't have the locked bodypart:
	match chastityString:
		"none":
			return [false]
		"cage":
			if(!_pawn1.getChar().hasPenis()):
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
		"beltP":
			if(!_pawn1.getChar().hasPenis()):
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
		"beltV":
			if(!_pawn1.getChar().hasVagina()):
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
		"beltPV":
			if(!_pawn1.getChar().hasPenis() && !_pawn1.getChar().hasVagina()): # one remaining is still enough >:)
				if (DEBUG): print_debug("stop if inmate does not have a penis")
				return [false]
	
	if DEBUG: print_debug("!"+_pawn1.getChar().getName()+"!+!"+_pawn2.getChar().getName()+"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1")
	if DEBUG: print_debug(GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})["type"])
	if "belt" in chastityString:
		chastityString = "belt" #strips P, V or A from the name

	if(!_pawn1.isPlayer()):
		# stop if character wasn't put in chastity on generation
#		if(!GlobalRegistry.getCharacter(_pawn1.charID).getFlag(CharacterFlag.WasPutInChastity)):
		if(chastityNpcs.get(_pawn1.charID)["type"] == "none"):
			if (DEBUG): print_debug("stop if character wasn't put into forced chastity")
			return [false]
	
	
	if(_pawn1.isPlayer()):
		if checkChance != 0:
			checkChance = GM.pc.getExposure()+checkChance
		if(RNG.chance(checkChance)):
			GM.main.setModuleFlag( "ChastityForEveryone", "inspectionCooldown",(GM.main.getTime()+(1.5*60*60)) )
			return [true, {inmate=_pawn1.charID, inspector=_pawn2.charID}, {}]
	else:
		if(RNG.chance(checkChance)):
			GM.main.setModuleFlag( "ChastityForEveryone", "inspectionCooldown",(GM.main.getTime()+(10*60)) )
			return [true, {inmate=_pawn1.charID, inspector=_pawn2.charID}, {}]
		
	return[false]

func getActivityIconForRole(_role:String):
	return RoomStuff.PawnActivity.Chat



#func init_text():

#func init_do(_id:String, _args:Dictionary, _context:Dictionary):


func confrontation_text():	
	chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	chastityPC = GM.main.getFlag("ChastityForEveryone.databasePC", {"type":"none"})
	if DEBUG: print_debug("name of inmate: ", getRolePawn("inmate").getChar().getName())
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	chastityString = makeChastityString(getRolePawn("inmate").getID(), isPlayer)
	if DEBUG: print_debug("isPlayer: ",isPlayer)
	var typeOfChastity
	if isPlayer:
		typeOfChastity = chastityPC["type"]
	else:
		typeOfChastity = chastityNpcs.get(getRolePawn("inmate").getChar().getID())["type"]
	
	var noChastityApparent = false
	var chastityApparent = false
	var exposedPrivates = []
	if isPlayer:
		exposedPrivates = GM.pc.getExposedPrivates()
	else:
		exposedPrivates = getRolePawn("inmate").getChar().getExposedPrivates()
	if DEBUG: print_debug(exposedPrivates)
	if !isWearingChastityCageOrBelt(getRolePawn("inmate").getChar()):
		match typeOfChastity:
			"cage":
				noChastityApparent = BodypartSlot.Penis in exposedPrivates
			"beltP":
				noChastityApparent = BodypartSlot.Penis in exposedPrivates
			"beltV":
				noChastityApparent = BodypartSlot.Vagina in exposedPrivates
			"beltPV":
				noChastityApparent = BodypartSlot.Vagina in exposedPrivates || BodypartSlot.Penis in exposedPrivates
	else:
		match typeOfChastity:
			"cage":
				chastityApparent = BodypartSlot.Penis in exposedPrivates
			"beltP":
				chastityApparent = BodypartSlot.Penis in exposedPrivates
			"beltV":
				chastityApparent = BodypartSlot.Vagina in exposedPrivates
			"beltPV":
				chastityApparent = BodypartSlot.Vagina in exposedPrivates || BodypartSlot.Penis in exposedPrivates
	saynn("[say=inspector]Random chastity inspection![/say]")
	saynn("[say=inspector]Let me see...[/say]")
	saynn("[say=inspector]Database records indicate you are supposed to be wearing your mandated chastity "+chastityString+"...[/say]")
	var tempString
#	if(inspectorUnwilling):
#		if(chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none"):
#			saynn("[say=inspector]...So do I, to be frank. Stupid pieces of crap...[/say]")
#		else:
#			saynn("[say=inspector]It's... kinda dumb... hehe... he.[/say]")
#			saynn("{inspector.name} rubs {inspector.hisHer} legs together.")
#	else:
#		saynn("[say=inspector]...Are you?![/say]")
	if !noChastityApparent:
		if(inspectorUnwilling):
			if(chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none"):
				saynn("[say=inspector]...So do I, to be frank. Stupid pieces of crap...[/say]")
			else:
				saynn("[say=inspector]It's... kinda dumb... hehe... he.[/say]")
				saynn("{inspector.name} rubs {inspector.hisHer} legs together.")
			
			tempString = RNG.pick([
			"[say=inspector]...Show me your "+chastityString+" now![/say]",
			"[say=inspector]...Are you?! Show it.[/say]",
			"[say=inspector]...Let me see it. Now.[/say]",
			"[say=inspector]...Present it.[/say]",
			])
			saynn(tempString)
			# !noChastityApparent && inspectorUnwilling
			if isWearingProperChastityCageOrBelt(getRolePawn("inmate").getChar()):
				if !chastityApparent:
					addAction("RCHIconfrontationInmateComplies", "Show it", "Pull your pants down and present it proudly!", "default", 1.0, 60, {})
				else:
					addAction("RCHIconfrontationInmateComplies", "Show it", "Right here officer", "default", 1.0, 60, {})
				addAction("RCHIconfrontationInmateShame", "Freeze in shame", "Cover your face and blush", "default", 1.0, 60, {})
				addAction("RCHIconfrontationInmateResists", "Resist", "", "default", 1.0, 60, {})
				if !chastityApparent:	addAction("RCHIconfrontationInmateNothing", "Do nothing", "Just let them do it", "default", 1.0, 60, {})
#				addAction("RCHIconfrontationInmatePunch", "(Punch!)", "You won't let yourself be treated like that!", "default", 1.0, 60, {})
			else:
				addAction("confrontationInmateResists", "You’re wrong!", "", "default", 1.0, 60, {})
				addAction("confrontationInmateResists", "It's a mistake!", "", "default", 1.0, 60, {})
				addAction("confrontationInmateComplies", "Well...", "", "default", 1.0, 60, {})
				addAction("confrontationInmateComplies", "Ugh, I guess", "", "default", 1.0, 60, {})
				addAction("confrontationInmateComplies", "You're right", "You like being caged anyways.", "default", 1.0, 60, {})
				addAction("confrontationInmateStartedRunning", "(Run!)", "You won’t be made to wear this stupid thing again!", "default", 1.0, 60, {})
#				addAction("confrontationInmateStartedFightFirst", "(Punch!)", "Catch the inspector by surprise!", "default", 1.0, 60, {})
		else:
			tempString = RNG.pick([
			"[say=inspector]...Show me your "+chastityString+" now![/say]",
			"[say=inspector]...Are you?![/say]",
			"[say=inspector]...Let's see![/say]",
			])
			saynn(tempString)
			if !chastityApparent: saynn("{inspector.name} Grabs your pants and starts pulling them down.")
			else: saynn("{inspector.name}Hmm, I can see you have something on you, let me cross reference it with your profile database.")
			
			var scoreComply = getRolePawn("inmate").getChar().getSkillLevel(Skill.Exhibitionism)/2 \
							+ getRolePawn("inmate").getChar().getLustLevel()*10\
							* (1.5 if getRolePawn("inmate").getChar().getInmateType() == InmateType.SexDeviant else 1.0)
			if (DEBUG): print_debug("scoreComply: ", scoreComply)
			var inspectorHimHerString = "(Asist "+getRolePawn("inspector").getChar().himHer()+")"
			# !noChastityApparent && !inspectorUnwilling
			if isWearingProperChastityCageOrBelt(getRolePawn("inmate").getChar()):
				if !chastityApparent:
					addAction("RCHIconfrontationInmateComplies", "Show it", "Pull your pants down and present it proudly!", "default", 1.0, 60, {})
				else:
					addAction("RCHIconfrontationInmateComplies", "Show it", "Right here officer", "default", 1.0, 60, {})
				addAction("RCHIconfrontationInmateShame", "Freeze in shame", "Cover your face and blush", "default", 1.0, 60, {})
				addAction("RCHIconfrontationInmateResists", "Resist", "You won't let yourself to be treated like that!", "default", 1.0, 60, {})
				if !chastityApparent:	addAction("RCHIconfrontationInmateNothing", "Do nothing", "Just let them do it", "default", 1.0, 60, {})
#				addAction("RCHIconfrontationInmatePunch", "(Punch!)", "You won't let yourself to be treated like that!", "default", 1.0, 60, {})
			else:
				addAction("confrontationInmateResists", "It's a mistake!", "", "default", 1.0, 60, {})
				addAction("confrontationInmateResists", "Stop! Please!", "Leave me alone! Please...", "default", 1.0, 60, {})
				addAction("confrontationInmateComplies", "(Let it happen)", "", "default", scoreComply, 60, {})
				addAction("confrontationInmateCompliesAssist", inspectorHimHerString, "", "default", scoreComply, 60, {})
#				addAction("confrontationInmateStartedRunning", "(Run!)", "You won’t be made to wear this stupid thing again!", "default", 1.0, 60, {})
#				addAction("confrontationInmateStartedFightFirst", "(Punch!)", "Catch the inspector by surprise!", "default", 1.0, 60, {})
#			addAction("confrontationInmateComplies", "(Let it happen)", "", "default", scoreComply, 60, {})
#			addAction("RCHIconfrontationInmateComplies", inspectorHimHerString, "", "default", scoreComply, 60, {})
#			addAction("confrontationInmateResists", "No! You’re wrong!", "", "default", 1.0, 60, {})
#			addAction("confrontationInmateResists", "Stop! Please! Leave me alone! Please...", "", "default", 1.0, 60, {})
	else:
		saynn("{inspector.name} looks down at your exposed privates")
		saynn("[say=inspector]...But it's obvious you don't...[/say]")
		saynn("{inspector.name} got closer to you, making an escape unfeasible.")
		if(inspectorUnwilling):
			if(chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none"):
				saynn("[say=inspector]...But I fucking do, ehh...[/say]")
				saynn("[say=inspector]...I'm sorry, but I can't just let it slide, everyone can see it.[/say]")
			else:
				saynn("[say=inspector]...I'm sorry, but I can't just let it slide, everyone can see it.[/say]")
				saynn("[say=inspector]And if this fricking doctor finds out I let you go I'll probably be next in line to be caged![/say]")
		else:
			saynn("[say=inspector]...That’s unacceptable, good inmates should be wearing their chastity![/say]")
		# noChastityApparent
		addAction("confrontationInmateResists", "No way!", "", "default", 1.0, 60, {})
		addAction("confrontationInmateResists", "It's a mistake!", "", "default", 1.0, 60, {})
		addAction("confrontationInmateComplies", "Well...", "", "default", 1.0, 60, {})
		addAction("confrontationInmateComplies", "Ugh, I guess", "", "default", 1.0, 60, {})
		addAction("confrontationInmateComplies", "You're right", "You like being caged anyways.", "default", 1.0, 60, {})
#		addAction("confrontationInmateStartedFightFirst", "(Punch!)", "You won't let yourself to be treated like that!", "default", 1.0, 60, {})
	# DEBUG options
	if DEBUG: addAction("debug", "DEBUG", "", "default", 1.0, 60, {})

func confrontation_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "confrontationInmateResists"):
		setState("inmateResists", "inmate")
	if(_id == "confrontationInmateCompliesAssist"):
		getRolePawn("inmate").getChar().addArousal(0.10)
		getRolePawn("inmate").getChar().addLust(10)
		setState("inmateComplies", "inmate")
	if(_id == "confrontationInmateComplies"):
		setState("inmateComplies", "inmate")
	if(_id == "confrontationInmateStartedRunning"):
		setState("inmateRuns", "inmate")
	if(_id == "confrontationInmateStartedFightFirst"):
		setState("inmateFightsFirst", "inmate")
	# RCHI
	if(_id == "RCHIconfrontationInmateShame"):
		getRolePawn("inmate").getChar().addArousal(0.10)
		getRolePawn("inmate").getChar().addLust(10)
		setState("RCHIinmateCompliesShame", "inmate")
	if(_id == "RCHIconfrontationInmateComplies"):
		getRolePawn("inmate").getChar().addArousal(0.10)
		getRolePawn("inmate").getChar().addLust(10)
		getRolePawn("inmate").getChar().addSkillExperience(Skill.Exhibitionism, 30)
		getRolePawn("inmate").getChar().addSkillExperience(Skill.SexSlave, 20)
		setState("RCHIinmateComplies", "inmate")
	if(_id == "RCHIconfrontationInmateNothing"):
		setState("RCHIinmateComplies", "inmate")
	if(_id == "RCHIconfrontationInmateResists"):
		setState("RCHIinmateResists", "inmate") # TODO
	#DEBUG OPTION
	if DEBUG:
		if(_id == "debug"):
			setState("theDebug", "inmate")


func theDebug_text():
	addAction("debug1", "inmateComplies", "", "default", 1.0, 60, {})
	addAction("debug2", "RCHIinmateComplies", "", "default", 1.0, 60, {})
	addAction("debug3", "RCHIinmateCompliesShame", "", "default", 1.0, 60, {})
	addAction("debug4", "RCHIinmateResists", "", "default", 1.0, 60, {})
	addAction("debug5", "inmateRunsFail", "", "default", 1.0, 60, {})
	addAction("debug6", "inmateFights", "", "default", 1.0, 60, {})
	addAction("debug7", "inmateLostFight", "", "default", 1.0, 60, {})
	addAction("debug8", "RCHIparade", "", "default", 1.0, 60, {})
	addAction("debug9", "inmateAllGood", "", "default", 1.0, 60, {})
	addAction("debug10", "releasedCaged", "", "default", 1.0, 60, {})

func theDebug_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "debug1"):
		setState("inmateComplies", "inmate")
	if(_id == "debug2"):
		setState("RCHIinmateComplies", "inmate")
	if(_id == "debug3"):
		setState("RCHIinmateCompliesShame", "inmate")
	if(_id == "debug4"):
		setState("RCHIinmateResists", "inmate")
	if(_id == "debug5"):
		setState("inmateRunsFail", "inmate")
	if(_id == "debug6"):
		setState("inmateFights", "inmate")
	if(_id == "debug7"):
		setState("inmateLostFight", "inspector")
	if(_id == "debug8"):
		setState("RCHIparade", "inmate")
	if(_id == "debug9"):
		setState("inmateAllGood", "inmate")
	if(_id == "debug10"):
		setState("releasedCaged", "inmate")


func inmateComplies_text():
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var configBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configBeltChance
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	chastityString = makeChastityString(getRolePawn("inmate").getID(), isPlayer) #doesn't seem to work globally :(
	var chastityStringFull = makeChastityString(getRolePawn("inmate").getID(), isPlayer, true)
	saynn("{inspector.name} has crouched next to you and is now staring directly at your exposed "
	+"{inmate.penis}" if getRolePawn("inmate").getChar().hasPenis() else "" 
	+ "and {inmate.vagina}" if getRolePawn("inmate").getChar().hasVagina()&&getRolePawn("inmate").getChar().hasPenis() else "{inmate.vagina}" if getRolePawn("inmate").getChar().hasVagina() else ""
	+".")
	if isWearingProperChastityCageOrBelt(getRolePawn("inmate").getChar())!=isWearingChastityCageOrBelt(getRolePawn("inmate").getChar()):
		if isWearingChastityX(getRolePawn("inmate").getChar(), "Belt") && chastityString == "belt":
			saynn("[say=inspector]What is this! The belt is other way around, it's supposed to cover this, not this![/say]")
		elif isWearingChastityX(getRolePawn("inmate").getChar(), "Cage") && chastityString == "belt":
			saynn("[say=inspector]What is this! Where is your assigned belt?![/say]")
		elif isWearingChastityX(getRolePawn("inmate").getChar(), "Belt") && chastityString == "cage":
			saynn("[say=inspector]What is this! Where is your assigned cage?![/say]")
	if (!isPlayer): saynn("[say=inmate]Well, hehe, I.. I... I can explain![/say]")
	if (!isPlayer): saynn("[say=inspector]For sure.[/say]")
	if isWearingProperChastityCageOrBelt(getRolePawn("inmate").getChar())!=isWearingChastityCageOrBelt(getRolePawn("inmate").getChar()):
		if RNG.chance(50):
			saynn("[say=inspector]You ain't fooling me like that. Let's get this off, shall we?[/say]")
			if isWearingChastityX(getRolePawn("inmate").getChar(), "Belt") && chastityString == "belt":
				saynn("You've got your chastity belt removed, for now...\n")
				getRolePawn("inmate").getChar().getInventory().unequipSlot(InventorySlot.UnderwearBottom)
			elif isWearingChastityX(getRolePawn("inmate").getChar(), "Cage") && chastityString == "belt":
				saynn("You've got your chastity cage removed.\n")
				getRolePawn("inmate").getChar().getInventory().unequipSlot(InventorySlot.Penis)
			elif isWearingChastityX(getRolePawn("inmate").getChar(), "Belt") && chastityString == "cage":
				saynn("You've got your chastity belt removed, for now...\n")
				getRolePawn("inmate").getChar().getInventory().unequipSlot(InventorySlot.UnderwearBottom)
		else:
			saynn("[say=inspector]...[/say]")
			saynn("[say=inspector]Well, it's good you're wearing something, right? I'll allow it.[/say]")
			saynn("[say=inspector]For now...[/say]")
			addAction("compliesEnd", "(Continue)", "", "default", 1.0, 60, {})
			return
	if inspectorUnwilling:
		saynn("[say=inspector]Let's get this over with.[/say]")
	else:
		saynn("[say=inspector]Let's get you back to normal~[/say]")
	if(getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.3):
		if getRolePawn("inmate").getChar().hasPenis() && (chastityString == "cage" || !configBeltChance>0):
			addAction("compliesCagedRandom", "(Get locked up)", "", "default", 1.0, 60, {})
		else:
			addAction("compliesBelted", "(Get locked up)", "", "default", 1.0, 60, {})
	else:
		saynn("[say=inspector]I’m sorry, but rules are rules. I have to lock you up.[/say]")
#		if(flatCageChance < 100):
#			if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular one?[/say]")
#			addAction("compliesCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
#			addAction("compliesCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
#			addAction("compliesCagedRandom", "Any will do", "", "default", 1.0, 60, {})
#		else:
#			addAction("compliesCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
		if getRolePawn("inmate").getChar().hasPenis() && (chastityString == "cage" || !configBeltChance>0):
			if(flatCageChance < 100):
				if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular cage?[/say]")
				addAction("compliesCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
				addAction("compliesCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
				addAction("compliesCagedRandom", "Any will do", "", "default", 1.0, 60, {})
			else:
				addAction("compliesCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
		elif !getRolePawn("inmate").getChar().hasPenis() || (chastityString == "belt" && chastityStringFull!="beltP"):
			if (isPlayer): saynn("[say=inspector]Get ready to be belted back up![/say]")
			addAction("compliesBelted", "(Get locked up)", "", "default", 1.0, 60, {})
		else:
			if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: belt or cage?[/say]")
			addAction("compliesBelted", "Belt", "Bulkier, but more practical", "default", 1.0, 60, {})
			if RNG.chance(flatCageChance):
				addAction("compliesCagedFlat", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
			else: 
				addAction("compliesCagedRegular", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
			
	if (!isPlayer): saynn("[say=inmate]Let’s just get this over with...[/say]")

### inmateComplies_do()


func RCHIinmateComplies_text():

	if isWearingChastityX(getRolePawn("inmate").getChar(),"Cage"):
		if isWearingChastityX(getRolePawn("inmate").getChar(),"Flat"):
			saynn("{inspector.name} has crouched next to you and is now staring directly at your snugly packed {inmate.penis}.")
		else:
			saynn("{inspector.name} has crouched next to you and is now staring directly at your {inmate.penis}.")
		if(getRolePawn("inspector").getChar().getLustLevel() >= 50 \
			|| getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.15):
			# kinky approach
			saynn("[say=inspector]It looks so pretty in here!~ You like being a good caged inmate?[/say]")
			var heShe = getRolePawn("inspector").getChar().heShe().capitalize()
#			var varbS = getRolePawn("inspector").getChar().verbS("start")
			saynn(heShe+" placed your balls in their hand, lightly so, and then started massaging them very gently.")
			saynn("[say=inspector]They're just so mesmerising to look at, you know? So cute...[/say]")
			if(getRolePawn("inspector").scorePersonality({PersonalityStat.Mean: 1.0}) > 0.3 \
			|| getRolePawn("inspector").scorePersonality({PersonalityStat.Subby: 1.0}) < -0.3):
				saynn("[say=inspector]...so...[/say]")
				saynn("[say=inspector][rainbow freq=0.5 sat=0.5 val=1.0]Useless[/rainbow]![/say]")
				saynn("Inspector releases your balls and gives them a nice plap! Your whole locked-up dick bounces from the impact.")
				saynn("[say=inmate]Hngh!!!~[/say]")
				saynn("[say=inspector]Good inmate~[/say]")
			else:
				saynn("[say=inspector]Are you comfy in there inmate? You'd better be, 'cause it ain't coming off anytime soon, hehe.[/say]")
			if(getRolePawn("inspector").scoreFetishMax({Fetish.OralSexGiving:1.0, Fetish.Bondage: 1.0}) > 0.4 \
				&& getRolePawn("inmate").getChar().getLustLevel() >= 30):
				saynn("[say=inspector]Oh, being excited? There’s some pre leaking already...[/say]")
				saynn("Suddenly {inspector.name} drags {inspector.hisHer} toung all over your caged bals, as well as the metal of the cage above them.")
				saynn("[say=inspector]...too bad you can’t do anything about it. Or perhaps you can~[/say]")
			elif getRolePawn("inmate").getChar().getLustLevel() >= 30:
				saynn("[say=inspector]Oh, being excited? There’s some pre leaking already...[/say]")
				saynn("{inspector.name} tugs on your caged balls, making the ring of our cage sink into your skin.")
				if isWearingChastityX(getRolePawn("inmate").getChar(), "Anus") || getRolePawn("inmate").getChar().hasReachableVagina():
					saynn("[say=inspector]...too bad you can’t do anything about it. Or perhaps you can~[/say]")
			
			# if inspector has penis && inmate !anus belt: it's good this hole is still accessable
			# else && inmate !anus belt: ~
			if getRolePawn("inspector").getChar().hasPenis():
				if getRolePawn("inmate").getChar().hasReachableVagina():
					saynn("{inspector.name} starts lightly massaging outher walls of your {inmate.vagina}.")
					saynn("[say=inspector]It's good this breedable hole is still accessable, don't you think so?[/say]")
				elif !isWearingChastityX(getRolePawn("inmate").getChar(), "Anus"):
					saynn("{inspector.name} starts lightly massaging your butt cheeks.")
					saynn("[say=inspector]I'm sure having your rear hole played with is more fun anyways~[/say]")
			addAction("RCHIinmateCompliesContinueKinky", "(Continue)", "", "default", 1.0, 60, {})
		else:
			# more "proffesional" approach
			saynn("[say=inspector]Alright, everything seems to be in order. You are properly restrained in the regulatory obedience-ensuring accessory.[/say]")
			addAction("RCHIinmateCompliesContinue", "(Continue)", "", "default", 1.0, 60, {})
		
	else:
		if(getRolePawn("inspector").getChar().getLustLevel() >= 50 \
			|| getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.15):
			# kinky approach
			if isWearingChastityX(getRolePawn("inmate").getChar(), "Penis Chastity Belt"):			
				saynn("{inspector.name} has crouched next to you and is now staring directly at your blocked-off "
				+"{inmate.penis}.")
				saynn("[say=inspector]Looking cosy here, very secure![/say]")
				saynn("[say=inspector]Must be so nice - no unwanted erections, no need for extra underwear.[/say]")
			elif isWearingChastityX(getRolePawn("inmate").getChar(), "Genital Chastity Belt"):
				saynn("{inspector.name} has crouched next to you and is now staring directly at your blocked-off "
				+"{inmate.penis}" if getRolePawn("inmate").getChar().hasPenis() else "" 
				+ "and {inmate.vagina}" if getRolePawn("inmate").getChar().hasVagina()&&getRolePawn("inmate").getChar().hasPenis() else "{inmate.vagina}" if getRolePawn("inmate").getChar().hasVagina() else ""
				+".")
				saynn("[say=inspector]Must be so nice"
				 + " - no unwanted erections" if getRolePawn("inmate").getChar().hasPenis() else ""
				 +", no one breeding you.[/say]" if getRolePawn("inmate").getChar().hasVagina()&&getRolePawn("inmate").getChar().hasPenis() else "- no one breeding you.[/say]" if getRolePawn("inmate").getChar().hasVagina() else "[/say]")
			elif isWearingChastityX(getRolePawn("inmate").getChar(), "Vagina Chastity Belt"):			
				saynn("{inspector.name} has crouched next to you and is now staring directly at your blocked-off "
				+"{inmate.vagina}.")
				saynn("[say=inspector]No breeding for you with this on, that’s too bad.[/say]")
			else: # other modded items?
				saynn("{inspector.name} has crouched next to you and is now staring directly at your blocked-off "
				+"genitails.")
			saynn("[say=inspector]That’s one less thing to worry about in this prison. Must be such a relief to have all of this security over there, am I right?[/say]")
			# if inspector has penis && inmate !anus belt: it's good this hole is still accessable
			# else && inmate !anus belt: ~
			if getRolePawn("inspector").getChar().hasPenis():
				if getRolePawn("inmate").getChar().hasReachableVagina():
					saynn("{inspector.name} starts lightly massaging outher walls of your {inmate.vagina}.")
					saynn("[say=inspector]It's good this breedable hole is still accessable, don't you think so?[/say]")
				elif !isWearingChastityX(getRolePawn("inmate").getChar(), "Anus"):
					saynn("{inspector.name} starts lightly massaging your butt cheeks.")
					saynn("[say=inspector]I'm sure having your rear hole played with is more fun anyways~[/say]")
			addAction("RCHIinmateCompliesContinueKinky", "(Continue)", "", "default", 1.0, 60, {})
			
		else:
			# more "proffesional" approach
			saynn("[say=inspector]Alright, everything seems to be in order. You are properly restrained in the regulatory obedience-ensuring accessory.[/say]")
			addAction("RCHIinmateCompliesContinue", "(Continue)", "", "default", 1.0, 60, {})

func RCHIinmateComplies_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "RCHIinmateCompliesContinueKinky"):
		getRolePawn("inmate").getChar().addArousal(0.10)
		getRolePawn("inmate").getChar().addLust(10)
		getRolePawn("inmate").getChar().addSkillExperience(Skill.SexSlave, 20)
		setState("inmateAllGood", "inmate")
	if(_id == "RCHIinmateCompliesContinue"):
		setState("inmateAllGood", "inmate")


func RCHIinmateCompliesShame_text():
	#being made to present your cage/belt to everyone around, add comments from other people
	var noKinky = !(getRolePawn("inspector").getChar().getLustLevel() >= 50 \
			|| getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.15)
	if noKinky:
		saynn("[say=inspector]Hey, what’s that blush about?[/say]")
		saynn("[say=inspector]Inmate, this is your second skin now, better get used to it. Quick. As it [b]will stay on forever.[/b] I'll see to it.[/say]")
		addAction("RCHIinmateCompliesShameContinueSHAME", "(Try to cover yourself)", "(placeholder for this mod version)", "default", 1.0, 60, {}) # TODO REMOVE in future version
		addAction("RCHIinmateCompliesShameContinueNOTHING", "(Do nothing)", "(placeholder for this mod version; but hey, it's free xp!)", "default", 1.0, 60, {}) # TODO REMOVE in future version
	else:
		saynn("[say=inspector]Oh, what’s that blush about? Poor thing! Gotta work up your courage, you know?[/say]")
		saynn("[say=inspector]Hmm, let me help...[/say]")
		if (
			getRolePawn("inmate").getChar().getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom) && !isWearingChastityX(getRolePawn("inmate").getChar(), "Belt") \
			|| getRolePawn("inmate").getChar().getInventory().hasSlotEquipped(InventorySlot.Body) && !getRolePawn("inmate").getChar().getExposedPrivates().size() > 0
		):
			saynn("{inspector.name} suddenly grabs your clothes and pulls them down, exposing your privates [b]and[/b] your chastity gear.")
			saynn("[say=inmate]Hey! What are you...[/say]")
		else:
			saynn("[say=inspector]How come, since you’re practically running naked around here?[/say]")
		saynn("The inspector turns around and screams loudly:")
		saynn("[say=inspector]Hey everyone! Come and take a look![/say]")
		saynn("You shivered heftily having heard that.")
	#	addAction("RCHIinmateCompliesShameContinue", "(Continue)", "", "default", 1.0, 60, {}) # TODO REMOVE in future version
		addDisabledAction("(Continue)", "WIP - sorry!") # TODO in future version
		addAction("RCHIinmateCompliesShameContinueSHAME", "(Try to cover yourself)", "(placeholder for this mod version)", "default", 1.0, 60, {}) # TODO REMOVE in future version
		addAction("RCHIinmateCompliesShameContinueNOTHING", "(Do nothing)", "(placeholder for this mod version; but hey, it's free xp!)", "default", 1.0, 60, {}) # TODO REMOVE in future version

func RCHIinmateCompliesShame_do(_id:String, _args:Dictionary, _context:Dictionary):
#	if(_id == "RCHIinmateCompliesShameContinue"): # TODO in future version
#		runScene("ChastityForEveryoneChastityShowOff")
#		stopMe()
	if(_id == "RCHIinmateCompliesShameContinueNOTHING"):
		getRolePawn("inmate").getChar().addSkillExperience(Skill.Exhibitionism, 40)
		setState("inmateAllGood", "inmate")
	if(_id == "RCHIinmateCompliesShameContinueSHAME"):
		setState("inmateAllGood", "inmate")

func RCHIinmateResists_text():
	chastityNpcs = GM.main.getFlag("ChastityForEveryone.databaseNew", {})
	if DEBUG: print_debug(getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}))
	var isInspectorHorny = getRolePawn("inspector").getChar().isInHeat() || getRolePawn("inspector").getChar().getLustLevel() > 0.5
	var noKinky = !(getRolePawn("inspector").getChar().getLustLevel() >= 50 \
			|| getRolePawn("inspector").scoreFetishMax({Fetish.Rigging:1.0, Fetish.Bondage: 1.0}) > 0.15)
	if(rng):
		if RNG.chance(66):
			if(chastityNpcs.get(getRolePawn("inspector").getChar().getID())["type"] != "none"):
				saynn("[say=inspector]You know what? Fuck this, I have enough of this chastity bullshit anyways. You are free to go, but please, don’t tell anyone, especially that fucking bitch doctor, alright?[/say]")
			else:
				saynn("[say=inspector]You know what? Fuck this, I have enough of this chastity bullshit anyways - they make things harder, you know?[/say]")
		else:
			saynn("[say=inmate]Hey, leave me alone![/say]")
			saynn("[say=inspector]Yeah, yeah, sure...[/say]")
			saynn("")
			saynn("After a slight pause {inspector.heShe} continues:")
			saynn("[say=inspector]Alright, but behave yourself, inmate.[/say]")
		saynn("[say=inspector]Move on now.[/say]")
		addAction("resistsEnding", "(Leave)", "", "default", 1.0, 60, {})
	elif(RNG.chance(15) && getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) < MEAN_PERSONALITY_TR):
		saynn("[say=inspector]How about I’ll show you how much fun you can still have, no matter the chastity?[/say]")
		saynn("{inspector.name} wants {inmate.you} to bottom for {inspector.himHer}.")
		addAction("resistsInmateBottoms", "Agree", "Fun times ahead~", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})
		addAction("resistsInmateRuns", "(Run away!)", "Try to run now!", "default", 1.0, 60, {})
	elif getRolePawn("inspector").scorePersonality({PersonalityStat.Mean:1.0}) >= MEAN_PERSONALITY_TR && getRolePawn("inmate").getAffection(getRolePawn("inspector")) < 0.15:
		if(getRolePawn("inmate").getChar().hasPenis() && isWearingChastityX(getRolePawn("inmate").getChar(), "Cage")):
			saynn("[say=inmate]AHH-HHH! Nghh... f-fuck...[/say]")
			saynn("Suddenly you end up screaming in pain after the inspector delivers a kick straight to your balls. Due to your chastity cage the hit is extra painful, making your whole ‘package’ jiggle  from the impact. You drop down to your knees in pain.")
			saynn("[say=inspector]On your knees already? Good. Will you behave now?[/say]")
			addAction("resistsCompliesPain", "Comply", "", "default", 1.0, 60, {})
			if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
			else:
				addDisabledAction("Kick them", "You can't do that with your legs bound.")
		elif isWearingChastityX(getRolePawn("inmate").getChar(), "Belt"):
			saynn("The inspector reaches out to your waist and grabs you by your chastity belt, then {inspector.heShe} {inspector.youVerb('pull')} you closer to {inspector.himHer}.")
			saynn("[say=inspector]What’s the matter? Not feeling safe with this on? Safety can be hard to come by in the prison, I’m sure you’ve found that by yourself already.[/say]")
			saynn("[say=inspector]But of course It doesn’t mean I can’t play with you.[/say]")
			saynn("Suddenly the inspector throws you down to the ground. You land on the hard floor below, writhing in pain.")
			saynn("[say=inmate]AGH! My back![/say]")
			saynn("{inspector.name} smiles ominously:")
			saynn("[say=inspector]You're mine.[/say]")
			addAction("resistsSexPain", "Give in to them", "", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})
			if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
			else:
				addDisabledAction("Kick them", "You can't do that with your legs bound.")
		else:
			# other modded items? +failsafe
			saynn("[say=inspector]What’s the matter? Not feeling safe with this gear on you? Safety can be hard to come by in the prison, I’m sure you’ve found that by yourself already.[/say]")
			saynn("[say=inspector]But of course It doesn’t mean I can’t play with you.[/say]")
			saynn("Suddenly the inspector throws you down to the ground. You land on the hard floor below, writhing in pain.")
			saynn("[say=inmate]AGH! My back![/say]")
			saynn("{inspector.name} smiles ominously:")
			saynn("[say=inspector]You're mine.[/say]")
			addAction("resistsSexPain", "Give in to them", "", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})
			if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
			else:
				addDisabledAction("Kick them", "You can't do that with your legs bound.")
	elif noKinky:
		saynn("[say=inspector]Change your attitude at once, inmate![/say]")
		saynn("After {inspector.heShe} {inspector.youVerb('say')} it you get smacked in the head with a batton.") #todo animation for that
		saynn("[say=inmate]Agh! Stop it![/say]")
		saynn("[say=inspector]Present your genitals inmate, now![/say]")
		addAction("resistsCompliesPain", "Comply", "", "default", 1.0, 60, {})
		addAction("resistsInmateRuns", "(Run away!)", "Try to run now!", "default", 1.0, 60, {})
		if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
		else:
			addDisabledAction("Kick them", "You can't do that with your legs bound.")
	else: # not mean
		if(getRolePawn("inmate").getChar().hasPenis() && isWearingChastityX(getRolePawn("inmate").getChar(), "Cage")):
			saynn("The inspector reaches out with one hand to your waist and grabs you by your balls - literally, then {inspector.heShe} {inspector.youVerb('tug')} your chastity cage and moves you closer to {inspector.himHer} by your crotch.")
			saynn("[say=inmate]Ah! Nghh... [/say]")
			saynn("Being moved like that was a little painful.")
			saynn("[say=inspector]What’s the matter? Not liking it? I thought you’d crave any stimulation, being in your current predicament and all.[/say]")
			if isInspectorHorny: saynn("[say=inspector]Maybe [b]I[/b] can help you with that~[/say]")
			addAction("resistsCompliesPain", "Comply", "", "default", 1.0, 60, {})
			if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
			else:
				addDisabledAction("Kick them", "You can't do that with your legs bound.")
			if isInspectorHorny: addAction("resistsSexPain", "Give in to them", "Fun times ahead~", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})
		elif isWearingChastityX(getRolePawn("inmate").getChar(), "Belt"):
			saynn("The inspector reaches out to your waist and grabs you by your chastity belt, then {inspector.heShe} {inspector.youVerb('pull')} you closer to {inspector.himHer}.")
			saynn("[say=inspector]What’s the matter? Not feeling safe with this on? Safety can be hard to come by in the prison, I’m sure you’ve found that by yourself already.[/say]")
			if isInspectorHorny: saynn("[say=inspector]But tell me, would you feel safe with me?~[/say]")
			saynn("[say=inspector]Either way I have to check your chastity. Your choice~[/say]")
			addAction("resistsComplies", "Comply", "Get inspected", "default", 1.0, 60, {})
			if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
			else:
				addDisabledAction("Kick them", "You can't do that with your legs bound.")
			if isInspectorHorny: addAction("resistsSex", "Give in to them", "Fun times ahead~", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})
		else:
			# other modded items? +failsafe
			saynn("[say=inspector]What’s the matter? Not feeling safe with this gear on you? Safety can be hard to come by in the prison, I’m sure you’ve found that by yourself already.[/say]")
			if isInspectorHorny: saynn("[say=inspector]But tell me, would you feel safe with me?~[/say]")
			saynn("[say=inspector]Either way I have to check your chastity. Your choice~[/say]")
			addAction("resistsComplies", "Comply", "Get inspected", "default", 1.0, 60, {})
			if	!getRolePawn("inmate").getChar().hasBoundLegs():
				addAction("resistsFight", "Kick them", "", "default", 1.0, 60, {})
			else:
				addDisabledAction("Kick them", "You can't do that with your legs bound.")
			if isInspectorHorny: addAction("resistsSex", "Give in to them", "Fun times ahead~", "default", 1.0, 600, {start_sex=["inspector", "inmate", SexType.DefaultSex],})

func RCHIinmateResists_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "resistsEnding"):
		setState("inmateAllGood", "inmate")
	if(_id == "resistsSex"):
#		startInteraction("PunishInteraction", {punisher=getRoleID("inspector"), target=getRoleID("inmate")})
		stopMe()
	if(_id == "resistsSexPain"):
#		startInteraction("PunishInteraction", {punisher=getRoleID("inspector"), target=getRoleID("inmate")})
		getRolePawn("inmate").getChar().addPain(10)
		stopMe()
	if(_id == "resistsComplies"):
		setState("RCHIinmateComplies", "inmate")
	if(_id == "resistsCompliesPain"):
		getRolePawn("inmate").getChar().addPain(30)
		setState("RCHIinmateComplies", "inmate")
	if(_id == "resistsInmateRuns"):
		setState("inmateRuns", "inmate")
	if(_id == "resistsInmateBottoms"):
		stopMe()
	if(_id == "resistsFight"):
		getRolePawn("inmate").getChar().addPain(30)
		setState("inmateFights", "inmate")


#func inmateRunsFail_text()

func inmateRunsFail_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateRunsFailContinue"):
		setState("RCHIinmateComplies", "inmate")


func inmateFights_text():
	saynn("Not wanting to go down so easily, {inmate.you} caught {inspector.name} off guard and sneaked a kick to the legs.")
	#var theInmate = getRolePawn("inmate").getChar()
#	var theInspector = getRolePawn("inspector").getChar()
	#theInspector.addPain(15)
#	theInspector.addEffect(StatusEffect.Stunned)
#	theInspector.addEffect(StatusEffect.Wounded)
	saynn("[say=inspector]Ouch! You fucker![/say]")
	sayLine("inspector", "AttackStart", {main="inspector", target="inmate"})
	#addAction("firstFight", "Fight!", "Begin the fight", "default", 1.0, 60, {}) debug
	addAction("firstFight", "Fight!", "Begin the fight", "fight", 1.0, 600, {start_fight=["inmate", "inspector"],})

# func inmateFights_do(_id:String, _args:Dictionary, _context:Dictionary)


#func inmateWonFight_text()

#func inmateWonFight_do(_id:String, _args:Dictionary, _context:Dictionary)


func inmateLostFight_text():
	saynn("{inmate.name} hits the floor. {inspector.name} won!")
	sayLine("inmate", "FightLostGeneric", {winner="inspector", loser="inmate"})
	saynn("[say=inspector]What should I do with you now...[/say]")

	addAction("inmateLostPunish", "Punish", "They gotta serve a punishment!", "punishMean", 1.0, 60, {})
	if(isWearingProperChastityCageOrBelt(getRolePawn("inmate").getChar())):
		addAction("inmateLostCage", "Inspect", "Do what you were supposed to", "punish", 1.0, 60, {})
	else:
		addAction("inmateLostDoubleCheck", "Inspect", "Do what you were supposed to", "punish", 1.0, 60, {})
	addAction("inmateLostParade", "Parade", "Teach them a lesson~", "default", 1.0, 60, {})

	addDefeatButtons("inspector", "inmate")

func inmateLostFight_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "inmateLostPunish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("inspector"), target=getRoleID("inmate")})
	if(_id == "inmateLostCage"):
		setState("RCHIinmateComplies", "inmate")
	if(_id == "inmateLostDoubleCheck"):
		setState("inmateComplies", "inmate")
	if(_id == "inmateLostParade"):
		setState("RCHIparade", "inmate")


func RCHIparade_text():
	saynn("[say=inspector]Hmm, I suppose we have to make you more comfortable being in your current position, won’t you agree?~[/say]")
	if (
		getRolePawn("inmate").getChar().getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom) && !isWearingChastityX(getRolePawn("inmate").getChar(), "Belt") \
		|| getRolePawn("inmate").getChar().getInventory().hasSlotEquipped(InventorySlot.Body) && !getRolePawn("inmate").getChar().getExposedPrivates().size() > 0
	):
		saynn("{inspector.name} suddenly grabs your clothes and pulls them down, exposing your privates [b]and[/b] your chastity gear.")
		saynn("[say=inmate]Hey! What are you...[/say]")
	saynn("The inspector turns around and screams loudly:")
	saynn("[say=inspector]Hey everyone! Come and take a look![/say]")
	saynn("You shivered heftily having heard that.")
	addDisabledAction("(Continue)", "WIP - sorry!") # TODO in future version
	addAction("RCHIinmateCompliesShameContinueSHAME", "(Try to cover yourself)", "(placeholder for this mod version)", "default", 1.0, 60, {}) # TODO REMOVE in future version
	addAction("RCHIinmateCompliesShameContinueNOTHING", "(Do nothing)", "(placeholder for this mod version; but hey, it's free xp!)", "default", 1.0, 60, {}) # TODO REMOVE in future version

func RCHIparade_do(_id:String, _args:Dictionary, _context:Dictionary):
#	if(_id == "RCHIinmateCompliesShameContinue"): TODO in future version
#		runScene("ChastityForEveryoneChastityShowOff")
#		stopMe()
	if(_id == "RCHIinmateCompliesShameContinueNOTHING"):
		getRolePawn("inmate").getChar().addSkillExperience(Skill.Exhibitionism, 40)
		setState("inmateAllGood", "inmate")
	if(_id == "RCHIinmateCompliesShameContinueSHAME"):
		setState("inmateAllGood", "inmate")


func inmateAllGood_text():
	saynn("After the check-up, you're left alone.")
	addAction("leave", "(End)", "", "default", 1.0, 60, {})

func inmateAllGood_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()


func releasedCaged_text():
	var flatCageChance = FoxGlobals.ofModule("ChastityForEveryone").configFlatCageChance
	var configBeltChance = FoxGlobals.ofModule("ChastityForEveryone").configBeltChance
	var theInmate = getRolePawn("inmate").getChar()
	var isPlayer = getRolePawn("inmate").getChar().isPlayer()
	chastityString = makeChastityString(getRolePawn("inmate").getID(), isPlayer) #doesn't seem to work globally :(
	var chastityStringFull = makeChastityString(getRolePawn("inmate").getID(), isPlayer, true)
	print_debug(isWearingChastityCageOrBelt(theInmate))
	if(loopBrakerFailsafe<=2 && !isWearingChastityCageOrBelt(theInmate)): # chastity on if inmate didn't comply and lost or didn't manage to run away
		loopBrakerFailsafe += 1 #transformation during the scene or some other weird thing, is it a real possibility? idk
		if inspectorUnwilling:
			saynn("[say=inspector]I'm sorry but I have to do this...[/say]")
		else:
			saynn("[say=inspector]I'll take a good care of you now...[/say]")
		if chastityString == "cage":
			if(inspectorUnwilling && flatCageChance < 100):
				if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: flat or regular one?[/say]")
				addAction("releasedCagedCagedRegular", "Regular", "You like having some wiggle room", "default", 1.0, 60, {})
				addAction("releasedCagedCagedFlat", "Flat one", "Looks better on you anyways", "default", 1.0, 60, {})
				addAction("releasedCagedCagedRandom", "Any will do", "", "default", 1.0, 60, {})
			else:
				saynn("[say=inspector]For all of this trouble you coused me, I think flat cage would suit you best.[/say]")
				addAction("releasedCagedCagedFlat", "(Get caged)", "", "default", 1.0, 60, {})
		elif !getRolePawn("inmate").getChar().hasPenis() || (chastityString == "belt" && chastityStringFull!="beltP"):
			if (isPlayer): saynn("[say=inspector]Get ready to be belted back up![/say]")
			addAction("releasedCagedCagedBelted", "Get locked up", "", "default", 1.0, 60, {})
		else:
			if(inspectorUnwilling && configBeltChance<100):
				if (isPlayer): saynn("[say=inspector]I’ll allow you to pick: belt or cage?[/say]")
				addAction("releasedCagedCagedBelted", "Belt", "Bulkier, but more practical", "default", 1.0, 60, {})
				if RNG.chance(flatCageChance):
					addAction("releasedCagedCagedFlat", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
				else: 
					addAction("releasedCagedCagedRegular", "Cage", "Looks better on you anyways", "default", 1.0, 60, {})
			else:
				saynn("[say=inspector]For all of this trouble you coused me, I think belt would suit you best.[/say]")
				addAction("releasedCagedCagedBelted", "(Get locked)", "", "default", 1.0, 60, {})
		if (!isPlayer): saynn("[say=inmate]Fuck, you will pay me for that![/say]")
	else: #got caged in scene already
		saynn("[say=inspector]Stand still now.[/say]")
		saynn("{inspector.name} takes out the chastity gear and starts forcing it on {inmate.you}. They are not as careful nor as skilled, as was the doctor. Or they simply don’t care.")
		saynn("After {inmate.your} genitals get put in chastity, {inspector.name} turns the key on the lock and hides it in {inspector.hisHer} pocket.")
		var tempString = "[say=inspector]Aaaand finished. I’ll make sure this key gets to Eliza.[/say]"
		
		print_debug("femininintiniti", theInmate.getFemininity())
		if(!theInmate.hasPenis() || theInmate.getFemininity() > 40):
			if(theInmate.isPlayer()):
				GM.pc.addPain(5)
				GM.pc.addLust(20)
				saynn(tempString)
				saynn("With your little clitty safely locked up, {inspector.name} leaves you alone.")
			else:
				saynn(tempString)
				saynn("{inmate.name} got {inmate.hisHer} clitty locked up, after that {inspector.name} leaves them alone.")
		else:
			if(theInmate.isPlayer()):
				GM.pc.addPain(5)
				GM.pc.addLust(20)
				saynn(tempString)
				saynn("With {inmate.your} genitals safely locked up, {inspector.name} leaves you alone.")
			else:
				saynn(tempString)
				saynn("{inmate.name} got {inmate.hisHer} genitals locked up, after that {inspector.name} leaves them alone.")
		addAction("releasedCagedEnd", "(Leave)", "", "default", 1.0, 60, {})


func getAnimData() -> Array:
	var theInmate = getRolePawn("inmate").getChar()

	if(getState() == "RCHIinmateComplies"):
		return [StageScene.Grope, "grope", {pc="inmate", npc="inspector", bodyState={exposedCrotch=true}}]
	if(getState() == "RCHIinmateCompliesShame"):
		return [StageScene.SexFreeStanding, "tease", {npc="inmate", pc="inspector", npcBodyState={exposedCrotch=true}}]
	if(getState() == "RCHIinmateResists"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=false}]
	if(getState() == "RCHIparade"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", bodyState={exposedCrotch=true}, further=false}]
	if(getState() == "inmateAllGood"):
		return [StageScene.TFLook, "crotch", {pc="inmate", npc="inspector"}]
		
	# copy from parent class ChastityPolice below:
	if(getState() == "confrontation"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=true}]
	if(getState() == "inmateResists"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=false}]
	if(getState() in ["inmateTops", "inmateBottoms", "inspectorSatisfied", "inspectorNotSatisfied"]):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="stand", further=false}]
	if(getState() == "inspectorGotRekt"):
		return [StageScene.SexStart, "defeated", {pc="inmate", npc="inspector"}]
	if(getState() == "inmateComplies"):
		return [StageScene.Grope, "grope", {pc="inmate", npc="inspector", bodyState={exposedCrotch=true}}]
	if(getState() == "inmateRuns"):
		return [StageScene.Duo, "jog", {pc="inspector", npc="inmate", npcAction="jog", further=false, flipNPC=true}]
	if(getState() == "inmateRunsSuccess"):
		return [StageScene.Grope, "gropefast", {pc="inmate", onlyPC=true}]
	if(getState() == "inmateRunsFail"):
		return [StageScene.Duo, "hurt", {pc="inmate", npc="inspector", npcAction="stunbaton"}]
	if(getState() == "inmateFightsFirst"):
		return [StageScene.Duo, "punch", {pc="inmate", npc="inspector", npcAction="hurt"}]
	if(getState() == "inmateFights"):
		return [StageScene.Duo, "dodge", {pc="inmate", npc="inspector", npcAction="stunbaton"}]
	if(getState() == "inmateWonFight"):
		return [StageScene.Duo, "stand", {pc="inmate", npc="inspector", npcAction="defeat"}]
	if(getState() == "cageTheInspector"):
		return [StageScene.BreastFeeding, "tease", {pc="inspector", npc="inmate", bodyState={exposedCrotch=true}}]
	if(getState() == "inmateLostFight"):
		return [StageScene.Duo, "defeat", {pc="inmate", npc="inspector", npcAction="stand"}]
	if(getState() == "releasedCaged" && !theInmate.isWearingChastityCage()):
		return [StageScene.BreastFeeding, "tease", {pc="inmate", npc="inspector", bodyState={exposedCrotch=true, hard=true}}]
	if(getState() == "releasedCaged" && theInmate.isWearingChastityCage()):
		return [StageScene.TFLook, "crotch", {pc="inmate", bodyState={exposedCrotch=true, hard=false}}]
	if(getState() == "inmateFree"):
		return [StageScene.TFLook, "start", {pc="inmate"}]
	return [StageScene.Solo, "jog", {pc="inspector"}]
