# mod version: 2.3
extends "res://Scenes/SceneBase.gd"

var DEBUG = false

func isWearingPermanentChastityBelt(character):
	if(character.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom)):
		var item = character.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
		if "Permanent" in item.getVisibleName() && "Chastity Belt" in item.getVisibleName():
			return true
	return false

func _init():
	sceneID = "ChastityForEveryoneLubeWiggleOutScene"

func _run():
	var buttonsShowedUp = false # fix for when game is loaded in the scene, dirty, but it works, I'm probably doing something wrong
	if DEBUG:
		print_debug("flag StockpileUseLube")
		print_debug(getModuleFlag("ChastityForEveryone", "Lube.StockpileUseLube"))
		print_debug("flag StockpileSearched")
		print_debug(getModuleFlag("ChastityForEveryone", "Lube.StockpileSearched"))
	playAnimation(StageScene.Solo, "stand", {pc="pc"})

	if(state == "" && !getModuleFlag("ChastityForEveryone", "Lube.StockpileSearched", false) && !getModuleFlag("ChastityForEveryone", "Lube.StockpileUseLube", false)):
		if DEBUG: print_debug("STATE: first interaction")
		setModuleFlag("ChastityForEveryone", "Lube.StockpileUseLube", false)
		
		saynn("The surrounding space is partially occupied with a various assortment of crates, barrels and boxes, presumably supplies for the engineering bay, or the prison as a whole. You catch a glimpse of a barrel with letters L-U-B… written across it. It’s a rather random place to keep a full barrel of lube, are engineers that kinky?")
		
		saynn("Upon getting closer and a further inspection it has occurred to you, that it’s a industrial-grade lubricant for use in greasing up machinery and such. “Universe renowned” it’ written in quirky font on the side of the barrel.")
		
		saynn("In case you would randomly need to made something metallic all slippery it’s just junk as anything else in here. Plus, you don’t need extra contraband on your person, you’ve carrying enough as it is.")
		
		if(isWearingPermanentChastityBelt(GM.pc)):
			saynn("As you begin to walk away your chastity belt shifts and reminds you of its presence.")
			
			saynn("[say=pc] Unless...[/say]")

		buttonsShowedUp = true
		addButton("Keep that in mind", "", "endFirstTime")

	if(state == "" && getModuleFlag("ChastityForEveryone", "Lube.StockpileUseLube", false) && getModuleFlag("ChastityForEveryone", "Lube.StockpileSearched", false)):
		if DEBUG: print_debug("STATE: use the lube")
		setModuleFlag("ChastityForEveryone", "Lube.StockpileUseLube", false)
		
		saynn("You’ve figured, that this barrel could help you deal with your – supposedly permanent, predicament. Unfortunately there is no tap, but you’ve managed to find a metal rod to prod the lid open and revile the content.")
		saynn("The chastity belts have one major flaw – only your hips block it from being pulled down. Eliza made sure that the hoop  is pressed tightly around your waist, nonetheless it’s not physically glued to you. All of this lube could help you yank it down.")

		buttonsShowedUp = true
		addButton("Try it", "Reach for the lube", "wiggleStart")
		
	if(state=="wiggleStart"):
		if DEBUG: print_debug("STATE: wiggle start")
		playAnimation(StageScene.Solo, "struggle", {bodyState={exposedCrotch=true}})
		
		saynn("You reached out to the barrel and scooped a handful of thick liquid. It’s all greasy and some droplets fall to the ground. Undetermined you start covering your sides with it, all around the metal hoop of the chastity belt. After covering it thoroughly the hard part begins. You press down on the belt with all your strength but it only moves a little.")
		if GM.pc.getStat(Stat.Strength) >= 15:
			var item = GM.pc.getInventory().getEquippedItem(InventorySlot.UnderwearBottom)
			if GM.pc.hasPenis() && "beltV" in item.getVisibleName():
				var penisSize = GM.pc.getBodypart(BodypartSlot.Penis).getLength()
				saynn("Your penis is also making it harder to do, as the belt gets blocked on it.")
				if(penisSize <= 8.0):
					addButton("Push harder", "", "wiggleSuccessPenisSmall")
				else:
					addButton("Push harder", "", "wiggleStrugglePenisBig")
			else:
				addButton("Push harder", "", "wiggleSuccess")
		else:
			addDisabledButton("Push harder", "Your strength is too low (< 15)")
			addButton("Give up", "", "wiggleStruggle")
		buttonsShowedUp = true
		
	if(state=="wiggleSuccessPenisSmall"):
		if DEBUG: print_debug("STATE: wiggleSuccessPenisSmall")
		saynn("Fortunately you {pc.penis} did not give you much trouble.")
		#rest the same as wiggleSuccess
	if(state in ["wiggleSuccessPenisSmall", "wiggleSuccess"]):
		if DEBUG: print_debug("STATE: in [\"wiggleSuccessPenisSmall\", \"wiggleSuccess\"]")
		playAnimation(StageScene.TFLook, "crotch", {bodyState={exposedCrotch=true}})
		saynn("Thanks to your strength you successfully pushed the hoop of the belt past your hips. You’ve scratched your legs a bit, but in the end you made the belt hit the floor with audible bang.")
		saynn("Great success!")
		buttonsShowedUp = true
		addButton("Leave", "", "end")
		# TODO when the story expansion for the mod comes out add a caracter that would try to stop the player here, and will put them back in chastity or smthg
		
	if(state=="wiggleStrugglePenisBig"):
		if DEBUG: print_debug("STATE: wiggleStrugglePenisBig")
		saynn("It seems that due to the size of your {pc.penis} the belt just won't come down. Dang!")
		#rest the same as wiggleStruggle
	if(state in ["wiggleStruggle", "wiggleStrugglePenisBig"]):
		if DEBUG: print_debug("STATE: in [\"wiggleStruggle\", \"wiggleStrugglePenisBig\"")
		saynn("Despite all of this lubricant and your strong motivation to succeed, the belt wouldn’t move. Looks like you stuck with it for a bit longer.")
		buttonsShowedUp = true
		addButton("Leave", "", "end")
	
	if(!buttonsShowedUp):
		addButton("Leave", "", "end")

func _react(_action: String, _args):
	if(_action == ""):
		return
	if(_action == "wiggleStart"):
		setState("wiggleStart")
		return
	if(_action == "wiggleStruggle" || _action == "wiggleStrugglePenisBig"):
		setState("wiggleStruggle")
		GM.pc.addStamina(-20)
		setState(_action)
		return
	if(_action == "wiggleSuccess" || _action == "wiggleSuccessPenisSmall"):
		setModuleFlag("ChastityForEveryone", "Lube.StockpileDaysSinceUsed", RNG.randi_range(5, 10))
		setModuleFlag("ChastityForEveryone", "Lube.StockpileUsedToday", true)
		GM.pc.addStamina(-30)
		GM.pc.addEffect(StatusEffect.Exhausted)
		GM.pc.addPain(20)
		GM.pc.getInventory().unequipSlot(InventorySlot.UnderwearBottom)
		setState(_action)
		return
	if(_action == "endFirstTime"):
		setFlag("ChastityForEveryone.Lube.StockpileSearched", true)
		endScene()
		return
	if(_action == "end"):
		endScene()
		return
	
	setState(_action)
	processTime(60)
	return
