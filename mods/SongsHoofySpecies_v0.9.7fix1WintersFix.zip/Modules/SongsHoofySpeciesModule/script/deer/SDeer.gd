extends Species

func _init():
	id = "sdeer"
	
func getVisibleName():
	return "Deer"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffhoofs", "fluffhoofssmall", "scruffhoofs", "scruffhoofssmall", "sdeerhoofs1", "sunihoofs1"])
	return RNG.pick(["sdeerhoofs1", "sunihoofs1"])

func getDefaultTail(_gender):
	return "sunitail2"

func isPlayable():
	return true

func getVisibleDescription():
	return "Herbivores of the forest"

func getDefaultHead(_gender):
	return "sdeerhead1"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffbody", "scruffbodyneckfluff", "scruffbody", "anthrobody"])
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"
	#Tried adding the fluffy arm part, but left it out since it didn't seem to fit well with the paws ㅠㅠ

func getDefaultEars(_gender):
	return "suniears2"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "sdeerantlers1"
	else:
		return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 7.0],
		[2, 5.0],
		[3, 0.5],
	]

func getDefaultBreasts(_gender):
	var modules = GlobalRegistry.getModules()
	var WinterBreastmod = "WintersExpandedBreasts" in modules
	var WinterFluffmod = "WintersFluffyBodyparts" in modules

	if WinterBreastmod and WinterFluffmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["fluffmalebreasts", "malefluffbreastsnippleinv", "malefluffbreastspuffy", "malefluffbreastspuffyinv"])
		return RNG.pick(["fluffbreasts", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"])

	elif WinterBreastmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"])
		return RNG.pick(["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"])

	elif WinterFluffmod:
		if (_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"

	else:
		if (_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
