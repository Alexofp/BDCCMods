extends Species

func _init():
	id = "scow"
	
func getVisibleName():
	return "Cow"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffhoofs", "fluffhoofssmall", "scruffhoofs", "scruffhoofssmall", "scowhoofs1", "sunihoofs1"])
	return RNG.pick(["scowhoofs1", "sunihoofs1"])

func getDefaultTail(_gender):
	return "sunitail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "Milky Friends"

func getDefaultHead(_gender):
	return "scowhead1"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffbody", "scruffbody", "anthrobody"])
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"
	#Tried adding the fluffy arm part, but left it out since it didn't seem to fit well with the paws ㅠㅠ

func getDefaultEars(_gender):
	return "suniears1"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "scowhorns1"
	else:
		return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("songjohorseparts" in GlobalRegistry.getModules()):
			return "songhorsepenis"
		else:
			return "equinepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 10.0],
		[2, 1.5],
		[3, 0.5],
	]

func getDefaultBreasts(_gender):
	var modules = GlobalRegistry.getModules()
	var WinterBreastmod = "WintersExpandedBreasts" in modules
	var WinterFluffmod = "WintersFluffyBodyparts" in modules

	if WinterBreastmod and WinterFluffmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["fluffmalebreasts", "malefluffbreastsnippleinv", "malefluffbreastspuffy", "malefluffbreastspuffyinv"])
		return RNG.pick(["fluffbreasts", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"])

	elif WinterBreastmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"])
		return RNG.pick(["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"])

	elif WinterFluffmod:
		if (_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"

	else:
		if (_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
