extends Species

func _init():
	id = "sheep"
	
func getVisibleName():
	return "Sheep"

func getDefaultBody(_gender):
	return "sheepbody"

func getDefaultLegs(_gender):
	return "sheephoofs"
	
func getDefaultTail(_gender):
	return "sheeptail"

func getDefaultHorns(_gender):
	return "sheepspiralhorns"

func isPlayable():
	return true

func getVisibleDescription():
	return "Cute fluffballs"

func getDefaultHead(_gender):
	return "sheephead"

func getDefaultArms(_gender):
	return "sheeparms"

func getDefaultEars(_gender):
	return "sheepears"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sheeppenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 2.0],
		[2, 8.0],
		[3, 6.0],
		[4, 4.0],
		[5, 2.0],
		[6, 1.0],
		[7, 0.5],
	]

func getDefaultBreasts(_gender):
	if ("WintersExpandedBreasts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv",])
		return RNG.pick(["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv",])
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
