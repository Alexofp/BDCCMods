extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "sgoat"
	
func getVisibleName():
	return "Goat"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffhoofssmall", "scruffhoofssmall", "sgoathoofs1", "sunihoofs1"])
	return RNG.pick(["sgoathoofs1", "sunihoofs1"])

func getDefaultTail(_gender):
	return "sunitail2"

func isPlayable():
	return true

func getVisibleDescription():
	return "Curious and Stubborn friends."

func getDefaultHead(_gender):
	return "sgoathead1"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffbody", "scruffbody", "anthrobody"])
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "suniears3"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "sgoathorns1"
	else:
		return "sgoathorns2"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenishyperable"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 8.0],
		[3, 4.0],
		[4, 2.0],
		[5, 0.5],
	]

func getDefaultBreasts(_gender):
	var modules = GlobalRegistry.getModules()
	var WinterBreastmod = "WintersExpandedBreasts" in modules
	var WinterFluffmod = "WintersFluffyBodyparts" in modules

	if WinterBreastmod and WinterFluffmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["fluffmalebreastshyperable", "malefluffbreastsnippleinvhyperable", "malefluffbreastspuffyhyperable", "malefluffbreastspuffyinvhyperable"])
		return RNG.pick(["fluffbreastshyperable", "fluffbreastsnippleinvhyperable", "fluffbreastspuffyhyperable", "fluffbreastspuffyinvhyperable"])

	elif WinterBreastmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipplehyperable", "malebreastsnippleinvhyperable", "malebreastspuffyhyperable", "malebreastspuffyinvhyperable"])
		return RNG.pick(["breastsnipplehyperable", "breastsnippleinvhyperable", "breastspuffyhyperable", "breastspuffyinvhyperable"])

	elif WinterFluffmod:
		if (_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"

	else:
		if (_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"
