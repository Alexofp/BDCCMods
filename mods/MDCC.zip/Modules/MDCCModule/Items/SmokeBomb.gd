extends ItemBase

func _init():
	id = "MDCC_SmokeBomb"

func getVisibleName():
	return "Smoke Bomb"

func getDescription():
	var text = "A small, round bomb that releases smoke upon detonation.\nDoes a tiny bit of physical damage and causes blindness."

	return text

func canCombine():
	return true

func getAttacks():
	return ["MDCC_SmokeBombAttack"]

func getTags():
	return [ItemTag.Illegal]

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"
