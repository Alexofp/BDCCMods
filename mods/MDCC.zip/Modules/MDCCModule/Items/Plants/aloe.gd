extends ItemBase

func _init():
	id = "MDCCaloe"

func getVisibleName():
	return "Bishop Aloe Leaf"
	
func getDescription():
	return "A leaf."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
