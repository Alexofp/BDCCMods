extends ItemBase

func _init():
	id = "MDCCdognipt"

func getVisibleName():
	return "Dognip"
	
func getDescription():
	return "A thing."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
