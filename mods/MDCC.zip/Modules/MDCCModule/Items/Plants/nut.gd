extends ItemBase

func _init():
	id = "MDCCnut"

func getVisibleName():
	return "Nut"
	
func getDescription():
	return "A nut."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
