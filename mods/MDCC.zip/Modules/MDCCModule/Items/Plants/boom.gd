extends ItemBase

func _init():
	id = "MDCCboom"

func getVisibleName():
	return "Explosive thing"
	
func getDescription():
	return "A thing."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
