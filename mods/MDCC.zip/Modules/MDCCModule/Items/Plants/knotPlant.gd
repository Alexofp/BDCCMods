extends ItemBase

func _init():
	id = "MDCCknot"

func getVisibleName():
	return "Strange Purple Fruit"
	
func getDescription():
	return "A fruit."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
