extends ItemBase

func _init():
	id = "MDCCroot"

func getVisibleName():
	return "Teleport Root"
	
func getDescription():
	return "A root."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
