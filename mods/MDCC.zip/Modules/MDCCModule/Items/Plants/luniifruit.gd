extends ItemBase

const restoredStamina : int = 10
const restoredPain : int = 10

func _init():
	id = "MDCCluniifruit"

func getVisibleName():
	return "Lunii Fruit"
	
func getDescription():
	return "A thingy.\nRestores %s stamina and removes %s pain" % [restoredStamina, restoredPain]


func getInventoryImage():
	return "res://Modules/MDCCModule/Items/Icons/Restricted_Keycard.png"

func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	_attacker.addPain(-restoredPain)
	_attacker.addStamina(restoredStamina)
	removeXOrDestroy(1)
	return "{_attacker.NameOrYou} ate a lunii fruit."

func getPossibleActions():
	return [
		{
			"name": "Eat",
			"scene": "UseItemLikeInCombatScene",
			"description": "Eat a lunii fruit",
		},
	]

func canCombine():
	return true

func getItemCategory():
	return "MDCC"
