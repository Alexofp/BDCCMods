extends ItemBase

func _init():
	id = "MDCCteleportTotem"

func getVisibleName():
	return "Teleport Totem"
	
func getDescription():
	return "A totem that can teleport you inside the locked greenhouse."

func isImportant():
	return true

func canSell():
	return false

func canCombine():
	return true

func getInventoryImageColor():
	return Color.mediumseagreen

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"


func canUseInCombat():
	return false

func useInCombat(_attacker, _receiver):
	if _attacker==GM.pc:
		_attacker.setLocation("MDCC_keypaddoor")
		return "{_attacker.nameOrYou} used the teleport totem"
	return "{_attacker.name} tried to use the teleport totem but failed!"

func getPossibleActions():
	return [
		{
			"name": "Use",
			"scene": "UseItemLikeInCombatScene",
			"description": "Teleport to the greenhouse",
		},
	]
