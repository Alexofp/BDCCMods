extends ItemBase

var seedType : String = "" # plant id
var seedName : String = "unknown" # to avoid calling all the time
var seedRarity : String = "" # just the string of it for now
var description : String = ""

var important : bool = false

func setSeedType(st:String="") -> void:
	seedType = st
	var plant = getPlant()
	seedName = plant.name
	seedRarity = GlobalRegistry.getModule("MDCC").getSubmodule("Plants").getPlantRarityName(plant.rarity)
	important = plant.rarity==0
	description = plant.desc

func _init():
	id = "MDCC_Seed"

func getVisibleName():
	return "Seed (%s)" % seedName

func getPlant():
	var mod = GlobalRegistry.getModules().get("MDCC")
	return mod.getSubmodule("Plants").getPlant(seedType)

func getInventoryGroupName():
	return "Seeds"

func canCombine():
	return true
	
func tryCombine(_otherItem):
	if _otherItem.seedType!=seedType:
		return false
	amount += _otherItem.amount
	return true


func getDescription():
	return "Seeds that can be planted in the greenhouse\nRarity: %s%s" % [seedRarity, ( "\n\n%s" % description if description else "" ) ]

func isImportant():
	return important

func canSell():
	return false

func getInventoryImageColor():
	return Color.mediumseagreen

func getInventoryImage():
	return "res://Images/Perks/flowers.png"

func getItemCategory():
	return "MDCC"

func saveData():
	var d = .saveData()
	d["seedType"] = seedType
	return d

func loadData(d):
	.loadData(d)
	setSeedType(SAVE.loadVar(d, "seedType", ""))
