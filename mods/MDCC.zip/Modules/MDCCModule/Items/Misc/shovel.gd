extends ItemBase

func _init():
	id = "MDCCshovel"

func getVisibleName():
	return "Shovel"
	
func getDescription():
	return "A shovel that can be used for digging."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"
