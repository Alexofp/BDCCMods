extends ItemBase

func _init():
	id = "MDCCscrapMetal"

func getVisibleName():
	return "Scrap Metal"
	
func getDescription():
	return "A few pieces of scrap metal."

func getItemCategory():
	return "MDCC"

func getInventoryImage():
	return "res://Images/StatusEffects/smoke-bomb.png"

func canCombine():
	return true
