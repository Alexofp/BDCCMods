extends Attack

func _init():
	id = "MDCC_LustDotAttack"
	category = Category.Special
	aiCategory = AICategory.Offensive
	attackPriority = 5
	
func getVisibleName(_context = {}):
	return "Throw smoke bomb"
	
func getVisibleDesc(_context = {}):
	return "Ta"
	
func _doAttack(_attacker, _receiver, _context = {}):
	_attacker.getInventory().removeXOfOrDestroy("MDCC_SmokeBomb",1)
	
#	if(checkMissed(_attacker, _receiver, damageType, 1.0)):
#		var txt = "{attacker.NameOrYou} forgot to press the detonation trigger on the smoke bomb"
#		return {
#			text = txt,
#			missed = true,
#		}
#
#	if(checkDodged(_attacker, _receiver, damageType)):
#		var txt = "{receiver.NameOrYou} dodged the smoke bomb"
#		return {
#			text = txt,
#			dodged = true,
#		}
#
#	var texts = [
#		"{attacker.name} throws a smoke bomb at {receiver.name}.",
#	]
#
#	var text = RNG.pick(texts)
#
#	_receiver.addEffect(StatusEffect.Blindness, [blindTurns])
	
	return {
		text = "a",
		pain = 1,
	}
	
func _canUse(_attacker, _receiver, _context = {}):
	return true
	

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]

func getAnticipationText(_attacker, _receiver):
	return "{attacker.name}a at you!"

func getAttackSoloAnimation():
	return "throw"

func getExperience():
	return [[Skill.Combat, 10]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 1.5
