extends Control

var currentChoiceIdx : int = 0
var choices : Array = [] # array of indexes [start,end, type]

var brackets : Array = [
	"<>", "[]", "{}", "()", # for replenishing attempts
]

var selectionChar = "█"

enum ChoiceType { CHOICE, BRACKET, NONE }

var junkChars : String = "!@#$%^&*/.,\\;"

var triesLeft : int = 3
var score : int = 0
var inGame : bool = false

var password : String = ""
var displayedText : String = ""

var difficulty : int = 12 # 1-15, 12 is the last one that has a decent variety of words

const typeSpeed : float = 0.06

func _process(delta):
	$TextureRect.rect_position.y = wrapf($TextureRect.rect_position.y + delta * 10, -256, 0)
	$TextureRect.modulate = Color(1, 1, 1, clamp( sin($TextureRect.rect_position.y * 0.1) + 0.5, 0.5, 1.0))

func addTries(am:int) -> void:
	triesLeft += am
	$cc/rightmenu/tries.text = "%s attempts left" % triesLeft

func removeDud() -> bool: # returns successful
	var avails = []
	for choice in choices:
		if getTextFromChoice(choice)==password or choice[2]!=ChoiceType.CHOICE:
			continue
		avails.append(choice)
	
	if !avails:
		return false
	
#	removeChoice(RNG.pick(avails))
	return true

func words() -> PoolStringArray:
	var file : File = File.new()
	if file.open("res://Modules/MDCCModule/Minigames/Hacking/words.txt", File.READ) == OK:
		var ar : PoolStringArray = PoolStringArray([])
		for string in file.get_as_text().split(" ",false):
			if string.length()==difficulty:
				ar.append(string)
		
		return ar
	else:
		return PoolStringArray([])

func addHistoryEntry(txt:String) -> void:
	var e = Label.new()
	e.add_font_override("font",load("res://Modules/MDCCModule/Minigames/Hacking/hackingMinigameFont.tres"))
	e.text = txt
	e.add_color_override("font_color",Color("009a18"))
	e.align = Label.ALIGN_RIGHT
	$cc/rightmenu/history.add_child(e)
	while $cc/rightmenu/history.get_child_count()>10:
		$cc/rightmenu/history.get_child(0).queue_free()
		$cc/rightmenu/history.remove_child($cc/rightmenu/history.get_child(0))

func createChoices() -> void:
	displayedText = ""
	
	var possibles : Array = Array(words())
	if !possibles:
		end()
	
	var chosens = []
	for i in min(possibles.size(),20):
		chosens.append(RNG.grab(possibles))
	
	password = RNG.pick(chosens)
	
	
	var lastIdx = 0
	for chosen in chosens:
		choices.append([lastIdx,lastIdx+chosen.length(),ChoiceType.CHOICE])
		lastIdx += chosen.length()
		
		displayedText += chosen
		
		
		var bracketRelativeIdxs = [-1,-1]
		var junkSize = RNG.randi_range(8,24)
		var bracketChars = ""
		if RNG.chance(100): # add bracket
			var fidx = RNG.randi_range(0,junkSize-2) # first
			bracketRelativeIdxs[0]=fidx
			bracketRelativeIdxs[1]=RNG.randi_range(fidx,junkSize-2)
			bracketChars = RNG.pick(brackets)
		
		var bracketArray = []
		for i in junkSize:
			if i==bracketRelativeIdxs[0]: # start of bracket
				bracketArray.append(lastIdx)
				displayedText += bracketChars[0]
			elif i==bracketRelativeIdxs[1]: # end of bracket
				bracketArray.append(lastIdx+1)
				displayedText += bracketChars[1]
			
			else: # add junk
				displayedText += junkChars[RNG.randi_range(0,junkChars.length()-1)]
			lastIdx+=1
		
		if bracketArray.size()==2:
			bracketArray.append(ChoiceType.BRACKET)
			choices.append(bracketArray)
		
		
		
	
	displayChoice()
	$cc/vb/RichTextLabel.parse_bbcode(displayedText)


func updDifficulty():
	pass

func _ready():
	randomize()
	$cc/rightmenu/typingThing.install_effect(load("res://Modules/MDCCModule/Minigames/Hacking/hacking_typing_effect.gd").new())
	updDifficulty()
	createChoices()
	addTries(0)

func _input(event):
	if event.is_action_pressed("ui_right",true):
		if Input.is_key_pressed(16777237): # shift
			var idx = findNextChoiceIdx()
			currentChoiceIdx = choices[idx][0]
			
			displayChoice()
		else:
			moveCursor(1)
	elif event.is_action_pressed("ui_left",true):
		if Input.is_key_pressed(16777237): # shift
			var idx = findPreviousChoiceIdx()
			currentChoiceIdx = choices[idx][0] if idx>=0 else 0
			
			displayChoice()
		else:
			moveCursor(-1)
	elif event.is_action_pressed("ui_accept"):
		commit(getTextFromChoice(findCurrentChoice()))

func commit(txt:String) -> void:
#	$commit.pitch_scale = RNG.randf_range(0.88,0.93)
#	$commit.play()
	var cc = findCurrentChoice()
	if !cc:
		return
	if cc[2]==ChoiceType.NONE:
		return
	addHistoryEntry(txt)
	if password==txt:
		print("you win")
		end()
#	elif not txt in junkChars && not txt in brackets: # fail
#		print("not good")
#		if cc:
#			removeChoice(cc)
	elif cc[2]==ChoiceType.BRACKET:
		print("aa")
		removeChoice(cc)
		
		if removeDud():
			addTries(1)
	elif cc[2]==ChoiceType.CHOICE:
		removeChoice(cc)

func removeChoice(choice:Array) -> void:
	var l = choice[1]-choice[0]
	displayedText.erase(choice[0],l)
	displayedText = displayedText.insert(choice[0],".".repeat(l))
	$cc/vb/RichTextLabel.parse_bbcode(displayedText)
	choice[2]=ChoiceType.NONE

func getChoiceText() -> String:
	return $cc/rightmenu/typingThing.text

func getTextFromChoice(currentChoice:Array) -> String:
	if !currentChoice:
		return ""
	var length = 1 if currentChoice[2]==ChoiceType.BRACKET else currentChoice[1]-currentChoice[0]
	
	if currentChoice[2]==ChoiceType.BRACKET:
		currentChoice[0] = currentChoiceIdx
	
	var typed = displayedText.substr(currentChoice[0],length)
	return typed

func displayChoice() -> void:
	var currentChoice = findCurrentChoice()
	
	if !currentChoice:
		currentChoice = [currentChoiceIdx,currentChoiceIdx+1,ChoiceType.BRACKET]
	
	var length = 1 if currentChoice[2]==ChoiceType.BRACKET else currentChoice[1]-currentChoice[0]
	
	if currentChoice[2]==ChoiceType.BRACKET:
		currentChoice[0] = currentChoiceIdx
	
	var res = ""+" ".repeat(displayedText.length()-length).insert(currentChoice[0],  ""+selectionChar.repeat(length)+"" )+""
	
	
	$cc/vb/RichTextLabel/selectorLabel.parse_bbcode(res)
	var typed = displayedText.substr(currentChoice[0],length)
	
	var tt = $cc/rightmenu/typingThing
	if tt.text==typed:
		return
	
#	tt.visible_characters = 0
#	tt.text = typed
#	var t = tt.create_tween()
#	for ch in typed.length():
##		t.tween_interval(typeSpeed)
#		t.tween_callback($type,"play")
#		t.tween_property(tt,"visible_characters",ch+1,typeSpeed)
#		t.parallel().tween_property($type,"pitch_scale",RNG.randf_range(1.1,1.3),0.0)
#		print("a")
	tt.parse_bbcode("[type]%s[/type]" % typed)

func findNextChoiceIdx() -> int:
	for choicei in choices.size():
		if currentChoiceIdx<choices[choicei][0] && choices[choicei][2] in [ChoiceType.CHOICE, ChoiceType.NONE]:
			return choicei
	return -1

func findPreviousChoiceIdx() -> int:
#	var chosen = 0
	var s = choices.size()
	for choicei in s:
		if currentChoiceIdx>choices[s-1-choicei][0] && choices[s-1-choicei][2] in [ChoiceType.CHOICE, ChoiceType.NONE]:
			return s-1-choicei
	return -1

func findCurrentChoice() -> Array:
	for choice in choices:
		if currentChoiceIdx>=choice[0] && currentChoiceIdx<choice[1]:
			return choice
	return []


func moveCursor(dir:int=1) -> void:
	var currentChoice = findCurrentChoice()
	if currentChoice && currentChoice[2] in [ChoiceType.CHOICE, ChoiceType.NONE]:
		currentChoiceIdx = currentChoice[1] if dir>=1 else currentChoice[0]-1
	else:
		currentChoiceIdx += dir
	
	currentChoiceIdx = int(clamp(currentChoiceIdx,0,displayedText.length()-1))
	
	displayChoice()


func end():
	inGame = false
	yield(get_tree().create_timer(0.5),"timeout")
	var res = MinigameResult.new()
	res.score = score
	res.failedHard = score==0
	print(res.score)
#	queue_free()
	return res



func endCriticalFail():
	score = 0
	end()
