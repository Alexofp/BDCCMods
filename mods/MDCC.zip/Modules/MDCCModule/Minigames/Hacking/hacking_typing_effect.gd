extends RichTextEffect

var bbcode = "type"

const CURSOR = ord("|")

func _process_custom_fx(char_fx):
	var speed = char_fx.env.get("speed", 27.5)
	if(char_fx.elapsed_time*speed > char_fx.relative_index):
		pass
	elif (char_fx.elapsed_time*speed+1) > char_fx.relative_index :
		char_fx.character = CURSOR
	else:
		char_fx.character = 32
	return true
