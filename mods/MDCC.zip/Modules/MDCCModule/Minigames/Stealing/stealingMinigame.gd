extends Control

var score : float = 0

var validActions = []

var currentIdx = 0
var currentSet = 0

const DoneColor : Color = Color("#34404c")
const NormalColor : Color = Color("#5159b8")
const BadColor : Color = Color.crimson

onready var timerBar : ProgressBar = $vb/bar/ProgressBar
onready var livesBar : ProgressBar = $vb/lives/ProgressBar

var arrowTexture = load("res://Modules/MDCCModule/Minigames/Stealing/arrow.png")

var lootMultIncrease = 5

var timeLimit : float = 6.0

var dirs = {
	Vector2.LEFT:"ui_left",
	Vector2.RIGHT:"ui_right",
	Vector2.DOWN:"ui_down",
	Vector2.UP:"ui_up",
}

var arrows = [
	
]

var fails : int = 2 # left

var extraArrowsPerSet : int = 0
var extraTimePerSet : float = 0.0


signal finished(result)

func _ready():
	$end.hide()
	
	extraArrowsPerSet = -int(GM.pc.hasPerk("MDCC_Fingersmith"))
	extraTimePerSet = int(GM.pc.hasPerk("MDCC_QuickFingers"))
	
	score = 50.0 # init loot mult
	if GM.pc.hasPerk("MDCC_MoreMarks"):
		fails += 1
	if GM.pc.hasPerk("MDCC_Shade"):
		fails += 2
	
	
	if GM.pc.hasPerk("MDCC_SoftPresence"): # to override C
		timeLimit = 10.0
	elif GM.pc.hasPerk("MDCC_LowPresence"):
		timeLimit = 8.0
	
	if GM.pc.hasPerk("MDCC_MasterPickpocket"):
		score = 150.0
	elif GM.pc.hasPerk("MDCC_AdeptPickpocket"):
		score = 120.0
	elif GM.pc.hasPerk("MDCC_Pickpocket"):
		score = 90.0
		lootMultIncrease = 10.0
	
	livesBar.max_value = fails
	livesBar.value = fails
	for dir in dirs:
		validActions.append(dirs[dir])
	newSet()
	timerBar.max_value = timeLimit
	$Timer.wait_time = timeLimit
	$Timer.start()
	setScore(score)

func setScore(v:float) -> void:
	score = v
	$vb/loot.text = "Loot multiplier: %s" % str(score).pad_decimals(0)+"%"

func clearSet() -> void:
	Util.delete_children($vb/hb)
	arrows.clear()


func createArrow(dir:Vector2=Vector2.ZERO) -> Control:
#	var l = Label.new()
	var c = Control.new()
	var l = TextureRect.new()
	if !dirs.has(dir):
		dir = RNG.pick(dirs.keys())
	
	
	
	c.rect_min_size = Vector2.ONE*72
	l.rect_min_size = c.rect_min_size
	l.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	l.expand = true
	l.texture = arrowTexture
	l.rect_pivot_offset = c.rect_min_size*0.5
	
	c.modulate = NormalColor
	
	arrows.append(dir)
	c.add_child(l)
	$vb/hb.add_child(c)
	l.rect_rotation = rad2deg(dir.angle())
	return c

func newSet() -> void:
	clearSet()
	currentSet+=1
	var amount = 7
	
	if currentSet<=2:
		amount = 5
	elif currentSet<=4:
		amount = 6
	
	amount = int(  max(1, amount+extraArrowsPerSet)  )
	
	for i in amount:
		createArrow()
	
	$Timer.start( $vb/bar/ProgressBar.value )


func _process(_delta):
	if $Timer.is_stopped():
		return
	
	timerBar.value = $Timer.time_left

func _input(event):
	if $Timer.is_stopped():
		return
	var currentArrow = arrows[currentIdx] if arrows.size()>currentIdx else null
	if !currentArrow:
		return
	if event.is_action_pressed(dirs[currentArrow]): # correct
		removeArrow()
		return
	var act = isValidEvent(event)
	if act && event.pressed: # wrong!!!
		var dir = dirs.keys()[dirs.values().find(act)] # vector2
		removeArrow(dir)
		return

func removeArrow(dir:Vector2=Vector2.ZERO) -> void: # dir is to rotate if fail
	var ar = $vb/hb.get_child(currentIdx)
	
	var animDuration : float = 0.12
	
	var t = ar.create_tween()
	var pos = ar.rect_position
	t.tween_property(ar,"rect_position",pos+Vector2(0,24),animDuration).set_ease(Tween.EASE_IN)
	t.tween_property(ar,"rect_position",pos,animDuration).set_ease(Tween.EASE_OUT)
	t.parallel().tween_property(ar,"modulate",DoneColor if !dir else BadColor,animDuration).set_ease(Tween.EASE_OUT)
	
	currentIdx += 1
	
	
	if dir: # fail
		$losep.play()
		fails-=1
		var ft = livesBar.create_tween()
		var ft2 = livesBar.create_tween()
		ft.tween_property(livesBar,"value",fails,animDuration*2)
		ft2.set_ease(Tween.EASE_IN).tween_property(livesBar,"modulate",Color(2,2,2,1),animDuration*0.5)
		ft2.set_ease(Tween.EASE_OUT).tween_property(livesBar,"modulate",Color.white,animDuration*0.75)
		
		t.parallel().tween_property(ar.get_child(0),"rect_rotation",rad2deg(dir.angle()),animDuration).set_ease(Tween.EASE_OUT)
	else:
		$winp.play()
		
	
	var failed = fails<1
	
	if arrows.size()<=currentIdx or failed:
		if !failed:
			var scoret = create_tween()
			scoret.tween_method(self,"setScore",score,score+lootMultIncrease,animDuration*2).set_ease(Tween.EASE_IN_OUT)
		
		var nv = min(timeLimit,$Timer.time_left + extraTimePerSet)
		$Timer.stop()
		var tt = $vb/bar/ProgressBar.create_tween()
		tt.tween_property($vb/bar/ProgressBar,"value",nv, animDuration*2)
		
		
		yield(t,"finished")
		
		
		for node in $vb/hb.get_children():
			var c = node.modulate
			c.a=0
			var at : SceneTreeTween = node.create_tween()
			at.tween_property(node,"rect_position",node.rect_position-Vector2(0,24),animDuration)
			at.parallel().tween_property(node,"modulate",c,animDuration)
#		yield(t2,"finished")
		yield(get_tree().create_timer(animDuration*2),"timeout")
		
		currentIdx = 0
		if failed:
			clearSet()
			if currentSet==1:
				endCriticalFail()
			else:
				end()
		else:
			newSet()

func isValidEvent(event) -> String: # also returns action
	for vac in validActions:
		if event.is_action(vac):
			return vac
	return ""

func end():
	$Timer.stop()
	clearSet()
	yield(get_tree().create_timer(0.5),"timeout")
	var res = MinigameResult.new()
	res.score = score
	res.failedHard = score==0
	$end.show()
	$end/hb/vb/scorel.text = "You stole with " + str(score) + "% efficiency"
	yield($end/hb/vb/endb,"pressed")
	
	emit_signal("finished",res)

func endCriticalFail():
	score = 0
	end()



func _on_Timer_timeout():
	end()
