extends LootList

func _init():
	handlesIds = ["roguelikeLoot"]

func getLoot(_id, _characterID, _battleName):
	var floorNumber = int(GM.main.getModuleFlag("MDCC", "RoguelikeFloor", 0))
	
	var chance = RNG.chance( (floorNumber/10) * (1 + int(floorNumber>20)) ) # every 10 floors = 1% or 2% if floor>20, snapped (only multiples of 10 count, integer division)
	
	
	if !(is_instance_valid(GM.pc) && chance): # both chance and pc have to be valid/true
		return [] # abort if pc invalid or chance doesn't hit
	
	var mdcc = GlobalRegistry.getModule("MDCC")
	var uniquePlants = mdcc.getSubmodule("UniquePlants")
	
	if uniquePlants.getMaxCanFindUnique("teleport root", 1): # this source can give 1 max root, if can find, do
		uniquePlants.increaseFoundUnique("teleport root", 1) # find
		
		return [
			[100, [ ["MDCC_Seed:teleport root", 1] ] ], # return actual data for it; to be handled by our loottable
		]
	
	return []
