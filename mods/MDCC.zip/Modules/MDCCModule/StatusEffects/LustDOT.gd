extends StatusEffectBase

var amount : float = 1.0

func _init():
	id = "MDCC_LustDOT"
	isBattleOnly = true
	
func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 3
	
	if _args.size()>1:
		amount = _args[1]
	
func processBattleTurn():
	var fam : int = int(amount)
	
	fam += int(RNG.chance((amount-fam)*100))
	
	character.addLust(fam)
	
	turns -= 1
	if(turns <= 0):
		stop()
	
func processTime(_secondsPassed: int):
	pass

func getEffectName():
	return "Horny Thoughts"

func getEffectDesc():
	return "I'm losing %s health a turn. %s more turns" % [amount, turns]

func getEffectImage():
	return "res://Images/StatusEffects/bleeding-wound.png"

func getIconColor():
	return IconColorPurple

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)
	else:
		turns = max(3, turns)
	
	if _args.size()>1:
		amount = (amount + _args[1]) * 0.5

func saveData():
	return {
		"turns": turns,
		"amount": amount,
	}
	
func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 3)
	amount = SAVE.loadVar(_data, "amount", 1)
