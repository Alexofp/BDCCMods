extends "res://Modules/MDCCModule/Submodules/submoduleBase.gd"

var plants : Array
var plots : Array

var maxPlots : int = 3

class Plant:
	var id : String
	var name : String = "Unknown"
	var desc : String
	var growthTime : int = 1
	var rarity : int = 1
	var maxNeglect : int = 1
	var maxHarvests : int = 1
	var harvestInterval : int = 1
	
	var items : Array = []
	var ings : Array = []
	
	var pricePerDay : int = 1
	var plantable : bool = true

class Plot:
	var id : String
	var plantID : String = ""
	var neglect : int = 0
	var currentHarvestCooldown : int = 0
	var harvestsDone : int = 0
	
	var grownDays : int = 0
	
	var watered : bool = false
	var yeen : bool = false
	
	func hasPlant() -> bool:
		return plantID!=""
	
	func saveData() -> Dictionary:
		var d : Dictionary = {
			"id": id,
			"plant": plantID,
			"neglect": neglect,
			"harvestCD": currentHarvestCooldown,
			"harvestsDone": harvestsDone,
			"days": grownDays,
			"watered": watered,
			"yeen": yeen,
		}
		
		return d
	
	func loadData(d:Dictionary) -> void:
		id = SAVE.loadVar(d, "id", "")
		plantID = SAVE.loadVar(d, "plant", "")
		neglect = int(SAVE.loadVar(d, "neglect", 0))
		currentHarvestCooldown = int(SAVE.loadVar(d, "harvestCD", 0))
		harvestsDone = int(SAVE.loadVar(d, "harvestsDone", 0))
		grownDays = int(SAVE.loadVar(d, "days", 0))
		watered = bool(SAVE.loadVar(d, "watered", false))
		yeen = bool(SAVE.loadVar(d, "yeen", false))
		
	

func onNewDay() -> void: # process plants on new day
	for plot in plots: # process each plot
		if !plot.plantID:
			continue
		
		var plant : Plant = getPlant(plot.plantID) # get plant obj
		if !plant: # no plant, invalid plot
			continue # skip
		
		if plant.growthTime <= plot.grownDays: # grown
			if plot.currentHarvestCooldown>0: # if cooldown exists, decrease it
				plot.currentHarvestCooldown -= 1
			
			continue # skip
		
		
		if plot.watered: # grow
			plot.grownDays += 1
		else: # deteriorate
			plot.neglect += 1
		
		plot.watered = plot.yeen # yeen
	
	

func dict2plant(id:String, d:Dictionary, defaults:Dictionary={}) -> Plant:
	var p : Plant = Plant.new()
	
	if !defaults:
		defaults = getPlantDataDefaults()
	
	p.id = id
	p.growthTime = int(d.get("growthTime", defaults["growthTime"]))
	p.name = str(d.get("name", defaults["name"]))
	p.maxNeglect = int(d.get("maxUnwateredLifespan", defaults["maxUnwateredLifespan"]))
	p.maxHarvests = int(d.get("maxHarvests", defaults["maxHarvests"]))
	p.harvestInterval = int(d.get("harvestingCooldown", defaults["harvestingCooldown"]))
	p.rarity = int(d.get("rarity", defaults["rarity"]))
	p.pricePerDay = int(d.get("pricePerDay", defaults["pricePerDay"]))
	p.desc = str(d.get("description", defaults["description"]))
	p.plantable = bool(d.get("plantable", defaults["plantable"]))
	
	return p

func getPlantDataDefaults() -> Dictionary:
	return {
		"name":"unknown",
		"growthTime":100,
		"resultingIngredients": [], # array of [ ingredientID, amount ]
		"resultingItems": [], # array of [ itemID, amount ]
		"maxUnwateredLifespan":30, # days, after which it'll die
		"maxHarvests":1,
		"harvestingCooldown":1,
		"rarity":1, # affects price & loot rates
		"pricePerDay":1, # in credits, can be float but will be rounded down
		"description":"[you should never see this]",
		"plantable": true,
	}

func sort_ids(a, b) -> bool:
	if a is Plot or a is Plant:
		a = a.id
	if b is Plot or b is Plant:
		b = b.id
	
	return a < b

func getPlots() -> Array:
	return plots

func getPlants() -> Array:
	return plants

func getNewEntryIdx(id:String, dar:Array=getPlots()) -> int:
	return dar.bsearch_custom(id, self, "sort_ids")

func getThingIdx(id:String, dar:Array=getPlots()) -> int:
	var idx : int = getNewEntryIdx(id, dar)
	if idx >= dar.size():
		return -1
	
	return idx if dar[idx].id == id else -1

func getPlot(id:String) -> Plot:
	var dar : Array = getPlots()
	var idx : int = getThingIdx(id, dar)
	return null if idx==-1 else dar[idx]

func getPlant(id:String) -> Plant:
	var dar : Array = getPlants()
	var idx : int = getThingIdx(id, dar)
	return null if idx==-1 else dar[idx]

func addPlot(entry:Plot, dar:Array=getPlots()) -> void:
	var idx : int = getNewEntryIdx(entry.id, dar)
	if idx>=dar.size() or dar[idx].id != entry.id:
		dar.insert(idx, entry)
		return
	dar[idx] = entry
	

func addPlant(entry:Plant, dar:Array=getPlants()) -> void:
	var idx : int = getNewEntryIdx(entry.id, dar)
	if idx>=dar.size() or dar[idx].id != entry.id:
		dar.insert(idx, entry)
		return
	dar[idx] = entry

func removePlot(id:String, dar:Array=getPlots()) -> void:
	var idx : int = getThingIdx(id, dar)
	if idx!=-1:
		dar.remove(idx)

func sort(ar:Array) -> void:
	ar.sort_custom(self, "sort_ids")

func saveData() -> Dictionary:
	var d : Dictionary = {
		"plots": [],
		"maxPlots": maxPlots,
	}
	
	for plot in getPlots():
		d["plots"].append(plot.saveData())
	
	return d

func loadData(d:Dictionary) -> void:
	maxPlots = SAVE.loadVar(d, "maxPlots", 3)
	
	for plotdict in SAVE.loadVar(d, "plots", []):
		var np : Plot = Plot.new()
		np.loadData(plotdict)
		plots.append(np)
	
	sort(plots)

func populatePlants() -> void:
	plants.clear()
	
	var ds : Dictionary = getPlantDataDefaults()
	for module in GlobalRegistry.getModules():
		if !GlobalRegistry.modules[module].has_method("getAddedPlants"):
			continue
		var nplants = GlobalRegistry.modules[module].getAddedPlants()
		for plantID in nplants:
			var np : Plant = dict2plant(plantID, nplants[plantID], ds)
			addPlant(np, plants)
		
	
	

func canHarvestPlot(plot:Plot) -> bool:
	if !plot.plantID:
		return false
	
	if plot.currentHarvestCooldown>0:
		return false
	
	var plant : Plant = getPlant(plot.plantID)
	
	if plant==null or plot.harvestsDone > plant.maxHarvests:
		return false
	
	return true

func isPlotDead(plot:Plot) -> bool:
	if !plot.plantID:
		return false
	
	var plant : Plant = getPlant(plot.plantID)
	if plant && plant.maxNeglect > plot.neglect:
		return false
	
	return true

static func getPlantRarityName(rarity:int=0) -> String:
	var strings = [ # can have as many as needed, rarity starts at 1 and ends whenever, these ones are in order of ascending rarity
		"Unique", # rarity 0, which can only spawn once
		"Abundant",
		"Uncommon",
		"Rare",
	]
	if rarity>=0 && rarity<strings.size():
		return strings[rarity]
	
	return "Unknown (%s)" % rarity
