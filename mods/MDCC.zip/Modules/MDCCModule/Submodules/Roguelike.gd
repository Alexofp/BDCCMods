extends "res://Modules/MDCCModule/Submodules/submoduleBase.gd"

const SeedLength : int = 32

const SeedKey : String = "seed"
const RoomsKey : String = "rooms"
const RunItemsKey : String = "currentRunItems"

var darkness : int = 0

class RoomEntry:
	var roomID : String
	var data : Dictionary = {}
	
	func getDataKey(key):
		return data.get(key, null)
	
	func saveData() -> Dictionary:
		return {
			"id":roomID, "data":data
		}
	
	func loadData(d:Dictionary) -> void:
		roomID = SAVE.loadVar(d, "id", "")
		if roomID:
			data = SAVE.loadVar(d, "data", {})
		else:
			data.clear()

func sort_rooms(a, b) -> bool:
	if a is RoomEntry:
		a = a.roomID
	if b is RoomEntry:
		b = b.roomID
	
	return a < b

func getAllWorldTypes() -> Dictionary: # this one merges events as well, from multiple modules
	var res = {}
	for mod in GlobalRegistry.getModules().values():
		if !mod.has_method("getAddedWorldTypes"):
			continue
		
		var modwtypes = mod.getAddedWorldTypes()
		res.merge(modwtypes, true)
	
	return res

func newRoguelikeEntry() -> void: # upon descending/entering
	var extender = GlobalRegistry.getGameExtender("MDCC_RoguelikeEnemyExtender")
	if extender:
		extender.clearEnemies()
		extender.createEnemies()

func onEnter() -> bool: # returns true if successful
	var flobj = GM.world.floorDict.get("RoguelikeFloor")
	if flobj:
		flobj = flobj.get_child(0)
		if !data.get(SeedKey, ""):
			data[SeedKey] = generateSeed()
		
		if !GM.pc.is_connected("location_changed", flobj, "onPcLocChanged"):
			GM.pc.connect("location_changed", flobj, "onPcLocChanged")
		flobj.clearWorld()
		
		flobj.createWorld(data[SeedKey])
		
		var ext = GlobalRegistry.getGameExtender("MDCC_RoguelikeEnemyExtender")
		if ext:
			for enemy in ext.enemies:
				enemy.createIcon(ext)
		
		return true
	
	return false

func generateSeed():
	var ls = "1234567890qwertyuiopasdfghjklzxcvbnm"
	var lsl = ls.length()
	var res := ""
	for i in SeedLength:
		var c = ls[randi() % lsl]
		if RNG.chance(50):
			c = c.to_upper()
		res += c
	
	var allWorldTypes = getAllWorldTypes()
	
	
	var pairs := [] # key, weight
	for wtype in allWorldTypes:
		if !RNG.chance(allWorldTypes[wtype].get("spawnChance", 100)): # didn't spawn, skip
			continue
		pairs.append([wtype, allWorldTypes[wtype].get("weight", 1.0) ])
	
	var chosenWorldtype = RNG.pickWeightedPairs(pairs)
	res += ":"+chosenWorldtype
	
	return res
	

func clear() -> void:
	data[RoomsKey] = []

func destroyWorld() -> void:
	data.clear()
	var ext = GlobalRegistry.getGameExtender("MDCC_RoguelikeEnemyExtender")
	if ext:
		ext.clearEnemies()

func getNewIdxForRoomID(id:String, dar:Array) -> int:
	return dar.bsearch_custom(id, self, "sort_rooms")

func getIdxForRoomID(id:String, dar:Array) -> int:
	var idx : int = getNewIdxForRoomID(id, dar)
	
	if idx>=dar.size():
		return -1
	
	return idx if dar[idx].roomID==id else -1

func getEntryForRoomID(roomID:String) -> RoomEntry: # returns entry or null
	var dar : Array = getRooms()
	var idx : int = getIdxForRoomID(roomID, dar)
	
	return null if idx==-1 else dar[idx]

func getDataKeyForEntry(roomID:String, key:String, default=null):
	var entry : RoomEntry = getEntryForRoomID(roomID)
	return entry.data.get(key, default) if entry else default

func addRunItem(uuid, amount:int) -> void:
	var items = data.get_or_add(RunItemsKey, [])
	for item in items:
		if item[0]==uuid:
			item[1] += amount
			return
	items.append([uuid, amount])

func removeEntryID(id:String) -> void:
	var dar : Array = getRooms()
	var idx : int = getIdxForRoomID(id, dar)
	if idx!=-1:
		dar.remove(idx)
	

func getRoguelikeData() -> Dictionary:
	return data

func getRooms() -> Array: # returns array of entries
	return data.get(RoomsKey, [])

func addEntryDirect(entry:RoomEntry) -> void:
	# replaces if already exists
	var d := getRooms()
	var idx : int = getNewIdxForRoomID(entry.roomID, d)
	
	if idx>=d.size() or d[idx].roomID!=entry.roomID:
		d.insert(idx, entry)
		return
	
	d[idx] = entry
	

func removeRunItems() -> void:
	var runits = data.get(RunItemsKey, [])
	
	for itar in runits:
		var uid = itar[0]
		var it = GM.pc.getInventory().getItemByUniqueID(uid)
		if !it:
			continue
		
		if it.isImportant():
			continue
		
		var oldAmount = it.getAmount()
		var amountLost = int( max(1, int(itar[1])*0.5 ) )
		
		# below for display purposes
		it.amount = amountLost
		GM.main.addMessage("You were robbed of %s" % it.getAStackName())
		it.amount = oldAmount
		
		it.removeXOrDestroy(amountLost)

func doDie() -> void:
	for scene in GM.main.sceneStack:
		if scene.sceneID=="MDCC_RoguelikeEventWrapper":
			scene.endScene()
	GM.pc.setLocation(GM.pc.getCellLocation())
	GM.main.startNewDay()
	GM.main.addMessage("You wake up in your cell...")
	GM.pc.afterSleepingInBed()
	var robbedValue = RNG.randi_range(int(GM.pc.getCredits()*0.5),GM.pc.getCredits())
	GM.pc.addCredits(-robbedValue)
	GM.main.addMessage("You were robbed of %s credits" % robbedValue)
	
	removeRunItems()
	

func saveData() -> Dictionary:
	var d : Dictionary = {
		SeedKey:data.get(SeedKey, ""),
		RunItemsKey:data.get(RunItemsKey, []),
		"darkness": darkness,
	}
	
	d[RoomsKey] = []
	for entry in getRooms():
		d[RoomsKey].append(entry.saveData())
	
	return d

func loadData(d:Dictionary) -> void:
	data.clear()
	data[SeedKey] = SAVE.loadVar(d, SeedKey, "")
	data[RunItemsKey] = SAVE.loadVar(d, RunItemsKey, [])
	darkness = int(SAVE.loadVar(d, "darkness", 0))
	
	data[RoomsKey] = []
	for entryDict in SAVE.loadVar(d, RoomsKey, []):
		var entry := RoomEntry.new()
		entry.loadData(entryDict)
		data[RoomsKey].append(entry)
	
	data[RoomsKey].sort_custom(self, "sort_rooms")
	

