extends Reference

var modID : String = "MDCC"

var data : Dictionary = {}

func saveData() -> Dictionary:
	return data

func loadData(d:Dictionary) -> void:
	data = d
