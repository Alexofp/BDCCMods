extends "res://Modules/MDCCModule/Submodules/submoduleBase.gd"

class UniqueEntry:
	var id : String
	var found : int
	

const UniquesKey : String = "uniques"

func sort_uniques(a, b) -> bool:
	if a is UniqueEntry:
		a = a.id
	
	if b is UniqueEntry:
		b = b.id
	
	return a < b

func getEntryNewIdx(plantid:String, dar:Array=getAllUniqueEntries()) -> int:
	return dar.bsearch_custom(plantid, self, "sort_uniques")

func getEntryIdxWithId(plantid:String, dar:Array=getAllUniqueEntries()) -> int:
	var idx = getEntryNewIdx(plantid, dar)
	if idx >= dar.size():
		return -1
	
	return dar[idx] if dar[idx].id == plantid else -1

func getUniqueEntry(plantid:String, dar:Array=getAllUniqueEntries()) -> UniqueEntry: # returns string
	var idx = getEntryIdxWithId(plantid, dar)
	return null if idx==-1 else dar[idx]

func increaseFoundUnique(plantid:String, amount:int=1) -> void:
	var entry = getUniqueEntry(plantid)
	
	if entry:
		entry.found += amount
		return
	
	entry = UniqueEntry.new()
	entry.id = plantid
	entry.found = amount
	
	addDirectEntry(entry)

func addDirectEntry(entry:UniqueEntry) -> void:
	var dar : Array = getAllUniqueEntries()
	var idx : int = getEntryNewIdx(entry.id, dar)
	if idx >= dar.size():
		dar.insert(idx, entry)
		return
	
	dar[idx] = entry

func getMaxCanFindUnique(plantid:String, maxv:int=1) -> int: # returns max amount you can find of a plant with the given id, based on the max amount provided
	var entry = getUniqueEntry(plantid)
	if !entry:
		return maxv
	
	return maxv-entry.found

func getAllUniqueEntries() -> Array: # array of string entries
	return data.get(UniquesKey, [])

func saveData() -> Dictionary:
	var d : Dictionary = { UniquesKey:[] }
	for entry in getAllUniqueEntries():
		d[UniquesKey].append([ entry.id, entry.found ])
	
	return d

func loadData(d:Dictionary) -> void:
	data.clear()
	data[UniquesKey] = []
	
	for arrayEntry in SAVE.loadVar(d, UniquesKey, []):
		if arrayEntry<2:
			continue
		var nentry := UniqueEntry.new()
		
		nentry.found = int(arrayEntry[1])
		nentry.id = arrayEntry[0]
		
		data[UniquesKey].append(nentry)
	
	data[UniquesKey].sort_custom(self, "sort_uniques")
	
