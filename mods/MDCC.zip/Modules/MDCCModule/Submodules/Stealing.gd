extends "res://Modules/MDCCModule/Submodules/submoduleBase.gd"

var wealthData : Dictionary = {
	"poor":{
		"credCap":5,
		"itemMult":100,
		"initRolls":1,
		"extraRolls":false,
		"text":"{vic.HeShe} {vic.verb('look')} like {vic.theyre} struggling."
	},
	"med":{
		"credCap":15,
		"itemMult":100,
		"initRolls":1,
		"extraRolls":true,
		"text":"{vic.HeShe} {vic.verb('look')} pretty well-off."
	},
	"rich":{
		"credCap":25,
		"itemMult":100,
		"initRolls":2,
		"extraRolls":false,
		"text":"{vic.Their} pockets look loaded."
	},
}

var wealthSizeIndividual : int = 3

const TimesStolenKey : String = "timesStolen"
const NpcsKey : String = "npcs"

const MaxDaysBeforeDeleteData : int = 4

func sort_npcs(a, b) -> bool:
	if a is NpcStealingEntry:
		a = a.npcID
	if b is NpcStealingEntry:
		b = b.npcID
	
	return a < b


class NpcStealingEntry:
	var npcID : String
	var wealth : int = -1
	var stolenToday : bool
	var daysSinceStolen : int
	var stealAgainTime : int
	
	func saveData() -> Dictionary:
		return {
			"id": npcID,
			"wealth": wealth,
			"stolenToday": stolenToday,
			"daysStolen": daysSinceStolen,
			"stealAgainTime": stealAgainTime,
		}
	
	func loadData(data:Dictionary) -> void:
		npcID = SAVE.loadVar(data, "id", "")
		wealth = int(SAVE.loadVar(data, "wealth", 0))
		stolenToday = bool(SAVE.loadVar(data, "stolenToday", false))
		stealAgainTime = int(SAVE.loadVar(data, "stealAgainTime", 0))
		if !npcID:
			daysSinceStolen = 1000
		else:
			daysSinceStolen = int(SAVE.loadVar(data, "daysStolen", 1000))
		
	
	

func onStealingNewDay() -> void: # process stealing when a day passes
	var npcData = [] # new entries as objects
	
	var entries : Array = getAllNpcEntries()
	
	for npcEntry in entries:
		if npcEntry.stolenToday: # stolen from
			npcEntry.daysSinceStolen = 0 # reset countdown
		else: # not stolen from
			npcEntry.daysSinceStolen += 1
			if npcEntry.daysSinceStolen > MaxDaysBeforeDeleteData: # too long since last time
				continue # don't even add entry
		
		
		if npcEntry.wealth == -1: # randomize wealth if needed
			npcEntry.wealth = RNG.randi_range(1, wealthSizeIndividual * wealthData.size())
		
		
		if npcEntry.wealth >= 11: # very rich
			npcEntry.wealth += 1 - (2*int(RNG.chance(75))) # -1 75% of the time
		elif npcEntry.wealth<=2: # very poor
			npcEntry.wealth -= 1 - (2*int(RNG.chance(75))) # +1 75% of the time
		else: # don't care tbh, middle ground-ish
			npcEntry.wealth += 1 - (2*int(RNG.chance(50))) # +1 50% of the time
		
		npcEntry.wealth = int(clamp(npcEntry.wealth, 1, wealthSizeIndividual * wealthData.size()))
		
		npcData.append(npcEntry) # create entry as object
	
	npcData.sort_custom(self, "sort_npcs")
	
	data[NpcsKey] = npcData
	

func getAllNpcEntries() -> Array:
	return data.get_or_add(NpcsKey, [])

func addEntryDirect(entry:NpcStealingEntry, dar:Array=getAllNpcEntries()):
	var idx = getNewIdxNpc(entry, dar)
	if idx<dar.size() && dar[idx].npcID == entry.npcID:
		dar[idx] = entry
		return
	
	dar.insert(idx, entry)

func addNpcStealingData(charid:String, stolenFrom:bool=false, wealth:int=-1, countdown:int=0) -> void: # replaces if already exists
	var entry : NpcStealingEntry = getEntryWithID(charid)
	if !entry:
		entry = NpcStealingEntry.new()
		entry.npcID = charid
	
	entry.stolenToday = stolenFrom
	entry.wealth = wealth
	entry.daysSinceStolen = countdown
	
	addEntryDirect(entry)

func increaseStolenTimes(amount:int=1) -> void:
	data[TimesStolenKey] = getTimesStolen() + amount

func getEntryWithID(id:String) -> NpcStealingEntry:
	var dar = getAllNpcEntries()
	var idx = getEntryIdxID(id, dar)
	
	return null if idx==-1 else dar[idx]

func getEntryIdxID(id:String, dar:Array=getAllNpcEntries()) -> int:
	var idx = getNewIdxNpc(id, dar)
	if dar.size()<=idx:
		return -1
	
	return idx if dar[idx].npcID == id else -1

func getNewIdxNpc(entry, ar:Array) -> int:
	return ar.bsearch_custom(entry, self, "sort_npcs")

func getNpcStealingData(charid:String) -> NpcStealingEntry:
	return getEntryWithID(charid)

func generateWealth(pawn:String) -> int:
	var wealth : int = hash(pawn+str(GM.main.currentDay)) % (wealthSizeIndividual * wealthData.size())
	
	return wealth

func applyWealthBuff(buff:int, npc:String) -> void:
	var entry : NpcStealingEntry = getEntryWithID(npc)
	if entry:
		entry.wealth = int( clamp(entry.wealth + buff, 0, wealthData.size() - 1) )
		return
	
	entry = NpcStealingEntry.new()
	
	var wealth : int = generateWealth(npc)
	wealth = int( clamp(wealth+buff, 0, wealthData.size()-1) )
	
	entry.wealth = wealth
	entry.stolenToday = false
	entry.daysSinceStolen = 0
	

func getTimesStolen() -> int:
	return data.get_or_add(TimesStolenKey, 0)

func onHitmanBountyDone(entry, hitman:Object) -> void:
	if entry.type == hitman.BountyTypes.STEAL:
		# 2 credits = 1 wealth class
		var debuff : int = -(entry.value/int(2))
		applyWealthBuff(debuff, entry.npcID)

func getWealthType(pawnWealth:int) -> String:
	return wealthData.keys()[pawnWealth / wealthData.size()]

func saveData() -> Dictionary:
	var d : Dictionary = { "npcs":[], "timesStolen": getTimesStolen() }
	for entry in getAllNpcEntries():
		d["npcs"].append(entry.saveData())
	return d

func loadData(d:Dictionary) -> void:
	data.clear()
	data[NpcsKey] = []
	data[TimesStolenKey] = int(SAVE.loadVar(d, "timesStolen", 0))
	
	for npcEntry in SAVE.loadVar(d, "npcs", []):
		var e := NpcStealingEntry.new()
		e.loadData(npcEntry)
		data[NpcsKey].append(e)
	
	data[NpcsKey].sort_custom(self, "sort_npcs")
	
