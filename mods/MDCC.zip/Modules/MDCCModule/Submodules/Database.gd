extends "res://Modules/MDCCModule/Submodules/submoduleBase.gd"

enum Vars { # ease of access, less memory usage (these are stored as ints)
	INMATE_ID, NAME, SPECIES, GENDER, ANATOMY, AGE, HEIGHT, WEIGHT, DESCRIPTION,
	ORIGIN, INMATE_TYPE, CRIMES, DETAINMENT_PROCS, CHARID, MODULE_ID, FLAG_ID,
	}

var popMethod : String = "getInmateProfiles"

var inmateIdPrefix : String = "P-"

var identifyingVar : int = Vars.INMATE_ID
var secondaryIdentifiableVar : int = Vars.NAME

var missingText : String = "[color=gray](unknown)[/color]"

const DiscoveredKey : String = "discovered"
const SecondariesKey : String = "secondaries"
const ProfilesKey : String = "profiles"


func getProfiles() -> Array:
	return data.get_or_add(ProfilesKey, [])

func getSecondaryIdxs() -> Array:
	return data.get_or_add(SecondariesKey, [])

func clear() -> void:
	for key in [ProfilesKey, SecondariesKey]:
		data[key] = []

func popAllProfiles(extras:Array=[]) -> void:
	clear()
	var inmatesProfiles = getProfiles()
	
	inmatesProfiles.append_array(extras)
	
	inmatesProfiles.append_array(getEveryInmateProfile())
	
	inmatesProfiles.sort_custom(self, "sort_ascending_profile")
	
	var inmateSecondaryIndexes = getSecondaryIdxs()
	inmateSecondaryIndexes = range(inmatesProfiles.size())
	inmateSecondaryIndexes.sort_custom(self, "sortIdxsBasedOnSecondary")


func generatePlayerProfile() -> Array:
	var anatomyText : String = "Intersex (asexual)"
	
	var hasDick : bool = GM.pc.hasPenis()
	var hasVagina : bool = GM.pc.hasVagina()
	
	if hasDick && hasVagina:
		anatomyText = "Hermaphrodite"
	elif hasDick:
		anatomyText = "Male"
	elif hasVagina:
		anatomyText = "Female"
	
	if GM.pc.hasAnus():
		if GM.pc.getBodypart(BodypartSlot.Anus).hasWomb():
			anatomyText += " (anally fertile)"
	
	var texts : Dictionary = {
		Flag.Crime_Type.Innocent:"Innocent",
		Flag.Crime_Type.Murder:"Murderer",
		Flag.Crime_Type.Prostitution:"Prostitute",
		Flag.Crime_Type.Theft:"Thief",
	}
	
	var playerCrimeString : String = texts.get(GM.main.getFlag("Player_Crime_Type"), missingText)
	
	return dict2prof({ # auto-generate player profile
			"name": GM.pc.getName(),
			"charid": "pc",
			"inmate id": str(GM.pc.getInmateNumber()),
			"inmate type": "%s (%s designation)" % [GM.pc.getInmateTypeString().capitalize(), GM.pc.getInmateColorString().capitalize()],
			"gender": "%s (%s)" % [Gender.genderToString(GM.pc.getGender()).capitalize(), Gender.genderToPronouns(GM.pc.getPronounGender())],
#			"age": "Unknown",
			"crimes": playerCrimeString,
#			"origin": "Unknown",
#			"height": "Unknown",
#			"weight": "Unknown",
			"species": GM.pc.getSpeciesFullName(),
#			"description": "Unknown",
			"detainment procs": "None",
			"module id": "",
			"flag id": "", # make player's profile accessible by default, as handled by shouldDisplayProfile()
			"anatomy": anatomyText,
			})



func getDiscoveredChars() -> Array:
	return data.get_or_add(DiscoveredKey, [])

func discoverChars(chars:Array): # array of charids
	var entries = getDiscoveredChars()
	
	for chid in chars:
		var idx : int = getDiscoveredEntryIdx(chid, entries)
		if idx>=entries.size() or entries[idx]!=chid:
			entries.insert(idx, chid)
	

func getDiscoveredEntryNewIdx(id:String, dar:Array=getDiscoveredChars()) -> int:
	return dar.bsearch_custom(id, self, "sort_ascending_charid")

func getDiscoveredEntryIdx(id:String, dar:Array=getDiscoveredChars()) -> int:
	var idx : int = getDiscoveredEntryNewIdx(id, dar)
	if idx>=dar.size() or dar[idx]!=id:
		return -1
	return idx

func getEntryIdx(id:String, dar:Array=getProfiles()) -> int:
	var idx : int = getEntryNewIdx(id, dar)
	if idx>=dar.size() or dar[idx][Vars.CHARID]!=id:
		return -1
	return idx

func getEntryNewIdx(id:String, dar:Array=getProfiles()) -> int:
	return dar.bsearch_custom(id, self, "sort_ascending_charid")

func getDiscoveredEntry(chid:String, dar:Array=getProfiles()) -> String:
	var idx : int = getDiscoveredEntryIdx(chid, dar)
	return "" if idx==-1 else dar[idx]


func getEveryInmateProfile() -> Array: # excludes pc
	var profs = []
	for mod in GlobalRegistry.getModules().values(): # get every new character
		profs.append_array(getInmateProfilesForMod(mod))
	return profs

func dict2prof(prof:Dictionary) -> Array: # takes in a dictionary and converts it to our own profile format
	var newp = [] # new profile here
	
	for vari in Vars.size():
		var key = Vars.keys()[vari].capitalize().to_lower() # convert a Var from our enum to a usable string. since capitalize returns a string, we can chain the string functions like that
		var value = prof.get(key, missingText) # we should never have unknown, but we can't be dependent on the datapack/mod to do it right, especially after an update that changes the Vars enum
		newp.append(value) # can add the above command directly, but this way we can process/edit values if need be
	
	
	return newp


func getInmateProfilesForMod(mod:Module) -> Array:
	if !mod.has_method(popMethod): # all other modules that add profiles must return them from here, preferably as an Array of Arrays of Strings
		return []
	
	var newProfiles = mod.call(popMethod)
	if typeof(newProfiles)==TYPE_ARRAY: # bit of a validity check
		if newProfiles.size()==0: # can't process empty arrays, to avoid crashing, we'll ignore this mod
			return []
		if typeof(newProfiles[0])==TYPE_ARRAY: # they returned an array of arrays, so we append all its elements
			return newProfiles
		
		elif typeof(newProfiles[0])==TYPE_DICTIONARY: # they sent an array of dicts, we'll convert and append
			var res = []
			for dict in newProfiles:
				var newp = dict2prof(dict)
				res.append(newp)
			return res
		
		else: # it's probably a singular profile, for some reason. return it by itself
			return [newProfiles]
	elif typeof(newProfiles)==TYPE_DICTIONARY: # this whole thing fucking sucks, but it'll work. they sent a singular dictionary, which is weird, but we'll convert and append it anyway
		var newp = dict2prof(newProfiles)
		return [newp]
	
	return [] # who knows


func getProfileVar(profile:Array, variable:int, accessLevel:int) -> String:
	if profile.size() <= variable:
		return missingText
	
	var v = profile[variable]
	if typeof(v) == TYPE_ARRAY:
		if v.empty():
			return missingText
		
		return v[int(min(accessLevel, v.size()-1))]
	
	return v

func accessLevelString(accessLevel:int=0) -> String:
	var accessNames = [
		"General Staff", "Administrator"
	]
	
	return accessNames[accessLevel] if accessLevel<accessNames.size() else "Access %s" % accessLevel
	

func sanitize(input:String) -> String: # clean up user input
	return input.strip_edges().to_lower()

############### sorting
func sort_ascending_profile(a:Array, b:Array) -> bool: # expects proper profiles
	var av = sanitize(getProfileVar(a, identifyingVar, 0))
	var bv = sanitize(getProfileVar(b, identifyingVar, 0))
	return av < bv

func sort_ascending_charid(a, b) -> bool: # same as above, but we can mix and match ids and arrays
	if a is Array: # convert if need be, so we can compare
		a = sanitize(getProfileVar(a, identifyingVar, 0))
	if b is Array:
		b = sanitize(getProfileVar(b, identifyingVar, 0))
	
	return a < b


func getProfileIdx(charid:String, dar:Array=getProfiles()) -> int: # returns either the index of our profile, or where it'd be inserted
	return dar.bsearch_custom(charid, self, "sort_ascending_charid")

func getProfile(charid:String, dar:Array=getProfiles()) -> Array:
	var idx = getProfileIdxStrict(charid, dar)
	
	return [] if idx==-1 else dar[idx]

func getProfileIdxStrict(charid:String, dar:Array=getProfiles()) -> int: # returns idx of profile or -1
	var idx = dar.bsearch_custom(charid, self, "sort_ascending_charid")
	if dar.size()<=idx: # if we're outta bounds
		return -1
	if sanitize(getProfileVar(dar[idx], identifyingVar, 0)) != charid: # it was gonna return insertion idx instead
		return -1
	return idx

func sortIdxsBasedOnSecondary(a, b) -> bool:
	var dar : Array = getProfiles()
	if a is int:
		a = sanitize(getProfileVar(dar[a], secondaryIdentifiableVar, 0))
	if b is int:
		b = sanitize(getProfileVar(dar[b], secondaryIdentifiableVar, 0))
	return a<b

func getProfileIdxBasedOnSecondary(secondaryValue:String) -> int: # returns index of the index of profile, or where it'd be inserted
	return getSecondaryIdxs().bsearch_custom(secondaryValue, self, "sortIdxsBasedOnSecondary")

func getProfileIdxBasedOnSecondaryStrict(secondaryValue:String) -> int: # returns idx of profile or -1
	var idx = getProfileIdxBasedOnSecondary(secondaryValue)
	var dar : Array = getSecondaryIdxs()
	if dar.size() <= idx: # if we're outta bounds
		return -1
		
	if sanitize( getProfileVar(getProfiles()[dar[idx]], secondaryIdentifiableVar, 0) ) != secondaryValue: # it was gonna return insertion idx instead
		return -1
	return dar[idx]

func saveData() -> Dictionary:
	return {
		DiscoveredKey: getDiscoveredChars()
	}

func loadData(d:Dictionary) -> void:
	data[DiscoveredKey] = SAVE.loadVar(d, DiscoveredKey, [])
