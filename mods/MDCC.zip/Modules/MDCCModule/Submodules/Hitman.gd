extends "res://Modules/MDCCModule/Submodules/submoduleBase.gd"

const BountiesKey : String = "bounties"

const LocationBountiesKey : String = "locational_bounties"

enum BountyTypes {
	BEAT_UP,
	INDOCTRINATE,
	STEAL,
	
	TOTAL_SIZE
}

const IndoctrinatedKey : String = "indoctrinated_chars" # character ids

signal bountyCompleted

var indGenerator : CharacterGeneratorBase = load("res://Modules/MDCCModule/Gameplay/indoctrinatedGenerator.gd").new()

func sort_bounties(a, b) -> bool:
	if a is Bounty:
		a = a.npcID
	if b is Bounty:
		b = b.npcID
	
	return a < b

func sort_locations(a, b) -> bool:
	if a is Array:
		a = a[0].location if a else ""
	if b is Array:
		b = b[0].location if b else ""
	
	return a < b

class Bounty:
	var npcID : String
	var completed : bool = false
	var type : int = 0
	var value : int = 0
	var location : String = ""
	
	var daysToDie : int = 2
	var active : bool = false
	
	var extraData : Dictionary = {}
	
	func saveData() -> Dictionary:
		var d = {
			"npc":npcID,
			"completed":completed,
			"type":type,
			"value":value,
			"days":daysToDie,
			"active":active,
		}
		
		if location:
			d["location"] = location
		if extraData:
			d["extraData"] = extraData
		
		return d
	
	func loadData(d:Dictionary) -> void:
		npcID = SAVE.loadVar(d, "npc", "")
		if !npcID:
			value = 0
			type = 0
			completed = true
			return
		completed = bool(SAVE.loadVar(d, "completed", false))
		value = int(SAVE.loadVar(d, "value", 0))
		type = int(SAVE.loadVar(d, "type", 0))
		location = d.get("location", "")
		extraData = d.get("extraData", {})
		active = bool(SAVE.loadVar(d, "active", false))
		daysToDie = int(SAVE.loadVar(d, "days", 0))

func genIndoctrinatedId(i:int) -> String:
	return "MDCC_Indoctrinated"+str(i).pad_zeros(2)

func onNewDay() -> void:
	var new : Array = []
	var deltarep : float = 0.0
	for key in [BountiesKey]:
		data[key] = []
	
	for b in getEntries():
# warning-ignore:unsafe_cast
		b = b as Bounty
		if !b.active or b.completed:
#			if b.npcID in data.get(IndoctrinatedKey, []):
#				GM.main.removeDynamicCharacter(b.npcID)
			continue
		
		b.daysToDie -= 1
		if b.daysToDie<=0:
			deltarep -= b.value*0.1
#			if b.npcID in data.get(IndoctrinatedKey, []):
#				GM.main.removeDynamicCharacter(b.npcID)
			continue
		
		new.append(b)
		
	
	data[IndoctrinatedKey] = []
	for i in 3:
		var ind : Bounty = Bounty.new()
		var ch = makeIndoctrinatedNPC(i, ind)
		ind.npcID = ch.getID()
#		GM.main.addDynamicCharacter(ch)
		ind.daysToDie = 1
		ind.value = 10
		ind.type = BountyTypes.INDOCTRINATE
		
		ind.location = getIndoctrinateLocation()
		new.append(ind)
		data[IndoctrinatedKey].append(ind.npcID)
		addBountyLocation(ind)
	
	new.sort_custom(self, "sort_bounties")
	
	data[BountiesKey] = new
	
	
	GM.pc.reputation.addRep("MDCC_MafiaRep", deltarep)

func makeIndoctrinatedNPC(i:int, entry:Bounty) -> DynamicCharacter:
	var npc : DynamicCharacter = indGenerator.generate({
		index=i,
		"MDCC_bounty":entry,
		})
	return npc

func adjustIndoctrinateLevel(npc:DynamicCharacter, deadjust:bool=false) -> void:
	var entry : Bounty = getNpcEntry(npc.getID())
	if !entry or entry.type != BountyTypes.INDOCTRINATE:
		return
	
	var threat : int = entry.extraData.get("threat", 0)
	var lvl : int = getIndoctrinatedLevelDelta(threat)
	
	if deadjust:
		npc.getSkillsHolder().setLevel(npc.getLevel()-lvl)
	else:
		npc.getSkillsHolder().setLevel(GM.pc.getLevel()+lvl)
	
	if npc.getSkillsHolder().getFreeStatPoints()<0:
		autoSpendExcessStatPoints(npc)

func getIndoctrinatedLevelDelta(threat:int) -> int:
	return (1-threat)*10

func autoSpendExcessStatPoints(npc:BaseCharacter):
	var statWeightMap:Dictionary = {}
	for stat in Stat.getAll():
		var statValue:int = npc.skillsHolder.getStat(stat)
		
		var statWeight:float = max(1.0, 10.0 - sqrt(float(statValue)))
		statWeightMap[stat] = statWeight
	
	while(npc.skillsHolder.getFreeStatPoints() < 0):
		var stat = RNG.pickWeightedDict(statWeightMap)
		statWeightMap[stat] = max(1.0, 10.0 - sqrt(float(npc.skillsHolder.getStat(stat))))
		npc.skillsHolder.setStat(stat, npc.skillsHolder.getBaseStat(stat) - 1)

func getIndoctrinateLocation() -> String:
	return "MDCC_mafia1"

func getNewEntryIdx(id:String, dar:Array=getEntries()) -> int:
	return dar.bsearch_custom(id, self, "sort_bounties")

func getEntryIdx(id:String, dar:Array=getEntries()) -> int:
	var idx : int = getNewEntryIdx(id, dar)
	if idx >= dar.size():
		return -1
	
	return idx if dar[idx].npcID == id else -1

func jobText(btype:int) -> String:
	var s = {
		BountyTypes.BEAT_UP: "Intimidation",
		BountyTypes.STEAL: "Item Reclamation",
	}
	
	return s.get( btype, (BountyTypes.keys()[btype] if BountyTypes.size()>btype else "Job %s" % btype) )

func getNpcEntryIdx(id:String, dar:Array=getEntries()) -> int:
	return getEntryIdx(id, dar)

func getBountyLocationArray(location:String): # array or new idx
	var dar : Array = data.get_or_add(LocationBountiesKey, [])
	var idx : int = dar.bsearch_custom(location, self, "sort_locations")
	if idx >= dar.size():
		return idx
	
	if dar[idx][0].location != location:
		return idx
	
	return dar[idx]

func getBountyLocationArrayStrict(location:String) -> Array: # array or empty
	var ar = getBountyLocationArray(location)
	return ar if typeof(ar) == TYPE_ARRAY else []

func getOrAddBountyLocationArray(location:String) -> Array:
	var array = getBountyLocationArray(location)
	var bountiesWithLocations = data.get_or_add(LocationBountiesKey, [])
	if typeof(array) == TYPE_INT:
		bountiesWithLocations.insert(array, [])
		array = bountiesWithLocations[array]
	
	return array

func getNpcEntryLocation(location:String, id:String) -> Bounty:
	var array = getOrAddBountyLocationArray(location)
	
	var subidx : int = getEntryIdx(id, array)
	return null if subidx==-1 else array[subidx]


func removeBountyLocation(bounty:Bounty) -> void:
	if !bounty.location:
		return
	
	var array = getOrAddBountyLocationArray(bounty.location)
	
	var idx : int = getNewEntryIdx(bounty.npcID, array)
	if idx >= array.size():
		return
	
	array.remove(idx)

func addBountyLocation(bounty:Bounty) -> void:
	if !bounty.location:
		return
	
	var array = getOrAddBountyLocationArray(bounty.location)
	
	var idx : int = getNewEntryIdx(bounty.npcID, array)
	if idx >= array.size():
		array.insert(idx, bounty)
		return
	
	array[idx] = bounty

func getNpcEntry(id:String) -> Bounty:
	var dar : Array = getEntries()
	var idx : int = getEntryIdx(id, dar)
	return null if idx==-1 else dar[idx]

func addNpcEntry(id:String, done:bool=false, type:int=BountyTypes.BEAT_UP, value:int=10) -> void:
	var entry := Bounty.new()
	entry.npcID = id
	entry.value = value
	entry.type = type
	entry.completed = done
	
	addNpcEntryDirect(entry)

func addNpcEntryDirect(entry:Bounty, dar:Array=getEntries()) -> void:
	var idx : int = getNewEntryIdx(entry.npcID, dar)
	if idx>=dar.size() or dar[idx].npcID != entry.npcID:
		dar.insert(idx, entry)
		return
	dar[idx] = entry
	
	addBountyLocation(entry)
	

func removeNpc(id:String, dar:Array=getEntries()) -> void:
	var idx : int = getEntryIdx(id, dar)
	if idx!=-1:
		removeBountyLocation(dar[idx])
		dar.remove(idx)

func getEntries() -> Array: # array of objects
	return data.get_or_add(BountiesKey, [])

func getNpcs() -> Array: # character ids
	var ar : Array = []
	
	for entry in getEntries():
		ar.append(entry.npcID)
	
	return ar

func isBountyDoneID(id:String) -> bool:
	var entry := getNpcEntry(id)
	if entry:
		return entry.completed
	return false

func completeBountyFlagOnly(npc:String) -> void:
	var entry := getNpcEntry(npc)
	if entry:
		entry.completed = true

func completeBountyFull(npc:String) -> void:
	var dar := getEntries()
	var idx := getNpcEntryIdx(npc, dar)
	
	if idx==-1:
		return
	
	var value = dar[idx].value
	
	GM.main.addMessage("You completed {%s.nameS} bounty for %s %s" % [ npc, value, Util.multipleOrSingularEnding(value, "credit") ] )
	GM.pc.addCredits(value)
	
	if dar[idx].type == BountyTypes.INDOCTRINATE:
		GM.main.removeDynamicCharacter(dar[idx].npcID)
	
	emit_signal("bountyCompleted", dar[idx])
	dar.remove(idx)

func saveData() -> Dictionary:
	var d : Dictionary = {
		BountiesKey:[],
		IndoctrinatedKey:data.get(IndoctrinatedKey, []),
	}
	
	for entry in getEntries():
		d[BountiesKey].append(entry.saveData())
	
	
	return d

func loadData(d:Dictionary) -> void:
	data.clear()
	data[BountiesKey] = []
	data[LocationBountiesKey] = []
	
	for entryDict in SAVE.loadVar(d, BountiesKey, []):
		var nentry : Bounty = Bounty.new()
		nentry.loadData(entryDict)
		data[BountiesKey].append(nentry)
		if nentry.location:
			getOrAddBountyLocationArray(nentry.location).append(nentry)
	
	for locationArray in data[LocationBountiesKey]:
		locationArray.sort_custom(self, "sort_bounties")
	
	data[IndoctrinatedKey] = SAVE.loadVar(d, IndoctrinatedKey, [])
	
	data[BountiesKey].sort_custom(self, "sort_bounties")
