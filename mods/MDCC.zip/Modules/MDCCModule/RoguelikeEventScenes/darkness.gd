extends SceneBase

func _run():
	saynn("The few lights in the mineshaft suddenly flicker and weaken.")
	
	addButton("Continue", "", "endthescene")

func _react(_action: String, _args):
	if _action=="endthescene":
		var rogue = getModule("MDCC").getSubmodule("Roguelike")
		rogue.darkness = 32
		endScene()
		return
	
	setState(_action)
