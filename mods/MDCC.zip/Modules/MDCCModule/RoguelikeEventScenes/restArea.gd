extends SceneBase

var percRestored : float = 0.2 # 20%
var snaccRestore : float = 0.3 # 30%

var snacced : bool = false

func _run():
	if(state == ""):
		saynn("You find a little nook, with a buzzing yellow-ish light above, a worn couch, and an old vending machine in the corner.")
		saynn("You feel like it's safe to rest here for a bit.")
		
		addButton("Keep moving","","move")
		addButton("Rest for a bit","","rest")
		if GM.pc.getCredits()>=2 && !snacced:
			addButton("Buy a snack","Buy something from the vending machine","buysnacc")
		
	
	elif state=="rest":
		playAnimation(StageScene.Solo, "sit")
		saynn("You sat down and rested for a while.")
		addButton("Get up","Time to go","go")
	
	elif state=="move":
		saynn("You decide not to rest.")
		addButton("Continue","","endthesceneKeep")
	
	elif state=="go":
		saynn("You get up and continue on your way.")
		playAnimation(StageScene.Solo, "stand")
		addButton("Continue","","endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if(_action == "endthesceneKeep"):
		endScene(["keepme"])
		return
	
	
	if _action=="rest":
		var stam = int(GM.pc.getMaxStamina()*percRestored)
		var lust = int(GM.pc.lustThreshold()*percRestored)
		GM.pc.addStamina(stam)
		GM.pc.addLust(-lust)
		
		addMessage("You restored %s stamina" % stam)
		addMessage("You restored %s lust" % lust)
		
		processTime(30*60) # half an hour passes
	
	elif _action=="buysnacc":
		var stam = int(GM.pc.getMaxStamina()*snaccRestore)
		GM.pc.addStamina(stam)
		addMessage("You bought a snack that restored %s points of your stamina" % stam)
		snacced = true
		GM.pc.addCredits(-2)
		return
	
	setState(_action)

func saveData():
	var d = .saveData()
	d["snacced"]=snacced
	return d

func loadData(d):
	.loadData(d)
	snacced = SAVE.loadVar(d,"snacced",false)
