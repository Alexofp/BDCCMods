extends SceneBase

var ratGender = null

class Rat: # sucky suck suck, but whatever
	static func they(ratGender) -> String:
		match ratGender:
			Gender.Male:
				return "he"
			Gender.Female:
				return "she"
			Gender.Other:
				return "it"
		
		return "they"

	static func their(ratGender) -> String:
		match ratGender:
			Gender.Male:
				return "his"
			Gender.Female:
				return "her"
			Gender.Other:
				return "its"
		
		return "their"

	static func verb(ratGender,verbPlur:String,verbSing:String="") -> String:
		if ratGender==Gender.Androgynous:
			return verbPlur
		
		return verbPlur+"s" if !verbSing else verbSing
	
	static func them(ratGender) -> String:
		match ratGender:
			Gender.Male:
				return "him"
			Gender.Female:
				return "her"
			Gender.Other:
				return "it"
		
		return "them"

func _run():
	if ratGender==null:
		ratGender = RNG.pick([
			Gender.Androgynous,
			Gender.Male,
			Gender.Other,
			Gender.Female
		])
	
	if(state in ["go",""]):
		saynn("A lone rat is standing on an old, weathered wooden table.")
		
		saynn("The table has a small lantern on it, somehow still lit and illuminating the small area around it with warm orange-yellow light, and a perfectly preserved cheese wedge inside a glass box.")
		
		saynn("The rat is staring at the cheese wedge intensely, going up and around the glass box, looking for a way in. %s %s seem to notice you." % [Rat.they(ratGender).capitalize(), Rat.verb(ratGender,"don't","doesn't")])
		
		addButton("Keep going","Let the rat struggle on %s own" % Rat.their(ratGender),"endthesceneKeep")
		addButton("Help %s" % Rat.them(ratGender),"Look for a way to get %s the cheese" % Rat.them(ratGender),"help")
	
	elif state=="help":
		saynn("You approach the table and start examining the glass box.")
		if "rat" in GM.pc.getSpecies():
			saynn("The rat sees you and turns to face you, awaiting your help.")
			
			if GM.pc.getPersonality().getStat(PersonalityStat.Mean)>0.5: # mean
				saynn("You push %s gently out of the way, letting %s know that you don't want %s in your way.".replace("%s",Rat.them(ratGender)))
			else:
				saynn("You pet %s head a bit and point %s to a place a bit more out of your way." % [Rat.their(ratGender), Rat.them(ratGender)])
		else:
			saynn("The rat sees you and jumps off the table in fear, but you notice %s still standing by the table, observing you." % Rat.them(ratGender))
		
		saynn("It seems that the box has a small lock on it.")
		
		
		addButton("Give up","Keep going","endthesceneKeep")
		
		if GM.pc.getStamina()==0:
			saynn("Unfortunately, you're too exhausted to do anything.")
			return
		
		if GM.pc.getStat(Stat.Strength)>=15:
			saynn("You think you could probably break the box with your fists.")
			if GM.pc.hasBlockedHands() or GM.pc.hasBoundArms():
				addDisabledButton("Break the box","Your hands need to be free to do this")
			elif GM.pc.getStamina()<5:
				addDisabledButton("Break the box","You're too tired to do this")
			else:
				addButton("Break the box","Use your fists to break it open","break")
		
		
		if GM.pc.hasPerk(Perk.BreedCockSlap) && GM.pc.hasReachablePenis():
			var cage = GM.isWearingChastityCage()
			saynn("You don't think the box would be able to handle a slap from your cock." + (" If only it weren't caged up..." if cage else ""))
			if cage:
				addDisabledButton("Cockslap the sucker","You can't do that with a chastity cage on")
			else:
				addButton("Cockslap the sucker","Time to break something more than holes","cockslap")
		
		
		if GM.pc.getInventory().hasItemID("Shiv") && GM.pc.getStat(Stat.Agility)>=5:
			var blind = GM.pc.isBlindfolded()
			saynn("You might be able to pick the lock with a shiv and some fine motor skills." + (" Being blindfolded is gonna make it much more difficult, though" if blind else ""))
			
			var cost = 5 + (10 if blind else 0)
			
			if GM.pc.hasBlockedHands() or GM.pc.hasBoundArms():
				addDisabledButton("Pick lock","Your hands need to be free to do this")
			elif GM.pc.getStat(Stat.Agility)<cost:
				addDisabledButton("Pick lock","You need to have at least %s Agility to do this" % cost)
			else:
				addButton("Pick lock","Use your shiv to pick the lock","picklock")
		
		
		if GM.pc.getInventory().hasItemID("restraintkey"):
			saynn("The lock looks like it can be unlocked using a restraint key.")
			addButton("Unlock with restraint key","Use one of your restraint keys to unlock the box","unlock")
		
		
		
	
	elif state in ["picklock", "unlock"]: # restraint key
		if state=="unlock":
			saynn("You put %s into the box's lock and turn it. The lock opens with a satisfying click." % ( "one of your restraints keys" if GM.pc.getInventory().getXOfTotal("restraintkey")+1>1 else "your only restraint key" ) )
		else:
			saynn("You pull out your shiv, and proceed to carefully pick the box's lock with it, taking more time than you'd want to do so, but finally managing to unlock it with a satisfying click.")
		
		
		if "rat" in GM.pc.getSpecies():
			saynn("The rat quickly approaches the box again, turning %s head to look at you and then looking back at the box." % Rat.their(ratGender))
		else:
			saynn("The rat quickly jumps back onto the table and rushes to the box, stopping once %s %s you're still there." % [Rat.they(ratGender), Rat.verb(ratGender,"realize")])
		
		addButton("Let %s have it" % Rat.them(ratGender),"You did it for %s, after all" % Rat.them(ratGender),"ratreward_%s" % state)
		addButton("Eat the cheese","You did all the hard work, not %s" % Rat.them(ratGender),"fkn_asshole_%s" % state)
	
	elif state=="cockslap": # yea
		saynn("You whip out your {pc.cock}, and slap the glass box with it. It breaks, exposing the cheese. The glass's consistency makes its shards big and solid, easy to pick out.")
		if "rat" in GM.pc.getSpecies():
			saynn("The rat jumps down from the table, scared by the force and the sound.")
		saynn("... Unfortunately, your {pc.cockSize} {pc.penisShort} did also crush the cheese, but it's still edible.")
		
		saynn("The rat finds the courage to jump back onto the table, excited by the prospect of cheese.")
		
		
		addButton("Let %s have it" % Rat.them(ratGender),"You did it for %s, after all" % Rat.them(ratGender),"ratreward_cockslap")
		addButton("Eat the cheese","You did all the hard work, not %s" % Rat.them(ratGender),"fkn_asshole_cockslap")
	
	elif state=="break": # fist
		saynn("You clench your fist and take a moment to prepare. You raise your arm high and bring it down onto the glass box with force, breaking it into thick shards. The glass is solid enough, making it easy to pick out from the cheese.")
		
		saynn("... Of course, your fist did also crush the cheese, as is expected, but it's still edible.")
		
		addButton("Let %s have it" % Rat.them(ratGender),"You did it for %s, after all" % Rat.them(ratGender),"ratreward_break")
		addButton("Eat the cheese","You did all the hard work, not %s" % Rat.them(ratGender),"fkn_asshole_break")
	
	elif state.begins_with("ratreward_"):
		saynn("You let the rat have the cheese"+ (", petting their head a bit to show them a bit more affection." if("rat" in GM.pc.getSpecies()) else "."))
		
		var secondary = state.trim_prefix("ratreward_")
		
		if secondary in ["cockslap","break"]: # broken
			saynn("The rat tries to get the cheese from under and between all the glass shards. You decide to help %s do that as well, otherwise the whole exercise would be useless." % Rat.them(ratGender))
			
		elif secondary in ["picklock","unlock"]:
			saynn("The rat runs up to the now wide-open box, staring at %s new treasure." % Rat.their(ratGender))
		
		saynn("After %s %s a little taste of the cheese, %s %s back down and %s under the table." % [ Rat.they(ratGender), Rat.verb(ratGender,"get"), Rat.they(ratGender), Rat.verb(ratGender,"jump"), Rat.verb(ratGender,"disappear") ])
		
		saynn("%s %s with a credit chip in %s mouth, leaving it on the table for you." % [ Rat.they(ratGender).capitalize(), Rat.verb(ratGender,"reappear"), Rat.their(ratGender) ])
		
		addButton("Job well done","Move on","endthescene")
	
	elif state.begins_with("fkn_asshole_"):
		saynn("You, being the lowly fucking asshole that you are, decide to take the cheese for yourself.")
		
		var secondary = state.trim_prefix("fkn_asshole_")
		
		if secondary in ["cockslap","break"]: # broken
			saynn("You pick out the glass shards from the cheese, and proceed to eat it in front of the rat, %s watching you sadly, before running away and disappearing in the darkness." % Rat.them(ratGender))
			
		elif secondary in ["picklock","unlock"]:
			saynn("You take the cheese out of the box and eat it in front of the rat. %s %s you in silence, heartbroken, and %s into the darkness." % [ Rat.they(ratGender).capitalize(), Rat.verb(ratGender,"watch","watches"), Rat.verb(ratGender,"disappear") ])
		
		saynn("You then leave, licking your digits on one hand and knocking down the lantern with the other, causing its light to die out just like yours did so long ago.")
		
		addButton("Continue","Walk away","endthescene")
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	elif(_action == "endthesceneKeep"):
		endScene(["keepme"])
		return
	
	
	elif _action=="unlock":
		GM.pc.getInventory().removeXOfOrDestroy("restraintkey",1)
		addMessage("You used a restraint key to unlock the box")
	elif _action=="break":
		processTime(60)
		GM.pc.addStamina(-5)
		addMessage("You lost 5 stamina")
	
	elif _action.begins_with("fkn_asshole"):
		processTime(30)
		GM.pc.addStamina(1)
		addMessage("You recovered 1 stamina")
	elif _action.begins_with("ratreward"):
		processTime(90)
		var creds = RNG.randi_range(1,3)
		GM.pc.addCredits(creds)
		addMessage("You got %s %s" % [creds, Util.multipleOrSingularEnding(creds, "credit")])
	setState(_action)


func saveData():
	var d = .saveData()
	d["ratGender"] = ratGender
	return d

func loadData(d):
	.loadData(d)
	ratGender = int(SAVE.loadVar(d,"ratGender",0))
