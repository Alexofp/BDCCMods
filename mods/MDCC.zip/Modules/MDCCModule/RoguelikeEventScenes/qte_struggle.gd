extends SceneBase

var difficulty : float = 5.0

func _run():
	if(state in ["go",""]):
		var game : Control = load("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn").instance()
		
		GM.ui.addFullScreenCustomControl("minigame",game)
		game.setDifficulty(difficulty)
		game.timer *= 0.32
		game.timeLeft *= 0.32
		game.button.hide()
		game.button.get_node("../Label").text = "Think fast, chucklenuts!"
		game.connect("minigameCompleted",self,"minigameFinished")
		yield(get_tree().create_timer(0.75),"timeout")
		game.setIngame(true)
		return
	
	if state == "done":
		saynn("You managed to do the thing I guess")
	elif state == "epicFail":
		saynn("You fucked up big time, this is gonna hurt")
	elif state == "victoryRoyale":
		saynn("Good {pc.boyGirl}! Who's a good little pet? You are! Have a treat!")
		
	addButton("Okay","","endthescene")
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if _action=="qteResult":
		var res : MinigameResult = _args[0]
		if res.failedHard or res.score==0.0:
			GM.pc.addPain(50)
			addMessage("You were hurt for %s points" % 50)
			setState("epicFail")
		elif res.instantUnlock or res.score>=1.0:
			var treat = GlobalRegistry.createItem("applepie" if "AnAppleADay" in GlobalRegistry.getModules() else "appleitem")
			GM.pc.getInventory().addItem(treat)
			addMessage("You got %s!" % treat.getAStackName())
			setState("victoryRoyale")
		else:
			setState("done")
		return
	setState(_action)

func minigameFinished(result:MinigameResult):
	GM.main.pickOption("qteResult", [result])
