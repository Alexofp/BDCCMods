extends SceneBase

const energyCost : int = 10
const damage : int = 45

func _run():
	if(state in ["go",""]):
		saynn("Suddenly, there's a cave-in while you're exploring the cave!")
		
		if GM.pc.getStamina()<energyCost:
			addDisabledButton("Dodge","You don't have enough stamina")
		else:
			addButton("Dodge", "Try to dodge the falling rocks","dodge")
		addButton("Do nothing","Let the rocks hit you","rockslap")
		return
	
	if state=="dodge":
		saynn("You managed to dodge the falling debris!")
		addMessage("You spent %s stamina" % energyCost)
	
	elif state=="rockslap":
		saynn("You let the falling debris hit you.")
		addMessage("You were hurt for %s points" % damage)
	
	
	addButton("Continue","","endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if _action=="dodge":
		GM.pc.addStamina(-energyCost)
	
	elif _action=="rockslap":
		GM.pc.addPain(damage)
	
	
	
	setState(_action)
