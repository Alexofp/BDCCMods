extends GameExtender

var enemies : Array = []
var pawnUID : int = 0 # don't edit

const femPawn = preload("res://Images/WorldPawns/fem.png")
const mascPawn = preload("res://Images/WorldPawns/masc.png")
const pawnColor : Color = Color.magenta

const movementCooldown : int = 60 # in seconds, every 1 min

class WanderingEnemy:
	var iconID:String = ""
	var loc:String = ""
	var path:Array = []
	var cooldown : int = 0
	
	func saveData() -> Dictionary:
		return {
			iconID = iconID,
			loc = loc,
			path = path,
			cooldown = cooldown
		}
	
	func loadData(_data:Dictionary):
		iconID = SAVE.loadVar(_data, "iconID", "")
		loc = SAVE.loadVar(_data, "loc", "")
		path = SAVE.loadVar(_data, "path", [])
		cooldown = int(SAVE.loadVar(_data, "cooldown", 0))
	
	func getTarget() -> String:
		if(path.empty()):
			return ""
		return path.back()
		
	func go(theTargetLoc:String) -> bool:
		var theLoc:String = loc
		if(theLoc == theTargetLoc):
			return true
		
		if(path.empty() || path.back() != theTargetLoc):
			path = GM.world.calculatePath(theLoc, theTargetLoc)
			if(!path.empty() && path[0] == loc):
				path.pop_front()
		
		if(path.empty()):
			return false
		
		var nextLoc:String = path.pop_front()
		setLoc(nextLoc)
		return false
	
	func setLoc(_newLoc:String):
		loc = _newLoc
		GM.world.moveEntity(iconID, loc)
	
	func createIcon(_uidProvider):
		if !GM.world.getRoomByID(loc):
			return
		
		if(iconID == ""):
			var nextEntityID:String = "MDCC_rogueEnemy%s" % _uidProvider.getPawnUID()
			iconID = nextEntityID
		
		GM.world.createEntity(iconID, RNG.pick([_uidProvider.mascPawn, _uidProvider.femPawn]), loc)
		
		GM.world.entities[iconID].modulate = _uidProvider.pawnColor

func createEnemy(loc:String) -> void:
	var nen = WanderingEnemy.new()
	enemies.append(nen)
	nen.loc = loc
	nen.createIcon(self)
	nen.cooldown = movementCooldown

func _init():
	id = "MDCC_RoguelikeEnemyExtender"

func register(_GES:GameExtenderSystem):
	## Uncomment these lines to make this extender work
	_GES.register(self, ExtendGame.pcProcessTime)
	_GES.register(self, ExtendGame.saveLoadData)
#	pass

func processAllEnemies(_seconds) -> void:
	for enemy in enemies:
		processEnemy(enemy,_seconds)

func killEnemy(enemyID:String) -> bool:
	for enemy in enemies:
		if enemy.iconID==enemyID:
			return killEnemyObject(enemy)
	return false

func killEnemyObject(enemy:WanderingEnemy) -> bool:
	GM.world.deleteEntity(enemy.iconID)
	enemies.erase(enemy)
	return true

func pcProcessTime(_pc:Player, _seconds):
	processAllEnemies(_seconds)

func processEnemy(enemy:WanderingEnemy,_seconds) -> void:
	enemy.cooldown -= _seconds
	if enemy.cooldown>0:
		return
	
	var flobj = GM.world.floorDict.get("RoguelikeFloor")
	
	if !enemy.getTarget():
		var avails = flobj.getRooms()
		var chosenRoom = RNG.grab(avails)
		while enemy.go(chosenRoom.roomID): # dest?
			if !avails:
				Log.printerr("WanderingEnemy path is empty, something is wrong!")
				return
			chosenRoom = RNG.grab(avails)
			
	else: # we have path
		enemy.go(enemy.getTarget())
	enemy.cooldown = movementCooldown

func getEnemiesInLoc(loc:String) -> Array:
	var res = []
	for enemy in enemies:
		if enemy.loc==loc:
			res.append(enemy)
	return res

func saveData():
	var d = {
		"enemiesData":[],
		"pawnUID":pawnUID,
	}
	for enemy in enemies:
		d["enemiesData"].append(enemy.saveData())
	
	return d

func createEnemies() -> void:
	var flobj = GM.world.floorDict.get("RoguelikeFloor").get_child(0)
	
	var avails = []
	for roomnode in flobj.get_children():
		if not roomnode.roomID in [flobj.exit, "rogueOrigin"]: # as long as it's not taken pretty much
			avails.append(roomnode)
	
	
	var floornum = GM.main.getModuleFlag("MDCC", "RoguelikeFloor", 0)
	
	var amounts = [1,2]
	if floornum>15:
		if GM.main.isVeryLate():
			amounts = [3,4]
		else:
			amounts = [1,3]
	elif floornum>35:
		if GM.main.isVeryLate():
			amounts = [4,5]
		else:
			amounts = [3,4]
	elif GM.main.isVeryLate():
		amounts = [2,2]
	
	for i in int(min(avails.size(), RNG.randi_range(amounts[0],amounts[1]))):
		createEnemy(RNG.pick(avails).roomID)

func clearEnemies() -> void:
	for enemy in enemies:
		GM.world.deleteEntity(enemy.iconID)
	enemies.clear()

func loadData(d):
	.loadData(d)
	clearEnemies()
	for enemyData in SAVE.loadVar(d,"enemiesData",[]):
		var nenemy = WanderingEnemy.new()
		nenemy.loadData(enemyData)
		enemies.append(nenemy)
	pawnUID = int(SAVE.loadVar(d,"pawnUID",0))

func getPawnUID() -> int:
	pawnUID += 1
	return pawnUID
