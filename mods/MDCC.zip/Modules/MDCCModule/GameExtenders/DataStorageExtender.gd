extends GameExtender

func _init():
	id = "MDCC_DataStorageExtender"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.saveLoadData)


func saveData():
	var MDCC : Module = GlobalRegistry.getModule("MDCC")
	var d : Dictionary = {}
	
	var subs : Dictionary = MDCC.getSubmodules()
	for submod in subs:
		d[submod] = subs[submod].saveData()
	
	return d

func loadData(_d):
	if _d==null:
		var MDCC : Module = GlobalRegistry.getModule("MDCC")
		var subs : Dictionary = MDCC.getSubmodules()
		for submod in subs:
			subs[submod].loadData({})
		return
	
	loadDataFR(_d)

func loadDataFR(_d):
	if GM.main == null:
		return
	
	var MDCC : Module = GlobalRegistry.getModule("MDCC")
	var subs : Dictionary = MDCC.getSubmodules()
	
	for submod in subs:
		subs[submod].loadData(SAVE.loadVar(_d, submod, {}))
	
	
	GM.main.reRun()
