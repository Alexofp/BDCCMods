extends BodypartHair

func _init():
	visibleName = "Astra Hair"
	id = "MDDC_AstraHair"
	

func getDoll3DScene():
	return "res://Modules/MDCCModule/Bodyparts/AstraHair/AstraHair.tscn"

func getTraits():
	return {
		PartTrait.HairLong: true,
	}

func getCompatibleSpecies():
	return []

func npcGenerationWeight(_dynamicCharacter):
	return 0.0
