extends LootTableBase

const minRarity = 1 # any seed less than this is cut
const maxRarity = 10 # should probably calc this somehow, this will likely cause issues if it rolls this and there's no plant this rare

const seedDelimiter : String = ":" # if a loot entry begins with MDCC_Seed, this shows where the seed type id starts

func _init():
	id = "roguelikeLoot"
	minCredits = 0
	maxCredits = 3
	if !GM.main:
		return
	loot = [getBasicSeedLoot()]

func generateAndCreateItems(characterID=null, battleName=null):
	var idsToDrawFrom = [
		"inmate", # can get items from other loottables, defaults to inmate
	]
	
	var generatedLoot = generateAndCreateItemsBasic(characterID,battleName)
	
	for ltId in idsToDrawFrom: # loop over ids to draw from
		var lt = GlobalRegistry.createLootTable(ltId)
		if !lt: # no table, abort
			continue
		
		var l = lt.generateAndCreateItems(characterID, battleName)
		for item in l["items"]:
			if !item.canCombine(): # can't combine stack to existing stack in genlooot, continue
				continue
			for myitem in generatedLoot["items"]:
				if myitem.id==item.id && myitem.tryCombine(item):
					break # if any item can be combined (done in trycombine) with this stack, do so and break outta this loop
	
	
	return generatedLoot



func getBasicSeedLoot() -> Array:
	var finalLoot = []
	
	var mdcc = GlobalRegistry.getModule("MDCC")
	
	var floorNumber : int = int(GM.main.getModuleFlag("MDCC", "RoguelikeFloor", 0))
	
	
	var increaseInWeight : float = 0.25 # per floor
	
	var initial = (increaseInWeight)
	
	var finalWeight : float = (2*initial + ((floorNumber-1)*increaseInWeight)) # arithmetic sequence i think
	
	finalWeight *= increaseInWeight*0.5
	
	var repeats = [ # weighted pairs of how many seed rolls we get
		[0, 1.75], # rolls, weight
		[1, 1.0*finalWeight],
		[2, 0.5*finalWeight],
	]
	
	var finalRepeats = RNG.pickWeightedPairs(repeats)
	
	var bigLoot = RNG.chance(2) # 2% chance for a lot of seeds, increases chance for them later
	
	for i in finalRepeats+int(bigLoot):
		var rars = [] # possible rarities
		
		for rar in getDroppedRaritiesForFloor(floorNumber,bigLoot):
			if rar[0]>=minRarity && rar[0] <= maxRarity: # keep good ones
				rars.append(rar)
		
	#	var seedChance = 22.5 # idk
		var seedAmounts = [
			[1,1.0-int(bigLoot)],
			[2,0.34], # rare to get 2 seeds
			[3,0.34+int(bigLoot)], # rarer to get 3 seeds
		]
		var chosenRarity = RNG.pickWeightedPairs(rars)+1 # one added bc we decrease it regardless later, kinda clunky but whatever -w-
		
		var availSeeds = [] # avail seed types
		var plants = mdcc.getSubmodule("Plants").getPlants()
		
		while !availSeeds && chosenRarity>=minRarity: # if we have no seeds and our current rarity is in the valid range
			chosenRarity -= 1 # decrease since we found nothing here
			for p in plants: # for every plant
				if p.rarity==chosenRarity:
					availSeeds.append(p.id) # get all with same rarity as chosen rarity
		
		if availSeeds: # if we got seeds, add 'em
			finalLoot.append([ "MDCC_Seed:%s" % RNG.pick(availSeeds), RNG.pickWeightedPairs(seedAmounts) ])
	
	return [100, finalLoot]


#func getPossibleLoot(characterID, battleName):
#	var a = .getPossibleLoot(characterID, battleName)
#	var sloot = getBasicSeedLoot()
#	if sloot:
#		a.append(sloot)
#	return a

func generateAndCreateItemsBasic(characterID = null, battleName = null):
	var generatedloot = generate(characterID, battleName)
	
	var createdItems = []
	
	if!(generatedloot.has("items")): # no items? add ours ig and return
		generatedloot["items"] = createdItems
		return generatedloot
	
	for generatedItemData in generatedloot["items"]:
		var generatedItem = null
		
		if generatedItemData[0].get_slice(seedDelimiter,0)=="MDCC_Seed": # item id is a seed of ours, make a seed item with provided seed type; delimiter is ":"
			
			var parts = generatedItemData[0].split(seedDelimiter, 1)
			
			generatedItem = GlobalRegistry.createItem(parts[0])
			generatedItem.setSeedType(parts[1])
		else: # regular item, do whatever we don't give a shit
			generatedItem = GlobalRegistry.createItem(generatedItemData[0])
		
		if(generatedItemData.size() > 1): # has amount
			generatedItem.setAmount(generatedItemData[1])
		createdItems.append(generatedItem)
		
	generatedloot["items"] = createdItems
	return generatedloot


func getDroppedRaritiesForFloor(fl:int=1,bigLoot:bool=false): # returns weighted pairs [rarity, weight]
	var medianRarity : int = (fl / 15) + minRarity # +1 every 15 floors, this is the most common rarity for this floor, starts at min rarity
	
#	medianRarity = int(max(minRarity,medianRarity))
	
	var plants = GlobalRegistry.getModule("MDCC").getSubmodule("Plants").getPlants()
	var found = false
	var maxr = maxRarity+1
	while !found && maxr>=minRarity: # find good rarity
		maxr -= 1 # decrease
		for p in plants:
			if p.rarity == maxr:
				found = true
				break
	
	medianRarity = int(min(maxr, medianRarity))
	
	var res = [
		[medianRarity-1, 0.5], # previous rarity, rarer than our median one
		[medianRarity, 1.0], # median, normal weight ig
	]
	if medianRarity<maxr or bigLoot:
		res.append_array([
			[medianRarity+1, 1.5 if bigLoot else 0.1], # rarer than median, even rarer than previous
			[medianRarity+2, 1.2 if bigLoot else 0.02], # jackpot, +2 rarity than expected
		])
	else: # median rarity is max rarity or higher, can't be even higher, its previous rarity's weight is now 1.0 for balance i think
		res[0][1]=1.0
	
	
	return res
