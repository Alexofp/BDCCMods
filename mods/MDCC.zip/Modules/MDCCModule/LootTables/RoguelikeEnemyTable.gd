extends LootTableBase

func _init():
	id = "roguelikeEnemy"

func generateAndCreateItems(characterID=null, battleName=null):
	var floorNumber = GM.main.getModuleFlag("MDCC","RoguelikeFloor",0)
	var idsToDrawFrom = [
		"inmate" if floorNumber<30 else "guard",
	]
	
	var generatedLoot = .generateAndCreateItems(characterID,battleName)
	
	for ltId in idsToDrawFrom:
		var lt = GlobalRegistry.createLootTable(ltId)
		if !lt:
			continue
		
		var l = lt.generateAndCreateItems(characterID, battleName)
		for item in l["items"]:
			if !item.canCombine():
				continue
			for myitem in generatedLoot["items"]:
				if myitem.id==item.id && myitem.tryCombine(item):
					break
	
	
	
	
	return generatedLoot
