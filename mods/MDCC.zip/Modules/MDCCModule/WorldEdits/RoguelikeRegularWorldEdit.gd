extends WorldEditBase

var rogue

func _init():
	id = "RoguelikeRegularWorldEdit"
	isRegular = true

func apply(_world: GameWorld):
	if !rogue:
		rogue = GlobalRegistry.getModule("MDCC").getSubmodule("Roguelike")
	
	var room = _world.getRoomByID(GM.pc.location)
	if !room:
		return
	if room.getFloorID()=="RoguelikeFloor":
		GM.world.setDarknessVisible(rogue.darkness>0)
		GM.world.setDarknessSize(rogue.darkness)
	
