extends WorldEditBase

func _init():
	id = "RoguelikeWorldEdit"

func apply(_world: GameWorld):
	GlobalRegistry.getModule("MDCC").getSubmodule("Roguelike").onEnter()
	Console.addCommand("loot", self, "loot", ["floors"],"test roguelike loot")
	Console.addCommand("mloot", self, "massLoot", ["floors","times"],"test roguelike loot")
	

func massLoot(fls=1,times=1) -> void:
	var totss = {}
	var totos = {}
	for i in int(times):
		var ds = loot(int(fls),false)
		for d in ds[0]:
			totss[d] = totss.get(d,0)+ds[0][d]
		for d in ds[1]:
			totos[d] = totos.get(d,0)+ds[1][d]
	
	Console.printLine("\nTotal seeds for %s floors, %s times:" % [fls, times])
	for r in totss:
		Console.printLine("%s: %s seeds" % [r, totss[r]])
	
	Console.printLine("\nTotal others for %s floors, %s times:" % [fls, times])
	for r in totos:
		Console.printLine("%sx %s" % [totos[r],r])

func loot(fls=1,mess=true) -> Array:
	var lootChances = [
		[1,50],
		[0,40],
		[2,10],
	]
	
	var totalSeedRaritiesAmount = {}
	var oldf = GM.main.getModuleFlag("MDCC","RoguelikeFloor",0)
	var totalOthers = {}
	
	for fl in int(fls):
		GM.main.setModuleFlag("MDCC","RoguelikeFloor",fl)
		for i in RNG.pickWeightedPairs(lootChances):
			var lootdict = GlobalRegistry.createLootTable("roguelikeLoot").generateAndCreateItems()["items"]
			
			for item in lootdict:
				if item.id=="MDCC_Seed":
					if mess:
						Console.printLine("%sx %s seed for floor %s (%s rarity)" % [item.amount,item.seedType,fl,item.seedRarity])
					totalSeedRaritiesAmount[item.seedRarity]=totalSeedRaritiesAmount.get(item.seedRarity,0)+item.amount
				else:
#					Console.printLine("%sx %s for floor %s" % [item.amount,item.id,fl])
					totalOthers[item.id]=totalOthers.get(item.id,0)+item.amount
	if mess:
		Console.printLine("\nTotal seeds for %s floors:" % fls)
		for r in totalSeedRaritiesAmount:
			Console.printLine("%s: %s seeds" % [r, totalSeedRaritiesAmount[r]])
		
		Console.printLine("\nTotal others for %s floors:" % fls)
		for r in totalOthers:
			Console.printLine("%sx %s" % [totalOthers[r],r])
	
	GM.main.setModuleFlag("MDCC","RoguelikeFloor",oldf)
	return [totalSeedRaritiesAmount,totalOthers]
