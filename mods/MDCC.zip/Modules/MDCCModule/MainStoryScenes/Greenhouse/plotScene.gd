extends SceneBase

var debug : bool = false

var plantsSM

var chosenPlotID : String = ""

# change at will
const GoodColor : Color = Color.limegreen
const MehColor : Color = Color.gold
const BadColor : Color = Color.crimson
const DeadColor : Color = Color.gray


func _init():
	sceneID = "MDCC_PlotScene"
	if GM.main:
		plantsSM = GlobalRegistry.getModule("MDCC").getSubmodule("Plants")
	

func getPlant(id:String):
	return plantsSM.getPlant(id)

func listAllPlots() -> void:
	saynn("You have:")
	var plots = plantsSM.getPlots()
	for plot in plots:
		if !plot.hasPlant():
			saynn("[color=gray]An empty plot[/color]")
			addButton("Plant there", "", "plantMenu", [plot])
			continue
		
		
		var plant = getPlant(plot.plantID)
		if !plant:
			saynn(colorText("BAD PLOT", BadColor))
			continue
		
		var gperc = plant.growthTime / float(plot.grownDays)
		var nperc = plant.maxNeglect / float(plot.neglect)
		
		var col = BadColor.linear_interpolate(MehColor, gperc) if gperc<1.0 else GoodColor
		
		
		sayn("[color=yellow]A plot with %s%s[/color]" % [plant.name, ("" if !plot.yeen else colorText(" (cared for)", Color.gray)) if nperc<1.0 else colorText(" (dead)", Color.gray) ] )
		if plant.desc:
			saynn("[i]%s[/i]" % plant.desc)
		
		
		var negText = colorText("%s/%s" % [plot.neglect, plant.maxNeglect], MehColor.linear_interpolate(BadColor, nperc) if nperc!=0 else GoodColor)
		
		var growText = ""
		if plot.currentHarvestCooldown>0:
			growText = colorText("(harvested, %s %s left)" % [plot.currentHarvestCooldown, ( "days" if plot.currentHarvestCooldown>1 else "day" ) ], Color.gray)
		else:
			growText = colorText(("%s/%s" % [plot.grownDays, plant.growthTime]), col)
		
		
		saynn("Growth: %s\nWatered: %s\nDays neglected: %s" % [ growText, (colorText("Yes", GoodColor) if plot.watered else colorText("No", BadColor)), negText ] )
		
		if nperc>=1.0: # dead
			addButton("Clean", "", "cleanPlot", [plot])
		
		elif gperc>=1.0: # grown & not dead
			if plot.currentHarvestCooldown>0:
				addDisabledButton("Harvest %s" % plant.name, "You've already harvested this today")
			else:
				addButton("Harvest %s" % plant.name,"Harvest this", "harvestPlot", [plot])
		elif plot.watered: # watered, nothing left to do
			addDisabledButton("Harvest %s" % plant.name, "It's not mature")
		else:
			if plant.rarity:
				addDisabledButton("Water %s" % plant.name, "You're not experienced enough to care for this plant")
			else:
				addButton("Water %s" % plant.name, "Water this", "waterPlot", [plot])

func colorText(txt:String, col:Color) -> String: # easier formatting
	return "[color=#%s]%s[/color]" % [col.to_html(),txt]

func _run():
	if(state in ["go",""]):
		addButton("Step away", "", "endthescene")
		
		listAllPlots()
		addButton("Stores","See what the workbench has","stores")
		if debug:
			addButton("Gimme one of each seed", "Do it", "seedsgalore")
			addButton("Instagrow", "I'm an impatient little slut", "instagrow")
		
	
	elif state=="plantMenu":
		addButton("Go back", "", "")
		
		saynn("Choose what to plant here:")
		
		var seeds = GM.pc.getInventory().getAllOf("MDCC_Seed")
		for seeditem in seeds:
			var seedPlant = getPlant(seeditem.seedType)
			if !seedPlant:
				continue
			
			if seedPlant.rarity==0 && !seedPlant.plantable: # unique & unplantable
				addDisabledButton("Plant %s" % seedPlant.name, "Your thumb's not green enough")
			else:
				addButton("Plant %s" % seedPlant.name, "Plant this" + ("\n\n%s" % seedPlant.desc), "plant", [chosenPlotID, seeditem.seedType, seeditem.uniqueID])
			
			saynn("%s:\nGrowing Time:%s days" % [seedPlant.name, seedPlant.growthTime])
	
	elif state=="stores":
		saynn("The greenhouse workbench has:")
		saynn(getModule("MDCC").getIngredientStoresText())
		addButton("Okay", "", "")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if _action=="instagrow":
		for plot in plantsSM.getPlots():
			plot.grownDays = 9001
		
		setState("")
		return
	
	if _action=="seedsgalore": # for debugging
		for plant in plantsSM.getPlants():
			var sitem = GlobalRegistry.createItem("MDCC_Seed")
			sitem.setSeedType(plant.id)
			GM.pc.getInventory().addItem(sitem)
		
		setState("")
		return
	
	
	if _action=="plant":
		var plotId = _args[0]
		var plant = getPlant(_args[1])
		if !plant:
			setState("")
			return
		
		plantsSM.doPlantInPlot(plotId, _args[1])
		
		var it = GM.pc.getInventory().getItemByUniqueID(_args[2]) # get seeds
		
		it.removeXOrDestroy(1) # remove them
		
		addMessage("You planted %s" % plant.name)
		setState("")
		return
	
	if _action=="waterPlot":
		_args[0].watered = true
		addMessage("You watered the plant")
		setState("")
		return
	
	if _action=="harvestPlot":
		var plot = _args[0]
		var plant = getPlant(plot.plantID)
		if !plant:
			setState("")
			return
		var craftingLib = GlobalRegistry.getModules().get("CraftingLibReworked")
		
		var lootings = plant.ings
		var lootits = plant.items
		
		
		if craftingLib: # add ingredients if we have craftinglib
			var d = {}
			for ar in lootings:
				craftingLib.Workbench.addIngredient("MDCC_GreenhouseWB", ar[0], ar[1], {})
				d[ar[0]]=[ar[1]]
			
			var itemd = {}
			for ar in lootits:
				itemd[ar[0]]=[ar[1]]
			
			addMessage("You harvested:\n%s" % "\n".join(craftingLib.getIngredientsRequiredArray(d,itemd)))
		
		
		for ar in lootits:
			GM.pc.getInventory().addXOfItemID(ar[0], ar[1])
		
		plot.harvestsDone += 1
		if plot.harvestsDone >= plant.maxHarvests: # no more
			plot.plantID = ""
			plot.watered = false
			plot.yeen = false
		else:
			plot.currentHarvestCooldown = plant.harvestInterval
		
		setState("")
		return
	
	if _action=="cleanPlot":
		_args[0].plantID = ""
		addMessage("You cleaned out the plot")
		setState("")
		return
	
	if _action=="plantMenu": # set chosen plot upon going to plant something on an empty plot
		chosenPlotID = _args[0].id
	
	setState(_action)

func saveData() -> Dictionary:
	var d = .saveData()
	d["chosenPlotID"] = chosenPlotID
	return d

func loadData(d):
	.loadData(d)
	chosenPlotID = SAVE.loadVar(d, "chosenPlotID", "")


func getDebugActions():
	return [
		{
			"id": "MDCC_plotDebug",
			"name": "Toggle plots debug (%s)" % ("ON" if debug else "OFF"),
			"args": [
			],
		},
	]

func doDebugAction(_id, _args = {}):
	if(_id == "MDCC_plotDebug"):
		debug = !debug
	
