extends SceneBase

const debug : bool = false

var plantsSM = null

var lastPlantID : String = ""

func resolveCustomCharacterName(_charID):
	if _charID=="a":
		return "MTlani"
	return null

func _init():
	sceneID = "MDCC_PaymentScene"
	if GM.main:
		plantsSM = GlobalRegistry.getModule("MDCC").getSubmodule("Plants")
		

func getPlant(id:String):
	return plantsSM.getPlant(id)

func getPlot(id:String):
	return plantsSM.getPlot(id)

func listAllPlots() -> void:
	saynn("[say=a]ok dokie lil person let's see what we can do[/say]")
	
	var plots = plantsSM.getPlots()
	var empties = [] # plots
	var deads = []
	var cantcarefor = [] # almost grown & watered
	var frees = [] # can be paid to grow more
	var grown = []
	for plot in plots:
		if !plot.hasPlant():
			empties.append(plot)
			continue
		var plant = getPlant(plot.plantID)
		if !plant:
			continue
		
		
		var daysleft = plant.growthTime - plot.grownDays
		
		if plantsSM.isPlotDead(plot):
			deads.append(plot)
		elif daysleft==1 && plot.watered:
			cantcarefor.append(plot)
		elif daysleft<=0:
			grown.append(plot)
		elif plot.yeen: # if not already caring for it
			frees.append(plot)
	
	if deads:
		saynn("[say=a]well i can see you've got %s dead %s. you gotta take better care of your plants mate, i can do nuttin' about %s[/say]" % [  deads.size(), Util.multipleOrSingularEnding(deads.size(),"plot"), Util.multipleOrSingularEnding(deads.size(),"that one", "those ones")  ] )
	
	if cantcarefor:
		saynn("[say=a]%s pretty much done, nothing for me to do there[/say]" % Util.multipleOrSingularEnding(cantcarefor.size(), "this one plot is", "those %s plots are" % cantcarefor.size()) )
	
	if grown:
		saynn("[say=a]i can see you got %s %s waiting to be harvested, {pc.boyGirl}. whatcha waitin' for? plants ain't gonna harvest 'emselves, darn city{pc.boyGirl}[/say]" % [ grown.size(), Util.multipleOrSingularEnding(grown.size(),"plot") ])
	
	if frees:
		saynn("[say=a]we can talk numbers about %s, though, i can take %s under my wing no problem[/say]" % [ Util.multipleOrSingularEnding(frees.size(), "that one plot what hasn't quite grown yet", "those %s plots that aren't quite ready yet" % frees.size()), Util.multipleOrSingularEnding(frees.size(), "that one", "those ones") ])
		
		addButton("Care for plots","Pay %s to care for a plot" % getCharacter("MTlani").himHer(),"carefor_menu")
	
	if empties:
		saynn("[say=a]i can see you've%s got %s here. now i ain't gonna waste my time growing regular ol' crops here, but if ya find anythin' interesting out there, maybe in them old mines under the prison, we can see about planting somethin' or another there[/say]" % [ " also" if frees else "", Util.multipleOrSingularEnding(empties.size(), "an empty one", "%s empty ones" % empties.size()) ])
		
		addButton("Plant uniques","","plantunique")
	
	saynn("[say=a]so, whaddaya say?[/say]")
	

func careForMenu() -> void: # carefor_menu state
	addButton("Nevermind","You changed your mind","")
	
	var plots = plantsSM.getPlots()
	for plot in plots:
		if !plot.hasPlant():
			continue
		
		var plant = getPlant(plot.plantID)
		if !plant:
			continue
		
		var daysleft = plant.growthTime - plot.grownDays
		
		if daysleft>(1+int(plot.watered)) && !plantsSM.isPlotDead(plot) && plot.yeen:
			var descText = ("\n\n%s" % plant.desc)
			
			var price = daysleft * plant.pricePerDay
			
			saynn("%s: %s %s for %s %s" %  [  plant.name, price, Util.multipleOrSingularEnding(price, "credit"), daysleft, Util.multipleOrSingularEnding(daysleft, "day")  ]  )
			
			if GM.pc.getCredits() < price:
				addDisabledButton("Care for %s" % plant.name, "You don't have enough credits (%s needed)%s" % [price, descText])
			else:
				addButton("Care for %s" % plant.name,"Pay %s %s %s to care for this plot%s" % [ getCharacter("MTlani").himHer(), price, Util.multipleOrSingularEnding(price, "credit"), descText], "doCareFor", [plot, price] )

func plantUniques() -> void: # plantunique state
	var hasone = false
	addButton("Nevermind", "You changed your mind", "")
	
	for seedi in GM.pc.getInventory().getAllOf("MDCC_Seed"):
		var seedPlant = getPlant(seedi.seedType)
		if !seedPlant:
			continue
		
		if seedPlant.rarity==0:
			hasone = true
			
			var cost = seedPlant.pricePerDay * seedPlant.growthTime
			
			saynn("%s cost: %s %s" % [ seedi.seedName, cost, Util.multipleOrSingularEnding(cost, "credit") ])
			
			if seedi.description:
				saynn("[i]%s[/i]\n" % seedi.description)
			
			if GM.pc.getCredits()<cost:
				addDisabledButton("Plant %s" % seedi.seedName, "You don't have enough credits for that")
			else:
				addButton("Plant %s" % seedi.seedName,"Plant one of those%s" % ("\n\n%s" % seedi.description if seedi.description else ""),"doplantUnique", [seedi.uniqueID, cost])
	
	if hasone:
		saynn("[say=a]so, which one'll it be?[/say]")
	else:
		saynn("[say=a]mate, how do ya expect me ter plant somethin' ya don't even have?[/say]")


func colorText(txt:String,col:Color) -> String: # easier formatting
	return "[color=#%s]%s[/color]" % [col.to_html(), txt]

func _run():
	if(state == ""):
		addButton("Step away", "", "endthescene")
		
		listAllPlots()
	elif state == "plantunique":
		plantUniques()
	
	elif state == "postplant":
		var lastPlant = getPlant(lastPlantID)
		if !lastPlant:
			return
		saynn("{a.Name} planted a %s yippee" % lastPlant.name)
		if lastPlant.desc:
			saynn("[i]%s[/i]" % lastPlant.desc)
		addButton("okie dokie", "wahoo", "")
	
	elif state == "carefor_menu":
		careForMenu()
	
	elif state == "doCareFor":
		saynn("[say=a]Alright, I'll take good care of this %s[/say]" % getPlant(lastPlantID).name)
		
		addButton("Okay", "", "")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	elif _action=="doplantUnique":
		var plots = plantsSM.getPlots()
		for plot in plots:
			if plots.hasPlant():
				continue
			var item = GM.pc.getInventory().getItemByUniqueID(_args[0])
			if item:
				plot.plantID = item.seedType
				plot.grownDays = 0
				plot.neglect = 0
				plot.harvestsDone = 0
				plot.watered = false
				plot.yeen = true
				
				item.removeXOrDestroy(1)
				GM.pc.addCredits(-_args[1])
				addMessage("You paid %s %s" % [ _args[1], Util.multipleOrSingularEnding(_args[1], "credit") ] )
				lastPlantID = item.seedType
			else:
				addMessage("this shouldn't ever happen but the seed item wasn't found, sorry :P")
			
			setState("postplant")
			return
	
	elif _action == "doCareFor":
		var plotObj = _args[0]
		var price = _args[1]
		
		lastPlantID = plotObj.plantID
		GM.pc.addCredits(-price)
		addMessage("You paid {a.name} %s %s to care for %s" % [ price, Util.multipleOrSingularEnding(price, "credit"), getPlant(lastPlantID).name ] )
		
		
		plotObj.yeen = true
	
	
	setState(_action)

func saveData() -> Dictionary:
	var d = .saveData()
	d["lastPlantID"] = lastPlantID
	return d

func loadData(d):
	.loadData(d)
	lastPlantID = SAVE.loadVar(d,"lastPlantID","")
	

