extends SceneBase

func _init():
	sceneID = "MDCC_CratePickupScene"

func _run():
	if state=="":
		var c = getModuleFlag("MDCC", "CratesOpened", 0)
		
		var foundTexts = [
			"Huh, a crate",
			"Another crate?",
			"Another crate again!? What's going on here?",
		]
		
		var ftxt : String = foundTexts[c] if c<foundTexts.size() else "A crate? (invalid idx)"
		
		saynn("[say=pc]%s[/say]" % ftxt)
		
		addButton("Search", "Search the crate", "pickup")
	
	elif state == "pickup":
		saynn("You opened the crate.")
		addButton("Continue", "", "endthescene")


func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	
	if _action=="pickup":
		var c = getModuleFlag("MDCC", "CratesOpened", 0)
		
		var ids = getModule("MDCC").getCrateWeapons()
		var itid : String = ids[c] if c<ids.size() else ""
		if itid:
			var it = GlobalRegistry.createItem(itid)
			GM.pc.getInventory().addItem(it)
			addMessage("You got %s" % it.getAStackName())
		else:
			addMessage("You found nothing")
		increaseModuleFlag("MDCC", "CratesOpened", 1)
		# no return, goes to pickup state
	
	setState(_action)
	
