extends SceneBase

var scenePath : String = ""
var roomID : String =""
var scene : SceneBase = null

func _init():
	sceneID = "MDCC_RoguelikeEventWrapper"

func _initScene(_args = []):
	if _args.size()>1:
		roomID = _args.pop_front()
		scenePath = _args.pop_front()
		scene = load(scenePath).new()
		add_child(scene)
		scene._initScene(_args)
		scene.connect("sceneEnded", self, "childSceneEnded")
	

func childSceneEnded(_result):
	sceneEndedFlag = true
	if  !_result or not "keepme" in _result:
		removeRoguelikeEvent()
	
	GM.main.removeScene(self)
	
	emit_signal("sceneEnded", sceneEndedArgs)
	
	queue_free()

func removeRoguelikeEvent():
	var rogue = getModule("MDCC").getSubmodule("Roguelike")
	var entry = rogue.getEntryForRoomID(roomID)
	if entry:
		entry.data.erase("event")

func run():
	if sceneValid():
		scene.run()
		sceneEndedFlag = scene.sceneEndedFlag
	checkSceneEnded()

func setState(newState: String):
	if sceneValid():
		scene.setState(newState)

func addItemToSavedItems(theItem):
	if sceneValid():
		scene.addItemToSavedItems(theItem)
		sceneSavedItemsInv = scene.sceneSavedItemsInv

func getState() -> String:
	if sceneValid():
		return scene.state
	return state

func resolveCustomCharacterName(_charID):
	if sceneValid():
		return scene.resolveCustomCharacterName(_charID)
	return null

func supportsBattleTurns():
	if sceneValid():
		return scene.supportsBattleTurns()
	return false

func supportsSexEngine():
	if sceneValid():
		return scene.supportsSexEngine()
	return false

func getDebugActions():
	if sceneValid():
		return scene.getDebugActions()
	return []

func doDebugAction(_id, _args = {}):
	if sceneValid():
		scene.doDebugAction(_id,_args)

func getSceneCreator():
	if sceneValid():
		return scene.getSceneCreator()
	
	return null

func checkSceneEnded():
	if sceneValid() && !sceneEndedFlag:
		scene.checkSceneEnded()
#		sceneEndedArgs = scene.sceneEndedArgs
		sceneEndedFlag = scene.sceneEndedFlag
	else:
		childSceneEnded([])

func addCharacter(id: String, variant: Array = []):
	if sceneValid():
		scene.addCharacter(id,variant)
		currentCharactersVariants = scene.currentCharactersVariants

func removeCharacter(id: String):
	if sceneValid():
		scene.removeCharacter(id)
		currentCharactersVariants = scene.currentCharactersVariants

func hasCharacter(id: String):
	if sceneValid():
		return scene.hasCharacter(id)
	return false

func updateCharacter():
	if sceneValid():
		scene.updateCharacter()

func clearCharacter():
	if sceneValid():
		scene.clearCharacter()
		currentCharactersVariants = scene.currentCharactersVariants

func setCharactersEasyList(newChars:Array):
	if sceneValid():
		scene.setCharactersEasyList(newChars)
		currentCharactersVariants = scene.currentCharactersVariants

func _onSceneEnd():
	if sceneValid():
		scene._onSceneEnd()

func markShownDevCommentary():
	if sceneValid():
		scene.markShownDevCommentary()
		showedDeveloperCommentary = scene.showedDeveloperCommentary

func shouldShowDevCommentaryIcon():
	return scene.shouldShowDevCommentaryIcon() if sceneValid() else false

func shouldDisplayBigButtons():
	return scene.shouldDisplayBigButtons() if sceneValid() else false

func getSceneCompanions():
	return scene.getSceneCompanions() if sceneValid() else []

func isSpyingOnInteractionsWith(_charID:String):
	return scene.isSpyingOnInteractionsWith(_charID) if sceneValid() else false

func supportsShowingPawns() -> bool:
	return scene.supportsShowingPawns() if sceneValid() else false

func sceneValid() -> bool:
	return scene && is_instance_valid(scene)

func getDevCommentary():
	return scene.getDevCommentary() if sceneValid() else null

func _react(_action: String, _args):
	if sceneValid():
		scene._react(_action,_args)
		return
	
	if(_action == "endthescene"):
		endScene()
		return
	
	setState(_action)

func friskPlayer():
	if sceneValid():
		return scene.friskPlayer()
	return false

func saveData():
	var d = .saveData()
	d["scenePath"] = scenePath
	d["roomID"] = roomID
	if sceneValid():
		d["state"]=scene.state
		d["sceneData"] = scene.saveData()
	return d

func loadData(d):
	Util.delete_children(self)
	.loadData(d)
	scenePath = SAVE.loadVar(d, "scenePath", "")
	roomID = SAVE.loadVar(d, "roomID", "")
	if scenePath:
		scene = load(scenePath).new()
		add_child(scene)
		scene.loadData(SAVE.loadVar(d, "sceneData", {}))
		scene.connect("sceneEnded", self, "childSceneEnded")
