extends SceneBase

var lastState = ""
var enemyid = ""

func resolveCustomCharacterName(_charID):
	if _charID=="enemy":
		return enemyid
	return null

func _init():
	sceneID = "MDCC_RoguelikeFightScene"

func _run():
	if(state in ["go",""]):
		if !hasCharacter(enemyid):
			var fl = int(getModuleFlag("MDCC","RoguelikeFloor",1))
			var npcgen = (InmateGenerator if fl<30 else GuardGenerator).new()
			var npc = npcgen.generate({NpcGen.Temporary:true, NpcGen.Level:fl})
			
			npc.npcLootOverride = {
				"baseTableID":"roguelikeEnemy",
			}
			
			enemyid = npc.id
			addCharacter(npc.id)
		saynn("{enemy.Name} jumps out from the shadows!")
		addButton("Fight","","encounter")
	
	
	# lose
	elif(state == "lostpain"):
		saynn("You succumb to your wounds...")
		addButton("Continue","","endthescene")
	
	elif state == "lostlust":
		saynn("")
		addButton("Continue","","endthescene")
	
	elif state == "lostsurrendered":
		saynn("You surrender to {enemy.name}. {enemy.HeShe} {enemy.verb('knock')} you out when you least expect it, and everything turns dark...")
		addButton("Continue","","endthescene")
	
	
	# win
#	elif(state == "wonpain"): # reenable with the others
	elif state.begins_with("won"):
		saynn("After you manage to defeat {enemy.name}, {enemy.heShe} {enemy.isAre} lost in the shadows...")
		addButton("Continue","","endthescene")
	
	
	### TODO: fill out and reenable
#	elif state == "wonlust":
#		addButton("Continue","","endthescene")
#
#	elif state == "wonsurrendered":
#		addButton("Continue","","endthescene")

func _react(_action: String, _args):
	if _action in ["go",""]:
		return
	if(_action == "endthescene"):
		var ar = Array(lastState.split(",",false))
		ar.resize(2)
		removeCharacter(enemyid)
		endScene(ar)
		
		var roguelike = getModule("MDCC").getSubmodule("Roguelike")
		if ar[0]=="lost": # pc lost
			match ar[1]: # valid vales are: pain, lust, surrendered
#				"pain": # beat up
				"lust":
					roguelike.removeRunItems()
					if getFlag("FightClubModule.BulldogBypassed"): # slutwall access
						GM.pc.setLocation("fight_slutwall")
						GM.main.IS.startInteraction("InSlutwall", {inmate="pc"})
					else:
						GM.pc.setLocation("main_punishment_spot")
						GM.main.IS.startInteraction("InStocks", {inmate="pc"})
					
				_: # default fallback
					roguelike.doDie()
				
		
		return
	if _action=="encounter":
		GM.main.playAnimation(StageScene.Duo, "stand", {npc=enemyid})
		runScene("FightScene", [enemyid], "MDCC_RoguelikeFight")
		return
		
	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "MDCC_RoguelikeFight"):
		processTime(30 * 60)
		var battlestate = _result[0]
		
		lastState = "%s,%s" % _result
		
		if(battlestate == "win"):
			setState("won%s" % _result[1])
			addExperienceToPlayer(50)
		else:
			setState("lost%s" % _result[1])
			addExperienceToPlayer(20)

func saveData():
	var d = .saveData()
	d["lastState"] = lastState
	d["enemyid"] = enemyid
	return d

func loadData(d):
	.loadData(d)
	lastState = SAVE.loadVar(d,"lastState","")
	enemyid = SAVE.loadVar(d,"enemyid","")
