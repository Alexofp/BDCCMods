extends SceneBase

func _init():
	sceneID = "MDCC_RoguelikeResumeScene"

func _run():
	if state == "":
		playAnimation(StageScene.Solo, "stand", {pc="pc"})
		saynn("You descend down into the bowels of the abandoned mines...")
		
		if int(getModuleFlag("MDCC", "RoguelikeFloor", 1)-1) % 5:
			
			saynn("Along the spiral staircase the all-familiar light fixture is broken inside its cage. A small lantern's warm light illuminates an old, rusted metal door fitted crudely into the wall. It has a metal mesh in the middle at about eye level, but looking inside from it leads nowhere; it's been boarded up from inside.")
			
			saynn("Some kind of insulating paste has been liberally applied to the sides of the doorframe, patching any would-be (and probably once-were) holes in the wall. There's a sign right next to the door, the word \"Store\" burned into its wood surface.")
			
			addButton("Enter", "Enter the store", "shop")
			addButton("Ignore it", "You're not interested in whatever's going on there", "endthescene")
		else:
			saynn("The spiral staircase takes you down, a dim sickly light %s." % ("sends shivers down your spine" if GM.pc.getPersonality().getStat(PersonalityStat.Coward) >= 0.5 else "shows the way"))
			
			addButton("Let's go", "Peep around the corner", "endthescene")
		
	
	elif state == "shop":
		addCharacter("MT_Astra")
		playAnimation(StageScene.Duo, "standing", {pc="pc", npc="MT_Astra"})
		
		saynn("A little bell gently rings as you enter the shop. The rock walls seem to be adorned with strings of mismatched lightbulbs, shining brightly. You see a figure passing by behind a half-open, weathered, wooden door in the back of the room. A large piece of rock has been carved into a shape roughly resembling a counter, an assortment of old colorful but faded blankets covering it.")
		
		sastra("Oh, hello! I'm your AlphaCorp-mandated roguelike shopkeeper. You might have also caught a glimpse of me working in the not-as-abandoned mines, but if you decide to spend any amount of time in this section we'll be seeing a whole lot of each other.")
		sastra("So, what's up?")
		
		addButton("See her wares", "ye", "do")
		addButton("Be on your way", "Say your farewells and go", "endthescene")
	

func sastra(txt:String) -> void:
	saynn("[say=MT_Astra]%s[/say]" % txt)

func _react(_action: String, _args):
	if(_action == "endthescene"):
#		GM.pc.setLocation("mdcc_mines_rogueEntrance")
		var rl = getModule("MDCC").getSubmodule("Roguelike")
		rl.destroyWorld()
		rl.onEnter()
		rl.newRoguelikeEntry()
		
		GM.pc.setLocation("rogueOrigin")
		GM.world.highlightedRoom = null
		GM.main.aimCameraAndSetLocName(GM.pc.location)
		var ext = GlobalRegistry.getGameExtender("MDCC_RoguelikeEnemyExtender")
		if ext:
			for en in ext.enemies:
				en.createIcon(ext)
		endScene()
		return
	
	setState(_action)

