extends SubGameWorld


func _on_Room14_onEnter(room:GameRoom):
	room.addButton("Elevator", "Get back inside the elevator", "elevator")

func _on_Room14_onReact(room:GameRoom, key):
	if key=="elevator":
		room.runScene("ElevatorScene")


func _on_Room8_onEnter(room):
	room.addButton("Descend","Enter the abandoned mineshafts","enterRogue")

func _on_Room8_onReact(_room, key):
	if key=="enterRogue":
		GlobalRegistry.getModule("MDCC").getSubmodule("Roguelike").destroyWorld()
		GM.main.setModuleFlag("MDCC","RoguelikeFloor",1)
		GM.main.runScene("MDCC_RoguelikeResumeScene").sceneTag = "descend"
#		_room.addButton("amog","","do")
#	if key=="do":
#		GM.pc.setLocation("rogueOrigin")


func _on_Room6_onEnter(room):
	room.addButton("Go back","Go back through the hole in the wall","leaveOtherside")

func _on_Room6_onReact(_room, key):
	if key=="leaveOtherside":
		GM.pc.setLocation("mdcc_mines_explodey")


func _on_Room5_onEnter(room):
	if GM.main.getModuleFlag("MDCC", "HasRoguelikeAccess", false):
		room.saynn("There's a hole in the wall here that you can pass through.")
		room.addButton("Go through", "Go through the hole to the other side", "enterOtherside")
		return
	
	room.saynn("You feel like you could destroy this wall with some explosives.")
	if GM.pc.getInventory().hasItemID("MDCCexplosive"):
		room.addButton("Rig explosive", "Rig an explosive to blow the wall up", "blowup")
	else:
		room.addDisabledButton("Rig explosive", "You don't have any explosives")

func _on_Room5_onReact(_room, key):
	if key=="enterOtherside":
		GM.pc.setLocation("mdcc_mines_postExplodey")
	elif key == "blowup":
		GM.pc.getInventory().removeXOfOrDestroy("MDCCexplosive",1)
		_room.addMessage("You blew the wall up with an explosive")
		GM.main.setModuleFlag("MDCC","HasRoguelikeAccess",true)
	

