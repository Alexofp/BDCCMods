extends SubGameWorld

onready var rng = RandomNumberGenerator.new() # need our own rng for deterministic results, recreating levels when loading, etc.

var exit = "" # room id

var roguelike : Reference = GlobalRegistry.getModule("MDCC").getSubmodule("Roguelike")

class Walker: # look at me i suck at proc gen and use walkers all the time
	var pos : Vector2 = Vector2.ZERO
	var currentStepsBeforeTurning = 0
	var stepsToTurnRange = [5,8] # [min, max]
	var stepsToTurn = 0 # start with random direction
	var direction := Vector2.RIGHT # why not ig
	
	func move(rng:RandomNumberGenerator):
		if stepsToTurn<=currentStepsBeforeTurning:
			currentStepsBeforeTurning = 0
			stepsToTurn = rng.randi_range(stepsToTurnRange[0],stepsToTurnRange[1])
			turn(rng)
		
#		var ogpos = pos
		currentStepsBeforeTurning += 1
		pos += direction
		
		return pos
	
	func turn(rng:RandomNumberGenerator):
		var dirs = [
			Vector2.RIGHT, Vector2.UP, Vector2.DOWN, Vector2.LEFT,
		]
		dirs.erase(direction)
		direction = dirs[rng.randi_range(0,2)]



func clearWorld(): # destroy all tiles/rooms and clear data
	var w = GM.world
	var floorID = "RoguelikeFloor"
	
#	roguelike.clear()
	
	if(!w.cells.has(floorID)):
		return
	
	var floorcells = w.cells[floorID]
	
	for pos in floorcells.keys():
		var _room = floorcells[pos]
		
		w.roomDict.erase(_room.roomID)
		for otherRoomAStarID in _room.astarConnections:
			if(w.astar.has_point(otherRoomAStarID)):
				w.astar.disconnect_points(_room.astarID, otherRoomAStarID)
		
		w.astar.remove_point(_room.astarID)
		w.astarIDToRoomIDMap.erase(_room.astarID)
		
		_room.free() # needs to be here or it'll crash, this is really the only difference between this and the world's clearFloor function
	
	w.cells[floorID].clear()

func floorify(f:int=getFloor()) -> String: # 1st, 2nd, 3rd, 4th, etc. string based on int
	if f/10%10!=1: # second to last digit
		match f % 10: # last digit
			1:
				return "%sst" % f
			2:
				return "%snd" % f
			3:
				return "%srd" % f
	
	return "%sth" % f

func createWorld(worldSeed:="amogus") -> void:
	rng.seed = hash(worldSeed.get_slice(":",0))
	
	var mainWalker : Walker = Walker.new()
	mainWalker.stepsToTurnRange = [1,3]
	
	var worldSize = rng.randi_range(8,13) # tiles/steps
	var variationSize = rng.randi_range(1,4) # small walker steps
	var variations = rng.randi_range(2,4)
	
	var lastRoom = createRoom(mainWalker.pos*64)
#	lastRoom.roomDescription = "seeded %s, floor %s" % [worldSeed, getFloor()]
	
	var worldTypes = roguelike.getAllWorldTypes()
	
	var specialData = worldTypes.get(worldSeed.get_slice(":", 1), {})
	
	var specialDesc = specialData.get("text", "")
	
	
	lastRoom.roomDescription = "There's a bit of light on the stairs behind you, leading up to the mineshaft's entrance. You're currently on the %s floor.%s" % [floorify(), "\n\n"+specialDesc if specialDesc else ""  ]
	
	lastRoom.roomColor = RoomStuff.RoomColor.Blue
	lastRoom.gridColor = RoomStuff.RoomColor.White
	
	
	var farthestPos = mainWalker.pos
	
	for i in worldSize:
		var pos = mainWalker.move(rng)*64
		connectRoomToPos(lastRoom,pos)
		var lrPos = lastRoom.position
		lastRoom = createRoom(pos)
		
		connectRoomToPos(lastRoom,lrPos)
		
		if pos.distance_squared_to(Vector2.ZERO) > farthestPos.distance_squared_to(Vector2.ZERO):
			farthestPos = pos
	
	
	for v in variations:
		var varWalker : Walker = Walker.new()
		varWalker.pos = get_children()[rng.randi() % get_child_count()].position/64
		
		varWalker.stepsToTurnRange = [1,3]
		
		for i in variationSize:
#			varWalker.move(rng)
			var pos = varWalker.pos*64
			connectRoomToPos(lastRoom,pos)
			var lrPos = lastRoom.position
			
			lastRoom = createRoom(varWalker.pos*64)
			connectRoomToPos(lastRoom,lrPos)
			
			if pos.distance_squared_to(Vector2.ZERO) > farthestPos.distance_squared_to(Vector2.ZERO):
				farthestPos = pos
			
			varWalker.move(rng)
	
	var room = createRoom(farthestPos)
	
	room.roomColor = RoomStuff.RoomColor.Yellow
	room.roomSprite = RoomStuff.RoomSprite.STAIRS
	exit = room.roomID
	
	
	var events = specialData.get("events",[])
	if specialData.get("parentWorldType",null) != null: # inherit parent world type events
		events.append_array(worldTypes.get(specialData["parentWorldType"]).get("events", [] ) )
	
	postCreate(events)
	
	GM.world.addTransitions(["RoguelikeFloor"])
	
#	GM.main.reRun()

func convertToLootRoom(room:GameRoom) -> void:
	var entry = roguelike.getEntryForRoomID(room.roomID)
	if !entry:
		entry = roguelike.RoomEntry.new()
		entry.roomID = room.roomID
		roguelike.addEntryDirect(entry)
	if entry.data.get("lootState", null)==null:
		entry.data["lootState"] = 1 # 0=unlootable, 1=not looted, 2= looted
	room.roomColor = RoomStuff.RoomColor.Green
	room.gridColor = RoomStuff.RoomColor.White

func convertToHackRoom(room:GameRoom) -> void:
	var entry = roguelike.getEntryForRoomID(room.roomID)
	if !entry:
		entry = roguelike.RoomEntry.new()
		entry.roomID = room.roomID
		roguelike.addEntryDirect(entry)
	
	if entry.data.get("hackState", null)==null:
		entry.data["hackState"] = 1 # 0=unlootable, 1=not looted, 2= looted
	room.roomColor = RoomStuff.RoomColor.Blue
	room.gridColor = RoomStuff.RoomColor.White
#	room.roomSprite = RoomStuff.RoomSprite.Computer
	
	



func postCreate(events:Array=[]) -> void: # special events are pupulated from special seeds
	var avails = [] # array of gamerooms, these are available to edit/transform
	for roomnode in get_children():
		if not roomnode.roomID in [exit,"rogueOrigin"]: # as long as it's not taken pretty much
			avails.append(roomnode)
	
	var lootChances = [
		[1,50],
		[0,40],
		[2,10],
	]
	
	for i in pickWeightedPairs(lootChances):
		if avails.empty():
			break
		var chosen : int = rng.randi() % avails.size()
		convertToLootRoom(avails[chosen])
		avails.remove(chosen)
	
	
	var hackChances = [
		[1,50],
		[0,40],
		[int(avails.size()*0.1), 10], # idk
	]
	
	for i in int(pickWeightedPairs(hackChances)*0): # TODO: reenable when hacking's done
		if avails.empty():
			break
		var chosen : int = rng.randi() % avails.size()
		convertToHackRoom(avails[chosen])
		avails.remove(chosen)
		
	
	var eventPairs = getAvailableEvents(events)
	
	var maxEvents : int = 3
	
	for i in int(min(eventPairs.size(),maxEvents)):
		var picked = pickWeightedPairs(eventPairs,true)
		var chosenRoom : int = rng.randi() % avails.size()
		
		var entry = roguelike.getEntryForRoomID(avails[chosenRoom].roomID)
		if !entry:
			entry = roguelike.RoomEntry.new()
			entry.roomID = avails[chosenRoom].roomID
			roguelike.addEntryDirect(entry)
		if entry.data.get("event", null)==null:
			entry.data["event"] = picked
		
		avails.remove(chosenRoom)
	

func getAvailableEvents(events:Array) -> Array: # runs every time we create. runs events' chances and returns weighted pairs
	var res : Array = [] # array of [scenePath,weight]
	
	for entry in events: # expects array of [scenePath, weight, chance]
		if entry.size()>=3 && rng.randf_range(0.0, 100.0) < entry[2]: # valid & will appear
				res.append([entry[0],entry[1]]) # add entry's scenePath & weight
	
	
	return res

func pickWeightedPairs(ar: Array,grabMode:bool=false): # gotta do it, copied from RNG and uses our rng object to always generate the same things with the same seed
	if(ar.empty()):
		return null
		
	var sum = 0.0
	for pair in ar:
		sum += max(pair[1], 0.0)
		
	var r:float = rng.randf_range(0.0, sum)
	for i in range(ar.size()):
		r -= max(ar[i][1], 0.0)
		if r <= 0.0:
			var res = ar[i][0]
			if grabMode:
				ar.remove(i)
			return res
	
	var res = ar[0][0]
	if grabMode:
		ar.remove(0)
	return res


func connectRoomToPos(room:GameRoom,pos:Vector2):
	match room.position.direction_to(pos): # this sucks
		Vector2.RIGHT:
			room.canEast = true
		Vector2.LEFT:
			room.canWest = true
		Vector2.UP:
			room.canNorth = true
		Vector2.DOWN:
			room.canSouth = true


func onGenericRoomEnter(_room:GameRoom):
	var ext = GlobalRegistry.getGameExtender("MDCC_RoguelikeEnemyExtender")
	if ext:
		var enm = ext.getEnemiesInLoc(GM.pc.location)
		if enm:
			if RNG.chance(pow(0.1, enm.size())*100): # won't get seen rarely
				return
			for scene in GM.main.sceneStack:
				if scene.sceneID in ["FightScene", "MDCC_RoguelikeFightScene", "MDCC_RoguelikeResumeScene"]: # these scenes won't trigger attacks
					return
			
			GM.world.highlightedRoom = null # crashes otherwise i think
			GM.world.aimCamera(GM.pc.location, false)
			
			_room.runScene("MDCC_RoguelikeFightScene")
			ext.killEnemyObject(enm.back())
			GM.main.runCurrentScene()
			return
	
	if _room.roomID=="rogueOrigin":
		_room.addButton("Ascend","Go back up","gobacknow")
		_room.saynn("You can go back to the abandoned mines floor here")
		return
	if _room.roomID==exit:
		_room.addButton("Descend","Go deeper into the mineshafts","descend")
		_room.saynn("You can go further down here")
	
	var lentry = roguelike.getDataKeyForEntry(_room.roomID, "lootState", 0)
	if lentry==2:
		_room.saynn("This room has already been looted")
	elif lentry==1:
		_room.saynn("There's loot here")
		_room.addButton("Loot", "", "loot")
	
	lentry = roguelike.getDataKeyForEntry(_room.roomID, "hackState", 0)
	if lentry==2: # hacked
		_room.saynn("This room's terminal has already been hacked")
	elif lentry==1:
		_room.saynn("This room has a terminal you can hack")
		_room.addButton("Try to hack", "", "hack")
		
	

func onGenericRoomReact(_room:GameRoom,key):
	if key=="gobacknow":
		GM.pc.setLocation("mdcc_mines_rogueEntrance")
		return
	elif key=="descend":
		increaseFloor(1)
		GM.main.runScene("MDCC_RoguelikeResumeScene")
	elif key=="loot":
		lootRoom(_room)
		
	elif key=="hack": # TODO: make
		
		pass # add minigame here

func lootRoom(room:GameRoom) -> void:
	var _lootlist = GlobalRegistry.createLootTable("roguelikeLoot")
	
	var loot = _lootlist.generateAndCreateItems()
	var its = loot.get("items",[])
	var creds = loot.get("credits", 0)
	if its.empty() && creds<1:
		GM.main.addMessage("You found nothing of value.")
	else:
		if creds>0:
			GM.pc.addCredits(creds)
			GM.main.addMessage("You looted %s %s" % [creds, Util.multipleOrSingularEnding(creds,"credit")])
		for item in its:
			GM.main.addMessage("You looted %s" % item.getAStackName())
			
			addLootedItemToPc(item)
	
	var entry = roguelike.getEntryForRoomID(room.roomID)
	if entry:
		entry.data["lootState"] = 2

func addLootedItemToPc(item:ItemBase) -> void:
	var inv = GM.pc.getInventory()
	var lamount = item.getAmount()
	# whyyyyy does additem not return combined item????
	if(item.canCombine()):
		for myitem in inv.items:
			if(myitem.id == item.id):
				if(myitem.tryCombine(item)):
					roguelike.addRunItem(myitem.uniqueID, lamount)
					return
		
	inv.items.append(item)
	item.currentInventory = inv
	roguelike.addRunItem(item.uniqueID, lamount)

func createRoomId(pos):
	var id = "%s,%s" % [pos.x, pos.y] if pos else "Origin"
	var nid = "rogue%s" % str(id)
	return nid

func createRoom(pos:Vector2) -> GameRoom:
	
	var nid = createRoomId(pos)
	
	var oldr = get_node_or_null(nid)
	if oldr:
		return oldr
	
	var nr : GameRoom = load("res://Game/World/GameRoom.tscn").instance()
	nr.roomID = nid
	nr.roomName = "Abandoned Mineshaft"
	
	var roomDescriptions = getGenericRoomDescriptions()
	
	nr.roomDescription = roomDescriptions[rng.randi() % roomDescriptions.size()]
	nr.position = pos
	nr.name = nr.roomID
	nr.scale = Vector2.ONE*0.5
	nr.setRoomColor(RoomStuff.RoomColor.LightGrey)
	nr.gridColor = RoomStuff.RoomColor.Grey if rng.randi_range(0,1) else RoomStuff.RoomColor.White
	
	nr.canWest = false
	nr.canSouth = false
	nr.canNorth = false
	nr.canEast = false
	
#	nr.connect("onPreEnter",self,"onGenericRoomPreEnter")
	nr.connect("onEnter",self,"onGenericRoomEnter")
	nr.connect("onReact",self,"onGenericRoomReact")
	
	add_child(nr)
	GM.world.registerRoom("RoguelikeFloor",nr)
	return nr

func getGenericRoomDescriptions() -> Array:
	return [
		"There's a lotta rock here.",
		"There's a bit of ore shining in a crevice in the wall here.",
		"The rocky ground's more uneven here than you expected.",
		"A forgotten %s lies against the wall here." % ["pickaxe", "shovel"][rng.randi() % 2],
	]

func onPcLocChanged(newloc:String):
	var room = GM.world.getRoomByID(newloc)
	if !room:
		return
	if room.getFloorID()!="RoguelikeFloor":
		return # abort
	
	var lentry = roguelike.getDataKeyForEntry(newloc, "event", "")
	if lentry: # has event
		for scene in GM.main.sceneStack: # this fucking sucks but it should fix loading creating more scenes than needed
			if scene.sceneID in ["MDCC_RoguelikeEventWrapper", "MDCC_RoguelikeResumeScene"]:
				return # abort
		room.runScene("MDCC_RoguelikeEventWrapper", [newloc,  lentry])
		return
	


func getFloor() -> int:
	return int(GM.main.getModuleFlag("MDCC", "RoguelikeFloor", 0))

func increaseFloor(amount:int=1) -> void:
	GM.main.increaseModuleFlag("MDCC", "RoguelikeFloor", amount)

func setFloor(amount:int=0) -> void:
	GM.main.setModuleFlag("MDCC", "RoguelikeFloor", amount)

