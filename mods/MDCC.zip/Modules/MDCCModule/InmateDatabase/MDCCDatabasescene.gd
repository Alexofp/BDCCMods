extends SceneBase

func _init():
	sceneID = "MDCC_DatabaseScene"

func _run():
	if(state == ""):
		saynn("You find a console hooked up to the BDCC system. There's a post-it note on the corner of the monitor, it reads:")
		
		saynn("[i]The address for the admin server is 127.0.246 since I know you will forget Valarie\n[right]-Roach[/right][/i]")
		
		saynn("Do you want to access it?")
		
		addButton("new", "", "new")
		addButton("new al1", "", "new2")
		addButton("Access", "Log into the BDCC console", "screen")
		addButton("Leave", "Walk away from the console", "endthescene")
		
	if(state == "after_completed"):
		saynn("You step back from the console.")
		
		addButton("Continue", "End the test scene", "endthescene")
	
	if state == "new":
		var db = load("res://Modules/MDCCModule/InmateDatabase/DatabaseUI.tscn").instance()
		GM.ui.addFullScreenCustomControl("database", db)
		addButton("ok", "", "")
	if state == "new2":
		var db = load("res://Modules/MDCCModule/InmateDatabase/DatabaseUI.tscn").instance()
		db.accessLevel = 1
		GM.ui.addFullScreenCustomControl("database", db)
		addButton("ok", "", "")

func _react(_action: String, _args):
	if(_action == "screen"):
		# Launch the BDCC computer here
		runScene("ComputerSimScene", ["MDCCDatabase"], "databaselookup")
		setState("after_completed")
		return
	
	if(_action == "endthescene"):
		endScene()
		return
	
	if _action == "new":
		pass
	
	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "databaselookup"):
		# This runs after the computer closes 
		processTime(5*60)
		setState("after_completed")
