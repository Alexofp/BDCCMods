extends NetworkedComputerBase



var MDCC : Module = null
var Database : Reference




#################

func connectComputer(_args:Array=[]):
	if _args.size()!=1:
		return "'connect' expects 1 argument"
	var res = "Connecting to "+_args[0]+"..."
	var newServer = getServer(_args[0])
	if newServer:
		res += " Connected!\n"+newServer.enterText
		connectedTo = _args[0]
		if connectedTo == "127.0.246":
			Database = MDCC.getSubmodule("Database")
			Database.popAllProfiles()
		elif connectedTo == "67.0.0":
			Database = MDCC.getSubmodule("StaffDatabase")
			Database.popAllProfiles()
	else:
		res += " Connection failed!"
	return res




func _init():
	id = "MDCCDatabase"
	
	if !GM.main: # we're being instantiated for registration purposes
		return
	
	MDCC = GlobalRegistry.getModule("MDCC")
	Database = MDCC.getSubmodule("Database")
	
	
	
	Database.popAllProfiles([Database.generatePlayerProfile()])
	
	# local cmds
	localCmds["id"] = "Displays details for a specific inmate by ID.\nSyntax: 'id <INMATE ID>'"
	localCmds["name"] = "Displays details for a specific inmate by name.\nSyntax: 'name <INMATE NAME>'"
	localCmds["exit"] = "Leaves the BDCC terminal entirely and returns to the standby state."
	
	
	# local server
	var localServer = NetworkedComputerServer.new("", ["connect","help","exit","ls","cat"], "Connected to local server\n\nType 'help' for available commands", false, {}, {}, "", "", [])
	
	var addressFile = newCompFile(
		"addresses.dat", "127.0.246: BDCC database server"
	)
	localServer.addFile(addressFile)
	
	
	# general staff server
	var generalStaffS = NetworkedComputerServer.new(
		"127.0.246", ["ls","help","connect","disconnect","exit","id","name"], "Welcome to BDCC Inmate Database.\nType 'help' to see available commands.", false, {}, {}, Database.accessLevelString(0), ""
	)
	
	# admin server
	var adminServer = NetworkedComputerServer.new(
		"127.0.255", ["help","connect","disconnect","exit","login"], "Welcome to BDCC Inmate Database.\nType 'help' to see available commands.", false, {}, {}, Database.accessLevelString(1), "", ["ls","id","name"]
	)
	
	
	var staffServer = NetworkedComputerServer.new(
		"67.0.0", ["ls","help","connect","disconnect","exit","id","name"], "Welcome to BDCC Staff Database.\nType 'help' to see available commands.", false, {}, {}, Database.accessLevelString(0), ""
	)
	
	
	# add servers
	servers = {
		localServer.ip: localServer,
		generalStaffS.ip: generalStaffS,
		adminServer.ip: adminServer,
		staffServer.ip:staffServer,
	}
	
	# discover needed chars
	var allcs = [str(GM.pc.getInmateNumber())]
	for prof in Database.inmatesProfiles:
		if shouldDisplayProfile(prof):
			var idVar = prof[Database.identifyingVar]
			allcs.append(idVar)
	
	discoverCharacters(allcs)


func getDiscoveredCharacters() -> Array: # returns array of identifyingVars
	return Database.getDiscoveredChars()

func discoverCharacters(chars:Array=[]) -> void: # chars is array of identifiable vars
	Database.discoverChars(chars)

func isCharacterDiscovered(idVar) -> bool:
	return bool(Database.getDiscoveredEntry(idVar))

func shouldDisplayProfile(profile:Array) -> bool: # for ease of access in case we need it anywhere else
	if !profile[Database.Vars.FLAG_ID]: # we got no flag, so they're fine to be displayed?
		return true
	
	if profile[Database.Vars.FLAG_ID] == "MDCC_Met":
		return MDCC.hasMet(profile[Database.Vars.CHARID])
	
	return GM.main.getModuleFlag(profile[Database.Vars.MODULE_ID], profile[Database.Vars.FLAG_ID], false)

func getAccessLevel() -> int: # access level replaces the old redacted/unredacted stuff; you can have as much/little information revealed as you want, in as many levels as you want
	if (connectedTo in ["127.0.255"]): # admin access, unredacted
		return 1
	return 0

# --- Profile display ---
func displayInmateProfile(profile:Array, accessLevel=0) -> String:
	if !shouldDisplayProfile(profile):
		return "There are a few names that show up, but no one you know."
	
	if !isCharacterDiscovered(profile[Database.identifyingVar]):
		discoverCharacters([profile[Database.identifyingVar]])
	
	
#	var panel = GM.ui.smartCharacterPanel
#	panel.clear()
#	panel.addCharacter(profile[Database.Vars.CHARID])
#	panel.artworkPanel.characterStatusGrid.hide()
	
	var varsToDisplay = [
		Database.Vars.INMATE_ID,
		Database.Vars.NAME,
		Database.Vars.INMATE_TYPE,
		Database.Vars.GENDER,
		Database.Vars.SPECIES,
		
		Database.Vars.AGE,
		Database.Vars.HEIGHT,
		Database.Vars.WEIGHT,
		
		Database.Vars.DESCRIPTION,
		
		Database.Vars.DETAINMENT_PROCS,
		
		Database.Vars.CRIMES,
		Database.Vars.ORIGIN,
		
	]
	
	var c = GM.main.getCharacter("MDCC_FakeCharacter")
	if c:
		var nid : String = profile[Database.Vars.CHARID] if profile.size()>Database.Vars.CHARID else ""
		c.setMimiced(nid)
		
	
	var panel = GM.ui.smartCharacterPanel
	var maxOtherPortraits = 0
	
	if panel.characters.size() <= maxOtherPortraits:
		panel.addCharacter("MDCC_FakeCharacter", [])
	
	elif "MDCC_FakeCharacter" in panel.characters.keys()[0] && panel.characters.size() > maxOtherPortraits+1:
		panel.removeCharacter("MDCC_FakeCharacter")
	
	
	return inmateProfile(profile, accessLevel, varsToDisplay)

func getProfileVariable(profile:Array, variable:int=Database.identifyingVar, accessLevel:int=0):
	return Database.getProfileVar(profile, variable, accessLevel)

# --- Profile template ---
func inmateProfile(profile:Array, accessLevel=0, displayedVars=Database.Vars.values()) -> String:
	var d = {
		TableMaker.TableVars.HEADERS: [["Property", 18, TableMaker.Alignments.RIGHT], ["Value", 48]],
		TableMaker.TableVars.CELLS: [],
		TableMaker.TableVars.TITLE: "BDCC Inmate Profile (%s)" % Database.accessLevelString(accessLevel),
		TableMaker.TableVars.VERBOSE: true,
	}
	
	var replacements = []
	replacements.resize(Database.Vars.size())
	
	replacements[Database.Vars.DETAINMENT_PROCS] = "Admin. Note"
	replacements[Database.Vars.INMATE_ID] = "Inmate ID" # capitalize the last letter
	
	
	for variable in displayedVars: # no longer has validity check, we expect the profile to always have the var.
		var string = replacements[variable] if replacements[variable] else Database.Vars.keys()[variable].capitalize() # convert our Database.Vars variables to a string, this could be done using a dictionary instead to customize the headers further
		d[TableMaker.TableVars.CELLS].append([string, (Database.inmateIdPrefix if variable == Database.Vars.INMATE_ID else "") +String(getProfileVariable(profile, variable, accessLevel))]) # finally, we append to our cells an array like so: [header string, profile variable (converted to string)]
	
	var v = TableMaker.make(d)
	
	
	return "[b][font=res://Modules/MDCCModule/Fonts/smallconsolefont_dense.tres]%s[/font][/b]" % v


func clearanceText() -> String:
	return "[Access Level: %s]\n" % Database.accessLevelString(getAccessLevel())


func ls(_args:Array=[]):
	if !connectedTo in ["127.0.255", "127.0.246", "67.0.0"]: # we are in a server that supports/should support files, so give em
		return .ls(_args)
	
	
	var currentServer = getServer(connectedTo)
	if !currentServer:
		return "ERROR: no connected server"
	
	if getDiscoveredCharacters().size() == 0:
		var d := {
			TableMaker.TableVars.HEADERS: [["Database error", 32]],
			TableMaker.TableVars.CELLS: [["No profiles found"]],
			TableMaker.TableVars.TITLE: "BDCC Inmate Records (%s)" % Database.accessLevelString(getAccessLevel()),
			
			}
		var table = TableMaker.make(d)
		return "[b][font=res://Modules/MDCCModule/Fonts/smallconsolefont_dense.tres]%s[/font][/b]" % table
	
	if(_args.size() != 0):
		return "'ls' command expects 0 arguments"
	
	var profs = []
	var headers = [
		[Database.Vars.INMATE_ID, 12, TableMaker.Alignments.CENTER],
		[Database.Vars.NAME, 12, TableMaker.Alignments.CENTER],
		[Database.Vars.SPECIES, 16, TableMaker.Alignments.CENTER],
		[Database.Vars.GENDER, 12, TableMaker.Alignments.CENTER],
	]
	
	for idVal in getDiscoveredCharacters():
		var prof = Database.getProfileIdxStrict(Database.sanitize(idVal))
		if prof == -1:
			continue
		var entry = Database.inmatesProfiles[prof]
		var nentry = []
		nentry.resize(headers.size())
		for headerIdx in headers.size():
			var variable = headers[headerIdx][0]
			nentry[headerIdx] = (Database.inmateIdPrefix if variable==Database.Vars.INMATE_ID else "")  +  str(Database.getProfileVar(entry, headers[headerIdx][0], ( 0 if variable == Database.secondaryIdentifiableVar else getAccessLevel()  )  ))
		profs.append(nentry)
	
	
	for headeri in headers.size():
		headers[headeri][0] = Database.Vars.keys()[ headers[headeri][0] ].capitalize()
	
	var d = {
		TableMaker.TableVars.HEADERS: headers,
		TableMaker.TableVars.CELLS: profs,
		TableMaker.TableVars.TITLE: "BDCC Inmate Records (%s)" % Database.accessLevelString(getAccessLevel()),
		TableMaker.TableVars.VERBOSE: false,
	}
	
	
	var res = TableMaker.make(d)
	
	return "[b][font=res://Modules/MDCCModule/Fonts/smallconsolefont_dense.tres]"+res+"[/font][/b]"
	
	


func help(_args:Array=[]):
	if _args.size()==1:
		if _args[0]=="ls" && connectedTo != "":
			return "Lists inmate records stored on the BDCC server."
	return .help(_args)

func localCmd_exit(_args:Array=[]) -> String:
	markFinished()
	var panel = GM.ui.smartCharacterPanel
	panel.removeCharacter("MDCC_FakeCharacter")
	return "Exiting terminal... returning to the control room."

func localCmd_id(_args):
	if _args.size()!=1:
		return "'id' command expects 1 argument"
	var idx = Database.getProfileIdx(str(_args[0]))
	if idx==-1:
		return "No inmate record found with inmate ID %s%s." % [Database.inmateIdPrefix, _args[0]]
	var prof = Database.inmatesProfiles[idx]
	return displayInmateProfile(prof, getAccessLevel())

func localCmd_name(_args):
	if _args.size()!=1:
		return "'name' command expects 1 argument"
	
	var sanitizedName = Database.sanitize(_args[0])
	if sanitizedName == Database.sanitize(GM.pc.getName()):
		var pcidx = Database.getProfileIdxStrict(str(GM.pc.getInmateNumber()))
		if pcidx != -1:
			return displayInmateProfile(Database.inmatesProfiles[pcidx], getAccessLevel())
	var idx = Database.getProfileIdxBasedOnSecondaryStrict(sanitizedName)
	if idx==-1:
		return "No inmate record found with that identifier."
	
	var profile = Database.inmatesProfiles[idx]
	
	return displayInmateProfile(profile,getAccessLevel())

func localCmd_login(_args):
	if _args.size()!=0:
		return "'login' command expects 0 arguments (external authentication)"
	
	var currentServer = getServer(connectedTo)
	
	if !currentServer:
		return "no current server"
	
	if currentServer.loggedin:
		return "Already logged in"
	
	if GM.main.getModuleFlag("MDCC", "VeyraServerAccess", false):
		currentServer.loggedin = true
		
		return "Logged in as admin successfully. Welcome, "+currentServer.username
	
	return "External authentication failed. Please contact your network admin"


func saveData():
	var d = .saveData()
	d["connectedTo"] = connectedTo
	
	return d

func loadData(d:Dictionary):
	connectedTo = SAVE.loadVar(d, "connectedTo", "")
	.loadData(d)


class TableMaker:
	const junction := "□" # where lines meet
	const lineChar := "═" # horizontal
	const separator := "║" # vertical
	enum Alignments { LEFT, CENTER, RIGHT }
	
	enum TableVars { TITLE, CELLS, VERBOSE, HEADERS }
	
	enum Levels {
		TOP, MIDDLE, BOTTOM
	}
	
	static func getCharForPosition(pos:Vector2) -> String: # autotiling
		var autotileArray = "╔╦╗╠╬╣╚╩╝"
		var idx = pos.y*3+pos.x
		if autotileArray.length()<=idx:
			return junction
		return autotileArray[idx]
	
	static func padString(string:String, length:int,alignment:int) -> String:
		match alignment:
			Alignments.LEFT:
				return string+" ".repeat( int(max(0,length-string.length())) )
			
			Alignments.RIGHT:
				return " ".repeat( int(max(0,length-string.length())) )+string
			
			Alignments.CENTER:
				var totalAvailLength : int = length-string.length() # avail spaces we should add
				if totalAvailLength<0: # would crash if we didn't return, due to the division below
					return string
				var startSpaceAmount = totalAvailLength/2 # we want it centered, so this is about how much space to the left
				return " ".repeat(startSpaceAmount) + string + " ".repeat(totalAvailLength-startSpaceAmount) # padding to the right might not be the same, so we subtract instead
		
		return string # in case of invalid alignment
		
	
	static func makeLine(length:int,level:int=Levels.TOP) -> String: # make uniform line, no junctions
		
		return getCharForPosition(Vector2(0,level)) + lineChar.repeat(int(max(0,length-2))) + getCharForPosition(Vector2(2,level))
	
	static func makeFooter(rowlengths:Array,level:int=Levels.TOP,insideLevel=null) -> String:
		var footer = getCharForPosition(Vector2(0,level)) # starting the footer, it'll always be a junction
		insideLevel = insideLevel if insideLevel!=null else level
		var rlsize = rowlengths.size()
		for i in rlsize:
			footer += lineChar.repeat(rowlengths[i])
			if i+1==rlsize: # end
				footer += getCharForPosition(Vector2(2,level))
			else:
				footer += getCharForPosition(Vector2(1,insideLevel))
		return footer
	
	static func make(data:Dictionary={}) -> String:
		
		var headers = data.get(TableVars.HEADERS,[]) # expecting array of [String (header name), int (field size), int (Alignment, optional) ]
		var cells = data.get(TableVars.CELLS,[]) # expecting array of arrays
		
		var verbose : bool = data.get(TableVars.VERBOSE,false) # if true, doesn't remove parentheses
		
		var res = ""
		var rowLengths = []
		for header in headers:
			if header.size()<2: # invalid
				continue # ignore header
			rowLengths.append(header[1]) # add the header's length to the list, for calculations & formatting the table based on which header the cell's value is
			res += separator+padString(header[0],header[1], (Alignments.LEFT if header.size()<3 else header[2]) ) # add to table string, pad  it, and add a separator
		res+=separator # end of table
		
		var footer = makeFooter(rowLengths,Levels.BOTTOM)
		res += "\n"+makeFooter(rowLengths,Levels.MIDDLE)
		
		var cellssize = cells.size()
		for cellIdx in cellssize:
			var cell = cells[cellIdx]
			var toProcess = cell.size()
			if toProcess!=headers.size(): # fewer or more values than we want
				continue # ignore this cell
			
			
			
			while toProcess>0: # autowrap values
				res += "\n"+separator # start a cell by moving down a line and adding a separator
				toProcess = cell.size() # we always start thinking we'll process every cell. can also be done another way, by incrementing it instead
				for valueIndex in toProcess: # index points to header and corresponding rowLength
					var alignment : int = headers[valueIndex][2] if headers[valueIndex].size()>2 else Alignments.LEFT
					var maxValueLength : int = rowLengths[valueIndex]
					var valueStr = cell[valueIndex].strip_edges().strip_escapes() # our value for the header of this cell
					if !verbose: # for full profiles, we want this info
						valueStr = valueStr.substr(0,int(max(-1,valueStr.find("(")-1))) # trim out anything after a parenthesis, otherwise leave it as is
					var offset = int(min(maxValueLength-1,valueStr.length())) # this is for autowrapping, where our new string will end
					var partialValue = valueStr.substr(0,offset).strip_edges() # our new value, which will be added to this line's text. it is partial for autowrapping purposes, yet again
					
					
					valueStr = valueStr.substr(offset,-1) # trim the original value, so we can autowrap that if needed later
					if !valueStr: # we're done, the next value we'd try to autowrap is empty, so we no longer need to process this
						toProcess -= 1 # decrement to not get stuck in an infinite loop
					
					var partialPadded = padString(partialValue,maxValueLength,alignment) # we pad it for formatting purposes
					
					res += partialPadded + separator # and add the value and a separator, moving on to the next value of the cell
					cell[valueIndex]=valueStr # update it so we can have the new value when autowrapping in the next loop, and to avoid an infinite loop again
			
			res += ("" if cellIdx+1<cellssize else "\n"+makeFooter(rowLengths,Levels.BOTTOM))
		
		
		
		var title = data.get(TableVars.TITLE) # get title or null
		
		res = makeFooter(rowLengths,Levels.MIDDLE if title else Levels.TOP,Levels.TOP)+"\n"+res+"\n" # finally, add footers to the top and bottom of the table, to have it nicely formatted. if you had a multi-page table, you could leave out the bottom footer and replace it with one that was like "|..........|" so it's visible that there's more, but such a case should be impossible for now
		
		
		if title:
			var titleStr = separator + padString(title,footer.length()-2,Alignments.CENTER) + separator # padding to the right might not be the same, so we subtract instead
			var startLine = makeLine(footer.length(),Levels.TOP) # make a line like the footer without most of the junctions other than the ones on the border
			res = startLine+"\n"+titleStr+"\n"+res
		
		
		return res

