extends ComputerBase

var connectedTo = ""
var discoveredInmates = []
# Debug for lazy peoples like me - Fox2Code
const debugAccessAll = false
# Static var ("const" in godot3) is only initialized once, and allow me to add my character to your mod database - Fox2Code
const inmatesProfiles = [
	# ["Inmate ID", "Name", "Species", "Gender", "Age",  # -- 0, 1, 2, 3, 4
	# "height", "weight", "desc", # -- 5, 6, 7
	# "Origin", "Inmate type", # -- 8, 9
	# "Crimes", # -- 10
	# "Special detainment procedures", # -- 11
	# "internalCharID", "ModuleID", "FlagID"  # -- 12, 13, 14
	# "unredacted origin", # -- 15
	# "unredacted crimes",], # -- 16
	["BDCC-21473", "Lani", "Shark", "Female", "27",
	"1.72m", "62kg", "desc",
	"Outer Rim Colony", "Low-Security (Orange Uniform Designation)",
	"Smuggling, Data Tampering",
	"[Standard monitoring protocols apply]",
	"lani", "MDCC", "Lani_Met"],
	["BDCC-22918", "Nala", "Feline", "Female (Hermaphroditic Traits: Negative)", "31",
	"1.65m", "58kg", "desc",
	"Federation Coreworld", "Low-Security (Orange Uniform Designation)",
	"Assault, Racketeering",
	"[Subject flagged for disciplinary review]",
	"nala", "MDCC", "Nala_Met", ],
	["BDCC-23604", "Nyx", "Feline", "Female (Hermaphroditic Traits: Positive)", "21",
	"2.05m", "95kg", "desc",
	"Unverified", "Low-Security (Orange Uniform Designation)",
	"Smuggling, Grand Larceny",
	"[Psychological evaluation required]",
	"nyx", "MDCC", "Nyx_Met"],
	["BDCC-25287", "Rena", "Canine (Hyaenidae Variant)", "Female (Hermaphroditic Traits: Negative)", "25",
	"1.9 meters (6'2\" Imperial Equivalent)", "90kg", "Feathered crest, sharp talons, piercing gaze",
	"Skyreach Spire", "High-Security (Red Uniform Designation)",
	"Assault, 2 Counts Manslaughter",
	"Combative tendencies with other High-Security inmates",
	"rena", "MDCC", "Rena_Met"],
	["BDCC-24927", "Veyra", "Canine (Lupine-Adapted Variant)", "Female (Hermaphroditic Traits: Negative)", "33",
	"2.1 meters (6'11\" Imperial Equivalent)", "115 kg (Predominantly Muscle Mass with Dense Fur Insulation)", "Grayish-White fur with darker accents on ears and below neck; violet eyes; elongated canine fangs and claws; muscular build optimized for extreme cold environments",
	"[color=#FF0000][REDACTED][/color]", "High-Security (Red Uniform Designation)",
	"[color=#FF0000][REDACTED][/color]",
	"[b]Extreme Risk of Violence[/b] - Avoid Direct Confrontation; [b][Federation Blackout Order 2512][/b] Official record sanitized to \"Treason\" [color=#FF0000]| Do not pursue further inquiries - Auto-Flag for Audit |[/color]",
	"veyra", "MDCC", "Veyra_Met",
	"[color=#FF0000][UNREDACTED][/color]",
	"[color=#FF0000][UNREDACTED][/color]"],
	["BDCC-26751", "Willow", "Lupine", "Female", "25",
	"1.68m", "60kg", "desc",
	"Unknown Syndicate Space", "Low-Security (Purple Uniform Designation)",
	"10 Counts Drug Trafficking",
	"[Routine observation]",
	"willow", "MDCC", "Willow_Met"],
]

func _init():
	id = "MDCCDatabaseOld"
	if debugAccessAll:
		discoveredInmates.append_array(inmatesProfiles)

# makes input so no spaces or caps mess up the database by adding to of them
func normalizeInmateKey(input:String) -> String:
	return input.strip_edges().capitalize()

# the general lookup function
func lookupInmateProfile(identifier:String):
	var key = normalizeInmateKey(identifier)
	var key2 = "BDCC-" + key
	var matchingProfile = null
	for inmateProfile in inmatesProfiles:
		var id = inmateProfile[0]
		if key == id or key2 == id or key == inmateProfile[1]:
			matchingProfile = inmateProfile
			break
	return matchingProfile

func lookupInmateProfileName(identifier:String):
	var key = normalizeInmateKey(identifier)
	var matchingProfile = null
	for inmateProfile in inmatesProfiles:
		if key == inmateProfile[1]:
			matchingProfile = inmateProfile
			break
	return matchingProfile

func lookupInmateProfileID(identifier:String):
	var key = normalizeInmateKey(identifier)
	var key2 = "BDCC-" + key
	var matchingProfile = null
	for inmateProfile in inmatesProfiles:
		var id = inmateProfile[0]
		if key == id or key2 == id:
			matchingProfile = inmateProfile
			break
	return matchingProfile

# --- Profile display ---
func displayInmateProfile(matchingProfile, unredacted=false) -> String:
	if matchingProfile == null:
		return "No inmate record found with that identifier."
	if not (GM.main.getModuleFlag(matchingProfile[13], matchingProfile[14], false) or debugAccessAll):
		return "There are a few names that show up, but no one you know."
	if not discoveredInmates.has(matchingProfile):
		discoveredInmates.append(matchingProfile)
	var origin = matchingProfile[8]
	var crimes = matchingProfile[10]
	if unredacted and matchingProfile.size() >= 17:
		origin = matchingProfile[15]
		crimes = matchingProfile[16]
	return inmateProfile(matchingProfile[0], matchingProfile[1], matchingProfile[2], matchingProfile[3],
		matchingProfile[4], matchingProfile[5], matchingProfile[6], matchingProfile[7],
		origin, matchingProfile[9], crimes, matchingProfile[11])

# --- Profile template ---
func inmateProfile(
	id:String, name:String,
	species:String, gender:String, age:String,
	height:String, weight:String,
	physicalDesc:String, origin:String,
	criminalClass:String, conviction:String,
	note:String
) -> String:
	return (
		"=== BDCC Inmate Profile ===\n"
		+ clearanceText()
		+ "---------------------------------------\n"
		+ "Inmate ID: " + id + "\n"
		+ "Name: " + name + "\n"
		+ "Species: " + species + "\n"
		+ "Sex/Gender: " + gender + "\n"
		+ "Age: " + age + "\n"
		+ "Height: " + height + "\n"
		+ "Weight: " + weight + "\n"
		+ "Physical Description: " + physicalDesc + "\n"
		+ "Origin: " + origin + "\n"
		+ "Criminal Classification: " + criminalClass + "\n"
		+ "Conviction Charges: " + conviction + "\n"
		+ "---------------------------------------\n"
		+ "Administrative Note: " + note + "\n"
		+ "=== END OF RECORD ==="
	)

# --- Save/load state ---
func saveData() -> Dictionary:
	# this calls the saveData()
	var data = .saveData()
	# what of my custom stuff that gets saved
	data["connectedTo"] = connectedTo
	data["discoveredInmates"] = discoveredInmates
	return data

func loadData(data:Dictionary) -> void:
	# this calls the loadData()
	.loadData(data)
	# what of my custom stuff that gets loaded
	if data.has("connectedTo"):
		connectedTo = data["connectedTo"]
	if data.has("discoveredInmates"):
		discoveredInmates = data["discoveredInmates"].duplicate()

# --- Main command ---
func clearanceText() -> String:
	var level = "General Staff" if connectedTo != "127.1.255" else "Administrator"
	return "[Access Level: %s Clearance]\n" % level

func reactToCommand(_command:String, _args:Array, _commandStringRaw:String):
	if(connectedTo == "127.0.246" or connectedTo == "127.1.255"):
		if(_command == "help"):
			if(_args.size() == 1):
				var tolearn = _args[0]
				if(tolearn == "help"):
					return "Outputs all available commands. You can also type 'help <COMMAND>' for details."
				elif(tolearn == "ls"):
					return "Lists inmate records stored on the BDCC server."
				elif(tolearn == "id"):
					return "Displays details for a specific inmate by ID.\nSyntax: 'id <INMATE ID>'"
				elif(tolearn == "name"):
					return "Displays details for a specific inmate by name.\nSyntax: 'name <INMATE NAME>'"
				elif(tolearn == "connect"):
					return "Connects to a remote host by IP.\nSyntax: 'connect <IP>'"
				elif(tolearn == "disconnect"):
					return "Disconnects from the current host but keeps you inside the BDCC console."
				elif(tolearn == "exit"):
					return "Leaves the BDCC terminal entirely and returns to the control room."
				else:
					return "Couldn't find command '"+str(tolearn)+"'. Type 'help' to see available commands."

			elif(_args.size() == 0):
				learnCommand("help")
				learnCommand("ls")
				learnCommand("id")
				learnCommand("name")
				learnCommand("connect")
				learnCommand("disconnect")
				learnCommand("exit")
				return "Available commands are: ls, id, name, connect, disconnect, help, exit.\nType 'help <COMMAND>' for details."

			else:
				learnCommand("help")
				return "'help' expects 0 or 1 arguments"

		if _command == "exit":
			markFinished()
			return "Exiting terminal... returning to the control room."

		if(_command == "disconnect"):
			if(_args.size() == 0):
				connectedTo = ""
				return "Disconnecting... Success"
			else:
				return "'disconnect' expects 0 arguments"

		if(_command == "ls"):
			if(_args.size() == 0):
				var output = "=== BDCC Inmate Records ===\n"
				output += clearanceText() #added by Fox2code
				output += "---------------------------------------\n" #might look jank? ill have to fiddle with it
				output += "ID         | Name     | Status\n"
				output += "-----------+----------+-----------------\n"

				for entry in discoveredInmates:
					var recordMessage = "[Record Available]"
					var idMessage = entry[0]
					var nameMesage = entry[1]
					if not (GM.main.getModuleFlag(entry[13], entry[14], false) or debugAccessAll):
						recordMessage = "[No Record Found]"
						idMessage = "?????     "
					while nameMesage.length() < 8:
						nameMesage = nameMesage + " "
					output += idMessage + " | " + nameMesage + " | " + recordMessage + "\n"
				if discoveredInmates.size() == 0:
					return "=== BDCC Inmate Records ===\nNo inmate records discovered yet."
				return output
			else:
				return "'ls' expects 0 arguments"

		if(_command == "id"):
			if(_args.size() == 1):
				return displayInmateProfile(lookupInmateProfileID(_args[0]), connectedTo == "127.1.255")
			else:
				return "'id' expects 1 argument"

		if(_command == "name"):
			if(_args.size() == 1):
				return displayInmateProfile(lookupInmateProfileName(_args[0]), connectedTo == "127.1.255")
			else:
				return "'name' expects 1 argument"

		# Unknown command or random typing gets this 
		return "Unknown command. Type 'help' for available commands."

	if(connectedTo == ""):
		if(_command == "connect"):
			if(_args.size() == 1):
				var server = _args[0]
				if(server == "127.0.246"):
					connectedTo = server
					return "Connecting to "+server+"... Connected!\nWelcome to BDCC Inmate Database.\nType 'help' to see available commands."
				elif(server == "127.1.255"):
					if not (GM.main.getModuleFlag("MDCC", "VeyraServerAccess", false) or debugAccessAll):
						return "Connecting to "+server+"... Connection failed!"
					connectedTo = server
					return "Connecting to "+server+"... Connected!\nWelcome to BDCC Inmate Database.\nType 'help' to see available commands."
				else:
					return "Connecting to "+server+"... Connection failed!"
			else:
				return "'connect' expects 1 argument"

		elif(_command == "help"):
			if(_args.size() == 1):
				var tolearn = _args[0]
				if(tolearn == "connect"):
					return "Connect to the BDCC servers by IP.\nSyntax: 'connect 127.0.246'"
				elif(tolearn == "exit"):
					return "Leaves the BDCC terminal entirely and returns to the standby state."
				elif(tolearn == "help"):
					return "Outputs all available commands. You can also type 'help <COMMAND>' for details."
				else:
					return "Couldn't find command '"+str(tolearn)+"'. Type 'help' to see available commands."
			elif(_args.size() == 0):
				learnCommand("help")
				learnCommand("connect")
				learnCommand("exit")
				return "Available commands are: connect, help, exit.\nType 'help <COMMAND>' for details."
			else:
				learnCommand("help")
				return "'help' expects 0 or 1 arguments"

		elif(_command == "exit"):
			if(_args.size() == 0):
				markFinished()
				return "Exiting terminal... returning to the standby state."
			else:
				return "'exit' expects 0 arguments"

		learnCommand("help")
		return "Error, unknown command. Use 'help' to list all available commands"
