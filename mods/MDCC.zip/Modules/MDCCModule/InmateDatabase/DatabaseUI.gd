extends Control

var Database : Reference = GlobalRegistry.getModule("MDCC").getSubmodule("Database")

var entriesPerPage : int = 8

var columns : Dictionary # variable idx: { size:float, display:String }

var accessLevel : int = 0

onready var tree : Tree = $vb/Tree

export var style : StyleBox
export var darkStyle : StyleBox

export var entryCol : Color
export var columnCol : Color

var currentPage : int = 0

func stripBBCode(txt:String) -> String:
	var res : String = ""
	
	var inCode : bool = false
	for i in txt.length():
		var c = txt[i]
		if c=="[":
			inCode = true
			continue
		
		if inCode:
			if c=="]":
				inCode = false
			continue
		
		res += c
	
	return res


func popColumnsLs() -> void:
	var cols : Array = [
		[Database.Vars.INMATE_ID, 1.3, "Inmate ID"],
		[Database.Vars.NAME, 2.0],
		[Database.Vars.SPECIES, 1.2],
		[Database.Vars.GENDER, 1.5],
	]
	
	for entry in cols:
		newColumn(entry[0], entry[1], entry[2] if entry.size()>2 else "")

func getDisplayProfile() -> Array:
	var a : Array = []
	
	for v in Database.Vars.values():
		a.append(Database.Vars.keys()[v].capitalize())
	
	return a


func newColumn(variable:int, size:float=1.0, display:String="") -> void:
	var ndict : Dictionary = {
		"size": size,
		"display":display if display else Database.Vars.keys()[variable].capitalize(),
	}
	
	columns[variable] = ndict

func updateLabels(d:Dictionary={}) -> void:
	$vb/HEADER.text = d.get("header", "Database (Access Level: %s)" % accessLevel)
	$vb/FOOTER.text = d.get("footer", "")

func _ready():
	updateLabels()
	
	Database.popAllProfiles([Database.generatePlayerProfile()])
	tree.column_titles_visible = true
	popColumnsLs()
	tree.columns = columns.size()
	
	for i in columns.size():
		tree.set_column_title(i, columns.values()[i]["display"])
		
		tree.set_column_expand(i, true)
		tree.set_column_min_width(i, int(columns.values()[i]["size"]*100))
	
	setPageTo(currentPage)
	$profileDisplay.Database = Database
	$profileDisplay.accessLevel = accessLevel
	$profileDisplay.onReady()
	
	$profileDisplay.connect("hide", $vb, "show")
	

func generateRandoms() -> Array:
	var r : Array = []
	
	for i in 50:
		var p = []
		
		for v in Database.Vars:
			p.append(RNG.randomFemaleName() if RNG.randi_range(0,1) else RNG.randomMaleName())
			
		
		r.append(p)
	
	return r

func clearEntries() -> void:
	tree.clear()
	tree.create_item()

func display(page:int=0) -> void:
	var idx : int = getDisplayedIndex(page)
	var profs : Array = Database.getDiscoveredChars()
	var displayedEntries = profs.size()-idx
	
	displayedEntries = int( min(entriesPerPage, displayedEntries) )
	
	clearEntries()
	
	var ps : Array = Database.getProfiles()
	
	for i in displayedEntries:
		var it = newEntry(Database.getProfile(profs[i+idx], ps), true)
		for k in tree.columns:
			it.set_custom_bg_color(k, entryCol)

func newEntry(prof:Array, nv:bool=false) -> TreeItem:
	
	var it := tree.create_item()
	
	for columni in columns.size():
		var variable : int = columns.keys()[columni]
		
		var ftxt : String = Database.getProfileVar(prof, variable, accessLevel)
		if nv:
			ftxt = ftxt.substr(0, ftxt.find("("))
		
		ftxt = stripBBCode(ftxt)
		
		if variable==Database.Vars.INMATE_ID:
			ftxt = Database.inmateIdPrefix+ftxt
		
		it.set_text(columni, ftxt)
		it.set_metadata(0, prof[Database.Vars.INMATE_ID])
	
	
	return it

#	page = 2, idx = 20*2 = 40 (41st entry... 60th)
#	total = 57, start = 0
#	max displayed = size - idx = 57 - didx-1 = 17, 40 to 40+17=57


#func 

func getDisplayedIndex(page:int) -> int:
	return page*entriesPerPage


func _on_prevp_pressed():
	if currentPage>0:
		setPageTo(currentPage-1)

func setPageTo(page:int) -> void:
	currentPage = page
	
	display(currentPage)
	updatePageDisplay()

func getMaxPages() -> int:
	var s : int = Database.getProfiles().size()
	if s==0:
		return 0
	return int(ceil(s/float(entriesPerPage))-1)

func updatePageDisplay() -> void:
	var idx : int = getDisplayedIndex(currentPage)
	var profs : Array = Database.getProfiles()
	var shown = profs.size()-idx
	
	shown = int( min(entriesPerPage, shown) )
	$vb/pagesc/vb/pagel.text = "Page %s/%s (%s/%s)" % [ currentPage+1, getMaxPages()+1, shown+currentPage*entriesPerPage, profs.size() ]


func _on_nextp_pressed():
	if currentPage<getMaxPages():
		setPageTo(currentPage+1)



func _on_Tree_item_activated():
	var sel = tree.get_selected()
	if !sel:
		return
	
	var m = sel.get_metadata(0)
	
	if !m:
		return
	
	var p = Database.getProfile(m)
	if !p:
		return
	
	$profileDisplay.show()
	$profileDisplay.displayProfile(p)
	$vb.hide()


func _on_DatabaseUI_tree_exiting():
	Database.clear()
