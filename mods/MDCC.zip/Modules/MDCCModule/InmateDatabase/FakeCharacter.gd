extends Character

var mimiced : String = "pc"

func _init():
	id = "MDCC_FakeCharacter"
	npcCharacterType = CharacterType.Inmate
	
	disableSerialization = true

func setMimiced(m:String) -> void:
	mimiced = m

func getName():
	return GM.main.getCharacter(mimiced).getName() if mimiced else "No data"

func getGender():
	return GM.main.getCharacter(mimiced).getGender() if mimiced else Gender.Other
	
func getSmallDescription() -> String:
	return GM.main.getCharacter(mimiced).getSmallDescription() if mimiced else ""

func getSpecies():
	return GM.main.getCharacter(mimiced).getSpecies() if mimiced else [Species.Unknown]

func getThickness() -> int:
	return GM.main.getCharacter(mimiced).getThickness() if mimiced else 100

func getFemininity() -> int:
	return GM.main.getCharacter(mimiced).getFemininity() if mimiced else 100

func getChatColor():
	return GM.main.getCharacter(mimiced).getChatColor() if mimiced else Color.white
