extends HBoxContainer

var accessLevel : int = 0
var Database : Reference

var varDisplays : Dictionary = {
	
}

export var darkStyle : StyleBox

onready var colsc : Container = $vb/colsc/vb

var columnRatios = [0.5, 1.0]

onready var entriesc : Container = $vb/sc/entriesvb

func onReady():
	varDisplays[Database.Vars.INMATE_ID]="Inmate ID"
	varDisplays[Database.Vars.DETAINMENT_PROCS]="Admin. Note"

func getDisplayProfile() -> Array:
	var a : Array = []
	
	for v in Database.Vars.values():
		a.append(Database.Vars.keys()[v].capitalize())
	
	return a

func newEntry(prof:Array, variable:int) -> HBoxContainer:
	var keyText : String = (varDisplays.get(variable, Database.Vars.keys()[variable].capitalize()))
	var finalText : String = Database.getProfileVar(prof, variable, accessLevel)
	
	if variable==Database.Vars.INMATE_ID:
		finalText = Database.inmateIdPrefix+finalText
	
	var nit := newEntryRaw([keyText, finalText])
	
	return nit

func newEntryRaw(txts:Array) -> HBoxContainer:
	var nit := HBoxContainer.new()
	for i in txts.size():
		var rtlKey := RichTextLabel.new()
		rtlKey.fit_content_height = true
		rtlKey.bbcode_enabled = true
		rtlKey.parse_bbcode(txts[i])
		
		rtlKey.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rtlKey.size_flags_stretch_ratio = columnRatios[i]
		nit.add_child(rtlKey)
	
	return nit


func displayProfile(prof:Array) -> void:
	Util.delete_children(entriesc)
#	var pc := PanelContainer.new()
#	pc.add_stylebox_override("panel", darkStyle)
#	pc.add_child(newEntryRaw(["Property", "Value"]))
#	entriesc.add_child(pc)
	
	var varsToDisplay = [
		Database.Vars.INMATE_ID,
		Database.Vars.NAME,
		Database.Vars.INMATE_TYPE,
		Database.Vars.GENDER,
		Database.Vars.ANATOMY,
		Database.Vars.SPECIES,
		
		Database.Vars.AGE,
		Database.Vars.HEIGHT,
		Database.Vars.WEIGHT,
		
		Database.Vars.DESCRIPTION,
		
		Database.Vars.DETAINMENT_PROCS,
		
		Database.Vars.CRIMES,
		Database.Vars.ORIGIN,
		
	]
	
	for v in varsToDisplay:
		entriesc.add_child(newEntry(prof, v))
	
	$pc/art/CharactersArtworkPanel.clear()
	
	var charid : String = prof[Database.Vars.CHARID]
	
	
	if charid=="pc" && GlobalRegistry.modules.has("PlayerPortrait"):
		$pc/art/CharactersArtworkPanel.addCharacter("RAT_FakePlayer", [])
		$pc/art/CharactersArtworkPanel.nextCharacterButton.hide()
		$pc/art/CharactersArtworkPanel.characterStatusGrid.hide()
		return
	
	var fake = GlobalRegistry.getCharacter("MDCC_FakeCharacter")
	if charid!="pc" && GM.main.getCharacter(charid):
		fake.mimiced = charid
	else:
		fake.mimiced = ""
	
	$pc/art/CharactersArtworkPanel.addCharacter("MDCC_FakeCharacter", [])
	$pc/art/CharactersArtworkPanel.nextCharacterButton.hide()
	$pc/art/CharactersArtworkPanel.characterStatusGrid.hide()



func _on_back_pressed():
	hide()
