extends ImagePack

func _init():
	id = "MDCC_DatabasePack"
	artist = "MDCC Database (MoldyT & Selinoccino)"
	

func getCharacterImage(characterID: String, variant: Array):
	if characterID=="MDCC_FakeCharacter" && GM.main:
		var c = GM.main.getCharacter(characterID)
		if c:
			if c.mimiced:
				return Images.getCharacter(c.mimiced, variant)
			else:
				return null
	
	return .getCharacterImage(characterID, variant)
