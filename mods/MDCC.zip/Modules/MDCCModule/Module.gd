extends Module


const SpecialDataDelimiter : String = ":-:"

var submodules : Dictionary = {
	"Stealing": load("res://Modules/MDCCModule/Submodules/Stealing.gd").new(),
	"Hitman": load("res://Modules/MDCCModule/Submodules/Hitman.gd").new(),
	"UniquePlants": load("res://Modules/MDCCModule/Submodules/UniquePlants.gd").new(),
	"StaffDatabase": load("res://Modules/MDCCModule/Submodules/Database.gd").new(),
	"Database": load("res://Modules/MDCCModule/Submodules/Database.gd").new(),
	"Roguelike": load("res://Modules/MDCCModule/Submodules/Roguelike.gd").new(),
	"Plants": load("res://Modules/MDCCModule/Submodules/Plants.gd").new(),
}

func getSubmodule(subid:String) -> Reference:
	return submodules.get(subid)

func getSubmodules() -> Dictionary:
	return submodules

######### module #########

func getFlags():
	return {
		# Character introduction flags
		"MetCharacters":flag(FlagType.Text), # string that we can split into an array
		
		# roguelike
		"HasRoguelikeAccess":flag(FlagType.Bool),
		"RoguelikeFloor": flag(FlagType.Number),
		
		# thingy
		"CratesOpened":flag(FlagType.Number),
		"CrateRoom":flag(FlagType.Text),
	}

func _init():
	# Unique identifier for this module
	id = "MDCC"
	# Author metadata
	author = "Selinoccino"
	
	characters = [
		"res://Modules/MDCCModule/InmateDatabase/FakeCharacter.gd",
	]
	
	
	# Computers: add terminals, safes, or other interactables.
	computers = [
		"res://Modules/MDCCModule/InmateDatabase/MDCCDatabaseNew.gd",
	]
	
	skills = [
		"res://Modules/MDCCModule/Skills/StealingSkill.gd",
	]
	
	attacks = [
		"res://Modules/MDCCModule/Attacks/smokeBombAttack.gd",
	]
	
	gameExtenders = [
		"res://Modules/MDCCModule/GameExtenders/roguelikeEnemyExtender.gd",
		"res://Modules/MDCCModule/GameExtenders/DataStorageExtender.gd",
	]
	
	
	lootLists = [
		"res://Modules/MDCCModule/LootLists/rootList.gd",
	]
	
	scenes = [
		"res://Modules/MDCCModule/InmateDatabase/MDCCDatabasescene.gd",
		"res://Modules/MDCCModule/Gameplay/stealingScene.gd",
		"res://Modules/MDCCModule/Gameplay/bountyBoardScene.gd",
		"res://Modules/MDCCModule/Gameplay/indoctrinateBountyScene.gd",
		
	]
	
	events = [
		"res://Modules/MDCCModule/Gameplay/stealingEvent.gd",
		"res://Modules/MDCCModule/Gameplay/hitmanEvent.gd",
		"res://Modules/MDCCModule/Gameplay/hitmanLocationBountyEvent.gd"
		
	]
	
	submodules["Hitman"].connect("bountyCompleted", submodules["Stealing"], "onHitmanBountyDone", [submodules["Hitman"]])
	
	submodules["StaffDatabase"].popMethod = "getStaff"
	submodules["StaffDatabase"].inmateIdPrefix = "STAFF-"

func writeDataToUserData() -> void:
	var f = File.new()
	
	Directory.new().make_dir_recursive("user://MDCCData")
	f.open("user://MDCCData/InmateProfiles.json", File.WRITE)
	
	f.store_string(JSON.print(getInmateProfiles(), "\t"))
	f.close()
	
	f.open("user://MDCCData/Recipes.json", File.WRITE)
	f.store_string(JSON.print(getAddedRecipes(), "\t"))
	f.close()
	
	f.open("user://MDCCData/Ingredients.json", File.WRITE)
	f.store_string(JSON.print(getAddedIngredients(), "\t"))
	f.close()
	
	f.open("user://MDCCData/Plants.json", File.WRITE)
	f.store_string(JSON.print(getAddedPlants(), "\t"))
	f.close()
	
#	f.open("user://MDCCData/WorldTypes.json", File.WRITE)
#	f.store_string(JSON.print(getAddedWorldTypes(), "\t"))
#	f.close()
	

## type is from Variant.Type thingy
func readJsonData(path:String, type:int, nullval=null):
	var f = File.new()
	
	var e = f.open(path, File.READ)
	
	if e != OK:
		Log.error("MDCC: error accessing json data file %s, code %s" % [ path, e])
		return nullval
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		Log.error("MDCC: error reading json data from file %s, code %s at line %s, message: %s" % [ path, r.error, r.error_line, r.error_string ])
		return nullval
	
	if typeof(r.result) != type:
		Log.error("MDCC: error parsing json data from file %s, unexpected return type, type: %s, expected: %s" % [ path, typeof(r.result), type ])
		return nullval
	
	
	return r.result
	

func register(): # best to do it here
	.register() # call our parent script's one first
	
	GlobalRegistry.registerRepStat("res://Modules/MDCCModule/Gameplay/madiaRepStat.gd")
	
	# bodyparts
	for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/MDCCModule/Bodyparts/"):
		GlobalRegistry.registerBodypart(bp)
	
	# items
	for it in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/MDCCModule/Items/"):
		GlobalRegistry.registerItem(it)
	
	# world edits
	for wedit in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/MDCCModule/WorldEdits/"):
		GlobalRegistry.registerWorldEdit(wedit)
	
	# scenes
	for scene in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/MDCCModule/MainStoryScenes/"):
		GlobalRegistry.registerScene(scene)
	
	# perks
	GlobalRegistry.registerPerkFolder("res://Modules/MDCCModule/Skills/Perks")
	
	
	# events
	for event in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/MDCCModule/Events/"):
		GlobalRegistry.registerEvent(event)
	
	# characters
	for character in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/MDCCModule/Characters/"):
		GlobalRegistry.registerCharacter(character)
	
	# image packs
	GlobalRegistry.registerImagePack("res://Modules/MDCCModule/InmateDatabase/InmateDatabaseImagePack.gd")
	
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)
	
	
	# floors
	GlobalRegistry.registerMapFloorFolder("res://Modules/MDCCModule/Floors/")
	
	# loot tables
	GlobalRegistry.registerLootTableFolder("res://Modules/MDCCModule/LootTables/")

func resetFlagsOnNewDay():
	if GM.main.getModuleFlag(id, "CratesOpened", 0) < getCrateWeapons().size():
		rerollCrateRoom()
	
	
	submodules["Stealing"].onStealingNewDay()
	submodules["Hitman"].onNewDay()
	submodules["Plants"].onNewDay()

######### end module #########


######### plants #########

func getAddedPlants() -> Dictionary:
	return readJsonData("res://Modules/MDCCModule/Data/Plants.json", TYPE_DICTIONARY, {})

######### end plants #########

######### interactions #########

func meetCharacter(charid:String) -> void:
	if !hasMet(charid):
		GM.main.setModuleFlag(id,"MetCharacters", GM.main.getModuleFlag(id,"MetCharacters","") + ","+charid)

func hasMet(charid:String) -> bool:
	return charid in GM.main.getModuleFlag(id,"MetCharacters","").split(",",false)

######### end interactions #########


######### database ##########
## returns usable data
func getInmateProfiles() -> Array: # we want other mods to be able to get our profiles, just as we do theirs, so they can account for them maybe
	return readJsonData("res://Modules/MDCCModule/Data/InmateProfiles.json", TYPE_ARRAY, [])
######### end database #########


######### craftinglib & stuff #########

func getAddedWorkbenchTypes():
	return {
		"mdcc_workbench":{
			"name":"Workbench", # TODO: replace name here
			"mod":id,
			"fluidsCallback": "getWorkbenchFluids",
			"tagsCallback": "getWorkbenchTags",
			},
		} # key is id, name is display name

func getWorkbenchTags(_typeData:Dictionary) -> Array:
	if GM.main.getModuleFlag(id, "Tu-toriel mode", false):
		return ["tu-toriel"]
	return ["mdcc0"]

func getWorkbenchFluids(typeData:Dictionary) -> Array:
	var tier : int = int(typeData.get("tier", 0))
	if tier==0:
		return ["Cum"]
	else:
		return ["Cum", "Milk"]

func getAddedRecipes(): # allows CraftingLib to draw recipes from here; since this is called every time it gets the recipes, you can adds conditions, eg. have a perk that allows you to make specific items. wtype is the workbench type, which you can also add your own
	var rs = readJsonData("res://Modules/MDCCModule/Data/Recipes.json", TYPE_DICTIONARY, {})
	for rid in rs:
		rs[rid]["compatibleWorkbenches"] = ["mdcc_workbench"]
	
	return rs


func getAddedIngredients() -> Dictionary: # these will exist in every kind of workbench but, since they'll have no way to make them, we don't have to worry about them; they won't even be visible
	return readJsonData("res://Modules/MDCCModule/Data/Ingredients.json", TYPE_DICTIONARY, {})

func getIngredientStoresText() -> String:
	var craftinglib = GlobalRegistry.getModules().get("CraftingLibReworked")
	if !craftinglib:
		return "(none)"
	
	var stores = craftinglib.getWorkbenchStores("MDCC_GreenhouseWB")
	if !stores:
		return "(none)"
	
	var res = []
	for array in stores: # array = [ingid, amount]
		if !array:
			continue
		
		var idata = craftinglib.Ingredients.getIngredient(array[0])
		if !idata:
			res.append("(unknown): %s pcs" % [ str(array[1]).pad_decimals(2) if array.size()>1 else "0.00" ])
			continue
		
		res.append("%s: %s %s" % [ ( idata.name if idata.name else "(unknown)" ), (str(array[1]).pad_decimals(2) if array.size()>1 else "0.00"), (idata.measure if idata.measure else "pcs")   ])
	
	
	return "\n".join(res)

######### end crafting #########

######### roguelike #########

func getAddedWorldTypes() -> Dictionary: # exposed bc mdcc acts like an expansion mod for itself
	var floorNumber = int(GM.main.getModuleFlag("MDCC","RoguelikeFloor",1))
	
	var p = "res://Modules/MDCCModule/RoguelikeEventScenes/"
	return {
		"Default":{
			"text":"",
			"events":[
				[p+"caveIn.gd",1.0,60], # scenePath, weight, chance to appear in a floor
				[p+"qte_struggle.gd",1.0,40],
				[p+"restArea.gd",0.5, 25],
				[p+"darkness.gd",0.5, 20],
			],
			"weight":1.0, # relative to others and stuff. if spawnChance hits, world type is added to weighted list of worldtypes
			"spawnChance":100 if floorNumber%10 else 0, # never spawns when floor is 10, 20, 30, etc. this is checked before weight
			"parentWorldType":null, # string or null. if set, will inherit that world type's events
		},
		"Selinoccino":{
			"text":"You hear rats squeaking further in.",
			"events":[
				[p+"ratCredit.gd",1.5, 100],
			],
			"weight":0.05,
			"spawnChance":100, # can always spawn, very low weight so yk
			"parentWorldType":"Default", # string or null. if set, will inherit that world type's events
		},
	}

######### end roguelike #########

func getCrateWeapons() -> Array:
	return ["Shiv", "MDCC_SmokeBomb", "StunBaton"]

func rerollCrateRoom() -> void:
	var oldRoom : String = GM.main.getModuleFlag(id, "CrateRoom", "")
	
	var avails = []
	var f = File.new()
	
	if f.open("res://Modules/MDCCModule/Data/crate_rooms.tres", File.READ)==OK:
		avails.append_array(f.get_as_text().split("\n", false))
	
	if oldRoom:
		avails.erase(oldRoom.get_slice("::", 0))
	
	GM.main.setModuleFlag(id, "CrateRoom", RNG.pick(avails))
	


######### utilities #########

## expects array[ array[num, string (or array of strings) ], ... , ... , [string(s)] (least)], biggest first (checked if bigger than), least last
func scaledString(scalesArray:Array,num) -> String:
	var lastidx = scalesArray.size()-1
	for idx in scalesArray.size():
		var ar = scalesArray[idx]
		if idx==lastidx:
			return RNG.pick(ar)
		if num>=ar[0]:
			if typeof(ar[1]) == TYPE_ARRAY:
				return RNG.pick(ar[1])
			return ar[1]
	return "null"

######### end utilities #########
