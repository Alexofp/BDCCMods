extends EventBase

func _init():
	id = "MDCCElevatorEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["ElevatorScene", ""])

func run(_id,_args):
	var hasKeycard : bool = GM.pc.getInventory().hasItemID("MDCC_Keycard") # check if we have a keycard in the first place to enter
	if("mdcc_elevator" == GM.pc.location):
		addDisabledButton("Insert Keycard", "You are already here")
	elif !hasKeycard:
		addDisabledButton("Keycard Reader", "You don't have a keycard")
	else:
		addButton("Insert Keycard", "Insert your keycard to descend to the restricted floor", "gothereuwu", ["mdcc_elevator"])
	if("mdcc_mines_entrance" == GM.pc.location):
		addDisabledButton("Abandoned Mines", "You are already here")
	else:
		addButton("Abandoned Mines", "Descend to the abandoned mines", "gothereuwu", ["mdcc_mines_entrance"])
	
	addButton("aa", "a", "gothereuwu", ["MDCC_mafia1"])


func onButton(_method, _args):
	if(_method == "gothereuwu"): # idk why it didn't work before (at least i think it didn't), but this way it does, so yay
		GM.main.getCurrentScene()._react("gofloor",_args)
		
