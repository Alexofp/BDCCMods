extends EventBase

func _init():
	id = "MDCCCrateEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, null)
	

func run(_triggerID, _args):
	var rooom = _args[0] if _args else null
	if !rooom:
		return
	
	var f = getModuleFlag("MDCC", "CrateRoom","")
	
	if f && rooom==f:
		saynn("There's a MEGA LUCK LOOT CRATE here.")
		addButton("Search crate", "goodies", "search")
	

func getPriority():
	return 10
	

func onButton(_method, _args):
	if(_method == "search"):
		
		var nid = ""
		if getModuleFlag("MDCC", "CratesOpened", 0)<getModule("MDCC").getCrateWeapons().size():
			runScene("MDCC_CratePickupScene")
			nid = getModuleFlag("MDCC", "CrateRoom", "") + "::done"
		else:
			runScene("MDCC_CrateLeviScene")
		
		setModuleFlag("MDCC", "CrateRoom", nid)
