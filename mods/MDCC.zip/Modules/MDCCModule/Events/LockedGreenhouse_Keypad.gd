extends EventBase

func _init():
	id = "lockedgreenhousekeypad"

func registerTriggers(es):
	# add lisen triggers, this event will run when its triggered
	es.addTrigger(self, Trigger.EnteringRoom, "main_green_corridor2") # entrance

func run(_triggerID, _args):
	if _triggerID == "EnteringRoom": # safe guard even though it shouldn't be possible to have other triggers in here
		saynn("Built into the northern wall is a greenhouse. Next to the door is a keypad that looks newer then the rest of the infrastructure")
		if GM.main.getModuleFlag("MDCC", "MSGhLocked", false):
			addDisabledButton ("Keypad","The electronic keypad is still disabled")
		elif GM.pc.isBlindfolded() && !GM.pc.canHandleBlindness():
			addDisabledButton("Keypad","You can't use this while blindfolded")
		else:
			addButton("Keypad", "There is an electronic keypad locking a greenhouse door", "EnterGreenhouse") # Adds a button to enter

func getPriority():
	return 0

func onButton(_method, _args):
	if _method=="EnterGreenhouse": # if the method in the button is EnterGreenhouse
		if GM.main.getModuleFlag("MDCC", "MSGreenhouseClear", false):
			GM.pc.setLocation("MDCC_keypaddoor")
			GM.main.reRun()
		else:
			runScene("LockedGreenhouseKeypad")
