extends PerkBase

func _init():
	id = "MDCC_MoreMarks"
	skillGroup = "MDCC_Stealing"
	dungeonWeight = 0.0

func getVisibleName():
	return "More Marks"

func getVisibleDescription():
	return "You get one extra life when stealing."

func getMoreDescription():
	return "ye"

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"
