extends PerkBase

func _init():
	id = "MDCC_MasterPickpocket"
	skillGroup = "MDCC_Stealing"
	dungeonWeight = 0.0

func getVisibleName():
	return "Master Pickpocket"

func getVisibleDescription():
	return "ya"

func getMoreDescription():
	return "ye, plus guards 50%"

func getSkillTier():
	return 2

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func getRequiredPerks():
	return ["MDCC_AdeptPickpocket"]
