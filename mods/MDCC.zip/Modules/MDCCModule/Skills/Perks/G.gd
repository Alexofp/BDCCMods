extends PerkBase

func _init():
	id = "MDCC_QuickFingers"
	skillGroup = "MDCC_Stealing"
	dungeonWeight = 0.0

func getVisibleName():
	return "Quick Fingers"

func getVisibleDescription():
	return "ya"

func getMoreDescription():
	return "ye"

func getSkillTier():
	return 2

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"
