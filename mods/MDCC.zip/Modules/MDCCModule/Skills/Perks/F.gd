extends PerkBase

func _init():
	id = "MDCC_SoftPresence"
	skillGroup = "MDCC_Stealing"
	dungeonWeight = 0.0

func getVisibleName():
	return "Soft Presence"

func getVisibleDescription():
	return "ya"

func getMoreDescription():
	return "ye"

func getSkillTier():
	return 1

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func getRequiredPerks():
	return ["MDCC_LowPresence"]
