extends PerkBase

func _init():
	id = "MDCC_Pickpocket"
	skillGroup = "MDCC_Stealing"
	dungeonWeight = 0.0

func getVisibleName():
	return "Pickpocket"

func getVisibleDescription():
	return "ya"

func getMoreDescription():
	return "ye"

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"
