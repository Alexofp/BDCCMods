extends PerkBase

func _init():
	id = "MDCC_AdeptPickpocket"
	skillGroup = "MDCC_Stealing"
	dungeonWeight = 0.0

func getVisibleName():
	return "Adept Pickpocket"

func getVisibleDescription():
	return "ya"

func getMoreDescription():
	return "ye, plus engies nurses 50%"

func getSkillTier():
	return 1

func getPicture():
	return "res://Modules/AnAppleADay/Images/appleeffect.png"

func getRequiredPerks():
	return ["MDCC_Pickpocket"]
