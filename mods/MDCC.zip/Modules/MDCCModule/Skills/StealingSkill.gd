extends SkillBase

func _init():
	id = "MDCC_Stealing"

func getVisibleName():
	return "Pickpocket"

func getVisibleDescription():
	return "The lowly art of relieving someone of their earthly possessions."

func getPerkTiers():
	return [
		[0],
		[5],
		[10],
	]
