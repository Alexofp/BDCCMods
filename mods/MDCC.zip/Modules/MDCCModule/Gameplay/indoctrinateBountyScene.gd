extends SceneBase

var pawn : String

func _init():
	sceneID = "MDCC_IndoctrinateScene"

func resolveCustomCharacterName(_charID):
	if _charID=="vic":
		return pawn
	return null


func _run():
	if state == "":
		saynn("{vic.name} isn't here right now, do you want to wait for {vic.himHer}?")
		
		addButton("Yes", "", "wait")
		addButton("No", "", "end")
		return
	
	if state == "wait":
		saynn("Time passes...")
		addContinue("confront")
		return
	
	if state == "confront":
		playAnimation(StageScene.Duo, "stand", {npc=pawn})
		saynn("{vic.name} appears.")
		
		addButton("Leash!", "", "doLeash")
		return
	
	if state == "doLeash":
		playAnimation(StageScene.Duo, "stand", {npc="pc", bodyState={leashedBy="pc"}, npcAction="stand", flipNPC=false, pc=pawn})
		saynn("You clip a leash onto {vic.his} collar!")
		
		addContinue("tp")
		return
	
	if state == "tp":
		saynn("You go to the mafia floor...")
		
		addContinue("leashWalk")
		return
	
	if state == "leashWalk":
		var roomID : String = GM.pc.location
		var _roomInfo = GM.world.getRoomByID(roomID)
		
		if(GM.world.canGoID(roomID, GameWorld.Direction.NORTH)):
			addButtonAt(6, "North", "Go north", "leashWalk", [GameWorld.Direction.NORTH, Direction.North])
		else:
			addDisabledButtonAt(6, "North", "Can't go north")
			
		if(GM.world.canGoID(roomID, GameWorld.Direction.WEST)):
			addButtonAt(10, "West", "Go west", "leashWalk", [GameWorld.Direction.WEST, Direction.West])
		else:
			addDisabledButtonAt(10, "West", "Can't go west")
			
		if(GM.world.canGoID(roomID, GameWorld.Direction.SOUTH)):
			addButtonAt(11, "South", "Go south", "leashWalk", [GameWorld.Direction.SOUTH, Direction.South])
		else:
			addDisabledButtonAt(11, "South", "Can't go south")
		
		if(GM.world.canGoID(roomID, GameWorld.Direction.EAST)):
			addButtonAt(12, "East", "Go east",  "leashWalk", [GameWorld.Direction.EAST, Direction.East])
		else:
			addDisabledButtonAt(12, "East", "Can't go east")
		
		
		if roomID == "MDCC_mafia9":
			addButton("Turn in", "", "turnin")
		
		
		if(GM.pc.isBlindfolded() && !GM.pc.canHandleBlindness()):
			saynn(_roomInfo.getBlindDescription())
		else:
			saynn(_roomInfo.getDescription())
			
		var roomMemory = GM.main.getRoomMemory(roomID)
		if(roomMemory != null && roomMemory != ""):
			saynn("[i]"+roomMemory+"[/i]")
		
		
		return
	
	if state == "turnin":
		saynn("You turned {vic.name} in.")
		
		addContinue("end")
	

func _react(action: String, _args):
	if action == "end":
		endScene()
		return
	
	if action == "wait":
		processTime(60 * (RNG.randi_range(60, 120))) # 1-2 hours
		setState(action)
		return
	
	elif action == "leashWalk":
		#GM.PROFILE.start("playAnimation")
		playAnimation(StageScene.Duo, "walk", {npc="pc", bodyState={leashedBy="pc"}, npcAction="walk", flipNPC=true, pc=pawn})
		if !_args:
			setState(action)
			return
		
		GM.pc.setLocation(GM.world.applyDirectionID(GM.pc.location, _args[0]))
		processTime(60 if GM.pc.hasBoundLegs() else 30)
		aimCameraAndSetLocName(GM.pc.location)
		
	
	
	elif action == "turnin":
		var hitman = getModule("MDCC").getSubmodule("Hitman")
#		var bounty = hitman.getNpcEntry(pawn)
#		if !bounty:
#			setState(action)
#			return
		
		hitman.completeBountyFull(pawn)
	
	elif action == "tp":
		GM.pc.setLocation("MDCC_mafia1")
	
	setState(action)
	


func _initScene(_args = []):
	if !_args:
		endScene()
		return
	
	pawn = _args[0]

func saveData():
	var d = .saveData()
	d["pawn"] = pawn
	return d

func loadData(d):
	.loadData(d)
	pawn = SAVE.loadVar(d, "pawn", "")
	
