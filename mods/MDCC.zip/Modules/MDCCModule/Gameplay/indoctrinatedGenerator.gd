extends InmateGenerator

func makeBase(_idprefix = "dynamicnpc", _args = {}):
	var dynamicCharacter = DynamicCharacter.new()
	if(is_instance_valid(GM.main)):
		dynamicCharacter.id = GlobalRegistry.getModule("MDCC").getSubmodule("Hitman").genIndoctrinatedId(_args.get("index", 0))
	
	if(_args.has(NpcGen.Temporary) && _args[NpcGen.Temporary]):
		dynamicCharacter.temporaryCharacter = true
	
	if(is_instance_valid(GM.main)):
		GM.main.addDynamicCharacter(dynamicCharacter)
	elif(_args.has("addtonode") && _args["addtonode"]):
		_args["addtonode"].add_child(dynamicCharacter)
	return dynamicCharacter

func pickEquipment(character:DynamicCharacter, _args = {}):
	.pickEquipment(character, _args)
#	var bounty = _args.get("MDCC_bounty")
	
	var type = character.getFlag(CharacterFlag.InmateType)
	if type == InmateType.SexDeviant:
		adjustForLilac(character, _args)
	elif type == InmateType.HighSec:
		adjustForRed(character, _args)
	

func adjustForLilac(character:DynamicCharacter, _args={}) -> void:
	character.npcAttacks.append("MDCC_LustDOT")

func adjustForRed(_character:DynamicCharacter, _args={}) -> void:
	return
