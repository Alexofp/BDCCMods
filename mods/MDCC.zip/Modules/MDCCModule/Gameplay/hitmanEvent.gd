extends EventBase

func _init():
	id = "MDCC_HitmanEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["FightScene", "win"])

func run(_id,_args):
	var cs = GM.main.getCurrentScene()
	
	if !cs.enemyID:
		return
	
#	if cs.checkEnd()=="win":
	var hitman = getModule("MDCC").getSubmodule("Hitman")
	var entry = hitman.getNpcEntry(cs.enemyID)
	if entry && !entry.completed:
		hitman.completeBountyFlagOnly(cs.enemyID)
		addMessage("You completed {%s.nameS} bounty" % cs.enemyID)
#		addMessage("")
	


#enemyID
