extends EventBase

func _init():
	id = "MDCC_HitmanLocationEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func run(_id,_args): # _args[0] = roomid
	if !_args:
		return
	var hitman = getModule("MDCC").getSubmodule("Hitman")
	
	var bounties : Array = hitman.getBountyLocationArrayStrict(_args[0])
	if !bounties:
		return
	
	for bounty in bounties:
		addButton(bounty.npcID, "aa", "do", [bounty])

func onButton(_triggerID, _args):
	if _triggerID == "do":
		runScene("MDCC_IndoctrinateScene", [_args[0].npcID])

#enemyID
