extends SceneBase

var pawn : String = ""
var scn = -1

var pawnEntry = null
var stealing
var bounty

func resolveCustomCharacterName(_charID):
	if _charID=="vic":
		return pawn
	return null

func _initScene(_args = []):
	if(_args.size() < 2):
		endScene()
		return
	
	pawn = _args[0]
	scn = _args[1]
	

func _init():
	sceneID = "MDCCStealingScene"
	
	if GM.main:
		stealing = GlobalRegistry.getModule("MDCC").getSubmodule("Stealing")

func _run():
	pawnEntry = stealing.getEntryWithID(pawn)
	if !pawnEntry:
		pawnEntry = stealing.NpcStealingEntry.new()
		pawnEntry.npcID = pawn
		pawnEntry.wealth = stealing.generateWealth(pawn)
	
	var hitman = getModule("MDCC").getSubmodule("Hitman")
	bounty = hitman.getNpcEntry(pawn)
#	if !pawnEntry:
#		saynn("Error: No entry for pawn!")
#		addButton("done", "1", "endthescene")
#		return
	if(state in ["go",""]):
		var type = stealing.getWealthType(pawnEntry.wealth)
		
		saynn(stealing.wealthData[type]["text"]+" Do you want to try pickpocketing {vic.him}?")
		
		
		if bounty && bounty.type == hitman.BountyTypes.STEAL:
			saynn("It seems {vic.heShe} {vic.have} a bounty.")
		
		addButton("Steal", "Go through their pockets.", "doStole")
		addButton("No", "Leave them alone. ","endthescene")
		
		return
	elif state == "doStole":
		var game : Control = load("res://Modules/MDCCModule/Minigames/Stealing/stealingMinigame.tscn").instance()
		GM.ui.addFullScreenCustomControl("minigame",game)
		game.connect("finished", self, "minigameFinished")
		
	elif state == "caught_nofight":
		saynn("{vic.Name} caught you trying to pickpocket {vic.him}!")
		saynn("{vic.She} {vic.verb('choose')} not to fight you...")
		
		addButton("Fight", "", "endthescene")
	
	elif state == "caught_fight":
		saynn("{vic.Name} caught you trying to pickpocket {vic.him}!")
		saynn("{vic.Theyre} getting ready to fight!")
		
		addButton("Fight", "", "fight")
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if _action=="fight":
		endScene()
		GM.main.getSceneByUniqueID(scn).endScene()
		runScene("FightScene", [pawn])
		GM.main.reRun()
		return
	
	if _action=="stoleResult":
		var res = _args[0]
		if res.failedHard:
			setState("caught_fight" if willFight() else "caught_nofight")
			return
		
		stealing.increaseStolenTimes(1)
		
		var hitman = getModule("MDCC").getSubmodule("Hitman")
		
		if bounty && bounty.type == hitman.BountyTypes.STEAL:
			bounty.completed = true
			addMessage("You got the item for {vic.nameS} bounty!")
			endScene()
			addEXP(res.score + 50)

			return
		
		var pawnc = getCharacter(pawn)
		var initExp = res.score
		
		if pawnc.getCharType() in [CharacterType.Nurse, CharacterType.Guard, CharacterType.Engineer]:
			res.score *= 0.5 # half loot
		
		var loott = pawnc.getLootTable(null)
		
		var floot = {
			"items":[],
			"credits":int(  (res.score + RNG.randi_range(-5,5))  * 0.1), # every 10% score = 1 credit
		}
		
		var wtype = stealing.getWealthType(pawnEntry.wealth)
		
		var reps = stealing.wealthData[wtype]["initRolls"]
		if stealing.wealthData[wtype]["extraRolls"]:
			reps += (int(res.score) / 100) + int(RNG.chance(int(res.score) % 100))
		
		
		for i in int(max(1, reps)): # min 1 roll
			var l = loott.generateAndCreateItems(pawn)
			var nitem = RNG.pick(l["items"])
			if nitem:
				floot["items"].append(  nitem  )
		
		floot["credits"] = int(min(floot["credits"], stealing.wealthData[wtype]["credCap"]))
		if floot["credits"]>0 or floot["items"].size()>0: # has loot
			GM.main.runScene("LootingScene", [floot])
		else: # no loot
			addMessage("They had nothing on them")
		
#		var sexp = 50
#		if GM.pc.hasPerk("MDCC_MasterPickpocket"):
#			sexp = 150
#		elif GM.pc.hasPerk("MDCC_AdeptPickpocket"):
#			sexp = 120
#		elif GM.pc.hasPerk("MDCC_Pickpocket"):
#			sexp = 90
		
		addEXP(initExp)
		
		endScene()
		return
	
	elif _action == "doStole":
		pawnEntry.stolenToday = true
		pawnEntry.wealth = int(max(1, pawnEntry.wealth - 1))
		
		pawnEntry.daysSinceStolen = 0
		pawnEntry.stealAgainTime = GM.main.timeOfDay + 60*60*2 # 2 hours
		stealing.addEntryDirect(pawnEntry)
		
	
	setState(_action)

func addEXP(xp:int) -> void:
	GM.pc.addSkillExperience("MDCC_Stealing", xp)
	addMessage("You received %s %s experience" % [ xp, GlobalRegistry.createSkill("MDCC_Stealing").getVisibleName() ])

func minigameFinished(result:MinigameResult):
	GM.main.pickOption("stoleResult", [result])

func willFight() -> bool:
	var p : Personality = getCharacter(pawn).getPersonality()
	var s : float = p.personalityScore({
		PersonalityStat.Coward:-1.0, # brave mult 1.0
		PersonalityStat.Mean:0.5, # mean mult 0.5
		PersonalityStat.Subby:-0.75, # dom mult 0.75
		PersonalityStat.Impatient:0.2, # impatient mult 0.2
		PersonalityStat.Brat:0.1, # brat mult 0.1
	}) # extremes: +-2.55
	
	return s>=2.55*(RNG.randf_range(0.5, 0.75)) # they're brave enough to fight

func saveData():
	var d = .saveData()
	d["pawn"] = pawn
	d["scn"] = scn
	return d

func loadData(d):
	.loadData(d)
	pawn = SAVE.loadVar(d, "pawn")
	scn = SAVE.loadVar(d, "scn")
