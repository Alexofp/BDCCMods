extends RepStatBase

func _init():
	id = "MDCC_MafiaRep"

func getVisibleName():
	return "Mafia Reputation"

func getMaxLevel() -> int:
	return 4

func getMinLevel() -> int:
	return -2

func getTextForLevel(_level:int, _rep):
	if _level <= -2:
		return "punching bag"
	if(_level <= -1):
		return "enemy"
	if(_level == 0):
		return "nobody"
	if(_level == 1):
		return "goon"
	if(_level == 2):
		return "ultra goon"
	if(_level == 3):
		return "2nd in cmd"
	if(_level == 4):
		return "2nd in cmd senior"
	return "mafiozo"

#func getSpecialRequirementToReachLevel(_level:int, _rep):
#	if(_level == 3):
#		return ["enslavesomeone", "Enslave anyone"]
#	if(_level == 5):
#		return ["makeobey", "Make any slave submit to you.. or break their mind"]
#
#	return null

func getEffectsInfoForLevel(_level:int, _rep) -> Array:
	return [
		"ocassional shakedowns or smth idk man"
	]
