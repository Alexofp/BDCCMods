extends SceneBase

var hitman

func _init():
	sceneID = "MDCC_BountyBoard"
	
	if GM.main:
		hitman = getModule("MDCC").getSubmodule("Hitman")

func _run():
	if state == "":
		listAllBounties()
		
		addButton("Done", "", "end")
		addButton("Gimme a bounty!", "", "gimmeone")
		
	

func addFightButtons() -> void:
	for entry in hitman.getEntries():
		var npcid = entry.npcID
		addButton(GM.ui.gameParser.executeString("spy {%s.name}" % npcid) ,"", "spy", [npcid])
		addButton(GM.ui.gameParser.executeString("fight {%s.name}" % npcid), "fight {%s.him}" % npcid, "fight", [npcid])

func listAllBounties() -> void:
	saynn(colorize("Currently available bounties:", Color.gold))
	
	for entry in hitman.getEntries():
		var npc = entry.npcID
		printOneBounty(npc)
		if entry.completed:
			addButton(parse("Claim {%s.name}'s bounty" % npc), "Claim the bounty", "claim", [npc])
		elif !entry.active:
			addButton(parse("Take {%s.name}'s bounty" % npc), "Take the bounty", "take", [npc])

func parse(txt:String) -> String:
	return GM.ui.gameParser.executeString(txt)

func colorize(txt:String, col:Color=Color.white) -> String:
	return "[color=%s]%s[/color]" % [col.to_html(), txt]

func printOneBounty(npc:String) -> void:
	var entry = hitman.getNpcEntry(npc)
	if entry:
		var jobString : String = hitman.jobText(entry.type)
		
		var extra : String = entry.extraData.get("extraText", "")
		
		saynn("{%s.name} (%s)\n\tJob: %s\n\tReward: %s %s\n\tExpires in %s %s%s" % [ npc, ("Active" if entry.active else "Available"), jobString, entry.value, Util.multipleOrSingularEnding(entry.value, "credit"), entry.daysToDie, Util.multipleOrSingularEnding(entry.daysToDie, "day"), "\n\t"+extra if extra else "" ])
	

func _react(_action: String, _args):
	if _action == "end":
		endScene()
		return
	
	if _action == "claim" && _args:
		var id = _args[0]
		addMessage("You claimed {%s.nameS} bounty" % id)
		hitman.completeBountyFull(id)
		
		setState("")
		return
	
	if _action == "take" && _args:
		var id = _args[0]
		addMessage("You took {%s.nameS} bounty" % id)
		var entry = hitman.getNpcEntry(id)
		if entry:
			entry.active = true
		
		setState("")
		return
	
	if _action == "gimmeone":
		var entry = hitman.Bounty.new()
		entry.npcID = RNG.pick(GM.main.getDynamicCharacters())
		entry.type = RNG.randi_range(0, hitman.BountyTypes.TOTAL_SIZE-1)
		entry.value = RNG.randf_range(5, 30)
		entry.completed = false
		
		if RNG.chance(25):
			entry.location = RNG.pick(GM.world.roomDict.keys())
		
		hitman.addNpcEntryDirect(entry)
		
		setState("")
		return
	
	elif _action == "fight" && _args:
		runScene("FightScene", _args)
		setState("")
		return
	elif _action == "spy" && _args:
		runScene("SpyOnPawnScene", _args)
		setState("")
		return
	
	setState(_action)

