extends EventBase

enum denialReasons {
	NONE, # can steal
	TOO_SOON, # stolen from today
	NEED_ADEPT, # eng/nurse too hard
	NEED_MASTER, # guard too hard
	COOLDOWN, # wait more days
	TOTAL_SIZE,
}
func _init():
	id = "MDCCStealingEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook,["SpyOnPawnScene",""])


func canSteal(charId:String) -> int: # returns reason they can't steal, 0 is can do
	var stealing = getModule("MDCC").getSubmodule("Stealing")
	var npcEntry = stealing.getEntryWithID(charId)
	
	if !npcEntry:
		return denialReasons.NONE
	
	if npcEntry.stealAgainTime > GM.main.timeOfDay:
		return denialReasons.COOLDOWN
	
	var ctype = getCharacter(charId).getCharacterType()
	
	if ctype in [CharacterType.Guard] && !GM.pc.hasPerk("MDCC_MasterPickpocket"):
		return denialReasons.NEED_MASTER 
	
	if ctype in [CharacterType.Engineer, CharacterType.Nurse] && !GM.pc.hasPerk("MDCC_AdeptPickpocket"):
		return denialReasons.NEED_ADEPT
	
	
	if npcEntry.stolenToday: # stolen from today?
		return denialReasons.TOO_SOON # stop stealing from this person omg
	
	return denialReasons.NONE

func run(_id,_args):
	var cs = GM.main.getCurrentScene()
	
	if !cs.pawnID:
		return
	
	if(cs.state in ["go",""]):
#		var lucky = RNG.chance(10)
		
		saynn("You're following {%s.name}. You can try to steal from {%s.him}. ".replace("%s",cs.pawnID))
#		if lucky:
#			saynn("You think this is a good moment to strike.")
		
		var can : int = canSteal(cs.pawnID)
		
		if can==denialReasons.NONE:
			addButton("Steal", "Steal from them", "steal", [true])
			return
		
		
		var reasons : Array = []
		reasons.resize(denialReasons.TOTAL_SIZE)
		
		reasons[denialReasons.TOO_SOON] = "It's best not to test your luck with them again"
		reasons[denialReasons.NEED_ADEPT] = "This person seems a bit too perceptive for you to get away with stealing"
		reasons[denialReasons.NEED_MASTER] = "You don't want to risk stealing from a guard with your current skills"
		reasons[denialReasons.COOLDOWN] = "You think you should lay low for a while longer"
		
		
		addDisabledButton("Steal",  reasons[can] if can<denialReasons.TOTAL_SIZE else "You can't steal from them right now" )
		return

func onButton(_method, _args):
	var cs = GM.main.getCurrentScene()
	if _method=="stoleResult":
		var res = _args[0]
		if res.failedHard:
			getCaught(cs)
			return
		
		var text = getModule("MDCC").scaledString([
			[180, "Your digits moved masterfully in their pockets, you managed to take more than you expected"],
			[130, "You skillfully rummaged through their pockets"],
			[90, "You did reasonably well in pickpocketing them"],
			[40, "You barely managed to avoid getting caught with your awkwardness and general inexperience"],
			["You have zero idea how you managed to get away with this poor a performance"]
		],res.score)
		
		saynn(text)
		return
	
	if _method=="steal":
		if !_args:
			cs.setState("")
		elif _args[0]:
			runScene("MDCCStealingScene", [cs.pawnID, cs.uniqueSceneID])
		else:
			getCaught(cs)
		return
	if _method=="fight":
		cs.endScene()
		GM.main.runScene("FightScene", [cs.pawnID])
		return

func getCaught(cs): # cs is current scene
	var p : Personality = getCharacter(cs.pawnID).getPersonality()
	var s : float = p.personalityScore({
		PersonalityStat.Coward:-1.0, # brave mult 1.0
		PersonalityStat.Mean:0.5, # mean mult 0.5
		PersonalityStat.Subby:-0.75, # dom mult 0.75
		PersonalityStat.Impatient:0.2, # impatient mult 0.2
		PersonalityStat.Brat:0.1, # brat mult 0.1
	}) # extremes: +-2.55
	addMessage("{%s.name} caught you!" % cs.pawnID)
	cs.endScene()
	if s>=1.8: # they're brave enough to fight
		GM.main.runScene("FightScene", [cs.pawnID])
	else:
		addMessage("{%s.They} {%s.verb('choose')} not to fight you..." % [cs.pawnID, cs.pawnID])
