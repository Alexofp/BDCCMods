Using PlayerPortrait:

All portrait files have to be placed this directory: (BDCC user data folder, where your saves folder is)/PlayerPortraits/(your images here)

Image size used when testing is 700x895, but the vanilla dimensions (512x600 I think) should also work well.

The only required file(s) for the mod to "work" is either one .png file that begins with "naked" or one that begins with "normal". Those will be used when your character is clothed or naked appropriately or, if one is missing, the other will be used all the time.

Please note that the hurt, neutral and lust variants are all displayed on top of your normal/naked image; you can have the normal and naked images be a blank head shape and the variants be the facial expression.

To specify hurt variants, you can make any number of .png files that should all start with "hurt"; they'll be read alphabetically I think. The hurt variants that are alphabetically earlier will be displayed on lower pain levels, and the ones later on higher ones (I recommend naming them smth like "hurt1", "hurt2" etc.).

You can follow the same proccess to add lust variants, only difference being that the filenames have to start with "lust". You can currently only have one hurt/lust overlay active, and the lust one will only be displayed if your lust percentage is higher than your pain percentage.

You can also specify a neutral overlay that will be displayed when your character is not feeling too lusty or hurt, by adding a .png file that starts with "neutral".
