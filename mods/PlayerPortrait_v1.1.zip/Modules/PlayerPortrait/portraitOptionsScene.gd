extends SceneBase

var colorPickerScene = preload("res://UI/ColorPickerWidget.tscn")
var col : String = ""

func _init():
	sceneID = "RAT_PortraitOptionsScene"


func _initScene(_args = []):
	col = getModuleFlag("PlayerPortrait", "PortraitNameColor", GM.pc.getChatColor())

func _run():
	# font color
	saynn("Choose font color for your nametag")
	
	var p = colorPickerScene.instance()
	GM.ui.addCustomControl("picker", p)
	p.setCurrentColor(Color(col))
	
	p.connect("color_changed", self, "chooseColor")
	
	addButton("Nevermind", "Cancel and keep old color", "endthescene")
	addButton("Done", "Save the color", "done")
	addButton("Reset color", "Reset the color to the default", "reset")
	

func chooseColor(c:Color=Color.white) -> void:
	col = c.to_html()
	#

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if _action=="done":
		setModuleFlag("PlayerPortrait", "PortraitNameColor", col)
		endScene()
		return
	
	if _action == "reset":
		col = getModuleFlag("PlayerPortrait", "PortraitNameColor", GM.pc.getChatColor())
		setState("")
		return
	
	setState(_action)

func saveData():
	var d = .saveData()
	d["col"] = col
	return d

func loadData(d):
	.loadData(d)
	col = SAVE.loadVar(d, "col", GM.pc.getChatColor())
