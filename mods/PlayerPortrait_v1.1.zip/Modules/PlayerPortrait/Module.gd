extends Module

func getFlags():
	return {
		"PortraitNameColor": flag(FlagType.Text),
	}

func _init():
	id = "PlayerPortrait"
	author = "Selinoccino"
	
	worldEdits = [
		"res://Modules/PlayerPortrait/PortraitWorldEdit.gd",
	]
	
	characters = [
		"res://Modules/PlayerPortrait/FakePlayer.gd",
	]
	
	scenes = [
		"res://Modules/PlayerPortrait/portraitOptionsScene.gd",
	]
	
	events = [
		"res://Modules/PlayerPortrait/OptionsEvent.gd",
	]
	

func postInit():
	GlobalRegistry.registerImagePack("res://Modules/PlayerPortrait/PlayerImagePack.gd")
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)
	doReloadMyPackPleaseAndThankYou()

func doReloadMyPackPleaseAndThankYou():
	var pack = GlobalRegistry.imagePacks.get("RAT_PlayerPortrait")
	if !pack:
		return
	
	pack.reloadMyDataPleaseAndThankYou()

#func onFoxLibModInit(_foxModuleAPI):
#	return
