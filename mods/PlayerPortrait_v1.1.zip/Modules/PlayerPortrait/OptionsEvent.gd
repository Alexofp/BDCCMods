extends EventBase

func _init():
	id = "RAT_PortraitOptionsEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook,["MeScene",""])

func run(_id,_args):
	addButton("Portrait Options", "Change some stuff about your portrait", "doPortraitOps")


func onButton(_method, _args):
	if(_method == "doPortraitOps"):
		runScene("RAT_PortraitOptionsScene")
