extends ImagePack

var totalLust : int = 0
var totalHurt : int = 0

func _init():
	id = "RAT_PlayerPortrait"
	artist = "PlayerPortrait (Selinoccino)"
	

func reloadMyDataPleaseAndThankYou() -> void:
	characters.clear()
	
	var path = "user://PlayerPortraits/"
	
	var files : PoolStringArray = dir_contents(path)
	if files.size()==0:
		Log.warning("PlayerPortrait: Portrait folder is either empty or can't be accessed")
		return
	
	var hurts = []
	var lusts = []
	var naked = ""
	var normal = ""
	var neutral_overlay = ""
	
	for file in files:
		if !normal && file.begins_with("normal"):
			normal = file
			continue
		
		if !neutral_overlay && file.begins_with("neutral"):
			neutral_overlay = file
			continue
		
		if !naked && file.begins_with("naked"):
			naked = file
			continue
		
		if file.begins_with("hurt"):
			hurts.append(file)
		elif file.begins_with("lust"):
			lusts.append(file)
	
	if !normal: # no normal variant somehow?
		if naked: # substitute with naked
			normal = naked
		else: # if not, just f off ig
			Log.warning("PlayerPortrait: Can't find normal or naked file for portrait")
			return
	normal = loadTexture(path.plus_file(normal))
	neutral_overlay = loadTexture(path.plus_file(neutral_overlay))
	
	var a = [normal]
	if neutral_overlay:
		a.append(neutral_overlay)
	
	doAddVariant([], a)
	
	if !naked:
		naked = normal
	else:
		naked = loadTexture(path.plus_file(naked))
	
	a = [naked]
	if neutral_overlay:
		a.append(neutral_overlay)
	
	doAddVariant(["naked"], a)
	
	
	for hurti in hurts.size():
		var hurtKey : String = formatVariantNum("hurt", hurti)
		var hurtFile : String = path.plus_file(hurts[hurti])
		
		var t = loadTexture(hurtFile)
		
		doAddVariant([hurtKey], [normal, t])
		doAddVariant([hurtKey, "naked"], [naked, t])
	
	for lusti in lusts.size():
		var lustKey : String = formatVariantNum("lust", lusti)
		var lustFile : String = path.plus_file(lusts[lusti])
		
		var t = loadTexture(lustFile)
		
		doAddVariant([lustKey], [normal, t])
		doAddVariant([lustKey, "naked"], [naked, t])
	
	totalHurt = hurts.size()
	totalLust = lusts.size()
	

func getFinalVariantForCharacter():
	var l = GM.pc.getLustLevel()
	var p = GM.pc.getPainLevel()
	
	var f = []
	var pvar = ""
	if l>p:
		pvar = getFinalVariantStringLust(l)
	else:
		pvar = getFinalVariantStringHurt(p)
	
	if pvar:
		f.append(pvar)
	
	if GM.pc.isFullyNaked():
		f.append("naked")
	
	return f

func getFinalVariantStringLust(perc:float) -> String:
	var v = getVariantForPercentageLevel(perc, totalLust)
	if v<0:
		return ""
	return formatVariantNum("lust", v)

func getFinalVariantStringHurt(perc:float) -> String:
	var v = getVariantForPercentageLevel(perc, totalHurt)
	if v<0:
		return ""
	return formatVariantNum("hurt", v)

func getVariantForPercentageLevel(perc:float=0.0, total:int=0) -> int:
	if total<=0:
		return -1
	
	var n : int = int(clamp(perc, 0.0, 1.0)*(total))-1 # total if perc>=1.0, else <total towards min 0 inclusive ig idk man i just work here. -1 cuz there should always be the normal one in case of min damage
	
	print(n)
	
	return n # return variant num

func formatVariantNum(variant:String, num:int) -> String:
	return variant + str(num).pad_zeros(2)

func doAddVariant(variant:Array, fullPath):
	addCharacter("RAT_FakePlayer", variant, fullPath)

func dir_contents(path) -> PoolStringArray:
	var r : PoolStringArray = []
	# copy-pasted but who cares tbh
	var dir : Directory = Directory.new()
	if !dir.dir_exists(path):
		Log.warning("PlayerPortrait: Portrait folder can't be found; follow instructions in README.txt")
		return r
	
	var er = dir.open(path)
	if er == OK:
		dir.list_dir_begin(true)
		var file_name = dir.get_next()
		while file_name != "":
			if !dir.current_is_dir() && file_name.get_extension()=="png":
				r.append(file_name)
#				print("Found directory: " + file_name)
#			else:
#				print("Found file: " + file_name)
			file_name = dir.get_next()
	else:
		Log.warning("PlayerPortrait: Portrait folder can't be accessed for some reason, error code: %s" % er)
	
	return r

func loadTexture(p:String) -> ImageTexture:
	var img = Image.new()
	if img.load(p)==OK:
		var t = ImageTexture.new()
		t.create_from_image(img)
		return t
	return null
