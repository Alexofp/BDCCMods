extends WorldEditBase

func _init():
	id = "RAT_PortraitEdit"
	isRegular = true

func apply(_world: GameWorld):
#	if GM.ui:
#		GM.ui.connect("on_option_button", self, "dothething")
	dothething()

func dothething() -> void:
	var panel = GM.ui.smartCharacterPanel
	if panel.characters.empty():
#	panel.clear()
		panel.addCharacter("RAT_FakePlayer", getCurrentVariant())
	elif "RAT_FakePlayer" in panel.characters.keys()[0] && panel.characters.size()>1:
		panel.removeCharacter("RAT_FakePlayer")
#	panel.artworkPanel.characterStatusGrid.hide()

func getCurrentVariant() -> Array:
	var pack = GlobalRegistry.imagePacks.get("RAT_PlayerPortrait", null)
	if !pack:
		return []
	return pack.getFinalVariantForCharacter()

#on_option_button
