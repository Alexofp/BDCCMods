extends Character

func _init():
	id = "RAT_FakePlayer"
	
	npcLevel = 30
	npcBasePain = 100
	npcBaseLust = 130
	npcBaseStamina = 120
	npcCharacterType = CharacterType.Inmate
	
	disableSerialization = true

func getName():
	return GM.pc.getName()

func getGender():
	return GM.pc.getGender()
	
func getSmallDescription() -> String:
	return GM.pc.getSmallDescription()

func getSpecies():
	return GM.pc.getSpecies()

#func _getAttacks():
#	return ["biteattack", "StrongBite", "kickToBallsAttack", "stunbatonAttack", "stunbatonStrongAttack", "stunbatonOverchargeAttack", "ShivAttack", "stretchingAttack", "lickWounds", "shoveattack", "trygetupattack", "TaviAlluringGaze", "TaviFelineGrace", "TaviSeductiveWhispers", "TaviSensualScratches", "TaviTemptingTease"]

#func getFightIntro(_battleName):
#	return getName() + " gets into the combat stance and prepares for a fight. "+formatSay("Your not afraid are you, little lamb~?")

func getThickness() -> int:
	return GM.pc.getThickness()

func getFemininity() -> int:
	return GM.pc.getFemininity()

func getChatColor():
	return GM.main.getModuleFlag("PlayerPortrait", "PortraitNameColor", GM.pc.getChatColor())
