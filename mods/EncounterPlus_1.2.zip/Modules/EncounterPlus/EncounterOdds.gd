extends Object

const NPC_APPROACH_THRESHOLD = 30.0

static func setting(field:String, fallback):
	var aurysEncounterModule = GlobalRegistry.getModules().get("EncounterPlus")
	if(aurysEncounterModule == null):
		return fallback
	var value = aurysEncounterModule.get(field)
	if(value == null):
		return fallback
	return clamp(float(value), 1.0, 100.0)

static func encounterThreshold():
	return setting("encounterThreshold",NPC_APPROACH_THRESHOLD)
