extends Module

var name = "EncounterPlus"

var encounterThreshold = 30.0

func _init():
	id = "EncounterPlus"
	author = "Aurys"

	events = ["res://Modules/EncounterPlus/MoreEncounters.gd"]

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addNumberOption("encounterThreshold", "Encounter Threshold", "How many NPCs you have to meet before guaranteeing an interaction. Default is 30.", encounterThreshold)
