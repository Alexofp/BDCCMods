extends "res://Game/InteractionSystem/Interactions/Talking.gd"
const EncounterOdds := preload("res://Modules/EncounterPlus/EncounterOdds.gd")



func _init():
	id = "AurysTalkEncounter"																			
	
	
func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	
	
func getPriority():
	return 0


var currentCooldown = 0																				#Current value for the cooldown/buildup value, increases as the PC encounters other Pawns



func run(_triggerID, _args)	:
	if(state == "about_to_leave"):
		
		return 0

func react(_triggerID, _args):
	
	
	if(_triggerID == Trigger.EnteringRoom):															#Upon entering any room...
		
		var threshold = EncounterOdds.encounterThreshold()												#Threshold to meet before talking event occurs
		
		
		var currentPopIDs = GM.main.IS.getPawnIDsAt(GM.pc.location)									#Makes a list of all Pawn IDs in the room
		#print("Current Pawns Here PC Included:", currentPopIDs)


		if currentPopIDs.size() < 2:																#If only the PC is present...
			pass																					#Pass
		else:																						#If there are two or more Pawns present...


			currentPopIDs.erase("pc")																#Removes the PC from the list of Pawn IDs in the room
			#print("Current Pawns Here:", currentPopIDs)

			var currentPopNum = currentPopIDs.size()												#Counts the number of Pawns in the room
			#print("Current Population Number is: ", currentPopNum)

			currentCooldown += currentPopNum														#Increases the cooldown/buildup value equal to the number of Pawns in the room
			#print("Current Encounter Buildup is:", currentCooldown)

			if(currentPopNum > 0 && currentCooldown > threshold):									#If there is at least one NPC, and the cooldown/buildup value is greater than the threshold...

				currentCooldown = 0																	#Reset cooldown/buildup value
				var starter = currentPopIDs[randi() % currentPopIDs.size()]							#Set a random NPC from the list to be the starter for the upcoming talking scene
				#print("Starter is: ", starter)

				if starter :																		#If the starter is not null/nil...

					#getPawn(getRoleID("inmate"))
					var reacter= GM.pc.getID()														#Set the PC to be the reacter for the upcoming talking scene
					#print("Reacter is: ", reacter)
					#var _chars = { "starter" : other, "reacter" : GM.pc.getID()}
					doInvolvePawn(getRoleID(starter), starter, false)								#Involve the starter
					doInvolvePawn(getRoleID(reacter), reacter, false)								#Involve the reacter
					startInteraction("Talking", {starter= starter  , reacter= reacter})				#Start the talking scene
					
									
				else :																				#If either the population is zero, or the cooldown/buildup value does not meet the threshold...
					return																			#Run it back
					
		
