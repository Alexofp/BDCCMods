extends Module

var hairs : Dictionary = {
	# id: state
}

func _init():
	id = "RAT_GetAHaircut"
	author = "Selinoccino"

func postInit():
	load("res://Modules/RAT_GetAHaircut/codegen.gd").do()

func isHairEnabled(hair:String) -> bool:
	var option = hairs.get(hair)
	if option:
		return option.getOptionValue()
	
	return true

func onFoxLibModInit(foxModuleAPI):
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Hair)
	for hairid in all:
		var bp = GlobalRegistry.getBodypartRef(hairid)
		hairs[hairid] = foxModuleAPI.addBooleanOptionInCategory("Get A Haircut (Rat)", hairid, "%s (%s)" % [ bp.visibleName if bp else "Error", hairid ], "Created by: %s\n\nEnable or disable this hairstyle" % (bp.author if bp && bp.author else "(unknown)"), isHairEnabled(hairid)).advanced()
	


