extends Module

var hairs : Dictionary = {
	# id: state
}

func _init():
	id = "RAT_GetAHaircut"
	author = "Selinoccino"
	

func postInit():
	load("res://Modules/RAT_GetAHaircut/codegen.gd").do()

func isHairEnabled(hair:String) -> bool:
	var option = hairs.get(hair)
	if option:
		return option.getValue()
	
	return true

func RatConfigure(ratc):
	ratc.overrideModConfigName(id, "Get a Haircut! (Rat)")
	
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Hair)
	for hairid in all:
		var bp = GlobalRegistry.getBodypartRef(hairid)
		var cat : String = getCat(bp.getTraits())
		hairs[hairid] = ratc.addOptionBool(id, hairid, cat, bp.visibleName if bp else ("Error (%s)" % hairid), "Created by: %s\n\nEnable or disable this hairstyle" % (bp.author if bp && bp.author else "(unknown)"), true)
	

func getCat(traits) -> String:
	if !traits:
		return "Generic Hairstyles"
	
	var f = traits.keys()[0]
	var c : String = "Generic"
	
	if f == PartTrait.HairBald:
		c = "Bald"
	elif f == PartTrait.HairLong:
		c = "Long"
	elif f == PartTrait.HairOvereye:
		c = "Overeye"
	elif f == PartTrait.HairPonytail:
		c = "Ponytail"
	elif f == PartTrait.HairShort:
		c = "Short"
	elif f == PartTrait.HairVeryShort:
		c = "Very Short"
	
	return c+" Hairstyles"

