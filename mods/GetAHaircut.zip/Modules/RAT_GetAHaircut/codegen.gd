extends Node

static func do() -> void:
	for bp in GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Hair):
		var bpo = GlobalRegistry.getBodypartRef(bp)
		if !bpo:
			continue
		var path = bpo.get_script().resource_path
		
		
		var scriptText = "\n".join([ # the actual code generation
			"extends \"%s\"" % path, # we extend from the script file we just got, to inherit and replace its functions
			"func npcGenerationWeight(_dynamicCharacter):",
			"	if GlobalRegistry.getModule(\"RAT_GetAHaircut\").isHairEnabled(id):",
			"		return .npcGenerationWeight(_dynamicCharacter)",
			"	return 0.0",
			"	",
		])
		
		
		var file : Resource = bpo.get_script().duplicate()
		file.source_code = scriptText
		file.reload()
		
		var nbpo = file.new()
		var bid = bpo.id
		GlobalRegistry.bodyparts[bid].free()
		GlobalRegistry.bodyparts[bid] = nbpo
		GlobalRegistry.bodypartStorageNode.add_child(nbpo)
		
