extends Node

const codeGenReplacementsFolder = "res://RAT_GetAHaircut/" # save new files here

static func do() -> void:
	var d = Directory.new()
	if !d.dir_exists(codeGenReplacementsFolder): # make the dir
		d.make_dir_recursive(codeGenReplacementsFolder)
	
	for bp in GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Hair):
		var bpo = GlobalRegistry.getBodypartRef(bp)
		if !bpo:
			continue
		var path = bpo.get_script().resource_path
		
#		var newPath = codeGenReplacementsFolder+path.get_file() # where we'll save the new one
		
		
		var scriptText = "\n".join([ # the actual code generation
			"extends \"%s\"" % path, # we extend from the script file we just got, to inherit and replace its functions
			"func npcGenerationWeight(_dynamicCharacter):",
			"	if GlobalRegistry.getModule(\"RAT_GetAHaircut\").isHairEnabled(id):",
			"		print(\"yay \"+id)",
			"		return .npcGenerationWeight(_dynamicCharacter)",
			"	return 0.0",
			"	",
		])
		
		
		var file : Resource = bpo.get_script().duplicate()
		file.source_code = scriptText
		file.reload()
#		if file.file_exists(newPath):
#			if file.open(newPath,File.READ)==OK: # file open successfully
#				if file.get_as_text().sha256_text()==scriptText.sha256_text():
#					continue # ignore if it's the same
#				file.close()
		
#		if file.open(newPath,File.WRITE)!=OK: # creating the file failed, move on
#			continue
		
		
#		file.store_string(scriptText) # sstore new script data
		
		
#		file.close() # close the file to save it
		
		var nbpo = file.new()
		var bid = bpo.id
		GlobalRegistry.bodyparts[bid].free()
		GlobalRegistry.bodyparts[bid] = nbpo
		GlobalRegistry.bodypartStorageNode.add_child(nbpo)
		
		# register to replace the original
		
