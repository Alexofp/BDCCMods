# Changelog

## 0.1.1

- Correctly check for wearing a chastity cage in scenes
- Fix multiple disabled 'pee' buttons existing in places you could pee with Free-Roam
- Fixed peeing into items at the toilet
- Made descriptions of vaginas less average-sized and average-looking

## 0.1.0

- Initial release
