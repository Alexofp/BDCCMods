# Changelog

## 0.3.0

- Added ability to pee during tribadism
- Added ability to pee when getting oral to your vagina
- Meat toilet scene is now free to enter even without any levels in the skill
- XP awarded to the skill now scales based on how much pee is involved. This should make leveling the skill a lot faster.
- If you have both a vagina and a penis, you now get to choose which one you pee with when selecting the 'Piss On' button during sex
- Added starting perk that you can take during character creation to unlock peeing during combat and sex
- Fixed the Meat Toilet scene not giving any XP

## 0.2.1

- Fixed issue that made it so you couldn't pee in a sub's vagina
- Fixed issue where if you pulled out of a hole the game would still say you peed in it
- Fixed issue where you could not pee inside a sub's mouth in some situations
- Introduced the linear concept of time to the meat toilet scene

## 0.2.0

- Add scene where you volunteer to be a meat toilet in the bathroom.
    This is identical in spirit to @reggie_the_fennec's old Toilet Slave mod, though expanded upon to be more detailed. A very big thank you to them for the idea and for giving permission to ~~steal~~ integrate it!

## 0.1.1

- Correctly check for wearing a chastity cage in scenes
- Fix multiple disabled 'pee' buttons existing in places you could pee with Free-Roam
- Fixed peeing into items at the toilet
- Made descriptions of vaginas less average-sized and average-looking

## 0.1.0

- Initial release
