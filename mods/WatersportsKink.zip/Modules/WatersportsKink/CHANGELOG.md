# Changelog

## 0.2.0

- Add scene where you volunteer to be a meat toilet in the bathroom.
    This is identical in spirit to @reggie_the_fennec's old Toilet Slave mod, though expanded upon to be more detailed. A very big thank you to them for the idea and for giving permission to ~~steal~~ integrate it!

## 0.1.1

- Correctly check for wearing a chastity cage in scenes
- Fix multiple disabled 'pee' buttons existing in places you could pee with Free-Roam
- Fixed peeing into items at the toilet
- Made descriptions of vaginas less average-sized and average-looking

## 0.1.0

- Initial release
