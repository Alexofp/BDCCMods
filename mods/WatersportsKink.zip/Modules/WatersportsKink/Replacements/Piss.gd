extends "res://Player/Fluids/Fluids/Piss.gd"
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func getMessyDescription(character, amount):
	if character.hasPerk(WsUtil.Perk_Urolagnia):
		if amount >= 500.0:
			return "You are soaked in piss and you love it."
		if amount >= 300.0:
			return "You smell strongly of piss... Other people probably won't like it as much as you."
		if amount >= 100.0:
			return "You smell of piss. It's not bad, but others might disagree."
		else:
			return "You faintly smell of piss. Either shower or [i]go shower[/i]."
	else:
		if (amount >= 300.0):
			return "You have a strong scent of piss attached to you!"
		if (amount >= 100.0):
			return "You smell gross! Better not let others near you."
		
		return "You have a faint gross scent attached to you."

func getMessyBuffs(character, amount):
	if character.hasPerk(WsUtil.Perk_Urolagnia):
		if amount >= 500.0:
			return [
				buff(Buff.AmbientLustBuff, [30]),
			]
		if amount >= 300.0:
			return [
				buff(Buff.AmbientLustBuff, [15])
			]
		if amount >= 100.0:
			return [
				buff(Buff.AmbientLustBuff, [10])
			]

		return [
			buff(Buff.AmbientLustBuff, [5])
		]
	else:
		if (amount >= 500.0):
			return [
				buff(Buff.LustDamageBuff, [-80]),
				buff(Buff.LustArmorBuff, [50]),
			]
		if (amount >= 100.0):
			return [
				buff(Buff.LustDamageBuff, [-60]),
				buff(Buff.LustArmorBuff, [20]),
			]
		return [
			buff(Buff.LustDamageBuff, [-30]),
			buff(Buff.LustArmorBuff, [10]),
		]

func getBellyBuffs(character, amount):
	var buffs = []
	var messLevel = Util.mini(int(amount / 100), 10)

	if character.hasPerk(WsUtil.Perk_Lemonade):
		if messLevel > 0:
			buffs.push_back(
				buff(Buff.MaxStaminaBuff, [5 * messLevel])
			)

	# "But won't this make piss extremely overpowered?"
	# Yes.
	if (character.hasPerk(Perk.CumBreathV1)):
		if (messLevel > 0):
			buffs.push_back(
				buff(Buff.ReceivedLustDamageBuff, [-2 * messLevel])
			)

	if buffs.empty():
		if (messLevel > 0):
			buffs.push_back(
				buff(Buff.MaxStaminaBuff, [-5 * messLevel])
			)
	
	return buffs

func onSwallow(character: BaseCharacter, amount):
	var painHeal = Util.mini(int(amount / 10), 10)
	var staminaHeal = Util.mini(int(amount / 20), 5)
	if painHeal <= 0:
		return null

	if character.hasPerk(WsUtil.Perk_Lemonade):
		character.addPain(-painHeal)
		character.addStamina(staminaHeal)
		character.addLust(staminaHeal)
		return "Drinking piss soothed {name} and turned {him} on, granting {painHeal}, [color={staminaColor}] {staminaAmount} stamina[/color], and {lustAdd}.".format({
			"name": character.getName(),
			"him": character.himHer(),
			"painHeal": DamageType.getDamageColoredString(DamageType.Physical, -painHeal),
			"staminaColor": DamageType.getColorString(DamageType.Stamina),
			"staminaAmount": staminaHeal,
			"lustAdd": DamageType.getDamageColoredString(DamageType.Lust, staminaHeal),
		})
	else:
		character.addLust(-painHeal)
		return "Drinking piss grossed {name} out, removing {lustRemove}.".format({
			"name": character.getName(),
			"lustRemove": DamageType.getDamageColoredString(DamageType.Lust, painHeal),
		})

func onGettingHitWith(character: BaseCharacter, amount: float):
	var likesCum = 1.0 if character.hasPerk(WsUtil.Perk_Urolagnia) else -1.0
	
	var lustToAdd = int(likesCum * sqrt(amount) / 1.0)
	var staminaToDrain = int(sqrt(amount)) * 2
	
	var text = ""
	if (lustToAdd < 0):
		text += character.getName() + " hated getting splashed with piss!"
	elif (lustToAdd > 0):
		text += character.getName() + " " + RNG.pick(["loved", "enjoyed", "got lusty from", "liked", "got aroused from"]) + " getting splashed with piss!"
	
	var painToAdd = 0
	if (RNG.chance(4.0 * sqrt(amount)) && !character.hasEffect(StatusEffect.Collapsed)):
		if (text != ""):
			text += " "
		text += character.getName() + " slipped on piss, ow!"
		character.addEffect(StatusEffect.Collapsed)
		painToAdd = 10
	
	if !character.hasPerk(WsUtil.Perk_Urolagnia):
		if (RNG.chance(4.0 * sqrt(amount)) && !character.hasEffect(StatusEffect.Weakness)):
			if (text != ""):
				text += " "
			text += character.getName() + " got very grossed out from getting covered in piss!"
			character.addEffect(StatusEffect.Weakness, [Util.mini(3, 1 + int(amount / 2000))])
	else:
		if RNG.chance(4.0 * sqrt(amount)) && !character.hasEffect(StatusEffect.Blindness):
			if text != "":
				text += " "
			text += character.getName() + " got " + RNG.pick(["pee", "piss", "urine"]) + " in their eyes and can't see!"
			character.addEffect(StatusEffect.Blindness, [Util.mini(3, 1 + int(amount / 2000))])
		
	return {
		text = text,
		lust = lustToAdd,
		stamina = staminaToDrain,
		pain = painToAdd,
	}
