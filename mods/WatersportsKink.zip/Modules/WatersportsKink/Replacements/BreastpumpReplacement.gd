extends "res://Inventory/Items/BreastPump.gd"
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func getPossibleActions():
	var result: Array =.getPossibleActions()

	if GM.pc != null:
		if GM.pc.hasPerk(WsUtil.Perk_FreeRoam):
			result.push_back({
				"name": "Pee Into",
				"scene": WsUtil.Scene_PeeInto,
				"description": "Pee into the breast pump",
			})
	return result

func getTags():
	var result =.getTags()

	result.push_back(ItemTag.CanPeeInto)

	return result