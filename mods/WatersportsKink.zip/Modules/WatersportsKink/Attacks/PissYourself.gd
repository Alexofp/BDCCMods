extends Attack
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

func _init():
	id = WsUtil.Attack_PissYourself
	category = Category.Special
	aiCategory = AICategory.Defensive
	
func getVisibleName(_context = {}):
	return "Piss Yourself"
	
func getVisibleDesc(_context = {}):
	return "Piss yourself in combat to assert dominance."
	
func _doAttack(attacker: BaseCharacter, receiver: BaseCharacter, _context = {}):
	# if attacker.hasPenis():
		# var penis: BodypartPenis = attacker.getBodypart(BodypartSlot.Penis)
	PissWrapper.peeOntoCharacter(attacker, attacker)

	var text = "{attacker.name} pisses {attacker.himself}."
	var lustChange = 0

	# TODO: Make this respect fetish system
	if !receiver.hasPerk(WsUtil.Perk_Urolagnia):
		receiver.addEffect(StatusEffect.Stunned)
		lustChange = -15
		text += "\n\n{receiver.name} was [b]disgusted[/b]!"
	else:
		lustChange = 15
		text += "\n\n{receiver.name} [b]liked what they saw[/b]!"

	# Attacks cannot deal negative damage, so we have to improvise.
	text += WsUtil.pretendDamage(receiver, DamageType.Lust, lustChange)

	return {
		text = text,
	}

func _canUse(attacker, _receiver, _context = {}):
	return PissWrapper.canPee(attacker)

func getRequirements():
	return []

func getAnticipationText(_attacker, _receiver):
	return "{attacker.name} closes {attacker.his} eyes and relaxes."

#func getAttackSoloAnimation():
#	return "shove"

func getExperience():
	return [[WsUtil.SkillId, 15]]
