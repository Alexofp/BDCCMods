extends Attack
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

func _init():
	id = WsUtil.Attack_PissOn
	category = Category.Special
	aiCategory = AICategory.Offensive

func getVisibleName(_context = {}):
	return "Piss On"

func getVisibleDesc(_context = {}):
	if GM.pc.hasPerk(WsUtil.Perk_Alpha):
		return "Piss on your opponent. Makes your opponent do 15% less damage for two turns."
	else:
		return "Piss on your opponent."

func _canUse(attacker: BaseCharacter, receiver: BaseCharacter, _context = {}):
	if receiver.hasEffect(WsUtil.StatusEffect_PissBeta):
		return false
	return PissWrapper.canPee(attacker)

func getAnticipationText(attacker: BaseCharacter, _receiver):
	if attacker.hasReachablePenis():
		return "{attacker.name} reaches down and grabs {attacker.his} {attacker.penis}, preparing to piss."
	elif attacker.isWearingChastityCage():
		return "{attacker.name} reaches down and grabs {attacker.his} {attacker.penisShort}, angling it and preparing to piss."
	elif attacker.hasReachableVagina():
		return "{attacker.name} reaches down and spreads {attacker.his} {attacker.pussyStretch} {pussy}, preparing to piss."
	else:
		return "{attacker.name} angles {attacker.himself}, preparing to piss."

func _doAttack(attacker: BaseCharacter, receiver: BaseCharacter, _context = {}):
	if checkMissed(attacker, receiver, DamageType.Physical, 0.5):
		PissWrapper.peeOntoCharacter(attacker, attacker)
		return {
			text = "{attacker.name} tried to piss on {receiver.name} but missed, and pissed on {attacker.himself} instead!",
			missed = true,
		}
	if checkDodged(attacker, receiver, DamageType.Physical, 0.5):
		return genericDodgeMessage(attacker, receiver, "piss on")
	
	PissWrapper.peeOntoCharacter(attacker, receiver)

	var text = RNG.pick([
		"{attacker.name} " + RNG.pick(["pees", "pisses"]) + " on {receiver.name}.",
		"{attacker.name} soaks {receiver.name} with {attacker.his} {attacker.piss}.",
		"{attacker.name} {attacker.verbS('manage')} to splash {receiver.name} with {attacker.his} {attacker.piss}."
	])

	var lustReceived = 0
	var damageReduction = 15

	if receiver.hasPerk(WsUtil.Perk_Urolagnia):
		lustReceived = 10
		damageReduction = 10

	if attacker.hasPerk(WsUtil.Perk_Alpha):
		receiver.addEffect(WsUtil.StatusEffect_PissBeta, [2, damageReduction])

	if attacker.getID() == "pc":
		attacker.getReputation().addRep(RepStat.Alpha, 0.2)

	if lustReceived > 0:
		text += " Seems like they liked it..."
		return {
			text = text,
			lust = lustReceived
		}
	else:
		return {
			text = text
		}

func getExperience():
	return [[WsUtil.SkillId, 15]]
