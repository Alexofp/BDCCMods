extends EventBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

const ROOM_NOVA = "yard_novaspot"
const ROOM_ARTICA = "main_bench3"
const ROOM_CANTEEN = "hall_canteen"
const ROOM_LAUNDRY = "main_laundry"

const ROOM_RAHI_CELL = "cellblock_orange_nearcell"
const ROOM_TAVI_CELL = "cellblock_red_nearcell"
const ROOM_PC_CELLS = ["cellblock_orange_playercell", "cellblock_pink_playercell", "cellblock_red_playercell"]

const ROOM_SLUT_WALL = "fight_slutwall"

const ROOM_MINING = "mining_shafts_entering"

const ROOM_TAVI_MINING = "mining_taviroom"

const ROOM_ALEX_SOCKET = "eng_workshop"
const ROOM_COMPUTER = "eng_lorecomputerroom"
const ROOM_NURA = "eng_robotics"

const ROOM_AUCTION = "market_market"

const ROOM_LIST_YARD = [
	"yard_corridor1", "yard_firstroom", "yard_nearstairs",
	"yard_westCorridor", "yard_eastCorridor",
	"yard_neargym", "yard_northCorridor", "yard_corridor2", "yard_corridor3", "yard_corridor4", "yard_vaulthere",
	"yard_deadend1", "yard_deadend2", "yard_waterfall"
]

const ROOM_LIST_GREENHOUSE = [
	"main_green_corridor7", "main_green_corridor8",
	"main_green_corridor9", "main_green_corridor10",
	"main_green_corridor11", "main_greenhouses",
]

func _init():
	id = WsUtil.Event_PissInPublic

func registerTriggers(es):
	for room_id in ROOM_LIST_YARD:
		es.addTrigger(self, Trigger.EnteringRoom, room_id)
	for room_id in ROOM_LIST_GREENHOUSE:
		es.addTrigger(self, Trigger.EnteringRoom, room_id)
	for room_id in ROOM_PC_CELLS:
		es.addTrigger(self, Trigger.EnteringRoom, room_id)

	var room_list = [
		## Main floor
		ROOM_NOVA,
		# ROOM_ARTICA,
		# ROOM_CANTEEN,
		# ROOM_LAUNDRY,

		## Cell blocks
		# ROOM_RAHI_CELL,
		# ROOM_TAVI_CELL,

		## Arena area
		# ROOM_SLUT_WALL,

		## Mining floor
		# ROOM_MINING,
		# ROOM_TAVI_MINING,
		ROOM_ALEX_SOCKET,
		# ROOM_COMPUTER,
		# ROOM_NURA,

		## Blacktail ship
		# ROOM_AUCTION,
	]

	for room_id in room_list:
		es.addTrigger(self, Trigger.EnteringRoom, room_id)

func run(_triggerID: String, args: Array):
	if GM.pc == null:
		return
	if args.empty():
		return
	var room_id = args[0]

	if !GM.pc.hasPerk(WsUtil.Perk_FreeRoam):
		return

	var disabled = false
	var name = "UNUSED"
	var tooltip = "If you see this text, this is a bug!"

	if room_id in ROOM_PC_CELLS:
		if room_id == GM.pc.getCellLocation():
			disabled = false
			name = "public_pee_pc_cell"
			tooltip = "Pee in your cell."
		else:
			return
	elif ROOM_LIST_YARD.has(room_id):
		disabled = false
		name = "public_pee_yard"
		tooltip = "You need to go pee, and the yard looks pretty empty..."
	elif ROOM_LIST_GREENHOUSE.has(room_id):
		disabled = false
		name = "public_pee_greenhouse"
		tooltip = "The greenhouse seems like a nice place to go pee."
	elif room_id == ROOM_NOVA:
		disabled = true
		name = "public_pee_nova"
		tooltip = "Nova may be nice but she isn't going to just let you piss on the ground."
	elif room_id == ROOM_ARTICA:
		disabled = true
		name = "public_pee_artica"
		tooltip = "Who the hell is Artica?"
	elif room_id == ROOM_CANTEEN:
		disabled = false
		name = "public_pee_canteen"
		tooltip = "Piss where you eat. Surely people won't get mad."
	elif room_id == ROOM_LAUNDRY:
		disabled = false
		name = "public_pee_laundry"
		tooltip = "...This place is for dirty stuff anyway, right?"
	elif room_id == ROOM_RAHI_CELL:
		disabled = true
		name = "pubic_pee_rahi"
		tooltip = "Who the hell is Rahi?"
	elif room_id == ROOM_TAVI_CELL:
		disabled = true
		name = "public_pee_tavi_2"
		tooltip = "Who the hell is Tavi?"
	elif room_id == ROOM_SLUT_WALL:
		disabled = true
		name = "pubic_pee_slutwall"
		tooltip = "Who the hell is Avy?"
	elif room_id == ROOM_MINING:
		disabled = false
		name = "public_pee_mining"
		tooltip = "Nothing beats hard work and pissing."
	elif room_id == ROOM_TAVI_MINING:
		disabled = true
		name = "pubic_pee_tavi_mining"
		tooltip = "Who the hell is Tavi?"
	elif room_id == ROOM_ALEX_SOCKET:
		disabled = true
		name = "pubic_pee_workshop"
		tooltip = "Alex would kill you. Like, you'd be straight up dead."
	elif room_id == ROOM_COMPUTER:
		disabled = false
		name = "pubic_pee_computer"
		tooltip = "Piss near a delicate computer. It'll probably be fine."
	elif room_id == ROOM_NURA:
		disabled = true
		name = "pubic_pee_robot"
		tooltip = "Who the hell is Nur-A?"
	elif room_id == ROOM_AUCTION:
		disabled = false
		name = "public_pee_auction"
		tooltip = "If Mirri or Luxe saw you doing this they'd have your head. Luckily they aren't here."

	if disabled:
		_addDisabledButton("Pee", tooltip)
	elif !PissWrapper.canPee(GM.pc):
		_addDisabledButton("Pee", "You don't need to go pee right now.")
	elif GM.pc.hasBlockedHands():
		_addDisabledButton("Pee", "You must be able to use your hands to do this.")
	else:
		_addButton("Pee", tooltip, name)

	
func getPriority():
	return 0

func onButton(method, _args):
	# TODO: Scenes for peeing
	match method:
		"public_pee_pc_cell":
			runScene(WsUtil.Scene_PeeInPublic_YourCell, [])
			return
		"public_pee_yard":
			runScene(WsUtil.Scene_PeeInPublic_Yard, [])
			return
		"public_pee_greenhouse":
			runScene(WsUtil.Scene_PeeInPublic_Greenhouse, [])
			return
		_:
			GM.main.addMessage("missing trigger for: " + method)

func _addButton(text: String, tooltip: String, method: String, args: Array = []):
	var buttons: Dictionary = GM.ui.get("options")
	if buttons.get(4) == null:
		GM.ui.addButtonAt(4, text, tooltip, "EVENTSYSTEM_BUTTON", [self, method, args])
	elif buttons.get(8) == null:
		GM.ui.addButtonAt(8, text, tooltip, "EVENTSYSTEM_BUTTON", [self, method, args])
	else:
		GM.ui.addButton(text, tooltip, "EVENTSYSTEM_BUTTON", [self, method, args])

func _addDisabledButton(text: String, tooltip: String):
	var buttons: Dictionary = GM.ui.get("options")
	if buttons.get(4) == null:
		GM.ui.addDisabledButtonAt(4, text, tooltip)
	elif buttons.get(8) == null:
		GM.ui.addDisabledButtonAt(8, text, tooltip)
	else:
		GM.ui.addDisabledButton(text, tooltip)