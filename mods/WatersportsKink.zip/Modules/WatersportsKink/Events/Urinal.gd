extends EventBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

const BATHROOMS = [
	"main_bathroom1",
	"main_bathroom2",
	# "cellblock_pink_playercell"
]

func _init():
	id = WsUtil.Event_Urinal

func registerTriggers(es: EventSystem):
	for room in BATHROOMS:
		es.addTrigger(self, Trigger.EnteringRoom, room)

func run(_triggerID, args):
	addButton("Urinals", "Inspect the urinals", "urinal_willing", [args[0]])

func onButton(method, args):
	if method == "urinal_willing":
		runScene(WsUtil.Scene_MeatToilet_Willing, [args[0]])
	else:
		GM.main.addMessage("no handler found for method " + method + ". report this to frivolous.")

func getPriority():
	return -1