extends SceneBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

const CELL_TO_OUTSIDE_CELL = {
	"cellblock_orange_playercell": "cellblock_orange_nearcell",
	"cellblock_pink_playercell": "cellblock_lilac_nearcell",
	"cellblock_red_playercell": "cellblock_red_nearcell",
}

func _init():
	sceneID = WsUtil.Scene_PeeInPublic_YourCell

func _run():
	var genitals = "unknown"
	if GM.pc.hasPenis():
		if GM.pc.isWearingChastityCage():
			genitals = "chastity_cage"
		else:
			genitals = "penis"
	elif GM.pc.hasVagina():
		genitals = "vagina"
	else:
		genitals = "other"
	
	if state == "":
		saynn("You decide that you want to relieve yourself in your own cell. This is complicated by the fact that you do not actually have a toilet. You're not entirely sure why, but none of the cells in this prison have one. The doors remain unlocked all night so it's never been a problem, but it's just another one of those 'fun' quirks of the place.")

		saynn("Still, a lack of a toilet won't stop you. You need to go [i]now[/i] and walking upstairs to the toilets just won't work. Or rather, you don't want to do it. You are unafraid of the consequences. Someone will probably clean your cell eventually, right?")

		if !hasJunkExposed():
			saynn("You decide that getting your clothes messy is a bad idea and quickly remove them.")

		saynn("Looking at your cell, you only really have a couple options. The pee corner is a classic, but it'll leave a gross puddle on the floor. You have a stool, which... might be fine, though it has the same problem of leaving a puddle. And of course you have your bed, but it's probably a bad idea to willingly piss in your own bed. You have to sleep in that, after all.")

		addButton("Corner", "A piss corner is a time honored tradition", "corner_1", [])
		addButton("Stool", "That stool looks pretty comfortable", "stool_1", [])
		addButtonUnlessLate("...Bed", "You want to piss your bed", "bed_1", [], "You need to sleep there tonight!")

		addButtonAt(4, "Never Mind", "You have changed your mind", "end_scene")
	if state == "corner_1":
		saynn("Classics are classics for a reason. You elect to establish a pee corner. After taking a moment to think about it, you meander over to your chosen corner and assume the position, aiming at the wall. You sigh, close your eyes, and let the urge to go overtake you.")

		if genitals == "penis":
			saynn("It becomes obvious immediately that you were not far enough from the wall. Your legs get splashed immediately.")
		elif genitals == "chastity_cage":
			saynn("It becomes obvious immediately that you miscalculated how much of a mess you'd make in your cage. You get {pick('pee', 'piss')} all over your legs.")
		elif genitals == "vagina":
			saynn("It becomes obvious immediately that you didn't think the logistics of this through. {pick('Pee', 'Piss')} goes everywhere, getting all over your legs.")
		else:
			saynn("It becomes obvious immediately that you didn't think through how much of a mess you'd make. A lot of {pick('pee', 'piss')} gets on your legs.")
		
		saynn("You are also very quickly standing in a pool of your own {pick('pee', 'piss')}, one that's growing. Still, you keep going. There's no sense in stopping after you've already made a mess.")

		say("To be honest, it's kind of hot. You feel a spike of arousal go up your spine as you smell the thick piss smell and the warm fluid around your {pc.feet}. ")
		if genitals == "penis":
			say("You give your {pc.penisShort} a quick stroke and moan softly.")
		elif genitals == "chastity_cage":
			say("You give your {pc.penisShort} a pull and whimper.")
		elif genitals == "vagina":
			say("You rub your {vagina} several times and moan.")
		else:
			say("You give your genitals a rub and moan.")
		saynn(" The depravity of it all is getting you going.")

		addButton("Continue", "See what happens next", "corner_2")
	if state == "corner_2":
		saynn("After a while, the stream stops and you're left with just a pool of your pee with the strong smell of it in the air. You briefly wonder whether anyone else in the cellblock can smell it but decide you don't care. You give your hips a little shake and then your thoughts turn towards the future.")

		saynn("If you don't clean this up soon, your cell is going to smell like {pick('pee', 'piss', 'urine')} until it's deep cleaned. You knew that going in but it's different now that you can actually smell it and see the pool. You... actually aren't sure how often cells are cleaned by staff, if ever. This might be a long-term problem if you don't solve it yourself. Luckily towels are readily available to inmates, so you'd just need to head upstairs.")

		saynn("That said, you are feeling more than just a little horny. Maybe delaying a little wouldn't be so bad...")

		addButton("Clean Up", "Go to the laundry room", "cleanup_puddle1")
		addButton("Just Leave", "This is future " + GM.pc.getName() + "'s problem", "leave_puddle")
		addButton("Masturbate", "Solving this can wait", "masturbate_puddle")

	if state == "stool_1":
		saynn("{pick('Peeing', 'Pissing')} while standing is for the birds. You walk over to the stool and sit your fuzzy ass down. The way your cell is set up, the stool is very visible if someone were to look in, but... people rarely do that. Still, the thought is enough to put you on edge a little. It'd be really embarrassing if someone saw you doing this, not to mention how the guards might react.")

		saynn("You take a few deep breaths and spread your legs. You close your eyes and try to focus on nothing but the need to pee and the desire to let it go. After a couple of beats, you do just that and a stream of {pick('pee', 'piss')} starts coming out.")

		saynn("The sound of it hitting the floor is... Relaxing, in its own way. Now that the hard part is done you open your eyes and look. The stream of urine from your crotch is... hypnotic. It's also making a big mess, but that's future " + GM.pc.getName() + "'s problem. For now, you just enjoy.")

		say("You take a moment to dip your fingers into your piss stream before bringing them to your mouth. The salty-acrid taste causes a spike of arousal in you, and you almost shiver. This is naughty in a way that very few things are. ")
		if genitals == "penis":
			saynn("You can't help but start rubbing at your {pc.penisShort} a little and you let out a low groan.")
		elif genitals == "chastity_cage":
			saynn("You can't help but pull at your {pc.penisShort} a little and let out a low groan.")
		elif genitals == "vagina":
			saynn("You can't help but start rubbing at your {vagina} a little, and you let out a low groan.")
		else:
			saynn("You can't help but start rubbing at your crotch a little and let out a low grown")

		addButton("Continue", "See what happens next", "stool_2")
	if state == "stool_2":
		saynn("Eventually, the pool of your {pick('pee', 'piss')} that's forming in front of you stops growing and your piss stream comes to an end. It almost reaches your {pc.feet}. Luckily, it stops just short. You're left with a cell that smells strongly of {pick('pee', 'piss', 'urine')} and a floor with a nice sized puddle in the middle of it.")

		saynn("You... should probably clean that up. You aren't sure how often the cells are cleaned by staff. As hot as it is right now, it probably won't be once it dries and your cell just smells like stale urine. Luckily prisoners have essentially unlimited access to towels, so you'd just have to go upstairs and get some. It might linger a little bit, but it won't be anywhere near as bad.")

		saynn("If you're going to do that, now is the time. Though you are awfully horny, so it might be worth delaying just a little bit...")

		addButton("Clean Up", "Go to the laundry room", "cleanup_puddle1")
		addButton("Just Leave", "This is future " + GM.pc.getName() + "'s problem", "leave_puddle")
		addButton("Masturbate", "Solving this can wait", "masturbate_puddle")

	if state == "bed_1":
		saynn("You're feeling lazy, and you've already decided that you don't mind the mess. Your bed seems like a nice place to relax while you take a leak. You push the logistical concerns out of your mind. If anything, the fact that you sleep there makes it hotter.")

		saynn("Without another, you climb onto the mattress and lay on your back, legs spread. You sigh and close your eyes, trying to will yourself to pee. It... isn't working. You have a mental block against willingly {pick('peeing', 'pissing')} the bed. You force yourself to focus on the waterfall out in the yard. Splish splash. It makes you feel a bit silly, but it works. Soon you feel a warmness spreading out from your crotch beneath you.")

		saynn("It would be humiliating in the wrong circumstances, but as it is all you can think of is how nice it feels. The normal room temperature isn't cold per se, but it's nowhere near body temperature and it feels nice. You cannot help but let out a deep-seated sigh at the feeling. This prompts you to inhale, which gives you a nice smell of the mess you're making.")

		addButton("Continue", "See what happens next", "bed_2")
	if state == "bed_2":
		say("The fact that your bed smells like that now just turns you on. It's gross, but so are a lot of things if you think about them too much. So, you don’t and just enjoy the thoughts. ")
		if genitals == "penis":
			saynn("As your stream tapers off, your hand wanders down to your {pc.penisShort} and begins playing with it. You get some {pick('pee', 'piss')} on yourself, but you don't care. It works pretty well as a lube either way.")
		elif genitals == "chastity_cage":
			saynn("As your stream tapers off, your hand wanders down to your {pc.penisShort} and begins rubbing and pulling at it. You get some {pick('pee', 'piss')} on yourself and let out a whine.")
		elif genitals == "vagina":
			saynn("As your stream tapers off, you hand wanders down to your {vagina} and begin playing with it. You get {pick('pee', 'piss')} all over your hand and sigh.")
		else:
			saynn("As your stream tapers off, your hands wander down to your crotch and begin rubbing at your genitals. You get {pick('pee', 'piss')} on yourself, but you don't care.")

		saynn("You spend a few minutes playing with yourself on the {pick('pee', 'piss')}-soaked bed before reality catches up to you. The concerns you pushed out of your head are back in full now. You should really clean this up before it starts to dry. Stale {pick('pee', 'urine')} doesn't smell nearly as good as the fresh stuff, and you [i]do[/i] have to sleep here later. It'd suck if it was soaking wet.")

		saynn("Still, a part of you wants to finish what you've started and to hell with the consequences. You're plenty turned on, and it'd be easy to finish.")

		addButton("Clean Up", "Go to the laundry room", "cleanup_bed1")
		if GM.pc.hasPerk(WsUtil.Perk_Revelry):
			addButton("Just Leave", "Leave your bed soaked in pee", "leave_bed")
		else:
			addDisabledButton("Just Leave", "(Requires Revelry Perk)\nLeave your bed soaked in pee")
		addButton("Masturbate", "Solving this can wait", "masturbate_bed")

	if state == "cleanup_puddle1":
		say("You head out of your cell and up towards the laundry room. Hopefully nobody will look into your cell while you're gone... Or smell it. ")
		if GM.pc.hasPerk(Perk.NakedNoShame):
			saynn("You don't even bother putting your clothes back on.")
		else:
			saynn("You slide your clothes on. You might have to do laundry later, but it's better than everyone seeing you naked.")
		
		saynn("You stop once you're upstairs as you realize that towels are over by the showers. This means you have to go through the bathroom to get them. Turns out you had to go to the bathroom anyway. Though if you're being honest, it was an excuse either way. You just wanted to pee in your cell. Either way, it's a quick walk to the locker room. You grab a few towels and then hesitate before grabbing a few more. Then, you head back to your cell. A few inmates give you weird looks, but nobody tries to stop you.")

		addButton("Continue", "See what happens next", "cleanup_puddle2")
	if state == "cleanup_puddle2":
		saynn("Once you're back in your cell, you begin to frantically mop up the puddle of piss you've left on the floor. The white towels are dyed yellow by the {pick('pee', 'piss')}, but they do their job and after going through three towels the floor is just mildly damp. You're probably not going to be able to do better than that.")

		saynn("The towels smell disgusting and you quickly ferry them back upstairs and back to the locker room, where you drop them into the dirty towel bin. They're someone else's problem now. You then return to your cell.")

		addButton("Continue", "Another happy landing...", "end_scene")
	if state == "leave_puddle":
		saynn("Despite the problems it will cause, you decide to just leave the puddle of your own piss on the floor. You splash your {pc.feet} in it a little and then walk out the door of your cell, closing it behind you. The room will smell like {pick('pee', 'piss', 'urine')} for a long time now.")

		saynn("There's a silver lining though: you can't smell it from outside. If someone looks into the window, they'll be able to see the puddle though.")

		addButton("Continue", "Just let that stew for a bit", "end_scene")
	if state == "masturbate_puddle":
		saynn("Your head feels clearer after that, but the puddle on the floor hasn't gotten any smaller. You should still be able to get towels and prevent it from leaving behind the gross smell of stale urine. Assuming you wanted to, anyway.")

		addButton("Clean Up", "Go to the laundry room", "cleanup_puddle1")
		addButton("Just Leave", "This is future " + GM.pc.getName() + "'s problem", "leave_puddle")
		addDisabledButton("Masturbate", "You just did that")

	if state == "cleanup_bed1":
		saynn("You let out a groan and sit up and roll onto your {pc.feet}. Time to clean up.")

		saynn("You quickly strip the bed of the soaked sheets and inspect what passes for your mattress. It's just a mat of some kind, clearly designed to be easy to clean. The {pick('pee', 'piss')} hasn't soaked into it at all really, which bodes well for you. You're basically just mopping up a puddle.")

		saynn("You throw the sheets onto the ground for the moment and then leave your cell. You head upstairs, closing the cell behind you. The towels are over by the showers. This means you have to go through the bathroom to get them. Luckily {pick('peeing', 'pissing')} your bed was mostly just an excuse rather than laziness. It's a quick walk to the locker room. You grab an armful of towels, then head back to your cell. A guard raises an eyebrow but doesn't say anything.")

		addButton("Continue", "See what happens next", "cleanup_bed2")
	if state == "cleanup_bed2":
		saynn("Once you're back in your cell, you throw them onto your bed. The towels instantly start to soak up the {pick('pee', 'piss', 'urine')}, turning a pale yellow. You move them around with your hands. Your hands are dirty now but after you're done, the mattress is just damp. You probably won't be able to do better than that. Hopefully it won't smell too bad when it dries.")

		say("You grab your sheets and the towels and head upstairs. You take them both to the laundry room and drop them in a clothing bin. Technically you aren't meant to put towels in here, but that's not your problem. Who's going to stop you? You grab some clean sheets then head back to your cell. ")
		if GM.main.isVeryLate():
			saynn("You look down at the mattress. It... isn't really dry, but it's late and you should probably put the sheets on and go to bed. Reluctantly, you put the new sheets on the bed.")
			saynn("You take a step backwards and look at the bed. It... seems fine. There’re no visible wet spots or stains, anyway. It will have to do.")
		else:
			saynn("You put them down on the stool and head back outside your cell. You need to let the mattress finish drying and you're done today.")

		addButton("Continue", "See what happens next", "end_scene")
	if state == "leave_bed":
		saynn("Fuck it. You like {pick('pee', 'piss')}. You like it enough that despite knowing the consequences, you laid there and {pick('peed', 'pissed')} in your own bed. Your back is soaked in it and so are your sheets. You aren't afraid of the mess.")

		saynn("You decide to just leave your bed as-is. Yes, it will make the bed smell like {pick('pee', 'piss', 'urine')}. It will probably even make the room smell like it. But the thought just turns you on. You're a piss slut, and you aren't afraid to show it.")

		saynn("You get up and look back at the bed. The sheets are gross, clearly stained yellow with {pick('pee', 'piss', 'urine')}. Your head is briefly filled with doubt: it cannot be good for you to sleep on that. Still, after a few seconds you shake your head. It's not healthy to drink {pick('pee', 'piss', 'urine')} either and you still do that. The doctors will intervene if you get too sick and you can always shower later.")

		if GM.main.isVeryLate():
			say("This... may be a dumb decision. It's late, and you'll need to sleep soon. A soaking wet bed is going to be even less comfortable than normal to sleep in. Still, you're committed. It will probably be fine once your body has warmed it up. You want to give it as much time to dry as you can so don't lay back down for now.")
		else:
			say("You aren't tired quite yet, so you decide the appropriate thing to do is to just leave. It will give the bed some time to dry which will make it more comfortable later. It will also give the cell some time to fill with the smell of your {pick('pee', 'piss')}, which will be fun later. It might make falling asleep harder but that's future " + GM.pc.getName() + "'s problem. You take a final deep breath of the room's piss smell before sauntering out of your cell into the halls.")

		addButton("Continue", "See what happens next", "end_scene")
	if state == "masturbate_bed":
		saynn("Your head feels a lot clearer after you cum. The piss-soaked bed beneath you has started to cool down, which makes the experience a lot less enjoyable than it was a few minutes ago.")
		
		saynn("A cell that smells like {pick('pee', 'piss')} is one thing; a bed is another. You should get up and at least dry things off.")

		saynn("Reluctantly, you get up and set to work.")
		
		addButton("Clean Up", "Go to the laundry room", "cleanup_bed1")
		if GM.pc.hasPerk(WsUtil.Perk_Revelry):
			addButton("Just Leave", "Leave your bed soaked in pee", "leave_bed")
		else:
			addDisabledButton("Just Leave", "(Requires Revelry Perk)\nLeave your bed soaked in pee")
		addDisabledButton("Masturbate", "You just did that")

func _react(action: String, _args):
	if action == "corner_1":
		GM.pc.addLust(30)
		var amount = PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.2)
		PissWrapper.drain(GM.pc)
		if GM.pc.hasReachablePenis():
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSED_ON_BY_SOMEONE, amount, 1.0)
		processTime(2 * 60)
	if action == "corner_2":
		playAnimation(StageScene.Solo, "stand", {bodyState = {naked = true, hard = true}})
		processTime(2 * 60)
	if action == "stool_1":
		GM.pc.addLust(30)
		var amount = PissWrapper.peeIntoCharacter(GM.pc, GM.pc, BodypartSlot.Head, 0.05)
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_DRINKING_PISS, amount, 1.0)
		PissWrapper.drain(GM.pc)
		playAnimation(StageScene.Solo, "sit", {bodyState = {naked = true, hard = true}})
		processTime(2 * 60)
	if action == "stool_2":
		processTime(2 * 60)
	
	if action == "bed_1":
		GM.pc.addLust(30)
		var amount = PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.5)
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSED_ON_BY_SOMEONE, amount, 1.0)
		PissWrapper.drain(GM.pc)
		playAnimation(StageScene.Sleeping, "sleep", {bodyState = {naked = true, hard = true}, hideNPC = true})
		processTime(3 * 60)
	if action == "bed_2":
		processTime(3 * 60)
	
	if action == "masturbate_puddle":
		runScene("MasturbationScene")
	if action == "cleanup_puddle1":
		aimCameraAndSetLocName("main_bathroom1")
		processTime(7 * 60)
	if action == "cleanup_puddle2":
		aimCameraAndSetLocName(GM.pc.getCellLocation())
		processTime(10 * 60)
	if action == "leave_puddle":
		GM.main.setModuleFlag(WsUtil.ModuleId, "PissedInCell_Puddle_NoCleanup", true)
		GM.pc.setLocation(CELL_TO_OUTSIDE_CELL.get(GM.pc.getCellLocation(), "cellblock_nearcells"))
		processTime(1 * 60)

	if action == "masturbate_bed":
		runScene("MasturbationScene")
	if action == "cleanup_bed1":
		aimCameraAndSetLocName("main_laundry")
		processTime(10 * 10)
	if action == "cleanup_bed2":
		aimCameraAndSetLocName(GM.pc.getCellLocation())
		if !GM.main.isVeryLate():
			GM.pc.setLocation(CELL_TO_OUTSIDE_CELL.get(GM.pc.getCellLocation(), "cellblock_nearcells"))
		processTime(10 * 60)
	if action == "leave_bed":
		GM.main.setModuleFlag(WsUtil.ModuleId, "PissedInCell_Bed_NoCleanup", true)
		if !GM.main.isVeryLate():
			GM.pc.setLocation(CELL_TO_OUTSIDE_CELL.get(GM.pc.getCellLocation(), "cellblock_nearcells"))
		processTime(2 * 60)

	if action == "end_scene":
		playAnimation(StageScene.Solo, "stand")
		endScene()
		return
	
	setState(action)

func hasJunkExposed() -> bool:
	var equipment = GM.pc.inventory.getAllEquippedItems()
	for equippedItem in equipment.values():
		for coveredBodypart in equippedItem.coversBodyparts():
			if coveredBodypart == BodypartSlot.Penis || coveredBodypart == BodypartSlot.Vagina:
				return false

	return true