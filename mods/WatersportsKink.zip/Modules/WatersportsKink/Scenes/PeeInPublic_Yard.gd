extends SceneBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

const WATERFALL_CELL = "yard_waterfall"

const GUARD_PISS_FETISH = {
	"maleguard_canine": false,
	"femaleguard_feline": true,
	WsUtil.Character_Guard: true,
}

var behindBush: bool = false
var isNobodyAround: bool
var isExhibitionist: bool

var guard: Character
var guardSatisfied: bool = false
var chokedOut: bool = false
var wonFight: bool = false

func _init():
	sceneID = WsUtil.Scene_PeeInPublic_Yard
	if GM.main == null:
		return

	if GM.main.isVeryLate():
		isNobodyAround = true
	else:
		isNobodyAround = RNG.chance(30) || _isNobodyAround()
	isExhibitionist = GM.pc.getSkillLevel(Skill.Exhibitionism) >= 2
	guard = GlobalRegistry.getCharacter(RNG.pick(GUARD_PISS_FETISH.keys()))

func resolveCustomCharacterName(charId):
	if charId == "guard":
		return guard.getID()

func _run():
	var genitals = "unknown"
	if GM.pc.hasPenis():
		if GM.pc.isWearingChastityCage():
			genitals = "chastity_cage"
		else:
			genitals = "penis"
	elif GM.pc.hasVagina():
		genitals = "vagina"
	else:
		genitals = "other"
	if state == "":
		saynn("This prison doesn't have very many rules. The only ones you're aware of that are actually enforced are trespassing in non-inmate areas and murder. Even hurting fellow inmates doesn't get you more than a slap on the wrist if you're caught.")

		saynn("With that in mind, the greenery nearby looks like the perfect bathroom. You could easily make it to a real toilet with plumbing and privacy, but you want to {pick('pee', 'piss')} right here, right now. You stop and look around to see if you'll get away with it.")

		if isNobodyAround:
			saynn("This part of the yard is currently unoccupied. Now's your chance to {pick('take a piss', 'go pee')}.")
		else:
			if isExhibitionist:
				saynn("There are people milling about, but nobody is currently looking at you. You should be fine. A part of you even hopes that they stop and look.")
			else:
				say("There are people milling about. The thought of somebody catching you doing this gives you second thoughts, but you're brave. ")
				if GM.pc.getPersonality().getStat(PersonalityStat.Coward) > 0.0:
					saynn("Or at least brave enough to pee behind a bush.")
				else:
					saynn("You feel confident that you can go behind a bush without anyone spotting you.")

		if hasJunkExposed():
			if isNobodyAround:
				if isExhibitionist:
					saynn("Your " + genitalString() + " is already fully visible, so you crouch down on the path. Life is too short to hide what you're about to do. If somebody comes by and happens to see you, they'll just get a show.")
				else:
					saynn("You walk off the path, then go behind a nearby bush. Once you're reasonably sure you're hidden, you crouch down. There's no chance anyone will see you now.")
					behindBush = true
			else:
				if isExhibitionist:
					saynn("Your " + genitalString() + " is already fully visible. This has a few inmates eyeing you up as well as a nearby guard, but it's in a disinterested way. That will probably change once they see what you're doing. You hope it will, at least. You crouch down on the path, preparing for what's to come.")
				else:
					saynn("Your " + genitalString() + " is already fully visible. A few inmates are eyeing you up, as well as a nearby guard, but it's in a disinterested manner. Nobody follows you or makes any indication they care as you disappear behind the bush. You crouch down to make sure you aren't visible, and wait... But nobody comes to check on you. You should be hidden now.")
					behindBush = true
		else:
			if isNobodyAround:
				if isExhibitionist:
					saynn("You quickly expose your crotch and you crouch down on the path, not really trying to be careful. This should be quick enough that you're not worried about anyone spotting you. Even if they do, they'll just get a free show.")
				else:
					saynn("You walk off the path, then go behind a nearby bush. Once you're reasonably sure you're hidden, you pull your pants down and crouch in preparation for what you're about to do.")
					behindBush = true
			else:
				if isExhibitionist:
					saynn("You quickly expose your crotch, not really trying to be careful. This catches a few eyes, and you hear a whistle. You can't help but give the people watching a wave. They don't know what they're in for. You crouch down, not even bothering to move off the path.")
				else:
					saynn("You walk off the path, then go behind a nearby bush. Once you're reasonably sure you're hidden, you pull your pants down and crouch in preparation for what you're about to do.")
					behindBush = true

		if behindBush:
			addButton("Continue", "See what happens next", "bush_start")
		else:
			if isNobodyAround:
				addButton("Continue", "See what happens next", "path_start_nobody")
			else:
				addButton("Continue", "See what happens next", "path_start_crowd")

		if false:
			addButton("bush_start", "Go to bush_start", "bush_start")
			addButton("bush_end", "Go to bush_end", "bush_end")
			addButton("path_start_nobody", "Go to path_start_nobody", "path_start_nobody")
			addButton("path_end_nobody", "Go to path_end_nobody", "path_end_nobody")
			addButton("path_start_crowd", "Go to path_start_crowd", "path_start_crowd")
			addButton("path_end_crowd", "Go to path_end_crowd", "path_end_crowd")
			addButton("path_caught_crowd", "Go to path_caught_crowd", "path_caught_crowd")

	if state == "bush_start":
		say("You close your eyes and relax, trying to focus on the urge to pee. ")
		if GM.pc.getCellLocation() == WATERFALL_CELL:
			saynn("The sounds of the nearby waterfall help immensely with this task. As you relax your muscles, the urge to go rises and finally comes to a head.")
		else:
			saynn("You relax the muscles beneath yourself as best you can and soon the urge to go rises and finally comes to a head.")
		
		saynn("As you feel the stream of your {pick('pee', 'piss')} begin, you open your eyes to look down at it. It's leaving behind a nice puddle in the dirt in front of you, though most of it is being sucked up by the ground as soon as it lands. You can't help but moan slightly at the combination of the sight and feeling.")

		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			saynn("You move one of your hands down into the stream and cup it slightly, catching a handful of {pick('pee', 'piss', 'urine')}. You bring it up to your face and inhale deeply before moving it to your mouth and sipping it down. You shudder at the bitter smell and acrid test. You do this a few more times, moaning each time at the gross taste that you can't help but love. Your other hand can't help but move down to your " + genitalString() + " and begin stroking it. Slowly, so that you don't make any more of a mess than you already have, but enough that it feels amazing. You can't help but wonder why you don't do this all the time.")
		else:
			saynn("You move one of your hands down to your " + genitalString() + " and begin stroking it slowly so that you don't make any more of a mess than you already have. It feels amazing and you moan louder than you expected. You should do this all the time. Your hand picks up speed, and it causes your stream to become less stable than before. Luckily you don't get anything on you.")
		
		addButton("Continue", "See what happens next", "bush_end")
	if state == "bush_end":
		say("Eventually, the stream comes to an end, and you're left panting under your breath. The air near you smells strongly of your {pick('pee', 'piss')}, and your ")
		if genitals == "penis":
			saynn("{pc.penisShort} is hard as a rock.")
		elif genitals == "chastity_cage":
			saynn("{pc.penisShort} is straining against its cage.")
		elif genitals == "vagina":
			saynn("{vagina} is wet as a faucet.")
		else:
			saynn("arousal has spiked.")

		if hasJunkExposed():
			say("You stand up and shakily cover yourself, trying not to step into the pool you've left or fall. ")
		else:
			say("You shakily stand up, trying not to fall or step into the pool you've left or fall. ")
		saynn("After taking a few seconds to make sure you're stable, you walk around the bush and back onto the path.")

		if isNobodyAround:
			if isExhibitionist:
				saynn("You look around again after stepping back onto the path. Unfortunately, nobody is around. It's both a shame but kind of a relief. It means you'll make a clean getaway, but it also means you can't give anyone a tease. You’re horny and wanted to show off or maybe get some relief. Nobody will be any the wiser about your secret piss.")
			else:
				saynn("You look around again nervously after stepping back onto the path. It's still totally empty. You let out a breath you didn't realize you were holding. You're going to get away with it. You're unbelievably horny, but that's solvable in a bunch of ways. Most of them don't involve someone catching you peeing, and you're happy to go with them.")
			
			saynn("You walk down the path away from the bush and stretch. That felt good.")
		else:
			if isExhibitionist:
				saynn("You catch the eye of a nearby inmate and wink. From the look on your face, they probably think that you just came. If only they knew the truth... Who knows what they'd do? Before your imagination can get the better of you, you walk away from the bush you were behind. Hopefully nobody will bother checking until you're long gone.")
			else:
				saynn("You catch the eye of a nearby inmate by sheer happenstance and blush. From look on your face and how shaky your legs are, they probably think you just had a hell of an orgasm. This is less embarrassing than the alternative, but it's still mortifying. Hopefully nobody will check what you did until you're gone.")

			saynn("You quickly walk away from the bush and the inmate, further down the path. You stop and stretch after a few paces and then continue on your way.")
		
		addButton("Continue", "See what happens next", "end_scene")

	if state == "path_start_nobody":
		if isExhibitionist:
			saynn("You can't help but look around again. The area is deserted, but that doesn't mean you aren't hoping for an audience. Sadly, it looks deserted still. You can't help but reach your hands down to your crotch and give your " + genitalString() + " a light rub in preparation for what's to come. You keep your eyes open and peeled on the path as you try to relax and let the urge to pee come.")
		else:
			saynn("You nervously look around again, confirming that nobody is there. Getting caught right now would be embarrassing but it wouldn't be the end of the world. Getting caught once you've started {pick('peeing', 'pissing')}? You might keel over dead from the embarrassment. You take a deep breath and close your eyes. You try your best to relax and focus on your crotch. You've peed a great many times before. This should be easy.")

		if GM.pc.getLocation() == WATERFALL_CELL:
			saynn("You focus on the sound of the nearby waterfall, and that does the trick. A few drops start dripping out of your urethra which soon becomes a stream of golden {pick('pee', 'piss')}.")
		else:
			saynn("You try to remember the sound of rain. You have a moment of heartbreak as you realize you will never hear it again, so you immediately cut that line of thought short. That's the sort of thing you will have a panic attack about later, perhaps with Rahi or Artica.")

			saynn("Instead, you try to focus on running water, like from a drinking fountain or a waterfall. That does the trick. A few moments later a golden stream of pee is coming from your urethra.")
		
		say("A puddle starts to form on the path as you pee. If anyone was around, they'd no doubt be scandalized. Luckily you are alone. The puddle is quickly spreading. Before you have a chance to think about it, you're standing in a puddle of your own pee. ")
		if GM.pc.hasPerk(WsUtil.Perk_Revelry):
			say("It's a welcome change from the cold ground beneath your {pc.feet}.")
		else:
			say("You'll have to be careful not to track any back to where people might run into it later.")

		addButton("Continue", "See what happens next", "path_end_nobody")
	if state == "path_end_nobody":
		saynn("Your hand drifts down to your crotch and starts rubbing at it as you pee. You can't help but moan loudly at the combined feelings of relief and pleasure. You should do this all the time.")
		
		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			saynn("You can't help yourself, and with your other hand you cup your hand underneath the stream of {pick('urine', 'pee', 'piss')}. After allowing the cup to fill to overflowing, you move it up to your face and inhale deeply before sipping it into your mouth. You can't help but shiver at the taste. You do this several more times, moaning softly as the hand at your crotch picks up speed. It's gross, but you can't help but love it.")
		
		say("Eventually the stream starts to come to an end and you're left panting. The air around you smells strongly of your pee")
		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			saynn(", as does your breath.")
		else:
			saynn(".")
		say("Your ")
		
		if genitals == "penis":
			say("{pc.penisShort} is hard as a rock.")
		elif genitals == "chastity_cage":
			say("{pc.penisShort} is straining against its cage.")
		elif genitals == "vagina":
			say("{vagina} is wet as a faucet.")
		else:
			say("arousal has spiked.")
		saynn(" That was amazing.")
		
		if genitals == "penis" || genitals == "chastity_cage":
			say("You shakily stand up and give your {pc.penisShort} a shake before stepping away from the pool you've left behind. ")
		elif genitals == "vagina":
			say("You shakily stand up and give your {vagina} a wipe before stepping away from the pool you've left behind. ")
		else:
			say("You shakily stand up and give your crotch a wipe before stepping away from the pool you've left behind. ")
			
		if hasJunkExposed():
			saynn("You cover yourself back up, almost falling as you do.")
		else:
			saynn("")

		say("After taking a final glance to make sure nobody saw, you walk down the path away from the scene of the crime. If someone finds that later, they might be upset. It won't be your problem though.")

		addButton("Continue", "See what happens next", "end_scene")

	if state == "path_start_crowd":
		if isExhibitionist:
			saynn("You'll most likely get into trouble for this one, but it's totally worth it. You reach a hand down to your " + genitalString() + " and give them a rub in preparation. You force yourself to keep your eyes open, looking around at the people milling around you. You try to relax.")
		else:
			saynn("You're probably going to get in trouble for this one. Still, you're committed now. You clench your eyes shut and try to hide from the people you know are there, embarrassed at what you're about to do. You try to relax, though you're still unbelievably tense.")
		
		saynn("As you sit there crouched in the path, you try to find the will to go. Against all odds, you find it easy. Maybe you are a piss slut after all...")

		saynn("Slowly, a few drops come out of your " + genitalString() + ". Those drops very quickly become a stream. Before you or anyone else knows it, you're pissing directly onto the path.")

		if GM.pc.hasPerk(WsUtil.Perk_Revelry):
			if isExhibitionist:
				saynn("This is exciting. You look around as you pee, catching the eye of a few inmates who look at you with a combination of revulsion and lust. You can't help but reach a hand down to your crotch and give your " + genitalString() + " a quick stroke. You make sure it passes through the piss stream, letting your pee act as lube.")

				saynn("You can hear people whispering, though you can't make anything specific out.")
			else:
				saynn("This is embarrassing and yet unbelievably hot. You don't dare open your eyes. With them shut, your other senses are enhanced dramatically. You hear a gasp, followed by whispering.")

				saynn("[sayMale]Hey look at that![/sayMale]")
				saynn("[sayAndro]Ewww... That's disgusting.[/sayAndro]")
		else:
			if isExhibitionist:
				saynn("This is, to be honest, mortifying. As you look around and see the combinations of lust and revulsion on people's faces, you start to breathe faster. You're so incredibly turned on. Without thinking, you move a hand down to your crotch and start playing with your " + genitalString() + ". You get a bit of pee on it, but you don't care. This is hot and you aren't afraid of people knowing you believe this.")

				saynn("You can hear people whispering, though you can't make anything specific out.")
			else:
				saynn("This is mortifying. Your heart feels like it's going to beat out of your chest. You don't dare open your eyes, but with them shut your other senses are enhanced dramatically. You can clearly hear the gasp of someone else who can see you, followed by them speaking.")

				saynn("[sayMale]Hey, look. That guy is peeing![/sayMale]")
				saynn("[sayFemale]Holy shit. That's disgusting![/sayFemale]")
				say("[sayMale]It's kind of hot...[/sayMale]")

		addButton("Continue", "See what happens next", "path_end_crowd")
	if state == "path_end_crowd":
		if isExhibitionist:
			saynn("The puddle forming on the path is easy to forget until it reaches your {pc.feet}. You don't react, too in the moment to care. You cannot help but moan loudly before licking your lips and continuing to play with yourself even as your stream keeps splashing below.")
		else:
			saynn("The feeling of vulnerability you feel coupled with the embarrassment fill you like a cocktail. You can't help it: a hand drifts to your crotch and starts playing with your " + genitalString() + ". Your hand gets caught in your stream briefly and you can't help but groan. Despite everything, this is turning you on.")
		
		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			if isExhibitionist:
				saynn("You move your other hand into the piss stream, cupping it. After you fill your hand to overflowing, you move it up to your face before sipping at it. You shudder, both at the taste and at the look people are giving you. They think you're disgusting. You cannot help but do it again, moving your hand into your stream and taking another sip. The acrid taste is incredible.")
			else:
				saynn("You want to take a sip. You can't help yourself, you're a total slut for piss. After a moment of floundering, you manage to move your free hand down to your crotch and collect a handful of {pick('pee', 'piss', 'urine')}. You then move it up to your mouth and slurp it in. The taste almost makes you gag, but you swallow it gleefully and do it again. You can hear the shocked noise of someone nearby, but you don't care.")
		
		say("Alas, all good things must come to an end. As your stream stops, you let out a gasping moan and give your " + genitalString() + " another rub. ")
		if isExhibitionist:
			saynn("")
		else:
			saynn("You reluctantly open your eyes, though you avoid looking too closely at anyone around you.")

		saynn("There's a big puddle of your {pick('pee', 'urine')} in front of you. The very edges of it have reached your {pc.feet}, but the bulk is spread out across the path.")

		addButton("Continue", "See what happens next", "path_caught_crowd")
	if state == "path_caught_crowd":
		addCharacter(guard.getID())
		say("Now would be a good time to make an escape, preferably before a guard catches you. You shakily stand up and step away from the mess you made. ")
		if !hasJunkExposed():
			if isExhibitionist:
				saynn("You cover yourself back up, waving at a few of the shocked onlookers as you do.")
			else:
				saynn("You quickly cover yourself up, keeping your head down as much as you can. You barely stop yourself from falling in the process.")
		else:
			saynn("")
		
		saynn("[say=guard]Hey! What do you think you're doing?[/say]")

		saynn("Uh oh. Busted.")

		saynn("Running would just attract attention, and you don't really trust yourself not to slip with wet {pc.feet}. You settle for power walking away.")

		addButton("Continue", "See what happens next", "guard_intercept" if RNG.chance(50) else "guard_escape")
		# addButton("guard_escape", ":3", "guard_escape")
		# addButton("guard_intercept", ":3", "guard_intercept")
	
	if state == "guard_escape":
		saynn("Somehow the guard fails to keep up with you. After a short chase where {guard.he} shouts at you a bunch, {guard.he} gives up and sighs really loud. Looks like you've managed it this time.")

		saynn("The downside is that everyone has seen your face and your reputation might suffer, but that's ultimately a small price to pay for the thrill you got.")

		addButton("Continue", "Good job", "end_scene")
	if state == "guard_intercept":
		saynn("Before you can get away from the scene of the crime, the guard gets close enough that escaping isn't an option.")

		if GUARD_PISS_FETISH.get(guard.getID(), false):
			saynn("[say=guard]You can't pee there. At least go in the bushes. It makes my life harder when I have to punish cuties like you... Your little show was hot as hell. If you let me fuck you, I'll let you go. Or we can do this the hard way and you can clean that mess up. Your choice.[/say]")

			saynn("Well, that's blatant at least. Sex in exchange for being let go. You could always just fight {guard.him} though. {guard.He} probably wouldn't expect it.")

			addButton("Sex", "Fuck it (literally)", "guard_sex")
			addButton("Clean It Up", "You're not in the mood", "guard_cleanup")
			addButton("Fight", Util.capitalizeFirstLetter(guard.heShe()) + "'ll never see it coming!", "guard_fight")
		else:
			saynn("The guard pulls a leash off of {guard.his} belt and approaches you.")

			saynn("[say=guard]Stand still. You're going to clean this up.[/guard]")

			addButton("Clean It Up", "Comply", "guard_cleanup")
			addButton("Fight", "Hell no!", "guard_fight")
	if state == "guard_sex":
		if chokedOut:
			saynn("You awake with a loud gasp and have several seconds of absolute confusion as you forget where you are and what you were just doing. Then it all comes roaring back.")
		
		if guardSatisfied:
			saynn("[say=guard]Huff. Alright, get out of here. I need to make sure someone cleans that up before anyone complains and neither of us wants to deal with other inmates pointing fingers at you. Remember: in the bushes next time.[/say]")

			saynn("Well, that was fun! Time to scram.")
		else:
			saynn("[say=guard]How's a pervert like you such a lousy lay? Fucking... Fine, a deal's a deal. Get out of here. Next time I won't be so lenient, and you'll be licking it off the floor.[/say]")

			saynn("You should go.")
		
		addButton("Continue", "See what happens next", "end_scene")
	if state == "guard_cleanup":
		if GUARD_PISS_FETISH.get(guard.getID(), false):
			saynn("[say=pc]Sorry sir~, I'll clean it up. Lead the way.[/say]")

			saynn("The guard looks disappointed but just grunts and pulls a leash off {guard.his} belt. After {guard.he} attaches it to your collar, {guard.he} leads you to a nearby janitor station. You didn't realize that this was here.")

			saynn("[say=guard]You [i]sure[/i] you don't want to fuck? No? Fine. Grab that mop and bucket.[/say]")
		else:
			saynn("[say=pc]Alright, fine.[/say]")

			saynn("The guard steps forward and attaches the leash to your collar before leading you to a nearby janitor station. You had no idea that this was here.")

			saynn("[say=guard]Grab that mop and the bucket. Don't get any funny ideas.[/say]")

		saynn("{guard.He} leads you back out, and you spend the next 5 minutes carefully cleaning your {pick('pee', 'piss')} up. A few inmates from before are watching with clear amusement, but you don't let them distract you.")

		saynn("After you're done cleaning up, the guard marches you back to the janitor station, makes you empty the bucket, and lets you go.")

		addButton("Continue", "See what happens next", "end_scene")
	if state == "guard_fight":
		if wonFight:
			saynn("[say=guard]Ow. Fuck. Just go.[/say]")

			saynn("You should go before {guard.he} recovers and changes his mind.")
			
			addButton("Continue", "See what happens next", "end_scene")
		else:
			saynn("You collapse to the ground and stay down. The guard frowns and presses a {guard.foot} against your chest, putting just enough of {guard.his} weight on you that it's uncomfortable.")

			if GUARD_PISS_FETISH.get(guard.getID(), false):
				saynn("[say=guard]Now why'd you go and do that~? Come on, change of plans.[/say]")

				saynn("The guard pulls the leash off {guard.his} belt before bending down and clipping it to your collar. {guard.He} drags you over to the pool of piss and pushes you into it with a {guard.foot}. It's started to cool down, making it unpleasant to say the least.")

				saynn("[say=guard]Be a good {pc.boy} and stay.[/say]")

				if guard.hasReachablePenis():
					saynn("Holding the leash in one hand, {guard.he} unzips {guard.his} pants and gets {guard.his} half-erect penis out. {guard.He} grabs it and aims directly at you before starting to pee.")
				elif guard.hasReachableVagina():
					saynn("The guard shimmies down {guard.his} pants with one hand, enough that you can see {guard.his} {guard.vagina}. {guard.He} thrusts {guard.his} crotch forward and starts to pee on you.")
				else:
					saynn("The guard shimmies down {guard.his} pants with one hand, enough that you can see {guard.his} crotch. {guard.He} thrusts {guard.his} hips forward and starts to pee on you.")

				addButton("Continue", "See what happens next", "guard_pee")
			else:
				saynn("[say=guard]That was stupid.[/say]")

				saynn("The guard bends down and clips the leash to your collar. {guard.He} drags you over to the pool of piss you left on the path. You don't like where this is going.")

				saynn("[say=guard]Clean it up.[/say]")
				
				saynn("You look up at {guard.him}. Surely {guard.he} doesn't mean...?")

				saynn("[say=guard]Don't make me say it again. Clean. It. Up.[/say]")

				saynn("{guard.He}'s serious. Reluctantly, you stick your tongue out and... lick some of your rapidly cooling piss off the ground.")

				saynn("[say=guard]Good {pc.boy}.[/say]")

				saynn("The next few minutes are utterly humiliating and have you worrying for your health. Eventually, the guard relents. {guard.He} leans down and unclips the leash.")

				saynn("[say=guard]Go see a nurse if you feel like shit later. Now get the fuck out of here.[/say]")

				saynn("You climb to your {pc.feet} and leave before {guard.he} can change his mind.")

				addButton("Continue", "See what happens next", "end_scene")
	if state == "guard_pee":
		saynn("[say=guard]Ahhh~[/say]")

		say("It's... so warm. It helps with the chill from the pool, at least. You stay put, not wanting to anger {guard.him}. ")
		if GM.pc.hasHair():
			saynn("{guard.He} makes sure to aim at your head, making sure your hair gets utterly soaked.")
		else:
			saynn("{guard.He} makes sure to aim for your face, making sure that you get soaked.")

		saynn("It's clear that the guard didn't really need to go that badly, which is a blessing. After only a few moments the stream stops and {guard.he} bends down to unclip the leash, heedless of the pee that's soaked the clip end.")

		saynn("[say=guard]Get out of here. Or don't. I'm going to get someone to clean this up.[/say]")

		saynn("You shakily rise to your {pc.feet} and walk away.")

		addButton("Continue", "See what happens next", "end_scene")

func _react(action: String, _args):
	if action == "bush_start":
		setState("bush_start")
		if GM.pc.hasReachablePenis():
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			PissWrapper.peeIntoCharacter(GM.pc, GM.pc, BodypartSlot.Head, 0.05)
		return
	if action == "bush_end":
		setState("bush_end")
		playAnimation(StageScene.Solo, "stand")
		var amount = PissWrapper.drain(GM.pc)
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSING_ON_SOMEONE, amount)
		return
	
	if action == "path_start_nobody":
		setState("path_start_nobody")
		PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.05)
		playAnimationForceReset(StageScene.Solo, "stand", {bodyState = {naked = true, hard = true}})
		return
	if action == "path_end_nobody":
		setState("path_end_nobody")
		if GM.pc.hasReachablePenis():
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			PissWrapper.peeIntoCharacter(GM.pc, GM.pc, BodypartSlot.Head, 0.05)
		var amount = PissWrapper.drain(GM.pc)
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSING_ON_SOMEONE, amount)
		return
	
	if action == "path_start_crowd":
		setState("path_start_crowd")
		if GM.pc.hasReachablePenis():
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
		GM.pc.addSkillExperience(WsUtil.SkillId, WsUtil.XP_FROM_PISSED_ON_BY_SOMEONE)
		return
	if action == "path_end_crowd":
		setState("path_end_crowd")
		PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.05)
		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			PissWrapper.peeIntoCharacter(GM.pc, GM.pc, BodypartSlot.Head, 0.05)
		PissWrapper.drain(GM.pc)

		GM.pc.getReputation().addRep(RepStat.Alpha, -1, true)
		return
	if action == "path_caught_crowd":
		playAnimation(StageScene.Solo, "stand")
		setState("path_caught_crowd")
		return

	if action == "guard_escape":
		setState("guard_escape")
		playAnimation(StageScene.Solo, "jog")
		return
	if action == "guard_intercept":
		setState("guard_intercept")
		playAnimation(StageScene.Duo, "stand", {npc = guard.getID(), npcAction = "stand", bodyState = {naked = true, hard = true}})
		return
	if action == "guard_sex":
		runScene("GenericSexScene", [guard.getID(), "pc", SexType.DefaultSex, {SexMod.DisableDynamicJoiners: true}], "guard_sex")
		setState("guard_sex")
	if action == "guard_cleanup":
		setState("guard_cleanup")
		playAnimation(StageScene.Duo, "walk", {npc = guard.getID(), npcAction = "walk", flipNPC = true, bodyState = {leashedBy = guard.getID()}})
		return
	if action == "guard_fight":
		runScene("FightScene", [guard.getID()], "guard_fight")
		setState("guard_fight")
		return
	if action == "guard_pee":
		setState("guard_pee")
		playAnimation(StageScene.Duo, "allfours", {npc = guard.getID(), npcAction = "stand", bodyState = {leashedBy = guard.getID()}, npcBodyState = {hard = true}})
		PissWrapper.peeOntoCharacter(guard, GM.pc, 1)
		return

	if action == "end_scene":
		playAnimation(StageScene.Solo, "stand")
		endScene()
		return

func _react_scene_end(tag, result):
	._react_scene_end(tag, result)

	if tag == "guard_sex":
		var sexResult: SexEngineResult = result[0]
		guardSatisfied = sexResult.getDomSatisfaction(guard.getID()) > 0.8
		chokedOut = sexResult.isSubUnconscious("pc")
		# setState("guard_sex")
		return
	if tag == "guard_fight":
		wonFight = result[0] == "win"
		if wonFight:
			playAnimation(StageScene.Duo, "stand", {npc = guard.getID(), npcAction = "defeat"})
		else:
			playAnimation(StageScene.Duo, "allfours", {npc = guard.getID(), npcAction = "stand", bodyState = {leashedBy = guard.getID()}, npcBodyState = {hard = true}})
			if !GUARD_PISS_FETISH.get(guard.getID(), false):
				PissWrapper.addPee(GM.pc, 250)
				PissWrapper.peeIntoCharacter(GM.pc, GM.pc, BodypartSlot.Head, 1)
			
			GM.pc.getReputation().addRep(RepStat.Alpha, -3.0, true)
		return
	
func _isNobodyAround():
	var room_id: String = GM.pc.getLocation()
	for pawn in GM.main.IS.getPawnsNear(room_id, 1, 2):
		if pawn.charID != "pc":
			return false
	return true

func hasJunkExposed() -> bool:
	var equipment = GM.pc.inventory.getAllEquippedItems()
	for equippedItem in equipment.values():
		for coveredBodypart in equippedItem.coversBodyparts():
			if coveredBodypart == BodypartSlot.Penis || coveredBodypart == BodypartSlot.Vagina:
				return false

	return true

func genitalString() -> String:
	if GM.pc.hasReachablePenis():
		return "{pc.penisShort}"
	elif GM.pc.isWearingChastityCage():
		return "{pc.penisShort}"
	elif GM.pc.hasReachableVagina():
		return "{vagina}"
	else:
		return "crotch"

func getDebugActions():
	return [
	{
		"id": "set_exhibitionist",
		"name": "Set isExhibitionist",
		"args": [
			{
				"id": "flag",
				"name": "Is Exhibitionist",
				"type": "bool",
				"value": isExhibitionist if isExhibitionist != null else false,
			},
		],
	},
	{
		"id": "set_isNobodyAround",
		"name": "Set isNobodyAround",
		"args": [
			{
				"id": "flag",
				"name": "Is Nobody Around",
				"type": "bool",
				"value": isNobodyAround if isNobodyAround != null else false,
			},
		],
	},
	{
		"id": "reload_scene",
		"name": "Reload Scene",
		"args": [],
	},
]

func doDebugAction(_id, _args = {}):
	match _id:
		"set_exhibitionist":
			isExhibitionist = _args.get("flag", isExhibitionist)
		"set_isNobodyAround":
			isNobodyAround = _args.get("flag", isNobodyAround)
		"reload_scene":
			GM.ui.clearText()
			behindBush = false
			setState("")
			_run()

func saveData():
	var data =.saveData()
	data["behindBush"] = behindBush
	data["isNobodyAround"] = isNobodyAround
	data["isExhibitionist"] = isExhibitionist
	data["guard"] = guard.getID()
	data["guardSatisfied"] = guardSatisfied
	data["chokedOut"] = chokedOut
	data["wonFight"] = wonFight

	return data

func loadData(data):
	.loadData(data)
	behindBush = SAVE.loadVar(data, "behindBush", false)
	isNobodyAround = SAVE.loadVar(data, "isNobodyAround", RNG.chance(30) || _isNobodyAround())
	isExhibitionist = SAVE.loadVar(data, "isExhibitionist", GM.pc.getSkillLevel(Skill.Exhibitionism) >= 2)
	guard = GlobalRegistry.getCharacter(SAVE.loadVar(data, "guard", RNG.pick(GUARD_PISS_FETISH.keys())))
	guardSatisfied = SAVE.loadVar(data, "guardSatisfied", false)
	chokedOut = SAVE.loadVar(data, "chokedOut", false)
	wonFight = SAVE.loadVar(data, "wonFight", false)
