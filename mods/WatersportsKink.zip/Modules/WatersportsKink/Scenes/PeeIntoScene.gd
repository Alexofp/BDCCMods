extends SceneBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

var itemId := ""
var amount := 0.0
var item: ItemBase

func _init():
	sceneID = WsUtil.Scene_PeeInto

func _initScene(args = []):
	if !args.empty():
		itemId = args[0]
	
func _reactInit():
	if itemId == null && itemId == "":
		return
	
	amount = 0.0
	item = GM.pc.getInventory().getItemByUniqueID(itemId)

func _run():
	if !PissWrapper.canPee(GM.pc):
		saynn("You do not currently need to pee.")
		addButton("Continue", "Try again later...", "end_scene")
		return
	if GM.pc.hasBlockedHands():
		saynn("You need your hands free to pee into something!")
		addButton("Continue", "There's always next time", "end_scene")
		return

	var lustCombatState: LustCombatState = GM.pc.getLustCombatState()

	var exposed = hasJunkExposed()
	var genitals = "unknown"

	if GM.pc.hasPenis():
		if GM.pc.isWearingChastityCage():
			genitals = "chastity_cage"
		else:
			genitals = "penis"
	elif GM.pc.hasVagina():
		genitals = "vagina"
	else:
		genitals = "other"

	var itemName = itemName(item)
	amount = PissWrapper.peeIntoItem(GM.pc, item, 0.9)

	if lustCombatState.isInPublic() && exposed:
		say(RNG.pick([
			"This is a public place, but you're already exposed so nobody new will stare at you. That might change once people see what you're up to though.",
			"You're in public, but that won't stop you from peeing. The toilets are so far away! Besides, you're already half-naked anyway and people see lewder things every day in this prison.",
			"Being exposed in public is one thing, but pissing is quite another. Still... the toilets are pretty far, and you want to collect your piss anyway. You decide to go for it.",
			"You decide to pee in public. You're already exposed, and you want to collect your piss anyway. Plus some people would pay a small fortune to watch this, so you're almost doing them a favor.",
			"This is a public place, but you're already exposed so nobody new will stare at you, at least for now. People see lewder things than naked bodies every day in this prison. That might change if people notice what you're up to though."
		]))
	elif lustCombatState.isInPublic():
		say(RNG.pick([
			"This is a public place. You quickly expose your genitals, letting anyone who's looking see them. Despite that, you aren't worried. It takes a lot more than casual nudity to attract attention.",
			"The toilets are too far away and it feels unnecessary if you're going to collect your piss anyway. You quickly expose yourself, shivering slightly at the cold prison air.",
			"You want to collect your piss, and being in public won't stop you. You quickly expose your genitals and start preparing to piss into the {item}.".format({"item": itemName}),
			"Some people would pay a lot of money for your piss. Though all you care about is collecting some for later, even though you're out in the open where anyone could see it. Before you can think better of it, you expose yourself and get to work.",
			"You want to collect your piss in the {item}. Even though you're in public. Is it safe? No. But safety is relative in this prison, so you decide to carry through and expose yourself.".format({"item": itemName})
		]))
	elif exposed:
		say(RNG.pick([
			"You decide to collect your piss. Since your genitals are already in the open, this should be quick and easy.",
			"Rather than go to the toilets, you want to collect your piss for later. A part of you wonders whether this is healthy, but it's quickly swept away by a need to pee.",
			"You feel the urge to pee, and don't want to go to the toilets.",
		]))
	else:
		say(RNG.pick([
			"You need to go pee, but you don't want to go to the bathroom. So, you expose yourself and start preparing to pee into the {item}".format({"item": itemName}),
			"You expose yourself and prepare to pee into a container rather than walk to the toilets. Besides, you can use the pee for something later.",
			"You feel the urge to pee and want to save it for later. You quickly expose yourself to prepare."
		]))
	
	if genitals == "chastity_cage":
		say(" Peeing into a container will be hard due to your cage. This might get messy.")
	elif genitals == "vagina":
		say(" This might get messy, but that's the cost of peeing into a container.")

	say("\n\n")

	if GM.pc.hasPerk(WsUtil.Perk_Urolagnia):
		if genitals == "chastity_cage":
			saynn("You almost lose yourself in the fantasy of what you'll do with the piss you're collecting here. Your cage stops you from getting hard, so you let your thoughts run wild for a little bit.")
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
			GM.pc.addLust(30)
		elif genitals == "penis":
			saynn("You fantasize about what you'll do with the piss you're collecting now and give yourself a few strokes before stopping. If you get too hard, peeing will be difficult!")
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
			GM.pc.addLust(15)
		elif genitals == "vagina":
			saynn("You briefly lose control and rub your {vagina}, anticipating what you'll do with the piss you're collecting. It's tempting to just keep doing it, but business before pleasure.")
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
			GM.pc.addLust(15)
		else:
			saynn("You fantasize about what you'll do with the piss you're collecting here and almost lose yourself in it. After a minute, you shake your head and focus on the task at hand.")
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
			GM.pc.addLust(15)
	elif GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Innocent:
		if RNG.chance(25):
			saynn("You reflect on how your life used to be normal before being sent to prison... And now you're peeing into a {item} to save your piss for later.".format({"item": itemName}))

	if genitals == "chastity_cage":
		var penis: BodypartPenis = GM.pc.getBodypart(BodypartSlot.Penis)
		saynn("You hold the {itemName} up to your {penis} as best you can given the cage. After taking a moment to relax, you feel the urge come and you begin to pee into the {itemName}.".format({
			"itemName": itemName,
			"penis": penis.getLewdName(),
		}))
	elif genitals == "penis":
		saynn("You hold the {itemName} up to your {pc.penis} and take a moment to relax. After a moment, you feel the urge and you begin to pee into the {itemName}.".format({
			"itemName": itemName,
		}))
	elif genitals == "vagina":
		saynn("You hold the {itemName} up to your {pc.pussyStretch} pussy and relax. After a moment, you feel the urge and begin to piss.".format({
			"itemName": itemName
		}))
	else:
		saynn("You hold the {itemName} up to your genitals and relax. After a moment, you begin to pee.".format({
			"itemName": itemName
		}))

	if genitals == "chastity_cage" || genitals == "vagina":
		PissWrapper.peeOntoCharacter(GM.pc, GM.pc)
		if item.getFluids().isFull():
			saynn("You make a bit of a mess but by the time {itemName} is full, you've pissed {amount}ml into it.".format({
				"itemName": itemName,
				"amount": Util.roundF(amount, 1),
			}))
		else:
			saynn("You make a bit of a mess but by the time you're done, you've peed {amount}ml into the {itemName}.".format({
				"amount": Util.roundF(amount, 1),
				"itemName": itemName,
			}))
	else:
		amount += PissWrapper.peeIntoItem(GM.pc, item)
		# Technically not pissing inside someone but we stay silly.
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSING_INSIDE_SOMEONE, amount, 0.5)

		if item.getFluids().isFull():
			saynn("By the time the {itemName} is full, you've pissed {amount}ml into it.".format({
				"itemName": itemName,
				"amount": Util.roundF(amount, 1),
			}))
		else:
			saynn("By the time you're done, you've peed {amount}ml into the {itemName}.".format({
				"amount": Util.roundF(amount, 1),
				"itemName": itemName,
			}))

	if lustCombatState.isInPublic():
		GM.pc.addSkillExperience(WsUtil.SkillId, 10)


	addButton("Continue", "Your pissing is done.", "end_scene")

func _react(_action: String, _args):
	if (_action == "end_scene"):
		playAnimation(StageScene.Solo, "stand")
		endScene()
		return

	setState(_action)

func hasJunkExposed() -> bool:
	var equipment = GM.pc.inventory.getAllEquippedItems()
	for equippedItem in equipment.values():
		for coveredBodypart in equippedItem.coversBodyparts():
			if coveredBodypart == BodypartSlot.Penis || coveredBodypart == BodypartSlot.Vagina:
				return false

	return true

func itemName(_item: ItemBase) -> String:
	var name: String = _item.getVisibleName()
	return name[0].to_lower() + name.right(1)

func saveData():
	var data =.saveData()
	data["itemId"] = itemId
	data["peeAmount"] = amount

	return data

func loadData(data):
	.loadData(data)

	itemId = SAVE.loadVar(data, "itemId", "")
	amount = SAVE.loadVar(data, "peeAmount", "")
	item = GM.pc.getInventory().getItemByUniqueID(itemId)
