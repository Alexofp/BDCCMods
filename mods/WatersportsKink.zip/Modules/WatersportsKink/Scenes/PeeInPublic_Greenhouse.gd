extends SceneBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

const FORMULAS = [
	"C18-H24-O2",
	"C15-H20-O4",
	"C12-H22-O11",
	"C20-H25-N3O",
	"C22-H19-N-O4"
]

var useFloor = RNG.chance(50)
var pickedFormula = RNG.pick(FORMULAS)
var canOpenCrate: bool = false
var helpedAlex: bool = false
var openedMetalCrate = RNG.chance(20)

func _init():
	sceneID = WsUtil.Scene_PeeInPublic_Greenhouse
	if GM.pc != null:
		canOpenCrate = GM.pc.getStat(Stat.Strength) >= 10
	if GM.main != null:
		helpedAlex = GM.main.getModuleFlag("AlexRynardModule", "ch1IntroSceneHappened") == true

func _run():
	var genitals = "unknown"
	if GM.pc.hasPenis():
		if GM.pc.isWearingChastityCage():
			genitals = "chastity_cage"
		else:
			genitals = "penis"
	elif GM.pc.hasVagina():
		genitals = "vagina"
	else:
		genitals = "other"
	if state == "":
		saynn("The greenhouse isn't exactly bustling with activity even in the best of times. It's off limit to inmates, and what staff hang out here are usually quite easy to dodge. It's also very out of the way and hidden from private eyes. These all serve to make you believe that something in the area [i]must[/i] serve as a great place to pee.")

		saynn("Still, as you look around the pickings are slim. Probably the most promising spot is the grow beds, as those have dirt that will absorb the piss. They vary a fair bit in height and size, but you can already see a few that would be comfortable enough to pee into. Another option is any of the quite frankly absurd number of crates. You aren't sure what's inside them and you might not be even able to get them open, but the idea of pissing on something like that is appealing in its own way.")

		saynn("You could also just pee in the middle of the floor. It'd make a mess, but there's nobody around to stop you.")

		addButton("Grow Bed", "Pee on a grow bed", "grow_bed_start")
		addButton("Crate", "Pee into a crate", "crate_start")
		addButton("Just Pee", "Pee as you are", "just_pee_start")
	
	if state == "grow_bed_start":
		saynn("You aren't really sure what they grow here. You know that there are apples, but otherwise it could be anything. You're sure that whatever it is, it won't mind some {pick('pee', 'piss', 'urine')}. Extra water is good for plants, right?")

		say("You take a look around to try and determine what bed to {pick('pee', 'piss')} on. It's a toss-up between one on the floor that you can just stand over, and one that's at your crotch level. ")

		if useFloor:
			say("After a brief moment of consideration, you choose the bed on the floor. It'll be quick and most importantly it'll be easy. You waltz over to the grow bed without any hesitation. ")
		else:
			say("After considering for a bit, you choose one of the hip-height grow beds. It'll require a more hands-on approach, but it might be more fun that way. You walk over to a nearby grow bed. ")
		if hasJunkExposed():
			say("\n\n")
		else:
			saynn("You quickly expose your " + genitalString() + ". After a moment of consideration, you just strip out of all of your clothes. It'll be easier this way.")
		
		saynn("It's... oddly peaceful in the greenhouse. There's still the background noise that's present in every room in this damned prison, but there's none of the normal stress that comes from being out in the general population area. In another life, you might have enjoyed working here. Unfortunately, that's not going to happen now. You focus on the task at hand. Or " + genitalString(false) + ", as it were.")

		addButton("Continue", "See what happens next", "grow_bed_end")
	if state == "grow_bed_end":
		if useFloor:
			say("Not bothering to close your eyes, you relax and try to let your bladder contents go. It comes easily, and you quickly start to drip {pick('pee', 'piss', 'urine')} down onto the floor. The drops soon become a stream, and you can't help but groan at the feeling of relief it brings. Idly, you bring one of your hands up to a nipple and begin playing with it. Your other hand soon finds its way down to your " + genitalString() + ". ")

			if genitals == "penis":
				say("You stroke yourself slowly, exhaling sharply at the mixed sensations. ")
			elif genitals == "chastity_cage":
				say("You pull at your cage, trying to give yourself what stimulation you can. It only serves to make you needy, but you can't help enjoying it. ")
			elif genitals == "vagina":
				say("You start rubbing at your clitoris and shiver at the combination of feelings. ")
			else:
				say("You rub your crotch and sigh deeply. ")
			saynn("This is the life.")
		else:
			if genitals == "penis":
				say("You grab hold of your {penis} and aim it at the grow bed. This puts you in prime position to start stroking it slowly. ")
			elif genitals == "chastity_cage":
				say("You grab hold of your package and aim it at the grow bed as best you can. The naughtiness of what you're doing is turning you on so tug on it slightly, desperate for sensation. ")
			elif genitals == "vagina":
				say("You move forward as much as possible and thrust your hips forward over the grow bed. This is a bit awkward, and it might make a mess, but hopefully most of the pee will go into the dirt and not onto your feet. You start rubbing your clit and inhale sharply at the sensation. ")
			else:
				say("You thrust your hips forward as much as possible so that you're aiming as clearly at the grow bed as you can. This is a bit awkward, and it might make a mess, but hopefully most of the pee will go into the dirt and not onto your feet. You start rubbing your crotch as best you can, given the weird angle. ")
			saynn("That you're not allowed to be here at all, let alone to do what you're above to do, only turns you on further. Your free hand moves to a nipple and begins tweaking it.")

			saynn("You turn your thoughts towards running water and relax, letting the need to {pick('piss', 'pee')} come naturally. Soon, come it does, and a stream of golden liquid starts coming from your " + genitalString() + ". It smells a bit gross, but that just turns you on more.")
		
		saynn("The grow bed is taking your {pick('pee', 'piss')} like a champion. Nobody will be any the wiser when you're done. The soil is greedily sucking it all up. In a way, that's a shame. The idea of someone finding a pool of {pick('pee', 'piss')} in the greenhouse is... Oddly appealing.")

		say("Eventually, the stream starts to die down. Your hands are still going though. As you approach the edge of your climax, you force yourself to stop. As much fun as it sounds to cum right here, there's a lot of people in the prison that can help with that, and they'll make it more fun. ")
		if hasJunkExposed():
			saynn("You walk away from the grow bed, stopping to stretch. You have the rest of the day to waste. Who knows where it will bring you?")
		else:
			saynn("You quickly put your clothes back on and walk away from the grow bed. You have the rest of the day to waste.")

		addButton("Continue", "See what happens next", "end_scene")

	if state == "crate_start":
		saynn("{pick('Peeing', 'Pissing')} into or on one of these crates is really just a power fantasy more than anything. You have no idea what's in any of them. For all you know, it's food. That doesn't stop you though. You're fairly certain nothing [i]you[/i] eat comes from here, and a little bit of {pick('pee', 'piss', 'urine')} won't hurt anyone.")

		saynn("The crates are a weird mixture of highly secure metal boxes and retro wooden crates. The odds of you being able to open the wooden ones seems pretty good, so you pick one at random and approach it. It comes up to just under your crotch, which is convenient. You take a moment to tug on the top cover of the crate, trying to open it.")

		if canOpenCrate:
			saynn("It comes open with ease. Disappointingly, the crate seems to just have a bunch of sealed vials inside it. You pick one up and give it a look. It's very clearly labeled as being made in some AlphaCorp lab, but that's all you can parse from it. You have no idea what " + pickedFormula + " is. The label says \"food-grade\" though. You put the vial back where you found it. Best to not carry around something that you have no use for and no explanation for owning.")

			saynn("[say=pc]Not my problem...[/say]")
		else:
			saynn("It doesn't budge. You go to another crate and give it a pull, with the same result. You... aren't exactly the strongest person in the world, but it's still a bit disheartening. Well, you'll have to settle for just {pick('peeing', 'pissing')} on one. Out of spite, you look for a metal one of the right height and approach it. There's a tablet attached with AlphaCorp's logo on it. It prompts you for a password when you tap on it. Perfect.")

			say("You'll have to settle for just soaking the top of it. Maybe if you're lucky it will damage the lock so staff can't get into it either. ")
			if hasJunkExposed():
				saynn("You walk around the crate so that you'll be able to see anyone coming and then hop up, facing in towards the crate.")
			else:
				saynn("You walk around the crate so that you'll be able to see anyone coming and then shimmy your pants off. You then hop up onto the crate, facing inwards towards its center.")
	
		addButton("Continue", "See what happens next", "crate_end")
	if state == "crate_end":
		if canOpenCrate:
			say("You position yourself at the corner of the crate. You figure it will give you as good as coverage as you can get. ")
			if hasJunkExposed():
				saynn("You thrust your hips forward so that they're above the vials.")
			else:
				saynn("You expose your " + genitalString() + " and thrust your hips forward so that they're above the vials.")
			
			say("Then, you close your eyes and focus on relieving yourself. After a few seconds, a stream of {pick('pee', 'piss', 'urine')} starts flowing out. It gets all over the vials. The labels are soon soaked. You hope some is pooling at the bottom of the crate, but you can't see it very well. This is... not as erotic as you expected it to be. ")
			if GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Innocent:
				saynn("It just feels like vandalism, which isn't something you've ever been comfortable with.")
			else:
				saynn("It just feels like vandalism, which while awesome doesn't turn you on.")

			saynn("You've very rapidly come around to the idea of inconveniencing AlphaCorp, but you don't get off to it. Yet. Maybe if you thought about it for longer?")

			saynn("...")

			say("Nope, still not hot. Well, you'll have to be content with the act itself. Soon, your bladder is empty, and you pull your hips away from the crate. ")
			if hasJunkExposed():
				saynn("You shake your hips a bit to dislodge any lingering drops of {pick('pee', 'piss')}.")
			else:
				saynn("You give your " + genitalString(false) + " a quick wipe then cover yourself back up.")
			
			saynn("That was fun.")

			addButton("Continue", "See what happens next", "end_scene")
		else:
			saynn("You can't help but let out a yelp. It's cold!")

			saynn("You close your eyes and try to ignore the cold metal beneath your butt. You focus on how you need to {pick('pee', 'piss')}, and soon a stream of {pick('pee', 'piss', 'urine')} starts leaking out of your " + genitalString() + " and onto the top of the crate. Your butt is soon soaked, which helps warm you up. Mmm, that feels nice~.")

			if genitals == "penis":
				say("You can feel yourself start to harden, and you reach a hand down to your {penis}. You then start stroking it slowly. ")
			elif genitals == "chastity_cage":
				say("You can feel yourself starting to strain against your cage. You reach down and fondle your package. You get a bit of {pick('pee', 'piss', 'urine')} on your hand, but that ship has sailed so you aren't too worried. ")
			elif genitals == "vagina":
				say("You feel a spike of arousal and reach down to rub slowly at your clit. ")
			else:
				say("You feel a spike of arousal and reach down to slowly rub at your junk. ")
			saynn("You moan openly. This is the life.")

			saynn("The crate's top is soon covered with a thin layer of your {pick('pee', 'piss', 'urine')} and it's leaking onto the floor. Some of it is dripping over the crate's tablet. You lean forward, supporting yourself with your free hand, and take a look at it. Seems to still be working... You can fix that. You awkwardly slide yourself forward until you're almost at the edge of the crate and your stream is landing more or less directly on top of the tablet. You send a quiet thanks to your own {pick('pee', 'piss')} for lubricating the slide.")

			addButton("Continue", "See what happens next", "crate_pee")
	if state == "crate_pee":
		say("After a few seconds of direct exposure to your piss stream, the tablet displays a warning and then you hear a small crackle, and it shuts off. You aren't sure how much damage it caused, but you hope it's a lot. ")

		if helpedAlex:
			saynn("You feel a moment of doubt as you remember Alex's pile of broken tablets. Is he going to have to fix this...? Hopefully not.")
		else:
			say("\n\n")

		saynn("As your stream finally comes to an end, you give up all pretense and begin masturbating in earnest. You force yourself to stop at the edge of climax because it's more fun, but a large part of your brain wants to keep going. After you calm down enough to trust yourself, you slide off the crate and turn around to inspect your handiwork. It smells like a toilet.")

		say("You're almost certainly not going to be able to open this crate now, but you give it a try just in case. ")
		if openedMetalCrate:
			saynn("Somehow, it opens! The crate contains a bunch of vials labeled " + pickedFormula + ". You have no idea what that is. You reluctantly close the crate again. Best to not mess with it.")
		else:
			saynn("No dice.")
		
		if hasJunkExposed():
			saynn("You give the {pick('pee', 'piss')}-soaked crate one last look and turn around, walking away. Suck it, AlphaCorp.")
		else:
			saynn("You walk around the crate and retrieve your pants. A bunch of your {pick('pee', 'piss')} has dripped down onto them. You put them on and wince at the feeling of wet clothes on a wet body. You'll need to do laundry later, but this will do for now. You walk away as normally as you can, horny and satisfied.")

		addButton("Continue", "See what happens next", "end_scene")

	if state == "just_pee_start":
		saynn("Why pee on something when you can just pee?")

		if hasJunkExposed():
			say("You widen your stance and move a hand down to your " + genitalString(false) + ".")

			if genitals == "penis":
				saynn("You gently angle your {penis} down towards the ground.")
			elif genitals == "chastity_cage":
				saynn("You gently angle your package down towards the ground.")
			elif genitals == "vagina":
				saynn("You gently spread your folds, trying to give yourself a clear shot.")
			else:
				saynn("You try to give yourself a clear shot to the ground.")
			
			saynn("You relax and soon the need to {pick('pee', 'piss')} overtakes you. You push through the part of your brain that says to wait and before you know it, a stream of {pick('pee', 'piss', 'urine')} starts to flow out of you. Your aim is true, and it hits the ground without hitting your leg. You only have a few seconds to think about it before a puddle starts to form, soaking your {pc.feet}. It's very warm.")

			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				say("You cup your free hand under your piss stream and collect a handful of it. You bring it up to your mouth and slurp it up. It's wretched and you can't help but moan. Delicious~. You do this a few times before just leaving your hand down at your crotch to ")
				if GM.pc.hasReachablePenis():
					saynn("stroke your " + genitalString() + ".")
				else:
					saynn("rub your " + genitalString() + ".")
			else:
				say("You move your free hand down to your crotch and begin ")
				if GM.pc.hasReachablePenis():
					say("stroking ")
				else:
					say("rubbing ")
				saynn("your " + genitalString() + ".")
			
			saynn("You moan loudly at the mixed feelings of relief and pleasure. You should do this all the time. It might lead to an awkward time in the bathroom but that's a price you're willing to pay.")
		else:
			saynn("You start to pull off your clothes and then pause. Fuck it. Why [i]not[/i] {pick('pee', 'piss')} on something when you can? You decide to leave your clothes where they are.")

			saynn("You don't even bother to adjust your stance. This is going to be messy either way. You instead close your eyes and try to will yourself to {pick('pee', 'piss')}. It... doesn't work. At least not at first. Your thoughts turn to running water, which does the trick and you can feel yourself start to leak {pick('pee', 'piss')}.")

			saynn("You open your eyes and look down. There's a damp spot on your crotch that's expanding rapidly. What first starts as a pleasant warm sensation very quickly becomes the heavy feeling of wet pants. It's not unpleasant per se, but it's weird. You can feel {pick('pee', 'piss', 'urine')} dripping down your legs, leaving a trail of damp behind it.")

			saynn("There's a puddle forming beneath you. Your {pc.feet} are getting soaked. It's oddly nice. You didn't think they were cold but they're certainly warm now. It's kind of nice.")
		
		addButton("Continue", "See what happens next", "just_pee_end")
	if state == "just_pee_end":
		if hasJunkExposed():
			say("Eventually the stream tapers off, and you adjust your stance to be more comfortable. A bit of {pick('pee', 'piss', 'urine')} gets on your thighs, but not much. You keep ")
			
			if GM.pc.hasReachablePenis():
				say("stroking ")
			else:
				say("rubbing ")

			saynn("though. After a few more seconds of it, you force your hand away as you reach the edge of climax. It almost hurts, but it will feel better when you cum later. That's what you tell yourself anyway.")
		else:
			saynn("You slide a hand down your waistband and begin toying with your " + genitalString() + ". This should be embarrassing and gross, but it's just turned you on. You feel the stream on your hand and moan openly. If any guard sees you now, it will be outright impossible to explain and you're not sure you could run.")

			saynn("That thought prompts your hand to speed up, even as your stream starts to taper off. You keep going and use the {pick('pee', 'piss')} on your hand as lube. You must look wretched right now, standing in a pile of {pick('pee', 'piss')}, wet clothes, and masturbating. Eventually you find yourself approaching the edge and you force yourself to stop. It will be better later.")
		
		say("As you walk away from the puddle you've left, your {pc.feet} slip on the wet flooring, and you fall to the ground. Ow! You lay there for a moment in a puddle of your own {pick('pee', 'piss', 'urine')}. You sigh deeply. You don't think anything is hurt except for your pride. ")
		if GM.pc.hasPerk(WsUtil.Perk_Revelry):
			saynn("You're now absolutely soaked in your own {pick('pee', 'piss')} too, though that's not the worst thing to ever happen.")
		else:
			saynn("You smell like a walking toilet now. A lot of people won't like it, but it's not too bad.")
		
		saynn("You push yourself up with a grunt and then rise to your feet. You slowly walk away, this time being more careful not to fall.")

		addButton("Continue", "See what happens next", "end_scene")

func _react(action: String, _args):
	if action == "grow_bed_start":
		setState("grow_bed_start")

		playAnimation(StageScene.Solo, "stand", {bodyState = {naked = true}})

		return
	if action == "grow_bed_end":
		setState("grow_bed_end")

		if GM.pc.hasReachablePenis():
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})

		var amount = PissWrapper.drain(GM.pc)
		# Plants are people or whatever
		WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSING_ON_SOMEONE, amount)

		GM.pc.addLust(50)

		return

	if action == "crate_start":
		setState("crate_start")

		playAnimation(StageScene.Solo, "stand", {bodyState = {naked = true}})

		return
	if action == "crate_end":
		setState("crate_end")

		if !canOpenCrate:
			PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.25)
			if GM.pc.hasReachablePenis():
				playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
			else:
				playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
			
			GM.pc.addLust(50)
			PissWrapper.drain(GM.pc)
		else:
			var amount = PissWrapper.drain(GM.pc)
			playAnimation(StageScene.Solo, "stand", {bodyState = {naked = true, hard = true}})
			# Much like in dark souls, these crates are living.
			WsUtil.giveSkillExperience(GM.pc, WsUtil.XP_FROM_PISSING_ON_SOMEONE, amount, 0.5)

		return
	if action == "crate_pee":
		setState("crate_pee")

		playAnimation(StageScene.Solo, "stand", {bodyState = {naked = true, hard = true}})

		return

	if action == "just_pee_start":
		setState("just_pee_start")

		if hasJunkExposed():
			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				PissWrapper.peeIntoCharacter(GM.pc, GM.pc, BodypartSlot.Head, 0.05)
			PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.05)
			
			if GM.pc.hasReachablePenis():
				playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
			else:
				playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.5)

		return
	if action == "just_pee_end":
		setState("just_pee_end")

		if GM.pc.hasReachablePenis():
			playAnimation(StageScene.Grope, "watchstroke", {onlyPC = true, bodyState = {naked = true, hard = true}})
		else:
			playAnimation(StageScene.Grope, "watchrub", {onlyPC = true, bodyState = {naked = true, hard = true}})
		
		GM.pc.addLust(50)
		
		PissWrapper.peeOntoCharacter(GM.pc, GM.pc, 0.2)
		PissWrapper.drain(GM.pc)

		return

	if action == "end_scene":
		playAnimation(StageScene.Solo, "stand")
		endScene()
		return

func genitalString(descriptive: bool = true) -> String:
	if descriptive:
		if GM.pc.hasReachablePenis():
			return "{pc.penisShort}"
		elif GM.pc.isWearingChastityCage():
			return "{pc.penisShort}"
		elif GM.pc.hasReachableVagina():
			return "{vagina}"
		else:
			return "crotch"
	else:
		if GM.pc.hasPenis():
			return "{penis}"
		elif GM.pc.hasVagina():
			return "{vagina}"
		else:
			return "crotch"

func hasJunkExposed() -> bool:
	var equipment = GM.pc.inventory.getAllEquippedItems()
	for equippedItem in equipment.values():
		for coveredBodypart in equippedItem.coversBodyparts():
			if coveredBodypart == BodypartSlot.Penis || coveredBodypart == BodypartSlot.Vagina:
				return false

	return true

func saveData():
	var data =.saveData()

	data["useFloor"] = useFloor
	data["pickedFormula"] = pickedFormula
	data["canOpenCrate"] = canOpenCrate
	data["helpedAlex"] = helpedAlex
	data["openedMetalCrate"] = openedMetalCrate

	return data

func loadData(data):
	useFloor = SAVE.loadVar(data, "useFloor", RNG.chance(50))
	pickedFormula = SAVE.loadVar(data, "pickedFormula", RNG.pick(FORMULAS))
	canOpenCrate = SAVE.loadVar(data, "canOpenCrate", GM.pc.getStat(Stat.Strength) >= 10)
	helpedAlex = SAVE.loadVar(data, "helpedAlex", GM.main.getModuleFlag("AlexRynardModule", "ch1IntroSceneHappened") == true)
	openedMetalCrate = SAVE.loadVar(data, "openedMetalCrate", RNG.chance(20))