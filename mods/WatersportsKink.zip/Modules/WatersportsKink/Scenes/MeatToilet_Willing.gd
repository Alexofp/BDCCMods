extends SceneBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

const BULLY_ID = "gymbully3"

const COST_PER_ROUND = 20
const MAX_ROUNDS = 10
const MIN_ROUNDS = 4

const STRAPON_IDS = [
	"Strapon",
	"StraponCanine",
	"StraponDragon",
	"StraponFeeldoe",
	"StraponFeline",
	"StraponHorse",
]

var old_npc_he: String = "ERROR"
var leave: String = "ERROR"

var npcId
var npc: BaseCharacter
var usedNpcs = {}
var done: bool = false
var rounds = 0

var credits: int = 0
var hole: String = "ERROR"

func _init():
	sceneID = WsUtil.Scene_MeatToilet_Willing

func getSceneCreator():
	return "Frivolous\nInspired by Reggie"

func _run():
	if state == "":
		saynn("You see several urinals.")

		saynn("As you inspect them, a lewd idea strikes you. What if you let yourself be used as a {pick('meat', 'piss')} toilet?")

		if GM.pc.hasPerk(WsUtil.Perk_Urolagnia):
			addButtonUnlessLate("Commit", "Get into the urinal", "start", [], "It's a bit late to find a crowd to piss on you.")
		else:
			addButtonUnlessLate("Commit", "This is a bit gross, but you're gonna do it anyway", "start", [], "It's a bit late to find a crowd to piss on you.")
		addButton("Back", "You changed your mind", "end_scene")

	if state == "start":
		saynn("You give the urinals a quick inspection. They seem clean enough. You send a silent thank you to the janitors that do such a good job. This place would be intolerable if it wasn't so clean.")

		if GM.pc.isFullyNaked():
			saynn("You're glad that you aren't wearing anything. This is going to get messy.")
		else:
			saynn("You strip out of your clothes and go find a place to stash them. You don't want to be wearing them for what happens next.")

		saynn("You take a quick look around to see if anyone can help you with this. Chaining yourself to a urinal isn't easy, but it's a core part of the meat toilet experience.")

		npcId = getSomeoneNearby()
		if npcId != null:
			npc = GM.main.getCharacter(npcId)
			addCharacter(npcId)
			saynn("After a quick look around, you spot {npc.name}. You approach {npc.him} and ask {npc.him} an embarrassing question.")

			saynn(RNG.pick([
				"[say=pc]Hey, want to help tie me to the urinal for a bit? You can use me~[/say]",
				"[say=pc]I have a mighty need to get tied to that urinal. Want to help?[/say]",
				"[say=pc]I wanna be a {pick('piss', 'meat')} toilet. Wanna help?[/say]",
				"[say=pc]I wanna be a {pick('piss', 'meat')} toilet. If you tie me up, you can use me. What do you think~?[/say]",
			]))

			if npc.getFetishHolder().getFetish(WsUtil.Fetish_Giving) >= 0.5:
				saynn(RNG.pick([
					"[say=npc]Hell yeah I do. C'mon, I've got just the thing.[/say]",
					"[say=npc]Sure, sounds like fun.[/say]",
					"[say=npc]Okay, but we have to be quick. I really need to go.[/say]",
					"[say=npc]You okay with swallowing? Hell yeah.[/say]"
				]))
				
				saynn("You both approach a urinal in the middle of the wall.")

				cuffText()

				addButton("Continue", "See what happens next", "first_pee")
			else:
				saynn(RNG.pick([
					"[say=npc]Not really my thing... I know someone who'll love this though. One sec.[/say]",
					"[say=npc]No, but I know someone who will love that. Let me go get them.[/say]",
					"[say=npc]I'm not really into {pick('pee', 'piss')}... I think I know someone who is though.[/say]",
					"[say=npc]...I'm not going to judge, but no. I know someone who might be willing to help you though.[/say]",
				]))

				say("{npc.He} {npc.verbS('jog')} out the door, leaving you standing there awkwardly in the bathroom. As a minute passes, you begin to wonder if {npc.he}'ll ever come back. Until eventually...")

				addButton("Continue", "See what happens next", "start_found_someone")
		else:
			npcId = BULLY_ID
			npc = GM.main.getCharacter(npcId)

			saynn("Alas, nobody seems to be around. You even check under the stalls and there's nobody in any of those. You'll have to do this yourself.")

			saynn("Even as you have that thought, though, someone walks through the door. It's one of the prison's resident bullies. There's no sign of the rest of {npc.her} gang though, which is a relief.")

			if getModuleFlag("JackiModule", "BathroomBulliesBecamePissToilet"):
				saynn("{npc.Her} eyes light up upon seeing you.")

				saynn("[say=npc]Oh my god, it's my favorite meat toilet! Hi~![/say]")
			else:
				saynn("{npc.She} doesn't acknowledge you, instead just aiming for one of the toilet stalls.")

			saynn("{npc.She}... wouldn't be your first choice. {npc.She}'{npc.verbS('re', 's')} a Red, and crazy to boot. But from what you know {npc.she} won't judge, so you may as well ask. It'll be embarrassing but you're no stranger to shame.")
			
			saynn("[say=pc]Hey. Would you... tie me to the urinal and use me?[/say]")

			saynn("Like a switch was flipped, {npc.her} expression changes to a perverted smile, and {npc.her} eyes go half lidded.")

			saynn("[say=npc]God you're pathetic. Abso-fucking-lutely. Gotta hurry though I need to {pick('pee', 'piss')} real fucking bad.[/say]")

			saynn("Before you can respond, {npc.she} grabs you and drags you towards one of the urinals. Once you're there, {npc.she} gives you a shove so you land butt-first in the urinal and produces a pair of handcuffs and a ring gag. You aren't surprised that {npc.she} just carries those on {npc.her}.")

			saynn("With your assistance, {npc.she} secures your hands above your head and puts the gag on you.")

			saynn("[say=npc]Open wide, bitch.[/say]")

			if !npc.isFullyNaked():
				saynn("{npc.She} strips down and prepares to use you as a toilet.")
		
			addButton("Continue", "See what happens next", "first_pee")

	if state == "start_found_someone":
		removeCharacter(npcId)
		var npc_name = npc.getName()

		npcId = BULLY_ID
		npc = GM.main.getCharacter(npcId)
		addCharacter(BULLY_ID)


		if getModuleFlag("JackiModule", "BathroomBulliesBecamePissToilet"):
			saynn("[say=npc]Oh. My god. When " + npc_name + " said someone wanted to be used as a meat toilet, I didn't know it'd be you again. You're a freak, you know that?[/say]")

			saynn("It's one of the prison's resident bullies. You remember {npc.her} from when {npc.she} and the rest of {npc.her} gang forced you to be a toilet after you tried to rescue Jacki. {npc.She}{npc.verbS('re', 's')}... not that threatening, though {npc.she} is kinky.")

			saynn("{npc.She} has a perverted smile on {npc.her} face. A change from the usual crazy one you see.")
		else:
			saynn("[say=npc]Hey~. You're the one who wanted to be a meat toilet? I can help.[/say]")

			saynn("A cute canine {npc.girl} approaches you. You've seen {npc.himHer} around before. {npc.She}'{npc.verbS('re', 's')} a Red, and part of one of the prison gangs. Ordinarily you'd leave if {npc.she} started approaching you because it could only end badly. This time though, you're hoping that {npc.she}'ll help.")
		
		saynn(RNG.pick([
			"[say=pc]Hah, yeah. Can you tie me to the urinal? You can be first in line.[/say]",
			"[say=pc]Yep! Tie me up? You can be first in line.[/say]",
			"[say=pc]It's embarrassing... but yes. Want to help?[/say]",
			"[say=pc]Yeah... It's hot, right? Wanna help get me set up? You can have first dibs.[/say]",
		]))

		saynn(RNG.pick([
			"[say=npc]Couldn't stop me even if you wanted to. C'mere.[/say]",
			"[say=npc]Oh FUCK YEAH. NO TAKES BACKSIES.[/say]",
			"[say=npc]Like you even need to ask.[/say]",
			"[say=npc]Sluts usually don't ask for it~... Of course.[/say]"
		]))

		saynn("Before you can respond, {npc.she} {npc.verbS('grab')} you and {npc.verbS('pull')} you towards one of the urinals.")

		cuffText()
		
		addButton("Continue", "See what happens next", "first_pee")

	if state == "first_pee":
		var isPcBald = GM.pc.hasHair()

		if npc.hasPenis():
			if npc.isWearingChastityCage():
				saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('grab')} {npc.his} {npc.penisShort}. {npc.He} aims it at your face as best she can.")
			else:
				saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('grab')} {npc.his} {npc.penisShort}, aiming it at you. This would be a great position for {npc.him} to thrust cleanly into your mouth, but that's not what's about to happen.")
		elif npc.hasVagina():
			saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('thrust')} {npc.his} hips forward until {npc.his} {vagina} is inches from your face. This would be an ideal position to eat {npc.him} out in, but that's not what's about to happen.")
		else:
			saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('thrust')} {npc.his} hips forward until {npc.his} crotch is inches from your face. It'll be impossible to miss from here.")

		say("You can't help but begin to drool as {npc.he} {npc.verbS('loom')} over you. ")

		if npcId == BULLY_ID || npc.getInmateType() == InmateType.SexDeviant:
			saynn("{npc.He} {npc.verbS('make')} eye contact and {npc.verbS('lick')} {npc.his} lips before groaning.")
		else:
			saynn("{npc.He} {npc.verbS('close')} {npc.his} eyes and {npc.verbS('throw')} {npc.his} head back.")

		saynn("Slowly, a few drips of {pick('pee', 'piss')} start coming out of {npc.his} {pick('pee', 'piss')} hole. They very quickly become a stream of golden {pick('pee', 'piss', 'urine')}. It sprays all over your face, forcing you to shut your eyes. You can't shut your mouth though, and some of {npc.his} {pick('pee', 'piss')} gets into it.")

		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			saynn("You moan and let the {pick('pee', 'piss')} pool in your mouth, breathing only through your nose. It tastes awful but you can't help enjoy it. After your mouth is about halfway full, you swallow and shudder.")
		else:
			saynn("You can't spit out the {pick('pee', 'piss')} and you don't want to let it pool, which means you only have one choice. You swallow it and shudder, almost gagging as your body rebels.")
		
		saynn("[say=pc]Ngh-h[/say]")

		if npc.hasPenis():
			saynn("You can feel {npc.him} adjust {npc.his} stream, moving first up to " + ("your hair" if isPcBald else "top of your head") + " and then down to your chest to make sure that you're as soaked as possible. You sigh deeply at the feeling.")
		else:
			saynn("You feel {npc.his} hands reach out and press against your head, trying to make you look down. You don't resist, and soon the stream is spraying against " + ("your hair" if isPcBald else "the top of your head") + " and dripping down your back. You sigh deeply at the feeling.")
		
		saynn("After that, {npc.his} urine stream slowly starts to weaken. Looks like {npc.he}'{npc.verbS('re', 's')} finished {pick('peeing', 'pissing')} on you.")

		saynn("[say=npc]Ahh~. Good {pick('meat', 'piss')} toilet.[/say]")

		saynn("You give your head a shake to get some of the {pick('pee', 'piss')} off of your face and then look up at {npc.him}, opening your eyes. You can only imagine how you must look right now.")

		if npcId == BULLY_ID || npc.getInmateType() == InmateType.HighSec:
			saynn("[say=npc]Want out now? Too bad. You're too good a {pick('meat', 'piss')} toilet to free.[/say]")
		else:
			saynn("[say=npc]You're a cutie. I've got some friends that would love to meet you...[/say]")
		
		say("{npc.He} {npc.verbS('leave')}, presumably to fetch more people to use you.")

		addButton("Continue", "You're in for it now.", "generic_pee")
	
	if state == "generic_pee":
		say(RNG.pick([
			"You aren't left waiting for too long. ",
			"You don't have to wait very long. ",
			"You aren't waiting for very long. ",
			"You barely have to wait any time at all. "
		]))
		say(RNG.pick([
			"Another inmate walks in soon after " + old_npc_he + leave + ". ",
			"A couple minutes later, another inmate comes in. ",
			"After a few minutes, an inmate walks in. ",
			"Soon, another inmate walks through the door. "
		]))
		saynn(RNG.pick([
			"{npc.He} {npc.verbS('beeline')} towards you, stripping out of {npc.his} clothes as {npc.he} {npc.verbS('go', 'goes')}.",
			"After {npc.he} {npc.verbS('spot')} you, {npc.he} {npc.verbS('strip')} and {npc.verbS('approach', 'approaches')} you.",
			"{npc.He} {npc.verbS('were', 'was')} clearly expecting you and {npc.verbS('are', 'is')} halfway out of {npc.his} clothes before {npc.he} even gets through the door. {npc.He} quickly {npc.verbS('approach', 'approaches')} you.",
			"{npc.He} {npc.verbS('seem')} surprised to see you, but {npc.verbS('recover')} quickly and {npc.verbS('walk')} towards you while stripping out of {npc.his} clothes.",
		]))

		saynn(RNG.pick([
			"[say=npc]Finally. I've needed to go for ages.[/say]",
			"[say=npc]Hope you're ready, I've been holding this in all day[/say]",
			"[say=npc]Are you here for pleasure or as punishment? Don't answer that, I don't care.[/say]",
			"[say=npc]I really need to go, so I hope you're ready.[/say]",
			"[say=npc]Oh fuck yeah, this is hot.[/say]",
			"[say=npc]So I just piss on you? Awesome.[/say]"
		]))

		if npc.hasPenis():
			if npc.isWearingChastityCage():
				saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('grab')} {npc.his} package, aiming it at you.")
			else:
				saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('aim')} {npc.his} {npc.penisShort} at you.")
		elif npc.hasVagina():
			saynn("{npc.He} {npc.verbS('spread')} {npc.his} legs and {npc.verbS('thrust')} {npc.his} hips forward. One of {npc.his} hands moves down to {npc.his} {vagina} and spreads the folds to give {npc.him} a clear shot at you.")
		else:
			saynn("{npc.He} {npc.verbS('thrust')} {npc.his} hips forward, giving {npc.him} a clear shot at your face.")
		
		saynn("{npc.He} {npc.verbS('maintain')} eye contact with you as {npc.he} {npc.verbS('begin')} {pick('peeing', 'pissing')}. What starts as a few drops very quickly becomes a stream of strong-smelling {pick('pee', 'piss', 'urine')}. It gets all over your face, forcing you to close your eyes.")

		var isPcBald = GM.pc.hasHair()
		var rng = RNG.randi_range(1, 6)

		if rng == 1:
			saynn("Some of it gets up your nose, which causes you to immediately flinch and cough. {npc.He} {npc.verb('don', 'doesn')}'t even hesitate and {npc.verbS('reach', 'reaches')} out to grab your " + ("hair" if isPcBald else "head") + " and {npc.verb('pull')} you back so that the stream is still aimed at your face.")

			saynn("[say=npc]Bad slut. Stay still.[/say]")

			saynn("The liquid in your nose drains down the back of your throat and you cough again. It burns, but you can breathe through your nose safely again. You force yourself to stop coughing. Good toilets take it like a champ.")
		elif rng == 2:
			saynn("You can feel {npc.him} reach out and grab your " + ("hair" if isPcBald else "head") + " before pulling your head into a better angle. The stream goes directly into your mouth.")

			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				saynn("You let the stream collect in your mouth and just before it overflows, you swallow it eagerly before letting it start to pool again. It tastes gross and you feel depraved doing this, but you can't deny how much you like it.")
			else:
				saynn("You barely stop yourself from retching when the stream hits the back of your throat. You swallow it on reflex, but it keeps coming. You have a choice to make. Either let it pool and overflow or get rid of it. Reluctantly you start swallowing. You feel almost queasy from it.")
			
			saynn("[say=npc]Good {pc.boy}. Swallow it all.[/say]")
		elif rng == 3:
			saynn("Some of the {pick('pee', 'piss')} gets up your nose. It burns, and all you can smell now is {pick('pee', 'piss', 'urine')}. You immediately start hacking and retching, trying to get it out of your nose. The stream doesn't move at all. {npc.name} seems to not care about your distress.")

			saynn("[say=npc]You're a shitty toilet, you know that?[/say]")

			saynn("You try to respond but the gag makes it unclear whether {npc.he} understands you at all.")

			saynn("[say=pc]Got piss in my nose.[/say]")

			saynn("[say=npc]Yeah, whatever. Hold still.[/say]")
		elif rng == 4:
			saynn("{npc.He} {npc.verbS('reach', 'reaches')} out and grabs your " + ("hair" if isPcBald else "head") + ", guiding you to an angle where the stream goes directly into your mouth. You don't resist, acting like a good meat toilet should.")

			saynn("[say=npc]Be a good toilet and don't swallow.[/say]")

			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				saynn("That shouldn't be too hard. You let the urine pool in your mouth, closing the back of your throat and letting your tongue marinate in it. It doesn't taste good, but the situation more than makes up for it.")
			else:
				saynn("You whine but close your throat and let a pool of {pick('pee', 'piss', 'urine')} grow inside your mouth. You almost gag at the acrid taste. Almost.")
			
			saynn("{npc.He} {npc.verbS('keep')} going, filling your mouth almost to the point it overflows... Then {npc.he} {npc.verbS('grunt')} and the stream stops.")

			saynn("[say=npc]Alright. Swallow. Goooood {pc.boy}~.[/say]")

			say("At {npc.his} words, you do as requested and gulp down the mouthful of {pick('pee', 'piss', 'urine')}. ")
			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				say("Once you're done, you moan and push your tongue outside of your mouth, eager for more. ")
			else:
				say("You shudder as you do so, not enjoying the experience. The taste is still lingering. ")
			saynn("Before you get a chance to do anything else, you feel the {pick('pee', 'piss')} stream start up again, filling your mouth once again.")

			saynn("[say=npc]You know the drill.[/say]")

			saynn("This cycle repeats itself a few times.")
		elif rng == 5:
			saynn("As the stream continues, {npc.he} {npc.verbS('grab')} your head and {npc.verbS('pull')} it down so that it soaks " + ("your hair" if isPcBald else "the top of your head") + ". Then {npc.he} {npc.verbS('push', 'pushes')} it back up. You don't resist {npc.him} in either direction.")

			saynn("[say=npc]You're a cutie. You belong here.[/say]")

			if npc.hasPenis():
				say("You can feel the stream go up and down your front as {npc.he} {npc.verbS('move')} {npc.his} aim around before finally it settles aimed at your forcibly opened mouth. ")
			else:
				say("{npc.He} {npc.verbS('spray')} pee all over your front somehow and then {npc.verbS('aim')} back at your mouth. ")
			say("Your mouth quickly fills with {pick('pee', 'piss')}. ")
			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				saynn("You swallow it eagerly, moaning at the taste.")
			else:
				saynn("You swallow it reluctantly, not willing to let it pool but grimacing as much as you can at the taste.")
		elif rng == 6:
			saynn("[say=npc]Alright slut, you'd better not swallow. I wanna see you make a mess.[/say]")

			saynn("You grunt out your consent. You can feel the stream move around a bit before settling on your open mouth. It very quickly fills to the brim with {pick('pee', 'piss')}.")

			if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
				saynn("Quite frankly, it's gross. The taste is bitter and it smells awful. You love it. You dutifully keep your throat closed, breathing through your nose. Your mouth soon overflows, and a streams of {pick('pee', 'piss')} start flowing out of it.")
			else:
				saynn("This is disgusting, but it's also what you signed up for. You almost gag, but you force yourself to keep your throat closed and let the gross liquid start to overflow out of your mouth. Good toilets don't get a say in how they're used.")

			saynn("Even as the taste and smell threatens to overwhelm you, you hold it. It's really degrading but you're a good slut.")

		addButton("Continue", "See what happens next", "generic_pee_2")
	if state == "generic_pee_2":
		saynn("Eventually, the stream dies down and stops.")

		if GM.pc.hasPerk(WsUtil.Perk_Lemonade):
			say("You eagerly swallow down whatever {pick('pee', 'piss')} is in your mouth, then lick your lips. ")
		else:
			say("You groan softly and swallow down whatever {pick('pee', 'piss')} is left in your mouth. ")
		
		saynn("You stick your tongue out of your mouth and pant.")

		saynn("[say=npc]Ahh~. Fuck if I care whether you enjoyed yourself because I sure did.[/say]")

		if RNG.chance(50):
			if npc.hasPenis():
				saynn("{npc.He} {npc.verbS('step')} forward and {npc.verbS('press', 'presses')} {npc.his} {npc.penisShort} into your mouth.")
			elif npc.hasVagina():
				saynn("{npc.He} {npc.verbS('step')} forward and {npc.verbS('press', 'presses')} {npc.his} {vagina} against your mouth.")
			else:
				saynn("{npc.He} {npc.verbS('step')} forward and {npc.verbS('press', 'presses')} {npc.his} crotch against your mouth.")
			
			saynn("[say=npc]Clean it.[/say]")

			saynn("You do as {npc.he} {npc.verbS('ask')} and swipe your tongue over everything it can reach. After a few seconds, {npc.he} {npc.verbS('pull')} away and {npc.verbS('give')} you a pat on the head. {npc.He} then {npc.verbS('walk')} to the sink directly across from the urinal and {npc.verbS('begin')} washing {npc.his} hands.")
		else:
			saynn("{npc.He} {npc.verbS('walk')} to the sink directly across from the urinal and {npc.verbS('start')} washing {npc.his} hands.")

		if done:
			saynn("You shake your head to clear your face and open your eyes. You give {npc.him} a pointed look through the mirror.")

			saynn("[say=pc]Help me free?[/say]")

			saynn("[say=npc]Oh. Right. I guess nobody else is coming, huh? Should probably at least get those cuffs off...[/say]")

			saynn("{npc.He} {npc.verbS('walk')} back over to you, not even bothering to turn off the sink. After a moment of fidgeting with your hands, the cuffs come undone, letting you free.")

			saynn("[say=npc]You're lucky whoever put you here left the keys on the urinal. I can't pick locks.[/say]")

			saynn("{npc.He} {npc.verbS('go', 'goes')} back to washing {npc.his} hands and then leaves.")

			addButton("Continue", "That was a lot", "freedom")
		else:
			if RNG.chance(40):
				saynn("After {npc.he} {npc.verbS('finish', 'finishes')}, {npc.he} {npc.verbS('toss', 'tosses')} a credit chip down at the urinal you're cuffed to. It splashes into the remnants of {npc.his} {pick('pee', 'piss')} as it slowly drains away. Then {npc.he} {npc.verbS('walk')} away, leaving you alone and waiting.")
				credits += RNG.randi_range(1, 3)
			else:
				saynn("After {npc.he} {npc.verbS('finish', 'finishes')}, {npc.he} {npc.verbS('walk')} away, leaving you alone and waiting.")
			
			if RNG.chance(30):
				addButton("Continue", "Wait for the next person", "generic_fuck")
			else:
				addButton("Continue", "Wait for the next person", "generic_pee")
	
	if state == "generic_fuck":
		saynn("[say=npc]Hey so I know you're being a good toilet, but I'm really horny right now. Is it okay if I just fuck you?[/say]")
		
		saynn("{npc.He} {npc.verb('don', 'doesn')}'t wait for you to respond.")

		saynn("[say=npc]Okay, awesome.[/say]")

		say("{npc.He} {npc.verbS('strip')} out of {npc.his} clothes and {npc.verbS('approach', 'approaches')} you. ")
		if npc.hasPenis():
			if npc.isWearingChastityCage():
				saynn("{npc.His} {npc.penisShort} is already straining against its cage.")
			else:
				saynn("{npc.He}'{npc.verb('re', 's')} already fully erect, clearly eager to have a go at you.")
		elif npc.hasVagina():
			saynn("You can see some moisture around {npc.his} {vagina}. {npc.He}'{npc.verb('re', 's')} clearly excited to see you.")
		else:
			saynn("{npc.He}'{npc.verb('re', 's')} clearly excited and willing to use you.")

		if !npc.hasReachablePenis():
			say("{npc.He} {npc.verbS('start')} putting on a strap-on. ")
			if GM.pc.hasPenis() && !GM.pc.isWearingChastityCage():
				saynn("Despite the perfectly good {penis} you have between your legs, seems {npc.he} would rather fuck you than ride you.")
			else:
				say("\n\n")

			npc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem(RNG.pick(STRAPON_IDS)))
		
		saynn("{npc.He} {npc.verbS('grab')} your ankles and pull your legs up to your hands, heedless of the urine that's soaked your entire body.")

		saynn("[say=npc]Keep those legs up.[/say]")

		if GM.pc.hasReachableVagina():
			saynn("{npc.He} {npc.verbS('approach', 'approaches')} you and {npc.verbS('get')} down on {npc.his} knees, putting the tip of {npc.his} {npc.penisShort} level with your holes. {npc.He} {npc.verbS('prod')} both of them, making you tense before finally deciding on your " + hole + ".")
		else:
			saynn("{npc.He} {npc.verbS('approach', 'approaches')} you and {npc.verbS('get')} down on {npc.his} knees, putting the tip of {npc.his} {npc.penisShort} level with your hole. {npc.He} {npc.verbS('prod')} it a few times, testing how loose it is.")
		
		saynn("[say=npc]Relax. This is going in one way or another; you may as well enjoy it.[/say]")

		saynn("You try to do as {npc.he} {npc.verbS('say')}, though it's hard while keeping your legs up. Suddenly, without warning {npc.he} {npc.verbS('thrust')} into you. Your " + hole + " hurts a bit from the sudden penetration, but you don't think anything is seriously damaged.")

		addButton("Continue", "See what happens next", "generic_fuck_2")
	if state == "generic_fuck_2":
		saynn("{npc.He} {npc.verbS('start')} thrusting into you. Occasionally, {npc.he} {npc.verbS('hit')} a sensitive spot inside you, causing you to jerk suddenly. You cannot help but enjoy it, moaning aloud.")
		
		saynn("[say=pc]A-ahh~[/say]")

		if npc.hasPenis() && !npc.isWearingChastityCage():
			saynn("Eventually, {npc.he} {npc.verbS('pause')} and thrust all the way in.")
			if npc.bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot):
				saynn("The knot presses against your " + hole + ", threatening to go inside but not quite getting in.")

			saynn("[say=npc]Ahhhhhh~[/say]")

			saynn("You feel a flood of warmth inside you. Did... {npc.he} cum? That didn't take very long. {npc.He} slowly {npc.verbS('start')} thrusting again though and {npc.verb('are', 'is')} soon back up to full speed. Suddenly, it hits you. {npc.He} pissed inside you. You weren't prepared for the sudden spike of arousal that shoots down your spine.")

			say("A short time later, the thrusts get erratic and then {npc.he} {npc.verbS('hilt')} again. ")
			if npc.bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot):
				say("This time, {npc.he} {npc.verbS('press', 'presses')} all the way inside, properly knotting you. You groan at the sudden stretch but your " + hole + " takes it. ")
			saynn("{npc.He} {npc.verbS('lean')} in and {npc.verbS('exhale')} sharply in your ear, groaning.")

			saynn("{npc.He} {npc.verbS('rock')} {npc.his} hips a bit. You can't feel anything after {npc.he} {pick('peed', 'pissed')} in you earlier, but you're sure {npc.he} just finished and {npc.verb('are', 'is')} cumming inside your {pick('pee', 'piss')}-filled " + hole + ".")

			say("After a moment, {npc.he} {npc.verbS('pull')} out. A flow of {pick('pee', 'piss')} and cum flows out almost immediately. ")
			if hole == BodypartSlot.Anus:
				say("You moan and flex your {butthole} a few times, letting the disgusting cocktail flow out. ")
			else:
				say("You moan and relax your {vagina}, letting the mixture flow out.")
			saynn("Most of it comes out, then you clench and try to keep some of it inside.")
		else:
			say("{npc.He} {npc.verbS('keep')} going, building up speed until {npc.his} hips are a blur. Eventually, {npc.he} {npc.verbS('thrust')} all the way in and {npc.verbS('pause')}. ")
			if npc.bodypartHasTrait(BodypartSlot.Penis, PartTrait.PenisKnot):
				saynn("The knot presses against your " + hole + " and slips in. You squeak at the sudden intrusion.")

			saynn("[say=npc]Fuuucck.[/say]")

			npc.cumOnFloor()
			if npc.isWearingChastityCage():
				saynn("You feel a squirt of something warm down below. You suspect {npc.he} just came in {npc.his} cage. The embarrassed look on {npc.his} face all but confirms it. That must have been intense.")
			elif npc.hasVagina():
				saynn("You feel a squirt of something warm down below. A glance at {npc.his} face confirms what you already knew: {npc.he} just climaxed from fucking you.")
			else:
				saynn("The flushed look on their face suggests {npc.he} just came. {npc.He} {npc.verbS('grind')} slightly on the strap-on and {npc.verbS('moan')} softly under {npc.his} breath.")

			saynn("After a few seconds, {npc.he} {npc.verbS('pull')} out of you, leaving your " + hole + " clenching at nothing. {npc.He} {npc.verbS('stand')} up and thrust {npc.his} hips forwards before closing {npc.his} eyes. After a few seconds, a spray of {pick('pee', 'piss')} comes out from under the strap-on, soaking your face. You flinch and close your eyes.")

			saynn("[say=npc]Good {pc.boy}. Take my piss.[/say]")

			saynn("{npc.He} seemingly did not need to go that badly, which might explain why {npc.he} decided to fuck you first. You can already feel the stream start to die. {npc.He} {npc.verbS('groan')} one last time and then move {npc.his} hips away.")
		
		saynn("{npc.He} {npc.verbS('stand')} up and {npc.verbS('thrust')} into your mouth. {npc.He} can easily hilt inside thanks to the gag holding it open.")

		saynn("[say=npc]Clean it.[/say]")

		if hole == BodypartSlot.Anus:
			say("You gag at the taste and sudden intrusion, but you do as requested. ")
		else:
			say("You gag at the sudden intrusion, but you do as requested. ")
		
		saynn("You swipe your tongue around as much as you can and try to clean the shaft. {npc.He} {npc.verbS('give')} a few long thrusts over your tongue and back before pulling back out.")

		if npc.hasPenis():
			if npc.isWearingChastityCage():
				saynn("{npc.He} {npc.verbS('undo', 'undoes')} the straps on {npc.his} strap-on, and then {npc.verbS('press', 'presses')} forward again. This time, {npc.he} {npc.verbS('force')} {npc.his} cage into your mouth as far as it will go. Without being told, you swipe your tongue over it, cleaning it of the lingering mix of salty and bitter.")
			else:
				saynn("[say=npc]Good slut.[/say]")
		elif npc.hasVagina():
			saynn("{npc.He} {npc.verbS('undo', 'undoes')} the straps on {npc.his} strap-on, and then {npc.verbS('push', 'pushes')} forward again. This time, {npc.he} {npc.verbS('press', 'presses')} {npc.his} {vagina} against your mouth. Without being told, you swipe your tongue over it and groan. There's a lingering taste of {pick('pee', 'piss')} as well as arousal. {npc.He} {npc.verbS('grind')} against you for a little bit before eventually pulling away.")

			saynn("[say=npc]You make pretty good toilet paper.[/say]")
		else:
			saynn("{npc.He} {npc.verbS('undo', 'undoes')} the straps on {npc.his} strap-on, and then {npc.verbS('push', 'pushes')} forward again. This time, {npc.he} {npc.verbS('press', 'presses')} {npc.his} crotch against your mouth. Without being told, you swipe your tongue over it and groan. There's a lingering taste of {pick('pee', 'piss')}. {npc.He} {npc.verbS('grind')} against you for a little bit before eventually pulling away.")
		
		saynn("You can probably lower your legs, so you do so. They were getting tired anyway.")

		if RNG.chance(50):
			if RNG.chance(40):
				saynn("{npc.He} {npc.verbS('flick')} a credit chip at you. It lands in the pool of slowly draining liquid inside the urinal with a splash. {npc.He} then {npc.verbS('walk')} to the sink and {npc.verbS('wash', 'washes')} {npc.his} hands before leaving the bathroom. You're alone again, for now.")

				credits += RNG.randi_range(1, 3)
			else:
				saynn("{npc.He} {npc.verbS('walk')} over to the sink and {npc.verbS('wash', 'washes')} {npc.his} hands before walking out of the bathroom, leaving you alone.")
		else:
			if RNG.chance(40):
				saynn("{npc.He} {npc.verbS('flick')} a credit chip at you. It lands in the pool of slowly draining liquid inside the urinal with a splash. {npc.He} then {npc.verbS('walk')} away and {npc.verbS('leave')} the bathroom. You're alone again, for now.")

				credits += RNG.randi_range(1, 3)
			else:
				saynn("{npc.He} {npc.verbS('walk')} to the door and {npc.verbS('leave')}. {npc.He} didn't wash {npc.his} hands. Gross.")

		addButton("Continue", "Wait for the next person", "generic_pee")
	
	if state == "freedom":
		saynn("You just sit there for a moment in silence, not even bothering to move your arms. You're exhausted, despite doing very little. And you [i]really[/i] need to {pick('pee', 'piss')}. Luckily, you're in the perfect spot to take care of that.")

		say("Without moving a muscle, you relax your bladder. ")

		if GM.pc.hasPenis():
			if GM.pc.isWearingChastityCage():
				saynn("{pick('Pee', 'Piss')} starts spraying out of your {pc.penisShort}. It has a lot of force behind it, causing it to get everywhere, but you can't really tell. You're soaked, so this is a drop in the bucket.")

				saynn("Slowly, you lower your arms and move a hand to your package. You give it a few desperate pulls and whine. You're unbelievably horny. Your heart isn't in it though. You want to take a shower and then collapse into your bed.")

				say("As you finish {pick('peeing', 'pissing')}, you stop pulling at your cage ")
			else:
				saynn("A golden stream of {pick('pee', 'piss')} starts flowing out of your {pc.penisShort}. It's fighting against gravity, but it still manages to get far enough into the air that it lands on your face and head. If you weren't already soaked, you might react but it's really just a drop in the bucket at this point.")

				saynn("Slowly, you lower your arms and move a hand to your {penis}. You sigh deeply and start stroking. You are almost painfully hard. Unfortunately, your heart just isn't in it right now. You want to take a long shower and then collapse into your bed.")

				say("As your stream finishes, you stop stroking ")
		elif GM.pc.hasVagina():
			saynn("{pick('Pee', 'Piss')} starts spraying out of your {vagina}. There's not much force behind it, and you just sigh. It would soak your lower half, but that ship sailed long ago. This is just a drop in the bucket of {pick('pee', 'piss')} that soaks you.")

			saynn("Slowly, you lower your arms and rotate your shoulders. They'll be sore. You slowly move a hand to your {vagina} and start rubbing at your clit, moaning softly as you do. You're unbelievably turned on, but your heart just isn't in it. You want to collapse into your bed and take a shower. Not necessarily in that order.")

			say("As your stream finishes, you stop rubbing ")
		else:
			saynn("{pick('Pee', 'Piss')} starts spraying out of your urethra, but there's no force behind it. You sigh deeply. It would soak your lower half, but you cannot get any more wet. It's just a drop in the bucket of {pick('pee', 'piss')} you're sitting in.")

			saynn("Slowly, you lower your arms. You stretch them slightly, and groan. They'll be sore tomorrow. You slowly move a hand to your crotch and rub at it. You're incredibly turned on. Alas, your heart isn't in it. You want to collapse into your bed and take a shower. Not necessarily in that order.")

			say("As your stream finishes, you stop rubbing ")

		saynn("and reach your hands up to the gag on your head. It takes you a few moments, but you eventually get it off. You drop it into the urinal next to you. That'll be someone else's problem. You work your jaw and yawn. Your eyes feel heavy.")

		addButton("Continue", "See what happens next", "freedom_2")

	if state == "freedom_2":
		if credits > 0:
			saynn("Reluctantly, you push yourself to your knees and start collecting credits. They're disgusting to the touch, but you'll deal with that later. The chits should be waterproof. After you're done, you reach an arm up to the top of the urinal and pull yourself onto your {pc.feet}.")
		else:
			saynn("You push yourself to your knees and then reach your hands up to the top of the urinal. You pull yourself to your {pc.feet}.")
		
		saynn("Your legs shake a bit, but after a few seconds you feel confident and let go of the urinal.")

		saynn("Well, that was fun!")

		addButton("Freedom", "You're done being a toilet", "end_scene")

func _react(action: String, _args):
	if action == "first_pee":
		PissWrapper.fillBladder(npc)
		PissWrapper.peeIntoCharacter(npc, GM.pc, BodypartSlot.Head, 0.05)
		PissWrapper.peeOntoCharacter(npc, GM.pc, 1.0)

		processTime(5 * 60)

		if npc.hasPenis():
			playAnimationForceReset(StageScene.UrinalPeeing, "pee", {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
		else:
			playAnimationForceReset(StageScene.UrinalPeeing, "peefemale", {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
		
	if action == "generic_pee":
		old_npc_he = npc.heShe()
		leave = " leave" if npc.getPronounGender() == Gender.Androgynous else " leaves"
		chooseNewNpc()
		PissWrapper.fillBladder(npc)
		PissWrapper.peeIntoCharacter(npc, GM.pc, BodypartSlot.Head, 0.05)
		PissWrapper.peeOntoCharacter(npc, GM.pc, 1.0)

		processTime(5 * 60)
	
		if npc.hasPenis():
			playAnimationForceReset(StageScene.UrinalPeeing, "pee", {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
		else:
			playAnimationForceReset(StageScene.UrinalPeeing, "peefemale", {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
	if action == "generic_fuck":
		chooseNewNpc()
		hole = choosePcHole()
		PissWrapper.fillBladder(npc)

		processTime(2 * 60)

		playAnimationForceReset(StageScene.UrinalSex, "inside", {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
	if action == "generic_fuck_2":
		PissWrapper.peeIntoCharacter(npc, GM.pc, BodypartSlot.Head, 0.05)
		if npc.hasPenis() && !npc.isWearingChastityCage():
			GM.pc.cummedInBodypartBy(hole, npcId, FluidSource.Penis, 0.5)
			npc.cumOnFloor()
			PissWrapper.peeIntoCharacter(npc, GM.pc, hole, 1.0)
		else:
			PissWrapper.peeOntoCharacter(npc, GM.pc, 1.0)

		processTime(5 * 60)

		playAnimation(StageScene.UrinalSex, RNG.pick(["sex", "fast"]), {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
	if action == "freedom":
		playAnimation(StageScene.Urinal, "idle2", {pc = "pc", bodyState = {naked = true, hard = true}})

		processTime(2 * 60)

		GM.pc.getInventory().clearSlot(InventorySlot.Wrists)
	if action == "freedom_2":
		playAnimation(StageScene.Solo, "stand", {pc = "pc", bodyState = {naked = true, hard = true}})

		processTime(5 * 60)

		GM.pc.getInventory().clearSlot(InventorySlot.Mouth)
		if credits > 0:
			GM.main.addMessage("You got " + str(credits) + " credits!")
			GM.pc.addCredits(credits)
	if action == "end_scene":
		endScene()
		return

	setState(action)

func resolveCustomCharacterName(charId):
	if charId == "npc":
		return npcId

func cuffText():
	GM.pc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("inmatewristcuffs"))
	GM.pc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("ringgag"))
	playAnimation(StageScene.UrinalPeeing, "idle", {pc = "pc", npc = npcId, bodyState = {naked = true, hard = true}, npcBodyState = {naked = true, hard = true}})
	
	if npc.isFullyNaked():
		say("{npc.He} {npc.verbS('produce')} a ring gag and some cuffs from... somewhere. ")
	else:
		say("{npc.He} {npc.verbS('produce')} a ring gag and some cuffs from {npc.his} clothes. ")
	saynn("Once upon a time you might have wondered why someone would just carry those around. Now you know why: for situations like this.")

	saynn("Without any prompting, you climb into the urinal. It's cold, which causes you to wince slightly but that won't last for long. Before you know it, {npc.name} has you gagged and is securing your hands behind the pipes of the urinal. You're not getting out of this now.")

	if npc.getInmateType() in [InmateType.General, InmateType.SexDeviant]:
		saynn("[say=npc]I'd offer you a safe word, but we don't really do those here.[/say]")
	
	if !npc.isFullyNaked():
		saynn("{npc.He} {npc.verbS('remove')} {npc.his} clothes and {npc.verbS('get')} into position to treat you like the toilet you are.")

func getSomeoneNearby():
	var room_id: String = GM.pc.getLocation()
	var nearbyPawns = GM.main.IS.getPawnsNear(room_id, 1, 1)
	if nearbyPawns.size() == 1:
		return null

	var chosen: CharacterPawn = RNG.pick(nearbyPawns)
	while chosen.getCharID() == "pc":
		chosen = RNG.pick(nearbyPawns)
	
	return chosen.getCharID()

func choosePcHole():
	if RNG.chance(50):
		if GM.pc.hasVagina():
			return BodypartSlot.Vagina
		else:
			return BodypartSlot.Anus
	else:
		return BodypartSlot.Anus

func chooseNewNpc():
	usedNpcs[npcId] = true
	removeCharacter(npcId)
	npc.getInventory().clearSlot(InventorySlot.Strapon)
	
	while usedNpcs.get(npcId):
		npcId = NpcFinder.grabNpcIDFromPoolOrGenerate(CharacterPool.Inmates, [], InmateGenerator.new(), {})

	npc = GM.main.getCharacter(npcId)
	PissWrapper.fillBladder(npc)
	addCharacter(npcId)

	rounds += 1
	GM.pc.addStamina(-COST_PER_ROUND)
	if rounds >= MIN_ROUNDS:
		if rounds >= MAX_ROUNDS || GM.pc.getStamina() < COST_PER_ROUND:
			done = true

func saveData():
	var data =.saveData()
	data["old_npc_he"] = old_npc_he
	data["leave"] = leave

	data["npcId"] = npcId
	data["usedNpcs"] = usedNpcs
	data["done"] = done
	data["rounds"] = rounds

	data["credits"] = credits
	data["hole"] = hole

	return data

func loadData(data):
	.loadData(data)

	old_npc_he = SAVE.loadVar(data, "old_npc_he", "they")
	leave = SAVE.loadVar(data, "leave", "leave")
	npcId = SAVE.loadVar(data, "npcId", BULLY_ID)
	usedNpcs = SAVE.loadVar(data, "usedNpcs", {})
	done = SAVE.loadVar(data, "done", false)
	rounds = SAVE.loadVar(data, "rounds", 0)
	credits = SAVE.loadVar(data, "credits", 0)
	hole = SAVE.loadVar(data, "hole", BodypartSlot.Anus)