extends BuffBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

var scale = 0

func _init():
	id = WsUtil.Buff_PissCapacityMult

func initBuff(args):
	scale = args[0]

func getVisibleDescription():
	var text = str(Util.roundF(scale, 1))
	if scale > 0:
		text = "+" + text
	return "Piss Capacity " + text + "%"

func apply(holder: BuffsHolder):
	holder.addCustom(BuffAttribute.PissCapacityMult, scale / 100.0)

func getBuffColor():
	if scale < 0:
		return Color.red
	else:
		return Color.yellow

func saveData():
	var data =.saveData()
	data["scale"] = scale

	return data

func loadData(data):
	.loadData(data)
	scale = SAVE.loadVar(data, "scale", 0.0)

func combine(other):
	if other.scale > scale:
		scale = other.scale
