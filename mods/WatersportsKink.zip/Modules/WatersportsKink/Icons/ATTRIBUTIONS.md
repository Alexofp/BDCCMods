# Icon Attributions

## Noun Project

- [Ouroboros](./Ouroboros.png) by Zach Bogart sourced from [Noun Project here][Ouroboros] (CC BY 3.0).
  Modified slightly to create a larger gap between mouth and tail, for visual clarity.
- [Wolf](./Wolf.png) by Uswa KDT from [Noun Project here][Wolf] (CC BY 3.0).
- [drunk](./Drunk.png) by Muh zakaria from [Noun Project here][drunk] (CC BY 3.0).
- [lemonade](./lemonade.png) by Arkinasi [Noun Project here][lemonade] (CC BY 3.0)
- [hydration](./hydration.png) by Rahmad romadoni from [Noun Project here][hydration] (CC BY 3.0)
- [slip](./slip.png) by Michael Appleford from [Noun Project here][slip] (CC BY 3.0)
- [Peeing](./Peeing) by Norbert de Graaff from [Noun Project here][Peeing] (CC BY 3.0)
- [Dog Park](./DogPark.png) by Iconathon from [Noun Project here][Dog Park] (Public Domain)
- [Enema](./Enema.png) by Nur Achmadi Yusuf from [Noun Project here][Enema] (CC BY 3.0)
- [Running](./Running.png) by Zach Hainsworth from [Noun Project here][Running] (CC BY 3.0)
- [beta](./beta.png) by Bakunetsu Kaito from [Noun Project here][beta] (CC BY 3.0)

[Ouroboros]: https://thenounproject.com/icon/ouroboros-3169930/
[Wolf]: https://thenounproject.com/icon/wolf-8202542/
[drunk]: https://thenounproject.com/icon/drunk-5921285/
[lemonade]: https://thenounproject.com/icon/lemonade-6862876/
[hydration]: https://thenounproject.com/icon/hydration-8256492/
[slip]: https://thenounproject.com/icon/slip-6736640/
[Peeing]: https://thenounproject.com/icon/peeing-94435/
[Dog Park]: https://thenounproject.com/icon/dog-park-6323/
[Enema]: https://thenounproject.com/icon/enema-7029632/
[Running]: https://thenounproject.com/icon/running-6856327/
[beta]: https://thenounproject.com/icon/beta-880651/
