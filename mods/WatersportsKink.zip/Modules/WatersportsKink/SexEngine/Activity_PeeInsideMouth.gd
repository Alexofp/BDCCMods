extends SexActivityBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

# In 0.1.12, there is no way to tell if you're mid-oral. We check animations.
# This is gross though and should be replaced with the tagging system when
# we have the chance.
const ANIM_DATA = [
	[StageScene.SexOral, ["sex", "fast"]],
	[StageScene.SexOralForced, ["suck", "suckfast", "suckinside"]],
	[StageScene.SexOralTable, ["suck", "suckfast", "suckinside"]],
	[StageScene.ChairOral, ["suck", "suckfast", "suckinside"]],
	[StageScene.RopesOralSex, ["sex", "fast"]],
	[StageScene.SybianOral, ["blowjob", "blowjobfast"]],
	[StageScene.PuppySexOral, ["sex", "fast"]],
	[StageScene.SexPortalOral, ["suck", "suckfast"]],
	[StageScene.StocksSexOral, ["sex", "fast"]],
	[StageScene.SlutwallSexOral, ["blowjob"]],
]

func _init():
	id = WsUtil.Activity_PeeInMouth
	
	activityName = "Pee Inside"
	activityDesc = "Pee inside your partner. They probably won't mind!"
	activityCategory = ["Humiliate"]

func allowedToUse(sexEngine: SexEngine):
	var currentAnimation = sexEngine.getBestAnimation()
	for animData in ANIM_DATA:
		var stage = animData[0]
		var states = animData[1]
		if filterAnimation(currentAnimation, stage, states):
			return true
	
	return false

func getGoals():
	return {
		WsUtil.Goal_Pissplay: 1.0
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: true,
		SexType.SlutwallSex: true,
		SexType.BitchsuitSex: true,
	}

# For those who come after (more than likely just me):
# Tags are used to ensure that activities overlap.
# i.e. two activities that use the same tag cannot be used together
# the `getTags` method returns the tags that a particular activity gives
# the given SexEngine slot the `getCheckTagsSub` and `getCheckTagsDom` methods
# return tags that are illegal for this activity
# there is no way to whitelist an activity to ONLY occur with specific tags outside of
# overriding `canStartActivity`

# the current state of the SexActivity is processed every turn with
# `STATE_processTurn` where `STATE` is the current value of `state`.
# e.g. `rimming_processTurn` for `rimming`.

func canStartActivity(sexEngine: SexEngine, domInfo: SexDomInfo, subInfo: SexSubInfo):
	if domInfo.getCharID() == "pc":
		if !domInfo.getChar().hasPerk(WsUtil.Perk_PissYourself):
			return false
	else:
		if !OPTIONS.isContentEnabled(ContentType.Watersports):
			return false
	if !PissWrapper.canPee(domInfo.getChar()):
		return false
	
	if !allowedToUse(sexEngine):
		return false
	
	if hasActivity(sexEngine, id, domInfo, subInfo):
		return false

	return true

func getActivityBaseScore(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	return _domInfo.personalityScore({PersonalityStat.Subby: - 0.05}) + _subInfo.getResistScoreSmooth() * 0.05

func getTags(_indx: int) -> Array:
	if _indx == DOM_0:
		return [SexActivityTag.PenisUsed]
	return []

func startActivity(_args):
	addText(RNG.pick([
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and relax, preparing to piss inside {sub.name}'s mouth.",
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and relax, preparing to pee inside {sub.name}'s mouth.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} bladder, preparing to piss inside {sub.name}'s mouth.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} bladder, preparing to pee inside {sub.name}'s mouth.",
		"{dom.You} {dom.youVerb('pause')} for a moment and {dom.youVerb('relax', 'relaxes')} some muscles in {dom.your} crotch, trying to let the urge to pee come.",
		"{dom.You} {dom.youVerb('pause')} for a moment and {dom.youVerb('relax', 'relaxes')} some muscles in {dom.your} crotch, trying to let the urge to piss come.",
	]))

func init_processTurn():
	setState("react")

func react_processTurn():
	var domInfo: SexDomInfo = getDomOrSubInfo(DOM_0)
	var subInfo: SexSubInfo = getDomOrSubInfo(SUB_0)

	if !allowedToUse(getSexEngine()):
		addText("{dom.You} {dom.youVerb('aren', 'isn')}'t inside {sub.name}'s mouth anymore and {dom.youVerb('decide')} to hold {dom.yourHis} {pick('pee', 'piss')}.")
		endActivity()
		return

	addText(RNG.pick([
		"{dom.You} sigh softly and grip {sub.name}'s head as you begin emptying your bladder.",
		"{dom.You} say nothing but thrust a few times into {sub.name} as you let your bladder empty.",
		"{dom.You} grab {sub.name} and hilt {dom.yourself} in {sub.his} throat as {dom.you} let {dom.yourself} pee inside.",
		"{dom.You} grab {sub.name} and hilt {dom.yourself} in {sub.his} throat as {dom.you} let {dom.yourself} piss inside.",
		"{dom.You} {dom.youVerb('groan')} softly as {dom.you} {dom.youVerb('empty', 'empties')} {dom.your} bladder inside {sub.name}'s mouth.",
		"{dom.You} {dom.youVerb('groan')} as {dom.you} {dom.youVerb('empty', 'empties')} {dom.your} bladder inside {sub.name}'s mouth."
	]))

	var amount = PissWrapper.peeIntoCharacter(domInfo.getChar(), subInfo.getChar(), BodypartSlot.Head)
	var scaled = log(amount) + 5

	fetishAffect(DOM_0, WsUtil.Fetish_Giving, scaled)
	fetishAffect(SUB_0, WsUtil.Fetish_Receiving, scaled)

	# Having a cock down your throat does not count as gagged in BDCC.
	# Many are wondering how science has progressed to this point.
	reactSub(WsUtil.Reaction_PeeInside_Gagged)

	endActivity()

func filterAnimation(animData: Array, stageId: String, allowedStates: Array) -> bool:
	if animData == null:
		return false
	if animData[0] != stageId:
		return false
	if animData[1] in allowedStates:
		return true
	return false