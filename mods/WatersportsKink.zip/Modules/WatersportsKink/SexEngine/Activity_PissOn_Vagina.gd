extends SexActivityBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

func _init():
	id = WsUtil.Activity_PissOn_Vagina

	activityName = "Piss On (Vagina)"
	activityDesc = "Piss on your partner."
	activityCategory = ["Humiliate"]

func getGoals():
	return {
		WsUtil.Goal_Pissplay: 1.0
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: true,
		SexType.SlutwallSex: true,
		SexType.BitchsuitSex: true,
	}

func canStartActivity(_sexEngine: SexEngine, domInfo: SexDomInfo, subInfo: SexSubInfo):
	var domChar: BaseCharacter = domInfo.getChar()
	if domChar.getID() == "pc":
		if !domChar.hasPerk(WsUtil.Perk_PissYourself):
			return false
	else:
		if !OPTIONS.isContentEnabled(ContentType.Watersports):
			return false
	
	if !domChar.hasVagina():
		return false
	if !PissWrapper.canPee(domChar):
		return false
	
	return.canStartActivity(_sexEngine, domInfo, subInfo)

func getCheckTagsDom():
	return [SexActivityTag.PenisInside, SexActivityTag.VaginaUsed]

func getActivityBaseScore(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	return _domInfo.personalityScore({PersonalityStat.Subby: - 0.05}) + _subInfo.getResistScoreSmooth() * 0.05

func getTags(indx):
	if indx == DOM_0:
		return [SexActivityTag.PenisUsed, SexActivityTag.VaginaUsed]
	return []

func init_processTurn():
	var prepText = [
		# These are safe if you have no genitals.
		"{dom.You} {dom.youVerb('thrust')} {dom.your} hips forward, aiming at {sub.nameS} body.",
		"{dom.You} {dom.youVerb('widen')} {dom.your} legs and {dom.youVerb('inch', 'inches')} forward to aim at {sub.name}, preparing to coat {sub.him} in {dom.your} " + piss() + ".",
		"{dom.You} {dom.youVerb('prepare')} to piss on {sub.name} and {dom.youVerb('widen')} {dom.your} legs slightly."
	]

	# prepText.push_back(
	# 	"{dom.You} {dom.youVerb('move')} {dom.your} hands to {dom.your} {dom.penis} and {dom.youVerb('grab')} it, thrusting {dom.your} hips forward to aim at {sub.nameS} body."
	# )
	# prepText.push_back(
	# 	"{dom.You} grab {dom.your} {dom.penis} and {dom.youVerb('aim')} it at {sub.name}, preparing to coat {sub.him} in {dom.your} " + piss() + "."
	# )
	# prepText.push_back(
	# 	"{dom.You} {dom.youVerb('thrust')} {dom.your} {dom.penis} forward and {dom.youVerb('aim')} it at {sub.name}."
	# )

	prepText.push_back(
		"{dom.You} {dom.youVerb('move')} {dom.your} hands to {dom.your} {dom.vaginaStretch} {vagina} and {dom.youVerb('spread')} the lips, thrusting {dom.your} hips forward to aim at {sub.nameS} body."
	)
	prepText.push_back(
		"{dom.You} {dom.youVerb('widen')} {dom.your} legs and {dom.youVerb('inch', 'inches')} forward to {dom.youVerb('aim')} {dom.your} {dom.vaginaStretch} {vagina} at {sub.name}, preparing to coat {sub.him} in {dom.your} " + piss() + "."
	)
	prepText.push_back(
		"{dom.You} {dom.youVerb('spread')} the folds of {dom.your} {dom.vaginaStretch} {vagina} and thrust {dom.your} hips forward, aiming at {sub.name}."
	)

	addText(RNG.pick(prepText))
	setState("react")

func react_processTurn():
	var dom: BaseCharacter = getDomOrSubInfo(DOM_0).getChar()
	var sub_info: SexSubInfo = getDomOrSubInfo(SUB_0)
	var sub: BaseCharacter = sub_info.getChar()
	
	addText(RNG.pick([
		"{dom.You} {dom.youVerb('relax', 'relaxes')} and {dom.youVerb('begin')} to " + pissVerb() + ".",
		"After relaxing for a moment, {dom.you} {dom.youVerb('begin')} to " + pissVerb() + ".",
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and after letting the urge overtake {dom.you}, begin to " + pissVerb() + " on {sub.him}.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} pelvis and after just a moment, " + piss() + " begins flowing out over {sub.him}.",
		"Shuffling {dom.your} {dom.feet} a bit to get more comfortable, {dom.you} {dom.youVerb('relax', 'relaxes')} and {dom.youVerb('let')} the urge overtake {dom.you}.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} and {dom.youVerb('let')} out a sigh before allowing nature to take its course."
	]))
	addText(RNG.pick([
		"Soon, {sub.name} is soaked in {dom.your} " + piss() + ".",
		piss(true) + " splashes over {sub.nameS} body, leaving a gross smell and a yellow liquid staining {sub.him}.",
		"{sub.name} is soon soaked in {dom.your} " + piss() + " and has a yellow sheen.",
		"After giving a quick shake to get any lingering drops off, {dom.you} {dom.youVerb('stare')} at {dom.your} handiwork.",
		"A gross scent comes off of {sub.name} now.",
		"{sub.name} is stained yellow with " + piss() + " now."
	]))

	var amount = PissWrapper.peeOntoCharacter(dom, sub)
	var scaled = log(amount) + 5
	fetishAffect(DOM_0, WsUtil.Fetish_Giving, scaled)
	fetishAffect(SUB_0, WsUtil.Fetish_Receiving, scaled)
	
	reactSub(WsUtil.Reaction_PissedOn)

	if dom.hasPerk(WsUtil.Perk_Alpha):
		if sub.isSlaveToPlayer():
			# Today's nightmare fact: `slave` is a keyword in GDScript
			var slavery: NpcSlave = sub.getNpcSlavery()
			var kinkScore = sub.getFetishHolder().getFetishValue(WsUtil.Fetish_Receiving)
			if kinkScore > FetishInterest.SlightlyLikes:
				slavery.addObedience(0.2)
				slavery.addAwareness(0.2)
				slavery.addBrokenSpirit(-0.2)
				slavery.addDespair(RNG.randf_range(-0.3, -0.1))
			else:
				slavery.addObedience(0.4)
				slavery.addBrokenSpirit(0.4)
				slavery.addAwareness(0.2)
				slavery.addDespair(RNG.randf_range(0.1, 0.3))
			
			if slavery.isReadyToBeLeveledUp():
				var task: NpcBreakTaskBase = RNG.pick(slavery.levelupTasks)
				if task != null:
					task.completeSelf()
		elif sub.hasEnslaveQuest():
			var quest: NpcEnslavementQuest = sub.getEnslaveQuest()
			var task: NpcBreakTaskBase = RNG.pick(quest.tasks)
			if task != null:
				task.completeSelf()
		
		sub.addEffect(WsUtil.StatusEffect_PissBeta, [999, 0])

	endActivity()

func piss(capitalize: bool = false) -> String:
	if capitalize:
		return RNG.pick(["Piss", "Pee"])
	else:
		return RNG.pick(["piss", "pee"])

func pissVerb() -> String:
	return RNG.pick(["pee", "piss"])