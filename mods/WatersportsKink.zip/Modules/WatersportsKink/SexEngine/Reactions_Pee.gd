extends SexReactionHandler
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	handles = {
		WsUtil.Reaction_PeeInside: {REACT_CHANCE: 100},
		WsUtil.Reaction_PissedOn: {REACT_CHANCE: 100},
		WsUtil.Reaction_PeeInside_Gagged: {REACT_CHANCE: 100},
	}

func getLines(reaction: int, role: int, _args: Array):
	match reaction:
		WsUtil.Reaction_PeeInside:
			if role == ROLE_MAIN:
				if !isResisting():
					if hatesFetish(WsUtil.Fetish_Receiving):
						addLines([
							"What the fuck? Did you just pee!?",
							"That's fucking disgusting.",
							"What the actual fuck is wrong with you?",
							"This is so violating... I can't believe you did that.",
							"Ew. It's all inside me.",
							"What the hell was that? Don't do that ever again.",
							"I can feel how warm it is... Ew.",
						])
					elif lovesFetish(WsUtil.Fetish_Receiving):
						addLines([
							"Mmmmm... I can feel it inside me.",
							"Did you just pee? That's hot.",
							"I hope I can keep it inside...",
							"Thank you for the gift...",
							"It's like I'm being marked.",
							"Heh. It's so gross... I love it."
						])
					else:
						addLines([
							"...Did you just pee in me?",
							"That feels [i]weird[/i].",
							"You're lucky I was going to need a shower anyway.",
							"It's so warm...",
							"At least ask next time.",
							"This prison sucks.",
							"At least it's just inside, I guess...",
						])
				else:
					addLines([
						"Ew. Thanks for that, asshole.",
						"There isn't a long enough shower to help me forget this.",
						"Inside? Are you for real? You fucker.",
						"How dare you? I'll make you regret that.",
						"How would you like it if someone " + RNG.pick(["peed", "pissed"]) + " inside of you, jackass?",
						"Oh my god it's so warm. What the fuck did you do?",
						"I'll get you for this.",
						"As if I wasn't humiliated enough in this damn prison."
					])
		WsUtil.Reaction_PissedOn:
			if role == ROLE_MAIN:
				# if RNG.chance(1):
				#	 addLines([
				#		 "This golden shower dedicated to the brave cetaceans fighters in the Mediterranean."
				#	 ])
				if !isResisting():
					if hatesFetish(WsUtil.Fetish_Receiving):
						addLines([
							"Fuck. That's so gross. Why?",
							"That's disgusting.",
							"Ew. Why does it smell so strong?",
							"I cannot believe you just did that. It's so gross.",
							"A shower won't be enough. I'm going to smell this for hours.",
							"You're an asshole, you know that?",
							"This is so humiliating...",
							"I smell like a toilet now... Fuck."
						])
					elif lovesFetish(WsUtil.Fetish_Receiving):
						addLines([
							"Yes... Mark me.",
							"It's so warm. Thank you.",
							"Thanks for the gift.",
							"It smells so bad... I love it.",
							"Thank you!",
							"Next time do it inside, please.",
							"Well, I don't need a shower anymore~",
						])
					else:
						addLines([
							"Oh. That's... nice. For you.",
							"Ew. It smells like the bathroom in here.",
							"...You could have asked.",
							"I need a shower. No, not like that.",
							"Fuck, that smells strong.",
							"You've been in here for how long and you're just pissing on people now?",
							"I need a shower before this cools down."
						])
				else:
					addLines([
						"You motherfucker.",
						"I'm not your gods damned toilet.",
						"Are you a fucking dog?",
						"As if this prison wasn't bad enough without people like you in it.",
						"You fucker. There's not a long enough shower in this prison to make me forget this.",
						"Ew. I'm not your toilet, bitch.",
						"How would you like it if someone " + RNG.pick(["peed", "pissed"]) + " on you, jackass?",
					])

		WsUtil.Reaction_PeeInside_Gagged:
			if role == ROLE_MAIN:
				if !isResisting():
					if hatesFetish(WsUtil.Fetish_Receiving):
						addLines([
							"Mmhah t’ fuhh? Dih y’ jushh ppee!?",
							"Tha’sh fuhhkin’ dishgushh’n.",
							"Mmhah t’achooal fuhh ish rrhong wih yuu?",
							"Thishh ish sho v’owlayin’… I c’n b’weeve yuu dih tha’.",
							"Ew… i’sh awl inshhide mmeh.",
							"Mmhah t’hell wushh tha’? Dohn do tha’ ehv’r again.",
							"I c’n ffeew how wahm i’ ish… mmew.",
						])
					elif lovesFetish(WsUtil.Fetish_Receiving):
						addLines([
							"Mmmmmm… I c’n ffeew i’ inshhide mmeh.",
							"Dih yuu jushh ppee? Tha’sh hhahh’.",
							"I hhope I c’n keep i’ inshhide…",
							"Thah’ yuu f’r th’ gifh…",
							"I’sh wike I’m bein’ mahhk’d.",
							"Hehh… i’sh sho ggwosh… I wuv i’.",
						])
					else:
						addLines([
							"…Mmdih yuu jushh ppee in mmeh?",
							"Tha’ ffeews [i]w’ehhd[/i].",
							"Yuu’ wuhhky I wush goin’ t’ need a show’r anywhey.",
							"I’sh sho wahm…",
							"Ah’ weashh ahshh nex’ time.",
							"Thishh prish’n shucksh.",
							"Ah’ weashh i’sh jushh inshhide, I gueshh…",
						])
				else:
					addLines([
						"Ew… thahnksh f’r tha’, ahhsho’e.",
						"Ther’ ish’n ah wong ’nuff show’r t’ help meh f’rgeh’ thish.",
						"Inshhide? Ah yuu f’r rreal? Yuu fuhhk’r.",
						"How daehh yuu? Ah’ll make yuu r’gret tha’.",
						"How wud yuu wike i’ iff shomeone " + RNG.pick(["pishh’d", "ppeed"]) + " inshhide uh yuu, j’kahsh?",
						"Oh m’ gahd i’sh sho wahm… wha t’ fuhh dih yuu do?",
						"Ah’ll geh’ yuu f’r thish.",
						"Ahsh iff I wuhn’ h’yumihlayt’d ’nuff in thish dahm prish’n.",
					])