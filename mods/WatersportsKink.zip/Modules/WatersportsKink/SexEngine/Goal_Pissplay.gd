extends SexGoalBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

func _init():
	id = WsUtil.Goal_Pissplay

func getVisibleName():
	return "Do Pissplay"

func doFastSex(_sexEngine, domInfo, subInfo, _data):
	PissWrapper.peeOntoCharacter(domInfo.getChar(), subInfo.getChar())

func isPossible(_sexEngine, _domInfo, _subInfo, _data):
	return PissWrapper.canPee(_domInfo.getChar())

func getSubGoals(_sexEngine, _domInfo, _subInfo, _data):
	return {
	}

func getGoalDefaultWeight():
	return 0.1

# TODO: Make begging work
func canBegFor():
	return false
