extends SexActivityBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

var penetrationTag: int = SexActivityTag.VaginaPenetrated
var bodypartSlot: String = BodypartSlot.Vagina

func _init():
	id = WsUtil.Activity_PeeInVagina
	
	activityName = "Pee Inside"
	activityDesc = "Pee inside your partner. They probably won't mind!"
	activityCategory = ["Humiliate"]

func allowedToUse(sexEngine: SexEngine, domInfo: SexDomInfo, subInfo: SexSubInfo):
	var isDomInside = sexEngine.hasTag(domInfo.getCharID(), SexActivityTag.PenisInside)
	var isSubPenetrated = sexEngine.hasTag(subInfo.getCharID(), penetrationTag)

	return isDomInside && isSubPenetrated

func abortLine() -> String:
	return "{dom.You} {dom.youVerb('aren', 'isn')}'t inside {sub.name}'s {vagina} anymore and {dom.youVerb('decide')} to hold {dom.yourHis} {pick('pee', 'piss')}."

func getGoals():
	return {
		WsUtil.Goal_Pissplay: 1.0
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: true,
		SexType.SlutwallSex: true,
		SexType.BitchsuitSex: true,
	}

# For those who come after (more than likely just me):
# Tags are used to ensure that activities don't overlap.
# i.e. two activities that use the same tag cannot be used together
# the `getTags` method returns the tags that a particular activity gives
# the SexEngine. The `getCheckTagsSub` and `getCheckTagsDom` methods
# return tags that are illegal for this activity.
# There is no way to whitelist an activity to ONLY occur with specific tags
# outside of overriding `canStartActivity`

# the current state of the SexActivity is processed every turn with
# `STATE_processTurn` where `STATE` is the current value of `state`.
# e.g. `rimming_processTurn` for `rimming`.

func canStartActivity(sexEngine: SexEngine, domInfo: SexDomInfo, subInfo: SexSubInfo):
	if domInfo.getCharID() == "pc":
		if !domInfo.getChar().hasPerk(WsUtil.Perk_PissYourself):
			return false
	else:
		if !OPTIONS.isContentEnabled(ContentType.Watersports):
			return false
	if !PissWrapper.canPee(domInfo.getChar()):
		return false
	
	if !allowedToUse(sexEngine, domInfo, subInfo):
		return false
	
	if hasActivity(sexEngine, id, domInfo, subInfo):
		return false

	return true

func getActivityBaseScore(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	return _domInfo.personalityScore({PersonalityStat.Subby: - 0.05}) + _subInfo.getResistScoreSmooth() * 0.05

func getTags(_indx: int) -> Array:
	if _indx == DOM_0:
		return [SexActivityTag.PenisUsed]
	return []

func startActivity(_args):
	addText(RNG.pick([
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and relax, preparing to piss inside {sub.name}.",
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and relax, preparing to pee inside {sub.name}.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} bladder, preparing to piss inside {sub.name}.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} bladder, preparing to pee inside {sub.name}.",
		"{dom.You} {dom.youVerb('pause')} for a moment and {dom.youVerb('relax', 'relaxes')} some muscles in {dom.your} crotch, trying to let the urge to pee come.",
		"{dom.You} {dom.youVerb('pause')} for a moment and {dom.youVerb('relax', 'relaxes')} some muscles in {dom.your} crotch, trying to let the urge to piss come.",
	]))

func init_processTurn():
	setState("react")

func react_processTurn():
	var domInfo: SexDomInfo = getDomOrSubInfo(DOM_0)
	var subInfo: SexSubInfo = getDomOrSubInfo(SUB_0)

	if !allowedToUse(getSexEngine(), domInfo, subInfo):
		addText(abortLine())
		endActivity()
		return

	addText(RNG.pick([
		"{dom.You} sigh softly and grip {sub.name} as you begin emptying your bladder.",
		"{dom.You} say nothing but thrust a few times into {sub.name} as you let your bladder empty.",
		"{dom.You} grab {sub.name} and hilt {dom.yourself} in {sub.him} as {dom.you} let {dom.yourself} pee inside {sub.him}.",
		"{dom.You} grab {sub.name} and hilt {dom.yourself} in {sub.him} as {dom.you} let {dom.yourself} piss inside {sub.him}.",
		"{dom.You} {dom.youVerb('groan')} softly as {dom.you} {dom.youVerb('empty', 'empties')} {dom.your} bladder inside {sub.name}.",
		"{dom.You} {dom.youVerb('groan')} as {dom.you} {dom.youVerb('empty', 'empties')} {dom.your} bladder inside {sub.name}."
	]))

	var amount = PissWrapper.peeIntoCharacter(domInfo.getChar(), subInfo.getChar(), bodypartSlot)
	var scaled = log(amount) + 5

	fetishAffect(DOM_0, WsUtil.Fetish_Giving, scaled)
	fetishAffect(SUB_0, WsUtil.Fetish_Receiving, scaled)

	reactSub(WsUtil.Reaction_PeeInside)

	endActivity()