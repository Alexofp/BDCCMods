extends "res://Modules/WatersportsKink/SexEngine/Activity_PeeInsideVagina.gd"

func _init():
	id = WsUtil.Activity_PeeInAnus
	
	penetrationTag = SexActivityTag.AnusPenetrated
	bodypartSlot = BodypartSlot.Anus

func abortLine() -> String:
	return "{dom.You} {dom.youVerb('aren', 'isn')}'t inside {sub.name}'s {asshole} anymore and {dom.youVerb('decide')} to hold {dom.yourHis} {pick('pee', 'piss')}."