extends SexActivityBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

# In 0.1.12, there is no way to tell if you're mid-tribbing. We check animations.
# This is gross though and should be replaced with the tagging system when
# we have the chance.
const ANIM_DATA = [
	[StageScene.SexTribadism, ["tease", "sex", "fast"]],
]

func _init():
	id = WsUtil.Activity_PissOn_Oral
	
	activityName = "Pee On"
	activityDesc = "Pee on your partner. They probably won't mind!"
	activityCategory = ["Humiliate"]

func allowedToUse(sexEngine: SexEngine):
	var currentAnimation = sexEngine.getBestAnimation()
	for animData in ANIM_DATA:
		var stage = animData[0]
		var states = animData[1]
		if filterAnimation(currentAnimation, stage, states):
			return true
	
	return false

func getGoals():
	return {
		WsUtil.Goal_Pissplay: 1.0
	}

func getSupportedSexTypes():
	return {
		SexType.DefaultSex: true,
		SexType.StocksSex: true,
		SexType.SlutwallSex: true,
		SexType.BitchsuitSex: true,
	}

func canStartActivity(sexEngine: SexEngine, domInfo: SexDomInfo, subInfo: SexSubInfo):
	if domInfo.getCharID() == "pc":
		if !domInfo.getChar().hasPerk(WsUtil.Perk_PissYourself):
			return false
	else:
		if !OPTIONS.isContentEnabled(ContentType.Watersports):
			return false
	if !PissWrapper.canPee(domInfo.getChar()):
		return false
	
	if !allowedToUse(sexEngine):
		return false
	
	if hasActivity(sexEngine, id, domInfo, subInfo):
		return false

	return true

func getActivityBaseScore(_sexEngine: SexEngine, _domInfo: SexDomInfo, _subInfo: SexSubInfo):
	return _domInfo.personalityScore({PersonalityStat.Subby: - 0.05}) + _subInfo.getResistScoreSmooth() * 0.05

func getTags(_indx: int) -> Array:
	if _indx == DOM_0:
		return [SexActivityTag.VaginaUsed]
	return []

func startActivity(_args):
	addText(RNG.pick([
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and relax, preparing to piss on {sub.name}'s {pussy}.",
		"{dom.You} {dom.youVerb('close')} {dom.your} eyes and relax, preparing to pee on {sub.name}'s {pussy}.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} bladder, preparing to piss on {sub.name}'s {pussy}.",
		"{dom.You} {dom.youVerb('relax', 'relaxes')} {dom.your} bladder, preparing to pee on {sub.name}'s {pussy}.",
		"{dom.You} {dom.youVerb('pause')} for a moment and {dom.youVerb('relax', 'relaxes')} some muscles in {dom.your} crotch, trying to let the urge to pee come.",
		"{dom.You} {dom.youVerb('pause')} for a moment and {dom.youVerb('relax', 'relaxes')} some muscles in {dom.your} crotch, trying to let the urge to piss come.",
	]))

func init_processTurn():
	setState("react")

func react_processTurn():
	var dom: BaseCharacter = getDomOrSubInfo(DOM_0).getChar()
	var sub: BaseCharacter = getDomOrSubInfo(SUB_0).getChar()

	if !allowedToUse(getSexEngine()):
		addText("{dom.You} {dom.youVerb('aren', 'isn')}'t close enough to {sub.name}'s {pussy} anymore and {dom.youVerb('decide')} to hold {dom.yourHis} {pick('pee', 'piss')}.")
		endActivity()
		return

	addText(RNG.pick([
		"{dom.You} {dom.youVerb('exhale')} softly and {dom.youVerb('grip')} {sub.name} as {dom.you} begin emptying {dom.yourHis} bladder over {sub.yourHis} {pussy}.",
		"{dom.You} {dom.youVerb('say')} nothing but {dom.youVerb('groan')} deeply as {dom.you} let your bladder empty onto {sub.name}'s {pussy}.",
		"{dom.You} {dom.youVerb('grab')} {sub.name} and pull {sub.him} close as {dom.you} let {dom.yourself} {pick('piss', 'pee')}. It gets all over {sub.his} {pussy}.",
		"{dom.You} {dom.youVerb('groan')} as {dom.you} {dom.youVerb('empty', 'empties')} {dom.your} bladder over {sub.name}'s {pussy}.",
	]))

	var amount = PissWrapper.peeIntoCharacter(dom, sub, BodypartSlot.Vagina, 0.05)
	amount += PissWrapper.peeOntoCharacter(dom, sub)
	var scaled = log(amount) + 5

	fetishAffect(DOM_0, WsUtil.Fetish_Giving, scaled)
	fetishAffect(SUB_0, WsUtil.Fetish_Receiving, scaled)

	reactSub(WsUtil.Reaction_PissedOn)

	if dom.hasPerk(WsUtil.Perk_Alpha):
		if sub.isSlaveToPlayer():
			var slavery: NpcSlave = sub.getNpcSlavery()
			var kinkScore = sub.getFetishHolder().getFetishValue(WsUtil.Fetish_Receiving)
			if kinkScore > FetishInterest.SlightlyLikes:
				slavery.addObedience(0.2)
				slavery.addAwareness(0.2)
				slavery.addBrokenSpirit(-0.2)
				slavery.addDespair(RNG.randf_range(-0.3, -0.1))
			else:
				slavery.addObedience(0.4)
				slavery.addBrokenSpirit(0.4)
				slavery.addAwareness(0.2)
				slavery.addDespair(RNG.randf_range(0.1, 0.3))
			
			if slavery.isReadyToBeLeveledUp():
				var task: NpcBreakTaskBase = RNG.pick(slavery.levelupTasks)
				if task != null:
					task.completeSelf()
		elif sub.hasEnslaveQuest():
			var quest: NpcEnslavementQuest = sub.getEnslaveQuest()
			var task: NpcBreakTaskBase = RNG.pick(quest.tasks)
			if task != null:
				task.completeSelf()
		
		sub.addEffect(WsUtil.StatusEffect_PissBeta, [999, 0])

	endActivity()

func filterAnimation(animData: Array, stageId: String, allowedStates: Array) -> bool:
	if animData == null:
		return false
	if animData[0] != stageId:
		return false
	if animData[1] in allowedStates:
		return true
	return false