extends FetishBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Fetish_Giving
	dynamicChangesPersonalityAffectors = {
		PersonalityStat.Subby: - 0.2,
		PersonalityStat.Naive: - 0.3,
		PersonalityStat.Coward: - 0.2,
	}

func getVisibleName():
	return "Watersports (Giving)"

func getGoals(_sexEngine, _domFetishHolder, _dom, _sub):
	var possible = [WsUtil.Goal_Pissplay]
	
	return possible

func getDynamicChangeThreshold() -> float:
	return 1.0
	
func getDynamicChangeThresholdMax() -> float:
	return 5.0