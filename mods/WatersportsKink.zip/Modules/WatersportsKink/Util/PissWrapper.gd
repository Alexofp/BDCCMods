extends Object

static func getBladderContents(character: BaseCharacter) -> float:
	return character.getFluidAmount(FluidSource.Pissing)

static func peeOntoCharacter(source: BaseCharacter, target: BaseCharacter, percentageOfBladder: float = 1.0) -> float:
	target.pissedOnBy(source.getID(), percentageOfBladder)

	var amount = drain(source, percentageOfBladder)

	# TODO: Play animation of pissing
	return amount

static func peeIntoCharacter(source: BaseCharacter, target: BaseCharacter, slot: String, percentageOfBladder: float = 1.0) -> float:
	var amount = target.cummedInBodypartBy(slot, source.getID(), FluidSource.Pissing, percentageOfBladder)

	# TODO: Play animation of pissing
	return amount

static func peeIntoItem(who: BaseCharacter, item: ItemBase, percentageOfBladder = 1.0) -> float:
	return who.cumInItem(item, FluidSource.Pissing, percentageOfBladder)

static func canPee(character: BaseCharacter) -> bool:
	return getBladderContents(character) > 100.0

static func addPee(character: BaseCharacter, amount: float):
	var fluid: Fluids = character.peeProduction.getFluids()
	fluid.addFluid("Piss", amount)

static func fillBladder(character: BaseCharacter):
	character.peeProduction.fillPercent(1)

static func drain(character: BaseCharacter, percentage: float = 1.0) -> float:
	return character.peeProduction.drain(percentage)