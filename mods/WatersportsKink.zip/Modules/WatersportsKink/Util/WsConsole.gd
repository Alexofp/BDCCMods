extends Object

func _init():
	print("[WS Kink] Registering console commands")
	Console.addCommand("viewpisscontent", self, "viewPissContent", [], "View the amount of piss you have stored in ml")

func viewPissContent():
	Console.printLine("Piss is " + str(GM.pc.getFluidAmount(FluidSource.Pissing)) + "ml")