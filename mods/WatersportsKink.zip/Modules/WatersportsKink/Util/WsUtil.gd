extends Object

const ModuleId = "Frivolous_WatersportsKink"
const SkillId = "Frivolous_WatersportsKink_Skill"

# Used to force 'Piss Drinker' onto the player and hook sex events.
const Extender_Bootstrapper = "Frivolous_WatersportsKink_Bootstrapper"

# Hidden from user, used as a hack to force skill gain after swallowing piss.
const Perk_Hidden_PissDrinker = "Frivolous_WatersportsKink_HIDDEN_PissDrinker"

# A start perk that forces Urolagnia and Piss Yourself onto the character
const Perk_Starting_Urolagnia = "Frivolous_WatersportsKink_STARTING_Urolagnia"

# Tier 1

# Allows you to piss yourself in combat.
const Perk_PissYourself = "Frivolous_WatersportsKink_PissYourself"

# Makes you produce piss 25% faster
const Perk_WellHydrated = "Frivolous_WatersportsKink_WellHydrated"

# Allows you to pee freely in the yard + a few other places. Also allows you to pee into containers.
const Perk_FreeRoam = "Frivolous_WatersportsKink_FreeRoam"

# Forced upon you after level 4. Makes piss no longer gross you out.
const Perk_Urolagnia = "Frivolous_WatersportsKink_Urolagnia"

# Tier 2

# Drinking piss now provides benefits instead of consequences.
const Perk_Lemonade = "Frivolous_WatersportsKink_Lemonade"

# Allows you to piss inside people and gives stats bonus when it happens.
# Also gives you a stat bonus when someone pisses in you.
const Perk_PissEnema = "Frivolous_WatersportsKink_PissEnema"

# Your bladder can hold more piss and you produce it faster.
const Perk_Pissboy = "Frivolous_WatersportsKink_Pissboy"

# Gives you a chance to dodge attacks when covered in piss.
const Perk_SlipperyWhenWet = "Frivolous_WatersportsKink_SlipperyWhenWet"

# Tier 3

# Allows you to piss on someone during combat to break their will.
const Perk_Alpha = "Frivolous_WatersportsKink_Alpha"

# Whenever you swallow a liquid (no matter the source), it produces some pee.
const Perk_Ouroboros = "Frivolous_WatersportsKink_Ouroboros"

# You are granted a buff based on how much piss is on or inside you.
const Perk_Revelry = "Frivolous_WatersportsKink_Revelry"

# Grants an increase to the amount of piss you can hold and how fast you make it.
const Perk_LargeBladder = "Frivolous_WatersportsKink_LargeBladder"

const Attack_PissYourself = "Frivolous_WatersportsKink_AttackPissYourself"
const Attack_PissOn = "Frivolous_WatersportsKink_PissOn"

const Fetish_Receiving = "Frivolous_WatersportsKink_Receiving"
const Fetish_Giving = "Frivolous_WatersportsKink_Giving"
const Goal_Pissplay = "Frivolous_WatersportsKink_Pissplay"
const Activity_PeeInVagina = "Frivolous_WatersportsKink_PeeInsideVagina"
const Activity_PeeInAnus = "Frivolous_WatersportsKink_PeeInsideAnus"
const Activity_PeeInMouth = "Frivolous_WatersportsKink_PeeInsideMouth"
const Activity_PissOn_Penis = "Frivolous_WatersportsKink_PissOn_Penis"
const Activity_PissOn_Vagina = "Frivolous_WatersportsKink_PissOn_Vagina"
const Activity_PissOn_Oral = "Frivolous_WatersportsKink_PissOn_Oral"

const Reaction_PeeInside = 41553123 + 0
const Reaction_PissedOn = 41553123 + 1
const Reaction_PeeInside_Gagged = 41553123 + 2

const Buff_PissCapacityMult = "Frivolous_WatersportsKink_PissCapacityMult_Buff"
const Buff_PissProductionMult = "Frivolous_WatersportsKink_PissProductionMult_Buff"
const Attribute_PissCapacityMult = "Frivolous_WatersportsKink_PissCapacityMult_Attribute"
const Attribute_PissProductionMult = "Frivolous_WatersportsKink_PissProductionMult_Attribute"

const Character_Guard = "Frivolous_WatersportsKink_Guard"

const StatusEffect_PissBeta = "Frivolous_WatersportsKink_PissBeta"

const Event_PissInPublic = "Frivolous_WatersportsKink_PissInPublic"
const Event_Urinal = "Frivolous_WatersportsKink_Urinal"

const Scene_PeeInto = "Frivolous_WatersportsKink_PeeInto"

const Scene_MeatToilet_Willing = "Frivolous_WatersportsKink_MeatToilet_Willing"

const Scene_PeeInPublic_YourCell = "Frivolous_WatersportsKink_PeeInPublic_YourCell"
const Scene_PeeInPublic_Yard = "Frivolous_WatersportsKink_PeeInPublic_Yard"
const Scene_PeeInPublic_Greenhouse = "Frivolous_WatersportsKink_PeeInPublic_Greenhouse"

const XP_FROM_DRINKING_PISS = 25
const XP_FROM_PISSED_ON_BY_SOMEONE = 10
const XP_FROM_PISSING_ON_SOMEONE = 15
const XP_FROM_PISSED_INSIDE_BY_SOMEONE = 10
const XP_FROM_PISSING_INSIDE_SOMEONE = 15

# Makes `character` take the given `amount` of `type` damage. and return a string indicating how much damage they took.
# If `armorScale` is provided, then `character`'s armor is scaled by that amount.
static func pretendDamage(character: BaseCharacter, type: int, amount: int, armorScale: float = 1.0) -> String:
	var damageTaken = character.receiveDamage(type, amount, armorScale)
	
	return " [color={color}]({damage} {name})[/color]".format({
		"color": "#" + DamageType.getColor(type).to_html(false),
		"damage": damageTaken,
		"name": DamageType.getBattleName(type)
	})

static func giveSkillExperience(character: BaseCharacter, base: int, peeAmount: float, weight: float = 0.8):
	var scale = int(peeAmount / 100) * weight
	character.addSkillExperience(SkillId, Util.maxi(base, int(base * scale)))
	# print("[WS Kink] Awarding {0} XP to skill (base: {1}, weight: {2}, scale: {3})".format([Util.maxi(base, int(base * scale)), base, weight, scale]))