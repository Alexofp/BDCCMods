extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_SlipperyWhenWet
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Slippy When Wet"

func getVisibleDescription():
	return "You can a chance to dodge attacks when soaked in piss. Nobody wants to touch you.`"

func getMoreDescription():
	return "When you have piss on you, you gain a 10% chance to avoid attacks. If you have 500ml on you, this chance doubles to 20%."

func getSkillTier():
	return 1

func getCost():
	return 2

func getPicture():
	return "res://Modules/WatersportsKink/Icons/slip.png"

func getBuffs():
	var pissAmount = npc.getFluids().getFluidAmountByType().get("Piss", 0.0)
	if pissAmount >= 500.0:
		return [
			buff(Buff.DodgeChanceBuff, [20.0])
		]
	if pissAmount > 0.0:
		return [
			buff(Buff.DodgeChanceBuff, [10.0])
		]
	return []

func toggleable() -> bool:
	return false