extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_FreeRoam
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Free-Roam"

func getRequiredPerks():
	return []

func getVisibleDescription():
	return "Allows you to pee anywhere in the yard and a few spots elsewhere. Also, allows you to pee into containers from anywhere."

func getMoreDescription():
	return "Be warned that it pissing on the sidewalk will make you unpopular."

func getSkillTier():
	return 0

func getCost():
	return 1

func getPicture():
	return "res://Modules/WatersportsKink/Icons/DogPark.png"
