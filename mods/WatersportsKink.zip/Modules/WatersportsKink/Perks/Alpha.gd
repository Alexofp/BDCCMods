extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Alpha
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Alpha"

func getRequiredPerks():
	return [WsUtil.Perk_PissEnema]

func getVisibleDescription():
	return "You're the boss, and you know how to show it. Pissing on people during sex and combat now has benefits."

func getMoreDescription():
	return "During combat, pissing on someone will make them do less damage to you for a few turns. During sex, it will cause the person you piss on to stop resisting you if they are resisting."

func getSkillTier():
	return 2

func getCost():
	return 3

func getPicture():
	return "res://Modules/WatersportsKink/Icons/Wolf.png"