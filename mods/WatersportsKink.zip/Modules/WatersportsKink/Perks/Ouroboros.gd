extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")
const PissWrapper = preload("res://Modules/WatersportsKink/Util/PissWrapper.gd")

func _init():
	id = WsUtil.Perk_Ouroboros
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Ouroboros"

func getRequiredPerks():
	return [WsUtil.Perk_Lemonade]

func getVisibleDescription():
	return "Whenever you swallow liquid, you produce more piss."

func getMoreDescription():
	return "Your body converts 20% of all liquid you ingest into piss immediately. Your kidneys are tough like that."

func getSkillTier():
	return 2

func getCost():
	return 3

func getPicture():
	return "res://Modules/WatersportsKink/Icons/Ouroboros.png"

func onSexEvent(event: SexEvent):
	if event.getType() == SexEvent.SwallowFluid:
		if event.getTargetCharID() == npc.getID():
			PissWrapper.addPee(npc, event.getField("loadSize", 0.0) * 0.20)