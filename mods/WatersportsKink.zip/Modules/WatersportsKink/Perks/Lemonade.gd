extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Lemonade
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Lemonade"

func getVisibleDescription():
	return "Drinking piss now restores stamina and removes pain, but it turns you on a bit."

func getMoreDescription():
	return "Improvise, adapt, overcome."

func getSkillTier():
	return 1

func getCost():
	return 2

func getPicture():
	return "res://Modules/WatersportsKink/Icons/lemonade.png"
