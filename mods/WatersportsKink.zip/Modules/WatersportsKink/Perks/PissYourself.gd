extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_PissYourself
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Piss Yourself"

func getVisibleDescription():
	return "You can now piss in combat and sex."

func getMoreDescription():
	return "Pissing yourself in combat will stun your opponent. Pissing on your opponent or during sex has no effect beyond being fun."

func getSkillTier():
	return 0

func getCost():
	if GM.pc.hasPerk(WsUtil.Perk_Starting_Urolagnia):
		return 0
	else:
		return 1

func getPicture():
	return "res://Modules/WatersportsKink/Icons/Peeing.png"

func addsAttacks():
	return [WsUtil.Attack_PissYourself, WsUtil.Attack_PissOn]