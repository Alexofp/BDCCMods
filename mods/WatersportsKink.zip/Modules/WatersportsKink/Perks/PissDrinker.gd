extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Hidden_PissDrinker
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0

	# connectBodypartSignals()

	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Piss Drinker"

func getVisibleDescription():
	return "You shouldn't ever see this."

func getMoreDescription():
	return "Awards XP to this skill whenever you interact with piss in the sex system. You should not see this."

func getSkillTier():
	return 1

func hiddenWhenLocked() -> bool:
	return true
	
func hiddenWhenUnlocked() -> bool:
	return true

func getCost():
	return 0

func getPicture():
	return "res://Images/Perks/funnel.png"

func onSexEvent(event: SexEvent):
	var module = GlobalRegistry.getModule(WsUtil.ModuleId)
	var eventType: String = event.getType()
	if event.getTargetCharID() == npc.getID():
		if eventType == SexEvent.SwallowFluid:
			if event.getField("fluidID") == "Piss":
				module.emit_drank_piss(npc, event.getField("loadSize", 0.0))
		if eventType == SexEvent.ReceivedFluidsOnBody:
			if event.getField("fluidSource") == FluidSource.Pissing:
				module.emit_pissed_on(event.getSourceChar(), npc, event.getField("loadSize", 0.0))
		if eventType == SexEvent.PeedInside:
			module.emit_pissed_inside(event.getSourceChar(), npc, event.getField("hole", "ERROR"), event.getField("loadSize", 0.0))
	elif event.getSourceCharID() == npc.getID():
		if eventType == SexEvent.ReceivedFluidsOnBody:
			if event.getField("fluidSource") == FluidSource.Pissing:
				module.emit_pissed_on(npc, event.getTargetChar(), event.getField("loadSize", 0.0))
		if eventType == SexEvent.PeedInside:
			module.emit_pissed_inside(npc, event.getTargetChar(), event.getField("hole", "ERROR"), event.getField("loadSize", 0.0))