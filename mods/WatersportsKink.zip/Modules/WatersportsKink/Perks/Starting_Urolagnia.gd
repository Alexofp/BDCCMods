extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Starting_Urolagnia
	skillGroup = Skill.Start
	dungeonWeight = 0.0

func getVisibleName():
	return "Urolagnia"

func getVisibleDescription():
	return "You like piss. Sexually. You start with the ability to pee during combat and sex."

func hiddenWhenLocked() -> bool:
	return true

func toggleable() -> bool:
	return false
	
func unlockable() -> bool:
	return false

func getCost():
	return 0
	
func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/leak.png"
