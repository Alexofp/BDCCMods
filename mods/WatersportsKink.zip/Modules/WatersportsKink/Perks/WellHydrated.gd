extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_WellHydrated
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Well-Hydrated"

func getVisibleDescription():
	return "You produce piss 25% faster."

func getMoreDescription():
	return "Good hydration is important because it means you can piss more often."

func getSkillTier():
	return 0

func getCost():
	return 1

func getPicture():
	return "res://Modules/WatersportsKink/Icons/hydration.png"

func getBuffs():
	return [
		buff(WsUtil.Buff_PissProductionMult, [25]),
	]

func toggleable() -> bool:
	return false