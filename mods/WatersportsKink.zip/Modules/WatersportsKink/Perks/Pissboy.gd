extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Pissboy
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	var who: BaseCharacter = npc if npc != null else GM.pc
	if who == null || !is_instance_valid(who):
		return "Pissboy"
	var gender = who.getPronounGender()
	if gender == Gender.Male:
		return "Pissboy"
	elif gender == Gender.Female:
		return "Pissgirl"
	elif gender == Gender.Androgynous:
		return "Pissby"
	elif gender == Gender.Other:
		return "Piss Slut"

func getRequiredPerks():
	return [WsUtil.Perk_WellHydrated]

func getVisibleDescription():
	return "Your bladder can hold more and you produce more piss."

func getMoreDescription():
	return "Your bladder can now hold 100% more and you produce piss 20% faster. This is probably healthy."

func getSkillTier():
	return 1

func getCost():
	return 2

func getPicture():
	return "res://Modules/WatersportsKink/Icons/Running.png"

func getBuffs():
	return [
		buff(WsUtil.Buff_PissCapacityMult, [100.0]),
		buff(WsUtil.Buff_PissProductionMult, [20.0]),
	]

func toggleable() -> bool:
	return false