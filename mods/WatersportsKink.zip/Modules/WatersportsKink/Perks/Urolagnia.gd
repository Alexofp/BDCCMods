extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Urolagnia
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Urolagnia"

func getVisibleDescription():
	return "You like piss. Sexually."

func getMoreDescription():
	return "Urine doesn't gross you out and you gain lust whenever someone pisses on or in you."

func getSkillTier():
	return 0

func hiddenWhenLocked():
	return true

func toggleable() -> bool:
	return false

func unlockable() -> bool:
	return false

func getCost():
	return 0

func getPicture():
	# TODO real icon
	return "res://Images/Perks/leak.png"
