extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_LargeBladder
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Large Bladder"

func getRequiredPerks():
	return [WsUtil.Perk_Pissboy, WsUtil.Perk_WellHydrated]

func getVisibleDescription():
	return "Your bladder can fit more piss in it and you produce it faster."

func getMoreDescription():
	return "You can hold 100% more piss and produce it 50% faster."

func getSkillTier():
	return 2

func getCost():
	return 3

func getPicture():
	return "res://Images/StatusEffects/bladder.png"

func getBuffs():
	return [
		buff(WsUtil.Buff_PissCapacityMult, [100.0]),
		buff(WsUtil.Buff_PissProductionMult, [50.0]),
	]

func toggleable() -> bool:
	return false