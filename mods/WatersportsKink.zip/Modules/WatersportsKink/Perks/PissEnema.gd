extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_PissEnema
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Piss Enema"

func getVisibleDescription():
	return "Pissing inside or on someone during sex now grants benefits."

func getMoreDescription():
	return "Doing so removes some pain and restores a small amount of stamina. You also gain these benefits when someone pisses inside of you."

func getSkillTier():
	return 1

func getCost():
	return 2

func getPicture():
	return "res://Modules/WatersportsKink/Icons/Enema.png"

func onSexEvent(event: SexEvent):
	if event.getType() != SexEvent.PeedInside:
		return
	var hole = event.getField("hole", "ERROR")
	if hole != BodypartSlot.Vagina && hole != BodypartSlot.Anus && hole != BodypartSlot.Head:
		return

	var shouldDisplayMessage = false
	if npc.isPlayer():
		var currentScene: SceneBase = GM.main.getCurrentScene()
		match currentScene.sceneID:
			"WorldScene":
				shouldDisplayMessage = true
			"GenericSexScene":
				shouldDisplayMessage = true
	
	var scaledAmount = log(event.getField("loadSize", 0.0)) / log(100)

	if event.getTargetCharID() == npc.getID():
		var npc = event.getTargetChar()
		npc.addPain(-int(clamp(scaledAmount * 20, 20, npc.painThreshold())))
		npc.addStamina(int(clamp(scaledAmount * 10, 10, npc.getMaxStamina())))
		if shouldDisplayMessage:
				GM.main.addMessage("Being peed inside of makes you feel better!")
		return
	
	if event.getSourceCharID() == npc.getID():
		npc.addPain(-int(clamp(scaledAmount * 20, 20, npc.painThreshold())))
		npc.addStamina(int(clamp(scaledAmount * 10, 10, npc.getMaxStamina())))
		if shouldDisplayMessage:
			GM.main.addMessage("Peeing inside someone makes you feel better!")
		return