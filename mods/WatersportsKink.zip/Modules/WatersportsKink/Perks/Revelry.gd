extends PerkBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Perk_Revelry
	skillGroup = WsUtil.SkillId
	dungeonWeight = 0.0
	# print("[WS Kink] Initialized perk " + id)

func getVisibleName():
	return "Revelry"

func getRequiredPerks():
	return [WsUtil.Perk_SlipperyWhenWet]

func getVisibleDescription():
	return "You now gain benefits based on how much piss is on or inside you."

func getMoreDescription():
	return "You gain armor and a resistance to lust damage when soaked in piss."

func getSkillTier():
	return 2

func getCost():
	return 3

func getPicture():
	return "res://Modules/WatersportsKink/Icons/drunk.png"

func getBuffs():
	var armor = 0.0
	var lustResist = 0.0

	var totalPiss = 0.0

	for slot in [BodypartSlot.Head, BodypartSlot.Anus, BodypartSlot.Vagina]:
		var part = npc.getBodypart(slot)
		if part != null:
			var fluids: Fluids = part.getFluids()
			if fluids != null:
				totalPiss += fluids.getFluidAmountByType().get("Piss", 0.0)

	armor = clamp(12 * log(totalPiss) - 50, 0, 50)
	lustResist = clamp(8.5 * log(totalPiss) - 25, 0, 50)

	return [
		buff(Buff.PhysicalArmorBuff, [int(armor)]),
		buff(Buff.LustArmorBuff, [int(lustResist)])
	]

func toggleable() -> bool:
	return false