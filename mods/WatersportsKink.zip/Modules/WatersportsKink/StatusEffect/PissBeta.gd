extends StatusEffectBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

var damageReduction: int

func _init():
	id = WsUtil.StatusEffect_PissBeta
	isBattleOnly = true

func initArgs(args = []):
	if args.size() > 0:
		turns = args[0]
	else:
		turns = 1
	if args.size() > 1:
		damageReduction = args[1]
	else:
		damageReduction = 15
	
func processBattleTurn():
	turns -= 1
	if turns <= 0:
		stop()

func getEffectName():
	return "Piss Beta"

func getEffectDesc():
	if damageReduction > 0:
		return "You were pissed on by an alpha and are doing less damage. " + str(turns) + " more turns."
	else:
		return "You were pissed on by an alpha! You feel like you want to obey them now..."

func getEffectImage():
	return "res://Modules/WatersportsKink/Icons/beta.png"

func getIconColor():
	return IconColorYellow

func getBuffs():
	if damageReduction > 0:
		return [
			buff(Buff.LustDamageBuff, [-damageReduction]),
			buff(Buff.PhysicalDamageBuff, [-damageReduction]),
			buff(Buff.ForcedObedienceBuff, [25.0])
		]
	else:
		return [
			buff(Buff.ForcedObedienceBuff, [25.0])
		]