extends Character
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Character_Guard
	npcCharacterType = CharacterType.Guard
	npcBaseLust = 120
	npcBasePain = 130

	pickedSkin = "FerriSkin"
	pickedSkinRColor = Color("ff5b2e87")
	pickedSkinGColor = Color("ff8a28ec")
	pickedSkinBColor = Color("ff3f324d")
	npcSkinData = {
		"hair": {"r": Color("ffb1784a"), "g": Color("ff8b5b33"), "b": Color("ff40210c"), },
		"penis": {"g": Color("ff991c40"), "b": Color("ff6b142d"), },
	}

	npcHasMenstrualCycle = true

func _getName():
	return "Male guard"

func getGender():
	return Gender.Male

func getSmallDescription():
	return "A canine guard who seems to not take his job very seriously."

func _getAttacks():
	return ["HeatGrenade", "DoubleCuffPC", "CuffPCHands", "ForceGagPC", "ForceMuzzlePC", "stunbatonAttack", "stunbatonOverchargeAttack", "biteattack", "shoveattack", "trygetupattack"]

func getSpecies():
	return ["canine"]

func getFightIntro(_battleName):
	return "The guard prepares to fight."

func getLootTable(_battleName):
	return GuardLoot.new()

func getThickness() -> int:
	return 50

func getFemininity() -> int:
	return 0

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthroarms"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("canineears"))
	# TODO: Bald?
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("caninehead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("digilegs"))
	var penis = GlobalRegistry.createBodypart("caninepenis")
	penis.lengthCM = 15
	penis.ballsScale = 1
	giveBodypartUnlessSame(penis)
	var tail = GlobalRegistry.createBodypart("caninetail")
	tail.tailScale = 1
	giveBodypartUnlessSame(tail)


func getDefaultEquipment():
	return ["GuardArmor"]