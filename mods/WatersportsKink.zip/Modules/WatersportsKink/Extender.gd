extends GameExtender
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.Extender_Bootstrapper

func register(GES: GameExtenderSystem):
	GES.register(self, ExtendGame.pcProcessTime)

func pcProcessTime(pc: Player, _seconds: int):
	# Hacky solution to hooking sex events + fluid changes.
	var skillsHolder: SkillsHolder = pc.getSkillsHolder()
	if !skillsHolder.hasPerkDisabledOrNot(WsUtil.Perk_Hidden_PissDrinker):
		skillsHolder.addPerk(WsUtil.Perk_Hidden_PissDrinker)

	if skillsHolder.hasPerkDisabledOrNot(WsUtil.Perk_Starting_Urolagnia):
		if !skillsHolder.hasPerk(WsUtil.Perk_Urolagnia):
			skillsHolder.addPerk(WsUtil.Perk_Urolagnia)
		if !skillsHolder.hasPerk(WsUtil.Perk_PissYourself):
			skillsHolder.addPerk(WsUtil.Perk_PissYourself)