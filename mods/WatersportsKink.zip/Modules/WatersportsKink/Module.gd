extends Module
const WsConsole = preload("res://Modules/WatersportsKink/Util/WsConsole.gd")

var consoleInstance := WsConsole.new()

signal drank_piss(npc, amount)
signal pissed_on(source, target, amount)
signal pissed_inside(source, target, slot, amount)

func getFlags():
	return {
		"PissedInCell_Puddle_NoCleanup": flag(FlagType.Bool),
		"PissedInCell_Bed_NoCleanup": flag(FlagType.Bool),
	}

func _init():
	id = "Frivolous_WatersportsKink"
	author = "Frivolous"

	attacks = [
		"res://Modules/WatersportsKink/Attacks/PissYourself.gd",
		"res://Modules/WatersportsKink/Attacks/PissOn.gd",
	]
	skills = [
		"res://Modules/WatersportsKink/Skills/Watersports.gd",
	]
	perks = [
		"res://Modules/WatersportsKink/Perks/PissYourself.gd",
		"res://Modules/WatersportsKink/Perks/WellHydrated.gd",
		"res://Modules/WatersportsKink/Perks/FreeRoam.gd",
		"res://Modules/WatersportsKink/Perks/Urolagnia.gd",

		"res://Modules/WatersportsKink/Perks/SlipperyWhenWet.gd",
		"res://Modules/WatersportsKink/Perks/Lemonade.gd",
		"res://Modules/WatersportsKink/Perks/Pissboy.gd",
		"res://Modules/WatersportsKink/Perks/PissEnema.gd",

		"res://Modules/WatersportsKink/Perks/Alpha.gd",
		"res://Modules/WatersportsKink/Perks/Ouroboros.gd",
		"res://Modules/WatersportsKink/Perks/Revelry.gd",
		"res://Modules/WatersportsKink/Perks/LargeBladder.gd",

		"res://Modules/WatersportsKink/Perks/PissDrinker.gd",
		"res://Modules/WatersportsKink/Perks/Starting_Urolagnia.gd",
	]
	fetishes = [
		"res://Modules/WatersportsKink/SexEngine/Fetish_Giving.gd",
		"res://Modules/WatersportsKink/SexEngine/Fetish_Receiving.gd",
	]
	sexGoals = [
		"res://Modules/WatersportsKink/SexEngine/Goal_Pissplay.gd",
	]
	sexActivities = [
		"res://Modules/WatersportsKink/SexEngine/Activity_PeeInsideVagina.gd",
		"res://Modules/WatersportsKink/SexEngine/Activity_PeeInsideAnus.gd",
		"res://Modules/WatersportsKink/SexEngine/Activity_PeeInsideMouth.gd",
		"res://Modules/WatersportsKink/SexEngine/Activity_PissOn_Penis.gd",
		"res://Modules/WatersportsKink/SexEngine/Activity_PissOn_Vagina.gd",
		"res://Modules/WatersportsKink/SexEngine/Activity_PissOn_Oral.gd",
		"res://Modules/WatersportsKink/SexEngine/Activity_PissOn_Tribadism.gd",
	]
	items = [
		# Replacements to allow pissing
		"res://Modules/WatersportsKink/Replacements/PlasticBottleReplacement.gd",
		"res://Modules/WatersportsKink/Replacements/UsedCondomReplacement.gd",
		"res://Modules/WatersportsKink/Replacements/BreastpumpReplacement.gd",
		"res://Modules/WatersportsKink/Replacements/PenisPumpReplacement.gd",
	]
	fluids = [
		# Replaces piss to make it compatible with fetish
		"res://Modules/WatersportsKink/Replacements/Piss.gd",
	]
	scenes = [
		"res://Modules/WatersportsKink/Scenes/PeeIntoScene.gd",

		# Pee In Public scenes
		"res://Modules/WatersportsKink/Scenes/PeeInPublic_YourCell.gd",
		"res://Modules/WatersportsKink/Scenes/PeeInPublic_Yard.gd",
		"res://Modules/WatersportsKink/Scenes/PeeInPublic_Greenhouse.gd",

		"res://Modules/WatersportsKink/Scenes/MeatToilet_Willing.gd",
	]
	characters = [
		"res://Modules/WatersportsKink/Characters/SceneGuard.gd"
	]

	buffs = [
		"res://Modules/WatersportsKink/Buffs/PissCapacityMult.gd",
		"res://Modules/WatersportsKink/Buffs/PissProductionMult.gd",
	]
	statusEffects = [
		"res://Modules/WatersportsKink/StatusEffect/PissBeta.gd"
	]
	events = [
		"res://Modules/WatersportsKink/Events/PeeInPublic.gd",
		"res://Modules/WatersportsKink/Events/Urinal.gd",
	]
	gameExtenders = [
		"res://Modules/WatersportsKink/Extender.gd",
	]

	sexReactionHandlers = [
		"res://Modules/WatersportsKink/SexEngine/Reactions_Pee.gd"
	]

func emit_drank_piss(character: BaseCharacter, amount: float):
	emit_signal("drank_piss", character, amount)

func emit_pissed_on(source: BaseCharacter, target: BaseCharacter, amount: float):
	emit_signal("pissed_on", source, target, amount)

func emit_pissed_inside(source: BaseCharacter, target: BaseCharacter, slot: String, amount: float):
	emit_signal("pissed_inside", source, target, slot, amount)