extends SkillBase
const WsUtil = preload("res://Modules/WatersportsKink/Util/WsUtil.gd")

func _init():
	id = WsUtil.SkillId
	# print("[WS Kink] Initialized skill " + id)

	connect("levelChanged", self, "onLevelChanged")

	var module = GlobalRegistry.getModule(WsUtil.ModuleId)
	if module == null:
		return

	module.connect("drank_piss", self, "onDrankPiss")
	module.connect("pissed_on", self, "onPissedOn")
	module.connect("pissed_inside", self, "onPissedInside")

func getVisibleName():
	return "Watersports"

func getVisibleDescription():
	return "Shows how much you like piss and activities involving it."

static func alwaysVisible() -> bool:
	return true

func getPerkTiers():
	return [
		[0],
		[2],
		[5],
	]

func onLevelChanged(skillId: String, level: int):
	if id != skillId:
		return

	if level >= 4:
		var holder = npc.getSkillsHolder()
		if !holder.hasPerkDisabledOrNot(WsUtil.Perk_Urolagnia):
			holder.addPerk(WsUtil.Perk_Urolagnia)
			if npc != GM.pc:
				return
			if GM.ui != null:
				GM.main.addMessage("You're no longer grossed out by urine!")

func onDrankPiss(drinker: BaseCharacter, amount: float):
	print("[WS Kink] " + drinker.getName() + " drank " + str(amount) + "ml of piss")

	if drinker.getID() == npc.getID():
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_DRINKING_PISS, amount)

func onPissedOn(source: BaseCharacter, target: BaseCharacter, amount: float):
	print("[WS Kink] " + source.getName() + " pissed " + str(amount) + "ml onto " + target.getName())

	if target.getID() == target.getID():
		# Pissing on yourself gives more XP, but it doesn't give double
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_PISSING_ON_SOMEONE, amount, 1.0)
		return

	if source.getID() == npc.getID():
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_PISSING_ON_SOMEONE, amount)
	
	if target.getID() == npc.getID():
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_PISSED_ON_BY_SOMEONE, amount)

func onPissedInside(source: BaseCharacter, target: BaseCharacter, slot: String, amount: float):
	print("[WS Kink] " + source.getName() + " pissed " + str(amount) + "ml into " + target.getName() + "'s " + slot)

	if target.getID() == target.getID():
	# I guess you can probably piss inside yourself with portal panties?
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_PISSING_INSIDE_SOMEONE, amount, 1.2)
		return

	if source.getID() == npc.getID():
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_PISSING_INSIDE_SOMEONE, amount)
	
	if target.getID() == npc.getID():
		WsUtil.giveSkillExperience(npc, WsUtil.XP_FROM_PISSED_INSIDE_BY_SOMEONE, amount)