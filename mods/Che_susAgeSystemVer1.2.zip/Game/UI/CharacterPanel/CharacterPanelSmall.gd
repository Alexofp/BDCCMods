extends PanelContainer

var characterID: String

onready var characterNameLabel = $VBoxContainer/CharacterName
onready var characterStatusGrid = $VBoxContainer/CharacterStatusGrid

const MODULE_ID = "che_susAgeSystem"
const FLAG_AGES = "Ages"

var _rng = RandomNumberGenerator.new()

const _PERSIST_DIR = "user://che_sus_age_system"
var _persist_loaded_key := ""

func _get_persist_key() -> String:
	var slot = 0
	if(GlobalRegistry != null && GlobalRegistry.has("currentSave")):
		slot = int(GlobalRegistry.currentSave)
	var uid = 0
	if(GlobalRegistry != null && GlobalRegistry.has("currentUniqueID")):
		uid = int(GlobalRegistry.currentUniqueID)
	return "slot_%d_uid_%d" % [slot, uid]

func _get_persist_path() -> String:
	return _PERSIST_DIR + "/" + _get_persist_key() + ".json"

func _load_persisted_ages() -> Dictionary:
	var result := {}
	var f := File.new()
	var path := _get_persist_path()
	if(!f.file_exists(path)):
		return result
	if(f.open(path, File.READ) != OK):
		return result
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse(txt)
	if(parsed.error != OK):
		return result
	if(parsed.result is Dictionary && parsed.result.has("Ages") && parsed.result["Ages"] is Dictionary):
		result = parsed.result["Ages"]
	return result

func _save_persisted_ages(ages:Dictionary) -> void:
	var dir := Directory.new()
	if(!dir.dir_exists(_PERSIST_DIR)):
		dir.make_dir_recursive(_PERSIST_DIR)
	var f := File.new()
	var path := _get_persist_path()
	if(f.open(path, File.WRITE) != OK):
		return
	var payload := {
		"version": 1,
		"key": _get_persist_key(),
		"Ages": ages,
	}
	f.store_string(JSON.print(payload))
	f.close()

func _restore_persisted_ages_into_moduleflag() -> void:
	var persisted := _load_persisted_ages()
	if(persisted.empty()):
		return
	_ensure_persist_loaded()

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}
	for k in persisted.keys():
		ages[k] = persisted[k]
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)

func _ensure_persist_loaded() -> void:
	if(GM == null || GM.main == null):
		return
	var key := _get_persist_key()
	if(_persist_loaded_key == key):
		return
	_persist_loaded_key = key
	_restore_persisted_ages_into_moduleflag()



func _init():
	_rng.randomize()

func _ready():
	add_to_group("che_susAgeSystem_panels")

func setCharacterID(charID: String):
	var character = GlobalRegistry.getCharacter(charID)
	if(character == null):
		return

	characterID = charID
	_updateNameLabel(character)
	characterNameLabel.self_modulate = character.getChatColor()
	character.updateEffectPanel(characterStatusGrid)

func getCharacterID():
	return characterID

func updateStatuses():
	if(characterID == null || characterID == ""):
		return
	var character = GlobalRegistry.getCharacter(characterID)
	if(character == null):
		return
	_updateNameLabel(character)
	character.updateEffectPanel(characterStatusGrid)

func refreshAgeLine():
	if(characterID == null || characterID == ""):
		return
	var character = GlobalRegistry.getCharacter(characterID)
	if(character == null):
		return
	_updateNameLabel(character)

func _updateNameLabel(character):
	var age = _getOrGenerateAge(characterID)
	var typeLabel = _getAgeTypeLabel(age)
	characterNameLabel.text = character.getName() + "\nAge: " + str(age) + " (" + typeLabel + ")"

func _getAgeTypeLabel(age: int) -> String:
	if(age <= 18):
		return "Teen"
	if(age <= 27):
		return "Young"
	if(age <= 39):
		return "Adult"
	if(age <= 60):
		return "Mature"
	return "Older"

func _randAge() -> int:
	var roll = _rng.randi_range(1, 100)
	if(roll <= 65):
		return int(_rng.randi_range(18, 30))
	if(roll <= 82):
		return int(_rng.randi_range(31, 39))
	if(roll <= 92):
		return int(_rng.randi_range(40, 49))
	if(roll <= 97):
		return int(_rng.randi_range(50, 60))
	return int(_rng.randi_range(61, 80))

func _getOrGenerateAge(charID: String) -> int:
	if(GM == null || GM.main == null):
		return _randAge()

	_ensure_persist_loaded()

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}

	if(ages.has(charID)):
		return int(ages[charID])

	var newAge = _randAge()
	ages[charID] = newAge
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
	_save_persisted_ages(ages)
	return newAge
