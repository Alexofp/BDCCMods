extends Module

func _init():
	id = "che_susAgeSystem"
	author = "che_sus"

func getFlags():
	return {
		"Ages": flag(FlagType.Dict),
	}
