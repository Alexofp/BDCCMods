extends Control

const MODULE_ID = "che_susAgeSystem"
const FLAG_AGES = "Ages"

onready var _search = $VBoxContainer/TopRow/Search
onready var _refresh_btn = $VBoxContainer/TopRow/RefreshButton
onready var _list = $VBoxContainer/HSplit/Left/ItemList

onready var _selected_label = $VBoxContainer/HSplit/Right/SelectedLabel
onready var _info_label = $VBoxContainer/HSplit/Right/InfoLabel
onready var _age_spin = $VBoxContainer/HSplit/Right/AgeRow/AgeSpin
onready var _type_label = $VBoxContainer/HSplit/Right/TypeLabel
onready var _apply_btn = $VBoxContainer/HSplit/Right/ButtonsRow/ApplyButton
onready var _randomize_btn = $VBoxContainer/HSplit/Right/ButtonsRow/RandomizeButton

var _rng = RandomNumberGenerator.new()
var _index_to_char_id = []
var _selected_char_id = ""
var _ignore_spin = false

const _PERSIST_DIR = "user://che_sus_age_system"

func _get_persist_key() -> String:
	var slot = 0
	if(GlobalRegistry != null && GlobalRegistry.has("currentSave")):
		slot = int(GlobalRegistry.currentSave)
	var uid = 0
	if(GlobalRegistry != null && GlobalRegistry.has("currentUniqueID")):
		uid = int(GlobalRegistry.currentUniqueID)
	return "slot_%d_uid_%d" % [slot, uid]

func _get_persist_path() -> String:
	return _PERSIST_DIR + "/" + _get_persist_key() + ".json"

func _load_persisted_ages() -> Dictionary:
	var result := {}
	var f := File.new()
	var path := _get_persist_path()
	if(!f.file_exists(path)):
		return result
	if(f.open(path, File.READ) != OK):
		return result
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse(txt)
	if(parsed.error != OK):
		return result
	if(parsed.result is Dictionary && parsed.result.has("Ages") && parsed.result["Ages"] is Dictionary):
		result = parsed.result["Ages"]
	return result

func _save_persisted_ages(ages:Dictionary) -> void:
	var dir := Directory.new()
	if(!dir.dir_exists(_PERSIST_DIR)):
		dir.make_dir_recursive(_PERSIST_DIR)
	var f := File.new()
	var path := _get_persist_path()
	if(f.open(path, File.WRITE) != OK):
		return
	var payload := {
		"version": 2,
		"key": _get_persist_key(),
		"Ages": ages,
	}
	f.store_string(JSON.print(payload))
	f.close()

func _restore_persisted_ages_into_moduleflag() -> void:
	if(GM == null || GM.main == null):
		return
	var persisted := _load_persisted_ages()
	if(persisted.empty()):
		return
	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}
	for k in persisted.keys():
		ages[k] = persisted[k]
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)

func _ready():
	_rng.randomize()
	_restore_persisted_ages_into_moduleflag()

	_refresh_btn.connect("pressed", self, "refresh_list")
	_search.connect("text_changed", self, "_on_search_changed")
	_list.connect("item_selected", self, "_on_item_selected")
	_age_spin.connect("value_changed", self, "_on_age_spin_changed")
	_apply_btn.connect("pressed", self, "_on_apply_pressed")
	_randomize_btn.connect("pressed", self, "_on_randomize_pressed")
	connect("visibility_changed", self, "_on_visibility_changed")

	_age_spin.min_value = 18
	_age_spin.max_value = 80
	_age_spin.step = 1
	_age_spin.rounded = true

	_update_right_panel()
	refresh_list()

func _on_visibility_changed():
	if(visible):
		refresh_list()

func refresh_list():
	_index_to_char_id.clear()
	_list.clear()

	var ids = _get_all_loaded_character_ids()
	var query = str(_search.text).strip_edges().to_lower()

	for char_id in ids:
		var ch = null
		if(GlobalRegistry != null && GlobalRegistry.has_method("getCharacter")):
			ch = GlobalRegistry.getCharacter(char_id)

		var name = char_id
		var species = ""
		if(ch != null):
			if(ch.has_method("getName")):
				name = str(ch.getName())
			if(ch.has_method("getSpeciesFullName")):
				species = str(ch.getSpeciesFullName())

		var hay = (char_id + " " + name + " " + species).to_lower()
		if(query != "" && hay.find(query) == -1):
			continue

		var display = name + " [" + char_id + "]"
		if(species != ""):
			display += " - " + species

		_list.add_item(display)
		_index_to_char_id.append(char_id)

	if(_selected_char_id != ""):
		for i in range(_index_to_char_id.size()):
			if(_index_to_char_id[i] == _selected_char_id):
				_list.select(i)
				_on_item_selected(i)
				return

	_selected_char_id = ""
	_update_right_panel()

func _get_all_loaded_character_ids():
	var result = []
	var seen = {}

	_collect_character_ids_from_source(GlobalRegistry, result, seen)

	if(GM != null && GM.main != null):
		_collect_character_ids_from_source(GM.main, result, seen)

	for known_id in ["pc", "player", "main", "hero", "c_pc"]:
		_try_add_resolved_character_id(known_id, result, seen)

	result.sort()
	return result

func _collect_character_ids_from_source(source, result:Array, seen:Dictionary) -> void:
	if(source == null):
		return

	var method_names = [
		"getCharacters",
		"getDynamicCharacters",
		"getAllCharacters",
		"getCharactersList",
		"getLoadedCharacters",
		"getNearbyCharacters",
		"getVisibleCharacters",
		"getPartyCharacters",
		"getPlayerParty",
		"getPlayerCharacter",
		"getPlayer",
		"getPC",
		"getMainCharacter",
	]
	for method_name in method_names:
		if(source.has_method(method_name)):
			_add_character_entries_from_value(source.call(method_name), result, seen)

	for prop in source.get_property_list():
		if(!(prop is Dictionary)):
			continue
		if(!prop.has("name")):
			continue
		var prop_name = str(prop["name"])
		var lower_name = prop_name.to_lower()
		if(lower_name.find("char") == -1 && lower_name.find("party") == -1):
			continue
		_add_character_entries_from_value(source.get(prop_name), result, seen)

func _add_character_entries_from_value(value, result:Array, seen:Dictionary) -> void:
	if(value == null):
		return

	var value_type = typeof(value)
	if(value_type == TYPE_STRING):
		_add_character_id(str(value), result, seen)
		return

	if(value_type == TYPE_ARRAY):
		for item in value:
			_add_character_entries_from_value(item, result, seen)
		return

	if(value_type == TYPE_DICTIONARY):
		for k in value.keys():
			_add_character_entries_from_value(k, result, seen)
			_add_character_entries_from_value(value[k], result, seen)
		return

	if(value_type == TYPE_OBJECT):
		var cid = _extract_character_id(value)
		if(cid != ""):
			_add_character_id(cid, result, seen)

func _extract_character_id(obj) -> String:
	if(obj == null):
		return ""

	for method_name in ["getID", "getId", "get_id", "getCharID", "getCharacterID", "getCharacterId"]:
		if(obj.has_method(method_name)):
			var value = obj.call(method_name)
			if(value != null && str(value) != ""):
				return str(value)

	for prop_name in ["id", "ID", "charID", "characterID", "characterId"]:
		var value = _try_get_property(obj, prop_name)
		if(value != null && str(value) != ""):
			return str(value)

	return ""

func _try_get_property(obj, prop_name: String):
	if(obj == null):
		return null
	for prop in obj.get_property_list():
		if(prop is Dictionary && prop.has("name") && str(prop["name"]) == prop_name):
			return obj.get(prop_name)
	return null

func _try_add_resolved_character_id(char_id: String, result:Array, seen:Dictionary) -> void:
	if(char_id == ""):
		return
	if(GlobalRegistry != null && GlobalRegistry.has_method("getCharacter")):
		var ch = GlobalRegistry.getCharacter(char_id)
		if(ch != null):
			_add_character_id(char_id, result, seen)

func _add_character_id(char_id: String, result:Array, seen:Dictionary) -> void:
	char_id = str(char_id).strip_edges()
	if(char_id == ""):
		return
	if(seen.has(char_id)):
		return
	seen[char_id] = true
	result.append(char_id)

func _on_search_changed(_tnew):
	refresh_list()

func _on_item_selected(index):
	if(index < 0 || index >= _index_to_char_id.size()):
		return
	_selected_char_id = str(_index_to_char_id[index])
	_update_right_panel()

func _update_right_panel():
	if(_selected_char_id == ""):
		_selected_label.text = "Selected: No character selected"
		_info_label.text = ""
		_type_label.text = "Type:"
		_ignore_spin = true
		_age_spin.value = 18
		_ignore_spin = false
		_apply_btn.disabled = true
		_randomize_btn.disabled = true
		return

	_apply_btn.disabled = false
	_randomize_btn.disabled = false

	var ch = null
	if(GlobalRegistry != null && GlobalRegistry.has_method("getCharacter")):
		ch = GlobalRegistry.getCharacter(_selected_char_id)
	if(ch == null):
		_selected_label.text = "Selected: " + _selected_char_id
		_info_label.text = "ID: " + _selected_char_id
		var missing_age = _get_or_generate_age(_selected_char_id)
		_ignore_spin = true
		_age_spin.value = float(missing_age)
		_ignore_spin = false
		_type_label.text = "Type: " + _get_age_type_label(missing_age)
		return

	_selected_label.text = "Selected: " + str(ch.getName()) + " [" + _selected_char_id + "]"

	var species = ""
	if(ch.has_method("getSpeciesFullName")):
		species = str(ch.getSpeciesFullName())

	var info = "ID: " + _selected_char_id
	if(species != ""):
		info += "\nSpecies: " + species
	_info_label.text = info

	var age = _get_or_generate_age(_selected_char_id)
	_ignore_spin = true
	_age_spin.value = float(age)
	_ignore_spin = false

	_type_label.text = "Type: " + _get_age_type_label(age)

func _on_age_spin_changed(v):
	if(_ignore_spin):
		return
	var age = int(round(v))
	age = clamp(age, 18, 80)
	_type_label.text = "Type: " + _get_age_type_label(age)

func _on_apply_pressed():
	if(_selected_char_id == ""):
		return
	var age = int(round(_age_spin.value))
	age = clamp(age, 18, 80)
	_set_age(_selected_char_id, age)
	get_tree().call_group("che_susAgeSystem_panels", "refreshAgeLine")
	get_tree().call_group("che_susAgeSystem_player_panels", "refreshAgeLine")
	_update_right_panel()

func _on_randomize_pressed():
	if(_selected_char_id == ""):
		return
	_age_spin.value = float(_rand_age_weighted())

func _get_age_type_label(age):
	if(age <= 18):
		return "Teen"
	if(age <= 27):
		return "Young"
	if(age <= 39):
		return "Adult"
	if(age <= 60):
		return "Mature"
	return "Older"

func _rand_age_weighted() -> int:
	var roll = _rng.randi_range(1, 100)
	if(roll <= 65):
		return int(_rng.randi_range(18, 30))
	if(roll <= 82):
		return int(_rng.randi_range(31, 39))
	if(roll <= 92):
		return int(_rng.randi_range(40, 49))
	if(roll <= 97):
		return int(_rng.randi_range(50, 60))
	return int(_rng.randi_range(61, 80))

func _get_or_generate_age(charID):
	if(GM == null || GM.main == null):
		return int(_rand_age_weighted())

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}

	if(ages.has(charID)):
		return int(ages[charID])

	var newAge = int(_rand_age_weighted())
	ages[charID] = newAge
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
	_save_persisted_ages(ages)
	return newAge

func _set_age(charID, newAge):
	if(GM == null || GM.main == null):
		return
	newAge = clamp(int(newAge), 18, 80)

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}
	ages[charID] = newAge
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
	_save_persisted_ages(ages)
