extends Module

func _init():
	id = "songmustelids"
	author = "Songjo"
	
	bodyparts = [
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_HeadA.gd",
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_HeadB.gd",
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_Mask.gd",
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_EarsA.gd",
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_EarsB.gd",
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_tailA.gd",
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1_tailB.gd",
		]
	
	species = [
		"res://Modules/SongsMustelidsModule/Scripts/Mustelids1.gd",
	]
