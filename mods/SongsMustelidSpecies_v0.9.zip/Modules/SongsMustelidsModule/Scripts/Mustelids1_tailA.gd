extends BodypartTail

func _init():
	visibleName = "Mustelid tail 1"
	id = "mustelidtailA"

func getCompatibleSpecies():
	return ["smustelids1"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["mustelid", "fluffy"])

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_tailA/Mustelids1_tailA.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
