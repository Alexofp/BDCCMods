extends BodypartEars

func _init():
	visibleName = "Mustelids ears 1"
	id = "mustelidearsA"

func getCompatibleSpecies():
	return ["smustelids1"]

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_EarsA/Mustelids1_EarsA.tscn"
