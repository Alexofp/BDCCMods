extends BodypartHead

func _init():
	visibleName = "Weasel Head"
	id = "mustelidheadA"

func getCompatibleSpecies():
	return ["smustelids1"]

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_HeadA/Mustelids1_HeadA.tscn"

func getHeadLength():
	return 0.30
