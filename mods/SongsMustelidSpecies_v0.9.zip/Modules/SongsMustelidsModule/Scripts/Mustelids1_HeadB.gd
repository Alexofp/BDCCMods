extends BodypartHead

func _init():
	visibleName = "Ferret Head"
	id = "mustelidheadB"

func getCompatibleSpecies():
	return ["smustelids1"]

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_HeadB/Mustelids1_HeadB.tscn"

func getHeadLength():
	return 0.30
