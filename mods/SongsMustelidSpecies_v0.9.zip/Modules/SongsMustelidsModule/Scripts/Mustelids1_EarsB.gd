extends BodypartEars

func _init():
	visibleName = "Mustelids ears 2"
	id = "mustelidearsB"

func getCompatibleSpecies():
	return ["smustelids1"]

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_EarsB/Mustelids1_EarsB.tscn"
