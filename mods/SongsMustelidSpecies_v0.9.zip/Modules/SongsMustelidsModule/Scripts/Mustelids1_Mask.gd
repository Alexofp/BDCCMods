extends BodypartHorns

func _init():
	visibleName = "Ferret Mask"
	id = "sferretmask"

func getCompatibleSpecies():
	return ["smustelids1"]

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_Mask/Mustelids1_Mask1.tscn"

func npcGenerationWeight(_dynamicCharacter):
	var npchead = _dynamicCharacter.getBodypart(BodypartSlot.Head)
	if npchead.id == "mustelidheadA":
		return 0.0
	elif npchead.id == "mustelidheadB":
		return 1.0

func getHybridPriority():
	return -1
