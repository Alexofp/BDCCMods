extends BodypartTail

func _init():
	visibleName = "Mustelid tail 2"
	id = "mustelidtailB"

func getCompatibleSpecies():
	return ["smustelids1"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["mustelid", "fluffy"])

func getDoll3DScene():
	return "res://Modules/SongsMustelidsModule/Pngs/Mustelids1/Mustelids1_tailB/Mustelids1_tailB.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
