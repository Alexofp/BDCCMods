extends Species

func _init():
	id = "smustelids1"
	
func getVisibleName():
	return "Mustelid"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "mustelidtailA"

func isPlayable():
	return true

func getVisibleDescription():
	return "Cute fluffballs"

func getDefaultHead(_gender):
	return "mustelidheadA"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "mustelidearsA"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 4.0],
		[3, 5.0],
		[4, 6.0],
		[5, 6.0],
		[6, 3.0],
		[7, 3.0],
		[8, 3.0],
	]
