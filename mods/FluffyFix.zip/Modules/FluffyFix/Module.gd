extends Module

var affectPlayer : bool = false
var affectStatic : bool = false

func _init():
	id = "RAT_FluffyFix"
	author = "Selinoccino"
	
	worldEdits = [
		"res://Modules/FluffyFix/FixEdit.gd"
	]

func onFoxLibModInit(foxModuleAPI):
	foxModuleAPI.addBooleanOptionInCategory("FluffyFix", "affectPlayer", "Fix player", "Will attempt to fix the player's bodyparts as well as the dynamic/datapack NPCs' ones.", false)
	foxModuleAPI.addBooleanOptionInCategory("FluffyFix", "affectStatic", "Fix static characters", "Will attempt to fix static characters' bodyparts as well as the dynamic/datapack NPCs' ones.", false)
	
