extends WorldEditBase

func _init():
	id = "RAT_FluffyFixEdit"
	
	

var replacements : Dictionary = {
	BodypartSlot.Arms: {
		"fluffyarms": "fluffarms",
		"fluffyclawedarms": "fluffclawedarms",
		"fluffarms": "scruffarms",
		"scruffyclawedarms": "scruffclawedarms",
		"": "fluffarms",
	},
	BodypartSlot.Body: {
		"fluffybody": "fluffbody",
		"softbody": "fluffbody",
		"": "fluffbody",
	},
	BodypartSlot.Breasts: {
		"fluffbreastsextra": "fluffbreasts",
		"":"fluffbreasts",
	},
	BodypartSlot.Legs: {
		"scruffyhoofs": "scruffhoofs",
		"scruffysoftlegs": "scrufflegsclawless",
		"flufflegs": "scrufflegs",
		"scruffbackedlegs": "scrufflegsfluffy",
		"fluffylegs": "flufflegs",
		"fluffyhoofssmall": "fluffhoofssmall",
		"fluffyhoofs": "fluffhoofs",
		"softdigilegs": "flufflegsclawless",
		"": "flufflegs",
	}
}

func apply(_world: GameWorld):
	if GlobalRegistry.getModule("RAT_FluffyFix").affectPlayer:
		Log.print("FluffyFix: Starting fix for player character")
		fixCharacter(GM.pc)
	
	if GlobalRegistry.getModule("RAT_FluffyFix").affectStatic:
		Log.print("FluffyFix: Starting fix for static characters")
		for character in GM.main.getCharacters().values():
			fixCharacter(character)
	
	Log.print("FluffyFix: Starting fix for dynamic/datapack characters")
	for character in GM.main.getDynamicCharacters().values():
		fixCharacter(character)
	

func fixCharacter(character) -> void:
	var cid = character.getID()
	var cname = character.getName()
	var fixed : int = 0
	for slot in replacements:
		var oldID = character.getBodypartID(slot)
		if oldID in replacements[slot]:
			var newID = replacements[slot][oldID]
			character.switchBodypartSimple(newID)
			Log.print("FluffyFix: Switched bodypart %s with %s for character with ID %s (%s)" % [oldID, newID, cid, cname])
			fixed += 1
	
	Log.print("Fixed %s bodyparts for character %s (%s)" % [fixed, cid, cname] if fixed else "Nothing to fix for character %s (%s)" % [cid, cname])
