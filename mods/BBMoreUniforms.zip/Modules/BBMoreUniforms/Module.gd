extends Module

var debug = false # Debug - save modified code to user folder
var hooksHolder = [] # Hold them in memory, our changes don't exist on disk at res://

func _init():
	id = "BBMoreUniforms"
	author = "Anon, MaxMaxou, bringlebangul"
	
	#Bottoms only is deprecated by base game update 0.4.0

	#Harnesses and Misc Clothes are unaltered from MoreUniforms v7
	#Uniforms have been re-worked to fit the new clothing system, unfortunately they won't be compatible with old saves using MoreUniforms v7
	
	items = [
		"res://Modules/BBMoreUniforms/Uniforms/LongUniformOrange.gd",
		"res://Modules/BBMoreUniforms/Uniforms/LongUniformLilac.gd",
		"res://Modules/BBMoreUniforms/Uniforms/LongUniformRed.gd",
		"res://Modules/BBMoreUniforms/Uniforms/CropTopOrange.gd",
		"res://Modules/BBMoreUniforms/Uniforms/CropTopLilac.gd",
		"res://Modules/BBMoreUniforms/Uniforms/CropTopRed.gd",
		"res://Modules/BBMoreUniforms/Uniforms/MaternityUniformOrange.gd",
		"res://Modules/BBMoreUniforms/Uniforms/MaternityUniformLilac.gd",
		"res://Modules/BBMoreUniforms/Uniforms/MaternityUniformRed.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/NipTape.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/PussyTape.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/CowBra.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/CowBriefs.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/CowPanties.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/ChestWraps.gd",
		"res://Modules/BBMoreUniforms/Harnesses/6pointHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/8pointHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/BellyHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/ChestHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/FullHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/MaxHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/RestrictionHarness.gd",
		
		"res://Modules/BBMoreUniforms/outfitgiver.gd", #debug only
		
		# override items from base game to add shift-aside options
		# any newly added or modded items which refer to res://Inventory/RiggedModels/ for uniform, bra, panties, briefs, or undershirt will have to be overridden to function with this mod
		"res://Modules/BBMoreUniforms/Overrides/InmageUniformGeneral.gd",
		"res://Modules/BBMoreUniforms/Overrides/InmateUniformHighSec.gd",
		"res://Modules/BBMoreUniforms/Overrides/InmateUniformSexDeviant.gd",
		"res://Modules/BBMoreUniforms/Overrides/LaceBraOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/LacePantiesOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/MiriPantiesOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainBraOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainBriefsOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainPantiesOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainUndershirtOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/SportyBriefsOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/SportyTankTopOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/SportyTopOverride.gd",
		
		
	]
	scenes = [
		"res://Modules/BBMoreUniforms/ClothingAdjustState.gd",
	]
	


var hooks = [
	#allow the ShirtAndShortsState to keep track of the shorts the same way it does to the shirt
	["res://Inventory/ItemState/ShirtAndShortsState.gd",
		[ #start of file1 replacements
			["", "var noShirt:bool = false", "\n" + "var noPants:bool = false" + "\n\n" + "func shouldHideShorts() -> bool:" + "\n\t" + "return noPants"],
			["", "return shortsPulledDown", " || noPants"],
			["", "func pullDownShorts(_updateAppearance:bool = true):", "\n\t" + "if(noPants):" + "\n\t\t" + "return"],
			["", """data["noShirt"] = noShirt""", "\n\t" + """data["noPants"] = noPants"""],
			["", """noShirt = SAVE.loadVar(_data, "noShirt", false)""", "\n\t" + """if(!_data.has("noPants")):""" + "\n\t\t" + """noPants = SAVE.loadVar(_data, "noPants", false)"""],
		],
	],
]

func postInit():
	pass
	
func preInit():
	initMindsFileHandleing()


# credit Mindstormsman for code injection
func exportModifiedFile(fileName, fileContent):
	var file = File.new()
	var path = "user://Mind's_Hooks_Debug_Exports/"
	var fullPath = path + fileName
	print("Exporting to "+ fullPath)
	var error = file.open(fullPath, File.WRITE)
	if(!error):
		file.store_line(fileContent)
		file.close()
	else: print("Error "+str(error)+" opening path: "+fullPath)

func initMindsFileHandleing():
	if OS.has_feature("editor"):
		debug = true

	if(debug):
		var dir = Directory.new()
		var error = dir.make_dir("user://Mind's_Hooks_Debug_Exports")
		if(error and (error != 32)):
			print("Error "+str(error)+" creating directory user://Mind's_Hooks_Debug_Exports")
			debug = false

	for target in hooks:
		var codeBase = load(target[0])
		var originalCode = codeBase.source_code
		var modifiedCode = originalCode
		for hook in target[1]:
			modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
		codeBase.source_code = modifiedCode
		var error = codeBase.reload()
		if( error != 0):
			print("Error code "+str(error)+" reloading target at path: "+target[0])
		hooksHolder.append(codeBase)
		if(debug): exportModifiedFile(target[0].get_file(), modifiedCode)

	print("(BetterEditorControls): Mind's Hooks Applied")
	return
