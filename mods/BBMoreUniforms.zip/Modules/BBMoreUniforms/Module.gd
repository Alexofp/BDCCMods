extends Module

#var hack = load("res://Inventory/RiggedModels/InmateUniform/InmateUniform.tscn")

func _init():
	id = "BBMoreUniforms"
	author = "Anon, MaxMaxou, bringlebangul"
	
	#Bottoms only is deprecated by base game update 0.4.0

	#Harnesses and Misc Clothes are unaltered from MoreUniforms v7
	#Uniforms have been re-worked to fit the new clothing system, unfortunately they won't be compatible with old saves using MoreUniforms v7
	
	items = [
		"res://Modules/BBMoreUniforms/Uniforms/LongUniformOrange.gd",
		"res://Modules/BBMoreUniforms/Uniforms/LongUniformLilac.gd",
		"res://Modules/BBMoreUniforms/Uniforms/LongUniformRed.gd",
		"res://Modules/BBMoreUniforms/Uniforms/CropTopOrange.gd",
		"res://Modules/BBMoreUniforms/Uniforms/CropTopLilac.gd",
		"res://Modules/BBMoreUniforms/Uniforms/CropTopRed.gd",
		"res://Modules/BBMoreUniforms/Uniforms/MaternityUniformOrange.gd",
		"res://Modules/BBMoreUniforms/Uniforms/MaternityUniformLilac.gd",
		"res://Modules/BBMoreUniforms/Uniforms/MaternityUniformRed.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/NipTape.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/PussyTape.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/CowBra.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/CowBriefs.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/CowPanties.gd",
		"res://Modules/BBMoreUniforms/Misc Clothes/ChestWraps.gd",
		"res://Modules/BBMoreUniforms/Harnesses/6pointHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/8pointHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/BellyHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/ChestHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/FullHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/MaxHarness.gd",
		"res://Modules/BBMoreUniforms/Harnesses/RestrictionHarness.gd",
		
		"res://Modules/BBMoreUniforms/outfitgiver.gd", #debug only
		
		# override items from base game to add shift-aside options
		"res://Modules/BBMoreUniforms/Overrides/InmageUniformGeneral.gd",
		"res://Modules/BBMoreUniforms/Overrides/InmateUniformHighSec.gd",
		"res://Modules/BBMoreUniforms/Overrides/InmateUniformSexDeviant.gd",
		"res://Modules/BBMoreUniforms/Overrides/LaceBraOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/LacePantiesOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainBraOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainBriefsOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainPantiesOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/PlainUndershirtOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/SportyBriefsOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/SportyTankTopOverride.gd",
		"res://Modules/BBMoreUniforms/Overrides/SportyTopOverride.gd",
		
		
	]
	scenes = [
		"res://Modules/BBMoreUniforms/ClothingAdjustState.gd",
	]
	
	
	
	
var thepath = "res://Inventory/RiggedModels/InmateUniform/InmateUniform.gd"
var target = load(thepath)

var find1 = """	#legup_deformable.visible = true#bodywidepng_2.visible
	#legup_deformable_001.visible = true#bodywidepng_2.visible"""
var replace1 = """	legup_deformable.visible = !_state.shouldHideShorts()
	legup_deformable_001.visible = !_state.shouldHideShorts()"""
	
var thepath2 = "res://Inventory/RiggedModels/Bra/Bra.gd"
var target2 = load(thepath2)

var find2 = """	setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Bra/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Bra/bodyOpen.png")"""
var replace2 = """	if(_item.id == "LaceBra"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/body_lace.png" if !_state.pulledUp else "res://Modules/BBMoreUniforms/Underwear/body_laceOpen.png")
		setShaderMatTexturePath(breasts_scalable_001, "res://Modules/BBMoreUniforms/Underwear/breasts_lace.png")
	elif(_item.id == "sportyTop"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/bra_sporty_ColorMask.png" if !_state.pulledUp else "res://Modules/BBMoreUniforms/Underwear/body_sportyOpen_ColorMask.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_b", ColorN("white",1))
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/body_sporty.png" if !_state.pulledUp else "res://Modules/BBMoreUniforms/Underwear/body_sportyOpen.png")
		setShaderMatTexturePath(breasts_scalable_001, "res://Modules/BBMoreUniforms/Underwear/breasts_sporty.png")
	else:
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Bra/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Bra/bodyOpen.png")
		setShaderMatTexturePath(breasts_scalable_001, "res://Inventory/RiggedModels/Bra/breasts.png")
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")"""

var thepath3 = "res://Inventory/RiggedModels/Panties/Panties.gd"
var target3 = load(thepath3)
var find3 = """	bodywidepng.visible = !_state.pulledDown"""
var replace3 = """	bodywidepng.visible = !_state.pulledDown
	if(_item.id == "LacePanties"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/panties_lace.png" if !_state.arePantiesShiftedAside() else "res://Modules/BBMoreUniforms/Underwear/panties_lace_pulledaside.png")
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Underwear/panties_laceDown.png")
	else:
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Panties/panties.png" if !_state.arePantiesShiftedAside() else "res://Modules/BBMoreUniforms/Underwear/panties_pulledaside.png")
		setShaderMatTexturePath(legup_deformable, "res://Inventory/RiggedModels/Panties/pantiesDown.png")"""

var thepath4 = "res://Inventory/RiggedModels/Undershirt/Undershirt.gd"
var target4 = load(thepath4)
var find4 = """	setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Undershirt/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Undershirt/bodyOpen.png")"""
var replace4 = """	setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Undershirt/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Undershirt/bodyOpen.png")
	if(_item.id == "sportyTankTop"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/undershirt_sporty_layer_ColorMask.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_b", ColorN("white",1))
	else:
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")"""


var thepath5 = "res://Inventory/RiggedModels/Briefs/Briefs.gd"
var target5 = load(thepath5)
var find5 = """	bodywidepng.visible = !_state.arePantiesPulledDown()"""
var replace5 = """	bodywidepng.visible = !_state.arePantiesPulledDown()
	if(_item.id == "sportyBriefs"):
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Underwear/leg_sporty.png")
		setShaderMatTexturePath(legup_deformable_001, "res://Modules/BBMoreUniforms/Underwear/leg_sporty.png")
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Underwear/leg_sporty_ColorMask.png", "texture_colormask")
		setShaderMatTexturePath(legup_deformable_001, "res://Modules/BBMoreUniforms/Underwear/leg_sporty_ColorMask.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(legup_deformable)
		theMat.set_shader_param("color_b", ColorN("white",1))
		theMat = getShaderMatUnique(legup_deformable_001)
		theMat.set_shader_param("color_b", ColorN("white",1))
	else:
		setShaderMatTexturePath(legup_deformable, "res://Inventory/RiggedModels/Briefs/leg.png")
		setShaderMatTexturePath(legup_deformable_001, "res://Inventory/RiggedModels/Briefs/leg.png")
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")"""

func postInit(): # Called after everything is registered
	var original = target.source_code
	var modified = original.replace(find1, replace1)
	target.source_code = modified
	target.reload()
	if(replace1 in target.source_code):
		Log.print("[BBMoreUniforms] injected ban pants mode into "+ thepath)
	original = target2.source_code
	modified = original.replace(find2, replace2)
	target2.source_code = modified
	target2.reload()
	if(replace2 in target2.source_code):
		Log.print("[BBMoreUniforms] appled textures to "+ thepath2)
	original = target3.source_code
	modified = original.replace(find3, replace3)
	target3.source_code = modified
	target3.reload()
	if(replace3 in target3.source_code):
		Log.print("[BBMoreUniforms] appled textures to "+ thepath3)
	original = target4.source_code
	modified = original.replace(find4, replace4)
	target4.source_code = modified
	target4.reload()
	if(replace4 in target4.source_code):
		Log.print("[BBMoreUniforms] appled textures to "+ thepath4)
	original = target5.source_code
	modified = original.replace(find5, replace5)
	target5.source_code = modified
	target5.reload()
	if(replace5 in target5.source_code):
		Log.print("[BBMoreUniforms] appled textures to "+ thepath5)
