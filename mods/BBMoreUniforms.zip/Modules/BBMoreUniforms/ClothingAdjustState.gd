extends "res://Scenes/SceneBase.gd"



var savedActionText = ""
var uniqueItemID = ""


func _initScene(_args = []):
	if(_args.size() > 0):
		uniqueItemID = _args[0]
	else:
		sayn("An error happened. No clothing item was found.")
		return
		

func _reactInit():
	if(uniqueItemID == null || uniqueItemID == ""):
		return

		
func _init():
	sceneID = "ClothingAdjustState"

func _run():
	var item: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
#	var hack = item.getVisibleName()
	if(item.isRemoved()):
		return
	addButtonAt(14, "Back", "", "endthescene")
	addButtonAt(13, "Fix Clothes", "Wear your clothes like normal", "clothingReset")
	
	if(item.getItemState() is ShirtAndShortsState):
		if(item.getItemState().shouldHideShirt()):
			addDisabledButton("Toggle shorts", "Just get naked you slut")
		addButton("Toggle shorts", "Ban pants","banpants")

	var lustCombatState:LustCombatState = GM.pc.getLustCombatState()
	if(item == null):
		return
	var thestate = item.getItemState()
#	var slot = item.getClothingSlot()
	if(thestate is ShirtAndShortsState):
		if(!thestate.isShirtOpened()):
			addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "UniformExposeChest")
		if(!thestate.areShortsPulledDown()):
			if(item.getWearer().hasBlockedHands()):
				addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "UniformShakeShortsOff")
			else:
				addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "UniformExposeCrotch")
			
	if(thestate is BraState):
		if(!GM.pc.isInventorySlotBlocked(InventorySlot.UnderwearTop)):
			if(!thestate.isBraPulledUp()):
				if(item.getWearer().hasBlockedHands()):
					addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "BraShakeOff")
				else:
					addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "BraPullUp")
			
	if(thestate is PantiesState):
		if(!GM.pc.isInventorySlotBlocked(InventorySlot.UnderwearBottom)):
			if(!thestate.arePantiesShiftedAside() && !thestate.isRemoved()):
				if(item.getWearer().hasBlockedHands()):
					addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "PantiesShakeOff")
				else:
					addLustActionsButtons(lustCombatState, lustCombatState.getActionsSorted(), "PantiesPullDown")


	for activity in lustCombatState.getAllText():
		sayn(activity)
		

func addLustActionsButtons(lustState, theActions, name):
	var lustCombatState:LustCombatState = GM.pc.getLustCombatState()
	for actionData in theActions:
#		var _test = actionData.id
		var lustAction = GlobalRegistry.getLustAction(actionData.id)
		if(actionData.id == name):
			var canDo = lustAction.canDo(lustState, actionData)
			var reasonWhyCant = "You can’t do this right now"
			if(canDo is Array):
				if(canDo.size() > 1):
					reasonWhyCant = canDo[1]
				canDo = canDo[0]
			
			if(canDo):
				addButton(lustAction.getVisibleName(lustCombatState, actionData), lustAction.getVisibleDescription(lustCombatState, actionData), "doLustAction", [actionData])
			else:
				addDisabledButton(lustAction.getVisibleName(lustCombatState, actionData), reasonWhyCant)
			return

func _react(_action: String, _args):
	var lustCombatState:LustCombatState = GM.pc.getLustCombatState()
	var item: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
	
	if(_action == "endthescene"):
		endScene()
		
	if(_action == "doLustAction"):
		
		var actionData = _args[0]
#		print (actionData) #debug
		
		var result = lustCombatState.doAction(actionData)
		savedActionText = result["text"]
		sayn(savedActionText)
		item.updateWearerAppearance()
		addButton("Continue","","")

		return
	
	if(_action == "banpants"):
		var itemState = item.getItemState()
		var text = ""
		itemState.noPants = !itemState.noPants
		if(itemState.noPants):
			text = "You take the shorts off!"
		else:
			text = "You put the shorts on!"
		sayn(text)
		item.updateWearerAppearance()
		addButton("Continue","","")
		return
	
	if(_action == "clothingReset"):
		item.getItemState().resetState()
		if(item.getItemState() is ShirtAndShortsState):
			item.getItemState().noShirt = false
			item.getItemState().noPants = false
		item.updateWearerAppearance()
		sayn("You fix your clothing.")
		return
		
	setState(_action)

