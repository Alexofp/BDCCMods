extends ItemBase

func _init():
	id = "chestwraps"

func getVisibleName():
	return "Chest Wraps"
	
func getDescription():
	var text = "Some cloth wrap. This one seems like its made to wrap around someone's chest."

	return text

func getClothingSlot():
	return InventorySlot.UnderwearTop

func getBuffs():
	return []

func getTakingOffStringLong(withS):
	if(withS):
		return "strips off the wrappings on your chest"
	else:
		return "strip off the wrappings on your chest"

func getPuttingOnStringLong(withS):
	if(withS):
		return "grabs some cloth and wraps up your chest"
	else:
		return "grab some cloth and wrap up your chest"

func getPrice():
	return 3

func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
		ItemTag.GeneralInmateUniform
		]


func generateItemState():
	itemState = BraState.new()
	itemState.canActuallyBeDamaged = true
	
func getPossibleActions():
	if(!isWornByWearer()):
		return []
	return [
		{
			"name": "More Options",
			"scene": "ClothingAdjustState",
			"description": "How naked do you want to be while still technically wearing something?",
		},
	]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"bra": "res://Modules/BBMoreUniforms/Misc Clothes/ChestWraps/ChestWraps.tscn",
	}

func getInventoryImage():
	return "res://Modules/BBMoreUniforms/ItemIcons/WrapsIcon.png"

func canDye():
	return true
