extends ItemBase

func _init():
	id = "outfitgiver"

func getVisibleName():
	return "Outfit Giver (debug)"
	
func getDescription():
	return "Use to gain 1 of every clothing item edited by BBMoreUniforms. For debug only."

func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)

	var pockets = _attacker.getInventory()
	pockets.addItemID("inmateuniform")
	pockets.addItemID("inmateuniformHighsec")
	pockets.addItemID("inmateuniformSexDeviant")
	pockets.addItemID("croptopuniform")
	pockets.addItemID("croptopuniform-R")
	pockets.addItemID("croptopuniform-L")
	pockets.addItemID("inmateuniformlong")
	pockets.addItemID("inmateuniformlong-L")
	pockets.addItemID("inmateuniformlong-R")
	pockets.addItemID("maternityuniform")
	pockets.addItemID("maternityuniform-L")
	pockets.addItemID("maternityuniform-R")
	pockets.addItemID("LaceBra")
	pockets.addItemID("LacePanties")
	pockets.addItemID("plainBra")
	pockets.addItemID("plainBriefs")
	pockets.addItemID("plainPanties")
	pockets.addItemID("plainUndershirt")
	pockets.addItemID("sportyBriefs")
	pockets.addItemID("sportyTankTop")
	pockets.addItemID("sportyTop")
	
	pockets.addItemID("chestwraps")
	pockets.addItemID("cowbra")
	pockets.addItemID("cowpanties")
	pockets.addItemID("niptape")
	pockets.addItemID("pussytape")
	
	pockets.addItemID("6strapharness")
	pockets.addItemID("8strapharness")
	pockets.addItemID("bellyharness")
	pockets.addItemID("chestharness")
	pockets.addItemID("fullharness")
	pockets.addItemID("maxharness")
	pockets.addItemID("restrictharness")
	
	return "done"
	
	
			
func getPossibleActions():
	return [
		{
			"name": "Use",
			"scene": "UseItemLikeInCombatScene",
			"description": "Use item",
		},
	]

func getPrice():
	return 0

func canSell():
	return false

func canCombine():
	return false

func getTags():
	return [
		]


func getItemCategory():
	return ItemCategory.Generic

