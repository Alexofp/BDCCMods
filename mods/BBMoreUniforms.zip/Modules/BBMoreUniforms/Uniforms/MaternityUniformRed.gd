extends "res://Modules/BBMoreUniforms/Uniforms/MaternityUniformOrange.gd"

func _init():
	id = "maternityuniform-R"
	inmateType = InmateType.HighSec
