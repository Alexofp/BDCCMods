extends "res://Modules/BBMoreUniforms/Uniforms/LongUniformOrange.gd"

func _init():
	id = "inmateuniformlong-L"
	inmateType = InmateType.SexDeviant
