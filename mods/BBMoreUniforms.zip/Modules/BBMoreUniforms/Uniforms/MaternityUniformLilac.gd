extends "res://Modules/BBMoreUniforms/Uniforms/MaternityUniformOrange.gd"

func _init():
	id = "maternityuniform-L"
	inmateType = InmateType.SexDeviant
