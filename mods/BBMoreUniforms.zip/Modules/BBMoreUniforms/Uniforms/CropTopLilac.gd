extends "res://Modules/BBMoreUniforms/Uniforms/CropTopOrange.gd"

func _init():
	id = "croptopuniform-L"
	inmateType = InmateType.SexDeviant
