extends ItemBase

var prisonerNumber = ""
var inmateType = InmateType.General

func _init():
	id = "inmateuniformlong"

func getVisibleName():
	return "Inmate Uniform Upgraded (" + InmateType.getOfficialName(inmateType).capitalize() +")"
	
func setPrisonerNumber(newnumber):
	prisonerNumber = newnumber
	
func setInmateType(newtype):
	inmateType = newtype
	
func getDescription():
	var text = "A long-sleeved shirt and a pair of pants, both are made out of black cloth with "+InmateType.getColorName(inmateType)+" trim."

	if(prisonerNumber != null && prisonerNumber != ""):
		text += " The shirt has a prisoner number attached to it that says \""+prisonerNumber+"\""
	
	return text

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [-10]),
		buff(Buff.LustDamageBuff, [-10]),
		buff(Buff.LustArmorBuff, [10])
		]

func getPrice():
	return 25

func getTags():
	return [
		ItemTag.GeneralInmateUniform,
		ItemTag.SoldByUnderwearVendomat
		]

func saveData():
	var data = .saveData()
	
	data["prisonerNumber"] = prisonerNumber
	data["inmateType"] = inmateType
	
	return data
	
func loadData(data):
	.loadData(data)
	
	prisonerNumber = SAVE.loadVar(data, "prisonerNumber", "")
	inmateType = SAVE.loadVar(data, "inmateType", InmateType.General)

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your inmate shirt and pulls down the pants"
	else:
		return "take off your inmate shirt and pull down the pants"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your inmate shirt and the pants"
	else:
		return "put on your inmate shirt and the pants"

func generateItemState():
	itemState = ShirtAndShortsState.new()
	itemState.canActuallyBeDamaged = true # Is hack because there are many clothes that use this state already and don't support damaging..

func useInCombat(_attacker, _receiver):
	var text := "You toggle!"
	
	if(itemState is ShirtAndShortsState):
		itemState.noShirt = !itemState.noShirt
		if(itemState.noShirt):
			text = "You take the shirt off!"
		else:
			text = "You put the shirt on!"
	
	if(isWornByWearer()):
		updateWearerAppearance()
	
	return text

func getPossibleActions():
	if(!isWornByWearer()):
		return []
	return [
		{
			"name": "Toggle shirt",
			"scene": "UseItemLikeInCombatScene",
			"description": "Choose if you want to wear the shirt too or just the shorts",
		},
		{
			"name": "More Options",
			"scene": "ClothingAdjustState",
			"description": "How naked do you want to be while still technically wearing something?",
		},
	]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	
	return {
		"clothing": "res://Modules/BBMoreUniforms/Uniforms/LongUni/InmateUniformLong.tscn",
	}

func getInventoryImage():
	if(inmateType == InmateType.SexDeviant):
		return "res://Modules/BBMoreUniforms/ItemIcons/shirtlilac+.png"
	if(inmateType == InmateType.HighSec):
		return "res://Modules/BBMoreUniforms/ItemIcons/shirtred+.png"
	return "res://Modules/BBMoreUniforms/ItemIcons/shirtorange+.png"
