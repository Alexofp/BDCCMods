extends "res://Modules/BBMoreUniforms/Uniforms/CropTopOrange.gd"

func _init():
	id = "croptopuniform-R"
	inmateType = InmateType.HighSec
