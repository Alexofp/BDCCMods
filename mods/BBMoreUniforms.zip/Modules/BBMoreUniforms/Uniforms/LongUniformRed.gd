extends "res://Modules/BBMoreUniforms/Uniforms/LongUniformOrange.gd"

func _init():
	id = "inmateuniformlong-R"
	inmateType = InmateType.HighSec
