extends "res://Inventory/RiggedModels/InmateUniform/InmateUniform.gd"

#onready var bodywidepng = $"%bodywidepng"
#onready var bodywidepng_2 = $"%bodywidepng2"
#onready var armpng = $"%armpng"
#onready var armpng_001 = $"%armpng001"
#onready var legup_deformable = $"%legupDeformable"
#onready var legup_deformable_001 = $"%legupDeformable001"
#onready var breasts_scalable_001 = $"%breastsScalable001"
onready var forearmpng = $"%forearmpng"
onready var forearmpng_001 = $"%forearmpng001"
onready var digilegpng = $"%digilegpng"
onready var digilegpng_001 = $"%digilegpng001"
onready var legdownpng = $"%legdownpng"
onready var legdownpng_001 = $"%legdownpng001"
onready var lower_legs = $"%PartStatePicker2"

func updateFromItem(_item):
	if(!(_item.itemState is ShirtAndShortsState)):
		Log.printerr("Something is wrong, inmate uniform has wrong item state: "+str(_item.itemState))
		return
	var _inmateType:int = _item.inmateType # InmateType.General
	var _state:ShirtAndShortsState = _item.itemState
	var _dam:int = _state.getDamageState() # 0, 1, 2, 3
	
	setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Uniforms/Maternity/GeneralUni_Maternity Shirt.png" if !_state.isShirtOpened() else "res://Modules/BBMoreUniforms/Uniforms/CropTop/Croptop_shirtOpen.png")
	setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Uniforms/Maternity/GeneralUni_Maternity Shirt ColorMask.png" if !_state.isShirtOpened() else "res://Modules/BBMoreUniforms/Uniforms/CropTop/Croptop_shirtOpen_ColorMask.png", "texture_colormask")
	
	bodywidepng.visible = !_state.shouldHideShirt()
	forearmpng.visible = !_state.shouldHideShirt()
	forearmpng_001.visible = !_state.shouldHideShirt()
	armpng.visible = bodywidepng.visible
	armpng_001.visible = bodywidepng.visible
	breasts_scalable_001.visible = !_state.isShirtOpened()
	bodywidepng_2.visible = !_state.areShortsPulledDown()
	legup_deformable.visible = !_state.shouldHideShorts()
	legup_deformable_001.visible = !_state.shouldHideShorts()
	lower_legs.visible = !_state.shouldHideShorts()

	var theMat1:ShaderMaterial = getShaderMatUnique(legup_deformable)
	if(theMat1):
		theMat1.set_shader_param("uv1_offset", Vector2(0.0, -0.15 if _state.areShortsPulledDown() else 0.0))
	var theMat2:ShaderMaterial = getShaderMatUnique(legup_deformable_001)
	if(theMat2):
		theMat2.set_shader_param("uv1_offset", Vector2(0.0, -0.15 if _state.areShortsPulledDown() else 0.0))

	if(_inmateType == InmateType.General):
		setUniformColor(Color("ff6600"))
		#setMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/orangeUniform.png")
	elif(_inmateType == InmateType.HighSec):
		#setMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/redUniform.png")
		setUniformColor(Color("FF1500"))
	else:
		#setMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/lilacUniform.png")
		setUniformColor(Color("AE00FF"))
	
	if(_dam == 1):
		for theMesh in [bodywidepng, bodywidepng_2, armpng, armpng_001, legup_deformable, legup_deformable_001, breasts_scalable_001, forearmpng, forearmpng_001, legdownpng, legdownpng_001, digilegpng, digilegpng_001]:
			setDamageFloat(theMesh, 0.25)
		setDamageFloat(breasts_scalable_001, 0.0)
	elif(_dam == 2):
		for theMesh in [bodywidepng, bodywidepng_2, armpng, armpng_001, legup_deformable, legup_deformable_001, breasts_scalable_001, forearmpng, forearmpng_001, legdownpng, legdownpng_001, digilegpng, digilegpng_001]:
			setDamageFloat(theMesh, 0.5)
	elif(_dam == 3):
		for theMesh in [bodywidepng, bodywidepng_2, armpng, armpng_001, legup_deformable, legup_deformable_001, breasts_scalable_001, forearmpng, forearmpng_001, legdownpng, legdownpng_001, digilegpng, digilegpng_001]:
			setDamageFloat(theMesh, 0.75)
		setDamageFloat(breasts_scalable_001, 1.0)
		setDamageFloat(legup_deformable, 0.75)
	else:
		for theMesh in [bodywidepng, bodywidepng_2, armpng, armpng_001, legup_deformable, legup_deformable_001, breasts_scalable_001, forearmpng, forearmpng_001, legdownpng, legdownpng_001, digilegpng, digilegpng_001]:
			setDamageFloat(theMesh, 0.0)
	
