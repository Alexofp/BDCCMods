extends ItemBase

func _init():
	id = "chestharness"

func getVisibleName():
	return "Chest Harness"
	
#I have no idea what this does
func getA():
	return "a"
	
func getDescription():
	return "A simple harness straps to the chest."

func getClothingSlot():
	return InventorySlot.Torso


func getBuffs():
	return [
		buff(Buff.AmbientLustBuff, [10]),
		buff(Buff.PenisCumGenerationAfterOrgasmBuff, [5]),
		]

func getPrice():
	return 10

func canSell():
	return true
	
func getSellPrice():
	return 3

#Unsure to make it full BDSM restraint, as defined by the game
#doesnt directly restrict the player, or engage with them sexually like the ropes rubbing a characters crotch
#but BDSM isnt on my fetish list so who knows
func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.CanBeForcedByGuards, ItemTag.CanBeForcedInStocks, ItemTag.SoldByTheAnnouncer, ItemTag.RopeHarness]

func isRestraint():
	return true

func generateRestraintData():
	restraintData = RestraintRopeHarness.new()
	restraintData.setLevel(calculateBestRestraintLevel())

func getTakingOffStringLong(withS):
	if(withS):
		return "unbuckles and wiggles out of your harness"
	else:
		return "unbuckle and wiggle out of your harness"

func getPuttingOnStringLong(withS):
	if(withS):
		return "straps your body down into the harness"
	else:
		return "strap your body down into the harness"

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize()+" was forced onto you. The straps squeeze your body and restrict your movement."
	else:
		return getAStackNameCapitalize()+" was forced onto {receiver.name}. The straps restrict and squeeze {receiver.his}'s body"

func getRiggedParts(_character):
	return {
		"harness": "res://Modules/BBMoreUniforms/Harnesses/ChestHarness/ChestHarness.tscn",
	}

func getInventoryImage():
	return "res://Modules/BBMoreUniforms/ItemIcons/GreyRope.png"
