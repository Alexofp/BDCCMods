extends "res://Player/Player3D/Parts/Part3D.gd"

onready var bodywidepng = $bodywidepng
onready var breasts_scalable_001 = $PartStatePicker/PartState/breastsScalable001

func setColor(newColor):
	for theMesh in [bodywidepng, breasts_scalable_001]:
		var theMat:ShaderMaterial = getShaderMatUnique(theMesh)
		if(!theMat):
			continue
		theMat.set_shader_param("color_r", newColor)

func updateFromItem(_item):
	if(!(_item.itemState is BraState)):
		return
	var _state:BraState = _item.itemState
	var _dam:bool = _state.clothesDamaged
	breasts_scalable_001.visible = !_state.pulledUp
	
	if(_item.id == "LaceBra"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/body_lace.png" if !_state.pulledUp else "res://Modules/BBMoreUniforms/Underwear/body_laceOpen.png")
		setShaderMatTexturePath(breasts_scalable_001, "res://Modules/BBMoreUniforms/Underwear/breasts_lace.png")
	elif(_item.id == "sportyTop"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/body_sporty.png" if !_state.pulledUp else "res://Modules/BBMoreUniforms/Underwear/body_sportyOpen.png")
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/bra_sporty_ColorMask.png" if !_state.pulledUp else "res://Modules/BBMoreUniforms/Underwear/body_sportyOpen_ColorMask.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_b", ColorN("white",1))
		setShaderMatTexturePath(breasts_scalable_001, "res://Modules/BBMoreUniforms/Underwear/breasts_sporty.png")
	elif(_item.id == "chestwraps"):
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Bra/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Bra/bodyOpen.png")
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Misc Clothes/ChestWraps/ChestWraps.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
		setShaderMatTexturePath(breasts_scalable_001, "res://Modules/BBMoreUniforms/Misc Clothes/ChestWraps/ChestWrapsBreasts.png", "texture_colormask")
		theMat = getShaderMatUnique(breasts_scalable_001)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
	elif(_item.id == "cowbra"):
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Bra/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Bra/bodyOpen.png")
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Misc Clothes/CowBra/CowPrintBra.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
		setShaderMatTexturePath(breasts_scalable_001, "res://Modules/BBMoreUniforms/Misc Clothes/CowBra/CowPrintBreasts.png", "texture_colormask")
		theMat = getShaderMatUnique(breasts_scalable_001)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
	else:
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Bra/body.png" if !_state.pulledUp else "res://Inventory/RiggedModels/Bra/bodyOpen.png")
		setShaderMatTexturePath(breasts_scalable_001, "res://Inventory/RiggedModels/Bra/breasts.png")
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")
	
	for theMesh in [bodywidepng, breasts_scalable_001]:
		var theMat:ShaderMaterial = getShaderMatUnique(theMesh)
		if(!theMat):
			continue
		theMat.set_shader_param("damage", 0.25 if _dam else 0.0)
