extends "res://Player/Player3D/Parts/Part3D.gd"

onready var bodywidepng = $bodywidepng
onready var legup_deformable = $legupDeformable

func setColor(newColor):
	for theMesh in [bodywidepng, legup_deformable]:
		var theMat:ShaderMaterial = getShaderMatUnique(theMesh)
		if(!theMat):
			continue
		theMat.set_shader_param("color_r", newColor)

func updateFromItem(_item):
	if(!(_item.itemState is PantiesState)):
		return
	var _state:PantiesState = _item.itemState
	var _dam:bool = _state.clothesDamaged
	
	legup_deformable.visible = _state.pulledDown
	bodywidepng.visible = !_state.pulledDown
	if(_item.id == "LacePanties"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Underwear/panties_lace.png" if !_state.arePantiesShiftedAside() else "res://Modules/BBMoreUniforms/Underwear/panties_lace_pulledaside.png")
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Underwear/panties_laceDown.png")
	elif(_item.id == "cowpanties"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Misc Clothes/CowPanties/Cowpanties.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
		theMat = getShaderMatUnique(legup_deformable)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
	elif(_item.id == "pussytape"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Misc Clothes/PussyTape/PussyTape.png")
		legup_deformable.visible = false
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")
#		setColor(ColorN("white",1))
	else:
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/Panties/panties.png" if !_state.arePantiesShiftedAside() else "res://Modules/BBMoreUniforms/Underwear/panties_pulledaside.png")
		setShaderMatTexturePath(legup_deformable, "res://Inventory/RiggedModels/Panties/pantiesDown.png")
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")
	
	for theMesh in [bodywidepng, legup_deformable]:
		var theMat:ShaderMaterial = getShaderMatUnique(theMesh)
		if(!theMat):
			continue
		theMat.set_shader_param("damage", 0.25 if _dam else 0.0)
