extends "res://Modules/BBMoreUniforms/Overrides/InmageUniformGeneral.gd"

func _init():
	id = "inmateuniformHighsec"
	inmateType = InmateType.HighSec

func getTags():
	return [
		ItemTag.HighSecurityInmateUniform,
		]
