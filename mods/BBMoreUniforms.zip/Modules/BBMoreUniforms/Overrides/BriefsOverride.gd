extends "res://Player/Player3D/Parts/Part3D.gd"

onready var bodywidepng = $bodywidepng
onready var legup_deformable = $legupDeformable
onready var legup_deformable_001 = $legupDeformable001

func setColor(newColor):
	for theMesh in [bodywidepng, legup_deformable, legup_deformable_001]:
		var theMat:ShaderMaterial = getShaderMatUnique(theMesh)
		if(!theMat):
			continue
		theMat.set_shader_param("color_r", newColor)

func updateFromItem(_item):
	if(!(_item.itemState is PantiesState)):
		return
	var _state:PantiesState = _item.itemState
	var _dam:bool = _state.clothesDamaged
	bodywidepng.visible = !_state.arePantiesPulledDown()
	if(_item.id == "sportyBriefs"):
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Underwear/leg_sporty.png")
		setShaderMatTexturePath(legup_deformable_001, "res://Modules/BBMoreUniforms/Underwear/leg_sporty.png")
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Underwear/leg_sporty_ColorMask.png", "texture_colormask")
		setShaderMatTexturePath(legup_deformable_001, "res://Modules/BBMoreUniforms/Underwear/leg_sporty_ColorMask.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(legup_deformable)
		theMat.set_shader_param("color_b", ColorN("white",1))
		theMat = getShaderMatUnique(legup_deformable_001)
		theMat.set_shader_param("color_b", ColorN("white",1))
	elif(_item.id == "cowbriefs"):
		setShaderMatTexturePath(bodywidepng, "res://Modules/BBMoreUniforms/Misc Clothes/CowBriefs/cowbriefbody.png", "texture_colormask")
		var theMat:ShaderMaterial = getShaderMatUnique(bodywidepng)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
		setShaderMatTexturePath(legup_deformable, "res://Modules/BBMoreUniforms/Misc Clothes/CowBriefs/cowbriefleg.png", "texture_colormask")
		theMat = getShaderMatUnique(legup_deformable)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
		setShaderMatTexturePath(legup_deformable_001, "res://Modules/BBMoreUniforms/Misc Clothes/CowBriefs/cowbriefleg.png", "texture_colormask")
		theMat = getShaderMatUnique(legup_deformable_001)
		theMat.set_shader_param("color_r", ColorN("white",1))
		theMat.set_shader_param("color_g", ColorN("black",1))
	else:
		setShaderMatTexturePath(legup_deformable, "res://Inventory/RiggedModels/Briefs/leg.png")
		setShaderMatTexturePath(legup_deformable_001, "res://Inventory/RiggedModels/Briefs/leg.png")
		setShaderMatTexturePath(bodywidepng, "res://Inventory/RiggedModels/InmateUniform/Textures/red.png", "texture_colormask")
	#legup_deformable.visible = bodywidepng.visible
	#legup_deformable_001.visible = bodywidepng.visible
	var theMat1:ShaderMaterial = getShaderMatUnique(legup_deformable)
	if(theMat1):
		theMat1.set_shader_param("uv1_offset", Vector2(0.0, -0.15 if !bodywidepng.visible else 0.0))
	var theMat2:ShaderMaterial = getShaderMatUnique(legup_deformable_001)
	if(theMat2):
		theMat2.set_shader_param("uv1_offset", Vector2(0.0, -0.15 if !bodywidepng.visible else 0.0))
	
	for theMesh in [bodywidepng, legup_deformable, legup_deformable_001]:
		var theMat:ShaderMaterial = getShaderMatUnique(theMesh)
		if(!theMat):
			continue
		theMat.set_shader_param("damage", 0.25 if _dam else 0.0)
