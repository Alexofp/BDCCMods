extends ItemBase

var prisonerNumber = ""
var inmateType = InmateType.General

func _init():
	id = "inmateuniform"

func getVisibleName():
	return InmateType.getOfficialName(inmateType).capitalize() + " inmate uniform"
	
func setPrisonerNumber(newnumber):
	prisonerNumber = newnumber
	
func setInmateType(newtype):
	inmateType = newtype
	
func getDescription():
	var text = "A short sleeved shirt and some shorts, both are made out of black cloth with "+InmateType.getColorName(inmateType)+" trim."

	if(prisonerNumber != null && prisonerNumber != ""):
		text += " The shirt has a prisoner number attached to it that says \""+prisonerNumber+"\""
	
	return text

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		]

func getTags():
	return [
		ItemTag.GeneralInmateUniform,
		]

func saveData():
	var data = .saveData()
	
	data["prisonerNumber"] = prisonerNumber
	data["inmateType"] = inmateType
	
	return data
	
func loadData(data):
	.loadData(data)
	
	prisonerNumber = SAVE.loadVar(data, "prisonerNumber", "")
	inmateType = SAVE.loadVar(data, "inmateType", InmateType.General)

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your inmate shirt and pulls down the shorts"
	else:
		return "take off your inmate shirt and pull down the shorts"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your inmate shirt and the shorts"
	else:
		return "put on your inmate shirt and the shorts"

func generateItemState():
	itemState = ShirtAndShortsState.new()
	itemState.canActuallyBeDamaged = true # Is hack because there are many clothes that use this state already and don't support damaging..

func useInCombat(_attacker, _receiver):
	var text := "You toggle!"
	
	if(itemState is ShirtAndShortsState):
		if(itemState.noPants):
			return "You've already removed the shorts, just get naked you slut"
		itemState.noShirt = !itemState.noShirt
		if(itemState.noShirt):
			text = "You take the shirt off!"
		else:
			text = "You put the shirt on!"
	
	if(isWornByWearer()):
		updateWearerAppearance()
	
	return text

func getPossibleActions():
	if(!isWornByWearer()):
		return []
	return [
		{
			"name": "Toggle shirt",
			"scene": "UseItemLikeInCombatScene",
			"description": "Choose if you want to wear the shirt too or just the shorts",
		},
		{
			"name": "More Options",
			"scene": "ClothingAdjustState",
			"description": "How naked do you want to be while still technically wearing something?",
		},
	]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	
	return {
		"clothing": "res://Modules/BBMoreUniforms/Overrides/InmateUniformOverride.tscn",
	}

func getInventoryImage():
	if(inmateType == InmateType.SexDeviant):
		return "res://Images/Items/equipment/shirtlilac.png"
	if(inmateType == InmateType.HighSec):
		return "res://Images/Items/equipment/shirtred.png"
	return "res://Images/Items/equipment/shirtorange.png"
