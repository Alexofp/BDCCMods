extends "res://Modules/BBMoreUniforms/Overrides/PlainPantiesOverride.gd"

func _init():
	id = "MirriPanties"
	clothesColor = Color("#0E446E")

func getVisibleName():
	return "Mirri's panties"
	
func getDescription():
	var text = "Simple panties with a stripped pattern on them."

	return text

func getPrice():
	return 30

func getTags():
	return [
		]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"panties": "res://Modules/BBMoreUniforms/Overrides/PantiesStrippedOverride.tscn",
	}
