extends "res://Modules/BBMoreUniforms/Overrides/InmageUniformGeneral.gd"
func _init():
	id = "inmateuniformSexDeviant"
	inmateType = InmateType.SexDeviant

func getTags():
	return [
		ItemTag.SexualDeviantInmateUniform,
		]
