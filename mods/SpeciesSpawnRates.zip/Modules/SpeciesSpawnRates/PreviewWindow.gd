extends CanvasLayer

var module = null # SpeciesSpawnRates Module
var speciesID = ""
var dynamicCharacter = null

onready var doll = $Dim/Panel/VBox/HBox/DollWrapper/Viewport/Doll3D
onready var titleLabel = $Dim/Panel/VBox/Title
onready var infoLabel = $Dim/Panel/VBox/HBox/Info
onready var speciesList = $Dim/Panel/VBox/Buttons/SpeciesList

func _ready():
	var index = 0
	for theID in module.speciesOrder:
		speciesList.add_item(GlobalRegistry.getSpecies(theID).getVisibleName())
		if(theID == speciesID):
			speciesList.select(index)
		index += 1
	generate()

func generate():
	if(dynamicCharacter != null && is_instance_valid(dynamicCharacter)):
		dynamicCharacter.queue_free()
	dynamicCharacter = null

	# Same approach as the datapack skin editor: works in the main menu without GM.main
	var theGenerator:CharacterGeneratorBase = CharacterGeneratorBase.new()
	dynamicCharacter = theGenerator.generate({"editor_noequip": true, "addtonode": self, NpcGen.Gender: RNG.pick(NpcGender.getAll()), NpcGen.Species: speciesID})
	removeBrokenBodyparts()
	doll.prepareCharacter(dynamicCharacter)
	updateInfo()

# Bodyparts from mods can point to missing files (e.g. a mod built for an older version of another mod).
# Loading such a doll scene fails and the doll would crash, so those parts are removed and listed instead.
var brokenParts = []
func removeBrokenBodyparts():
	brokenParts = []
	var bodyparts = dynamicCharacter.getBodyparts()
	for slot in bodyparts.keys():
		var bodypart = bodyparts[slot]
		if(bodypart == null):
			continue
		var scenePath = bodypart.getDoll3DScene()
		if(scenePath == null || scenePath == ""):
			continue
		if(!ResourceLoader.exists(scenePath) || load(scenePath) == null):
			brokenParts.append(str(bodypart.id)+" ("+scenePath.get_file()+")")
			Log.printerr("[SpeciesSpawnRates] Broken doll scene for bodypart "+str(bodypart.id)+": "+scenePath)
			dynamicCharacter.removeBodypart(slot, false)

func updateInfo():
	var species = GlobalRegistry.getSpecies(speciesID)
	titleLabel.text = "Preview: "+species.getVisibleName()

	var text = ""
	if(dynamicCharacter != null):
		text += "[b]"+dynamicCharacter.getName()+"[/b]\n"
		text += "Gender: "+NpcGender.getVisibleName(dynamicCharacter.npcGeneratedGender)+"\n"
		text += "Species: "+species.getVisibleName()+"\n\n"
	if(brokenParts.size() > 0):
		text += "[color=#ff6666]Broken bodyparts (missing files, would crash the game):\n"
		for brokenPart in brokenParts:
			text += "- "+brokenPart+"\n"
		text += "[/color]\n"

	text += "[b]Spawn chances (current sliders):[/b]\n"
	var chances = module.getChances()
	for theID in module.speciesOrder:
		var line = GlobalRegistry.getSpecies(theID).getVisibleName()+": "+str(Util.roundF(chances[theID], 1))+"%"
		if(theID == speciesID):
			line = "[color=#ffcc44]> "+line+"[/color]"
		elif(chances[theID] <= 0.0):
			line = "[color=#777777]"+line+"[/color]"
		text += line+"\n"
	infoLabel.bbcode_text = text

func _on_RerollButton_pressed():
	generate()

func _on_SpeciesList_item_selected(index):
	speciesID = module.speciesOrder[index]
	generate()

func _on_CloseButton_pressed():
	queue_free()

func _input(event):
	if(event.is_action_pressed("ui_cancel")):
		get_tree().set_input_as_handled()
		queue_free()
