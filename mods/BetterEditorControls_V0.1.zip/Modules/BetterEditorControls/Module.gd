extends Module

var debug = false # Debug - save modified code to user folder
var hooksHolder = [] # Hold them in memory, our changes don't exist on disk at res://

func _init():
	id = "BetterEditorControls"
	author = "Astro"
	
	initMindsFileHandleing()
	

# Note: hooks arrangement is as follows:
# var hooks = [ targetFile1, [
#	[ PlaceBeforeTarget1, Target1, PlaceAfterTarget1 ], 
#	[ PlaceBeforeTarget2, Target2, PlaceAfterTarget2 ],
#	]],
# [ targetFile2, [
#	[ PlaceBeforeTarget3, Target3, PlaceAfterTarget3 ],
#	]],
# ]
# Note: Make sure your \n and \t are correct or the script won't parse!
# Tip: You can use +\ to split the string over multiple lines making it easier to read.

var hooks = [
	#Replace the link to the old character editor with the the link to the improved one:
	["res://Game/Datapacks/UI/PackVarUIs/EditorVarUI.gd",[[
		'var charEditor = load("res://Modules/BetterEditorControls/Files/DatapackCharacterEditor.tscn").instance()' + "\n\t\t#",
		'var charEditor = load("res://Game/Datapacks/UI/Editors/DatapackCharacterEditor.tscn").instance()', ""],
	]],
]	

#Credit to Mindstormsman for all of the file handleing code, I implemented it in my 
#Expanded Bodyparts mod and I basicaly just copy-pasted it from there and changed the mod's name.
func exportModifiedFile(fileName, fileContent):
	var file = File.new()
	var path = "user://(BetterEditorControls) Mind's_Hooks_Debug_Exports/"
	var fullPath = path + fileName
	print("Exporting to "+ fullPath)
	var error = file.open(fullPath, File.WRITE)
	if(!error):
		file.store_line(fileContent)
		file.close()
	else: print("Error "+str(error)+" opening path: "+fullPath)

func initMindsFileHandleing():
	if OS.has_feature("editor"):
		debug = true

	if(debug):
		var dir = Directory.new()
		var error = dir.make_dir("user://(BetterEditorControls) Mind's_Hooks_Debug_Exports")
		if(error and (error != 32)):
			print("Error "+str(error)+" creating directory user://(BetterEditorControls) Mind's_Hooks_Debug_Exports")
			debug = false

	for target in hooks:
		var codeBase = load(target[0])
		var originalCode = codeBase.source_code
		var modifiedCode = originalCode
		for hook in target[1]:
			modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
		codeBase.source_code = modifiedCode
		var error = codeBase.reload()
		if( error != 0):
			print("Error code "+str(error)+" reloading target at path: "+target[0])
		hooksHolder.append(codeBase)
		if(debug): exportModifiedFile(target[0].get_file(), modifiedCode)

	print("(BetterEditorControls): Mind's Hooks Applied")
	return
