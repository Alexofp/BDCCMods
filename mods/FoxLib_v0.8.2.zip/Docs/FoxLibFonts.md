# FoxLib Fonts

FoxLib has a custom font API, and itself bundle a Runic font by default.

## Using builtin Runic font!

The runnic font can be used by printing the following in the say box: `[runic]ᚺᛖᚱ ᛚᛁᛈᛋ ᛒᛖᚷᚨᚾ ᛏᛟ ᛋᚲᛟᚱᚲᚺ[/runic]`

## Adding a new dynamic font

To add a font and make them available for the say box you first need to make a font file, like `MyFont.ttf`

Then you need to make a `.tres` file next to it, for `MyFont.ttf` your `.tres` file must be named `MyFont.ttf.tres`, and contain the following:

```
[gd_resource type="DynamicFont" load_steps=2 format=2]

[sub_resource type="DynamicFontData" id=1]
font_path = "res://Modules/MyModule/MyFont.ttf"

[resource]
size = 20
use_mipmaps = true
use_filter = true
font_data = SubResource( 1 )
```

And then you can call `FoxFonts.addFallbackFont("res://Modules/MyModule/MyFont.ttf", false, "myfont")` inside your module `_init():`.

This will allow everyone to use `[myfont]This is a cool font![/myfont]` inside their mods and datapacks.

