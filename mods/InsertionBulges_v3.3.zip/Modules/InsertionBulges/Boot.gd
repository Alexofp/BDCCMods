const MARKERS := [
	"res://Player/Player3D/Bulge2/Driver.gd",
	"res://Player/Player3D/Bulge/BulgeDoll.gd",
]
const DECISION_META := "insertionbulges_v3_may_run"
const VERSION := "3.3"
static func blockedBy(paths:Array) -> Array:
	var found:Array = []
	var f := File.new()
	for path in paths:
		if(f.file_exists(path)):
			found.append(path)
	return found
static func mayRun(from:String = "?") -> bool:
	var tree = Engine.get_main_loop()
	if(tree == null || !(tree is SceneTree)):
		return blockedBy(MARKERS).empty()
	if(tree.has_meta(DECISION_META)):
		return bool(tree.get_meta(DECISION_META))
	var found:Array = blockedBy(MARKERS)
	tree.set_meta(DECISION_META, found.empty())
	if(!found.empty()):
		loud("REFUSING TO RUN: InsertionBulges v3 and InsertionBulges v1/v2 are mutually exclusive," \
			+ " and an older one is mounted (found " + PoolStringArray(found).join(", ") + ")." \
			+ " Unmount either pack and restart. v3 draws nothing this session; the older mod is" \
			+ " unaffected. [hook=" + from + "]")
	return found.empty()
static func loud(line:String) -> void:
	var text := "!!! InsertionBulges v3: " + line
	push_error(text)
	say(text)
static func say(text:String) -> void:
	print(text)
	var loop := Engine.get_main_loop()
	if(loop != null && loop.has_method("get_root")):
		var console = loop.get_root().get_node_or_null("Console")
		if(console != null && console.has_method("printLine")):
			console.printLine(text)
const CARRIED := [
	"res://Player/Player3D/Parts/MeshWithPattern.gd",
	"res://Player/Player3D/Parts/Part3D.gd",
	"res://Player/Player3D/Skins/MaterialForPartWithSkin.tres",
]
const CARRIED_VERSION := "2.0"
const MARKER_TAG := "IB-CARRIED"
const MARKER_MOD := "InsertionBulges"
const CARRIED_CURRENT := "current mod copy"
const CARRIED_OLDER := "older mod copy"
const CARRIED_UNMARKED := "unmarked"
const CARRIED_MISSING := "missing"
static func markerIn(text:String) -> Dictionary:
	var at:int = text.find(MARKER_TAG)
	if(at < 0):
		return {}
	var line:String = text.substr(at, -1)
	var cut:int = line.find("\n")
	if(cut >= 0):
		line = line.substr(0, cut)
	var out := {}
	for raw in line.split(" ", false):
		var token:String = raw
		var eq:int = token.find("=")
		if(eq <= 0):
			continue
		out[token.substr(0, eq)] = token.substr(eq + 1, -1).rstrip("\"")
	if(!out.has("file") || !out.has("mod") || !out.has("v")):
		return {}
	return out
static func audit(paths:Array = CARRIED) -> Dictionary:
	var out := {}
	var f := File.new()
	for raw in paths:
		var path:String = raw
		var fileName:String = path.get_file()
		var row := {"path": path, "state": CARRIED_MISSING, "version": "", "mod": "", "md5": ""}
		if(f.file_exists(path) && f.open(path, File.READ) == OK):
			var text:String = f.get_as_text()
			f.close()
			row["md5"] = f.get_md5(path)
			var marker:Dictionary = markerIn(text)
			if(marker.empty() || str(marker["file"]) != fileName || str(marker["mod"]) != MARKER_MOD):
				row["state"] = CARRIED_UNMARKED
			else:
				row["version"] = str(marker["v"])
				row["mod"] = str(marker["mod"])
				row["state"] = CARRIED_CURRENT if str(marker["v"]) == CARRIED_VERSION else CARRIED_OLDER
		out[fileName] = row
	return out
const SRC_ENGINE := "engine"
const SRC_ORAL_HINT := "oralhint"
const SRC_TAPER := "taper"
const SRC_DECLARATION := "declaration"
const SRC_GEOMETRY := "geometry"
const SOURCE_READABLE := "readable"
const SOURCE_UNREADABLE := "unreadable"
const SOURCE_SILENT := "nothing to say"
const SOURCE_PROBE := "res://Player/StageScene3D/Scenes/SexOral.gd"
const NEEDS_SCRIPT_TEXT := "the stage scene script's own source text"
const NEEDS_ENGINE := "a sex activity driving the scene, read through the engine's own hasTag()"
const NEEDS_TAPER := "a posed skeleton with one of v1's taper bones on the shaft chain"
const NEEDS_GEOMETRY := "shaft and hole vectors measured off the dolls on screen"
const NO_ENGINE_AT_BOOT := "no boot probe: there is no activity yet, and no activity is this" \
	+ " source's own \"nothing to say\" (EngineSource.gd:64) rather than a failure to read"
const NO_TAPER_AT_BOOT := "no boot probe: nothing is posed, and Providers.taperOf answers null -" \
	+ " nothing to say - for every one of its four ways of finding nothing"
const NO_GEOMETRY_AT_BOOT := "no boot probe: nothing is on screen to measure. This is the source" \
	+ " left standing when the two parsing sources go unreadable, and PLAN 4.7 is that it must not" \
	+ " act alone"
static func textStateOf(script) -> Dictionary:
	if(script == null || !(script is GDScript)):
		return {"state": SOURCE_SILENT, "detail": "no script to probe"}
	if(str(script.source_code) == ""):
		return {"state": SOURCE_UNREADABLE, "detail": "script text is empty - a bytecode export"}
	return {"state": SOURCE_READABLE, "detail": str(script.source_code.length()) + " chars read"}
static func sourceAudit(probe = SOURCE_PROBE) -> Dictionary:
	var script = probe
	var where:String = "handed in directly"
	if(typeof(probe) == TYPE_STRING):
		where = str(probe)
		script = null
		if(ResourceLoader.exists(where)):
			script = load(where)
	var parsed:Dictionary = textStateOf(script)
	var detail:String = str(parsed["detail"]) + " (" + where + ")"
	var state:String = str(parsed["state"])
	var out := {}
	out[SRC_ENGINE] = sourceRow(SRC_ENGINE, SOURCE_SILENT, NEEDS_ENGINE, NO_ENGINE_AT_BOOT)
	out[SRC_ORAL_HINT] = sourceRow(SRC_ORAL_HINT, state, NEEDS_SCRIPT_TEXT, detail)
	out[SRC_TAPER] = sourceRow(SRC_TAPER, SOURCE_SILENT, NEEDS_TAPER, NO_TAPER_AT_BOOT)
	out[SRC_DECLARATION] = sourceRow(SRC_DECLARATION, state, NEEDS_SCRIPT_TEXT, detail)
	out[SRC_GEOMETRY] = sourceRow(SRC_GEOMETRY, SOURCE_SILENT, NEEDS_GEOMETRY, NO_GEOMETRY_AT_BOOT)
	return out
static func sourceRow(id:String, state:String, needs:String, detail:String) -> Dictionary:
	return {"source": id, "state": state, "needs": needs, "detail": detail}
const BOOT_MAGIC := "bulge3-boot"
const BACKEND_LIVE := "H1"
const INTEGRATION_LIVE := "live"
const INTEGRATION_REFUSED := "refused"
const CARRIED_ORDER := [CARRIED_CURRENT, CARRIED_OLDER, CARRIED_UNMARKED, CARRIED_MISSING]
const SOURCE_ORDER := [SOURCE_READABLE, SOURCE_UNREADABLE, SOURCE_SILENT]
static func slug(text:String) -> String:
	return text.replace(" ", "-")
static func tally(rows:Dictionary, order:Array) -> String:
	var counts := {}
	for key in rows:
		var state:String = str(rows[key]["state"])
		counts[state] = int(counts.get(state, 0)) + 1
	var parts := PoolStringArray()
	for state in order:
		if(counts.has(state)):
			parts.append(str(counts[state]) + "-" + slug(str(state)))
	for state in counts:
		if(!order.has(state)):
			parts.append(str(counts[state]) + "-" + slug(str(state)))
	return str(rows.size()) + "/" + parts.join(",")
static func bootLine(carried:Dictionary = audit(), sources:Dictionary = sourceAudit()) -> String:
	return BOOT_MAGIC \
		+ " mod=" + VERSION \
		+ " integration=" + (INTEGRATION_LIVE if mayRun("bootLine") else INTEGRATION_REFUSED) \
		+ " carried=" + tally(carried, CARRIED_ORDER) \
		+ " sources=" + tally(sources, SOURCE_ORDER) \
		+ " backend=" + BACKEND_LIVE
const BOOT_LINE_META := "insertionbulges_v3_boot_line"
static func sayBootLineOnce() -> bool:
	var tree = Engine.get_main_loop()
	if(tree != null && tree is SceneTree):
		if(tree.has_meta(BOOT_LINE_META)):
			return false
		tree.set_meta(BOOT_LINE_META, true)
	say(bootLine())
	return true
const Backends := preload("res://Bulge3/Present/Backends.gd")
const BACKENDS_MAGIC := "bulge3-backends"
const BACKENDS_NONE := "none"
const BACKENDS_LINE_META := "insertionbulges_v3_backends_line"
static func gles2Mode() -> bool:
	var loop := Engine.get_main_loop()
	if(loop != null && loop.has_method("get_root")):
		var registry = loop.get_root().get_node_or_null("GlobalRegistry")
		if(registry != null && typeof(registry.get("gles2Mode")) == TYPE_BOOL):
			return bool(registry.get("gles2Mode"))
	return OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2
static func backendsOffered() -> Dictionary:
	var gles2:bool = gles2Mode()
	return Backends.probe(gles2, !gles2)
static func backendsLine(probed:Dictionary = backendsOffered()) -> String:
	var ids:Array = []
	for id in Backends.BACKENDS:
		if(probed.has(id)):
			ids.append(id)
	for id in probed:
		if(!Backends.BACKENDS.has(id)):
			ids.append(id)
	var runs := PoolStringArray()
	var refused := PoolStringArray()
	for id in ids:
		var reason:String = str(probed[id])
		if(reason == ""):
			runs.append(str(id))
		else:
			refused.append(str(id) + ":" + slug(reason))
	return BACKENDS_MAGIC \
		+ " runs=" + (runs.join(",") if runs.size() > 0 else BACKENDS_NONE) \
		+ " refused=" + (refused.join(",") if refused.size() > 0 else BACKENDS_NONE)
static func sayBackendsLineOnce() -> bool:
	var tree = Engine.get_main_loop()
	if(tree != null && tree is SceneTree):
		if(tree.has_meta(BACKENDS_LINE_META)):
			return false
		tree.set_meta(BACKENDS_LINE_META, true)
	say(backendsLine())
	return true
