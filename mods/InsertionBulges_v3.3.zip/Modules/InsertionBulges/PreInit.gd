const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
func _init():
	var _mayRun:bool = Boot.mayRun("PreInit")
