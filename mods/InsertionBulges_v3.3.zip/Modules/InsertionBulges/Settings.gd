const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const DECLARED := {
"bulgesEnabled": {
	"value": true, "unit": "on/off", "owner": "PRESENT",
	"source": "Player/Player3D/Bulge2/Renderer.gd:239",
	"note": "THE OFF SWITCH - PLAN §18's first stated minimum. v2 reads it through option() with a" \
		+ " literal fallback of true and the game has no such option, so today it resolves to the" \
		+ " compiled default and the mod cannot be turned off. That IS §4.8.",
},
"advancedShadersEnabled": {
	"value": true, "unit": "on/off", "owner": "PRESENT",
	"source": "Player/Player3D/Bulge2/Renderer.gd:239",
	"note": "THE GAME'S OWN, and the only option name the mod reads that actually exists in the game" \
		+ " (Game/Options/GlobalOptions.gd:98, in the options menu at :662). It is here so that the" \
		+ " game-option layer has something real to answer for and so that a stored mod setting for" \
		+ " it can be shown LOSING to the player's own choice, which is the top of the ladder.",
},
"bulgeLag": {
	"value": true, "unit": "on/off", "owner": "COMMIT",
	"source": "PLANS/6",
	"note": "the swelling follows the shaft with a spring instead of jumping; on every pipeline",
},
"bulgeLagInflate": {
	"value": 0.8, "unit": "0-1 speed", "owner": "COMMIT",
	"source": "PLANS/6",
	"note": "how fast the swelling grows, Spring.hzFor: 0 is 0.5 Hz, 0.5 is 3 Hz, 1 is 5.5 Hz",
},
"bulgeLagDeflate": {
	"value": 0.25, "unit": "0-1 speed", "owner": "COMMIT",
	"source": "PLANS/6",
	"note": "how fast it goes down again, same scale",
},
"bulgeUnionOverlap": {
	"value": 1.0, "unit": "0-1", "owner": "PRESENT",
	"source": "PLANS/16",
	"note": "0 is the bigger swelling only, 1 the plain sum; each DP swelling is drawn 1/(1+this) as tall",
},
"bulgeReachDeeper": {
	"value": 0.0, "unit": "0-1", "owner": "STAGE",
	"source": "PLANS/16",
	"note": "0 is today's ceiling (reach 0.5, push 0.33); 1 is reach 1.0, push 0.66",
},
"bulgeOtherHalfFollow": {
	"value": 0.2, "unit": "0-1", "owner": "STAGE",
	"source": "PLANS/15",
	"note": "0 is today's mirrored radius, 1 follows the half of the shaft facing the skin; same size",
},
"bulgeOtherHalfAdd": {
	"value": 0.5, "unit": "0-1", "owner": "STAGE",
	"source": "PLANS/15",
	"note": "adds the facing half's own variation on top: its bumps stand out more, peaks grow",
},
"bulgeBellyVariant": {
	"value": "blend", "unit": "off/fade/bone/blend", "owner": "PRESENT",
	"source": "PLANS/17",
	"note": "on a pregnant doll: fade the swelling, push the belly bone, or both",
},
"bulgePushRadial": {
	"value": 0.0, "unit": "0-1", "owner": "PRESENT", "source": "PLANS/34",
	"note": "0 pushes the whole swelling one way; 1 pushes each point away from the shaft's line",
},
"bulgeDirection": {
	"value": "blend", "unit": "blend/shaft/belly/torso", "owner": "STAGE", "source": "PLANS/32",
	"note": "which way the band runs: between hole and shaft (as before), along the shaft, along the" \
		+ " belly's edge, or along the torso",
},
"bulgeLipAmount": {
	"value": 0.2, "unit": "0-1", "owner": "STAGE", "source": "PLANS/35",
	"note": "how far the skin at the entry opens round the shaft, as a share of the shaft's girth there",
},
"bulgeLipMotion": {
	"value": "out", "unit": "open/out/in/open_stroke", "owner": "STAGE", "source": "PLANS/35",
	"note": "how the skin at the entry moves: widens round it, is pulled out along the shaft, or pushed in",
},
"bulgeTipRound": {
	"value": 0.0, "unit": "0-1", "owner": "PRESENT", "source": "PLANS/37",
	"note": "how early the band's tip end rounds off: 0 keeps it full to the end, 0.75 is Field.BAND_PLATEAU 0.25, 1 rounds from the middle; shipped 0",
},
"bulgeLipAnchor": {
	"value": "hole", "unit": "hole/outline", "owner": "STAGE", "source": "PLANS/38",
	"note": "where the mouth sits: the hole's own point, or where the shaft crosses the body's outline",
},
"bulgeStartAtMouth": {
	"value": false, "unit": "on/off", "owner": "STAGE", "source": "PLANS/38",
	"note": "the swelling's band starts at the mouth on the outline instead of past the hole",
},
"bulgeEndFade": {
	"value": 1.0, "unit": "0-1", "owner": "STAGE", "source": "PLANS/42",
	"note": "how far the band's ends fade: 1 is as before (about three girths), 0 is Intent.END_FADE_MIN of it",
},
"bulgePipeline": {
	"value": "brush", "unit": "pipeline name", "owner": "PRESENT", "source": "PLANS/20",
	"note": "brush is the baked backend with the measured band; classic the three shader slots",
},
"bulgeLagTravel": {
	"value": true, "unit": "on/off", "owner": "COMMIT", "source": "PLANS/44",
	"note": "the band's place and length ride the spring too, so the bulge's travel trails the cock",
},
"bulgeLagWobble": {
	"value": 0.6, "unit": "0-1", "owner": "COMMIT", "source": "PLANS/20",
	"note": "0 is zeta 1.0, 0.6 is 0.7, 1 is 0.5",
},
"bulgeBellyGain": {
	"value": 0.6, "unit": "0-1", "owner": "PRESENT", "source": "PLANS/20",
	"note": "0 pushes nothing, 0.6 is gain 1.2, 1 is gain 2.0",
},
"bulgeSizeModifier": {
	"value": 0.6, "unit": "multiplier", "owner": "STAGE", "source": "PLANS/18",
	"note": "the swelling's size; 0 draws nothing",
},
"bulgeInsertedGirth": {
	"value": 0.0, "unit": "0-1", "owner": "STAGE", "source": "PLANS/18",
	"note": "0 sizes by the girth at the entrance, 1 by the mean over the inserted length",
},
"bulgeShade": {
	"value": 0.0, "unit": "0-1", "owner": "PRESENT", "source": "PLANS/18",
	"note": "shading painted onto the swelling",
},
"bulgeRimShape": {
	"value": 1.0, "unit": "0-1", "owner": "PRESENT", "source": "PLANS/18",
	"note": "0 the ruled rim, 1 the cross-section of what is inside",
},
"bulgeShapeFidelity": {
	"value": 0.8, "unit": "0-1", "owner": "STAGE", "source": "PLANS/18",
	"note": "how closely the swelling follows the shaft's outline",
},
"bulgeThroatPath": {
	"value": "neck", "unit": "neck/body", "owner": "STAGE", "source": "PLANS/47",
	"note": "neck: the throat swells in one piece along the neck (as before); body: like the other holes, past the mouth-to-throat curve and down the body",
},
"bulgeOralSimpleSize": {"value": 0.8, "unit": "multiplier", "owner": "STAGE", "source": "PLANS/52",
	"note": "the Simple throat's size (3.2's bulgeSizeModifier default)"},
"bulgeOralThroatStretch": {"value": true, "unit": "on/off", "owner": "STAGE", "source": "PLANS/54",
	"note": "the throat's entrance opens round the cock as it passes (Detailed, brush drawing)"},
"bulgeOralSwallow": {"value": false, "unit": "on/off", "owner": "COMMIT", "source": "PLANS/54",
	"note": "a narrowing ring runs down the throat while the cock rests (Detailed)"},
"bulgeOralMouthLength": {"value": 0.4, "unit": "0-1", "owner": "STAGE", "source": "PLANS/52",
	"note": "how far the throat's spring keeps the cock's own direction at the mouth (Like the other holes)"},
"bulgeOralSize": {"value": 0.6, "unit": "multiplier", "owner": "STAGE", "source": "PLANS/48",
	"note": "bulgeSizeModifier for the throat"},
"bulgeOralShapeFidelity": {"value": 1.0, "unit": "0-1", "owner": "STAGE", "source": "PLANS/48",
	"note": "bulgeShapeFidelity for the throat"},
"bulgeOralOtherHalfAdd": {"value": 0.49, "unit": "0-1", "owner": "STAGE", "source": "PLANS/48",
	"note": "bulgeOtherHalfAdd for the throat"},
"bulgeOralOtherHalfFollow": {"value": 0.2, "unit": "0-1", "owner": "STAGE", "source": "PLANS/48",
	"note": "bulgeOtherHalfFollow for the throat"},
"bulgeOralTipRound": {"value": 0.0, "unit": "0-1", "owner": "PRESENT", "source": "PLANS/48",
	"note": "bulgeTipRound for the throat (Detailed drawing only; Simple uses the other holes' value)"},
"bulgeOralLagInflate": {"value": 0.8, "unit": "0-1 speed", "owner": "COMMIT", "source": "PLANS/48",
	"note": "bulgeLagInflate for the throat"},
"bulgeOralLagDeflate": {"value": 0.3, "unit": "0-1 speed", "owner": "COMMIT", "source": "PLANS/48",
	"note": "bulgeLagDeflate for the throat"},
"bulgeOralLagWobble": {"value": 0.6, "unit": "0-1", "owner": "COMMIT", "source": "PLANS/48",
	"note": "bulgeLagWobble for the throat"},
}
const ORAL := {
	"bulgeSizeModifier": "bulgeOralSize", "bulgeShapeFidelity": "bulgeOralShapeFidelity",
	"bulgeOtherHalfAdd": "bulgeOralOtherHalfAdd", "bulgeOtherHalfFollow": "bulgeOralOtherHalfFollow",
	"bulgeTipRound": "bulgeOralTipRound", "bulgeLagInflate": "bulgeOralLagInflate",
	"bulgeLagDeflate": "bulgeOralLagDeflate", "bulgeLagWobble": "bulgeOralLagWobble",
}
const ZONE_MOUTH := "mouth"
const LAYER_GAME := "game option"
const LAYER_MOD := "mod setting"
const LAYER_DEFAULT := "compiled default"
const LAYER_NONE := "not a setting"
const LAYER_BENCH := "workbench overlay"
const OVERLAY := {}
const CACHE := {"loaded": false, "settings": {}, "asked": false, "fox": null}
static func gameOption(name:String) -> Array:
	if(OPTIONS == null || !(name in OPTIONS)):
		return [false, null]
	return [true, OPTIONS.get(name)]
static func declaration(name:String):
	return DECLARED.get(name)
static func compiled(name:String):
	if(DECLARED.has(name)):
		return DECLARED[name]["value"]
	return null
static func vetSetting(name:String, given) -> Array:
	var bad:Array = []
	if(!DECLARED.has(name)):
		bad.append("'" + name + "' is not one of this mod's settings (" \
			+ PoolStringArray(DECLARED.keys()).join(", ") + ")")
		return [bad, null]
	var declared = DECLARED[name]["value"]
	if(typeof(declared) == TYPE_REAL && typeof(given) == TYPE_INT):
		given = float(given)
	if(typeof(given) != typeof(declared)):
		bad.append("'" + name + "' wants " + typename(declared) + ", got " + typename(given))
		return [bad, null]
	return [bad, given]
static func typename(value) -> String:
	match typeof(value):
		TYPE_BOOL:
			return "a bool"
		TYPE_INT:
			return "an int"
		TYPE_REAL:
			return "a float"
		TYPE_STRING:
			return "a string"
	return "a value of type " + str(typeof(value))
const PATH := "user://bulge3_settings.json"
const FORMAT_VERSION := 1
const KEY_FORMAT := "format"
const KEY_SETTINGS := "settings"
const LEGAL_KEYS := [KEY_FORMAT, KEY_SETTINGS]
static func parse(text:String, where:String = PATH):
	var parsed:JSONParseResult = JSON.parse(text)
	if(parsed.error != OK):
		Boot.loud("Settings: " + where + " is not valid JSON - line " + str(parsed.error_line) + ": " \
			+ str(parsed.error_string) + ". NOTHING IS APPLIED and no setting is stored this run;" \
			+ " every setting falls back to the compiled default. Delete the file or" \
			+ " fix it - it is never partially read.")
		return null
	var doc = parsed.result
	var bad:PoolStringArray = PoolStringArray()
	if(typeof(doc) != TYPE_DICTIONARY):
		bad.append("the file is not a JSON object")
		return refuse(where, bad)
	for key in doc:
		if(!LEGAL_KEYS.has(key)):
			bad.append("unknown top-level key '" + str(key) + "' - legal keys are " \
				+ PoolStringArray(LEGAL_KEYS).join(", "))
	if(typeof(doc.get(KEY_FORMAT, null)) != TYPE_INT && typeof(doc.get(KEY_FORMAT, null)) != TYPE_REAL):
		bad.append("\"" + KEY_FORMAT + "\" is missing or is not a number - a settings file says which" \
			+ " build wrote it")
	elif(float(doc[KEY_FORMAT]) != float(FORMAT_VERSION)):
		bad.append("\"" + KEY_FORMAT + "\" is " + str(doc[KEY_FORMAT]) + " and this build reads " \
			+ str(FORMAT_VERSION))
	if(typeof(doc.get(KEY_SETTINGS, null)) != TYPE_DICTIONARY):
		bad.append("\"" + KEY_SETTINGS + "\" is missing or is not an object")
		return refuse(where, bad)
	var wanted:Dictionary = {}
	for name in doc[KEY_SETTINGS]:
		if(declaration(str(name)) == null):
			Boot.loud("Settings: " + where + " holds '" + str(name) + "', which this build has no" \
				+ " setting for. IGNORED; every other setting is read.")
			continue
		var vetted:Array = vetSetting(str(name), doc[KEY_SETTINGS][name])
		for complaint in vetted[0]:
			bad.append(str(complaint))
		if(vetted[0].empty()):
			wanted[str(name)] = vetted[1]
	if(!bad.empty()):
		return refuse(where, bad)
	return wanted
static func refuse(where:String, bad:PoolStringArray):
	Boot.loud("Settings: " + where + " REFUSED, NOTHING APPLIED - every setting falls back to the" \
		+ " compiled default this run. " + str(bad.size()) + " problem(s): " \
		+ bad.join("; ") + ". Delete the file or fix it; it is never partially read.")
	return null
static func loadFrom(path:String) -> Dictionary:
	var f := File.new()
	if(!f.file_exists(path)):
		return {}
	if(f.open(path, File.READ) != OK):
		Boot.loud("Settings: cannot open " + path + " for reading. Nothing applied; every setting" \
			+ " falls back to the compiled default this run.")
		return {}
	var text:String = f.get_as_text()
	f.close()
	var wanted = parse(text, path)
	if(wanted == null):
		return {}
	return wanted
const FOXLIB_PATH := "res://Modules/InsertionBulges/FoxLibOptions.gd"
static func foxLib():
	if(!CACHE["asked"]):
		CACHE["asked"] = true
		var adapter = load(FOXLIB_PATH)
		if(adapter != null && adapter.live()):
			CACHE["fox"] = adapter
	return CACHE["fox"]
static func liveStore(fox = foxLib()) -> String:
	if(fox != null):
		return str(fox.storeLabel())
	return PATH
static func stored(fox = foxLib()) -> Dictionary:
	if(fox != null):
		return fox.stored()
	if(!CACHE["loaded"]):
		CACHE["loaded"] = true
		CACHE["settings"] = loadFrom(PATH)
	return CACHE["settings"]
static func forget() -> void:
	CACHE["loaded"] = false
	CACHE["settings"] = {}
static func write(settings:Dictionary, path:String = PATH) -> bool:
	var doc := {}
	doc[KEY_FORMAT] = FORMAT_VERSION
	doc[KEY_SETTINGS] = settings
	var f := File.new()
	if(f.open(path, File.WRITE) != OK):
		Boot.loud("Settings: cannot open " + path + " for writing. Nothing written and nothing" \
			+ " changed - the setting you just set is NOT saved and will not survive a restart.")
		return false
	f.store_string(JSON.print(doc, "  ", true))
	f.close()
	return true
static func store(name:String, given, fox = foxLib()) -> bool:
	var vetted:Array = vetSetting(name, given)
	if(!vetted[0].empty()):
		Boot.loud("Settings: '" + name + "' NOT stored, nothing changed and nothing written - " \
			+ PoolStringArray(vetted[0]).join("; ") + ".")
		return false
	if(fox != null):
		return fox.store(name, vetted[1])
	var next:Dictionary = stored(fox).duplicate()
	next[name] = vetted[1]
	if(!write(next)):
		return false
	CACHE["settings"] = next
	return true
static func clear(name:String, fox = foxLib()) -> bool:
	if(fox != null):
		return fox.clear(name)
	var next:Dictionary = stored(fox).duplicate()
	if(!next.erase(name)):
		return false
	if(!write(next)):
		return false
	CACHE["settings"] = next
	return true
static func resolve(name:String) -> Dictionary:
	if(declaration(name) == null):
		Boot.loud("Settings: no setting named '" + name + "'. Add it to DECLARED in" \
			+ " Modules/InsertionBulges/Settings.gd, or fix the name.")
		return row(name, null, LAYER_NONE, "no such setting")
	var asked:Array = gameOption(name)
	if(asked[0]):
		return row(name, asked[1], LAYER_GAME, "the game's own option")
	if(OVERLAY.has(name)):
		return row(name, OVERLAY[name], LAYER_BENCH, "the workbench")
	var mine:Dictionary = stored()
	if(mine.has(name)):
		return row(name, mine[name], LAYER_MOD, liveStore())
	return row(name, compiled(name), LAYER_DEFAULT, str(declaration(name)["source"]))
static func value(name:String):
	return resolve(name)["value"]
static func forZone(name:String, zone:String):
	if(zone == ZONE_MOUTH && ORAL.has(name)):
		return value(ORAL[name])
	return value(name)
static func row(name:String, value_, layer:String, detail:String) -> Dictionary:
	return {"setting": name, "value": value_, "layer": layer, "detail": detail}
