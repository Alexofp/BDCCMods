extends Node
const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const Cost := preload("res://Bulge3/Bench/Cost.gd")
const LastFrame := preload("res://Bulge3/Bench/LastFrame.gd")
const Preview := preload("res://Bulge3/Bench/Preview.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const SELF_PATH := "res://Bulge3/Bench/Commands.gd"
const ONCE_META := "insertionbulges_v3_commands"
const SETTING_CMD := "bulge3_setting"
const REPORT_CMD := "bulge3_report"
const COST_CMD := "bulge3_cost"
const PREVIEW_CMD := "bulge3_preview"
const HOST_NAME := "Bulge3Commands"
const TAG := "InsertionBulges v3: "
static func install(from:String):
	var tree = Engine.get_main_loop()
	if(tree == null || !(tree is SceneTree)):
		Boot.loud("Commands: no SceneTree, so there is nothing to host the console callbacks on." \
			+ " No command registered. [hook=" + from + "]")
		return null
	if(tree.has_meta(ONCE_META)):
		return tree.get_meta(ONCE_META)
	var console = tree.root.get_node_or_null("Console")
	if(console == null || !console.has_method("addCommand")):
		Boot.loud("Commands: no Console autoload with addCommand(), so there is no console to" \
			+ " register in. No command registered; the Bench still works from code." \
			+ " [hook=" + from + "]")
		return null
	var host = tree.root.get_node_or_null(HOST_NAME)
	if(host == null):
		host = load(SELF_PATH).new()
		host.name = HOST_NAME
		tree.root.add_child(host)
		if(!host.is_inside_tree()):
			host.free()
			Boot.loud("Commands: could not parent the callback host to the root viewport - the" \
				+ " engine refuses an add_child while the root is busy setting up children. No" \
				+ " command registered. Call install() from a module hook, or after one idle frame." \
				+ " [hook=" + from + "]")
			return null
	tree.set_meta(ONCE_META, host)
	console.addCommand(SETTING_CMD, host, "cmdSetting", ["name"],
		"InsertionBulges v3: resolve one setting and say what is in force, which of the three layers" \
		+ " won (game option > mod setting > compiled default) and which store answered.")
	console.addCommand(REPORT_CMD, host, "cmdReport", [],
		"InsertionBulges v3: print the LAST FRAME's H1 report for the running sex scene - the bulge," \
		+ " clip, drop, skip and cleared rows - and then walk H1's four silent outs per bulge and" \
		+ " read bulge_par<slot> back off the body material. Answers 'is it not drawing, or is it" \
		+ " drawing something I cannot see'.")
	console.addCommand(COST_CMD, host, "cmdCost", [],
		"InsertionBulges v3: time the displacement-field bake on THIS driver and print a table -" \
		+ " resolution x slot count -> milliseconds, with the material, the render and the readback" \
		+ " apart. Takes about " + str(Cost.frames()) + " frames; it prints once when it is done.")
	console.addCommand(PREVIEW_CMD, host, "cmdPreview",
		["resolution", "slots", "depth", "width", "shade"],
		"InsertionBulges v3: draw v2's three-slot path and H6's baked path SIDE BY SIDE on the same" \
		+ " skin material, plus their amplified difference, and write one PNG. resolution is one of" \
		+ " " + str(Preview.RESOLUTIONS) + "; slots is 1.." + str(Preview.MAX_SLOTS) + " and may" \
		+ " exceed the " + str(Preview.OLD_SLOTS) + " v2 can hold, which is the point; depth, width" \
		+ " and shade are multipliers on 1.0 = the reference slot. At " + str(Preview.OLD_SLOTS) \
		+ " slots or fewer the difference panel must be BLACK.")
	var names:String = SETTING_CMD + " <name>, " + REPORT_CMD + ", " + COST_CMD + ", " \
		+ PREVIEW_CMD + " <res> <slots> <depth> <width> <shade>"
	Boot.say(TAG + "console commands registered: " + names + ". [hook=" + from + "]")
	return host
static func settingLine(row:Dictionary) -> String:
	return TAG + str(row["setting"]) + " = " + str(row["value"]) + " <- " \
		+ str(row["layer"]) + " (" + str(row["detail"]) + ")"
func cmdSetting(name:String) -> void:
	Boot.say(settingLine(Settings.resolve(name)))
func cmdReport():
	var reader = LastFrame.new()
	add_child(reader)
	var block = yield(reader.run(), "completed")
	Boot.say(TAG + str(block))
	reader.queue_free()
func cmdCost():
	Boot.say(TAG + "timing the bake over " + str(Cost.RESOLUTIONS.size() * Cost.SLOT_COUNTS.size()) \
		+ " cells, " + str(Cost.RUNS) + " runs each - about " + str(Cost.frames()) \
		+ " frames. The table prints when it is done.")
	var meter = Cost.new()
	add_child(meter)
	var resultRaw = yield(meter.run(), "completed")
	var result:Dictionary = resultRaw
	Boot.say(Cost.block(result))
	meter.queue_free()
func cmdPreview(resolution:String, slots:String, depth:String, width:String, shade:String):
	var shot = Preview.new()
	add_child(shot)
	var resultRaw = yield(shot.run(int(resolution), int(slots), float(depth), float(width),
		float(shade)), "completed")
	var result:Dictionary = resultRaw
	if(str(result["refused"]) == Preview.REASON_NO_BAKED \
			|| str(result["refused"]) == Preview.REASON_NO_SHADER \
			|| str(result["refused"]) == Preview.REASON_NO_MATERIAL):
		Boot.loud(Preview.refusalBlock(str(result["refused"]), shot.inspected))
	else:
		Boot.say(Preview.block(result))
	shot.queue_free()
