extends Node
const Bake := preload("res://Bulge3/Present/Bake.gd")
const Backends := preload("res://Bulge3/Present/Backends.gd")
const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const MAGIC := "bulge3-cost"
const RESOLUTIONS := [64, 128, 256, 512]
const SLOT_COUNTS := [1, 3, 6, 12]
const RUNS := 9
const WARMUPS := 1
const STAT := "median"
const PROBE_SIDE := 64
const FLAT_SHAPE := [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
const SLOT_STEP := 0.01
const RESULT_KEYS := ["driver", "gles2", "float_targets", "format", "refused", "runs", "warmups",
	"stat", "empty_frame_ms", "rows"]
const COLUMNS := "%6s %6s %12s %11s %12s %9s"
var canvas:Viewport = null
var surface:ColorRect = null
static func slotAt(cy:float) -> Dictionary:
	return {
		"centre": Vector2(0.50, cy),
		"front": Vector2(0.76, cy),
		"spread": 0.10,
		"amplitude": 0.026,
		"shade": 0.5,
		"column_half": 0.05,
		"shape": FLAT_SHAPE,
		"axis_depth": 0.06,
	}
static func slotsFor(count:int) -> Array:
	var out:Array = []
	for i in range(count):
		out.append(slotAt(0.50 + (float(i) - float(count - 1) * 0.5) * SLOT_STEP))
	return out
static func median(values:Array) -> float:
	if(values.empty()):
		return 0.0
	var ordered:Array = values.duplicate()
	ordered.sort()
	var mid:int = int(ordered.size() / 2.0)
	if(ordered.size() % 2 == 1):
		return float(ordered[mid])
	return (float(ordered[mid - 1]) + float(ordered[mid])) * 0.5
static func msOf(usec:float) -> float:
	return usec / 1000.0
static func frames() -> int:
	return (RESOLUTIONS.size() * SLOT_COUNTS.size() * (RUNS + WARMUPS) + RUNS + 1) * 2
func sized(side:int) -> void:
	if(canvas == null):
		canvas = Viewport.new()
		canvas.usage = Viewport.USAGE_3D
		canvas.hdr = true
		canvas.transparent_bg = true
		surface = ColorRect.new()
		canvas.add_child(surface)
		add_child(canvas)
	canvas.size = Vector2(side, side)
	surface.rect_size = canvas.size
func release() -> void:
	if(canvas != null):
		canvas.queue_free()
		canvas = null
		surface = null
func timeOne(slots:Array):
	var t0:int = OS.get_ticks_usec()
	surface.material = Bake.materialFor(slots)
	var t1:int = OS.get_ticks_usec()
	canvas.render_target_update_mode = Viewport.UPDATE_ONCE
	yield(get_tree(), "idle_frame")
	yield(VisualServer, "frame_post_draw")
	var t2:int = OS.get_ticks_usec()
	var image:Image = Bake.imageFrom(canvas.get_texture())
	var t3:int = OS.get_ticks_usec()
	var format:int = -1
	if(image != null):
		format = image.get_format()
	return {"material": t1 - t0, "render": t2 - t1, "readback": t3 - t2, "format": format}
func emptyFrame():
	var e0:int = OS.get_ticks_usec()
	yield(get_tree(), "idle_frame")
	yield(VisualServer, "frame_post_draw")
	return OS.get_ticks_usec() - e0
func probeTarget():
	sized(PROBE_SIDE)
	var timedRaw = yield(timeOne(slotsFor(1)), "completed")
	return timedRaw
func run(gles2 = null, floatTargets = null):
	yield(get_tree(), "idle_frame")
	var driverGles2:bool = Boot.gles2Mode()
	if(gles2 != null):
		driverGles2 = bool(gles2)
	var floats:bool = false
	var probedFormat:int = -1
	if(floatTargets != null):
		floats = bool(floatTargets)
	elif(Backends.refusalFor(Backends.H6, driverGles2, true) == ""):
		var probeRaw = yield(probeTarget(), "completed")
		var probed:Dictionary = probeRaw
		probedFormat = int(probed["format"])
		floats = probedFormat != -1 && probedFormat != Image.FORMAT_RGBA8
	var driverName:String = "GLES3"
	if(driverGles2):
		driverName = "GLES2"
	var result:Dictionary = {
		"driver": driverName,
		"gles2": driverGles2,
		"float_targets": floats,
		"format": probedFormat,
		"refused": Backends.refusalFor(Backends.H6, driverGles2, floats),
		"runs": RUNS,
		"warmups": WARMUPS,
		"stat": STAT,
		"empty_frame_ms": 0.0,
		"rows": [],
	}
	if(str(result["refused"]) != ""):
		release()
		return result
	var empties:Array = []
	for _e in range(RUNS):
		var emptyRaw = yield(emptyFrame(), "completed")
		empties.append(emptyRaw)
	result["empty_frame_ms"] = msOf(median(empties))
	for side in RESOLUTIONS:
		for count in SLOT_COUNTS:
			var slots:Array = slotsFor(int(count))
			sized(int(side))
			var materials:Array = []
			var renders:Array = []
			var readbacks:Array = []
			for attempt in range(WARMUPS + RUNS):
				var oneRaw = yield(timeOne(slots), "completed")
				var one:Dictionary = oneRaw
				if(attempt < WARMUPS):
					continue
				materials.append(one["material"])
				renders.append(one["render"])
				readbacks.append(one["readback"])
			result["rows"].append({
				"resolution": int(side),
				"slots": int(count),
				"material_ms": msOf(median(materials)),
				"render_ms": msOf(median(renders)),
				"readback_ms": msOf(median(readbacks)),
			})
	release()
	return result
static func fmt(value) -> String:
	return "%.3f" % float(value)
static func rowLine(row:Dictionary) -> String:
	return COLUMNS % [str(row["resolution"]), str(row["slots"]), fmt(row["material_ms"]),
		fmt(row["render_ms"]), fmt(row["readback_ms"]),
		fmt(float(row["render_ms"]) + float(row["readback_ms"]))]
static func block(result:Dictionary) -> String:
	var head:String = MAGIC + " driver=" + str(result["driver"])
	if(str(result["refused"]) != ""):
		return head + " REFUSED - H6 cannot run here: " + str(result["refused"]) \
			+ ". Nothing was timed: a bake measured through a backend the driver refuses is not" \
			+ " this backend's cost."
	var out := PoolStringArray()
	out.append(head \
		+ " float_targets=" + ("yes" if bool(result["float_targets"]) else "no") \
		+ " format=" + str(result["format"]) \
		+ " (RGBA8 is " + str(Image.FORMAT_RGBA8) + ", RGBAH is " + str(Image.FORMAT_RGBAH) + ")" \
		+ " runs=" + str(result["runs"]) + " warmup=" + str(result["warmups"]) \
		+ " stat=" + str(result["stat"]) \
		+ " empty_frame=" + fmt(result["empty_frame_ms"]) + "ms")
	out.append(COLUMNS % ["res", "slots", "material_ms", "render_ms", "readback_ms", "frame_ms"])
	for row in result["rows"]:
		out.append(rowLine(row))
	out.append(MAGIC + " end - " + str(result["rows"].size()) + " rows, " + str(result["stat"]) \
		+ " of " + str(result["runs"]) + " runs each. render_ms and readback_ms are not two" \
		+ " independent costs and their split means nothing - where the vsync boundary falls decides" \
		+ " it. frame_ms is the pair, and it is read AS A MULTIPLE OF empty_frame above, never as a" \
		+ " difference from it: 1x fits inside the frame, 2x missed the deadline and waited for the" \
		+ " next one.")
	out.append(MAGIC + " scene - frame_ms QUANTISES TO WHOLE FRAMES, so this table only answers the" \
		+ " resolution knob FROM A LIVE SESSION: headless there is no scene competing for the frame," \
		+ " every cell fits inside one, and that says nothing about the bake. Measured live at" \
		+ " 13.324ms/frame: 64, 128 and 256 all landed on 1x and every 512 row on 2x, so 256 was that" \
		+ " machine's ceiling and 512 cost a second frame. A bake under the deadline is invisible and" \
		+ " cannot be priced finer than its frame; crossing the deadline is what this measures.")
	return out.join("\n")
