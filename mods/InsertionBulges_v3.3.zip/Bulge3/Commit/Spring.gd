extends Reference
const Lifetime := preload("res://Bulge3/Commit/Lifetime.gd")
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const Engagement := preload("res://Bulge3/Commit/Engagement.gd")
const TUNING := {"hz": 3.0, "hz_down": 3.0, "zeta": 0.85, "travel": false}
const TUNING_ORAL := {"hz": 3.0, "hz_down": 3.0, "zeta": 0.85}
const SIMPLE_RATES := {"hz": 4.5, "hz_down": 1.75, "zeta": 0.7}
const RATE_SLOW := 0.5
const RATE_FAST := 5.5
const MAX_STEP := 1.0 / 30.0
const MAX_FRAME := 0.25
const STROKE_FULL := 1.0
static func hz() -> float:
	return float(TUNING["hz"])
static func zeta() -> float:
	return float(TUNING["zeta"])
static func hzDown() -> float:
	return float(TUNING["hz_down"])
static func travelOn() -> bool:
	return bool(TUNING["travel"])
static func setTravel(on:bool) -> void:
	TUNING["travel"] = on
static func hzFor(share:float) -> float:
	return lerp(RATE_SLOW, RATE_FAST, clamp(share, 0.0, 1.0))
static func setRates(upHz:float, downHz:float) -> bool:
	if(upHz <= 0.0 || downHz <= 0.0):
		push_error("Spring: rates must be > 0; still " + str(hz()) + "/" + str(hzDown()))
		return false
	TUNING["hz"] = upHz
	TUNING["hz_down"] = downHz
	return true
static func setZeta(zetaValue:float) -> bool:
	if(zetaValue <= 0.0):
		push_error("Spring: zeta must be > 0; still " + str(zeta()))
		return false
	TUNING["zeta"] = zetaValue
	return true
static func setOralTuning(upHz:float, downHz:float, zetaValue:float) -> bool:
	if(upHz <= 0.0 || downHz <= 0.0 || zetaValue <= 0.0):
		push_error("Spring: oral rates and zeta must be > 0")
		return false
	TUNING_ORAL["hz"] = upHz
	TUNING_ORAL["hz_down"] = downHz
	TUNING_ORAL["zeta"] = zetaValue
	return true
static func ratesFor(intent) -> Dictionary:
	if(typeof(intent) == TYPE_DICTIONARY && str(intent.get("zone", "")) == "mouth"):
		if(intent.get("simple") == true):
			return SIMPLE_RATES
		return TUNING_ORAL
	return TUNING
static func setTuning(hzValue:float, zetaValue:float) -> bool:
	if(hzValue < 0.0 || zetaValue <= 0.0):
		push_error("Spring: hz must be >= 0 (0 is off) and zeta > 0; still " \
			+ str(hz()) + "/" + str(zeta()))
		return false
	TUNING["hz"] = hzValue
	TUNING["hz_down"] = hzValue
	TUNING["zeta"] = zetaValue
	return true
static func settle(previous, entries:Array, now:float) -> Dictionary:
	var was:Dictionary = {}
	var dt:float = 0.0
	if(typeof(previous) == TYPE_DICTIONARY):
		if(typeof(previous.get("slots")) == TYPE_DICTIONARY):
			was = previous["slots"]
		dt = clamp(now - float(previous.get("now", now)), 0.0, MAX_FRAME)
	var slots:Dictionary = {}
	var seen:Dictionary = {}
	for one in entries:
		if(typeof(one) == TYPE_DICTIONARY && typeof(one.get("engagement")) == TYPE_DICTIONARY):
			seen[Lifetime.relationKey(one["engagement"])] = true
	var inherited:Dictionary = {}
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var intent = entry.get("intent")
		var engagement = entry.get("engagement")
		if(typeof(engagement) != TYPE_DICTIONARY):
			continue
		if(typeof(intent) != TYPE_DICTIONARY):
			continue
		var target:float = float(intent["amplitude"])
		var lipTarget:float = float(intent.get("lip", 0.0))
		if(hz() <= 0.0):
			slots[Lifetime.relationKey(engagement)] = {"amplitude": target, "velocity": 0.0,
				"lip": lipTarget, "lip_velocity": 0.0, "stroke": 0.0, "depth": depthOf(entry),
				"engagement": engagement, "intent": intent}
			continue
		var key:String = Lifetime.relationKey(engagement)
		var value:float = 0.0
		var velocity:float = 0.0
		var from = was.get(key)
		if(typeof(from) != TYPE_DICTIONARY):
			for oldKey in was:
				if(seen.has(oldKey) || inherited.has(oldKey) || typeof(was[oldKey]) != TYPE_DICTIONARY \
						|| typeof(was[oldKey].get("engagement")) != TYPE_DICTIONARY):
					continue
				if(holeKey(was[oldKey]["engagement"]) == holeKey(engagement)):
					inherited[oldKey] = true
					from = was[oldKey]
					break
		var lip:float = 0.0
		var lipVelocity:float = 0.0
		var stroke:float = 0.0
		var depth = depthOf(entry)
		var strokeTarget:float = 0.0
		if(typeof(from) == TYPE_DICTIONARY):
			stroke = float(from.get("stroke", 0.0))
			if(depth != null && from.get("depth") != null && dt > 0.0):
				strokeTarget = clamp((float(depth) - float(from["depth"])) / dt / STROKE_FULL, -1.0, 1.0)
			value = float(from.get("amplitude", 0.0))
			velocity = float(from.get("velocity", 0.0))
			lip = float(from.get("lip", 0.0))
			lipVelocity = float(from.get("lip_velocity", 0.0))
		var rates:Dictionary = ratesFor(intent)
		var moved:Array = step(value, velocity, target, dt, true, rates)
		value = moved[0]
		velocity = moved[1]
		var lipMoved:Array = step(lip, lipVelocity, lipTarget, dt, true, rates)
		stroke = strokeEase(stroke, strokeTarget, dt, rates)
		slots[key] = {"amplitude": value, "velocity": velocity, "lip": lipMoved[0],
			"lip_velocity": lipMoved[1], "stroke": stroke, "depth": depth, "engagement": engagement,
			"intent": intent}
		var springed:Dictionary = Intent.withSpring(intent, value, lipMoved[0], stroke)
		if(travelOn() && str(intent.get("zone", "")) != "mouth"):
			travel(from, slots[key], springed, dt, rates)
		if(str(intent.get("zone", "")) == "mouth" && intent.get("simple") != true && Intent.swallowOn()):
			swallow(from, slots[key], springed, dt)
		entry["intent"] = springed
	for oldKey in inherited:
		seen[oldKey] = true
	settleTails(was, seen, slots, entries, dt)
	return {"now": now, "slots": slots}
const TRAVEL_KEYS := ["column_half", "band_from", "band_to"]
static func travel(from, slot:Dictionary, springed:Dictionary, dt:float, rates:Dictionary = TUNING) -> void:
	if(typeof(springed.get("centre_rest")) != TYPE_VECTOR3):
		return
	var was:Dictionary = {}
	if(typeof(from) == TYPE_DICTIONARY && typeof(from.get("travel")) == TYPE_DICTIONARY):
		was = from["travel"]
	var now:Dictionary = {}
	var centre:Vector3 = springed["centre_rest"]
	var drawn:Vector3 = centre
	var pace:Vector3 = Vector3.ZERO
	if(typeof(was.get("centre")) == TYPE_VECTOR3):
		for axis in range(3):
			var moved:Array = step(was["centre"][axis], was["centre_velocity"][axis], centre[axis], dt, false, rates)
			drawn[axis] = moved[0]
			pace[axis] = moved[1]
	now["centre"] = drawn
	now["centre_velocity"] = pace
	springed["centre_rest"] = drawn
	for name in TRAVEL_KEYS:
		if(springed.get(name) == null):
			continue
		var at:float = float(springed[name])
		var speed:float = 0.0
		if(was.has(name)):
			var moved2:Array = step(float(was[name]), float(was[name + "_velocity"]), at, dt, true, rates)
			at = moved2[0]
			speed = moved2[1]
		now[name] = at
		now[name + "_velocity"] = speed
		springed[name] = at
	slot["travel"] = now
const SWALLOW := {"rest": 0.5, "time": 0.8, "gap": 2.0, "depth": 0.5, "width": 0.15}
const SWALLOW_STILL := 0.15
static func swallow(from, slot:Dictionary, springed:Dictionary, dt:float) -> void:
	var rest:float = 0.0
	var phase:float = -1.0
	var wait:float = 0.0
	if(typeof(from) == TYPE_DICTIONARY):
		rest = float(from.get("swallow_rest", 0.0))
		phase = float(from.get("swallow_phase", -1.0))
		wait = float(from.get("swallow_wait", 0.0))
	if(abs(float(slot.get("stroke", 0.0))) < SWALLOW_STILL):
		rest += dt
	else:
		rest = 0.0
	wait = max(wait - dt, 0.0)
	if(phase < 0.0 && rest >= float(SWALLOW["rest"]) && wait <= 0.0):
		phase = 0.0
	if(phase >= 0.0):
		phase += dt / float(SWALLOW["time"])
		if(phase > 1.0):
			phase = -1.0
			wait = float(SWALLOW["gap"])
		elif(typeof(springed.get("shape")) == TYPE_ARRAY):
			springed["shape"] = swallowed(springed["shape"], phase)
	slot["swallow_rest"] = rest
	slot["swallow_phase"] = phase
	slot["swallow_wait"] = wait
static func swallowed(shape:Array, phase:float) -> Array:
	var width:float = float(SWALLOW["width"])
	var centre:float = lerp(-width, 1.0 + width, phase)
	var out:Array = []
	var last:int = int(max(shape.size() - 1, 1))
	for i in range(shape.size()):
		var d:float = (float(i) / float(last) - centre) / width
		out.append(float(shape[i]) * (1.0 - float(SWALLOW["depth"]) * exp(-d * d)))
	return out
static func depthOf(entry:Dictionary):
	var measures = entry.get("measures")
	if(typeof(measures) != TYPE_DICTIONARY || measures.get("depth") == null):
		return null
	return float(measures["depth"])
static func strokeEase(value:float, target:float, dt:float, rates:Dictionary = TUNING) -> float:
	return value + (target - value) * (1.0 - exp(-dt * TAU * max(float(rates["hz"]), 0.0001)))
static func step(value:float, velocity:float, target:float, dt:float, floored:bool = true,
		rates:Dictionary = TUNING) -> Array:
	var omega:float = TAU * float(rates["hz"])
	if(target < value):
		omega = TAU * float(rates["hz_down"])
	var damping:float = float(rates["zeta"])
	var left:float = dt
	while(left > 0.0):
		var h:float = min(left, MAX_STEP)
		left -= h
		velocity += (omega * omega * (target - value) - 2.0 * damping * omega * velocity) * h
		value = value + velocity * h
		if(floored && value <= 0.0):
			value = 0.0
			velocity = max(velocity, 0.0)
	return [value, velocity]
static func settleTails(was:Dictionary, seen:Dictionary, slots:Dictionary, entries:Array,
		dt:float) -> void:
	if(hz() <= 0.0 || dt <= 0.0):
		return
	for key in was:
		if(seen.has(key)):
			continue
		var old = was[key]
		if(typeof(old) != TYPE_DICTIONARY || typeof(old.get("intent")) != TYPE_DICTIONARY \
				|| typeof(old.get("engagement")) != TYPE_DICTIONARY):
			continue
		var value:float = float(old.get("amplitude", 0.0))
		var velocity:float = float(old.get("velocity", 0.0))
		var oldRates:Dictionary = ratesFor(old["intent"])
		var fell:Array = step(value, velocity, 0.0, dt, true, oldRates)
		value = fell[0]
		velocity = fell[1]
		var lipMoved:Array = step(float(old.get("lip", 0.0)), float(old.get("lip_velocity", 0.0)), 0.0, dt, true,
			oldRates)
		if(!Intent.springShows(value, lipMoved[0])):
			continue
		var stroke:float = strokeEase(float(old.get("stroke", 0.0)), 0.0, dt, oldRates)
		slots[key] = {"amplitude": value, "velocity": velocity, "lip": lipMoved[0],
			"lip_velocity": lipMoved[1], "stroke": stroke, "engagement": old["engagement"],
			"intent": old["intent"]}
		var fading:Dictionary = Intent.withSpring(old["intent"], value, lipMoved[0], stroke)
		if(typeof(old.get("travel")) == TYPE_DICTIONARY):
			slots[key]["travel"] = old["travel"]
			for name in old["travel"]:
				if(name == "centre"):
					fading["centre_rest"] = old["travel"][name]
				elif(TRAVEL_KEYS.has(name)):
					fading[name] = old["travel"][name]
		entries.append({
			"engagement": settlingOf(old["engagement"]),
			"measures": null,
			"intent": fading,
		})
static func holeKey(engagement:Dictionary) -> String:
	return str(engagement.get("hole_owner")) + "/" + str(engagement.get("hole"))
static func settlingOf(engagement:Dictionary) -> Dictionary:
	var out:Dictionary = engagement.duplicate()
	out["state"] = Engagement.STATE_SETTLING
	return out
