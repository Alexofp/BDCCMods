extends Reference
const Ladder := preload("res://Bulge3/Infer/Ladder.gd")
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Engagement := preload("res://Bulge3/Commit/Engagement.gd")
const LATCH_SETTLE := 1.5
const GEOMETRY_GRACE := 0.25
const KIND_DOLL := "doll"
static func commit(previous, snapshot, items, now:float, age:float) -> Array:
	var gated:bool = typeof(snapshot) == TYPE_DICTIONARY && snapshot.get("gated") == true
	if(gated):
		return []
	var roster:String = rosterOf(snapshot)
	var pose:String = ""
	if(typeof(snapshot) == TYPE_DICTIONARY && snapshot.get("pose") != null):
		pose = str(snapshot["pose"])
	var previousByKey:Dictionary = {}
	var wasAge:float = 0.0
	var wasRoster:String = ""
	var wasPose:String = ""
	var haveWas:bool = false
	if(typeof(previous) == TYPE_ARRAY):
		for one in previous:
			if(typeof(one) != TYPE_DICTIONARY):
				continue
			previousByKey[relationKey(one)] = one
			if(!haveWas):
				wasAge = float(one.get("pose_age", 0.0))
				wasRoster = str(one.get("roster"))
				wasPose = str(one.get("pose", ""))
				haveWas = true
	var latching:bool = haveWas && pose != "" && pose == wasPose && wasAge >= LATCH_SETTLE \
		&& wasRoster == roster
	var seeded:Array = []
	if(latching):
		for key in previousByKey:
			var decided:Dictionary = previousByKey[key]
			var was:Dictionary = decided["provenance"]
			seeded.append({
				"shaft": decided["shaft"],
				"hole_owner": decided["hole_owner"],
				"hole": str(decided["hole"]),
				"source": str(was["source"]),
				"confidence": int(was["confidence"]),
			})
	var fused:Dictionary = Ladder.fuse(snapshot, items, seeded)
	var participants:Dictionary = Ladder.participantsOf(snapshot)
	var claimed:Dictionary = {}
	for relation in fused["relations"]:
		claimed[relationKey(relation)] = true
	var graced:Array = []
	for key in previousByKey:
		var old:Dictionary = previousByKey[key]
		if(claimed.has(key) || str(old["provenance"]["source"]) != Evidence.SRC_GEOMETRY):
			continue
		var lastSeen:float = float(old.get("last_seen", 0.0))
		if(now - lastSeen >= GEOMETRY_GRACE):
			continue
		var carried:Dictionary = {
			"shaft": old["shaft"],
			"hole_owner": old["hole_owner"],
			"hole": str(old["hole"]),
			"source": str(old["provenance"]["source"]),
			"confidence": int(old["provenance"]["confidence"]),
		}
		Ladder.claim(fused, participants, carried)
		if(fused["relations"].find(carried) >= 0):
			graced.append(carried)
	var out:Array = []
	for relation in fused["relations"]:
		var state:String = Engagement.STATE_STATED
		if(seeded.find(relation) >= 0):
			state = Engagement.STATE_LATCHED
		elif(graced.find(relation) >= 0):
			state = Engagement.STATE_GRACED
		var key:String = relationKey(relation)
		var firstSeen:float = now
		var lastSeen:float = now
		if(previousByKey.has(key)):
			var before:Dictionary = previousByKey[key]
			firstSeen = float(before.get("first_seen", now))
			if(state != Engagement.STATE_STATED):
				lastSeen = float(before.get("last_seen", now))
		out.append(Engagement.engagement(relation, state, firstSeen, lastSeen, age, pose, roster))
	return out
static func rosterOf(snapshot) -> String:
	var roster:PoolStringArray = PoolStringArray()
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return ""
	for entry in snapshot["participants"]:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		var kind:String = KIND_DOLL
		if(entry.get("kind") != null):
			kind = str(entry["kind"])
		roster.append(str(entry["id"]) + "/" + kind + "/" + str(entry.get("char_id")))
	return roster.join(",")
static func relationKey(one:Dictionary) -> String:
	return str(one["shaft"]) + " -> " + str(one["hole_owner"]) + "/" + str(one["hole"])
