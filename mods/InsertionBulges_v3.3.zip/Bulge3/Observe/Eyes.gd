extends Reference
const BULGE_DOLL_PATH := "res://Bulge3/Doll/BulgeDoll.gd"
const BULGE_UTILS_PATH := "res://Bulge3/Doll/BulgeUtils.gd"
const HOLE_VAGINA := "vagina"
const HOLE_ANUS := "anus"
const HOLE_MOUTH := "mouth"
const SLOT_HEAD := "head"
const DOLL_HOLES := [HOLE_VAGINA, HOLE_ANUS, HOLE_MOUTH]
const KIND_DOLL := "doll"
const KIND_PROP := "prop"
const PROP_SHAFTS := [
	{"sign": "Shaft1", "bones": ["Shaft1", "Shaft2", "Shaft3", "Shaft4"], "radius": 0.22, "extend": 1.0},
	{"sign": "Knot", "bones": ["DildoBase.001", "Dildo", "Dildo.002", "Dildo.001"], "radius": 0.16,
		"extend": 1.0},
	{"sign": "Stick", "bones": ["Dildo1", "Dildo2", "Dildo3"], "radius": 0.16, "extend": 1.0},
]
const OVERLAP_PROBES := [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
const IMAGE_META := "bdccBulge3AlbedoImage"
const TAPER_BONES := ["Penis2", "Penis3"]
const RES_PREFIX := "res://"
const LOOP_SUFFIX := "-loop"
const DEFAULT_OVERSIZE := 0.9
const SOURCE_META := "bdccBulge3SceneSource"
var scene = null
var dollScript = null
var utilsScript = null
var byID := {}
var playbacks := []
var propByID := {}
func _init(stageScene):
	scene = stageScene
	dollScript = load(BULGE_DOLL_PATH)
	utilsScript = load(BULGE_UTILS_PATH)
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("getDolls")):
		return
	var dolls:Array = stageScene.getDolls()
	for index in range(dolls.size()):
		var theDoll = dolls[index]
		if(theDoll == null || !is_instance_valid(theDoll)):
			continue
		byID["doll" + str(index)] = theDoll
	var props:Array = propsIn(stageScene)
	for index in range(props.size()):
		propByID[KIND_PROP + str(index)] = props[index]
	if(stageScene.has_method("get_children")):
		for child in stageScene.get_children():
			if(!(child is AnimationTree)):
				continue
			var found = playbackParamOf(child)
			if(found != null):
				playbacks.append(found)
func engineFor(participantID):
	var theDoll = dollFor(participantID)
	if(theDoll == null || utilsScript == null):
		return null
	return utilsScript.engineFor(theDoll)
func sceneSource():
	if(scene == null || !is_instance_valid(scene)):
		return null
	var theScript = scene.get_script()
	if(theScript == null):
		return null
	if(theScript.has_meta(SOURCE_META)):
		return theScript.get_meta(SOURCE_META)
	var text = theScript.source_code
	theScript.set_meta(SOURCE_META, text)
	return text
func sceneScriptPath():
	if(scene == null || !is_instance_valid(scene)):
		return null
	var theScript = scene.get_script()
	if(theScript == null):
		return null
	return stripResPrefix(str(theScript.resource_path))
static func stripResPrefix(path:String) -> String:
	if(path.begins_with(RES_PREFIX)):
		return path.substr(RES_PREFIX.length(), path.length() - RES_PREFIX.length())
	return path
func taperOf(participantID):
	var helper = helperFor(participantID)
	if(helper == null):
		return null
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return null
	if(helper.getShaftInfo() == null):
		return null
	var hasTaperBone:bool = false
	for boneName in TAPER_BONES:
		if(skeleton.find_bone(boneName) >= 0):
			hasTaperBone = true
			break
	if(!hasTaperBone):
		return null
	return helper.getShaftTaper()
func holeOf(participantID, holeID):
	var helper = helperFor(participantID)
	if(helper == null):
		return null
	return helper.getOrificeInfo(str(holeID))
func rigOf(participantID):
	var helper = helperFor(participantID)
	if(helper == null):
		return null
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null || utilsScript == null):
		return null
	return {
		"hips": hipsToRest(skeleton),
		"origin": {
			HOLE_VAGINA: helper.getBulgeOriginRest(HOLE_VAGINA),
			HOLE_ANUS: helper.getBulgeOriginRest(HOLE_ANUS),
			HOLE_MOUTH: helper.getBulgeOriginRest(HOLE_MOUTH),
		},
		"neck_axis": helper.getNeckAxisWorld(),
		"spine_chain": helper.getSpineChainWorld(),
		"contour": helper.getFrontContour(HOLE_VAGINA),
		"margins": marginsOf(helper),
	}
func hipsToRest(skeleton:Skeleton):
	var boneIdx:int = skeleton.find_bone("Hips")
	if(boneIdx < 0):
		return null
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	var restGlobal:Transform = utilsScript.getBoneRestGlobal(skeleton, boneIdx)
	return restGlobal * posedGlobal.affine_inverse()
func marginsOf(helper) -> Array:
	var margins:Array = []
	for themesh in helper.getBulgeMeshesForZone(HOLE_VAGINA):
		if(!themesh.is_visible_in_tree()):
			continue
		margins.append(utilsScript.getFrontMargin(themesh))
	return margins
func oversize(shaftOwner, holeOwner, holeID):
	var topChar = charFor(dollFor(shaftOwner))
	var bottomChar = charFor(dollFor(holeOwner))
	if(topChar == null || bottomChar == null):
		return DEFAULT_OVERSIZE
	var slot = SLOT_HEAD if str(holeID) == HOLE_MOUTH else str(holeID)
	if(!bottomChar.hasBodypart(slot)):
		return DEFAULT_OVERSIZE
	var freeRoom:float = bottomChar.getPenetrationFreeRoom(slot, topChar.getPenisSize())
	return clamp(0.35 + max(-freeRoom, 0.0) / 18.0, 0.3, 1.7)
func clipOf(participantID):
	var id:String = str(participantID)
	for playback in playbacks:
		if(playback == null || !is_instance_valid(playback)):
			continue
		var clip = playback.get_current_node()
		if(typeof(clip) != TYPE_STRING || clip == ""):
			continue
		if(dollOwnerOfClip(clip) != id):
			continue
		return {
			"clip": clip,
			"travel_path": playback.get_travel_path(),
			"phase": phaseOf(playback),
		}
	return null
static func phaseOf(playback):
	var length:float = float(playback.get_current_length())
	if(length <= 0.0):
		return null
	var position:float = float(playback.get_current_play_position())
	return clamp(position / length, 0.0, 1.0)
static func playbackParamOf(tree:AnimationTree):
	if(tree == null || !is_instance_valid(tree)):
		return null
	for entry in tree.get_property_list():
		var propName:String = str(entry.get("name"))
		if(!propName.begins_with("parameters/") || !propName.ends_with("playback")):
			continue
		var value = tree[propName]
		if(value is AnimationNodeStateMachinePlayback):
			return value
	return null
static func dollOwnerOfClip(clip):
	if(typeof(clip) != TYPE_STRING):
		return null
	var stem:String = clip
	if(stem.ends_with(LOOP_SUFFIX)):
		stem = stem.substr(0, stem.length() - LOOP_SUFFIX.length())
	var underscore:int = stem.find_last("_")
	if(underscore < 0 || underscore == stem.length() - 1):
		return null
	var digits:String = stem.substr(underscore + 1, -1)
	for i in range(digits.length()):
		var ch:String = digits.substr(i, 1)
		if(ch < "0" || ch > "9"):
			return null
	var n:int = int(digits)
	if(n <= 0):
		return null
	return "doll" + str(n - 1)
func dollStateOf(participantID):
	var theDoll = dollFor(participantID)
	if(theDoll == null):
		return null
	return {
		"cock": theDoll.getFinalState("cock"),
		"mouth": theDoll.getFinalState("mouth"),
	}
func cumStateOf(participantID):
	var theDoll = dollFor(participantID)
	if(theDoll == null):
		return null
	return {"cummed_inside": float(theDoll.cummedInside)}
func propsOf(participantID) -> Dictionary:
	var out:Dictionary = {}
	var theDoll = dollFor(participantID)
	if(theDoll == null):
		return out
	var zones = theDoll.get("dollAttachmentZones")
	if(typeof(zones) != TYPE_DICTIONARY):
		return out
	for zoneName in zones:
		var nodes = zones[zoneName]
		if(typeof(nodes) != TYPE_ARRAY):
			continue
		for zone in nodes:
			if(zone == null || !is_instance_valid(zone)):
				continue
			var props = zone.get("temporaryScenes")
			if(typeof(props) != TYPE_ARRAY):
				continue
			for prop in props:
				if(prop == null || !is_instance_valid(prop) || !(prop is Spatial)):
					continue
				out[str(zoneName)] = openingsOf(prop)
				break
			if(out.has(str(zoneName))):
				break
	return out
func openingsOf(prop) -> Array:
	for child in prop.get_children():
		if(!(child is Sprite3D) || child.texture == null):
			continue
		var box:AABB = child.get_aabb()
		var span:Array = opaqueSpanOf(child.texture)
		var low:float = float(span[0])
		var high:float = float(span[1])
		if(child.flip_h):
			low = 1.0 - float(span[1])
			high = 1.0 - float(span[0])
		var mid:Vector3 = box.position + box.size * 0.5
		var ends:Array = []
		for frac in [low, high]:
			var local := Vector3(box.position.x + box.size.x * frac, mid.y, mid.z)
			ends.append(child.global_transform.xform(local))
		return ends
	return [prop.global_transform.origin]
const SPAN_META := "bdccBulge3OpaqueSpan"
const OPAQUE_ALPHA := 0.5
const SPAN_ROW_STEP := 4
func opaqueSpanOf(texture) -> Array:
	if(texture.has_meta(SPAN_META)):
		return texture.get_meta(SPAN_META)
	var span:Array = [0.0, 1.0]
	var image = texture.get_data()
	if(image != null && image.is_compressed() && image.decompress() != OK):
		image = null
	if(image != null && image.get_width() > 0):
		var width:int = image.get_width()
		var first:int = -1
		var last:int = -1
		image.lock()
		for x in range(width):
			for y in range(0, image.get_height(), SPAN_ROW_STEP):
				if(image.get_pixel(x, y).a >= OPAQUE_ALPHA):
					if(first < 0):
						first = x
					last = x
					break
		image.unlock()
		if(first >= 0):
			span = [float(first) / width, float(last + 1) / width]
	texture.set_meta(SPAN_META, span)
	return span
static func propsIn(stageScene) -> Array:
	var out:Array = []
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("get_children")):
		return out
	for child in stageScene.get_children():
		if(!(child is Spatial) || child.has_method("prepareCharacter")):
			continue
		var skeleton = skeletonIn(child, 3)
		if(skeleton == null):
			continue
		for row in PROP_SHAFTS:
			if(skeleton.find_bone(str(row["sign"])) >= 0):
				out.append({"skeleton": skeleton, "row": row})
				break
	return out
static func skeletonIn(node, depth:int):
	if(node is Skeleton):
		return node
	if(depth <= 0):
		return null
	for child in node.get_children():
		var found = skeletonIn(child, depth - 1)
		if(found != null):
			return found
	return null
func propShaftOf(participantID):
	var found = propByID.get(str(participantID))
	if(found == null):
		return null
	var skeleton = found["skeleton"]
	if(!is_instance_valid(skeleton) || !skeleton.is_visible_in_tree()):
		return null
	var row:Dictionary = found["row"]
	var points:Array = []
	for boneName in row["bones"]:
		var boneIdx:int = skeleton.find_bone(str(boneName))
		if(boneIdx < 0):
			return null
		var at:Vector3 = (skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)).origin
		at.z = 0.0
		points.append(at)
	var base:Vector3 = points[0]
	var last:Vector3 = points[points.size() - 1]
	var tip:Vector3 = last + (last - points[points.size() - 2]) * float(row["extend"])
	return {
		"base": base,
		"tip": tip,
		"length": base.distance_to(tip),
		"radius": float(row["radius"]),
		"profile": [],
		"skip": 0.0,
	}
func overlapOf(participantID) -> Dictionary:
	var out:Dictionary = {}
	var card = propShaftOf(participantID)
	if(card == null || utilsScript == null):
		return out
	var dir:Vector3 = card["tip"] - card["base"]
	for dollID in byID:
		var helper = helperFor(dollID)
		if(helper == null):
			continue
		var skeleton:Skeleton = helper.getSkeletonNode()
		if(skeleton == null):
			continue
		var meshes:Array = helper.getBulgeMeshesForZone(HOLE_VAGINA)
		if(meshes.empty()):
			continue
		var drawn:int = 0
		for t in OVERLAP_PROBES:
			var rest:Vector3 = utilsScript.worldToRest(skeleton, "Hips", card["base"] + dir * float(t))
			if(drawnAt(meshes[0], Vector2(rest.x, rest.y))):
				drawn += 1
		out[dollID] = float(drawn) / float(OVERLAP_PROBES.size())
	return out
func drawnAt(themesh, rest:Vector2) -> bool:
	var fit = utilsScript.fitOf(themesh)
	if(typeof(fit) != TYPE_DICTIONARY):
		return false
	var low:Vector2 = fit["restMin"]
	var high:Vector2 = fit["restMax"]
	if(rest.x < low.x || rest.y < low.y || rest.x > high.x || rest.y > high.y):
		return false
	var image = albedoImageOf(themesh)
	if(image == null):
		return false
	var uv:Vector2 = utilsScript.restToUV(fit, rest)
	if(uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0):
		return false
	var width:int = image.get_width()
	var height:int = image.get_height()
	image.lock()
	var alpha:float = image.get_pixel(int(clamp(uv.x * (width - 1), 0, width - 1)),
		int(clamp(uv.y * (height - 1), 0, height - 1))).a
	image.unlock()
	return alpha >= utilsScript.PROFILE_ALPHA
func albedoImageOf(themesh):
	var texture = utilsScript.getAlbedoTexture(themesh)
	if(texture == null):
		return null
	if(texture.has_meta(IMAGE_META)):
		var cached = texture.get_meta(IMAGE_META)
		if(cached is Image):
			return cached
		return null
	var image = texture.get_data()
	if(image != null && image.is_compressed() && image.decompress() != OK):
		image = null
	if(image == null):
		texture.set_meta(IMAGE_META, false)
	else:
		texture.set_meta(IMAGE_META, image)
	return image
func dollFor(participantID):
	var id:String = str(participantID)
	if(!byID.has(id)):
		return null
	var theDoll = byID[id]
	if(theDoll == null || !is_instance_valid(theDoll)):
		return null
	return theDoll
func helperFor(participantID):
	var theDoll = dollFor(participantID)
	if(theDoll == null || dollScript == null):
		return null
	return dollScript.forDoll(theDoll)
func charFor(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll) || !theDoll.has_method("getCharacterID")):
		return null
	var charID = theDoll.getCharacterID()
	if(charID is String):
		if(charID == ""):
			return null
		return GlobalRegistry.getCharacter(charID)
	if(typeof(charID) != TYPE_OBJECT || !is_instance_valid(charID)):
		return null
	if(!charID.has_method("getPenisSize") || !charID.has_method("getPenetrationFreeRoom")):
		return null
	return charID
