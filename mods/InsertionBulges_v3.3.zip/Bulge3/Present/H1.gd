extends Reference
const KEEP_PENIS_SCALE := true
const KEEP_SHAFT_SHAPE := true
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const Report := preload("res://Bulge3/Present/Report.gd")
const Fits := preload("res://Bulge3/Infer/Fits.gd")
const REASON_BULGES_OFF := "bulges are switched off in the player's options"
const REASON_SIZE_ZERO := "the player's bulge size modifier is zero"
const REASON_NO_PROVIDERS := "module 2 was handed no providers, so nothing could be drawn"
static func run(snapshot:Dictionary, entries:Array, rigs:Dictionary, providers) -> Dictionary:
	var report:Dictionary = {"bulges": [], "clips": [], "drops": [], "skips": [], "cleared": []}
	if(providers == null):
		skipAllEntries(report, entries, REASON_NO_PROVIDERS)
		return report
	var participants:Array = []
	if(typeof(snapshot.get("participants")) == TYPE_ARRAY):
		participants = snapshot["participants"]
	var wasDrawn:Dictionary = {}
	for entry in participants:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		var participant = entry["id"]
		var helper = providers.helperFor(participant)
		if(helper == null):
			continue
		if(!helper.dirtyMeshes.empty()):
			wasDrawn[participant] = true
		helper.clearBulgeState()
		if(KEEP_PENIS_SCALE):
			helper.restorePenisScale()
		if(KEEP_SHAFT_SHAPE):
			helper.unTaperShaftBones()
		else:
			helper.restoreShaftTaper()
	var wantsBulges:bool = bool(Settings.value("bulgesEnabled")) \
		&& bool(Settings.value("advancedShadersEnabled"))
	var sizeModifier:float = max(max(float(Settings.value("bulgeSizeModifier")),
		float(Settings.value("bulgeOralSize"))), float(Settings.value("bulgeOralSimpleSize")))
	if(!wantsBulges || sizeModifier <= 0.0):
		report["cleared"] = wasDrawn.keys()
		var offReason:String = REASON_BULGES_OFF
		if(wantsBulges):
			offReason = REASON_SIZE_ZERO
		skipAllEntries(report, entries, offReason)
		return report
	var built:Dictionary = Report.build(entries)
	var byKey:Dictionary = {}
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement = entry.get("engagement")
		if(typeof(engagement) != TYPE_DICTIONARY):
			continue
		var key:String = Report.rowKey(engagement.get("shaft"), engagement.get("hole_owner"), engagement.get("hole"))
		byKey[key] = entry
	var drew:Dictionary = {}
	for bulge in built["bulges"]:
		var key:String = Report.rowKey(bulge["shaft"], bulge["participant"], bulge["hole"])
		var entry = byKey.get(key)
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		var holeOwner = engagement["hole_owner"]
		var intent = entry.get("intent")
		var rig = rigs.get(holeOwner)
		var holeHelper = providers.helperFor(holeOwner)
		if(holeHelper == null || typeof(rig) != TYPE_DICTIONARY || typeof(intent) != TYPE_DICTIONARY):
			continue
		var centreWorld:Vector3 = restToWorld(rig, intent["centre_rest"])
		var frontWorld:Vector3 = restDirToWorld(rig, intent["front_dir_rest"])
		var travelWorld:Vector3 = restDirToWorld(rig, intent["travel_dir_rest"])
		holeHelper.applyBulge(str(bulge["hole"]), int(bulge["slot"]), centreWorld,
			centreWorld + frontWorld * float(intent["reach"]), float(intent["spread"]),
			float(intent["amplitude"]), float(intent["shade"]), float(intent["column_half"]),
			intent["shape"], centreWorld + travelWorld, float(intent["axis_depth"]))
		drew[holeOwner] = true
		var squeeze:float = float(entry.get("squeeze", 1.0))
		if(KEEP_SHAFT_SHAPE && squeeze < 1.0):
			var shaftHelper = providers.helperFor(engagement["shaft"])
			if(shaftHelper != null):
				shaftHelper.unTaperShaftBones(squeeze)
				drew[engagement["shaft"]] = true
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	for clip in built["clips"]:
		var key:String = Report.rowKey(clip["participant"], clip["hole_owner"], clip["hole"])
		var entry = byKey.get(key)
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		var shaftOwner = engagement["shaft"]
		var card = shafts.get(shaftOwner)
		var shaftHelper = providers.helperFor(shaftOwner)
		if(shaftHelper == null || !Fits.isShaft(card)):
			continue
		var base:Vector3 = card["base"]
		var tip:Vector3 = card["tip"]
		var length:float = float(card["length"])
		var dir:Vector3 = (tip - base) / length
		shaftHelper.applyShaftClip(base + dir * float(clip["clip_on_axis"]))
		drew[shaftOwner] = true
	report["bulges"] = built["bulges"]
	report["clips"] = built["clips"]
	report["drops"] = built["drops"]
	report["skips"] = built["skips"]
	var cleared:Array = []
	for participant in wasDrawn:
		if(!drew.has(participant)):
			cleared.append(participant)
	report["cleared"] = cleared
	return report
static func restToWorld(rig:Dictionary, restPoint:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().xform(restPoint)
static func restDirToWorld(rig:Dictionary, restDir:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().basis.xform(restDir).normalized()
static func skipAllEntries(report:Dictionary, entries:Array, reason:String) -> void:
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement = entry.get("engagement")
		if(typeof(engagement) != TYPE_DICTIONARY):
			continue
		report["skips"].append({
			"shaft": engagement["shaft"],
			"hole_owner": engagement["hole_owner"],
			"hole": str(engagement["hole"]),
			"reason": reason,
		})
