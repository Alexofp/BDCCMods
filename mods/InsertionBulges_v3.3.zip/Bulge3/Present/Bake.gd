extends Reference
const FieldMath := preload("res://Bulge3/Present/Field.gd")
const BAKE_SHADER := preload("res://Bulge3/Present/Bake.shader")
const SLOT_META := 4
const SLOT_LIP := 5
const SLOT_MORE := 6
const SLOT_FIRST_EXTRA := 7
const BulgeUtils := preload("res://Bulge3/Doll/BulgeUtils.gd")
const SLOT_INLINE_SAMPLES = BulgeUtils.SHAPE_TRANSPORT
static func texelsFor(slots:Array) -> int:
	var most:int = SLOT_INLINE_SAMPLES
	for slot in slots:
		if(typeof(slot) != TYPE_DICTIONARY || typeof(slot.get("shape")) != TYPE_ARRAY):
			continue
		most = int(max(most, slot["shape"].size()))
	var past:int = most - SLOT_INLINE_SAMPLES
	return SLOT_FIRST_EXTRA + int(ceil(float(max(past, 0)) / 4.0))
const SLOT_FORMAT := Image.FORMAT_RGBAF
static func slotImage(slots:Array) -> Image:
	var width:int = texelsFor(slots)
	var img := Image.new()
	img.create(width, int(max(slots.size(), 1)), false, SLOT_FORMAT)
	img.lock()
	for s in range(slots.size()):
		var slot:Dictionary = slots[s]
		var centre:Vector2 = slot["centre"]
		var front:Vector2 = slot["front"]
		var shape:Array = slot["shape"]
		img.set_pixel(0, s, Color(centre.x, centre.y, front.x, front.y))
		img.set_pixel(1, s, Color(float(slot["spread"]), float(slot["amplitude"]),
			float(slot["shade"]), float(slot["column_half"])))
		img.set_pixel(2, s, Color(sampleOf(shape, 0), sampleOf(shape, 1), sampleOf(shape, 2),
			float(slot["axis_depth"])))
		img.set_pixel(3, s, Color(sampleOf(shape, 3), sampleOf(shape, 4), sampleOf(shape, 5),
			sampleOf(shape, 6)))
		var knots:int = SLOT_INLINE_SAMPLES
		if(typeof(shape) == TYPE_ARRAY && shape.size() > SLOT_INLINE_SAMPLES):
			knots = shape.size()
		img.set_pixel(SLOT_META, s, Color(float(knots), float(slot.get("lip", 0.0)),
			float(slot.get("lip_reach", 0.0)), float(slot.get("lip_motion", 0.0))))
		var lipAt:Vector2 = slot.get("lip_at", centre)
		var lipToward:Vector2 = slot.get("lip_toward", centre)
		img.set_pixel(SLOT_LIP, s, Color(lipAt.x, lipAt.y, lipToward.x, lipToward.y))
		img.set_pixel(SLOT_MORE, s, Color(float(slot.get("radial_on", 1.0)), float(slot.get("lip_stroke", 0.0)),
			float(slot.get("plateau", FieldMath.bandPlateau())), 0.0))
		for at in range(SLOT_INLINE_SAMPLES, knots):
			var past:int = at - SLOT_INLINE_SAMPLES
			var col:int = SLOT_FIRST_EXTRA + int(past / 4)
			var lane:int = past % 4
			var had:Color = img.get_pixel(col, s)
			var value:float = float(shape[at])
			if(lane == 0):
				had.r = value
			elif(lane == 1):
				had.g = value
			elif(lane == 2):
				had.b = value
			else:
				had.a = value
			img.set_pixel(col, s, had)
	img.unlock()
	return img
static func sampleOf(shape:Array, at:int) -> float:
	if(shape.size() < 7):
		return 1.0
	return float(shape[at])
static func orientedShape(shape, uvA:Vector2, uvB:Vector2, uvBandEnd:Vector2,
		aspect:Vector2) -> Array:
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 2):
		return []
	var here:Vector2 = uvA * aspect
	var outward:Vector2 = uvB * aspect - here
	var across:Vector2 = Vector2(-outward.y, outward.x)
	var towardsTip:Vector2 = uvBandEnd * aspect - here
	var out:Array = shape.duplicate()
	if(towardsTip.dot(across) < 0.0):
		out.invert()
	return out
static func materialFor(slots:Array, bulge_aspect:Vector2 = Vector2(1, 1)) -> ShaderMaterial:
	var mat := ShaderMaterial.new()
	mat.shader = BAKE_SHADER
	var slotTex := ImageTexture.new()
	slotTex.create_from_image(slotImage(slots), 0)
	mat.set_shader_param("bulge_slots", slotTex)
	mat.set_shader_param("bulge_slot_count", slots.size())
	mat.set_shader_param("bulge_aspect", bulge_aspect)
	mat.set_shader_param("bulge_shape_fidelity", FieldMath.fidelity())
	mat.set_shader_param("bulge_rim_shape", FieldMath.rim())
	mat.set_shader_param("bulge_push_radial", FieldMath.radial())
	mat.set_shader_param("bulge_lip_soft", FieldMath.LIP_SOFT)
	mat.set_shader_param("bulge_ramp_slope_peak", FieldMath.RAMP_SLOPE_PEAK)
	mat.set_shader_param("bulge_union_overlap", FieldMath.unionOverlap())
	return mat
static func imageFrom(texture:Texture) -> Image:
	var image:Image = texture.get_data()
	if(image == null):
		return null
	image.flip_y()
	return image
static func texelOf(uv:Vector2, resolution:int) -> Vector2:
	var last:float = float(resolution - 1)
	return Vector2(clamp(floor(uv.x * float(resolution)), 0.0, last),
		clamp(floor(uv.y * float(resolution)), 0.0, last))
static func texelUV(uv:Vector2, resolution:int) -> Vector2:
	return (texelOf(uv, resolution) + Vector2(0.5, 0.5)) / float(resolution)
static func offsetAt(image:Image, uv:Vector2) -> Vector2:
	var texel:Vector2 = texelOf(uv, image.get_width())
	image.lock()
	var here:Color = image.get_pixel(int(texel.x), int(texel.y))
	image.unlock()
	return Vector2(here.r, here.g)
