extends Reference
const H1 := "H1"
const H6 := "H6"
const BACKENDS := [H1, H6]
const REASON_GLES2 := "the gles2 driver cannot take a uniform int as a loop bound"
const REASON_NO_FLOAT_TARGET := "no float render target so the signed offsets would quantise and clamp"
static func probe(gles2:bool, floatTargets:bool) -> Dictionary:
	var out := {}
	for id in BACKENDS:
		out[id] = refusalFor(str(id), gles2, floatTargets)
	return out
static func refusalFor(id:String, gles2:bool, floatTargets:bool) -> String:
	if(id == H6):
		if(gles2):
			return REASON_GLES2
		if(!floatTargets):
			return REASON_NO_FLOAT_TARGET
	return ""
