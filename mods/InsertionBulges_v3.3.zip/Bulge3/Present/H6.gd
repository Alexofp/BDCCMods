extends Reference
const Report := preload("res://Bulge3/Present/Report.gd")
const Bake := preload("res://Bulge3/Present/Bake.gd")
const Fits := preload("res://Bulge3/Infer/Fits.gd")
const BulgeUtils := preload("res://Bulge3/Doll/BulgeUtils.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const FieldMath := preload("res://Bulge3/Present/Field.gd")
const KEEP_PENIS_SCALE := true
const KEEP_SHAFT_SHAPE := true
const REASON_BULGES_OFF := "bulges are switched off in the player's options"
const REASON_SIZE_ZERO := "the player's bulge size modifier is zero"
const REASON_NO_PROVIDERS := "module 2 was handed no providers, so nothing could be drawn"
const REASON_NO_TARGETS := "H6 was handed no bake pool, so there was nowhere to compose the field"
static func run(snapshot:Dictionary, entries:Array, rigs:Dictionary, providers, targets) -> Dictionary:
	var report:Dictionary = {"bulges": [], "clips": [], "drops": [], "skips": [], "cleared": []}
	if(providers == null):
		skipAllEntries(report, entries, REASON_NO_PROVIDERS)
		return report
	if(targets == null || !targets.has_method("textureFor")):
		skipAllEntries(report, entries, REASON_NO_TARGETS)
		return report
	var participants:Array = []
	if(typeof(snapshot.get("participants")) == TYPE_ARRAY):
		participants = snapshot["participants"]
	var wasDrawn:Dictionary = {}
	for entry in participants:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		var participant = entry["id"]
		var helper = providers.helperFor(participant)
		if(helper == null):
			continue
		if(!helper.dirtyMeshes.empty()):
			wasDrawn[participant] = true
		helper.clearBulgeState()
		if(KEEP_PENIS_SCALE):
			helper.restorePenisScale()
		if(KEEP_SHAFT_SHAPE):
			helper.unTaperShaftBones()
		else:
			helper.restoreShaftTaper()
	var wantsBulges:bool = bool(Settings.value("bulgesEnabled")) \
		&& bool(Settings.value("advancedShadersEnabled"))
	var sizeModifier:float = max(max(float(Settings.value("bulgeSizeModifier")),
		float(Settings.value("bulgeOralSize"))), float(Settings.value("bulgeOralSimpleSize")))
	if(!wantsBulges || sizeModifier <= 0.0):
		report["cleared"] = wasDrawn.keys()
		var offReason:String = REASON_BULGES_OFF
		if(wantsBulges):
			offReason = REASON_SIZE_ZERO
		skipAllEntries(report, entries, offReason)
		return report
	var built:Dictionary = Report.build(entries)
	var byKey:Dictionary = {}
	for entry2 in entries:
		if(typeof(entry2) != TYPE_DICTIONARY):
			continue
		var engagement2 = entry2.get("engagement")
		if(typeof(engagement2) != TYPE_DICTIONARY):
			continue
		byKey[Report.rowKey(engagement2.get("shaft"), engagement2.get("hole_owner"), engagement2.get("hole"))] = entry2
	var perMesh:Dictionary = {}
	var drew:Dictionary = {}
	for bulge in built["bulges"]:
		var key:String = Report.rowKey(bulge["shaft"], bulge["participant"], bulge["hole"])
		var entry3 = byKey.get(key)
		if(typeof(entry3) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry3["engagement"]
		var holeOwner = engagement["hole_owner"]
		var intent = entry3.get("intent")
		var rig = rigs.get(holeOwner)
		var holeHelper = providers.helperFor(holeOwner)
		if(holeHelper == null || typeof(rig) != TYPE_DICTIONARY || typeof(intent) != TYPE_DICTIONARY):
			continue
		var centreWorld:Vector3 = restToWorld(rig, intent["centre_rest"])
		var frontWorld:Vector3 = restDirToWorld(rig, intent["front_dir_rest"])
		var travelWorld:Vector3 = restDirToWorld(rig, intent["travel_dir_rest"])
		var points = holeHelper.restBulgePoints(str(bulge["hole"]), centreWorld,
			centreWorld + frontWorld * float(intent["reach"]), centreWorld + travelWorld)
		if(typeof(points) != TYPE_DICTIONARY):
			continue
		var lipPoints = null
		if(float(intent.get("lip", 0.0)) > 0.0):
			var lipWorld:Vector3 = restToWorld(rig, intent["lip_rest"])
			lipPoints = holeHelper.restBulgePoints(str(bulge["hole"]), lipWorld,
				lipWorld + restDirToWorld(rig, intent["lip_dir_rest"]), null)
		for themesh in holeHelper.bulgeMeshesFor(str(bulge["hole"])):
			var fit = BulgeUtils.fitOf(themesh)
			if(typeof(fit) != TYPE_DICTIONARY):
				continue
			var meshKey:String = str(holeOwner) + "#" + str(themesh.get_instance_id())
			if(!perMesh.has(meshKey)):
				perMesh[meshKey] = {"mesh": themesh, "helper": holeHelper, "fit": fit, "slots": []}
			perMesh[meshKey]["slots"].append(slotFor(intent, points, fit, lipPoints))
		drew[holeOwner] = true
	for meshKey in perMesh:
		var row:Dictionary = perMesh[meshKey]
		var texture = targets.textureFor(meshKey, row["slots"], row["fit"]["aspect"])
		if(texture == null):
			continue
		row["helper"].setBakedBulge(row["mesh"], texture)
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	for clip in built["clips"]:
		var clipKey:String = Report.rowKey(clip["participant"], clip["hole_owner"], clip["hole"])
		var entry4 = byKey.get(clipKey)
		if(typeof(entry4) != TYPE_DICTIONARY):
			continue
		var engagement4:Dictionary = entry4["engagement"]
		var shaftOwner = engagement4["shaft"]
		var card = shafts.get(shaftOwner)
		var shaftHelper = providers.helperFor(shaftOwner)
		if(shaftHelper == null || !Fits.isShaft(card)):
			continue
		var base:Vector3 = card["base"]
		var tip:Vector3 = card["tip"]
		var length:float = float(card["length"])
		var dir:Vector3 = (tip - base) / length
		shaftHelper.applyShaftClip(base + dir * float(clip["clip_on_axis"]))
		drew[shaftOwner] = true
	report["bulges"] = built["bulges"]
	report["clips"] = built["clips"]
	report["drops"] = built["drops"]
	report["skips"] = built["skips"]
	var cleared:Array = []
	for participant2 in wasDrawn:
		if(!drew.has(participant2)):
			cleared.append(participant2)
	report["cleared"] = cleared
	return report
static func slotFor(intent:Dictionary, points:Dictionary, fit:Dictionary, lipPoints = null) -> Dictionary:
	var uvA:Vector2 = BulgeUtils.restToUV(fit, points["a"])
	var uvB:Vector2 = BulgeUtils.restToUV(fit, points["b"])
	var uvBand:Vector2 = BulgeUtils.restToUV(fit, points["band"])
	var lipAt:Vector2 = uvA
	var lipToward:Vector2 = uvA
	var lip:float = 0.0
	if(typeof(lipPoints) == TYPE_DICTIONARY):
		lipAt = BulgeUtils.restToUV(fit, lipPoints["a"])
		lipToward = BulgeUtils.restToUV(fit, lipPoints["b"])
		lip = float(intent.get("lip", 0.0))
	return {
		"lip_at": lipAt,
		"lip_toward": lipToward,
		"lip": lip,
		"lip_reach": float(intent.get("lip_reach", 0.0)),
		"lip_motion": float(intent.get("lip_motion", 0.0)),
		"lip_stroke": float(intent.get("lip_stroke", 0.0)),
		"radial_on": radialOnFor(intent),
		"plateau": float(intent.get("plateau", FieldMath.plateauFor(str(intent.get("zone", ""))))),
		"centre": uvA,
		"front": uvB,
		"spread": float(intent["spread"]),
		"amplitude": BulgeUtils.unfoldedAmplitude(float(intent["amplitude"]), uvA, uvB, fit["aspect"]),
		"shade": float(intent["shade"]),
		"column_half": float(intent["column_half"]),
		"shape": Bake.orientedShape(intent["shape"], uvA, uvB, uvBand, fit["aspect"]),
		"axis_depth": float(intent["axis_depth"]),
	}
static func radialOnFor(intent:Dictionary) -> float:
	if(str(intent.get("zone", "")) == "mouth"):
		return 0.0
	return 1.0
static func restToWorld(rig:Dictionary, restPoint:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().xform(restPoint)
static func restDirToWorld(rig:Dictionary, restDir:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().basis.xform(restDir).normalized()
static func skipAllEntries(report:Dictionary, entries:Array, reason:String) -> void:
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var engagement = entry.get("engagement")
		if(typeof(engagement) != TYPE_DICTIONARY):
			continue
		report["skips"].append({
			"shaft": engagement["shaft"],
			"hole_owner": engagement["hole_owner"],
			"hole": str(engagement["hole"]),
			"reason": reason,
		})
