extends Reference
const RAMP_SLOPE_PEAK := 1.5
const TUNING := {"fidelity": 0.55, "rim": 1.0, "radial": 0.0, "plateau": 0.25, "plateau_oral": 0.25}
static func fidelity() -> float:
	return float(TUNING["fidelity"])
static func rim() -> float:
	return float(TUNING["rim"])
static func radial() -> float:
	return float(TUNING["radial"])
const RADIAL_MAX := 0.5
static func setRadial(value:float) -> void:
	var live:Dictionary = TUNING
	live["radial"] = clamp(value, 0.0, 1.0) * RADIAL_MAX
static func pushDirection(outward:Vector2, along:float, across:float, halfBand:float,
		axisDepth:float, amount:float) -> Vector2:
	if(amount <= 0.0):
		return outward
	var beyond:float = sign(across) * max(abs(across) - halfBand, 0.0)
	var radialDir:Vector2 = outward * max(along + axisDepth, max(axisDepth, EPSILON)) \
		+ Vector2(-outward.y, outward.x) * beyond
	if(radialDir.length() <= EPSILON):
		return outward
	var mixed:Vector2 = outward.linear_interpolate(radialDir.normalized(), amount)
	if(mixed.length() <= EPSILON):
		return outward
	return mixed.normalized()
static func setTuning(fidelityValue:float, rimValue:float) -> bool:
	if(fidelityValue < 0.0 || fidelityValue > 1.0 || rimValue < 0.0 || rimValue > 1.0):
		push_error("Field: fidelity and rim must both be within 0..1; still " \
			+ str(fidelity()) + "/" + str(rim()))
		return false
	TUNING["fidelity"] = fidelityValue
	TUNING["rim"] = rimValue
	return true
const EPSILON := 0.0001
static func jacobianDet(slots:Array, uv:Vector2, bulge_aspect:Vector2 = Vector2(1, 1),
		clamped:bool = true, h:float = 0.001) -> float:
	var key:String = "clamped_offset"
	if(!clamped):
		key = "offset"
	var dx:Vector2 = compose(slots, uv + Vector2(h, 0.0), bulge_aspect)[key] \
		- compose(slots, uv - Vector2(h, 0.0), bulge_aspect)[key]
	var dy:Vector2 = compose(slots, uv + Vector2(0.0, h), bulge_aspect)[key] \
		- compose(slots, uv - Vector2(0.0, h), bulge_aspect)[key]
	dx = dx / (2.0 * h)
	dy = dy / (2.0 * h)
	return (1.0 - dx.x) * (1.0 - dy.y) - dy.x * dx.y
static func shapeAt(shape:Array, u:float) -> float:
	var knots:int = shape.size()
	if(knots < 2):
		return 1.0
	var f:float = clamp(u, 0.0, 1.0) * float(knots - 1)
	var low:int = int(floor(f))
	if(low >= knots - 1):
		return float(shape[knots - 1])
	return lerp(float(shape[low]), float(shape[low + 1]), smoothstep(0.0, 1.0, f - float(low)))
static func rampOf(slot:Dictionary, bulge_aspect:Vector2 = Vector2(1, 1)) -> float:
	var centre:Vector2 = slot["centre"] * bulge_aspect
	var reach:Vector2 = slot["front"] * bulge_aspect - centre
	return max(reach.length(), EPSILON)
const BAND_PLATEAU := 0.25
static func bandPlateau() -> float:
	return float(TUNING["plateau"])
static func setTipRound(value:float) -> void:
	var live:Dictionary = TUNING
	live["plateau"] = 1.0 - clamp(value, 0.0, 1.0)
static func setOralTipRound(value:float) -> void:
	var live:Dictionary = TUNING
	live["plateau_oral"] = 1.0 - clamp(value, 0.0, 1.0)
static func plateauFor(zone:String) -> float:
	if(zone == "mouth"):
		return float(TUNING["plateau_oral"])
	return bandPlateau()
static func bulgeField(uv:Vector2, slot:Dictionary, bulge_aspect:Vector2 = Vector2(1, 1)) -> Dictionary:
	var par_x:float = float(slot["spread"])
	var par_y:float = float(slot["amplitude"])
	var par_w:float = float(slot["column_half"])
	if(par_x <= EPSILON || par_y <= EPSILON):
		return {"offset": Vector2.ZERO, "weight": 0.0, "lit": 0.0}
	var p:Vector2 = uv * bulge_aspect
	var c:Vector2 = slot["centre"] * bulge_aspect
	var reach:Vector2 = slot["front"] * bulge_aspect - c
	var ramp:float = max(reach.length(), EPSILON)
	var outward:Vector2 = reach / ramp
	var rel:Vector2 = p - c
	var along:float = rel.dot(outward)
	var across:float = rel.dot(Vector2(-outward.y, outward.x))
	var plateau:float = par_w * float(slot.get("plateau", bandPlateau()))
	if(across < 0.0):
		plateau = par_w
	var h:float = clamp(1.0 - max(abs(across) - plateau, 0.0) / (par_x + par_w - plateau), 0.0, 1.0)
	h = h * h * (3.0 - 2.0 * h)
	var u:float = clamp(0.5 + across / max(2.0 * par_w, EPSILON), 0.0, 1.0)
	var profile:float = shapeAt(slot["shape"], u)
	h = h * lerp(1.0, profile, fidelity())
	var g:float = smoothstep(-ramp, 0.0, along)
	var push:Vector2 = pushDirection(outward, along, across, par_w, float(slot["axis_depth"]),
		radial() * float(slot.get("radial_on", 1.0)))
	var weight:float = h * g
	var axis:float = -float(slot["axis_depth"])
	var r:float = max(float(slot["axis_depth"]) + par_y, EPSILON)
	var tube:float = clamp(1.0 - abs(along - axis) / r, 0.0, 1.0)
	var lit:float = lerp(weight, h * tube, rim())
	return {"offset": push * (par_y * weight) / bulge_aspect, "weight": weight, "lit": lit}
const LIP_SOFT := 1.25
static func lipField(uv:Vector2, slot:Dictionary, bulge_aspect:Vector2 = Vector2(1, 1)) -> Vector2:
	var lip:float = float(slot.get("lip", 0.0))
	var reach:float = float(slot.get("lip_reach", 0.0))
	if(lip <= EPSILON || reach <= EPSILON):
		return Vector2.ZERO
	var at:Vector2 = slot["lip_at"] * bulge_aspect
	var along:Vector2 = slot["lip_toward"] * bulge_aspect - at
	if(along.length() <= EPSILON):
		return Vector2.ZERO
	var rel:Vector2 = uv * bulge_aspect - at
	var r:float = rel.length()
	var f:float = clamp(1.0 - r / reach, 0.0, 1.0)
	f = f * f * (3.0 - 2.0 * f)
	var motion:int = int(round(float(slot.get("lip_motion", 0.0))))
	if(motion == 3):
		var moved:Vector2 = along.normalized() * float(slot.get("lip_stroke", 0.0)) * lip * f
		var opened:Dictionary = slot.duplicate()
		opened["lip_motion"] = 0.0
		return moved / bulge_aspect + lipField(uv - moved / bulge_aspect, opened, bulge_aspect)
	if(motion == 1):
		return -along.normalized() * lip * f / bulge_aspect
	if(motion == 2):
		return along.normalized() * lip * f / bulge_aspect
	if(r <= EPSILON):
		return Vector2.ZERO
	var soft:float = lip * LIP_SOFT
	return rel * (lip / sqrt(r * r + soft * soft)) * f / bulge_aspect
const UNION_OVERLAP := 0.3
const UNION := {"overlap": UNION_OVERLAP}
static func unionOverlap() -> float:
	return float(UNION["overlap"])
static func setUnionOverlap(value:float) -> void:
	var live:Dictionary = UNION
	live["overlap"] = clamp(value, 0.0, 1.0)
static func unionOf(offsets:Array) -> Vector2:
	var total:Vector2 = Vector2.ZERO
	var sum:float = 0.0
	var most:float = 0.0
	for one in offsets:
		total += one
		sum += one.length()
		most = max(most, one.length())
	if(sum <= 0.0):
		return total
	return total * ((most + unionOverlap() * (sum - most)) / sum)
static func compose(slots:Array, uv:Vector2, bulge_aspect:Vector2 = Vector2(1, 1)) -> Dictionary:
	var offset:Vector2 = Vector2.ZERO
	var offsets:Array = []
	var field:float = 0.0
	var shade:float = 0.0
	var bound:float = 0.0
	var strongest:float = 0.0
	var contributors:int = 0
	var lipped:Vector2 = Vector2.ZERO
	for slot in slots:
		lipped += lipField(uv, slot, bulge_aspect)
	var at:Vector2 = uv - lipped
	for slot in slots:
		var one:Dictionary = bulgeField(at, slot, bulge_aspect)
		offsets.append(one["offset"])
		field = max(field, float(one["lit"]))
		shade = max(shade, float(one["lit"]) * float(slot["shade"]))
		if(one["offset"] == Vector2.ZERO):
			continue
		contributors += 1
		var push:float = (one["offset"] * bulge_aspect).length()
		if(contributors == 1 || push > strongest):
			strongest = push
			bound = rampOf(slot, bulge_aspect) / RAMP_SLOPE_PEAK
	offset = unionOf(offsets)
	var length:float = (offset * bulge_aspect).length()
	var clamped:Vector2 = offset
	if(bound > 0.0 && length > bound):
		clamped = offset * (bound / length)
	var ratio:float = 0.0
	if(bound > 0.0):
		ratio = length / bound
	offset += lipped
	clamped += lipped
	return {
		"offset": offset, "clamped_offset": clamped, "field": field, "shade": shade,
		"bound": bound, "length": length, "ratio": ratio, "contributors": contributors,
	}
