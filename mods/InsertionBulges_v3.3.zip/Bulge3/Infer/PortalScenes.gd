extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Fits := preload("res://Bulge3/Infer/Fits.gd")
const PORTAL_HOLES := ["vagina", "anus"]
const STROKE_REFERENCE_LENGTH := 1.678
const TABLE := {
	"Player/StageScene3D/Scenes/SexPortal.gd": {
		"shaft": "doll0", "hole_owner": "doll1",
		"portal": {"owner": "doll0", "zone": "hand.R"},
	},
	"Player/StageScene3D/Scenes/SexPortalProxy.gd": {
		"shaft": "doll2", "hole_owner": "doll1",
		"portal": {"owner": "doll0", "zone": "hand.R"},
	},
	"Player/StageScene3D/Scenes/SexPortalMasturbation.gd": {
		"shaft": "doll2", "hole_owner": "doll0",
	},
}
static func contribute(snapshot, _notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !TABLE.has(path)):
		return []
	var roster = snapshot.get("participants")
	if(typeof(roster) != TYPE_ARRAY):
		return []
	var row:Dictionary = TABLE[path]
	var shaftOwner:String = str(row["shaft"])
	var holeOwner:String = str(row["hole_owner"])
	var shaftEntry = entryOf(roster, shaftOwner)
	var holeEntry = entryOf(roster, holeOwner)
	if(shaftEntry == null || holeEntry == null):
		return []
	if(shaftEntry.get("has_shaft") != true):
		return []
	if(!row.has("portal")):
		return [Evidence.item(
			Evidence.SRC_PORTAL,
			Evidence.CLAIM_INSIDE,
			{
				Evidence.SUBJ_SHAFT: shaftOwner,
				Evidence.SUBJ_HOLE_OWNER: holeOwner,
			},
			true,
			Evidence.CONF_RUNTIME,
			{"scene_path": path}
		)]
	var measured = transferred(snapshot, row, shaftOwner, holeOwner, "")
	if(measured == null):
		return []
	return [Evidence.item(
		Evidence.SRC_PORTAL,
		Evidence.CLAIM_PAIRING,
		{
			Evidence.SUBJ_SHAFT: shaftOwner,
			Evidence.SUBJ_HOLE_OWNER: holeOwner,
			Evidence.SUBJ_HOLE: str(measured["hole"]),
		},
		true,
		Evidence.CONF_RUNTIME,
		measured["measures"]
	)]
static func measuresFor(snapshot, shaftOwner, holeOwner, holeID:String):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !TABLE.has(path)):
		return null
	var row:Dictionary = TABLE[path]
	if(!row.has("portal") || str(row["shaft"]) != str(shaftOwner) \
			|| str(row["hole_owner"]) != str(holeOwner)):
		return null
	var measured = transferred(snapshot, row, str(shaftOwner), str(holeOwner), holeID)
	if(measured == null):
		return null
	return measured["measures"]
static func owns(snapshot, shaftOwner, holeOwner) -> bool:
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return false
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !TABLE.has(path)):
		return false
	var row:Dictionary = TABLE[path]
	return row.has("portal") && str(row["shaft"]) == str(shaftOwner) \
		&& str(row["hole_owner"]) == str(holeOwner)
static func transferred(snapshot:Dictionary, row:Dictionary, shaftOwner:String, holeOwner:String,
		holeID:String):
	var shafts = snapshot.get("shafts")
	var holes = snapshot.get("holes")
	var props = snapshot.get("props")
	if(typeof(shafts) != TYPE_DICTIONARY || typeof(holes) != TYPE_DICTIONARY \
			|| typeof(props) != TYPE_DICTIONARY):
		return null
	var card = shafts.get(shaftOwner)
	if(!Fits.isShaft(card)):
		return null
	var length:float = float(card["length"])
	if(length < Fits.MIN_SHAFT_LENGTH):
		return null
	var portal:Dictionary = row["portal"]
	var owned = props.get(str(portal["owner"]))
	if(typeof(owned) != TYPE_DICTIONARY):
		return null
	var base:Vector3 = card["base"]
	var tip:Vector3 = card["tip"]
	var dir:Vector3 = (tip - base) / length
	var mouth = openingOf(owned.get(str(portal["zone"])), base, dir)
	if(typeof(mouth) != TYPE_VECTOR3):
		return null
	var along:float = clamp((mouth - base).dot(dir), 0.0, length)
	var depth:float = length - along
	if((mouth - (base + dir * along)).length() > Fits.LATERAL_TOLERANCE_OTHER):
		return null
	var drawnAlong:float = clamp(along * length / STROKE_REFERENCE_LENGTH, 0.0, length)
	depth = length - drawnAlong
	var hole = holeFor(holes, holeOwner, holeID)
	if(hole == null):
		return null
	var oversize:Dictionary = {}
	if(typeof(snapshot.get("oversize")) == TYPE_DICTIONARY):
		oversize = snapshot["oversize"]
	var candidate:Dictionary = {
		"shaft": shaftOwner,
		"hole_owner": holeOwner,
		"hole": hole["id"],
		"along": drawnAlong,
		"depth": depth,
		"clip_along": along,
		"entry": hole["pos"],
		"axis": portalAxis(snapshot, holeOwner, hole["inward"]),
		"fit": 0.0,
	}
	return {"hole": hole["id"], "measures": portalMeasures(candidate, card, oversize, length)}
const PORTAL_AXIS_REST := Vector3(0.0, 1.0, 0.0)
static func portalAxis(snapshot:Dictionary, holeOwner:String, inward:Vector3) -> Vector3:
	var rigs = snapshot.get("rig")
	if(typeof(rigs) != TYPE_DICTIONARY || typeof(rigs.get(holeOwner)) != TYPE_DICTIONARY \
			|| typeof(rigs[holeOwner].get("hips")) != TYPE_TRANSFORM):
		return inward
	var hips:Transform = rigs[holeOwner]["hips"]
	return hips.affine_inverse().basis.xform(PORTAL_AXIS_REST).normalized()
static func openingOf(points, base:Vector3, dir:Vector3):
	if(typeof(points) == TYPE_VECTOR3):
		return points
	if(typeof(points) != TYPE_ARRAY):
		return null
	var best = null
	for point in points:
		if(typeof(point) != TYPE_VECTOR3):
			continue
		if(best == null || (point - base).dot(dir) < (best - base).dot(dir)):
			best = point
	return best
static func portalMeasures(candidate:Dictionary, card, oversize:Dictionary, length:float) -> Dictionary:
	var measures:Dictionary = Fits.measuresOf(candidate, card, oversize)
	var axis:Vector3 = candidate["axis"]
	var tip:Vector3 = candidate["entry"] + axis * float(candidate["depth"])
	measures["shaft_tip"] = tip
	measures["shaft_base"] = tip - axis * length
	measures["clip_skin"] = 0.0
	measures["clip_along"] = float(candidate["clip_along"])
	measures["deadzone"] = 0.0
	return measures
static func holeFor(holes:Dictionary, holeOwner:String, wanted:String):
	var tried:Array = PORTAL_HOLES
	if(wanted != ""):
		tried = [wanted]
	for holeID in tried:
		var hole = Fits.holeAt(holes, holeOwner, holeID)
		if(typeof(hole) != TYPE_DICTIONARY || typeof(hole.get("pos")) != TYPE_VECTOR3 \
				|| typeof(hole.get("inward")) != TYPE_VECTOR3):
			continue
		return {"id": holeID, "pos": hole["pos"], "inward": hole["inward"]}
	return null
static func entryOf(roster:Array, id:String):
	for entry in roster:
		if(typeof(entry) == TYPE_DICTIONARY && str(entry.get("id")) == id):
			return entry
	return null
