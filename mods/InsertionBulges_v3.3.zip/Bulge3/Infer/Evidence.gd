extends Reference
const SRC_TAPER := "taper"
const SRC_ENGINE := "engine"
const SRC_ORAL_HINT := "oralhint"
const SRC_DECLARATION := "declaration"
const SRC_GEOMETRY := "geometry"
const SRC_CLIP_NAME := "clipname"
const SRC_DOLL_STATE := "dollstate"
const SRC_CUM_INSIDE := "cuminside"
const SRC_PORTAL := "portal"
const SRC_OVERLAP := "overlap"
const CLAIM_MOUTH_SHAFT := "mouth_shaft"
const CLAIM_PAIRING := "pairing"
const CLAIM_INSIDE := "inside"
const SUBJ_SHAFT := "shaft"
const SUBJ_HOLE_OWNER := "hole_owner"
const SUBJ_HOLE := "hole"
const CONF_RUNTIME := 1
const CONF_ENGINE := 3
const CONF_AUTHORED := 2
const CROTCH_AS := {"anus": "vagina"}
static func oneCrotchHole(items:Array) -> Array:
	var out:Array = []
	for one in items:
		if(typeof(one) == TYPE_DICTIONARY && typeof(one.get("subject")) == TYPE_DICTIONARY \
				&& CROTCH_AS.has(str(one["subject"].get(SUBJ_HOLE)))):
			var moved:Dictionary = one.duplicate()
			moved["subject"] = one["subject"].duplicate()
			moved["subject"][SUBJ_HOLE] = CROTCH_AS[str(one["subject"][SUBJ_HOLE])]
			one = moved
		out.append(one)
	return out
static func item(source, claim, subject:Dictionary, holds:bool, confidence:int, readOff:Dictionary) -> Dictionary:
	return {
		"source": str(source),
		"claim": str(claim),
		"subject": subject,
		"holds": holds,
		"confidence": confidence,
		"read_off": readOff,
	}
static func mouthShaftMap(items:Array) -> Dictionary:
	var out:Dictionary = {}
	for one in items:
		if(typeof(one) != TYPE_DICTIONARY || str(one.get("claim")) != CLAIM_MOUTH_SHAFT):
			continue
		var subject = one.get("subject")
		if(typeof(subject) != TYPE_DICTIONARY || subject.get(SUBJ_SHAFT) == null):
			continue
		out[str(subject[SUBJ_SHAFT])] = one["holds"] == true
	return out
static func declaredPairs(items:Array) -> Array:
	var out:Array = []
	for one in items:
		if(typeof(one) != TYPE_DICTIONARY || str(one.get("claim")) != CLAIM_INSIDE):
			continue
		if(one.get("holds") != true):
			continue
		var subject = one.get("subject")
		if(typeof(subject) != TYPE_DICTIONARY):
			continue
		if(subject.get(SUBJ_SHAFT) == null || subject.get(SUBJ_HOLE_OWNER) == null):
			continue
		out.append({
			"shaft": subject[SUBJ_SHAFT],
			"hole_owner": subject[SUBJ_HOLE_OWNER],
		})
	return out
