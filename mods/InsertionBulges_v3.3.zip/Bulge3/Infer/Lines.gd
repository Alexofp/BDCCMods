extends Reference
static func linesOf(source:String) -> Array:
	var lines:Array = []
	for line in source.split("\n"):
		var quote:String = ""
		var i:int = 0
		var cut:int = -1
		while(i < line.length()):
			var ch:String = line.substr(i, 1)
			if(quote != ""):
				if(ch == "\\"):
					i += 1
				elif(ch == quote):
					quote = ""
			elif(ch == "\"" || ch == "'"):
				quote = ch
			elif(ch == "#"):
				cut = i
				break
			i += 1
		if(cut < 0):
			cut = line.length()
		lines.append(line.substr(0, cut))
	return lines
