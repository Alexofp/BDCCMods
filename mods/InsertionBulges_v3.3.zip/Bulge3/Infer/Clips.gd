extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const READ_FAILED:String = "cannotread"
const PRE_INSIDE_TOKEN:String = "PreInside"
const INSIDE_TOKEN:String = "Inside"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("clips")) != TYPE_DICTIONARY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_CLIP_OF)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_CLIP_NAME)
		return []
	var items:Array = []
	for pid in snapshot["clips"]:
		var data = snapshot["clips"][pid]
		if(typeof(data) != TYPE_DICTIONARY):
			continue
		var clip = data.get("clip")
		if(typeof(clip) != TYPE_STRING || clip == ""):
			continue
		items.append(reading(pid, clip, data.get("phase")))
	return items
static func reading(pid, clip:String, phase) -> Dictionary:
	var preInside:bool = clip.find(PRE_INSIDE_TOKEN) >= 0
	var inside:bool = !preInside && clip.find(INSIDE_TOKEN) >= 0
	return Evidence.item(
		Evidence.SRC_CLIP_NAME,
		Evidence.CLAIM_INSIDE,
		{Evidence.SUBJ_SHAFT: pid},
		inside,
		Evidence.CONF_RUNTIME,
		{
			"clip": clip,
			"knot": clip.find("Knot") >= 0,
			"suck": clip.find("Suck") >= 0,
			"lick": clip.find("Lick") >= 0,
			"ride": clip.find("Ride") >= 0,
			"grind": clip.find("Grind") >= 0,
			"fast": clip.find("Fast") >= 0,
			"pre_inside": preInside,
			"phase": phase,
		}
	)
