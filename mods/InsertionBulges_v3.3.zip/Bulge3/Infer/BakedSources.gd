extends Reference
const TABLE := {
"Player/StageScene3D/Scenes/BDSMMachineAltFuck.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"fastdouble": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"insidedouble": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"sexdouble": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/BDSMMachineFuck.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"fastdouble": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"insidedouble": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"sexdouble": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"wand": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/BreastFeeding.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"feed": {
"declaration": [  ],
"oral": [  ]
},
"feedalt": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teasealt": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/BreastGroping.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"grope": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/ButtStack.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/ButtStackSex.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll2"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"fastdown": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fastdown"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"fastup": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fastup"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"insidedown": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "insidedown"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"insideup": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "insideup"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"npc2Cum": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npc2Cum"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"sexdown": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexdown"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"sexup": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexup"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Choking.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"choke": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"hard": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Cryopod.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Cuddling.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"squirm": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Duo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"allfours": {
"declaration": [  ],
"oral": [  ]
},
"crawl": {
"declaration": [  ],
"oral": [  ]
},
"further": {
"declaration": [  ],
"oral": [  ]
},
"sit": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/GivingBirth.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/HangingDuo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/HangingSex.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/HangingSexFuckmachine.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/HangingSolo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Hogtied.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/HorsecockDildoSex.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Hug.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"hug": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"kiss": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Massage.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"back": {
"declaration": [  ],
"oral": [  ]
},
"butt": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Nothing.gd": {
"": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/PuppyDuo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"sit": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/PuppyFeetCrotch.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"crotch": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/PuppyPinned.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"pinned": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/PuppySexAllFours.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/PuppySexOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"grind": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/PuppySolo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Rekt.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"end": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"kill": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexAllFours.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fastflop": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fastflop"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"insideflop": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "insideflop"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sexflop": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexflop"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teaseflop": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexBehind.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexCowgirl.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexCowgirlAlt.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexCowgirlChoke.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fastuncon": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fastuncon"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"insideuncon": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "insideuncon"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sexuncon": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexuncon"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teaseuncon": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexFaceSitting.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"grind": {
"declaration": [  ],
"oral": [  ]
},
"sit": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexFeetPlay.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"crotch": {
"declaration": [  ],
"oral": [  ]
},
"head": {
"declaration": [  ],
"oral": [  ]
},
"pin": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexFisting.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexFreeStanding.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexFullNelson.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexHandjob.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexMissionary.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"grind": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"start": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexPortal.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexPortalMasturbation.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexPortalOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"hold": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"lickfast": {
"declaration": [  ],
"oral": [  ]
},
"suck": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suck"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"suckfast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckfast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexPortalProxy.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexPortalRide.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"cum": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "cum"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexReverseCowgirl.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexRimming.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexStanding.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexStart.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"defeated": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SexTribadism.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Sleeping.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"sleep": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Slutwall.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SlutwallRide.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SlutwallSex.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SlutwallSexOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"blowjob": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "blowjob"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"handjob": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Solo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"custom": {
"declaration": [  ],
"oral": [  ]
},
"sit": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Spanking.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"fastonce": {
"declaration": [  ],
"oral": [  ]
},
"spank": {
"declaration": [  ],
"oral": [  ]
},
"spankonce": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Stocks.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/StocksSex.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/StocksSexOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"pussy": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/StocksSpitroast.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Sybian.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/SybianOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"blowjob": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "blowjob"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"blowjobfast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "blowjobfast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"hold": {
"declaration": [  ],
"oral": [  ]
},
"hump": {
"declaration": [  ],
"oral": [  ]
},
"humpfast": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"intense": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"lickfast": {
"declaration": [  ],
"oral": [  ]
},
"ride": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/TentaclesSex.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Urinal.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/UrinalPeeing.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"pee": {
"declaration": [  ],
"oral": [  ]
},
"peefemale": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/UrinalSex.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/WoodenHorseDuo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"lightstruggle": {
"declaration": [  ],
"oral": [  ]
},
"struggle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/WoodenHorseSolo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"bent": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"lightstruggle": {
"declaration": [  ],
"oral": [  ]
},
"struggle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes/Yoga.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"catcow": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/Beg.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"beg": {
"declaration": [  ],
"oral": [  ]
},
"pat": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/CanineDildoSex.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"hover": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"knot": {
"declaration": [  ],
"oral": [  ]
},
"knotfast": {
"declaration": [  ],
"oral": [  ]
},
"knotinside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/ChairCrotchSniff.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"grind": {
"declaration": [  ],
"oral": [  ]
},
"prepare": {
"declaration": [  ],
"oral": [  ]
},
"sniff": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/ChairOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"lickfast": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"suck": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suck"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"suckfast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckfast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"suckinside": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckinside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/CheckPaw.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"beans": {
"declaration": [  ],
"oral": [  ]
},
"check": {
"declaration": [  ],
"oral": [  ]
},
"crotch": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/FleshlightSit.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"standfast": {
"declaration": [  ],
"oral": [  ]
},
"standinside": {
"declaration": [  ],
"oral": [  ]
},
"standsex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/GeneratorOral.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/Grope.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"grope": {
"declaration": [  ],
"oral": [  ]
},
"gropefast": {
"declaration": [  ],
"oral": [  ]
},
"pat": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"strokefast": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"watchrub": {
"declaration": [  ],
"oral": [  ]
},
"watchstroke": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/MilkingProstate.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"milk": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/MilkingProstateFuck.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/MilkingStallDuo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"milk": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
},
"watch": {
"declaration": [  ],
"oral": [  ]
},
"watchcum": {
"declaration": [  ],
"oral": [  ]
},
"watchfast": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/MilkingStallSolo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/PawJobMutual.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"rubfast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/PawJobUnderTable.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/RopesOralSex.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"lickfast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/RopesSex.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"lick": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "lick"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"lickstroke": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "lickstroke"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/RopesSolo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"struggle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SelfSuck.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"fuck": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fuck"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"fuckfast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fuckfast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"fuckinside": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fuckinside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"inside": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"npcCum": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npcCum"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"sex": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll0"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/Sex69.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"FF": {
"declaration": [  ],
"oral": [  ]
},
"FM": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "FM"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"MF": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "MF"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"MM": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "MM"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
}, {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "MM"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll1"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexAgainstWall.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexCowgirlAmazon.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexDP.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"npcCum": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npcCum"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npcCum"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexDoubleDown.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sexhands": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexhands"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sexnohand": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexnohand"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teasenohand": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "teasenohand"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexFleshlight.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexGangbang.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll3"
}
} ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll3"
}
} ]
},
"npcCum": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npcCum"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npcCum"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "npcCum"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll3"
}
} ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll3"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexLotus.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexLowDoggy.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexMatingPress.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexOralForced.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"lickfast": {
"declaration": [  ],
"oral": [  ]
},
"suck": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suck"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"suckfast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckfast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"suckinside": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckinside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexOralTable.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"grind": {
"declaration": [  ],
"oral": [  ]
},
"grindfast": {
"declaration": [  ],
"oral": [  ]
},
"hover": {
"declaration": [  ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"peefem": {
"declaration": [  ],
"oral": [  ]
},
"peemale": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"suck": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suck"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"suckfast": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckfast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"suckinside": {
"declaration": [  ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "suckinside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll1",
"shaft": "doll0"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexOverTable.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexPawLick.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"strokefast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "strokefast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"strokeinside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "strokeinside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"strokesex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "strokesex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"stroketease": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexPawjob.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"thrust": {
"declaration": [  ],
"oral": [  ]
},
"thrustfast": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexPinnedBehind.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexSpitroast.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [ {
"claim": "pairing",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "oralhint",
"subject": {
"hole": "mouth",
"hole_owner": "doll0",
"shaft": "doll2"
}
} ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexStandRide.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexStealth.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"fastbusy": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fastbusy"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"insidebusy": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "insidebusy"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"rub": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "rub"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"rubbusy": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "rubbusy"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"sexbusy": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sexbusy"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teasebusy": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexTrain.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll1",
"shaft": "doll0"
}
}, {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll2"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/SexVent.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"finger": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"lick": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/Showering.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"body": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/ShoweringDuo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"shower": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teasehug": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/TFLook.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/TentaclesTease.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/Yoga2.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"plow": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes2/Zonked.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"rub": {
"declaration": [  ],
"oral": [  ]
},
"rubcum": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"strokecum": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/EggLaying.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"0": {
"declaration": [  ],
"oral": [  ]
},
"after": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/PuppySexCowgirl.gd": {
"": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": ""
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"fast": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "fast"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"inside": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "inside"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"sex": {
"declaration": [ {
"claim": "inside",
"confidence": 2,
"holds": true,
"read_off": {
"pose": "sex"
},
"source": "declaration",
"subject": {
"hole_owner": "doll0",
"shaft": "doll1"
}
} ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/PuppySexStart.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"pat": {
"declaration": [  ],
"oral": [  ]
},
"pet": {
"declaration": [  ],
"oral": [  ]
},
"sad": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/SoloBigEgg.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"sit": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesBondage.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"bondage": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"kneel": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"start": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"strokefast": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesChoke.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesCuddle.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"breasts": {
"declaration": [  ],
"oral": [  ]
},
"breaststease": {
"declaration": [  ],
"oral": [  ]
},
"cuddle": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"fast": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"sex": {
"declaration": [  ],
"oral": [  ]
},
"stroke": {
"declaration": [  ],
"oral": [  ]
},
"strokefast": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesDeepthroat.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesDuo.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"dance": {
"declaration": [  ],
"oral": [  ]
},
"danceFast": {
"declaration": [  ],
"oral": [  ]
},
"eat": {
"declaration": [  ],
"oral": [  ]
},
"glare": {
"declaration": [  ],
"oral": [  ]
},
"idle": {
"declaration": [  ],
"oral": [  ]
},
"poke": {
"declaration": [  ],
"oral": [  ]
},
"sleep": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"whip": {
"declaration": [  ],
"oral": [  ]
},
"whip2": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesGangbang.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"inside": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
},
"teasedef": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesGrope.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"grope": {
"declaration": [  ],
"oral": [  ]
},
"gropefast": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesSleepOn.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"cum": {
"declaration": [  ],
"oral": [  ]
},
"sleep": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
},
"Player/StageScene3D/Scenes3/TentaclesStroke.gd": {
"": {
"declaration": [  ],
"oral": [  ]
},
"tease": {
"declaration": [  ],
"oral": [  ]
}
}
}
