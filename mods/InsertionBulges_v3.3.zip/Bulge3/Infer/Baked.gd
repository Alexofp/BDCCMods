extends Reference
const BakedSources := preload("res://Bulge3/Infer/BakedSources.gd")
const Oral := preload("res://Bulge3/Infer/Oral.gd")
const Declaration := preload("res://Bulge3/Infer/Declaration.gd")
static func oralContribute(snapshot, notes:Array):
	var baked = bakedEntry(snapshot)
	if(baked != null):
		return baked["oral"].duplicate(true)
	return Oral.contribute(snapshot, notes)
static func declarationContribute(snapshot, notes:Array):
	if(typeof(snapshot) == TYPE_DICTIONARY && notInside().has(str(snapshot.get("pose", "")))):
		return []
	var baked = bakedEntry(snapshot)
	if(baked != null):
		return baked["declaration"].duplicate(true)
	return Declaration.contribute(snapshot, notes)
static func bakedEntry(snapshot):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !BakedSources.TABLE.has(path)):
		return null
	var byPose = BakedSources.TABLE[path]
	var pose:String = str(snapshot.get("pose", ""))
	if(typeof(byPose) != TYPE_DICTIONARY || !byPose.has(pose)):
		return null
	return byPose[pose]
const NOT_INSIDE := {"built": false, "names": {}}
static func notInside() -> Dictionary:
	var cache:Dictionary = NOT_INSIDE
	if(cache["built"]):
		return cache["names"]
	cache["built"] = true
	for path in BakedSources.TABLE:
		var byPose = BakedSources.TABLE[path]
		var declares:bool = false
		for pose in byPose:
			if(!byPose[pose]["declaration"].empty()):
				declares = true
		if(!declares):
			continue
		for pose in byPose:
			if(str(pose) != "" && byPose[pose]["declaration"].empty()):
				cache["names"][str(pose)] = true
	return cache["names"]
