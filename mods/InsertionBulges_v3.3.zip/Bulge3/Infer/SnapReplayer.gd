const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Taper := preload("res://Bulge3/Infer/Taper.gd")
const Acts := preload("res://Bulge3/Infer/Acts.gd")
const Baked := preload("res://Bulge3/Infer/Baked.gd")
const PortalScenes := preload("res://Bulge3/Infer/PortalScenes.gd")
const Overlap := preload("res://Bulge3/Infer/Overlap.gd")
const Clips := preload("res://Bulge3/Infer/Clips.gd")
const FinalState := preload("res://Bulge3/Infer/FinalState.gd")
const CumInside := preload("res://Bulge3/Infer/CumInside.gd")
const Fits := preload("res://Bulge3/Infer/Fits.gd")
const NOTE_UNREADABLE := "unreadable: "
const SILENCED := {}
static func infer(snapshot, age:float) -> Dictionary:
	var notes:Array = []
	var items:Array = []
	var taperItems = Taper.contribute(snapshot, age, notes)
	if(typeof(taperItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_TAPER)
	else:
		for one in taperItems:
			items.append(one)
	var actItems = Acts.contribute(snapshot, notes)
	if(typeof(actItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_ENGINE)
	else:
		for one in actItems:
			items.append(one)
	var oralItems = Baked.oralContribute(snapshot, notes)
	if(typeof(oralItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_ORAL_HINT)
	else:
		for one in oralItems:
			items.append(one)
	var declaredItems = Baked.declarationContribute(snapshot, notes)
	if(typeof(declaredItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_DECLARATION)
	else:
		for one in declaredItems:
			items.append(one)
	var clipItems = Clips.contribute(snapshot, notes)
	if(typeof(clipItems) != TYPE_ARRAY):
		if(typeof(snapshot) == TYPE_DICTIONARY && snapshot.has("clips")):
			notes.append(NOTE_UNREADABLE + Evidence.SRC_CLIP_NAME)
	else:
		for one in clipItems:
			items.append(one)
	var dollStateItems = FinalState.contribute(snapshot, notes)
	if(typeof(dollStateItems) != TYPE_ARRAY):
		if(typeof(snapshot) == TYPE_DICTIONARY && snapshot.has("doll_state")):
			notes.append(NOTE_UNREADABLE + Evidence.SRC_DOLL_STATE)
	else:
		for one in dollStateItems:
			items.append(one)
	var cumStateItems = CumInside.contribute(snapshot, notes)
	if(typeof(cumStateItems) != TYPE_ARRAY):
		if(typeof(snapshot) == TYPE_DICTIONARY && snapshot.has("cum_state")):
			notes.append(NOTE_UNREADABLE + Evidence.SRC_CUM_INSIDE)
	else:
		for one in cumStateItems:
			items.append(one)
	var portalItems = PortalScenes.contribute(snapshot, notes)
	if(typeof(portalItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_PORTAL)
	else:
		for one in portalItems:
			items.append(one)
	var overlapItems = Overlap.contribute(snapshot, notes)
	if(typeof(overlapItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_OVERLAP)
	else:
		for one in overlapItems:
			items.append(one)
	if(!SILENCED.empty()):
		var kept:Array = []
		for one in items:
			if(typeof(one) != TYPE_DICTIONARY || !SILENCED.has(str(one.get("source")))):
				kept.append(one)
		items = kept
	var geometryItems = Fits.contribute(snapshot, items, notes)
	if(typeof(geometryItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_GEOMETRY)
	else:
		for one in geometryItems:
			items.append(one)
	return {"items": Evidence.oneCrotchHole(items), "notes": notes}
