extends Reference
const Evidence := preload("res://Bulge3/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge3/Observe/Snapshot.gd")
const Lines := preload("res://Bulge3/Infer/Lines.gd")
const Oral := preload("res://Bulge3/Infer/Oral.gd")
const CUM_CALL:String = "startCumInside("
const SOLO_CALL:String = "startCumInsideSolo("
const INTENSITY_CALL:String = "getCumIntensity("
const CUM_FLAGS:Dictionary = {"pcCum": 0, "npcCum": 1, "npc2Cum": 2, "npc3Cum": 3}
const FLAG_AMBIGUOUS:int = -2
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || !snapshot.has("scene_source")):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_SCENE_SOURCE)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_DECLARATION)
		return []
	var source = snapshot["scene_source"]
	if(source == null):
		return []
	if(typeof(source) != TYPE_STRING || source == ""):
		notes.append(READ_FAILED + ": " + Evidence.SRC_DECLARATION)
		return []
	var known:Dictionary = {}
	for entry in Oral.rosterOf(snapshot):
		if(typeof(entry) == TYPE_DICTIONARY && entry.get("id") != null):
			known[str(entry["id"])] = true
	var lines:Array = Lines.linesOf(source)
	var blocks:Array = [lines]
	var pose:String = str(snapshot.get("pose", ""))
	if(pose != ""):
		var unguarded:Array = []
		blocks = Oral.regionsFor(lines, pose, unguarded)
		blocks.append(unguarded)
	var owners:Dictionary = cumOwners(lines)
	var items:Array = []
	for block in blocks:
		for line in block:
			var owner:int = int(owners.get(line.strip_edges(), -1))
			for declared in penetrationsIn(line):
				if(owner >= 0 && int(declared[0]) == owner && int(declared[1]) != owner):
					var swapped = declared[0]
					declared[0] = declared[1]
					declared[1] = swapped
				var receiver = Oral.dollAt(known, int(declared[0]))
				var penetrator = Oral.dollAt(known, int(declared[1]))
				if(receiver == null || penetrator == null):
					continue
				if(str(receiver) == str(penetrator)):
					continue
				if(!alreadyHeld(items, penetrator, receiver)):
					items.append(penetration(penetrator, receiver, pose))
	return items
static func penetration(shaftOwner, holeOwner, pose:String) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_DECLARATION,
		Evidence.CLAIM_INSIDE,
		{
			Evidence.SUBJ_SHAFT: shaftOwner,
			Evidence.SUBJ_HOLE_OWNER: holeOwner,
		},
		true,
		Evidence.CONF_AUTHORED,
		{"pose": pose}
	)
static func alreadyHeld(items:Array, shaftOwner, holeOwner) -> bool:
	for held in items:
		if(typeof(held) != TYPE_DICTIONARY || typeof(held.get("subject")) != TYPE_DICTIONARY):
			continue
		var subject:Dictionary = held["subject"]
		if(str(subject.get(Evidence.SUBJ_SHAFT)) == str(shaftOwner) \
				&& str(subject.get(Evidence.SUBJ_HOLE_OWNER)) == str(holeOwner)):
			return true
	return false
static func cumOwners(lines:Array) -> Dictionary:
	var owners:Dictionary = {}
	var flagIndent:int = -1
	var owner:int = -1
	for line in lines:
		var text:String = line.strip_edges()
		if(text == ""):
			continue
		var indent:int = Oral.indentOf(line)
		if(flagIndent >= 0 && indent <= flagIndent):
			flagIndent = -1
			owner = -1
		var flag:int = flagOf(text)
		if(flag >= 0):
			flagIndent = indent
			owner = flag
			continue
		if(owner < 0 || (text.find(CUM_CALL) < 0 && text.find(SOLO_CALL) < 0)):
			continue
		if(owners.has(text) && int(owners[text]) != owner):
			owners[text] = FLAG_AMBIGUOUS
		else:
			owners[text] = owner
	return owners
static func flagOf(text:String) -> int:
	if(!text.begins_with("if(")):
		return -1
	for flag in CUM_FLAGS:
		if(text.find("\"" + flag + "\"") >= 0):
			return int(CUM_FLAGS[flag])
	return -1
static func penetrationsIn(line:String) -> Array:
	var declared:Array = []
	var plain:int = line.find(CUM_CALL)
	if(plain >= 0):
		var args:String = line.substr(plain + CUM_CALL.length(), -1)
		var comma:int = args.find(",")
		if(comma >= 0):
			addPenetration(declared, dollNamed(args.substr(0, comma)), dollNamed(args.substr(comma + 1, -1)))
	var solo:int = line.find(SOLO_CALL)
	if(solo < 0):
		return declared
	var tail:String = line.substr(solo + SOLO_CALL.length(), -1)
	var firstComma:int = tail.find(",")
	if(firstComma < 0):
		return declared
	var bottom:int = dollNamed(tail.substr(0, firstComma))
	var found:int = tail.find(INTENSITY_CALL, firstComma)
	while(found >= 0):
		var after:int = found + INTENSITY_CALL.length()
		addPenetration(declared, bottom, dollNamed(tail.substr(after, -1)))
		found = tail.find(INTENSITY_CALL, after)
	return declared
static func addPenetration(declared:Array, receiver:int, penetrator:int) -> void:
	if(receiver < 0 || penetrator < 0):
		return
	declared.append([receiver, penetrator])
static func dollNamed(argument:String) -> int:
	var text:String = argument.strip_edges()
	var end:int = 0
	while(end < text.length() && isWordChar(text.substr(end, 1))):
		end += 1
	return Oral.DOLL_VARS.find(text.substr(0, end))
static func isWordChar(ch:String) -> bool:
	return ch == "_" || (ch >= "0" && ch <= "9") || (ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z")
