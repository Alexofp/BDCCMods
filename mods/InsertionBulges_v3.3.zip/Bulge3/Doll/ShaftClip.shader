shader_type spatial;
render_mode async_visible,blend_mix,depth_draw_opaque,cull_disabled,specular_disabled,unshaded;
uniform vec4 albedo : hint_color;
uniform sampler2D texture_albedo : hint_albedo;
uniform float shaft_clip;
uniform float shaft_clip_dir;
uniform float shaft_clip_feather;
void fragment() {
	vec4 albedo_tex = texture(texture_albedo, UV);
	if(shaft_clip < 1.5) {
		float clipDistance = (UV.x - shaft_clip) * shaft_clip_dir;
		albedo_tex.a *= 1.0 - smoothstep(-shaft_clip_feather, shaft_clip_feather, clipDistance);
	}
	ALBEDO = albedo.rgb * albedo_tex.rgb;
	ALPHA = albedo.a * albedo_tex.a;
}
