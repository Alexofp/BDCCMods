extends Reference
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const TUNING := {"knee": 0.7, "give": 0.5}
static func knee() -> float:
	return float(TUNING["knee"])
static func give() -> float:
	return float(TUNING["give"])
static func setTuning(kneeValue:float, giveValue:float) -> bool:
	if(kneeValue <= 0.0 || giveValue <= 0.0 || giveValue > 1.0):
		push_error("Resistance: knee must be > 0 and give in (0, 1]; still " \
			+ str(knee()) + "/" + str(give()))
		return false
	TUNING["knee"] = kneeValue
	TUNING["give"] = giveValue
	return true
static func yielded(oversize:float) -> float:
	if(oversize <= knee()):
		return oversize
	return knee() + (oversize - knee()) * give()
static func apply(entries:Array) -> void:
	if(give() >= 1.0):
		return
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY):
			continue
		var intent = entry.get("intent")
		var measures = entry.get("measures")
		if(typeof(intent) != TYPE_DICTIONARY || typeof(measures) != TYPE_DICTIONARY):
			continue
		var oversize:float = float(measures.get("oversize", 0.0))
		if(oversize <= knee()):
			continue
		entry["intent"] = Intent.withAmplitude(intent,
			float(intent["amplitude"]) * yielded(oversize) / oversize)
