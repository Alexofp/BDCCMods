extends SmartLockBase

var keyAmount:int = 3

func _init():
	id = SmartLock.TightLock

func canBeUnlockedWithKeys() -> bool:
	return false

func canUnlockWithKey():
	return false

func getName():
	return "Tight lock"

func getUnlockDescription():
	var restData:RestraintData = getRestraintData()
	if(restData == null):
		return "ERROR, SOMETHING WENT WRONG"
	var requiredItemID:String = restData.getTightLockRequiredItemID()
	var reqItem:ItemBase = GlobalRegistry.getItemRef(requiredItemID)
	if(reqItem == null):
		return "ERROR, SOMETHING WENT WRONG"
	
	return "Unable to struggle off, requires a special item to unlock! \nRequired item to unlock: "+reqItem.getVisibleName()
