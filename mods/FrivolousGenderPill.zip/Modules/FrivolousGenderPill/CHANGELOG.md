# Frivolous Gender Pills

## 1.0.1

- Made it so all pills can stack in menus during combat

## 1.0.0

- Initial release
