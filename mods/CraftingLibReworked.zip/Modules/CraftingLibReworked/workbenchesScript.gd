extends Reference

var modID : String = "CraftingLibReworked" # points to craftinglib

#var workbenchTypes = {} # dict of string keys, loaded once. this is what we use to get the recipe, name, etc. data from. must include key for name. valid keys are: name, allowedFluids (string of fluid ids, like so: "flId,flId2,flId3...")

var workbenchInstances : Array = []
var types : Array = []

class WorkbenchType:
	var id : String = ""
	
	var mod : String = ""
	
	var tagsCallback : String = ""
	var fluidsCallback : String = ""
	var ingredientCapsCallback : String = ""
	var defaultIngredientCap : float = -1.0
	
	func getTagsForData(data:Dictionary={}) -> Array:
		if !(mod && tagsCallback):
			return []
		return GlobalRegistry.getModule(mod).callv(tagsCallback, [data])
	
	func getFluidsForData(data:Dictionary={}) -> Array:
		if !(mod && fluidsCallback):
			return []
		return GlobalRegistry.getModule(mod).callv(fluidsCallback, [data])
	
	func getIngredientCapsForData(data:Dictionary={}) -> Dictionary:
		if !(mod && ingredientCapsCallback):
			return {}
		return GlobalRegistry.getModule(mod).callv(ingredientCapsCallback, [data])

func getMaxIngredientAmount(wid:String, ingid:String, caps=null) -> float:
	var wb : WorkbenchInstance = getInstance(wid)
	if !wb:
		return 0.0
	return getMaxIngredientAmountDirect(wb, ingid, caps)

func getMaxIngredientAmountDirect(wb:WorkbenchInstance, ingid:String, caps=null) -> float: # caps is previous max amounts dict
	var t : WorkbenchType = getType(wb.type)
	if !t:
		return 0.0
	
	return (caps if caps!=null else t.getIngredientCapsForData(wb.typeData)).get(ingid, t.defaultIngredientCap)

func dict2type(dict:Dictionary, id:String) -> WorkbenchType:
	var t : WorkbenchType = WorkbenchType.new()
	t.id = id
	t.mod = dict.get("mod", "")
	t.tagsCallback = dict.get("tagsCallback", "")
	t.fluidsCallback = dict.get("fluidsCallback", "")
	t.ingredientCapsCallback = dict.get("ingredientCapsCallback", "")
	t.defaultIngredientCap = float(dict.get("defaultIngredientCap", -1.0))
	
	return t

class WorkbenchInstance:
	var id : String = ""
	
	var ingredients : Array = [] # array of [id, amount]
	
	var type : String = ""
	var typeData : Dictionary
	
	
	func saveData() -> Dictionary:
		var d : Dictionary = {
			"id": id,
			"ingredients": ingredients,
			"type": type,
			"typeData": typeData,
		}
		
		return d
	
	func loadData(d:Dictionary) -> void:
		id = SAVE.loadVar(d, "id", "")
		ingredients = SAVE.loadVar(d, "ingredients", [])
		type = SAVE.loadVar(d, "type", "")
		typeData = SAVE.loadVar(d, "typeData", {})
	
	func sort_ings(a, b) -> bool:
		if typeof(a) == TYPE_ARRAY:
			a = a[0]
		if typeof(b) == TYPE_ARRAY:
			b = b[0]
		
		return a < b
	
	func getIngredientAmount(iid:String) -> int:
		var idx : int = getIngredientIdx(iid)
		return 0 if idx==-1 else (ingredients[idx][1] if ingredients[idx].size() > 1 else 0)
	
	func getIngredientIdx(iid:String) -> int:
		var idx : int = ingredients.bsearch_custom(iid, self, "sort_ings")
		if idx >= ingredients.size():
			return -1
		
		return idx if ingredients[idx][0] == iid else -1
	
	
	func addIngredient(iid:String, amount:float) -> float: # returns new amount or 0
		var idx : int = ingredients.bsearch_custom(iid, self, "sort_ings")
		if idx >= ingredients.size() or ingredients[idx][0] != iid:
			ingredients.insert(idx, [iid, amount])
			return amount
		
		if ingredients[idx].size()<2:
			ingredients[idx].append(amount)
			return amount
		
		ingredients[idx][1] += amount
		return ingredients[idx][1]
		
	
	func eraseIngredient(iid:String) -> void:
		var idx : int = getIngredientIdx(iid)
		if idx == -1:
			return
		
		ingredients.remove(idx)
	
	func getDataValue(val:String, nullv=null):
		return typeData.get(val, nullv)
	
	func setDataValue(val:String, v) -> void:
		typeData[val] = v
	
	func clearData() -> void:
		typeData.clear()
	
	func eraseDataValue(val:String) -> void:
		typeData.erase(val)
	

var idSortable : Reference = GlobalRegistry.getModule("RodentUtils")\
	.createSortable().setObject(Sorter).setSort("sort_ids")\
	.setComparison("are_ids_same")


class Sorter:
	static func are_ids_same(a, b) -> bool:
		if a is WorkbenchInstance or a is WorkbenchType:
			a = a.id
		if b is WorkbenchInstance or b is WorkbenchType:
			b = b.id
		
		return a == b
	
	static func sort_ids(a, b) -> bool:
		if a is WorkbenchInstance or a is WorkbenchType:
			a = a.id
		if b is WorkbenchInstance or b is WorkbenchType:
			b = b.id
		
		return a < b

func getTagsForInstance(wid:String) -> Array:
	var wb : WorkbenchInstance = getInstance(wid)
	if !wb:
		return []
	var type : WorkbenchType = getType(wb.type)
	if !type:
		return []
	
	return type.getTagsForData(wb.typeData)

func getTypes() -> Array:
	return types

func getInstances() -> Array:
	return workbenchInstances

func getInstance(id:String) -> WorkbenchInstance:
	return idSortable.getThing(id, getInstances())

func getType(id:String) -> WorkbenchType:
	return idSortable.getThing(id, getTypes())

func addInstance(entry:WorkbenchInstance) -> void:
	idSortable.addThing(entry, getInstances())

func addType(type:WorkbenchType) -> void:
	idSortable.addThing(type, getTypes())

func removeInstance(id:String) -> void:
	idSortable.removeThing(id, getInstances())

func getMod() -> Module:
	return GlobalRegistry.getModule(modID)

# dict or null
func getWorkbenchInstanceFromId(wid:String):
	return getInstance(wid)

## array[array[ingid, float] or []
func getWorkbenchStores(wid:String) -> Array:
	var wb = getWorkbenchInstanceFromId(wid)
	return wb.ingredients if wb else []

func getValidWorkbenchAllowedFluids(wid:String) -> Array: # same as below, but only gets fluids that are valid fluid ingredients
	var res = []
	var ingreds = getMod().Ingredients
	for wbflid in getWorkbenchFluids(wid):
		if ingreds.isFluidTypeValidIngredient(wbflid):
			res.append(wbflid)
		
	return res

func getWorkbenchFluids(wid:String) -> Array:
	var i : WorkbenchInstance = getInstance(wid)
	if !i:
		return []
	
	var t : WorkbenchType = getType(i.type)
	if t:
		return t.getFluidsForData(i.typeData)
	
	return []

func getWorkbenchTypeData(wtype:String) -> WorkbenchType:
	return getType(wtype)

func createWorkbenchInstance(wid:String, type:String) -> WorkbenchInstance: # returns instance
	if !getType(type): # if type is invalid, we don't have recipes; abort
		return null
	
	var ni : WorkbenchInstance = WorkbenchInstance.new()
	ni.id = wid
	ni.type = type
	
	addInstance(ni)
	return ni

func getWorkbenchInstanceType(wid:String):
	var wb = getInstance(wid)
	if !wb:
		return null
	return getType(wb.type)

func addIngredient(wid:String, ingid:String, amount:float, _data:Dictionary={}) -> float: # returns new amount or 0
	var wb : WorkbenchInstance = getInstance(wid)
	if !wb:
		return 0.0
	
	var maxam : float = getMaxIngredientAmountDirect(wb, ingid)
	if maxam==0.0:
		return 0.0
	elif maxam>0:
		amount = min(amount, maxam - wb.getIngredientAmount(ingid))
	
	return wb.addIngredient(ingid, amount)
	

func saveData() -> Dictionary:
	var d : Dictionary = {
		"instances": [],
	}
	
	for instance in getInstances():
		if !(instance && instance.id):
			continue
		
		d["instances"].append(instance.saveData())
	
	
	return d

func loadData(d:Dictionary) -> void:
	workbenchInstances.clear()
	for instDict in SAVE.loadVar(d, "instances", []):
		var ni : WorkbenchInstance = WorkbenchInstance.new()
		ni.loadData(instDict)
		if !ni.id:
			continue
		workbenchInstances.append(ni)
	
	workbenchInstances.sort_custom(Sorter, "sort_ids")
	

func cacheAll() -> void:
	var newTypes : Dictionary = {}
	var mod : Module = getMod()
	for modId in mod.modulesWithData.keys():
		if mod.modulesWithData[modId].get("workbenches", false):
			newTypes.merge(GlobalRegistry.getModule(modId).getAddedWorkbenchTypes(), true)
	
	
	types.clear()
	
	for type in newTypes:
		var nt : WorkbenchType = dict2type(newTypes[type], type)
		types.append(nt)
	
	types.sort_custom(Sorter, "sort_ids")
	


