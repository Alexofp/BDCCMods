extends PanelContainer

var rangedMode : bool = true
var itemMode : bool = false

onready var datac : Container = $vb/sc/vb

var data : Dictionary

#var mod : Module = GlobalRegistry.getModule("CraftingLibReworked")

func _ready():
	setData({
		"id1":[1, 2]
	})

func setLabel(txt:String) -> void:
	$vb/Label.text = txt

func getData() -> Dictionary:
	return data

func getArrayData() -> Array:
	var r : Array = []
	for id in data:
		r.append([id, data[id][0]])
	
	return r

func makeMeARealBoy(me:Control) -> void:
	me.size_flags_horizontal = Control.SIZE_EXPAND_FILL

func setData(d:Dictionary) -> void:
	data.clear()
	for key in d:
		if typeof(d[key]) != TYPE_ARRAY:
			data[key] = [d[key]]
		else:
			data[key] = d[key]
	
	Util.delete_children(datac)
	
	for key in data:
		datac.add_child(newEntry(key))

func newEntry(key:String) -> HBoxContainer:
	var n := HBoxContainer.new()
	
	
	var l := LineEdit.new()
	l.text = key
	l.connect("text_entered", self, "onKeyRenamed", [key])
	n.add_child(l)
	
	
	var reps : Array = ["min", "max"] if rangedMode else ["amount"]
	for i in reps.size():
		var sp := SpinBox.new()
		sp.min_value = 0
		sp.allow_greater = true
		sp.rounded = true
		
		sp.connect("value_changed", self, "onValueChanged", [key, i])
		if data[key].size()<=i:
			data[key].append(1)
		
		sp.set_value_no_signal(data[key][i])
		sp.prefix = reps[i].capitalize()
		
		n.add_child(sp)
		makeMeARealBoy(sp)
	
	var d := Button.new()
	d.text = "Delete"
	d.connect("pressed", self, "deleteKey", [key, n])
	n.add_child(d)
	
	for a in [n, l]:
		makeMeARealBoy(a)
	
	return n

func deleteKey(key:String, node:Control) -> void:
	data.erase(key)
	if node:
		node.queue_free()


func onValueChanged(new:float, key:String, idx:int=0) -> void:
	if idx>0 && !rangedMode:
		return
	
	if rangedMode:
		data[key][idx] = int(new)
	else:
		data[key] = [int(new)]

func onKeyRenamed(new:String, old:String) -> void:
	if new==old:
		return
	var nd : Dictionary = data.duplicate()
	nd[new] = nd[old]
	nd.erase(old)
	setData(nd)

func _on_add_pressed():
	var i : int = 0
	var nid : String = "ing%s" % i
	while nid in data.keys():
		i += 1
		nid = "ing%s" % i
	
	data[nid] = [1, 2] if rangedMode else [1]
	
	datac.add_child(newEntry(nid))
