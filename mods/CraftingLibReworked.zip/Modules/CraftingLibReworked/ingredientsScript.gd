extends Reference

var Workbench : Reference
var modID : String

var cached : Array # array of ingredients, sorted

var ingSortable : Reference = GlobalRegistry.getModule("RodentUtils")\
	.createSortable().setObject(Sorter).setSort("sort_ingredients")\
	.setComparison("are_ingredients_same")

func getMod() -> Module:
	return GlobalRegistry.getModule(modID)

func isFluidTypeValidIngredient(ftype:String) -> bool:
	return getIngredient(ftype)!=null

class Ingredient:
	var id : String
	func _init(i:String):
		self.id = i
	
	var name : String
	var measure : String = "pcs"

class Sorter:
	static func are_ingredients_same(a, b) -> bool:
		if a is Ingredient:
			a = a.id
		if b is Ingredient:
			b = b.id
		return a==b
	
	static func sort_ingredients(a, b) -> bool:
		if a is Ingredient:
			a = a.id
		if b is Ingredient:
			b = b.id
		return a<b

func cacheAllIngredients() -> void:
	var raw : Dictionary = getAllIngredientsRaw()
	for iid in raw:
		var i = dict2ing(iid, raw[iid])
		cached.append(i)
	
	cached.sort_custom(Sorter, "sort_ingredients")

func dict2ing(iid:String, dict:Dictionary) -> Ingredient:
	var i : Ingredient = Ingredient.new(iid)
	
	i.name = dict.get("name", "")
	i.measure = dict.get("measure", "pcs")
	
	return i


#func addFluidType(wid:String,fl:Fluids,type:String="Cum") -> float: # wid is workbench instance id, returns new amount or 0
#	if !isFluidTypeValidIngredient(type):
#		return 0.0
#	var wb = Workbench.getInstance(wid)
#	if !wb:
#		return 0.0
##	var avgVir = getAvgTypeVirility(fl,type)
##	var amount = fl.getFluidAmountByType().get(type,0.0)
##	var ings = Workbench.getWorkbenchStores(wid)
##	var storedFluidData = ings.get(type,{})
##	var finalData = storedFluidData.get("data",{}) # to keep other old data
##
##	var finalAmount : float = amount+storedFluidData.get("amount",0.0)
##	if finalAmount==0: # impossible div
##		return 0.0
##	var newFluidShare = amount/finalAmount
##	var oldFluidShare = storedFluidData.get("amount",0.0)/finalAmount
##
##	finalData["virility"] = finalData.get("virility",0.0)*oldFluidShare+avgVir*newFluidShare
##	ings[type] = {
##		"amount":amount+storedFluidData.get("amount",0.0),
##		"data":finalData,
##		}
##
##	Workbench.saveWorkbenchInstanceStores(wid,ings) # saves data ig
##	return finalAmount
#	return wb.addIngredient(type, fl.getFluidAmountByType().get(type, 0.0))

#func fluidToIngredient(fl:Fluids,type:String) -> Dictionary: # returns dict to be put in other ings dict
#	var amount = fl.getFluidAmountByType().get(type,0.0)
##	var avgVir = getAvgTypeVirility(fl,type)
##	var dat = {}
##	if avgVir:
##		dat["virility"]=avgVir
#	return {"amount":amount,"data":dat}

func getAllIngredientsRaw() -> Dictionary:
	var ings = {}
	var mods = getMod().modulesWithData
	for modId in mods.keys():
		if mods[modId].get("ingredients", false):
			ings.merge(GlobalRegistry.getModule(modId).getAddedIngredients(), true)

	return ings

func getIngredient(iid:String) -> Ingredient:
	return ingSortable.getThing(iid, cached)

func getIngredientsRequiredArray(ingredients:Dictionary, itemIngredients:Dictionary={}, fromInv:Inventory=null) -> Array: # to display recipe requirements, array of strings
	var lines = []
	for ing in ingredients.keys():
		var idata = getIngredient(ing)
		var a = "-".join(PoolStringArray(ingredients[ing]))
		var t = a+" "+idata.measure+" "+idata.name
		lines.append(t)

	for itemid in itemIngredients.keys():
		var tempItem = GlobalRegistry.createItemNoID(itemid)
		var a = "-".join(PoolStringArray(itemIngredients[itemid]))
		var t = "%sx %s%s" % [a, tempItem.getVisibleName(), ( "[color=grey] (you have %s)[/color]" % fromInv.getXOfTotal(itemid) if fromInv else "" )]
		lines.append(t)
	return lines


func getAvgVirility(fluids:Fluids) -> float:
	var fa : float = fluids.getFluidAmount()
	if fa==0:
		return 0.0
	var virileAmount = 0.0
	for fluidData in fluids.contents:
		var fluidDNA = fluidData["fluidDNA"] if fluidData.has("fluidDNA") else null
		if(!fluidDNA):
			continue
		var fluidType:String = fluidData["fluidType"]
		var theFluid:FluidBase = GlobalRegistry.getFluid(fluidType)
		if(!theFluid):
			continue

		if(theFluid.canImpregnate() && fluidDNA.getVirility() > 0.01):
			virileAmount += fluidData["amount"]*fluidDNA.getVirility() # the more virile, the better; can go more than 100% quality
	
	return virileAmount/fa

func getAvgTypeVirility(fluids:Fluids, type:String="Cum") -> float:
	if !fluids.hasFluidType(type):
		return 0.0
	var virileAmount : float = 0.0
	for fluidData in fluids.contents:
		var fluidDNA = fluidData["fluidDNA"] if fluidData.has("fluidDNA") else null
		var fluidType:String = fluidData["fluidType"]
		if !fluidDNA or fluidType!=type: # continue if invalid
			continue

		var theFluid:FluidBase = GlobalRegistry.getFluid(fluidType)
		if(!theFluid):
			continue
		if(theFluid.canImpregnate() && fluidDNA.getVirility() > 0.00):
			virileAmount += fluidData["amount"]*fluidDNA.getVirility() # the more virile, the better; can go more than 100% quality
	var avg : float = virileAmount/fluids.getFluidAmountByType().get(type,0.0)
	return avg


func getIngredientFluids() -> Array: # returns an array of all fluidTypes that have the same id as an ingredient, this is why the cream ingredient has the id "Cum"
	var res = []
	var fluidIds = GlobalRegistry.getFluids().keys()
	for fluid in fluidIds:
		if isFluidTypeValidIngredient(fluid):
			res.append(fluid)
	return res
