extends SceneBase

var workbenchID : String

func _init():
	sceneID = "RAT_RecipeEditor"
	


func _run():
	if state == "":
		saynn("a")
		
		addButton("do", "", "do")
		addButton("no", "", "end")
	
	elif state == "do":
		var ui : Control = load("res://Modules/CraftingLibReworked/recipeEditor.tscn").instance()
		GM.ui.addFullScreenCustomControl("recipeEditor", ui)
		addButton("no", "", "")


func _react(_action, _args):
	if _action == "end":
		endScene()
		return
	
	setState(_action)
