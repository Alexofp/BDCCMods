extends SceneBase

var workbenchID : String

func _init():
	sceneID = "BaseWorkbenchScene"
	

func getDebugActions():
	return [
		{
			"id": "recipeEditor",
			"name": "Recipe Editor",
			"args": [
			],
		},
	]

func doDebugAction(_id, _args = {}):
	if _id == "recipeEditor":
		runScene("RAT_RecipeEditor")

func _run():
	if state == "":
		addButton("Done", "You're finished here", "end")
		addButton("Craft", "See what you can craft", "do")
	
	elif state == "do":
		var ui : Control = load("res://Modules/CraftingLibReworked/CraftingUI.tscn").instance()
		ui.workbenchID = sceneTag
		GM.ui.addFullScreenCustomControl("craftingUI", ui)
		addButton("Back", "Go back", "")

func getMod() -> Module:
	return getModule("CraftingLibReworked")

func _react(_action, _args):
	if _action == "end":
		endScene()
		return
	
	setState(_action)
