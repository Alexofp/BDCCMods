extends HBoxContainer

onready var tree : Tree = $vb/recTree

onready var reqIngs = $sc/editor/requiredIngredients
onready var reqItems = $sc/editor/requiredItems

onready var resIngs = $sc/editor/resultIngs
onready var resItems = $sc/editor/resultItems

var savedRecipeIds : Array = []

var newRecipes : Array = []

func getMod() -> Module:
	return GlobalRegistry.getModule("CraftingLibReworked")

func _ready():
	reqIngs.setLabel("Required Ingredients")
	reqIngs.rangedMode = true
	reqIngs.itemMode = false
	
	reqItems.setLabel("Required Items")
	reqItems.rangedMode = true
	reqItems.itemMode = true
	
	resIngs.setLabel("Resulting Ingredients")
	resIngs.rangedMode = false
	resIngs.itemMode = false
	
	resItems.setLabel("Resulting Items")
	resItems.rangedMode = false
	resItems.itemMode = true
	
	tree.set_column_title(0, "ID")
	tree.set_column_title(1, "Name")
	tree.set_column_title(2, "Save")
	
#	populate()

func populate(modid:String="") -> void:
	clearRecipes()
	
	var recss = getMod().Recipes
	if modid:
		recss.cacheAllRecipes(recss.getRecipesRawFromMod(modid))
	else:
		recss.cacheAllRecipes()
	
	for recipe in newRecipes:
		recss.cached.insert( recss.cached.bsearch_custom(recipe, recss, "sort_recipes"), recipe )
	
	for recipe in recss.getCachedRecipes():
		addRecipeItem(recipe)
	
	tree.connect("item_selected", self, "itemSelected")

func itemSelected() -> void:
	var rid : String = tree.get_selected().get_metadata(0)
	var recipe = getMod().Recipes.getRecipeFromIdGlobal(rid)
	if recipe:
		updateEditor(recipe)

func updateEditor(recipe) -> void:
	reqIngs.setData(recipe.requiredIngredients)
	reqItems.setData(recipe.requiredItems)
	
	resItems.setData(recipe.resultingItems)
	resIngs.setData(recipe.resultingIngredients)
	
	$sc/editor/gc/id/idedit.text = recipe.id
	$sc/editor/gc/name/namedit.text = recipe.name
	$sc/editor/gc/itemdisplay/itdispedit.text = recipe.resultingItemDisplay
	$sc/editor/gc/ingdisplay/ingdispeit.text = recipe.resultingIngredientDisplay
	$sc/editor/gc/qualitycallback2/tagsEdit.text = "\n".join(recipe.tags)
	
	if recipe.onCraftCallback.size()==2:
		if recipe.onCraftCallback[0] is Module:
			$sc/editor/gc/craftcallback/craftcbedit.text = "%s.%s" % [recipe.onCraftCallback[0].id, recipe.onCraftCallback[1]]
	
	if recipe.extraQualityCallback.size()==2:
		if recipe.extraQualityCallback[0] is Module:
			$sc/editor/gc/qualitycallback/qualitycbedit.text = "%s.%s" % [recipe.extraQualityCallback[0].id, recipe.extraQualityCallback[1]]

func addRecipeItem(recipe) -> TreeItem:
	var t = tree.create_item()
	
	t.set_metadata(0, recipe.id)
	t.set_text(0, recipe.id)
	t.set_text(1, recipe.name if recipe.name else "(unnamed)")
	t.set_text(2, "Yes" if recipe.id in savedRecipeIds else "No")
	
	return t

func clearRecipes() -> void:
	tree.clear()
	tree.create_item()

func turnEditorToRecipe() -> Dictionary:
	var recs = getMod().Recipes
	
	var recipe = recs.Recipe.new($sc/editor/gc/id/idedit.text)
	recipe.name = $sc/editor/gc/name/namedit.text
	recipe.requiredIngredients = reqIngs.getData()
	recipe.requiredItems = reqItems.getData()
	
	recipe.resultingIngredients.clear()
	var rings = resIngs.getData()
	for ingid in rings:
		recipe.addResultingIngredient(ingid, rings[ingid][0])
	
	recipe.resultingItems.clear()
	var ritems = resItems.getData()
	for itemid in ritems:
		recipe.addResultingItem(itemid, ritems[itemid][0])
	
	recipe.resultingItemDisplay = $sc/editor/gc/itemdisplay/itdispedit.text
	recipe.resultingIngredientDisplay = $sc/editor/gc/ingdisplay/ingdispeit.text
	
	recipe.tags = $sc/editor/gc/qualitycallback2/tagsEdit.text.split("\n", false)
	
	var recipeDict : Dictionary = recs.recipe2dict(recipe)
	
	recipeDict["qualityCallback"] = $sc/editor/gc/qualitycallback/qualitycbedit.text
	recipeDict["craftCallback"] = $sc/editor/gc/craftcallback/craftcbedit.text
	
	return recipeDict

func _on_refresh_pressed():
	var modid : String = $vb/override/LineEdit.text
	if !modid or GlobalRegistry.modules.has(modid):
		populate(modid)


func _on_add_pressed():
	var i : int = 0
	var recs = getMod().Recipes
	while recs.getRecipeFromIdGlobal("rec%s" % i)!=null:
		i += 1
	
	var recipe = recs.dict2recipe("rec%s" % i, {})
	newRecipes.append( recipe )
	recs.cached.insert( recs.cached.bsearch_custom("rec%s" % i, recs, "sort_recipes"), recipe )
	
	savedRecipeIds.append(recipe.id)
	
	addRecipeItem(recipe)


func _on_recTree_item_activated():
	var sel = tree.get_selected()
	if !sel:
		return
	
	var id = sel.get_metadata(0)
	if !id:
		return
	
	if id in savedRecipeIds:
		savedRecipeIds.erase(id)
		sel.set_text(2, "No")
	else:
		savedRecipeIds.append(id)
		sel.set_text(2, "Yes")


func _on_copy_pressed():
	pass # Replace with function body.


func _on_idedit_text_entered(new_text):
	var sel = tree.get_selected()
	if !sel:
		return
	
	var recs = getMod().Recipes
	if recs.getRecipeFromIdGlobal(new_text):
		return
	
	var old = sel.get_metadata(0)
	
	var oldIdx = recs.getRecipeIdxStrict(old, recs.cached)
	
	if oldIdx == -1:
		return
	
	
	
	var oldNewrecsIdx = newRecipes.bsearch_custom(old, recs, "sort_recipes")
	if oldNewrecsIdx!=-1:
		newRecipes.remove(oldNewrecsIdx)
	
	if old in savedRecipeIds:
		savedRecipeIds.erase(old)
		savedRecipeIds.append(new_text)
	
	var p = recs.cached[oldIdx]
	recs.cached.remove(oldIdx)
	p.id = new_text
	newRecipes.append(p)
	
	populate($vb/override/LineEdit.text)
	


func _on_save_pressed():
	var sel = tree.get_selected()
	if !sel:
		return
	
	var selid = sel.get_metadata(0)
	if !selid:
		return
	var recs = getMod().Recipes
	var idx = recs.getRecipeIdxStrict(selid, recs.cached)
	if idx==-1:
		return
	
	var nrec = recs.dict2recipe(recs.cached[idx].id, turnEditorToRecipe())
	var nidx = recs.getRecipeIdxStrict(selid, newRecipes)
	if nidx==-1:
		var i : int = 0
		while recs.getRecipeIdxStrict(nrec.id+str(i), recs.cached)!=-1:
			i += 1
		nrec.id += str(i)
		newRecipes.append(nrec)
		if !nrec.id in savedRecipeIds:
			savedRecipeIds.append(nrec)
	else:
		newRecipes[nidx] = nrec
	
	populate($vb/override/LineEdit.text)


func saveToText() -> String:
	var recipes : Dictionary = {} # id: dict
	var recs = getMod().Recipes
	for recid in savedRecipeIds:
		var recipe = recs.getRecipeFromIdGlobal(recid)
		if !recipe:
			continue
		
		recipes[recid] = recs.recipe2dict(recipe)
	
	var res : String = JSON.print(recipes, "\t")
	
	return res



func _on_saveDialog_file_selected(path):
	var f = File.new()
	var err = f.open(path, File.WRITE)
	if err==OK:
		f.store_string(saveToText())
		f.close()
		$notifDialog.popup_centered_ratio()
		$notifDialog.dialog_text = "File at\n%s\nwas saved successfully!" % path
	else:
		$notifDialog.dialog_text = "Failed to save file\n%s\nError: %s" % [path, err]
		$notifDialog.popup_centered_ratio()


func _on_saveJson_pressed():
	$saveDialog.popup_centered_ratio()
