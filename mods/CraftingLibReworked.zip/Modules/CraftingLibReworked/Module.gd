extends Module

var modulesWithData : Dictionary # we draw data from these

var Workbench : Reference

var Recipes : Reference
var Ingredients : Reference

signal updateWorkbenchType(type)

#func RatConfigure(ratc):
#	ratc.overrideModConfigName(id, "Player Portrait (Rat)")

func createWorkbench() -> void:
	Workbench = load("res://Modules/CraftingLibReworked/workbenchesScript.gd").new()
	
	Workbench.modID = id
	Workbench.cacheAll()
	Recipes.Workbench = Workbench
	Ingredients.Workbench = Workbench

func createStuff() -> void:
	Recipes = load("res://Modules/CraftingLibReworked/recipesScript.gd").new()
	Ingredients = load("res://Modules/CraftingLibReworked/ingredientsScript.gd").new()
	
	Recipes.modID = id
	Recipes.Ingredients = Ingredients
	Ingredients.modID = id
	
	createWorkbench()

func requestWorkbenchUpdate(type:String) -> void:
	emit_signal("updateWorkbenchType", type)


func onItemCrafted(recipe, _inv:Inventory, _workbenchinstance) -> Array:
	var its : Array = []

	for item in recipe.resultingItems.keys():
		var it : ItemBase = GlobalRegistry.createItem(item)
		it.setAmount(recipe.resultingItems[item])
		
		its.append(it)
	
#	print("%s crafted" % recipe.name)
	
	return its

func _init():
	id = "CraftingLibReworked"
	author = "Selinoccino"

	scenes = [
#		"res://Modules/CraftingLibReworked/Scenes/baseWorkbench.gd",
		"res://Modules/CraftingLibReworked/Scenes/testScene.gd",
		"res://Modules/CraftingLibReworked/Scenes/recipeEditorScene.gd",
	]
	
	
	

func postInit(): # Called after everything is registered
	var modules = GlobalRegistry.getModules()
	for module in modules.keys():
		var mo : Module = modules[module]
		var modAddsRecs : bool = mo.has_method("getAddedRecipes")
		var modAddsIngs : bool = mo.has_method("getAddedIngredients")
		var modAddsTypes : bool = mo.has_method("getAddedWorkbenchTypes")
		if modAddsIngs or modAddsRecs or modAddsTypes:
			modulesWithData[module]={
				"recipes": modAddsRecs, # if it adds stuff, set that value
				"ingredients": modAddsIngs,
				"workbenches": modAddsTypes,
			}
	
	createStuff()
	cacheAll()
	


func cacheAll() -> void:
	Recipes.cacheAllRecipes()
	Ingredients.cacheAllIngredients()
	Workbench.cacheAll()


func addCraftedItemsToInv(craftedIts:Array, inv:Inventory) -> void: # this is to easily add the items from craftRecipe() func
	if !inv:
		return
	for it in craftedIts:
		if it.getAmount()<1:
			continue
		inv.addItem(it)

func RatRegister(ratreg) -> void:
	ratreg.registerSavedMod(self)

func RatSave() -> Dictionary:
	return {
		"Workbench": Workbench.saveData()
	}

func RatLoad(d) -> void:
	if d.get("RESET", false):
		createWorkbench()
		return
	
	Workbench.loadData(SAVE.loadVar(d, "Workbench", {}))

