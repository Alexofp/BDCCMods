extends Reference

var modID : String = ""

var Workbench : Reference
var Ingredients : Reference

var cached : Array # array of recipes
var cachedByTag : Dictionary # type: array[recipe]

var recipeSortable : Reference = GlobalRegistry.getModule("RodentUtils")\
	.createSortable().setObject(Sorter).setSort("sort_recipes")\
	.setComparison("are_recipes_same")

class RecipeQuality:
	var baseQuality : float = 0.0
	var extras : Dictionary = {}

class Sorter:
	static func are_recipes_same(a, b) -> bool:
		if a is Recipe:
			a = a.id
		if b is Recipe:
			b = b.id
		return a==b
	
	static func sort_recipes(a, b) -> bool:
		if a is Recipe:
			a = a.id
		if b is Recipe:
			b = b.id
		return a<b

class Recipe:
	var id : String
	var name : String
	
	var tags : Array
	
	func addTag(tag:String) -> void:
		if !tags.has(tag):
			tags.append(tag)
	
	func eraseTag(tag:String) -> void:
		tags.erase(tag)
	
	func _init(i:String):
		self.id = i
	
	var requiredItems : Dictionary = {
		# id: [ min, max amounts ] or [amount]
	}
	
	var requiredIngredients : Dictionary = {
		# same as above
	}
	
	var resultingItems : Dictionary = {
		# id: amount
	}
	
	var resultingIngredients : Dictionary = {
		# id: amount
	}
	
	var onCraftCallback : Array = [] # object that has callback method, callback method, expected arguments: recipe, inventory, workbench. expected return: array of ItemBase objects, set amounts and properties yourself
	
	var extraQualityCallback : Array = [] # same
	
	var resultingItemDisplay : String
	var resultingIngredientDisplay : String
	
	
	func addRequiredItem(iid:String, amount:int, maxAmount:int=-1) -> void: # max amount is -1 for no amount range
		self.requiredItems[iid] = [amount, maxAmount] if maxAmount!=-1 else [amount]
	
	func removeRequiredItem(iid:String) -> void:
		self.requiredItems.erase(iid)
	
	func addRequiredIngredient(iid:String, amount:int, maxAmount:int=-1) -> void: # max amount is -1 for no amount range
		self.requiredIngredients[iid] = [amount, maxAmount] if maxAmount!=-1 else [amount]
	
	func removeRequiredIngredient(iid:String) -> void:
		self.requiredIngredients.erase(iid)
	
	
	func getFinalItem(inv:Inventory, wb) -> Array: # array of ItemBase
		if onCraftCallback.size()==2:
			return onCraftCallback[0].callv(onCraftCallback[1], [self, inv, wb])
		
		return GlobalRegistry.getModule("CraftingLibReworked").onItemCrafted(self, inv, wb)
	
	func addResultingItem(iid:String, amount:int) -> void:
		resultingItems[iid] = amount
	
	func addResultingIngredient(iid:String, amount:int) -> void:
		resultingIngredients[iid] = amount
	


func getCraftedItemsLines(recipe:Recipe) -> PoolStringArray:
	if recipe.resultingItemDisplay:
		return recipe.resultingItemDisplay.split("\n")
	
	var r : PoolStringArray = []
	
	for itid in recipe.resultingItems:
		var it : ItemBase = GlobalRegistry.createItemNoID(itid)
		if !it:
			r.append("%sx no item with id %s found" % [recipe.resultingItems[itid], itid])
		
		it.setAmount(recipe.resultingItems[itid])
		r.append(it.getAStackName())
	
	return r

func getCraftedIngredientsLines(recipe:Recipe) -> PoolStringArray:
	if recipe.resultingIngredientDisplay:
		return recipe.resultingIngredientDisplay.split("\n")
	
	var r : PoolStringArray = []
	
	for ingid in recipe.resultingIngredients:
		var ing = Ingredients.getIngredient(ingid)
		if !ing:
			r.append("%sx no ingredient with id %s found" % [recipe.resultingIngredients[ingid], ingid])
		
		r.append("%s%s %s" % [recipe.resultingIngredients[ingid], ing.measure, ing.name])
	
	return r
	

func recipe2dict(recipe:Recipe) -> Dictionary:
	var d = {
		"name":recipe.name,
		"resultingIngredients":[],
		"resultingItems":[],
		"requiredIngredients":recipe.requiredIngredients,
		"requiredItems":recipe.requiredItems,
		"tags":recipe.tags,
		"finalIngsDisplay":recipe.resultingIngredientDisplay,
		"finalItemsDisplay":recipe.resultingItemDisplay,
	}
	
	for ingid in recipe.resultingIngredients:
		d["resultingIngredients"].append([ingid, recipe.resultingIngredients[ingid]])
	
	for itemid in recipe.resultingItems:
		d["resultingItems"].append([itemid, recipe.resultingItems[itemid]])
	
	var qcbString : String = ""
	if recipe.extraQualityCallback.size()==2 && recipe.extraQualityCallback[0] is Module:
		qcbString = "%s.%s" % [ recipe.extraQualityCallback[0].id, recipe.extraQualityCallback[1] ]
	
	var craftcbString : String = ""
	if recipe.onCraftCallback.size()==2 && recipe.onCraftCallback[0] is Module:
		craftcbString = "%s.%s" % [ recipe.onCraftCallback[0].id, recipe.onCraftCallback[1] ]
	
	d["qualityCallback"]=qcbString
	d["craftCallback"]=craftcbString
	
	return d

func dict2recipe(rid:String, dict:Dictionary) -> Recipe:
	var r : Recipe = Recipe.new(rid)
	
	var inings = dict.get("requiredIngredients", {})
	for entry in inings:
		var a = inings[entry]
		var ma : int = -1 if typeof(a)==TYPE_INT or a.size()<2 else a[1]
		r.addRequiredIngredient(entry, a if typeof(a)==TYPE_INT else a[0], ma)
	
	var itings = dict.get("requiredItems", {})
	for entry in itings:
		var a = itings[entry]
		var ma : int = -1 if typeof(a)==TYPE_INT or a.size()<2 else a[1]
		r.addRequiredItem(entry, a if typeof(a)==TYPE_INT else a[0], ma)
	
	
	var rings = dict.get("resultingIngredients", [])
	for entryAr in rings: # entryAr = [id, amount]
		if entryAr.size()<2:
			continue
		
		r.addResultingIngredient(entryAr[0], entryAr[1])
	
	var rits = dict.get("resultingItems", [])
	for entryAr in rits: # entryAr = [id, amount]
		if entryAr.size()<2:
			continue
		
		r.addResultingItem(entryAr[0], entryAr[1])
	
	
	r.name = dict.get("name", "(unknown)")
	r.resultingIngredientDisplay = dict.get("finalIngsDisplay", "")
	r.resultingItemDisplay = dict.get("finalItemsDisplay", "")
	
	for tag in dict.get("tags", []):
		r.addTag(tag)
	
	r.onCraftCallback = dict.get("craftCallback", "%s.onItemCrafted" % modID).split(".", false, 2)
	r.onCraftCallback.resize(2)
	r.onCraftCallback[0] = GlobalRegistry.getModule(r.onCraftCallback[0]) if r.onCraftCallback[0] else null
	r.extraQualityCallback = dict.get("qualityCallback", "").split(".", false, 2)
	r.extraQualityCallback.resize(2)
	r.extraQualityCallback[0] = GlobalRegistry.getModule(r.extraQualityCallback[0]) if r.extraQualityCallback[0] else null
	
	
	return r

func getCachedRecipes() -> Array:
	return cached

func cacheAllRecipes(override:Dictionary={}) -> void:
	var recs := getAllRecipesRaw() if !override else override
	cached.clear()
	cachedByTag.clear()
	cachedByTag["*"] =[ ]
	
	for recid in recs:
		var recipe : Recipe = dict2recipe(recid, recs[recid])
		cached.append(recipe)
		if !recipe.tags:
			cachedByTag["*"].append(recipe)
			continue
		
		for tag in recipe.tags:
			cachedByTag.get_or_add(tag, []).append(recipe)
	
	for tag in cachedByTag.keys():
		cachedByTag[tag].sort_custom(Sorter, "sort_recipes")
	
#	cachedByTag["*"].sort_custom(self, "sort_recipes")
	
	cached.sort_custom(Sorter, "sort_recipes")

func getMod() -> Module:
	return GlobalRegistry.getModule(modID)

func getAllRecipesRaw() -> Dictionary: # returns all recipes, overwriting if same id
	var recs := {}
	var mod : Module = getMod()
	for modId in mod.modulesWithData.keys():
		if mod.modulesWithData[modId].get("recipes", false):
			recs.merge(GlobalRegistry.getModule(modId).getAddedRecipes(), true)
	
	return recs

func getRecipesRawFromMod(mod:String) -> Dictionary:
	return GlobalRegistry.getModule(mod).getAddedRecipes()

func getRecipesForTagNoGlobal(tag:String) -> Array:
	return cachedByTag.get(tag, [])

func makeRecipesArrayFromArrays(arrays:Array) -> Array: # expects no conflicts
	var res : Array = []
	for array in arrays:
		res.append_array(array)
	
	res.sort_custom(Sorter, "sort_recipes")
	return res

func getRecipesForTag(tag:String) -> Array:
	var r : Array = getRecipesForTagNoGlobal(tag).duplicate()
	r.append_array(cachedByTag["*"]) # global recipes
	r.sort_custom(Sorter, "sort_recipes")
	
	return r

func getRecipeFromIdGlobal(recid:String) -> Recipe:
	return recipeSortable.getThing(recid, cached)

func getRecipeForInstance(recid:String, wid:String) -> Recipe:
	var ar : Array = getAllRecipesForInstance(wid)
	return recipeSortable.getThing(recid, ar)

func getRecipeFromId(recid:String, tag:String) -> Recipe:
	var car : Array = cachedByTag.get(tag, [])
	var thing = recipeSortable.getThing(recid, car)
	if thing:
		return thing
	
	var car2 = cachedByTag["*"]
	return recipeSortable.getThing(recid, car2)

func getRecipeQuality(rec:Recipe, workbenchID:String, inv:Inventory=null) -> RecipeQuality: # inv is the inventory of the char using it, if any
	var r : RecipeQuality = RecipeQuality.new()
	if !rec:
		return r
	
	var wb = Workbench.getInstance(workbenchID)
	if !wb:
		return r
	
	var q = {}
	
	var ingredients = rec.requiredIngredients
	var correctIngs = 0
	
	for key in ingredients: # count given ings that are also base, ignoring extras
		correctIngs += int(wb.getIngredientIdx(key)!=-1)
	
	var itemIngs = rec.requiredItems
	if inv:
		for itemid in itemIngs.keys():
			correctIngs += int(inv.hasItemID(itemid))
	
	if correctIngs!=ingredients.keys().size()+itemIngs.keys().size(): # wrong correct ings, some are missing
#		print("incorrect ing pop for "+rec.name)
		return r
	
	var extraQualityData = {} # id for quality kind: float for final quality (0.0-1.0), for use in custom items
	
	var qpercsum := 0.0 # quality percentage sum, to find avg quality from each ingkey quality
	
	var count = 0 # only counts stuff that's normal in quality calcs
	for ingkey in ingredients.keys(): # for given ingredients, checks against base ingredients since we know they exist
		var reqamount = ingredients[ingkey]
		var givenamount = wb.getIngredientAmount(ingkey)
		var m = reqamount[0]
		if givenamount<m: # an ingredient isn't enough
#			print("ingredient %s isn't enough for %s" % [ingkey, rec.name])
			return r
		
		var perc = 0.0 # satisfaction perc, pretty much float 0-1 between min-max if req range, otherwise for static req amount 1.0 if correct
		var percMult = 1.0 # this is set sepending on special ingredient quality data
		
		
		if reqamount.size()>1: # req amount range
			var M = reqamount[1]
			perc = min(inverse_lerp(m,M,givenamount),1.0)
		else: # enough if no req range; static req amount
			perc = float(givenamount>=m)
		
		qpercsum += perc*percMult
		count+=1
	
	
	for itemid in itemIngs.keys(): # for inv, checks against required items since we know they exist
		var reqamount = itemIngs[itemid]
		var givenamount = inv.getXOfTotal(itemid)
		var m = reqamount[0]
		if givenamount<m: # an item isn't enough
#			print("item %s isn't enough for %s" % [itemid, rec.name])
			return r
		
		var perc = 0.0 # satisfaction perc, pretty much float 0-1 between min-max if req range, otherwise for static req amount 1.0 if correct
		
		
		if reqamount.size()>1: # req amount range
			var M = reqamount[1]
			perc = min(inverse_lerp(m, M, givenamount), 1.0)
		else: # enough if no req range; static req amount
			perc = float(givenamount>=m)
	
		qpercsum += perc
		count+=1
	
	if rec.extraQualityCallback.size()==2:
		if rec.extraQualityCallback[0] && rec.extraQualityCallback[1]:
			extraQualityData = rec.extraQualityCallback[0].callv(rec.extraQualityCallback[1], [rec, workbenchID, inv])
	
	q = (qpercsum/float(count)) if count else float( itemIngs.empty() && ingredients.empty() )
	
	r.baseQuality = q
	r.extras = extraQualityData
	
	return r

func getAvailRecipesForInstance(wid:String, inv:Inventory=null) -> Array: # array of recipes
	var avails = []
	var wb = Workbench.getWorkbenchInstanceFromId(wid)
	if !wb:
		return []
	
	
	var allrecs = [getRecipesForTagNoGlobal("*")]
	for tag in Workbench.getTagsForInstance(wid):
		allrecs.append(getRecipesForTagNoGlobal(tag))
	
	for rec in makeRecipesArrayFromArrays(allrecs):
		var q = getRecipeQuality(rec, wid, inv)
		if q.baseQuality>0: # can make
			avails.append(rec)

	return avails

func getAllRecipesForInstance(wid:String) -> Array:
	var allrecs = [getRecipesForTagNoGlobal("*")]
	for tag in Workbench.getTagsForInstance(wid):
		allrecs.append(getRecipesForTagNoGlobal(tag))
	
	return makeRecipesArrayFromArrays(allrecs)

func getRecipesCanMakeInstance(wid, inv:Inventory=null) -> Dictionary: # returns dict w/ all recipes for workbench instance as keys, and all values as doable or not (have min. ingredients/items)
	var res = {} # key is recipe for rec, value is can be made bool (true means you can make it)
	
	for recipe in getAllRecipesForInstance(wid):
		var q = getRecipeQuality(recipe, wid, inv)
		res[recipe] = q.baseQuality>0
	return res


func craftRecipe(recid:String, wid:String, inv:Inventory=null) -> Array: # always assumes can be made, recid is recipeid for rec (key in recipes dict), returns array of items
	var wb = Workbench.getInstance(wid)
	if !wb:
#		print("no such workbench "+wid)
		return []
	var rec : Recipe = getRecipeForInstance(recid, wid)
	if !rec:
#		print("no such recipe "+recid+" for wb id "+wid)
		return []

#	var ings = Workbench.getWorkbenchStores(wid)
	var resultingItems : Array = []

	var reqings = rec.requiredIngredients
	var qdata = getRecipeQuality(rec, wid, inv)
	
	for it in rec.getFinalItem(inv, wb): # itembase array
		if it.has_method("setQuality"): # don't set quality for items that don't have any, such as basegame items
			it.setQuality(qdata)
		
		resultingItems.append(it)
	
	for ing in reqings.keys():
		var remVal = 0
		var givenAmount = wb.getIngredientAmount(ing)
		var reqAmount = reqings[ing]
		if reqAmount.size()>1: # req amount range
			remVal = min(givenAmount, reqAmount[1])
		else: # req amount static
			remVal = min(givenAmount, reqAmount[0]) # since always can make
		
		wb.addIngredient(ing, -remVal)
	
	var reqItems = rec.requiredItems
	for itemid in reqItems.keys():
		var remVal = 0
		var reqAmount = reqItems[itemid]
		if reqAmount.size()>1: # req amount range
			remVal = reqAmount[1] # get max
		else: # req amount static
			remVal = reqAmount[0] # since always can make
		inv.removeXOfOrDestroy(itemid, remVal)
	
	return resultingItems

func fullerCraftRecipe(recid:String, wid:String, inv:Inventory=null) -> Dictionary: # returns dict {items=array(object), ings=dict(id:amount), message=string}, doesn't add items to inv
	var finv = inv if inv else GM.pc.getInventory()
	var items : Array = craftRecipe(recid, wid, finv) # array of items
	var resultingIngs = getRecipeForInstance(recid, wid).resultingIngredients # ing: amount
	
	var list = []
	for item in items:
		list.append(item.getAStackName())
	for ing in resultingIngs:
		var idata = Ingredients.getIngredient(ing)
		if !idata:
			list.append("Can't find ingredient with id %s!" % ing)
			continue
		
		var m = idata.measure if idata.measure else "pcs"
		var iname = idata.name if idata.name else "(unknown)"
		list.append(str(resultingIngs[ing])+(" "+m if m else "")+" "+iname)
		Workbench.addIngredient(wid, ing, resultingIngs[ing])
	
	return {
		"items":items,
		"ings":resultingIngs,
		"message":Util.humanReadableList(list) if list else "nothing",
	}

func fullCraftRecipe(recid:String, wid:String, inv:Inventory=null) -> void: # this does everything, use when crafting simple recipes. always assumes can be made
	var recipeResultData = fullerCraftRecipe(recid, wid, inv)
	
	if !inv:
		return
	getMod().addCraftedItemsToInv(recipeResultData.get("items", []), inv)
	GM.main.addMessage(recipeResultData.get("message", ""))

