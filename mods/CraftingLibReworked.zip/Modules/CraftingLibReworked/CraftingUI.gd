extends HBoxContainer

var mod : Module

onready var recTree : Tree = $vb2/recipeTree
onready var ingTree : Tree = $vb2/ingTree
onready var console : RichTextLabel = $vb/console

var workbenchID : String = ""

func _ready():
	mod = GlobalRegistry.getModule("CraftingLibReworked")
	
	populate()
	displayIngredients()
	
	recTree.connect("item_selected", self, "onRecipeSelected")
	recTree.set_column_title(0, "Recipe")
	ingTree.set_column_title(0, "Ingredient")
	ingTree.set_column_title(1, "Amount")
	ingTree.set_column_title(2, "Maximum")
	$vb/craft.disabled = true
	
	mod.connect("updateWorkbenchType", self, "onUpdateRequested")

func onUpdateRequested(wtype:String) -> void:
	var wbtype = mod.Workbench.getInstance(workbenchID).type
	if wbtype!=wtype:
		return
	
	populate()
	displayIngredients()


func onRecipeSelected() -> void:
	var selectedId : String = recTree.get_selected().get_metadata(0)
	selectRecipe(selectedId)

func populate() -> void:
	clearRecipeTree()
	var recs = mod.Recipes.getRecipesCanMakeInstance(workbenchID, GM.pc.getInventory())
	for rec in recs:
		var titem : TreeItem = recTree.create_item()
		titem.set_metadata(0, rec.id)
		titem.set_text(0, rec.name if rec.name else "(unknown)")
		titem.set_custom_color(0, Color.white if recs[rec] else Color.webgray)

func clearRecipeTree() -> void:
	recTree.clear()
	recTree.create_item()

func getStores() -> Dictionary:
	return mod.Workbench.getWorkbenchStores(workbenchID)

func clearIngredients() -> void:
	ingTree.clear()
	ingTree.create_item()

func selectRecipe(rid:String) -> void:
	var rec = mod.Recipes.getRecipeForInstance(rid, workbenchID)
	
	console.clear()
	
	console.append_bbcode("[color=gold]Requires items:[/color]\n")
	var ritems = mod.Ingredients.getIngredientsRequiredArray({}, rec.requiredItems, GM.pc.getInventory())
	console.append_bbcode( "\n".join(ritems) if ritems else "[color=gray](none)[/color]" )
	console.append_bbcode("\n\n[color=gold]Requires ingredients:[/color]\n")
	var rings = mod.Ingredients.getIngredientsRequiredArray(rec.requiredIngredients, {}, null)
	console.append_bbcode( "\n".join(rings) if rings else "[color=gray](none)[/color]" )
	
	
	console.append_bbcode("\n\n[color=gold]Crafted items:[/color]\n")
	var cits = mod.Recipes.getCraftedItemsLines(rec)
	console.append_bbcode("\n".join(cits) if cits else "[color=gray](none)[/color]")
	
	var cings = mod.Recipes.getCraftedIngredientsLines(rec)
	console.append_bbcode("\n\n[color=gold]Crafted ingredients:[/color]\n")
	console.append_bbcode("\n".join(cings) if cings else "[color=gray](none)[/color]")
	
	var q = mod.Recipes.getRecipeQuality(rec, workbenchID, GM.pc.getInventory())
	
	console.append_bbcode("\n\nExpected base quality: %s" % [str(q.baseQuality*100).pad_decimals(0)+"%"])
	
	$vb/craft.disabled = q.baseQuality<=0

func displayIngredients():
	clearIngredients()
	
	var wb = mod.Workbench.getInstance(workbenchID)
	if !wb:
		return
	var type = mod.Workbench.getType(wb.type)
	if !type:
		return
	
	var ings = getStores()
	if !ings:
		var t : TreeItem = ingTree.create_item()
		t.set_custom_color(0, Color.webgray)
		t.set_text(0, "(none)")
		return
	
	var caps = type.getIngredientCapsForData(wb.typeData)
	for array in ings:
		if !array:
			continue
		var idata = mod.Ingredients.getIngredient(array[0])
		var n = idata.name if idata.name else "(unknown)"
		
		var a = "%s %s" % [str(array[1] if array.size()>1 else 0.0).pad_decimals(2), idata.measure if idata.measure else "pcs"]
		
		var maxam : float = mod.Workbench.getMaxIngredientAmountDirect(wb, array[0], caps)
		var m : String = str(maxam).pad_decimals(2) if maxam>=0 else "Infinite"
		
		var it : TreeItem = ingTree.create_item()
		it.set_text(0, n)
		it.set_text(1, a)
		it.set_text(2, m)
		it.set_custom_color(0, Color.white)

func colorizeRecipeItem(t:TreeItem) -> void:
	var rec = mod.Recipes.getRecipeForInstance(t.get_metadata(0), workbenchID)
	var q = mod.Recipes.getRecipeQuality(rec, workbenchID, GM.pc.getInventory())
	t.set_custom_color(0, Color.white if q.baseQuality>0 else Color.webgray)

func _on_craft_pressed():
	var pcInv : Inventory = GM.pc.getInventory()
	var recid : String = recTree.get_selected().get_metadata(0)
	
	var recipeResultData = mod.Recipes.fullerCraftRecipe(recid, workbenchID, pcInv)
	
	var resings = recipeResultData.get("ingredients", [])
	for ingArray in resings:
		mod.Workbench.addIngredient(workbenchID, ingArray[0], ingArray[1])
	
	
	displayIngredients()
	selectRecipe(recid)
	
	mod.addCraftedItemsToInv(recipeResultData.get("items", []), pcInv)
	console.append_bbcode("\n\n[center][color=gray][i]Crafted:\n%s[/i][/color][/center]" % recipeResultData.get("message", ""))
	
	var child = recTree.get_root().get_children()
	while child!=null:
		colorizeRecipeItem(child)
		child = child.get_next()
