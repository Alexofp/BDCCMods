extends Attack

func _init():
	id = "GunModEnergyRifleFocusedShotPCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isWeaponAttack = true

func getVisibleName(_context = {}):
	return "Focused Shot"

func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	if(item == null):
		return "error"

	return item.getVisisbleDescription()

func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical)):
		return genericMissMessage(_attacker, _receiver)

	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)

	var damageRange = [0,0]

	var item = getItem(_context)
	if(item != null):
		damageRange = item.getFocusedDamageRange()
		item.useCharge()
	elif(!_attacker.isPlayer()):
		damageRange = GlobalRegistry.getItemRef("GunModEnergyRifle").getFocusedDamageRange()

	var text = "{attacker.name} charges up the laser rifle for a focused shot, hitting {receiver.name} and causing intense pain."

	var pain = RNG.randi_range(damageRange[0], damageRange[1])
	if(GM.main.isInSpecificPlayerSlavery("WarDraft")):
		pain = int(round(pain * 0.4))

	return {
		text = text,
		pain = pain,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context) || !_attacker.isPlayer()

func getAttackSoloAnimation():
	return ["firerifle", "res://Modules/GunMod/Models/EnergyRifle.tscn"]

func getExperience():
	return [[Skill.Combat, 5]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.05

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]
