extends Attack

func _init():
	id = "GunModEnergyRifleSuppressingFirePCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isWeaponAttack = true

func getVisibleName(_context = {}):
	return "Suppressing Fire"

func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	if(item == null):
		return "error"
	var charges = item.getCharges()

	return "Use 3 battery cells to unload a burst of 2 to 12 weaker shots, each doing 12 physical damage."+"\n"+"Has "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "battery cell")+" left"

func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical)):
		return genericMissMessage(_attacker, _receiver)

	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)

	var item = getItem(_context)
	if(item != null):
		item.useCharge(3)

	var amountOfShots = RNG.randi_range(1, 6) + RNG.randi_range(1, 6)

	var text = "{attacker.name} holds the trigger down, unloading a suppressing burst from the laser rifle, hitting {receiver.name} "+str(amountOfShots)+" times."

	var pain = amountOfShots * 12
	if(GM.main.isInSpecificPlayerSlavery("WarDraft")):
		pain = int(round(pain * 0.4))

	return {
		text = text,
		pain = pain,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context) || !_attacker.isPlayer()

func getAttackSoloAnimation():
	return ["firerifle", "res://Modules/GunMod/Models/EnergyRifle.tscn"]

func getExperience():
	return [[Skill.Combat, 5]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.15

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]
