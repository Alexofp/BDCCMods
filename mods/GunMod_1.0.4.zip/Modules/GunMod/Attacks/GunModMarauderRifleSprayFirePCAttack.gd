extends Attack

func _init():
	id = "GunModMarauderRifleSprayFirePCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isWeaponAttack = true

func getVisibleName(_context = {}):
	return "Spray Fire"

func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	if(item == null):
		return "error"
	var charges = item.getCharges()

	return "Use 4 rounds to spray a wide 4-round burst, each doing 15 to 25 physical damage. 35% accuracy penalty."+"\n"+"Has "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "round")+" left"

func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical, 0.65)):
		return genericMissMessage(_attacker, _receiver)

	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)

	var item = getItem(_context)
	if(item != null):
		item.useCharge(4)

	var totalPain = 0
	for _i in range(4):
		totalPain += RNG.randi_range(15, 25)
	if(GM.main.isInSpecificPlayerSlavery("WarDraft")):
		totalPain = int(round(totalPain * 0.4))

	var text = "{attacker.name} sprays a wild 4-round burst from the rifle, riddling {receiver.name} with bullets."

	if(RNG.chance(50) && _receiver.addEffect(StatusEffect.Bleeding)):
		text += " [b]{receiver.name} begins bleeding![/b]"

	return {
		text = text,
		pain = totalPain,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context) || !_attacker.isPlayer()

func getAttackSoloAnimation():
	return ["firerifle", "res://Modules/GunMod/Models/MarauderRifle.tscn"]

func getExperience():
	return [[Skill.Combat, 5]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.4

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]
