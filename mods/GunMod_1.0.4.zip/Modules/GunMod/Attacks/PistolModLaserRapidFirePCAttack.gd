extends Attack

func _init():
	id = "PistolModLaserRapidFirePCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isWeaponAttack = true

func getVisibleName(_context = {}):
	return "Rapid Fire"

func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	if(item == null):
		return "error"
	var charges = item.getCharges()

	return "Use 2 battery cells to unload a burst of 2 to 10 weaker shots, each doing 10 physical damage."+"\n"+"Has "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "battery cell")+" left"

func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical)):
		return genericMissMessage(_attacker, _receiver)

	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)

	var item = getItem(_context)
	if(item != null):
		item.useCharge(2)

	var amountOfShots = RNG.randi_range(1, 5) + RNG.randi_range(1, 5)

	var text = "{attacker.name} holds the trigger down, unloading a rapid burst from the laser pistol, hitting {receiver.name} "+str(amountOfShots)+" times."

	return {
		text = text,
		pain = amountOfShots * 10,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context)

func getAttackSoloAnimation():
	return ["firepistol", "res://Inventory/UnriggedModels/EnergyPistol/EnergyPistolBlue.tscn"]

func getExperience():
	return [[Skill.Combat, 5]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.2

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]
