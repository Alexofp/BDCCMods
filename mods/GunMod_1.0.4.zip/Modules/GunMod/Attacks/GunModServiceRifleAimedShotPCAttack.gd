extends Attack

func _init():
	id = "GunModServiceRifleAimedShotPCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isWeaponAttack = true

func getVisibleName(_context = {}):
	return "Aimed Shot"

func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	if(item == null):
		return "error"

	return item.getVisisbleDescription()

func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical)):
		return genericMissMessage(_attacker, _receiver)

	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)

	var damageRange = [0,0]

	var item = getItem(_context)
	if(item != null):
		damageRange = item.getAimedDamageRange()
		item.useCharge()
	elif(!_attacker.isPlayer()):
		damageRange = GlobalRegistry.getItemRef("GunModServiceRifle").getAimedDamageRange()

	var text = "{attacker.name} lines up an aimed shot with the rifle and fires. The bullet tears into {receiver.name}, leaving a gaping hole in its way."

	if(RNG.chance(50) && _receiver.addEffect(StatusEffect.Bleeding)):
		text += " [b]{receiver.name} begins bleeding![/b]"

	var pain = RNG.randi_range(damageRange[0], damageRange[1])
	if(GM.main.isInSpecificPlayerSlavery("WarDraft")):
		pain = int(round(pain * 0.4))

	return {
		text = text,
		pain = pain,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context) || !_attacker.isPlayer()

func getAttackSoloAnimation():
	return ["firerifle", "res://Modules/GunMod/Models/ServiceRifle.tscn"]

func getExperience():
	return [[Skill.Combat, 5]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.8

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]
