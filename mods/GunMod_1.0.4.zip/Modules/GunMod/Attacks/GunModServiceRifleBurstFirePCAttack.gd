extends Attack

func _init():
	id = "GunModServiceRifleBurstFirePCAttack"
	category = Category.Physical
	aiCategory = AICategory.Offensive
	isWeaponAttack = true

func getVisibleName(_context = {}):
	return "Burst Fire"

func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	if(item == null):
		return "error"
	var charges = item.getCharges()

	return "Use 3 rounds to fire a 3-round burst, each doing 15 to 25 physical damage. 20% accuracy penalty."+"\n"+"Has "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "round")+" left"

func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical, 0.8)):
		return genericMissMessage(_attacker, _receiver)

	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)

	var item = getItem(_context)
	if(item != null):
		item.useCharge(3)

	var totalPain = 0
	for _i in range(3):
		totalPain += RNG.randi_range(15, 25)
	if(GM.main.isInSpecificPlayerSlavery("WarDraft")):
		totalPain = int(round(totalPain * 0.4))

	var text = "{attacker.name} lets loose a 3-round burst from the rifle, riddling {receiver.name} with bullets."

	if(RNG.chance(50) && _receiver.addEffect(StatusEffect.Bleeding)):
		text += " [b]{receiver.name} begins bleeding![/b]"

	return {
		text = text,
		pain = totalPain,
	}

func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context) || !_attacker.isPlayer()

func getAttackSoloAnimation():
	return ["firerifle", "res://Modules/GunMod/Models/ServiceRifle.tscn"]

func getExperience():
	return [[Skill.Combat, 5]]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.5

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]
