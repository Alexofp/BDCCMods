extends LootList

func _init():
	handlesIds = ["guard", "junkie", "junkieWeaponsLocker", "junkieStash"]
	handlesCharacters = ["captain"]

func getLoot(_id, _characterID, _battleName):
	var result = []

	# Generic pawn defeat drops (Inventory/LootTable/GuardLoot.gd id="guard",
	# JunkieLoot.gd id="junkie") and the Drug Den's own dungeon loot tables
	# (Inventory/LootTable/JunkieWeaponsLockerLoot.gd id="junkieWeaponsLocker",
	# JunkieStashLoot.gd id="junkieStash") - all additive, no overrides.
	if(_id == "guard"):
		result.append([3, ["PistolModGun"]])
	if(_id == "junkie"):
		result.append([2, ["PistolModGun"]])
	if(_id == "junkieWeaponsLocker"):
		result.append([15, ["PistolModGun"]])
		result.append([3, ["PistolModLaserPistol"]])
		result.append([5, ["GunModServiceRifle"]])
		result.append([6, ["GunModMarauderRifle"]])
		result.append([1, ["GunModEnergyRifle"]])
	if(_id == "junkieStash"):
		result.append([3, ["PistolModGun"]])
		result.append([1, ["GunModServiceRifle"]])
		result.append([2, ["GunModMarauderRifle"]])

	# Signature rare drop when the Captain specifically is defeated, regardless
	# of which loot table id the battle uses - keeps the laser pistol feeling
	# like the Captain's own weapon rather than a common find.
	if(_characterID == "captain"):
		result.append([8, ["PistolModLaserPistol"]])

	return result
