extends Module

func getFlags():
	return {
		"LastSoapDropDay": flag(FlagType.Number),
	}

func _init():
	id = "GunMod"
	author = "Adria"

	characters = [
		"res://Modules/GunMod/WarDraft/Drask.gd",
		"res://Modules/GunMod/WarDraft/Vex.gd",
	]

	scenes = [
		"res://Modules/GunMod/WarDraft/WarDraftStart.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDraskTalkScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftVexTalkScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftFinalPushScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftPatrolEncounterScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftCapturedScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftSyndicateOfferScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftPrisonScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftRescueObjectiveScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftBombObjectiveScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftAmbushScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftCapturedSoldierScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftKidlatCameoScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDetentionFightScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDetentionEscapeScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftStocksPunishmentScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftSoapDropScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDishonorableDischargeScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDraskMoraleCommentScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftRescuedByAlliesScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftFiringSquadScene.gd",
		"res://Modules/GunMod/WarDraft/WarDraftSyndicateFinalPushScene.gd",
	]

	events = [
		"res://Modules/GunMod/WarDraft/WarDraftPatrolEvent.gd",
		"res://Modules/GunMod/WarDraft/WarDraftDetentionEvent.gd",
		"res://Modules/GunMod/WarDraft/WarDraftBlockCellEventsEvent.gd",
	]

	items = [
		"res://Modules/GunMod/Items/Pistol.gd",
		"res://Modules/GunMod/Items/LaserPistol.gd",
		"res://Modules/GunMod/Items/ServiceRifle.gd",
		"res://Modules/GunMod/Items/EnergyRifle.gd",
		"res://Modules/GunMod/Items/MarauderRifle.gd",
		"res://Modules/GunMod/Items/ConscriptArmor.gd",
		"res://Modules/GunMod/Items/ConscriptHelmet.gd",
	]

	attacks = [
		"res://Modules/GunMod/Attacks/PistolModFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/PistolModLaserPreciseShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/PistolModLaserRapidFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModServiceRifleAimedShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModServiceRifleBurstFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModEnergyRifleFocusedShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModEnergyRifleSuppressingFirePCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModMarauderRifleAimedShotPCAttack.gd",
		"res://Modules/GunMod/Attacks/GunModMarauderRifleSprayFirePCAttack.gd",
	]

	lootLists = [
		"res://Modules/GunMod/LootLists/PistolModWeaponsList.gd",
	]

	# Acquisition, all additive - no overrides needed:
	#  - All seven items are tagged ItemTag.SoldByMirri, and MirriBuySellScene
	#    (Modules/SlaveAuctionModule/Mirri/MirriBuySellScene.gd) scans all
	#    registered items for that tag automatically. All three rifles also
	#    drop from the Drug Den's junkieWeaponsLocker/junkieStash loot tables
	#    now (5%/6%/1% locker, 1%/2%/- stash for service/marauder/laser rifle
	#    respectively) - kept off the common guard/junkie combat drop pools
	#    though, unlike the pistol, so they stay rarer than a random mugging.
	#  - PistolModWeaponsList (lootLists above) registers itself under the
	#    existing "guard"/"junkie" pawn-loot ids (Inventory/LootTable/GuardLoot.gd,
	#    JunkieLoot.gd) and the Drug Den's own "junkieWeaponsLocker"/"junkieStash"
	#    dungeon loot table ids (Inventory/LootTable/JunkieWeaponsLockerLoot.gd,
	#    JunkieStashLoot.gd) - GlobalRegistry.registerLootList() just appends to
	#    a list keyed by these id strings (see LootTableBase.getPossibleLoot()),
	#    so any mod can extend any loot table/pawn archetype this way without
	#    touching the file that owns it. The laser pistol also drops as an
	#    8% signature reward specifically off the Captain (handlesCharacters).
	#
	# Reuses base-game assets that already exist but were never wired to a
	# player-usable item: the "firepistol" animation id, and the
	# Inventory/UnriggedModels/Pistol/ and EnergyPistol/ model/icon pairs
	# (previously only used by Mirri's NPC-only MirriPistolShot attack and the
	# Captain's NPC-only CapEnergyBlast/CapRapidFire attacks, respectively).
	# The laser pistol's damage/armor-scaling numbers and flavor text are
	# lifted directly from CapEnergyBlast/CapRapidFire for balance parity with
	# the Captain's own version of the same weapon.
	#
	# NOTE: unlike everything above, the rifle/laser rifle's two-handed
	# "holdrifle"/"aimrifle"/"firerifle" animation poses are NOT mod-additive -
	# this mod depends on files living outside this folder, both edited
	# directly (search each for "GUNMOD" - not all edits are marked, see below):
	#  - Player/StageScene3D/Scenes/DollSoloAnimationTree.tres - added the
	#    WeaponGunDualHold-loop/WeaponGunDualAim-loop/WeaponGunDualShoot states
	#    and their transitions to the animation state machine graph. Resource
	#    .tres format has no room for a text marker comment, so this one isn't
	#    tagged "GUNMOD" - diff against a clean checkout to isolate the change.
	#  - Player/StageScene3D/BaseStageScene3D.gd (search "GUNMOD") - added the
	#    holdrifle/aimrifle/firerifle animID branches that travel to those new
	#    states and attach the weapon model to hand.L (the rifle is gripped by
	#    its trigger in the left hand, same single attachment point the
	#    one-handed pistol poses use - only the pose itself is two-handed).
	# Both need to be included when packaging with ModMaker, and both will
	# conflict with any future base-game change to those files, or another mod
	# that also touches them - same tradeoff as the Talking.gd override
	# documented in Modules/GangbangPerkMod/Module.gd.
	#
	# ConscriptArmor/ConscriptHelmet are the first "War Draft" scenario assets:
	# a recolored copy of the base game's GuardArmor/GuardHelmet rigged models
	# (Inventory/RiggedModels/GuardClothes/, .../GuardHelmet/) living under
	# Modules/GunMod/Models/ConscriptUniform/ - copied rather than overriding
	# the originals so regular prison guards don't get recolored too. Currently
	# tagged SoldByMirri purely as a debug/testing convenience so they're easy
	# to pull up in-game; revisit that tag once the actual War Draft scenario
	# exists and decides how conscripts should really acquire this gear.

func postInit():
	# PlayerSlaveryDef has no Module array to register into (see
	# GlobalRegistry.registerPlayerSlaveryDef) - has to happen here instead.
	GlobalRegistry.registerPlayerSlaveryDef("res://Modules/GunMod/WarDraft/WarDraftDef.gd")

	# Same story for GlobalTask/PawnInteraction - no Module array for either,
	# both individually-callable the same way (see registerInteraction() in
	# GlobalRegistry.gd). These two together are what makes the detention
	# floor's jailers real patrolling pawns (the base game's own
	# GlobalTask/InteractionGoal.Patrol/WorldZone machinery, same system
	# Cellblock's own guards patrol with) instead of a per-room dice roll:
	# WarDraftJailerPatrolTask assigns WarDraftBase's own jailer pawns to
	# patrol the "wardraftdetention" zone (see WarDraftDetentionFloor.tscn's
	# zone_wardraftdetention room groups), WarDraftJailerSpotsPlayer detects
	# the real spatial catch when a jailer and the player end up in the same
	# room and hands off to WarDraftDetentionFightScene.
	GlobalRegistry.registerGlobalTask("res://Modules/GunMod/WarDraft/WarDraftJailerPatrolTask.gd")
	GlobalRegistry.registerInteraction("res://Modules/GunMod/WarDraft/WarDraftJailerSpotsPlayer.gd")
	GlobalRegistry.registerPawnType("res://Modules/GunMod/WarDraft/WarDraftSyndicateJailerPawnType.gd")

	# --- TEST-ONLY DEBUG COMMANDS, remove before packaging a release build ---
	Console.addCommand("psmenu", self, "consoleShowSlaveryPicker", [], "Open the PlayerSlavery picker menu directly (lists all soft bad ends, including War Draft)")
	Console.addCommand("vextalk", self, "consoleShowVexTalk", [], "Open WarDraftVexTalkScene directly - now has a real trigger too (the 'final push?' option once corruption hits 100 while defected)")
	Console.addCommand("morale100", self, "consoleSetMorale100", [], "Set WarDraft morale to 100 (final push threshold) - must already be in the WarDraft scenario")
	Console.addCommand("moralebad", self, "consoleSetMoraleBad", [], "Set WarDraft morale to the dishonorable-discharge threshold - must already be in the WarDraft scenario, then click Extract to trigger it")
	Console.addCommand("corruptionbad", self, "consoleSetCorruptionBad", [], "Set WarDraft corruption to the firing-squad threshold - must already be in the WarDraft scenario and defected, then click Extract to trigger it")
	Console.addCommand("corruption100", self, "consoleSetCorruption100", [], "Set WarDraft corruption to 100 (Syndicate final push threshold) - must already be in the WarDraft scenario and defected")

func consoleShowSlaveryPicker():
	GM.main.runScene("PlayerSlaveryPickScene")
	GM.main.runCurrentScene()

func consoleSetMorale100():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addMorale(100 - GM.main.PS.morale)

func consoleSetMoraleBad():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addMorale(GM.main.PS.MoraleThresholdForDischargeBad - GM.main.PS.morale)

func consoleSetCorruptionBad():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addCorruption(GM.main.PS.CorruptionThresholdForFiringSquad - GM.main.PS.corruption)

func consoleSetCorruption100():
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		Log.printerr("ERROR: not currently in the WarDraft scenario")
		return
	GM.main.PS.addCorruption(100 - GM.main.PS.corruption)

func consoleShowVexTalk():
	GM.main.runScene("WarDraftVexTalkScene")
	GM.main.runCurrentScene()
