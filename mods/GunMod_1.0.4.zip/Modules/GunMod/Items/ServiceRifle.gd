extends ItemBase

var charges:int = 12

func useCharge(amount = 1):
	charges -= amount
	if(charges <= 0):
		destroyMe()

func getCharges():
	return charges

func getAimedDamageRange():
	return [60, 85]

func _init():
	id = "GunModServiceRifle"

func getVisibleName():
	return "Service rifle"

func getDescription():
	var text = "A full-size ballistic rifle.\nAimed Shot does "+Util.dmgRangeArrayStr(getAimedDamageRange())+" physical damage and has a chance to cause bleeding.\nBurst Fire trades accuracy for a 3-round burst.\nHas "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "round")+" left in the magazine."

	return text

func saveData():
	var data = .saveData()

	data["charges"] = charges

	return data

func loadData(data):
	.loadData(data)

	charges = SAVE.loadVar(data, "charges", 12)

func getAttacks():
	return ["GunModServiceRifleAimedShotPCAttack", "GunModServiceRifleBurstFirePCAttack"]

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getItemCategory():
	return ItemCategory.Weapons

func getInventoryImage():
	return "res://Modules/GunMod/Models/ServiceRifle.png"

func getPrice():
	return 500

func canSell():
	return true
