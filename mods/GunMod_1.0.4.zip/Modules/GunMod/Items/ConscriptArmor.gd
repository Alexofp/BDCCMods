extends ItemBase

func _init():
	id = "GunModConscriptArmor"

func getVisibleName():
	return "AlphaCorp fatigues"

func getDescription():
	return "Digital green camo plating covering the torso and limbs, paired with dull black gloves and boots. Standard-issue for whoever AlphaCorp ships to the front next."

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return []

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off the fatigues"
	else:
		return "take off the fatigues"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the fatigues"
	else:
		return "put on the fatigues"

func generateItemState():
	itemState = ShirtAndShortsState.new()

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"clothing": "res://Modules/GunMod/Models/ConscriptUniform/ConscriptArmor.tscn",
	}

func getHidesParts(_character):
	if(itemState.isRemoved()):
		return null
	var removed = {
		BodypartSlot.Legs: true,
		BodypartSlot.Arms: true,
		BodypartSlot.Body: true,
		BodypartSlot.Breasts: true,
		"panties": true,
		"bra": true,
		"top": true,
	}
	if(!itemState.areShortsPulledDown() && !itemState.isDamaged()):
		removed[BodypartSlot.Penis] = true

	return removed

func getInventoryImage():
	return "res://Modules/GunMod/Models/ConscriptUniform/conscriptArmorIcon.png"

func getPrice():
	return 300

func canSell():
	return true
