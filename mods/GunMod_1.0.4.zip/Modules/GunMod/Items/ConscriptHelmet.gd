extends ItemBase

func _init():
	id = "GunModConscriptHelmet"

func getVisibleName():
	return "AlphaCorp helmet"

func getDescription():
	return "A green field helmet with a black visor and a sharp crest running down the back. Standard-issue for conscripts sent to the front."

func getClothingSlot():
	return InventorySlot.Eyes

func getBuffs():
	return []

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off the helmet"
	else:
		return "take off the helmet"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the helmet"
	else:
		return "put on the helmet"

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"helmet": "res://Modules/GunMod/Models/ConscriptUniform/ConscriptHelmet.tscn",
	}

func getHidesParts(_character):
	if(itemState.isRemoved()):
		return null
	var removed = {
		BodypartSlot.Hair: true,
		BodypartSlot.Head: true,
		BodypartSlot.Ears: true,
		BodypartSlot.Horns: true,
	}

	return removed

func getInventoryImage():
	return "res://Modules/GunMod/Models/ConscriptUniform/conscriptHelmetIcon.png"

func getPrice():
	return 150

func canSell():
	return true
