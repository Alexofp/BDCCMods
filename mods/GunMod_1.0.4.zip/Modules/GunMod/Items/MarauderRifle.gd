extends ItemBase

var charges:int = 20

func useCharge(amount = 1):
	charges -= amount
	if(charges <= 0):
		destroyMe()

func getCharges():
	return charges

func getAimedDamageRange():
	return [65, 95]

func _init():
	id = "GunModMarauderRifle"

func getVisibleName():
	return "Marauder rifle"

func getDescription():
	var text = "A rugged, sleek rifle stripped off a dead raider. Hits harder than it aims.\nAimed Shot does "+Util.dmgRangeArrayStr(getAimedDamageRange())+" physical damage, has a chance to cause bleeding, and is a bit less accurate than a service rifle.\nSpray Fire trades even more accuracy for a wide 4-round burst.\nHas "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "round")+" left in the magazine."

	return text

func saveData():
	var data = .saveData()

	data["charges"] = charges

	return data

func loadData(data):
	.loadData(data)

	charges = SAVE.loadVar(data, "charges", 20)

func getAttacks():
	return ["GunModMarauderRifleAimedShotPCAttack", "GunModMarauderRifleSprayFirePCAttack"]

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getItemCategory():
	return ItemCategory.Weapons

func getInventoryImage():
	return "res://Modules/GunMod/Models/MarauderRifle.png"

func getPrice():
	return 400

func canSell():
	return true
