extends ItemBase

var charges:int = 8

func useCharge(amount = 1):
	charges -= amount
	if(charges <= 0):
		destroyMe()

func getCharges():
	return charges

func getFocusedDamageRange():
	return [70, 95]

func _init():
	id = "GunModEnergyRifle"

func getVisibleName():
	return "Laser rifle"

func getDescription():
	var text = "A rare, heavy-duty energy rifle. Its charge barely dips for armor.\nFocused Shot does "+Util.dmgRangeArrayStr(getFocusedDamageRange())+" physical damage and mostly ignores armor.\nSuppressing Fire unloads a large burst of weaker shots that drains the battery faster.\nHas "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "battery cell")+" left."

	return text

func saveData():
	var data = .saveData()

	data["charges"] = charges

	return data

func loadData(data):
	.loadData(data)

	charges = SAVE.loadVar(data, "charges", 8)

func getAttacks():
	return ["GunModEnergyRifleFocusedShotPCAttack", "GunModEnergyRifleSuppressingFirePCAttack"]

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getItemCategory():
	return ItemCategory.Weapons

func getInventoryImage():
	return "res://Modules/GunMod/Models/EnergyRifle.png"

func getPrice():
	return 1200

func canSell():
	return true
