extends ItemBase

var charges:int = 6

func useCharge(amount = 1):
	charges -= amount
	if(charges <= 0):
		destroyMe()

func getCharges():
	return charges

func getDamageRange():
	return [45, 65]

func _init():
	id = "PistolModGun"

func getVisibleName():
	return "Pistol"

func getDescription():
	var text = "A stolen sidearm, still loaded.\nDoes "+Util.dmgRangeArrayStr(getDamageRange())+" physical damage and has a chance to cause bleeding.\nHas "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "round")+" left in the chamber."

	return text

func saveData():
	var data = .saveData()

	data["charges"] = charges

	return data

func loadData(data):
	.loadData(data)

	charges = SAVE.loadVar(data, "charges", 6)

func getAttacks():
	return ["PistolModFirePCAttack"]

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getItemCategory():
	return ItemCategory.Weapons

func getInventoryImage():
	return "res://Inventory/UnriggedModels/Pistol/Pistol.png"

func getPrice():
	return 250

func canSell():
	return true
