extends ItemBase

var charges:int = 4

func useCharge(amount = 1):
	charges -= amount
	if(charges <= 0):
		destroyMe()

func getCharges():
	return charges

func getPrecisionDamageRange():
	return [50, 70]

func _init():
	id = "PistolModLaserPistol"

func getVisibleName():
	return "Laser pistol"

func getDescription():
	var text = "A confiscated guard-issue energy sidearm. Its charge barely dips for armor.\nPrecise Shot does "+Util.dmgRangeArrayStr(getPrecisionDamageRange())+" physical damage and mostly ignores armor.\nRapid Fire unloads a burst of weaker shots that drains the battery faster.\nHas "+str(charges)+" "+Util.multipleOrSingularEnding(charges, "battery cell")+" left."

	return text

func saveData():
	var data = .saveData()

	data["charges"] = charges

	return data

func loadData(data):
	.loadData(data)

	charges = SAVE.loadVar(data, "charges", 4)

func getAttacks():
	return ["PistolModLaserPreciseShotPCAttack", "PistolModLaserRapidFirePCAttack"]

func getTags():
	return [ItemTag.Illegal, ItemTag.SoldByMirri]

func getItemCategory():
	return ItemCategory.Weapons

func getInventoryImage():
	return "res://Inventory/UnriggedModels/EnergyPistol/EnergyPistolBlue.png"

func getPrice():
	return 600

func canSell():
	return true
