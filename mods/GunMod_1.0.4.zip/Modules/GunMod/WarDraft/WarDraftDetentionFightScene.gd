extends SceneBase

var npcID:String = ""

func _init():
	sceneID = "WarDraftDetentionFightScene"

func _initScene(_args = []):
	npcID = _args[0] if _args.size() > 0 else ""

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _reactInit():
	# npcID is one of WarDraftBase's own persistent, real-patrolling jailer
	# pawns (spawnDetentionJailers()), not a throwaway generated here anymore.
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID})

func _run():
	if(state == ""):
		saynn("A guard spots you before you can slip past.")
		saynn("[say="+npcID+"]Hey! You're not supposed to be out of your cell![/say]")

		addButton("Fight", "Fight your way past", "start_fight")

	if(state == "guard_defeated"):
		removeCharacter(npcID)
		saynn("{npc.name} goes down hard and stays down. The way's clear.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "caught"):
		playAnimation(StageScene.Duo, "defeat", {npc=npcID})
		saynn("{npc.He} gets the better of you. A stun baton to the ribs and the fight's over before it started.")

		addButton("Continue", "See what happens next", "go_stocks")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_fight"):
		runScene("FightScene", [npcID, "WarDraftDetention"], "jailerFight")
		return

	if(_action == "go_stocks"):
		endScene()
		runScene("WarDraftStocksPunishmentScene", [npcID])
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "jailerFight"):
		processTime(5*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			GM.main.PS.markDetentionGuardDefeated(npcID)
			setState("guard_defeated")
		else:
			setState("caught")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
