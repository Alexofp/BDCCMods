extends EventBase

# RestingInCellScene.gd fires the same global Trigger.SleepInCell/Trigger.WakeUpInCell
# any real prison cell would, with no location check at all. Modules/
# PlayerSlaveryModule/Util/NpcOwnerSleepTogetherEvent.gd listens for
# Trigger.SleepInCell to let a softly-owned NPC slave crawl into bed with the
# player - completely reasonable in an actual BDCC cell, not reasonable in a
# war-zone bunk in a totally different scenario. Real bug hit and confirmed:
# Modules/MedicalModule/ForcedChastity/ForcedChastityEvents.gd listens for
# Trigger.WakeUpInCell and, once due, runs ForcedChastityScene1/2/3/5/7 -
# which call GM.pc.setLocation("medical_confessionary") etc, teleporting the
# player straight off the WarDraft floor without going through
# WarDraftBase.endPatrol()/escapeDetention()'s own GM.world.clearFloor()/
# state cleanup. Result: PS stays stuck "in" WarDraft (isInSpecificPlayerSlavery
# still true) while physically not on its floor anymore - a soft lock -
# and since none of WarDraft's real exits ran, gear never gets stripped
# either. PriorityEventTrigger.triggerReact() stops at the first handler that
# returns true (Events/EventTriggers/PriorityEventTrigger.gd), so intercepting
# both triggers here with a higher priority than the default (10,
# EventBase.gd's own default - neither NpcOwnerSleepTogetherEvent nor
# ForcedChastityEvents override getPriority()) blocks them from ever running
# while in WarDraft. RestingInCellScene itself discards both trigger's return
# values ("if(GM.ES.triggerReact(Trigger.SleepInCell)): pass" and the
# WakeUpInCell check only branches on which order showLog()/endScene() run),
# so returning true here has no other side effect.

func _init():
	id = "WarDraftBlockCellEventsEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SleepInCell)
	es.addTrigger(self, Trigger.WakeUpInCell)

func getPriority():
	return 100

func react(_triggerID, _args):
	return GM.main.isInSpecificPlayerSlavery("WarDraft")
