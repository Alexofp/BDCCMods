extends SceneBase

var mode:String = "" # "disarm" or "plant"
var npcID:String = ""
var droppedRifle:bool = false

func _init():
	sceneID = "WarDraftBombObjectiveScene"

func _initScene(_args = []):
	mode = _args[0] if _args.size() > 0 else "disarm"

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func getSuccessChance() -> float:
	return clamp(55.0 + GM.pc.getSkillLevel(Skill.Combat) * 4.0, 10.0, 90.0)

func _run():
	if(state == ""):
		playAnimation(StageScene.Solo, "kneel")
		if(mode == "disarm"):
			saynn("A crude Syndicate charge is wired into the wreckage here, timer still counting down. If it goes off with the squad this close, that's not going to stay quiet.")
		else:
			saynn("This is as good a chokepoint as any to leave a present. Rig a charge here without anyone noticing, and it costs the Syndicate a lot more than one soldier.")

		addButton("Try it", "Attempt the "+("disarm" if mode == "disarm" else "plant")+" ("+str(int(round(getSuccessChance())))+"% chance)", "attempt")
		addButton("Leave it", "Walk away", "leave")

	if(state == "success"):
		if(mode == "disarm"):
			saynn("Your hands are steady enough. The timer stops with seconds left on the clock.")
		else:
			saynn("The charge goes in clean, timer set, and you're clear before anyone's the wiser.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "failure"):
		if(mode == "disarm"):
			saynn("Wrong wire. The charge goes off before you can pull back.")
		else:
			saynn("The charge slips, or the timer's faulty, or you just get unlucky - either way, it goes off early, right next to you.")

		saynn("The blast doesn't stay quiet. Something's already moving toward the noise.")

		addButton("Continue", "See what happens next", "spawn_ambush")

	if(state == "ambush_won"):
		playAnimation(StageScene.Solo, "stand")
		removeCharacter(npcID)
		saynn("Whoever came to check on the noise isn't checking on anything anymore.")

		if(droppedRifle):
			saynn("Their "+GM.main.PS.getEnemyWeaponName().to_lower()+"'s still fully loaded. You take it.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "lost_encounter"):
		playAnimation(StageScene.Duo, "defeat", {npc=npcID})
		saynn("Between the blast and the fight, you're not walking away from this one on your feet.")

		addButton("Continue", "See what happens next", "start_defeated_sex")

	if(state == "encounter_survived_sex"):
		removeCharacter(npcID)
		saynn("You manage to shove {npc.him} off and scramble back to your feet, ears ringing.")

		addButton("Continue", "Keep going", "endthescene")

	if(state == "encounter_captured"):
		removeCharacter(npcID)
		playAnimation(StageScene.Sleeping, "sleep")
		saynn("Everything goes dark before you even register losing.")

		addButton("Continue", "See what happens next", "go_captured")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "leave"):
		endScene()
		return

	if(_action == "attempt"):
		if(RNG.chance(getSuccessChance())):
			if(GM.main.PS.defected):
				GM.main.PS.addCorruption(GM.main.PS.CorruptionPerObjective)
			else:
				GM.main.PS.addMorale(GM.main.PS.MoralePerObjective)
			GM.pc.addCredits(GM.main.PS.CreditsPerObjective)
			setState("success")
		else:
			GM.pc.addPain(RNG.randi_range(15, 30))
			setState("failure")
		return

	if(_action == "spawn_ambush"):
		GM.main.PS.warnIfNoWeapon()
		var theGenerator = GM.main.PS.getEnemySoldierGeneratorScript().new()
		var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
		npcID = theChar.getID()
		addCharacter(npcID)
		playAnimation(StageScene.Duo, "holdrifle", {npc=npcID, npcAction=["holdrifle", GM.main.PS.getEnemyWeaponModelPath()]})
		runScene("FightScene", [npcID, "WarDraftPatrol"], "ambushFight")
		return

	if(_action == "start_defeated_sex"):
		getCharacter(npcID).prepareForSexAsDom()
		runScene("GenericSexScene", [npcID, "pc", SexType.DefaultSex, {SexMod.SubMustGoUnconscious:true, SexMod.DisableDynamicJoiners:true}], "defeated_sex")
		return

	if(_action == "go_captured"):
		endScene()
		runScene(GM.main.PS.getCombatLossSceneID())
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "ambushFight"):
		processTime(10*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			droppedRifle = GM.main.PS.dropEnemyWeapon(GM.main.PS.EnemyWeaponDropChance, GM.main.PS.getEnemyWeaponID())
			setState("ambush_won")
		else:
			setState("lost_encounter")

	if(_tag == "defeated_sex"):
		var sexResult:SexEngineResult = _result[0]
		var gotUncon:bool = sexResult.isSubUnconscious("pc")

		if(gotUncon):
			setState("encounter_captured")
		else:
			setState("encounter_survived_sex")

func saveData():
	var data = .saveData()

	data["mode"] = mode
	data["npcID"] = npcID
	data["droppedRifle"] = droppedRifle

	return data

func loadData(data):
	.loadData(data)

	mode = SAVE.loadVar(data, "mode", "disarm")
	npcID = SAVE.loadVar(data, "npcID", "")
	droppedRifle = SAVE.loadVar(data, "droppedRifle", false)
