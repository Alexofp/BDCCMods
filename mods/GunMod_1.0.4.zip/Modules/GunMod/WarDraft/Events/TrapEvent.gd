extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftTrap"
	eventWeight = 2.0

func getMaxPerLevel() -> int:
	return 2

func getMapIcon():
	return RoomStuff.RoomSprite.NONE

func getInteractInfo() -> Dictionary:
	return {
		text = "Something about this spot feels wrong - a tripwire glinting in the mud, maybe, or a shell casing that's a little too fresh.",
		actions = [
			{id = "check", name = "Investigate", desc = "See what's here", args = []},
			{id = "avoid", name = "Steer clear", desc = "Not worth the risk", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	if(_actionID == "avoid"):
		return {text = "You give it a wide berth. Better safe.", ended = true}

	if(RNG.chance(50)):
		return {sceneID = "WarDraftAmbushScene", args = [], ended = true}

	if(RNG.chance(50)):
		var dmg = RNG.randi_range(10, 20)
		GM.pc.addPain(dmg)
		return {text = "It's a tripwire - a frag charge goes off close enough to rattle your teeth. That hurt.", ended = true}

	GM.pc.addArousal(0.2)
	return {text = "Not a bomb - some kind of gas canister, rigged as a prank or a distraction. Whatever's in it makes your whole body go hot before it clears.", ended = true}
