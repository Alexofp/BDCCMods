extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftSupplyLocker"
	eventWeight = 2.0

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.VENDOMAT

func getInteractInfo() -> Dictionary:
	return {
		text = "A supply locker, jammed shut. Looks like it'll take some force to get it open.",
		actions = [
			{id = "force", name = "Force it open", desc = "Try to pry it open", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	if(RNG.chance(65)):
		GM.main.PS.restockAmmo()
		return {text = "The locker gives way. Someone left a full ammo crate inside.", ended = true}
	else:
		GM.pc.addPain(RNG.randi_range(5, 10))
		return {text = "The locker doesn't budge, and you bang your hand hard trying.", ended = true}
