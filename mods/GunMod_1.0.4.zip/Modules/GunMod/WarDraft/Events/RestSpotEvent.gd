extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftRestSpot"
	eventWeight = 2.0

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.BED

func getInteractInfo() -> Dictionary:
	return {
		text = "A half-collapsed dugout, someone's old bedroll still inside. Good enough for a few minutes off your feet - or to get rid of some pent-up lust.",
		actions = [
			{id = "rest", name = "Rest here", desc = "Catch your breath", args = []},
			{
				id = "masturbate",
				name = "Masturbate",
				desc = "Get rid of your lust. Your hands and arms have to be free.",
				args = [],
				disabled = (GM.pc.hasBoundArms() || GM.pc.hasBlockedHands()),
			},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	if(_actionID == "rest"):
		GM.pc.addStamina(GM.pc.getMaxStamina())
		GM.pc.addPain(-20)
		return {text = "You catch your breath and patch yourself up as best you can.", ended = true}

	GM.pc.orgasmFrom("pc")
	return {text = "You get as comfy as you can and masturbate until you cum, which helps clear your mind.", ended = true, anim = [StageScene.Grope, "watchstroke" if GM.pc.hasReachablePenis() else "watchrub", {onlyPC=true, pcCum=true, bodyState={naked=true,hard=true}}]}
