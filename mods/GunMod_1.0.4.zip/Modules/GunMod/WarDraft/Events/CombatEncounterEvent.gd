extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftCombatEncounter"
	eventWeight = 3.0

func getMaxPerLevel() -> int:
	return 3

func getMapIcon():
	return RoomStuff.RoomSprite.PERSON

func getInteractInfo() -> Dictionary:
	return {
		text = "A Syndicate soldier's dug in here, back turned.",
		actions = [
			{id = "engage", name = "Engage", desc = "Fight them", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftPatrolEncounterScene", args = [], ended = true}
