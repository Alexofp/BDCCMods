extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftItemStash"
	eventWeight = 3.0

func getMaxPerLevel() -> int:
	return 2

func getMapIcon():
	return RoomStuff.RoomSprite.IMPORTANT

func getInteractInfo() -> Dictionary:
	return {
		text = "A dead soldier's pack is half-buried in the mud here. Still looks worth going through.",
		actions = [
			{id = "take", name = "Search it", desc = "See what's inside", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	var credits:int = RNG.randi_range(20, 60)
	GM.pc.addCredits(credits)
	return {text = "You find "+str(credits)+" credits stashed in the lining.", ended = true}
