extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftBoss"
	eventWeight = 0.0 # only ever placed via WarDraftBase.generateMap()'s guaranteed slot, not the normal weighted roll

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.BOSS

func getInteractInfo() -> Dictionary:
	return {
		text = "A dug-in Syndicate squad, three strong, holding this position hard.",
		actions = [
			{id = "engage", name = "Engage", desc = "Fight through all of them", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftAmbushScene", args = [true], ended = true}
