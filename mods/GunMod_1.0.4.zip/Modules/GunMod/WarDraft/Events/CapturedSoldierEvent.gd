extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftCapturedSoldier"
	eventWeight = 1.5

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.PERSON

func getInteractInfo() -> Dictionary:
	var flavorText = "You hear it before you see it. One of your own has an AlphaCorp straggler pinned down, and they're not being gentle about it." if GM.main.PS.defected else "You hear it before you see it. A Syndicate soldier's got one of yours pinned down, and they're not being gentle about it."
	return {
		text = flavorText,
		actions = [
			{id = "approach", name = "Move in", desc = "Get a closer look", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftCapturedSoldierScene", args = [], ended = true}
