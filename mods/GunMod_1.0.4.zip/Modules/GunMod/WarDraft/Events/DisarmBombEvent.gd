extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftDisarmBomb"
	eventWeight = 1.5

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.COMPUTER

func getInteractInfo() -> Dictionary:
	return {
		text = "A crude Syndicate charge is wired into the wreckage here, timer still counting down.",
		actions = [
			{id = "approach", name = "Take a closer look", desc = "See if it can be disarmed", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftBombObjectiveScene", args = ["disarm"], ended = true}
