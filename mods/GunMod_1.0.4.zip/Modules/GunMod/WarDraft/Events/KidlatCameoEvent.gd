extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftKidlatCameo"
	eventWeight = 0.6

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.VENDOMAT

func getInteractInfo() -> Dictionary:
	return {
		text = "There's a folding table set up behind a burnt-out APC, absolutely covered in loose ammo and dubious snacks. That's... not standard issue.",
		actions = [
			{id = "approach", name = "Check it out", desc = "See who's running this", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftKidlatCameoScene", args = [], ended = true}
