extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftRescue"
	eventWeight = 1.5

func getMaxPerLevel() -> int:
	return 2

func getMapIcon():
	return RoomStuff.RoomSprite.IMPORTANT

func getInteractInfo() -> Dictionary:
	var flavorText = "You spot movement nearby, alone and struggling to keep going." if GM.main.PS.defected else "You hear muffled struggling nearby - someone's restrained here."
	return {
		text = flavorText,
		actions = [
			{id = "approach", name = "Investigate", desc = "See who it is", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftRescueObjectiveScene", args = [], ended = true}
