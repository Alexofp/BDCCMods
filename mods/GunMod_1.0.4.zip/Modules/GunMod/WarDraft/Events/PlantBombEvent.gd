extends "res://Modules/GunMod/WarDraft/WarDraftEventBase.gd"

func _init():
	id = "WarDraftPlantBomb"
	eventWeight = 1.5

func getMaxPerLevel() -> int:
	return 1

func getMapIcon():
	return RoomStuff.RoomSprite.COMPUTER

func getInteractInfo() -> Dictionary:
	return {
		text = "A good chokepoint, and nobody's watching it. Worth leaving a present.",
		actions = [
			{id = "approach", name = "Take a closer look", desc = "See if a charge can be planted here", args = []},
		],
	}

func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {sceneID = "WarDraftBombObjectiveScene", args = ["plant"], ended = true}
