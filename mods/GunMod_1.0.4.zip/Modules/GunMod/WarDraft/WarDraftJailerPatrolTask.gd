extends GlobalTask

const WarDraftBaseScript = preload("res://Modules/GunMod/WarDraft/WarDraftBase.gd")

# Real base-game patrol AI (same InteractionGoal.Patrol/GoalPatrol.gd machinery
# Cellblock's own guards use), scoped to just this scenario's own jailer pawns
# and its own detention-floor zone - never poaches an unrelated guard pawn,
# since canDoTask() only ever matches charIDs WarDraftBase itself spawned.

func _init():
	id = "WarDraftJailerPatrol"
	goalID = InteractionGoal.Patrol

func canDoTask(_pawn:CharacterPawn) -> bool:
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return false
	if(!GM.main.PS.inDetention):
		return false
	return GM.main.PS.detentionJailerIDs.has(_pawn.charID)

func getMaxAssigned(_maxPawnCount:int) -> int:
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return 0
	return GM.main.PS.detentionJailerIDs.size()

func configureGoal(_pawn:CharacterPawn, _goal):
	_goal.zone = WarDraftBaseScript.DetentionZone
