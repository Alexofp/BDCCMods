extends SceneBase

const SyndicateJailerGeneratorScript = preload("res://Modules/GunMod/WarDraft/SyndicateJailerGenerator.gd")

var capturingGuardID:String = ""
var npcID:String = ""
var device:String = "" # "stocks" or "slutwall"

func _init():
	sceneID = "WarDraftStocksPunishmentScene"

func _initScene(_args = []):
	capturingGuardID = _args[0] if _args.size() > 0 else ""

func resolveCustomCharacterName(_charID):
	if(_charID == "guard"):
		return capturingGuardID
	if(_charID == "npc"):
		return npcID

func getDeviceItemID():
	if(device == "slutwall"):
		return "SlutwallStatic"
	return "StocksStatic"

func getDeviceStageScene():
	if(device == "slutwall"):
		return StageScene.SlutwallSexOral
	return StageScene.StocksSexOral

func getDeviceIdleStageScene():
	if(device == "slutwall"):
		return StageScene.Slutwall
	return StageScene.Stocks

func getDeviceSexType():
	if(device == "slutwall"):
		return SexType.SlutwallSex
	return SexType.StocksSex

func _reactInit():
	device = RNG.pick(["stocks", "slutwall"])
	GM.pc.clearTallymarks()
	GM.pc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem(getDeviceItemID()))
	if(capturingGuardID != ""):
		addCharacter(capturingGuardID)
		playAnimation(StageScene.Duo, "stand", {npc=capturingGuardID})
	else:
		playAnimation(StageScene.Solo, "kneel")

func _run():
	if(state == ""):
		if(device == "slutwall"):
			saynn("They drag you to a slutwall bolted into the corridor and lock you into it before you can do much more than swear at them.")
		else:
			saynn("They drag you to a set of stocks bolted into the corridor and lock you into them before you can do much more than swear at them.")

		if(capturingGuardID != ""):
			saynn("[say="+capturingGuardID+"]Five marks and you're back in your cell. Try not to make it worse for yourself.[/say]")
			removeCharacter(capturingGuardID)

		setState("serving")

	if(state == "serving"):
		playAnimation(getDeviceIdleStageScene(), "idle")
		sayn("Tally marks: "+str(GM.pc.getTallymarkCount())+"/"+str(GM.main.PS.DetentionTalliesNeeded)+" - they'll let you go once you've been marked that many times.")
		addButton("Wait it out", "Let the time pass", "wait")
		if(GM.pc.getInventory().hasRemovableRestraints()):
			addButton("Struggle", "Try to work your way free early", "struggle")

	if(state == "visited"):
		removeCharacter(npcID)
		saynn("Eventually {npc.he} leaves you alone, still locked in.")

		addButton("Continue", "Keep waiting", "back_to_serving")

	if(state == "released"):
		saynn("A guard finally unlocks you and shoves you back toward your cell without a word.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "escaped_early"):
		saynn("The lock finally gives. You're out.")

		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "back_to_serving"):
		setState("serving")
		return

	if(_action == "wait"):
		processTime(30*60)

		if(RNG.chance(35)):
			var theGenerator := SyndicateJailerGeneratorScript.new()
			var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
			npcID = theChar.getID()
			theChar.prepareForSexAsDom()
			addCharacter(npcID)
			playAnimation(getDeviceStageScene(), "tease", {npc=npcID, pc="pc"})
			runScene("GenericSexScene", [npcID, "pc", getDeviceSexType(), {SexMod.DisableDynamicJoiners:true}], "punishment_sex")
			return

		setState("serving")
		return

	if(_action == "struggle"):
		runScene("StrugglingScene", [false], "struggle_stocks")
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "punishment_sex"):
		GM.pc.addTallymarkButt()
		if(GM.pc.getTallymarkCount() >= GM.main.PS.DetentionTalliesNeeded):
			GM.pc.getInventory().removeEquippedItemsList(GM.pc.getInventory().getEquippedItemsWithTag(ItemTag.BDSMRestraint))
			GM.main.PS.resetDetentionAttempt()
			setState("released")
		else:
			setState("visited")

	if(_tag == "struggle_stocks"):
		if(!GM.pc.getInventory().hasRemovableRestraints()):
			GM.main.PS.resetDetentionAttempt()
			setState("escaped_early")
		else:
			setState("serving")

func saveData():
	var data = .saveData()

	data["capturingGuardID"] = capturingGuardID
	data["npcID"] = npcID
	data["device"] = device

	return data

func loadData(data):
	.loadData(data)

	capturingGuardID = SAVE.loadVar(data, "capturingGuardID", "")
	npcID = SAVE.loadVar(data, "npcID", "")
	device = SAVE.loadVar(data, "device", "")
