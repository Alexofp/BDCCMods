extends SceneBase

var npcID:String = ""
var soldiersLeft:int = 3
var isBoss:bool = false

func _init():
	sceneID = "WarDraftAmbushScene"

func _initScene(_args = []):
	isBoss = _args[0] if _args.size() > 0 else false

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _reactInit():
	GM.main.PS.warnIfNoWeapon()
	if(isBoss):
		saynn("This squad's dug in properly - three of them, covering each other. No slipping past this one.")
	else:
		saynn("Movement in the wreckage - not one soldier. Several.")
	spawnNext()

func spawnNext():
	var theGenerator = GM.main.PS.getEnemySoldierGeneratorScript().new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	npcID = theChar.getID()
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "holdrifle", {npc=npcID, npcAction=["holdrifle", GM.main.PS.getEnemyWeaponModelPath()]})
	runScene("FightScene", [npcID, "WarDraftPatrol"], "ambushFight")

func _run():
	if(state == "between"):
		saynn(str(soldiersLeft)+" more coming up fast.")
		addButton("Continue", "Keep fighting", "next_wave")

	if(state == "lost_encounter"):
		playAnimation(StageScene.Duo, "defeat", {npc=npcID})
		saynn("Outnumbered and worn down, you finally go down.")

		addButton("Continue", "See what happens next", "start_defeated_sex")

	if(state == "encounter_survived_sex"):
		removeCharacter(npcID)
		saynn("You claw your way back to your feet, breathing hard. That was close.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "encounter_captured"):
		removeCharacter(npcID)
		playAnimation(StageScene.Sleeping, "sleep")
		saynn("Everything goes dark before you even register losing.")

		addButton("Continue", "See what happens next", "go_captured")

	if(state == "won_all"):
		removeCharacter(npcID)
		if(isBoss):
			saynn("The squad's down to the last one standing, and then not even that. Command's going to want to hear about this position clearing.")
		else:
			saynn("The ambush is over. Whatever was left of the squad isn't getting up.")

		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "next_wave"):
		removeCharacter(npcID)
		spawnNext()
		return

	if(_action == "start_defeated_sex"):
		getCharacter(npcID).prepareForSexAsDom()
		runScene("GenericSexScene", [npcID, "pc", SexType.DefaultSex, {SexMod.SubMustGoUnconscious:true, SexMod.DisableDynamicJoiners:true}], "defeated_sex")
		return

	if(_action == "go_captured"):
		endScene()
		runScene(GM.main.PS.getCombatLossSceneID())
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "ambushFight"):
		processTime(5*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			if(GM.main.PS.dropEnemyWeapon(GM.main.PS.EnemyWeaponDropChance, GM.main.PS.getEnemyWeaponID())):
				GM.main.PS.addMessage("You strip a fully-loaded "+GM.main.PS.getEnemyWeaponName()+" off the body.")
			soldiersLeft -= 1
			if(soldiersLeft <= 0):
				if(isBoss):
					if(GM.main.PS.defected):
						GM.main.PS.addCorruption(GM.main.PS.CorruptionPerObjective * 2)
					else:
						GM.main.PS.addMorale(GM.main.PS.MoralePerObjective * 2)
					GM.pc.addCredits(GM.main.PS.CreditsPerObjective * 2)
				setState("won_all")
			else:
				setState("between")
		else:
			setState("lost_encounter")

	if(_tag == "defeated_sex"):
		var sexResult:SexEngineResult = _result[0]
		var gotUncon:bool = sexResult.isSubUnconscious("pc")

		if(gotUncon):
			setState("encounter_captured")
		else:
			setState("encounter_survived_sex")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID
	data["soldiersLeft"] = soldiersLeft
	data["isBoss"] = isBoss

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
	soldiersLeft = SAVE.loadVar(data, "soldiersLeft", 3)
	isBoss = SAVE.loadVar(data, "isBoss", false)
