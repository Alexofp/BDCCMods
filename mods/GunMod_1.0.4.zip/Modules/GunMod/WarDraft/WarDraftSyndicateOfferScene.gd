extends SceneBase

func _init():
	sceneID = "WarDraftSyndicateOfferScene"

func _run():
	if(state == ""):
		addCharacter("vex")
		playAnimation(StageScene.Duo, "stand", {npc="vex"})
		saynn("Nobody comes for a while. Long enough that you start to wonder if waiting it out was ever a plan.")

		saynn("Then the door opens for someone who isn't a guard.")

		saynn("A tall looking hyena with a spotted coat gracefully approaches you. She doesn't introduce herself. You clock the rank markings before she says a word.")

		saynn("[say=vex]Well. Look at this fine AlphaCorp bitch. Didn't even try the handle on that door. That's either smart..[/say]")

		saynn("[say=vex]..or you're just slow.[/say]")

		saynn("[say=pc]And just who the hell are you?[/say]")

		saynn("[say=vex]Commander Vex. You'll want that name to stick, one way or another.[/say]")

		saynn("[say=pc]...Is that a threat?[/say]")

		saynn("[say=vex]Mm. Could be. Could also be the last thing you hear in here. Depends how sweetly you play for the next few minutes.[/say]")

		saynn("[say=pc]Doesn't sound like much of a choice.[/say]")

		saynn("[say=vex]It isn't, really. You're not like the rest of that transport, I noticed. Don't make me regret saying so.[/say]")

		addButton("Continue", "Hear her out", "pitch")

	if(state == "pitch"):
		saynn("[say=vex]AlphaCorp ships conscripts out here like ammunition. Cheap, disposable, replaced the second the count comes up short. You've noticed, haven't you?[/say]")

		saynn("[say=vex]I don't run things that way. My people are worth something to me, or they don't stay my people long.[/say]")

		saynn("[say=pc]So you're offering me a job?[/say]")

		saynn("[say=vex]I'm offering you a reason to stop being somebody else's expendable number. Why stay loyal to fools who'd trade you for scrap when you could belong to somebody worth the trouble instead? It's your call, sweetie.[/say]")

		saynn("[i](Accepting this offer means siding against AlphaCorp. You can still hear her out and refuse when it comes to it.)[/i]")

		addButton("What's the catch?", "Ask what she actually wants", "catch")
		addButton("Why me?", "Ask why she's bothering", "why_me")
		addButton("Why should I bet on you?", "Ask what makes her worth the risk", "why_her")

	if(state == "why_her"):
		saynn("[say=pc]And why should I bet on you, specifically?[/say]")

		saynn("[say=vex]Because I never lose. Kessler's Ridge, three outposts since, a command post AlphaCorp still hasn't worked out how they lost. Every bit of it, mine.[/say]")

		saynn("[say=vex]You want good odds, you don't pick a side.. you pick a person. And I'm the best one on offer out here, honey.[/say]")

		addButton("Continue", "Consider it", "decision")

	if(state == "catch"):
		saynn("[say=pc]...And the catch?[/say]")

		saynn("[say=vex]Noo, no catch at all. You fight for me instead of them, point that rifle the other direction. That's it.[/say]")

		saynn("[say=vex]Change your mind halfway through, and I won't be nearly this polite about it a second time.[/say]")

		addButton("Continue", "Consider it", "decision")

	if(state == "why_me"):
		saynn("[say=pc]Why bother with me, specifically?[/say]")

		saynn("[say=vex]Because you didn't panic. Didn't beg. You're a killer, a warrior, I could use someone like you.[/say]")

		saynn("[say=vex]You've handled yourself well so far. I'd hate to see that potential go to waste, once you're wearing my colors instead of theirs.[/say]")

		addButton("Continue", "Consider it", "decision")

	if(state == "decision"):
		saynn("[say=vex]So. In, or out, sweetheart. I'm not asking twice.[/say]")

		addButton("Join her", "Switch sides", "accept")
		addButton("Refuse", "Stay loyal to AlphaCorp and take your chances escaping", "decline")

	if(state == "decline"):
		saynn("[say=pc]No. I'll take my chances.[/say]")

		saynn("Vex doesn't look offended. Barely looks interested.")

		saynn("[say=vex]Your funeral. Don't say I didn't ask nicely, bitch.[/say]")

		saynn("She's gone as quietly as she came in, and the door locks again behind her.")

		addButton("Continue", "Look for a way out yourself", "do_escape")

	if(state == "accept"):
		saynn("[say=pc]Deal.[/say]")

		saynn("[say=vex]Smart choice. Let's make something useful out of you.[/say]")

		saynn("She cuts your zip ties herself, and walks you out.")

		saynn("[say=vex]Enjoying the place? Get settled in. Patrols don't start until I say they start.[/say]")

		addButton("Continue", "Follow her out", "gear_up")

	if(state == "gear_up"):
		saynn("Someone shoves a folded set of Syndicate fatigues into your arms without much ceremony.")

		GM.pc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("SyndiArmor"))
		GM.pc.getInventory().addItem(GlobalRegistry.createItem("SyndiHelmet"))

		saynn("It fits well enough. AlphaCorp green traded for Syndicate colors, just like that.")

		addButton("Continue", "Follow her out", "endthescene")

func _react(_action: String, _args):
	if(_action == "do_escape"):
		endScene()
		GM.main.PS.startDetention()
		return

	if(_action == "accept"):
		GM.main.PS.defected = true
		GM.main.PS.inDetention = false
		setState("accept")
		return

	if(_action == "endthescene"):
		GM.pc.setLocation(GM.main.PS.getHubOutpostRoom())
		endScene()
		return

	setState(_action)
