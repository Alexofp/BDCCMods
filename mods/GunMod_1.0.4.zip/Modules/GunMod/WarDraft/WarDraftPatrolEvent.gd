extends EventBase

func _init():
	id = "WarDraftPatrolEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

# EventBase (unlike SceneBase) has no addButtonAt of its own - addButton()
# routes clicks through GM.ui's "EVENTSYSTEM_BUTTON" marker so they reach
# onButton() instead of a scene's _react(); a positioned version needs the
# same wrapping.
func addButtonAt(index:int, text: String, tooltip: String = "", method: String = "", args = []):
	GM.ui.addButtonAt(index, text, tooltip, "EVENTSYSTEM_BUTTON", [self, method, args])

func run(_triggerID, _args):
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return
	var ps = GM.main.PS
	var loc = GM.pc.getLocation()

	if(loc == ps.getHubOutpostRoom() && !ps.inPatrol):
		if(ps.defected):
			saynn("Vex is going over a report near the sandbags, not bothering to look up until she's ready to.")
			addButton("Talk to Vex", "Talk to Commander Vex", "talk_vex")
		else:
			saynn("Drask's parked himself near the sandbags, keeping an eye on the new arrivals.")
			addButton("Talk to Sarge", "Talk to Sergeant Drask", "talk_drask")

	if(loc == ps.getHubTrenchRoom() && !ps.inPatrol):
		if(ps.defected):
			saynn("Today's roster is pinned to the muster board. Your name's on it. Past the sandbags, it's open ground and whatever AlphaCorp's dug into it.")
		else:
			saynn("Sergeant Drask's patrol roster is posted by the trench entrance. Your name's on it, same as it is every day. Past the sandbags, it's just open ground and whatever's waiting in it.")
		addButton("Go on patrol", "Head out into the field on a patrol mission", "start_patrol")

	if(loc == ps.getHubArmoryRoom() && !ps.inPatrol):
		if(ps.defected):
			saynn("Racked rifles, counted ammunition. The quartermaster watches you take what you need and logs it without a word.")
		else:
			saynn("A supply crate sits against the racks, half-full of loose rounds and spare magazines nobody's bothered to lock up.")
		addButton("Restock ammo", "Top off your weapon and patch yourself up", "restock_ammo")

	if(loc == ps.getHubShowerRoom() && !ps.inPatrol):
		addButton("Shower", "Take a shower", "go_shower")
		addButton("Mirror", "Change your haircut", "go_mirror")
		addButton("Toilet", "Find an empty stall", "go_toilet")
		if(GM.main.getFlag("GunMod.LastSoapDropDay", -1) != GM.main.getDays()):
			addButton("...", "You hear something over by the stalls", "go_soap_drop")

	if(ps.getHubBunkerRooms().has(loc) && !ps.inPatrol):
		saynn("Rows of cramped bunks dug into the earth. As good a place as any to get some sleep.")
		addButton("Sleep", "Get some rest", "go_sleep")

	if(ps.defected && loc == "syndicate_prison" && !ps.inPatrol):
		saynn("Rows of holding cells cut into the rock. AlphaCorp prisoners, crammed two and three to a cell.")
		if(GM.main.getFlag("GunMod.LastPrisonVisitDay", -1) != GM.main.getDays()):
			addButton("Visit the prisoners", "See who's being held", "visit_prison")

	if(ps.inPatrol):
		GM.main.playAnimation(StageScene.Solo, ["holdrifle", ps.getOwnFactionWeaponModelPath()])

		if(ps.defected):
			sayn("Patrol level "+str(ps.level)+" - Corruption: "+str(ps.corruption))
		else:
			sayn("Patrol level "+str(ps.level)+" - AlphaCorp morale: "+str(ps.morale))

		var roomID = GM.pc.getLocation()
		if(ps.hasEventInRoom(roomID)):
			var theEvent = ps.getEventInRoom(roomID)
			var interactInfo:Dictionary = theEvent.getInteractInfo()

			if(interactInfo.has("text")):
				saynn(interactInfo["text"])

			if(interactInfo.has("actions")):
				for actionEntry in interactInfo["actions"]:
					var isDisabled:bool = actionEntry["disabled"] if actionEntry.has("disabled") else false
					if(isDisabled):
						addDisabledButton(actionEntry["name"], actionEntry["desc"])
					else:
						var actionArgs:Array = actionEntry["args"] if actionEntry.has("args") else []
						var actionID:String = actionEntry["id"] if actionEntry.has("id") else ""
						addButton(actionEntry["name"], actionEntry["desc"], "doEventInteraction", [theEvent, actionID, actionArgs])
		else:
			saynn("")

		if(roomID == ps.exitRoom):
			saynn("A marked exit out of the area. You could push on from here.")
			addButtonAt(4, "Push deeper", "Keep going - harder, but more to gain", "push_deeper")

		addButtonAt(5, "Extract", "Call for extraction and end the patrol", "extract")

func react(_triggerID, _args):
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return false
	var ps = GM.main.PS

	if(GM.pc.getLocation() == "wardraft_outpost" && !ps.inPatrol):
		var currentTier = ps.getMoraleTier()
		if(currentTier != "neutral" && currentTier != ps.lastMoraleTierShown):
			ps.lastMoraleTierShown = currentTier
			runScene("WarDraftDraskMoraleCommentScene")
			return true
		return false

	if(!ps.inPatrol):
		return false

	var roomID = GM.pc.getLocation()
	if(!ps.hasEventInRoom(roomID)):
		return false

	# These are all "something's actively happening right here" encounters -
	# walking into the room should force them immediately, same as the base
	# game's own restricted-area encounters. Pure flavor/opt-in dead-ends
	# (item stash, locked crate, resting spot, trap, Kidlat) stay button-
	# driven via the interact prompt in run().
	var theEvent = ps.getEventInRoom(roomID)
	var autoTriggerEventIDs = ["WarDraftCombatEncounter", "WarDraftBoss", "WarDraftRescue", "WarDraftCapturedSoldier", "WarDraftDisarmBomb", "WarDraftPlantBomb"]
	if(!autoTriggerEventIDs.has(theEvent.id)):
		return false

	var theResult:Dictionary = theEvent.doInteract("engage", [])
	if(theResult.has("sceneID")):
		runScene(theResult["sceneID"], theResult["args"] if theResult.has("args") else [])
	if(theResult.has("ended") && theResult["ended"]):
		theEvent.endEvent()
	return true

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "talk_drask"):
		runScene("WarDraftDraskTalkScene")
	if(_method == "talk_vex"):
		runScene("WarDraftVexTalkScene")
	if(_method == "visit_prison"):
		GM.main.setFlag("GunMod.LastPrisonVisitDay", GM.main.getDays())
		runScene("WarDraftPrisonScene")
	if(_method == "start_patrol"):
		GM.main.PS.startPatrol()
	if(_method == "extract"):
		GM.main.PS.endPatrol()
		if(!GM.main.PS.defected && GM.main.PS.morale <= GM.main.PS.MoraleThresholdForDischargeBad):
			runScene("WarDraftDishonorableDischargeScene")
		if(GM.main.PS.defected && GM.main.PS.corruption <= GM.main.PS.CorruptionThresholdForFiringSquad):
			runScene("WarDraftFiringSquadScene")
	if(_method == "push_deeper"):
		GM.main.PS.nextLevel()
	if(_method == "restock_ammo"):
		GM.main.PS.restockAmmo()
		GM.pc.addPain(-GM.pc.getPain())
		addMessage("You patch yourself up while you're at it.")
	if(_method == "go_shower"):
		runScene("TakingAShowerScene")
	if(_method == "go_mirror"):
		runScene("ChangeHaircutScene")
	if(_method == "go_toilet"):
		runScene("ToiletScene")
	if(_method == "go_sleep"):
		runScene("RestingInCellScene")
	if(_method == "go_soap_drop"):
		GM.main.setFlag("GunMod.LastSoapDropDay", GM.main.getDays())
		runScene("WarDraftSoapDropScene")

	if(_method == "doEventInteraction"):
		var theEvent = _args[0]
		var theResult:Dictionary = theEvent.doInteract(_args[1], _args[2])

		if(theResult.has("text")):
			runScene("DungeonEventSimpleScene", [theResult])
		elif(theResult.has("sceneID")):
			runScene(theResult["sceneID"], theResult["args"] if theResult.has("args") else [])

		if(theResult.has("ended") && theResult["ended"]):
			theEvent.endEvent()
