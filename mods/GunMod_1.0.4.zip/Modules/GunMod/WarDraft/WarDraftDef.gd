extends PlayerSlaveryDef

func _init():
	id = "WarDraft"

func getVisibleName() -> String:
	return "War Draft"

func getVisibleDesc() -> String:
	return "(Combat focus, dark tone) You get conscripted into one of AlphaCorp's wars against the Syndicate, whether you like it or not."

func canBeChosen() -> bool:
	return true

func createSlavery():
	return load("res://Modules/GunMod/WarDraft/WarDraftBase.gd").new()

func getEndings() -> Dictionary:
	return {
		"mirri_bailout": {
			name = "Better Business",
			desc = "Earn enough AlphaCorp morale that Mirri decides you're worth more as a repeat customer than a dead one, and pulls you out.",
		},
		"dishonorable_discharge": {
			name = "Conduct Unbecoming",
			desc = "Let your AlphaCorp morale drop too far, and Command discharges you the hard way, in front of everyone.",
		},
		"firing_squad_escape": {
			name = "Lost in the Manifest",
			desc = "Let your corruption with the Syndicate drop too far, and Vex has you lined up against a wall. An AlphaCorp raid, and Kidlat's own missing paperwork, hand you a way out anyway.",
		},
		"vex_collateral": {
			name = "Paid in Full",
			desc = "Earn enough standing with the Syndicate to take Drask's position at Vex's side. Mirri crashes the celebration again, and this time Vex is the one who doesn't get up.",
		},
	}
