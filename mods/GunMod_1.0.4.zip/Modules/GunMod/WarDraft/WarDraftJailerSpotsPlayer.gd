extends PawnInteractionBase

# Real spatial catch, not a re-roll of the old RNG.chance() version: fires
# whenever the player and one of WarDraftBase's own live patrolling jailer
# pawns actually end up in the same room (either one walking into the
# other's), same shouldRunOnMeet() hook CaughtOffLimits.gd uses for the
# base game's own off-limits catch. Detect-and-handoff only, no dialogue
# state machine of its own - the actual fight is the existing
# WarDraftDetentionFightScene, unchanged.

func _init():
	id = "WarDraftJailerSpotsPlayer"

func shouldRunOnMeet(_pawn1, _pawn2, _pawn2Moved:bool):
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return [false]
	if(!GM.main.PS.inDetention):
		return [false]
	if(!_pawn1.canBeInterrupted() || !_pawn2.canBeInterrupted()):
		return [false]

	var jailerPawn = null
	var pcPawn = null
	if(_pawn1.isPlayer() && GM.main.PS.detentionJailerIDs.has(_pawn2.charID)):
		jailerPawn = _pawn2
		pcPawn = _pawn1
	elif(_pawn2.isPlayer() && GM.main.PS.detentionJailerIDs.has(_pawn1.charID)):
		jailerPawn = _pawn1
		pcPawn = _pawn2
	else:
		return [false]

	if(GM.main.PS.detentionGuardsDefeated.has(jailerPawn.charID)):
		return [false]

	return [true, {guard=jailerPawn.charID, pc=pcPawn.charID}, {}]

func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("guard", _pawns["guard"])
	doInvolvePawn("pc", _pawns["pc"])
	var jailerID = _pawns["guard"]
	stopMe()
	GM.main.runScene("WarDraftDetentionFightScene", [jailerID])
	GM.main.runCurrentScene()
