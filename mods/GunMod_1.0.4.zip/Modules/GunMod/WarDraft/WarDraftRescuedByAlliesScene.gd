extends SceneBase

func _init():
	sceneID = "WarDraftRescuedByAlliesScene"

func _reactInit():
	GM.main.PS.endPatrol()
	GM.pc.addPain(-GM.pc.getPain())
	GM.pc.setLocation(GM.main.PS.getHubOutpostRoom())

func _run():
	if(state == ""):
		saynn("Everything after that is pieces. Hands under your arms. Boots dragging through mud that isn't yours. Someone cursing in a voice you don't recognize, close enough to your ear that you feel it more than hear it.")

		saynn("By the time your head clears, you're back at the outpost. Whoever pulled you out is already gone, off to whatever they were doing before they found you.")

		saynn("[sayMale]Word of advice. Don't count on that twice.[/sayMale]")

		saynn("Your hands are still shaking too much to answer properly. You just nod.")

		addButton("Continue", "Get your bearings", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
