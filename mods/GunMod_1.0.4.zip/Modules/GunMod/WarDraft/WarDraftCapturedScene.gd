extends SceneBase

const SyndicateJailerGeneratorScript = preload("res://Modules/GunMod/WarDraft/SyndicateJailerGenerator.gd")

var guardID:String = ""

func _init():
	sceneID = "WarDraftCapturedScene"

func _reactInit():
	GM.main.PS.endPatrol()
	GM.pc.addPain(-GM.pc.getPain())

	var theGenerator := SyndicateJailerGeneratorScript.new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	guardID = theChar.getID()

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return guardID

func _run():
	if(state == ""):
		saynn("Voices, before anything else. Your eyes won't open yet, but your ears work fine.")

		saynn("[say="+guardID+"]...zip-tied and dumped in the corner cell. BDCC stock, if the collar's telling the truth.[/say]")

		saynn("A second voice, further off, bored.")

		saynn("[sayMale]Paperwork's already a mess this week. Toss 'em in with the rest, sort it out in the morning.[/sayMale]")

		saynn("[say="+guardID+"]Copy that.[/say]")

		saynn("Footsteps. A door. Then quiet.")

		addButton("Continue", "Try to open your eyes", "wake_up")

	if(state == "wake_up"):
		addCharacter(guardID)
		playAnimation(StageScene.Duo, "stand", {npc=guardID})
		saynn("Your eyes finally focus. Bare concrete, a drain in the floor, a door that only opens from the outside. Syndicate colors on the guard standing over you, none of it AlphaCorp's.")

		saynn("[say="+guardID+"]Oh, look who's up. BDCC stock, cheap end of the pipeline. Toss 'em with the rest of the intake.[/say]")

		saynn("Your rifle's gone. So's the armor. Whatever they stripped off you while you were out, you're not getting it back in here.")

		saynn("Nobody radios Drask. Nobody's coming for you. Out here, you're just new stock changing hands.")

		removeCharacter(guardID)
		saynn("The door shuts. You're alone, and it doesn't feel locked as tight as it should.")

		addButton("Look for a way out", "See if you can find a way out", "do_escape")
		addButton("Wait it out", "Stop trying to escape and see what the Syndicate wants with you", "wait_it_out")

func _react(_action: String, _args):
	if(_action == "wake_up"):
		GM.main.PS.stripPlayerGear()

	if(_action == "do_escape"):
		endScene()
		GM.main.PS.startDetention()
		return

	if(_action == "wait_it_out"):
		endScene()
		runScene("WarDraftSyndicateOfferScene")
		return

	setState(_action)

func saveData():
	var data = .saveData()

	data["guardID"] = guardID

	return data

func loadData(data):
	.loadData(data)

	guardID = SAVE.loadVar(data, "guardID", "")
