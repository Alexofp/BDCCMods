extends SceneBase

func _init():
	sceneID = "WarDraftFiringSquadScene"

func _reactInit():
	addCharacter("vex")
	playAnimation(StageScene.Duo, "stand", {npc="vex"})

func _run():
	if(state == ""):
		saynn("You notice Vex frantically pushing people around, while shouting your name around. Before you realise the situation you're in, she's already spotted you. She just walks up  with a mean mug on her face while you're still catching your breath from the patrol.")

		saynn("[say=vex]We had an arrangement bitch! You point that rifle the right direction, you keep proving useful. I keep you breathing.[/say]")

		saynn("[say=pc]I have no idea what you're talking about. I've been doing my job just fine.[/say]")

		saynn("[say=vex]Letting AlphaCorp walk off with soldiers I paid good people to catch. Having to send out good soldiers to die out there getting your ass to safety. That's not the fucking rep I wanna go by.[/say]")

		addButton("Continue", "Hear her out", "confront")

	if(state == "confront"):
		saynn("[say=pc]Vex, wait. Come on... don't do this![/say]")
		
		saynn("She slightly raises her voice, clearly pissed about you.")

		saynn("[say=vex]I've told you enough times. I wouldn't be nearly this polite about it a second time. I don't make a habit of repeating myself.[/say]")

		saynn("[say=vex]Cuff this bitch.[/say]")

		GM.pc.getInventory().equipItem(GlobalRegistry.createItem("policecuffs"))
		saynn("The cuffs close tight and your heartbeat's suddenly the loudest thing you can hear.")

		addButton("Continue", "See what happens next", "stripped")

	if(state == "stripped"):
		saynn("[say=vex]And give me your fucking gear. All of it.[/say]")

		GM.main.PS.stripPlayerGear()
		saynn("With your wrists locked behind you, there's nothing to do but stand there while someone else does the work. The rifle goes first, then the armor, then the fatigues themselves, until there's nothing left covering you at all. Your hands are shaking and you can't make them stop.")

		saynn("Nobody hands you anything to replace it with. You just stand there, {pc.thick} and {pc.masc}, bare in front of everyone with your wrists bound behind you.")

		if(GM.pc.hasPenis()):
			saynn("Your {pc.cock} hangs exposed along with the rest of you.")
		else:
			saynn("Your bare pussy is on display along with everything else.")

		saynn("[say=pc]Please. Vex, please![/say]")
		
		saynn("The spotted hyena turns to address the whole crowd.")

		saynn("[say=vex]Attention all troops! This is an example for all of you assholes who think they can fuck with me.[/say]")

		addButton("Continue", "See what happens next", "march")

	if(state == "march"):
		saynn("She has you marched out through the middle of the outpost, past the bunks, past the armory, past whoever's around to see it. Naked and cuffed the whole way. Every conversation stops as you go by.")

		saynn("Your eyes catch on face after face, looking for anyone who might do something. It looks like nobody's attempting to be a hero today.")

		saynn("[say=pc]Somebody. Please, somebody![/say]")

		saynn("No one answers.")

		addButton("Continue", "Keep walking", "sentence")

	if(state == "sentence"):
		saynn("They line you up against the back wall, the one with the bullet pocked concrete that was clearly built for exactly this. Three soldiers take position opposite you, rifles already up.")

		saynn("[say=vex]On your mark.[/say]")

		saynn("She says it to the soldier in charge, not even looking back at you.")

		saynn("Your mouth's too dry to get a word out. Your legs don't feel like they belong to you anymore.")

		saynn("Vex laughs, short and humorless, and turns to walk off before the order's even given, already done with you.")
		removeCharacter("vex")

		addButton("Continue", "Watch the squad", "squad_ready")

	if(state == "squad_ready"):
		saynn("The soldier in charge raises a hand. You watch three rifles settle, three fingers find three triggers.")

		saynn("[say=pc]No- wait, wait-[/say]")


		addButton("Continue", "This is it", "raid_hits")

	if(state == "raid_hits"):
		saynn("The first explosion hits the fence line before the order ever comes. Then the second, closer, throwing dirt and shrapnel over the yard. Your ears are ringing too hard to hear yourself think.")

		saynn("[sayMale]Contact! AlphaCorp's through the outer line, get eyes on the -[/sayMale]")

		saynn("Whatever the voice was about to say gets lost under the alarm. The firing squad breaks formation on their own, rifles swinging toward the noise instead of you.")

		saynn("[say=pc]Kyah![/say]")

		addButton("Continue", "Move", "kidlat_chaos")

	if(state == "kidlat_chaos"):
		addCharacter("kidlat")
		getCharacter("kidlat").getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("GunModConscriptArmor"))
		playAnimation(StageScene.Duo, "stand", {npc="kidlat"})
		saynn("An AlphaCorp transport comes tearing through the gap in the fence, and you get about ten feet before someone spills out of the back of it and plows straight into you, both of you going down in the mud. It's Kidlat, in AlphaCorp colors, riding in with the actual assault like she does this for a living.")

		saynn("[say=kidlat]Oh good, you're not dead yet! Perfect, help me with this, the truck's not waiting for inventory![/say]")

		saynn("[say=pc]My hands are cuffed! I can't- they were about to shoot me![/say]")

		saynn("[say=kidlat]Details![/say]")

		addButton("Continue", "Let her drag you along", "shipped_out")

	if(state == "shipped_out"):
		saynn("Nobody checks a manifest during a raid, least of all their own. Kidlat hauls her cart, and you, back up into the same transport she rode in on before anyone doing an actual headcount gets anywhere near either of you.")

		saynn("[say=kidlat]See? Nobody asks questions when the paperwork's already a lost cause. I'd know.[/say]")

		saynn("Whoever was supposed to have you shot is busy with a burning fence line. By the time anyone thinks to ask where the condemned prisoner went, the truck's long gone.")

		var cuffs = GM.pc.getInventory().getEquippedItem(InventorySlot.Wrists)
		if(cuffs != null && cuffs.id == "policecuffs"):
			GM.pc.getInventory().removeEquippedItem(cuffs)

		getCharacter("kidlat").resetEquipment()
		removeCharacter("kidlat")

		addButton("Continue", "See where you end up", "ending")

	if(state == "ending"):
		saynn("The transport doesn't stop until it's well clear of the fighting, and by then nobody on it particularly cares what happens to you next. Your hands won't stop shaking for most of the ride.")

		saynn("It takes a while and a few favors you'd rather not think about, but you make it. Back to BDCC. You're still property, and for once that's the good outcome.")

		addButton("Leave", "Go home", "go_home")

func _react(_action: String, _args):
	if(_action == "go_home"):
		GM.main.PSH.unlockEndingAddMessage("WarDraft", "firing_squad_escape")
		GM.pc.setLocation(GM.pc.getCellLocation())
		GM.main.stopPlayerSlavery()
		endScene()
		return

	setState(_action)
