extends Character

func _init():
	id = "vex"
	npcLevel = 20
	npcBasePain = 280
	npcBaseLust = 250
	npcCharacterType = CharacterType.Generic

	pickedSkin = "SpottedSkin"
	pickedSkinRColor = Color("ffc19a6b")
	pickedSkinGColor = Color("ffe8d9b5")
	pickedSkinBColor = Color("ff2b1f16")
	npcSkinData = {
	"hair": {"r": Color("ff7a2331"),"g": Color("ffffffff"),"b": Color("ff52151e"),},
	"ears": {"b": Color("ff1a120c"),},
	}

func _getName():
	return "Commander Vex"

func getChatColor():
	return "#FF3060"

func getGender():
	return Gender.Female

func getSmallDescription() -> String:
	return "A wiry hyena commander with a jaw that could take your arm off and a laugh that means someone's day is about to get a lot worse."

func getSpecies():
	return [Species.Canine]

func _getAttacks():
	return ["GunModEnergyRifleFocusedShotPCAttack", "GunModEnergyRifleSuppressingFirePCAttack", "simplekickattack", "trygetupattack"]

func getThickness() -> int:
	return 55

func getFemininity() -> int:
	return 65

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	var penis = GlobalRegistry.createBodypart("caninepenis")
	penis.lengthCM = 15
	penis.ballsScale = 1
	penis.pickedRColor = pickedSkinRColor
	penis.pickedGColor = pickedSkinGColor
	giveBodypartUnlessSame(penis)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("digilegs"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthroarms"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("caninetail"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("caninehead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("canineears"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("ferrihair"))
	var breasts = GlobalRegistry.createBodypart("humanbreasts")
	breasts.size = 5
	giveBodypartUnlessSame(breasts)

func getDefaultEquipment():
	return ["SyndiArmor"]
