extends Character

func _init():
	id = "drask"
	npcLevel = 15
	npcBasePain = 300
	npcBaseLust = 200
	npcCharacterType = CharacterType.Generic

	pickedSkin = "LynxSkin"
	pickedSkinRColor = Color("ff9ea3b5")
	pickedSkinGColor = Color("ffcdcad5")
	pickedSkinBColor = Color("ff494c54")
	npcSkinData = {
	"hair": {"r": Color("ff555555"),"g": Color("ff3c3c3c"),"b": Color("ff3d3d3d"),},
	"ears": {"b": Color("ffdcdcdc"),},
	}

func _getName():
	return "Sergeant Drask"

func getChatColor():
	return "#40FF40"

func getGender():
	return Gender.Male

func getSmallDescription() -> String:
	return "A hulking snow leopard sergeant with a jagged scar over one eye. Loud, foul-mouthed, and clearly enjoying himself."

func getSpecies():
	return [Species.Feline]

func _getAttacks():
	return ["GunModEnergyRifleFocusedShotPCAttack", "GunModEnergyRifleSuppressingFirePCAttack", "simplekickattack", "trygetupattack"]

func getThickness() -> int:
	return 90

func getFemininity() -> int:
	return 0

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("digilegs"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("buffarms"))
	var tail = GlobalRegistry.createBodypart("felinetail")
	tail.tailScale = 1.2
	giveBodypartUnlessSame(tail)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("felinehead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("felineears2"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("mohawkhair"))
	var penis = GlobalRegistry.createBodypart("felinepenis")
	penis.lengthCM = 20
	penis.ballsScale = 1
	penis.pickedRColor = pickedSkinRColor
	penis.pickedGColor = pickedSkinGColor
	giveBodypartUnlessSame(penis)

func getDefaultEquipment():
	# No helmet while at the base/trench - keep faces visible during dialogue.
	# Revisit once actual patrol/combat scenes exist.
	return ["GunModConscriptArmor"]
