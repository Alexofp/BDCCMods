extends SceneBase

func _init():
	sceneID = "WarDraftDetentionEscapeScene"

func _run():
	if(state == ""):
		playAnimation(StageScene.Solo, "stand")
		saynn("The service door's propped open, cold night air pouring in. Nobody's watching it. You don't wait around to find out why.")

		saynn("It's a long, quiet run back toward AlphaCorp lines, expecting a shout or a shot the whole way. Neither comes.")

		addButton("Continue", "Keep going", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		GM.main.PS.escapeDetention()
		return

	setState(_action)
