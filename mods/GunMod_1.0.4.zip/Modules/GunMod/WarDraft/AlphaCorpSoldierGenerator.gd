extends CharacterGeneratorBase
class_name AlphaCorpSoldierGenerator

# A disposable, ordinary fellow conscript hanging around the barracks -
# distinct from CapturedAlphaCorpSoldierGenerator, which is specifically
# framed as a Syndicate prisoner and would read wrong here.

func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = CharacterType.Generic

func pickName(character:DynamicCharacter, _args = {}):
	character.npcName = "Fellow Conscript"
	character.npcChatColorOverride = "#40FF40"

func pickSmallDescription(character:DynamicCharacter, _args = {}):
	return "Another conscript stuck out here same as you. "+str(.pickSmallDescription(character, _args))

func getAttacks():
	return ["simplepunchattack", "trygetupattack"]

func getPossibleAttacks():
	return []

func pickEquipment(character:DynamicCharacter, _args = {}):
	character.npcDefaultEquipment = ["GunModConscriptArmor"]
