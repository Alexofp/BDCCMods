extends SceneBase

var officerID:String = ""

func _init():
	sceneID = "WarDraftDishonorableDischargeScene"

func _reactInit():
	var theGenerator := GuardGenerator.new()
	var theOfficer:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true, NpcGen.Name: "AlphaCorp Officer"})
	theOfficer.npcDefaultEquipment = ["OfficialClothes"]
	theOfficer.resetEquipment()
	officerID = theOfficer.getID()
	theOfficer.npcChatColorOverride = "#FF8000"
	addCharacter(officerID)

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return officerID

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "stand", {npc=officerID})
		saynn("You're barely back through the gate when you spot {npc.him}. A stranger in a pressed AlphaCorp suit, working down the line of returning conscripts one face at a time, datapad held up next to each one like {npc.he}'s checking it against something. Two escorts trail behind {npc.him}, close enough that nobody in line tries walking past without getting a second look.")

		saynn("{npc.He} stops at the conscript two ahead of you, glances at the screen, glances at the mud on their boots, and moves on without a word.")

		saynn("Then {npc.he} gets to you. {npc.He} stops there.")

		addButton("Continue", "See what he wants", "found")

	if(state == "found"):
		saynn("{npc.He} holds the datapad up next to your face and studies it a second too long. Whatever's on the screen, it matches.")

		saynn("[say="+officerID+"]There you are.[/say]")

		saynn("[say=pc]Do I know you?[/say]")

		saynn("[say="+officerID+"]No. But your file knows me.[/say]")

		saynn("{npc.He} doesn't even look up when {npc.he} snaps two fingers. One of {npc.his} escorts has your wrists behind your back before you finish turning around, cold metal closing tight a second later.")

		GM.pc.getInventory().equipItem(GlobalRegistry.createItem("policecuffs"))

		saynn("[say=pc]What is this?[/say]")

		saynn("[say="+officerID+"]Sit tight. We'll get to it.[/say]")

		addButton("Continue", "Let him get to it", "confront")

	if(state == "confront"):
		saynn("[say="+officerID+"]Conduct review. Your name's come up more than once. Abused a rescued POW. Assaulted a captive already out of the fight. Command doesn't need details, just a pattern.[/say]")

		saynn("[say=pc]Where's Sergeant Drask?[/say]")

		addButton("Continue", "See what {npc.he} says", "wheres_drask")

	if(state == "wheres_drask"):
		saynn("[say="+officerID+"]Reassigned. His name was on your file too, vouching for you more than once. Command decided a sergeant with that kind of judgment shouldn't be running a squad right now.[/say]")

		saynn("{npc.He} says it without looking up from the datapad, like reading you a shipping manifest.")

		saynn("[say="+officerID+"]That's not your problem to fix. Yours is already decided.[/say]")

		saynn("[say=pc]So he's paying for what I did?[/say]")

		saynn("[say="+officerID+"]He's paying for who he vouched for. There's a difference. Not one you were worried about at the time.[/say]")

		addButton("Continue", "See what happens next", "stripped")

	if(state == "stripped"):
		saynn("[say="+officerID+"]Gear. Now.[/say]")

		GM.main.PS.stripPlayerGear()
		saynn("With your hands cuffed behind you, there's not much you can do but stand there while an escort does the work for you. The rifle goes first, then the helmet, then the fatigues themselves, unbuckled and peeled off piece by piece until there's nothing left covering you at all.")

		saynn("Nobody bothered issuing you anything to wear underneath. Command confiscated that along with everything else the day you got here. So you just stand there, {pc.thick} and {pc.masc}, bare in the open air with your wrists still bound behind you.")

		if(GM.pc.hasPenis()):
			saynn("Your {pc.cock} hangs exposed with the rest of you, nothing left to hide it behind.")
		else:
			saynn("Your bare pussy is on display along with everything else, nothing left to hide it behind.")

		saynn("{npc.He} doesn't so much as glance down. To {npc.him} you're a line item, not a body.")

		saynn("[say=pc]So that's it? No hearing, nothing?[/say]")

		saynn("[say="+officerID+"]This is the hearing. You lost it a while back.[/say]")

		addButton("Continue", "See what happens next", "public_march")

	if(state == "public_march"):
		saynn("{npc.He} has you marched out through the middle of the outpost instead of the back way, past the bunks, past the shower, past whatever's left of the current intake, naked and cuffed the whole way. Every conversation stops as you pass, and this time it isn't the collar they're staring at.")

		saynn("Someone you don't recognize mutters something under their breath. You can't make out the words.")

		saynn("[say="+officerID+"]Conduct unbecoming, formal discharge under Article 9. Let that be a lesson to the rest of you.[/say]")

		saynn("{npc.He}'s talking past you now, to everyone still watching.")

		saynn("Nobody says anything on your behalf.")

		addButton("Continue", "See what happens next", "discharge_final")

	if(state == "discharge_final"):
		saynn("[say="+officerID+"]Dishonorable discharge, effective immediately. AlphaCorp's done with you.[/say]")

		saynn("[say=pc]And BDCC?[/say]")

		saynn("[say="+officerID+"]Still owns you. You're property either way, you just stopped being useful property.[/say]")

		var cuffs = GM.pc.getInventory().getEquippedItem(InventorySlot.Wrists)
		if(cuffs != null && cuffs.id == "policecuffs"):
			GM.pc.getInventory().removeEquippedItem(cuffs)
		saynn("An escort unlocks your wrists once the transfer paperwork's signed, tossing the cuffs into a bin like they're already someone else's problem. Whatever happens to you now, it isn't his.")

		saynn("{npc.He} finally looks up from the datapad long enough to see your face, and whatever {npc.he} finds there doesn't change {npc.his} expression at all.")

		saynn("[say="+officerID+"]Get {pc.him} out of my outpost.[/say]")

		addButton("Leave", "Go home", "go_home")

func _react(_action: String, _args):
	if(_action == "go_home"):
		GM.main.PSH.unlockEndingAddMessage("WarDraft", "dishonorable_discharge")
		GM.pc.setLocation(GM.pc.getCellLocation())
		GM.main.stopPlayerSlavery()
		endScene()
		return

	setState(_action)

func saveData():
	var data = .saveData()

	data["officerID"] = officerID

	return data

func loadData(data):
	.loadData(data)

	officerID = SAVE.loadVar(data, "officerID", "")
