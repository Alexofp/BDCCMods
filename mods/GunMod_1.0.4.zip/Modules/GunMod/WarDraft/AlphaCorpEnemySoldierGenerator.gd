extends CharacterGeneratorBase
class_name AlphaCorpEnemySoldierGenerator

# A hostile AlphaCorp trooper, used once the player has defected to the
# Syndicate and patrols flip to fighting AlphaCorp instead. Mirrors
# SyndicateSoldierGenerator's shape exactly, re-flavored - distinct from
# AlphaCorpSoldierGenerator, which is a friendly disposable barracks
# fellow-conscript and would read wrong as an enemy here.

func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = CharacterType.Guard

func pickName(character:DynamicCharacter, _args = {}):
	character.npcName = RNG.pick(["AlphaCorp Trooper", "AlphaCorp Rifleman", "AlphaCorp Conscript"])
	character.npcChatColorOverride = "#40FF40"

func pickSmallDescription(character:DynamicCharacter, _args = {}):
	return "One of AlphaCorp's soldiers. "+str(.pickSmallDescription(character, _args))

func getAttacks():
	return ["GunModServiceRifleAimedShotPCAttack", "trygetupattack"]

func getPossibleAttacks():
	return ["GunModServiceRifleBurstFirePCAttack"]

func pickEquipment(character:DynamicCharacter, _args = {}):
	character.npcDefaultEquipment = ["GunModConscriptArmor", "GunModConscriptHelmet"]

func pickLevel(character:DynamicCharacter, _args = {}):
	.pickLevel(character, _args)
	if(GM.main.PS != null && GM.main.PS.id == "WarDraft"):
		character.npcLevel += Util.maxi(0, GM.main.PS.level - 1)
		character.getSkillsHolder().setLevel(character.npcLevel)
