extends SceneBase

const CapturedAlphaCorpSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/CapturedAlphaCorpSoldierGenerator.gd")

var npcID:String = ""
var device:String = "" # "stocks" or "slutwall" - AlphaCorp side only, unused once defected

func _init():
	sceneID = "WarDraftRescueObjectiveScene"

func _reactInit():
	var theGenerator := CapturedAlphaCorpSoldierGeneratorScript.new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	npcID = theChar.getID()
	addCharacter(npcID)

	if(GM.main.PS.defected):
		playAnimation(StageScene.Duo, "stand", {npc=npcID})
	else:
		theChar.lustStateFullyUndress()
		device = RNG.pick(["stocks", "slutwall"])
		playAnimation(getDeviceStageScene(), "tease", {npc="pc", pc=npcID})

func getDeviceStageScene():
	if(device == "slutwall"):
		return StageScene.SlutwallSexOral
	return StageScene.StocksSexOral

func getDeviceSexType():
	if(device == "slutwall"):
		return SexType.SlutwallSex
	return SexType.StocksSex

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _run():
	if(state == ""):
		if(GM.main.PS.defected):
			saynn("You catch an AlphaCorp soldier alone, favoring a bad leg, weapon lost somewhere back the way they came. They're not getting far.")

			saynn("{npc.name} eyes you, too winded to run and too outmatched to fight.")

			addButton("Take them alive", "Bring them in for processing", "do_capture")
			addButton("Kill them", "End it quick", "do_kill")
			addButton("Have your way with them", "Nobody's watching out here", "do_abuse")
			addButton("Let them go", "Walk away", "do_leave")
		else:
			if(device == "slutwall"):
				saynn("You find them jammed into a battered slutwall panel dragged out here for exactly this. AlphaCorp fatigues in a heap on the ground - one of yours, left for whoever finds them first.")
			else:
				saynn("You find them locked into a set of field stocks, stripped and struggling weakly against the restraints. AlphaCorp fatigues in a heap on the ground - one of yours, left for whoever finds them first.")

			saynn("{npc.name} looks up at you, too worn out to look relieved yet.")

			addButton("Free them", "Get them out of the restraints", "do_free")
			addButton("Have your way with them", "Nobody's watching out here", "do_abuse")
			addButton("Leave", "Walk away", "do_leave")

	if(state == "freed"):
		saynn("You work the restraints loose. It takes longer than it should - your hands aren't all that steady either.")

		saynn("{npc.name} doesn't say much, just nods once they're free, and stumbles off toward friendly lines.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "captured"):
		removeCharacter(npcID)
		saynn("You zip-tie them and mark the spot for pickup. One more body for the prison count.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "killed"):
		removeCharacter(npcID)
		saynn("It's over fast. No struggle worth mentioning.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "after_abuse"):
		if(GM.main.PS.defected):
			saynn("You leave them where you found them. Whether they make it back to their own lines afterward isn't your problem.")
		else:
			saynn("You leave them exactly how you found them. Somewhere behind you, {npc.he} is still locked in.")

		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "do_leave"):
		if(GM.main.PS.defected):
			GM.main.PS.addCorruption(GM.main.PS.CorruptionPenaltyForLeniency)
		endScene()
		return

	if(_action == "do_free"):
		GM.main.PS.addMorale(GM.main.PS.MoralePerObjective)
		GM.pc.addCredits(GM.main.PS.CreditsPerObjective)
		setState("freed")
		return

	if(_action == "do_capture"):
		GM.main.PS.addCorruption(GM.main.PS.CorruptionPerObjective)
		GM.pc.addCredits(GM.main.PS.CreditsPerObjective)
		setState("captured")
		return

	if(_action == "do_kill"):
		setState("killed")
		return

	if(_action == "do_abuse"):
		if(GM.main.PS.defected):
			runScene("GenericSexScene", ["pc", npcID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "abuse_sex")
		else:
			runScene("GenericSexScene", ["pc", npcID, getDeviceSexType(), {SexMod.DisableDynamicJoiners:true}], "abuse_sex")
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "abuse_sex"):
		if(GM.main.PS.defected):
			GM.main.PS.addCorruption(GM.main.PS.CorruptionPerAbuse)
			GM.pc.getFetishHolder().addFetish(Fetish.Sadism, RNG.randf_range(0.05, 0.15))
		else:
			GM.main.PS.addMorale(GM.main.PS.MoralePenaltyForAbuse)
		setState("after_abuse")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID
	data["device"] = device

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
	device = SAVE.loadVar(data, "device", "")
