extends SceneBase

const CapturedAlphaCorpSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/CapturedAlphaCorpSoldierGenerator.gd")

var npcID:String = ""

func _init():
	sceneID = "WarDraftPrisonScene"

func _reactInit():
	var theGenerator := CapturedAlphaCorpSoldierGeneratorScript.new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	npcID = theChar.getID()
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID})

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _run():
	if(state == ""):
		saynn("The cells are cramped, packed tighter than they need to be. Whoever runs this block isn't losing sleep over it.")

		saynn("One prisoner's alone in the nearest cell, still in what's left of AlphaCorp fatigues, watching you through the bars without much hope left in it.")

		addButton("Abuse them", "Nobody here is going to stop you", "do_abuse")
		addButton("Leave", "Walk away", "do_leave")

	if(state == "after_abuse"):
		saynn("You leave them exactly how you found them. Nobody's coming to check on that.")

		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene" || _action == "do_leave"):
		endScene()
		return

	if(_action == "do_abuse"):
		runScene("GenericSexScene", ["pc", npcID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "abuse_sex")
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "abuse_sex"):
		GM.main.PS.addCorruption(GM.main.PS.CorruptionPerAbuse)
		GM.pc.getFetishHolder().addFetish(Fetish.Sadism, RNG.randf_range(0.05, 0.15))
		setState("after_abuse")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
