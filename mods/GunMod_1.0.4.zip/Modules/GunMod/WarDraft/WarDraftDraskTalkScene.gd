extends SceneBase

func _init():
	sceneID = "WarDraftDraskTalkScene"

func _run():
	if(state == ""):
		addCharacter("drask")
		playAnimation(StageScene.Solo, "stand", {pc="drask"})
		saynn("Drask's got one boot up on a sandbag, watching the new arrivals mill around like he's daring one of them to do something stupid.")

		addButton("Talk", "Ask Drask about the outpost", "talk")
		addButton("Appearance", "Look at Drask", "appearance")
		addButton("Sex?", "Proposition Sergeant Drask", "sex_offer")
		if(GM.main.PS.morale >= GM.main.PS.MoraleThresholdForDischarge):
			addButton("The final push?", "Ask about ending your tour", "final_push_offer")
		addButton("Leave", "Get moving", "endthescene")

	if(state == "appearance"):
		saynn("Drask is a big son of a bitch, even for a snow leopard - thick through the shoulders and arms in a way that says he's spent as much time hauling crates as barking orders. His fur runs pale grey-blue over his back and flanks, fading almost white across his chest and muzzle, with darker rosettes breaking it up here and there. A jagged scar cuts across one eye, old enough that the fur's grown back wrong around it. His hair's cropped into a rough mohawk, dark near-black, more hacked short than cut. A thick tail swishes behind him, digitigrade legs planted wide, built like a brawler who ended up in charge instead of a desk soldier.")

		saynn("He's in standard-issue conscript fatigues, no helmet. Command gave up trying to make him wear one on base a long time ago.")

		saynn("Whatever's under those fatigues, he's never bothered hiding that he's hung to match the rest of him, a good twenty centimeters, thick with it.")

		addButton("Back", "Ask something else", "")

	if(state == "talk"):
		saynn("[say=drask]What.[/say]")

		addButton("What do I do?", "Ask about the outpost's layout and what's expected", "layout")
		addButton("Get out?", "Ask how you're actually supposed to leave", "record_topic")
		addButton("Caught?", "Ask what happens if you're captured on patrol", "captured_topic")
		addButton("War?", "Ask about the war", "war_topic")
		addButton("Sarge?", "Ask how he made sergeant", "sarge_topic")
		addButton("Back", "Enough talking", "")

	if(state == "layout"):
		saynn("[say=pc]So what am I supposed to be doing around here?[/say]")

		saynn("[say=drask]Trench is where patrols muster. You want to earn your keep, that's where you go.[/say]")
		
		saynn("[say=pc]Will I go in alone?[/say]")
		
		saynn("[say=drask]That's right. If I send you maggots together, you'll drop faster than a Syndicate mutt drops their pants at the slightest sight of ass. It's too risky, soldier.[/say]")

		saynn("[say=pc]Wha-whu-w-wh... Do I at least get to go equipped?[/say]")

		saynn("[say=drask]Sure as hell, the Armory tops off your ammo if you're running dry, you're lucky Command has the decency to supply us with enough ammo.[/say]")

		saynn("[say=pc]And we will be sleeping where?[/say]")

		saynn("[say=drask]Over there at the bunks! If you got the privilege to sleep. Right next to it are the showers, we enforce strict hygiene over here, not like those Syndicate dogs. A clean soldier is a healthy soldier.[/say]")

		saynn("You stare at the Sarge with a face like the world just ended. You feel pretty bummed about your current situation.")

		saynn("[say=drask]Quit starrin' at me with them big ol' eyes! Move your ass out on patrol and push as deep as you can stomach and pull! The deeper you push, the more chances we have to get out of this shithole.[/say]")

		addButton("Continue", "Ask something else", "talk")

	if(state == "record_topic"):
		saynn("[say=pc]Can our tour end here before we die?[/say]")

		saynn("[say=drask]Depends on you. Command tracks every soldier's record out there, objectives cleared, captives brought back breathing instead of broken. If we rile up our boys and gals we migh be able to make a  breaktrough.[/say]")

		saynn("[say=pc]And if I don't?[/say]")

		saynn("[say=drask]Then you keep patrolling til you drop dead, or this war ends. Worse, if you start racking up the other kind of record, roughing up prisoners, taking it out on people who already lost, Command notices that too. Enough of that and they'll pull you off the line and discharge you in disgrace instead. You'd be glad we don't just execute people like those Syndicate dogs.[/say]")

		saynn("[say=drask]So watch how you treat people out there. It's not just about staying alive. It's about helping eachother survive.[/say]")

		addButton("Continue", "Ask something else", "talk")

	if(state == "captured_topic"):
		saynn("[say=pc]And if the Syndicate gets their hands on me?[/say]")

		saynn("Drask's grin drops.")

		saynn("[say=drask]You try your best to not let that happen. We've sent search parties after lost troops before. All it ever gets us is more people dragged into whatever already got the first batch. Command doesn't bother with it anymore, so unless you want to become a fine piece of fuckable meat, keep your gun close, soldier.[/say]")

		saynn("[say=pc]...Noted.[/say]")

		addButton("Continue", "Ask something else", "talk")

	if(state == "war_topic"):
		saynn("[say=pc]What's this whole war even about?[/say]")

		saynn("[say=drask]Above my pay grade, and yours. Syndicate wants worlds, AlphaCorp's got contracts to hold onto them, and idiots like us are what gets spent doing it.[/say]")

		saynn("[say=drask]You want the honest version? Doesn't much matter who's right. Losing means the same thing either way. They don't take prisoners. They take inventory.[/say]")

		addButton("Continue", "Ask something else", "talk")

	if(state == "sarge_topic"):
		saynn("[say=pc]How'd you end up in charge, anyway?[/say]")

		saynn("Drask goes quiet for a second, like he's deciding whether you're worth the story.")

		saynn("[say=drask]Wasn't in charge. Not at first. Had a captain, a whole chain of command above me.[/say]")

		saynn("[say=drask]Syndicate hit our position at Kessler's Ridge. Wiped the whole line in about twenty minutes. I was the only one left breathing by the time it was over.[/say]")

		saynn("[say=drask]Command didn't have anyone left to hand the unit to. So they handed it to me.[/say]")

		saynn("He touches the scar over his eye without seeming to notice he's doing it.")

		saynn("[say=drask]Got this the same day. Fair trade, I figure.[/say]")

		addButton("Continue", "Ask something else", "talk")

	if(state == "sex_offer"):
		saynn("[say=pc]You ever get lonely out here, Sarge?[/say]")

		saynn("Drask looks at you like you just asked him something stupid.")

		saynn("[say=drask]No.[/say]")

		saynn("[say=drask]I don't fuck the conscripts. Bad enough keeping you all alive, I'm not keeping track of who's sleeping with who on top of it.[/say]")

		saynn("[say=drask]Go find something useful to do.[/say]")

		addButton("Continue", "Back off", "talk")

	if(state == "final_push_offer"):
		saynn("[say=pc]Command's really doing the final push? For real?[/say]")

		saynn("[say=drask]For real. You've more than earned a shot at it. Once we go, there's no half-measures - we're taking that position or we're not coming back.[/say]")

		saynn("[say=drask]Your call when we move. Say the word and I'll get everyone moving.[/say]")

		addButton("Move out", "Start the final push", "start_final_push")
		addButton("Not yet", "Keep patrolling for now", "")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_final_push"):
		endScene()
		runScene("WarDraftFinalPushScene")
		return

	setState(_action)
