extends CharacterGeneratorBase
class_name CapturedAlphaCorpSoldierGenerator

# Shared by WarDraftRescueObjectiveScene and the CapturedSoldierEvent dead-end -
# a disposable, unarmed AlphaCorp captive. Starts clothed like any other
# conscript; scenes that want them already stripped (the Rescue objective's
# stocks/slutwall captive) call lustStateFullyUndress() themselves rather than
# this generator defaulting to naked - the CapturedSoldierEvent dead-end wants
# them clothed at the start instead, so it leaves this alone.

func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = CharacterType.Generic

func pickName(character:DynamicCharacter, _args = {}):
	character.npcName = "Captured Soldier"
	character.npcChatColorOverride = "#40FF40"

func pickSmallDescription(character:DynamicCharacter, _args = {}):
	return "An AlphaCorp soldier, taken prisoner. "+str(.pickSmallDescription(character, _args))

func getAttacks():
	return ["trygetupattack"]

func getPossibleAttacks():
	return []

func pickEquipment(character:DynamicCharacter, _args = {}):
	character.npcDefaultEquipment = ["GunModConscriptArmor"]
