extends SceneBase

func _init():
	sceneID = "WarDraftKidlatCameoScene"

func _reactInit():
	addCharacter("kidlat")
	var kidlatChar = getCharacter("kidlat")
	kidlatChar.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("GunModConscriptArmor"))
	playAnimation(StageScene.Duo, "stand", {npc="kidlat"})

func showShopButtons():
	addButton("Buy ammo crate", "50 credits - restocks your weapon", "buy_ammo")
	addButton("Buy field ration", "20 credits - patches up some pain", "buy_ration")
	addButton("Leave", "You've got a patrol to run", "do_leave")

func _run():
	if(state == ""):
		saynn("[say=kidlat]Oh hey, a customer! Don't just stand there, the mortars won't wait forever.[/say]")

		saynn("You ask, slowly, what exactly Kidlat is doing in the middle of an active warzone, dressed like she's actually supposed to be here.")

		saynn("[say=kidlat]Followed a supply crate that smelled like good stuff, got scooped up by an AlphaCorp forklift before I could let go of it. Paperwork got weird. Now I'm technically staff![/say]")

		saynn("[say=kidlat]Nobody's told me otherwise, and I'm not about to bring it up. Wanna buy something?[/say]")

		showShopButtons()

	if(state == "bought_ammo"):
		saynn("[say=kidlat]Pleasure doing business.[/say]")
		showShopButtons()

	if(state == "bought_ration"):
		saynn("[say=kidlat]Don't ask what's in it.[/say]")
		showShopButtons()

	if(state == "broke"):
		saynn("[say=kidlat]Credits, sweetheart. Can't run a business on good vibes.[/say]")
		showShopButtons()

	if(state == "leaving"):
		saynn("[say=kidlat]Suit yourself. Don't die, you're a repeat customer now![/say]")

		addButton("Continue", "Get moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		getCharacter("kidlat").resetEquipment()
		endScene()
		return

	if(_action == "do_leave"):
		setState("leaving")
		return

	if(_action == "buy_ammo"):
		if(GM.pc.getCredits() < 50):
			setState("broke")
		else:
			GM.pc.addCredits(-50)
			GM.main.PS.restockAmmo()
			setState("bought_ammo")
		return

	if(_action == "buy_ration"):
		if(GM.pc.getCredits() < 20):
			setState("broke")
		else:
			GM.pc.addCredits(-20)
			GM.pc.addPain(-25)
			setState("bought_ration")
		return

	setState(_action)
