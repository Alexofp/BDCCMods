extends CharacterGeneratorBase
class_name SyndicateJailerGenerator

# Detention-facility guard, distinct from SyndicateSoldierGenerator - batons
# instead of a Marauder rifle, matching a "keep prisoners in line" role rather
# than a front-line combatant.

func pickCharacterType(character:DynamicCharacter, _args = {}):
	character.npcCharacterType = CharacterType.Guard

func pickName(character:DynamicCharacter, _args = {}):
	character.npcName = RNG.pick(["Syndicate Jailer", "Syndicate Guard"])
	character.npcChatColorOverride = "#FF4040"

func pickSmallDescription(character:DynamicCharacter, _args = {}):
	return "One of the Syndicate's detention guards. "+str(.pickSmallDescription(character, _args))

func getAttacks():
	return ["stunbatonAttack", "trygetupattack"]

func getPossibleAttacks():
	return ["stunbatonOverchargeAttack", "simplekickattack"]

func pickEquipment(character:DynamicCharacter, _args = {}):
	character.npcDefaultEquipment = ["SyndiHelmet", "SyndiArmor"]
