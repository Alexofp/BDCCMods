extends EventBase

func _init():
	id = "WarDraftDetentionEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func run(_triggerID, _args):
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return
	if(!GM.main.PS.inDetention):
		return

	var loc = GM.pc.getLocation()

	if(GM.main.PS.downedJailerRooms.has(loc)):
		var downedChar = GlobalRegistry.getCharacter(GM.main.PS.downedJailerRooms[loc])
		if(downedChar != null):
			saynn(downedChar.getName()+" is still slumped here, out cold. Nobody's come to collect them yet.")

	if(loc == "wardraftCell"):
		addButton("Use the bucket", "It's grim, but it's there", "use_bucket")

	if(loc == "wardraftCellDoor" && !GM.main.PS.doorForced):
		var chance = int(round(GM.main.PS.getDoorForceChance()))
		addButton("Force the door", "Try to break out ("+str(chance)+"% chance)", "force_door")

func onButton(_method, _args):
	if(_method == "use_bucket"):
		addMessage("There's a bucket in the corner, already reeking. You use it anyway - there's no other option in here.")
	if(_method == "force_door"):
		if(RNG.chance(GM.main.PS.getDoorForceChance())):
			GM.main.PS.forceDoorOpen()
			addMessage("With a sharp crack, the door gives. You're not locked in anymore.")
		else:
			GM.pc.addStamina(-15)
			addMessage("The door doesn't budge. Just a wasted, tiring shove.")
			if(RNG.chance(25.0)):
				var jailerID = GM.main.PS.getLivingDetentionJailer()
				if(jailerID != ""):
					addMessage("The noise carries further than you'd like.")
					runScene("WarDraftDetentionFightScene", [jailerID])

func react(_triggerID, _args):
	if(!GM.main.isInSpecificPlayerSlavery("WarDraft")):
		return false
	var ps = GM.main.PS
	if(!ps.inDetention):
		return false

	ps.tickDetentionJailers(30 if !GM.pc.hasBoundLegs() else 60)

	if(GM.pc.getLocation() == "wardraftExit"):
		runScene("WarDraftDetentionEscapeScene")
		return true

	return false

func getPriority():
	return 0
