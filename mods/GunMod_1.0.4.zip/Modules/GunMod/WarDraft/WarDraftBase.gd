extends PlayerSlaveryBase

const PatrolFloor = "WarDraftPatrolFloor"
const DetentionTalliesNeeded = 5

const DetentionZone = "wardraftdetention" # matches the "zone_wardraftdetention" group on WarDraftDetentionFloor.tscn's corridor/guard-post rooms
const DetentionJailerCount = 2
const DetentionPatrolRooms = [
	"wardraftCorridorNearExit", "wardraftCorridorMidWest",
	"wardraftCorridorCellExitWest", "wardraftCorridorCellExitEast",
	"wardraftCorridorMidEast", "wardraftCorridorNearGuardPost",
	"wardraftGuardPost",
]

const MoralePerObjective = 2
const MoralePenaltyForAbuse = -5
const CreditsPerObjective = 40
const ContentChancePerRoom = 55.0
const MoraleThresholdForDischarge = 100
const MoraleThresholdForDischargeBad = -30

const CorruptionPerObjective = 2
const CorruptionPerAbuse = 3
const CorruptionPenaltyForRescue = -3 # needing allies to pull you out after a lost fight
const CorruptionPenaltyForLeniency = -3 # letting a captured AlphaCorp soldier go instead of processing them
const CorruptionThresholdForFiringSquad = -20
const CorruptionThresholdForFinalPush = 100

const AlphaCorpEnemySoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/AlphaCorpEnemySoldierGenerator.gd")
const AlphaCorpSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/AlphaCorpSoldierGenerator.gd")
const SyndicateSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/SyndicateSoldierGenerator.gd")
const SyndicateJailerGeneratorScript = preload("res://Modules/GunMod/WarDraft/SyndicateJailerGenerator.gd")

const WeaponAmmoDefaults = {
	"GunModServiceRifle": 12,
	"GunModMarauderRifle": 20,
	"GunModEnergyRifle": 8,
	"PistolModGun": 6,
	"PistolModLaserPistol": 4,
}

const EventScripts = {
	"WarDraftItemStash": preload("res://Modules/GunMod/WarDraft/Events/ItemStashEvent.gd"),
	"WarDraftSupplyLocker": preload("res://Modules/GunMod/WarDraft/Events/SupplyLockerEvent.gd"),
	"WarDraftRestSpot": preload("res://Modules/GunMod/WarDraft/Events/RestSpotEvent.gd"),
	"WarDraftTrap": preload("res://Modules/GunMod/WarDraft/Events/TrapEvent.gd"),
	"WarDraftCapturedSoldier": preload("res://Modules/GunMod/WarDraft/Events/CapturedSoldierEvent.gd"),
	"WarDraftKidlatCameo": preload("res://Modules/GunMod/WarDraft/Events/KidlatCameoEvent.gd"),
	"WarDraftCombatEncounter": preload("res://Modules/GunMod/WarDraft/Events/CombatEncounterEvent.gd"),
	"WarDraftRescue": preload("res://Modules/GunMod/WarDraft/Events/RescueEvent.gd"),
	"WarDraftDisarmBomb": preload("res://Modules/GunMod/WarDraft/Events/DisarmBombEvent.gd"),
	"WarDraftPlantBomb": preload("res://Modules/GunMod/WarDraft/Events/PlantBombEvent.gd"),
	"WarDraftBoss": preload("res://Modules/GunMod/WarDraft/Events/BossEvent.gd"),
}

var morale:int = 0 # AlphaCorp faction-standing meter
var lastMoraleTierShown:String = "neutral"
var corruption:int = 0 # Syndicate standing meter, only relevant once defected
var level:int = 1 # how deep into the current patrol run
var inPatrol:bool = false

var map:Dictionary = {}
var events:Dictionary = {} # roomID = WarDraftEventBase instance
var startRoom:String = ""
var exitRoom:String = ""

var inDetention:bool = false
var detentionJailerIDs:Array = [] # persistent, real-pawn jailer charIDs for the current detention
var detentionGuardsDefeated:Dictionary = {} # jailer charID = true, this attempt only
var downedJailerRooms:Dictionary = {} # roomID = jailerID, persists until resetDetentionAttempt()/escapeDetention()
var doorForced:bool = false
var defected:bool = false # true once the player has switched sides to the Syndicate

func _init():
	id = "WarDraft"

func getStartScene() -> String:
	return "WarDraftStart"

func relockCellDoor():
	doorForced = false
	var door = GM.world.getRoomByID("wardraftCellDoor")
	if(door != null):
		door.canSouth = false

func getDoorForceChance() -> float:
	return clamp(55.0 + GM.pc.getSkillLevel(Skill.Combat) * 4.0, 10.0, 90.0)

func forceDoorOpen():
	doorForced = true
	var door = GM.world.getRoomByID("wardraftCellDoor")
	if(door != null):
		door.canSouth = true

func startDetention():
	inDetention = true
	relockCellDoor()
	spawnDetentionJailers()
	GM.pc.setLocation("wardraftCell")

func spawnDetentionJailers():
	detentionJailerIDs.clear()
	detentionGuardsDefeated.clear()
	downedJailerRooms.clear()
	for _i in range(DetentionJailerCount):
		var theGenerator = SyndicateJailerGeneratorScript.new()
		var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: false})
		var jailerID = theChar.getID()
		detentionJailerIDs.append(jailerID)
		placeDetentionJailer(jailerID)

func placeDetentionJailer(jailerID:String):
	GM.main.IS.spawnPawnIfNeeded(jailerID, "WarDraftSyndicateJailer")
	var pawn:CharacterPawn = GM.main.IS.getPawn(jailerID)
	if(pawn != null):
		pawn.setLocation(RNG.pick(DetentionPatrolRooms))

func resetDetentionAttempt():
	detentionGuardsDefeated.clear()
	downedJailerRooms.clear()
	relockCellDoor()
	for jailerID in detentionJailerIDs:
		placeDetentionJailer(jailerID)
	GM.pc.setLocation("wardraftCell")

func markDetentionGuardDefeated(jailerID:String):
	detentionGuardsDefeated[jailerID] = true
	var pawn:CharacterPawn = GM.main.IS.getPawn(jailerID)
	if(pawn != null):
		downedJailerRooms[pawn.getLocation()] = jailerID
	GM.main.IS.deletePawn(jailerID) # stops patrolling/being met again this attempt - the body itself persists via downedJailerRooms until the next reset

# MainScene.doTimeProcess() only calls GM.main.IS.processTime() "if(!PS)" -
# the whole population simulation (every GlobalTask included) is
# unconditionally frozen for as long as ANY PlayerSlavery scenario is
# active, by design (the main prison doesn't keep living while the player's
# off in a side scenario). That means WarDraftJailerPatrolTask/GoalPatrol
# never gets ticked through the normal pipeline while inDetention, no matter
# how correctly it's wired up. There's no safe cross-system hook to claw
# that back either - MainScene's own "time_passed" signal fires outside that
# same "if(!PS)" gate, but connecting to it from Module.postInit() risks
# GM.main not existing yet at that point in boot (postInitModules() runs as
# part of GlobalRegistry's own asset-loading sequence, which reads as
# happening before MainScene._ready() ever sets GM.main - not proven safe to
# assume otherwise). So instead this is called directly from
# WarDraftDetentionEvent.react() on every real room move while inDetention -
# self-contained within this mod's own already-firing trigger, no boot-order
# risk - manually replicating just the slice of
# InteractionSystem.processBusyAllInteractions() our own jailer pawns need,
# scoped to only them rather than resuming the whole game's population sim
# during WarDraft.
func tickDetentionJailers(seconds:int):
	var theTask:GlobalTask = GM.main.IS.getGlobalTask("WarDraftJailerPatrol")
	if(theTask != null):
		theTask.processTime(seconds)
		theTask.maxAssignedCached = theTask.getMaxAssigned(GM.main.IS.getMaxPawnCount())

	for jailerID in detentionJailerIDs:
		if(detentionGuardsDefeated.has(jailerID)):
			continue
		var pawn:CharacterPawn = GM.main.IS.getPawn(jailerID)
		if(pawn == null):
			continue
		pawn.processTime(seconds) # also lazily creates the AloneInteraction via checkAloneInteraction()

		var interaction:PawnInteractionBase = pawn.getInteraction()
		if(interaction == null):
			continue
		interaction.busyActionSeconds -= seconds
		interaction.processTime(seconds)
		if(interaction.busyActionSeconds <= 0 && !interaction.isBeingSpied() && !interaction.isWaitingForScene()):
			interaction.doCurrentAction()
			if(!interaction.wasDeleted && !interaction.getCurrentPawn().isPlayer()):
				GM.main.IS.decideNextAction(interaction)

func getLivingDetentionJailer() -> String:
	for jailerID in detentionJailerIDs:
		if(!detentionGuardsDefeated.has(jailerID)):
			return jailerID
	return ""

func escapeDetention():
	inDetention = false
	for jailerID in detentionJailerIDs:
		GM.main.IS.deletePawn(jailerID)
	detentionJailerIDs.clear()
	detentionGuardsDefeated.clear()
	downedJailerRooms.clear()
	GM.world.aimCamera("wardraft_trench")
	GM.pc.setLocation("wardraft_trench")
	reissueUniformIfNeeded()

func reissueUniformIfNeeded():
	if(GM.pc.getInventory().getEquippedItem(InventorySlot.Body) == null):
		GM.pc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("GunModConscriptArmor"))
		addMessage("Someone tosses you a spare uniform on your way back in.")

func generateMap():
	map.clear()
	events.clear()

	var dunGen:DungeonMapGenerator = DungeonMapGenerator.new()
	dunGen.generate({
		mainPathLen = 8,
		amountOfDeadends = 5,
	})

	# Only deadends used to be eligible for content, which starved things
	# badly (5 deadends a level, 10 competing event types) - any room that
	# isn't the start or exit is eligible now, main path included, each
	# rolling an independent chance to actually get something (so travel
	# rooms still exist, just fewer of them). Also guarantee at least one
	# fight every level, plus a boss every 3rd level (mirrors Drug Den's own
	# "shouldHaveBoss = level % 3 == 0"), by reserving specific spots before
	# the rest roll normally.
	var eligibleList:Array = []
	for thePos in dunGen.map:
		if(thePos != dunGen.startPos && thePos != dunGen.endPos):
			eligibleList.append(thePos)
	eligibleList.shuffle()

	var guaranteedSpots:Dictionary = {} # pos = eventID string

	if(!eligibleList.empty()):
		guaranteedSpots[eligibleList.pop_back()] = "WarDraftCombatEncounter"

	if(level % 3 == 0 && !eligibleList.empty()):
		guaranteedSpots[eligibleList.pop_back()] = "WarDraftBoss"

	var mapIndex:int = 1
	var posToIDMap:Dictionary = {}
	for thePos in dunGen.map:
		var thisRoomID:String = "wardraftPatrolRoom"+str(mapIndex)

		var isEligible:bool = (thePos != dunGen.startPos && thePos != dunGen.endPos)
		var customIcon = RoomStuff.RoomSprite.NONE

		if(isEligible):
			var newEvent = null
			if(guaranteedSpots.has(thePos)):
				newEvent = createEvent(guaranteedSpots[thePos])
			elif(RNG.chance(ContentChancePerRoom)):
				newEvent = generateEvent()
			if(newEvent != null):
				events[thisRoomID] = newEvent
				newEvent.loc = thisRoomID
				newEvent.onSpawn(self)
				customIcon = newEvent.getMapIcon()

		posToIDMap[thePos] = thisRoomID
		map[thisRoomID] = {
			x = int(thePos.x),
			y = int(thePos.y),
			canN = dunGen.canGo(thePos, DungeonMapGenerator.DIR_N),
			canS = dunGen.canGo(thePos, DungeonMapGenerator.DIR_S),
			canE = dunGen.canGo(thePos, DungeonMapGenerator.DIR_E),
			canW = dunGen.canGo(thePos, DungeonMapGenerator.DIR_W),
			customIcon = customIcon,
		}

		mapIndex += 1

	startRoom = posToIDMap[dunGen.startPos]
	exitRoom = posToIDMap[dunGen.endPos]

func buildMap():
	GM.world.clearFloor(PatrolFloor)
	for roomID in map:
		var roomInfo:Dictionary = map[roomID]

		var theIcon = roomInfo["customIcon"] if roomInfo.has("customIcon") else RoomStuff.RoomSprite.NONE
		if(roomID == exitRoom):
			theIcon = RoomStuff.RoomSprite.STAIRS

		GM.world.addRoom(PatrolFloor, roomID, Vector2(roomInfo["x"], roomInfo["y"]), {
			name = "Front Line",
			desc = "Cratered ground, burnt-out sandbag lines, the occasional stretch of razor wire nobody's bothered to clear. Gunfire echoes somewhere out of sight, close enough that you can't tell if it's ahead of you or behind.",
			icon = theIcon,
			canW = roomInfo["canW"],
			canE = roomInfo["canE"],
			canS = roomInfo["canS"],
			canN = roomInfo["canN"],
		})
	GM.world.addTransitions([PatrolFloor])

func startPatrol():
	inPatrol = true
	level = 1
	generateMap()
	buildMap()
	GM.pc.setLocation(startRoom)
	giveStartingPainkillers()

func getPainkillerCount() -> int:
	var total = 0
	for item in GM.pc.getInventory().getItems():
		if(item.id == "painkillers"):
			total += item.getAmount()
	return total

func giveStartingPainkillers():
	if(getPainkillerCount() <= 2):
		var newItem = GlobalRegistry.createItem("painkillers")
		newItem.setAmount(2)
		GM.pc.getInventory().addItem(newItem)

func nextLevel():
	level += 1
	# buildMap() clears and rebuilds PatrolFloor in place - if the camera's
	# still highlighting a room on that floor (it always is here, the player
	# just pressed this from the exit room) when the old rooms get freed,
	# World.gd's highlightedRoom is left dangling and the next aimCamera()
	# call anywhere crashes with "call on a deleted object". Aim somewhere
	# safe and static first so the freed rooms are never the highlighted one.
	GM.world.aimCamera("wardraft_trench")
	generateMap()
	buildMap()
	GM.pc.setLocation(startRoom)
	addMessage("You push deeper into hostile territory. Patrol level "+str(level)+".")

func endPatrol():
	inPatrol = false
	GM.world.aimCamera(getHubTrenchRoom()) # see nextLevel() - same dangling-highlightedRoom risk
	GM.world.clearFloor(PatrolFloor)
	GM.pc.setLocation(getHubTrenchRoom())

func addMorale(amount:int):
	var wasEligibleForDischarge:bool = morale >= MoraleThresholdForDischarge
	morale += amount
	if(amount > 0):
		addMessage("AlphaCorp morale +"+str(amount)+" ("+str(morale)+" total).")
	elif(amount < 0):
		addMessage("AlphaCorp morale "+str(amount)+" ("+str(morale)+" total).")

	if(!wasEligibleForDischarge && morale >= MoraleThresholdForDischarge):
		addMessage("Your record's good enough that Command's talking about a final push. Might be worth asking Drask about it.")

func getMoraleTier() -> String:
	if(morale >= MoraleThresholdForDischarge):
		return "great"
	if(morale >= 75):
		return "good"
	if(morale >= 50):
		return "fine"
	if(morale >= 25):
		return "decent"
	if(morale > -15):
		return "neutral"
	if(morale > -25):
		return "bad"
	return "critical"

func addCorruption(amount:int):
	var wasEligibleForFinalPush:bool = corruption >= CorruptionThresholdForFinalPush
	corruption += amount
	if(amount > 0):
		addMessage("Corruption +"+str(amount)+" ("+str(corruption)+" total).")
	elif(amount < 0):
		addMessage("Corruption "+str(amount)+" ("+str(corruption)+" total).")

	if(!wasEligibleForFinalPush && corruption >= CorruptionThresholdForFinalPush):
		addMessage("Vex has started talking about you differently. Might be worth bringing it up with her.")

# No advance-warning nudge here, unlike addMorale()'s positive-threshold
# message - matches the deliberate choice already made for
# MoraleThresholdForDischargeBad (fires with no warning on Extract).
func getCombatLossSceneID() -> String:
	if(defected):
		addCorruption(CorruptionPenaltyForRescue)
		return "WarDraftRescuedByAlliesScene"
	return "WarDraftCapturedScene"

func getEnemySoldierGeneratorScript():
	return AlphaCorpEnemySoldierGeneratorScript if defected else SyndicateSoldierGeneratorScript

func getOwnFactionSoldierGeneratorScript():
	return SyndicateSoldierGeneratorScript if defected else AlphaCorpSoldierGeneratorScript

func getEnemyWeaponID() -> String:
	return "GunModServiceRifle" if defected else "GunModMarauderRifle"

func getEnemyWeaponName() -> String:
	return "Service rifle" if defected else "Marauder rifle"

func getEnemyWeaponModelPath() -> String:
	return "res://Modules/GunMod/Models/ServiceRifle.tscn" if defected else "res://Modules/GunMod/Models/MarauderRifle.tscn"

func getOwnFactionWeaponID() -> String:
	return "GunModMarauderRifle" if defected else "GunModServiceRifle"

func getOwnFactionWeaponModelPath() -> String:
	return "res://Modules/GunMod/Models/MarauderRifle.tscn" if defected else "res://Modules/GunMod/Models/ServiceRifle.tscn"

func getHubOutpostRoom() -> String:
	return "syndicate_outpost" if defected else "wardraft_outpost"

func getHubArmoryRoom() -> String:
	return "syndicate_armory" if defected else "wardraft_armory"

func getHubShowerRoom() -> String:
	return "syndicate_shower" if defected else "wardraft_shower"

func getHubTrenchRoom() -> String:
	return "syndicate_trench" if defected else "wardraft_trench"

func getHubBunkerRooms() -> Array:
	return ["syndicate_bunker"] if defected else ["wardraft_bunker", "wardraft_bunker2"]

func hasEventInRoom(roomID:String) -> bool:
	return events.has(roomID)

func getEventInRoom(roomID:String):
	return events[roomID] if events.has(roomID) else null

func removeEventFromRoom(roomID:String):
	if(!events.has(roomID)):
		return
	events.erase(roomID)
	GM.world.setRoomSprite(roomID, RoomStuff.RoomSprite.NONE)

func getEventAmountOfType(theType:String) -> int:
	var result:int = 0
	for loc in events:
		if(events[loc].id == theType):
			result += 1
	return result

func createEvent(eventID:String):
	if(!EventScripts.has(eventID)):
		return null
	return EventScripts[eventID].new()

func generateEvent():
	var possible:Dictionary = {}
	for eventID in EventScripts:
		var theEvent = createEvent(eventID)
		if(getEventAmountOfType(eventID) >= theEvent.getMaxPerLevel()):
			continue
		if(!theEvent.canSpawn(self)):
			continue
		var weight:float = theEvent.getEventWeight()
		if(weight <= 0.0):
			continue
		possible[eventID] = weight

	if(possible.empty()):
		return null
	var pickedID:String = RNG.pickWeightedDict(possible)
	return createEvent(pickedID)

const EnemyWeaponDropChance = 35.0

func dropEnemyWeapon(chance:float = EnemyWeaponDropChance, weaponID:String = "GunModMarauderRifle") -> bool:
	if(!RNG.chance(chance)):
		return false
	var weapon = GlobalRegistry.createItem(weaponID)
	weapon.charges = WeaponAmmoDefaults[weaponID]
	GM.pc.getInventory().addItem(weapon)
	return true

func restockAmmo():
	var restockedAny:bool = false
	for item in GM.pc.getInventory().getItems():
		if(WeaponAmmoDefaults.has(item.id)):
			item.charges = WeaponAmmoDefaults[item.id]
			restockedAny = true

	if(!restockedAny):
		GM.pc.getInventory().addItem(GlobalRegistry.createItem(getOwnFactionWeaponID()))

	addMessage("You restock on ammo from the barracks supply crate.")

func hasWorkingWeapon() -> bool:
	for item in GM.pc.getInventory().getItems():
		if(WeaponAmmoDefaults.has(item.id)):
			return true
	return false

func warnIfNoWeapon():
	if(!hasWorkingWeapon()):
		addMessage("You have no ammo!")

func stripPlayerGear():
	var inv = GM.pc.getInventory()
	var gearIDs = ["GunModServiceRifle", "GunModMarauderRifle", "GunModEnergyRifle", "PistolModGun", "PistolModLaserPistol", "GunModConscriptArmor", "GunModConscriptHelmet", "SyndiArmor", "SyndiHelmet"]

	# Collect matches into separate lists first - inv.getItems() returns the
	# inventory's live internal array, so erasing from it mid-loop shifts
	# later entries down and silently skips whatever lands in the freed slot.
	var carriedToRemove = []
	for item in inv.getItems():
		if(gearIDs.has(item.id)):
			carriedToRemove.append(item)
	inv.removeItemsList(carriedToRemove)

	var equippedToRemove = []
	for item in inv.getAllEquippedItems().values():
		if(gearIDs.has(item.id)):
			equippedToRemove.append(item)
	inv.removeEquippedItemsList(equippedToRemove)

func addMessage(theText:String):
	GM.main.addMessage(theText)

func saveData() -> Dictionary:
	var eventData:Dictionary = {}
	for loc in events:
		var theEvent = events[loc]
		eventData[loc] = {
			id = theEvent.id,
			data = theEvent.saveData(),
		}

	return {
		morale = morale,
		lastMoraleTierShown = lastMoraleTierShown,
		corruption = corruption,
		level = level,
		inPatrol = inPatrol,
		map = map,
		startRoom = startRoom,
		exitRoom = exitRoom,
		events = eventData,
		inDetention = inDetention,
		detentionJailerIDs = detentionJailerIDs,
		detentionGuardsDefeated = detentionGuardsDefeated,
		downedJailerRooms = downedJailerRooms,
		doorForced = doorForced,
		defected = defected,
	}

func loadData(_data:Dictionary):
	morale = SAVE.loadVar(_data, "morale", 0)
	lastMoraleTierShown = SAVE.loadVar(_data, "lastMoraleTierShown", "neutral")
	corruption = SAVE.loadVar(_data, "corruption", 0)
	level = SAVE.loadVar(_data, "level", 1)
	inPatrol = SAVE.loadVar(_data, "inPatrol", false)
	map = SAVE.loadVar(_data, "map", {})
	startRoom = SAVE.loadVar(_data, "startRoom", "")
	exitRoom = SAVE.loadVar(_data, "exitRoom", "")

	events = {}
	var eventData:Dictionary = SAVE.loadVar(_data, "events", {})
	for loc in eventData:
		var entry:Dictionary = eventData[loc]
		var eventID:String = SAVE.loadVar(entry, "id", "")
		var newEvent = createEvent(eventID)
		if(newEvent == null):
			continue
		newEvent.loc = loc
		newEvent.loadData(SAVE.loadVar(entry, "data", {}))
		events[loc] = newEvent

	inDetention = SAVE.loadVar(_data, "inDetention", false)
	detentionJailerIDs = SAVE.loadVar(_data, "detentionJailerIDs", [])
	detentionGuardsDefeated = SAVE.loadVar(_data, "detentionGuardsDefeated", {})
	downedJailerRooms = SAVE.loadVar(_data, "downedJailerRooms", {})
	doorForced = SAVE.loadVar(_data, "doorForced", false)
	if(doorForced):
		forceDoorOpen()
	elif(inDetention):
		# Room state (canSouth) lives on the freshly-.tscn-loaded GameRoom
		# node, not in save data - a reload mid-detention with the door
		# correctly locked would otherwise silently leave it open, since
		# nothing here was re-asserting the lock, only ever opening it.
		relockCellDoor()
	defected = SAVE.loadVar(_data, "defected", false)

	if(inDetention):
		for jailerID in detentionJailerIDs:
			if(!detentionGuardsDefeated.has(jailerID) && !GM.main.IS.hasPawn(jailerID)):
				placeDetentionJailer(jailerID)

	if(inPatrol):
		buildMap()
