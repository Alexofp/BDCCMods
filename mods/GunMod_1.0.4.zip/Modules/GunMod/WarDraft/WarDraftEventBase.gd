extends Reference
class_name WarDraftEventBase

# Mod-owned equivalent of Game/DrugDen/DrugDenEventBase.gd - that class can't be
# reused directly since GlobalRegistry only ever scans Drug Den's own hardcoded
# "res://Game/DrugDen/Events/" folder for it (registerDrugDenEventFolder), with
# no Module.gd array to extend it through. This is a standalone parallel system
# WarDraftBase.gd manages entirely on its own (see its generateEvent()).

var id:String = "error"
var loc:String = ""
var eventWeight:float = 1.0

func canSpawn(_wd) -> bool:
	return true

func onSpawn(_wd):
	pass

func getMaxPerLevel() -> int:
	return 1

func getEventWeight() -> float:
	return eventWeight

func getMapIcon():
	return RoomStuff.RoomSprite.IMPORTANT

func getInteractInfo() -> Dictionary:
	return {
		text = "You found something!",
		actions = [
			{id = "act", name = "Act", desc = "Do something!", args = []},
		],
	}

# Return either {text=...} for an inline result, or {sceneID=..., args=[...]}
# to hand off to a real scene. "ended" removes the event from its room.
func doInteract(_actionID:String, _args:Array = []) -> Dictionary:
	return {text = "You did it!", ended = true}

func endEvent():
	if(loc == ""):
		return
	if(GM.main.PS == null || GM.main.PS.id != "WarDraft"):
		return
	GM.main.PS.removeEventFromRoom(loc)
	loc = ""

func saveData() -> Dictionary:
	return {}

func loadData(_data:Dictionary):
	pass
