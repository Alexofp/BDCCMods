extends SceneBase

var guardID:String = ""

func _init():
	sceneID = "WarDraftStart"

func _reactInit():
	var theGenerator := GuardGenerator.new()
	var theGuard:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	guardID = theGuard.getID()
	theGuard.npcChatColorOverride = "#40FF40"
	addCharacter(guardID)

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return guardID

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "stand", {npc=guardID})
		saynn("A guard reads your inmate number off a datapad, same tone {npc.he} would use for a grocery list.")

		saynn("[say="+guardID+"]Reassignment. Effective immediately. Congratulations, you're a soldier now.[/say]")

		saynn("You ask what that means. {npc.He} doesn't look up.")

		saynn("[say="+guardID+"]Means AlphaCorp needs bodies at the front more than BDCC needs you scrubbing floors. You're still property. Just reassigned property.[/say]")

		saynn("Your collar stays on. Nobody's letting you go anywhere. They're just sending you somewhere else.")

		addButton("Continue", "See what happens next", "shower")

	if(state == "shower"):
		aimCameraAndSetLocName("wardraft_shower")
		playAnimation(StageScene.Duo, "stand", {npc=guardID})
		saynn("Before anything else, you're marched into a delousing shower with the rest of the new intake. No curtains, no doors. {npc.name} leans in the frame with a clipboard, making sure nobody skips a spot.")

		saynn("[say="+guardID+"]Hands up. Arms out. Standard contamination check, won't take long.[/say]")

		saynn("{npc.He} doesn't check for contamination. {npc.He} checks whatever {npc.he} {npc.verbS('feel')} like, taking {npc.his} time about it, clipboard forgotten against {npc.his} hip.")

		addButton("Endure it", "Stand still and let {npc.him} finish", "shower_endure")
		addButton("Pull away", "Flinch back from {npc.his} hands", "shower_resist")

	if(state == "shower_endure"):
		saynn("You stand still and let {npc.him} finish. It's faster that way. It's always faster that way.")

		saynn("[say="+guardID+"]Good. Some of you learn quick.[/say]")

		saynn("{npc.He} moves on to the next body in line like nothing happened. For {npc.him}, nothing did.")

		addButton("Continue", "Get dressed", "gear_up")

	if(state == "shower_resist"):
		saynn("You pull back. {npc.His} grip tightens, hard enough to bruise, and {npc.he} doesn't even raise {npc.his} voice.")

		saynn("[say="+guardID+"]Don't. You're not the first collar to flinch and you won't be the last, but you'll stand still either way. Your choice how long it takes.[/say]")

		saynn("You stand still. It takes longer anyway.")

		addButton("Continue", "Get dressed", "gear_up")

	if(state == "gear_up"):
		aimCameraAndSetLocName("wardraft_armory")
		playAnimation(StageScene.Duo, "stand", {npc=guardID})
		saynn("Before you're handed anything, {npc.name} empties your pockets and strips whatever you walked in with. It goes into a crate with a number on it, not your name.")

		saynn("A quartermaster shoves a folded bundle into your arms without looking at you. Fatigues, a helmet, a rifle with the serial number scratched half off.")

		saynn("[say="+guardID+"]Service rifle. Try not to lose it, the paperwork's a nightmare.[/say]")

		saynn("The armor's stiff and smells like whoever wore it before you. You put it on anyway.")

		saynn("The rifle's heavier than you expected. You didn't ask for this. Nobody asked you.")

		addButton("Continue", "Get moving", "transport")

	if(state == "transport"):
		clearCharacter()
		aimCameraAndSetLocName("wardraft_transport")
		saynn("You're marched onto a troop transport with a few dozen other fresh conscripts. Some are inmates like you, still collared. Others just look tired.")

		saynn("Nobody talks much. One guy keeps checking his rifle's safety, on and off, on and off.")

		saynn("The speakers crackle with chatter that isn't meant for you - coordinates, casualty counts, someone asking for an evac that isn't coming. Then it cuts to silence.")

		saynn("Through the window: flashes of red and white, still hours off.")

		saynn("[i](Build a strong enough record out there and you'll eventually earn a shot at a final push, one last objective and an honorable way out. Let your conduct slide the other way and Command will discharge you in disgrace instead. Either way, you're not doing this forever.)[/i]")

		addButton("Continue", "Try to get some rest before landing", "arrival")

	if(state == "arrival"):
		aimCameraAndSetLocName("wardraft_outpost")
		addCharacter("drask")
		playAnimation(StageScene.Solo, "stand", {pc="drask"})
		saynn("The transport lands hard enough to rattle your teeth. The rear door drops. Mud, sandbags, a whole lot of nervous new faces just like yours.")

		saynn("Then you see him. A huge, scarred snow leopard, standing in the mud like he owns it.")

		saynn("[say=drask]Well shit, look what the prison shat out today. Fresh meat, and it's already collared. Somebody up top's got a sense of humor.[/say]")

		saynn("He walks the line, looking each of you over like livestock at an auction.")

		saynn("[say=drask]Name's Drask. Sergeant Drask to you. You get a gun, a uniform, and exactly zero say in whether you make it home. Congratulations, you're soldiers now.[/say]")

		addButton("Continue", "Let him keep talking", "briefing")

	if(state == "briefing"):
		playAnimation(StageScene.Solo, "stand", {pc="drask"})
		saynn("[say=drask]Rules are simple. You do what I say, when I say it. You don't run. You don't freeze up. And you sure as hell don't get yourself captured, we clear?[/say]")

		saynn("[say=drask]Every one of you that comes back in a bag is a personal insult. Take that personal. You die out there, I don't just lose a body, I lose a number. My number.[/say]")

		saynn("He crouches down, getting right up in your face.")

		saynn("[say=drask]So no, you don't get to die. Not on my watch, not without my permission.[/say]")

		addButton("Stay quiet", "Keep your mouth shut", "stay_quiet")
		addButton("Talk back", "Say something", "talk_back")

	if(state == "talk_back"):
		saynn("[say=pc]And if we get taken instead?[/say]")

		saynn("Drask's grin drops.")

		saynn("[say=drask]Then you'd better hope Syndicate kills you quick. Because if I get you back, you're gonna wish they hadn't.[/say]")

		saynn("[say=drask]Got some spine on you. Good. Doesn't mean I like the mouth on you, though.[/say]")

		addButton("Continue", "See what happens next", "end_hook")

	if(state == "stay_quiet"):
		saynn("You keep your mouth shut. Smartest thing you've done all day.")

		saynn("Drask looks at you a second longer than he needs to, then moves down the line.")

		addButton("Continue", "See what happens next", "end_hook")

	if(state == "end_hook"):
		aimCameraAndSetLocName("wardraft_bunker")
		playAnimation(StageScene.Solo, "stand")
		saynn("[say=drask]Get some rest. Patrols start at first light.[/say]")

		saynn("You find a bunk that isn't yours yet and sit down, rifle across your knees, collar still locked around your neck.")

		saynn("Tomorrow, someone out past those sandbags is going to try and kill you.")

		addButton("End", "End the scene here", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "gear_up"):
		processTime(20*60)
		GM.main.PSH.storePlayersItems()
		GM.pc.getInventory().addItem(GlobalRegistry.createItem("GunModServiceRifle"))
		GM.pc.getInventory().forceEquipStoreOtherUnlessRestraint(GlobalRegistry.createItem("GunModConscriptArmor"))
		GM.pc.getInventory().addItem(GlobalRegistry.createItem("GunModConscriptHelmet"))

	if(_action == "transport"):
		processTime(3*60*60)

	if(_action == "arrival"):
		processTime(30*60)
		GM.pc.setLocation("wardraft_outpost")

	if(_action == "stay_quiet" || _action == "talk_back"):
		GM.pc.setLocation("wardraft_bunker")

	setState(_action)

func saveData():
	var data = .saveData()

	data["guardID"] = guardID

	return data

func loadData(data):
	.loadData(data)

	guardID = SAVE.loadVar(data, "guardID", "")
