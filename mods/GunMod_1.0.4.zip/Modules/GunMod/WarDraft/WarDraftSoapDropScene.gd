extends SceneBase

var victimID:String = ""
var opportunistID:String = ""

func _init():
	sceneID = "WarDraftSoapDropScene"

func _reactInit():
	var theGeneratorScript = GM.main.PS.getOwnFactionSoldierGeneratorScript()

	var victimGen = theGeneratorScript.new()
	var victim:BaseCharacter = victimGen.generate({NpcGen.Temporary: true})
	victimID = victim.getID()
	victim.lustStateFullyUndress()

	var oppGen = theGeneratorScript.new()
	var opp:BaseCharacter = oppGen.generate({NpcGen.Temporary: true})
	opportunistID = opp.getID()

	addCharacter(victimID)
	addCharacter(opportunistID)
	playAnimation(StageScene.Duo, "tease", {npc=opportunistID, pc=victimID})

func resolveCustomCharacterName(_charID):
	if(_charID == "victim"):
		return victimID
	if(_charID == "opportunist"):
		return opportunistID

func _run():
	if(state == ""):
		saynn("You catch the tail end of it - a bar of soap skittering across the wet floor, {victim.name} freezing mid-crouch to grab it. {opportunist.name}'s already moving before {victim.he} can stand back up.")

		saynn("[say="+opportunistID+"]Well, would you look at that.[/say]")

		addButton("Intervene", "Pull them apart before it goes further", "do_intervene")
		addButton("Join in", "Nobody's going to know", "do_join")
		addButton("Just watch", "Stay out of it", "do_watch")
		addButton("Walk away", "Not your business", "do_walk_away")

	if(state == "after_intervene"):
		removeCharacter(opportunistID)
		saynn("[say="+opportunistID+"]Relax, I was just messing around.[/say]")

		saynn("{opportunist.He} backs off with both hands raised, all innocence, and clears out. {victim.name} doesn't say much, just nods at you and gets their pants back on in a hurry.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "after_join"):
		removeCharacter(opportunistID)
		removeCharacter(victimID)
		saynn("{opportunist.name} gives you a nod on the way out, like the two of you just split something. {victim.name} doesn't look at either of you.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "after_watch"):
		removeCharacter(opportunistID)
		removeCharacter(victimID)
		saynn("Eventually {opportunist.he} finishes, straightens up, and walks off without a second glance. {victim.name} stays slumped against the shower wall a while longer before pulling {victim.his} things back together.")

		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "do_walk_away"):
		endScene()
		return

	if(_action == "do_intervene"):
		setState("after_intervene")
		return

	if(_action == "do_join"):
		var sexScene = runScene("GenericSexScene", [["pc", opportunistID], victimID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "join_sex")
		sexScene.sexEngine.pcAllowsDomAutonomy = true
		return

	if(_action == "do_watch"):
		GM.pc.addArousal(0.15)
		runScene("GenericSexScene", [opportunistID, victimID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "watch_sex")
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "join_sex"):
		setState("after_join")

	if(_tag == "watch_sex"):
		setState("after_watch")

func saveData():
	var data = .saveData()

	data["victimID"] = victimID
	data["opportunistID"] = opportunistID

	return data

func loadData(data):
	.loadData(data)

	victimID = SAVE.loadVar(data, "victimID", "")
	opportunistID = SAVE.loadVar(data, "opportunistID", "")
