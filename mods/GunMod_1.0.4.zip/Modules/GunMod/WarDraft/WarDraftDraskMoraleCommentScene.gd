extends SceneBase

func _init():
	sceneID = "WarDraftDraskMoraleCommentScene"

func _run():
	if(state == ""):
		addCharacter("drask")
		playAnimation(StageScene.Solo, "stand", {pc="drask"})

		var tier = GM.main.PS.getMoraleTier()
		if(tier == "great"):
			saynn("[say=drask]You've more than earned your keep out there. Command's noticed. So have I.[/say]")
		elif(tier == "good"):
			saynn("[say=drask]You're closing in on something big. Don't let up now.[/say]")
		elif(tier == "fine"):
			saynn("[say=drask]Word's getting back to me about you. Keep it up.[/say]")
		elif(tier == "decent"):
			saynn("[say=drask]You're doing alright out there. Don't get comfortable.[/say]")
		elif(tier == "bad"):
			saynn("[say=drask]I've been hearing things about you I don't like. Fix it, before Command decides to fix it for you.[/say]")
		elif(tier == "critical"):
			saynn("[say=drask]You're one bad report away from getting pulled off this line for good. Get a fucking grip soldier.[/say]")

		addButton("...", "Get moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
