extends "res://Game/InteractionSystem/PawnTypes/Guard.gd"

# Dedicated pawn type for WarDraftBase's detention jailers - reuses Guard.gd's
# stats/pool/generator, only overrides: red map color (getCustomPawnColor),
# Patrol-only goal scoring (getProcessedGoalScore), and zero spawn weight
# (getDistributionWeight/shouldSpawnPawns - without this, registering the
# type put it in the ambient population spawner's pool, which tagged random
# ordinary guards with it and turned them permanently red on the map). Only
# ever assigned explicitly via IS.spawnPawnIfNeeded(jailerID,
# "WarDraftSyndicateJailer") in WarDraftBase.placeDetentionJailer().

func _init():
	id = "WarDraftSyndicateJailer"

func getCustomPawnColor(_pawn):
	return Color.red

func getDistributionWeight() -> float:
	return 0.0

func shouldSpawnPawns() -> bool:
	return false

func getProcessedGoalScore(_pawn, _goalID:String, theScore:float, _isKeepScore:bool) -> float:
	if(_goalID == InteractionGoal.Patrol):
		return theScore
	return 0.0
