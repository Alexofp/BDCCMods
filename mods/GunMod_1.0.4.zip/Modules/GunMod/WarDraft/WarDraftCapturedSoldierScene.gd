extends SceneBase

const SyndicateSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/SyndicateSoldierGenerator.gd")
const CapturedAlphaCorpSoldierGeneratorScript = preload("res://Modules/GunMod/WarDraft/CapturedAlphaCorpSoldierGenerator.gd")

var soldierID:String = ""
var captiveID:String = ""
var droppedRifle:bool = false

func _init():
	sceneID = "WarDraftCapturedSoldierScene"

func _reactInit():
	var soldierGen := SyndicateSoldierGeneratorScript.new()
	var soldier:BaseCharacter = soldierGen.generate({NpcGen.Temporary: true})
	soldierID = soldier.getID()

	var captiveGen := CapturedAlphaCorpSoldierGeneratorScript.new()
	var captive:BaseCharacter = captiveGen.generate({NpcGen.Temporary: true})
	captiveID = captive.getID()

	addCharacter(soldierID)
	addCharacter(captiveID)
	playAnimation(StageScene.Duo, "tease", {npc=soldierID, pc=captiveID})

func resolveCustomCharacterName(_charID):
	if(_charID == "soldier"):
		return soldierID
	if(_charID == "captive"):
		return captiveID

func _run():
	if(state == ""):
		if(GM.main.PS.defected):
			saynn("One of your own has {captive.name} shoved up against the wreckage, {captive.his} fatigues in a torn heap on the ground. {captive.He} isn't fighting anymore, just enduring it.")

			addButton("Take them in", "Call it off and haul them in for processing", "do_capture")
			addButton("Join in", "Nobody's going to know", "do_join")
			addButton("Just watch", "Stay out of sight and let it happen", "do_watch")
			addButton("Walk away", "Not your problem", "do_walk_away")
		else:
			saynn("{soldier.name} has {captive.name} shoved up against the wreckage, {captive.his} fatigues in a torn heap on the ground. {captive.He} isn't fighting anymore, just enduring it.")

			addButton("Rescue them", "Fight the soldier off", "do_rescue")
			addButton("Join in", "Nobody's going to know", "do_join")
			addButton("Just watch", "Stay out of sight and let it happen", "do_watch")
			addButton("Walk away", "Not your problem", "do_walk_away")

	if(state == "after_watch"):
		removeCharacter(soldierID)
		removeCharacter(captiveID)
		saynn("Eventually the soldier finishes, straightens up, and walks off without a second glance back. {captive.name} stays slumped against the wreckage a while longer before pulling {captive.his} fatigues back on.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "rescue_won"):
		removeCharacter(soldierID)
		saynn("{captive.name} slumps against the wreckage, shaken but alive. {captive.He} doesn't say much - just nods, and starts pulling {captive.his} fatigues back on.")

		if(droppedRifle):
			saynn("The soldier's Marauder rifle is still fully loaded. You take it before you move on.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "lost_encounter"):
		playAnimation(StageScene.Duo, "defeat", {npc=soldierID})
		saynn("You don't win this one.")

		addButton("Continue", "See what happens next", "start_defeated_sex")

	if(state == "encounter_survived_sex"):
		removeCharacter(soldierID)
		removeCharacter(captiveID)
		saynn("You manage to break free and get clear. {captive.name}'s not so lucky - not your problem anymore, not like this.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "encounter_captured"):
		removeCharacter(soldierID)
		removeCharacter(captiveID)
		playAnimation(StageScene.Sleeping, "sleep")
		saynn("Everything goes dark before you even register losing.")

		addButton("Continue", "See what happens next", "go_captured")

	if(state == "after_join"):
		removeCharacter(soldierID)
		removeCharacter(captiveID)
		saynn("The soldier gives you a nod on the way out, like you're colleagues now, and tosses over some spare rounds before heading off. {captive.name} doesn't look at either of you.")

		addButton("Continue", "Keep moving", "endthescene")

	if(state == "taken_in"):
		removeCharacter(soldierID)
		removeCharacter(captiveID)
		saynn("Your own soldier zip-ties {captive.name} without much fuss and radios it in. One more body for the count.")

		addButton("Continue", "Keep moving", "endthescene")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "do_walk_away"):
		endScene()
		return

	if(_action == "do_watch"):
		GM.pc.addArousal(0.15)
		runScene("GenericSexScene", [soldierID, captiveID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "watch_sex")
		return

	if(_action == "do_rescue"):
		GM.main.PS.warnIfNoWeapon()
		playAnimation(StageScene.Duo, "holdrifle", {npc=soldierID, npcAction=["holdrifle", "res://Modules/GunMod/Models/MarauderRifle.tscn"]})
		runScene("FightScene", [soldierID, "WarDraftPatrol"], "rescueFight")
		return

	if(_action == "do_capture"):
		GM.main.PS.addCorruption(GM.main.PS.CorruptionPerObjective)
		GM.pc.addCredits(GM.main.PS.CreditsPerObjective)
		setState("taken_in")
		return

	if(_action == "do_join"):
		var sexScene = runScene("GenericSexScene", [["pc", soldierID], captiveID, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}], "join_sex")
		sexScene.sexEngine.pcAllowsDomAutonomy = true
		return

	if(_action == "start_defeated_sex"):
		getCharacter(soldierID).prepareForSexAsDom()
		runScene("GenericSexScene", [soldierID, "pc", SexType.DefaultSex, {SexMod.SubMustGoUnconscious:true, SexMod.DisableDynamicJoiners:true}], "defeated_sex")
		return

	if(_action == "go_captured"):
		endScene()
		runScene(GM.main.PS.getCombatLossSceneID())
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "rescueFight"):
		processTime(10*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			GM.main.PS.addMorale(GM.main.PS.MoralePerObjective)
			GM.pc.addCredits(GM.main.PS.CreditsPerObjective)
			droppedRifle = GM.main.PS.dropEnemyWeapon()
			setState("rescue_won")
		else:
			setState("lost_encounter")

	if(_tag == "join_sex"):
		GM.pc.getFetishHolder().addFetish(Fetish.Sadism, RNG.randf_range(0.05, 0.15))
		if(GM.main.PS.defected):
			GM.main.PS.addCorruption(GM.main.PS.CorruptionPerAbuse)
		else:
			GM.main.PS.addMorale(GM.main.PS.MoralePenaltyForAbuse)
		GM.main.PS.restockAmmo()
		setState("after_join")

	if(_tag == "watch_sex"):
		setState("after_watch")

	if(_tag == "defeated_sex"):
		var sexResult:SexEngineResult = _result[0]
		var gotUncon:bool = sexResult.isSubUnconscious("pc")

		if(gotUncon):
			setState("encounter_captured")
		else:
			setState("encounter_survived_sex")

func saveData():
	var data = .saveData()

	data["soldierID"] = soldierID
	data["captiveID"] = captiveID
	data["droppedRifle"] = droppedRifle

	return data

func loadData(data):
	.loadData(data)

	soldierID = SAVE.loadVar(data, "soldierID", "")
	captiveID = SAVE.loadVar(data, "captiveID", "")
	droppedRifle = SAVE.loadVar(data, "droppedRifle", false)
