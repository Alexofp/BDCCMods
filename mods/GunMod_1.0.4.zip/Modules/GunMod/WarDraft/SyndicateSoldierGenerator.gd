extends CharacterGeneratorBase
class_name SyndicateSoldierGenerator

func pickCharacterType(character:DynamicCharacter, _args = {}):
	# CharacterType.Guard (rather than Generic) gets these soldiers the real
	# GuardLoot table (painkillers/energy drinks/restraints/etc.) instead of
	# falling through to the bare-bones generic default - Generic returned
	# credits only, which is why loot felt so thin. Also lets them roll the
	# pistol, since GunMod's PistolModWeaponsList already hooks into the
	# shared "guard"/"junkie" loot pools (rifles were deliberately kept off
	# those pools to stay rare, so this doesn't affect that).
	character.npcCharacterType = CharacterType.Guard

func pickName(character:DynamicCharacter, _args = {}):
	character.npcName = RNG.pick(["Syndicate Trooper", "Syndicate Raider", "Syndicate Marauder"])
	character.npcChatColorOverride = "#FF4040"

func pickSmallDescription(character:DynamicCharacter, _args = {}):
	return "One of the Syndicate's soldiers. "+str(.pickSmallDescription(character, _args))

func getAttacks():
	return ["GunModMarauderRifleAimedShotPCAttack", "trygetupattack"]

func getPossibleAttacks():
	return ["GunModMarauderRifleSprayFirePCAttack"]

func pickEquipment(character:DynamicCharacter, _args = {}):
	character.npcDefaultEquipment = ["SyndiHelmet", "SyndiArmor"]

func pickLevel(character:DynamicCharacter, _args = {}):
	.pickLevel(character, _args)
	if(GM.main.PS != null && GM.main.PS.id == "WarDraft"):
		character.npcLevel += Util.maxi(0, GM.main.PS.level - 1)
		character.getSkillsHolder().setLevel(character.npcLevel)
