extends SceneBase

var npcID:String = ""

func _init():
	sceneID = "WarDraftPatrolEncounterScene"

func _reactInit():
	GM.main.PS.warnIfNoWeapon()

	var theGenerator = GM.main.PS.getEnemySoldierGeneratorScript().new()
	var theChar:BaseCharacter = theGenerator.generate({NpcGen.Temporary: true})
	npcID = theChar.getID()
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "holdrifle", {npc=npcID, npcAction=["holdrifle", GM.main.PS.getEnemyWeaponModelPath()]})
	runScene("FightScene", [npcID, "WarDraftPatrol"], "encounterFight")

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _run():
	if(state == "lost_encounter"):
		playAnimation(StageScene.Duo, "defeat", {npc=npcID})

		saynn("Your legs give out and {npc.name} isn't in the mood to let that go to waste.")

		addButton("Continue", "See what happens next", "start_defeated_sex")

	if(state == "encounter_survived_sex"):
		removeCharacter(npcID)
		saynn("You manage to shove {npc.him} off and scramble back to your feet. Your ears are ringing but you're still standing. Still moving.")

		addButton("Continue", "Keep going", "endthescene")

	if(state == "encounter_captured"):
		removeCharacter(npcID)
		playAnimation(StageScene.Sleeping, "sleep")

		saynn("Everything goes dark before you even register losing.")

		addButton("Continue", "See what happens next", "go_captured")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_defeated_sex"):
		getCharacter(npcID).prepareForSexAsDom()
		runScene("GenericSexScene", [npcID, "pc", SexType.DefaultSex, {SexMod.SubMustGoUnconscious:true, SexMod.DisableDynamicJoiners:true}], "defeated_sex")
		return

	if(_action == "go_captured"):
		endScene()
		runScene(GM.main.PS.getCombatLossSceneID())
		return

	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "encounterFight"):
		processTime(10*60)
		var battlestate = _result[0]

		if(battlestate == "win"):
			if(GM.main.PS.defected):
				GM.main.PS.addCorruption(GM.main.PS.CorruptionPerObjective)
			else:
				GM.main.PS.addMorale(GM.main.PS.MoralePerObjective)
			GM.pc.addCredits(GM.main.PS.CreditsPerObjective)
			if(GM.main.PS.dropEnemyWeapon(GM.main.PS.EnemyWeaponDropChance, GM.main.PS.getEnemyWeaponID())):
				GM.main.PS.addMessage("You strip a fully-loaded "+GM.main.PS.getEnemyWeaponName()+" off the body.")
			removeCharacter(npcID)
			endScene()
		else:
			setState("lost_encounter")

	if(_tag == "defeated_sex"):
		var sexResult:SexEngineResult = _result[0]
		var gotUncon:bool = sexResult.isSubUnconscious("pc")

		if(gotUncon):
			setState("encounter_captured")
		else:
			setState("encounter_survived_sex")

func saveData():
	var data = .saveData()

	data["npcID"] = npcID

	return data

func loadData(data):
	.loadData(data)

	npcID = SAVE.loadVar(data, "npcID", "")
