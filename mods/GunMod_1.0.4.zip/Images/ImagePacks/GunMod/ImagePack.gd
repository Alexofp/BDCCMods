extends ImagePack

func _init():
	id = "gunmod"
	artist = "Adria"

	addCharacter("drask", [], "res://Images/ImagePacks/Rahi/Characters/drask.png")
	addCharacter("vex", [], "res://Images/ImagePacks/Rahi/Characters/vex.png")
