extends Module

func _init():
	id = "BullyBreeding"
	author = "Foreman"
	
	events = [
		"res://Modules/BullyBreeding/BullyBreedEvent.gd"
	]
