extends EventBase

func _init():
	id = "BullyBreedEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["BullyGangScene", "if_won"])

func run(_triggerID, _args):
	saynn("You might be able to snag one of the bullies to have your way before they all get away.")
	addButton("Snag the leader", "Assert dominance by having your way with the leader", "gymbully")
	addButton("Snag the quiet one", "The quiet one is pretty cute", "gymbully2")
	addButton("Snag the girl", "Looks like the girl wants to be bred", "gymbully3")

func onButton(_method, _args):
	if(_method in ["gymbully", "gymbully2", "gymbully3"]):
		GM.main.endCurrentScene()
		runScene("GenericSexScene", ["pc", _method, SexType.DefaultSex, {SexMod.DisableDynamicJoiners:true}])
