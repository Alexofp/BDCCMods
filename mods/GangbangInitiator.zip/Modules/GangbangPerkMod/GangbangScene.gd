extends "res://Scenes/SceneBase.gd"

# Generic version of the hand-authored gangbang scenes (see
# Modules/ArticaModule/c1Corruption/Tease/articaSlaveGangbangScene.gd for the
# original this is modeled on) - cycles through DP/spitroast/full-gangbang
# animation states with whoever's in the group, refreshing the pool once
# everyone's had a turn, until the player chooses to stop.

var targetID = "" # who this was originally started on, just for the opening line
var attackerIDs = [] # everyone you recruited, plus "pc"
var allParticipants = [] # attackerIDs + targetID - the full pool that can give or take
var currentReceiver = ""
var doerPool = []
var npc1 = ""
var npc2 = ""
var npc3 = ""
var didFirst = false
var lastScene = ""
var onlyCocksGlobal = true
var onlyStraponsGlobal = true
var receiverResistance: float = 0.0
var receiverFear: float = 0.0

func _init():
	sceneID = "GangbangPerkMod_GangbangScene"

func _initScene(_args = []):
	targetID = _args[0]
	attackerIDs = _args[1]
	allParticipants = attackerIDs.duplicate()
	allParticipants.append(targetID)
	currentReceiver = targetID

func resolveCustomCharacterName(_charID):
	if(_charID == "receiver"):
		return currentReceiver
	if(_charID == "npc1"):
		return npc1
	if(_charID == "npc2"):
		return npc2
	if(_charID == "npc3"):
		return npc3

# SceneBase (unlike PawnInteractionBase) has no sayLine() of its own - this
# mirrors PawnInteractionBase.sayLine() but resolves roles through this
# scene's own resolveCustomCharacterName() instead of getRoleID().
func sayLine(role:String, lineID:String, args:Dictionary):
	var processedArgs = {}
	for argID in args:
		processedArgs[argID] = resolveCustomCharacterName(args[argID])
	saynn("[say="+role+"]"+ModularDialogue.generate(lineID, processedArgs)+"[/say]")

func pickNextReceiver():
	var eligible = allParticipants.duplicate()
	if(eligible.size() > 1 && eligible.has(currentReceiver)):
		eligible.erase(currentReceiver)
	currentReceiver = RNG.pick(eligible)
	# Whatever they were wearing to top with last round shouldn't be in the
	# way now that it's their turn to receive.
	getCharacter(currentReceiver).removeStrapon()
	initReceiverSubStats()

# Same formula SexSubInfo.initFromPersonality() uses, computed once per
# receiver turn (that's also when the real system computes it - once per
# SexEngine session, not continuously).
func initReceiverSubStats():
	var character = getCharacter(currentReceiver)
	var personality:Personality = character.getPersonality()
	var bratiness = personality.getStat(PersonalityStat.Brat)

	receiverResistance = 0.0
	if(bratiness > 0.0):
		receiverResistance = RNG.randf_range(0.0, bratiness)
	if(character.getBuffsHolder().hasBuff(Buff.ActiveResistanceInSexBuff)):
		receiverResistance = 1.0

	receiverFear = 0.0
	if(character.isSlaveToPlayer()):
		receiverFear = character.getNpcSlavery().getFear()

func startNewDoerPool():
	doerPool = allParticipants.duplicate()
	doerPool.erase(currentReceiver)

func getNextDoer():
	# doerPool is reset fresh once per round in nextGang(), sized for
	# whatever that round type needs, so no mid-round refill is needed here.
	var result = RNG.grab(doerPool)
	ensureCanTop(result)
	return result

func ensureCanTop(_charID):
	var character = getCharacter(_charID)
	if(character.hasReachablePenis()):
		onlyStraponsGlobal = false
		return
	onlyCocksGlobal = false
	if(character.isWearingStrapon()):
		return
	var strapon = GlobalRegistry.createItem(RNG.pick(GlobalRegistry.getItemIDsByTag(ItemTag.Strapon)))
	var fluids = strapon.getFluids()
	fluids.addFluid("CumLube", RNG.randi_range(2, 5)*RNG.randf_range(80.0, 100.0))
	character.getInventory().forceEquipStoreOtherUnlessRestraint(strapon)

func addReceiverArousal(amount:float):
	getCharacter(currentReceiver).addArousal(amount)

func receiverOrgasm():
	getCharacter(currentReceiver).setArousal(0.3) # comes down a bit after finishing, doesn't reset to 0

# Same message as the real one (Game/MainScene.gd's
# _on_Player_orificeBecomeMoreLoose, normally only wired up for the player)
# instead of a raw number - fires for any receiver, not just the player.
func applyStretch(_bodypartSlot:String, _doerID:String, _mult:float = 1.0):
	var receiverChar = getCharacter(currentReceiver)
	if(!receiverChar.hasBodypart(_bodypartSlot)):
		return
	var bodypart = receiverChar.getBodypart(_bodypartSlot)
	var orifice = bodypart.getOrifice()
	if(orifice == null):
		return
	var oldLooseness = orifice.getLooseness()
	receiverChar.gotOrificeStretchedBy(_bodypartSlot, _doerID, false, _mult)
	if(orifice.getLooseness() > oldLooseness):
		var whoText:String = "Your" if currentReceiver == "pc" else receiverChar.getName()+"'s"
		addMessage(whoText+" "+bodypart.getOrificeName()+" is stretched and is now more used to the insertions")

func applyPrimaryHoleStretch(_doerID:String, _mult:float = 1.0):
	if(getCharacter(currentReceiver).hasVagina()):
		applyStretch(BodypartSlot.Vagina, _doerID, _mult)
	else:
		applyStretch(BodypartSlot.Anus, _doerID, _mult)

func applyOralStretch(_doerID:String, _mult:float = 1.0):
	applyStretch(BodypartSlot.Head, _doerID, _mult)

func addDoerAnger(_doerID:String, _amount:float):
	var doerPawn:CharacterPawn = GM.main.IS.getPawn(_doerID)
	if(doerPawn != null):
		doerPawn.addAnger(_amount)

func addDoerArousal(_doerID:String, _arousalAmount:float, _angerAmount:float):
	getCharacter(_doerID).addArousal(_arousalAmount)
	addDoerAnger(_doerID, _angerAmount)

# Matches SexDomInfo.getInfoString(): "Name. Anger: X% Arousal: Y%"
func getDoerStatLine(_charID:String) -> String:
	var character = getCharacter(_charID)
	var pawn:CharacterPawn = GM.main.IS.getPawn(_charID)
	var angerPercent:int = int(round((pawn.getAngerClamped() if pawn != null else 0.0)*100.0))
	return "[i]"+character.getName()+". Anger: "+str(angerPercent)+"% Arousal: "+str(int(round(character.getArousal()*100.0)))+"%[/i]"

# Matches SexSubInfo.getInfoString(): "Name. Resistance: X% Fear: Y% Arousal: Z% Consciousness: W%"
# plus extra lines the same way SexInfoBase.getInfoStringFinal() appends them ("\n - ...").
func getReceiverStatLine() -> String:
	var character = getCharacter(currentReceiver)
	var text:String = character.getName()+". Resistance: "+str(int(round(receiverResistance*100.0)))+"% Fear: "+str(int(round(receiverFear*100.0)))+"% Arousal: "+str(int(round(character.getArousal()*100.0)))+"% Consciousness: "+str(int(round(character.getConsciousness()*100.0)))+"%"

	return "[i]"+text+"[/i]"

func getRoundStatLines() -> String:
	var lines:Array = [getReceiverStatLine()]
	lines.append(getDoerStatLine(npc1))
	if(npc2 != ""):
		lines.append(getDoerStatLine(npc2))
	if(npc3 != ""):
		lines.append(getDoerStatLine(npc3))
	return Util.join(lines, "\n")

# Hooks into the game's real, generic tracking systems (there's no generic
# "corruption" stat outside a handful of story modules, so fetish + relationship
# lust are the actual systems every other sex scene in the game feeds).
func affectFetish(_charID:String, _fetishID:String, _amount:float = 0.05):
	getCharacter(_charID).getFetishHolder().addFetish(_fetishID, _amount)

func doerGivingFetish(_charID:String, _isVaginal:bool) -> String:
	var isStrap:bool = getCharacter(_charID).isWearingStrapon()
	if(_isVaginal):
		return Fetish.StraponSexVaginal if isStrap else Fetish.VaginalSexGiving
	return Fetish.StraponSexAnal if isStrap else Fetish.AnalSexGiving

func applyReceiverSusceptibility():
	# Being gangbanged and getting off on it makes someone more into the idea
	# next time - addLust feeds the exact same lust value the accept-chance
	# formula (agreeSexAsSub) and the roster gating already read. Doesn't
	# apply when the player themselves is the receiver this round.
	if(currentReceiver == "pc"):
		return
	GM.main.RS.addLust(currentReceiver, "pc", 0.05)

func nextGang():
	pickNextReceiver()
	startNewDoerPool()

	var possible = ["dp", "spit"]
	if(allParticipants.size() > 3):
		possible.append("gang")
	if(possible.has(lastScene)):
		possible.erase(lastScene)
	var nextSceneType = RNG.pick(possible)
	lastScene = nextSceneType

	if(!didFirst):
		setState(nextSceneType+"_tease")
	else:
		setState(nextSceneType+"_sex")
	npc1 = getNextDoer()
	npc2 = getNextDoer()
	if(nextSceneType == "gang"):
		npc3 = getNextDoer()
	else:
		npc3 = "" # otherwise it'd still hold whoever was in the last gang round

func cleanupAfterGangbang():
	for participantID in allParticipants:
		# processUntilTime() (called by updateCharacterUntilNow) only exists on
		# Character.gd, which NPCs extend - Player.gd doesn't, so it can't be
		# called for "pc" (which is always in allParticipants).
		if(participantID != "pc"):
			GM.main.updateCharacterUntilNow(participantID)
		getCharacter(participantID).removeStrapon()

func _run():
	if(state == ""):
		addCharacter(targetID)
		for attackerID in attackerIDs:
			if(attackerID != "pc"):
				addCharacter(attackerID)
		playAnimation(StageScene.Solo, "struggle", {pc=targetID, bodyState={naked=true}})

		saynn("The group closes in around {receiver.you}.. "+str(allParticipants.size())+" of you, ready to have your way with each other.")

		addButton("Start", "Time to have some fun", "start_gangbang")
		addButton("Cancel", "Not right now", "endthescene")
	if(state == "start_gangbang"):
		saynn("Everyone moves in.. {receiver.you} {receiver.youVerb('realize')} there's no getting out of this now.")

		addButton("Continue", "See what happens next", "start_first_scene")
	if(state == "dp_tease"):
		playAnimation(StageScene.SexDP, "tease", {pc=currentReceiver, npc=npc1, npc2=npc2, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		saynn("Two of the group close in. {npc1.You} {npc1.youVerb('slide')} underneath {receiver.you}, guiding {npc1.yourHis} {npc1.strapon} toward {receiver.yourHis} entrance, while {npc2.you} {npc2.youVerb('press')} in from behind, {npc2.yourHis} {npc2.strapon} lining up with {receiver.yourHis} other hole.")
		sayLine("receiver", "GangbangReceiverTease", {main="receiver", target="npc1"})
		applyStretch(BodypartSlot.Anus, npc1, 0.4)
		applyPrimaryHoleStretch(npc2, 0.4)
		addReceiverArousal(0.10)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "dp_sex")
	if(state == "dp_sex"):
		playAnimation(StageScene.SexDP, "sex", {pc=currentReceiver, npc=npc1, npc2=npc2, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		if(!didFirst):
			saynn("Both {npc1.strapon} and {npc2.strapon} push in at once, filling {receiver.you} from both ends.")
		else:
			saynn("A fresh pair pushes into {receiver.yourHis} already well-used holes.")
		sayLine("npc1", "GangbangDoerTaunt", {main="npc1", target="receiver"})
		applyStretch(BodypartSlot.Anus, npc1, 0.8)
		applyPrimaryHoleStretch(npc2, 0.8)
		addDoerArousal(npc1, 0.15, 0.03)
		addDoerArousal(npc2, 0.15, 0.03)
		addReceiverArousal(0.20)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "dp_sexfast")
	if(state == "dp_sexfast"):
		playAnimation(StageScene.SexDP, "fast", {pc=currentReceiver, npc=npc1, npc2=npc2, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		saynn("The pace quickens, {receiver.you} {receiver.youVerb('get')} pounded from both sides at once, barely able to keep up.")
		applyStretch(BodypartSlot.Anus, npc1, 1.3)
		applyPrimaryHoleStretch(npc2, 1.3)
		addDoerArousal(npc1, 0.20, 0.05)
		addDoerArousal(npc2, 0.20, 0.05)
		addReceiverArousal(0.25)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "dp_cum")
	if(state == "dp_cum"):
		playAnimation(StageScene.SexDP, "inside", {pc=currentReceiver, npc=npc1, npc2=npc2, pcCum=true, npcCum=true, npc2Cum=true, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		saynn("{npc1.You} and {npc2.you} finish deep inside {receiver.you} at almost the same time.")
		sayLine("receiver", "GangbangReceiverCum", {main="receiver", target="npc1"})
		receiverOrgasm()
		saynn(getRoundStatLines())
		addNextGangButton()
	if(state == "spit_tease"):
		playAnimation(StageScene.SexSpitroast, "tease", {pc=currentReceiver, npc=npc1, npc2=npc2, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		saynn("{npc1.You} {npc1.youAre} holding {receiver.yourHis} legs, {npc1.yourHis} {npc1.strapon} brushing against {receiver.yourHis} entrance. {npc2.You} {npc2.youAre} holding {receiver.yourHis} head, {npc2.yourHis} {npc2.strapon} resting on {receiver.yourHis} lips.")
		sayLine("receiver", "GangbangReceiverTease", {main="receiver", target="npc1"})
		applyPrimaryHoleStretch(npc1, 0.4)
		applyOralStretch(npc2, 0.4)
		addReceiverArousal(0.10)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "spit_sex")
	if(state == "spit_sex"):
		playAnimation(StageScene.SexSpitroast, "sex", {pc=currentReceiver, npc=npc1, npc2=npc2, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		if(!didFirst):
			saynn("Both push in together, stuffing {receiver.you} from both ends, stealing {receiver.yourHis} ability to talk or breathe right.")
		else:
			saynn("A fresh set of {npc1.strapon} and {npc2.strapon} fill {receiver.yourHis} mouth and hole once again.")
		sayLine("npc1", "GangbangDoerTaunt", {main="npc1", target="receiver"})
		applyPrimaryHoleStretch(npc1, 0.8)
		applyOralStretch(npc2, 0.8)
		addDoerArousal(npc1, 0.15, 0.03)
		addDoerArousal(npc2, 0.15, 0.02)
		addReceiverArousal(0.20)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "spit_sexfast")
	if(state == "spit_sexfast"):
		playAnimation(StageScene.SexSpitroast, "fast", {pc=currentReceiver, npc=npc1, npc2=npc2, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		saynn("Muffled noises spill out of {receiver.you} as {receiver.youAre} worked from both ends, faster and faster.")
		applyPrimaryHoleStretch(npc1, 1.3)
		applyOralStretch(npc2, 1.3)
		addDoerArousal(npc1, 0.20, 0.05)
		addDoerArousal(npc2, 0.20, 0.03)
		addReceiverArousal(0.25)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "spit_cum")
	if(state == "spit_cum"):
		playAnimation(StageScene.SexSpitroast, "inside", {pc=currentReceiver, npc=npc1, npc2=npc2, pcCum=true, npcCum=true, npc2Cum=true, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}})
		saynn("{npc1.You} and {npc2.you} both finish at once, filling {receiver.yourHis} hole and mouth.")
		sayLine("receiver", "GangbangReceiverCum", {main="receiver", target="npc1"})
		receiverOrgasm()
		saynn(getRoundStatLines())
		addNextGangButton()
	if(state == "gang_tease"):
		playAnimation(StageScene.SexGangbang, "tease", {pc=currentReceiver, npc2=npc1, npc=npc2, npc3=npc3, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}, npc3BodyState={exposedCrotch=true,hard=true}})
		saynn("{receiver.You} {receiver.youAre} forced onto all fours as three of the group line up. {npc1.You} {npc1.youAre} underneath, {npc2.you} behind, {npc3.you} in front, all three {npc1.strapon}s already aligned with {receiver.yourHis} holes.")
		sayLine("receiver", "GangbangReceiverTease", {main="receiver", target="npc1"})
		applyPrimaryHoleStretch(npc1, 0.4)
		applyStretch(BodypartSlot.Anus, npc2, 0.4)
		applyOralStretch(npc3, 0.4)
		addReceiverArousal(0.15)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "gang_sex")
	if(state == "gang_sex"):
		playAnimation(StageScene.SexGangbang, "sex", {pc=currentReceiver, npc2=npc1, npc=npc2, npc3=npc3, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}, npc3BodyState={exposedCrotch=true,hard=true}})
		if(!didFirst):
			saynn("All three push in together, filling {receiver.you} from every angle at once.")
		else:
			saynn("A fresh trio takes over, ramming into {receiver.yourHis} used holes without giving {receiver.youHim} a moment to recover.")
		sayLine("npc1", "GangbangDoerTaunt", {main="npc1", target="receiver"})
		applyPrimaryHoleStretch(npc1, 0.8)
		applyStretch(BodypartSlot.Anus, npc2, 0.8)
		applyOralStretch(npc3, 0.8)
		addDoerArousal(npc1, 0.15, 0.03)
		addDoerArousal(npc2, 0.15, 0.03)
		addDoerArousal(npc3, 0.15, 0.02)
		addReceiverArousal(0.30)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "gang_sexfast")
	if(state == "gang_sexfast"):
		playAnimation(StageScene.SexGangbang, "fast", {pc=currentReceiver, npc2=npc1, npc=npc2, npc3=npc3, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}, npc3BodyState={exposedCrotch=true,hard=true}})
		saynn("{receiver.You} {receiver.youAre} pounded from every side, the whole group working {receiver.you} over at once.")
		applyPrimaryHoleStretch(npc1, 1.3)
		applyStretch(BodypartSlot.Anus, npc2, 1.3)
		applyOralStretch(npc3, 1.3)
		addDoerArousal(npc1, 0.20, 0.05)
		addDoerArousal(npc2, 0.20, 0.05)
		addDoerArousal(npc3, 0.20, 0.03)
		addReceiverArousal(0.35)
		saynn(getRoundStatLines())
		addButton("Continue", "See what happens next", "gang_cum")
	if(state == "gang_cum"):
		playAnimation(StageScene.SexGangbang, "inside", {pc=currentReceiver, npc2=npc1, npc=npc2, npc3=npc3, pcCum=true, npcCum=true, npc2Cum=true, bodyState={naked=true, hard=true}, npcBodyState={exposedCrotch=true,hard=true}, npc2BodyState={exposedCrotch=true,hard=true}, npc3BodyState={exposedCrotch=true,hard=true}})
		saynn("All three finish together, filling {receiver.you} up from every side at once.")
		sayLine("receiver", "GangbangReceiverCum", {main="receiver", target="npc1"})
		receiverOrgasm()
		saynn(getRoundStatLines())
		addNextGangButton()
	if(state == "after_gangbang"):
		saynn("Once everyone's finally had their fill, the group starts untangling itself, everyone thoroughly spent and covered in "+str("fake seed" if onlyStraponsGlobal else ("seed" if onlyCocksGlobal else "seed and fake seed"))+".")
		addButton("Enough", "That was fun", "endthescene")

func addNextGangButton():
	saynn("The group doesn't look done just yet..")
	addButton("Continue", "Keep going", "start_next_scene")
	addButton("Enough", "Wrap it up here", "end_gangbang")

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "start_first_scene"):
		nextGang()
		return

	if(_action == "start_next_scene"):
		processTime(5*60)
		didFirst = true
		nextGang()
		return

	if(_action == "end_gangbang"):
		processTime(3*60)
		cleanupAfterGangbang()
		setState("after_gangbang")
		return

	if(_action in ["dp_sex", "dp_sexfast", "spit_sex", "spit_sexfast", "gang_sex", "gang_sexfast"]):
		processTime(5*60)

	if(_action == "dp_cum"):
		processTime(5*60)
		getCharacter(currentReceiver).cummedInAnusBy(npc1)
		affectFetish(npc1, doerGivingFetish(npc1, false))
		affectFetish(currentReceiver, Fetish.AnalSexReceiving)
		if(getCharacter(currentReceiver).hasVagina()):
			getCharacter(currentReceiver).cummedInVaginaBy(npc2)
			affectFetish(npc2, doerGivingFetish(npc2, true))
			affectFetish(currentReceiver, Fetish.VaginalSexReceiving)
		else:
			getCharacter(currentReceiver).cummedInAnusBy(npc2)
			affectFetish(npc2, doerGivingFetish(npc2, false))
			affectFetish(currentReceiver, Fetish.AnalSexReceiving)
		applyReceiverSusceptibility()

	if(_action == "spit_cum"):
		processTime(5*60)
		if(getCharacter(currentReceiver).hasVagina()):
			getCharacter(currentReceiver).cummedInVaginaBy(npc1)
			affectFetish(npc1, doerGivingFetish(npc1, true))
			affectFetish(currentReceiver, Fetish.VaginalSexReceiving)
		else:
			getCharacter(currentReceiver).cummedInAnusBy(npc1)
			affectFetish(npc1, doerGivingFetish(npc1, false))
			affectFetish(currentReceiver, Fetish.AnalSexReceiving)
		getCharacter(currentReceiver).cummedInMouthBy(npc2)
		affectFetish(npc2, Fetish.OralSexGiving)
		affectFetish(currentReceiver, Fetish.OralSexReceiving)
		applyReceiverSusceptibility()

	if(_action == "gang_cum"):
		processTime(5*60)
		if(getCharacter(currentReceiver).hasVagina()):
			getCharacter(currentReceiver).cummedInVaginaBy(npc1)
			affectFetish(npc1, doerGivingFetish(npc1, true))
			affectFetish(currentReceiver, Fetish.VaginalSexReceiving)
		else:
			getCharacter(currentReceiver).cummedInAnusBy(npc1)
			affectFetish(npc1, doerGivingFetish(npc1, false))
			affectFetish(currentReceiver, Fetish.AnalSexReceiving)
		getCharacter(currentReceiver).cummedInAnusBy(npc2)
		affectFetish(npc2, doerGivingFetish(npc2, false))
		affectFetish(currentReceiver, Fetish.AnalSexReceiving)
		getCharacter(currentReceiver).cummedInMouthBy(npc3)
		affectFetish(npc3, Fetish.OralSexGiving)
		affectFetish(currentReceiver, Fetish.OralSexReceiving)
		applyReceiverSusceptibility()

	setState(_action)

func saveData():
	var data = .saveData()

	data["targetID"] = targetID
	data["attackerIDs"] = attackerIDs
	data["allParticipants"] = allParticipants
	data["currentReceiver"] = currentReceiver
	data["doerPool"] = doerPool
	data["receiverResistance"] = receiverResistance
	data["receiverFear"] = receiverFear
	data["npc1"] = npc1
	data["npc2"] = npc2
	data["npc3"] = npc3
	data["didFirst"] = didFirst
	data["lastScene"] = lastScene
	data["onlyCocksGlobal"] = onlyCocksGlobal
	data["onlyStraponsGlobal"] = onlyStraponsGlobal

	return data

func loadData(data):
	.loadData(data)

	targetID = SAVE.loadVar(data, "targetID", "")
	attackerIDs = SAVE.loadVar(data, "attackerIDs", [])
	allParticipants = SAVE.loadVar(data, "allParticipants", [])
	currentReceiver = SAVE.loadVar(data, "currentReceiver", targetID)
	doerPool = SAVE.loadVar(data, "doerPool", [])
	receiverResistance = SAVE.loadVar(data, "receiverResistance", 0.0)
	receiverFear = SAVE.loadVar(data, "receiverFear", 0.0)
	npc1 = SAVE.loadVar(data, "npc1", "")
	npc2 = SAVE.loadVar(data, "npc2", "")
	npc3 = SAVE.loadVar(data, "npc3", "")
	didFirst = SAVE.loadVar(data, "didFirst", false)
	lastScene = SAVE.loadVar(data, "lastScene", "")
	onlyCocksGlobal = SAVE.loadVar(data, "onlyCocksGlobal", true)
	onlyStraponsGlobal = SAVE.loadVar(data, "onlyStraponsGlobal", true)
