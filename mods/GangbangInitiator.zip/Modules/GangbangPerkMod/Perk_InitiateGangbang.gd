extends PerkBase

const PerkID = "GB_InitiateGangbang"

func _init():
	id = PerkID
	skillGroup = Skill.SexSlave

func getVisibleName():
	return "Gangbang Initiator"

func getVisibleDescription():
	return "You've learned how to properly organize a gangbang. While talking to someone, you can ask them to join a group you're putting together, then call everyone in once you've got enough people."

func getSkillTier():
	return 2 # Sex Slave's 3rd tier, unlocks at skill level 10 (see SexSlave.gd getPerkTiers())

func getPicture():
	return "res://Images/Perks/gangbang.png"
