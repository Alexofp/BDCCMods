extends Module

func _init():
	id = "GangbangPerkMod"
	author = "YourNameHere"

	perks = [
		"res://Modules/GangbangPerkMod/Perk_InitiateGangbang.gd",
	]

	statusEffects = [
		"res://Modules/GangbangPerkMod/StatusEffect_GangbangActive.gd",
	]

	scenes = [
		"res://Modules/GangbangPerkMod/GangbangScene.gd",
	]

	# NOTE: this mod also depends on files living outside this folder, all
	# need to be included when packaging with ModMaker:
	#  - Game/InteractionSystem/Interactions/Talking.gd (search it for
	#    "GANGBANG MOD") - a FULL-FILE OVERRIDE of a core script, since its
	#    options aren't reachable through the normal mod registry. Will
	#    conflict with any future base-game change to Talking.gd, or another
	#    mod that also touches it.
	#  - Game/ModularDialogue/FormBanks/GangbangPerkModFormBank.gd and
	#    Game/ModularDialogue/Fillers/GangbangPerkMod*.gd (4 files: Default,
	#    ShySubby, Mean, Dommy) - these are ADDITIVE, not overrides.
	#    registerAllFormBanks()/registerAllFillers() just load every file in
	#    those folders, so these are normal, low-risk mod files - they just
	#    have to physically live at those res:// paths for the scan to find
	#    them.

func getFlags():
	return {
		"Roster": flag(FlagType.Anything), # Array of recruited character IDs
	}
