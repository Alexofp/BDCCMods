extends StatusEffectBase

const EffectID = "GB_GangbangActive"

func _init():
	id = EffectID

func getEffectName():
	return "Gangbang Planned"

func getEffectDesc():
	var roster:Array = GM.main.getFlag("GangbangPerkMod.Roster", [])
	return "You currently have a gangbang active of "+str(roster.size())+" people!\nTalk to one of them again to start it or keep recruiting."

func getEffectImage():
	return "res://Images/Perks/gangbang.png"

func getIconColor():
	return IconColorPurple
