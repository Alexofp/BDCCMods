extends DialogueFormBank

# Modules/GangbangPerkMod: additive-only file, doesn't override anything -
# registerAllFormBanks() just loads every file under this folder, so a mod
# can drop a new one in here without touching Default.gd.

func getForms() -> Dictionary:
	return {
		"TalkGangbangAsk": form("Hey, want to join a little group I'm putting together? Could be a lot of fun.", {main=CHAR, target=CHAR}, "main", "target"),
		"TalkGangbangAccept": form("Sure, count me in.", {main=CHAR, target=CHAR}, "main", "target"),
		"TalkGangbangDeny": form("I'd rather not, sorry.", {main=CHAR, target=CHAR}, "main", "target"),

		"GangbangReceiverTease": form("Ah.. w-wait..", {main=CHAR, target=CHAR}, "main", "target"),
		"GangbangReceiverCum": form("Ah! I'm.. cumming!..", {main=CHAR, target=CHAR}, "main", "target"),
		"GangbangDoerTaunt": form("Take it.", {main=CHAR, target=CHAR}, "main", "target"),
	}
