extends DialogueFiller

# Modules/GangbangPerkMod: mirrors Mean.gd's gate (meanness >= 0.4) and
# priority, but only for the gangbang form IDs.

func _init():
	priority = 12

func getFormIDs() -> Array:
	return [
		"TalkGangbangAsk",
		"TalkGangbangAccept",
		"TalkGangbangDeny",
		"GangbangReceiverTease",
		"GangbangReceiverCum",
		"GangbangDoerTaunt",
	]

func canBeUsed(_id:String, _args:Dictionary, _form) -> bool:
	var theChar = getChar(_args, _form.mainRole)
	var personality:Personality = theChar.getPersonality()
	var meanness = personality.getStat(PersonalityStat.Mean)

	if(meanness < 0.4):
		return false

	return true

func getText(_id:String, _args:Dictionary):
	if(_id == "TalkGangbangAsk"):
		return [
			"Get your ass over here, [[SLUT]]. You're joining my group whether you like it or not.",
			"I'm putting a group together to wreck you. Don't fucking disappoint me.",
			"Shut up and listen. I've got a few others lined up and you're next, [[SLUT]].",
			"I need a few more fuckholes for my group. Congratulations, you volunteered.",
			"You're joining in with the others, and you're gonna fucking love it.",
		]
	if(_id == "TalkGangbangAccept"):
		return [
			"Fine, fuck it, I'm in. Try not to bore me.",
			"Sure, whatever gets me some action. Let's get this shit over with.",
			"I'm in. Don't waste my fucking time though.",
			"Yeah, count me in. Let's fucking go.",
		]
	if(_id == "TalkGangbangDeny"):
		return [
			"Fuck no. Ask someone else, loser.",
			"Not interested, dumbass. Piss off.",
			"Hard pass. Don't fucking ask me again.",
			"No. Get the fuck away from me.",
		]
	if(_id == "GangbangReceiverTease"):
		return [
			"Fuck.. get on with it already.",
			"Tch.. is this all you've got?",
			"Come on, quit teasing, [[SLUT]].",
		]
	if(_id == "GangbangReceiverCum"):
		return [
			"Fuck! Fine, you win this round..",
			"Ugh.. fuck, there it is..",
			"Shit.. don't you dare stop..",
		]
	if(_id == "GangbangDoerTaunt"):
		return [
			"Shut up and take it, [[SLUT]].",
			"Yeah, that's it, moan for me.",
			"Fucking take all of it.",
		]
