extends DialogueFiller

# Modules/GangbangPerkMod: additive-only file, mirrors DefaultFiller.gd's role
# (baseline variety, always applicable) but only for the gangbang form IDs -
# doesn't touch DefaultFiller.gd itself.

func getFormIDs() -> Array:
	return [
		"TalkGangbangAsk",
		"TalkGangbangAccept",
		"TalkGangbangDeny",
		"GangbangReceiverTease",
		"GangbangReceiverCum",
		"GangbangDoerTaunt",
	]

func getText(_id:String, _args:Dictionary):
	if(_id == "TalkGangbangAsk"):
		return [
			"Want to join in on something fun with a few others?",
			"I'm putting a group together.. you interested?",
			"How about joining a few of us for some fun?",
			"Fancy joining in with a group of us?",
		]
	if(_id == "TalkGangbangAccept"):
		return [
			"Sure, sounds fun.",
			"Yeah, I'm in.",
			"Alright, count me in.",
			"Sounds good to me.",
		]
	if(_id == "TalkGangbangDeny"):
		return [
			"Not really my thing, sorry.",
			"I'll pass on that.",
			"Maybe another time.",
			"Not today, sorry.",
		]
	if(_id == "GangbangReceiverTease"):
		return [
			"Ah.. w-wait..",
			"Oh.. here we go..",
			"Mm.. easy..",
			"Ah, already?..",
		]
	if(_id == "GangbangReceiverCum"):
		return [
			"Ah! I'm.. cumming!..",
			"Oh! Right there.. ah!",
			"Mm! I'm.. so close..",
			"Ah.. ah.. yes!..",
		]
	if(_id == "GangbangDoerTaunt"):
		return [
			"Take it.",
			"You like that, don't you.",
			"Relax, we're just getting started.",
			"Good, keep going like that.",
		]
