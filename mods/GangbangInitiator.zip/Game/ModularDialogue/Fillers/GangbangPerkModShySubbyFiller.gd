extends DialogueFiller

# Modules/GangbangPerkMod: mirrors ShySubby.gd's gate (meanness <= 0.2 and
# subby > 0.5) and priority, but only for the gangbang form IDs.

func _init():
	priority = 10

func getFormIDs() -> Array:
	return [
		"TalkGangbangAsk",
		"TalkGangbangAccept",
		"TalkGangbangDeny",
		"GangbangReceiverTease",
		"GangbangReceiverCum",
		"GangbangDoerTaunt",
	]

func canBeUsed(_id:String, _args:Dictionary, _form) -> bool:
	var theChar = getChar(_args, _form.mainRole)
	var personality:Personality = theChar.getPersonality()
	var meanness = personality.getStat(PersonalityStat.Mean)
	var subby = personality.getStat(PersonalityStat.Subby)

	if(meanness > 0.2):
		return false
	if(subby <= 0.5):
		return false

	return true

func getText(_id:String, _args:Dictionary):
	if(_id == "TalkGangbangAsk"):
		return [
			"Um.. w-would you maybe want to join a little group.. with some others..?",
			"I-I was thinking of getting a few people together.. would you like to join..?",
			"M-Maybe you'd want to join in.. with some others too..?",
		]
	if(_id == "TalkGangbangAccept"):
		return [
			"O-Okay.. I'll join in..",
			"Um.. sure, I-I don't mind..",
			"I-I guess I could join.. if that's okay..",
			"Y-Yeah.. I'll go along with it..",
		]
	if(_id == "TalkGangbangDeny"):
		return [
			"I-I don't think I could handle that many.. sorry..",
			"U-Um.. that's a bit much for me.. sorry..",
			"S-Sorry.. I don't think I'm ready for that..",
		]
	if(_id == "GangbangReceiverTease"):
		return [
			"A-ah.. p-please be gentle..",
			"Um.. I-I've never done this with so many..",
			"Eep.. t-that's a lot of hands..",
		]
	if(_id == "GangbangReceiverCum"):
		return [
			"Ah-h! I-I'm cumming.. sorry..",
			"Nh-h.. it's too much.. ah!",
			"Ah.. p-please.. I'm gonna..",
		]
	if(_id == "GangbangDoerTaunt"):
		return [
			"Y-you're doing so well.. I promise..",
			"I-I'll be gentle.. I think..",
			"Um.. i-is this okay..?",
		]
