extends DialogueFiller

# Modules/GangbangPerkMod: mirrors Dommy.gd's gate (subby <= -0.4) and
# priority, but only for the gangbang form IDs.

func _init():
	priority = 14

func getFormIDs() -> Array:
	return [
		"TalkGangbangAsk",
		"TalkGangbangAccept",
		"TalkGangbangDeny",
		"GangbangReceiverTease",
		"GangbangReceiverCum",
		"GangbangDoerTaunt",
	]

func canBeUsed(_id:String, _args:Dictionary, _form) -> bool:
	var theChar = getChar(_args, _form.mainRole)
	var personality:Personality = theChar.getPersonality()
	var subby = personality.getStat(PersonalityStat.Subby)

	if(subby > -0.4):
		return false

	return true

func getText(_id:String, _args:Dictionary):
	if(_id == "TalkGangbangAsk"):
		return [
			"I'm arranging a little group. You're welcome to join, if you can keep up.",
			"How about you join a group I'm putting together? Could be entertaining.",
			"I'm gathering a few people for some fun. Interested?",
		]
	if(_id == "TalkGangbangAccept"):
		return [
			"Sure, I'll join. Just know I like being in control.",
			"I'm in, but don't expect me to be a pushover.",
			"Count me in. I'll make it interesting.",
		]
	if(_id == "TalkGangbangDeny"):
		return [
			"Not interested in sharing the spotlight, sorry.",
			"I'll pass. Group scenes aren't really my style.",
			"No thanks, I prefer to be the one in charge.",
		]
	if(_id == "GangbangReceiverTease"):
		return [
			"Is that the best you've got? Impress me.",
			"Mm, I'll allow this.. for now.",
			"Careful, I bite back.",
		]
	if(_id == "GangbangReceiverCum"):
		return [
			"Hah.. good, that's exactly what I wanted.",
			"Mm, right on schedule.",
			"There we go.. was that so hard?",
		]
	if(_id == "GangbangDoerTaunt"):
		return [
			"Good. Now beg for more.",
			"That's it, exactly like that.",
			"You'll thank me for this later.",
		]
