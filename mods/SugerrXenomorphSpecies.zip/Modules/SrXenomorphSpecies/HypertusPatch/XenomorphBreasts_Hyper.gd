extends "res://Modules/Z_Hypertus/Misc/ModBodypartBreasts.gd"

func _init():
	visibleName = "hyperable xenomorph breasts"
	id = "sugerrxenobreastshyperable"
	size = breastSizeModClass.G

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return breastSizeModClass.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= breastSizeModClass.FLAT):
		return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphBreastsFlat/BreastsFlat.tscn"
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphBreastsScaleable/BreastsScaleable.tscn"

func getTraits():
	return {
		"Hyperable": true,
	}
	
func getVulgarName() -> String:
	return "female breasts"

func getAVulgarName() -> String:
	return getVulgarName()
