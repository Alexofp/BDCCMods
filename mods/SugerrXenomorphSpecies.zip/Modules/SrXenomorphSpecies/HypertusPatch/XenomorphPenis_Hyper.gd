extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "hyperable xenomorph penis"
	id = "sugerrxenopenishyperable"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphPenis/XenomorphPenis.tscn"

func generateRandomColors(_dynamicCharacter):
	pass

func getVulgarName() -> String:
	return "cock"
	
func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"
