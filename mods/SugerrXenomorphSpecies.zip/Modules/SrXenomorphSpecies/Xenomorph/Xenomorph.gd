extends Species

func _init():
	id = "sugerrxenomorph"

func isPlayable():
	return true

func getVisibleName():
	return "Xenomorph"

func getVisibleDescription():
	return "Long flaccid heads"

func getDefaultLegs(_gender):
	return "sugerrxenolegs"

func getDefaultTail(_gender):
	return "sugerrxenotail"

func getDefaultHead(_gender):
	return "sugerrxenoheadv1ipless"

func getDefaultArms(_gender):
	return "sugerrxenoarms"
	
func getDefaultHorns(_gender):
	return "sugerrxenobackheadv1"

func getDefaultEars(_gender):
	return "sugerrxenoears"
	
func getDefaultBody(_gender):
		return "sugerrxenobodyv1"
	
		
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "sugerrxenomalebreasts"
	else: 
		return "sugerrxenobreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sugerrxenopenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]

func generateSkinColors():
	var tonestest = [
		#Note: If the primary color is too light or dark it not match with the back part of the head
		
		["#16161A", "#27272E", "#22222E"],  # Blueish
		["#151C19", "#232829", "#172325"],  # Turquoiseish
		["#181C18", "#202916", "#1a1f1d"],  # Greenish
		["#1C181C", "#2E272D", "#241723"],  # Purpleish
		#Accents
		["#1c1617", "#be453a", "#160d0f"],  # red
		["#1c1916", "#d0843b", "#16110d"],  # orange
		["#18161c", "#dee774", "#120d16"],  # yellow
		["#1c161c", "#60d03b", "#160d16"],  # green
		["#18161c", "#3b97d0", "#120d16"],  # blue
		["#1c191c", "#9963c6", "#150d18"],  # purple
		["#1f171d", "#c77cd4", "#16110d"],  # pink
		#Accents - Dark
		["#1c1617", "#340e0a", "#160d0f"],  # red
		["#1c1916", "#5c3612", "#16110d"],  # orange
		["#18161c", "#484d0b", "#120d16"],  # yellow
		["#1c161c", "#215011", "#160d16"],  # green
		["#18161c", "#0f3a55", "#120d16"],  # blue
		["#1c191c", "#461173", "#150d18"],  # purple
		["#1f171d", "#601f6c", "#16110d"],  # pink
		# Mix
		["#18181F", "#161d36", "#12141a"],  # blue
		["#18181F", "#afbe3a", "#1b1a30"],  # blue-yellow
		["#18141a", "#302a51", "#1d0914"],  # purple
		["#17141a", "#70f108", "#0c131a"],  # Saturated green
	]
	
	var randomSkinTone = RNG.pick(tonestest)
	return [Color(randomSkinTone[0]), Color(randomSkinTone[1]), Color(randomSkinTone[2])]
	

