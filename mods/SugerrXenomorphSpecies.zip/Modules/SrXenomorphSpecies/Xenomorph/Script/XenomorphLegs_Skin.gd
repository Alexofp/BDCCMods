extends BodypartLeg

func _init():
	visibleName = "xenomorph legs (skin)"
	id = "sugerrxenolegsskin"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphLegs/XenomorphLegs_Skin.tscn"
	
func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
	
