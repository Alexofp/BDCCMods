extends BodypartBody

func _init():
	visibleName = "Xenomorph body v1"
	id = "sugerrxenobodyv1"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphBodyV1/XenomorphBody.tscn"

func getVulgarName() -> String:
	return "alien body"

func getAVulgarName() -> String:
	return "an alien body"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
