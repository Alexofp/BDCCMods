extends BodypartHead

func _init():
	visibleName = "xenomorph head v1 (lipless)"
	id = "sugerrxenoheadv1ipless"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphHeadV1Lipless/XenomorphHead.tscn"
	
func getHeadLength():
	return 0.55
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
