extends BodypartBody

func _init():
	visibleName = "Xenomorph body v2 (skin)"
	id = "sugerrxenobodyv2skin"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphBodyV2/XenomorphBody_Skin.tscn"

func getVulgarName() -> String:
	return "alien body"

func getAVulgarName() -> String:
	return "an alien body"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
