extends BodypartPenis

func _init():
	visibleName = "xenomorph penis"
	id = "sugerrxenopenis"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphPenis/XenomorphPenis1.tscn"

func generateRandomColors(_dynamicCharacter):
	pass

func getVulgarName() -> String:
	return "cock"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
