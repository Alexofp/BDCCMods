extends BodypartPenis

func _init():
	visibleName = "xenomorph penis"
	id = "sugerrxenopenis"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphPenis/XenomorphPenis.tscn"

func generateRandomColors(_dynamicCharacter):
	pass
	
func getLewdAdjective():
	return RNG.pick(["big", "xenomorph"])

func getVulgarName() -> String:
	return "xenomorph cock"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
