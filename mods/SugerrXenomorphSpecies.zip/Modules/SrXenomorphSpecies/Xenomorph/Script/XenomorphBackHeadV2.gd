extends BodypartHorns

func _init():
	visibleName = "xenomorph forehead v2"
	id = "sugerrxenobackheadv2"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphBackHeadV2/XenomorphBackHead.tscn"

func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func generateRandomColors(_dynamicCharacter):
	var theHue = pickedRColor
	if(_dynamicCharacter != null):
		theHue = _dynamicCharacter.pickedSkinRColor.h
	pickedRColor = Color.from_hsv(theHue, RNG.randf_range(0.1, 0.1), RNG.randf_range(0.1, 0.1))
	pickedGColor = pickedGColor
	pickedBColor = pickedBColor
