extends BodypartArms

func _init():
	visibleName = "xenomorph buff arms"
	id = "sugerrxenobuffarms"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphArmsBuff/BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
