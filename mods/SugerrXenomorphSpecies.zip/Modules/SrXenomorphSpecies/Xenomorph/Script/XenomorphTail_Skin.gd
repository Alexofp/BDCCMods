extends BodypartTail

func _init():
	visibleName = "xenomorph tail (skin)"
	id = "sugerrxenotailskin"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["segmented", "alien"])

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphTail/XenomorphTail_Skin.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
