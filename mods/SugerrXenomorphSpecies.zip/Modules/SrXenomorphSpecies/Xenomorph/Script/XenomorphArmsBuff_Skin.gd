extends BodypartArms

func _init():
	visibleName = "xenomorph buff arms (skin)"
	id = "sugerrxenobuffarmsskin"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphArmsBuff/BuffArms_Skin.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
