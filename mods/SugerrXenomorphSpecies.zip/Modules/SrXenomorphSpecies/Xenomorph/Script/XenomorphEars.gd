extends BodypartEars

func _init():
	visibleName = "xenomorph ears"
	id = "sugerrxenoears"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return null
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
