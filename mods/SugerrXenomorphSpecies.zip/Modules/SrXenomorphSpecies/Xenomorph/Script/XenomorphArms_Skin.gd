extends BodypartArms

func _init():
	visibleName = "xenomorph arms (skin)"
	id = "sugerrxenoarmsskin"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphArms/XenomorphArms_Skin.tscn"
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
