extends BodypartLeg

func _init():
	visibleName = "xenomorph legs"
	id = "sugerrxenolegs"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphLegs/XenomorphLegs.tscn"
	
func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
	
