extends BodypartHead

func _init():
	visibleName = "xenomorph head v1 (Skin)"
	id = "sugerrxenoheadv1skin"

func getCompatibleSpecies():
	return ["sugerrxenomorph"]

func getDoll3DScene():
	return "res://Modules/SrXenomorphSpecies/Xenomorph/PNG/XenomorphHeadV1/XenomorphHead_Skin.tscn"
	
func getHeadLength():
	return 0.55
	
func getCharacterCreatorDesc():
	return "(Art by Sugerør, Xenomorph Species)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
