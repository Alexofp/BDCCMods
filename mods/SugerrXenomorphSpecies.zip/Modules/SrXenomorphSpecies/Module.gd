extends Module

func _init():
	id = "sugerrxenospecies"
	author = "Sugerør"
	
	species = [
		"res://Modules/SrXenomorphSpecies/Xenomorph/Xenomorph.gd",

	]
	bodyparts = [
		#Xenomorph
		# - head
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV1.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV1_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV1Lipless.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV1Lipless_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBackHeadV1.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV2.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV2_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV2Lipless.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphHeadV2Lipless_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBackHeadV2.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphEars.gd",
		# - Body
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBodyV1.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBodyV1_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBodyV2.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBodyV2_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBreasts.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphBreastsMale.gd",
		# - Arms
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphArms.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphArms_Skin.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphArmsBuff.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphArmsBuff_Skin.gd",
		# - Legs
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphLegs.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphLegs_Skin.gd",
		# - Tail
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphTail.gd",
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphTail_Skin.gd",
		# - Penis
		"res://Modules/SrXenomorphSpecies/Xenomorph/Script/XenomorphPenis.gd",
	]
