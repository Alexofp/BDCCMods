extends ItemBase

func _init():
	id = "CowbellCollar"

func getVisibleName():
	return "Cowbell Collar"

func getDescription():
	return "A cowprint collar with a cowbell on the front."

func getClothingSlot():
	return InventorySlot.Neck

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"neck": "res://Modules/MoreCowClothesModule/CowbellCollar/CowbellCollar.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your neck"
	else:
		return "take off your neck"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your neck"
	else:
		return "put on your neck"

func getPrice():
	return 50

func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SoldByGeneralVendomat,
		ItemTag.AllowsEnslaving,
		]

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Vitality, 55]),
		buff(Buff.StatBuff, [Stat.Sexiness, 60]),
		buff(Buff.FertilityBuff, [1]),
		buff(Buff.BreastsForcedLactationBuff, [1]),
		buff(Buff.BreastsMilkProductionBuff, [5]),
		buff(Buff.PenisCumProductionBuff, [1]),
		]

func getInventoryImage():
	return "res://Modules/MoreCowClothesModule/CowbellCollar/icon.tres"
