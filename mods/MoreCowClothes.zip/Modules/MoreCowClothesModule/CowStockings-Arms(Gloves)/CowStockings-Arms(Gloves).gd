extends ItemBase

func _init():
	id = "CowStockings-Arms(Gloves)"

func getVisibleName():
	return "Cow Stockings - Arms (Gloves)"

func getDescription():
	return "Cowprint stockings, but for your hands!"

func getClothingSlot():
	return InventorySlot.Hands

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"hands": "res://Modules/MoreCowClothesModule/CowStockings-Arms(Gloves)/CowStockings-Arms(Gloves).tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your hands"
	else:
		return "take off your hands"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your hands"
	else:
		return "put on your hands"

func getPrice():
	return 50

func getTags():
	return [
		ItemTag.SoldByGeneralVendomat,
		ItemTag.SoldByMedicalVendomat,
		ItemTag.CanBeForcedByGuards,
		ItemTag.CanBeForcedInStocks,
		ItemTag.SexEngineCanApply,
		]

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [10]),
		buff(Buff.BreastsMilkProductionBuff, [5]),
		buff(Buff.PenisCumProductionBuff, [5]),
		buff(Buff.VirilityBuff, [5]),
		buff(Buff.FertilityBuff, [5]),
		buff(Buff.StatBuff, [Stat.Sexiness, 25]),
		]

func getInventoryImage():
	return "res://Modules/MoreCowClothesModule/CowStockings-Arms(Gloves)/icon.tres"
