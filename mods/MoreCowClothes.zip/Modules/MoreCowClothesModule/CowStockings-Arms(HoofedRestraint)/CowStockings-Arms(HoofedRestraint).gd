extends ItemBase

func _init():
	id = "CowStockings-Arms(HoofedRestraint)"

func getVisibleName():
	return "Cow Stockings - Arms (Hoofed Restraint)"

func getDescription():
	return "A version of the cowprint arm stockings, except it acts more like bondage mittens. They are shaped like cow hooves."

func getClothingSlot():
	return InventorySlot.Hands

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"hands": "res://Modules/MoreCowClothesModule/CowStockings-Arms(HoofedRestraint)/CowStockings-Arms(HoofedRestraint).tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your hands"
	else:
		return "take off your hands"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your hands"
	else:
		return "put on your hands"

func getPrice():
	return 75

func getTags():
	return [
		ItemTag.SoldByGeneralVendomat,
		ItemTag.SoldByMedicalVendomat,
		ItemTag.CanBeForcedByGuards,
		ItemTag.CanBeForcedInStocks,
		ItemTag.BDSMRestraint,
		ItemTag.SexEngineCanApply,
		]

func isRestraint():
	return true

func generateRestraintData():
	restraintData = RestraintMittens.new()
	restraintData.setLevel(calculateBestRestraintLevel())

func getTakeOffScene():
	return "RestraintTakeOffNopeScene"

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize() + " were locked onto your hands"
	else:
		return getAStackNameCapitalize() + " were locked onto {receiver.nameS} hands"

func getBuffs():
	return [
		buff(Buff.BlockedHandsBuff),
		buff(Buff.StatBuff, [Stat.Strength, -25]),
		buff(Buff.StatBuff, [Stat.Sexiness, 50]),
		buff(Buff.PhysicalDamageBuff, [-30]),
		buff(Buff.ReceivedLustDamageBuff, [5]),
		buff(Buff.BreastsForcedLactationBuff, [1]),
		]

func getInventoryImage():
	return "res://Modules/MoreCowClothesModule/CowStockings-Arms(HoofedRestraint)/icon.tres"
