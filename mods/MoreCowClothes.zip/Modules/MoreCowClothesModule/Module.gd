extends Module

func _init():
	id = "MoreCowClothes"
	author = "WolfStarArt"

	items = [
		"res://Modules/MoreCowClothesModule/CowbellCollar/CowbellCollar.gd",
		"res://Modules/MoreCowClothesModule/CowStockings-Arms(Gloves)/CowStockings-Arms(Gloves).gd",
		"res://Modules/MoreCowClothesModule/CowStockings-Arms(HoofedRestraint)/CowStockings-Arms(HoofedRestraint).gd",
		"res://Modules/MoreCowClothesModule/CowStockings-Legs/CowStockings-Legs.gd",
		"res://Modules/MoreCowClothesModule/CowUdderChastity/CowUdderChastity.gd",
		]