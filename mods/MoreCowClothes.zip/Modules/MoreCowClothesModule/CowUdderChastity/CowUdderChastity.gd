extends ItemBase

func _init():
	id = "CowUdderChastity"

func getVisibleName():
	return "Cow Udder Chastity"

func getDescription():
	return "A special type of chasity that looks like a cow's udder."

func getClothingSlot():
	return InventorySlot.Unique

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"bdsm": "res://Modules/MoreCowClothesModule/CowUdderChastity/CowUdderChastity.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your bdsm"
	else:
		return "take off your bdsm"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your bdsm"
	else:
		return "put on your bdsm"

func generateItemState():
	itemState = PantiesState.new()

func getPrice():
	return 75

func getTags():
	return [
		ItemTag.BDSMRestraint,
		ItemTag.ChastityCage,
		ItemTag.SoldByMedicalVendomat,
		]

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 25]),
		buff(Buff.FertilityBuff, [20]),
		buff(Buff.VirilityBuff, [20]),
		buff(Buff.PregnantBellySizeModifierBuff, [-5]),
		buff(Buff.ChastityPenisBuff),
		buff(Buff.ChastityVaginaBuff),
		buff(Buff.BreastsMilkProductionBuff, [5]),
		]

func isRestraint():
	return true

func generateRestraintData():
	restraintData = RestraintChastityCage.new()
	restraintData.setLevel(RNG.randi_range(4, 6))

func getTakeOffScene():
	return "RestraintTakeOffNopeScene"

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize() + " was locked onto your groin"
	else:
		return getAStackNameCapitalize() + " was locked onto {receiver.nameS} groin"

func getInventoryImage():
	return "res://Modules/MoreCowClothesModule/CowUdderChastity/icon.tres"
