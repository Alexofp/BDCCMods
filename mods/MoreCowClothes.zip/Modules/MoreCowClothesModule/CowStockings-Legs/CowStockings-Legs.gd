extends ItemBase

func _init():
	id = "CowStockings-Legs"

func getVisibleName():
	return "Cow Stockings - Legs"

func getDescription():
	return "Cowprint Stockings, but for the legs!"

func getClothingSlot():
	return InventorySlot.Ankles

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"ankles": "res://Modules/MoreCowClothesModule/CowStockings-Legs/CowStockings-Legs.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your ankles"
	else:
		return "take off your ankles"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your ankles"
	else:
		return "put on your ankles"

func getPrice():
	return 50

func getTags():
	return [
		ItemTag.CanBeForcedByGuards,
		ItemTag.CanBeForcedInStocks,
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SexEngineCanApply,
		]

func getBuffs():
	return [
		buff(Buff.ExposureBuff, [10]),
		buff(Buff.PenisCumProductionBuff, [5]),
		buff(Buff.VirilityBuff, [25]),
		]

func getInventoryImage():
	return "res://Modules/MoreCowClothesModule/CowStockings-Legs/icon.tres"
