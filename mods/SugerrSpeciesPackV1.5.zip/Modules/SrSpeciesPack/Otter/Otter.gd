extends Species

func _init():
	id = "sugerrotter"

func isPlayable():
	return true

func getVisibleName():
	return "Otter"

func getVisibleDescription():
	return "Otterly glad"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "sugerrottertail"

func getDefaultHead(_gender):
	return "sugerrotterhead1potes"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "sugerrotterears"
	
func getDefaultBody(_gender):
		return "anthrobody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else: 
			return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]
