extends BodypartEars

func _init():
	visibleName = "otter ears"
	id = "sugerrotterears"

func getCompatibleSpecies():
	return ["sugerrotter"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Otter/PNG/OtterEars/OtterEars.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
