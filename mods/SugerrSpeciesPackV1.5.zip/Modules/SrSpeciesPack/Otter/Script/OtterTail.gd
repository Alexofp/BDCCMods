extends BodypartTail

func _init():
	visibleName = "otter tail"
	id = "sugerrottertail"

func getCompatibleSpecies():
	return ["sugerrotter"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["otter, strong"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Otter/PNG/OtterTail/OtterTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
