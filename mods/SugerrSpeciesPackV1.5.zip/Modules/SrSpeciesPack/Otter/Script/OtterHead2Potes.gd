extends BodypartHead

func _init():
	visibleName = "otter head 2 v.2"
	id = "sugerrotterhead2potes"

func getCompatibleSpecies():
	return ["sugerrotter"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Otter/PNG/OtterHead2Potes/OtterHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) Art by Potes"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
