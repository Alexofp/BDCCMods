extends BodypartHead

func _init():
	visibleName = "otter head 1"
	id = "sugerrotterhead1"

func getCompatibleSpecies():
	return ["sugerrotter"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Otter/PNG/OtterHead1/OtterHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
