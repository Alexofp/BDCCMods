extends BodypartHead

func _init():
	visibleName = "otter head 1 v2"
	id = "sugerrotterhead1potes"

func getCompatibleSpecies():
	return ["sugerrotter"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Otter/PNG/OtterHead1Potes/OtterHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) Art by Potes"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
