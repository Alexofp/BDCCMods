extends BodypartHead

func _init():
	visibleName = "otter head 2"
	id = "sugerrotterhead2"

func getCompatibleSpecies():
	return ["sugerrotter"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Otter/PNG/OtterHead2/OtterHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
