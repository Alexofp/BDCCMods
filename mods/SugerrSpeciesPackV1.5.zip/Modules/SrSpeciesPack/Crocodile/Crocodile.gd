extends Species

func _init():
	id = "sugerrcrocodile"

func isPlayable():
	return true

func getVisibleName():
	return "Crocodile"

func getVisibleDescription():
	return "In awhile, crocodile"

func getAllowedBodyparts():
	return ["sugerrspikedback"]

func getDefaultLegs(_gender):
	return "sugerrcrocodilelegs"

func getDefaultTail(_gender):
	return "sugerrcrocodiletail"

func getDefaultHead(_gender):
	return "sugerrcrocodilehead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "sugerrcrocodileears"
	
func getDefaultBody(_gender):
	return "sugerrcrocodilebody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "dragonpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]
