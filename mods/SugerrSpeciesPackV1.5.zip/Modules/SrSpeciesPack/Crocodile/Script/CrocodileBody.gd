extends BodypartBody

func _init():
	visibleName = "crocodile body"
	id = "sugerrcrocodilebody"

func getCompatibleSpecies():
	return ["sugerrcrocodile", Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileBody/CrocodileBody.tscn"

func getVulgarName() -> String:
	return "spiked body"

func getAVulgarName() -> String:
	return "a spiked body"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
