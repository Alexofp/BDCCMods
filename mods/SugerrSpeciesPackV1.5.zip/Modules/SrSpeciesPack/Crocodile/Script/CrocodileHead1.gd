extends BodypartHead

func _init():
	visibleName = "crocodile head 1"
	id = "sugerrcrocodilehead"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileHead1/CrocodileHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
