extends BodypartLeg

func _init():
	visibleName = "crocodile legs"
	id = "sugerrcrocodilelegs"

func getCompatibleSpecies():
	return ["sugerrcrocodile", Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileLegs/CrocodileLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
