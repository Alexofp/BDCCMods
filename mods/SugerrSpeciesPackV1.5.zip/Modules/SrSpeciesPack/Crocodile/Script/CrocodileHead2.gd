extends BodypartHead

func _init():
	visibleName = "crocodile head 2"
	id = "sugerrcrocodilehead2"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileHead2/CrocodileHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
