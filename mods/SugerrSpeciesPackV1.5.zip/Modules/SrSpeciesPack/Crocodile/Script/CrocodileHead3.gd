extends BodypartHead

func _init():
	visibleName = "crocodile head 3"
	id = "sugerrcrocodilehead3"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileHead3/CrocodileHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
