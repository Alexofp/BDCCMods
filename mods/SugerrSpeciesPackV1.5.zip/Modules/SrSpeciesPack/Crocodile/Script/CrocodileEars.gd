extends BodypartEars

func _init():
	visibleName = "reptile ears"
	id = "sugerrcrocodileears"

func getCompatibleSpecies():
	return ["sugerrcrocodile", "sugerrlizard"]

func getDoll3DScene():
	return null
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
