extends BodypartHead

func _init():
	visibleName = "alligator head"
	id = "sugerralligatorhead"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/AlligatorHead/AlligatorHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
