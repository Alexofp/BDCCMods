extends BodypartTail

func _init():
	visibleName = "crocodile tail (skin)"
	id = "sugerrcrocodiletailskin"

func getCompatibleSpecies():
	return ["sugerrcrocodile"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Crocodile/PNG/CrocodileTailSkin/CrocodileTailSkin.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
