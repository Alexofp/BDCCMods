extends Species

func _init():
	id = "sugerrfossa"

func isPlayable():
	return true

func getVisibleName():
	return "Fossa"

func getVisibleDescription():
	return "Foss"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "sugerrfossatail"

func getDefaultHead(_gender):
	return "sugerrfossahead1"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "sugerrfossaears1"
	
func getDefaultBody(_gender):
		return "anthrobody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "felinepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]
