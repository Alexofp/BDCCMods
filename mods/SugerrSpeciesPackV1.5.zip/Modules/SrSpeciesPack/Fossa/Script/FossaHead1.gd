extends BodypartHead

func _init():
	visibleName = "fossa head 1"
	id = "sugerrfossahead1"

func getCompatibleSpecies():
	return ["sugerrfossa"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Fossa/PNG/FossaHead1/FossaHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
