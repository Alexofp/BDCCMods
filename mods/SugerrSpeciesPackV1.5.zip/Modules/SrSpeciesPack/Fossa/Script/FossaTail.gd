extends BodypartTail

func _init():
	visibleName = "fossa tail"
	id = "sugerrfossatail"

func getCompatibleSpecies():
	return ["sugerrfossa"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["fossa"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Fossa/PNG/FossaTail/FossaTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
