extends BodypartHead

func _init():
	visibleName = "fossa head 2"
	id = "sugerrfossahead2"

func getCompatibleSpecies():
	return ["sugerrfossa"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Fossa/PNG/FossaHead2/FossaHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
