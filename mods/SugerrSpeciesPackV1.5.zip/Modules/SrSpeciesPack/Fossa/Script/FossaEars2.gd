extends BodypartEars

func _init():
	visibleName = "fossa ears 2"
	id = "sugerrfossaears2"

func getCompatibleSpecies():
	return ["sugerrfossa"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Fossa/PNG/FossaEars2/FossaEars.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
