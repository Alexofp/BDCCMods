extends BodypartEars

func _init():
	visibleName = "fossa ears 1"
	id = "sugerrfossaears1"

func getCompatibleSpecies():
	return ["sugerrfossa"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Fossa/PNG/FossaEars1/FossaEars.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
