extends BodypartLeg

func _init():
	visibleName = "old bear legs"
	id = "sugerrbearlegsold"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/OldBearLegs/BearLegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) The old bear legs. These shouldn't generate naturally, just added this as an option"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
