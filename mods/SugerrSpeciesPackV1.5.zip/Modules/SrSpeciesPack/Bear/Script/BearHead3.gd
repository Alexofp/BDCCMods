extends BodypartHead

func _init():
	visibleName = "bear head 3"
	id = "sugerrbearhead3"

func getCompatibleSpecies():
	return ["sugerrbear"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearHead3/BearHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
