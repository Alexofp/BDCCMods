extends BodypartBody

func _init():
	visibleName = "bear body 1"
	id = "sugerrbearbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearBody1/BearBody.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
