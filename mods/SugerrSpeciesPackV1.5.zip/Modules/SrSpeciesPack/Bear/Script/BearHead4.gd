extends BodypartHead

func _init():
	visibleName = "bear head 4"
	id = "sugerrbearhead4"

func getCompatibleSpecies():
	return ["sugerrbear"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearHead4/BearHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
