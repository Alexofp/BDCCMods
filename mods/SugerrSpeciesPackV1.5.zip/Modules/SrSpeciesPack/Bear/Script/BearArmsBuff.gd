extends BodypartArms

func _init():
	visibleName = "buff bear arms"
	id = "sugerrbeararmsbuff"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearArmsBuff/BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
