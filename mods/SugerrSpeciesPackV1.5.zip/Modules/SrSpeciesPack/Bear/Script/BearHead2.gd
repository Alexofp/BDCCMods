extends BodypartHead

func _init():
	visibleName = "bear head 2"
	id = "sugerrbearhead2"

func getCompatibleSpecies():
	return ["sugerrbear"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearHead2/BearHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
