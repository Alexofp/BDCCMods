extends BodypartTail

func _init():
	visibleName = "bear tail 1"
	id = "sugerrbeartail1"

func getCompatibleSpecies():
	return ["sugerrbear"]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["fluffy"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearTail1/BearTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
