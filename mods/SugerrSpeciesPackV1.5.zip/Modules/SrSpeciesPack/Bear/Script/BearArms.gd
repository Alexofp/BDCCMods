extends BodypartArms

func _init():
	visibleName = "bear arms"
	id = "sugerrbeararms"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearArms/BearArms.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
