extends "res://Modules/SrSpeciesPack/Bear/Script/BearBreasts.gd"

func _init():
	visibleName = "male bear breasts"
	id = "sugerrmalebearbreasts"
	size = BreastsSize.FLAT

func getTraits():
	return {
		PartTrait.BreastsMale: true,
	}

func getLewdAdjective():
	return RNG.pick(["firm", "strong"])

func getLewdName():
	if(size <= BreastsSize.A):
		return "pecs"

	return RNG.pick(["manbreasts", "manboobs", "mantits", "jugs", "orbs"])

func safeWhenExposed():
	if(size <= BreastsSize.A):
		return true
	
	return false

func generateDataFor(_dynamicCharacter):
	pass

func getVulgarName() -> String:
	return "male pecs"

func getAVulgarName() -> String:
	return getVulgarName()
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
