extends BodypartEars

func _init():
	visibleName = "bear ears 3 v.2"
	id = "sugerrbearears3v2"

func getCompatibleSpecies():
	return ["sugerrbear"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Bear/PNG/BearEars3v2/BearEars.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
