extends Species

func _init():
	id = "sugerrlizard"

func isPlayable():
	return true

func getVisibleName():
	return "Lizard"

func getVisibleDescription():
	return "Lizards? More like Rizzards.. im so funny, aha"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "sugerrlizardtail1"

func getDefaultHead(_gender):
	return "sugerrgeckohead1"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "sugerrcrocodileears"
	
func getDefaultBody(_gender):
		return "anthrobody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersTaperedPenises" in GlobalRegistry.getModules()):
			return "taperedpenis"
		else: 
			return "dragonpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]
