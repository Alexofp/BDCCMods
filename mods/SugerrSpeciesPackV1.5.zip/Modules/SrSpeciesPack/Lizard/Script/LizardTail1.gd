extends BodypartTail

func _init():
	visibleName = "lizard tail 1"
	id = "sugerrlizardtail1"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaled, thin"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/LizardTail1/LizardTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
