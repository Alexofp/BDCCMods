extends BodypartEars

func _init():
	visibleName = "lizard ears 2"
	id = "sugerrlizardears2"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getHybridPriority():
	return -1

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/LizardEars2/LizardEars.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.5
