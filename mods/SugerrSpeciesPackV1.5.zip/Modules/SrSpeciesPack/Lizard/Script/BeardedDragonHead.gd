extends BodypartHead

func _init():
	visibleName = "bearded dragon head"
	id = "sugerrbeardeddragon"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/BeardedDragonHead/BeardedDragonHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
