extends BodypartTail

func _init():
	visibleName = "dropped tail"
	id = "sugerrdroppedtail"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["nub"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/DroppedTail/DroppedTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) oopsies.."
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
