extends BodypartEars

func _init():
	visibleName = "lizard ears 1"
	id = "sugerrlizardears1"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getHybridPriority():
	return -1

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/LizardEars1/LizardEars.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.5
