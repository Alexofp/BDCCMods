extends BodypartHorns

func _init():
	visibleName = "chameleon horns"
	id = "sugerrchameleonhorns"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/ChameleonHorns/ChameleonHorns.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
