extends BodypartHead

func _init():
	visibleName = "gecko head 2"
	id = "sugerrgeckohead2"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/GeckoHead2/GeckoHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
