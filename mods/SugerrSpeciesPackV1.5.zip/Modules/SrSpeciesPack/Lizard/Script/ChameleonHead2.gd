extends BodypartHead

func _init():
	visibleName = "chameleon head 2"
	id = "sugerrchameleonhead2"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/ChameleonHead2/ChameleonHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
