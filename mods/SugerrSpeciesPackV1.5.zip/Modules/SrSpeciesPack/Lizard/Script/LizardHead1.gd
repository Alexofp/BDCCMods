extends BodypartHead

func _init():
	visibleName = "lizard head 1"
	id = "sugerrlizardhead1"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/LizardHead1/LizardHead.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
