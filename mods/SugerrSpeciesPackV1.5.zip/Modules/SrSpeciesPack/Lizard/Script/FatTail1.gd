extends BodypartTail

func _init():
	visibleName = "fat tail 1"
	id = "sugerrfattail1"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getLewdSizeAdjective():
	return RNG.pick(["big"])

func getLewdAdjective():
	return RNG.pick(["scaled, thick"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/FatTail1/FatTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
