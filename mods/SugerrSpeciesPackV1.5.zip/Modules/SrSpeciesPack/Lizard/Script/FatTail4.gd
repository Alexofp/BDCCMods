extends BodypartTail

func _init():
	visibleName = "fat tail 4"
	id = "sugerrfattail4"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getLewdSizeAdjective():
	return RNG.pick(["big"])

func getLewdAdjective():
	return RNG.pick(["scaled, thick"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/FatTail4/FatTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
