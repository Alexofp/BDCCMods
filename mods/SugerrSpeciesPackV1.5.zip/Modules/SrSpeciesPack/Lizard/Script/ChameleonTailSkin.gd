extends BodypartTail

func _init():
	visibleName = "chameleon tail (skin)"
	id = "sugerrchameleontailskin"

func getCompatibleSpecies():
	return ["sugerrlizard"]

func getLewdSizeAdjective():
	return RNG.pick(["big"])

func getLewdAdjective():
	return RNG.pick(["scaled, thick"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Lizard/PNG/ChameleonTailSkin/ChameleonTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack) Doesn't generate on npcs"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func npcGenerationWeight(_dynamicCharacter):
	return 0.0
