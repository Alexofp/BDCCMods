extends BodypartHead

func _init():
	visibleName = "Red Panda Head Alt"
	id = "redpandaheadalt"

func getCompatibleSpecies():
	return ["redpanda"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaHeadAlt/RedPandaHeadAlt.tscn"

func getHeadLength():
	return 0.5
