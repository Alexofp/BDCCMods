extends BodypartTail

func _init():
	visibleName = "Red Panda Tail"
	id = "redpandatail"

func getCompatibleSpecies():
	return ["redpanda"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaTail/RedPandaTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
