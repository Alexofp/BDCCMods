extends BodypartHead

func _init():
	visibleName = "Red Panda Head No Pattern"
	id = "redpandaheadnopattern"

func getCompatibleSpecies():
	return ["redpanda"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaHeadNoPattern/RedPandaHeadNoPattern.tscn"

func getHeadLength():
	return 0.5
