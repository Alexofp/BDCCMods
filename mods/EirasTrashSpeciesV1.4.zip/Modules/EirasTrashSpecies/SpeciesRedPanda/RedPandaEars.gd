extends BodypartEars

func _init():
	visibleName = "red panda ears"
	id = "redpandaears"

func getCompatibleSpecies():
	return ["redpanda"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaEars/RedPandaEars.tscn"
