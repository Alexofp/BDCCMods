extends BodypartHead

func _init():
	visibleName = "red panda head"
	id = "redpandahead"

func getCompatibleSpecies():
	return ["redpanda"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaHead/RedPandaHead.tscn"

func getHeadLength():
	return 0.5
