extends BodypartEars

func _init():
	visibleName = "rat ears"
	id = "ratears"

func getCompatibleSpecies():
	return ["rat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRat/Bodyparts/RatEars/RatEars.tscn"
