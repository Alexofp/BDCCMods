extends Species

func _init():
	id = "rat"

func isPlayable():
	return true

func getVisibleName():
	return "Rat"

func getVisibleDescription():
	return "Cheeselovers"

func getDefaultBody(_gender):
	return "anthrobody"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "rattail"

func getDefaultHead(_gender):
	return "rathead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "ratears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "malebreasts"
	return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else:
			return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 2.0],
		[2, 8.0],
		[3, 6.0],
		[4, 4.0],
		[5, 2.0],
		[6, 1.0],
		[7, 0.5],
	]
