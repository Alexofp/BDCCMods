extends BodypartTail

func _init():
	visibleName = "rat tail"
	id = "rattail"

func getCompatibleSpecies():
	return ["rat"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["rat", "thin", "smooth"])

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRat/Bodyparts/RatTail/RatTail.tscn"
