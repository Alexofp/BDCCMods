extends BodypartHead

func _init():
	visibleName = "rat head"
	id = "rathead"

func getCompatibleSpecies():
	return ["rat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumHead/PossumHead.tscn"

func getHeadLength():
	return 0.6
