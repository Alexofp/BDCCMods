extends BodypartHead

func _init():
	visibleName = "mouse head"
	id = "mousehead"

func getCompatibleSpecies():
	return ["rat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRat/Bodyparts/MouseHead/MouseHead.tscn"

func getHeadLength():
	return 0.30
