extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "squirrel"

#I cant fucking type squrriel consistently so you get treenuts instead
#Avery & Eira - It's okay, we can!

func getVisibleName():
	return "Squirrel"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "squirreltaillong"

func isPlayable():
	return true

func getVisibleDescription():
	return "Nut joke."

func getDefaultHead(_gender):
	return "squirrelhead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "felineears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"
	else:
		if(_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"

#A lot of the refs I saw had human dick so we're gonna do both and see how it goes
# NO!!!!!!
func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheathhyperable"
		else:
			return "caninepenishyperable"
	else:
		return null

#Avery - No dicks in getAllowedBodyparts. They count as an allowed part regardless of gender and it results in females & peachboys spawning with dicks.
func getAllowedBodyparts():
	return ["shorttail", "felineears", "wolfears"]

#I actually gave this one a custom Ovulation count this time

func getEggCellOvulationAmount():
	return [
		[2, 6.0],
		[3, 8.0],
		[4, 6.0],
		[5, 1.0],
	]
