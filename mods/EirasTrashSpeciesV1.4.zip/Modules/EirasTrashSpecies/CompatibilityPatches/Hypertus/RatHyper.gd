extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "rat"

func isPlayable():
	return true

func getVisibleName():
	return "Rat"

func getVisibleDescription():
	return "Cheeselovers"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "rattail"

func getDefaultHead(_gender):
	return "rathead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "ratears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"
	else:
		if(_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheathhyperable"
		else:
			return "caninepenishyperable"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 2.0],
		[2, 8.0],
		[3, 6.0],
		[4, 4.0],
		[5, 2.0],
		[6, 1.0],
		[7, 0.5],
	]
