extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "redpanda"
	
func getVisibleName():
	return "Red Panda"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "redpandatail"

func isPlayable():
	return true

func getVisibleDescription():
	return "The fluffy boys and girls"

func getDefaultHead(_gender):
	return "redpandahead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "redpandaears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"
	else:
		if(_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheathhyperable"
		else:
			return "caninepenishyperable"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]

func supportsMane():
	return true
