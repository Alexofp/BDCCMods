extends BodypartEars

func _init():
	visibleName = "bat ears 1"
	id = "batears1"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatEars1/BatEars1.tscn"
