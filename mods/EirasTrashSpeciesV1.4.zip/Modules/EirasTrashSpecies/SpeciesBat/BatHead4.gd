extends BodypartHead

func _init():
	visibleName = "bat head 4"
	id = "bathead4"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatHead4/BatHead4.tscn"

func getHeadLength():
	return 0.55
