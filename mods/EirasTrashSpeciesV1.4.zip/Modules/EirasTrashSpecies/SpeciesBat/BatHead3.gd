extends BodypartHead

func _init():
	visibleName = "bat head 3"
	id = "bathead3"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatHead3/BatHead3.tscn"

func getHeadLength():
	return 0.55
