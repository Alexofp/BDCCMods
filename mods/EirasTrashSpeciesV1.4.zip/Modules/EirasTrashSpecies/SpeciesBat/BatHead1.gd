extends BodypartHead

func _init():
	visibleName = "bat head 1"
	id = "bathead1"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatHead1/BatHead1.tscn"

func getHeadLength():
	return 0.5
