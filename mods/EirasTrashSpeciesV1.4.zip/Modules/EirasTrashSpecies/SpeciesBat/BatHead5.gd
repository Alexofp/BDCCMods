extends BodypartHead

func _init():
	visibleName = "bat head 5"
	id = "bathead5"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatHead5/BatHead5.tscn"

func getHeadLength():
	return 0.55
