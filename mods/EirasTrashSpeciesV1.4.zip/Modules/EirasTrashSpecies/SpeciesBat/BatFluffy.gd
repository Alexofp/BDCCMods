extends Species

func _init():
	id = "bat"
	
func getVisibleName():
	return "Bat"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "battailfluffy"

func isPlayable():
	return true

func getVisibleDescription():
	return "The flying things related to being kinda scary but not really"

func getDefaultHead(_gender):
	return "bathead4"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "batarmsfluffy"
	return "batarms"

func getDefaultEars(_gender):
	return "batears1"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else:
			return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
	]
