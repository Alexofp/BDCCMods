extends BodypartArms

func _init():
	visibleName = "fluffy bat arms"
	id = "batarmsfluffy"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatArms/BatArmsFluffy.tscn"
