extends BodypartEars

func _init():
	visibleName = "bat ears 4 (damaged)"
	id = "batears4damaged"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatEars4/BatEars4Damaged.tscn"
