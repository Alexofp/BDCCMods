extends BodypartEars

func _init():
	visibleName = "bat ears 5"
	id = "batears5"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatEars5/BatEars5.tscn"
