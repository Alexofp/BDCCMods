extends BodypartTail

func _init():
	visibleName = "fluffy bat tail"
	id = "battailfluffy"

func getCompatibleSpecies():
	return ["bat"]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["fluffy"])

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatTailFluffy/BatTailFluffy.tscn"
