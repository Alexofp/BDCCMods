extends BodypartArms

func _init():
	visibleName = "bat arms"
	id = "batarms"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatArms/BatArms.tscn"
