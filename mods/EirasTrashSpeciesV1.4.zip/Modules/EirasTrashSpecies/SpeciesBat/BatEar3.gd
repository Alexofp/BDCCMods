extends BodypartEars

func _init():
	visibleName = "bat ears 3"
	id = "batears3"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatEars3/BatEars3.tscn"
