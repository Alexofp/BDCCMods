extends BodypartHead

func _init():
	visibleName = "bat head 6"
	id = "bathead6"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatHead6/BatHead6.tscn"

func getHeadLength():
	return 0.30
