extends BodypartEars

func _init():
	visibleName = "bat ears 4"
	id = "batears4"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatEars4/BatEars4.tscn"
