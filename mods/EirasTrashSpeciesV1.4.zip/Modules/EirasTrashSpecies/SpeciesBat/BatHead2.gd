extends BodypartHead

func _init():
	visibleName = "bat head 2"
	id = "bathead2"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatHead2/BatHead2.tscn"

func getHeadLength():
	return 0.5
