extends BodypartEars

func _init():
	visibleName = "bat ears 2"
	id = "batears2"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatEars2/BatEars2.tscn"
