extends BodypartArms

func _init():
	visibleName = "scruffy bat arms"
	id = "batarmsscruffy"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatArms/BatArmsScruffy.tscn"
