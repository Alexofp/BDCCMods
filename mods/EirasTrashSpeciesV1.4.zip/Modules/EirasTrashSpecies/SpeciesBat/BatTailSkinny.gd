extends BodypartTail

func _init():
	visibleName = "skinny bat tail"
	id = "battailskinny"

func getCompatibleSpecies():
	return ["bat"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesBat/Bodyparts/BatTailSkinny/BatTailSkinny.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
