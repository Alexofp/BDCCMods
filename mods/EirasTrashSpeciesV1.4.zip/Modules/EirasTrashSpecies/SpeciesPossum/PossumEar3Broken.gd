extends BodypartEars

func _init():
	visibleName = "possum ears 3 broken"
	id = "possumear3broken"

func getCompatibleSpecies():
	return ["possum"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumEars3/PossumEars3Broken.tscn"
