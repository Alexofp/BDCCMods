extends BodypartEars

func _init():
	visibleName = "possum ears 4"
	id = "possumear4"

func getCompatibleSpecies():
	return ["possum"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumEars4/PossumEars4.tscn"
