extends BodypartEars

func _init():
	visibleName = "possum ears 1"
	id = "possumear"

func getCompatibleSpecies():
	return ["possum"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumEars1/PossumEars1.tscn"
