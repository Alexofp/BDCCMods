extends BodypartTail

func _init():
	visibleName = "Possum tail"
	id = "possumtail"

func getCompatibleSpecies():
	return ["possum"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["flexible", "possum"])

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumTail/PossumTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
