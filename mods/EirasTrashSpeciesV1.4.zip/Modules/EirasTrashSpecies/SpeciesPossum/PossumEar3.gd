extends BodypartEars

func _init():
	visibleName = "possum ears 3"
	id = "possumear3"

func getCompatibleSpecies():
	return ["possum"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumEars3/PossumEars3.tscn"
