extends Species

func _init():
	id = "possum"
	
func getVisibleName():
	return "Possum"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "possumtail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Trashy marsupials known for being incredibly based."

func getDefaultHead(_gender):
	return "possumhead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffclawedarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "possumear4"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else:
			return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 1.0],
		[3, 2.0],
		[4, 3.0],
		[5, 4.0],
		[6, 6.0],
		[7, 8.0],
		[8, 10.0],
		[9, 9.0],
		[10, 8.0],
		[11, 7.0],
		[12, 6.0],
		[13, 5.0],
		[14, 4.0],
		[15, 3.0],
		[16, 2.0],
		[17, 1.0],
	]
