extends BodypartEars

func _init():
	visibleName = "possum ears 2"
	id = "possumear2"

func getCompatibleSpecies():
	return ["possum"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumEars2/PossumEars2.tscn"
