extends BodypartHead

func _init():
	visibleName = "possum head"
	id = "possumhead"

func getCompatibleSpecies():
	return ["possum"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesPossum/Bodyparts/PossumHead/PossumHead.tscn"

func getHeadLength():
	return 0.6
