extends Module

var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")
var FluffyBodypartsLoad = ResourceLoader.exists("res://Modules/WintersFluffyBodyparts/Module.gd")

func _init():
	id = "EirasTrashSpecies"
	author = "Originals: Anon, Fantos Updates: Winter Eira, Avery Winters & Moldy Tub"
	
	bodyparts = [
	#Bat Species Parts
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatArms.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatEar1.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatEar2.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatEar3.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatEar4.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatEar4Damaged.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatEar5.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatHead1.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatHead2.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatHead3.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatHead4.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatHead5.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatHead6.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatTailFluffy.gd",
		"res://Modules/EirasTrashSpecies/SpeciesBat/BatTailSkinny.gd",
	#Possum Species Parts
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumEar1.gd",
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumEar2.gd",
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumEar3.gd",
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumEar3Broken.gd",
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumEar4.gd",
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumHead.gd",
		"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumTail.gd",
	#Raccoon Species Parts
		"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RaccoonEars.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RaccoonHead.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RaccoonHeadNoPattern.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RacoonTailBushy.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RacoonTailStriped.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RacoonTailThin.gd",
	#Rodent Species Parts
		"res://Modules/EirasTrashSpecies/SpeciesRat/MouseHead.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRat/RatEars.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRat/RatHead.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRat/RatTail.gd",
	#Red Panda Species
		"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaEars.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaHead.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaHeadAlt.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaHeadNoPattern.gd",
		"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaTail.gd",
	#Squirrel Species
		"res://Modules/EirasTrashSpecies/SpeciesSquirrel/SquirrelHead.gd",
		"res://Modules/EirasTrashSpecies/SpeciesSquirrel/SquirrelTailLong.gd",
		"res://Modules/EirasTrashSpecies/SpeciesSquirrel/SquirrelTailShort.gd",
	]

	if (FluffyBodypartsLoad == true):
			GlobalRegistry.registerBodypart("res://Modules/EirasTrashSpecies/SpeciesBat/BatArmsFluffy.gd")
			GlobalRegistry.registerBodypart("res://Modules/EirasTrashSpecies/SpeciesBat/BatArmsScruffy.gd")
			GlobalRegistry.registerBodypart("res://Modules/EirasTrashSpecies/SpeciesBat/BatArmsBuffFluffy.gd")

	if (RAT_ArchetypeLoad == false):
		species = [
			"res://Modules/EirasTrashSpecies/SpeciesBat/BatFluffy.gd",
			"res://Modules/EirasTrashSpecies/SpeciesPossum/PossumFluffy.gd",
			"res://Modules/EirasTrashSpecies/SpeciesRaccoon/RaccoonFluffy.gd",
			"res://Modules/EirasTrashSpecies/SpeciesRat/RatFluffy.gd",
			"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPandaFluffy.gd",
			"res://Modules/EirasTrashSpecies/SpeciesSquirrel/SquirrelFluffy.gd",
		]
	else:
		species = [
			"res://Modules/EirasTrashSpecies/SpeciesBat/Bat.gd",
			"res://Modules/EirasTrashSpecies/SpeciesPossum/Possum.gd",
			"res://Modules/EirasTrashSpecies/SpeciesRaccoon/Raccoon.gd",
			"res://Modules/EirasTrashSpecies/SpeciesRat/Rat.gd",
			"res://Modules/EirasTrashSpecies/SpeciesRedPanda/RedPanda.gd",
			"res://Modules/EirasTrashSpecies/SpeciesSquirrel/Squirrel.gd",
		]

func getAddedRatArchetypes() -> Dictionary:
	var pathDirFluffy = "res://Modules/WintersFluffyBodyparts/CompatibilityPatches/RAT_BodypartArchetypes/"
	var pathDir = "res://Modules/EirasTrashSpecies/CompatibilityPatches/RAT_BodypartArchetypes/"
	
	return {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)
	#Base Species Archetypes
	"bat": [pathDir+"BatArchetypes.json"],
	"possum": [pathDirFluffy+"ClawedArchetypes.json"],
	"raccoon": [pathDirFluffy+"ClawedArchetypes.json"],
	"rat": [pathDirFluffy+"ClawedArchetypes.json"],
	"redpanda": [pathDirFluffy+"ClawedArchetypes.json"],
	"squirrel": [pathDirFluffy+"ClawedArchetypes.json"],
	}
