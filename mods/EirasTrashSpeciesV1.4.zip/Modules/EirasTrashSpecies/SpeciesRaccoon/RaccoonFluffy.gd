extends Species

func _init():
	id = "raccoon"

func isPlayable():
	return true

func getVisibleName():
	return "Raccoon"

func getVisibleDescription():
	return "Trash pandas"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "raccoontail"

func getDefaultHead(_gender):
	return "raccoonhead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "raccoonears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else:
			return "caninepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 6.0],
		[3, 8.0],
		[4, 5.0],
		[5, 4.0],
	]
