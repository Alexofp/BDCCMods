extends BodypartTail

func _init():
	visibleName = "raccoon tail thin"
	id = "raccoontailthin"

func getCompatibleSpecies():
	return ["raccoon"]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["racoon", "fluffy", "striped"])

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRaccoon/Bodyparts/RaccoonTailThin/RaccoonTailThin.tscn"

func npcGenerationWeight(_dynamicCharacter):
	return 0.1
