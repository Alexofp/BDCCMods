extends BodypartTail

func _init():
	visibleName = "raccoon tail striped"
	id = "raccoontailstriped"

func getCompatibleSpecies():
	return ["raccoon"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["racoon", "fluffy", "striped"])

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRaccoon/Bodyparts/RaccoonTailStripes/RaccoonTailStripes.tscn"

func npcGenerationWeight(_dynamicCharacter):
	return 0.1
