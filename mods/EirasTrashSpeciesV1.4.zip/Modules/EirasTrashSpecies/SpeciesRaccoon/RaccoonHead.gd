extends BodypartHead

func _init():
	visibleName = "raccoon head"
	id = "raccoonhead"

func getCompatibleSpecies():
	return ["raccoon"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRaccoon/Bodyparts/RaccoonHead/RaccoonHead.tscn"

func getHeadLength():
	return 0.5
