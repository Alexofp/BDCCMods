extends BodypartEars

func _init():
	visibleName = "raccoon ears"
	id = "raccoonears"

func getCompatibleSpecies():
	return ["raccoon"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRaccoon/Bodyparts/RaccoonEar/RaccoonEar.tscn"
