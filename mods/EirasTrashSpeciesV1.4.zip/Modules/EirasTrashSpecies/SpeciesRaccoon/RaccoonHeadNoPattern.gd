extends BodypartHead

func _init():
	visibleName = "raccoon head no pattern"
	id = "raccoonheadnopattern"

func getCompatibleSpecies():
	return ["raccoon"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesRaccoon/Bodyparts/RaccoonHeadNoPattern/RaccoonHeadNoPattern.tscn"

func getHeadLength():
	return 0.5
