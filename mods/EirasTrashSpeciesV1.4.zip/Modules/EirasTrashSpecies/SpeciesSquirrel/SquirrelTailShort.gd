extends BodypartTail

func _init():
	visibleName = "Squirrel tail Short"
	id = "squirreltailshort"

func getCompatibleSpecies():
	return ["squirrel"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesSquirrel/Bodyparts/SquirrelTailShort/SquirrelTailShort.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
