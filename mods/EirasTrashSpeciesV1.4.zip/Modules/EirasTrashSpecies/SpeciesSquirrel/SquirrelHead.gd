extends BodypartHead

func _init():
	visibleName = "Squirrel Head"
	id = "squirrelhead"

func getCompatibleSpecies():
	return ["squirrel"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesSquirrel/Bodyparts/SquirrelHead/SquirrelHead.tscn"

func getHeadLength():
	return 0.3
