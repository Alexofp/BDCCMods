extends Species

func _init():
	id = "squirrel"

#I cant fucking type squrriel consistently so you get treenuts instead
#WK: F your treenuts learn to use copy paste XD
func getVisibleName():
	return "Squirrel"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "squirreltaillong"

func isPlayable():
	return true

func getVisibleDescription():
	return "Nut joke."

func getDefaultHead(_gender):
	return "squirrelhead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "felineears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

#A lot of the refs I saw had human dick so we're gonna do both and see how it goes
#Avery - Eira ripped the human version out of the hypertus compat so im removing it here to maintain consistency
func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("AnonsHumanSheathedPenis" in GlobalRegistry.getModules()):
			return "humanpenissheath"
		else:
			return "caninepenis"
	else:
		return null

func getAllowedBodyparts():
	return ["shorttail", "felineears", "wolfears"]

#I actually gave this one a custom Ovulation count this time
func getEggCellOvulationAmount():
	return [
		[2, 6.0],
		[3, 8.0],
		[4, 6.0],
		[5, 1.0],
	]
