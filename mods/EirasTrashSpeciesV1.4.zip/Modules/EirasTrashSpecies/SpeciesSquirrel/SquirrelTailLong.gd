extends BodypartTail

func _init():
	visibleName = "Squirrel tail long"
	id = "squirreltaillong"

func getCompatibleSpecies():
	return ["squirrel"]

func getDoll3DScene():
	return "res://Modules/EirasTrashSpecies/SpeciesSquirrel/Bodyparts/SquirrelTailLong/SquirrelTailLong.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
