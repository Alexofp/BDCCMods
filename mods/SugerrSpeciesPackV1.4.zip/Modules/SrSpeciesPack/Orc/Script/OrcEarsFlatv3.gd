extends BodypartEars

func _init():
	visibleName = "orc ears flat v.3"
	id = "sugerrorcearsflatv3"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Orc/PNG/OrcEarsFlatv3/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
