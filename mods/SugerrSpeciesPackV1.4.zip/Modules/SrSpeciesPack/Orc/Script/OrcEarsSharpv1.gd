extends BodypartEars

func _init():
	visibleName = "orc ears sharp v.1"
	id = "sugerrorcearsv1"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Orc/PNG/OrcEarsSharpv1/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
