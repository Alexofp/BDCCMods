extends BodypartEars

func _init():
	visibleName = "orc ears flat v.2"
	id = "sugerrorcearsflatv2"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Orc/PNG/OrcEarsFlatv2/OrcEars.tscn"
	
func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
