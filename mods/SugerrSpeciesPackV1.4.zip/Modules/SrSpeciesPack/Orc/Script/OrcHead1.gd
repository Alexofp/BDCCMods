extends BodypartHead

func _init():
	visibleName = "orc head 1"
	id = "sugerrorchead1"

func getCompatibleSpecies():
	return ["sugerrorc"]

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Orc/PNG/OrcHead1/OrcHead.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
