extends Module

func _init():
	id = "sugerrspeciespack"
	author = "Sugerør"
	
	species = [
		"res://Modules/SrSpeciesPack/Crocodile/Crocodile.gd",
		"res://Modules/SrSpeciesPack/Orc/Orc.gd",
		"res://Modules/SrSpeciesPack/Bear/Bear.gd",
		"res://Modules/SrSpeciesPack/Fossa/Fossa.gd",
		"res://Modules/SrSpeciesPack/Lizard/Lizard.gd",
	]
	bodyparts = [
		#Crocodile
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileHead1.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileHead2.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileHead3.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/AlligatorHead.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileEars.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileTail.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileTailSkin.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileLegs.gd",
		"res://Modules/SrSpeciesPack/Crocodile/Script/CrocodileBody.gd",
		#Orc
		"res://Modules/SrSpeciesPack/Orc/Script/OrcHead1.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcHead2.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcHead3.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcEarsSharpv1.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcEarsSharpv2.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcEarsSharpv3.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcEarsFlatv1.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcEarsFlatv2.gd",
		"res://Modules/SrSpeciesPack/Orc/Script/OrcEarsFlatv3.gd",
		#Bear
		"res://Modules/SrSpeciesPack/Bear/Script/BearHead1.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearHead2.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearHead3.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearHead4.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearEars1.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearEars2.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearEars3v1.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearEars3v2.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearEars4.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearTail1.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearTail2.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearLegs.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/OldBearLegs.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearBody1.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearBody2.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearArms.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearArmsBuff.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearBreasts.gd",
		"res://Modules/SrSpeciesPack/Bear/Script/BearBreastsFlat.gd",
		#Fossa
		"res://Modules/SrSpeciesPack/Fossa/Script/FossaHead1.gd",
		"res://Modules/SrSpeciesPack/Fossa/Script/FossaHead2.gd",
		"res://Modules/SrSpeciesPack/Fossa/Script/FossaEars1.gd",
		"res://Modules/SrSpeciesPack/Fossa/Script/FossaEars2.gd",
		"res://Modules/SrSpeciesPack/Fossa/Script/FossaTail.gd",
		"res://Modules/SrSpeciesPack/Fossa/Script/FossaTailSkin.gd",
		#Lizard
		"res://Modules/SrSpeciesPack/Lizard/Script/GeckoHead1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/GeckoHead2.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/GeckoHead3.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/LizardHead1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/ChameleonHead1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/ChameleonHead2.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/LizardEars1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/LizardEars2.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/ChameleonHorns.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/LizardTail1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/LizardTail2.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/FatTail1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/FatTail2.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/FatTail3.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/FatTail4.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/FatTailSkin.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/ChameleonTail1.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/ChameleonTail2.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/ChameleonTailSkin.gd",
		"res://Modules/SrSpeciesPack/Lizard/Script/DroppedTail.gd",
	]

