extends BodypartTail

func _init():
	visibleName = "fossa tail (skin)"
	id = "sugerrfossatailskin"

func getCompatibleSpecies():
	return ["sugerrfossa"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["fossa"])

func getDoll3DScene():
	return "res://Modules/SrSpeciesPack/Fossa/PNG/FossaTailSkin/FossaTail.tscn"

func getCharacterCreatorDesc():
	return "(Sugerør's Species Pack)"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
	
func npcGenerationWeight(_dynamicCharacter):
	return 1.0
