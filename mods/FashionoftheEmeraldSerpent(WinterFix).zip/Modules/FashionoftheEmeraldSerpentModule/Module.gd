extends Module

func _init():
	id = "snakefashion"
	author = "JokeMysterious/WolfStarArt"

	items = [
		"res://Modules/FashionoftheEmeraldSerpentModule/SerpentsPiercings/SerpentsPiercings.gd",
		"res://Modules/FashionoftheEmeraldSerpentModule/SerpentLoincloth/SerpentLoincloth.gd",
		"res://Modules/FashionoftheEmeraldSerpentModule/OrnateSerpentCollar/OrnateSerpentCollar.gd",
		"res://Modules/FashionoftheEmeraldSerpentModule/ControlledOrnateSerpentCollar/ControlledOrnateSerpentCollar.gd",
		"res://Modules/FashionoftheEmeraldSerpentModule/SerpentJewelery/SerpentJewelery.gd",
		"res://Modules/FashionoftheEmeraldSerpentModule/SerpentChastityCage/SerpentChastityCage.gd",
		]
