extends ItemBase

func _init():
	id = "SerpentChastityCage"

func getVisibleName():
	return "Serpent Chastity Cage"
	
func getDescription():
	return "Prevents the ability to use your penis"

func getClothingSlot():
	return InventorySlot.Penis

func getRequiredBodypart():
	return BodypartSlot.Penis

func getBuffs():
	return [
		buff(Buff.ChastityPenisBuff),
		buff(Buff.SensitivityGainBuff, [25.0]),
		]

func getTakeOffScene():
	return "RestraintTakeOffNopeScene"

func getPrice():
	return 20

func canSell():
	return true

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.ChastityCage]

func isRestraint():
	return true

func generateRestraintData():
	restraintData = RestraintChastityCage.new()
	restraintData.setLevel(RNG.randi_range(3, 5))

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize()+" was locked onto your penis, making it useless!"
	else:
		return getAStackNameCapitalize()+" was locked onto {receiver.nameS} penis, making it useless!"

#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "caged")
#	doll.setBallsScale(0)


func getAIForceItemWeight(_whoForcesNpc, _targetNpc):
	return 0.1

func getInventoryImage():
	return "res://Modules/FashionoftheEmeraldSerpentModule/SerpentChastityCage/serpentcage_inv.png"

func getRiggedParts(_character):
	return {
		"chastity_cage": "res://Modules/FashionoftheEmeraldSerpentModule/SerpentChastityCage/SerpentCage.tscn",
	}

func shouldBeVisibleOnDoll(_character, _doll):
	if(!_character.isBodypartCovered(BodypartSlot.Penis) || _doll.isForcedExposed(BodypartSlot.Penis)):
		return true
	return false



func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
	}
