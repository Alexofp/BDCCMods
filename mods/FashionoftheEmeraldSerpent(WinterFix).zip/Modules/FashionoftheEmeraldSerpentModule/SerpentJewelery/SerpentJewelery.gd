extends ItemBase

func _init():
	id = "SerpentJewelery"

func getVisibleName():
	return "Serpent Jewelery"

func getDescription():
	return "Description:A series of ornate gold jewelery pieces addorned with emeralds and ivory rope. Also has a fabric skirt and arm cufflings. Used by the Emerald Serpents."

func getClothingSlot():
	return InventorySlot.Torso

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"jewelery": "res://Modules/FashionoftheEmeraldSerpentModule/SerpentJewelery/SerpentJewelery.tscn"}

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your jewelery"
	else:
		return "take off your jewelery"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your jewelery"
	else:
		return "put on your jewelery"

func getPrice():
	return 100000

func getTags():
	return [
		ItemTag.SoldByTheAnnouncer,
		]

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 125]),
		buff(Buff.MaxLustBuff, [15]),
		buff(Buff.LustArmorBuff, [-5]),
		buff(Buff.ExposureBuff, [200]),
		buff(Buff.FertilityBuff, [100]),
		buff(Buff.OvulationEggsAmountBuff, [35]),
		buff(Buff.FetishGainBuff, [10]),
		buff(Buff.TransformationSpeedBuff, [100]),
		buff(Buff.ForcedObedienceBuff, [50]),
		]

func getInventoryImage():
	return "res://Modules/FashionoftheEmeraldSerpentModule/SerpentJewelery/icon.tres"
