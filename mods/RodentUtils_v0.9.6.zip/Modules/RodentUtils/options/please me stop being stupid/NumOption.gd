extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = _option.getValue()
	$SpinBox.value = v
	if $HSlider.visible:
		$HSlider.value = v

func unconfigValueSetter(_option) -> void:
	return

func configValueSetter(_option) -> void:
	if !_option.shouldHaveSlider():
		$HSlider.hide()
		return
	
	$HSlider.show()
	$HSlider.min_value = _option.minValue
	$HSlider.max_value = _option.maxValue
	$HSlider.step = _option.step
	


func _on_HSlider_value_changed(value: float) -> void:
	if option && $HSlider.visible:
		option.setValue(value)


func _on_SpinBox_value_changed(value: float) -> void:
	if option:
		option.setValue(value)
