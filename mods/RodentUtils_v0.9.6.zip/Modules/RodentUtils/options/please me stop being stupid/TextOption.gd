extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func _ready() -> void:
	$LineEdit.connect("text_changed", self, "setText")

func setText(t:String) -> void:
	if option:
		option.setValue(t)

func onOptionValueChanged(_option) -> void:
	var v = $LineEdit
	var fv = _option.getValue()
	if v.text != fv:
		v.text = fv
