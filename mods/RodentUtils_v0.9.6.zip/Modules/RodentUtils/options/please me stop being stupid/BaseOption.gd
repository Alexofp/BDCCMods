extends HBoxContainer

var option

func _ready() -> void:
	$Defaults.key_label.text = ""
	
	rect_min_size.y = int(OPTIONS.isTouchFriendlyUI())*68.0

func onOptionValueChanged(_option) -> void:
	return

func unconfigValueSetter(_option) -> void:
	return

func configValueSetter(_option) -> void:
	return

func setToOption(op) -> void:
	if option:
		if option.is_connected("valueChanged", self, "onOptionValueChanged"):
			option.disconnect("valueChanged", self, "onOptionValueChanged")
		
		if $Defaults.is_connected("pressedActually", option, "restoreDefault"):
			$Defaults.disconnect("pressedActually", option, "restoreDefault")
		
		if $Label.is_connected("mouse_entered", GlobalTooltip, "showTooltip"):
			$Label.disconnect("mouse_entered", GlobalTooltip, "showTooltip")
		
		if $Label.is_connected("mouse_exited", GlobalTooltip, "hideTooltip"):
			$Label.disconnect("mouse_exited", GlobalTooltip, "hideTooltip")
		
		unconfigValueSetter(option)
	
	
	option = op
	
	$Label.text = option.name
	
	$Label.connect("mouse_entered", GlobalTooltip, "showTooltip", [$Label, option.name, option.desc, false, true])
	
	$Label.connect("mouse_exited", GlobalTooltip, "hideTooltip", [$Label])
	
	option.connect("valueChanged", self, "onOptionValueChanged")
	
	$Defaults.connect("pressedActually", option, "restoreDefault")
	
	configValueSetter(option)
	
	onOptionValueChanged(option)

func _exit_tree() -> void:
	if option:
		option.disconnect("valueChanged", self, "onOptionValueChanged")
	
