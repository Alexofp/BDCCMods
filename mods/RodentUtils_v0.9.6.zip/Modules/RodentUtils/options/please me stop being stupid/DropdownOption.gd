extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = $OptionButton
	
	var idx : int = _option.dropdowns.find(_option.getValue())
	if idx!=-1:
		v.select(idx)
		v.text = _option.dropdowns[idx]

func setOptionValue(idx:int, _option) -> void:
	if idx < _option.dropdowns.size():
		_option.setValue(_option.dropdowns[idx])

func configValueSetter(_option) -> void:
	var valuesetter = $OptionButton
	var fvalue = _option.getValue()
	for v in _option.dropdowns:
		var idx : int = valuesetter.get_item_count()
		valuesetter.add_item(v)
		if v == fvalue:
			valuesetter.select(idx)
	
	valuesetter.connect("item_selected", self, "setOptionValue", [_option])


func unconfigValueSetter(_option) -> void:
	var valuesetter = $OptionButton
	if valuesetter.is_connected("item_selected", self, "setOptionValue"):
		valuesetter.disconnect("item_selected", self, "setOptionValue")
