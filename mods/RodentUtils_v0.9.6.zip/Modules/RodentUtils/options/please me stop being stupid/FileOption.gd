extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	var v = $FileDialog
	v.current_path = _option.getValue()
	$vb/Current.text = v.current_path if v.current_path else "(unset)"

func configValueSetter(_option) -> void:
	var v = $FileDialog
	v.connect("file_selected", _option, "setValue")
	v.access = _option.getExtra("access", FileDialog.ACCESS_USERDATA)
	v.set_filters(PoolStringArray(_option.getExtra("filters", [])))

func unconfigValueSetter(_option) -> void:
	var v = $FileDialog
	if v.is_connected("file_selected", _option, "setValue"):
		v.disconnect("file_selected", _option, "setValue")

func _ready() -> void:
	$vb/Browse.key_label.text = ""
