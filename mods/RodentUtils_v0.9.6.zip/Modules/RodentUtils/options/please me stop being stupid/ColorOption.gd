extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func onOptionValueChanged(_option) -> void:
	$ColorPickerButton.color = _option.getValue()

func _on_ColorPickerButton_color_changed(color: Color) -> void:
	if option:
		option.setValue(color)
