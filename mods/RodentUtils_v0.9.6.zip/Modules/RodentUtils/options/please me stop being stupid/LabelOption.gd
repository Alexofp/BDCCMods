extends "res://Modules/RodentUtils/options/please me stop being stupid/BaseOption.gd"

func setText(t:String) -> void:
	$Label2.text = t

func setColor(c:Color=Color.white) -> void:
	$Label2.self_modulate = c
