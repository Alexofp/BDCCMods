# Configuration
## Getting started
In your `Module.gd`:
```gdscript
func RatConfigure(config) -> void:
	config.addOptionNum(id, "optionIDorVariableName", "Category", "Option Name", "Description is here", 0.0)\ # 0.0 is default
		.setGreater().setMin(0.0).setStep(1.0) # examples
	# addOption always returns an option
	
	config.overrideModConfigName(id, "My Mod") # display in ratconfig
	config.overrideModConfigAuthor(id, "Made by Rat") # same
	
```
Supported option types (function, value type; they always return `Option`):
- `addOptionNum`, `float`
- `addOptionBool`, `bool`
- `addOptionText`, `String`
- `addOptionMultiline`, `String`
- `addOptionFile`, `String`
- `addOptionDirectory`, `String`
- `addOptionDropdown`, `String`
- `addOptionColor`, `Color`
Setting option ID to a variable of the same name in your Module requires that the variable is typed properly according to the text above. Example: `var optionedVar : float` for Num options.
## Options
Options are returned by the `addOption` functions, and their functions can be chained (always return `Option`), as seen above. Here's the supported functions and option types:
- All
	- `setPlayer`: Only editable in-game and saved individually for each save file
	- `setMainMenu`: Only editable from the main menu and not the pause menu
	- `addExtra(key:String, value)`: Set extra data
	- `setValue(value)`: Set the value, validates value type and clamps if needed
- Num
	- `noSlider`: Never display slider
	- `alwaysSlider`: Always display slider (if possible)
	- `setMin(float)`: Set a minimum value
	- `setMax(float)`: Set a maximum value
	- `setStep(float)`: Value will always snap to the closest factor(if that's the word? Multiplication? Anyway...) of the number specified
	- `setLesser(bool=true)`: Allow values smaller than minimum or not
	- `setGreater(bool=true)`: Allow values larger than maximum or not
	- 
- Directory
	- `setAccess(int)`: Sets filesystem access based on the Access variable in Godot's FileDialog
- File
	- `setAccess(int)`: Sets filesystem access based on the Access variable in Godot's FileDialog
	- `addFileFilter(String)`: Add a file filter, again see Godot's FileDialog
- Dropdown
	- `addDropdownOption(String)`: Add an option

Every option defaults to:
- Minimum `0.0`
- Maximum `100.0`
- Step `0.1`
- Greater & Lesser `false`
- Editable anywhere
- Default `null`
- Name `Option`
- Description empty
- ID empty
- Dropdowns empty
- No extra data

Non-chained functions you can use:
- `restoreDefault() -> void`: Restores default value
- `shouldHaveSlider() -> bool`: Returns `true` if this option should have a slider
- `getExtra(key:String, nullv=null) -> Variant`: Get the extra data `key` or return `nullv` if it doesn't exist
- `getValue() -> Variant`: Get the option's value or the default value if it's unset
- `getValueSimple() -> Variant`: Get the option's value or `null` if it's the wrong data type

Signals you can use:
- `valueChanged(option)`: Emitted when the value is changed, and returns the option (use `getValue` to get the value after)
## Rat Config
Below is a list for functions you can use on the `config` object in `RatConfigure(config)`.
- `removeModConfig(modID:String) -> void`: Remove a module's configuration page completely
- `clearModCategory(modID:String, category:String) -> void`: Clear all options from a category
- `addCategory(modID:String, category:String) -> void`: Add an empty category to a module
- `getOrCreateModConfig(modID:String) -> ModConfig`: Get the mod config object for a module or create it, always returns an object
- `getOption(modID:String, category:String, optionID:String) -> Option`: Get an option or `null`
## Mod Config
For general mod entries (mod config objects), you can use several functions to modify them:
- `hasCategory(category:String) -> bool`: Returns `true` if the category exists
- `getAllOptions() -> Array`: Get all options in a messy array
- `getOptionsInCategory(category:String) -> Array`: Get all options in a category, sorted by ID
- `overrideAuthor(newAuthorText:String) -> ModConfig`: Override author display in Rat Config, can be chained
- `overrideName(newModText:String) -> ModConfig`: Override mod display in Rat Config, can be chained
# Saving
RodentUtils can be used to handle saving and loading for data in your mod. Start by writing in `RatRegister(registry)` this:
```gdscript
func RatRegister(registry) -> void:
	registry.registerSavedMod(self)
```
Your module should, from now on, have these functions:
- `RatSave() -> Dictionary`: Save the data
- `RatLoad(_data:Dictionary) -> void`: Load the data and handle resets/new games
New games/resets will always load this data dictionary: `{"RESET":true}`
And that's it, your mod will now be able to handle its saving and loading however it wants, no flags needed.
# Slavery Utilities
## Getting started with actionable slaveries
RodentUtils contains some utilities for creating player slavery scenarios, the main part of which is the actionable slavery system. Use it like so, after creating your slavery def:

In your gameplay object (PlayerSlaveryBase normally), set it to extend `res://Modules/RodentUtils/UtilScripts/actionableSlavery.gd` instead

In your slavery scene (SceneBase), add this:
 ```gdscript
 func _run():
	 if state == "":
		 var slavery : PlayerSlaveryBase = GM.main.PS
		 saynn(slavery.getText())
		 
		 var theActions:Array = slavery.getActions()
		for action in theActions:
			addButton(action.name, action.description, "doAction", [action])
		
		for message in slavery.messages:
			addMessage(message)
		

func _react(action:String, _args):
	 var slavery : PlayerSlaveryBase = GM.main.PS
	 slavery.onNewReact()
	 
	 if action == "doAction" && _args:
		slavery.doAction(_args[0])
		setState("")
		return
	
	setState(action)
 ```
This will allow the basic gameplay you will implement to work.
## Basic implementation
The basic functions you need to define in your actionable slavery are:
- `doAction(action:Action) -> bool`: When an action is committed, return `true` if the action was handled, and remember to call the parent function `.doAction(action)`
- `getText() -> String`: The actual text to display at any given point
- `processTime(_time:int) -> void`: If needed, what to do when time passes
- `createIcons() -> void`: If needed, create icons. Make sure to call the parent function `.createIcons()` as well
- `clearIcons() -> void`: Same as above but for clearing
- `getActions() -> Array[Action]`: The actions a player can take at any given time
Creating actions for the `getActions()` function can be done like so:
```gdscript
func getActions() -> Array:
	var acts : Array = []
	
	if true:
		acts.append(
			Action.new("actionID").setName("This will be the button text")\
			.setDesc("This the description")\
			.setArgs(["arguments here if needed", true, 0.0])
			)
	
	return acts
```
Implementing the `doAction()` function is as simple as checking the action's ID and its arguments if needed, not dissimilar to implementing `_react()` for a regular scene.
## Creating and using extensions
Actionable slaveries support creating and using extensions for expanded functionality. An example of an extension is the `movableItems` script included in RodentUtils, which allows you to define items that the player can pick up, move around, and put down during the slavery.

A slavery extension has largely the same functions as a normal actionable slavery, with the difference of the `getID() -> String` function, which should return the ID of the extension.
An extension can be added to a slavery simply by doing this:
```gdscript
func _init():
	id = "test"
	
	extensions.clear()
	addExt(load("path/to/extension.gd").new())
```
And will then call some of its functions when needed. You will need to implement calling for these functions yourself, optionally:
- `processTurn() -> void`
- `getLateActions() -> Array`
Implementing all method should be fairly easy, since they're basically the same as the normal actionable slavery ones.
# Using Sortables
## Basic sortables
A sortable allows you to use binary search to find, add/replace and erase entries from an array easily. To use a basic sortable, create it using `RodentUtils.createSortableSimple()` and use its functions like normal. A quick overview of some of the functions:
- `getThing(thing, array, nullv=null) -> Variant`: Get a value from an array, or return `nullv`
- `addThing(thing, array) -> void`: Add a value to the array, or replace it if it exists (useful for normal sortables, here it's kinda superfluous)
- `removeThing(thing, array) -> void`: Remove a value from the array
- `getOrAddThing(thing, array, nullv=null)`: Either get a value or add it to the array and return it (once again more useful with normal sortables)
## Normal sortables
Normal sortables can be created like so:
```gdscript
var sortable : Reference = RodentUtils.createSortable()\
	.setObject(self).setSort("sort_arrays")\
	.setComparison("arrays_same")

func sort_arrays(a, b) -> bool:
	return a[0] < b[0]

func arrays_same(a, b) -> bool:
	return a[0] == b[1]
```
They are used just like basic ones. Their strength lies in that you can set which object, sorting method, and identification/comparison method to use, which allows you to use them to sort objects. This is where replacing and getting-or-adding values matters.
# Miscellaneous Utilities
All of these can be found in the RodentUtils module and used:
- `scaledString(array:Array, number) -> String`: Expects array like so:
	```gdscript
	[
		[10.0, "This will be displayed if the number is bigger or equal to 10"],
		[5.0, ["This will be displayed if the number is between 10 and 5, including 5 and excluding 10", "This too, half of the time"]],
		
		["This will be displayed when the number is smaller than 5", "Or this, 1/3 of the time", "Or this. You can also just use a regular String instead of an array"]
	]
	```
- `scaledConditions(array:Array) -> Variant`: Expects an array like so:
	```gdscript
	[
		[false, "this won't appear"],
		[randi() % 2 == 1, "this one is a coinflip"],
		[false, 123.0], # not this one
		
		"this will be returned if all others above it are false, and can be any type of value"
	]
	```
- `readJsonData(path:String, type:int, nullv=null) -> Variant`: Read a JSON file at path, expecting result of Variant.Type = type, returning `nullv` if it fails and printing proper error messages
- `floorify(n:int) -> String`: Returns String like 1st, 2nd, 13th, etc. depending on `n`, I don't know what that's called in English so that's all you get