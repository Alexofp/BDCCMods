extends HTTPRequest

var authors : PoolStringArray
var mods : PoolStringArray

const saveDir : String = "user://RodentUtils/SlopWatch.json"

signal offendingModFound(mod)
signal offendingAuthorFound(author)

var flaggedData : Dictionary = {}

func isFlagged() -> bool:
	return !flaggedData.empty()

func pleaseRemoveMe(_mod) -> void:
	return

func check(show:bool=false) -> bool:
	flaggedData = updateFlagged()
	
	if show && isFlagged():
		Log.warning("\n== SlopWatch report ==")
		Log.warning("\nAuthors:")
		for author in flaggedData.get("authors", []):
			Log.warning("\t"+author)
		
		Log.warning("\nMods:")
		for mod in flaggedData.get("mods", []):
			Log.warning("\t"+mod)
		
		Log.warning("\n== End of report ==\n")
	
	return isFlagged()

func updateFlagged() -> Dictionary:
	var found : Dictionary = {}
	for mod in GlobalRegistry.getModules().values():
		if mod.id in mods:
			emit_signal("offendingModFound", mod.id)
			found.get_or_add("mods", []).append(mod.id)
			continue
		
		if mod.author.strip_escapes() in authors:
			emit_signal("offendingAuthorFound", mod.author)
			found.get_or_add("authors", []).append(mod.author)
			found.get_or_add("mods", []).append(mod.id)
		
	
	return found

func save(txt:String) -> void:
	var f = File.new()
	var d = Directory.new()
	d.make_dir_recursive(saveDir.get_base_dir())
	
	if f.open(saveDir, File.WRITE)==OK:
		f.store_string(txt)
		f.close()
	

func loadData() -> void:
	var f = File.new()
	if f.open(saveDir, File.READ)!=OK:
		return
	
	var result = JSON.parse(f.get_as_text())
	if(result.error != OK):
		Log.printerr("RodentUtils/SlopWatch: Can't parse JSON data")
		return
	
	var slopData = result.result
	
	if typeof(slopData)!=TYPE_DICTIONARY:
		Log.printerr("RodentUtils/SlopWatch: File data has unexpected type")
		return
	
	mods = PoolStringArray(slopData.get("mods", []))
	authors = PoolStringArray(slopData.get("authors", []))

func doRequest() -> void:
	var er = request("https://raw.githubusercontent.com/Selinoccino/BDCC_SlopWatch/refs/heads/main/data.json")
	
	if er != OK:
		Log.printerr("RodentUtils/SlopWatch: Error requesting data from GitHub repository")

func _ready() -> void:
	connect("request_completed", self, "requestCompleted")
	doRequest()

func requestCompleted(result: int, _response_code: int, _headers: PoolStringArray, body: PoolByteArray) -> void:
	if !readDataFromRequest(result, _response_code, _headers, body):
		loadData()
	
	check()

func readDataFromRequest(result: int, _response_code: int, _headers: PoolStringArray, body: PoolByteArray) -> bool:
	if result != HTTPRequest.RESULT_SUCCESS:
		Log.printerr("RodentUtils/SlopWatch: Can't access GitHub repository")
		return false
	
	var txt = body.get_string_from_utf8()
	var jsonResult = JSON.parse(txt)
	if(jsonResult.error != OK):
		Log.printerr("RodentUtils/SlopWatch: Can't parse GitHub JSON data")
		return false
	
	var slopData = jsonResult.result
	
	if typeof(slopData)!=TYPE_DICTIONARY:
		Log.printerr("RodentUtils/SlopWatch: GitHub data has unexpected type")
		return false
	
	save(txt)
	mods = PoolStringArray(slopData.get("mods", []))
	authors = PoolStringArray(slopData.get("authors", []))
	
	return true
