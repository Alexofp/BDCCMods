extends Reference

const MOD : String = "RodentUtils"



var idSortable : Reference

var affections : Array = []
var savedMods : Array = [] # array of modules


func registerSavedMod(mod) -> void:
	idSortable.addThing(mod, savedMods)

func registerConfigMod(mod) -> void:
	idSortable.addThing(mod, savedMods)

func getSavedMods() -> Array:
	return savedMods

func registerAffection(path:String) -> void:
	registerThing(path, affections, "Affection")

func getAffection(id:String) -> Reference:
	return idSortable.getThing(id, affections, null)

func registerThing(path:String, dar:Array, thingName:String="thing") -> void:
	
	var mod = GlobalRegistry.getModule(MOD)
	var obj = load(path).new()
	if !obj:
		if mod.verbose(mod.Verbs.BRIEF):
			Log.printerr("%s: Can't register %s (path: %s)!" % [MOD, thingName, path])
		return
	
	if mod.verbose(mod.Verbs.VERBOSE):
		Log.print("%s: Registered %s with ID \"%s\" (path: %s)" % [MOD, thingName, obj.id, path])
	
	idSortable.addThing(obj, dar)

func saveData() -> Dictionary:
	var d : Dictionary = {
	}
	
	var pers : Dictionary = getPeristentObjectsDict()
	for key in pers:
		d[key]={}
		for object in pers[key]:
			d[key][object.id] = object.saveData()
	
	return d

func getPeristentObjectsDict() -> Dictionary:
	return {
		"affections": affections, # key: array
	}

func resetData() -> void:
	for affection in affections:
		affection.resetData()


func loadData(d:Dictionary) -> void:
	if d.get("RESET", false): # TODO: remove when update extenders
		for affection in affections:
			affection.loadData(d)
		return
	
	# objects with save-specific data but persistent presence
	var persistentObjects : Dictionary = getPeristentObjectsDict()
	for key in persistentObjects:
		loadPersistentObject(key, persistentObjects[key], d)
		
	
	# ephemeral: objects that only exist per save file
	for array in []:
		array.clear()
	
	# for dict in d.get(key, []): createobject, object.loaddata(dict)
	

func loadPersistentObject(key:String, array:Array, data:Dictionary) -> void:
	var persistentData = SAVE.loadVar(data, key, {})
	for object in array:
		object.loadData(persistentData.get(object.id, {"RESET":true}))
