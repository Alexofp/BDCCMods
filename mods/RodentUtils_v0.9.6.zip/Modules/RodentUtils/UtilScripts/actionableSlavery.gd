extends PlayerSlaveryBase

var messages : PoolStringArray = []

var extraText : String = "" # after

var extensions : Dictionary = {}

class Action:
	var id : String = ""
	var name : String = "Action"
	var description : String = "Do the action"
	var args : Array = []
	
	func _init(n:String):
		self.id = n
	
	func setDesc(d:String) -> Action:
		self.description = d
		return self
	
	func setName(n:String) -> Action:
		self.name = n
		return self
	
	func setArgs(a:Array) -> Action:
		self.args = a
		return self
	

func getActions() -> Array:
	var acts : Array = []
	for ext in extensions.values():
		acts.append_array(acts)
	return acts

func onNewDay() -> void:
	for ext in extensions.values():
		ext.onNewDay()

func doAction(_action:Action) -> bool:
	for ext in extensions.values():
		if ext.doAction(_action):
			return true
	return false

func onNewReact() -> void:
	clearMessages()
	extraText = ""

func clearMessages() -> void:
	messages.clear()

func getText() -> String:
	return ""

func processTime(_time:int) -> void:
	return

func createIcons() -> void:
	for ext in extensions.values():
		ext.createIcons()
	

func clearIcons() -> void:
	for ext in extensions.values():
		ext.clearIcons()

func onSlaveryStart():
	for ext in extensions.values():
		ext.onSlaveryStart()

func onSlaveryEnd():
	for ext in extensions.values():
		ext.onSlaveryEnd()

func getExt(id:String) -> Reference:
	return extensions.get(id, null)

func addExt(ext:Reference) -> void:
	extensions[ext.getID()] = ext

func saveData():
	var d : Dictionary = {"extensions":{}}
	for ext in extensions.values():
		d["extensions"][ext.getID()] = ext.saveData()
	
	return d

func loadData(d):
	var extData = SAVE.loadVar(d, "extensions", {})
	for ext in extensions.values():
		ext.loadData(SAVE.loadVar(extData, ext.getID(), {}))
