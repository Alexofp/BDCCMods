extends Module

func _init():
		id = "VHairAndParts"
		author = "Verdeth"
		
		bodyparts = [
			"res://Modules/VHairPartsAndParts/Parts/Scripts/VHair1.gd",
			"res://Modules/VHairPartsAndParts/Parts/Scripts/VHair2.gd",
			"res://Modules/VHairPartsAndParts/Parts/Scripts/VHair3.gd",
			"res://Modules/VHairPartsAndParts/Parts/Scripts/VHair3l.gd",
			"res://Modules/VHairPartsAndParts/Parts/Scripts/VHair4.gd",
			"res://Modules/VHairPartsAndParts/Parts/Scripts/VHorn1.gd"
		
					]
