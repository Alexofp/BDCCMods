extends BodypartHair

func _init():
	visibleName = "Vhair3l"
	id = "Vhair3l"

	maleWeight = 1.0
	femaleWeight = 1.0

func getDoll3DScene():
	return "res://Modules/VHairPartsAndParts/Parts/Source/VHair3l/VHair3l.tscn"
