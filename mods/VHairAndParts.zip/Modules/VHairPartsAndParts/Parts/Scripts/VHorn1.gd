extends BodypartHorns

func _init():
	visibleName = "VHorn1"
	id = "VHorn1"

func getDoll3DScene():
	return "res://Modules/VHairPartsAndParts/Parts/Source/VHorn1/VHorn1.tscn"

func npcGenerationWeight(_dynamicCharacter):
	return 0.05
