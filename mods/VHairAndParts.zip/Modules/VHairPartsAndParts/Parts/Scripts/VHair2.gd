extends BodypartHair

func _init():
	visibleName = "Vhair2"
	id = "Vhair2"

	maleWeight = 1.0
	femaleWeight = 1.0

func getDoll3DScene():
	return "res://Modules/VHairPartsAndParts/Parts/Source/VHair2/VHair2.tscn"
