extends BodypartHair

func _init():
	visibleName = "Vhair3"
	id = "Vhair3"

	maleWeight = 1.0
	femaleWeight = 1.0

func getDoll3DScene():
	return "res://Modules/VHairPartsAndParts/Parts/Source/VHair3/VHair3.tscn"

func getTraits():
	return {
		PartTrait.HairShort: true,
	}
