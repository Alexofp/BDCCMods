extends BodypartHair

func _init():
	visibleName = "Vhair1"
	id = "Vhair1"

	maleWeight = 1.0
	femaleWeight = 1.0

func getDoll3DScene():
	return "res://Modules/VHairPartsAndParts/Parts/Source/VHair1/VHair1.tscn"

func getTraits():
	return {
		PartTrait.HairShort: true,
	}
