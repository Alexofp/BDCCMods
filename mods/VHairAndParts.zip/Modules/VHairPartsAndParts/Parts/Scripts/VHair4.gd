extends BodypartHair

func _init():
	visibleName = "Vhair4"
	id = "Vhair4"

	maleWeight = 1.0
	femaleWeight = 1.0

func getDoll3DScene():
	return "res://Modules/VHairPartsAndParts/Parts/Source/VHair4/VHair4.tscn"
