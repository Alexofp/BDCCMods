extends Module

var RatRegistry : Reference = load("res://Modules/RodentUtils/RatRegistry.gd").new()

var Options : Reference = load("res://Modules/RodentUtils/options/Options.gd").new()

var ratmode : bool = false setget setRatmode

func setRatmode(v) -> void:
	ratmode = v
	emit_signal("ratmode_changed", v)

signal ratmode_changed(new)
signal configClosed

var idSortable : Reference

var verbosity : int = Verbs.BRIEF
enum Verbs {
	NONE,
	BRIEF,
	VERBOSE,
	
	TOTAL_SIZE
}

func getVerbosity() -> int:
	return verbosity

func verbose(level:int, current:int=getVerbosity()) -> bool:
	return current >= level


class Sorter:
	static func sort_pers_arrays(a, b) -> bool:
		return a[0] < b[0]
	
	static func are_ids_same(a, b) -> bool:
		if typeof(a) == TYPE_OBJECT:
			a = a.id
		if typeof(b) == TYPE_OBJECT:
			b = b.id
		
		return a == b

	static func sort_ids(a, b) -> bool:
		if typeof(a) == TYPE_OBJECT:
			a = a.id
		if typeof(b) == TYPE_OBJECT:
			b = b.id
		
		return a < b
	


func _init():
	id = "RodentUtils"
	author = "Selinoccino"
	
	GlobalRegistry.connect("loadingFinished", self, "onLoadingFinished")
	
	
	idSortable = createSortable().setSort("sort_ids").setObject(Sorter)\
		.setComparison("are_ids_same")
	
	RatRegistry.idSortable = idSortable
	Options.sortable = idSortable
	
	
	scenes = [
		"res://Modules/RodentUtils/scenes/affectionviewer.gd"
	]
	
	gameExtenders = [
		"res://Modules/RodentUtils/RatSaver.gd"
	]
	
	worldEdits = [
		"res://Modules/RodentUtils/menuEdit.gd"
	]

func onLoadingFinished() -> void:
	for module in GlobalRegistry.getModules().values():
		if module.has_method("RatRegister"):
			module.RatRegister(self.RatRegistry)
			
			Log.print("RatRegistry: Registered %s Module by %s" % [module.id, module.author if module.author else "(unknown)"])
		if module.has_method("RatConfigure"):
			module.RatConfigure(self.Options)
		
	
	Options.loadFromFile()
	emit_signal("configClosed")

func RatConfigure(ratconf:Reference) -> void:
	ratconf.overrideModConfigName(id, "Rodent Utilities")
	ratconf.addOptionBool(id, "ratmode", "General", "Ratmode", "What's a 'tone?'", false)
	ratconf.addOptionNum(id, "verbosity", "General", "Verbosity", "0: None\n1: Brief\n2: Verbose", Verbs.BRIEF).setStep(1)\
		.setMin(0).setMax(Verbs.TOTAL_SIZE-1)

#func RatRegister(_ratRegistry:Reference) -> void:
#	return

func floorify(f:int) -> String:
	if f/10%10!=1: # second to last digit
		match f % 10: # last digit
			1:
				return "%sst" % f
			2:
				return "%snd" % f
			3:
				return "%srd" % f
	
	return "%sth" % f

func createSortable() -> Reference:
	return load("res://Modules/RodentUtils/UtilScripts/sortable.gd").new()

func createSortableSimple() -> Reference:
	return load("res://Modules/RodentUtils/UtilScripts/sortableSimple.gd").new()

## type is from Variant.Type thingy
func readJsonData(path:String, type:int, nullval=null):
	var f = File.new()
	
	var e = f.open(path, File.READ)
	
	if e != OK:
		Log.error("%s: Error accessing JSON data file %s, code %s" % [ id, path, e])
		return nullval
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		Log.error("%s: Error reading JSON data from file %s, code %s at line %s, message: %s" % [ id, path, r.error, r.error_line, r.error_string ])
		return nullval
	
	if typeof(r.result) != type:
		Log.error("%s: Error parsing JSON data from file %s, unexpected return type, type: %s, expected: %s" % [ id, path, typeof(r.result), type ])
		return nullval
	
	
	return r.result
	

func scaledConditions(ar:Array): # [condition, value], last one is value
	if !ar:
		return null
	var lastVal = ar.pop_back()
	for car in ar:
		if car[0]:
			return car[1]
	
	return lastVal
	

## expects array[ array[num, string (or array of strings) ], ... , ... , [string(s)] (least)], biggest first (checked if bigger than), least last
func scaledString(scalesArray:Array,num) -> String:
	if !scalesArray:
		return ""
	var lastThing = scalesArray.pop_back()
	for idx in scalesArray.size():
		var ar = scalesArray[idx]
		if num>=ar[0]:
			if typeof(ar[1]) == TYPE_ARRAY:
				return RNG.pick(ar[1])
			return ar[1]
	return RNG.pick(lastThing) if typeof(lastThing) == TYPE_ARRAY else lastThing

func getMenuButtons() -> Array:
	return [menuButton("RAT_Options", "RatConfig", "Configure mods")]

func onMenuButton(_buttonID:String, _menuScene):
	if _buttonID == "RAT_Options":
		_menuScene.setCustomScreen(load("res://Modules/RodentUtils/options/modsListAndMenuYayColonThree.tscn").instance())

func getPersonalityStatsSorted(pers:Personality) -> Array: # [stat, value], [...]
	var r : Array = []
	
	for stat in PersonalityStat.getAll():
		var v = pers.getStat(stat)
		r.append([stat, v])
	
	r.sort_custom(Sorter, "sort_pers_arrays")
	return r

func getFirstPersoKey(provided:Array, sorted:Array):
	for array in sorted:
		if provided.has(array[0]):
			return array[0]
	
	return null

func persoSpeech(charid, data:Dictionary={}, statsArray=null) -> String:
	var ch : BaseCharacter = GM.main.getCharacter(charid) if typeof(charid)==TYPE_STRING else charid
	if !ch:
		return "ERROR: no char found for func persospeech"
	
	var finalkey : String = "default"
	
	if statsArray == null:
		statsArray = getPersonalityStatsSorted(ch.getPersonality())
	
	for array in statsArray:
		if data.has(array[0]):
			finalkey = array[0]
			break
	
	var v = data.get(finalkey, null)
	if v == null:
		v = data.get("default", "no line found")
	
	return v if typeof(v)==TYPE_STRING else RNG.pick(v)

