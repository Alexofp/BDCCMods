extends Module

# Doll rendering tweaks, configured via FoxLib "Mod Options". No game files are replaced.
#
# Supersampling: the doll textures have ~100 px per unit but the doll panel shows ~47 px per unit and
# the textures have no mipmaps, so lines get jagged. Every 3D viewport shown by a CustomViewportControl
# is rendered at <factor> times its pixel size and scaled back down with a box filter shader.
# size_override keeps the viewport's input/camera coordinates at the original size, so the vanilla
# CustomViewportControl input code keeps working unchanged.
#
# Shoulder fade: upper arm textures have a closed round outline at the shoulder that is drawn on top
# of the torso. For meshes of the arms slot that are skinned to an upper arm bone, the pattern shader
# gets a variant that fades the alpha out towards the shoulder end, so the torso's own outline shows.
#
# Pattern smoothing: every pattern shader of a doll part gets a variant with a smoother skin pattern
# lookup (see PATTERN_FUNCTIONS). Both shader changes are combined into one variant per original shader.

const CATEGORY = "Doll render tweaks"
const VIEWPORT_CONTROL_SCRIPT = "res://UI/CustomViewportControl.gd"
const VIEWPORT_GROUP = "DollRenderTweaksViewport"
const PATTERN_GROUP = "DollRenderTweaksPattern"
const MAX_FACTOR = 4

const DOWNSAMPLE_SHADER = """shader_type canvas_item;
uniform int factor = 2;

void fragment() {
	float f = float(factor);
	vec4 sum = vec4(0.0);
	for (int x = 0; x < 4; x++) {
		if (x >= factor) {
			break;
		}
		for (int y = 0; y < 4; y++) {
			if (y >= factor) {
				break;
			}
			vec2 offset = (vec2(float(x), float(y)) - vec2((f - 1.0) * 0.5)) * TEXTURE_PIXEL_SIZE;
			sum += texture(TEXTURE, UV + offset);
		}
	}
	COLOR = sum / (f * f);
}
"""

const FADE_UNIFORMS = "\nuniform vec2 drt_fade_dir;\nuniform float drt_fade_start;\nuniform float drt_fade_end;\n"
const FADE_LINE = " ALPHA *= smoothstep(drt_fade_start, drt_fade_end, dot(base_uv, drt_fade_dir));"

# The skin pattern (r/g/b = which color goes where) has hard edges and is magnified a lot, plain bilinear
# filtering turns diagonal edges into stairs. drt_pattern() samples it with a cubic B-spline (4 bilinear
# taps) and optionally raises the channels to a power before the vanilla code normalizes them, which
# makes the color borders crisp again while keeping their smooth outline.
const PATTERN_CALL = "texture(texture_pattern,UV_pattern)"
const PATTERN_UNIFORMS = "\nuniform float drt_pattern_crisp = 1.0;\n"
const CUBIC_FUNCTION = """vec4 drt_cubic(float v) {
	vec4 n = vec4(1.0, 2.0, 3.0, 4.0) - v;
	vec4 s = n * n * n;
	float x = s.x;
	float y = s.y - 4.0 * s.x;
	float z = s.z - 4.0 * s.y + 6.0 * s.x;
	float w = 6.0 - x - y - z;
	return vec4(x, y, z, w) * (1.0 / 6.0);
}

"""
const PATTERN_FUNCTIONS = """vec4 drt_pattern(vec2 uv) {
	vec2 size = vec2(textureSize(texture_pattern, 0));
	vec2 coord = uv * size - 0.5;
	vec2 fxy = fract(coord);
	coord -= fxy;
	vec4 xc = drt_cubic(fxy.x);
	vec4 yc = drt_cubic(fxy.y);
	vec4 c = coord.xxyy + vec2(-0.5, 1.5).xyxy;
	vec4 s = vec4(xc.xz + xc.yw, yc.xz + yc.yw);
	vec4 offset = (c + vec4(xc.yw, yc.yw) / s) / size.xxyy;
	vec4 s0 = texture(texture_pattern, offset.xz);
	vec4 s1 = texture(texture_pattern, offset.yz);
	vec4 s2 = texture(texture_pattern, offset.xw);
	vec4 s3 = texture(texture_pattern, offset.yw);
	float sx = s.x / (s.x + s.y);
	float sy = s.z / (s.z + s.w);
	vec4 result = mix(mix(s3, s2, sx), mix(s1, s0, sx), sy);
	result.rgb = pow(max(result.rgb, vec3(0.0)), vec3(drt_pattern_crisp));
	return result;
}

"""
const CRISP_EXPONENT = 3.0

# lineSmoothing 2: cubic B-spline lookup (smooth but blurry), then the amount of dark "ink" is pushed
# through a threshold that is one screen pixel wide (fwidth), like a distance field font. The blurred
# stair steps become smooth, crisp outlines. Only near-black lines are sharpened, grey shading is kept.
const ALBEDO_VECTOR_FUNCTIONS = """vec4 drt_albedo(vec2 uv) {
	vec2 size = vec2(textureSize(texture_albedo, 0));
	vec2 coord = uv * size - 0.5;
	vec2 fxy = fract(coord);
	coord -= fxy;
	vec4 xc = drt_cubic(fxy.x);
	vec4 yc = drt_cubic(fxy.y);
	vec4 c4 = coord.xxyy + vec2(-0.5, 1.5).xyxy;
	vec4 s = vec4(xc.xz + xc.yw, yc.xz + yc.yw);
	vec4 offset = (c4 + vec4(xc.yw, yc.yw) / s) / size.xxyy;
	float sx = s.x / (s.x + s.y);
	float sy = s.z / (s.z + s.w);
	vec4 t0 = texture(texture_albedo, offset.xz);
	vec4 t1 = texture(texture_albedo, offset.yz);
	vec4 t2 = texture(texture_albedo, offset.xw);
	vec4 t3 = texture(texture_albedo, offset.yw);
	vec4 c = mix(mix(t3, t2, sx), mix(t1, t0, sx), sy);

	vec3 lumW = vec3(0.299, 0.587, 0.114);
	float lum = dot(c.rgb, lumW);
	float ink = c.a * (1.0 - lum);
	// Only real outlines are nearly black in the texture; grey shading and faint strokes stay soft
	float tapInk = max(max(t0.a * (1.0 - dot(t0.rgb, lumW)), t1.a * (1.0 - dot(t1.rgb, lumW))),
		max(t2.a * (1.0 - dot(t2.rgb, lumW)), t3.a * (1.0 - dot(t3.rgb, lumW))));
	float w = max(fwidth(ink) * 0.75, 0.01);
	float sharpInk = smoothstep(0.5 - w, 0.5 + w, ink);
	float newInk = mix(ink, sharpInk, smoothstep(0.75, 0.9, tapInk));
	float alpha = clamp(c.a + newInk - ink, 0.0, 1.0);
	float newLum = 1.0 - (alpha > 0.001 ? clamp(newInk / alpha, 0.0, 1.0) : 0.0);
	c.rgb = clamp(c.rgb * (newLum / max(lum, 0.001)), vec3(0.0), vec3(1.0));
	if (lum < 0.001) {
		c.rgb = vec3(newLum);
	}
	c.a = alpha;
	return c;
}

"""

# Body textures are magnified when the doll is zoomed in, bilinear filtering makes the outlines look
# stepped. drt_albedo() is a Catmull-Rom bicubic lookup in 9 bilinear taps: smooth but not blurry.
const ALBEDO_CALL = "texture(texture_albedo,base_uv)"
const ALBEDO_FUNCTIONS = """vec4 drt_albedo(vec2 uv) {
	vec2 size = vec2(textureSize(texture_albedo, 0));
	vec2 samplePos = uv * size;
	vec2 texPos1 = floor(samplePos - 0.5) + 0.5;
	vec2 f = samplePos - texPos1;
	vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
	vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
	vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
	vec2 w3 = f * f * (-0.5 + 0.5 * f);
	vec2 w12 = w1 + w2;
	vec2 texPos0 = (texPos1 - 1.0) / size;
	vec2 texPos3 = (texPos1 + 2.0) / size;
	vec2 texPos12 = (texPos1 + w2 / w12) / size;
	vec4 result = texture(texture_albedo, vec2(texPos0.x, texPos0.y)) * w0.x * w0.y;
	result += texture(texture_albedo, vec2(texPos12.x, texPos0.y)) * w12.x * w0.y;
	result += texture(texture_albedo, vec2(texPos3.x, texPos0.y)) * w3.x * w0.y;
	result += texture(texture_albedo, vec2(texPos0.x, texPos12.y)) * w0.x * w12.y;
	result += texture(texture_albedo, vec2(texPos12.x, texPos12.y)) * w12.x * w12.y;
	result += texture(texture_albedo, vec2(texPos3.x, texPos12.y)) * w3.x * w12.y;
	result += texture(texture_albedo, vec2(texPos0.x, texPos3.y)) * w0.x * w3.y;
	result += texture(texture_albedo, vec2(texPos12.x, texPos3.y)) * w12.x * w3.y;
	result += texture(texture_albedo, vec2(texPos3.x, texPos3.y)) * w3.x * w3.y;
	return clamp(result, vec4(0.0), vec4(1.0));
}

"""

var supersampling = 2
var shoulderFade = 15 # length of the fade in percent of the upper arm, 0 = off
var patternSmoothing = 2 # 0 = off, 1 = smooth, 2 = smooth + crisp
var lineSmoothing = 2 # 0 = off, 1 = bicubic body textures, 2 = vector-like outlines

var downsampleShader:Shader
var patchedShaders = {} # original Shader -> {variant: patched Shader or null if it can't be patched}
var textureExtents = {} # texture path -> [first, last] opaque row and column as UV

func _init():
	id = "DollRenderTweaks"
	author = "45hr4k"

	var tree = Engine.get_main_loop()
	if(tree is SceneTree && !tree.is_connected("node_added", self, "onNodeAdded")):
		var _ok = tree.connect("node_added", self, "onNodeAdded")

func onFoxLibModInit(foxModuleAPI):
	var option = foxModuleAPI.addListOptionInCategory(CATEGORY, "supersampling", "Doll supersampling", [
			[1, "Off"], [2, "2x (recommended)"], [3, "3x"], [4, "4x"],
		], "Renders the doll at a higher resolution and scales it down. Removes jagged lines.\nHigher = smoother but more GPU work.", 2)
	var _ok = option.connect("option_changed", self, "onSupersamplingChanged")

	option = foxModuleAPI.addListOptionInCategory(CATEGORY, "shoulderFade", "Shoulder fade", [
			[0, "Off"], [8, "Short (8%)"], [15, "Medium (15%)"], [22, "Long (22%)"], [30, "Very long (30%)"],
		], "Fades out the top of the upper arm so the shoulder blends into the torso instead of looking stuck on.\nNeeds the advanced shaders option (on by default).", 15)
	_ok = option.connect("option_changed", self, "onPatternOptionChanged")

	option = foxModuleAPI.addListOptionInCategory(CATEGORY, "patternSmoothing", "Pattern smoothing", [
			[0, "Off"], [1, "Smooth (softer borders)"], [2, "Smooth + crisp (recommended)"],
		], "Removes the stair steps at the borders of skin patterns (stripes, spots).\nNeeds the advanced shaders option and the GLES3 renderer.", 2)
	_ok = option.connect("option_changed", self, "onPatternOptionChanged")

	option = foxModuleAPI.addListOptionInCategory(CATEGORY, "lineSmoothing", "Line smoothing", [
			[0, "Off"], [1, "Bicubic (softer)"], [2, "Vector (recommended)"],
		], "Smoother outlines when the doll is zoomed in.\nBicubic = smoother texture filtering, Vector = smooth crisp outlines like a vector drawing.\nNeeds the advanced shaders option and the GLES3 renderer.", 2)
	_ok = option.connect("option_changed", self, "onPatternOptionChanged")

func onSupersamplingChanged(_value):
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		for control in tree.get_nodes_in_group(VIEWPORT_GROUP):
			applySupersampling(control)

func onPatternOptionChanged(_value):
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		for mesh in tree.get_nodes_in_group(PATTERN_GROUP):
			applyPatch(mesh)

func onNodeAdded(node):
	if(node is TextureRect):
		var script = node.get_script()
		if(script != null && script.resource_path == VIEWPORT_CONTROL_SCRIPT):
			call_deferred("onViewportControlAdded", weakref(node))
	# Doll3D.addPartObject(): skeleton.add_child(part), then part.initPart() -> handle it afterwards
	elif(node.has_method("initPart") && node.get_parent() is Skeleton):
		call_deferred("onPartAdded", weakref(node))

### Supersampling

func getFactor() -> int:
	return int(clamp(int(supersampling), 1, MAX_FACTOR))

func onViewportControlAdded(controlRef):
	var control = controlRef.get_ref()
	if(control == null || !is_instance_valid(control) || !control.is_inside_tree()):
		return
	var viewport = control.get_node_or_null(control.viewportPath)
	if(!(viewport is Viewport) || !hasCamera3D(viewport)):
		return # 2D viewports (map) would show more of the world instead of more detail
	control.add_to_group(VIEWPORT_GROUP)
	var _ok = control.connect("resized", self, "onViewportControlResized", [weakref(control)])
	# CustomViewportControl sets the viewport size in a deferred init_texture() that runs after this
	call_deferred("applySupersampling", control)

func hasCamera3D(node) -> bool:
	for child in node.get_children():
		if(child is Camera || hasCamera3D(child)):
			return true
	return false

func onViewportControlResized(controlRef):
	# The control resets the viewport size right after this signal, apply ours after that
	call_deferred("applySupersamplingRef", controlRef)

func applySupersamplingRef(controlRef):
	var control = controlRef.get_ref()
	if(control != null):
		applySupersampling(control)

func applySupersampling(control):
	if(!is_instance_valid(control) || !control.is_inside_tree()):
		return
	var viewport = control.get_node_or_null(control.viewportPath)
	if(!(viewport is Viewport)):
		return
	var baseSize = getBaseSize(control)
	if(baseSize == null):
		return
	var factor = getFactor()
	if(factor <= 1):
		viewport.set_size_override(false)
		viewport.size = baseSize
		control.material = null
		return
	viewport.size = baseSize * factor
	viewport.set_size_override(true, baseSize)
	viewport.size_override_stretch = true
	if(downsampleShader == null):
		downsampleShader = Shader.new()
		downsampleShader.code = DOWNSAMPLE_SHADER
	if(!(control.material is ShaderMaterial) || control.material.shader != downsampleShader):
		control.material = ShaderMaterial.new()
		control.material.shader = downsampleShader
	control.material.set_shader_param("factor", factor)

# Same as CustomViewportControl.getPixelSize() without its fallback to the (already scaled) viewport size
func getBaseSize(control):
	var rect = control.get_global_rect()
	if(is_nan(rect.size.x) || is_nan(rect.size.y) || rect.size.x < 1.0 || rect.size.y < 1.0):
		return null
	var size = rect.size
	var rootViewport = control.get_viewport()
	if(rootViewport.is_size_override_enabled()):
		size = rect.size / rootViewport.get_size_override() * rootViewport.size
	return Vector2(max(1.0, round(size.x)), max(1.0, round(size.y)))

### Pattern shader variants (shoulder fade, pattern smoothing)

func onPartAdded(partRef):
	var part = partRef.get_ref()
	if(part == null || !is_instance_valid(part) || !part.is_inside_tree()):
		return
	var isArms = (findSlot(part) == BodypartSlot.Arms)
	var stack = [part]
	while(!stack.empty()):
		var node = stack.pop_back()
		if(node is MeshInstance && node.mesh != null && node.get_surface_material(0) is ShaderMaterial):
			if(isArms):
				var info = getUpperArmInfo(node)
				if(info != null):
					node.set_meta("drtFadeInfo", info)
			node.add_to_group(PATTERN_GROUP)
			applyPatch(node)
		for child in node.get_children():
			if(child is Spatial):
				stack.append(child)

func findSlot(part):
	var doll = part.get("doll3D")
	if(doll == null || !is_instance_valid(doll)):
		return null
	var parts = doll.get("parts")
	if(!(parts is Dictionary)):
		return null
	for slot in parts:
		if(parts[slot] == part):
			return slot
	return null

static func isUpperArmBone(boneName:String) -> bool:
	var lower = boneName.to_lower()
	if("fore" in lower || "hand" in lower || "lower" in lower):
		return false
	return lower.begins_with("arm") || "upperarm" in lower || "upper_arm" in lower

# Returns {"head": UV of the vertex nearest to the shoulder joint, "tail": UV of the farthest one}
# or null if the mesh isn't mostly skinned to an upper arm bone.
func getUpperArmInfo(meshInstance:MeshInstance):
	if(meshInstance.mesh.get_surface_count() < 1):
		return null
	var arrays = meshInstance.mesh.surface_get_arrays(0)
	if(arrays.size() <= Mesh.ARRAY_WEIGHTS || arrays[Mesh.ARRAY_BONES] == null || arrays[Mesh.ARRAY_TEX_UV] == null):
		return null
	var vertices = arrays[Mesh.ARRAY_VERTEX]
	var uvs = arrays[Mesh.ARRAY_TEX_UV]
	var bones = arrays[Mesh.ARRAY_BONES]
	var weights = arrays[Mesh.ARRAY_WEIGHTS]
	if(vertices.size() < 3 || uvs.size() != vertices.size() || bones.size() < vertices.size() * 4):
		return null

	var boneWeights = {}
	for i in range(bones.size()):
		var bone = int(bones[i])
		boneWeights[bone] = boneWeights.get(bone, 0.0) + float(weights[i])
	var mainBone = -1
	for bone in boneWeights:
		if(mainBone < 0 || boneWeights[bone] > boneWeights[mainBone]):
			mainBone = bone

	# Bone indices point into the skin binds, or straight into the skeleton without a skin
	var skin:Skin = meshInstance.skin
	var skeleton = meshInstance.get_node_or_null(meshInstance.skeleton)
	var boneName = ""
	var headPos = null
	if(skin != null && mainBone < skin.get_bind_count()):
		boneName = skin.get_bind_name(mainBone)
		headPos = skin.get_bind_pose(mainBone).affine_inverse().origin
	elif(skeleton is Skeleton && mainBone < skeleton.get_bone_count()):
		boneName = skeleton.get_bone_name(mainBone)
		headPos = skeleton.get_bone_global_rest(mainBone).origin
	if(headPos == null || !isUpperArmBone(boneName)):
		return null

	# Average UV of the quarter of vertices nearest to / farthest from the shoulder joint
	# (for a quad: the middle of the shoulder edge and of the elbow edge)
	var byDistance = []
	for i in range(vertices.size()):
		byDistance.append([vertices[i].distance_squared_to(headPos), i])
	byDistance.sort_custom(self, "sortByFirst")
	var count = max(1, vertices.size() / 4)
	var head = Vector2.ZERO
	var tail = Vector2.ZERO
	for i in range(count):
		head += uvs[byDistance[i][1]]
		tail += uvs[byDistance[byDistance.size() - 1 - i][1]]
	return {"head": head / count, "tail": tail / count}

static func sortByFirst(a, b):
	return a[0] < b[0]

# Variant of a pattern shader with the given features ("fade", "pattern", "lines" or "linesVector").
# Returns null if the shader doesn't look like the vanilla pattern shader.
func getPatchedShader(original:Shader, features:Array):
	if(features.empty()):
		return original
	if(!patchedShaders.has(original)):
		patchedShaders[original] = {}
	var cache = patchedShaders[original]
	var variant = PoolStringArray(features).join("+")
	if(cache.has(variant)):
		return cache[variant]

	var code:String = original.code
	var ok = code.find("uniform ") >= 0
	var uniforms = ""
	var functions = ""
	if(ok && "fade" in features):
		var alphaPos = code.find_last("ALPHA =")
		var endPos = code.find(";", alphaPos) if alphaPos >= 0 else -1
		ok = endPos >= 0 && "base_uv" in code
		if(ok):
			code = code.insert(endPos + 1, FADE_LINE)
			uniforms += FADE_UNIFORMS
	if(ok && "pattern" in features):
		ok = PATTERN_CALL in code
		if(ok):
			code = code.replace(PATTERN_CALL, "drt_pattern(UV_pattern)")
			functions += PATTERN_FUNCTIONS
			uniforms += PATTERN_UNIFORMS
	var vectorLines = "linesVector" in features
	if(ok && ("lines" in features || vectorLines)):
		ok = ALBEDO_CALL in code
		if(ok):
			code = code.replace(ALBEDO_CALL, "drt_albedo(base_uv)")
			functions += ALBEDO_VECTOR_FUNCTIONS if vectorLines else ALBEDO_FUNCTIONS
	if("pattern" in features || vectorLines):
		functions = CUBIC_FUNCTION + functions
	if(ok && functions != ""):
		var fragmentPos = code.find("void fragment")
		ok = fragmentPos >= 0
		if(ok):
			code = code.insert(fragmentPos, functions)
	var patched = null
	if(ok):
		code = code.insert(code.find("uniform "), uniforms)
		patched = Shader.new()
		patched.code = code
	else:
		printerr("DollRenderTweaks: can't patch shader "+str(original.resource_path)+" with "+variant)
	cache[variant] = patched
	return patched

func applyPatch(meshInstance):
	if(!is_instance_valid(meshInstance)):
		return
	var material = meshInstance.get_surface_material(0)
	if(!(material is ShaderMaterial) || material.shader == null):
		return # advanced shaders off: plain SpatialMaterial, leave it alone
	if(!meshInstance.has_meta("drtOriginalShader")):
		meshInstance.set_meta("drtOriginalShader", material.shader)
	var original = meshInstance.get_meta("drtOriginalShader")

	var fadePercent = clamp(int(shoulderFade), 0, 100)
	var gles3 = OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES3 # textureSize() is missing in GLES2
	var wantedFeatures = []
	if(fadePercent > 0 && meshInstance.has_meta("drtFadeInfo")):
		wantedFeatures.append("fade")
	if(int(patternSmoothing) > 0 && gles3):
		wantedFeatures.append("pattern")
	if(int(lineSmoothing) > 0 && gles3):
		wantedFeatures.append("linesVector" if int(lineSmoothing) >= 2 else "lines")
	# Leave out the features this shader can't take
	var features = []
	for feature in wantedFeatures:
		if(getPatchedShader(original, [feature]) != null):
			features.append(feature)
	var wanted = getPatchedShader(original, features)
	if(wanted == null):
		wanted = original
	if(material.shader != wanted):
		setShaderKeepParams(material, wanted)

	if("drt_pattern_crisp" in wanted.code):
		material.set_shader_param("drt_pattern_crisp", CRISP_EXPONENT if int(patternSmoothing) >= 2 else 1.0)
	if("drt_fade_dir" in wanted.code):
		applyFadeParams(meshInstance, material, fadePercent)

# Fade along the UV axis that runs from shoulder to elbow, starting where the drawing begins
func applyFadeParams(meshInstance, material, fadePercent):
	var info = meshInstance.get_meta("drtFadeInfo")
	var head:Vector2 = info["head"]
	var tail:Vector2 = info["tail"]
	var axis = 0 if abs(tail.x - head.x) > abs(tail.y - head.y) else 1
	var dirSign = 1.0 if tail[axis] > head[axis] else -1.0
	var extent = getTextureExtent(material.get_shader_param("texture_albedo"), axis)
	var start = extent[0] if dirSign > 0.0 else extent[1]
	var length = (extent[1] - extent[0]) * fadePercent / 100.0
	var dir = Vector2(dirSign, 0.0) if axis == 0 else Vector2(0.0, dirSign)
	material.set_shader_param("drt_fade_dir", dir)
	material.set_shader_param("drt_fade_start", start * dirSign)
	material.set_shader_param("drt_fade_end", start * dirSign + length)

func setShaderKeepParams(material:ShaderMaterial, shader:Shader):
	var values = {}
	for param in VisualServer.shader_get_param_list(material.shader.get_rid()):
		values[param["name"]] = material.get_shader_param(param["name"])
	material.shader = shader
	for paramName in values:
		if(values[paramName] != null):
			material.set_shader_param(paramName, values[paramName])

# [first, last] row (axis 1) or column (axis 0) that has visible pixels, as UV. Falls back to [0, 1].
func getTextureExtent(texture, axis:int) -> Array:
	if(!(texture is Texture)):
		return [0.0, 1.0]
	var key = texture.resource_path + "|" + str(axis)
	if(key != "|"+str(axis) && textureExtents.has(key)):
		return textureExtents[key]
	var result = [0.0, 1.0]
	var image:Image = texture.get_data()
	if(image != null && !image.is_empty()):
		if(image.is_compressed()):
			image = image.duplicate()
			var _err = image.decompress()
		if(!image.is_compressed()):
			var size = image.get_size()
			var lineCount = int(size[axis])
			var first = -1
			var last = -1
			image.lock()
			for line in range(lineCount):
				if(lineHasPixels(image, axis, line, int(size[1 - axis]))):
					if(first < 0):
						first = line
					last = line
			image.unlock()
			if(first >= 0):
				result = [float(first) / lineCount, float(last + 1) / lineCount]
	if(key != "|"+str(axis)):
		textureExtents[key] = result
	return result

static func lineHasPixels(image:Image, axis:int, line:int, length:int) -> bool:
	for i in range(0, length, 2):
		var pixel = image.get_pixel(line, i) if axis == 0 else image.get_pixel(i, line)
		if(pixel.a > 0.5):
			return true
	return false
