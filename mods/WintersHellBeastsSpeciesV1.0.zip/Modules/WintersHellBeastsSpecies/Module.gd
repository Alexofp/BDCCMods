extends Module

var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")

func _init():
	id = "WintersHellBeastsSpecies"
	author = "Avery Winters"

	if (RAT_ArchetypeLoad == false):
		species = [
			"res://Modules/WintersHellBeastsSpecies/HellbeastFluffy.gd"
		]
	else:
		species = [
			"res://Modules/WintersHellBeastsSpecies/Hellbeast.gd"
		]

func getAddedRatArchetypes() -> Dictionary:
	var pathDir = "res://Modules/WintersHellBeastsSpecies/CompatibilityPatches/RAT_BodypartArchetypes/"
	
	return {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)
	#Base Species Archetypes
	"demon": [pathDir+"DemonArchetypes.json"],
	}
