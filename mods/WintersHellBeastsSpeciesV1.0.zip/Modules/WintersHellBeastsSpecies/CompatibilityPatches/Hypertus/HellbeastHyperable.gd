extends "res://Species/Demon.gd"

func _init():
	id = Species.Demon

func getVisibleName():
		return "Hellbeast"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffyhoofs"
	return "hoofs"

func getDefaultTail(_gender):
	return "demontail"

func getDefaultHorns(_gender):
	return "demonhorns"

func isPlayable():
	return true

func getVisibleDescription():
	return "Your non-friendly neighbors"

func getDefaultHead(_gender):
	return "wolfhead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultEars(_gender):
		return "wolfears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "equinepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 6.0],
		[3, 9.0],
		[4, 12.0],
		[5, 9.0],
		[6, 7.0],
		[7, 4.0],
	]

func npcGenerationWeight():
	return 0.5

func getSkinType():
	return SkinType.Fur

func getAllowedBodyparts():
	if ("AnonsBaseSpeciesExpansion" in GlobalRegistry.getModules()):
		return ["caninehead", "foxhead", "wolfhead", "canineears", "canineears2", "canineears3", "wolfears", "saberwolfhead", "hyenahead", "hyenaears", "jackalears", "jackalears2"] 
	return ["caninehead", "foxhead", "wolfhead", "canineears", "canineears2", "canineears3", "wolfears"]

#func generateSkinColors():
#	var humanColors = ColorUtils.generateGenericHumanSkinColors()
#	var furryColors = ColorUtils.generateGenericFurryColors()
#	humanColors[2] = RNG.pick(furryColors)
#	humanColors[2] = ColorUtils.generateRandomVibrantColor()
#	humanColors[2].v = RNG.randf_rangeX2(0.2, 0.5)
	
#	return humanColors
