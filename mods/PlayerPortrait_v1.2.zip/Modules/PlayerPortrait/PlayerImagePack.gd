extends ImagePack

var totalLust : int = 0
var totalHurt : int = 0
var totalArousal : int = 0

func _init():
	id = "RAT_PlayerPortrait"
	artist = "PlayerPortrait (Selinoccino)"
	

func reloadMyDataPleaseAndThankYou() -> void:
	characters.clear()
	
	var path = GM.main.getModuleFlag("PlayerPortrait", "PortraitsPath", "")
	
	if !path:
		Log.warning("PlayerPortrait: Portrait path isn't set! Setting to previous default (userdata/PlayerPortraits)")
		path = "user://PlayerPortraits"
		GM.main.setModuleFlag("PlayerPortrait", "PortraitsPath", path)
	
	var files : PoolStringArray = dir_contents(path)
	if files.size()==0:
		Log.warning("PlayerPortrait: Portrait folder is either empty or can't be accessed\nPath: %s" % path)
		return
	
	files.sort()
	
	var hurts = []
	var lusts = []
	var arouss = []
	var naked = ""
	var normal = ""
	var neutral_overlay = ""
	
	for file in files:
		if !normal && file.begins_with("normal"):
			normal = file
			continue
		
		if !neutral_overlay && file.begins_with("neutral"):
			neutral_overlay = file
			continue
		
		if !naked && file.begins_with("naked"):
			naked = file
			continue
		
		if file.begins_with("hurt"):
			hurts.append(file)
		elif file.begins_with("lust"):
			lusts.append(file)
		elif file.begins_with("arousal"):
			arouss.append(file)
	
	if !normal: # no normal variant somehow?
		if naked: # substitute with naked
			normal = naked
		else: # if not, just f off ig
			Log.warning("PlayerPortrait: Can't find normal or naked file for portrait")
			return
	normal = loadTexture(path.plus_file(normal))
	neutral_overlay = loadTexture(path.plus_file(neutral_overlay))
	
	var a = [normal]
	if neutral_overlay:
		a.append(neutral_overlay)
	
	doAddVariant([], a)
	
	if !naked:
		naked = normal
	else:
		naked = loadTexture(path.plus_file(naked))
	
	a = [naked]
	if neutral_overlay:
		a.append(neutral_overlay)
	
	doAddVariant(["naked"], a)
	
	
	for hurti in hurts.size():
		var hurtKey : String = formatVariantNum("hurt", hurti)
		var hurtFile : String = path.plus_file(hurts[hurti])
		
		var t = loadTexture(hurtFile)
		
		doAddVariant([hurtKey], [normal, t])
		doAddVariant([hurtKey, "naked"], [naked, t])
	
	for lusti in lusts.size():
		var lustKey : String = formatVariantNum("lust", lusti)
		var lustFile : String = path.plus_file(lusts[lusti])
		
		var t = loadTexture(lustFile)
		
		doAddVariant([lustKey], [normal, t])
		doAddVariant([lustKey, "naked"], [naked, t])
	
	
	for lusti in arouss.size():
		var lustKey : String = formatVariantNum("arousal", lusti)
		var lustFile : String = path.plus_file(arouss[lusti])
		
		var t = loadTexture(lustFile)
		
		doAddVariant([lustKey], [normal, t])
		doAddVariant([lustKey, "naked"], [naked, t])
	
	
	totalHurt = hurts.size()
	totalLust = lusts.size()
	totalArousal = arouss.size()

func getFinalVariantForCharacter():
	
	var f = []
	var pvar = ""
	
	var vs = [
		["getFinalVariantStringLust", GM.pc.getLustLevel()],
		["getFinalVariantStringHurt", GM.pc.getPainLevel()],
		["getFinalVariantStringArousal", GM.pc.getArousal()],
	]
	
	print("as%s" % GM.pc.getArousal())
	
	vs.sort_custom(self, "dosort")
	
	pvar = callv(vs[0][0], [vs[0][1]])
	
	if pvar:
		f.append(pvar)
	
	if GM.pc.isFullyNaked():
		f.append("naked")
	
	return f

func dosort(a,b):
	if a[1]>b[1]:
		return true
	
	elif a[1]==b[1]:
		return a[0].ends_with("Arousal") && b[0].ends_with("Lust") or a[0].ends_with("Pain")

func getFinalVariantString(type:String, perc:float, total:int) -> String:
	var v = getVariantForPercentageLevel(perc, total)
	if v<0:
		return ""
	return formatVariantNum(type, v)

func getFinalVariantStringLust(perc:float) -> String:
	return getFinalVariantString("lust", perc, totalLust)

func getFinalVariantStringArousal(perc:float) -> String:
	return getFinalVariantString("arousal", perc, totalArousal)

func getFinalVariantStringHurt(perc:float) -> String:
	return getFinalVariantString("hurt", perc, totalHurt)

func getVariantForPercentageLevel(perc:float=0.0, total:int=0) -> int:
	if total<=0:
		return -1
	
	var n : int = int(clamp(perc, 0.0, 1.0)*(total))-1 # total if perc>=1.0, else <total towards min 0 inclusive ig idk man i just work here. -1 cuz there should always be the normal one in case of min damage
	
	print(n)
	
	return n # return variant num

func formatVariantNum(variant:String, num:int) -> String:
	return variant + str(num).pad_zeros(2)

func doAddVariant(variant:Array, fullPath):
	addCharacter("RAT_FakePlayer", variant, fullPath)

func dir_contents(path) -> PoolStringArray:
	var r : PoolStringArray = []
	# copy-pasted but who cares tbh
	var dir : Directory = Directory.new()
	if !dir.dir_exists(path):
		Log.warning("PlayerPortrait: Portrait folder can't be found\nPath: %s" % path)
		return r
	
	var er = dir.open(path)
	if er == OK:
		dir.list_dir_begin(true)
		var file_name = dir.get_next()
		while file_name != "":
			if !dir.current_is_dir() && file_name.get_extension()=="png":
				r.append(file_name)
#				print("Found directory: " + file_name)
#			else:
#				print("Found file: " + file_name)
			file_name = dir.get_next()
	else:
		Log.warning("PlayerPortrait: Portrait folder can't be accessed for some reason, error code: %s\nPath: %s" % [er, path])
	
	return r

func loadTexture(p:String) -> ImageTexture:
	var img = Image.new()
	if img.load(p)==OK:
		var t = ImageTexture.new()
		t.create_from_image(img)
		return t
	return null
