extends WorldEditBase

func _init():
	id = "RAT_PortraitInitEdit"
	isRegular = false

func apply(_world: GameWorld):
	GlobalRegistry.getModule("PlayerPortrait").doReloadMyPackPleaseAndThankYou()
