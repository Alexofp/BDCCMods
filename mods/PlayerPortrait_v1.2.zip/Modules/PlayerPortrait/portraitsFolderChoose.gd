extends PanelContainer


signal dirChosen


func _on_FileDialog_dir_selected(dir):
	$vb/pathedit.text = dir

func _on_donebutt_pressed():
	emit_signal("dirChosen", $vb/pathedit.text)
