extends Module

func getFlags():
	return {
		"PortraitNameColor": flag(FlagType.Text),
		"PortraitsPath": flag(FlagType.Text),
	}

func _init():
	id = "PlayerPortrait"
	author = "Selinoccino"
	
	worldEdits = [
		"res://Modules/PlayerPortrait/PortraitWorldEdit.gd",
		"res://Modules/PlayerPortrait/PortraitInitWorldEdit.gd",
	]
	
	characters = [
		"res://Modules/PlayerPortrait/FakePlayer.gd",
	]
	
	scenes = [
		"res://Modules/PlayerPortrait/portraitOptionsScene.gd",
	]
	
	events = [
		"res://Modules/PlayerPortrait/OptionsEvent.gd",
	]
	

func postInit():
	GlobalRegistry.registerImagePack("res://Modules/PlayerPortrait/PlayerImagePack.gd")
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)
	#doReloadMyPackPleaseAndThankYou()

func doReloadMyPackPleaseAndThankYou():
	var pack = GlobalRegistry.imagePacks.get("RAT_PlayerPortrait")
	if !pack:
		Log.warning("PlayerPortrait: can't find imagepack!")
		return
	
	pack.reloadMyDataPleaseAndThankYou()

#func onFoxLibModInit(_foxModuleAPI):
#	return
