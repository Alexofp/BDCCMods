extends SceneBase

var colorPickerScene = preload("res://UI/ColorPickerWidget.tscn")
var col : String = ""

func _init():
	sceneID = "RAT_PortraitOptionsScene"


func _initScene(_args = []):
	col = getModuleFlag("PlayerPortrait", "PortraitNameColor", GM.pc.getChatColor())

func _run():
	if state=="":
		saynn("Choose what you want to configure regarding your portrait:")
		
		
		saynn("Current portraits folder: %s" % getModuleFlag("PlayerPortrait", "PortraitsPath", "[color=gray](unset)[/color]"))
		
		addButton("Save", "Save your changes", "endthescene")
		addButton("Name color", "Change this", "font")
		addButton("Portraits folder", "Choose another folder for this save file", "folder")
	
	if state=="folder":
		var dc = load("res://Modules/PlayerPortrait/portraitsFolderChoose.tscn").instance()
		GM.ui.addFullScreenCustomControl("dirchoose", dc)
		
		dc.connect("dirChosen", self, "dirChosen")
		
		addButton("Back", "Go back", "")
	
	if state=="font":
		# font color
		saynn("Choose font color for your nametag")
		
		var p = colorPickerScene.instance()
		GM.ui.addCustomControl("picker", p)
		p.setCurrentColor(Color(col))
		
		p.connect("color_changed", self, "chooseColor")
		
		addButton("Back", "Cancel and keep old color", "")
		addButton("Done", "Save the color", "done")
		addButton("Restore previous saved color", "Reset the color to the previously saved one", "reset")
		addButton("Reset color", "Reset the color to the default", "reset_full")
	

func chooseColor(c:Color=Color.white) -> void:
	col = c.to_html()
	#

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if _action=="done":
		setModuleFlag("PlayerPortrait", "PortraitNameColor", col)
		setState("")
		return
	
	if _action == "reset":
		col = getModuleFlag("PlayerPortrait", "PortraitNameColor", GM.pc.getChatColor())
		setState("")
		return
	
	if _action == "reset_full":
		col = GM.pc.getChatColor()
		setState("")
		return
	
	setState(_action)

func dirChosen(dir:String) -> void:
	setModuleFlag("PlayerPortrait", "PortraitsPath", dir)
	getModule("PlayerPortrait").doReloadMyPackPleaseAndThankYou()
	setState("")

func saveData():
	var d = .saveData()
	d["col"] = col
	return d

func loadData(d):
	.loadData(d)
	col = SAVE.loadVar(d, "col", GM.pc.getChatColor())
