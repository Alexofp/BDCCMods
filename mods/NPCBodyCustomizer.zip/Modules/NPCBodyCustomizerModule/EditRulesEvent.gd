extends EventBase

func _init():
	id = "NPCBodyCustomizer.EditRulesEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["EncountersMenuScene", ""])

func run(_triggerID, _args):
	addButton("Body parts", "Customize the body parts that NPCs are allowed to spawn with.", "doEvent")

func onButton(_method, _args):
	runScene("NPCBodyCustomizer.EditRulesScene")
