extends "res://Modules/NPCBodyCustomizerModule/Matcher/Matcher.gd"

var isDatapack = false
var datapackID = ""

func _init():
	id = "DatapackMatcher"

func saveData():
	var data = .saveData()
	data["isDatapack"] = isDatapack
	data["datapackID"] = datapackID
	return data

func loadData(_data):
	.loadData(_data)
	isDatapack = SAVE.loadVar(_data, "isDatapack", false)
	datapackID = SAVE.loadVar(_data, "datapackID", "")

func setDatapack():
	isDatapack = true
	datapackID = ""

func clearDatapack():
	isDatapack = false
	datapackID = ""

func setDatapackID(id: String):
	isDatapack = true
	datapackID = id

func matches(_npc: Character):
	if !isDatapack || datapackID == "":
		return GM.main.isDatapackCharacter(_npc.id) == isDatapack
	if !GM.main.datapackCharacters.has(datapackID):
		return false
	return GM.main.datapackCharacters[datapackID].has(_npc.id)

func describe():
	if isDatapack && datapackID == "":
		return "From any datapack.\n"
	elif isDatapack:
		var pack = GlobalRegistry.getDatapack(datapackID)
		if pack == null:
			return "From an unloaded datapack (id = %s).\n" % datapackID
		return "From the datapack %s.\n" % pack.name
	return "Not from a datapack.\n"

func addEditButtons(scene: SceneBase, _category):
	.addEditButtons(scene, _category)
	if isDatapack && datapackID == "":
		scene.addDisabledButton("Any datapack", "Allow NPCs from any datapack, but not other NPCs.")
		scene.addButton("No datapack", "Only allow NPCs that did not come from a datapack.", "editMatcherCallMethod", ["clearDatapack"])
	elif isDatapack:
		scene.addButton("Any datapack", "Allow NPCs from any datapack, but not other NPCs.", "editMatcherCallMethod", ["setDatapack"])
		scene.addButton("No datapack", "Only allow NPCs that did not come from a datapack.", "editMatcherCallMethod", ["clearDatapack"])
	else:
		scene.addButton("Any datapack", "Allow NPCs from any datapack, but not other NPCs.", "editMatcherCallMethod", ["setDatapack"])
		scene.addDisabledButton("No datapack", "Only allow NPCs that did not come from a datapack.")
	var datapacks = GlobalRegistry.getDatapacks()
	for id in datapacks:
		var pack = datapacks[id]
		if pack == null:
			continue
		if datapackID == id:
			scene.addDisabledButton(pack.name, "Only allow NPCs from the datapack %s." % pack.name)
		else:
			scene.addButton(pack.name, "Only allow NPCs from the datapack %s." % pack.name, "editMatcherCallMethod", ["setDatapackID", id])

func getNewLabel():
	return "Datapack"

func getNewTooltip():
	return "Filter NPCs by what datapack they came from (if any)."

