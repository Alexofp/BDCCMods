extends "res://Modules/NPCBodyCustomizerModule/Matcher/ValueMatcher.gd"

func _init():
	id = "SpeciesMatcher"
	canInvert = true
	
func matches(_npc: Character):
	for s in values:
		var isSpecies = _npc.getSpecies().has(s)
		if isSpecies:
			return !inverted
	return inverted

func describe():
	var species = []
	for s in values.keys():
		if GlobalRegistry.getSpecies(s) == null:
			species.append("Missingno. (id = %s)" % s)
		else:
			species.append(GlobalRegistry.getSpecies(s).getVisibleName())
	species.sort()
	var list = Util.humanReadableList(species, "or")
	if values.empty():
		list = "(no species selected)"
	if inverted:
		return "Is none of these species (incl. hybrids): %s\n" % list
	else:
		return "Is any of these species (incl. hybrids): %s\n" % list

func addEditButtons(scene: SceneBase, _category):
	.addEditButtons(scene, _category)
	for s in GlobalRegistry.getAllSpecies().values():
		if s.id == "error":
			continue
		var name = s.getVisibleName()
		if values.has(s.id):
			scene.addButton("-%s" % name, "Remove %s from filter." % name, "editMatcherRemoveValue", [s.id])
		else:
			scene.addButton("+%s" % name, "Add %s to filter." % name, "editMatcherAddValue", [s.id])

func getNewLabel():
	return "Species"

func getNewTooltip():
	return "Filter NPCs by species."
