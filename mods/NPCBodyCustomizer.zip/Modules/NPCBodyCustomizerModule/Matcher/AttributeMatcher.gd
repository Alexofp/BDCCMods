extends "res://Modules/NPCBodyCustomizerModule/Matcher/Matcher.gd"

var slotAttribute
var thresholdToMatch


func _init():
	id = "AttributeMatcher"
	canInvert = true
	slotAttribute = ""
	thresholdToMatch = 0


func saveData():
	var d = .saveData()
	d["slotAttribute"] = slotAttribute
	d["thresholdToMatch"] = thresholdToMatch
	return d

func loadData(_data):
	.loadData(_data)
	slotAttribute = SAVE.loadVar(_data, "slotAttribute", "")
	thresholdToMatch = SAVE.loadVar(_data, "thresholdToMatch", 0)

func matches(npc: Character):
	if slotAttribute == "":
		return true
	var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
	var slot = mod.getSlot(slotAttribute)
	if !npc.hasBodypart(slot):
		return false
	var part = npc.getBodypart(slot)
	var field = mod.getField(slotAttribute)
	var value = part.get(field)
	if !inverted && thresholdToMatch <= value:
		return true
	if inverted && thresholdToMatch >= value:
		return true
	return false

func describe():
	if slotAttribute == "":
		return "Has any attributes.\n"
	var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
	var slot = mod.getSlot(slotAttribute)
	var args = [
		BodypartSlot.getVisibleNameNoCap(slot),
		mod.getDescNoCap(slotAttribute),
		"at least",
		mod.showAttribute(slotAttribute, thresholdToMatch),
	]
	if inverted:
		args[2] = "at most"
	if BodypartSlot.isEssential(slot):
		args.pop_front()
		return "Has %s of %s %s.\n" % args
	return "Has %s, with %s of %s %s.\n" % args
	
func getNewLabel():
	return "Attribute"

func getNewTooltip():
	return "Filter NPCs by an attribute of a body part (such as penis length or breast size)."

func setSlotAttribute(attr: String, threshold):
	slotAttribute = attr
	thresholdToMatch = threshold

func addEditButtons(scene: SceneBase, _category):
	if _category != null:
		scene.addButton("Back", "Go back.", "editMatcherClearCategory")
	.addEditButtons(scene, _category)
	var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
	if _category == null:
		scene.addCategoryPicker("attr")
		return
	var p = BodypartSlot.findReplacement(mod.getSlot(_category), null)
	var ref = GlobalRegistry.getBodypartRef(p)
	for option in ref.getPickableAttributes()[_category]["options"]:
		scene.addButton(option[1], option[2], "editMatcherCallMethod", ["setSlotAttribute", _category, option[0]])
