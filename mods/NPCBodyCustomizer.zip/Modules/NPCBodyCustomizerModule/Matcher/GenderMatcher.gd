extends "res://Modules/NPCBodyCustomizerModule/Matcher/ValueMatcher.gd"

const NUM_GENDERS = 4

func _init():
	id = "GenderMatcher"

func matches(_npc: Character):
	if values.empty():
		return true
	var result = values.has(_npc.getGender())
	return result

func describe():
	if values.empty():
		return "Is any gender.\n"
	var list = []
	for g in values.keys():
		list.append(Gender.genderToString(g))
	list.sort()
	return "Is any of these genders: %s\n" % Util.humanReadableList(list, "or")

func addEditButtons(scene: SceneBase, _category):
	.addEditButtons(scene, _category)
	for g in range(NUM_GENDERS):
		var name = Util.capitalizeFirstLetter(Gender.genderToString(g))
		if values.has(g):
			scene.addButton("-%s" % name, "Remove %s from filter." % name, "editMatcherRemoveValue", [g])
		else:
			scene.addButton("+%s" % name, "Add %s to filter." % name, "editMatcherAddValue", [g])

func getNewLabel():
	return "Gender"

func getNewTooltip():
	return "Filter NPCs by gender."
