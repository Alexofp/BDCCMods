extends "res://Modules/NPCBodyCustomizerModule/Matcher/ValueMatcher.gd"

func _init():
	id = "SlotMatcher"
	canInvert = true

func matches(_npc: Character):
	for s in values:
		var hasPart = _npc.hasBodypart(s)
		if hasPart:
			return !inverted
	return inverted

func describe():
	var slots = []
	for s in values.keys():
		slots.append(BodypartSlot.getVisibleName(s))
	slots.sort()
	var list = Util.humanReadableList(slots, "or")
	if values.empty():
		list = "(no slots selected)"
	if inverted:
		return "Has none of these body parts (any variant): %s\n" % list
	else:
		return "Has any variant of any of these body parts: %s\n" % list

func addEditButtons(scene: SceneBase, _category):
	.addEditButtons(scene, _category)
	for s in BodypartSlot.getAll():
		if BodypartSlot.isEssential(s):
			continue
		var name = BodypartSlot.getVisibleName(s)
		var nameNoCap = BodypartSlot.getVisibleNameNoCap(s)
		if values.has(s):
			scene.addButton("-%s" % name, "Remove %s from filter." % nameNoCap, "editMatcherRemoveValue", [s])
		else:
			scene.addButton("+%s" % name, "Add %s to filter." % nameNoCap, "editMatcherAddValue", [s])

func getNewLabel():
	return "Body slot"

func getNewTooltip():
	return "Filter NPCs by body slot (e.g. has any penis, has any tail, etc.)."
