extends "res://Modules/NPCBodyCustomizerModule/Matcher/Matcher.gd"

var values = {}

var Rule = preload("res://Modules/NPCBodyCustomizerModule/Rule.gd")

func saveData():
	var data = .saveData()
	data["values"] = Rule.dictToArray(values)
	return data

func loadData(_data):
	.loadData(_data)
	values = Rule.arrayToDict(SAVE.loadVar(_data, "values", []))

func addValue(_value):
	values[_value] = true

func removeValue(_value):
	values.erase(_value)

func clearValues():
	values.clear()
