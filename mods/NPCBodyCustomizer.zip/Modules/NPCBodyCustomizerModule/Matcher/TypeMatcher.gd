extends "res://Modules/NPCBodyCustomizerModule/Matcher/ValueMatcher.gd"

func _init():
	id = "TypeMatcher"

func matches(_npc: Character):
	if values.empty():
		return true
	return values.has(_npc.getCharType())

func describe():
	if values.empty():
		return "Is any role.\n"
	return "Is any of these roles: " + Util.humanReadableList(values.keys(), "or") + "\n"

func addEditButtons(scene: SceneBase, _category):
	.addEditButtons(scene, _category)
	for t in CharacterType.getAll():
		var name = CharacterType.getName(t)
		if values.has(t):
			scene.addButton("-%s" % name, "Remove %s from filter." % name, "editMatcherRemoveValue", [t])
		else:
			scene.addButton("+%s" % name, "Add %s to filter." % name, "editMatcherAddValue", [t])

func getNewLabel():
	return "Role"

func getNewTooltip():
	return "Filter NPCs by role (inmate, guard, etc.)."
