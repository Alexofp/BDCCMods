extends "res://Modules/NPCBodyCustomizerModule/Matcher/ValueMatcher.gd"

func _init():
	id = "PartMatcher"
	canInvert = true

func matches(_npc: Character):
	for p in values:
		var r = GlobalRegistry.getBodypartRef(p)
		if r == null:
			continue
		var s = r.getSlot()
		var hasPart =  _npc.hasBodypart(s) && _npc.getBodypart(s).id == p
		if hasPart:
			return !inverted
	return inverted

func describe():
	var partNames = []
	for p in values:
		if GlobalRegistry.getBodypartRef(p) == null:
			partNames.append("Missingno.'s dick (id = %s)" % p)
		else:
			partNames.append(GlobalRegistry.getBodypartRef(p).getCharacterCreatorName())
	partNames.sort()
	var list = Util.humanReadableList(partNames, "or")
	if values.empty():
		list = "(no body parts selected)"
	if inverted:
		return "Has none of these (exact) body parts: %s\n" % list
	else:
		return "Has any of these (exact) body parts: %s\n" % list

func addEditButtons(scene: SceneBase, _category):
	if _category != null:
		scene.addButton("Back", "Go back.", "editMatcherClearCategory")
	.addEditButtons(scene, _category)
	if _category == null:
		scene.addCategoryPicker("slot")
		return
	for p in GlobalRegistry.getBodypartsIdsBySlot(_category):
		var ref: Bodypart = GlobalRegistry.getBodypartRef(p)
		var name = ref.getCharacterCreatorName()
		if values.has(p):
			scene.addButton("-%s" % name, "Remove %s from filter." % name, "editMatcherRemoveValue", [p])
		else:
			scene.addButton("+%s" % name, "Add %s to filter." % name, "editMatcherAddValue", [p])

func getNewLabel():
	return "Exact part"

func getNewTooltip():
	return "Filter NPCs by specific body part. Must match exactly (e.g. a horse penis is not the same as a dragon penis)."
