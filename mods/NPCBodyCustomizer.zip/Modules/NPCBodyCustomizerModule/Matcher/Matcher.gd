extends Reference

var id: String
var inverted = false
var canInvert = false

func matches(_npc: Character):
	return true

func saveData():
	var result = {
		"id": id,
	}
	if canInvert:
		result["inverted"] = inverted
	return result

func loadData(_data):
	# id set in _init() by subclasses.
	if canInvert:
		inverted = SAVE.loadVar(_data, "inverted", false)

func describe():
	return "Is any NPC.\n"

func getNewLabel():
	return "Matcher"

func getNewTooltip():
	return "Add a filter that matches everyone."

func addEditButtons(scene: SceneBase, _category):
	if canInvert:
		scene.addButton("Invert", "Reverse the sense of this filter.", "editMatcherInvert")
