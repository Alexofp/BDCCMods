extends "res://Modules/NPCBodyCustomizerModule/Matcher/Matcher.gd"

var isDynamic = true

func _init():
	id = "StaticDynamicMatcher"

func saveData():
	var data = .saveData()
	data["isDynamic"] = isDynamic
	return data

func loadData(_data):
	.loadData(_data)
	isDynamic = SAVE.loadVar(_data, "isDynamic", true)

func setDynamic():
	isDynamic = true

func setStatic():
	isDynamic = false

func matches(_npc: Character):
	return _npc.isDynamicCharacter() == isDynamic

func describe():
	if isDynamic:
		return "Only dynamic NPCs.\n"
	return "Only static NPCs.\n"

func addEditButtons(scene: SceneBase, _category):
	.addEditButtons(scene, _category)
	if isDynamic:
		scene.addDisabledButton("Dynamic", "Only allow dynamic NPCs.")
		scene.addButton("Static", "Only allow static NPCs.", "editMatcherCallMethod", ["setStatic"])
		return
	scene.addButton("Dynamic", "Only allow dynamic NPCs.", "editMatcherCallMethod", ["setDynamic"])
	scene.addDisabledButton("Static", "Only allow static NPCs.")

func getNewLabel():
	return "Static or Dynamic"

func getNewTooltip():
	return "Filter static vs. dynamic NPCs."

