extends Module

var matchers = {}

var attributeMetadata = {
	"breastsize": {
		"desc": "Breast size",
		"descNoCap": "breast size",
		"fieldName": "size",
		"showMethod": "showCupSize",
		"slot": BodypartSlot.Breasts,
	},
	"ballsscale": {
		"desc": "Balls scale",
		"descNoCap": "balls scale",
		"fieldName": "lengthCM",
		"showMethod": "showPercent",
		"slot": BodypartSlot.Penis,
	},
	"cocksize": {
		"desc": "Penis length",
		"descNoCap": "penis length",
		"fieldName": "lengthCM",
		"showMethod": "showPenisLength",
		"slot": BodypartSlot.Penis,
	},
	"tailscale": {
		"desc": "Tail scale",
		"descNoCap": "tail scale",
		"fieldName": "tailScale",
		"showMethod": "showPercent",
		"slot": BodypartSlot.Tail,
	},
}

func showPercent(v) -> String:
	return "%.0f%%" % (v * 100)

func showCupSize(v) -> String:
	return BreastsSize.breastSizeToCupString(v)

func showPenisLength(v) -> String:
	return Util.cmToString(v)

func getField(attribute: String) -> String:
	if attributeMetadata.has(attribute):
		return attributeMetadata[attribute]["fieldName"]
	return attribute

func getDesc(attribute: String) -> String:
	if attributeMetadata.has(attribute):
		return attributeMetadata[attribute]["desc"]
	return attribute

func getDescNoCap(attribute: String) -> String:
	if attributeMetadata.has(attribute):
		return attributeMetadata[attribute]["descNoCap"]
	return attribute

func showAttribute(attribute: String, value) -> String:
	if attributeMetadata.has(attribute):
		return call(attributeMetadata[attribute]["showMethod"], value)
	return "%s" % value

func getSlot(attribute: String) -> String:
	if attributeMetadata.has(attribute):
		return attributeMetadata[attribute]["slot"]
	return BodypartSlot.Body

func getFlags():
	return {
		"ShownWarning": flag(FlagType.Bool),
	}

func registerMatcher(s: String):
	var m = load(s)
	var mid = m.new().id
	matchers[mid] = m

func createMatcher(id: String):
	var m = matchers[id]
	if m:
		return m.new()
	else:
		return null

func _init():
	id = "NPCBodyCustomizerModule"
	author = "NYKevin"
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/AttributeMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/DatapackMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/GenderMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/PartMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/SlotMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/SpeciesMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/StaticDynamicMatcher.gd")
	registerMatcher("res://Modules/NPCBodyCustomizerModule/Matcher/TypeMatcher.gd")
	events = [
		"res://Modules/NPCBodyCustomizerModule/EditRulesEvent.gd",
	]
	gameExtenders = [
		"res://Modules/NPCBodyCustomizerModule/ApplyCustomizationExtender.gd",
	]
	scenes = [
		"res://Modules/NPCBodyCustomizerModule/EditRulesScene.gd",
	]

func postInit():
	var exportDir = Directory.new()
	exportDir.make_dir("user://body_customizer_export")
