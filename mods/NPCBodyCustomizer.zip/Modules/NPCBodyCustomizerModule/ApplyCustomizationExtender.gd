extends GameExtender

var rules = []

var Rule = preload("res://Modules/NPCBodyCustomizerModule/Rule.gd")

func _init():
	id = "NPCBodyCustomizer.ApplyCustomizations"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.npcUpdateNonBattleEffects)
	_GES.register(self, ExtendGame.saveLoadData)

func npcUpdateNonBattleEffects(_npc:Character):
	# Some scenes might break if we swap out body parts at the wrong moment.
	if GM.main.isCharacterInAnySexEngine(_npc.id) || GM.main.isCharIDFighting(_npc.id):
		return
	for r in rules:
		r.tryApply(_npc)

func saveData():
	var result = []
	for r in rules:
		result.append(r.saveData())
	return {
		"rules": result,
	}

func loadData(_data):
	rules = []
	for d in SAVE.loadVar(_data, "rules", []):
		var r = Rule.new()
		r.loadData(d)
		rules.append(r)
