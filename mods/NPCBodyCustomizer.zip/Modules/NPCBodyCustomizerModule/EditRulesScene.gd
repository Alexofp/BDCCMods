extends SceneBase

var page: int = 0
var ruleIndex: int = 0
var matcherIndex: int = 0
var matcherCategory = null

const PAGE_SIZE = 3

var Rule = preload("res://Modules/NPCBodyCustomizerModule/Rule.gd")
var DatapackMatcher = preload("res://Modules/NPCBodyCustomizerModule/Matcher/DatapackMatcher.gd")
var StaticDynamicMatcher = preload("res://Modules/NPCBodyCustomizerModule/Matcher/StaticDynamicMatcher.gd")

func _init():
	sceneID = "NPCBodyCustomizer.EditRulesScene"

func showRule(thisRule, withIndex=false):
	if withIndex:
		sayn(thisRule.describe(matcherIndex))
	else:
		sayn(thisRule.describe())
	addButton("Rule list", "Return to the list of rules (changes are saved as you go).", "")

func addCategoryPicker(type):
	if type == "slot":
		for s in BodypartSlot.getAll():
			var name = BodypartSlot.getVisibleName(s)
			var nameNoCap = BodypartSlot.getVisibleNameNoCap(s)
			addButton(name, "Select %s." % nameNoCap, "editMatcherSetCategory", [s])
		return
	if type == "attr":
		var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
		var attributeMetadata = mod.attributeMetadata
		for attr in attributeMetadata:
			var desc = mod.getDesc(attr)
			var descNoCap = mod.getDescNoCap(attr)
			addButton(desc, "Select %s." % descNoCap, "editMatcherSetCategory", [attr])
		return

func addChanceModButton(rule, amount: int):
	var tooltip: String
	if amount > 0:
		tooltip = "Increase the chance of applying this rule by %d%%." % amount
	else:
		tooltip = "Decrease the chance of applying this rule by %d%%" % -amount
	if rule.chance + amount >= 0 && rule.chance + amount <= 100:
		addButton("%+d%%" % amount, tooltip, "editRuleAddChance", [amount])
	else:
		addDisabledButton("%+d%%" % amount, tooltip)

func addReplaceButton(rule):
	if rule.doesReplaceMatter():
		addButton("Toggle replace", "Toggle whether this rule automatically replaces existing body parts when they conflict. If a body part is non-optional (such as a head or anus), it will always be replaced.", "editRuleToggleOverwrite")
	else:
		addDisabledButton("Toggle replace", "Toggle whether this rule automatically replaces existing body parts when they conflict. If a body part is non-optional (such as a head or anus), it will always be replaced.")

func _run():
	var ext = GlobalRegistry.getGameExtender("NPCBodyCustomizer.ApplyCustomizations")
	if state == "":
		if !getFlag("NPCBodyCustomizerModule.ShownWarning"):
			saynn("[b]WARNING: This might break your save![/b]")
			saynn("Modifying NPC body parts can potentially break the game in a variety of exciting and confusing ways. This is more likely to cause problems if you edit static NPCs, but some datapacks and mods might break from editing dynamic NPCs as well. Please save early, save often, and don't delete old saves (unless you're getting rid of the whole playthrough). If you don't want to deal with all that, then do not use this customizer.")
			saynn("For more specific information about how to use this editor, click the \"Help\" button on the next screen.")
			addButton("Acknowledge", "I promise to be careful!", "acknowledgeWarning")
			addButton("Cancel", "I don't want to risk it.", "endScene")
			return
		addButton("EXIT", "Close this editor and return to the Encounters menu.", "endScene")
		if len(ext.rules) > 0:
			if page*PAGE_SIZE >= len(ext.rules):
				page = 0
				ruleIndex = 0
			elif ruleIndex >= len(ext.rules):
				ruleIndex = page * PAGE_SIZE
			saynn("Rules applied to new and existing NPCs:")
			if len(ext.rules) > PAGE_SIZE:
				saynn("Page %d of %d." % [page+1, ceil(len(ext.rules) / float(PAGE_SIZE))])
			for i in range(page*PAGE_SIZE, page*PAGE_SIZE + PAGE_SIZE):
				if i < len(ext.rules):
					if i > page*PAGE_SIZE:
						saynn("***")
					if i == ruleIndex:
						say("[b]>>[/b] ")
					sayn(ext.rules[i].describe())
			if page > 0:
				addButton("<<", "Back one page.", "pageBack")
			else:
				addDisabledButton("<<", "Already on the first page.")
			if ruleIndex > 0:
				addButton("<", "Select the previous rule.", "prevRule")
			else:
				addDisabledButton("<", "Already on the first rule.")
			if ruleIndex + 1 < len(ext.rules):
				addButton(">", "Select the next rule.", "nextRule")
			else:
				addDisabledButton(">", "Already on the last rule.")
			if page*PAGE_SIZE + PAGE_SIZE < len(ext.rules):
				addButton(">>", "Forward one page.", "pageForward")
			else:
				addDisabledButton(">>", "Already on the last page.")

			addButton("New", "Add a new rule.", "newRule")
			addButton("Edit", "Edit this rule", "editRule")
			if ruleIndex > 0:
				addButton("Move up", "Move this rule up.", "editRuleMoveUp")
			else:
				addDisabledButton("Move up", "Rule is already first.")
			if ruleIndex + 1 < len(ext.rules):
				addButton("Move down", "Move this rule down.", "editRuleMoveDown")
			else:
				addDisabledButton("Move down", "Rule is already last.")
			addButton("Delete rule", "Delete this rule.", "confirmDelete")
		else:
			saynn("No NPC transformations are enabled.")
			addButton("New", "Add a new rule.", "newRule")
		addButton("Import", "Import a rule from an external file.", "importRuleFilePicker")
		if len(ext.rules) > 0:
			addButton("Export", "Export the selected rule to an external file.", "exportRuleSetName")
		addButton("Help", "Display information about how to use this editor.", "help")
		return
	if state == "help":
		saynn("This mod lets you define custom rules to change the bodies of some or all NPCs in the game, even if they've already spawned. It is designed to be highly flexible and easy to use.")
		saynn("Each rule has a set of filters and a set of changes. Filters narrow down which NPCs are affected by a rule. By default, all new rules start with two filters, that limit them to non-datapack, dynamic NPCs only. This is just for your convenience, and you can delete these filters if you also want to edit static and datapack NPCs. However, that's more likely to break things, so be careful when doing this. You can also create filters based on several other factors, such as an NPC's species, role, or existing body parts.")
		saynn("Rules can make three kinds of changes to NPCs: Adding parts, removing parts, and setting attributes. Removing parts is simple, but limited: You can only remove optional parts like tails, horns, or genitals, not mandatory parts like the head or anus. Adding parts is more complex, because the NPC might already have another part in the same slot. By default, optional parts are not replaced, but you can enable replacement if you prefer. Removals always happen before additions, so another option is to remove the unwanted part before adding a new part. Attributes are always set last, to ensure they are not overridden by removals or additions.")
		saynn("Finally, rules can have a set chance to apply, from 0% to 100%. This chance is rolled once per NPC. When the chance is 100%, it is not shown to conserve space. You can set chance to 0% to disable a rule without deleting it.")
		addButton("Done", "Return to the editor.", "")
		addButton("Next", "See the next page of help information.", "help2")
		return
	if state == "help2":
		saynn("The currently selected rule or filter is indicated with the symbol [b]>>[/b]. The edit, delete, etc. buttons will all act on the selected item.")
		saynn("Rules are applied from top to bottom. If a rule makes changes to an NPC, subsequent rules may overwrite those changes. You can reorder rules in the editor to change which one goes first.")
		saynn("Once an NPC has been checked against a given rule, regardless of whether it passed the filters, that rule will never touch that NPC again, even if you edit it. If this is a problem, you can click the Reapply button, which forces the rule to rerun against all NPCs in the game. This also re-rolls the random chance for each NPC, so it may alter the overall proportion of NPCs with a given set of parts.")
		saynn("Rules are not applied instantaneously. Instead, they are applied to each NPC when the game decides to process out-of-battle effects for that NPC, and the NPC is not in a fight or sex scene. This is designed to avoid extreme lag on setups with a large number of NPCs, but I haven't extensively tested it, so you might still have some performance issues. In most cases, it won't make a difference unless you are frequently editing rules during normal gameplay.")
		saynn("Rules can be exported to an external file to copy them between saves. You can find these files in a directory called body_customizer_export, alongside saves, mods, etc. Rules can also be imported from this directory into the game. To duplicate a rule, export it and then import it. Exporting silently overwrites existing files, so you should copy these files into a separate directory if you want to keep them around.")
		addButton("Back", "Go back to the first page.", "help")
		addButton("Next", "See the next page of help information", "help3")
		addButton("Done", "Return to the editor.", "")
		return
	if state == "help3":
		saynn("Now for some important limitations. Adding or removing genitals will not change an NPC's gender nor reroll their fetishes. If an NPC did not spawn with a given set of genitals, they will not have fetish values for those genitals (they will be neutral). NPCs will also keep the fetish values for genitals they no longer have (but those fetishes won't do much if anything). If you prefer a specific gender, it's best to set the vanilla gender spawn ratio, rather than using this mod to swap out an NPC's parts.")
		saynn("It is not recommended to remove all genitals from an NPC. Many sex scenes and interactions assume that all NPCs have at least one set of genitalia, and some of the writing will not make sense. Of course, it probably won't make anything seriously malfunction, because you can already do this in vanilla with TF drugs. But I have not extensively tested this scenario, so there might be complications I'm unaware of.")
		saynn("When an NPC receives a new body part with attributes (penis length, breast size, etc.), the NPC's existing attributes (if any) are lost, because they're attached to the old body part. To avoid giving every NPC the exact same body parts, the mod forcibly re-rolls these attributes on the new part. It also sets their colors to something reasonable (usually). After these values are re-rolled, the mod then applies whatever attributes you have configured, so your choices always take precedence over the RNG. It is recommended to make multiple rules with multiple different attribute values, and set each rule to have some chance of applying, so that you end up with a range of different values, but you could set all NPCs to the same value if you prefer.")
		saynn("This mod will not touch the player's anatomy under any circumstances. If you don't like your parts, use a different mod to reopen the character creator.")
		addButton("Back", "Go back to the last page", "help2")
		addButton("Done", "Return to the editor", "")
		return
	if state == "importRuleFilePicker":
		saynn("Which file would you like to import?")
		addButton("Cancel", "Don't import anything.", "")
		var dir = Directory.new()
		dir.open("user://body_customizer_export")
		dir.list_dir_begin(true)
		var filename = dir.get_next()
		while filename != "":
			addButton(filename, "Import this rule.", "importRule", [filename])
			filename = dir.get_next()
		return
	var thisRule = ext.rules[ruleIndex]
	if state == "editRule":
		if matcherIndex >= len(thisRule.matchers):
			matcherIndex = 0
			matcherCategory = null
		saynn("What changes do you want to make to this rule?")
		showRule(thisRule, true)
		if matcherIndex > 0:
			addButton("<", "Select the previous filter.", "prevMatcher")
		else:
			addDisabledButton("<", "Already selected the first filter.")
		if matcherIndex + 1 < len(thisRule.matchers):
			addButton(">", "Select the next filter.", "nextMatcher")
		else:
			addDisabledButton(">", "Already selected the last filter.")
		if matcherIndex > 0:
			addButton("Move up", "Move this filter up.", "editMatcherMoveUp")
		else:
			addDisabledButton("Move up", "Filter is already the first one.")
		if matcherIndex + 1 < len(thisRule.matchers):
			addButton("Move down", "Move this filter down.", "editMatcherMoveDown")
		else:
			addDisabledButton("Move down", "Filter is already the last one.")
		addButton("New filter", "Add a filter to this rule.", "createMatcher")
		if matcherIndex < len(thisRule.matchers):
			addButton("Edit filter", "Edit the selected filter.", "editMatcher")
			addButton("Delete filter", "Delete the selected filter.", "deleteMatcher")
		addButton("Changes", "Configure what this rule does when an NPC matches all filters.", "editRuleEffects")
		addButton("Chance", "Configure the chance that this rule is applied (rolled once per NPC).", "editRuleChance")
		addButton("Reapply rule", "Reapply this rule to all NPCs as if it was a brand-new rule.", "confirmReapplyRule")
		addButton("Delete rule", "Delete this rule.", "confirmDelete")
		addButton("Export rule", "Save this rule to an external file (for use with a different save).", "exportRuleSetName")
	if state == "exportRuleSetName":
		saynn("Exporting this rule:")
		showRule(thisRule, true)
		saynn("Enter the name of the file:")
		var textBox = addTextbox("export_rule_filename")
		textBox.connect("text_entered", self, "onTextBoxEnterPressed")
		addButton("Cancel", "Don't export this rule.", "editRule")
		addButton("Save", "Save the rule to this file.", "exportRule")
	if state == "confirmReapplyRule":
		saynn("Are you sure you want to reapply this rule to all NPCs? This will not undo previous applications of this rule.")
		showRule(thisRule)
		addButton("Yes", "Reapply this rule to all NPCs.", "editRuleReapply")
		addButton("No", "Do not reapply this rule.", "editRule")
	if state == "createMatcher":
		saynn("What kind of filter do you want to add?")
		showRule(thisRule)
		addButton("Cancel", "Don't add a new filter.", "editRule")
		var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
		var keys = mod.matchers.keys()
		keys.sort()
		for mid in keys:
			var matcher = mod.matchers[mid].new()
			addButton(matcher.getNewLabel(), matcher.getNewTooltip(), "editRuleAddMatcher", [matcher])
	if state == "editMatcher":
		saynn("How do you want to change the selected filter?")
		showRule(thisRule, true)
		if matcherCategory == null:
			addButton("Back", "Go back to editing the rule.", "editRule")
		addButton("Delete", "Delete this filter.", "deleteMatcher")
		var m = thisRule.matchers[matcherIndex]
		m.addEditButtons(self, matcherCategory)
	if state == "editRuleEffects":
		saynn("What do you want this rule to do to matching NPCs?")
		showRule(thisRule)
		addButton("Back", "Go back to editing the rule.", "editRule")
		addReplaceButton(thisRule)
		addButton("Add parts", "Add body parts when this rule is applied.", "editRuleParts")
		addButton("Remove parts", "Remove body parts when this rule is applied.", "editRuleSlots")
		addButton("Set attributes", "Modify body parts when this rule is applied.", "editRuleAttrs")
	if state == "editRuleParts":
		saynn("Which parts do you want to add to NPCs?")
		showRule(thisRule)
		if matcherCategory == null:
			addButton("Back", "Go back to editing the effects.", "editRuleEffects")
			addReplaceButton(thisRule)
			addCategoryPicker("slot")
			return
		addButton("Back", "Go back.", "editMatcherClearCategory")
		addReplaceButton(thisRule)
		var slotName = BodypartSlot.getVisibleNameNoCap(matcherCategory)
		var canAddMore = true
		for p in thisRule.partsToAdd:
			var ref: Bodypart = GlobalRegistry.getBodypartRef(p)
			if ref.getSlot() == matcherCategory:
				canAddMore = false
		for p in GlobalRegistry.getBodypartsIdsBySlot(matcherCategory):
			var ref: Bodypart = GlobalRegistry.getBodypartRef(p)
			var name = ref.getCharacterCreatorName()
			if thisRule.partsToAdd.has(p):
				addButton("-%s" % name, "Do not add %s to NPCs." % name, "editRuleRemovePart", [p])
			elif canAddMore:
				addButton("+%s" % name, "Add %s to NPCs." % name, "editRuleAddPart", [p])
			else:
				addDisabledButton("+%s" % name, "Can't add more than one %s to the same character!" % slotName)
	if state == "editRuleSlots":
		saynn("Which parts do you want to remove from NPCs?")
		showRule(thisRule)
		addButton("Back", "Go back to editing the effects.", "editRuleEffects")
		for s in BodypartSlot.getAll():
			if BodypartSlot.isEssential(s):
				continue
			var name = BodypartSlot.getVisibleName(s)
			var nameNoCap = BodypartSlot.getVisibleNameNoCap(s)
			if thisRule.slotsToClear.has(s):
				addButton("-%s" % name, "Do not remove %s from NPCs." % nameNoCap, "editRuleRemoveSlot", [s])
			else:
				addButton("+%s" % name, "Remove %s from NPCs." % nameNoCap, "editRuleAddSlot", [s])
	if state == "editRuleAttrs":
		saynn("Which attributes do you want to set?")
		showRule(thisRule)
		if matcherCategory == null:
			addButton("Back", "Go back to editing the effects.", "editRuleEffects")
			addCategoryPicker("attr")
			return
		addButton("Back", "Go back.", "editMatcherClearCategory")
		var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
		var slot = mod.getSlot(matcherCategory)
		var p = BodypartSlot.findReplacement(slot, null)
		var ref = GlobalRegistry.getBodypartRef(p)
		addButton("Unset", "Do not change the %s." % mod.getDescNoCap(matcherCategory), "editRuleClearAttr")
		for option in ref.getPickableAttributes()[matcherCategory]["options"]:
			addButton(option[1], option[2], "editRuleSetAttr", [option[0]])
	if state == "editRuleChance":
		saynn("Use the buttons to adjust the chance of this rule applying.")
		showRule(thisRule)
		addButton("Back", "Go back to editing the rule.", "editRule")
		addChanceModButton(thisRule, -1)
		addChanceModButton(thisRule, -5)
		addChanceModButton(thisRule, -10)
		addDisabledButton("")
		addDisabledButton("")
		addChanceModButton(thisRule, 1)
		addChanceModButton(thisRule, 5)
		addChanceModButton(thisRule, 10)
	if state == "confirmDelete":
		saynn("Really delete this rule?")
		sayn(thisRule.describe())
		addButton("OK", "Delete this rule (can't be undone).", "deleteRule")
		addButton("Cancel", "Do not delete this rule.", "editRule")

func _react(_action: String, _args):
	if _action == "endScene":
		endScene()
		return
	if _action == "acknowledgeWarning":
		setFlag("NPCBodyCustomizerModule.ShownWarning", true)
		return
	if _action == "pageBack":
		page -= 1
		ruleIndex = page * PAGE_SIZE
		return
	if _action == "pageForward":
		page += 1
		ruleIndex = page * PAGE_SIZE
		return
	if _action == "prevRule":
		ruleIndex -= 1
		page = ruleIndex / PAGE_SIZE
		return
	if _action == "nextRule":
		ruleIndex += 1
		page = ruleIndex / PAGE_SIZE
		return
	if _action == "prevMatcher":
		matcherIndex -= 1
		matcherCategory = null
		return
	if _action == "nextMatcher":
		matcherIndex += 1
		matcherCategory = null
		return
	var ext = GlobalRegistry.getGameExtender("NPCBodyCustomizer.ApplyCustomizations")
	if _action == "newRule":
		var r = Rule.new()
		# Editing static NPCs is fraught with peril, so disable it by default.
		r.matchers.append(StaticDynamicMatcher.new())
		r.matchers.append(DatapackMatcher.new())
		ext.rules.append(r)
		ruleIndex = len(ext.rules) - 1
		page = ruleIndex / PAGE_SIZE
		matcherIndex = 0
		matcherCategory = null
		setState("editRule")
		return
	if _action == "importRule":
		var r = Rule.new()
		r.importFromFile("user://body_customizer_export/" + _args[0])
		ext.rules.append(r)
		ruleIndex = len(ext.rules) - 1
		page = ruleIndex / PAGE_SIZE
		setState("")
		return

	if ruleIndex < 0 || ruleIndex >= len(ext.rules):
		setState(_action)
		return
	var rule = ext.rules[ruleIndex]
	if _action == "editRule":
		setState(_action)
		matcherCategory = null
		return
	if _action == "editRuleMoveUp":
		ext.rules[ruleIndex] = ext.rules[ruleIndex - 1]
		ext.rules[ruleIndex - 1] = rule
		ruleIndex -= 1
		page = ruleIndex / PAGE_SIZE
		return
	if _action == "editRuleMoveDown":
		ext.rules[ruleIndex] = ext.rules[ruleIndex + 1]
		ext.rules[ruleIndex + 1] = rule
		ruleIndex += 1
		page = ruleIndex / PAGE_SIZE
		return
	if _action == "editRuleToggleOverwrite":
		rule.allowOverwrite = !rule.allowOverwrite
		return
	if _action == "editRuleReapply":
		rule.npcsChecked.clear()
		rule.npcEditCount = 0
		setState("editRule")
		return
	if _action == "editRuleAddChance":
		rule.chance += _args[0]
		return
	if _action == "editRuleEffects":
		matcherCategory = null
	if _action == "editRuleRemovePart":
		rule.partsToAdd.erase(_args[0])
		return
	if _action == "editRuleAddPart":
		rule.partsToAdd[_args[0]] = true
		return
	if _action == "editRuleRemoveSlot":
		rule.slotsToClear.erase(_args[0])
		return
	if _action == "editRuleAddSlot":
		rule.slotsToClear[_args[0]] = true
		return
	if _action == "editRuleSetAttr":
		rule.attributesToSet[matcherCategory] = _args[0]
		return
	if _action == "editRuleClearAttr":
		rule.attributesToSet.erase(matcherCategory)
		return
	if _action == "editRuleAddMatcher":
		rule.matchers.append(_args[0])
		matcherIndex = len(rule.matchers) - 1
		matcherCategory = null
		setState("editMatcher")
		return
	if _action == "editMatcherSetCategory":
		matcherCategory = _args[0]
		return
	if _action == "editMatcherClearCategory":
		matcherCategory = null
		return
	if _action == "deleteRule":
		ext.rules.pop_at(ruleIndex)
		setState("")
		ruleIndex -= 1
		ruleIndex = int(max(ruleIndex, 0))
		page = ruleIndex / PAGE_SIZE
		return
	if _action == "exportRule":
		var filename = getTextboxData("export_rule_filename")
		if filename != "":
			rule.exportToFile("user://body_customizer_export/%s.json" % filename)
			setState("editRule")
		return

	if matcherIndex < 0 || matcherIndex >= len(rule.matchers):
		setState(_action)
		return
	var m = rule.matchers[matcherIndex]
	if _action == "editMatcherMoveUp":
		rule.matchers[matcherIndex] = rule.matchers[matcherIndex - 1]
		rule.matchers[matcherIndex - 1] = m
		matcherIndex -= 1
		return
	if _action == "editMatcherMoveDown":
		rule.matchers[matcherIndex] = rule.matchers[matcherIndex + 1]
		rule.matchers[matcherIndex + 1] = m
		matcherIndex += 1
		return
	if _action == "editMatcherInvert":
		m.inverted = !m.inverted
		return
	if _action == "editMatcherAddValue":
		m.addValue(_args[0])
		return
	if _action == "editMatcherRemoveValue":
		m.removeValue(_args[0])
		return
	if _action == "editMatcherCallMethod":
		var meth = _args.pop_front()
		m.callv(meth, _args)
		return
	if _action == "deleteMatcher":
		var r = ext.rules[ruleIndex]
		r.matchers.pop_at(matcherIndex)
		matcherIndex -= 1
		matcherIndex = int(max(matcherIndex, 0))
		matcherCategory = null
		setState("editRule")
		return
	setState(_action)

func onTextBoxEnterPressed(_unused):
	GM.main.pickOption("exportRule", [])

func saveData():
	var data = .saveData()
	data["page"] = page
	data["ruleIndex"] = ruleIndex
	data["matcherCategory"] = matcherCategory
	data["matcherIndex"] = matcherIndex
	return data

func loadData(data):
	.loadData(data)
	page = SAVE.loadVar(data, "page", 0)
	ruleIndex = SAVE.loadVar(data, "ruleIndex", 0)
	matcherCategory = SAVE.loadVar(data, "matcherCategory", null)
	matcherIndex = SAVE.loadVar(data, "matcherIndex", 0)
