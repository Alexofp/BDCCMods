extends Reference

var matchers = []

var allowOverwrite = false
var chance = 100.0
var partsToAdd = {}
var slotsToClear = {}
var attributesToSet = {}

var npcsChecked = {}
var npcEditCount = 0

static func dictToArray(dir) -> Array:
	if typeof(dir) == TYPE_ARRAY:
		return dir
	return dir.keys()

static func arrayToDict(arr) -> Dictionary:
	if typeof(arr) == TYPE_DICTIONARY:
		return arr
	var result = {}
	for key in arr:
		result[key] = true
	return result

func saveData():
	var saveMatchers = []
	for m in matchers:
		saveMatchers.append(m.saveData())
	return {
		"allowOverwrite": allowOverwrite,
		"attributesToSet": attributesToSet,
		"chance": chance,
		"matchers": saveMatchers,
		"npcsChecked": dictToArray(npcsChecked),
		"npcEditCount": npcEditCount,
		"partsToAdd": dictToArray(partsToAdd),
		"slotsToClear": dictToArray(slotsToClear),
	}

func exportToFile(path: String):
	var d = saveData()
	d["npcsChecked"] = []
	d["npcEditCount"] = 0
	var f = File.new()
	f.open(path, File.WRITE)
	f.store_line(JSON.print(d, "\t", true))
	f.close()

func importFromFile(path: String):
	var f = File.new()
	f.open(path, File.READ)
	var text = f.get_as_text()
	f.close()
	var parsed = JSON.parse(text)
	var result = parsed.result
	var error = parsed.error
	if error != OK:
		return false
	loadData(result)
	return true

func loadData(_data):
	allowOverwrite = SAVE.loadVar(_data, "allowOverwrite", false)
	attributesToSet = SAVE.loadVar(_data, "attributesToSet", {})
	chance = SAVE.loadVar(_data, "chance", 100.0)
	npcsChecked = arrayToDict(SAVE.loadVar(_data, "npcsChecked", []))
	npcEditCount = SAVE.loadVar(_data, "npcEditCount", 0)
	partsToAdd = arrayToDict(SAVE.loadVar(_data, "partsToAdd", []))
	matchers = []
	var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
	for d in SAVE.loadVar(_data, "matchers", []):
		var m = mod.createMatcher(SAVE.loadVar(d, "id", ""))
		if m:
			m.loadData(d)
			matchers.append(m)
	slotsToClear = arrayToDict(SAVE.loadVar(_data, "slotsToClear", []))

func tryApply(_npc: Character):
	if npcsChecked.has(_npc.id):
		return
	npcsChecked[_npc.id] = true
	for m in matchers:
		if !m.matches(_npc):
			return
	if !RNG.chance(chance):
		return
	Log.print("NPC Body Customizer modifying %s." % _npc.id)
	npcEditCount += 1
	for s in slotsToClear:
		if _npc.hasBodypart(s):
			_npc.removeBodypart(s, false)
	for p in partsToAdd:
		var ref: Bodypart = GlobalRegistry.getBodypartRef(p)
		if !ref:
			continue
		var slot: String = ref.getSlot()
		var isEssential = BodypartSlot.isEssential(slot)
		if !allowOverwrite && !isEssential && _npc.hasBodypart(slot):
			continue
		var part = GlobalRegistry.createBodypart(p)
		_npc.giveBodypart(part, false)
		part.generateDataFor(_npc)
	var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
	for attr in attributesToSet:
		var s = mod.getSlot(attr)
		if !_npc.hasBodypart(s):
			continue
		var p = _npc.getBodypart(s)
		var value = attributesToSet[attr]
		p.applyAttribute(attr, value)
	_npc.emit_signal("bodypart_changed")

func doesReplaceMatter():
	for p in partsToAdd:
		var ref: Bodypart = GlobalRegistry.getBodypartRef(p)
		if !ref:
			continue
		var slot: String = ref.getSlot()
		if !BodypartSlot.isEssential(slot) && !slotsToClear.has(slot):
			return true
	return false

func describeChanges():
	var descs = []
	var slots = slotsToClear.keys()
	slots.sort()
	var num = 1
	for s in slots:
		descs.append("%d. Remove %s (if any).\n" % [num, BodypartSlot.getVisibleNameNoCap(s)])
		num += 1
	var parts = partsToAdd.keys()
	parts.sort()
	for p in parts:
		var ref: Bodypart = GlobalRegistry.getBodypartRef(p)
		if ref == null:
			descs.append("%d. Add Missingno.'s dick (id = %s).\n" % [num, p])
			num += 1
			continue
		var slot = ref.getSlot()
		var name = ref.getCharacterCreatorName()
		var slotName =  BodypartSlot.getVisibleNameNoCap(slot)
		if slotsToClear.has(slot):
			descs.append("%d. Add %s.\n" % [num, name])
			num += 1
		elif allowOverwrite || BodypartSlot.isEssential(slot):
			descs.append("%d. Add %s (replace existing %s).\n" % [num, name, slotName])
			num += 1
		else:
			descs.append("%d. Add %s (unless already has %s).\n" % [num, name, slotName])
			num += 1
	var mod = GlobalRegistry.getModule("NPCBodyCustomizerModule")
	for attr in attributesToSet:
		var attrDesc = mod.getDescNoCap(attr)
		var attrValue = mod.showAttribute(attr, attributesToSet[attr])
		var slot = mod.getSlot(attr)
		if BodypartSlot.isEssential(slot):
			descs.append("%d. Change %s to %s.\n" % [num, attrDesc, attrValue])
			num += 1
		else:
			var slotName = BodypartSlot.getVisibleNameNoCap(slot)
			descs.append("%d. Change %s to %s (if has %s).\n" % [num, attrDesc, attrValue, slotName])
			num += 1
	return "".join(descs)

func describe(mindex = -1):
	var descs = []
	for i in range(len(matchers)):
		var m = matchers[i]
		if i == mindex:
			descs.append("[b]>>[/b] " + m.describe())
		else:
			descs.append("* " + m.describe())
	var matcherDesc = "".join(descs)
	var result = "Target NPCs matching [b]all[/b] of these criteria:\n%s\n" % matcherDesc
	if matcherDesc == "":
		result = "Target all NPCs.\n\n"
	if chance <= 0.0:
		result += "0% chance to affect each targeted NPC (rule doesn't do anything!).\n\n"
	elif chance < 100.0:
		result += "%.f%% chance to affect each targeted NPC.\n\n" % chance
	if partsToAdd.empty() && slotsToClear.empty() && attributesToSet.empty():
		result += "Make no changes to NPCs (rule doesn't do anything!).\n"
	else:
		result += "Make the following changes to each NPC:\n"
		result += describeChanges()
	if npcsChecked.empty():
		result += "\nRule has not run yet.\n"
	else:
		result += "\nRule applied to %d out of %d NPCs.\n" % [npcEditCount, len(npcsChecked)]
	return result
