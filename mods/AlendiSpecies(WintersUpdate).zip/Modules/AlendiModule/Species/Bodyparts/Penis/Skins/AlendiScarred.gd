extends PartSkinBase

func _init():
	id = "alendiscarred"
	partID = "alendipenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiScarred.png"),
	}
	
