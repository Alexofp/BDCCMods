extends PartSkinBase

func _init():
	id = "alendilover"
	partID = "alendipenis"

func getName():
	return "LoversMark"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiLoverMark.png"),
	}

