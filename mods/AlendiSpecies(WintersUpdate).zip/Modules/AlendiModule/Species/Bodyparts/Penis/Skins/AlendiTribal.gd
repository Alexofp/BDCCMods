extends PartSkinBase

func _init():
	id = "alenditribal"
	partID = "alendipenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiTribal.png"),
	}
	
	 
