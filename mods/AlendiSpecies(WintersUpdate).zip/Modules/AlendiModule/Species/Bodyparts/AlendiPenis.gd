extends BodypartPenis

func _init():
	visibleName = "Alendi penis"
	id = "alendipenis"

func getCompatibleSpecies():
	return [Species.Any]

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0
	else:
		return 1

func getTraits():
	return {
		PartTrait.PenisBarbs: true,
	}

func getLewdAdjective():
	return RNG.pick(["spiked", "tapered", "feline"])
	
func getVulgarName() -> String:
	return "catcock"

func getDoll3DScene():
	return "res://Modules/AlendiModule/Species/Bodyparts/Penis/AlendiPenis.tscn"
