extends BodypartEars

func _init():
	visibleName = "Alendi Ears"
	id = "alendiears"

func getCompatibleSpecies():
	return ["Alendi"]

func getDoll3DScene():
	return "res://Modules/AlendiModule/Species/Bodyparts/Ears/AlendiEars.tscn"
