extends Module

var BallsExtraLoad = ResourceLoader.exists("res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd")
var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")
var FluffyBodypartsLoad = ResourceLoader.exists("res://Modules/WintersFluffyBodyparts/Module.gd")
var KemonomimiSpeciesLoad = ResourceLoader.exists("res://Modules/WintersKemonomimiDynamicNPCs/Module.gd")

func _init():
	id = "AlendiSpecies"
	author = "Sophia & Sophel"
	
	if (BallsExtraLoad == true):
		bodyparts = [
		"res://Modules/AlendiModule/CompatibilityPatches/BallsExtra/AlendiPenisBallsExtra.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/AlendiEars.gd",
	]

	elif (BallsExtraLoad == false):
		bodyparts = [
		"res://Modules/AlendiModule/Species/Bodyparts/AlendiPenis.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/AlendiEars.gd",
	]
	
	partSkins = [
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiCockHighlight.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiGradient.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiLoverMark.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiPiercing.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiScarred.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiTribal.gd",
		"res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiVirile.gd",
	]
	
	if (RAT_ArchetypeLoad == false):
		species = [
			"res://Modules/AlendiModule/Species/AlendiFluffy.gd"
		]
	else:
		species = [
			"res://Modules/AlendiModule/Species/Alendi.gd"
		]
	
	species = [
	"res://Modules/AlendiModule/Species/Alendi.gd",
	]

func getAddedRatArchetypes() -> Dictionary:
	var pathDir = "res://Modules/WintersFluffyBodyparts/CompatibilityPatches/RAT_BodypartArchetypes/"
	var pathDirKemono = "res://Modules/WintersKemonomimiDynamicNPCs/CompatabilityPatches/RAT_BodypartArchetypes/"
	
	if (FluffyBodypartsLoad == true):
		return {
		# species id: [array of paths to file] or "path to file"
		# turns to speciesID: types dictionary (typeID: type dict)
		"alendi": [pathDir+"ClawedArchetypes.json"],
		}
	if (KemonomimiSpeciesLoad == true):
		return {
		"alendi": [pathDirKemono+"KemonomimiArchetypes.json"],
	}
	else:
		return{
		}
