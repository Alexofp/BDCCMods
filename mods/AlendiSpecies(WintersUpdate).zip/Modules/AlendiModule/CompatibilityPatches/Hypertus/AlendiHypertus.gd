extends Species

func _init():
	id ="Alendi"
	
func getVisibleName():
	return "Alendi"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegs"
	return "digilegs"

func getDefaultTail(_gender):
	return "caninetail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Weird alien cats"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultHead(_gender):
	if ("WintersBaseSpeciesExpansion" in GlobalRegistry.getModules()):
		return "sabercathead"
	return "felinehead"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffclawedarms"
	return "anthroarms"

func getDefaultEars(_gender):
	return "alendiears"

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"
	else:
		if(_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"
	
func getDefaultPenis(_gender):
		if(_gender in [Gender.Male, Gender.Androgynous]):
			return "alendipenishyperable"
		return null

func getAllowedBodyparts():
	return ["sabertoothhead", "alendiears", "caninetail", "felinehead"]

func getEggCellOvulationAmount():
	return [
		[1, 2.0],
		[2, 8.0],
		[3, 6.0],
		[4, 4.0],
		[5, 2.0],
		[6, 1.0],
		[7, 0.5],
	]
	
func getSkinType():
	return SkinType.Fur
	
#func onDynamicNpcCreation(_npc, _args):
#	var available_skins = ["VerySpiky", "WildSkin", "CunningSkin", "FerriSkin", "LuxeSkin", "SpottedSkin", "TaviSkin", "BreezeSkin", "SmuttySkin", "ArconSkin", "SocketSkin"]
#	_npc.pickedSkin = available_skins.pick_random()

func npcGenerationWeight():
	return 1.0
