extends PartSkinBase

func _init():
	id = "alendiscarredhyperable"
	partID = "alendipenishyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiScarred.png"),
	}
	
