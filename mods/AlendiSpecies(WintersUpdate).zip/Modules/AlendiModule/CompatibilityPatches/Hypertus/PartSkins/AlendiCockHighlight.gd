extends PartSkinBase

func _init():
	id = "alendicockhighlighthyperable"
	partID = "alendipenishyperable"

func getName():
	return "Highlighted"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiCockHighlight.png"),
	}
