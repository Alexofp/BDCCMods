extends PartSkinBase

func _init():
	id = "alendipiercinghyperable"
	partID = "alendipenishyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiPiercing.png"),
	}
	
	 
