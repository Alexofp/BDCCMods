extends PartSkinBase

func _init():
	id = "alendiGradienthyperable"
	partID = "alendipenishyperable"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiGradient.png"),
	}
