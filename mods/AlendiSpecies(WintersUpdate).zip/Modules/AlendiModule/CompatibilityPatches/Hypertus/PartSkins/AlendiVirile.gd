extends PartSkinBase

func _init():
	id = "alendivirilehyperable"
	partID = "alendipenishyperable"

func getName():
	return "Virile lube"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiVirile.png"),
	}
