extends PartSkinBase

func _init():
	id = "alenditribalhyperable"
	partID = "alendipenishyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/AlendiModule/Species/Bodyparts/Penis/Skins/AlendiTribal.png"),
	}
	
	 
