extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable Alendi penis"
	id = "alendipenishyperable"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0
	else:
		return 1

func getTraits():
	return {
		PartTrait.PenisBarbs: true,
		"Hyperable": true,
	}

func getLewdAdjective():
	return RNG.pick(["spiked", "tapered", "feline"])
	
func getVulgarName() -> String:
	return "catcock"

func getDoll3DScene():
	return "res://Modules/AlendiModule/Species/Bodyparts/Penis/AlendiPenis.tscn"
