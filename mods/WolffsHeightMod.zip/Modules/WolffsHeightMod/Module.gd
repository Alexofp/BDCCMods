extends Module

var sceneID = "IgnoreMe"
var height_script = load("res://Modules/WolffsHeightMod/HeightIK_Injection.gd")

func _init():
	id = "WolffsHeightMod"
	author = "Wolff"
	
	# Let the engine handle item registration and UI hooks properly!
	items = [
		"res://Modules/WolffsHeightMod/Inventory/Items/HeightPillGrow.gd",
		"res://Modules/WolffsHeightMod/Inventory/Items/HeightPillShrink.gd"
	]
	
	# Start the skeleton injector safely after the engine boots
	call_deferred("start_skeleton_injector")

func start_skeleton_injector():
	var tree = Engine.get_main_loop()
	if tree and tree is SceneTree:
		tree.connect("node_added", self, "_on_node_added")

func _on_node_added(node):
	if node.get_class() == "Skeleton" and node.name == "Skeleton":
		if not node.get_script(): 
			node.set_script(height_script)
			node.set_process(true)
			if node.has_method("_ready"):
				node._ready()
