extends Skeleton

var possible_scales = [0.85, 0.92, 1.0, 1.07]
const SAVE_FILE_PATH = "user://mod_heights.json"

# POSES TO DISABLE SCALING (Force to 1.0)
var disabled_scale_poses = [
	"sex69"
]

# UNIVERSAL POSE CONFIGURATION
# Format: {"keys": ["word1"], "exclude": ["word2"], "offsets": [Y, X, BaseY, BaseX]}

var pose_rules = [
	# 19. STOCKS ORAL
	{"keys": ["stockssexoral", "facing:left"], "offsets": [-3.4, 3.0, 0.0, 2.152]},
	{"keys": ["stockssexoral", "facing:right"], "offsets": [-3.4, 3.0, 0.0, 2.152]},

	# 20. STOCKS SEX (node:doll3d2 exclusively made it so targets the Dom)
	{"keys": ["stockssex", "node:doll3d2"], "offsets": [-3.4, -1.8, 0.0, 0.6]},
	{"keys": ["stockssex", "node:doll3d"], "offsets": [-3.4, -1.8, 0.0, 0.57]},

	# 1. ORAL BASELINE 
	{"keys": ["sexoral"], "exclude": ["stocks"], "offsets": [-3.5, 0.0]},

	# 2. ALL FOURS 
	{"keys": ["sexallfours"], "offsets": [-1.5, -1.0]},

	# 3. MISSIONARY
	{"keys": ["sexmissionary", "facing:left"], "offsets": [-0.9, -0.2]},
	{"keys": ["sexmissionary", "facing:right"], "offsets": [-0.9, -0.2]},

	# 4. FREE STANDING SEX 
	{"keys": ["sexfreestanding"], "offsets": [-3.1, -0.5]},

	# 5. FULL NELSON
	{"keys": ["sexfullnelson"], "offsets": [-3.95, -0.6]},

	# 6. BEHIND
	{"keys": ["sexbehind"], "offsets": [-1.4, 0.7]},
	
	# 7. MATING PRESS
	{"keys": ["sexmatingpress", "facing:left"], "offsets": [-0.9, -1.3]},
	{"keys": ["sexmatingpress", "facing:right"], "offsets": [-0.9, -1.3]},
	
	# 8. RAISED LEG 
	{"keys": ["sexpawlick"], "offsets": [-1.9, -0.9]},
	
	# 9. LOW DOGGY
	{"keys": ["sexlowdoggy"], "offsets": [-1.8, -1.5]},
	
	# 10. AGAINST WALL
	{"keys": ["sexstanding"], "offsets": [-4.2, -0.8, 0.0, -0.2]},
	
	# 11. PINNED INTO WALL
	{"keys": ["sexpinnedbehind"], "offsets": [-4.0, -0.3, 0.0, -0.3]},
	
	# 12. WALL PRESS [Scale_Y, Scale_X, Base_Y, Base_X]
	{"keys": ["sexagainstwall", "facing:left"], "offsets": [-3.4, -1.2, 0.0, -1.78]},
	{"keys": ["sexagainstwall", "facing:right"], "offsets": [-3.4, 0.2, 0.0, -1.78]},
	
	# 13. RIMMING
	{"keys": ["sexrimming"], "offsets": [-3.5, -0.7]},
	
	# 14. GROPE BREASTS
	{"keys": ["breastgroping"], "offsets": [-2.8, 1.5]},
	
	# 15. BREASTFEEDING
	{"keys": ["breastfeeding", "facing:left"], "offsets": [-2.4, -0.6]},
	{"keys": ["breastfeeding", "facing:right"], "offsets": [-2.4, -0.6]},
	
	# 16. FEET PLAY
	{"keys": ["sexfeetplay", "facing:left"], "offsets": [-1.5, -0.5]},
	{"keys": ["sexfeetplay", "facing:right"], "offsets": [-1.5, -0.5]},
	
	# 17. SPANKING
	{"keys": ["spanking"], "offsets": [-2.5, 0.5]},
	
	# 18. CHOKING
	{"keys": ["choking"], "offsets": [-6.5, 0.8]},
	
	# 21. SLUTWALL SEX (Active)
	{"keys": ["slutwallsex", "facing:left"], "offsets": [-3.5, 1.0, 0.0, -0.3]},
	{"keys": ["slutwallsex", "facing:right"], "offsets": [-3.5, 0.5, 0.0, -0.3]},
	# Sub (Locked in the wall)
	{"keys": ["slutwallsex"], "offsets": [0.0, 0.0, 0.0, 0.0]},
	
	# 23. GIVING BIRTH
	{"keys": ["givingbirth"], "offsets": [0.0, 0.0, 1.3, 0.0]},
	
	# 24. AMAZON COWGIRL
	{"keys": ["sexcowgirlamazon", "facing:left"], "offsets": [-1.2, -0.5, 0.0, -1.0]},
	{"keys": ["sexcowgirlamazon", "facing:right"], "offsets": [-1.2, -2.0, 0.0, -1.0]},
	
	# 25. STANDARD COWGIRL
	{"keys": ["sexcowgirl", "facing:left"], "offsets": [-1.0, -1.0, 0.0, -1.0]},
	{"keys": ["sexcowgirl", "facing:right"], "offsets": [-1.2, 0.0, 0.0, -1.1]},
	
	# 26. REVERSE COWGIRL
	{"keys": ["sexreversecowgirl"], "offsets": [-0.9, -1.0, 0.0, 0.0]},
	
	# 27. COWGIRL ALTERNATIVE
	{"keys": ["sexcowgirlalt", "facing:left"], "offsets": [-1.0, -0.5, 0.0, 0.0]},
	{"keys": ["sexcowgirlalt", "facing:right"], "offsets": [-1.0, 0.5, 0.0, 0.0]},
	
	# 28. LOTUS
	{"keys": ["sexlotus", "facing:left"], "offsets": [-1.0, -0.5, 0.0, 0.0]},
	{"keys": ["sexlotus", "facing:right"], "offsets": [-1.0, 0.5, 0.0, 0.0]},
	
	# 29. PORTAL FLESHLIGHT
	{"keys": ["sexfleshlight"], "offsets": [-4.0, -1.0, 0.0, 0.0]},
	
	# 30. SLEEP
	{"keys": ["sleep"], "offsets": [0.0, 0.0, 1.3, 0.0]},
]

var excluded_npc_ids = [
	"alexrynard", "announcer", "artica", "avy", "axis", "boss_alex", "bulldog", 
	"captain", "cp_guard", "eliza", "elizaMom", "ferri", "gymbully", "gymbully2", 
	"gymbully3", "intro_detective", "jack", "jacki", "junkieBoozeSeller", "kait", 
	"kidlat", "lin_alex", "luxe", "mirri", "nova", "novaArena", "nura", "nurse", 
	"PCTentacles", "psmilkgirl", "psmilkguy", "pspip", "psricky", "rahi", "rebel", 
	"risha", "rubi", "rush", "sen_alex", "skar", "socket", "stud", "tavi", 
	"taviDemon", "taviDemonFuta", "vion", "volk"
]

func _ready():
	randomize()
	load_permanent_heights()

func load_permanent_heights():
	if Engine.has_meta("heights_file_loaded"):
		return
		
	var saved_data = {}
	var file = File.new()
	if file.file_exists(SAVE_FILE_PATH):
		file.open(SAVE_FILE_PATH, File.READ)
		var content = file.get_as_text()
		var parse_result = JSON.parse(content)
		if parse_result.error == OK and typeof(parse_result.result) == TYPE_DICTIONARY:
			saved_data = parse_result.result
		file.close()
		
	Engine.set_meta("global_height_dict", saved_data)
	Engine.set_meta("heights_file_loaded", true)
	
	if saved_data.has("pc"):
		var pc_scale = saved_data["pc"]
		Engine.set_meta("debug_scale", Vector3(pc_scale, pc_scale, pc_scale))
		Engine.set_meta("is_debug_scaling", true)

func save_height_to_disk(char_id, scale_value):
	var saved_data = {}
	if Engine.has_meta("global_height_dict"):
		saved_data = Engine.get_meta("global_height_dict")
		
	saved_data[char_id] = scale_value
	Engine.set_meta("global_height_dict", saved_data)
	
	var file = File.new()
	file.open(SAVE_FILE_PATH, File.WRITE)
	file.store_string(JSON.print(saved_data))
	file.close()

func get_character_id():
	var current_node = self
	for _i in range(6):
		if current_node == null: break
		if current_node.get("savedCharacterID") != null:
			return str(current_node.get("savedCharacterID"))
		current_node = current_node.get_parent()
	return "UNKNOWN"

func get_character_root():
	var current_node = self
	for _i in range(6):
		if current_node == null: break
		if current_node.get("savedCharacterID") != null:
			return current_node 
		current_node = current_node.get_parent()
	return null

func calculate_offsets(target_size, activity_text):
	var height_diff = target_size - 1.0 
	var target_y = 0.0
	var target_x = 0.0
	var is_active_pose = false
	
	for rule in pose_rules:
		# Check exclusions to prevent overlap
		if rule.has("exclude"):
			var should_skip = false
			for ex in rule["exclude"]:
				if ex in activity_text:
					should_skip = true
					break
			if should_skip:
				continue
				
		var all_match = true
		for k in rule["keys"]:
			if not k in activity_text:
				all_match = false
				break
		
		if all_match:
			# Apply scaling offsets
			target_y = height_diff * rule["offsets"][0]
			target_x = height_diff * rule["offsets"][1]
			
			# If the rule has Base Offsets (4 numbers)
			if rule["offsets"].size() >= 4:
				target_y += rule["offsets"][2]
				target_x += rule["offsets"][3]
				
			is_active_pose = true
			break 
			
	return [target_x, target_y, is_active_pose]

func _process(_delta):
	var char_id = get_character_id()
	var root = get_character_root()
	
	if not root or char_id == "UNKNOWN": return
	
	var target_size = 0.0
	
	if char_id == "pc":
		if Engine.has_meta("is_debug_scaling") and Engine.get_meta("is_debug_scaling"):
			target_size = abs(Engine.get_meta("debug_scale").x)
			
	elif not char_id in excluded_npc_ids:
		var saved_data = Engine.get_meta("global_height_dict")
		if not saved_data.has(char_id):
			var random_scale = possible_scales[randi() % possible_scales.size()]
			save_height_to_disk(char_id, random_scale)
			target_size = random_scale
		else:
			target_size = saved_data[char_id]
			
	if target_size > 0.0:
		# 1. Gather Activity Text FIRST so we can check for overrides
		var activity_text = ""
		
		# NEW: Safely ask the scene orchestrator if this character is the user or target
		if root.owner != null:
			if root.owner.get("user") == root or root.owner.get("user") == root.get_parent():
				activity_text += "role:dom "
			elif root.owner.get("target") == root or root.owner.get("target") == root.get_parent():
				activity_text += "role:sub "
				
		# NEW: Grab the character's exact node name as a backup
		activity_text += "node:" + str(root.name).to_lower() + " "
		
		if root.get_parent() != null:
			activity_text += "slot:" + str(root.get_parent().name).to_lower() + " "
			
		if root.owner != null:
			activity_text += str(root.owner).to_lower() + " "
			
		var anim_player = root.get_node_or_null("AnimationPlayer")
		if anim_player != null:
			activity_text += str(anim_player.current_animation).to_lower() + " "
			
		var state_dict = root.get("state")
		if state_dict != null and typeof(state_dict) == TYPE_DICTIONARY:
			for key in state_dict.keys():
				activity_text += str(key).to_lower() + ":" + str(state_dict[key]).to_lower() + " "
				
		var temp_state = root.get("temporaryState")
		if temp_state != null and typeof(temp_state) == TYPE_DICTIONARY:
			for key in temp_state.keys():
				activity_text += str(key).to_lower() + ":" + str(temp_state[key]).to_lower() + " "

		# OVERRIDE SCALING FOR IMPOSSIBLE POSES
		for disabled_pose in disabled_scale_poses:
			if disabled_pose in activity_text:
				target_size = 1.0 
				break # Stop checking once a match is found
				
		# 3. Apply the final target size
		var current = root.scale
		var sign_x = -1.0 if current.x < 0 else 1.0
		var sign_y = -1.0 if current.y < 0 else 1.0
		var sign_z = -1.0 if current.z < 0 else 1.0
		
		root.scale = Vector3(target_size * sign_x, target_size * sign_y, target_size * sign_z)
				
		# 4. Print Debug Log if it changed
		if not Engine.has_meta("last_text_" + char_id) or Engine.get_meta("last_text_" + char_id) != activity_text:
			print("DEBUG [", char_id, "]: ", activity_text)
			Engine.set_meta("last_text_" + char_id, activity_text)
			
		# 5. Calculate & Apply Offsets
		var offsets = calculate_offsets(target_size, activity_text)
		var target_x = offsets[0]
		var target_y = offsets[1]
		var is_active_pose = offsets[2]
			
		if "translation" in root:
			# Y-axis always returns to normal when not in scene
			root.translation.y = lerp(root.translation.y, target_y, 0.1)
			
			# ONLY apply X-axis movement if sex scene is recognized
			if is_active_pose:
				root.translation.x = lerp(root.translation.x, target_x, 0.1)
