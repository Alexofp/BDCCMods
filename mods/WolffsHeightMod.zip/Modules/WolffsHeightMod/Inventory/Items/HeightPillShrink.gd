extends ItemBase

var sceneID = "IgnoreMe"

func _init():
	id = "HeightPillShrink"

func getVisibleName():
	return "Bone-Compressing Pill"

func getDescription():
	return "An experimental medical pill. It causes permanent bone and tissue compression, decreasing your overall height."

func canUseInCombat():
	return true

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SexEngineDrug
	]

func getItemCategory():
	return ItemCategory.Medical

func getInventoryImage():
	return "res://Images/Items/medical/tfpill.png"

func useItem(_character):
	var possible_scales = [0.85, 0.92, 1.0, 1.07]
	var height_names = ["Very Short", "Short", "Normal", "Tall"]
	
	var target_id = "pc"
	var target_name = "You"
	if _character != null and _character.has_method("getID"):
		target_id = _character.getID()
		if target_id != "pc":
			target_name = _character.getName()

	var saved_data = {}
	if Engine.has_meta("global_height_dict"):
		saved_data = Engine.get_meta("global_height_dict")
		
	var current_scale = 1.0
	if saved_data.has(target_id):
		current_scale = saved_data[target_id]
	elif target_id == "pc" and Engine.has_meta("is_debug_scaling") and Engine.get_meta("is_debug_scaling"):
		current_scale = Engine.get_meta("debug_scale").x
		
	var index = 2
	var min_diff = 999.0
	for i in range(possible_scales.size()):
		var diff = abs(possible_scales[i] - current_scale)
		if diff < min_diff:
			min_diff = diff
			index = i
		
	if index > 0:
		var new_index = index - 1
		var new_scale = possible_scales[new_index]
		
		if target_id == "pc":
			Engine.set_meta("debug_scale", Vector3(new_scale, new_scale, new_scale))
			Engine.set_meta("is_debug_scaling", true)
		
		saved_data[target_id] = new_scale
		Engine.set_meta("global_height_dict", saved_data)
		
		var file = File.new()
		file.open("user://mod_heights.json", File.WRITE)
		file.store_string(JSON.print(saved_data))
		file.close()
		
		if target_id == "pc":
			return "You swallow the pill. A bizarre tingling sensation washes over you as your body compresses, leaving you visibly shorter! You are now [" + height_names[new_index] + "]."
		else:
			return target_name + " swallows the pill. A bizarre tingling sensation washes over them as their body compresses, leaving them visibly shorter! " + target_name + " is now [" + height_names[new_index] + "]."
	else:
		if target_id == "pc":
			return "You swallow the pill, but nothing happens. Your body can't compress any further [" + height_names[index] + "]."
		else:
			return target_name + " swallows the pill, but nothing happens. Their body can't compress any further [" + height_names[index] + "]."

func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Take the pill"
		}
	]

func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	var target = _receiver
	if target == null:
		target = _attacker
		
	return useItem(target)

func useInSex(_receiver):
	var text = useItem(_receiver)
	return {
		"text": text
	}

func getSexEngineInfo(_sexEngine, _domInfo, _subInfo):
	return {
		"name": "Bone-Compressing Pill",
		"usedName": "a Bone-Compressing pill",
		"desc": "Decreases height.",
		"scoreOnSub": 0.0,
		"scoreOnSelf": 0.0,
		"scoreSubScore": 0.0,
		"canUseOnDom": true,
		"canUseOnSub": true,
		"maxUsesByNPC": 0,
	}
