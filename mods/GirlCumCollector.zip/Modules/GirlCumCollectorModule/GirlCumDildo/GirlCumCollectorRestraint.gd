extends RestraintData
class_name GirlCumCollectorRestraint

func _init():
    npcDodgeDifficultyMod = 1.5
    restraintType = RestraintType.VaginalPlug
    sexReaction = SexReaction.BondageVaginalPlug

func canUnlockWithKey():
    return false

func alwaysSavedWhenStruggledOutOf():
    return true

func shouldDoStruggleMinigame(_pc):
    var _handsFree = !_pc.hasBlockedHands()
    if _handsFree:
        return false
    return .shouldDoStruggleMinigame(_pc)

func doStruggle(_pc, _minigame:MinigameResult):
    var _handsFree = !_pc.hasBlockedHands()
    var _armsFree = !_pc.hasBoundArms()
    var _legsFree = !_pc.hasBoundLegs()
    var text = "error?"
    var lust = 0
    var pain = 0
    var damage = 0
    var stamina = 0

    if failChanceLowScore(_pc, 20, _minigame):
        text = "{user.name} clenches and tries to push the GirlCum Collector out, but the dildo only slides deeper. It suddenly activates and milks {user.his} vagina hard, sucking out more girlcum."
        damage = -0.5
        lust = scaleDamage(12)
        pain = scaleDamage(5)
        _pc.getBodypart(BodypartSlot.Vagina).addFluidOrifice("GirlCum", RNG.randf_range(60.0, 120.0))
        
    elif _handsFree && _armsFree:
        text = "Because {user.name}'s hands are free, {user.he} easily pulls the GirlCum Collector Dildo out."
        damage = 1.0
        lust = scaleDamage(6)
        
    elif _legsFree:
        text = "{user.name} squirms and rolls {user.his} hips, trying to force the milking dildo out of {user.his} vagina."
        damage = calcDamage(_pc, _minigame, 0.85)
        stamina = RNG.randi_range(5, 8)
        lust = scaleDamage(7)
        
    else:
        text = "{user.name} desperately wiggles and clenches, trying to expel the GirlCum Collector, but being unable to spread {user.his} legs makes it very difficult."
        damage = calcDamage(_pc, _minigame, 0.45)
        stamina = RNG.randi_range(10, 14)
        lust = scaleDamage(8)

    if damage < 1.0 && !(_handsFree && _armsFree):
        if _pc.isPlayer() && failChance(_pc, 60) && _pc.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom):
            if _pc.getInventory().getEquippedItem(InventorySlot.UnderwearBottom).coversBodypart(BodypartSlot.Vagina):
                text += " The dildo presses firmly against your underwear."
                damage /= 2.0
            if failChance(_pc, 20):
                text += " [b]Your underwear slipped down.[/b]"
                _pc.getInventory().unequipSlot(InventorySlot.UnderwearBottom)

    return {"text": text, "damage": damage, "lust": lust, "pain": pain, "stamina": stamina}

func processStruggleTurn(_pc, _isActivelyStruggling):
    if failChance(_pc, 25):
        _pc.getBodypart(BodypartSlot.Vagina).addFluidOrifice("GirlCum", RNG.randf_range(40.0, 80.0))
        return {"text": "The GirlCum Collector suddenly activates and milks {user.name}'s vagina, sucking out a big load of girlcum.", "lust": scaleDamage(10)}
    
    elif failChance(_pc, 35):
        return {"text": "The GirlCum Collector vibrates and throbs intensely inside {user.name}, stimulating {user.his} walls.", "lust": scaleDamage(9)}
    
    elif failChance(_pc, 30):
        return {"text": "The GirlCum Collector gives {user.name} a strong milking pulse!", "lust": scaleDamage(11)}
    
    elif failChance(_pc, 25) || _isActivelyStruggling:
        return {"text": "The GirlCum Collector shifts and sucks on {user.name}'s sensitive walls while {user.he} {user.verbS('squirm')}.", "lust": scaleDamage(6)}

    return {"text": "The GirlCum Collector stays firmly lodged inside {user.name}.", "lust": scaleDamage(3)}
