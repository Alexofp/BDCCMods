extends ItemBase

var lastTimeMilked: float = 0.0

func _init():
    id = "GirlCumDildo"

func generateFluids():
    fluids = Fluids.new()
    fluids.setCapacity(12000.0)

func addFluid(amount: float):
    var dna = FluidDNA.new()
    dna.charID = getWearer().getID()
    dna.virility = 0.0
    dna.species = getWearer().getSpecies()
    fluids.addFluid("GirlCum", amount, dna)

func getVisibleName():
    return "GirlCum Collector Dildo"

func getDescription():
    var desc = "A strange dildo designed to collect and store girl cum from the wearer."
    
    if getFluids() && getFluids().getFluidAmount() > 0:
        desc += "\n[b]Currently contains:[/b] " + str(Util.roundF(getFluids().getFluidAmount())) + " ml of girl cum."
        if getFluids().isFull():
            desc += " [color=red](Full)[/color]"
    else:
        desc += "\nIt is currently empty."
    
    return desc

func getEquippedDescription(_slot):
    var desc = "A GirlCum Collector Dildo is lodged deep inside your vagina, actively milking you."
    
    var fluids = getFluids()
    if fluids:
        var amount = fluids.getFluidAmount()
        desc += "\n[b]Contains:[/b] " + str(Util.roundF(amount)) + " / 12000 ml of girl cum"
        
        if fluids.isFull():
            desc += "\n[color=green]It is full and can now be removed.[/color]"
        else:
            desc += "\n[color=red]It is locked until completely full.[/color]"
    
    return desc

func getClothingSlot():
    return InventorySlot.Vagina

func getRiggedParts(_character):
    if itemState != null and itemState.isRemoved():
        return null
    return {"Vagina": "res://Modules/GirlCumCollectorModule/GirlCumDildo/GirlCumDildo.tscn"}

func getPuttingOnStringLong(withS):
    if withS:
        return "slides the GirlCum Collector Dildo into {pc.your} vagina, making you shudder."
    else:
        return "slide the GirlCum Collector Dildo into your vagina, making you shudder."

func getTakingOffStringLong(withS):
    if withS:
        return "pulls the GirlCum Collector Dildo out of {pc.your} vagina."
    else:
        return "pull the GirlCum Collector Dildo out of your vagina."

func getTakeOffScene():
    return "GirlCumDildoRemoveScene"

func getPrice():
    return 50

func getTags():
    return [
	ItemTag.BDSMRestraint,
        ItemTag.CanBeForcedByGuards,
        ItemTag.CanBeForcedInStocks,
        ItemTag.SoldByGeneralVendomat,
        ItemTag.SoldByMedicalVendomat,
        ItemTag.CanPeeInto,
        ItemTag.CanForceCumInto,
    ]

func getBuffs():
    return [
        buff(Buff.AmbientLustBuff, [45]),
        buff(Buff.MinLoosenessVaginaBuff, [7.5]),
        buff(Buff.BlocksVaginaLeakingBuff),
        buff(Buff.ChastityVaginaBuff),
        buff(Buff.GenitalElasticityBuff, [20.0]),
        buff(Buff.SensitivityRestoreBuff, [BodypartSlot.Vagina, -10.0]),
        buff(Buff.SensitivityGainBuff, [BodypartSlot.Vagina, 50.0]),
        buff(Buff.OverstimulationThresholdBuff, [BodypartSlot.Vagina, -25.0]),
    ]

func getPossibleActions():
    return [
        {
            "name": "Transfer fluids",
            "scene": "FluidTransferScene",
            "description": "Transfer the fluids between fluid containers",
        },
        {
            "name": "Adjust Looseness",
            "scene": "GirlCumDildoLoosenessScene",
            "description": "Change current and minimum looseness of your holes",
        },
        {
            "name": "Drink from",
            "scene": "DrinkFromScene",
            "description": "Swallow the contents of this item",
        },
        {
            "name": "Collect fluids from you",
            "scene": "CatchBodyFluidsScene",
            "description": "Catch some of the fluids that you are covered with",
        },
        {
            "name": "Turn on and masturbate",
            "scene": "MasturbationScene",
            "description": "Turn on the vibrator and masturbate",
        },
    ]

func onAction(_actionID, _args):
    if _actionID == "Adjust Looseness":
        GM.main.addMessage("You focus on the dildo and adjust your looseness...")
        # This will be handled in the new scene
        pass

func getInventoryImage():
    return "res://Modules/GirlCumCollectorModule/GirlCumDildo/icon.tres"

func saveData():
    var data = .saveData()
    data["lastTimeMilked"] = lastTimeMilked
    if getFluids():
        data["fluids"] = getFluids().saveData()
    return data

func loadData(data):
    .loadData(data)
    lastTimeMilked = data.get("lastTimeMilked", 0.0)
    if getFluids() and data.has("fluids"):
        getFluids().loadData(data["fluids"])

# lock, some stuff here doesnt work because im stupid
func canBeUnequipped():
    var fluids = getFluids()
    if fluids == null:
        return true
    return fluids.isFull()

func canBeQuickUnequipped():
    return canBeUnequipped()

func getUnEquipDenyReason():
    var fluids = getFluids()
    if fluids && !fluids.isFull():
        return "The dildo is locked tight until it collects enough girl cum."
    return null

func isRestraint():
    return true

func generateRestraintData():
	restraintData = RestraintUnremovable.new()
	restraintData.setLevel(calculateBestRestraintLevel())

func shouldBeDroppedOnSexEnd():
    return false

func isVaginalPlug():
    return true

func _getWornSlot():
    return InventorySlot.Vagina