extends "res://Scenes/SceneBase.gd"

func _init():
    sceneID = "GirlCumDildoLoosenessScene"

func _run():
    if state == "":
        var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
        if !vagina:
            saynn("You don't have a vagina.")
            addButton("Close", "", "endthescene")
            return
           
        var orifice: Orifice = vagina.getOrifice()
        var currentLooseness = orifice.getLooseness() if orifice else 0.0
        
        saynn("The thick GirlCum Collector throbs and pulses warmly deep inside your dripping cunt. Its special mechanisms are actively connected to your most intimate depths, sending pleasurable ripples through your sensitive vaginal walls as it milks you.")
        saynn("You can feel it gently massaging and stimulating you from the inside, letting you control over how loose and used your pussy feels right now.")
        
        saynn("[b]Current Vaginal Looseness:[/b] " + str(Util.roundF(currentLooseness, 1)) +
              " (" + orifice.getLoosenessString() + ")")
        
        saynn("Your cunt feels wonderfully [i]" + orifice.getLoosenessString() + "[/i] around the thick intruder, ready to be adjusted to whatever slutty state you desire.")
        
        addButton("Adjust Your Pussy Looseness", "Change how loose, stretched, and fuckable your cunt is right now", "set_current_menu")
        addButton("Close", "Leave the milking object inside you", "endthescene")

    elif state == "set_current":
        saynn("You focus on the throbbing object buried deep in your vagina. You can make your cunt as tight and virginal or as loose and ruined as you want...")
        for i in range(21):
            addButton(str(i), "", "apply_current", [float(i)])
        addButton("Back", "", "")


func _react(_action: String, _args):
    if _action == "endthescene":
        endScene()
        return

    if _action == "set_current_menu":
        setState("set_current")
        return

    var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
    if !vagina:
        GM.main.addMessage("No vagina found.")
        setState("")
        return

    var orifice: Orifice = vagina.getOrifice()
    if !orifice:
        GM.main.addMessage("No orifice found.")
        setState("")
        return

    if _action == "apply_current":
        var value = clamp(_args[0], 0.0, 20.0)
        orifice.setLooseness(value)
        GM.main.addMessage("Your vagina is now " + str(Util.roundF(value, 1)) + 
                          " looseness (" + orifice.getLoosenessString() + "). It feels incredibly " + getSexualDescription(value) + ".")

    setState("")


func getSexualDescription(value: float) -> String:
    if value <= 1.0: return "tight and eager, squeezing around the object"
    if value <= 3.0: return "delightfully snug and fuckable"
    if value <= 6.0: return "loose and welcoming, perfect for big cocks"
    if value <= 10.0: return "very used and stretched, a proper cumdump pussy"
    if value <= 15.0: return "gaping and ruined, easily taking anything"
    return "a completely wrecked, cavernous fuckhole"


func _onSceneEnd():
    var vagina = GM.pc.getBodypart(BodypartSlot.Vagina)
    if vagina && vagina.has_method("updateLooseness"):
        vagina.updateLooseness()