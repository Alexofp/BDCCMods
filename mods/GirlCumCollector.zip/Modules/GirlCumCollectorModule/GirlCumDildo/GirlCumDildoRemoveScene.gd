extends "res://Scenes/SceneBase.gd"

func _init():
    sceneID = "GirlCumDildoRemoveScene"

func _run():
    if state == "":
        var item = GM.pc.getInventory().getEquippedItemByID("GirlCumDildo")
        if item == null:
            endScene()
            return
        
        var fluids = item.getFluids()
        
        if fluids && fluids.isFull():
            saynn("The GirlCum Collector Dildo is now full.")
            saynn("You can finally remove it.")
            addButton("Remove it", "Pull the dildo out", "remove")
        else:
            saynn("You try to pull out the GirlCum Collector Dildo...")
            saynn("But it's firmly locked in place.")
            saynn("It won't come out until it's completely full.")
            
            addDisabledButton("Remove", "It's locked until full")
            addButton("Leave it", "Keep it inside", "endthescene")
        
        addButton("Nevermind", "Leave it alone", "endthescene")

    elif state == "remove":
        saynn("You pull the now-full GirlCum Collector Dildo out of your vagina.")
        GM.pc.getInventory().unequipSlot(InventorySlot.Vagina)
        endScene()

func _react(_action: String, _args):
    if _action == "endthescene":
        endScene()
        return
    
    if _action == "remove":
        setState("remove")
        return
    
    # Fallback
    setState(_action)