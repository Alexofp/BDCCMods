extends Module

func _init():
    id = "GirlCumCollector"
    author = "Mimi"
    
    items = [
        "res://Modules/GirlCumCollectorModule/GirlCumDildo/GirlCumDildo.gd",
    ]
    
    events = [
        "res://Modules/Events/CollectGirlCumEvent.gd",
    ]
    
    scenes = [
        "res://Modules/GirlCumCollectorModule/GirlCumDildo/GirlCumDildoRemoveScene.gd",
    ]