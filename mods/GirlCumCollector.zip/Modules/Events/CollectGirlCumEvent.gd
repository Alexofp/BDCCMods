extends EventBase

func _init():
    id = "CollectGirlCum"

func registerTriggers(es):
    es.addTrigger(self, Trigger.EnteringRoom)
    es.addTrigger(self, Trigger.Waiting)
    es.addTrigger(self, Trigger.WakeUpInCell)
    es.addTrigger(self, Trigger.TakingAShower)

func react(_triggerID, _args):
    var currentTime = GM.main.getTimeInGlobalSeconds()
    
    if !GM.pc.getInventory().hasItemIDEquipped("GirlCumDildo"):
        return false
    
    var item = GM.pc.getInventory().getEquippedItemByID("GirlCumDildo")
    if item == null:
        return false
    
    var lastTimeMilked = item.lastTimeMilked
    
    if currentTime >= (lastTimeMilked + 60*30) || _triggerID == Trigger.WakeUpInCell:
        item.lastTimeMilked = currentTime
    else:
        return false

    var amount = RNG.randf_range(300.0, 800.0)
    
    if amount > 5.0:
        item.addFluid(amount)
        var fluidName = "girl cum"
        GM.main.addMessage("Your GirlCum Collector Dildo activates, milking your vagina for " + str(Util.roundF(amount)) + " ml of " + fluidName + ".")
        
        if item.getFluids().isFull():
            GM.main.addMessage("Your GirlCum Collector Dildo is now full!")

        GM.pc.addSkillExperience(Skill.Milking, 8)
    else:
         GM.main.addMessage("Your GirlCum Collector Dildo stimulates your vagina for a few minutes but doesn't manage to extract much fluid.")
        
    return false

func getPriority():
    return 20