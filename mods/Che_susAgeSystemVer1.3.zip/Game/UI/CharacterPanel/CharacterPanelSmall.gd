extends PanelContainer

var characterID: String

onready var characterNameLabel = $VBoxContainer/CharacterName
onready var characterStatusGrid = $VBoxContainer/CharacterStatusGrid

const MODULE_ID = "che_susAgeSystem"
const FLAG_AGES = "Ages"

var _rng = RandomNumberGenerator.new()

const _PERSIST_DIR = "user://che_sus_age_system"
var _persist_loaded_key := ""

func _get_persist_key() -> String:
	var slot = 0
	if(GlobalRegistry != null && "currentSave" in GlobalRegistry):
		slot = int(GlobalRegistry.currentSave)
	var uid = 0
	if(GlobalRegistry != null && "currentUniqueID" in GlobalRegistry):
		uid = int(GlobalRegistry.currentUniqueID)
	return "slot_%d_uid_%d" % [slot, uid]

func _get_persist_path() -> String:
	return _PERSIST_DIR + "/" + _get_persist_key() + ".json"

func _load_persisted_ages() -> Dictionary:
	var result := {}
	var f := File.new()
	var path := _get_persist_path()
	if(!f.file_exists(path)):
		return result
	if(f.open(path, File.READ) != OK):
		return result
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse(txt)
	if(parsed.error != OK):
		return result
	if(parsed.result is Dictionary && parsed.result.has("Ages") && parsed.result["Ages"] is Dictionary):
		result = parsed.result["Ages"]
	return result

func _save_persisted_ages(ages:Dictionary) -> void:
	var dir := Directory.new()
	if(!dir.dir_exists(_PERSIST_DIR)):
		dir.make_dir_recursive(_PERSIST_DIR)
	var f := File.new()
	var path := _get_persist_path()
	if(f.open(path, File.WRITE) != OK):
		return
	var payload := {
		"version": 1,
		"key": _get_persist_key(),
		"Ages": ages,
	}
	f.store_string(JSON.print(payload))
	f.close()

func _restore_persisted_ages_into_moduleflag() -> void:
	var persisted := _load_persisted_ages()
	if(persisted.empty()):
		return
	_ensure_persist_loaded()

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}
	for k in persisted.keys():
		ages[k] = persisted[k]
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)

func _ensure_persist_loaded() -> void:
	if(GM == null || GM.main == null):
		return
	var key := _get_persist_key()
	if(_persist_loaded_key == key):
		return
	_persist_loaded_key = key
	_restore_persisted_ages_into_moduleflag()



func _init():
	_rng.randomize()

func _ready():
	add_to_group("che_susAgeSystem_panels")

func setCharacterID(charID: String):
	var character = GlobalRegistry.getCharacter(charID)
	if(character == null):
		return

	characterNameLabel.text = character.getName()
	characterNameLabel.self_modulate = character.getChatColor()
	characterID = charID
	character.updateEffectPanel(characterStatusGrid)

	_updateNameLabel(character)

func getCharacterID():
	return characterID

func updateStatuses():
	if(characterID == null || characterID == ""):
		return
	var character = GlobalRegistry.getCharacter(characterID)
	if(character == null):
		return
	character.updateEffectPanel(characterStatusGrid)
	_updateNameLabel(character)

func refreshAgeLine():
	if(characterID == null || characterID == ""):
		return
	var character = GlobalRegistry.getCharacter(characterID)
	if(character == null):
		return
	_updateNameLabel(character)

func _updateNameLabel(character):
	if(character == null):
		return
	var age = _getOrGenerateAge(characterID)
	if(age < 1):
		characterNameLabel.text = character.getName()
		return
	var typeLabel = _getAgeTypeLabel(age)
	characterNameLabel.text = character.getName() + "\nAge: " + str(age) + " (" + typeLabel + ")"

func _getAgeTypeLabel(age: int) -> String:
	if(age <= 18):
		return "Teen"
	if(age <= 27):
		return "Young"
	if(age <= 39):
		return "Adult"
	if(age <= 60):
		return "Mature"
	return "Older"

const _GLOBAL_AGE_LIMITS_PATH = _PERSIST_DIR + "/global_age_limits.json"

func _getConfiguredAgeRange() -> Array:
	var minAge := 18
	var maxAge := 80
	var f := File.new()
	if(f.file_exists(_GLOBAL_AGE_LIMITS_PATH) && f.open(_GLOBAL_AGE_LIMITS_PATH, File.READ) == OK):
		var txt := f.get_as_text()
		f.close()
		var parsed = JSON.parse(txt)
		if(parsed.error == OK && parsed.result is Dictionary):
			var data: Dictionary = parsed.result
			if(data.has("min") && (typeof(data["min"]) == TYPE_INT || typeof(data["min"]) == TYPE_REAL)):
				minAge = int(data["min"])
			if(data.has("max") && (typeof(data["max"]) == TYPE_INT || typeof(data["max"]) == TYPE_REAL)):
				maxAge = int(data["max"])
	minAge = int(clamp(minAge, 18, 200))
	maxAge = int(clamp(maxAge, 1, 200))
	if(maxAge < minAge):
		maxAge = minAge
	return [minAge, maxAge]

func _randAge() -> int:
	var ageRange := _getConfiguredAgeRange()
	var minAge: int = ageRange[0]
	var maxAge: int = ageRange[1]
	if(maxAge <= minAge):
		return minAge

	var roll = _rng.randi_range(1, 100)
	var bucket := 4
	if(roll <= 65):
		bucket = 0
	elif(roll <= 82):
		bucket = 1
	elif(roll <= 92):
		bucket = 2
	elif(roll <= 97):
		bucket = 3

	var span: float = float(maxAge - minAge)
	var bucketWidth: float = span / 5.0
	var bucketMin: int = minAge + int(floor(bucketWidth * bucket))
	var bucketMax: int = minAge + int(floor(bucketWidth * (bucket + 1)))
	if(bucket == 4):
		bucketMax = maxAge
	if(bucketMax < bucketMin):
		bucketMax = bucketMin
	return _rng.randi_range(bucketMin, bucketMax)

func _isDynamicPopulationCharacter(charID: String) -> bool:
	return charID.begins_with("dynamicnpc")

func _getOrGenerateAge(charID: String) -> int:
	if(GM == null || GM.main == null):
		return -1

	_ensure_persist_loaded()

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}

	if(ages.has(charID)):
		var existing = ages[charID]
		var t = typeof(existing)
		if(t == TYPE_INT || t == TYPE_REAL):
			var asInt = int(existing)
			if(asInt >= 1 && asInt <= 200):
				return asInt

	if(!_isDynamicPopulationCharacter(charID)):
		return -1

	var newAge = _randAge()
	ages[charID] = newAge
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
	_save_persisted_ages(ages)
	return newAge
