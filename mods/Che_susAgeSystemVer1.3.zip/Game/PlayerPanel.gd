extends VBoxContainer

onready var grid = $FlexGridContainer
onready var nameLabel = $NameLabel
onready var ageLabel = $AgeLabel
onready var creditsLabel = $CreditsLabel
onready var camera3d = $ViewportWrapper/Viewport/Camera
onready var stage3d = $ViewportWrapper/Viewport/Stage3D
onready var viewport = $ViewportWrapper/Viewport
onready var staminaBar = $StaminaBar
onready var painBar = $PainBar
onready var lustBar = $HBoxContainer/LustBar
onready var levelBar = $LevelBar

onready var consciousnessBar = $ConsciousnessBar
onready var arousalBar = $HBoxContainer/ArousalBar

const MODULE_ID = "che_susAgeSystem"
const FLAG_AGES = "Ages"
const _PERSIST_DIR = "user://che_sus_age_system"

var previousPosition: Vector2 = Vector2(0, 0)
var startMousePosition: Vector2 = Vector2(0, 0)
var draggingCamera: bool = false
var mouseInsideViewport = false
var savedTooltipDoll = null
var savedTooltipBodypartSlot = null

func _ready():
	set_process_input(true)
	set_process_unhandled_input(true)
	camera3d.current = true
	add_to_group("che_susAgeSystem_player_panels")
	_bulkAssignAgesToPopulation()
	updateUI()

func loadingSavefileFinished():
	_bulkAssignAgesToPopulation()
	updateUI()

func on_player_statchange():
	_bulkAssignAgesToPopulation()
	updateUI()

func refreshAgeLine():
	updateUI()

var _lastBulkAgeScanMs := -1000000

# Assigns an age to every random population NPC (dynamicnpcXXX) currently
# known to the game, not just the ones on screen. Throttled to avoid
# rescanning the population too often.
func _bulkAssignAgesToPopulation() -> void:
	if(GM == null || GM.main == null):
		return
	if(!GM.main.has_method("getDynamicCharacters")):
		return

	var nowMs = OS.get_ticks_msec()
	if(nowMs - _lastBulkAgeScanMs < 3000):
		return
	_lastBulkAgeScanMs = nowMs

	var dynChars = GM.main.getDynamicCharacters()
	if(!(dynChars is Dictionary) || dynChars.empty()):
		return

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}

	var changed := false
	for charID in dynChars.keys():
		var idStr := str(charID)
		if(!idStr.begins_with("dynamicnpc")):
			continue
		if(ages.has(idStr) && _isValidAgeValue(ages[idStr])):
			continue
		ages[idStr] = _randAge()
		changed = true

	if(changed):
		GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
		_savePersistedAges(ages)

func updateUI():
	nameLabel.text = GM.pc.getName() + ", " + GM.pc.getSpeciesFullName()
	creditsLabel.text = "Work Credits: " + str(GM.pc.getCredits())

	painBar.setProgressBarValueInt(GM.pc.getPain(), GM.pc.painThreshold())
	painBar.setText( str(GM.pc.getPain()) + " / " + str(GM.pc.painThreshold()) )

	lustBar.setProgressBarValueInt(GM.pc.getLust(), GM.pc.lustThreshold())
	lustBar.setText( str(GM.pc.getLust()) + " / " + str(GM.pc.lustThreshold()) )

	staminaBar.setProgressBarValueInt(GM.pc.getStamina(), GM.pc.getMaxStamina())
	staminaBar.setText( str(GM.pc.getStamina()) + " / " + str(GM.pc.getMaxStamina()) )
	
	levelBar.setProgressBarValue(GM.pc.getSkillsHolder().getLevelProgress())
	levelBar.setText(str(GM.pc.getSkillsHolder().getLevel()))
	
	var arousal = GM.pc.getArousal()
	if(arousal > 0.0):
		arousalBar.visible = true
		arousalBar.setProgressBarValue(arousal)
		arousalBar.setText( str(Util.roundF(arousal*100.0))+"%" )
		lustBar.setText( str(Util.roundF(GM.pc.getLustLevel()*100.0))+"%" )
	else:
		arousalBar.visible = false
		arousalBar.setProgressBarValue(0.0)

	var consciousness = GM.pc.getConsciousness()
	if(consciousness < 1.0):
		levelBar.visible = false
		consciousnessBar.visible = true
		consciousnessBar.setProgressBarValue(consciousness)
		consciousnessBar.setText( str(Util.roundF(consciousness*100.0))+"%" )
	else:
		levelBar.visible = true
		consciousnessBar.visible = false
		consciousnessBar.setProgressBarValue(1.0)

	var _currentAge = _getOrGeneratePlayerAge()
	ageLabel.text = "Age: " + (str(_currentAge) if _currentAge >= 1 else "-")

func _getPersistKey() -> String:
	var slot = 0
	if(GlobalRegistry != null && "currentSave" in GlobalRegistry):
		slot = int(GlobalRegistry.currentSave)
	var uid = 0
	if(GlobalRegistry != null && "currentUniqueID" in GlobalRegistry):
		uid = int(GlobalRegistry.currentUniqueID)
	return "slot_%d_uid_%d" % [slot, uid]

func _getPersistPath() -> String:
	return _PERSIST_DIR + "/" + _getPersistKey() + ".json"

func _loadPersistedAges() -> Dictionary:
	var result := {}
	var f := File.new()
	var path := _getPersistPath()
	if(!f.file_exists(path)):
		return result
	if(f.open(path, File.READ) != OK):
		return result
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse(txt)
	if(parsed.error != OK):
		return result
	if(parsed.result is Dictionary && parsed.result.has("Ages") && parsed.result["Ages"] is Dictionary):
		result = parsed.result["Ages"]
	return result

func _savePersistedAges(ages: Dictionary) -> void:
	var dir := Directory.new()
	if(!dir.dir_exists(_PERSIST_DIR)):
		dir.make_dir_recursive(_PERSIST_DIR)
	var f := File.new()
	if(f.open(_getPersistPath(), File.WRITE) != OK):
		return
	var payload := {
		"version": 2,
		"key": _getPersistKey(),
		"Ages": ages,
	}
	f.store_string(JSON.print(payload))
	f.close()

const _GLOBAL_AGE_LIMITS_PATH = _PERSIST_DIR + "/global_age_limits.json"

func _getConfiguredAgeRange() -> Array:
	var minAge := 18
	var maxAge := 80
	var f := File.new()
	if(f.file_exists(_GLOBAL_AGE_LIMITS_PATH) && f.open(_GLOBAL_AGE_LIMITS_PATH, File.READ) == OK):
		var txt := f.get_as_text()
		f.close()
		var parsed = JSON.parse(txt)
		if(parsed.error == OK && parsed.result is Dictionary):
			var data: Dictionary = parsed.result
			if(data.has("min") && (typeof(data["min"]) == TYPE_INT || typeof(data["min"]) == TYPE_REAL)):
				minAge = int(data["min"])
			if(data.has("max") && (typeof(data["max"]) == TYPE_INT || typeof(data["max"]) == TYPE_REAL)):
				maxAge = int(data["max"])
	minAge = int(clamp(minAge, 18, 200))
	maxAge = int(clamp(maxAge, 1, 200))
	if(maxAge < minAge):
		maxAge = minAge
	return [minAge, maxAge]

func _randAge() -> int:
	var ageRange := _getConfiguredAgeRange()
	var minAge: int = ageRange[0]
	var maxAge: int = ageRange[1]
	if(maxAge <= minAge):
		return minAge

	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var roll = rng.randi_range(1, 100)
	var bucket := 4
	if(roll <= 65):
		bucket = 0
	elif(roll <= 82):
		bucket = 1
	elif(roll <= 92):
		bucket = 2
	elif(roll <= 97):
		bucket = 3

	var span: float = float(maxAge - minAge)
	var bucketWidth: float = span / 5.0
	var bucketMin: int = minAge + int(floor(bucketWidth * bucket))
	var bucketMax: int = minAge + int(floor(bucketWidth * (bucket + 1)))
	if(bucket == 4):
		bucketMax = maxAge
	if(bucketMax < bucketMin):
		bucketMax = bucketMin
	return rng.randi_range(bucketMin, bucketMax)

func _isValidAgeValue(value) -> bool:
	var t = typeof(value)
	return t == TYPE_INT || t == TYPE_REAL

func _toAgeInt(value, fallback: int) -> int:
	if(!_isValidAgeValue(value)):
		return fallback
	var result = int(value)
	if(result < 1 || result > 200):
		return fallback
	return result

func _getOrGeneratePlayerAge() -> int:
	var charID := "pc"

	if(GM == null || GM.main == null):
		return -1

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}

	if(ages.has(charID) && _isValidAgeValue(ages[charID])):
		return _toAgeInt(ages[charID], _randAge())

	var persisted := _loadPersistedAges()
	if(persisted.has(charID) && _isValidAgeValue(persisted[charID])):
		var restoredAge = _toAgeInt(persisted[charID], _randAge())
		ages[charID] = restoredAge
		GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
		return restoredAge

	if(GM.main.has_method("getFlag") && !GM.main.getFlag("Game_CompletedPrologue")):
		return -1

	var newAge = _randAge()
	ages[charID] = newAge
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
	return newAge

func _gui_input(event: InputEvent):
	if event is InputEventMouseButton && event.button_index == BUTTON_MIDDLE:
		camera3d.size = 10
		camera3d.transform.origin = Vector3(0.0,4.141,50.0)
	
	if event is InputEventMouseButton:
		if(event.button_index == BUTTON_WHEEL_UP):
			camera3d.size *= 0.9
		if(event.button_index == BUTTON_WHEEL_DOWN):
			camera3d.size *= 1.1
	
	if event is InputEventMouseButton:
		if event.pressed:
			draggingCamera = true
			startMousePosition = event.position
			previousPosition = event.position
		else:
			draggingCamera = false
	elif touch_points.size() <= 1 && draggingCamera && event is InputEventMouseMotion:
		var delta = previousPosition - event.position
		camera3d.translate(Vector3(delta.x * camera3d.size / 500.0, -delta.y * camera3d.size / 500.0, 0.0))
		previousPosition = event.position

	if event is InputEventScreenTouch:
		_handle_touch(event)
	elif event is InputEventScreenDrag:
		_handle_drag(event)

func _on_ViewportContainer_mouse_exited():
	mouseInsideViewport = false

func _on_ViewportContainer_mouse_entered():
	mouseInsideViewport = true

func getStatusEffectsPanel():
	return grid

func getStage3d() -> Stage3D:
	return stage3d

func _on_ViewportWrapper_gui_input(event):
	_gui_input(event)

var touch_points: Dictionary = {}

func _handle_touch(event: InputEventScreenTouch):
	if event.pressed:
		touch_points[event.index] = event.position
	else:
		if(touch_points.has(event.index)):
			touch_points.erase(event.index)

func _handle_drag(event: InputEventScreenDrag):
	if touch_points.size() == 2:
		var pivot_point: Vector2
		
		var pivot_index:int = -1
		for fingerIndex in touch_points:
			if(fingerIndex != event.index):
				pivot_index = fingerIndex
				break
		if(pivot_index < 0):
			return
		pivot_point = touch_points[pivot_index]
		
		var old_point: Vector2 = touch_points[event.index]
		var new_point: Vector2 = event.position

		var old_vector: Vector2 = old_point - pivot_point
		var new_vector: Vector2 = new_point - pivot_point
		
		var delta_scale = new_vector.length() / old_vector.length()
		camera3d.size *= delta_scale
		touch_points[event.index] = new_point
		
		var drag_vector: Vector2 = event.relative
		var offsetTranslate :Vector2 = drag_vector
		camera3d.translate(Vector3(offsetTranslate.x * camera3d.size / 500.0, -offsetTranslate.y * camera3d.size / 500.0, 0.0))
