extends "res://Scenes/SceneBase.gd"

var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")

func _init():
	sceneID = "MeScene"


const MODULE_ID = "che_susAgeSystem"
const FLAG_AGES = "Ages"
const _PERSIST_DIR = "user://che_sus_age_system"

func _getPersistKey() -> String:
	var slot = 0
	if(GlobalRegistry != null && "currentSave" in GlobalRegistry):
		slot = int(GlobalRegistry.currentSave)
	var uid = 0
	if(GlobalRegistry != null && "currentUniqueID" in GlobalRegistry):
		uid = int(GlobalRegistry.currentUniqueID)
	return "slot_%d_uid_%d" % [slot, uid]

func _getPersistPath() -> String:
	return _PERSIST_DIR + "/" + _getPersistKey() + ".json"

func _loadPersistedAges() -> Dictionary:
	var result := {}
	var f := File.new()
	var path := _getPersistPath()
	if(!f.file_exists(path)):
		return result
	if(f.open(path, File.READ) != OK):
		return result
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse(txt)
	if(parsed.error != OK):
		return result
	if(parsed.result is Dictionary && parsed.result.has("Ages") && parsed.result["Ages"] is Dictionary):
		result = parsed.result["Ages"]
	return result

const _GLOBAL_AGE_LIMITS_PATH = _PERSIST_DIR + "/global_age_limits.json"

func _getConfiguredAgeRange() -> Array:
	var minAge := 18
	var maxAge := 80
	var f := File.new()
	if(f.file_exists(_GLOBAL_AGE_LIMITS_PATH) && f.open(_GLOBAL_AGE_LIMITS_PATH, File.READ) == OK):
		var txt := f.get_as_text()
		f.close()
		var parsed = JSON.parse(txt)
		if(parsed.error == OK && parsed.result is Dictionary):
			var data: Dictionary = parsed.result
			if(data.has("min") && (typeof(data["min"]) == TYPE_INT || typeof(data["min"]) == TYPE_REAL)):
				minAge = int(data["min"])
			if(data.has("max") && (typeof(data["max"]) == TYPE_INT || typeof(data["max"]) == TYPE_REAL)):
				maxAge = int(data["max"])
	minAge = int(clamp(minAge, 18, 200))
	maxAge = int(clamp(maxAge, 1, 200))
	if(maxAge < minAge):
		maxAge = minAge
	return [minAge, maxAge]

func _randAge() -> int:
	var ageRange := _getConfiguredAgeRange()
	var minAge: int = ageRange[0]
	var maxAge: int = ageRange[1]
	if(maxAge <= minAge):
		return minAge

	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var roll = rng.randi_range(1, 100)
	var bucket := 4
	if(roll <= 65):
		bucket = 0
	elif(roll <= 82):
		bucket = 1
	elif(roll <= 92):
		bucket = 2
	elif(roll <= 97):
		bucket = 3

	var span: float = float(maxAge - minAge)
	var bucketWidth: float = span / 5.0
	var bucketMin: int = minAge + int(floor(bucketWidth * bucket))
	var bucketMax: int = minAge + int(floor(bucketWidth * (bucket + 1)))
	if(bucket == 4):
		bucketMax = maxAge
	if(bucketMax < bucketMin):
		bucketMax = bucketMin
	return rng.randi_range(bucketMin, bucketMax)

func _getAgeTypeLabel(age: int) -> String:
	if(age <= 18):
		return "Teen"
	if(age <= 27):
		return "Young"
	if(age <= 39):
		return "Adult"
	if(age <= 60):
		return "Mature"
	return "Older"

func _isValidAgeValue(value) -> bool:
	var t = typeof(value)
	return t == TYPE_INT || t == TYPE_REAL

func _toAgeInt(value, fallback: int) -> int:
	if(!_isValidAgeValue(value)):
		return fallback
	var result = int(value)
	if(result < 1 || result > 200):
		return fallback
	return result

func _getOrGeneratePlayerAge() -> int:
	var charID := "pc"

	if(GM == null || GM.main == null):
		return -1

	var ages = GM.main.getModuleFlag(MODULE_ID, FLAG_AGES, {})
	if(!(ages is Dictionary)):
		ages = {}

	if(ages.has(charID) && _isValidAgeValue(ages[charID])):
		return _toAgeInt(ages[charID], _randAge())

	var persisted := _loadPersistedAges()
	if(persisted.has(charID) && _isValidAgeValue(persisted[charID])):
		var restoredAge = _toAgeInt(persisted[charID], _randAge())
		ages[charID] = restoredAge
		GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
		return restoredAge

	if(GM.main.has_method("getFlag") && !GM.main.getFlag("Game_CompletedPrologue")):
		return -1

	var newAge = _randAge()
	ages[charID] = newAge
	GM.main.setModuleFlag(MODULE_ID, FLAG_AGES, ages)
	return newAge


func _run():
	if(state == ""):
		addButton("Close", "Continue on your way", "endthescene")
		addButtonUnlessLate("Wait here", "Spend some time idling", "wait")
		if(GM.main.isInDungeon()):
			addDisabledButton("Masturbate", "It's too dark and gross in here to masturbate. Find a resting spot!")
		else:
			addButton("Masturbate", "Do the thing", "domasturbate")
		addButton("Gender", "Pick your gender", "pickgender")
		addButton("Pronouns", "Pick your pronouns", "pickpronouns")
		addButton("Encounters", "Info about your previous encounters", "encountersMenu")
		addButton("Reputation", "Look at your reputation", "reputationMenu")
		if(!GM.main.isInDungeon()):
			addButton("Look for trouble", "Try to find an encounter", "lookfortrouble")
		if(!getFlag("Game_PickedStartingPerks", false)):
			addButton("Pick Perks!", "Pick your starting perks. You can only do this once", "pickstartingperks")
		if(GM.main.RS.special.empty()):
			addDisabledButton("Relationships", "You don't have any special relationships with others")
		else:
			addButton("Relationships", "Look at all the special relationships that you have", "specialMenu")
		if(GM.main.isInDungeon()):
			addButton("Tasks", "Look at your tasks", "tasks")

		if(GM.main.getFlag("Game_CompletedPrologue")):
			var genderSTR = "a male"
			if(GM.pc.getGender() == Gender.Female):
				genderSTR = "a female"
			if(GM.pc.getGender() == Gender.Androgynous):
				genderSTR = "an androgynous"
			if(GM.pc.getGender() == Gender.Other):
				genderSTR = "a non-gender"
			var badThingName = "was imprisoned for the crime of theft"
			if(GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Innocent):
				badThingName = "was wrongly imprisoned"
			if(GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Murder):
				badThingName = "was imprisoned for the crime of murder"
			if(GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Prostitution):
				badThingName = "was imprisoned for the crime of prostitution"
			saynn(GM.pc.getName() +" is "+genderSTR+" "+GM.pc.getSpeciesFullName() + " that "+badThingName+". Sentence length is indefinite")
		
		sayn("[b]Personal information:[/b]")
		sayn("Name: "+GM.pc.getName())
		sayn("Species: "+GM.pc.getSpeciesFullName())
		sayn("Gender: "+Gender.genderToString(GM.pc.getGender()).capitalize())
		sayn("Pronouns: "+Gender.genderToPronouns(GM.pc.getPronounGender()))
		var _playerAge = _getOrGeneratePlayerAge()
		if(_playerAge >= 1):
			sayn("Age category: "+_getAgeTypeLabel(_playerAge))
		
		sayn("Femininity: "+str(GM.pc.getFemininity())+"%")
		sayn("Thickness: "+str(GM.pc.getThickness())+"%")
		
		sayn("")
		
		sayn("[b]Bio information:[/b]")
		sayn("Intoxication: "+str(round(GM.pc.getIntoxicationLevel()*100.0))+"%")
		sayn("Intoxication tolerance: "+str(round(GM.pc.getIntoxicationTolerance()*100.0))+"%")
		var menstrualCycle: MenstrualCycle = GM.pc.getMenstrualCycle()
		if(menstrualCycle != null && menstrualCycle.hasAnyWomb()):
			sayn("Menstruation cycle: "+str(CycleStage.getVisibleActionName(menstrualCycle.getCurrentStage())))
			sayn("Cycle length: "+str(Util.roundF(menstrualCycle.getCycleLength()/60.0/60.0/24.0, 1))+" days")
			sayn("Visibly pregnant: "+str(menstrualCycle.isVisiblyPregnant()))
			sayn("Is in heat: "+str(menstrualCycle.isInHeat()))
			sayn("Estimate chance of becoming pregnant after sex: "+str(Util.roundF(menstrualCycle.getRoughChanceOfBecomingPregnant(), 1))+"%")
			sayn("Fertility: "+str(Util.roundF(GM.pc.getFertility()*100.0, 1))+"%")
		if(GM.pc.hasPenis()):
			sayn("Virility: "+str(Util.roundF(GM.pc.getVirility()*100.0, 1))+"%")
		sayn("")
		
		var bodyparts = GM.pc.getBodyparts()
		for bodypartSlot in bodyparts:
			var slotName = BodypartSlot.getVisibleName(bodypartSlot)
			var bodypart: Bodypart = bodyparts[bodypartSlot]
			sayn("[b]"+slotName+"[/b]")
			
			if(bodypart == null):
				sayn("Nothing")
				continue
				
			sayn("Type: "+bodypart.getName())
			for attribData in bodypart.getAttributesText():
				sayn(attribData[0]+": "+str(attribData[1]))
			if(bodypart.getOrifice() != null):
				sayn("Orifice type: "+bodypart.getOrificeName())
				for attribData in bodypart.getOrifice().getAttributesText():
					sayn(attribData[0]+": "+str(attribData[1]))
			if(bodypart.getFluidProduction() != null):
				for attribData in bodypart.getFluidProduction().getAttributesText():
					sayn(attribData[0]+": "+str(attribData[1]))
			if(bodypart.getSensitiveZone() != null):
				for infoLine in bodypart.getSensitiveZone().getMeInfo():
					sayn(infoLine)
		
		sayn("")
		
		sayn("[b]Stats:[/b]")
		for statID in Stat.getAll():
			var howmuch = GM.pc.getStat(statID)
			var howMuchExtra = GM.pc.getBuffsHolder().getExtraStat(statID)
			var howMuchExtraStr = (str(howMuchExtra) if howMuchExtra < 0 else "+"+str(howMuchExtra))
			var statObject:StatBase = GlobalRegistry.getStat(statID)
			sayn(statObject.getVisibleName()+": "+str(howmuch)+(" ("+howMuchExtraStr+")" if howMuchExtra != 0 else ""))
				
		sayn("")
		sayn("[b]Skills:[/b]")
		var skills = GM.pc.getSkillsHolder().getSkills()
		if(skills.size() == 0):
			sayn("No learned skills")
		for skillID in skills:
			var skill: SkillBase = skills[skillID]
			sayn(skill.getVisibleName()+": level "+str(skill.getLevel()))
		
		sayn("")
		sayn("[b]Reputation:[/b]")
		for line in GM.pc.getReputation().getInfoLines():
			sayn(line)
		
		
	if(state == "domasturbate"):
		saynn("You remove some stress by masturbating (temporary text)")
		
		addButton("Continue", "Good", "")
		
	if(state == "teststruggle"):
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("minigame", game)
		game.setDifficulty(4)
		game.connect("minigameCompleted", self, "onMinigameTest")

		addButton("Continue", "Good", "")

	if(state == "pickgender"):
		saynn("Pick your character's gender. This will affect the color of your speech and how others treat you.")
		saynn("Current gender: [color="+GM.pc.getChatColor()+"]"+Gender.genderToString(GM.pc.getGender()).capitalize()+"[/color]")

		addButton("Male", "You're a guy", "setgender", [Gender.Male])
		addButton("Female", "You're a girl", "setgender", [Gender.Female])
		addButton("Androgynous", "Somewhere in between", "setgender", [Gender.Androgynous])
		addButton("Other", "Something else", "setgender", [Gender.Other])
		addButton("back", "Keep your current gender", "")

	if(state == "pickpronouns"):
		saynn("Pick your character's pronouns.")
		saynn("Current pronouns: "+GM.pc.heShe()+"/"+GM.pc.hisHer()+(" (derived from gender)" if(GM.pc.pronounsGender == null) else ""))

		addButton("Derive from gender", "Automatically adjust pronouns based on gender", "setpronouns", [null])
		addButton("he/his", "Choose masculine pronouns", "setpronouns", [Gender.Male])
		addButton("she/her", "Choose feminine pronouns", "setpronouns", [Gender.Female])
		addButton("they/their", "Choose androgynous or neutral pronouns", "setpronouns", [Gender.Androgynous])
		addButton("it/its", "Choose neutral pronouns", "setpronouns", [Gender.Other])
		addButton("back", "Keep your current pronouns", "")
	
	if(state == "wait"):
		saynn("Choose how long do you want wait.")
		
		addButton("5 minutes", "Wait this much", "dowait", [5*60])
		addButton("15 minutes", "Wait this much", "dowait", [15*60])
		addButton("30 minutes", "Wait this much", "dowait", [30*60])
		addButton("1 hour", "Wait this much", "dowait", [1*60*60])
		addButton("2 hours", "Wait this much", "dowait", [2*60*60])
		addButton("3 hours", "Wait this much", "dowait", [3*60*60])
		addButton("back", "Don't wait", "")

	if(state == "failedtofindtrouble"):
		saynn("You try to look around for trouble but there is nothing here.")
		
		saynn("Try some other area.")
		
		addButton("Continue", "Oh well", "")
	
	if(state == "reputationMenu"):
		var reputation:Reputation = GM.pc.getReputation()
		
		saynn("Your current prison reputation:")
		for repID in GlobalRegistry.getRepStats():
			var repStat:RepStatBase = GlobalRegistry.getRepStat(repID)
			
			var repLevel:int = reputation.getRepLevel(repID)
			var repScore:float = reputation.getRepScore(repID)
			var nextScore:float = repStat.getNeededScoreForLevel(repLevel+1, repLevel)
			var prevScore:float = -repStat.getNeededScoreForLevel(repLevel-1, repLevel)
			
			var normScore:float = (repScore - prevScore) / (nextScore - prevScore)
			
			sayn("[b]"+repStat.getVisibleName()+"[/b]")
			sayn("Your current level is '"+repStat.getTextForLevel(repLevel, reputation)+"' (level "+str(repLevel)+"/"+(str(repStat.getMaxLevel()) if repLevel >= 0 else str(repStat.getMinLevel()))+")")
			sayn("Progress: [font=res://Fonts/smallconsolefont.tres]"+Util.textProgressBar(normScore, 40)+"[/font]")
			var specialReq = repStat.getSpecialRequirementToReachLevel(repLevel+1, reputation)
			if(specialReq != null && repScore>=nextScore):
				sayn("LEVEL UP REQUIREMENT: "+str(specialReq[1]))
			
			sayn("Current effects:")
			var repEffects:Array = repStat.getEffectsInfoForLevel(repLevel, reputation)
			if(repEffects.size() <= 0):
				sayn("- NONE")
			else:
				for line in repEffects:
					sayn("- "+line)
			
			var maxLevel:int = repStat.getMaxLevel()
			var minLevel:int = repStat.getMinLevel()
			if(repLevel >= maxLevel):
				sayn("(You have reached the highest reputation level possible)")
			if(repLevel <= minLevel):
				sayn("(You have reached the lowest reputation level possible)")
			sayn("")
		
		addButton("Back", "Go back to the previous menu", "")

func onMinigameTest(_score:MinigameResult):
	Log.print("SCORE: "+str(_score.score))
	Log.print("INSTANT UNLOCK: "+str(_score.instantUnlock))
	Log.print("FAILED HARD: "+str(_score.failedHard))
	GM.main.pickOption("", [])

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if(_action == "lookfortrouble"):
		if(GM.ES.triggerReact(Trigger.PCLookingForTrouble)):
			endScene()
		else:
			setState("failedtofindtrouble")
		return
	
	if(_action == "encountersMenu"):
		runScene("EncountersMenuScene", [], "encountersMenu")
		return
	
	if(_action == "setgender"):
		GM.pc.setGender(_args[0])
		setState("")
		return
		
	if(_action == "setpronouns"):
		GM.pc.setPronounGender(_args[0])
		setState("")
		return
	if(_action == "tasks"):
		runScene("QuestLogScene")
		setState("")
		return
	
	if(_action == "domasturbate"):
		runScene("MasturbationScene")
		endScene()
		return
	
	if(_action == "dowait"):
		var newt = _args[0]
		
		GM.main.processTime(newt)
		
		if(GM.ES.triggerReact(Trigger.Waiting, [newt])):
			endScene()
			return
		
		setState("")
		return
	
	if(_action == "pickstartingperks"):
		setFlag("Game_PickedStartingPerks", true)
		runScene("PickStartingPerksScene")
		setState("")
		return
	if(_action == "specialMenu"):
		endScene()
		runScene("SpecialRelationshipsScene")
		return
	
	setState(_action)

func _react_scene_end(_tag, _result):
	if(_tag == "encountersMenu"):
		if(_result is Array && _result.size() > 0 && _result[0]):
			endScene()
		
func supportsShowingPawns() -> bool:
	return true
