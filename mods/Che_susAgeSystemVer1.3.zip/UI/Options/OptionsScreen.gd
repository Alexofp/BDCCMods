extends Control

onready var optionsContainer = $VBoxContainer/ScrollContainer/ScrollVBox/OptionsContainer
var optionsCategoryScene = preload("res://UI/Options/OptionsCategory.tscn")
var optionCategoryUnknown = preload("res://UI/Options/OptionUnknownType.tscn")
var optionCategoryCheckbox = preload("res://UI/Options/OptionCheckboxType.tscn")
var optionCategoryList = preload("res://UI/Options/OptionListType.tscn")
var optionCategoryFloat = preload("res://UI/Options/OptionFloatType.tscn")
var optionCategoryInt = preload("res://UI/Options/OptionIntType.tscn")
var optionCategoryPriorityList = preload("res://UI/Options/OptionPriorityListType.tscn")
var optionCategoryString = preload("res://UI/Options/OptionStringType.tscn")
onready var category_name_label = $"%CategoryNameLabel"


signal onClosePressed



var currentTab = -1

onready var gameplay_cat_button = $"%GameplayCatButton"
onready var game_cat_button = $"%GameCatButton"
onready var display_cat_button = $"%DisplayCatButton"
onready var interface_cat_button = $"%InterfaceCatButton"
onready var age_cat_button = $VBoxContainer/HFlowContainer/AgeCatButton

# The Age System tab is self-contained: it doesn't go through
# OPTIONS.getChangeableOptions()/applyOption(), and stores its settings in
# its own file instead of through OPTIONS' save/load system.
const TAB_AGE = 100
const _PERSIST_DIR = "user://che_sus_age_system"
const _AGE_LIMITS_PATH = _PERSIST_DIR + "/global_age_limits.json"

func _ready():
	setTab(OPTIONS.TAB_GAMEPLAY)


func updateOptions():
	Util.delete_children(optionsContainer)

	if(currentTab == TAB_AGE):
		_buildAgeTabUI()
		return

	var options = OPTIONS.getChangeableOptions()
	
	for category in options:
		var optionsCategory = optionsCategoryScene.instance()
		optionsContainer.add_child(optionsCategory)

		optionsCategory.setCategoryName(category["name"])
		
		var addedAny:bool = false
		for option in category["options"]:
			var optionTab:int = option["tab"] if option.has("tab") else OPTIONS.TAB_GAME
			if(optionTab != currentTab):
				continue
			
			var optionType = option["type"]
			var optionID = option["id"]
			var optionName = option["name"]
			var optionValue = option["value"]
			var optionDescription = null
			if(option.has("description")):
				optionDescription = option["description"]
			
			var optionUIObject: Node = null
			if(optionType == "checkbox"):
				optionUIObject = optionCategoryCheckbox.instance()
			elif(optionType == "list"):
				optionUIObject = optionCategoryList.instance()
			elif(optionType == "float"):
				optionUIObject = optionCategoryFloat.instance()
			elif(optionType == "int"):
				optionUIObject = optionCategoryInt.instance()
			elif(optionType == "prioritylist"):
				optionUIObject = optionCategoryPriorityList.instance()
			elif(optionType == "string"):
				optionUIObject = optionCategoryString.instance()
			else:
				optionUIObject = optionCategoryUnknown.instance()
			
			if(optionUIObject == null):
				continue
			
			addedAny = true
			optionsContainer.add_child(optionUIObject)
			optionUIObject.id = optionID
			optionUIObject.categoryID = category["id"]
			optionUIObject.setOptionName(optionName)
			optionUIObject.setOptionValue(optionValue)
			if(optionUIObject.has_signal("value_changed")):
				var _ok = optionUIObject.connect("value_changed", self, "onOptionChanged")
			
			if(optionType == "string"):
				if("placeholder" in option):
					optionUIObject.setPlaceholderValue(option["placeholder"])
			if(optionType == "list"):
				optionUIObject.setValues(option["values"])
			if(optionType == "prioritylist"):
				if("imagePacks" in option):
					optionUIObject.makeImagepackList()
				
				optionUIObject.setValues(option["values"])
			
			if(optionDescription != null && optionUIObject.has_signal("mouse_entered")):
				var _ok = optionUIObject.connect("mouse_entered", self, "onOptionMouseEntered", [optionUIObject])
				var _ok2 = optionUIObject.connect("mouse_exited", self, "onOptionMouseExited", [optionUIObject])
				if(optionUIObject.has_method("setDescription")):
					optionUIObject.setDescription(optionDescription)
		if(!addedAny):
			optionsCategory.queue_free()

const _ABSOLUTE_MIN_AGE = 18

func _loadAgeLimits() -> Dictionary:
	var minAge := 18
	var maxAge := 80
	var f := File.new()
	if(f.file_exists(_AGE_LIMITS_PATH) && f.open(_AGE_LIMITS_PATH, File.READ) == OK):
		var txt := f.get_as_text()
		f.close()
		var parsed = JSON.parse(txt)
		if(parsed.error == OK && parsed.result is Dictionary):
			var data: Dictionary = parsed.result
			if(data.has("min") && (typeof(data["min"]) == TYPE_INT || typeof(data["min"]) == TYPE_REAL)):
				minAge = int(data["min"])
			if(data.has("max") && (typeof(data["max"]) == TYPE_INT || typeof(data["max"]) == TYPE_REAL)):
				maxAge = int(data["max"])
	minAge = int(clamp(minAge, _ABSOLUTE_MIN_AGE, 200))
	maxAge = int(clamp(maxAge, _ABSOLUTE_MIN_AGE, 200))
	if(maxAge < minAge):
		maxAge = minAge
	return {"min": minAge, "max": maxAge}

func _saveAgeLimits(minAge: int, maxAge: int) -> void:
	minAge = int(clamp(minAge, _ABSOLUTE_MIN_AGE, 200))
	maxAge = int(clamp(maxAge, _ABSOLUTE_MIN_AGE, 200))
	if(maxAge < minAge):
		maxAge = minAge
	var dir := Directory.new()
	if(!dir.dir_exists(_PERSIST_DIR)):
		dir.make_dir_recursive(_PERSIST_DIR)
	var f := File.new()
	if(f.open(_AGE_LIMITS_PATH, File.WRITE) != OK):
		return
	f.store_string(JSON.print({"min": minAge, "max": maxAge}))
	f.close()

func _buildAgeTabUI():
	var limits = _loadAgeLimits()

	var infoLabel := Label.new()
	infoLabel.text = "Controls the range of ages the game can randomly assign to a character (player or NPC). Applies to new assignments only - characters that already have an age keep it. Minimum age cannot be set below 18."
	infoLabel.autowrap = true
	optionsContainer.add_child(infoLabel)

	var minRow := HBoxContainer.new()
	optionsContainer.add_child(minRow)
	var minLabel := Label.new()
	minLabel.text = "Minimum age"
	minLabel.size_flags_horizontal = SIZE_EXPAND_FILL
	minRow.add_child(minLabel)
	var minSpin := SpinBox.new()
	minSpin.min_value = _ABSOLUTE_MIN_AGE
	minSpin.max_value = 200
	minSpin.step = 1
	minSpin.rounded = true
	minSpin.rect_min_size = Vector2(150, 0)
	minSpin.value = limits["min"]
	minRow.add_child(minSpin)

	var maxRow := HBoxContainer.new()
	optionsContainer.add_child(maxRow)
	var maxLabel := Label.new()
	maxLabel.text = "Maximum age"
	maxLabel.size_flags_horizontal = SIZE_EXPAND_FILL
	maxRow.add_child(maxLabel)
	var maxSpin := SpinBox.new()
	maxSpin.min_value = _ABSOLUTE_MIN_AGE
	maxSpin.max_value = 200
	maxSpin.step = 1
	maxSpin.rounded = true
	maxSpin.rect_min_size = Vector2(150, 0)
	maxSpin.value = limits["max"]
	maxRow.add_child(maxSpin)

	var _ok1 = minSpin.connect("value_changed", self, "_onAgeMinChanged", [minSpin, maxSpin])
	var _ok2 = maxSpin.connect("value_changed", self, "_onAgeMaxChanged", [minSpin, maxSpin])

func _onAgeMinChanged(newValue, _minSpin: SpinBox, maxSpin: SpinBox):
	var minAge := int(round(newValue))
	minAge = int(clamp(minAge, _ABSOLUTE_MIN_AGE, 200))
	var maxAge := int(round(maxSpin.value))
	if(minAge > maxAge):
		maxAge = minAge
		maxSpin.value = maxAge
	_saveAgeLimits(minAge, maxAge)

func _onAgeMaxChanged(newValue, minSpin: SpinBox, _maxSpin: SpinBox):
	var maxAge := int(round(newValue))
	maxAge = int(clamp(maxAge, _ABSOLUTE_MIN_AGE, 200))
	var minAge := int(round(minSpin.value))
	if(maxAge < minAge):
		minAge = maxAge
		minSpin.value = minAge
	_saveAgeLimits(minAge, maxAge)

func onOptionMouseEntered(optionUIObject):
	if(optionUIObject.has_method("getDescription")):
		var optionName = "Option"
		if(optionUIObject.has_method("getOptionName")):
			optionName = optionUIObject.getOptionName()
		GlobalTooltip.showTooltip(optionUIObject, optionName, optionUIObject.getDescription(), false, true)
			
func onOptionMouseExited(_optionUIObject):
	GlobalTooltip.hideTooltip(_optionUIObject)
				
func onOptionChanged(categoryID, optionID, optionNewValue):
	OPTIONS.applyOption(categoryID, optionID, optionNewValue)


func _on_RevertButton_pressed():
	if(currentTab == TAB_AGE):
		_saveAgeLimits(18, 80)
		updateOptions()
		return
	OPTIONS.resetToDefaults()
	updateOptions()


func _on_CloseButton_pressed():
	OPTIONS.saveToFile()
	emit_signal("onClosePressed")


func _on_ResetRenderButton_pressed():
	OPTIONS.resetRenderSettings()

func _getTabLabelText(_tab: int) -> String:
	if(_tab == TAB_AGE):
		return "Age options"
	if(_tab == OPTIONS.TAB_GAMEPLAY):
		return "Gameplay options"
	if(_tab == OPTIONS.TAB_GAME):
		return "Game options"
	if(_tab == OPTIONS.TAB_DISPLAY):
		return "Display options"
	if(_tab == OPTIONS.TAB_INTERFACE):
		return "Interface options"
	return "Unknown options"

func setTab(_tab:int):
	currentTab = _tab
	if(gameplay_cat_button != null):
		gameplay_cat_button.disabled = (_tab == OPTIONS.TAB_GAMEPLAY)
	if(game_cat_button != null):
		game_cat_button.disabled = (_tab == OPTIONS.TAB_GAME)
	if(display_cat_button != null):
		display_cat_button.disabled = (_tab == OPTIONS.TAB_DISPLAY)
	if(interface_cat_button != null):
		interface_cat_button.disabled = (_tab == OPTIONS.TAB_INTERFACE)
	if(age_cat_button != null):
		age_cat_button.disabled = (_tab == TAB_AGE)
	
	category_name_label.text = _getTabLabelText(currentTab)
	
	updateOptions()

func _on_GameplayCatButton_pressed():
	setTab(OPTIONS.TAB_GAMEPLAY)

func _on_GameCatButton_pressed():
	setTab(OPTIONS.TAB_GAME)

func _on_DisplayCatButton_pressed():
	setTab(OPTIONS.TAB_DISPLAY)

func _on_InterfaceCatButton_pressed():
	setTab(OPTIONS.TAB_INTERFACE)

func _on_AgeCatButton_pressed():
	setTab(TAB_AGE)
