extends "res://Modules/SongsVanillaPartsModule/Script/Universal/SuniBreasts2.gd"

func getCompatibleSpecies():
	return []

func npcGenerationWeight(_dynamicCharacter):
	return 0.0
