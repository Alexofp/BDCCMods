extends BodypartBreasts

func _init():
	visibleName = "Nipple breasts"
	id = "breastsnipple"
	size = BreastsSize.C

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNipples/BreastNippleFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNipples/BreastNipple.tscn"

func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
