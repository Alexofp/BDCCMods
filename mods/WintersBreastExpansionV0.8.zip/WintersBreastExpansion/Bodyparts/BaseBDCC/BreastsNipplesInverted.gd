extends BodypartBreasts

func _init():
	visibleName = "Inverted nipple breasts"
	id = "breastsnippleinv"
	size = BreastsSize.C

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNippleInverted/BreastNippleInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNippleInverted/BreastNippleInverted.tscn"

func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
