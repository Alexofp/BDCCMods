extends BodypartBreasts

func _init():
	visibleName = "Fluffy inverted puffy breasts"
	id = "fluffbreastspuffyinv"
	size = BreastsSize.C

func getCompatibleSpecies():
	return [Species.Any]

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted/FluffyBreastsPuffyInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted/FluffyBreastsPuffyInverted.tscn"

func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
