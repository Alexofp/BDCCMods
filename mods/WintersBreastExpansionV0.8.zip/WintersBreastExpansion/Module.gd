extends Module

var FluffyBodypartsLoad = ResourceLoader.exists("res://Modules/WintersFluffyBodyparts/Module.gd")
var HellBeastsLoad = ResourceLoader.exists("res://Modules/WintersFluffyBodyparts/Module.gd")
var SongPartsLoad = ResourceLoader.exists("res://Modules/SongsVanillaPartsModule/Module.gd")

func _init():
	id = "WintersBreastExpansion"
	author = "Avery Winters"

	species = [
		"res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/HumanBreasts.gd"
	]

	bodyparts = [
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastsNipples.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastsNipplesInverted.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastsPuffy.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastsPuffyInverted.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/MaleBreastsNipples.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/MaleBreastsNipplesInverted.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/MaleBreastsPuffy.gd",
		"res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/MaleBreastsPuffyInverted.gd",
	]

	if (FluffyBodypartsLoad == true):
		#Fluffy Male and Female Breasts
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsNipples.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsNipplesInverted.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffy.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/MaleFluffyBreastsNipples.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/MaleFluffyBreastsNipplesInverted.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/MaleFluffyBreastsPuffy.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/FluffyBodyparts/MaleFluffyBreastsPuffyInverted.gd")
		#Scaled Male and Female Breasts
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastsNipples.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastsNipplesInverted.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastsPuffy.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastsPuffyInverted.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/MaleScaledBreastsNipples.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/MaleScaledBreastsNipplesInverted.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/MaleScaledBreastsPuffy.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/MaleScaledBreastsPuffyInverted.gd")

	if (SongPartsLoad == true):
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/CompatabilityPatches/SongsVanillaParts/SuniBreasts1Tweaks.gd")
		GlobalRegistry.registerBodypart("res://Modules/WintersBreastExpansion/CompatabilityPatches/SongsVanillaParts/SuniBreasts2Tweaks.gd")

	if (FluffyBodypartsLoad == false):
		#Adds species generation for the new breasts, but only if fluffy is not installed as it should add its own breast generation
		GlobalRegistry.registerSpecies("res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/CanineBreasts.gd")
		GlobalRegistry.registerSpecies("res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/DragonBreasts.gd")
		GlobalRegistry.registerSpecies("res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/EquineBreasts.gd")
		GlobalRegistry.registerSpecies("res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/FelineBreasts.gd")

	if (HellBeastsLoad == false):
		GlobalRegistry.registerSpecies("res://Modules/WintersBreastExpansion/CompatabilityPatches/BDCC/DemonBreasts.gd")
