extends DialogueFiller

func getFormIDs() -> Array:
	return [
		"PunishDecideUrinal",
		"PunishLockingInUrinal",
		"PissingOn",
		"GettingPissedOn"
		]
		
func getText(_id:String, _args:Dictionary):
	if(_id == "PunishDecideUrinal"):
		return [
			"How about I lock you in the urinals?",
			"I think you could do as a meat toilet...",
			"A slut like you belongs in the bathroom.",
			"I think the urinals are fitting for you.",
			"You're going in the urinals",
			"Let's see how you serve as a meat toilet.",
		]
	if(_id == "PunishLockingInUrinal"):
		return [
			"Enjoy your time as a toilet, slut.",
			"Have a nice time.",
			"Enjoy being a toilet.",
			"Now you get to be the urinal.",
			"Have fun being a urinal",
		]
	if(_id == "PissingOn"):
		return [
			"Drink up, bitch.",
			"Enjoy the shower.",
			"Open wide.",
			"Have fun washing this out.",
			"Sorry, I gotta go...",
			"Be a good toilet and take it.",
		]
	if(_id == "GettingPissedOn"):
		return [
			"[[C_UGH]]!",
			"Yuck.",
			"[[C_UGH]]... Why?!",
			"Eww, thanks a lot.",
			"Disgusting...",
			"Eugh, gross.",
		]
