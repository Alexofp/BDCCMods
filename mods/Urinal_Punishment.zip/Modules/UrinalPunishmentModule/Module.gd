extends Module

func _init():
	id = "UrinalPunishment"
	author = "driftcatch"

	GlobalRegistry.registerInteraction("res://Modules/UrinalPunishmentModule/InUrinal.gd")	
	var theBank = load("res://Modules/UrinalPunishmentModule/Urinal.gd").new()
	ModularDialogue.registerFormBank(theBank)
	var theFiller = load("res://Modules/UrinalPunishmentModule/UrinalResponsesDefault.gd").new()
	ModularDialogue.registerFiller(theFiller)
