extends DialogueFormBank

func getForms() -> Dictionary:
	return {
		"PunishDecideUrinal": form("I'm locking you in the urinals.", {punisher=CHAR, target=CHAR}, "punisher", "target"),
		"PunishLockingInUrinal": form("Enjoy, piss whore.", {punisher=CHAR, target=CHAR}, "punisher", "target"),
		"PissingOn": form("Drink up, piss whore.", {punisher=CHAR, target=CHAR}, "punisher", "target"),
		"GettingPissedOn": form("Yuck.. Gross.", {punisher=CHAR, target=CHAR}, "punisher", "target"),
		}
