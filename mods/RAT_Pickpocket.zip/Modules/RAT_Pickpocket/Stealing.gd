extends Reference

var npcEntries : Array = []
var todaysEntries : Array = []

var timesStolen : int = 0
var stealingLessonStage : int = 1
var stealAgainTime : int = -1

var wealths : Dictionary = {
	"poor": WealthClass.new()\
		.setCreditCap(5)\
		.setStartingRolls(1)\
		.setScaling(0.125)\
		.setText("{vic.HeShe} {vic.verb('look')} like {vic.theyre} struggling."),
	
	"med": WealthClass.new()\
		.setCreditCap(15)\
		.setStartingRolls(1)\
		.setScaling(0.25)\
		.setText("{vic.HeShe} {vic.verb('look')} pretty well-off."),
	
	"rich": WealthClass.new()\
		.setCreditCap(25)\
		.setStartingRolls(2)\
		.setScaling(0.5)\
		.setText("{vic.Their} pockets look loaded."),
}

class WealthClass:
	var creditCap : int = 5
	var startingRolls : int = 1
	var scalingMultiplier : float = 1.0
	var text : String = ""
	
	func setCreditCap(amount:int) -> WealthClass:
		self.creditCap = amount
		return self
	
	func setText(t:String) -> WealthClass:
		self.text = t
		return self
	
	func setScaling(f:float) -> WealthClass:
		self.scalingMultiplier = f
		return self
	
	func setStartingRolls(i:int) -> WealthClass:
		self.startingRolls = i
		return self
	

var wealthSizeIndividual : int = 3

const MaxDaysBeforeDeleteData : int = 4

func getWealthsSize() -> int: # total size (idx is this - 1)
	return wealthSizeIndividual*wealths.size()

func sort_npcs(a, b) -> bool:
	if a is NpcStealingEntry:
		a = a.npcID
	if b is NpcStealingEntry:
		b = b.npcID
	
	return a < b


class NpcStealingEntry:
	var npcID : String
	var wealth : int = -1
	var stolenToday : bool
	var daysSinceStolen : int
#	var stealAgainTime : int
	
	func saveData() -> Dictionary:
		return {
			"id": npcID,
			"wealth": wealth,
			"stolenToday": stolenToday,
			"daysStolen": daysSinceStolen,
#			"stealAgainTime": stealAgainTime,
		}
	
	func loadData(data:Dictionary) -> void:
		npcID = SAVE.loadVar(data, "id", "")
		wealth = int(SAVE.loadVar(data, "wealth", 0))
		stolenToday = bool(SAVE.loadVar(data, "stolenToday", false))
#		stealAgainTime = int(SAVE.loadVar(data, "stealAgainTime", 0))
		if !npcID:
			daysSinceStolen = 1000
		else:
			daysSinceStolen = int(SAVE.loadVar(data, "daysStolen", 1000))
		
	
	

func onNewDay() -> void: # process stealing when a day passes
	var npcData = [] # new entries as objects
	
	todaysEntries.clear()
	stealAgainTime = -1
	
	var entries : Array = getAllNpcEntries()
	
	for npcEntry in entries:
		if npcEntry.stolenToday: # stolen from
			npcEntry.daysSinceStolen = 0 # reset countdown
		else: # not stolen from
			npcEntry.daysSinceStolen += 1
			if npcEntry.daysSinceStolen > MaxDaysBeforeDeleteData: # too long since last time
				continue # don't even add entry
		
		
		
		if npcEntry.wealth == -1: # randomize wealth if needed
			npcEntry.wealth = RNG.randi_range(0, getWealthsSize()-1)
		
		
		if npcEntry.wealth >= 11: # very rich
			npcEntry.wealth += 1 - (2*int(RNG.chance(75))) # -1 75% of the time
		elif npcEntry.wealth<=2: # very poor
			npcEntry.wealth -= 1 - (2*int(RNG.chance(75))) # +1 75% of the time
		else: # don't care tbh, middle ground-ish
			npcEntry.wealth += 1 - (2*int(RNG.chance(50))) # +1 50% of the time
		
		npcEntry.wealth = int(clamp(npcEntry.wealth, 0, getWealthsSize()-1))
		
		npcData.append(npcEntry) # create entry as object
	
	npcData.sort_custom(self, "sort_npcs")
	
	npcEntries = npcData

func getTodaysEntries() -> Array:
	return todaysEntries

func getAllNpcEntries() -> Array:
	return npcEntries

func addEntryDirect(entry:NpcStealingEntry, dar:Array=getAllNpcEntries(), checkToday:bool=true):
	var idx = getNewIdxNpc(entry, dar)
	if idx<dar.size() && dar[idx].npcID == entry.npcID:
		dar[idx] = entry
		return
	
	dar.insert(idx, entry)
	
	if checkToday && entry.stolenToday:
		addEntryDirect(entry, getTodaysEntries(), false)
	

func addNpcStealingData(charid:String, stolenFrom:bool=false, wealth:int=-1, countdown:int=0) -> void: # replaces if already exists
	var entry : NpcStealingEntry = getEntryWithID(charid)
	if !entry:
		entry = NpcStealingEntry.new()
		entry.npcID = charid
	
	entry.stolenToday = stolenFrom
	entry.wealth = wealth
	entry.daysSinceStolen = countdown
	
	addEntryDirect(entry)

func increaseStolenTimes(amount:int=1) -> void:
	timesStolen += amount

func getEntryWithID(id:String) -> NpcStealingEntry:
	var dar = getAllNpcEntries()
	var idx = getEntryIdxID(id, dar)
	
	return null if idx==-1 else dar[idx]

func getEntryIdxID(id:String, dar:Array=getAllNpcEntries()) -> int:
	var idx = getNewIdxNpc(id, dar)
	if dar.size()<=idx:
		return -1
	
	return idx if dar[idx].npcID == id else -1

func getNewIdxNpc(entry, ar:Array) -> int:
	return ar.bsearch_custom(entry, self, "sort_npcs")

func getNpcStealingData(charid:String) -> NpcStealingEntry:
	return getEntryWithID(charid)

func generateWealth(pawn:String) -> int:
	var wealth : int = hash(pawn+str(GM.main.currentDay)) % getWealthsSize()
	
	return wealth

func applyWealthBuff(buff:int, npc:String) -> void:
	var entry : NpcStealingEntry = getEntryWithID(npc)
	if entry:
		entry.wealth = int( clamp(entry.wealth + buff, 0, getWealthsSize() - 1) )
		return
	
	entry = NpcStealingEntry.new()
	
	var wealth : int = generateWealth(npc)
	wealth = int( clamp(wealth+buff, 0, getWealthsSize()-1) )
	
	entry.wealth = wealth
	entry.stolenToday = false
	entry.daysSinceStolen = 0
	addEntryDirect(entry)

func getTimesStolen() -> int:
	return timesStolen

func getWealthType(pawnWealth:int) -> String:
	return wealths.keys()[pawnWealth / getWealthsSize()]

func getWealth(type:String) -> WealthClass:
	return wealths.get(type, null)

func saveData() -> Dictionary:
	var d : Dictionary = {
			"npcs":[],
			"timesStolen": getTimesStolen(),
#			"stealingLessonStage": stealingLessonStage,
			"stealAgainTime": stealAgainTime
		}
	
	for entry in getAllNpcEntries():
		d["npcs"].append(entry.saveData())
	
	return d

func loadData(d:Dictionary) -> void:
	npcEntries.clear()
	
	timesStolen = int(SAVE.loadVar(d, "timesStolen", 0))
#	stealingLessonStage = int(SAVE.loadVar(d, "stealingLessonStage", 0))
	stealAgainTime = int(SAVE.loadVar(d, "stealAgainTime", -1))
	
	for npcEntry in SAVE.loadVar(d, "npcs", []):
		var e := NpcStealingEntry.new()
		e.loadData(npcEntry)
		npcEntries.append(e)
	
	npcEntries.sort_custom(self, "sort_npcs")
	

func addStealingExp(amount:int, character:BaseCharacter=GM.pc, activity=null) -> String: # returns message
	if character:
		var finalv : int = int(amount*getExpMultFor(character))
		character.addSkillExperience("RAT_PickpocketSkill", finalv, activity)
		return "You received %s %s experience" % [ finalv, GlobalRegistry.createSkill("RAT_PickpocketSkill").getVisibleName() ]
	
	return ""

func getStealingNpcsCap(character:BaseCharacter=GM.pc) -> int:
	if character==GM.pc:
#		if stealingLessonStage<=0:
#			return int(GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Theft)
		
		return 5 # TODO: change
	
	return 0

func getExpMultFor(character:BaseCharacter) -> float:
	if character == GM.pc:
		if stealingLessonStage>0:
			return 1.0
		
		if GM.main.getFlag("Player_Crime_Type") == Flag.Crime_Type.Theft:
			return 0.1
		
		return 0.0
		
	return 0.5

func willFight(character) -> bool: # TODO: account for affection/lust
	var p : Personality = character.getPersonality()
	var s : float = p.personalityScore({
		PersonalityStat.Coward:-1.0, # brave mult 1.0
		PersonalityStat.Mean:0.5, # mean mult 0.5
		PersonalityStat.Subby:-0.75, # dom mult 0.75
		PersonalityStat.Impatient:0.2, # impatient mult 0.2
		PersonalityStat.Brat:0.1, # brat mult 0.1
	}) # extremes: +-2.55
	
#	print("val: %s" % s)
	return s >= RNG.randf_range(0.4, 0.55) # they're brave enough to fight

func shouldFuck(characterID) -> bool:
	var threshold : float = 0.65 * (1.0 - GM.main.getCharacter(characterID).getLustLevel()*0.5) # up to 50% less lust needed
	
	return GM.main.RS.getLust("pc", characterID) >= threshold
