extends SceneBase

var pawn : String = ""
var scn = -1

var pawnEntry = null
var stealing

func resolveCustomCharacterName(_charID):
	if _charID=="vic":
		return pawn
	return null

func _initScene(_args = []):
	if(_args.size() < 2):
		endScene()
		return
	
	pawn = _args[0]
	scn = _args[1]
	

func _init():
	sceneID = "RAT_PickpocketScene"
	
	if GM.main:
		stealing = GlobalRegistry.getModule("RAT_Pickpocket").Stealing

func _run():
	pawnEntry = stealing.getEntryWithID(pawn)
	if !pawnEntry:
		pawnEntry = stealing.NpcStealingEntry.new()
		pawnEntry.npcID = pawn
		pawnEntry.wealth = stealing.generateWealth(pawn)
	
	if(state in ["go",""]):
		var type = stealing.getWealth(stealing.getWealthType(pawnEntry.wealth))
		
		saynn(type.text)
		saynn("Do you want to try pickpocketing {vic.him}?")
		
		addButton("Steal", "Go through their pockets.", "doStole")
		addButton("No", "Leave them alone. ","endthescene")
		
		return
	elif state == "doStole":
		var game : Control = load("res://Modules/RAT_Pickpocket/Minigames/Stealing/stealingMinigame.tscn").instance()
		GM.ui.addFullScreenCustomControl("minigame",game)
		game.connect("finished", self, "minigameFinished")
		
	elif state == "caught_nofight":
		saynn("{vic.Name} caught you trying to pickpocket {vic.him}!")
		saynn("{vic.She} {vic.verb('choose')} not to fight you...")
		
		addButton("Fight", "", "endthescene")
	
	elif state == "caught_fight":
		saynn("{vic.Name} caught you trying to pickpocket {vic.him}!")
		saynn("{vic.Theyre} getting ready to fight!")
		
		addButton("Fight", "", "fight")
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if _action=="fight":
		endScene()
		GM.main.getSceneByUniqueID(scn).endScene()
		runScene("FightScene", [pawn])
		GM.main.reRun()
		return
	
	if _action=="stoleResult":
		var res = _args[0]
		var pawnc = getCharacter(pawn)
		if res.failedHard:
#			decreaseRepFor(pawnc)
			setState("caught_fight" if stealing.willFight(pawnc) else "caught_nofight")
			return
		
		stealing.increaseStolenTimes(1)
		
		var initExp = res.score
		
		
		res.score *= getMult(pawnc)
		
		var loott = pawnc.getLootTable(null)
		
		var floot = {
			"items":[],
			"credits":int(  (res.score + RNG.randi_range(-5,5))  * 0.1), # every 10% score = 1 credit
		}
		
		var wtype = stealing.getWealth(stealing.getWealthType(pawnEntry.wealth))
		
		var reps : int = wtype.startingRolls
		var scalingMult : float = wtype.scalingMultiplier
		var extra : float = res.score*scalingMult
		reps += (int(extra) / 100) + int(RNG.chance(int(extra) % 100))
		
		
		for i in int(max(1, reps)): # min 1 roll
			var l = loott.generateAndCreateItems(pawn)
			var nitem = RNG.pick(l["items"])
			if nitem:
				floot["items"].append(  nitem  )
		
		floot["credits"] = int(min(floot["credits"], wtype.creditCap))
		if floot["credits"]>0 or floot["items"].size()>0: # has loot
			GM.main.runScene("LootingScene", [floot])
		else: # no loot
			addMessage("They had nothing on them")
		
#		var sexp = 50
#		if GM.pc.hasPerk("RAT_Pickpocket_MasterPickpocket"):
#			sexp = 150
#		elif GM.pc.hasPerk("RAT_Pickpocket_AdeptPickpocket"):
#			sexp = 120
#		elif GM.pc.hasPerk("RAT_Pickpocket_Pickpocket"):
#			sexp = 90
		
		addEXP(initExp)
		
		endScene()
		return
	
	elif _action == "doStole":
		pawnEntry.stolenToday = true
		pawnEntry.wealth = int(max(0, pawnEntry.wealth - 1))
		
		pawnEntry.daysSinceStolen = 0
		pawnEntry.stealAgainTime = GM.main.timeOfDay + 60*60*2 # 2 hours
		stealing.addEntryDirect(pawnEntry)
		
	
	setState(_action)

func addEXP(xp:int) -> void:
	addMessage(stealing.addStealingExp(xp, GM.pc))

func minigameFinished(result:MinigameResult):
	GM.main.pickOption("stoleResult", [result])

func saveData():
	var d = .saveData()
	d["pawn"] = pawn
	d["scn"] = scn
	return d

func loadData(d):
	.loadData(d)
	pawn = SAVE.loadVar(d, "pawn")
	scn = SAVE.loadVar(d, "scn")

func scaledConditions(dict:Array): # [condition, value], last one is value
	if !dict:
		return null
	var lastVal = dict.pop_back()
	for ar in dict:
		if ar[0]:
			return ar[1]
	
	return lastVal
	

func getMult(pawnc) -> float:
	var type = pawnc.getCharType()
	if type == CharacterType.Nurse:
		return scaledConditions([
			[GM.pc.hasPerk("RAT_Pickpocket_NurseMaster"), 1.0],
			[GM.pc.hasPerk("RAT_Pickpocket_NurseAdept"), 0.75],
			[GM.pc.hasPerk("RAT_Pickpocket_AdeptPickpocket"), 0.5],
			
			0.0
		])
	elif type == CharacterType.Engineer:
		return scaledConditions([
			[GM.pc.hasPerk("RAT_Pickpocket_EngineerMaster"), 1.0],
			[GM.pc.hasPerk("RAT_Pickpocket_EngineerAdept"), 0.75],
			[GM.pc.hasPerk("RAT_Pickpocket_AdeptPickpocket"), 0.5],
			
			0.0
		])
	
	elif type == CharacterType.Guard:
		return scaledConditions([
			[GM.pc.hasPerk("RAT_Pickpocket_GuardMaster"), 1.0],
			[GM.pc.hasPerk("RAT_Pickpocket_GuardAdept"), 0.75],
			[GM.pc.hasPerk("RAT_Pickpocket_MasterPickpocket"), 0.5],
			
			0.0
		])
	
	
	return 1.0
