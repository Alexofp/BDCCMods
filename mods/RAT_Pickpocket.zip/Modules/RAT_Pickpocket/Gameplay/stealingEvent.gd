extends EventBase

enum denialReasons {
	NONE, # can steal
	TOO_SOON, # stolen from today
	NEED_ADEPT, # eng/nurse too hard
	NEED_MASTER, # guard too hard
	COOLDOWN, # wait more days
	TOO_MANY, # reached cap
	INEXPERIENCED, # cap is 0
	TOTAL_SIZE,
}

func _init():
	id = "RAT_PickpocketEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["SpyOnPawnScene", ""])


func canSteal(charId:String) -> int: # returns reason they can't steal, 0 is can do
	var stealing = getModule("RAT_Pickpocket").Stealing
	
	var cap : int = stealing.getStealingNpcsCap(GM.pc)
	
	if cap <= 0:
		return denialReasons.INEXPERIENCED
	elif stealing.getTodaysEntries().size()>=cap:
		return denialReasons.TOO_MANY
	
	if stealing.stealAgainTime > 0 && stealing.stealAgainTime > GM.main.timeOfDay:
		return denialReasons.COOLDOWN
	
	var ctype = getCharacter(charId).getCharacterType()
	
	if ctype in [CharacterType.Guard] && !GM.pc.hasPerk("RAT_Pickpocket_MasterPickpocket"):
		return denialReasons.NEED_MASTER
	
	if ctype in [CharacterType.Engineer, CharacterType.Nurse] && !GM.pc.hasPerk("RAT_Pickpocket_AdeptPickpocket"):
		return denialReasons.NEED_ADEPT
	
	var npcEntry = stealing.getEntryWithID(charId)
	
	if !npcEntry:
		return denialReasons.NONE
	
	if npcEntry.stolenToday: # stolen from today?
		return denialReasons.TOO_SOON # stop stealing from this person omg
	
	return denialReasons.NONE

func run(_id,_args):
	var cs = GM.main.getCurrentScene()
	
	if !cs.pawnID:
		return
	
	if(cs.state in ["go", ""]):
#		var lucky = RNG.chance(10)
		
		saynn("You're following {%s.name}. You can try to steal from {%s.him}. ".replace("%s", cs.pawnID))
		
		var can : int = canSteal(cs.pawnID)
		
		if can==denialReasons.NONE:
			addButton("Pickpocket", "Steal from them", "steal")
			return
		
		
		var reasons : Array = []
		reasons.resize(denialReasons.TOTAL_SIZE)
		
		reasons[denialReasons.TOO_SOON] = "It's best not to test your luck with them again"
		reasons[denialReasons.NEED_ADEPT] = "This person seems a bit too perceptive for you to get away with stealing"
		reasons[denialReasons.NEED_MASTER] = "You don't want to risk stealing from a guard with your current skills"
		reasons[denialReasons.COOLDOWN] = "You think you should lay low for a while longer (%s left)" % Util.getTimeStringHumanReadable(getModule("RAT_Pickpocket").Stealing.stealAgainTime - GM.main.getTime())
		reasons[denialReasons.TOO_MANY] = "You've stolen from too many people today"
		reasons[denialReasons.INEXPERIENCED] = "You don't know the first thing about pickpocketing..."
		
		
		addDisabledButton("Pickpocket",  reasons[can] if can<denialReasons.TOTAL_SIZE else "You can't steal from them right now" )
	

func onButton(_method, _args):
	var cs = GM.main.getCurrentScene()
	if _method=="steal":
		runScene("RAT_PickpocketScene", [cs.pawnID, cs.uniqueSceneID])
