extends GameExtender

func _init():
	id = "RAT_PickpocketSAVE"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.saveLoadData)


func saveData():
	var mod : Module = GlobalRegistry.getModule("RAT_Pickpocket")
	
	return mod.Stealing.saveData()

func loadData(_d):
	var mod : Module = GlobalRegistry.getModule("RAT_Pickpocket")
	if _d==null:
		mod.Stealing.loadData({})
		return
	
	mod.Stealing.loadData(_d)
	
	GM.main.reRun()
