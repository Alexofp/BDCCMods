extends PerkBase

func getDungeonWeight() -> float:
	return 0.0

func canAppearInDungeons() -> bool:
	return false
