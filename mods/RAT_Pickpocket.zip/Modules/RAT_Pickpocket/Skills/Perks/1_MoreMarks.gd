extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_MoreMarks"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "More Marks"

func getVisibleDescription():
	return "You are getting used to having your hands in someone elses pants for a change. You get one extra life when stealing."

func getMoreDescription():
	return ""

func getSkillTier():
	return 0
