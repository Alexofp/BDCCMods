extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_NurseMaster"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Nurse Master"

func getVisibleDescription():
	return "Your time watching nurses has taught you where the best loot is, your hands are as comfortable in their pockets as your own. You now pickpocket nurses at a normal rate."

func getMoreDescription():
	return ""

func getSkillTier():
	return 4

func getRequiredPerks():
	return ["RAT_Pickpocket_NurseAdept"]
