extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_SoftPresence"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Soft Presence"

func getVisibleDescription():
	return "Your have gotten very comfortable not drawing attention leaving you more time to work. Increases pickpocket time to from 8 to 10 seconds."

func getMoreDescription():
	return ""

func getSkillTier():
	return 1

func getRequiredPerks():
	return ["RAT_Pickpocket_LowPresence"]
