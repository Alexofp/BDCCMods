extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_EngineerMaster"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Engineer Master"

func getVisibleDescription():
	return "Your time watching engineers has taught you where the best loot is, your hands are as comfortable in their pockets as your own. You now pickpocket engineers at a normal rate."

func getMoreDescription():
	return ""

func getSkillTier():
	return 4

func getRequiredPerks():
	return ["RAT_Pickpocket_EngineerAdept"]
