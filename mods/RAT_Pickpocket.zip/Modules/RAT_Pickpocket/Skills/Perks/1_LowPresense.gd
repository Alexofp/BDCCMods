extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_LowPresence"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Low Presence"

func getVisibleDescription():
	return "You are getting more used to not drawing attention to yourself. Increases pickpocket time to from 6 to 8 seconds."

func getMoreDescription():
	return ""

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/speedometer.png"
