extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_NurseAdept"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Nurse Adept"

func getVisibleDescription():
	return "Your time watching nurses has made you more comfortable sticking your hands in their pockets. You now pickpocket nurses at 25% reduced rate."

func getMoreDescription():
	return ""

func getSkillTier():
	return 3

func getRequiredPerks():
	return ["RAT_Pickpocket_MasterPickpocket"]
