extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_Fingersmith"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Fingersmith"

func getVisibleDescription():
	return "You have long since learned the where the pockets are in every uniform. reduces the number of arrows required per set by 1."

func getMoreDescription():
	return ""

func getSkillTier():
	return 2
