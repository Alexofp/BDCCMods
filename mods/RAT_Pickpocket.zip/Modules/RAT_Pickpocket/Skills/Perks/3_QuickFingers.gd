extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_QuickFingers"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Quick Fingers"

func getVisibleDescription():
	return "You have learned how to keep a mark distracted for longer. Finishing a set increased the time limit by 1 second."

func getMoreDescription():
	return ""

func getSkillTier():
	return 2

func getPicture():
	return "res://Images/Perks/distraction.png"
