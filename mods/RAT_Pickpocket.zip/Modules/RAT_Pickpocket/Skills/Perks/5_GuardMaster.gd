extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_GuardMaster"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Guard Master"

func getVisibleDescription():
	return "Your time watching guards has taught you where the best loot is, your hands are as comfortable in their pockets as your own. You now pickpocket guards at a normal rate."

func getMoreDescription():
	return ""

func getSkillTier():
	return 4

func getRequiredPerks():
	return ["RAT_Pickpocket_GuardAdept"]
