extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_MasterPickpocket"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Master Pickpocket"

func getVisibleDescription():
	return "Your eye for valuables is unmatched, you are able to find more loot while pickpocketing."

func getMoreDescription():
	return "Boosts loot score to 150% and increases the per set bonus to 20%. Also allows pickpocketing guards at 50% reduced rate."

func getSkillTier():
	return 2

func getRequiredPerks():
	return ["RAT_Pickpocket_AdeptPickpocket"]
