extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_AdeptPickpocket"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Adept Pickpocket"

func getVisibleDescription():
	return "Your eye for valuables is getting sharper, you are able to find more loot while pickpocketing."

func getMoreDescription():
	return "Boosts loot score to 120% and increases the per set bonus to 15%. Also allows pickpocketing nurses and engineers at 50% reduced rate."

func getSkillTier():
	return 1

func getRequiredPerks():
	return ["RAT_Pickpocket_Pickpocket"]
