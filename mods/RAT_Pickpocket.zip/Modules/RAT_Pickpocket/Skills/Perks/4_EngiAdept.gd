extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_EngineerAdept"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Engineer Adept"

func getVisibleDescription():
	return "Your time watching engineers has made you more comfortable sticking your hands in their pockets. You now pickpocket engineers at 25% reduced rate."

func getMoreDescription():
	return ""

func getSkillTier():
	return 3

func getRequiredPerks():
	return ["RAT_Pickpocket_MasterPickpocket"]
