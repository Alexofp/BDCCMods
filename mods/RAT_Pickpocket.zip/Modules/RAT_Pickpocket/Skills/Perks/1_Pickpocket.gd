extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_Pickpocket"
	skillGroup = "RAT_PickpocketSkill"
	dungeonWeight = 0.0

func getVisibleName():
	return "Pickpocket"

func getVisibleDescription():
	return "You are developing an eye for valuables, you are able to find more loot while pickpocketing."

func getMoreDescription():
	return "Boosts loot score to 90% and increases the per set bonus to 10%."

func getSkillTier():
	return 0
