extends "res://Modules/RAT_Pickpocket/Skills/perkTemplate.gd"

func _init():
	id = "RAT_Pickpocket_Shade"
	skillGroup = "RAT_PickpocketSkill"

func getVisibleName():
	return "Shade"

func getVisibleDescription():
	return "Your hands are almost as comfortable in the pockets of someone else as they are in yours. You get one extra life when stealing."

func getMoreDescription():
	return ""

func getSkillTier():
	return 1

func getRequiredPerks():
	return ["RAT_Pickpocket_MoreMarks"]
