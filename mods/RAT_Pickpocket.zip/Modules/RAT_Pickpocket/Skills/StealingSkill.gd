extends SkillBase

func _init():
	id = "RAT_PickpocketSkill"

func getVisibleName():
	return "Pickpocket"

func getVisibleDescription():
	return "The elegant art of pilfering through pockets unnoticed."

func getPerkTiers():
	return [
		[0],
		[5],
		[10],
		[15],
		[20],
	]
