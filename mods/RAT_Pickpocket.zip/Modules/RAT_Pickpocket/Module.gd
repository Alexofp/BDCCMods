extends Module

var Stealing = load("res://Modules/RAT_Pickpocket/Stealing.gd").new()

func _init():
	id = "RAT_Pickpocket"
	author = "Selinoccino"
	
	gameExtenders = [
		"res://Modules/RAT_Pickpocket/GameExtenders/DataStorageExtender.gd"
	]
	
	events = [
		"res://Modules/RAT_Pickpocket/Gameplay/stealingEvent.gd"
	]
	
	scenes = [
		"res://Modules/RAT_Pickpocket/Gameplay/stealingScene.gd"
	]
	
	skills = [
		"res://Modules/RAT_Pickpocket/Skills/StealingSkill.gd"
	]
	
	perks = GlobalRegistry.getScriptsInFolder("res://Modules/RAT_Pickpocket/Skills/Perks/")
