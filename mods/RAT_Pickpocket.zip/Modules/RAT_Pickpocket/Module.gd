extends Module

var Stealing = load("res://Modules/RAT_Pickpocket/Stealing.gd").new()

func _init():
	id = "RAT_Pickpocket"
	author = "Selinoccino"
	
	gameExtenders = [
		"res://Modules/RAT_Pickpocket/GameExtenders/DataStorageExtender.gd"
	]
	
	events = [
		"res://Modules/RAT_Pickpocket/Gameplay/stealingEvent.gd"
	]
	
	scenes = [
		"res://Modules/RAT_Pickpocket/Gameplay/stealingScene.gd"
	]
	
	skills = [
		"res://Modules/RAT_Pickpocket/Skills/StealingSkill.gd"
	]
	
	perks = GlobalRegistry.getScriptsInFolder("res://Modules/RAT_Pickpocket/Skills/Perks/")

func getDialogue(path:String="res://Modules/RAT_Pickpocket/Dialogue.json") -> Dictionary:
	var f = File.new()
	
	var e = f.open(path, File.READ)
	
	if e != OK:
		Log.error("%s: Can't load dialogue %s, code %s" % [id, path, e])
		return {}
	
	var r : JSONParseResult = JSON.parse(f.get_as_text())
	
	if r.error != OK:
		Log.error("%s: Error loading dialogue from file %s, code %s at line %s, message: %s" % [id, path, r.error, r.error_line, r.error_string])
		return {}
	
	if typeof(r.result) != TYPE_DICTIONARY:
		Log.error("%s: Dialogue file %s, has wrong return type, type: %s, expected dictionary" % [id, path, typeof(r.result)])
		return {}
	
	
	return r.result
	

