extends ItemBase

var used_last = 0
var storedml = 0
var lustMode = true
var switchedToday = false

func _init():
	id = "AzazelsPlushie"
	if GM.pc != null:
		GM.pc.connect("pain_changed", self, "_on_Player_painChanged")

func getVisibleName():
	return "Demon Prince Plushie"

func getDescription():
	return "It's a plushie you've received from Azazel as a reward for successfully guessing his pregnancies multiple times. It features a humanoid demon with slender frame, [color=#da5781]pinkish[/color] skin color, [color=#6a2d4f]darker purple[/color] wings on his back, dark purple neck-length hair, two [color=#da5781]pinkish[/color] horns protruding from his head and colored spaded tail of same color coming from his back. Plush is entirely naked"+(" and gives a slight glow from all over its body and especially its beautiful [color=#6a2d4f]purple[/color] eyes" if canBeUsed() else "")+". It's currently "+("[color=#FFA500]warm[/color]" if lustMode else "[color=#00FFFF]cold[/color]")+" to touch. A tag is attached to its bottom, it gives a name to the character „Anthon Juan Basilis”."

func canUseInCombat():
	return false

func getPrice():
	return 50

func canSell():
	return false

func canCombine():
	return false

func getTags():
	return []

func isImportant():
	return true
	
func isEmpty() -> bool:
	return storedml < 0.1
	
func getData():
	return [lustMode, storedml]
	
func destroyMe():
	GM.main.setModuleFlag("IssixModule", "Azazel_Has_Plushie", true)
	.destroyMe()

func getItemCategory():
	return ItemCategory.Generic
	
func getClothingSlot():
	return InventorySlot.Unique
	
func changeMode():
	lustMode = !lustMode
	return "hotter" if lustMode else "colder"

func _on_Player_painChanged(pain, initialPain):
	print("damage registered"+str(pain-initialPain))
	if lustMode == false and pain > initialPain:
		storedml += pain-initialPain

func getInventoryImage():
	if canBeUsed():
		return "res://Modules/IssixModule/Items/Icons/azazelsplushieglowing.png"
	return "res://Modules/IssixModule/Items/Icons/azazelsplushie.png"

func useInCombat(_attacker, _receiver):
	pass
	
func markAsUsed():
	used_last = GM.main.getDays()
	
func canBeUsed() -> bool:
	return used_last != GM.main.getDays()
	
func saveData():
	var data = .saveData()

	data["used_last"] = used_last
	data["storedml"] = storedml
	data["lustMode"] = lustMode
	data["switchedToday"] = switchedToday

	return data

func onSexEvent(event):
	if lustMode == false:
		return
	if event.getTargetCharID() == "pc" and event.has_method("getField"):
		print("cum registered"+str(event.getField("loadSize", 0)))
		storedml += event.getField("loadSize", 0)


func loadData(data):
	.loadData(data)

	used_last = SAVE.loadVar(data, "used_last", 0)
	storedml = SAVE.loadVar(data, "storedml", 0)
	lustMode = SAVE.loadVar(data, "lustMode", true)
	switchedToday = SAVE.loadVar(data, "switchedToday", false)
	# GM.pc.connect("pain_changed", self, "_on_Player_painChanged")

func getPossibleActions():
	var actions = []
	if getWearer().getStamina() > 100 and canBeUsed():
		actions.append({
					"name": "Squeeze",
					"scene": "AzazelPlushieHover",
					"description": "Squeeze the plushie!",
					"onlyWhenCalm": true
				})
	if !switchedToday and GM.main.getModuleFlag("IssixModule", "Plushie_Learned_Password", false):
		actions.append({
					"name": "\"Mūto\"",
					"scene": "AzazelPlushieChangeMode",
					"description": "Give the plushie password to change",
					"onlyWhenCalm": true
				})
	return actions
