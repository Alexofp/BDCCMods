extends ItemBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "HerbalMedicine"

func getVisibleName():
	return "Herbal Medicine"
	
func getDescription():
	return "Medicine prepared from many herbs gathered and prepared to assist in healing process\n\nRequires 100ml of water in any container to use."

func canUseInCombat():
	return true if canWearerUseIt() else false

func useInCombat(_attacker, _receiver):
	_attacker.addEffect("HerbalMedicine", [6*60*60])
	if checkIfLoc(_attacker):
		if _attacker.isPlayer():
			GM.main.addMessage("Water from the faucet has been used for Herbal Medicine")
	else:
		Globals.removeFluid(currentInventory, "Water", 100.0)
	removeXOrDestroy(1)
	return _attacker.getName() + " took herbal medicine. It's strong."

func getPossibleActions():
	var wearer = getWearer()
	if wearer == null:
		return []
	if canWearerUseIt():
		return [
			{
				"name": "Eat one!",
				"scene": "UseItemLikeInCombatScene",
				"description": "Eat the herbal medicine with 100ml of water",
			},
		]
	else:
		return []
		
func canWearerUseIt():
	var wearer = getWearer()
	if wearer == null:
		return false
	return checkIfLoc(wearer) or Globals.hasFluid(currentInventory, "Water", 100.0)

func checkIfLoc(wearer):
	var pawn = GM.main.IS.getPawn(wearer.getID())
	if pawn != null:
		if pawn.getLocation() in ["main_bathroom1", "main_bathroom2", "main_shower2", "main_shower1"]:
			return true
	return false

func getPrice():
	return 60

func canSell():
	return true

func canCombine():
	return true

func tryCombine(_otherItem):
	return .tryCombine(_otherItem)

func getTags():
	return []

func getItemCategory():
	return ItemCategory.Medical

func saveData():
	var data = .saveData()
	return data
	
func loadData(data):
	.loadData(data)

func getInventoryImage():
	return "res://Modules/IssixModule/Items/Icons/herbalmedicine.png"
