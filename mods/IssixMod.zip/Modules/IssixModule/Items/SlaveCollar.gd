extends ItemBase

func _init():
	id = "inmatecollarslave"

func getVisibleName():
	return "Heavy duty slave collar"

func getDescription():
	return "Extremely bulky and very uncomfortable collar made out of casted iron."

func getClothingSlot():
	return InventorySlot.Neck

func getBuffs():
	return [
		]

func getTakeOffScene():
	return "CollarTuggingScene"

func getTags():
	return [ItemTag.AllowsEnslaving]


func isImportant():
	return true

func isRestraint():
	return true

func generateRestraintData():
	restraintData = RestraintUnremovable.new()

func getUnriggedParts(_character):
	return {
		"neck": ["res://Modules/IssixModule/Items/Models/CollarSlave.tscn"],
	}

func getInventoryImage():
	return "res://Modules/IssixModule/Items/Models/collarslave.png"
