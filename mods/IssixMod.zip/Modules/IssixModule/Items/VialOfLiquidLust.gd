extends ItemBase

func _init():
	id = "VialOfLiquidLust"

func getVisibleName():
	return "Vial of lust"
	
func getDescription():
	return "A transparent glass vial with pink liquid. If broken produces alluring gas."

func getBuffs():
	return [
		]

func getTags():
	return []
	
func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	_attacker.addLust(min(int(_attacker.lustThreshold()/2), 150))
	_attacker.addEffect(StatusEffect.Stunned, [1])
	removeXOrDestroy(1)
	return _attacker.getName() + " uncorked the vial and started sniffing, immediately getting hit with wave of lust getting knocked out hard, the liquid evaporated... Along with the vial?"

func getPossibleActions():
	return [
			{
				"name": "Sniff it",
				"scene": "UseItemLikeInCombatScene",
				"description": "Uncork that beauty and start sniffing it out",
			},
		]

func getAttacks():
	return ["ThrowLustGas"]

func getInventoryImage():
	return "res://Modules/IssixModule/Items/Icons/pinklustvial.png"
