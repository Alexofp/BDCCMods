extends "res://Scenes/SceneBase.gd"

# From Scenes/VendomatScene.gd
# This iterations allows the player to buy items that are currently in given in arg 0 ID of character's inventory. This limits amount that player can buy to what is physically in the inventory of given character

var inventoryScreenScene = preload("res://UI/Inventory/InventoryScreen.tscn")

var sellingItemsTags = [
	ItemTag.SoldByGeneralVendomat,
]
var sellingItems = [
	]
var sellItemsData = {}
var finalSellingItemsObjects = []

var lockedInto = true
var characterId := ""
var characterInventory: Inventory

func _initScene(_args = []):
	if(_args.size() > 0):
		setState("buymenu")
		characterId = _args[0]
		characterInventory = GlobalRegistry.getCharacter(characterId).getInventory()
	else:
		endScene()
		return

func _init():
	sceneID = "LamiaSellScreen"
	
func _reactInit():
	updateSellingItems()
	
func updateSellingItems():
	sellItemsData.clear()
	
	for itemObject in characterInventory.getAllItems():
		sellItemsData[itemObject.id] = {
			"name": itemObject.getVisibleName(),
			"desc": itemObject.getVisisbleDescription(),
			"price": itemObject.getPrice(),
			"amount": itemObject.getBuyAmount(),
			"available": itemObject.getAmount()
		}
		finalSellingItemsObjects.append(itemObject)
	
	if finalSellingItemsObjects.size() == 0:
		addMessage("Lamia is currently not selling anything, check again another day.")
		endScene()
		return


func _run():
	if(state == ""):
		saynn("You ask Lamia to show what he is selling.")
		
		saynn("What do you wanna do?")

		addButton("Buy", "See what they have to sell", "buymenu")
		addButton("Step away", "Step away", "endthescene")
	
	if(state == "buymenu"):
		var inventory = inventoryScreenScene.instance()
		GM.ui.addFullScreenCustomControl("inventory", inventory)
		inventory.setItems(finalSellingItemsObjects, "buy")
		var _ok = inventory.connect("onItemSelected", self, "onInventoryItemSelected")
		var _ok2 = inventory.connect("onInteractWith", self, "onInventoryItemInteracted")

		addButton("Back", "Don't buy anything", "")

		
func _react(_action: String, _args):
	if(_action == ""):
		if(lockedInto):
			endScene()
			return
	
	if(_action == "buy"):
		processTime(2*60)
		var itemID = _args[0]
		var amount = 1
		if(_args.size() > 1):
			amount = _args[1]
		var item = sellItemsData[itemID]
		var itemName = item["name"]
		if((item["amount"] * amount) > 1):
			itemName = str(item["amount"] * amount)+"x"+itemName
		var split = characterInventory.getFirstOf(itemID).splitAmount(amount)
		GM.pc.getInventory().addItem(split)
		GM.pc.addCredits(-sellItemsData[itemID]["price"] * amount)

		
		addMessage(""+itemName+" was added to your inventory")
		
		if(lockedInto):
			endScene()
			return
		setState("")
		return

	if(_action == "endthescene"):
		endScene()
		return
	
	setState(_action)

func saveData():
	var data = .saveData()
	
	data["characterId"] = characterId

	return data
	
func loadData(data):
	.loadData(data)
	
	characterId = SAVE.loadVar(data, "characterId", null)
	if characterId == null:
		endScene()
		return
	characterInventory = GlobalRegistry.getCharacter(characterId).getInventory()
	
	updateSellingItems()

func onInventoryItemInteracted(item: ItemBase):
	if(state == "buymenu"):
		GM.main.pickOption("buy", [item.id])


func onInventoryItemSelected(item: ItemBase):
	GM.ui.clearButtons()
	addButton("Back", "Don't do anything", "")
	
	if(state == "buymenu"):
		var itemData = sellItemsData[item.id]
		var itemAmountPerBuy = itemData["amount"]
		var itemPrice = itemData["price"]
		var maxSell = itemData["available"]
		
		var credits = GM.pc.getCredits()
		var amounts = [1, 2, 3, 4, 5, 10, 20]
		for amount in amounts:
			if amount > maxSell:
				break
			var newPrice = itemPrice * amount
			var newAmount = itemAmountPerBuy * amount
			
			if(credits >= newPrice):
				addButton("Buy "+(str(newAmount))+" for "+str(newPrice)+" credits", "Amount: "+str(newAmount)+"\nPrice: "+str(newPrice)+" credits", "buy", [item.id, amount])
			else:
				addDisabledButton("Buy "+(str(newAmount))+" for "+str(newPrice)+" credits", "Amount: "+str(newAmount)+"\nPrice: "+str(newPrice)+" credits\nYou don't have enough credits")

func onInventoryItemGroupInteracted(item: ItemBase):
	if(state == "sellmenu"):
		GM.main.pickOption("sellall", [item])
		

		
		
