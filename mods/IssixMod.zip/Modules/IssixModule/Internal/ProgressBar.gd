extends ProgressBar

var id
var time_to_count = 0
var initial_time = 0
var started = false

signal timer_reached_zero

func _process(_delay: float):
	if started:
		time_to_count -= _delay
		set_value(time_to_count)
	if time_to_count <= 0:
		emit_signal("timer_reached_zero")

func setTime(time: int):
	set_step(0.01)
	time_to_count = time
	initial_time = time
	max_value = time
	min_value = 0
	
func start():
	started = true
