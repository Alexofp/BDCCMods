extends "res://Characters/Dynamic/Generator/GuardGenerator.gd"

func getPossibleAttacks():  # Doesn't do anything, likely because our parent function basically overwrites return
	return ["HeatGrenade", "DoubleCuffPC", "CuffPCHands", "ForceGagPC", "ForceMuzzlePC", "stunbatonOverchargeAttack", "simplekickattack", "biteattack", "shoveattack", "PetCommandSit", "PetCommandRoll"]
