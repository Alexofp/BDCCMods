extends EventTrigger
class_name EventTriggerSpecificTime

# Dict in form of:
# {12*60*60: [obj, obj]}
var eventsByTime = {}
var lastTimeCached := -1
var diff: int = 0

static func sortPriority(a, b):
	if a.getPriority() > b.getPriority():
		return true
	return false

func addEvent(event, args):
	var time: int = args[0]
	
	if(!eventsByTime.has(time)):
		eventsByTime[time] = []
		
	eventsByTime[time].append(event)

func onAllEventsAdded():
	pass

func triggerReact(args):
	var timeDiff = 0
	
	for event_object in objectsToInform(args[0]):
		if typeof(event_object) == TYPE_INT:
			timeDiff = event_object
			continue
		if(event_object.react(id, [timeDiff])):
			return true

	return false

func triggerRun(args):
	var timeDiff = 0
	
	for event_object in objectsToInform(args[0]):
		if typeof(event_object) == TYPE_INT:
			timeDiff = event_object
			continue
		event_object.run(id, [timeDiff])

func objectsToInform(timePassed: int) -> Array:
	var arrays := []
	var now: int = GM.main.getTime()
	var then: int = lastTimeCached
	
	if lastTimeCached == -1:  # In case we have only just now began obtaining the time, do this TODO Hook when main scene loads instead?
		then = now - timePassed  # It's not perfect, if player sleeps for 3 hours this will miss 2 hours
	if now < then:  # New day
		now = 23*60*60  # Do all events until the end of the day
	elif now == then:  # In case time didn't move do not reexecute the events
		return []
	
	for item in eventsByTime.keys():
		if then < item and now >= item:
			arrays.append(now-item)
			arrays.append_array(eventsByTime[item])
	
	lastTimeCached = GM.main.getTime()
	
	return arrays
