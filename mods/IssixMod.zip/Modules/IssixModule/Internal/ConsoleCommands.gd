
func init():
	Console.addCommand("spawng", GM.main.IS, "trySpawnPawn", ["Guard"], "Spawns a guard and gives their name")
