extends FluidBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "CorruptiveTar"

func getVisibleName():
	return "Corruptive Tar"

func getCost(_amount) -> int:
	return int(_amount / 100.0) * 3

func getCumOverlayColor():
	return Color.black

func getMessyBuffs(_pc, _amount):
	var messLevel = Util.mini(int(_amount / 100), 10)
	
	if(messLevel > 0):
		return [
			buff(Buff.DodgeChanceBuff, [-15 * messLevel]),
			buff(Buff.AmbientLustBuff, [8 * messLevel]),
			buff(Buff.ReceivedLustDamageBuff, [3 * messLevel]),
			buff(Buff.StatBuff, [Stat.Agility, -messLevel if _pc.getStat(Stat.Agility)-messLevel >= 0 else -_pc.getStat(Stat.Agility)])  # negative Agility brings stamina to 0
		]

func getMessyDescription(_pc, _amount):
	if _amount > 1000:
		return "You are absolutely drenched in void black corruptive tar. Sensations from all over your body overwhelm your control over it, moving is difficult, sluggish. You hear whispers all around, they tell you to give yourself in to the tar, to become one with it, all you need to do is to just fill yourself with it as well, from the inside."
	if _amount > 650:
		return "All parts of your body are covered with black corruptive tar. You feel heat coming from all over you, you feel weaker, more malleable."
	if _amount > 350:
		return "You have the black corruptive tar on most body parts of yours. Each one of those feels in need, supplying your brain with ample amount of hormones. You feel the need to cover yourself some more with that tar."
	if _amount > 100:
		return "There is quite a lot of corruptive tar on you, it sticks to your " + Globals.getSkinWord() + " making you feel... Strange all around."