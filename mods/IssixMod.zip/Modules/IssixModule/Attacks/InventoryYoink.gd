extends Attack

func _init():
	id = "InventoryYoink"
	category = Category.Special
	aiCategory = AICategory.Offensive
	aiScoreMultiplier = 2

func getVisibleName(_context = {}):
	return "Grab items"

func getVisibleDesc(_context = {}):
	return "Temporarily incapacitate enemy to the point where they cannot use their items"

func _doAttack(_attacker, _receiver, _context = {}):
	var text = ""
	
	if checkDodged(_attacker, _receiver, DamageType.Physical, 0.4):
		var texts = [
			"{attacker.name} rushes {receiver.name} on {receiver.his} left, while {receiver.name} successfully dodges the attack",
			"{attacker.name} rushes {receiver.name} on {receiver.his} right, while {receiver.name} successfully dodges the attack"
		]
		text = RNG.pick(texts)
	else:
		var texts = [
			"{attacker.name} rushes {receiver.name} on {receiver.his} left successfully stealing {receiver.name}'s items away",
			"{attacker.name} rushes {receiver.name} on {receiver.his} right successfully stealing {receiver.name}'s items away"
		]
		text = RNG.pick(texts)
		_receiver.addEffect("InventoryBlocked", [2])
		_attacker.addEffect("InventoryBlocked", [2, _receiver.getID()])

	return {
		text = text
	}

func _canUse(_attacker, _receiver, _context = {}):
	return !(_receiver.hasEffect("InventoryBlocked") or _attacker.hasEffect("InventoryBlocked"))

# func _canUse(_attacker, _receiver, _context = {}):
# 	return !_receiver.isBlindfolded()

func getAnticipationText(_attacker, _receiver):
	var text = "{attacker.name} approaches you rapidly with {attacker.his} front slightly lowered."

	return text

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands, AttackRequirement.CanSee]
