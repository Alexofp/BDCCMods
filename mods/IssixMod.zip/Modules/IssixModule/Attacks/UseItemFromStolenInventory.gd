extends Attack

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "UseStolenItem"
	category = Category.Special
	aiCategory = AICategory.Defensive
	isPlayerAttack = false  # Currently unimplemented but entirely possible to implement it

func getVisibleName(_context = {}):
	return "Use stolen item"

func getVisibleDesc(_context = {}):
	return "Use item from stolen inventory of opponent."

func allOrNothing(arr: Array):
	return 1 if arr.size() > 0 else 0

func _doAttack(_attacker:BaseCharacter, _receiver, _context = {}):
	if !_attacker.hasEffect("InventoryBlocked"):
		return {text = "ERROR: Nothing has happened, Issix Mod error (no effect on attacker)"}
	var eff = _attacker.getEffect("InventoryBlocked")
	var items = eff.getAnyReliefItem()
	var result = RNG.pickWeighted(
					[items[0], items[1], items[2]],
					[_attacker.getPainLevel() * allOrNothing(items[0]), 
					_attacker.getLustLevel() * allOrNothing(items[1]), 
					_attacker.getStaminaLevel() * allOrNothing(items[2])]
				)
	if result.size() == 0:
		return {text = "ERROR: Nothing has happened, Issix Mod error (array has 0 for usestolenitem)"}
	var item = eff.getStolenInventory().getFirstOf(result[0])
	
	return {text = item.useInCombat(_attacker, _receiver) }

func _canUse(_attacker, _receiver, _context = {}):
	if _attacker.hasEffect("InventoryBlocked"):
		var eff = _attacker.getEffect("InventoryBlocked")
		if eff.gainedInventory() and Globals.any(eff.getAnyReliefItem()):
			return true
	
	return false

func canBeDodgedByPlayer(_attacker, _receiver):
	return false

func getAnticipationText(_attacker, _receiver):
	return "{attacker.name} dives right into stolen inventory in {attacker.his} possession."

func getAttackSoloAnimation():
	return "stand"

func getRequirements():
	return [AttackRequirement.FreeHands]

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getAIScore(_attacker, _receiver):
	# In theory this can replace _canUse if we were looking for optimization
	var eff = _attacker.getEffect("InventoryBlocked")
	var items = eff.getAnyReliefItem()
	if (_attacker.getPainLevel() < 0.6 and allOrNothing(items[0])) or (_attacker.getLustLevel() < 0.6 and allOrNothing(items[1])) or (_attacker.getStaminaLevel() < 0.6 and  allOrNothing(items[2])):
		return 5 * RNG.pick([0.0, 10.0])
	return 0.0
