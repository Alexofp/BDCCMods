extends Attack

func _init():
	id = "ThrowLustGas"
	category = Category.Lust
	aiCategory = AICategory.Lust
	isWeaponAttack = true
	
func getVisibleName(_context = {}):
	return "Throw lust gas"
	
func getVisibleDesc(_context = {}):
	var item = getItem(_context)
	
	return item.getVisisbleDescription()
	
func _doAttack(_attacker, _receiver, _context = {}):
	if(checkMissed(_attacker, _receiver, DamageType.Physical)):
		return genericMissMessage(_attacker, _receiver)
	
	if(checkDodged(_attacker, _receiver, DamageType.Physical)):
		return genericDodgeMessage(_attacker, _receiver)
	
	var item = getItem(_context)
	
	# (50 * Lust level (0.0-1.0) + 0.5) ^ 2 to maximum of 35% of receiver's lust threshold
	var howMuchLustToAdd = int(min(50 * pow(_receiver.getLustLevel() + 0.5, 2), _receiver.lustThreshold()/3.5))
	
	var text = "{attacker.name} throws a pink gas vial at {receiver.name}! The vial breaks right at {receiver.him} {receiver.feet}, spilling all of its contents!\n\n{receiver.name} received [color="+DamageType.getColorString(DamageType.Lust)+"]"+str(howMuchLustToAdd) + " lust damage[/color], which invigorated them adding [color="+DamageType.getColorString(DamageType.Stamina)+"]"+"20 stamina[/color]."
	
	item.destroyMe()
	
	var resultStuff = {
		text = text,
		lust = howMuchLustToAdd,
		stamina = 20
	}
	
	return resultStuff
	
func _canUse(_attacker, _receiver, _context = {}):
	return itemExists(_context)

func getAttackSoloAnimation():
	return "throw"

func getRecieverArmorScaling(_attacker, _receiver, _damageType) -> float:
	return 1.0

func getAttackerDamageMultiplierEfficiency(_attacker, _receiver, _damageType) -> float:
	return 0.0

func getRequirements():
	return [AttackRequirement.FreeArms, AttackRequirement.FreeHands]

func combineWeaponAttacks():
	return false
