extends Reference

var id:String = "error"


func isOrderSensitive() -> bool:
	return false
	
func sizeMin() -> int:
	return 0
	
func sizeMax() -> int:
	return 99
	
func checkSize(size: int) -> bool:
	return size <= sizeMax() and size >= sizeMin()
	
func requiredIngrediants() -> Array:
	return []
	
func checkIfFullfillsIngredients(ingredients: Array) -> bool:
	if isOrderSensitive():
		var index = 0
		for reqIng in requiredIngrediants():
			if index > ingredients.size()-1:
				return false
			if ingredients[index] == reqIng:
				index = index + 1
				continue
		return true
	else:
		for reqIng in requiredIngrediants():
			if ingredients.has(reqIng):
				ingredients.erase(reqIng)  # Check if it won't remove the value from given array
			else:
				return false
		return true
		
func checkColor(_r: float, _g: float, _b: float):
	return true
	
func fulfillsRecipe(size: int, ingrediants: Array, color = Color(0.0, 0.8, 0.0)):
	return checkSize(size) and checkIfFullfillsIngredients(ingrediants) and checkColor(color.r, color.g, color.b)

func result():
	return null
	
func resultSchedule(_day: int) -> bool:
	return false
	
func notesDescription() -> String:
	return ""