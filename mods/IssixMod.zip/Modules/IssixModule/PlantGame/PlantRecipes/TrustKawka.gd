extends "res://Modules/IssixModule/PlantGame/RecipeBase.gd"

func _init():
	id = "TruskKawka"

func requiredIngrediants() -> Array:
	return ["P-Bloom"]
	
func checkColor(_r: float, _g: float, _b: float):
	return _r > 0.8 and _g < 0.2 and _b < 0.2

func result():
	var item = GlobalRegistry.createItem("TrustKawka")
	item.setAmount(RNG.randi_range(1, 2))
	return item
	
func resultSchedule(day: int) -> bool:
	return day % 2 and day != 0
	
func notesDescription():
	return "A very sweet red fruit comes from combining P-Bloom with red CoLore."
	
func plantGrowLook():
	return "Small white bulbs with green leaves start to grow along the stems of the plant."