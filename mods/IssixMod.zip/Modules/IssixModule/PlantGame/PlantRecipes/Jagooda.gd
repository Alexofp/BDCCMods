extends "res://Modules/IssixModule/PlantGame/RecipeBase.gd"

func _init():
	id = "Jagooda"

func requiredIngrediants() -> Array:
	return ["P-Bloom"]
	
func checkColor(_r: float, _g: float, _b: float):
	return _r < 0.2 and _g < 0.2 and _b > 0.8

func result():
	var item = GlobalRegistry.createItem("Jagooda")
	item.setAmount(RNG.randi_range(1, 2))
	return item
	
func resultSchedule(day: int) -> bool:
	return day % 2 and day != 0
	
func notesDescription():
	return "A sweet blue, round fruit comes from combining P-Bloom with blue CoLore."
	
func plantGrowLook():
	return "Small purple bulbs with green leaves start to grow along the stems of the plant."