extends "res://Modules/IssixModule/PlantGame/RecipeBase.gd"

func _init():
	id = "Sa Lata"

func requiredIngrediants() -> Array:
	return ["P-Bloom"]
	
func checkColor(_r: float, _g: float, _b: float):
	return _r < 0.2 and _g > 0.8 and _b < 0.2

func result():
	var item = GlobalRegistry.createItem("Jagooda")
	item.setAmount(RNG.randi_range(1, 2))
	return item
	
func resultSchedule(day: int) -> bool:
	return day % 2 and day != 0
	
func notesDescription():
	return "A large green bulb made of leaves grows out from the ground by combining P-Bloom with green CoLore."
	
func plantGrowLook():
	return "Leaves grow and surround the thin stem at the center."