extends "res://Modules/IssixModule/PlantGame/RecipeBase.gd"

func _init():
	id = "LiquidLust"

func requiredIngrediants() -> Array:
	return ["MegaMilkMAX", "DemoniX"]
	
func checkColor(_r: float, _g: float, _b: float):
	return _r > 0.8 and _g < 0.2 and _b < 0.0

func result():
	var item = GlobalRegistry.createItem("VialOfLiquidLust")
	# item.setAmount(RNG.randi_range(1, 2))
	return item
	
func resultSchedule(_day: int) -> bool:
	return true
	
func notesDescription():
	return "A musty aphrodisiac is produced by a plant created by combining MegaMilkMAX and essence of a demon."
	
func plantGrowLook():
	return "{stems} are covered by thick layer of sticky liquid that tints the entire plant red. The smell is highly arousing."