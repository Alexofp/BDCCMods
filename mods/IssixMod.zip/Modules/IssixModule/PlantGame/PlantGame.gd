# Ideas:
# Plant properties:
# Aggression
# Size
# Stress (each pill adds stress value of 1 except size, max is 3?)
# Color
# Tentacleness
# Toxicity maybe?
# Hard end - If fed aggression, strength and size pills the plant will strangle the player

# QuickShift = General growth
# MegaMilkMAX = fluid creator (affected by other pills on which fluid is being produced, should be able to produce liquid last for collection)
# CoLore = changes color
# DemoniX = Demonification = aggression
# SissyMoldPro = remove aggression
# DiRecto = makes plant tentacles
# CockBeGone = removes tentacles
# ThiCC = death
# SliMM = death
# P-Bloom = flowering
# EstroGPlus = light emitting
# PussyBeGone = grows spikes
# ??? = 
# P-Bloom + red = Trust Kawka
# P-Bloom + blue = Jagooda
# P-Bloom + green = Sa Lata
# P-Bloom + black = Ziemninmak
# P-Bloom + white = 
# P-Bloom + purple = PsiPsi
# P-Bloom + 

# MegaMilkMAX + DemoniX + red = Liquid Lust
# MegaMilkMAX + DemoniX + black = Corruptive Tar
# MegaMilkMAX + white = White Goo
# 

# Unstable Mutagen + WildShift + BoneRoll on both plants = Quantum Fruit

extends SceneBase

const plant_data_schema = {"plant1": null, "plant2": null, "discovered_combinations": [], "last_view": 0, "upgrades_purchased": []}
const PILL_EFFECTS = {"Demonification": {"aggression": 1}, "Sissification": {"aggression": -1}, "GrowPenisTF": {"tentacles": true}, "RemovePenisTF": {"tentacles": false}}
const UPGRADES = {"FluidCollector": 2000, "ItemCollector": 2000, "Humidifier": 3000, "LightEmitter": 2000}
const MAX_LINES_PER_PAGE = 7
const MAX_PILLS = 3
var active_side = 0
var last_pill = ""
var plant1 = null # refreshed every printPlant() call
var plant2 = null
const Globals = preload("res://Modules/IssixModule/Globals.gd")

class Plant:
	var pills = []
	var size = 0
	var color = null
	var variant = 0
	var planted_day = null
	var last_collected = null
	var matching_recipe = null
		
	func _init(data: Dictionary):
		pills = data.get("pills", [])
		size = data.get("size", 0)
		#warning-ignore:incompatible_ternary
		color = Color(data.get("color")) if data.get("color") else null
		planted_day = data.get("planted_day", GM.main.getDays())
		last_collected = data.get("last_collected", GM.main.getDays())
		variant = data.get("variant", RNG.randi_range(1, 5))
		for recipeID in Globals.ofModule("IssixModule").plantRecipes:
			if Globals.ofModule("IssixModule").plantRecipes[recipeID].fulfillsRecipe(getSize(), getPills(), getColors()):
				matching_recipe = recipeID
				break
		
	func getPills() -> Array:
		return pills
		
	func getSize() -> int:
		return size
		
	func plantedDay() -> int:
		return planted_day
	
	func plantAge() -> int:
		return GM.main.getDays() - planted_day
		
	func collectResults():
		if matching_recipe and last_collected < GM.main.getDays():
			var iter = last_collected
			var rewards = []
			var recipe = getRecipe()
			while iter < GM.main.getDays():
				iter = iter + 1
				
				if recipe.resultSchedule(iter):
					rewards.append(recipe.result())
			if rewards:
				return rewards
		return null
		
	func collect():
		last_collected = GM.main.getDays()
		
	func increaseSize():
		size = size + 1
		
	func decreaseSize():
		size = size - 1
		
	func getAggression():
		return pills.count("Demonification") - pills.count("Sissification")
		
	func addPill(pill: String):
		pills.push_back(pill)
		
	func addColor(_color: String):
		if color != null:
			color = color.linear_interpolate(_color, 0.5)
		else:
			color = _color
		
	func getColors():
		return color
		
	func getRecipe():
		return Globals.ofModule("IssixModule").plantRecipes[matching_recipe]
		
	func setNewRecipe(recipeID):
		matching_recipe = recipeID
		last_collected = GM.main.getDays()
		
	func isAlive() -> bool:
		if getSize() > MAX_PILLS:
			return false
		if pills.has("ThicknessRemoveTF") or pills.has("ThicknessAddTF"):
			return false
		return true
		
	func isTentacled() -> bool:
		return (pills.count("GrowPenisTF") - pills.count("RemovePenisTF")) > 0
		
	func sizeDescription() -> String:
		return {0: "tiny sized, just a little stem coming off the ground", 1: "medium sized", 2: "large sized", 3: "huge sized (struggling to be contained within the aquarium)", 4: "enormous sized (no longer contained by the aquarium)", 5: "gargantuan sized (plant grows now outside of the aquarium)"}[getSize()]
		
	func sizeDescriptionGrowing() -> String:
		return {0:"tiny sprout", 1: "medium size (around 15 cm)", 2: "large size (around 28 cm)", 3: "huge size (around 50 cm), the aquarium struggles to contain the plant", 4: "enormous size (around 1 meter), the plant forcefully removed the lid on the aquarium and grows about the aquarium", 5: "gargantuan size (around 3 meters), the plant now threatens the integrity of a room you are in"}[getSize()]
		
	func getColorText() -> String:
		if color == null:
			return "regular green"
		if color.b > 0.8 and color.g > 0.8 and color.r > 0.8:
			return "white"
		elif color.b > 0.8 and color.g < 0.8 and color.r < 0.8:
			return "blue"
		elif color.b < 0.8 and color.g > 0.8 and color.r < 0.8:
			return "intense green"
		elif color.b < 0.8 and color.g < 0.8 and color.r > 0.8:
			return "red"
		elif color.b > 0.8 and color.g > 0.8 and color.r < 0.8:
			return "teal"
		elif color.b > 0.8 and color.g < 0.8 and color.r > 0.8:
			return "purple"
		elif color.b < 0.8 and color.g > 0.8 and color.r > 0.8:
			return "brown"
		elif color.b < 0.2 and color.g < 0.2 and color.r < 0.2:
			return "black"
		else:
			return "color mixed"
		
	func plantStems() -> String:
		var stem_type = null
		if isTentacled():
			stem_type = ["tentacled", "tentacles", "Its stems turned into mass of tentacles"]
		elif hasFlowers():
			stem_type = ["flowery", "flowers", "Countless flowers are connected to branching leaves"]
		else:
			stem_type = ["", "stems", "The plant looks almost ordinary with regular stems shooting off the dirt below"]
		return stem_type
		
	func getVariantDescriptors() -> Array:
		match variant:
			1:
				return ["fragrant"]
			2:
				return ["hardy"]
			3: 
				return ["vibrant"]
			4:
				return ["thriving"]
			5:
				return ["majestic"]
			_:
				return []
		
	func hasFlowers() -> bool:
		return "P-Bloom" in pills
		
	func Sformat(description) -> String:
		var stems = plantStems()
		return description.format({"stems": stems[1], "stems_how": stems[0], "stems_desc": stems[2]})
		
	func getDescription() -> String:
		if not isAlive():
			return "This " + sizeDescription() + " plant is entirely withered away, the formerly "+plantStems()+ " plant is devoid of life and color."
		else:
			# We have size, variant based description, color, stem type and aggressiveness
			# you see a gargantuan sized (plant grows now outside of the aquarium) green plant. Its stems turned into mass of tentacles./Countless flowers are connected to branching leaves./The plant looks almost ordinary with regular stems shooting off the dirt below. <recipe specific description>. (if agressive) <stems[1]> are violently shaking in many directions hitting the walls of aquarium, the plant is somehow agitated.
			var stems = plantStems()
			
			return "You look over a " + sizeDescription() + ", " + getVariantDescriptors()[0] + " "+ getColorText() +" plant. "+ stems[2]+". " +(Sformat(Globals.ofModule("IssixModule").plantRecipes[matching_recipe].plantGrowLook()) if matching_recipe != null else "") + " " + (Util.capitalizeFirstLetter(stems[1])+" are viollently shaking in all directions hitting the walls of aquarium — the plan is somehow agitated.")
		
	func serialize() -> Dictionary:
		return {"pills": pills, "size": getSize(), "color": color.to_html() if color else null, "planted_day": planted_day, "variant": variant, "last_collected": last_collected}
		
	func isQuantum() -> bool:
		return pills.has("GrowPenisRandomTF") and pills.has("RandomTFs") and pills.has("SpeciesTF") and getSize() > 1 and getSize() < 4


func _init():
	sceneID = "PlantGameIssix"

func _initScene(_args = []):
	var plant_data = getModuleFlag("IssixModule", "Plant_Data", plant_data_schema)
	if plant_data["plant1"] != null:
		plant1 = Plant.new(plant_data["plant1"])
		# plant1.init(plant_data["plant1"])
	if plant_data["plant2"] != null:
		plant2 = Plant.new(plant_data["plant2"])
		# plant2.init(plant_data["plant2"])
		
func isQuantumConfiguration() -> bool:
	return plant1 != null and plant2 != null and plant1.isQuantum() and plant2.isQuantum()

func getActivePlant() -> Plant:
	if active_side == 2:
		return plant2
	else:
		return plant1
		
func savePlants():
	var plant_data = getModuleFlag("IssixModule", "Plant_Data", plant_data_schema)
	if plant1 != null:
		plant_data["plant1"] = plant1.serialize()
	if plant2 != null:
		plant_data["plant2"] = plant2.serialize()
	setModuleFlag("IssixModule", "Plant_Data", plant_data)

func _run():
	if(state == ""):
		printPlant()
		if plant1 == null:
			addButtonAt(0, "Plant", "Plant a new plant on the left space", "plant", [1])
		else:
			addButtonAt(0, "Clear", "Clear plant from left space", "remove", [1])
			if !plant1.isAlive():
				addDisabledButtonAt(1, "Add pill", "This plant is withered away and will no longer grow")
			else:
				addButtonAt(1, "Add pill", "Feed the plant on the left space with a pill", "pill", [1])
		if plant2 == null:
			addButtonAt(4, "Plant", "Plant a new plant on the right space", "plant", [2])
		else:
			addButtonAt(4, "Clear", "Clear plant from right space", "remove", [2])
			if !plant2.isAlive():
				addDisabledButtonAt(1, "Add pill", "This plant is withered away and will no longer grow")
			else:
				addButtonAt(3, "Add pill", "Feed the plant on the right space with a pill", "pill", [2])
		addButtonAt(2, "Back", "Go back", "endthescene")
		addButtonAt(7, "Stash", "Access your Stash", "stash")
		addButtonAt(12, "Notebook", "Check notes", "notebook")
		addButtonAt(13, "Upgrades", "See possible upgrades", "upgrades")
		
	if state == "pill":
		saynn("What pill do you want to feed the plant on the [b]"+left_right(active_side)+"[/b] side of the aquarium?")
		if GM.pc.getInventory().getFirstOf("TFAcceleratePill") != null:
			addButton("QuickShift", "Increase size of plant", "feed", ["TFAcceleratePill"])
		for item in GM.pc.getInventory().getAllOf("TFPill"):
			addButton(item.getVisibleName(), item.getDescription(), "feed", ["TFPill", item.getTFID(), item])
		
	if state == "result":
		if last_pill[0] == "TFAcceleratePill":
			saynn("The plant on the "+left_right(active_side)+" grew to "+getActivePlant().sizeDescriptionGrowing())
		elif last_pill[0] == "TFPill":
			if getActivePlant().getPills().size() > MAX_PILLS:
				saynn("The plant dramatically spasms until it visibly withers. Plant experienced way too much stress from all of the chemicals.")
			else:
				saynn("You've dropped "+GlobalRegistry.getTransformationRef(getActivePlant().getPills()[-1]).getPillName() +" into the ground next to the plant.")
				
		addButton("Back", "", "")
		
	if state == "fail_remove":
		saynn("You attempt to remove the plant however the plant is so big and aggressive that it attacks you on spot when you approach the aquarium leaving you bruised up. If you want to get rid of it, it will require a different plan, otherwise if you attempt this again you might not be as fortunate.")
		addButton("Back", "", "")
		
	if state.begins_with("notebook"):
		var page = int(state.substr(8)) if state.substr(8) else 1 
		var notes = []
		notes.append("You look at notebook, in it some written notes.")
		notes.append("[center][b]OBSERVATIONS OF PLANTS[/b][/center]")
		notes.append("  „Plant grows when helped with some water, the rate of growth naturally is around 1 cm every 3 days. When in contact with other plant of same species both seem to fight each other. One usually wins out.”")
		notes.append("  „Dissolving [color=cyan][b]QuickShift[/b][/color] onto one of the plants causes it to grow rapidly. The size seems to depend on existing size. It starts with growth of around 15 cm however adding can quickly cause the size to go out of control.”")
		notes.append("  „Dissolving [color=cyan][b]ThiCC[/b][/color] causes the plant to wither and die unconditionally.”")
		notes.append("  „Dissolving [color=cyan][b]CoLore[/b][/color] causes the plant to change color.”")
		notes.append("  „I've noticed that adding more than 3 pills of transformative qualities seems to outright kill the plant, I don't know why.”")
		for line in notes.slice(max(0, page*MAX_LINES_PER_PAGE-MAX_LINES_PER_PAGE), page*MAX_LINES_PER_PAGE):
			saynn(line)
			
		for page_other in range(notes.size() / MAX_LINES_PER_PAGE):
			if page_other == page:
				continue
			addButton("Page "+str(page_other), "Go to page "+str(page_other), "notebook"+str(page_other))
		addButton("Back", "", "")
		

func printPlant():
	if isQuantumConfiguration():
		saynn("Countless stems of both plants have connected, creating a messy intertwined web. Both plants have unified in darker navy blue color and are now pulsating regularly from the roots to the top. This web weaves to invisible wind and mesmerizes with its pulsating spectacle. You can see "+plant1.fruitStatus() + ".")
	else:
		for loc in [1, 2]:
			var desc = left_right(loc)
			var plant = plant1 if loc == 1 else plant2
			if plant == null:
				saynn(Util.capitalizeFirstLetter(desc)+" side of aquarium currently has no plant growing in it.")
				continue
			
			saynn("Status of plant on [b]"+Util.capitalizeFirstLetter(desc)+"[/b] side of aquarium:")
			saynn(plant.getDescription())
			
			
	
func left_right(side):
	return "left" if side == 1 else "right"

func findMatchingRecipeForActivePlant():
	var plant = getActivePlant()
	for recipeID in Globals.ofModule("IssixModule").plantRecipes:
		if Globals.ofModule("IssixModule").plantRecipes[recipeID].fulfillsRecipe(plant.getSize(), plant.getPills(), plant.getColors()):
			return recipeID
	return null
	
func addDiscoveredRecipeCombination(recipeID: String) -> bool:
	var data = getModuleFlag("IssixModule", "Plant_Data", plant_data_schema)
	if !(recipeID in data["discovered_combinations"]):
		data["discovered_combinations"].append(recipeID)
		setModuleFlag("IssixModule", "Plant_Data", data)
		return true
	return false
	
	
func _react(_action: String, _args):
	if _action == "plant":
		active_side = _args[0]
		if active_side == 1:
			plant1 = Plant.new({})
		else:
			plant2 = Plant.new({})
		addMessage("You've grabbed a seed and put it on the "+left_right(_args[0])+" side of aquarium.")
		savePlants()
		processTime(60)
		_action = ""
		
	if _action == "remove":
		active_side = _args[0]
		if getActivePlant().getAggression() > 0 and getActivePlant().getSize() > 2 and getActivePlant().isAlive():
			GM.pc.addPain(RNG.randi_range(40, 60))
			if GM.pc.getPainLevel() == 1.0:
				runScene("MauledByPlant", [], "mauled_by_plant")
				return
			_action = "fail_remove"
		else:
			processTime(3*60*getActivePlant().getSize())
			if active_side == 1:
				plant1 = null
			else:
				plant2 = null
			savePlants()
			addMessage("You've successfully removed the plant on [b]"+left_right(active_side)+"[/b] side.")
			_action = ""
		
	if _action == "pill":
		active_side = _args[0]
		processTime(5)
		
	if _action == "feed":
		processTime(60*3)
		if _args[0] == "TFAcceleratePill":
			getActivePlant().increaseSize()
		else:
			getActivePlant().addPill(_args[1])
			if _args[1] == "SkinTF":
				getActivePlant().addColor(_args[2].pickedColors[0])  # Pick only first color (primary)
		var recipe = findMatchingRecipeForActivePlant()
		if recipe != null:
			getActivePlant().setNewRecipe(recipe)
			if addDiscoveredRecipeCombination(recipe.id):
				GM.pc.addExperience(25)
				addMessage("You've discovered a new combination of transformatives producing a new effect in a plant!")
		last_pill = _args
		savePlants()
		_action = "result"
		
	if _action == "stash":
		runScene("PlayerStashScene")
		_action = ""

	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
