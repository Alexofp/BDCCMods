extends GameRoom

func _init():
	self_modulate = Color( 1, 1, 0.7, 1 )
	position = Vector2( -64, 64 )
	roomName = "Issix's Hidden Cell Room"
	roomID = "cellblock_orange_issixcell"
	roomDescription = "A secret room behind Issix's cell's vent."
	canWest = false
	canNorth = false
	canEast = false
	canSouth = false
	roomColor = 6
	gridColor = 7