extends RichTextLabel

var shift = 0
var tick = 0

func _init():
	init_shift()

func init_shift():
	shift = RNG.randf_range(-0.5, 0.5)

func _process(_delta):
	.set_position(self.get_position()+Vector2(shift, 2.0))
	tick += 1
	if tick > 80:
		.queue_free()
	.set_self_modulate(Color(Color.green, 1.0-(tick/80)))
