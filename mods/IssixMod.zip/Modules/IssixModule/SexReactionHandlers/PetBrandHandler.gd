extends SexReactionHandler

func _init():
	handles = {
		5600: {REACT_CHANCE: 100}  # 560 is all letters of "issix" converted to decimal values summed, 5600 responds to Issix's brand
	}
	
func getLines(_reaction:int, _role:int, _args:Array):
	var lustInterets:LustInterests = getChar(ROLE_TARGET).getLustInterests()
	var likesBrand = lustInterets.getTopicValue("IssixBrand", getChar())
	
	match(_reaction):
		5600:
			if(likesBrand > 0.2):
				addLines([
					"Nice brand, slave. Master treats you well?",
					"I love branded sluts, they are always already trained well.",
					"That brand on your back look so right on you.",
					"Oh? Branded by Issix. Well, I don't mind using someone's toys.",
					"I wish I had my own branded sluts, your Master must be so proud."
				])
			elif(likesBrand < -0.2):
				addLines([
					"Disgusting mark, slavers these days have no dignity, to make someone's body so ugly.",
					"Property of Issix? This mark surely brings your value down.",
					"I hate when sluts come with an ugly mark like this.",
					"Meh, you'd look better without that mark on your back."
				])
