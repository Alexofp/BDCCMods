extends SkillBase

func _init():
	id = "IssixMiscellaneous"

func getVisibleName():
	return "Miscellaneous"

func getVisibleDescription():
	return "Miscellaneous"

# func _on_levelChanged(idParam, newLevel):
# 	if(id != idParam):
# 		return
	# unlockFeatures(newLevel)

# func unlockFeatures(level):
# 	if level >= 4 and GM.main.getModuleFlag("IssixModule", "Did_Task_Today") == null:
# 		GM.main.setModuleFlag("IssixModule", "Did_Task_Today", false)
# 		GM.main.addMessage("Pet tasks have been unlocked!")
# 	if level >= 6 and GM.main.getModuleFlag("IssixModule", "Drone_Task_Timeout") == null:
# 		GM.main.setModuleFlag("IssixModule", "Drone_Task_Timeout", 0)
# 		GM.main.addMessage("Drone task has been unlocked!")


func getPerkTiers():
	return [
		[0]
	]

func scripted():
	return true
