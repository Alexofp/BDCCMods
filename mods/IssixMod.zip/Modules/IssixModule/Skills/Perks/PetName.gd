extends PerkBase

var oldName = null

func _init():
	id = "PetName"
	skillGroup = "Pet"

func getVisibleName():
	return "New name"

func getVisibleDescription():
	return "You have received a completely new name from your Master - Seir"

func getSkillTier():
	return 4

func getPicture():
	return "res://Modules/IssixModule/Skills/Images/name.png"

func toggleable():
	return false

func unlockable():
	return false

func hiddenWhenLocked():
	return true

func getOldName():
	return oldName

func runOnceWhenLearned():
	oldName = npc.getName()
	if npc.isPlayer():
		npc.setName("Seir")
		
func canAppearInDungeons():
	return false
	
func saveData():
	var data = .saveData()

	data["oldName"] = oldName

	return data

func loadData(data):
	.loadData(data)
	
	oldName = SAVE.loadVar(data, "oldName", null)
	if GM.pc.getName() != "Seir":
		GM.pc.setName("Seir")
