extends PerkBase

func _init():
	id = "PetBrand"
	skillGroup = "Pet"

func getVisibleName():
	return "Pet brand"

func getVisibleDescription():
	return "You have Issix's brand saying „PROPERTY OF ISSIX” on your lower back"

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/IssixModule/Skills/Images/brand.png"

func toggleable():
	return false

func unlockable():
	return false

func hiddenWhenLocked():
	return true

func hiddenWhenUnlocked():
	return true
	
func canAppearInDungeons():
	return false
	
func isItemRemoved(item):
	if item != null:
		var state = item.getItemState()
		if state != null:
			# Item states are fucked for cases which base game doesn't need to care about'
			return state.isRemoved() or !state.coversBodypart(BodypartSlot.Body)
	return true
	
func allItemsNotCovering(inventory: Inventory):
	for item in inventory.getEquippedItems():
		if inventory.equippedItems[item].coversBodypart(BodypartSlot.Body):
			return false
	return true
	
# I'm getting mad in here
func listUndressed(sexEngine: SexEngine):
	var undressedSubs := []
	for subID in sexEngine.subs:
		var subInfo = sexEngine.subs[subID]
		var character = subInfo.getChar()
		if(character.hasBodypart(BodypartSlot.Body) and !sexEngine.revealedBodyparts[subID].has(BodypartSlot.Body) and character.hasPerk("PetBrand")):
			if allItemsNotCovering(character.getInventory()):
				sexEngine.revealedBodyparts[subID][BodypartSlot.Body] = true
				undressedSubs.append(character.getID())
	return undressedSubs
	
func domReactToSubBodypart(_bodypart, _sexEngine, _domInfo, _subInfo):
	var possible = []
	
	if(_bodypart is BodypartBody):
		var sub = _subInfo.getChar()
		var dom = _domInfo.getChar()
		var lustInterets:LustInterests = dom.getLustInterests()
		var likesBrand = lustInterets.getTopicValue("IssixBrand", sub)
		print("Likes brand in:"+str(likesBrand))
		if(likesBrand > 0.2):
			possible.append_array([
				"Nice brand, slave. Master treats you well?",
				"I love branded sluts, they are always already trained well.",
				"That brand on your back look so right on you.",
				"Oh? Branded by Issix. Well, I don't mind using someone's toys.",
				"I wish I had my own branded sluts, your Master must be so proud."
			])
		elif(likesBrand < -0.2):
			possible.append_array([
				"Disgusting mark, slavers these days have no dignity, to make someone's body so ugly.",
				"Property of Issix? This mark surely brings your value down.",
				"I hate when sluts come with an ugly mark like this.",
				"Meh, you'd look better without that mark on your back."
			])
	
	if possible.size():
		return RNG.pick(possible)

	
func processSexTurnContex(context={}):
	var sexEngine: SexEngine = context.get("sexEngine", null)
	if sexEngine:
		if !sexEngine.doms.has("issix"):
			var undressed = listUndressed(sexEngine)
			for subID in undressed:
				var domID = RNG.pick(sexEngine.doms.keys())
				var comment = domReactToSubBodypart(sexEngine.subs[subID].getChar().getBodypart(BodypartSlot.Body), sexEngine, sexEngine.doms[domID], sexEngine.subs[subID])
				if comment:
					sexEngine.addText("[say="+domID+"]"+comment+"[/say]", domID, subID)
					
	
# This is sadly not doable for now due to limitations in Godot's class loading'
func onSexStarted(context={}):
	# Hijack SexVoice object for each participant so we can add our own reactions, this is not friendly from POV of compatibility, though we could easily make it more compatible by 
	var sexEngine: SexEngine = context.get("sexEngine", null)
	if sexEngine:
		for character in sexEngine.subs.values():
			if !character.getChar().hasPerk("PetBrand"):
				return
		for subID in sexEngine.subs:
			var character = sexEngine.subs[subID].getChar()
			if character.hasBodypart(BodypartSlot.Body):
				if !character.isBodypartCovered(BodypartSlot.Body):
					sexEngine.revealedBodyparts[subID][BodypartSlot.Body] = true
					var domID = RNG.pick(sexEngine.doms.keys())
					var comment = domReactToSubBodypart(sexEngine.subs[subID].getChar().getBodypart(BodypartSlot.Body), sexEngine, sexEngine.doms[domID], sexEngine.subs[subID])
					if comment:
						sexEngine.addText("[say="+domID+"]"+comment+"[/say]", domID, subID)
