extends PerkBase

func _init():
	id = "Bimbo"
	skillGroup = "IssixMiscellaneous"

func getVisibleName():
	return "Bimbo"

func getVisibleDescription():
	return "You've became a bimbo and now speak like one"

func getSkillTier():
	return 0

func getPicture():
	return "res://Modules/IssixModule/Skills/Images/bimbo.png"

func toggleable():
	return false

func unlockable():
	return false

func canAppearInDungeons():
	return false
	
func hiddenWhenLocked() -> bool:
	return true
	
func hiddenWhenUnlocked() -> bool:
	return true

func getBuffs():
	return [
		buff(Buff.ReceivedLustDamageBuff, [30]),
		buff(Buff.AmbientLustBuff, [50]),
		buff(Buff.ExposureBuff, [50]),
		buff(Buff.StatBuff, [Stat.Sexiness, 3])
	]