extends BaseStageScene3D

# Original taken from base game WoodenHorseSolo.tscn/.gd in /Player/StageScene3D/Scenes/WoodenHorseSolo.tscn/.gd
# Made by Rahi and repurposed by Frisk for scene in IssixMod

onready var animationTree = $AnimationTree
onready var doll = $Doll3D

func _init():
	id = "BrandingTable"

func _ready():
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer())
	animationTree.active = true

func updateSubAnims():
	pass

func playAnimation(animID, _args = {}):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)

	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})

	updateSubAnims()
	
	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)
	
	var state_machine = animationTree["parameters/StateMachine/playback"]

	if(animID == "idle"):
		state_machine.travel("WoodenHorseIdle-loop")
	if(animID == "bent"):
		state_machine.travel("WoodenHorseBentIdle-loop")
	if(animID == "lightstruggle"):
		state_machine.travel("WoodenHorseStruggleLight-loop")
	if(animID == "struggle"):
		state_machine.travel("WoodenHorseStruggle-loop")

func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]

	if(doll.getCharacterID() != firstDoll):
		return false
	return true

func getSupportedStates():
	return ["idle", "lightstruggle", "struggle"]

func getVarNpcs():
	return ["pc"]
