static func ofModule(moduleId):
	return GlobalRegistry.getModules()[moduleId]

static func getSkinWord() -> String:
	return ofModule("IssixModule").characterCoverage
	
static func skinIs() -> String:
	return "are" if ofModule("IssixModule").characterCoverage.ends_with("s") else "is"

# Check if there is enough of fluid in the Inventory
static func hasFluid(inventory: Inventory, fluidId: String, fluidAmount: float):
	var foundAmount := 0.0
	for item in inventory.getAllItems():
		if item.fluids == null:
			continue
		var fluids: Fluids = item.fluids
		foundAmount += fluids.getFluidAmountByType().get(fluidId, 0.0)
		if foundAmount >= fluidAmount:
			return true
	return false
	
# Remove given amount of fluid from the inventory (first item that has it) (why is this not in base game aaaaaaaa)
# Returns true if all fluids have been removed and false if it couldn't match the full amount'
static func removeFluid(inventory: Inventory, fluidId: String, fluidAmount: float):
	for item in inventory.getAllItems():
		var removedFromItem := 0.0
		if item.fluids == null:
			continue
		for fluid in item.fluids.contents:
			if fluid["fluidType"] == fluidId:
				var toRemove = min(fluidAmount, fluid["amount"])
				fluidAmount -= toRemove
				fluid["amount"] = fluid["amount"] - toRemove
				removedFromItem += toRemove
		if removedFromItem > 0.0:
			item.fluids.removeEmptyInternalEntries()
			item.fluids.emit_signal("contentsChanged", item.fluids.cachedFluidsAmount-removedFromItem, item.fluids.cachedFluidsAmount)
			if fluidAmount < 0.1:
				return true
	return false

# Undress the player of everything but unremovable restraints
static func undressPlayerExceptCollar(name: String):
	for slot in GM.pc.getInventory().getEquippedItems():  # Force unequip all items, why is there getEquippedItems and getAllEquippedItems doing the same thing lol
		var item = GM.pc.getInventory()["equippedItems"][slot]
		if item.isRestraint() and item.getRestraintData() is RestraintUnremovable:  # ignore collar
			continue
		GM.main.addMessage(name+" took off your "+item.getVisibleName()+".")
		GM.pc.getInventory().unequipSlot(slot)
	return

# Check if character is wearing PERMANENT restraints on both vagina and penis
static func hasPermanentChasityOnBoth(characterID: String):
	var blocked_penis = false
	var character = GlobalRegistry.getCharacter(characterID)
	if character == null:
		return null
	if character.hasPenis():
		var item = character.getInventory().getEquippedItem(BodypartSlot.Penis)
		if item != null and item.isRestraint() and item.getRestraintData() is RestraintUnremovable:
			blocked_penis = true
	if character.hasVagina():
		var item = character.getInventory().getEquippedItem(BodypartSlot.Vagina)
		if item != null and item.isRestraint() and item.getRestraintData() is RestraintUnremovable:
			if blocked_penis:
				return true
		blocked_penis = false
	return blocked_penis


# Check if player has any restraints that would be considered unremovable or has any clothes
static func isPlayerSuperNaked() -> bool:
	for slot in GM.pc.getInventory().getEquippedItems():
		var item = GM.pc.getInventory()["equippedItems"][slot]
		if item.isRestraint() and item.getRestraintData() is RestraintUnremovable:  # ignore collar
			continue
		return false
	return GM.pc.isFullyNaked()


# Can you believe it's not in base game? Function to learn interests in array of certain character
static func learnInterestOf(characterID: String, interests: Array):
	var character = GlobalRegistry.getCharacter(characterID)
	if character == null:
		return
	var lust_interests = character.getLustInterests()
	var player_knows = lust_interests.getPlayerKnowledge()
	for interest in interests:
		if !lust_interests.interests.has(interest):
			continue
		if(!player_knows.has(interest) || player_knows[interest] != lust_interests.interests[interest]):
			player_knows[interest] = lust_interests.interests[interest]

# Find a pet name for the player
static func getPlayerPetName():
	var species = GM.pc.getSpecies().duplicate()
	var foxModuleAPI = ofModule("IssixModule").foxModuleAPI
	if foxModuleAPI != null and foxModuleAPI.isFoxLibAtLeast(0, 8, 0):
		var FoxGameRegistry = load("res://FoxLib/FoxGameRegistry.gd")
		var speciesLength = species.size()
		var index = 0
		while index < speciesLength:
			species[index] = FoxGameRegistry.getVanillaSpeciesEquivalent(species[index])
			index = index + 1
	if Species.Canine in species:
		return "puppy"
	elif Species.Feline in species:
		return "kitty"
	elif Species.Equine in species:
		return "pony"
	else:
		return "pet"

# If player is enslaved
static func checkIfPCEnslaved() -> bool:
	return GM.main.getModuleFlag("IssixModule", "PC_Enslavement_Role", 0) >= 1

# Return average time for which there should be a walk
static func averageWalkTime() -> int:
	return 9

static func untilNextWalk(fake = false) -> int:
	var last_walk = GM.main.getModuleFlag("IssixModule", "Last_Walk", GM.main.getDays())
	var rng = RandomNumberGenerator.new()
	rng.seed = last_walk
	var variation = rng.randi_range(-2, 2)
	if fake:
		variation += rng.randi_range(-1, 1)
	return last_walk + averageWalkTime() + variation - GM.main.getDays()
	
# Check if a state exists inside stateKey dict flag storage
static func checkIfAchieved(flagName: String, stateKey: String) -> bool:
	return GM.main.getModuleFlag("IssixModule", flagName, {}).has(stateKey)

static func returnValueFromStateFlag(flagName: String, stateKey: String, default=null):
	return GM.main.getModuleFlag("IssixModule", flagName, {}).get(stateKey, default)
	
static func increaseValueFromStateFlag(flagName: String, stateKey: String, amount=1, default=0):
	var dict = GM.main.getModuleFlag("IssixModule", flagName, {})
	dict[stateKey] = int(dict[stateKey] + amount) if dict.has(stateKey) else int(default + amount)
	GM.main.setModuleFlag("IssixModule", flagName, dict)

# Modify state of a state dict flag
static func modifyDictStates(flagName: String, stateKey: String, stateValue):
	var states = GM.main.getModuleFlag("IssixModule", flagName, {})
	states[stateKey] = stateValue
	GM.main.setModuleFlag("IssixModule", flagName, states.duplicate(true))

# Add Issix's mood'
static func addIssixMood(mood: int):
	GM.main.setModuleFlag("IssixModule", "Issix_Mood", clamp(GM.main.getModuleFlag("IssixModule", "Issix_Mood", 50)+mood, 0, 100))

# Get item that covers given inventory slot
static func getBodyCoveringItem(character, bodyslot):
	var equippedItems = character.getInventory().getAllEquippedItems()
	for inventorySlot in equippedItems:
		var item = equippedItems[inventorySlot]
		if(item.coversBodypart(bodyslot)):
			return item

	return null
	
# Unequip restraints from given inventory slots
static func undressBlockingRestraints(character, inventorySlots: Array):
	var result = false
	for item in character.getInventory().getEquippedRestraints():
		if item.getClothingSlot() in inventorySlots and not item.getRestraintData() is RestraintUnremovable:
			result = !character.getInventory().unequipItem(item) or result
	return !result
			

# Verify requirements for pawns, requirements is array of two arrays, first one are methods which should return true in CharacterPawn obj and second is same but for BaseCharacter
static func verifyRequirements(pawn: CharacterPawn, requirements: Array) -> bool:
	if pawn.isPlayer():
		return false
	for method in requirements[0]:
		if !pawn.has_method(method) or !pawn.call(method):
			return false
	var base_character = pawn.getCharacter()
	for method in requirements[1]:
		base_character.has_method(method)
		if !base_character.call(method):
			return false
	return true

# Find pawns that succeed requirements in list of lists
# It returns list of lists of pawnIDs like dynamicnpc32
static func findPawns(requirements) -> Array:
	var all_pawns = GM.main.IS.getPawns()
	var results = []
	for pawn_requirement in requirements:
		var meet_criteria = []
		for pawn in all_pawns:
			if !verifyRequirements(all_pawns[pawn], pawn_requirement):
				continue
			meet_criteria.append(pawn)
		results.append(meet_criteria)
	return results

# Pick a unique random item for each of arrays
static func pick_unique_one(input_array: Array) -> Array:
	var sizes_of_arrays = []  # We will need to compare sized of arrays to first process smallest arrays
	var processed_array = input_array.duplicate(true)
	for array in input_array:
		sizes_of_arrays.append(array.size())

	for _item in range(input_array.size()):
		var smallest_array = sizes_of_arrays.min()
		var index = sizes_of_arrays.find(smallest_array)
		for _i in range(smallest_array):
			var pick = processed_array[index].pick_random()
			if pick in processed_array:
				processed_array[index].erase(pick)
				continue
			processed_array[index] = pick
			break
		if processed_array[index] is Array:
			processed_array[index] = null
		sizes_of_arrays[index] = 999999
	return processed_array

# This is a replacement for addButtonWithChecks which is entirely non-flexible in terms of adding new checks
static func addButtonCheckNoncon(text: String, tooltip: String, method: String, args=[]):
	if GM.main.getModuleFlag("IssixModule", "Noncon_Mode_Enabled", false) == true:
		GM.ui.addDisabledButton(text, RNG.pick(["That's not what Master wants to hear", "I don't want to be a bad pet!", "This isn't available to me, good pet obeys"]))
	else:
		GM.ui.addButton(text, tooltip, method, args)
		
# As a result of hooking with some scene hooks our buttons end up after Back/Leave buttons. This method looks for such case and puts the back button back as the last one
# I'm unsure why it works, I'd expect the new dict to require duplication but thankfully it doesn't, hope it never causes issues
static func fixBackButton(back_button=["Back", "Leave"]):
	var new_dict = {}
	var move_back = []
	var keys_sorted = GM.ui.options.keys()
	keys_sorted.sort()
	for optionIndex in keys_sorted:
		if GM.ui.options[optionIndex].size() > 1:
			if GM.ui.options[optionIndex][1] in back_button:
				move_back.append(GM.ui.options[optionIndex])
			else:
				new_dict[new_dict.size()] = GM.ui.options[optionIndex]
	for item in move_back:
		new_dict[new_dict.size()] = item
	GM.ui.options = new_dict
	GM.ui.queueUpdate()

# Undress all items covering slot
static func undressForBodypart(character: BaseCharacter, slot: String, who = "You", remove_restraints=true, return_if_restraint=false, only_messages=false):
	var all_items = []
	var inventory: Inventory = character.getInventory()
	var any_unequipped = false
	for inventorySlot in InventorySlot.getAll():
		if(!inventory.hasSlotEquipped(inventorySlot)):
			continue

		var item = inventory.getEquippedItem(inventorySlot)
		if(item.coversBodypart(slot)):
			all_items.append(item)

	if remove_restraints == false and return_if_restraint:
		for item in all_items:
			if item.isRestraint():
				return null

	for item in all_items:
		if (item.isRestraint() and remove_restraints == false) or (item.isRestraint() and item.getRestraintData().hasSmartLock()):
			continue

		GM.main.addMessage(who + " " + item.getTakingOffStringLong(true if who == "You" else false))
		if only_messages:
			inventory.unequipItem(item)
		any_unequipped = true
	return any_unequipped
	
static func numberToTextual(number: int) -> String:
	match number:
		0:
			return "zero"
		1:
			return "one"
		2:
			return "two"
		3:
			return "three"
		4:
			return "four"
		5:
			return "five"
		6:
			return "six"
		7:
			return "seven"
		8:
			return "eight"
		9:
			return "nine"
		_:
			return "???"
	
# Adapted from EventBase, used for scenes
static func checkCharacterBusy(_checkID, messageifbusy="", characterName = ""):
	var checkData = null
	if(GM.ES):
		checkData = GM.ES.eventCheck(_checkID)
		
	if(checkData == null):
		return false
	
	if(checkData is Dictionary && checkData.has("text")):
		GM.ui.say(checkData["text"] + "\n\n")
	elif messageifbusy != "":
		GM.ui.say(messageifbusy + "\n\n")
	if(characterName != ""):
		GM.ui.addDisabledButton(characterName, "They are not here")
	return true
	
# Gets pet location
static func getPetLocation(pet: String):
	var checkData = null
	if(GM.ES):
		checkData = GM.ES.eventCheck(pet.capitalize()+"Busy")
		
	if checkData == null or checkData.get("loc", null) == null:
		return "hall_ne_corner"
	else:
		return checkData["loc"]
	
static func calculateParasiteFeedingTime() -> int:
	var amount_of_days: int = GM.main.getDays() - GM.main.getModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", 0)
	return amount_of_days * 40
	
static func calculateParasiteEffectLength() -> int:
	var amount_of_days: int = GM.main.getDays() - GM.main.getModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", 0)
	return (((amount_of_days * 3) + 1) * 60 * 60) + (RNG.randi_range(-5 * amount_of_days, (amount_of_days * 5)) * 60)
	
# Color a button, not reliable, colors future button on that index too?
static func colorButton(index: int, color: Color):
	GM.ui.buttons[index].add_color_override("font_color", color)
	GM.ui.buttons[index].add_color_override("font_color_hover", color)
	
# It's criminal this is lacking in Godot
static func sum(data: Array):
	var sum = 0
	for i in data:
		sum += i
	return sum
	
static func avg(data: Array):
	return sum(data)/data.size()
	
# Return common elements between two Arrays (if elements from b are in array a)
static func arrayIntersection(a: Array, b: Array):
	var common = []
	for item in b:
		if a.has(item):
			common.append(item)
	return common

# Check for non-null/non-empty values inside array
static func any(item):
	if item is Array:
		for i in item:
			if i == null:
				continue
			if i is Array:
				if i.size() == 0:
					continue
				return true
			if i is Dictionary:
				if !i.empty():
					return true
		return false

static func higherEqualThan(arr: Array, than: int):
	var count = 0
	var temp_array = arr.duplicate()
	temp_array.sort()
	for number in temp_array:
		if number <= than:
			count += 1
		else:
			break
	return count

# Dictionary for boundaries where new scenes are unlocked
const pet_affections = {"lamia": ["Lamia_Times_Helped", [3, 8, 13, 18], 10], "hiisi": ["Hiisi_Affection", [3, 6, 9, 12], 12], "azazel": ["Azazel_Affection_given", [3, 6, 9, 12], 8]}
static func increasePetAffection(pet, amount=1):
	var pet_info = pet_affections.get(pet)
	if pet_info == null:
		return
	var current = GM.main.getModuleFlag("IssixModule", pet_info[0], 0)
	if pet == "azazel" and checkIfPCEnslaved():
		pass
	else:
		if amount > 0:
			match higherEqualThan(pet_info[1], current+amount) - higherEqualThan(pet_info[1], current):  # Couldn't think of anything more clever
				0:
					pass
				1:
					GM.main.addMessage("New scene has been unlocked for "+pet.capitalize())
				_:
					GM.main.addMessage("New scenes have been unlocked for "+pet.capitalize())
		if current+amount >= pet_info[2] and current < pet_info[2] and checkIfPCEnslaved() == false:
			GM.main.addMessage(pet.capitalize()+"'s affection makes him no longer object to you becoming Issix's pet.")
	GM.main.setModuleFlag("IssixModule", pet_info[0], current+amount)
		
static func describeBodypart(character, bodypartslot):
	var bodypart = character.getBodypart(bodypartslot)
	if bodypart == null:
		return "[color=red]ERROR: NO BODYPART "+str(bodypartslot)+"[/color]"
	return bodypart.getName().to_lower().rstrip("0123456789")
	
static func all(arr: Array) -> bool:
	for element in arr:
		if element == false:
			return false
	return true

# Remove all writings on given character zone
static func removeWritingsFrom(ch: BaseCharacter, zone: int):
	var theEffect = ch.getEffect(StatusEffect.HasBodyWritings)
	if theEffect:
		theEffect.writings.erase(zone)
		theEffect.permWritings.erase(zone)
		
# Functions for quick check whether aggro/tiredness functionalities are set by the player
static func vibrationsCranked() -> bool:
	var tiring = returnValueFromStateFlag("OpenClue_Status", "pulsatorsWU", 14)
	return tiring > 15 or tiring < 13
	
static func oxygenCranked() -> bool:
	return returnValueFromStateFlag("OpenClue_Status", "oxygenNm", 3200) > 3300
	
static func isTiring() -> bool:
	return returnValueFromStateFlag("OpenClue_Status", "oxygenNm", 3200) < 3100

# Mark entire day as completed for the player
static func markDayAsComplete():
	var time_set = GM.main.getModuleFlag("IssixModule", "Is_Player_Forced_Today") if GM.main.getModuleFlag("IssixModule", "Is_Player_Forced_Today", 0) > 0 else 60*60
	if GM.main.getModuleFlag("IssixModule", "Pet_Time_Interaction_Today", 0) < time_set:
		GM.main.setModuleFlag("IssixModule", "Pet_Time_Interaction_Today", time_set)

static func playSound(name, type=1):
	if ofModule("IssixModule").IssixAudio[name] != null:
		if type == 1:
			ofModule("IssixModule").IssixAudio[name].playAsSFX()
		if type == 2:
			ofModule("IssixModule").IssixAudio[name].playAsBGM()
		
static func stopAudio(name):
	if ofModule("IssixModule").IssixAudio[name] != null:
		ofModule("IssixModule").IssixAudio[name].stopBGM()

# Never let Fox2Code know I did this, they will skin me alive, there is no way to do per track specific volume though, it's all global :(
static func setAudioVolume(volume):
	if volume == null:
		volume = ofModule("FoxLib").audioVolume
	ofModule("FoxLib").FoxLibAudioManager.setVolume(volume)
	
# Taken from PawnInteractionBase.gd, related_check switches whether to ignore pawns with special relationship to the player
static func findFreePawnsNearby(distance: int, related_check = false) -> Array:
	var result:Array = []

	var pawns = GM.main.IS.getPawnsNear(GM.pc.getLocation(), distance)
	for pawn in pawns:
		if(!pawn.canBeInterrupted() or !pawn.isInmate() or pawn.isPlayer()) or (related_check and (pawn.isPlayerOwner() or pawn.isSlaveToPlayer())):
			continue
		result.append(pawn.charID)
	return result

