extends Character

func _init():
	id = "rowan"
	npcHasMenstrualCycle = false
	npcCharacterType = CharacterType.Inmate
	
	pickedSkin="SimpleSpottedSkin"
	pickedSkinRColor=Color("ffc8b2b2")
	pickedSkinGColor=Color("ffa18e8e")
	pickedSkinBColor=Color("ff6e4f93")
	npcSkinData={
	"head": {"skin": "CunningSkin",},
	"hair": {"r": Color("ff1d1818"),"g": Color("ff645a58"),"b": Color("ffffffff"),},
	"legs": {"skin": "SphinxCatSkin",},
	}
	# npcPersonality = {
	# 	PersonalityStat.Brat: 0.5,
	# 	PersonalityStat.Mean: 0.2,
	# 	PersonalityStat.Subby: -1.0,
	# 	PersonalityStat.Impatient: 0.1,
	# 	PersonalityStat.Naive: -1.0,
	# 	PersonalityStat.Coward: -0.7,
	# }
	# npcLevel = 50
	# npcBasePain = 400
	# npcBaseLust = 400
	# npcBaseStamina = 500
	# npcArmor = {
	# 	DamageType.Physical: 15,
	# 	DamageType.Lust: 30,
	# }
	# npcStats = {
	# 	Stat.Strength: 40,
	# 	Stat.Vitality: 20,
	# 	Stat.Sexiness: 10
	# }
	
func _getName():
	return "Rowan"

func getGender():
	return Gender.Androgynous

func getSmallDescription() -> String:
	return ""

func getInmateNumber() -> String:
	return "9228"
	
func getFullInmateNumber() -> String:
	return "P-" + getInmateNumber()

func getSpecies():
	return [Species.Human]

func getThickness() -> int:
	return 20

func getFemininity() -> int:
	return 40

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanhead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("messyhair2"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("humanears"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("buffarms"))
	var breasts = GlobalRegistry.createBodypart("malebreasts")
	breasts.size = 0
	giveBodypartUnlessSame(breasts)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("vagina"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("plantilegs"))


func getLootTable(_battleName):
	return InmateLoot.new()

func onGivingBirth(_impregnatedEggCells: Array, _newkids: Array):
	.onGivingBirth(_impregnatedEggCells, _newkids)

func getBirthWaitTime():
	return 60*60*24*10

func getDefaultEquipment():
	return ["inmatecollar", "inmateuniform"]
