extends Character

func _init():
	id = "loxia"
	npcHasMenstrualCycle = false
	npcCharacterType = CharacterType.Inmate
	
	pickedSkin="BreezeSkin"
	pickedSkinRColor=Color("ffd5dafd")
	pickedSkinGColor=Color("ffbebebe")
	pickedSkinBColor=Color("ff402824")
	npcSkinData={
	"head": {"skin": "CunningSkin",},
	"hair": {"r": Color("ffb05745"),"g": Color("ffb05745"),"b": Color("ff2288ab"),},
	"penis": {"g": Color("ffff0000"),"b": Color("ff8b0000"),},
	"legs": {"skin": "KidlatSkin","g": Color("ffffffff"),},
	}
	# npcPersonality = {
	# 	PersonalityStat.Brat: 0.5,
	# 	PersonalityStat.Mean: 0.2,
	# 	PersonalityStat.Subby: -1.0,
	# 	PersonalityStat.Impatient: 0.1,
	# 	PersonalityStat.Naive: -1.0,
	# 	PersonalityStat.Coward: -0.7,
	# }
	# npcLevel = 50
	# npcBasePain = 400
	# npcBaseLust = 400
	# npcBaseStamina = 500
	# npcArmor = {
	# 	DamageType.Physical: 15,
	# 	DamageType.Lust: 30,
	# }
	# npcStats = {
	# 	Stat.Strength: 40,
	# 	Stat.Vitality: 20,
	# 	Stat.Sexiness: 10
	# }

	
func _getName():
	return "Lo'xia"

func getGender():
	return Gender.Other
	
func getSmallDescription() -> String:
	return ""

func getInmateNumber() -> String:
	return "9229"
	
func getFullInmateNumber() -> String:
	return "P-" + getInmateNumber()

func getSpecies():
	return [Species.Equine]

func getThickness() -> int:
	return 80

func getFemininity() -> int:
	return 70

func createBodyparts():
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("horsehead"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("longhair"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("horseears"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthrobody"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anthroarms"))
	var breasts = GlobalRegistry.createBodypart("humanbreasts")
	breasts.size = 4
	giveBodypartUnlessSame(breasts)
	var penis = GlobalRegistry.createBodypart("equinepenis")
	penis.lengthCM = 18
	penis.ballsScale = 1.5
	giveBodypartUnlessSame(penis)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("vagina"))
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("anus"))
	var tail = GlobalRegistry.createBodypart("horsetail")
	tail.tailScale = 0.4
	giveBodypartUnlessSame(tail)
	giveBodypartUnlessSame(GlobalRegistry.createBodypart("hoofs"))

func getLootTable(_battleName):
	return InmateLoot.new()

func onGivingBirth(_impregnatedEggCells: Array, _newkids: Array):
	.onGivingBirth(_impregnatedEggCells, _newkids)

func getBirthWaitTime():
	return 60*60*24*10

func getDefaultEquipment():
	return ["inmatecollar", "inmateuniform"]
