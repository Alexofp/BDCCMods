extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "HiisiUndergroundPlantRoom"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "yard_deadend2")

func run(_triggerID, _args):
	if(GM.main.getModuleFlag("IssixModule", "Hiisi_Encounter_scene", 0) > 5):
		if GM.main.getTime() >= 22*60*60:
			if Globals.findFreePawnsNearby(2).size() > 0:
				addDisabledButton("Enter room", "There are still other creatures around, you should wait until they are gone not to compromise the position")
			else:
				addButton("Enter room", "Open the secred doors to Hiisi's underground room", "enterroom")

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "enterroom"):
		runScene("HiisiPlantRoomRegular")
