extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "IssixMeSceneHook"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["MeScene", ""])
	

func run(_triggerID, _args):
	saynn("\n[b]Issix Mod[/b]")
	if !Globals.checkIfPCEnslaved():
		saynn("You are not enslaved by Master Issix.")
		return
	if getModuleFlag("IssixModule", "Is_PC_Corrupted", 0) >= 100:
		saynn("[color=#250a46]You are part of the hive.[/color]")
	
	sayn("Your body "+("bears the mark of your Master Issix, with large „PROPERTY OF ISSIX” branded on your back, right above the {pc.slim} butt" if getModuleFlag("IssixModule", "Issix_Branded_PC", false) else "is free of any brandings")+".")
	sayn("Free will: "+("still there" if !getModuleFlag("IssixModule", "Noncon_Mode_Enabled", false) else "doesn't exist"))
	if GM.pc.hasPerk("Bimbo"):
		sayn("[color=#f79ac0]Mind consumed by thoughts of giggly sex[/color]")
		
	if getModuleFlag("IssixModule", "Gumball_Fetch") in [2, 51] or getModuleFlag("IssixModule", "Quest_Status") == 3:
		sayn("You hold a pack of gumball.")

# 
# func onButton(_method, _args):
# 	if(_method == "main"):
# 		# GM.main.endCurrentScene()
# 		runScene("NovaIssixTalkScene")

func getPriority():
	return 20
