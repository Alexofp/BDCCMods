extends EventBase

# Event for feeding the parasite on one of the pets if player didn't'

func _init():
	id = "LamiaFeedsOnPet"

func registerTriggers(es):
	es.addTrigger(self, "SpecificTimePassed", [15*60*60+30*60])
	es.addEventCheck(self, "AzazelBusy")
	es.addEventCheck(self, "HiisiBusy")
	es.addEventCheck(self, "LamiaBusy")

func run(_triggerID, _args):
	if GM.main.getDays() - getModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", 0) >= 5 and !playerAlreadyFeeding():
		var pet_to_snack_on = getModuleFlag("IssixModule", "Lamia_Parasite_Feeding_Victim", 1)
		if pet_to_snack_on == 1:
			GlobalRegistry.getCharacter("azazel").addEffect("LifeEssenceDrained", [16*60*60-_args[0]])
			if useHerbal():
				GlobalRegistry.getCharacter("azazel").addEffect("HerbalMedicine", [])
		else:
			GlobalRegistry.getCharacter("hiisi").addEffect("LifeEssenceDrained", [16*60*60-_args[0]])
			if useHerbal():
				GlobalRegistry.getCharacter("hiisi").addEffect("HerbalMedicine", [])

func getPriority():
	return 0
	
func playerAlreadyFeeding():
	if GM.main.getCurrentScene().sceneID in ["LamiaParasiteReoccurring", "LamiaStoryScene4"]:
		return true
	return false
	
func useHerbal():
	var inventory: Inventory = GlobalRegistry.getCharacter("lamia").getInventory()
	if inventory.hasItemID("HerbalMedicine"):
		inventory.removeXOfOrDestroy("HerbalMedicine", 1)
		return true
	return false

func eventCheck(_checkID, _args = []):
	if GM.main.getDays() - getModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", 0) >= 5 and GM.main.getTime() >= 15*60*60 and GM.main.getTime() < 18*60*60+(35*60):
		if _checkID == "LamiaBusy":
			return {busy=true,loc="cellblock_orange_issixcell"}
		if _checkID == "AzazelBusy" and getModuleFlag("IssixModule", "Lamia_Parasite_Feeding_Victim", 1) == 1:
			return {busy=true,loc="cellblock_orange_issixcell"}
		if _checkID == "HiisiBusy":  # If Azazel went there then Hiisi is protecting them
			if GM.main.getTime() >= 15*60*60+(15*60*60) and GM.main.getTime() < 18*60*60:
				return {}
			return {busy=true,loc="cellblock_orange_issixcell"}
