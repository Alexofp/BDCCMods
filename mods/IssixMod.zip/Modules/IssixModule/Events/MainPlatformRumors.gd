extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "MainPlatformRumors"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "main_punishment_spot")

func run(_triggerID, _args):
	var pawns = Globals.findFreePawnsNearby(2, true)
	if pawns.size() < 2:
		return false
	var pawnId = pawns[0]
	var pawnId2 = pawns[1]
		
	var dialogues = []
	
	# GENERAL DIALOGUES
	dialogues.append(["[say={pawn}]Maaaan! I've never missed weather so much as I do ever since I ended up in this dump. I'll take the hulking tornadoes and pouring rain over another day of ABSOLUTELY NOTHING.[/say]", 1])
	dialogues.append(["[say={pawn}]The uniform vendor in laundry dyed my shorts in wrong color. I hate this.[/say]", 1])
	dialogues.append(["[say={pawn}]That place near the gym, really need to get there...[/say]", 1])
	dialogues.append(["[say={pawn}]I saw someone phase through the floor yesterday. I have no idea what's going on in this place. I've heard rumors there is alternate dimension full of yellow walls and abandoned office rooms, creepy man, creepy.[/say]", 1])  # Backrooms reference
	dialogues.append(["[say={pawn}]I've heard there is a place where all of the failures from the prison end up in. Full of extreme drugs and fucking. That's how some get the transformatives from, Freaks.[/say]\n\n[say={pawn2}]... You wouldn't know where it is, would you, {{pawn}.name}?[/say]\n\n[say={pawn}]Huh?[/say]", 1])
	dialogues.append(["[say={pawn}]There are multiple maintenance shafts in the prison. But I can never find any. I knew someone who found one, but they disappeared.[/say]", 1])
	dialogues.append(["[say={pawn}]Come here, {{pawn2}.name}.[/say]\nYou can see {{pawn2}.name} approach {{pawn}.name}, then {{pawn}.name} simply puts {{pawn}.his} paw on {{pawn2}.nameS} head, patting it gently on the top.\n[say={pawn}]You are precious just the way you are, sweetheart.[/say]", 1])
	dialogues.append(["You overhear conversation from nearby\n[say={pawn}]Do you ever regret your life choices?[/say]\n[say={pawn2}]Some, for sure.[/say]\n[say={pawn}]What about the one that landed you in this place?[/say]\n[say={pawn2}]I did meet you, so it wasn't that bad of a choice, and besides, while I'm not proud, I'm satisfied with what I did.[/say]\n", 1])
	if GM.main.getModuleFlag("FightClubModule", "AvyGotRekt", false):
		dialogues.append(["[say={pawn}]I'm so glad that the arena has a new Grand Champion, Avy was a cheating ass. Guess bitch had it coming.[/say]", 1])
	else:
		dialogues.append(["[say={pawn}]Avy is a cheating bitch, champion of the arena my ass.[/say]", 1])
	
	dialogues.append(["[say={pawn}]Day after day it feels there are more of inmates here. Why are they throwing them all to this middle of nowhere?", 1])
	if GM.main.getDays() < 5:
		dialogues.append(["[say={pawn}]Did you see that new "+GlobalRegistry.getSpecies(GM.pc.getSpecies()[0]).getVisibleName()+"? {pc.He} is such a meat.", 1])
	elif GM.main.getDays() > 70:
		if GM.pc.getReputation().getRepLevel(RepStat.Alpha) > 4:
			dialogues.append(["[say={pawn}]{pc.name}? Stay away from them, {pawn2.name}. {pc.He} breaks others.[/say]{pawn} looks your way, his face distorting into face full of terror.\n\n[say={pawn}]Oh shoot, I'm outta here![/say]", 1])
		elif GM.pc.getReputation().getRepLevel(RepStat.Alpha) < 0:
			dialogues.append(["[say={pawn}]{pc.name}? Bottom of the ladder, will do anything you ask them, {{pawn2}.name}. Tell {pc.him} you want him to do your laundry and he will come back begging for you to use {pc.him} again.[/say]\n{pawn.name} looks your way, his face lightening up.\n[say={pawn}]Isn't that right, doormat?[/say]", 1])
		if GM.pc.getReputation().getRepLevel(RepStat.Whore) <= -1:
			dialogues.append(["[say={pawn}]Look, it's the holy virgin of the prison![/say]", 1])
		elif GM.pc.getReputation().getRepLevel(RepStat.Whore) >= 9:
			dialogues.append(["[say={pawn}]Hey slut, wanna have fun?[/say]", 0.5])
			dialogues.append(["[say={pawn}]I've never heard of a prison full of sluts before I ended up in here. It's this prison's only redeeming quality. Speaking of which, {pc.name}, fancy a fuck?[/say]", 0.5])
			
	if GM.main.isInPlayerSlavery():
		dialogues.append(["[say={pawn}]Look, {{pawn2}.name}. A slave running loose. Should we capture {pc.him}? Though, you know what, I don't want to get in trouble with someone else's property.[/say]", 1])
	if GM.main.getTime() < 8*60*60:
		dialogues.append(["[say={pawn}]*yawn* It's so early still. I shouldn't leave bed so early.[/say]", 1])
	elif GM.main.getTime() > 21*60*60:
		dialogues.append(["[say={pawn}]*yawn* I'm beat. Gotta hit the hay.[/say]", 1])
	
	# ISSIX MOD DIALOGUES
	if GM.main.getModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 0) == 0:
		match GM.main.getModuleFlag("IssixModule", "Quest_Status"):
			3, 4, 5:
				dialogues.append(["You hear whispers coming from nearby.\n[say={pawn}]Psst, {{pawn2}.name}, it's this {pc.boy}, supposedly Issix wants to claim {pc.him} as {issix.his} own.[/say]", 1])
			6, 7:
				dialogues.append(["You hear whispers coming from nearby.\n[say={pawn}]I've seen Issix lead this {pc.boy} on a leash, {pc.he} is another Issix's pet.[/say]\n[say={pawn2}]Another one? Just how many does he have now?[/say]\n[say={pawn}]Four? Five? I don't know. Don't think this one was a naughty one.[/say]", 1])
	match GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0):
		2, 3, 4, 5:
			dialogues.append(["[say={pawn}]Supposedly someone wants to get Issix.[/say]\n[say={pawn2}]Do they have a death wish or something?[/say]\n[say={pawn}]I don't know, but I'd love to see some entertainment, do you think it will result in a fight?[/say]", 2])
		50:
			dialogues.append(["A conversation plays out between {{pawn}.name} and {{pawn2}.name}.\n[say={pawn}]Dude, no. Do not piss Issix off. I've seen what happens when you do, and you won't like it. It's messed up.[/say]\n[say={pawn2}]I'll take him down.[/say]\n[say={pawn}]Fuck no, you won't, trust me on that. You are going to become another one of {issix.his} pets, just like the last one. Give it up.[/say]", 1])
	
	## SPECIAL DIALOGUES
	if GM.main.getModuleFlag("IssixModule", "Hiisi_Encounter_scene", 1) == 4 and GM.main.getModuleFlag("IssixModule", "Had_Pet_Scene_Today", false) == false:
		dialogues.append(["[say={pawn}]Did you hear that strange music coming from the Prison Yard at night? I swear I'm not hallucinating. One day I lost track of time near the pond and when I headed back to cells I've heard this weird music coming from nowhere! I looked for it everywhere but its as if it was coming from the floor.[/say]", 5.0])

	saynn(RNG.pickWeightedPairs(dialogues).format({"pawn": pawnId, "pawn2": pawnId2}))
	return false


func getPriority():
	return -50  # This is just informational event, it doesn't have high priority
