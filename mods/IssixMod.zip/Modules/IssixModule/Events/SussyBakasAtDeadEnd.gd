extends EventBase

func _init():
	id = "IssixDeadEnd"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "yard_deadend2")
	es.addEventCheck(self, "HiisiBusy")
	es.addEventCheck(self, "IssixBusy")
	es.addEventCheck(self, "AzazelBusy")
	es.addEventCheck(self, "LamiaBusy")

func run(_triggerID, _args):
	if getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) == 5:
		if isTimeRight():
			addButton("Look", "You've arrived at place mentioned in the invitation, look around", "look")
		else:
			addDisabledButton("Look", "Doesn't seem it's the right time")
	elif getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) > 11 and getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) < 14:
		if isTimeRight():
			addButton("Join up", "You are back with required items, approach the waiting couple", "join")
		else:
			addDisabledButton("Join up", "Doesn't seem it's the right time")
	
func isTimeRight():
	return GM.main.getTime() > 22*60*60 and !GM.main.isVeryLate()

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "look"):
		runScene("IssixGettingRidOf")
	if(_method == "join"):
		runScene("IssixFinalTakedown")

func eventCheck(_checkID, _args = []):
	if (getModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 0) == 2 and getModuleFlag("IssixModule", "Quest_Wait_Another_Day") == true):
		return {busy=true}
