extends EventBase

func _init():
	id = "IssixPlayerSleeps"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SleepInCell)

func react(_triggerID, _args):
	if(getModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 0) == 1 and getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) == 3):
		runScene("IssixChasesBadPlayer")
		return true
		
	if GM.pc.getInventory().hasItemIDEquipped("AzazelsPlushie") and !GM.pc.getInventory().getEquippedItem(InventorySlot.Unique).isEmpty():
		if GM.main.getModuleFlag("IssixModule", "Plushie_Disabled_Sleep_Scene", false):
			GM.pc.addEffect("AzazelsPlushie", [GM.pc.getInventory().getEquippedItemByID("AzazelsPlushie")])
		else:
			runScene("PlushieSleepSummary")
			return true
		
	return false
	
func getPriority():
	return 40
