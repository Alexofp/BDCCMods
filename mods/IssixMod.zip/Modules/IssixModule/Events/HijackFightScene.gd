extends EventBase

func _init():
	id = "FightSceneIssixFightHijack"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["FightScene", "fighting"])

func run(_triggerID, _args):
	if GM.pc.hasEffect("InventoryBlocked"):
		for option in GM.ui.options:
			if GM.ui.options[option][1] == "Inventory":
				GM.ui.addDisabledButtonAt(option, "Inventory", "Issix took your items")
				break
	return true


# func onButton(_method, _args):
# 	if(_method == "main"):
# 		# GM.main.endCurrentScene()
# 		runScene("NovaIssixTalkScene")

func getPriority():
	return 20
