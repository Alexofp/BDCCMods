extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "CellBlockIssixEvents"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func react(_triggerID, _args):
	if !GM.pc.getLocation().begins_with("cellblock_"):
		return false
	if getModuleFlag("IssixModule", "Quest_Wait_Another_Day", false) == false and getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) == 2 and RNG.chance(8.0):
		runScene("UnconciousPetRandom")
		return true

func getPriority():
	return 0

