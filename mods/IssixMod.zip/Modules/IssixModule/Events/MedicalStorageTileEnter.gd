extends EventBase

func _init():
	id = "MedicalStorageSleepinggas"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "medical_storage")

func react(_triggerID, _args):
	if GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) > 5 and GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) < 9:
		runScene("GrabSleepingGas")
		return true

	return false


func getPriority():
	return 0
