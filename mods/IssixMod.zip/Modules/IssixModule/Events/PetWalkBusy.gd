extends EventBase

# Event for feeding the parasite on one of the pets if player didn't'
const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "PetWalkBusyEvent"

func registerTriggers(es):
	es.addEventCheck(self, "AzazelBusy")
	es.addEventCheck(self, "HiisiBusy")
	es.addEventCheck(self, "LamiaBusy")
	es.addEventCheck(self, "IssixBusy")

func getPriority():
	return 0
	

func eventCheck(_checkID, _args = []):
	if Globals.untilNextWalk() == 0 and 17 * 60 * 60 < GM.main.getTime() and 20 * 60 * 60 > GM.main.getTime():
		return {busy=true,loc="yard_waterfall"}
