extends EventBase

func _init():
	id = "MedicalLabChemicals"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "med_researchlab")

func react(_triggerID, _args):
	if GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) == 6 or GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) == 11:
		runScene("GrabChemicals")
		return true

	return false


func getPriority():
	return 0
