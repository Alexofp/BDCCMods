extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "IssixToiletScene"

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["ToiletScene", "fillmenu"])

func run(_triggerID, _args):
	if(GM.pc.getInventory().getItemsWithTag(ItemTag.CanPeeInto).size() == 0):
		addDisabledButton("Pour water..", "You don't have any bottles to pour water into")
	else:
		addButton("Pour water..", "Pour water into one of your bottles", "pourwater")
	Globals.fixBackButton()

func onButton(_method, _args):
	if(_method == "pourwater"):
		# GM.main.endCurrentScene()
		runScene("IssixToiletUseScene")

func getPriority():
	return 20
