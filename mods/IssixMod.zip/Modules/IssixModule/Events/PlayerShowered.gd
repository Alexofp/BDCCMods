extends EventBase

func _init():
	id = "PCShowersMark"

func registerTriggers(es):
	es.addTrigger(self, Trigger.TakingAShower)

func _run():
	GM.main.setModuleFlag("IssixModule", "Player_Showered_Since_Last", true)