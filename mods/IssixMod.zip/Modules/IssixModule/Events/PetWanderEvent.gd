extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "AzazelCorruptionAttemptEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func react(_triggerID, _args):
	# If player unwelcome at the corner
	if getModuleFlag("IssixModule", "Unwelcome_At_Corner", false):
		return false
	if not (GM.pc.getLocation().begins_with("main_hall") or GM.pc.getLocation().begins_with("main_stairs_") or (GM.pc.getLocation() in ["main_bathroom1", "hall_ne_corner"])) or GM.main.isVeryLate():
		return false
	if GM.main.getModuleFlag("IssixModule", "Had_Pet_Scene_Today", false) == false:
		if activateHiisiScenes():
			return true
	if GM.pc.getLocation() == "hall_ne_corner":
		return false
	if activateOtherScenes():
		return true
	# BEFORE ENSLAVEMENT
	if not (GM.main.getModuleFlag("IssixModule", "Quest_Status", 0) < 1) or GM.main.getModuleFlag("IssixModule", "Issix_Anger_Noncon", 0) > 2:  # Do not show those if player started the quest as Azazel doesn't have a reason to corrupt the player or PC has been an asshole to Azazel
		return false
	return activateAzazelScenes()

func activateOtherScenes():
	# Mindless pet scene
	if GM.main.getModuleFlag("IssixModule" ,"Mindlessness_Walkies_Status", 0) == 1 and RNG.chance(3):
		runScene("NonconAltIntro")
		return true
		
	if GM.main.getModuleFlag("IssixModule", "Quest_Status", 0) < 1 and GM.main.getModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 0) == 0 and GM.main.getModuleFlag("IssixModule", "Pets_Introduced", false) == true and GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) < 2 and GM.main.getModuleFlag("IssixModule", "Had_Pet_Scene_Today", false) == false and RNG.chance(2):
		runScene("AzazelCatchUpWith", [Globals.pick_unique_one(Globals.findPawns([[["isInmate"], []]]))[0]])
		GM.main.setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true) 
		return true

func activateHiisiScenes() -> bool:
	if GM.main.getModuleFlag("IssixModule", "Susipicious_Hiisi_Scene_Occured") == false:
		runScene("HiisiAfterNonconAsk")
		return true
	var scene_index = GM.main.getModuleFlag("IssixModule", "Hiisi_Encounter_scene", 1)
	if scene_index == -1 or GM.main.getModuleFlag("IssixModule", "Hiisi_Affection", -1) < scene_index*3 or scene_index > 4:
		return false
	if scene_index != 3 and GM.pc.getLocation() == "hall_ne_corner":  # This scene only shows on that tile
		return false
	if scene_index == 1 and RNG.chance(5.0):  # Different conditions per Hiisi's scenes
		var pawns = Globals.findFreePawnsNearby(2)
		if pawns.size() > 1:
			GM.main.setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
			runScene("HiisiWanderScene1", [RNG.pick(pawns)])
			return true
	elif scene_index == 2 and RNG.chance(5.0):
		if GM.pc.getLocation() in ["main_bathroom1"]:
			return false
		var path = GM.world.calculatePath(GM.pc.getLocation(), "main_bathroom1")
		GM.main.setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		GM.pc.setLocation(path[1])
		runScene("HiisiWanderScene2")
		return true
	elif scene_index == 3 and GM.pc.getLocation() == "hall_ne_corner" and RNG.chance(5.0):
		runScene("HiisiWanderScene3")
		return true
	elif scene_index == 4 and GM.pc.getLocation() == "yard_deadend2" and GM.main.getTime() > 22*60*60:
		runScene("HiisiWanderScene4")
		return true
	return false

func activateAzazelScenes() -> bool:
	if GM.main.getModuleFlag("IssixModule", "Had_Pet_Scene_Today", false) == false and RNG.chance(3.0):
		var scene_index = GM.main.getModuleFlag("IssixModule", "Azazel_Corruption_Scene", 1)
		if scene_index == -1 or GM.main.getModuleFlag("IssixModule", "Azazel_Affection_given", -1) < scene_index*3 or scene_index > 4:  # Player disabled corruption scenes, their affection score is too low or we ran out of them
			return false
		GM.main.setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		runScene("AzazelCorruption"+str(scene_index))
		return true
	return false


func getPriority():
	return 5

