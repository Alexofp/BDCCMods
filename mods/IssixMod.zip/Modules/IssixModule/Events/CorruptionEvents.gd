extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "CorruptionVisionsEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func react(_triggerID, _args):
	if getModuleFlag("IssixModule", "Is_PC_Corrupted", 0) < 100:
		return false
	if RNG.chance(99.87):
		return false
	
	runScene("CorruptedVisionFlashback")
	return true
	
func getPriority():
	return -20

