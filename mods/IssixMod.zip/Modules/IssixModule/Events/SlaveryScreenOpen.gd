extends EventBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "SlaveryScreenOpen"

func registerTriggers(es):
	es.addTrigger(self, Trigger.TalkingToNPC, "slaveryscreen")

func react(_triggerID, _args):
	if GM.main.getModuleFlag("IssixModule", "Lamia_Encounter_scene") == 3 and GM.main.getModuleFlag("IssixModule", "QuestionnaireQ10") == 4 and getModuleFlag("IssixModule", "Lamia_Times_Helped", 0) >= 13 and RNG.chance(13):
		runScene("LamiaStoryScene3")
		GM.main.reRun()
		return true
	if GM.main.getModuleFlag("IssixModule", "Issix_Suggested_Name_Change", false) == false and GM.pc.getSkillLevel("Pet") >= 10:
		runScene("IssixNameSuggestion")
		GM.main.reRun()
		return true
	if GM.main.getModuleFlag("IssixModule", "PC_Should_Be_Punished", 0) != 0:
		var scene_to_play = assignScene("PUNISHMENT")
		if scene_to_play:
			runScene(scene_to_play)
			GM.main.reRun()
			GM.main.setModuleFlag("IssixModule", "PC_Should_Be_Rewarded", 0)
			GM.main.setModuleFlag("IssixModule", "PC_Should_Be_Punished", 0)
			return true
	elif GM.main.getModuleFlag("IssixModule", "PC_Should_Be_Rewarded", 0) != 0:
		var scene_to_play = assignScene("REWARD")
		if scene_to_play:
			runScene(scene_to_play)
			GM.main.reRun()
			GM.main.setModuleFlag("IssixModule", "PC_Should_Be_Rewarded", 0)
			return true
	if OPTIONS.isContentEnabled(ContentType.Watersports) and !GM.pc.getFluids().hasFluidTypeWithCharID("Piss", "issix") and getModuleFlag("IssixModule", "Watersports_Ignore_Today", false) != true:
		if GM.main.getModuleFlag("IssixModule", "Watersports_Scene_Ignored", false):
			GM.pc.cummedOnBy("issix", FluidSource.Pissing, RNG.randf_range(0.4, 0.8))
			addMessage("Issix has marked you with his {issix.piss}")
		else:
			runScene("IssixReapplyPiss")
			GM.main.reRun()
			return true
	# if !GM.main.getModuleFlag("IssixModule", "Shown_Survey", false) and GM.pc.getSkillLevel("Pet") >= 10:
	# 	runScene("10question")
	# 	GM.main.reRun()
	# 	return true

	return false

func assignScene(scene_type: String):
	var possible_scenes: Array = Globals.ofModule("IssixModule").punrew.get(scene_type, null)
	if not possible_scenes:
		return null
	return RNG.pick(possible_scenes)


func onButton(_method, _args):
	pass

func getPriority():
	return 20
