extends QuestBase

func _init():
	id = "IssixGumballQuest"

func getVisibleName():
	return "Fetch Master's gumball"

func getProgress():
	var result = []
	var quest_status = GM.main.getModuleFlag("IssixModule", "Gumball_Fetch", 0)
	if quest_status <= 50:
		if quest_status >= 1:
			result.append("Master has given you a task to retrieve a pack of gumball for him. For this, you have to head to the closet in the Engineering wing for him.")
		if quest_status >= 2:
			result.append("You've obtained the gumball for your Master, now it's just a matter of bringing it back to your Master")
		if quest_status >= 3:
			result.append("You've given the package of gumball to your Master. Yippie!")
		# 50 is gumball is refreshed after quest from 1 has been completed
	else:  # Did not pick up the quest from Issix first
		if quest_status >= 51:
			result.append("You've obtained Master's gumball, you should deliver it shortly...")
		if quest_status >= 52:
			result.append("You've delivered Master's gumball.")
		# 53 is gumball is refreshed after quest from 50+ has been completed
	return result

func isVisible():
	return GM.main.getModuleFlag("IssixModule", "Gumball_Fetch", 0) > 0

func isCompleted():
	return GM.main.getModuleFlag("IssixModule", "Gumball_Fetch", 0) in [3, 52, 53]

func isMainQuest():
	return false
