extends QuestBase

func _init():
	id = "GetRifOfIssix"

func getVisibleName():
	return "Putting the dragon in their place"

func getProgress():
	var quest_status = GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0)
	var result = []
	if(quest_status > 4):
		result.append("You've found a note telling you to appear „at dead end in the yard at 22”. You assume the latter is the time.")
	if quest_status == 100:
		result.append("You've declined to help with getting rid of Issix.")
		return result
		
	if quest_status > 5 and quest_status % 2 == 0:
		result.append("You've agreed to help in making Issix harmless, you'll need to find both the chemicals as well as sleeping gas in medical wing.")
	elif quest_status > 5:
		result.append("You've agreed to help in making Issix harmless, you'll need to find the sleeping gas in medical wing.")
		
	if quest_status == 8:
		result.append("You've found the chemicals, time to find the sleeping gas in the medical wing as well")
	elif quest_status == 11:
		result.append("You've found the sleeping gas, time to find the chemicals in the medical wing as well")
	elif quest_status > 11:
		result.append("You've found all of the required ingredients. Need to meet with the pair at 22 in the dead end path of the yard")
		
	if quest_status == 50:
		result.append("You've been enslaved by Issix after failing to capture {issix.him}.")
		
	return result

func isVisible():
	return GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) > 4

func isCompleted():
	return GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) > 49 or GM.main.getModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 0) > 1

func isMainQuest():
	return false

# quest_status - state (number)
# 5 - found a letter
# 6 - agreed to help 
# 7 - agreed to help with conditions
# 8 - picked up the chemicals (no conditions)


# 11 - picked up sleeping gas (no conditions)
# 12 - picked up sleeping gas with conditions (all cleared)
# 13 - picked up both sleeping gas and chemicals (no conditions, all cleared)

# chemicals add 2 6 or 11
# sleeping gas adds 5 <6, 8>
# Complete condition is <12, 13>

# 50 is when everything is done and ended and Issix enslaved the player
