extends WorldEditBase

func _init():
	id = "IssixSecretCellWorldEdit"
	
func apply(world: GameWorld):
	var cell = preload("res://Modules/IssixModule/Floors/Rooms/IssixSecretRoom.tscn").instance()
	world.registerRoom("Cellblock", cell)
	world.floorDict["Cellblock"].add_child(cell)
	disappear(cell)
	# world.cells["Cellblock"][world.applyDirection(cell.getCell(), Direction.South)].canNorth = false

func disappear(cell):
	cell.visible = false

func appear(cell):
	cell.visible = true
