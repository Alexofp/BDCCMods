extends StatusEffectBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var stolen_from = null

const health_relief = ["painkillers", "appleitem"]
const lust_relief = ["AnaphrodisiacPill"]
const stamina_relief = ["EnergyDrink", "appleitem", "Cookie"]

func _init():
	id = "InventoryBlocked"
	isBattleOnly = true
	
func setCharacter(c):
	.setCharacter(c)

func initArgs(_args = []):
	if(_args.size() > 0):
		turns = _args[0]
	else:
		turns = 2
	if _args.size() == 2:
		stolen_from = _args[1]

func processBattleTurn():
	turns -= 1
	if(turns <= 0):
		if character and character.isPlayer():
			GM.main.addMessage("You've managed to get back your inventory from Issix.")
		stop()
	
func onFightEnd(_context = {}):
	stop()

func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()

func gainedInventory() -> bool:
	return stolen_from != null
	
func getStolenInventory() -> Inventory:
	return GlobalRegistry.getCharacter(stolen_from).getInventory()
	
# Return array of 3 arrays with IDs of available relief items inside of inventory, first are pain related, second are lust related third are stamina related
func getAnyReliefItem() -> Array:
	var inv = []
	for item in getStolenInventory().getAllItems():
		inv.append(item.id)
	return [Globals.arrayIntersection(inv, health_relief), Globals.arrayIntersection(inv, lust_relief), Globals.arrayIntersection(inv, stamina_relief)]

func getEffectName():
	if gainedInventory():
		return "Extra inventory"
	return "Missing inventory"

func getEffectDesc():
	if gainedInventory():
		return character.getName() + " has stolen inventory from " + GlobalRegistry.getCharacter(stolen_from).getName()
	return character.getName() + " is currently missing inventory"

func getEffectImage():
	if gainedInventory():
		return "res://Modules/IssixModule/StatusEffects/missinginventorygain.png"
	return "res://Modules/IssixModule/StatusEffects/missinginventorylack.png"

func getIconColor():
	if gainedInventory():
		return IconColorGreen
	return IconColorRed

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	return [
	]

func saveData():
	return {
		"turns": turns,
		"stolen_from": stolen_from
	}

func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 2)
	stolen_from = SAVE.loadVar(_data, "stolen_from", null)
