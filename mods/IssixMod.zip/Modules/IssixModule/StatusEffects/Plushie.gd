extends StatusEffectBase

var lvlProtection = 0
var mode = false

func _init():
	id = "AzazelsPlushie"
	isBattleOnly = false

func initArgs(_args = []):
	var plushie = _args[0]
	if plushie == null:
		stop()
		return
	var data = plushie.getData()
	mode = data[0]
	if data[1] < 0.1:
		stop()
		return

	if mode:
		lvlProtection = clamp(ceil(data[1] / 50), 1, 10)
	else:
		lvlProtection = clamp(ceil(data[1] / 30), 1, 10)
	turns = 60*60*23
	
func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()
		
func getInfo():
	return [mode, lvlProtection]

func getEffectName():
	return "Plushie"

func getEffectDesc():
	return "You feel the protective power of the plushie in your inventory"

func getEffectImage():
	return "res://Modules/IssixModule/Items/Icons/azazelsplushie.png"

func getIconColor():
	return IconColorGreen

func combine(_args = []):
	if(_args.size() > 0):
		turns = max(_args[0], turns)

func getBuffs():
	if mode:
		return [
			buff(Buff.MaxPainBuff, [lvlProtection*10]),
			buff(Buff.AmbientLustBuff, [lvlProtection])
		]
	else:
		return [
			buff(Buff.MaxLustBuff, [lvlProtection*10]),
			buff(Buff.AmbientPainBuff, [lvlProtection])
		]

func saveData():
	return {
		"lvlProtection": lvlProtection,
		"mode": mode,
		"turns": turns
	}

func loadData(_data):
	lvlProtection = SAVE.loadVar(_data, "lvlProtection", 0)
	mode = SAVE.loadVar(_data, "mode", false)
	turns = SAVE.loadVar(_data, "turns", 60*60)
	