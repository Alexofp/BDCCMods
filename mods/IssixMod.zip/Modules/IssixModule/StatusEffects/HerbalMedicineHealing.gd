extends StatusEffectBase

var stacks := []
var herbal_healing = false  # Variable to mark that healing comes from the herbal healing itself so we ignore it in _on_pain_changed

func _init():
	id = "HerbalMedicine"
	isBattleOnly = false
	isSexEngineOnly = false
	
func setCharacter(c):
	.setCharacter(c)
	character.connect("pain_changed", self, "_on_pain_changed")
	
func initArgs(_args = []):
	if(_args.size() > 0):
		stacks.append(_args[0])  # stacks can be null for indefinite working
	else:
		stacks.append(6*60*60)
	stacks.sort()
	clampOrRemove()
# 	
# func processBattleTurn():
# 	clampOrRemove()
	
func processTime(seconds: int):
	for i in range(stacks.size()):
		if stacks[i] == null:
			continue
		stacks[i] = max(stacks[i]-seconds, 0)
	
	clampOrRemove()
	if stacks.size() > 0 and !isOverdosed():
		var amount_to_heal: float = RNG.randf_range(1.0, 2.0) * (seconds / 500.0) * ((stacks.size() * 0.05) + 0.95) # ~1.5 pain per relief per 5 minutes
		amount_to_heal = ceil(amount_to_heal) if RNG.chance((fmod(amount_to_heal, 1.0))*100) else floor(amount_to_heal)
		if amount_to_heal == 0:
			return
		herbal_healing = true
		character.addPain(amount_to_heal as int * (-1 if !isOverdosed() else 1))
		
func processBattleTurn():
	if RNG.chance(30):
		var heal: int = RNG.randi_range(1, 2)
		character.addPain(heal as int * (-1 if !isOverdosed() else 1))
		herbal_healing = true
		GM.main.addMessage("-"+str(heal)+" pain removed thanks to effects of herbal medicine.")
	
	
func _on_pain_changed(after, before):
	var amount = after - before
	if amount < 0 and !herbal_healing and !isOverdosed():
		var calculated_extra_gain: int = int((amount * (stacks.size() * 0.2 + 0.3)))
		if calculated_extra_gain == 0:
			return
		herbal_healing = true
		character.addPain(calculated_extra_gain)
		if character.isPlayer():
			GM.main.addMessage(str(-calculated_extra_gain)+" additional pain removed thanks to effects of herbal medicine.")
	herbal_healing = false
		
func getEffectName():
	if(!isOverdosed()):
		return "Assisted healing"
	else:
		return "Overdosed herbs"

func getEffectDesc():
	var text
	if(!isOverdosed()):
		text = "Herbal medicine is providing you with increased gains to pain relief and assisted mild passive recovery"
	else:
		text = "Overdosing the medicine makes you feel bad"
		
	return text + "\n\n("+str(stacks.size())+" stacks)"

func getEffectImage():
	return "res://Modules/IssixModule/StatusEffects/herbalmedicine.png"

func getIconColor():
	if !isOverdosed():
		return IconColorGreen
	else:
		return IconColorRed

func isOverdosed():
	return stacks.size() > 5
	
func combine(_args = []):
	if _args.size():
		stacks.append(_args[0])
	else:
		stacks.append(6*60*60)
	stacks.sort()
	
func saveData():
	return {
		"stacks": stacks,
	}
	
func loadData(_data):
	stacks = SAVE.loadVar(_data, "stacks", [6*60*60])
	
func clampOrRemove():
	while stacks.size():
		if stacks[0] != null and stacks[0] <= 0:
			stacks.pop_front()
			continue
		break
	if(stacks.size() <= 0):
		stop()
