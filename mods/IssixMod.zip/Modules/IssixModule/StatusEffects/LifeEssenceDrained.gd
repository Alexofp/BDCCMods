extends StatusEffectBase

func _init():
	id = "LifeEssenceDrained"
	isBattleOnly = false
	isSexEngineOnly = false
	
func setCharacter(c):
	.setCharacter(c)
	
func initArgs(_args = []):
	turns = _args[0] if _args else 10*60*60
	
func processBattleTurn():
	turns -= 1
	if(turns <= 0):
		stop()
		
func processTime(_secondsPassed: int):
	turns -= _secondsPassed
	if(turns <= 0):
		stop()

func getEffectName():
	if GM.main.getModuleFlag("IssixModule", "Lamia_Encounter_scene", 0) < 5:
		return "???"
	if(isManaged()):
		return "Nullified draining"
	return "Life drained"

func getEffectDesc():
	var text
	if GM.main.getModuleFlag("IssixModule", "Lamia_Encounter_scene", 0) < 5:
		if character.isPlayer():
			text = "You are in drained state for some reason, but you don't understand why"  # Don't expect it to show up ever but whatev
		else:
			text = character.getName() + " looks weakened, but you don't understand why..."
	elif(isManaged()):
		text = "Drained from blood and life essence but with negative effects nullified by Lamia made herbal medicine"
	else:
		text = "Drained from blood and life essence"
		
	return text + "\n\n("+Util.getTimeStringHumanReadable(turns)+" left)"

func getEffectImage():
	if GM.main.getModuleFlag("IssixModule", "Lamia_Encounter_scene", 0) < 5:
		return "res://Modules/IssixModule/StatusEffects/questionmarks.png"
	else:
		return "res://Modules/IssixModule/StatusEffects/parasitedrain.png"

func getIconColor():
	if isManaged():
		return IconColorGray
	else:
		return IconColorRed

func isManaged():
	if character and character.hasEffect("HerbalMedicine"):
		return true
	return false
	
func getBuffs():
	if isManaged():
		return []
	else:
		return [
			buff(Buff.DodgeChanceBuff, [-20.0]),
			buff(Buff.BlockArmorBuff, [-10.0]),
			buff(Buff.StatBuff, [Stat.Strength, -10]),
			buff(Buff.StatBuff, [Stat.Vitality, -20]),
		]
	
func combine(_args = []):
	turns = Util.maxi(_args[0], turns) if _args else 10*60*60
	
func saveData():
	return {
		"turns": turns,
	}
	
func loadData(_data):
	turns = SAVE.loadVar(_data, "turns", 10*60*60)

