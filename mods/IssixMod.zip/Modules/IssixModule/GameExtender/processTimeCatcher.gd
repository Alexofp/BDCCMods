extends GameExtender

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	id = "IssixModGE"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.pcProcessTime)
	_GES.register(self, ExtendGame.pcHoursPassed)
	# _GES.register(self, ExtendGame.pcHoursPassed)
	_GES.register(self, ExtendGame.pcProcessBattleTurn)

# func pcHoursPassed(_pc:Player, hours):
# 	GM.ES.triggerRun("SpecificTimePassed", [hours*60*60])

func pcProcessTime(_pc:Player, _seconds):
	# Don't progress time while in a dream
	if GM.main.getModuleFlag("IssixModule", "Azazel_In_Dream", false):
		GM.main.timeOfDay -= _seconds
	# 15-18 - three hours when Lamia and random pet will be unavailable for parasite feeding
	GM.ES.triggerRun("SpecificTimePassed", [_seconds])

func pcProcessBattleTurn(_pc: Player):
	if GM.main.getModuleFlag("IssixModule", "Hiisi_Protects_PC") == true:
		if RNG.chance(70):
			var scene = GM.main.getCurrentScene()
			# Make sure we are in generic FightScene and it's the player defending themselves not starting a fight'
			if scene.sceneID != "FightScene" or !(scene.sceneTag in ["interaction_fight_pcdef", "guardfight"]):
				return
			# Make sure that enemy is not a guard
			var pawn = GlobalRegistry.getCharacter(scene.enemyID)
			if pawn == null:
				return
			if !pawn.isInmate():
				return
			#scene.endScene(["win", "pain"])  # TODO We may want to change the sceneTag and handle the pawn interactions by ourselves so the player doesn't get XP & rep change'
			GM.main.runScene("RescueFromFight", [scene.enemyID, scene])

func pcHoursPassed(_pc:Player, hours):
	if hours == 0:
		return
	if Globals.returnValueFromStateFlag("OpenClue_Status", "pulsatorsWU", 14) != 14:
		var anger_calculated = GlobalRegistry.getModule("IssixModule").getPulsatorValue()
		if anger_calculated >= 12 and anger_calculated <= 16:
			anger_calculated = 0
		else:
			# For anger, both excessive and uber-small values should contribute to anger the same way, the further from center the worse
			var max_anger_per_hour = CharacterPawn.angerPerHour * 2
			if anger_calculated < 12:
				# 12 to -13 possible values
				anger_calculated = clamp(abs(25.0 / (anger_calculated + 13)), 0.0, 1.0) * max_anger_per_hour * hours
			else:
				# 41 to 16 possible values
				anger_calculated = clamp(abs(25.0 / (anger_calculated - 16)), 0.0, 1.0) * max_anger_per_hour * hours
			print("anger_calculated="+str(anger_calculated)+"hours="+str(hours))
			for pawn in GM.main.IS.getPawns().values():
				pawn.addAnger(anger_calculated)
	if Globals.returnValueFromStateFlag("OpenClue_Status", "oxygenNm", 3200) != 3200:
		var oxygen = Globals.returnValueFromStateFlag("OpenClue_Status", "oxygenNm", 3200)
		# 2200 - 4200
		# For oxygen the more oxygen the less exhaustion/tiredness, the less oxygen the more exhausion/tiredness
		if oxygen > 3200:
			oxygen = (oxygen - 3200)/1000.0
		else:
			oxygen = -1.0+((oxygen - 2200)/1000.0)
		# oxygen will be in -1.0 to 1.0 
		for pawn in GM.main.IS.getPawns().values():
			print("oxygen="+str(oxygen))
			if pawn.getExhaustion() > 0.0 or oxygen > 0.0:  # Don't add exhaustion if pawn has none'
				pawn.recoverExhaustion(hours * CharacterPawn.fightExhaustionPerHour * 1.5 * oxygen)
			pawn.tiredness = clamp(pawn.tiredness + (-1 * hours * CharacterPawn.tirednessPerHour * 2 * oxygen), 0.0, 1.0)
			#recoverExhaustion(float(_howMuch) * fightExhaustionPerHour / 3600.0)
			#tiredness += float(_howMuch) * tirednessPerHour / 3600.0
