extends ImagePack

func _init():
	id = "roar"
	artist = "Roar"
	
	addCharacter("azazel", [], "res://Modules/IssixModule/ImagePacks/Roar/Images/Characters/Azazel_byRoar.png")
	addCharacter("issix", [], "res://Modules/IssixModule/ImagePacks/Roar/Images/Characters/Issix_byRoar.png")
	addCharacter("hiisi", [], "res://Modules/IssixModule/ImagePacks/Roar/Images/Characters/Hiisi_byRoar.png")
	addCharacter("lamia", [], "res://Modules/IssixModule/ImagePacks/Roar/Images/Characters/Lamia_byRoar.png")
