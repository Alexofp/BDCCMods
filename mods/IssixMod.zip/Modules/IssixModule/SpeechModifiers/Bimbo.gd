extends SpeechModifierBase

# WARNING: This speech modifier is stereotyping certain group of people, it's mainly meant to be a fun trait in-game.
# Adapted from rules defined at https://github.com/Triskelia/Bambi-Dumbtalk-Script/ by Triskelia

var word_replacements = {"okay": "okie", "ok": "okie", "oki": "okie", "delicious": "yummy", "tasty": "yummy", "best": "bestest", "better": "bettah", "god": "gawd", "wow": "oh gawd", "hot": "hawt", "probably": "totally", "girls": "girlz", "woman": "girl", "women": "girlz", "dumb": "dum", "confused": "ditzy", "very": "so", "thus": "so", "really": "rly", "tits": "tiddies", "boobs": "bewbz", "boobies": "bewbz", "though": "tho", "through": "thru", "thanks": "thankies", "whatever": "whatevz", "yes": ["yis", "yas", "yus", "yes"], "your": ["ur", "yr"], "hi": ["Hiya", "Heya", "Hellooo", "Like, Hi"], "hello": ["Hiya", "Heya", "Hellooo", "Like, Hi"], "goodbye": ["luv you, byeeee", "byeeee"], "cya": ["luv you, byeeee", "byeeee"], "bye": ["luv you, byeeee", "byeeee"], "a lot of": ["hella", "lotta"], "lot of": ["hella", "lotta"], "lots of": ["hella", "lotta"], "cool": ["coool", "kewl"], "coolest": ["cooolest", "kewlest"], "entirely": ["totes", "tots", "totz", "totally"], "completely": ["totes", "tots", "totz", "totally"], "totally": ["totes", "tots", "totz", "totally"], "absolutely": ["totes", "tots", "totz", "totally"], "greatly": ["totes", "tots", "totz", "totally"], "butt": ["booty", "bum", "ass", "butt"], "ass": ["booty", "bum", "ass", "butt"], "anus": ["fuckhole", "pussy", "butthole"], "breasts": ["boobz", "titties", "boobs", "honkers", "boobies", "bewbz", "knockers", "jugs", "udders"], "mouth": ["suckhole", "mouth"],"am not": "aint", "is not": "aint", "isn't": "aint", "was not": "wasnt", "are not": "aint", "aren't": "aint", "were not": "werent", "do not": "dont", "does not": "doesnt", "did not": "didnt", "have not": "havent", "has not": "hasnt", "had not": "hadnt", "can not": "cant", "can't": "cant", "cannot": "cant", "could not": "cudnt", "should not": "shudnt", "will not": "wont", "would not": "wudnt", "you": "u", "what is": "watz", "what's": "watz", "what has": "watz", "that is": "datz", "that's": "datz", "thats": "datz", "this": "dis", "don't know": "dunno", "doesn't know": "dunno", "because": "coz", "give me": "gimme", "going to": "gonna", "got to": "gotta", "kind of": "kinda", "little": "lil'", "let me": "lemme", "out of": "outta", "sort of": "sorta", "want to": "wanna"}
var thinking = ["\\band ", "\\bto ", "\\b, "]
var ending = {"ck": "k", "ome": "um", "ewd": "ood", "ph": "f", "ing": "in'", "ough": "uff"}

func _init():
	id = "BimboSpeech"
	priority = 5
	for key in word_replacements.keys():
		var r = RegEx.new()
		r.compile("\\b"+key+"\\b")
		word_replacements[r] = word_replacements[key]
		word_replacements.erase(key)
	for key in ending.keys():
		var r = RegEx.new()
		r.compile("\\B"+key+"\\b")
		ending[r] = ending[key]
		ending.erase(key)
	for _garbage in thinking.size():
		var r = RegEx.new()
		r.compile(thinking[0])
		thinking.append(r)
		thinking.pop_front()

func appliesTo(_speaker: BaseCharacter) -> bool:
	return _speaker.hasPerk("Bimbo")
	
func get_replacement_one(replacements):
	if replacements is String:
		return "[color=#f79ac0]"+replacements+"[/color]"
	elif replacements is Array:
		return "[color=#f79ac0]"+replacements.pick_random()+"[/color]"
	
func word_replacement(text: String):
	var matches = []
	for compiled_re in word_replacements.keys():
		matches = compiled_re.search_all(text)
		if matches.size() > 0:
			var replacement = get_replacement_one(word_replacements[compiled_re])
			for re_match in matches:
				text = compiled_re.sub(text, replacement, false, re_match.get_start())
	return text
	
func interruptors(text: String):
	for compiled_re in thinking:
		var matches = compiled_re.search_all(text)
		if matches:
			var offset = 0
			for re_match in matches:
				if RNG.chance(18):
					var insertion = [", [color=#f79ac0]like,[/color] ", "[color=#f79ac0]hmmm...[/color] ", "[color=#f79ac0]uhhh...[/color] ", "[color=#f79ac0]ummm...[/color] ", "[color=#f79ac0]um[/color] ", "[color=#f79ac0]er..[/color] ", "[color=#f79ac0]uh..[/color] "].pick_random()
					text = text.insert(re_match.get_end()+offset, insertion)
					offset += insertion.length()
	return text
	
func endings(text: String):
	var matches = []
	for compiled_re in ending.keys():
		matches = compiled_re.search_all(text)
		if matches.size() > 0:
			var replacement = ending[compiled_re]
			for re_match in matches:
				text = compiled_re.sub(text, replacement, false, re_match.get_start())
	return text

func modify(_text: String, _speaker: BaseCharacter) -> String:
	var text = word_replacement(_text)
	text = interruptors(text)
	text = endings(text)
	return text

