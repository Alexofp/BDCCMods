extends SpeechModifierBase

const petNoises = {Species.Canine: ["Woof", "Bark"], Species.Feline: ["Meow", "Mew"], Species.Equine: ["Neigh!"], Species.Unknown: ["Yip"]}
const fail_examples = ["*cough*", "khhr", "aaah", "sshhh", "*gasp*"]
var regex = RegEx.new()

func _init():
	id = "PetTalk"
	priority = 500
	regex.compile("([\\!\\.\\?]*)")

func appliesTo(_speaker: BaseCharacter) -> bool:
	return _speaker.hasPerk("PetSpeech")

func getProficiency(speaker):
	if speaker.isPlayer():
		var prof = GM.main.getModuleFlag("IssixModule", "Pet_Speech_Proficiency", 0)
		if prof < 30 and RNG.chance(0.01):
			GM.main.increaseModuleFlag("IssixModule", "Pet_Speech_Proficiency")
			GM.main.addMessage("Your pet speech proficiency has improved.")
		return prof
	else:
		return 30

func modify(_text: String, _speaker: BaseCharacter, overwrite_prof=null) -> String:
	var proficiency = overwrite_prof if overwrite_prof != null else getProficiency(_speaker)
	var species = petNoises[Species.Unknown]
	for single_species in _speaker.getSpecies():
		if single_species in petNoises:
			species = petNoises[single_species]
			break
	var return_text = ""
	var split_text = _text.split(" ")
	for word in split_text:
		if RNG.chance(20) and return_text != "":  # Don't make a sound 
			continue
		var addition = RNG.pick(species)
		var should_fail = RNG.chance(min((1.0-(proficiency/30.0))*100.0, 85)) if overwrite_prof != -1 else true  # True if should fail, false if it shouldn't
		if word.length() > addition.length():
			addition = addition.substr(0, 1) + addition[1].repeat(word.length()-addition.length()+1) + addition.substr(2)
		if should_fail:
			addition = addition.substr(0, RNG.randi_range(int(addition.length()/2), addition.length()-1))+"- "+RNG.pick(fail_examples)
		var result = regex.search(word)  # Preserve the interpunction
		return_text = return_text + " " + addition + (result.get_string() if result else "")
	return return_text.dedent() +" ("+_text+")"

