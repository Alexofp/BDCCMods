extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "IssixGumballFetch"
	
func _initScene(_args = []):
	if getModuleFlag("IssixModule", "Gumball_Fetch", 0) == 1:
		setState("no_gumball")
	elif getModuleFlag("IssixModule", "Gumball_Fetch", 0) in [2, 51]:
		setState("reward")
		GM.pc.getInventory().removeFirstOf("IssixsMap")
		Globals.addIssixMood(4)
		GM.pc.addCredits(RNG.randi_range(15, 40))
		increaseModuleFlag("IssixModule", "Issix_Donation_Meter", 5)
		if GM.main.getModuleFlag("IssixModule", "Issix_Donation_Meter", 0) > 50 and GM.main.getModuleFlag("IssixModule", "Issix_Donation_Meter", 0) < 56:
			addMessage("You can now enchant items with smart locks thanks to Issix's good will")
		if getModuleFlag("IssixModule", "Gumball_Fetch", 2) == 2:
			setModuleFlag("IssixModule", "Gumball_Fetch", 3)
		else:
			setModuleFlag("IssixModule", "Gumball_Fetch", 52)
		return
	
	if !getModuleFlag("IssixModule", "Obtained_Closet_Access", false):
		setState("nopass")
		if !(getModuleFlag("IssixModule", "Quest_Status", 0) > 0):
			GM.pc.getInventory().addItemID("IssixsMap")
		setModuleFlag("IssixModule", "Obtained_Closet_Access", true)
		setModuleFlag("IssixModule", "Gumball_Fetch", 1)
		var scenes = getModuleFlag("IssixModule", "Misc_Slavery_Info", {"scenes_seen": []})
		scenes["scenes_seen"].append(sceneID)
		setModuleFlag("IssixModule", "Misc_Slavery_Info", scenes.duplicate(true))
		setModuleFlag("IssixModule", "Progression_Day_Next", GM.main.getDays()+5)
	else:
		setState("pass")

func _run():
	if(state == "pass"):
		addCharacter("issix")
		saynn("[say=issix]{pc.name}? It's this time again, the gumball should be delivered and await in the closet, would you be so kind to get it for your Master again?[/say]")
		addButton("Sure!", "Go for the gumball (restarts the fetch quest)", "restart_quest")
		Globals.addButtonCheckNoncon("Not now", "You currently don't have the time for Master's fetch quests", "no_time")
		
	if state == "no_gumball":
		addCharacter("issix")
		saynn("[say=issix]Hmm? Need help?[/say]")
		saynn("You nod.")
		saynn("[say=issix]The closet is in the engineering wing. You'll have to go through the checkpoint on the left from the elevator exit of Engineering block. You'll have to go through the „No Inmates Beyond This Point” sign, walk a while until you find a major hallway going on your left. Between storage and robotics there should be a place in the corridor with nothing next to its wall. Just come closer to it and it should open automatically.[/say]")
		addButton("Leave", "", "endthescene")
		
	if state == "no_time":
		saynn("[say=pc]I apologize, Master. I'd rather not do it today.[/say]")
		saynn("[say=issix]It's fine, pet. I'll ask Hiisi to go fetch it. Though, you should be more considerate of your Master's needs, pet.[/say]")
		saynn("You again apologize to your Master before you are dismissed.")
		addButton("Leave", "", "endthescene")
		
	if state == "restart_quest":
		saynn("You accept Master's request enthusiastically, {issix.he} gives you a warm smile and dismisses you, leaving you to it.")
		addButton("Leave", "", "endthescene")
	
	if(state == "nopass"):
		addCharacter("issix")
		saynn("[say=issix]{pc.name}, care for a little adventure?[/say]")
		saynn("[say=pc]What does the Master require of me?[/say]")
		if getModuleFlag("IssixModule", "Quest_Status", 0) > 0:
			saynn("[say=issix]Do you remember the little closet room I've made you go to back when my pet still was a stray?[/say]")
			saynn("[say=pc]Hmm, the one in engineering?[/say]")
			saynn("[say=issix]Exactly the one.[/say]")
			saynn("[say=pc]I do remember, Master.[/say]")
			saynn("[say=issix]Splendid, I'd like you to go there today and retrieve a package of my gum again. I know you are perfectly capable to go there by yourself.[/say]")
			saynn("[say=pc]Of course, Master![/say]")
			saynn("[say=issix]Oh, and you don't have to do the silly things with the blindfold anymore. I've got that covered, simply approach the wall and the gates to the closet will open! I've made sure your pretty face is in the database.[/say]")
			saynn("[say=pc]Thank you, Master![/say]")
			saynn("It appears that the closet is now yours to search and loot.")
		else:
			saynn("[say=issix]Hmm, I didn't send you do the closet yet, correct, pet?[/say]")
			saynn("[say=pc]The closet? No, I don't remember.[/say]")
			saynn("[say=issix]Indeed... Well, it is high time I do that. You see, there is a certain item that is being delivered to a special closet in the Engineering wing that I require. A pack of gumball. It's my personal favorite that I've had to pull a lot of leverage to have it delivered to this forgotten corner of the galaxy.[/say]")
			saynn("[say=issix]I know full well that you are perfectly capable of getting this one for me. I've seen what you can do. So, if you are so kind, pet, please fetch it for your Master. Here is a map so you know where to look for it. Don't mind additional scribble, wasn't me.[/say]")
			
			saynn("You've received a map! You can look at it from the Inventory.")
		addButton("Leave", "Go to the closet", "endthescene")
		
	if state == "reward":
		addCharacter("issix")
		saynn("You come to your Master and show {issix.him} the box of gumball.")
		if getModuleFlag("IssixModule", "Gumball_Fetch", 0) == 52:
			saynn("[say=issix]Oh? Well, thank you, I didn't even need to ask you for it.[/say]")
		else:
			saynn("[say=issix]Splendid, that's what I needed, thank you, pet![/say]")
		saynn("You earned a share of scratches behind your ears as well as some credits and donation points towards Issix's BDSM gear collection reward system.")
		addButton("Leave", "", "endthescene")
		
# 
func saveData():
	var data = .saveData()

	return data

func loadData(data):
	.loadData(data)


func getDevCommentary():
	return ""

func hasDevCommentary():
	return false


func _react(_action: String, _args):
		
	if _action == "restart_quest":
		 setModuleFlag("IssixModule", "Gumball_Fetch", 1)

	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
