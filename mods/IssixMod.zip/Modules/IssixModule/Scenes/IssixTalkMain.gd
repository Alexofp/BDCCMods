extends SceneBase

var random_issix_activities_talk = [
	"He notices you right away and follows you with his gaze.",
	"He is busy tinkering with some metal parts before noticing you.",
	"He sings a song to himself while gesticulating with his paws keeping the eyes closed, until he sees you approach.",

]  #TODO Write more

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "IssixTalkScene"
	
func _reactInit():
	if(GM.ES.triggerReact(Trigger.TalkingToNPC, ["issix"])):
		endScene()
		return

func _run():
	if(state == ""):
		setLocationName("Issix's Corner")
		if (GM.main.getModuleFlag("IssixModule", "Quest_Status") < 6 and GM.main.getModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 0) == 0) or Globals.checkIfPCEnslaved():
			playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="sit"})
		else:
			playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="sit"})
			
		addButtonAt(14, "Walkthrough", "(opens a link in a browser to git.frisk.space) In case you are stuck, you can use the Walkthrough, however it is not recommended to use one", "walkthrough")
	
	if(state == ""):
		if(!GM.main.getModuleFlag("IssixModule", "Issix_Introduced")):
			saynn("While exploring the cellblock you stumble upon an uncommon sight - three leashed creatures resting on red blankets around a sitting man. One of the creatures appears to be sleeping, the other one is laying on their front turned towards the man sitting on the chair and the third one is licking their paws with their eyes closed, below them sheets of paper with drawings.\n\nThe sitting figure appears to be talking with the creature laying on their belly.")
			if(OPTIONS.isContentEnabled(ContentType.Watersports)):
				saynn("All of the three leashed creatures give off a pretty strong smell - they are all marked. While their fur seems dry, it's undeniable it had contact with piss, of a single male. Not difficult to figure out which.")
			addButton("Talk", "Talk to the intimidating demon", "talk")
			addButton("Appearance", "Take a closer look at the intimidating demon", "appearance")
		elif getModuleFlag("IssixModule", "Issix_Anger_Noncon", 0) > 2 and !Globals.checkIfPCEnslaved():
			saynn("[say=issix]You have some nerve to come here, cunt. Get lost or it's not going to turn out so well for you.[/say]")
			if getModuleFlag("IssixModule", "Issix_Anger_Noncon", 2) != 100:  # Issix ditched by player fighting him and winning
				addButton("Sorry", "Express that you are sorry and you'd like to mend relationship with Issix", "fix_anger")
		else:
			saynn("While exploring the station a in the corner of a platform sits a demon-dragon Issix with three leashed creatures.")
			addButton("Talk", "Talk to Issix", "talk")
			addButton("Donate", "Donate loose BDSM gear you have to Issix", "issixdonate")
			addButton("Appearance", "Take a closer look at Issix", "appearance")
		addButton("Leave", "Be on your way", "endthescene")
		
	if(state == "appearance"):
		saynn("Before you, on his ”throne” sits an intimidating figure - a demon-dragon hybrid. His piercing black eyes look distinct from any other inmate. His bright red fur uncommon for a dragon or even inmates, though his color pallette does fit a demon - his fur has three main colors, bright red, dark red and black.\n\nHe can certainly be called muscular, his arms and legs are on the beefier side, not extremely so, but one wouldn't want to pick a fight with him.\nEven though intimidating, his face... Shows kindness and calm.\n\nWhat makes him much different from everyone else is the... Harem? Three leashed creatures sit around on their blankets.")
		addButton("Back", "Go back", "")
		
	if(state == "talk"):
		clearCharacter()
		if (GM.main.getModuleFlag("IssixModule", "Quest_Status") < 6 and GM.main.getModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 0) == 0) and not Globals.checkIfPCEnslaved():
			playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="sit"})
		else:
			playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="sit"})
		addCharacter("issix")
		if(!GM.main.getModuleFlag("IssixModule", "Issix_Introduced")):
			GM.main.setModuleFlag("IssixModule", "Issix_Introduced", true)
			saynn("You approach the intimidating demon, with a lot of distance still in-between you and him, standing right in front of his harem.")
			saynn("[say=issix]Oh hello little morsel. Don't believe I've seen you. Name is Issix. Do you have a name?[/say]")
			addButton("I'm "+GM.pc.getName(), "Introduce yourself with your name", "name")
		else:
			saynn("You approach the demon."+(" He grins, seeing you kneel." if GM.main.getModuleFlag("IssixModule", "Quest_Status") > 5 or Globals.checkIfPCEnslaved() else ""))
			saynn(RNG.pick(random_issix_activities_talk))
			addButton("Prison", "How did he end up in prison?", "prison")
			if GM.main.getModuleFlag("IssixModule", "PC_Enslavement_Role", 0) == 0:
				if GM.pc.getFluids().hasFluidTypeWithCharID("Piss", "issix") or GM.pc.getFluids().hasFluidTypeWithCharID("Cum", "issix"):
					saynn("That's so odd, why do you smell like me {pc.name}?")

				addButton("Pets", "Have they really willingly gave to him?", "pets2")
			addButton("Guards", "Are prison guards giving him trouble?", "guards")
			if GM.main.getModuleFlag("IssixModule", "Quest_Status") == 1 and GM.main.getModuleFlag("IssixModule", "Quest_Bonked") == true:
				addButton("Exercise", "Ask Issix for explanation about your incident with the wall", "quest1bonk")
			if GM.main.getModuleFlag("IssixModule", "Quest_Status") == 3:
				addButton("Gumball", "Bring back the gumball to Issix", "quest1turn")
			match GM.main.getModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 0):
				0:
					if GM.main.getModuleFlag("IssixModule", "Quest_Status", 0) == 0 and !Globals.checkIfPCEnslaved():
						addButton("Become his", "Ask if he'd like to make you his own pet", "join")
					elif GM.main.getModuleFlag("IssixModule", "Quest_Status", 0) > 10 or Globals.checkIfPCEnslaved():
						pass
					else:
						addDisabledButton("Become his", "You have already started the quest, see the status in Tasks")
				1, 3, 4:
					addDisabledButton("Become his", "You don't think there is much sense in asking anymore after you rejected Issix's proposition")
				2:
					addDisabledButton("Become his", "You don't think Issix trusts you enough to become his pet")
				100:
					addDisabledButton("Become his", "This isn't going to happen")
			if getModuleFlag("IssixModule", "Random_Encounter_Scene") == 50:
				addButton("Memory loss", "Talk with Issix about your life before your memory loss", "memory_loss_talk")
			if getModuleFlag("IssixModule", "Lamia_Has_Shown_PC_Past_Noncon", false):
				addButton("Lamia's drawing", "Ask Issix about what Lamia drawn about your past", "lamias_painting_noncon")
			GM.ES.triggerRun(Trigger.TalkingToNPC, ["issix"])
			addButton("Leave", "Be on your way", "endthescene")
			
	if state == "fix_anger":
		saynn("[say=pc]I wanted to apologize for my behavior, I'm interested in resetting our relationship.[/say]")
		if getModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 0) == 1:
			saynn("[say=issix]Phahaha, you want to „reset” the relationship? After raping Hiisi? You are joking.[/say]")
		else:
			saynn("[say=issix]Phahaha, you want to „reset” the relationship? After being such a piece of work towards my pets? You gotta be joking.[/say]")
		
		saynn("[say=pc]I know I did wrong, and I want to fix it.[/say]")
		# Humiliation, degradation
		saynn("{issix.He} is pissed off, that much is very clear.")
		saynn("[say=issix]You can't „fix” everything. Hiisi is not an object, you cannot just apply some glue to mend him you...[/say]")
		saynn("Issix almost loses {issix.his} cool before Hiisi interrupts to your surprise.")
		saynn("[say=hiisi]Master, it's okey. {pc.He} isn't worth it.[/say]")
		saynn("Issix looks at Hiisi, {issix.his} face relaxes a little.")
		saynn("[say=issix]... You are right Hiisi. But are you seriously okey with this piece of shit?[/say]")
		saynn("[say=hiisi]Seen worse in here. {pc.He} is an absolute piece of shit, but... Maybe not completely a lost cause?[/say]")
		saynn("Issix listens to {issix.his} pet carefully, then studies you with {issix.his} dark eyes.")
		saynn("[say=issix]If you say so, I suppose we can give it a go, but I'll leave {pc.him} to you. This okey with you two?[/say]")
		saynn("Issix refers both at Hiisi and Azazel awaiting their response.")
		saynn("[say=azazel]Welll, it's not really my thiinngggg.[/say]")
		saynn("[say=hiisi]Az, I'll make it up to you.[/say]")
		saynn("[say=azazel]Oh? In that case I'm interested hihi.[/say]")
		saynn("[say=issix]Hey, you, piece of shit, wanna „mend” the shit you've done? Here is the only offer you'll get. Take it or fuck off. Make trouble for my pets and I'll not let you live. another day.[/say]")
		saynn("It appears their Master wants to give you a way to apologize directly to the pets...")
		addButton("Accept", "Accept the offer (CW: humiliation, degradation)", "accept_fix_anger")
		addButton("Decline", "Decline the offer", "decline_fix_anger")
		
	if state == "accept_fix_anger":
		playAnimation(StageScene.Duo, "allfours", {pc="pc", npc="hiisi", bodyState={naked=true, hard=false, leashedBy="hiisi"}, npcAction="stand", flipNPC=true, npcBodyState={naked=false, hard=false}})
		addCharacter("hiisi")
		addCharacter("azazel")
		saynn("[say=pc]Fine. I accept. I'm really sorry.[/say]")
		saynn("A faint smile appears on Issix's face, before a command is spoken, directed at you.")
		if !GM.pc.isFullyNaked():
			saynn("[say=issix]Strip.[/say]")
			saynn("You did assume this is going to involve something like this, but since you already agreed, backing out now would be only making things worse. You strip your body of clothing.")
		
		saynn("[say=issix]On your knees.[/say]")
		saynn("You comply. Issix grabs something from {issix.his} bag while two pets loom above you, standing and observing. Though, it's hard to say Azazel is looming in any way, he is, after all, pretty short, and besides, he seems rather unsatisfied. Before you have time for second thoughts, a clawed paw attaches one end of a leash to your collar.")
		saynn("[say=issix]Those two will be your masters for today. Understood, shit stain?[/say]")
		saynn("Feeling humiliated enough you simply nod in response. Issix frisks you.")
		if GM.pc.getInventory().hasItemID("Shiv") or GM.pc.getInventory().hasItemID("StunBaton"):
			saynn("{issix.He} finds some weapons on you, taking them away.")
			saynn("[say=issix]We wouldn't want the pup to hurt {pc.himself} now, would we?[/say]")
		
		saynn("The demonic dragon satisfied almost sits on {issix.his} chair.")
		saynn("[say=issix]Wait, one more thing.[/say]")
		saynn("{issix.He} then pulls a permanent marker out before coming to you. {issix.He} cleans your forehead before scribbling something on it, you can't tell what it says.")
		saynn("[say=issix]Perfect. Azazel, Hiisi, don't go too far, I want to have sight on you for the most part. Have this.[/say]")
		saynn("Dragon hands the end of the leash to Hiisi.")
		saynn("[say=issix]What you do with this thing is your choice, but make sure you feel satisfied at the end.[/say]")
		saynn("With that, Issix leaves you to the two.")
		addButton("Continue", "", "fix_anger_walk")
		
	if state == "fix_anger_walk":
		playAnimation(StageScene.Duo, "crawl", {pc="pc", npc="hiisi", bodyState={naked=true, hard=false, leashedBy="hiisi"}, npcAction="walk", flipNPC=true, npcBodyState={naked=false, hard=false}})
		aimCameraAndSetLocName("main_stairs2")
		removeCharacter("issix")
		saynn("Hiisi leads you on leash away from the corner, it's clear this is an exercise in humiliation and for sake of taking that target off your back you are willing to endure it. Azazel walks to the side of Hiisi, a little bit behind, looking around, seemingly bored.")
		saynn("[say=azazel]I can understand why Master wanted me to be the part of the walk, but I wish {issix.he} also knew how torturous this is for meeee.[/say]")
		saynn("[say=hiisi]You are just watching, I'm the one holding the leash.[/say]")
		saynn("[say=azazel]Still, it's like holding a candy in front of a kid behind military grade glass so they can't grab it.[/say]")
		saynn("[say=hiisi]If you need it so badly I can find a second leash.[/say]")
		saynn("[say=azazel]I'd totally do that, but I would rather die than do a walk on fours near that thing you have on your leash.[/say]")
		saynn("Ouch.")
		saynn("[say=hiisi]That's probably the worst thing I've heard you saying about another from you.[/say]")
		if getModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 0) == 1:
			saynn("[say=azazel]You surprised? That thing sexually assaulted you![/say]")
			saynn("[say=hiisi]I know.[/say]")
			saynn("[say=azazel]That's horrible![/say]")
			saynn("[say=hiisi]You wouldn't care this much either if it assaulted you, would you?[/say]")
			saynn("[say=azazel]...[/say]")
			saynn("[say=hiisi]Thought so. Look, it happened. Yes, it's terrible but honestly? I have bigger traumas to process than that. This happens all the time in this place anyways.[/say]")
			saynn("[say=azazel]You are right. Still... Eh.[/say]")
		
		saynn("[say=azazel]I hate assholes.[/say]")
		saynn("[say=hiisi]Only assholes love other assholes. Sounds like you are alright.[/say]")
		saynn("[say=azazel].. Thanks Hiisi.[/say]")
		saynn("You passively listen to their conversations are you are dragged behind on the leash.")
		addButton("Crawl", "Continue", "fix_anger_walk2")
		
	if state == "fix_anger_walk2":
		playAnimation(StageScene.Duo, "crawl", {pc="pc", npc="hiisi", bodyState={naked=true, hard=false, leashedBy="hiisi"}, npcAction="walk", flipNPC=true, npcBodyState={naked=false, hard=false}})
		aimCameraAndSetLocName("main_stairs_n")
		if GM.main.IS.getInteractionsOfTypeAmount("InStocks") > 0:
			saynn("[say=azazel]Looks like some poor bugger is in the stocks. Wanna release them?[/say]")
			saynn("[say=hiisi]No, let them stay, don't feel like fiddling with stocks right now.[/say]")
			saynn("[say=azazel]Alright, your choice, last time we did get a cookie though.[/say]")
			saynn("[say=hiisi]Don't count on it.[/say]")
		else:
			saynn("[say=azazel]Nobody in stocks today, must be a good day in this shithole.[/say]")
			saynn("[say=hiisi]Would be the first.[/say]")
			saynn("[say=azazel]Pff. It's not thiiis bad![/say]")
			
		saynn("[say=azazel]Hey, do you remember that kitty that usually sits on the bench... There?[/say]")
		saynn("[say=hiisi]Rahi.[/say]")
		saynn("[say=azazel]Yes! Right, that's the name.[/say]")
		
		if getFlag("RahiModule.rahi4SceneHappened"):
			saynn("[say=azazel]Haven't seen her for a while.[/say]")
			saynn("[say=hiisi]The reason for that might be closer than you think.[/say]")
			saynn("Hiisi looks behind at you, Azazel follows his gaze.")
			saynn("[say=azazel]Seriously?[/say]")
			saynn("[say=hiisi]Seriously.[/say]")
			saynn("[say=azazel]You fucking hurt the kitty too?[/say]")
			saynn("You were about to defend yourself but Hiisi speaks first.")
			saynn("[say=hiisi]Relax, Az. {pc.He} did not.[/say]")
			saynn("Azazel looks clearly confused.")
			saynn("[say=hiisi]The cat almost died, {pc.name} saved her. Multiple sources confirmed that, including the cat herself.[/say]")
			saynn("[say=azazel]How did it happen? Wait, alcohol?[/say]")
			saynn("[say=hiisi]Yes.[/say]")
			saynn("[say=azazel]Always knew she had that problem, never figured how she even finds it. But damn... Maybe you were right, {pc.he} is reformable.[/say]")
			saynn("[say=hiisi]... Maybe.[/say]")
			addButton("Continue", "Continue the walk", "fix_anger_walk3")
		elif GM.ES.eventCheck("rahiBusy"):
			saynn("[say=azazel]Don't see her.[/say]")
			saynn("[say=hiisi]Maybe went for lunch.[/say]")
			saynn("[say=azazel]Maybe...[/say]")
			addButton("Continue", "Continue the walk", "fix_anger_walk3")
		else:
			saynn("[say=azazel]I can see her, can we visit? I may have something for her.[/say]")
			saynn("[say=hiisi]Sure. We do want to present our „pet”, after all.[/say]")
			saynn("[say=azazel]Let's go then.[/say]")
			addButton("Rahi", "Crawl behind the two approaching Rahi", "fix_anger_walk_rahi")
			
	if state == "fix_anger_walk_rahi":
		playAnimation(StageScene.Duo, "crawl", {pc="pc", npc="hiisi", bodyState={naked=true, hard=false, leashedBy="hiisi"}, npcAction="walk", flipNPC=true, npcBodyState={naked=false, hard=false}})
		aimCameraAndSetLocName("main_bench2")
		addCharacter("rahi")
		saynn("[say=azazel]Heey, Rahi, Rahi![/say]")
		saynn("Feline directs {rahi.her} gaze at screaming Azazel as he approaches.")
		saynn("[say=azazel]Hey there! How have you been?[/say]")
		saynn("[say=rahi]{rahi.She} is okey, why?[/say]")
		saynn("[say=azazel]I don't know, I just haven't seen fellow cat for a while, but that's my bad, I should be coming more often.[/say]")
		saynn("Rahi seems rather surprised by suddenness of the visit. Though seeing another inmate led on a leash does not surprise her a little.")  # Makes more sense, Rahi has been owned in BDCC before
		saynn("[say=azazel]Oh! This is our pet, well, for now I suppose. Its been a piece of work honestly. "+("I guess you have met already? You seem to recognize the pet." if getModuleFlag("IssixModule", "Rahi_Introduced", false) else "")+"[/say]")
		
		saynn("[say=azazel]Go on pet, say hi to Rahi![/say]")
		saynn("[say=pc]H-hello.[/say]")
		saynn("The entire situation is incredibly awkward"+(", especially in presence of someone that you've made introductions to already" if getModuleFlag("IssixModule", "Rahi_Introduced", false) else ", to you Rahi is a complete stranger."))
		
		saynn("[say=azazel]I'd prefer you to speak less sophisticated language but fair enough. Do you need anything Rahi? I could try to get you something.[/say]")
		saynn("[say=rahi]No, thank you..[/say]")
		saynn("[say=azazel]You sure? It's no problem for me, you know? My Master makes sure we have all the things we need.[/say]")
		saynn("[say=hiisi]Here, have this.[/say]")
		saynn("Hiisi takes out an apple from his pocket and throws it in Rahi's direction. The feline catches it with a little effort.")
		saynn("[say=rahi]Oh, kitty thanks you![/say]")
		saynn("The cat sniffs the apple and cheerfully takes bite after bite enjoying the meal.")
		saynn("[say=azazel]Hehe, if you need anything more, don't hesitate to visit us at the corner nearby, I'm sure our Master wouldn't mind, you are a sweet kitty! Can I pet your head?[/say]")
		saynn("After Rahi nods Azazel shortly pats brown hair on Rahi's head before turning to Hiisi and giving a nod to continue your walk.")
		addButton("Continue","Issix seems annoyed, marking this conversation over", "fix_anger_walk3")
		
	if state == "fix_anger_walk3":
		playAnimation(StageScene.Duo, "crawl", {pc="pc", npc="hiisi", bodyState={naked=true, hard=false, leashedBy="hiisi"}, npcAction="walk", flipNPC=true, npcBodyState={naked=false, hard=false}})
		removeCharacter("rahi")
		aimCameraAndSetLocName("main_hallroom10")
		if getFlag("RahiModule.rahi4SceneHappened") or GM.ES.eventCheck("rahiBusy"):
			saynn("[say=azazel]Too bad we coulldn't visit the cat, they seem different from everyone in here.[/say]")
		else:
			saynn("[say=azazel]Always love coming to the kitty, they are different from everyone else here.[/say]")
			
		saynn("[say=hiisi]Really? In what way?[/say]")
		saynn("[say=azazel]I don't know, they seem sincere, and kind. Too kind for this place.[/say]")
		saynn("[say=hiisi]You are too naive, you can't tell that about her.[/say]")
		saynn("[say=azazel]Can't I? Have you seen her? She wouldn't kill a fly.[/say]")
		saynn("[say=hiisi]I've seen killers looking as innocent as she does.[/say]")
		saynn("[say=azazel]Bullshit.[/say]")
		saynn("[say=hiisi]Like I said, naive.[/say]")
		saynn("Azazel simply shows his tongue to Hiisi. As the three of you continue walking through the corridors and stairs.")
		saynn("[say=hiisi]Wanna have fun with our pet before we release it to the wild?[/say]")
		saynn("[say=azazel]I'm happy for a good fuck, but not with it, no, and certainly not planning to take control, you know I haaaate it.[/say]")
		saynn("[say=hiisi]You'd do it for the Master if {issix.he} asked.[/say]")
		saynn("[say=azazel]I would, and he wouldn't.[/say]")
		saynn("[say=hiisi]That's true. Still, I want to use the time we have it on a leash for myself, so lets go there and I'll fuck it. You don't have to join if you don't want to.[/say]")
		saynn("[say=azazel]You?.. Sure, go on. have fun. I'll just... Stand here and observe.[/say]")
		saynn("[say=hiisi]If you fancy doing that, won't complain. Get on your twos, bitch. I'm not lowering myself to your level.[/say]")
		addButton("Stand up", "Do as he says", "fix_anger_walk4")
		
	if state == "fix_anger_walk4":
		playAnimation(StageScene.SexPinnedBehind, "tease", {pc="hiisi", npc="pc", bodyState={naked=true, hard=false}, npcBodyState={naked=true, hard=false, leashedBy="hiisi"}})
		
		saynn("Hiisi forcefully grabs you by your shoulder and pushes your body against the cold wall nearby. His left holds your back {pc.foot} while he grinds his {hiisi.penis} in between of your butt cheeks.")
		saynn("This kind of behavior isn't anything uncommon for this prison. Some of the creatures passing by – be it the guards or other inmates don't really so much as bat an eye, some that are more into that do steal a look from time to time.")
		saynn("In the prison the law is that the one holding the leash is the one in power. This can change really quickly, but if you wanted, strong paws of Hiisi don't give you much of leeway to rebel against power you are dealing with.")
		saynn("[say=hiisi]How do you feel now? Not so cocky, huh?[/say]")
		saynn("[say=hiisi]Let's see how sorry you are, bitch.[/say]")
		addButton("Ahh!", "Hiisi penetrates your backdoor", "fix_anger_walk5")
		
	if state == "fix_anger_walk5":
		playAnimation(StageScene.SexPinnedBehind, "fast", {pc="hiisi", npc="pc", bodyState={naked=true, hard=true}, pcCum=true, npcBodyState={naked=true, hard=false, leashedBy="hiisi"}})

		saynn("Hiisi buries his {hiisi.penis} deep inside of your pucker without giving you much of forewarning, what's more he does so with very little interest of your own pleasure, you can feel there is something more that drives him through his movement. Those aren't not feral, erratic movements, but they are forceful, there is a certain rhythm to them, but your pleasure right now does not hatter in the slightest.")
		saynn("You are filled with mix of pain and pleasure, canine bone buries deep inside of you with each thrust. Thankfully, despite beeing able to, he stops his thrusts right before passing his knot through you. Plap. Plap. Plap. Your entrance getting more and more slick as canine's pre starts to leak out as well as your own anal juices end up sliding out.")
		saynn("[say=hiisi]Huff. Hufff. Take.. It... In![/say]")
		saynn("With that last part the knot finally is pushed in. It's painful but... There is also some kind of finality to it. Not explicit, but implied. You just feel that Hiisi's release means something more than him rutting in your ass, like some kind of debt was paid.")
		saynn("[say=azazel]*clap clap* I rarely see you so enthusiastic about yiff Hiisi, what changed?[/say]")
		saynn("[say=hiisi]Nothing. Just felt like using the fact we have a pet.[/say]")
		saynn("The knot tied you with the canine, Hiisi gives a few tugs but predictably it just doesn't budge. This gives some time for respite. The warm load in your ass feels pretty nice to you though.")
		
		saynn("[say=azazel]Do I need to be a bad kitty for you to rut me this well too? Aww.[/say]")
		saynn("[say=hiisi]Phh. Dream on, Az.[/say]")
		
		saynn("[say=azazel]Such a spoilsport.[/say]")
		addButton("Continue", "", "fix_anger_walk6")
		
	if state == "fix_anger_walk6":
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="hiisi", bodyState={naked=true, hard=true, leashedBy="hiisi"}, npcAction="walk", flipNPC=true, npcBodyState={naked=false, hard=false}})
		aimCameraAndSetLocName("main_hallroom11")
		saynn("After few minutes the knot finally gives and Hiisi can put on his uniform back.")
		saynn("[say=hiisi]We can go.[/say]")
		saynn("[say=azazel]Mrrr, sure you don't want to have a second go?[/say]")
		saynn("He winks. Hiiisi just rolls his eyes in response before tugging your least going towards the corner.")
		saynn("[say=azazel]Laaaaaame.[/say]")
		
		saynn("[say=hiisi]Don't bother going on fours, pet. Lets just get it over with already.[/say]")
		saynn("You continue walking towards the corner, led by Hiisi, with Azazel on his side.")
		addButton("Finish", "Finish your walk", "fix_anger_finish")
		
	if state == "fix_anger_finish":
		aimCameraAndSetLocName("hall_ne_corner")
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="hiisi", bodyState={naked=true, hard=false, leashedBy="hiisi"}, npcAction="walk", flipNPC=true, npcBodyState={naked=false, hard=false}})
		addCharacter("issix")
		saynn("Shortly after you arrive back at the corner. Azazel comes back to his blanket while Hiisi stands awaiting for his Master to finish conversing with a guard who approached the corner, they seem to be wrapping up.")
		saynn("[say=issix]Back already? Expected you to make the walk a bit longer.[/say]")
		saynn("[say=hiisi]We've had our fun, Master.[/say]")
		saynn("[say=issix]Gave you any trouble?[/say]")
		saynn("The dog looks at you before turning back around and giving an answer, after which he passed leash connected with your collar to Issix.")
		saynn("[say=hiisi]Nope.[/say]")
		saynn("[say=issix]That's good to hear. Have you learned anything {pc.name}? Hah, don't answer it. I can see the answer leaking out of your ass.[/say]")
		saynn("[say=issix]Consider yourself lucky, that I'm willing to give you a second go, and listen. There will not be a third try. My pets are mine, you mess with my property, you mess with me – and this entire prison will be the last place you see before your eyes. Capisce? Good.[/say]")
		saynn("A click is heard as dragon's skilled claw detaches a leash from your collar.")
		saynn("[say=issix]We are done here.[/say]")
		addButton("End", "Seems like Issix no longer hates you? So much?", "endthescene")
		
		
	if state == "decline_fix_anger":
		saynn("You communicate you aren't planning to let his pets do whatever they want with you.")
		saynn("[say=issix]Then get the fuck away from here. If you aren't ready to do the bare minium for me to consider letting you near us again just go space yourself or something.[/say]")
		addButton("Leave", "Be on your way", "endthescene")
			
	if state == "lamias_painting_noncon":
		saynn("[say=pc]Master Issix?[/say]")
		saynn("[say=issix]Yes, "+Globals.getPlayerPetName()+"?[/say]")
		saynn("[say=pc]I've asked Lamia what he remember of me before my memory loss and he has drew this. He didn't explain it any further, could Master explain what it might mean?[/say]")
		saynn("[say=issix]Ah, yes. It's from the time before you became my pet. You were a little bit rowdy and had a rival in the prison so you gathered some attention from that. Thing of the past, you shouldn't dwell on it anymore, pet.[/say]")
		saynn("[say=pc]Huh? Are they still in the prison? The rival?[/say]")
		saynn("[say=issix]I'm afraid not. Sorry.[/say]")
		saynn("{issix.He} doesn't seem interested in continuing this conversation any further.")
		addButton("Back","Issix seems annoyed, marking this conversation over", "talk")
			
	if state == "guards":
		saynn("[say=pc]What about guards? Are they not a problem for your operations?[/say]")
		saynn("[say=issix]Guards? No. They are just a gear in the system. As to my attitude towards them - I guess it's pretty symbiotic. I'm a very nice inmate, not making them any trouble and they leave me alone to my devious plans. My past earned me some privileges in here that no other can claim, by no means I'm untouchable but I'm close to being that. There are a few deals I have with the guards that allow me to live in here on my own terms, and its to their own benefit as well.[/say]")
		saynn("[say=pc]Really? So you are a big deal?[/say]")
		saynn("He takes a long breath")
		saynn("[say=issix]Nothing you have to worry about, morsel. All you need to know is to not cross me or any of my precious pets. That's all I want you to keep in mind.[/say]")
		saynn("[say=pc]Any way I could get on on some of deals you've mentioned?[/say]")
		saynn("[say=issix]Don't push it, morsel. If you are looking for charity this isn't the way to look.[/say]")
		addButton("Back","Issix seems annoyed, marking this conversation over", "talk")

	if state == "memory_loss_talk":
		saynn("[say=pc]Master?[/say]")
		saynn("[say=issix]Yes, pet?[/say]")
		saynn("[say=pc]Could we talk about... Myself and everything that happened before I lost my memory?[/say]")
		saynn("{issix.He} looks at you with suspicion at first, before standing up and leading you to more discrete place, away from other pets, odd.")
		saynn("[say=issix]What would you like to know?[/say]")
		
		addButton("Prison", "Talk about the prison", "memory_loss_prison")
		addButton("Pet", "Talk how did you became Master's pet", "memory_loss_pet")
		addButton("Life", "Talk about life before the prison", "memory_loss_life")
		addButton("Life", "Talk about Issix", "memory_loss_issix")
		
		addButton("Back","", "talk")
		
	if state == "memory_loss_prison":
		saynn("You ask Master about how did you end up being in this prison, how the prison works.")
		match GM.pc.getInmateType():
			InmateType.General, InmateType.Unknown:
				saynn("[say=issix]Sorry, I don't know why you were sent to the prison, you didn't tell much. But judging by the color of your uniform, it probably wasn't too bad. Maybe you did some financial fraud or stole from wrong creature. Hard to tell.[/say]")
			InmateType.SexDeviant:
				saynn("[say=issix]Sorry, I don't know why you were sent to the prison, you didn't tell much. But judging by the color of your uniform, it's most likely that you've been sent here for whoring yourself without a license. Good for you, in BDCC you don't need a license to do that, and I don't care whether you whore yourself or not. So if your old you imprints hornyness onto your current you, go wild.[/say]")
			InmateType.HighSec:
				saynn("[say=issix]Sorry, I don't know why you were sent to the prison, you didn't tell much. But judging by the color of your uniform, you've been sent here for violent crime. That's all I know.[/say]")
			_:
				saynn("Issix shrugs.")
				saynn("[say=issix]No idea why you've been sent here, you've never shared.[/say]")
		
		saynn("[say=issix]As to the prison itself, the collar on your neck can kill you if you don't play nice with the guards and their rules. We are on a remote comet in secret location, no one should know about – which limits your escape routes if you ever think about that. Other than that, the rules are pretty relaxed as far as prisons go, fuck as much as you want, you get your daily food in the canteen, there is wonderful medical coverage as long as you don't mention suspicious pills to the head doctor and beds in cells – as you've already noticed – can be a bit shit but livable.[/say]")
		addButton("Back","", "memory_loss_talk")
		
	if state == "memory_loss_pet":
		saynn("You ask Master about how did you came to be {issix.his} pet.")
		saynn("[say=issix]Oh, you don't have to worry about not remembering it, can't blame you for after operation memory loss, right?[/say]")
		saynn("{issix.He} smiles.")
		saynn("[say=issix]After you came to the prison, you had it pretty tough, You had pissed off some powerful individuals in the prison and were paying the price. Eventually, while looking for new stability in the prison, you've ended up at my little corner, choosing to be mine. That was it.[/say]")
		addButton("Back","", "memory_loss_talk")
		
	if state == "memory_loss_life":
		saynn("You ask Master about your life before the prison.")
		saynn("[say=issix]Oh, sorry, I don't know much about your life before the prison, you've been fairly secretive about it and I don't ask my pets such personal questions on my own.[/say]")
		addButton("Back","", "memory_loss_talk")
		
	if state == "memory_loss_issix":
		saynn("You ask Master about himself, because while you recognize {issix.him} as your Master... Somehow, you can't remember anything more about that and it's quite awkward. {issix.He} chuckles after hearing the question.")
		saynn("[say=issix]You've chosen me as your Master, I take care of pets like yourself, name is Issix. Before the prison I were at AlphaCorp, decided it wasn't for me, I still have plenty of power, decided to use it to get here, got few pretty pets like yourself, and this is all you need to know.[/say]")
		saynn("Doesn't seem like your Master will elaborate further.")
		addButton("Back","", "memory_loss_talk")

	if state == "prison":
		saynn("You ask Issix about how he ended up in here. He looks at you with intensity, studying your face.")
		saynn("[say=issix]Honestly, don't think there is much for you to know morsel. But sure, I can entertain you a little.[/say]")
		saynn("Issix relaxes, his shoulders straight, he puts one leg on another, in crossed position.")
		saynn("[say=issix]I wanted to be here. My position offered me plenty of opportunities, everyone had their own expectations of everyone else's needs and wishes. I gave them all a big middle finger.\nThrough my connections I became an inmate. Nobody convicted me of any crime, like everyone else in here. I simply used my connections at AlphaCorp to be here. To gain my paradise.[/say]")
		if (GM.pc.getPersonality().getStat(PersonalityStat.Coward) < -0.2):
			saynn("[say=pc]You are craz-[/say]")
		else:
			saynn("[say=pc]That's... Cr-[/say]")
		saynn("[say=issix]Crazy. I know. I've heard it a million times, thanks.[/say]")
		saynn("He rolls his eyes and sips water from the glass nearby.")
		saynn("[say=pc]So how long have you been in here?[/say]")
		saynn("[say=issix]Enough to find my place, acquire three pets and make my own little business. So 5 years or so. I have it somewhere saved, but I don't really care enough to keep count.[/say]")
		addButton("Back", "Turn to other matters", "talk")
			
	if(state == "name"):
		saynn("[say=issix]I see. Nice to meet you {pc.name} and welcome to my humble corner in this piece of heaven.[/say]")
		saynn("He holds his paw up to you, not fazed by the fact that you are still separated by an awkwardly long distance from the demon-dragon.\nNot wanting to be rude, you lean forwards while making extra sure you will not trample upon laying inmate or fall forwards by yourself. Eventually your " + ("hand" if len(GM.pc.getSpecies()) == 1 and GM.pc.getSpecies()[0] == "human" else "paw") + " meets his and you are able to do shake them.")  # ok, I have no idea what's the difference between buff arms and anthro arms, they seem the same, and technically neither have paws, too bad I'm the one writing dialogue though
		saynn("[say=issix]What leads you to me? I don't suppose you are here to admire me like the three here.[/say]")
		saynn("He lets out a laugh")
		saynn("[say=issix]Anyways, I own this little corner including those three wonderful leashed pets beside me. Since you do seem fairly new here, I want to make something very clear to you - you do NOT touch my pets without their permission. Normally I wouldn't think this has to be mentioned, but for some reasons inmates think otherwise, those who do - don't keep this thought for long. I don't mind if you talk with them, if they allow you, you can even touch them, but you do not hurt or fuck my property, if you fancy any of them you can come to me and nicely ask for permission, but they are mine. Understood?[/say]")
		saynn("[say=pc]Understood.[/say]")
		saynn("[say=issix]As long as you follow this rule, you'll not have to worry about humble me. Now, is there any reason you came to me?[/say]")
		addButton("Heaven?", "Did you hear that correctly?", "heaven")
		addButton("You", "Learn more about Issix", "issixdetails")
		addButton("Pets", "Who are the pets?", "pets")
		
	if(state == "heaven"):
		saynn("[say=pc]Did you just call this prison a piece of heaven? Why?[/say]")
		saynn("[say=issix]Because it is. I don't understand why everyone says it's not.[/say]")
		saynn("[say=pc]Because it's... A prison?" + (" It's a middle-of-nothing rock that belongs to some mega rich empire. Because we have collars on our necks and they expect us to mine rock for their benefit, we are just slaves." if GM.main.getFlag("Mining_IntroducedToMinning", false) else "") + "[/say]")
		saynn("[say=issix]You are looking at it all wrong. While the rest of the galaxy is participating in a rat-race for who is the most awful of them all, when they are murdering each other daily in show of dominance, when food shortages, speciesism, chaos is happening out there, here? Sure we still have a lot of show of power, but nobody is murdering each other because of it, we have shitty, but food, and speciesism isn't as bad as out there because what's the point, everyone has been reduced to just an inmate. Slavery here isn't only restricted to AlphaCorp's and Syndicate's of the galaxy, which what allows me to have those wonderful pets in here.[/say]")
		saynn("[say=pc]So you like it here because you can have your own slaves?[/say]")
		saynn("[say=issix]I like it here because I can enjoy what the fuck I enjoy and whatever restrictions this place has don't bother me.[/say]")
		addButton("Continue", "Ask about something else", "name")
		
	if(state == "pets"):
		addCharacter("azazel")
		GM.main.setModuleFlag("IssixModule", "Pets_Introduced", true)
		saynn("[say=pc]So... Who are your pets exactly?[/say]")
		saynn("[say=issix]Curious about my treasured pearls, aren't you? Oh, I'm happy to introduce you, people usually talk only with me, but I feel like pets could use some social interactions with someone else than myself and themselves.[/say]")
		saynn("[say=issix]This kitty here is my very first pet, they've recognized me as their master shortly after I came here. They were very spooked and lost in here, still unsure what exactly they did to end up in this place. I gave them meaning, they repay me by being an excellent pet. Azazel, say hi.[/say]")
		saynn("Issix looks expectantly at Azazel - a fairly regular looking feline, he is wearing an lilac uniform. Until now he was curled and seemingly asleep, even though his ears were perking up whenever his master spoke. After hearing his master's voice speak his name however, his head immediately went up, and along with it the rest of his body. He stood on his fours and turned towards you.")
		saynn("[say=azazel]Hello... Stranger.[/say]")
		saynn("Azazel said with reservation. He looked away from you for a second to look at face of his master, whos face didn't lose his expectant look. Turning back to you he hesitently rubbed his cheek on your leg and collapsed onto his blanket again, making sure to take a last look at his master before closing his eyelids and presumably continuing his slumber.")
		saynn("[say=issix]Good kitty. He is the best breeding bitch in this entire institution, that's what nature made him to be. He doesn't mind petting his head, if that's something you'd like, otherwise we can move on.[/say]")
		saynn("In corner of your eye you see Azazel's faint smile in reaction to Issix's comment.")
		addButton("Pet Azazel", "Pet that kitty!", "hiisipet")
		addButton("Move on", "Learn about second pet", "hiisi")
		
	if(state in ["hiisipet", "hiisi"]):
		removeCharacter("azazel")
		addCharacter("hiisi")
		addCharacter("lamia")
		if(state == "hiisipet"):
			saynn("You crouch and gently pet Azazel's head. You can feel very delicate vibrations produced by the kitten. He doesn't open his eyes, but it's clear cat enjoys this treatment.")
			saynn("Master looks at this interaction with interest and sincere smile on his face.")
			saynn("After a short moment you stand back up and look at pet on your right.")
		saynn("[say=issix]This one here is Hiisi. He is my latest, which doesn't mean I love him any different. This puppy rather keeps to himself, you may have difficulties getting him to open to you, if you'd ever want to do that. He's.. A troubled one, to say the least, but look at him, isn't he the pristine puppy boy? He loves his belly rubs and stays out of the trouble! ... Well, mostly. Anyways, despite his troubled past, he agreed to join me and became my pup! Hiisi cmon, welcome our guest, give {pc.him} a sniff![/say]")
		saynn("[say=hiisi]{pc.name} isn't it? Umm... Hi.[/say]")
		saynn("{hiisi.Name} licks your leg, leaving a bit of saliva on your fur.")  # TODO Fur/skin
		saynn("[say=issix]I apologize for my pets, they aren't used to longer conversations with strangers. They've been through a lot and... *sigh* Anyways, Lamia! Lamia is a fox breed, he doesn't speak. He communicates with drawings. He is getting pretty good at them. He also doesn't seem to mind being mute, quite to the opposite, he seems excited that his... Speech is in form of images.[/say]")
		saynn("You can see Lamia drawing something, Issix gives you a signal to just wait a second. After a minute, Lamia presents you with a drawing, smiling.")
		saynn("The drawing shows a pretty good representation of yourself, on fours, while leashed by a figure that you can only infer to be Issix. There is Lamia, Azazel and Hiisi hanging around there as well besides you. Issix laughs when he sees the drawing.")
		saynn("[say=issix]Lamia, please, don't scare our guest, not every friendly face you see must become my pet. You selfish little rascal.[/say]")
		saynn("While Issix's words seem playful, Lamia still is saddened by his master's words.")
		saynn("[say=issix]That would be it for introductions. If you have any problems with my pets you come to me, understood? Good.[/say]")
		addButton("Back", "Turn to other matters", "talk")
	
	if(state == "issixdetails"):
		saynn("[say=pc]Who are you?[/say]")
		saynn("[say=issix]Oh, I'm just a dragon-demon, nobody special. I dabble in... Equipment, and make bunch of things out of it. If you have some unused restraints, feel free to donate them to me, I'll be sure to make use of them, and maybe reward you a little, if I feel like it.[/say]")
		saynn("[say=pc]How long have you been in here?[/say]")
		saynn("[say=issix]A long while, compared to the others in here, several years at least. Enough to make some reputation for myself. [/say]")
		addButton("Back", "If he says so", "name")

	if(state == "pets2"):
		playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="sit"})
		saynn("[say=pc]Have your pets willingly gave to you? Can't imagine anyone giving up their freedom of their free will.[/say]")
		saynn("He looks at you with a mix of curiosity and amusement.")
		saynn("[say=issix]Oh? You think I'm a brute taking strays from the corridors of this prison against their will and making them my own?[/say]")
		saynn("He sips the drink from his glass. As he tries to read your very soul through your eyes.")
		if GM.main.getPCSlaveAmount() > 0:  # Judgement wooho
			saynn("[say=issix]Perhaps that's something you'd do. Perhaps you think that taking someone as your own is just a matter of violence and power. Perhaps you think that someone's will is yours to take, on your command, just like that, just because they walk this prison.[/say]")
			saynn("He recoils, you see a sliver of regret in his eyes.")
			saynn("[say=issix]No, fuck that. That's amateur hour. This is exactly what just another brute in this prison would think.[/say]")
			saynn("[say=issix]There is more to making someone a pet than brute force. There are other slavers in here who only care about shiny income and nothing else, they think a life is its worth in credits and that's all they see. They don't see the person behind eyes, they see money.[/say]")
			saynn("[say=pc]So what do you see in your pets?[/say]")
			saynn("[say=issix]Living, conscious beings, capable of love and hate, students yearning to learn about how life works, to find their destiny.[/say]")
			saynn("[say=pc]Sounds like load of bollocks.[/say]")
			saynn("[say=issix]To you, sure. Wouldn't expect you to understand anyways.[/say]")
			addButton("Back", "He gestures he is done talking on this topic", "talk")
		elif getModuleFlag("RahiModule", "rahiMile7Enslaved") == true:
			saynn("[say=issix]Perhaps not. Perhaps I misjudged you. Though, it is strange of you to ask me this question this way, considering you yourself look like someone who would enslave someone else with their own permission, giving themselves to you willingly. Am I mistaken?[/say]")
			saynn("His grin is very telling, he knows more than you tell him")
			saynn("[say=issix]Thought so. I don't like using violence and power to make someone my pet. Non-[/say]")
			saynn("He cuts himself in the middle")
			saynn("[say=issix]-my pets submitted to me willingly. I don't subscribe to other methods. That's all.[/say]")
			addButton("Back", "He gestures he is done talking on this topic", "talk")
		else:
			saynn("[say=issix]I'm not like this. My pets are here of their own will. They chose to give themselves to me. I don't enslave people if they don't want to, that's amateur and unfun.[/say]")
			saynn("[say=issix]I don't feel like you'd know a lot about slavery. Doesn't seem like you. Are you maybe an obedient puppy type of person?[/say]")
			saynn("He smiles")
			saynn("[say=issix]Well, if you are, I could show you exactly how my pets came to be my pets. If you allow, of course. All up to you.[/say]")
			saynn("This feels like a serious offer.")
			addButton("Back", "That's all on this topic", "talk")
		
	if(state == "join"):
		var score = calculateHaremScore()
		#var pets = [getModuleFlag("IssixModule", "Azazel_Affection_given", 0), getModuleFlag("IssixModule", "Lamia_Times_Helped", 0), getModuleFlag("IssixModule", "Hiisi_Affection", 0)]
		var score_explored = GM.main.getModuleFlag("IssixModule", "Score_Explored")
		saynn("[say=pc]"+RNG.pick(["What would you say about me becoming one of your pets?", "Do you think I would fit in with your harem?", "I'd like to become one of your pets, is this possible?"])+"[/say]")
		if GM.pc.getPersonality().getStat(PersonalityStat.Subby) < 0.5 and score < 90:
			if getModuleFlag("IssixModule", "Subbed_for_Issix_Today", false) == false:
				addButton("Help?", "Perhaps Issix would have time to train you a little?", "subtrainingq")
			else:
				addDisabledButton("Help?", "You've asked this today, try again tomorrow")
		if(GM.pc.getPersonality().getStat(PersonalityStat.Subby) < 0):
			saynn("[say=issix]Look, you are lovely and all that, but I don't think you are the right fit. I require absolute obedience. Once you submit to me there is no going back, you become MY treasured pet forever. Those three? They know their place, they are ready to be mated whenever I feel like doing so. You? You strike me as leader - like myself. Why not just be business partners in here eh? I think you are entirely capable of gathering your own pets.[/say]")
		elif(score > 89):
			playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="stand"})
			saynn("You mention the intention to join his harem of pets, lust in your eyes. He looks at you and starts grinning.")
			saynn("[say=issix]Mmmmmm. You are almost done morsel. Not mine yet, but so close... I really like you. I really really like you. I think you have all of the qualities I'm looking for in a pet but...[/say]")
			saynn("He looks away, and looks... Concerned? No. In deep thought rather.")
			saynn("[say=hiisi]Is something the matter, master?[/say]")
			saynn("[say=issix]No Hiisi, you don't have to...[/say]")
			saynn("[say=azazel]Will {pc.name} join us, master?[/say]")
			saynn("Issix stands up, pulling on both Azazel's and Hiisi's leashes.")
			saynn("[say=issix]You two, do not concern yourself. {pc.name} here...[/say]")
			saynn("He looks at you, his black eyes again staring into yours. His face is neutral, still hazed by wandering thoughts.")
			saynn("[say=issix]... Is interested, but he still needs to prove he is worthy to be owned by your master.[/say]")
			saynn("He comes closer to you, leashes in his paw, eyes on you. There are only two steps separating you and him, but with each his tall posture makes you feel as if he is getting taller and taller, or perhaps you smaller and smaller. Eventually you can feel his body heat on yours, he is standing just in front of you, a peanut away. Your face meets his chest, you don't dare to look him in the face.\nHis paw reaches your chin to correct that. You see his black eyes again, looking down on you, as if you were a little feral kitten looking at big human. Insignificant. Tiny. His face has a serious expression.")
			saynn("[say=issix]Tell me {pc.name}, do you want to be my pet or do you want to stay a stray?[/say]")
			GM.main.setModuleFlag("IssixModule", "Score_Explored", score)
			addButton("Y-your pet", "Submit to Issix", "quest")
			if (GM.pc.getPersonality().getStat(PersonalityStat.Subby) < 0.3) and GM.pc.getLust() < 30 and !GM.pc.isWearingHypnovisor() and !GM.pc.hasEffect(StatusEffect.Suggestible) and !GM.pc.hasEffect(StatusEffect.UnderHypnosis):  # Good luck lol
				addButton("Stray", "You don't want to be his (abandons quest for becoming Issix's pet)", "questreject")
			else:
				addDisabledButton("Stray kitten", "Your mind doesn't allow you to make this choice")
		elif(score > 75 and score_explored < 76):
			playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="stand"})
			saynn("[say=issix]Hmm.[/say]")
			saynn("He approaches you. Studying details of your face, he puts two of his paw fingers on your mouth opening it, he checks your teeth, if you have fangs. Without asking he grabs your arm rotating it, looking at every possible detail. You don't put up resistance at any point, you expected this treatment, after all. Being a pet is very intimate experience submitting yourself to someone else, after all.")
			saynn("Each one of your front paws are checked, whether you have nails, claws. He puts a paw on your chest, pushing it slightly as if to test your reaction, he tracks with his finger your spine on the back.")
			if GM.pc.hasNonFlatBreasts():
				#saynn("He looks at your "+ GM.pc.getBodypartLewdDescriptionAndName(BodypartSlot.Breasts) + "")
				saynn("He looks at your {pc.breasts}, giving them a squeeze, judging them by his own measures.")
				saynn("[say=issix]You'd be the first pet coming with extras in this area.[/say]")
				if GM.pc.hasBreastsFullOfMilk():
					saynn("As he squeezes your chest, some {pc.milk} spills out of your nipples onto the floor, with a few drops spilling on his paw. He notices and licks the drops off his paws.")
					saynn("[say=issix]Eager to be milked? A pet cow would be most welcome in my corner. How are your cow impressions?[/say]")
					saynn("You figure it's a rhetorical question and keep quiet as he moves to your other body parts.")
			saynn("He continues to explore your {pc.thick} {pc.masc} body, continuing wandering with his paws further down.")
			if GM.pc.getInventory().hasSlotEquipped(InventorySlot.UnderwearBottom) or GM.pc.getInventory().hasSlotEquipped(InventorySlot.Body):
				saynn("[say=issix]I'd rather see you without the clothes, but for today perhaps it's not a priority.[/say]")
				saynn("His hand gently and sensually explores your belly, ass and reproductive equipment.")
				if GM.pc.hasVagina() and GM.pc.getGender() == Gender.Male:
					saynn("[say=issix]A pussy huh? Well, don't worry, you wouldn't be the only male breeding bitch in here.[/say]")
					saynn("He laughs")
				elif GM.pc.hasVagina():
					saynn("[say=issix]A pussy huh? Tasty.")
				elif GM.pc.hasPenis():
					saynn("[say=issix]A penis huh? Wouldn't get much use out of it, but entirely acceptable.[/say]")
				else:
					saynn("[say=issix]Nothing there? That's okey by me, everyone comes with at least one hole.[/say]")
			else:
				if GM.pc.hasVagina() or GM.pc.hasPenis():
					saynn("[say=issix]You like having your babymaker on display, [pulse color=#00FFAA height=0.0 freq=1.0]slut[/pulse]?[/say]")
				else:
					saynn("[say=issix]Nothing there? That's okey by me, everyone comes with at least one hole.[/say]")
				if GM.pc.hasReachableVagina():
					var fluid = GM.pc.getBodypart(BodypartSlot.Vagina).getOrifice().getFluids().getDominantFluidID()
					saynn("He puts his finger into your {pc.pussyStretch} pussy, exploring it from the inside. You close your eyes as the dragon explores your body completely unrestricted as if you were just a [pulse color=#00FFAA height=0.0 freq=1.0]piece of meat[/pulse], a mix of pleasure and humiliation inside of your head. At last, he pulls out, his finger "+ ("covered in "+GlobalRegistry.getFluid(fluid).getVisibleName().to_lower() if fluid != null else "a bit moist")+".")
				if GM.pc.hasReachablePenis():
					saynn("He wraps around his paw around your {pc.penis}, stroking it a little. It already had some encouragement earlier, but now with some stroking from dominant dragon it became much harder.")
					if GM.pc.getPenisSize() > 14:
						saynn("[say=issix]What a shame. Such a big tool, you could be a breeder, if I would let you, but I won't.[/say]")
					else:
						saynn("[say=issix]What a nice little tool you have there. I'll be honest, I'd feel bad if you had a bigger penis, all this potential would be wasted, but this makes things simpler. Bitch.[/say]")
			saynn("He ends exploring your body and comes back to his chair.")
			saynn("[say=issix]I like what I see. You are almost ready, but not yet. When the time comes I expect you to show up again for my judgment. Then, I'll give you a chance. Don't waste it.[/say]")
			GM.main.setModuleFlag("IssixModule", "Score_Explored", score)
		elif(score > 45 and score_explored < 46):
			playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="stand"})
			saynn("[say=issix]Heh, interesting ask. It's still a no, though I have to admit, I do see some potential in here.[/say]")
			if (GM.pc.isBlindfolded()):
				saynn("Issix stands up, takes a step towards you, grabs your blindfold, pulls it higher, grabs you by your chin to look you straight in your eyes.")
			elif (GM.pc.isWearingHypnovisor()):
				saynn("[say=issix]Heh, I see you already come with the equipment. Let me take a look at you.[/say]")
				saynn("Issix stands up, takes a step towards you, pulls you forward, grabs your chin, pulls your head higher to face his head on top of his tall body. You barely see his eyes through your visor, which continues to massage your brain to obey every whim of every alpha in the prison.")
			else:
				saynn("Issix stands up, takes a step towards you, grabs you by your chin without asking and looks you straight into your eyes.")
			GM.pc.addLust(30)
			saynn("The moment takes forever, just as his gaze pierces through your eyes, you also observe his black, void pupils and irises. For a moment, it feels as if his pupil turned bright red. Could be just a play of light or something... But then... There is allure in those eyes. Something dangerous, yet enticing. You feel primal, bare. With every moment of this eye contact you feel less in control, weaker, inferior. Your knees start to bend ever so slightly before Issix steadies your head again and takes his paws from your chin.")
			if (GM.pc.isBlindfolded()):
				saynn("He fixes your blindfold to be back on your eyes.")
			saynn("[say=issix]Yess, you have the potential, whether you'll use it or not is up to you.[/say]")
			saynn("Issix goes back to his chair and sits, staring at you with a grin on his face.")
			GM.main.setModuleFlag("IssixModule", "Score_Explored", score)
		elif(score > 25 and score_explored < 26):
			saynn("[say=issix]I gotta say, I did hear of a certain {pc.name} around doing some whoring, but that's about it. You must understand, my pets must have prior experience and right spirit that I can exploit. You seem like a small fish. So no, my apologies but I'm simply not interested in you at the moment.[/say]")
			GM.main.setModuleFlag("IssixModule", "Score_Explored", score)
		elif(score_explored > 1):
			saynn("[say=issix]You still look the same as the last time you came to me, do not waste my time. If you are really serious about becoming my pet you'll know what to do.[/say]")
			saynn("( Ask Azazel for advice )")
		else:
			saynn("[say=issix]Look, you are lovely and all that, but I don't think you have what it takes to join my other pets. I require absolute obedience and sexual experience. Once you submit to me there is no going back, you become MY treasured pet forever. Those three? They know their place, they are ready to be mated whenever I feel like doing so. They obey my every single command. I just don't see that in you, sorry.[/say]")
		addButton("Back", "Maybe another time then...", "talk")
		
	if state == "subtrainingq":
		saynn("[say=pc]Sir, would you like to.. Show me the ropes then?[/say]")
		saynn("[say=issix]You'd like me to teach you something huh? Normally my training starts after I decide see someone worthy of being my pet.[/say]")
		saynn("[say=pc]I'd want to join sir as {issix.his} pet. But since I can't do that yet, I need some pointers![/say]")
		saynn("[say=issix]Hmm, fair, then. In that case...[/say]")
		addButton("Continue", "", "subtraining")
		
	if state == "subtraining1":
		saynn("[say=issix]I can help you attune your mind a bit more towards ways of submission and obedience. You see, to be my little pet, you have to know your place. Subservience is hard work and appropriate state of mind. See this one?[/say]")
		saynn("{issix.He} points at the fox breed.")
		saynn("[say=issix]He may not attend to me in sexual ways, he is not a brute either, but he has accepted me as his master and acts within my expectations. To be a submissive, is to think and act, is to know your place, is to know when you can speak. It is also to have trust in your Master.[/say]")
		saynn("[say=issix]Today we... Hmm. Hiisi?[/say]")
		saynn("[say=hiisi]Yes Master?[/say]")
		
		saynn("He leans towards Hiisi and whispers something into canine's ear.")
		saynn("[say=hiisi]Of course, give me a minute.[/say]")
		saynn("The puppy leaves somewhere in haste.")
		saynn("[say=issix]Kneel now. We are going to wait a bit.[/say]")
		addButton("Wait", "Do as commanded", "subtraining1_2")
		
	if state == "subtraining1_2":
		saynn("You kneel and wait. Not much happens for a while, Issix doesn't talk to you nor does anything interesting, just sits and manhandles some bondage equipment. You look around and everyone is doing their own thing.")
		saynn("...")
		saynn("Eventually, you notice Hiisi coming back from whatever place he was in, with what looks to be a large metal cage. It must be heavy, considering his movement and how he struggles to drag it in.")
		saynn("[say=issix]Great work, pet. I'll treat you later. Put it here.[/say]")
		saynn("He points at empty space on the floor to the side of {issix.his} chair. Hiisi complies without a word before he returns to his blanket and staring at everything around.")
		saynn("[say=issix]{pc.Name}, come here.[/say]")
		saynn("Dragon beacons you towards the mini-prison made out of regular rather thin metal bars. The entire construction looks solid, it is big enough that a medium sized anthropomorphic creature can fit inside and lay, although they'd have to curl a little bit, the cage is not bed sized after all. The overall condition seems fine, even though the cage clearly had its use, some bars are bent, some are discolored. There are thick handle bars attached to metal plates on the sides and at the top, all of those plates are additionally reinforced by a little bit thicker bars holding everything together. On one side there seems to be a small locking mechanism with separate bar component that can be opened and closed. The gole it makes wouldn't be big enough to squeeze through, but is big enough to insert some items or plats of food inside.")
		saynn("The bottom of the cage is a flat metal plate on top of which there is soft cushioned material tied around to bars around so to not slide off in one way or another. You can spot some blond fur still attached to the material.")
		saynn("Issix unlock the mechanism guarding release of bars on the side and opens the cage, making inviting gesture.")
		saynn("[say=issix]Hop inside then. Show me how much you want to be my pet.[/say]")
		addButton("Refuse", "You don't want to enter the cage", "no_enter_cage")
		addButton("Question", "Ask questions regarding this entire concept of getting into cage, what is dragon going to do with you inside?", "question_cage")
		addButton("Enter", "Enter the cage", "enter_cage")
		
	if state == "no_enter_cage":
		saynn("[say=pc]I... Don't feel good about it. I'm not getting in.[/say]")
		saynn("Issix looks at you for few seconds, before his clawed paw closes the cage again.")
		saynn("[say=issix]This is fine, you can do this another time. Come back when you feel ready, but keep in mind that you'll never have what it takes to be my pet if you don't put in the work it takes.[/say]")
		addButton("Leave", "", "endthescene")
		
	if state == "question_cage":
		saynn("[say=pc]Huh? But... Do you plan to keep me inside? For how long? Will you do something to me when I'm inside?[/say]")
		saynn("[say=issix]I'm not going to tell you what happens once you are inside. You have to trust me. Being a submissive pet requires trust. If you can't do that then well... You will not make a good pet for me. And trust me, I get the irony of just another smaller cage inside of bigger one, but if you choose to learn how to be a submissive from me, then that's how I'm going to teach you.[/say]")
		saynn("Clearly you have a choice to make here. You don't know what Issix is going to do once you are inside, he could close you in and leave you there for the night or worse, hard to tell if there would be anyone willing to help you out if it came to be this way. This could be a trap.")
		addButton("Refuse", "You don't want to enter the cage", "no_enter_cage")
		addButton("Enter", "Enter the cage", "enter_cage")
		
	if state == "enter_cage":
		saynn("You choose to enter the cage, you slowly move inside, with your front paws feeling the material inside first, since you have to move inside on your fours. The material below your paws feels even better than it looks, some high quality silky soft bedding, counterintuitively better than the bedding in prison cells themselves. Your front slowly aligns with width of the cage so that you can enter in full as your "+Globals.describeBodypart(GM.pc, BodypartSlot.Head)+" moves through the entrance"+(", your "+Globals.describeBodypart(GM.pc, BodypartSlot.Horns) + " almost hitting the top of the cage." if GM.pc.hasHorns() else "."))
		saynn("Soon enough the rest of your {pc.thick} "+Util.getSpeciesName(GM.pc.getSpecies())+" body follows, with {pc.feet}"+(" and your {pc.tail} included." if GM.pc.hasTail() else "."))
		
		saynn("You feel the smell of a creature waft towards your nose as the air is pushed out of the material below. It's fairly faint, clearly whoever was there has been there a while ago. What doesn't escape you is that the smell is clearly feminine, odd.")
		saynn("Lack of freedom inside is further highlighted by how cramped the cage feels inside. You can easily stay on your fours there, but in length you have to curve your body so that you can fit. This cage could potentially be okey for a large feral dog, not necessarily a "+Util.getSpeciesName(GM.pc.getSpecies())+" of your size. Looking back at dragon demon, {issix.he} is observing you carefully.")
		saynn("[say=issix]Good, see? You fit. It is a little tight, sure, but you shouldn't have any issues staying there for a while, right? That's what you'll do. Go on, lay there like a good {pc.boy} "+Globals.getPlayerPetName()+" you are.[/say]")
		saynn("Hearing sweet words coming from Issix and his gentle smile already has an effect on you. A nod is returned to the big dragon and you try to make yourself comfortable. The views from the cage seem depressing, though it's not something new to you, life behind bars. Though, there is something exciting about this entire thing, it's rather unique for you to be inside of a cage like that. Those things are for animals and now you are in one.")
		saynn("What you also notice is that Issix did not lock the cage. At any moment you can leave, technically. Cage's metal bars are wide open. Yet you remember {issix.his} words and choose not to speak, it must be the intent of whatever exercise {issix.he} is entrusting you with.")
		addButton("Wait", "That's the command, to wait. You make yourself comfortable, lay and wait", "cage_wait")
		
	if state == "cage_wait":
		saynn("And so you wait. An hour passes and for its entirety you've been on guard staring around looking from place to place. Not easy to get accustomed to new kind of experience like this.")
		saynn("[say=issix]Alright, {pc.name}, come out.[/say]")
		if getModuleFlag("IssixModule", "Silly_mode", false):
			saynn("[say=pc]I'm gay.[/say]")
			saynn("Issix looks at you incredibly confused.")
			saynn("[say=issix]What?[/say]")
			saynn("[say=pc]Uhhh, you wanted me to come out?[/say]")
			saynn("{issix.He} stares at you in disbelief for 3 seconds before {issix.he} mashes his clawed paw against the forehead.")
			saynn("[say=issix]No you little idiot gremlin, out of the cage! What the hell did- Argghhh.[/say]")
			saynn("[say=pc]Whoops.[/say]")
		else:
			saynn("You move your body out of the cage, the moment all of your limbs are out you look at Issix before standing up.")
			saynn("[say=issix]Good {pc.boy}. You did good today. I see you are learning.[/say]")
			saynn("You thank Issix for {issix.his} help.")
		addButton("Finish", "Finish the training session", "talk")
			
		
	if state == "subtraining2":
		saynn("[say=issix]Great. In that case Hiisi, would you be so kind?[/say]")
		saynn("With no further question Hiisi leaves the corner only to come back shortly after with familiar to you cage.")
		saynn("[say=issix]Thank you pet. Now, {pc.name} you know what to do, right?[/say]")
		saynn("You enter the cage just like before, the same silky material as before puffs below your paws. The smell coming from the material no longer just alien, it now feels mixed with your own smell, a mattress of memory retaining last pets - guests to the humiliating animal cage you are in.")
		
		saynn("When your entire body fits the inside of the cage, the gate you just used to enter it is closed behind you and the locking mechanism engaged. You look quizzically at Issix, who returns a grin at you.")
		saynn("[say=issix]Good {pc.boy}, such a submissive little creature you are becoming huh? Going into the cage without needing much encouragement. I can already see the progress in you, that's perfect. I'm sure you won't mind being locked in there for a while, after all, we do want your mind to start learning its place, right?[/say]")
		saynn("He chuckles, before {issix.his} attention wanders somewhere else and you are left alone to your own devices, or maybe not.")
		saynn("[say=azazel]Hehe. You are making me feel jealous. Last time this cage was occupied it housed a bitch in heat, she had such soft fur, mrrr. I think her heat never died down, which made her insufferably horny and, if I'm to be honest, a bit dumb. And it's not often that I see others who are hornier than myself![/say]")
		saynn("Azazel suddenly appears next to your cage, laying on his belly with two arms in front serving as a pillow for his head with eyes right on you. He says the last part very proudly, as to accent he is very proud of being a horny kitten.")
		saynn("[say=pc]Where is she now then? Was it Issix training her too?[/say]")
		saynn("[say=azazel]Oh, I haven't seen her for a long time, I think she got released or something. And yes, it was Master training her, although she couldn't handle the cage.[/say]")
		saynn("[say=pc]Why not?[/say]")
		saynn("[say=azazel]Because of that insufferable heat. She has begged Master to fuck her for hours while locked, I think it's fair to say she went feral at one point.[/say]")
		saynn("[say=pc]Damn.[/say]")
		saynn("[say=azazel]Yeah, even Master felt it was too much...[/say]")
		addButton("Chat", "The time in captivity is more pleasant by some company", "chat_cage")
		addButton("Alone", "Make it clear that you don't want any chat with Azazel", "shut_down_cage")
		
	if state == "chat_cage":
		saynn("You continue conversations with feline. You learn this and that about him and his Master. He listens to your stories as well, and often makes dirty jokes and puns. At some point he flopped on his back, looking at you upside down. For the entire conversation however his gentle laugh, respectful conversation skills combined with casual horniness made the time very worthwhile.")
		saynn("[say=azazel]And then, they entered the toilet stall and right as they were getting ready to sit on the throne, a high pressure jet of clean water hit their face! The sight of their wet face was HILARIOUS.[/say]")
		saynn("Both of you start laughing.")
		saynn("[say=issix]Feeling good there {pc.name}? The kitty might have spoiled the exercise a bit too much, no Azazel?[/say]")
		saynn("His clawed paw ruffles the fur of Azazel's belly as the dragon opens your cage with the other one. Feline is delighted and the face radiates with happiness as sound of purring comes from that direction.")
		saynn("You take your leave from the cage, stretching your limbs again after being confined to little space. It's so interesting to see the playfullness in between the master and his pet, makes you think... Things.")
		addButton("Finish", "Finish the training session", "talk")
		
	if state == "shut_down_cage":
		saynn("You shut down the chatty feline, giving him clear sign that you do not want to be conversed with, he takes the hint and comes back to doing his own things. You meanwhile concentrate on resting, as much resting as you can have in this cramped cage of yours. Nevertheless, you are able to mute the outside world for a while after closing your lids and resting, laying on the silky material as time passes.")
		saynn("[say=issix]{pc.name}? Still there?[/say]")
		saynn("You raise your head.")
		saynn("[say=pc]Yup.[/say]")
		saynn("[say=issix]I think you are good to go now, such a well behaved {pc.boy}. Come back next time for some more training, will you? I think there is clear progress, we just have to cement it onto your mind.[/say]")
		addButton("Finish", "Finish the training session", "talk")
		
	if state == "subtraining3":
		saynn("[say=issix]If you are still coming for more then we can do more. But today I'd like to do something much, much personal. Do you understand what it means?[/say]")
		saynn("You tilt your head a little in confusion, getting personal could mean multiple things. That said, your confusion disappears pretty quick as Issix reaches to the garments on his bottom, taking them off.")
		saynn("[say=pc]Oh.[/say]")
		saynn("Under Issix's uniform shorts there is a sizable base of dragon's penis along with his sizable balls.")
		saynn("[say=issix]Kneel. I want you to get working on those.[/say]")
		addButton("Accept", "You are expected to do some oral service for the demonic dragon", "accept_oral_service")
		addButton("Refuse", "You do not want to service the dragon sexually", "refuse_oral_service")
		
	if state == "refuse_oral_service":
		saynn("[say=pc]I'm not interested in that, Issix.[/say]")
		saynn("[say=issix]Really? You surprise me.[/say]")
		saynn("Not discouraged, {issix.he} calls for Azazel to do what was supposed to be your job. The feline eagerly jumps to action, figuratively and literally. Kneeling with his face right in his Master's crotch.")
		saynn("[say=issix]I'm afraid then, that I don't have anything else to let you do. I do expect compliance. Come back when you feel like serving your dominant.[/say]")
		saynn("Loud sloppy noises begin to fill the air around as Azazel is worshiping his Master's balls using his rough tongue.")
		addButton("Finish", "Finish the training session", "talk")
		
	if state == "accept_oral_service":
		playAnimation(StageScene.ChairOral, "lick", {pc="issix", npc="pc", bodyState={naked=true, hard=true}, npcBodyState={naked=false, hard=false}})
		saynn("This is something you'll have no trouble doing, you think and do as commanded by imposing demonic dragon. You [b]kneel[/b] before {issix.him}, looking above at his face and further commands. This is just another step in your training, after all. The next step in becoming [i]{issix.his}[/i] pet.")
		saynn("[say=issix]Good. Now crawl to my chair on your knees bitch.[/say]")
		saynn("{issix.He} doesn't say that last word in overly degrading manner you feel, it's supposed to be a play. And so you follow the command, putting your legs forward until you arrive closer than ever to his junk, you stare at it intensely. The musk of strong male hits you like a speeding train. It's dominating your sens of smell and your mind. You salivate on thought of servicing this dragon with your mouth, it's so potent, so right for you to be in this position.")
		saynn("Your salivation is broken by the dragon {issix.himself}, {issix.he} grabbed you by the chin to make you look above at {issix.his} face.")
		saynn("[say=issix]That's the face of someone thirsty for dick. Fits a pet... to be. But my dick is a special treat I reserve for my own puppies and kittens, so you'll have to manage with appetizer. Service my balls, bitch. Do take all of that sweet musk into your lungs when you are at it, make sure to remember this smell, it might just be the smell of your future Master.[/say]")
		saynn("To your mind this sounds cruel, why not have the main dish? It's so primal, so there, so within reach. And yet you are like a puppy on a chain, with the reward right behind the threshold you can reach with your chain. But then, You still get to serve the dragon, you still get to please {issix.him}. With your thoughts clouded by the powerful manly pheromones that amounts to all you can think of anyways.")
		saynn("Dragon's claws are removed from your chin and you dive without saying a word further. First taking a lung full of that potent smell. That's the smell of someone powerful, of someone gifted with power to conquer, to command others.")
		if getModuleFlag("IssixModule", "Azazel_Corruption_Scene", 0) == 5:
			saynn("This is the exact smell that you remember from the time Azazel made you smell that jockstrap. That one time you were sent to the paradise where Issix collared you as {issix.his} own. Yesss. That was divine. You have to become {issix.his} pet, it's not even a question.")
		addButton("Service", "Service the good dragon", "service_dragon")
		
	if state == "service_dragon":
		playAnimation(StageScene.ChairOral, "tease", {pc="issix", npc="pc", bodyState={naked=true, hard=true}, npcBodyState={naked=false, hard=false}})
		saynn("Satisfied with the musk fill you have inhaled, you start to fulfill Issix's wish, you lap your tongue at his juicy orbs, at first slow getting to know the texture and feel, slowly increasing the speed as you get used to it. Issix's clawed paw finds its way onto your head and pets it nicely applying some pressure at the back of your "+Globals.describeBodypart(GM.pc, BodypartSlot.Head)+" so that you can feel just how much power you let the dragon have over you. To remind you of your place and task.")
		saynn("Polishing each one of them, your nose continues to make contact with the large shaft above, which as you are going extended itself quite significantly thanks to arousal caused by your soft mouth. It is quite frustrating you can't just start cleaning up the pole instead, but you want to be a good {pc.boy} for your... Dragon friend. Massage {issix.his} orbs very well so they shine.")
		saynn("[say=issix]Perfect. That's enough now. You did a great job. Azazel will take it from here.[/say]")
		saynn("Your head pulled out of Issix's junk, immediately feeling discontent, it felt so fulfilling to be {issix.his} bitch.")
		saynn("[say=pc]Yes Mast- Ekhem. Issix![/say]")
		saynn("[say=issix]Haha. Getting ready to your role huh? We will see soon enough I suppose. For today, that's it. You are dismissed, bitch in training.[/say]")
		saynn("{issix.He} gives you a wink and calls Azazel to finish your job, which feline gladly does. You however, take last few looks at Issix and {issix.his} {issix.masculine} body. The musk still wrecking havoc in your mind, and lack of it makes you feel needy.")
		addButton("Finish", "Finish the training session", "talk")
		

	if state == "questreject":
		setModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 1)
		saynn("[say=issix]I see... Disappointing, but it's your choice and I respect that.[/say]")
		saynn("He looks at you some more, he takes away his paw from your chin, turns around and sits on his chair. A serious and... Disappointed look on his face.")
		saynn("[say=issix]Go on then, unless you want to donate some items.[/say]")
		addButton("Leave", "Take your leave", "endthescene")

	if(state == "quest"):
		playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="sit"})
		saynn("He smiles briefly.")
		saynn("[say=issix]Very well.[/say]")
		saynn("He puts his paws on sides of your head and starts scratching you behind your ears. Immediately you feel... Comfortable. Loved. Protected. You closed your eyes in bliss. And then he... Stops, the feeling of his paws is filled with void. You feel empty, unfulfilled. You open your eyes and meet his eyes staring at you again from the above. He looks at you expectantly. You aren't sure what to do, you don't want to fail your Master, but... His black eyes speak to you, yes. They want you to open your mouth. You don't even realize when your mouth opens. You didn't do that by yourself, did you?")
		saynn("He takes your tongue in between his paw fingers gently, pulls it out a little. He opens his mouth and he spits. Spit lands right on your tongue, with incredible precision right in the middle. He does it again, using the fact your mouth is still open. It lands deeper inside your mouth. He pulls his paw fingers from your tongue and uses his two fingers to pressure your chin from below, giving you a signal to close your mouth.")
		saynn("You comply. There is nothing other than his eyes staring deep at you, his will is your will. His spit doesn't feel particularly different from yours, perhaps you can pick up some flavor or two, but it's more dignified flavor than one of cum that you are so used to. You keep the spit inside your mouth for a bit, tasting it, feeling it, connecting with its owner. And you swallow it, with a visible gulp.")
		saynn("Issix smiles. He ruffles your " + ("hair" if GM.pc.hasHair() else "ears") + " with his paws.")
		saynn("[say=issix]Good pet.\nNow, to be MY pet you'll have to prove yourself further. Besides the fact I want my pets to be all famous in this little heaven of ours, I want to make sure they follow my orders. For you my dear, I have a few little tasks, nothing you can't do, I'm sure, but it will be the proof I need you can become MY pet.[/say]")
		saynn("He turns around and moves towards his chair, where he sits.")
		saynn("[say=issix]Your first task will require... Trust. In me. Tell me, do you trust me?[/say]")
		addButton("Yes", "Say you trust Issix", "questresponseyes")
		addButton("No", "Say you don't trust Issix", "questresponseno")
			
	if(state in ["questresponseyes", "questresponseno"]):
		GM.main.setModuleFlag("IssixModule", "Quest_Status", 1)
		if checkIncompat():
			saynn("[color=red][b]WARNING: You appear to have AcesWorldbuildingMod mod installed. It will cause incompatibility in this quest line. This mod has been in base game for a while now so it's redundant to have it. Uninstall it and restart the game please.[/b][/color]")
		if(state=="questresponseyes"):
			saynn("Issix grins after hearing the answer.")
			saynn("[say=issix]Excellent. Now, what I want to do is verify your trust, and gain some of my own trust in you. You must be acutely aware how words, especially in this place"+ (" and especially coming from a red like yourself" if GM.pc.getInmateType() == InmateType.HighSec else "") + " can be deceptive.[/say]")
		if(state=="questresponseno"):
			saynn("Issix looks at you, studying you.")
			saynn("[say=issix]Curious. Not the answer I anticipated. It's fine, we can work on that.[/say]")
		saynn("[say=issix]For your first task, you'll need something I'm sure you are now well acquainted with - a blindfold. After all, what is the better tool to test someone's trust than tell them to do something stupid blind?[/say]")
		saynn("He chuckles")
		saynn("[say=issix]You will have to use your little head a bit too before you put one. I'll give you a map, I've drawn it myself, but it has to do. I won't spoil your fun and tell you what it shows, I'm sure you are clever enough to figure it out by yourself, after all, this prison isn't thaaat big, right?[/say]")
		saynn("He winks at you, and lets out a chuckle.")
		saynn("[say=issix]Go next to where the place in X is marked, blind yourself, go through a wall where the X should be and bring me the goods. The number you'll need is 84. And morsel, don't hang in there for too long, trust me on that. Don't worry, I'll know if you succeed or not, don't try to cheat. Remember, trust is the key.[/say]")
		addMessage("You've received a map.")
		addButton("Leave", "Take your leave", "endthescene")
	
	if(state == "quest1bonk"):
		saynn("Before you even start speaking Issix starts laughing maniacally, catching you off guard.")
		saynn("[say=issix]Oh Morsel[/say]")
		saynn("He almost chokes with laughter.")
		saynn("[say=issix]I've been told you- you've had a[/say]")
		saynn("He barely breathes thanks to constant laughter.")
		saynn("[say=issix]certain mee- meeting with a wall.[/say]")
		saynn("He starts recovering from the laughter.")
		saynn("[say=issix]I'm sorry, it was just... I've seen the clip, little birdie showed me it, told me I'd enjoy, and oh morsel, it made my week.[/say]")
		saynn("[say=pc]W-was it all a joke then? Have I passed your trust exercise?[/say]")
		saynn("[say=issix]Haha, don't get ahead of yourself there. I just didn't mention one very important fact, honestly didn't anticipate you trying to be sneaky.[/say]")
		saynn("[say=pc]What do you mean?[/say]")
		saynn("[say=issix]I mean that you weren't supposed to do that at night! I appreciate the attempt, but the mechanism closes shut at night.[/say]")
		saynn("That... Would make sense. Still unsure what mechanism Issix is referring to, but its true that the prison isn't exactly the same when the night comes, and some places are simply locked. "+("Your tail wraps around you in embarrassment" if GM.pc.hasTail() else "You blush in embarrassment")+".")
		saynn("[say=issix]It's fine pet, you didn't know. Go there today and do the same thing, just perhaps not during the night, okey?[/say]")
		addButton("Leave", "Nod and leave embarrassed", "endthescene")
	
	if(state == "quest1turn"):
		saynn("[say=pc]Is... This what you wanted?[/say]")
		saynn("You said with uncertainty in your voice, presenting Issix with a packet of gumball.\nIssix looks at you elated, he claps his paws.")
		saynn("[say=issix]Yes, YES. This is exactly what I needed, morsel.[/say]")
		saynn("He stands up, and takes the packet of gum from your paw.")
		saynn("He opens one end of it and immediately pops one of the gums in his mouth. He goes back to sit on his chair.")
		saynn("[say=issix]You know, a lot of goods in here are generally unavailable to inmates. I knew what I were getting into arriving in here, and didn't really care about most of favorite dishes or products. But this gum? I can't live without it. I were able to make sure it arrives here, in this prison just for myself regularly. You wouldn't believe just how much I had to work to have it delivered, it's not exactly the most popular destination in the galaxy. I have a contact who drops it always in same place where you got it from.[/say]")
		saynn("He savours the taste of gum, closing his eyes and resting his head on chair's headrest.")
		saynn("[say=issix]Ahhhhhh. So good. I've been chewing this brand since I were little, out of all things, it never gets old.[/say]")
		saynn("He looks back at you.")
		if GM.main.getModuleFlag("IssixModule", "Quest_Bonked") == true:
			saynn("[say=issix]I assume no more, akhem, ”wall incidents”?[/say]")
			saynn("He grins")
		saynn("[say=issix]And with just that you've passed my first test. Congratulations! I knew you could do it.[/say]")
		saynn("[say=issix]That would be it for today. For your next time I'll have to prepare a little. I should have something for you tomorrow, so please come then.[/say]")
		addButton("Alright", "Leave", "endthescene")


func calculateHaremScore():
	var score = 0
	score += GM.pc.getPersonality().getStat("Subby")*10  # -10 - 10
	score += clamp(GM.pc.getReputation().getRepLevel(RepStat.Whore), 0, 6)*10 # 0 - 60
	score += clamp(GM.main.getModuleFlag("IssixModule", "Azazel_Affection_given", 0), 0, 8) # 0 - 8
	score += clamp(GM.main.getModuleFlag("IssixModule", "Lamia_Times_Helped", 0), 0, 10) # 0 - 10
	score += clamp(GM.main.getModuleFlag("IssixModule", "Hiisi_Affection", 0), 0, 12) # 0 - 12
	return int(score) # -10 - 100, 90 required to start the quest

func checkIncompat():
	for mod in GlobalRegistry.getLoadedMods():
		if "AcesWorldbuildingMod" in mod:
			return true
	return false

func _react(_action: String, _args):
	if _action in ["questresponseno", "questresponseyes"]:
		GM.pc.getInventory().addItem(GlobalRegistry.createItem("IssixsMap"))

	if _action == "quest1turn":
		GM.main.setModuleFlag("IssixModule", "Quest_Status", 4)
		GM.main.setModuleFlag("IssixModule", "Quest_Wait_Another_Day", true)
		GM.pc.getInventory().removeFirstOf("IssixsMap")  #- might be useful for later?

	if _action == "walkthrough":
		OS.shell_open("https://git.frisk.space/Frisk/Issix-mod/wiki/Walkthrough")
		_action = ""

	if _action == "issixdonate":
		runScene("IssixDonationScreen")
		_action = ""
		
	if _action == "fix_anger_walk2":
		GM.pc.getReputation().addRep(RepStat.Alpha, -50.0)

	if(_action == "endthescene"):
		endScene()
		return
		
	if _action == "subtraining":
		if getModuleFlag("IssixModule", "Sub_Training_Time", 1) == 4:
			_action = "subtraining"+str(RNG.randi_range(1, 3))
		else:
			_action = "subtraining"+str(getModuleFlag("IssixModule", "Sub_Training_Time", 1))
			
		setModuleFlag("IssixModule", "Subbed_for_Issix_Today", true)

	if _action == "enter_cage":
		setModuleFlag("IssixModule", "Sub_Training_Time", 2)
		
	if _action == "subtraining2":
		setModuleFlag("IssixModule", "Sub_Training_Time", 3)
		
	if _action == "accept_oral_service":
		setModuleFlag("IssixModule", "Sub_Training_Time", 4)
		
	if _action == "service_dragon":
		addMessage("This experience changed you, you've became more submissive.")
		processTime(15*60)
		GM.pc.getPersonality().addStat(PersonalityStat.Subby, 0.3)
		
	if _action in ["cage_wait", "shut_down_cage", "chat_cage"]:
		addMessage("This experience changed you, you've became more submissive.")
		processTime(62*60)
		GM.pc.getPersonality().addStat(PersonalityStat.Subby, 0.15)

	if _action == "accept_fix_anger":
		Globals.removeWritingsFrom(GM.pc, BodyWritingsZone.Forehead)
		GM.pc.addBodywriting(BodyWritingsZone.Forehead, "uselesscunt", true)
		
	if _action == "fix_anger_finish":
		setModuleFlag("IssixModule", "Issix_Anger_Noncon", 0)

	setState(_action)


func getDebugActions():
	return [
		{
			"id": "req",
			"name": "Force Requirements",
			"args": [
			],
		}
	]

func doDebugAction(_id, _args = {}):
	if(_id == "req"):
		GM.main.setModuleFlag("IssixModule", "Azazel_Affection_given", 8)
		GM.main.setModuleFlag("IssixModule", "Lamia_Times_Helped", 10)
		GM.main.setModuleFlag("IssixModule", "Hiisi_Affection", 12)
		GM.pc.getReputation().setLevel(RepStat.Whore, 6, false)
		addMessage("Forced all of the requirements to appropriate values")
