extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var savedText = ""
var uniqueItemID = ""
var path = []

func _init():
	sceneID = "AzazelPlushieHover"

func _initScene(_args = []):
	if(_args.size() > 0):
		uniqueItemID = _args[0]
	
func _reactInit():
# 	if(uniqueItemID == null || uniqueItemID == ""):
# 		return
# 	var item: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
# 	
	path = GM.world.calculatePath(GM.pc.getLocation(), getLandLocation())
	if(path.size() <= 0):
		addMessage("Plush shimmers a few times but nothing happens.")
		endScene()
		
	setState("")

func _run():
	if(state == ""):
		saynn("You squeeze the glowing Naked Prince plush, you feel something hard growing out of it, immediately you pull out to see its wings gain in length and becoming leathery. The wings eventually gain enough of size, that even if you stood with your arms stretched in both directions, it would still not be as lengthy as them fully extended.")
		saynn("[say=pc]Woah. So cool.[/say]")
		saynn("The rest of the plush still is fluffy and soft, and yet the wings are somehow steadily attached to it... Somehow. The plush makes a first flap with its wings and you feel the need to hang onto it, which results in the plush taking off as you hang onto its incredibly strong plush body that starts hovering in the air with you dangling like an apple from the tree. Plush, having mind of its own starts to move in some direction, and there is not much you can do other than hang onto it.")
		addButton("Fly", "Hang onto it!", "fly")
		
	if(state == "fly"):
		saynn("You continue to fly over the halls of BDCC while hanging from a magical plushie traveling you.")
		if(path.size() > 0):
			aimCameraAndSetLocName(path[0])
		
		var _roomInfo = GM.world.getRoomByID(path[0])
		
		if(GM.pc.isBlindfolded() && !GM.pc.canHandleBlindness()):
			saynn(_roomInfo.getBlindDescription())
		else:
			saynn(_roomInfo.getDescription())
			
		addButton("Fly", "Continue flying", "fly")
		addButton("Skip", "Skip flying", "skip")
		
	if state == "end_flying":
		saynn("Finally, reaching its destination the plushie weakens its wing flaps until you safely touch the ground, the wings become smaller and smaller until they are just regular plush wings as they were before, the plushie looking as innocent as it always was, except... It lost its glow, both its eyes and the plush itself no longer glow.")
		
		match GM.pc.getLocation():
			"cellblock_orange_nearcell":
				if getModuleFlag("IssixModule", "Lamias_Parasite_Fed_Times", 0) == 0:
					saynn("You land next to Issix's cell, though no Azazel to be found nearby. Curious.")
				else:
					saynn("You land next to Issix's cell, Azazel must be busy feeding Lamia's parasite, best to leave them alone.")
			"yard_waterfall":
				saynn("You landed on the pasture, heh, must have missed today's walk, oh well.")
			"hall_ne_corner":
				saynn("Safely landing next to Azazel he smiles at you.")
				saynn("[say=azazel]Hope you liked your travel! It's super cool, isn't it? Since the plush is bound to me it always attempts to come back to me when you squeeze it.[/say]")
			_:
				saynn("( Whoops! This is not supposed to happen. Please report it. )")
				
		addButton("Stash", "Stash your plushie into your *magical* infinite inventory", "endthescene")
		

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
		
	if(_action in ["fly"]):
		processTime(20)
		GM.pc.addStamina(-2)
		if(path.size() == 0):
			_action = "end_flying"
		
		var nextLoc = path.pop_front()
		
		if(!GM.world.hasRoomID(nextLoc)):
			endScene()
			return
		
		GM.pc.setLocation(nextLoc)
		if(path.size() == 0):
			_action = "end_flying"
	
	if _action == "skip":
		GM.pc.addStamina(-(path.size()*2))
		if path.size() > 0:
			GM.pc.setLocation(path.pop_back())
		processTime(20*(path.size()-1))
		_action = "end_flying"
		
	if _action == "end_flying":
		var item: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
		if item != null:
			item.markAsUsed()
	
	setState(_action)
	
func getLandLocation():
	var land = Globals.getPetLocation("Azazel")
	return land if land != "cellblock_orange_issixcell" else "cellblock_orange_nearcell"

func saveData():
	var data = .saveData()
	
	data["path"] = path
	data["uniqueItemID"] = uniqueItemID
	
	return data
	
func loadData(data):
	.loadData(data)
	
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	path = SAVE.loadVar(data, "path", GM.world.calculatePath(GM.pc.getLocation(), getLandLocation()))

