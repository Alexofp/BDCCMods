extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var mode = "INVALID"

func _init():
	sceneID = "AzazelPlushieChangeMode"

func _initScene(_args = []):
	if(_args.size() > 0):
		mode = GM.pc.getInventory().getItemByUniqueID(_args[0]).changeMode()

func _run():
	if(state == ""):
		saynn("You utter the password you've learned to change plushie's mode „Mūto”. Body of the plush becomes much much "+mode +" to the touch.")
		addButton("Close", "", "endthescene")
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)

func saveData():
	var data = .saveData()
	
	data["mode"] = mode
	
	return data
	
func loadData(data):
	.loadData(data)
	
	mode = SAVE.loadVar(data, "mode", "INVALID")

