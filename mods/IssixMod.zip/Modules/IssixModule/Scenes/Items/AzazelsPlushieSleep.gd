extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "PlushieSleepSummary"

func _initScene(_args = []):
	GM.pc.addEffect("AzazelsPlushie", [GM.pc.getInventory().getEquippedItemByID("AzazelsPlushie")])

func _run():
	if GM.pc.getEffect("AzazelsPlushie") == null:
		endScene()
		return
		
	if(state == ""):
		saynn("When in your slumber, your plushie pulsates and envelops your body in a glowing mist of particles making you "+desc()+".")
		
		addButton("Close", "", "endthescene")
		addButton("Disable", "Disable this scene in the future (effects will still apply)", "disable")

func desc() -> String:
	var effect = GM.pc.getEffect("AzazelsPlushie")
	var level = 0
	var adjective = ""
	var what = ""
	if effect:
		var data = effect.getInfo()
		if data[0]:
			what = "sturdier"
		else:
			what = "resistant to advances by others"
		level = data[1]
	else:
		endScene()
		return ""
	if level < 3:
		adjective = "[color=green]somewhat[/color]"
	elif level < 6:
		adjective = ""
	elif level < 10:
		adjective = "[color=orange]much more[/color]"
	else:
		adjective = "[color=red]extremely[/color]"
	return adjective +" "+ what
	
	

func _react(_action: String, _args):
	if _action == "disable":
		setModuleFlag("IssixModule", "Plushie_Disabled_Sleep_Scene", true)
		_action = "endthescene"
		
	if(_action == "endthescene"):
		endScene()
		return
		

	setState(_action)

func saveData():
	var data = .saveData()
	
	return data
	
func loadData(data):
	.loadData(data)

