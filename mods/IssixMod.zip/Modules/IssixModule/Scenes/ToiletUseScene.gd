extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var usedItemName = ""

func _init():
	sceneID = "IssixToiletUseScene"

func _run():
	if(state == ""):
		saynn("Which bottle would you want to fill with water?")
		
		var items = GM.pc.getInventory().getItemsWithTag(ItemTag.CanPeeInto)
		
		for item in items:
			if(item.getFluids().isFull()):
				addDisabledButton(item.getStackName(), item.getVisisbleDescription())
			else:
				addButton(item.getStackName(), item.getVisisbleDescription(), "fillwithwater", [item.getUniqueID()])
		
		addButton("Back", "Never mind", "endthescene")
		
		
	if(state == "fillwithwater"):
		saynn("You hold the "+usedItemName+" with your hands just under the water tap and then active the flow of water filling the container with water.")
		
		addButton("Continue", "", "endthescene")

func _react(_action: String, _args):
	
	if _action == "fillwithwater":
		var item = GM.pc.getInventory().getItemByUniqueID(_args[0])
		if(item != null):
			var fluids = item.getFluids()
			if not fluids:
				endScene()
				return
			fluids.addFluid("Water", RNG.randf_range(950.0, 1050.0))
			usedItemName = item.getVisibleName()
			
			addMessage("You fill the "+usedItemName+" with some water")
	
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)


func saveData():
	var data = .saveData()
	
	data["usedItemName"] = usedItemName
	
	return data
	
func loadData(data):
	.loadData(data)
	
	usedItemName = SAVE.loadVar(data, "usedItemName", "")