extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "IssixReapplyPiss"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="stand"})
		addCharacter("issix")
		saynn("When you approach the corner you can feel Master's gaze on you. He stands up and sniffs you.")
		saynn("[say=issix]My mark is gone, pet.[/say]")
		if getModuleFlag("IssixModule", "Player_Showered_Since_Last", false):
			saynn("[say=pc]I showered since last time, Master.[/say]")
			saynn("[say=issix]I see, I hope it wasn't because you wanted to get rid of my mark.[/say]")
			saynn("[say=pc]Never! I just had to clean myself...[/say]")
			saynn("[say=issix]That's okey, pet. Let's re-do it.[/say]")
		else:
			saynn("[say=pc]Your mark just worn off, Master.[/say]")
			saynn("[say=issix]That's only natural, let's make sure you are marked as my property again.[/say]")
		
		saynn("Master Issix lowers his uniform boxers to show his {issix.penisDesc} {issix.penisSize} {issix.penis}.")
		addButton("Accept", "Present yourself so you can receive Master's golden mark", "accept_piss")
		Globals.addButtonCheckNoncon("Decline", "Say you don't want to be marked with Master's piss", "decline_piss")
		
	if state == "accept_piss":
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="stand", npcBodyState={naked=true, hard=true}})
		saynn("You kneel before your Master as his figure looms over you, the other pets around are occupied with themselves.")
		saynn("[say=issix]"+RNG.pick(["Now, time for a shower.", "My property must smell like me, wouldn't want anyone to mistake it for a stray, would we?", "I'm glad I can push my bathroom break to some other time thanks to you.", "Let's just get this over with."])+"[/say]")
		var acceptance = getModuleFlag("IssixModule", "Player_Accepted_Marks", 0)
		if acceptance < 4:
			saynn("You are still conflicted about receiving Master's mark. It's degrading. Living in prison full of creatures who are sensitive to smells makes smell one of pretty important senses. Anthropomorphic animals generally don't want to smell like someone else unless they are in a relationship. In this case – strong masculine smell is very telling, and it screams to anyone smelling it – this person belongs to someone else, do not touch. That is your Master's goal, after all. To make this ownership relationship clear.")
		elif acceptance < 12:
			saynn("You are starting to get used to this situation. You've gathered many looks from creatures all around looking at you with disgust, like a property. It's very odd feeling in prison, where you were already degraded to „an inmate” – in here, basically a slave of a corporation. But to be owned by another inmate? That's even on down the ladder, the only way back up would be for you to probably leave this prison... And shower.")
		elif acceptance < 19:
			saynn("Master's marking is already in your blood, you accept it as a matter of fact at this point, they happen and you take them as just another part of routine. You've learned to live with the disgusted looks from other inmates, or degrading comments.")
		else:
			saynn("You await your Master's mark not with conflict in your mind, not with disinterest but... With excitement. You enjoy this situation, you enjoy having your Master's mark, the smell so intoxicating that it became addicting. It is your new normal, and not having it feels weird. You flaunt it and enjoy the disgusted looks of others, the degrading comments are like compliments to you.")
		
		say("A stream of urine from your Master's {issix.penis} hits your "+Globals.getSkinWord()+(", you can almost feel it soak into it." if "fur" in Globals.getSkinWord() else "."))
		if acceptance > 18:
			say("You feel happy to feel Master's urine, it feels right.")
			
		addButton("Finish", "The stream dwindles", "after_piss")
		
	if state == "after_piss":
		saynn("Finally the stream of urine ceases. Not an insignificant portion of your "+Globals.getSkinWord()+" will be wet for a while, with urine mainly hitting your chest, throat and leaking down your crotch.")
		
		saynn("[say=issix]Now, this is the right perfume for you. Go out there and flaunt your Master's smell.[/say]")
		saynn("[say=pc]Yes, Master![/say]")
		
		saynn("[say=issix]Good pet.[/say]")
		addButton("End", "Finish", "endthescene")
		addButton("Disable", "Don't show this scene again (you'll still be marked)", "disable_scene_piss")
		
	if state == "decline_piss":
		saynn("[say=pc]I'm sorry Master, I don't want to be marked today.[/say]")
		if (getModuleFlag("IssixModule", "Issix_Mood", 0) > 95 and RNG.chance(85)) or getModuleFlag("IssixModule", "Player_Accepted_Marks", 0) > 15:
			saynn("[say=issix]Hmm. If that's so then so be it. But I expect you tomorrow.[/say]")
			addButton("Leave", "Leave", "endthescene")
		else:
			saynn("[say=issix]Huh? You don't want to get marked by your Master?[/say]")
			saynn("Your Master's voice is a mix of disappointment and cockiness.")
			saynn("[say=pc]... I don't want to get marked to- [/say]")
			saynn("[say=issix]Silence.[/say]")
			saynn("[say=issix]It is for me to decide when my pets receive my mark. Clearly, you don't understand the meaning of what it is to be my pet yet, I'm sure that with more training you'll start seeing it.[/say]")
			saynn("[say=issix]But now, kneel. I won't repeat myself.[/say]")
			addButton("Obey", "Seeing how pointless it would be to refuse your Master you do what you've been told", "forced_piss")
			
	if state == "forced_piss":
		saynn("Shortly after Master says it, you are marked with his piss.")
		saynn("[say=issix]And NOW you smell like my property. Do NOT forget who OWNS you.[/say]")
		saynn("He says with dissatisfaction in his voice.")
		addButton("Thank", "Thank your Master for the mark", "thank_piss")
		addButton("Leave", "Just leave", "endthescene")
		
	if state == "thank_piss":
		saynn("[say=pc]Thank you Master for your mark.[/say]")
		saynn("[say=issix]Good pet.[/say]")
		addButton("Leave", "You can leave now", "endthescene")


func _react(_action: String, _args):
	if _action == "accept_piss":
		processTime(2*60)
		GM.pc.cummedOnBy("issix", FluidSource.Pissing, RNG.randf_range(0.4, 0.8))
		increaseModuleFlag("IssixModule", "Player_Accepted_Marks")
		
	if _action == "forced_piss":
		processTime(2*60)
		GM.pc.cummedOnBy("issix", FluidSource.Pissing, RNG.randf_range(0.4, 0.8))

	if _action == "disable_scene_piss":
		setModuleFlag("IssixModule", "Watersports_Scene_Ignored", true)
		_action = "endthescene"
		addMessage("This watersports scene will no longer appear.")

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Watersports_Ignore_Today", true)
		endScene()
		return

	setState(_action)
