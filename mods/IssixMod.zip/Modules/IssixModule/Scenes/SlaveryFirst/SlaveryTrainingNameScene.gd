extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

const jokes = {"steve": "While BDCC is a perfect place for those yearning for the mines, you deserve a better one.", "frisk": "Your name... {pc.name}, a true hero working for peace or genocidal maniac? *chuckle* Ignore that.", "rahi": "Your old name, Rahi... Man, I can never get rid of this incredibly eerie feeling I have each time I hear it.", "sex": "{pc.name} Never liked your old name, let's be honest, it's uncreative, it sucks, but certainly does not fuck.", "roar": "Hah, I remember someone of that name making my portrait once, a fine fellow.", "name": "Besides, let's face it {pc.name}. Name is not a good name. You did not understand the assignment when you were asked for one.", "donald": "Believe me. What name I have for you is one nobody have ever heard before. Nobody has a better name, nobody. It's incredible. I'm going to make your name great again, you'll see.", "mario": "By the way, I've heard BDCC needs some plumbing help, sounds like you'd be great, if you weren't an inmate."}

func _init():
	sceneID = "IssixSlaveryNameTraining"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="sit"})
		addCharacter("issix")
		saynn("[say=pc]Master, could we talk... About what you asked me about before?[/say]")
		saynn("[say=issix]The meaning of life? Which dimension do all the lost socks go to? How are you able to hold infinite amount of horse dildos without any backpack, bag or even pockets?[/say]")
		saynn("[say=pc]I meant the name change, though the last question sound inter-[/say]")
		saynn("[say=issix]Ah right, the name change! Of course. I'm so glad. So, I come to understanding you are interested in getting a new name?[/say]")
		saynn("[say=pc]I suppose...[/say]")
		saynn("[say=issix]And you are absolutely okey with that?[/say]")
		saynn("[say=pc]Of course, Master, this is why I'm here.[/say]")
		saynn("[say=issix]Excellent. In that case, let's continue. "+jokes.get(GM.pc.getName(), "")+"[/say]")
		
		saynn("[say=issix]I want you to have something befitting my pet.[/say]")
		saynn("[say=issix]Are you curious? What new name I have chosen for you?[/say]")
		saynn("Other pets look at you two, their attention captured.")
		addButton("Continue", "", "get_new_name")
		
	if state == "get_new_name":
		addCharacter("azazel")
		addCharacter("lamia")
		addCharacter("hiisi")
		saynn("[say=issix]It's [b]Seir[/b]. I want you to be known as Seir from now on. This is how you'll be known.[/say]")
		saynn("[say=azazel]Woooah, Seir. It's... Interesting.[/say]")
		saynn("[say=hiisi]It's a good name I think.[/say]")
		saynn("Lamia nods.")
		saynn("Issix puts a finger below your chin and raises your head slightly.")
		saynn("[say=issix]So what do you think? Do you like my name for you, "+Globals.getPlayerPetName()+"?[/say]")
		addButton("Yes", "Of course, Master", "accept_name")
		if GM.main.getModuleFlag("IssixModule", "Noncon_Mode_Enabled", false) == true:
			addDisabledButton("No", "Something in you prevents you from disagreeing with Master's decision")
		else:
			addDisabledButton("No", "You are too much of a pet to say something so rude to your Master")
		
	if state == "accept_name":
		saynn("[say=pc]Of course Master, I'd love to be [b]Seir[/b] from now on.[/say]")
		saynn("Master smiles knowingly, putting a finger under your inmate collar and pulling you closer to his face.")
		saynn("[say=issix]In this case, let's make it real, in here, right now.[/say]")
		if ResourceLoader.exists("res://Modules/FoxLib/Resources/NotoSansRunic-Regular.ttf"):
			saynn("He hovers his paw above your head, looking in your eyes with his dominating look he begins chanting.")
			saynn("[say=issix][color=#ff5100][runic]ᚤᛟᚢᚱ ᚾᚨᛗᛖ ᚠᛟᚱᚠᛖᛁᛏ, ᛁ ᛏᚨᚴᛖ ᛁᛏ ᚠᚱᛟᛗ ᚤᛟᚢ.[/runic][/color][/say]")
			saynn("[say=issix][color=#ff5100][runic]ᛁ ᛗᚨᚴᛖ ᚤᛟᚢ ᚾᛟᚹ ᚨᚾᛖᚹ, ᚹᛁᛏᚺ ᚾᚨᛗᛖ ᛟᚠ ᛗᚤ ᛟᚹᚾ.[/runic][/color][/say]")
			if not Species.Demon in GM.pc.getSpecies():
				saynn("[say=issix][color=#ff5100][runic]ᛁᚾ ᛋᛖᚱᚡᛁᚲᛖ ᛟᚠ ᛁᛋᛋᛁᛪ ᚨ ᚾᛖᚹ ᛞᛖᛗᛟᚾ ᛒᛟᚱᚾ, ᛏᚺᛖᛁᚱ ᚾᚨᛗᛖ ᛋᛖᛁᚱ.[/runic][/color][/say]")
			else:
				saynn("[say=issix][color=#ff5100][runic]ᛞᛖᛗᛟᚾ ᚹᚺᛟ'ᛋ ᛟᛚᛞ ᚾᚨᛗᛖ ᛋᚺᚨᛚᛚ ᛒᛖ ᚠᛟᚱᚷᛟᛏᛏᛖᚾ, ᚹᛁᛚᛚ ᚾᛟᚹ ᛋᛖᚱᚡᛖ ᛁᛋᛋᛁᛪ ᚢᚾᛞᛖᚱ ᚾᚨᛗᛖ ᛟᚠ ᛋᛖᛁᚱ.[/runic][/color][/say]")
		else:
			saynn("He hovers his paw above your head, looking in your eyes with his dominating look he begins chanting in unknown to you language.")
			
			saynn("[say=issix]* chants *[/say]")
			
		saynn("The moment feels grand, your Master became very serious when chanting and the air became very thick, if not a little suffocating. Audience of three pets behind you captivated by the spectacle. As Issix finishes his chant, something changes, you can't quite put a finger on it, but its significance feels to your subconscious mind like something way grander than just your name. Something clicks, and you don't know why. In your moment of pondering the demon dragon steals your attention once again, his black soul-sucking eyes focused on you, his face – showing satisfaction like you've never seen this face show before.")
		addButton("He speaks", "You listen", "after_ritual")
		
	if state == "after_ritual":
		playAnimation(StageScene.ChairOral, "tease", {pc="issix", npc="pc", bodyState={naked=true}, npcBodyState={}})

		saynn("[say=issix]It is done, Seir, my dear pet. Your old name forgotten, thrown away. You'll never use it again. From now on, you are Seir, servant of Issix. Do you understand?[/say]")
		
		saynn("[say=pc]Yes, Master. My name is Seir, and I'm your servant.[/say]")
		
		if GM.pc.isBitingBlocked() or GM.pc.hasBlockedHands():
			saynn("[say=issix]Of course you are, pet. I'd make you serve me today but.. To be frank, you look right in your gear and I wouldn't want to mess up your look... Unless you'd want that, but you'll have to lose your gear.[/say]")
			addButton("Unequip gear", "Ask for help with your restraints and start servicing your Master", "unequip_gear")
			addButton("Nah", "You are fine in your hear, don't service your Master", "dont_service_gear")
		else:
			saynn("[say=issix]Of course you are, pet. Now, prove your servitude, can you?[/say]")
	
			saynn("He stands up, loses his clothes and sits back down.")
	
			saynn("[say=issix]You can suck me off.[/say]")
			saynn("It was an order, you realize.")
			addButton("Suck it", "Do as you are commanded", "suck_off")
			Globals.addButtonCheckNoncon("Don't", "You are not feeling like sucking him off", "dont_suck")
		
	if state == "dont_suck":
		saynn("[say=pc]I'm sorry Master, I... Don't feel like doing that.[/say]")
		saynn("[say=issix]Tsk. I thought you know better than to disobey my orders. Begone then. Azazel, come here.[/say]")
		addButton("Leave", "And so, you are dismissed, somehow.", "endthescene")
		
	if state in ["suck_off", "unequip_gear"]:
		playAnimation(StageScene.ChairOral, "suckfast", {pc="issix", npc="pc", bodyState={naked=true, hard=true}})
		if state == "unequip_gear":
			saynn("[say=pc]I want to serve you, Master![/say]")
			
			saynn("[say=issix]If you insist, let's unstrap you then, pet.[/say]")
			saynn("Issix proceeds to take off your restraints, afterwards he loses his own clothes and sits back on his chair.")
			saynn("[say=issix]Now, get to work.[/say]")
		saynn("Of course, there is no way you could pass off on such an offer to service your Master. Your mouth hungry for his cock dives to his crotch.")
		saynn("[say=issix]Start with balls, I have a certain itch that you can help with.[/say]")
		saynn("[say=pc]io![/say]")
		saynn("Welp escapes your mouth as you are buzzing with excitement at prospect of servicing Master. You take the opportunity by first getting a good sniff of his manhood, strong masculine, musky aroma. While he certainly tries to keep himself clean, production of male musk happens at all times, and he is certainly a good proof of that.")
		saynn("You bask in glory of your Master's hard cock, worshiping it. Giving it occasional licks, intimately making out with it, covering it with your slobber. Smooth surface of Master's penis feels wonderful on your tongue, and his taste will stay lingering in your mouth for a long while.")
		saynn("[say=issix]Ahhh, what a hungry mouth, why don't you take your treat already, huh? I know you crave it, slut.[/say]")
		saynn("As he says it, you take a peek at his lusty face and take the {issix.penis} in side of your warm mouth, soon after you are helped by Issix's paw at the back of your head setting a rhythm for going down on the dick.")
		saynn("[say=issix]Fuck yeah. Keep going, {pc.name}. Reward your Master for giving you your name.[/say]")
		saynn("And so you do, full of gratefulness you go down on his cock, making sure to be a good fleshlight for your Master. A thank you, for his care and love. Minutes pass by as your lovemaking continues.")
		saynn("[say=issix]I'm nearing it, gonna cum.[/say]")
		addButton("Stay", "Just keep pleasuring your Master until the very end", "stay_at_it")
		addButton("Pull out", "Move your head back for the monster to pull back from your mouth.", "pull_out")
		
	if state == "pull_out":
		playAnimation(StageScene.ChairOral, "suckfast", {pc="issix", npc="pc", pcCum=true, bodyState={naked=true, hard=true}})
		saynn("As you hear Master's warning your face pulls out of his crotch and as soon as it does, almost as if synchronized Issix's hard shaft erupts with white semen hitting your face, covering it whole with baby batter.")
		saynn("[say=issix]Heh, you look just fine like this slut. Here, have a tissue, won't help you with my smell but at least you won't get any in your eyes, that shit doesn't feel great.[/say]")
		
		saynn("[say=pc]Thank you, Master. I enjoyed servicing you.[/say]")
		saynn("[say=issix]Not the last time, I hope.[/say]")
		saynn("He chuckles, after you clean yourself and trash entirely wet tissue you are dismissed by your Master, with your new name.")
		addButton("End", "You are dismissed", "endthescene")
	
	if state == "stay_at_it":
		playAnimation(StageScene.ChairOral, "suckinside", {pc="issix", npc="pc", bodyState={naked=true, hard=true}})
		saynn("You hear Master's warning but you do not relent, continuing to bob your head on his throbbing hog of a penis, tasting the pre, being fully ready for the main dish. And so it happens, Issix orgasm comes to a climax filling your hungry mouth with his spunk. You swallow the salty fluid eagerly feeling the sperm hitting the back of your throat in pulsating rhythm until it ends.")
		saynn("[say=issix]Argghh, good to the very end. What a good pet you are. You've done good. Thank you, {pc.name}.[/say]")
		saynn("[say=pc]Ith ish a pleshuure to sherwhee youuhh.[/say]")
		saynn("Wanting to answer Master in quick manner you spew your response still with plenty of swallowed spunk in your mouth making a mess in short distance and yourself.")
		saynn("[say=issix]Too excited for your own good, what a cumslut heh. Have some help, and swallow next time before speaking.[/say]")
		saynn("Issix passes you a tissue which you use to clean your face from his spunk, you are unable to clean yourself fully with sperm permeating your "+Globals.getSkinWord()+" however you do not mind Master's smell on you.")
		addButton("End", "You are dismissed", "endthescene")


func _react(_action: String, _args):
	processTime(2*60)
	
	if _action == "unequip_gear":
		Globals.undressBlockingRestraints(GM.pc, [InventorySlot.Mouth, InventorySlot.Hands])
	
	if _action == "after_ritual":
		GM.pc.getSkillsHolder().addPerk("PetName")
		GM.pc.getSkillsHolder().getPerks()["PetName"].runOnceWhenLearned()  # Doesn't run with addPerk()
		
	if _action == "dont_suck":
		Globals.addIssixMood(-3)
		
	if _action == "pull_out":
		GM.pc.cummedOnBy("issix", FluidSource.Penis)
		
	if _action == "stay_at_it":
		GM.pc.cummedInMouthBy("issix", FluidSource.Penis)
		GM.pc.cummedOnBy("issix", FluidSource.Penis, 0.1)
		GM.pc.addSkillExperience(Skill.CumLover, 15)

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Obtained_New_Name", true)
		endScene([true])
		return

	setState(_action)
