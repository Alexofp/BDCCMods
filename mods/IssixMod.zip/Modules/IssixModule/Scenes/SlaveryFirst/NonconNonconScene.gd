extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var reason = null

func _init():
	sceneID = "NonconNonconScene"
	
func _initScene(_args = []):
	reason = _args[0]  # disobedience or violence

func _run():
	if(state == ""):
		addCharacter("issix")
		if reason == "disobedience":
			saynn("First thing Issix did after bounding and gagging you in place was give you injection right in your neck. With no explanation given, the only way to understand its effects is by observing yourself, your feelings and senses.")
			saynn("And it's difficult to recognize the effects of the injection when your entire body is in panic mode and you don't recognize which symptom is real and which is created by your own paranoia.")
			saynn("[say=pc]Mhhh- mhhhhhhhmpphh![/say]")
			saynn("[say=issix]Yeah, yeah, anyone would be panicking in this situation. Can't blame you for that my little pet. Truth be told, I never like doing what I'm about to do. It reminds me of what I remember seeing in my AlphaCorp days, dark days...[/say]")
			saynn("He seems to stop for a moment, looking away as if daydreaming and reminiscing of the past.")
			saynn("[say=issix]So anyway, tell me, pet, what happened? Why did you decide to just disobey me so many times? Did I do something wrong? Am I a bad Master?[/say]")
			saynn("He waits for response, before realizing one crucial detail.")
			saynn("[say=issix]Oh, right, my bad. I... That's awkward. That was a genuine question, I just forgot that... Eh, scratch that.[/say]")
			
			saynn("Soon he resumes to be busy with machinery somewhere above your head.")
			
		else:
			saynn("Your eyes open, the world is a blurry mess at first, colors swirling until they slowly come into place, world becoming clearer.")
			saynn("[say=pc]whaaa?[/say]")
			saynn("Still unable to speak properly you try to turn your head only to find resistance, something is keeping it straight.")
			saynn("[say=issix]Welcome back. Enjoying yourself?[/say]")
			saynn("Voice, that makes you angry, speaks out. Memories flood back, you were in medical confessionary and you were trying to make Issix pay but... Something didn't work out, the two that you saw were probably collaborating with Issix, they trapped you. You test the various bounds on your body, but they hold well. With your still weakened body there is no way you can break them.")
			saynn("[say=issix]{pc.Name}, you don't deserve comfort. Probably never did, and never will. But it's okey, you won't exist for much longer.[/say]")
			saynn("Your blood boils, is {issix.he} just going to kill you? Just like that?")
			match getModuleFlag("IssixModule", "Chemicals_Chosen", ""):
				null:
					pass
				"81'm'80":
					saynn("As the feeling comes back to your body, you feel different.")
					saynn("[say=issix]My friends tipped me off about some surprise you've had for me. And really, you didn't have to bring me any presents, you know? That said, thank you, I've made sure to inject you with the vial I've found on you. The physical changes already kicked in, you've got a nice pair of breasts, and looking more feminine than ever. Suits you, and your future life, I guess.[/say]")
					saynn("[say=issix]Mental changes will take a bit longer, your successor will appreciate those.[/say]")
				"NULLX":
					saynn("As the feeling comes back to your body, you feel different.")
					saynn("[say=issix]My friends tipped me off about some surprise you've had for me. And really, you didn't have to bring me any presents, you know? That said, thank you, I've made sure to inject you with the vial I've found on you. And well, I can't say I'm impressed, but regardless, you still have a hole to fill.[/say]")
				"8R006'm'0TH34":
					saynn("As the feeling comes back to your body, you feel different.")
					saynn("[say=issix]My friends tipped me off about some surprise you've had for me. And really, you didn't have to bring me any presents, you know? That said, thank you, I've made sure to inject you with the vial I've found on you. Looks like you'll make a great mother with your new body.[/say]")
				"H1'm'80":
					saynn("As the feeling comes back to your body, you feel different.")
					saynn("[say=issix]My friends tipped me off about some surprise you've had for me. And really, you didn't have to bring me any presents, you know? That said, thank you, I've made sure to inject you with the vial I've found on you. Looks like you'll make a great mother with your new body. The physical changes already kicked in, you seem more manly. Suits you, and your future life, I guess.[/say]")
					saynn("[say=issix]Mental changes will take a bit longer, your successor will appreciate those.[/say]")
			
		saynn("[say=issix]So, here is how it's going to be...[/say]")
			
		addButton("Listen", "You don't have much choice on the matter. Bound to medical bed there is zero chance of escape, so you might as well listen", "explanation")
		
	if state == "explanation":
		if reason != "disobedience":
			saynn("[say=issix]I'm going to make you into my pet. You've been particularly troublesome and you misunderstand your place in this facility. You've inflicted harm onto my pets multiple times and I cannot tolerate anything of this sort.[/say]")
			saynn("[say=issix]You may question, how will I make you my pet? I'm sure you are quite... resistant to such an idea. It's okey. You don't have to accept it, because the truth is that I do not need your permission. You've met Hiisi. He was just like you, a troublemaker, a naughty pup who thought too much of himself. He came here in red inmate uniform and thought of the prison as his own. Both Azazel and Lamia had... Less than positive encounters with him. Come to think of it... Yes, you were very alike with how you choose to be.[/say]")
			saynn("[say=issix]Guards, inmates... Everyone had issues with him. He was enemy of prison number one, physically capable asshole with too much energy.[/say]")
			saynn("He speaks calmly, continuing to work with something you can't see while speaking.")
			saynn("[say=issix]So what I did was take him in here, I put a little chip in his head, it makes creatures... More compliant, easier to control. And control is exactly what I needed. And so he was on bed similar to the one you are laying on right now. Upgrades, upgrades![/say]")
			saynn("[say=issix]The chip is one part of the plan. It can steer behaviors and give the operator some degree of control over how someone thinks, what kind of behaviors they have, more advanced ones can issue clear commands and be in general more complex. And those are exactly the ones I use. Top notch technology, not cheap, mind you.[/say]")
			saynn("He pauses for a moment.")
			saynn("[say=issix]But safety of my pets is paramount.[/say]")
			saynn("[say=issix]You know, back at original Hiisi's time, after the operation even prison's management thanked me. I couldn't care any less, but Hiisi's troublemaking was universally hated, and prison staff knew exactly what happened. You don't build high security prison and not know what happens in it, that's besides the fact that the most aggressive and problematic inmate suddenly turned into another inmate's obedient puppy is extremely fucking suspicious.[/say]")
			saynn("[say=issix]Nobody liked him.[/say]")
			
			saynn("[say=issix]Does he know of that? I hardly doubt. I wouldn't be telling you all of this if the same fate didn't await you. For the operation to succeed, I'll have to wipe your mind a little. Or rather, a lot. If you wanted this chip voluntarily this wouldn't be a big issue, you could still have your memory. Alas, different circumstances brought us together, and you knowing yourself could make it a lot more difficult, for me and for yourself. So I'm afraid you'll not remember much of yourself.[/say]")
			saynn("[say=issix]Though I like to think I'm doing you a huge favor, you know {pc.name}? Life of a violent person like yourself is a miserable one. You can't form proper connections, cannot enjoy life, don't you think? Or maybe I misunderstand your lifestyle? What is the lifestyle of beating everyone around up? Have you fallen into vicious cycle of violence from your youth? Had rough parents? Want to be macho alpha? Or maybe you are a sadist, huh?... Not that it matters, not anymore. Trust me, you don't need this kind of life, I'll give you something better.[/say]")
		else:
			saynn("[say=issix]I'm finally going to make you listen. There are many different types of pets, some are not capable of understanding, have you ever had a goldfish?... You are quite different from such a creature, you can understand and act upon your own desires. You understand complex commands, you are sophisticated. It's undignified for such a sophisticated pet to ignore or disobey its Master.[/say]")
			saynn("[say=issix]This is why I want to correct this. It's unfortunate I weren't able to teach my pet obedience using less... Forceful methods, however I don't think I can afford disobedience and rebellion, and honestly? I'm too old for that. Which means I have to turn to miracles of technology.[/say]")
			saynn("In your field of vision comes a paw wrapped in latex glove, between its fingers is a small spherical transparent capsule, in its center a barely visible object of size of maybe grain of sand.")
			saynn("[say=issix]You can barely see it, and even if you do, you can't say much about it, can you?[/say]")
			saynn("[say=issix]This little thing is a chip inside some clever engineering. When its in someone's brain matter, or rather, in between of it, it is capable of changing one's behaviors. This brain implant can make someone obedient, complicit, fulfilling my commands and wishes will come natural to you, and overwrite any other objective of yours. It's not a cheap toy, but sophisticated way to control someone.[/say]")
			saynn("[say=issix]Probably the only reason Alpha Corp doesn't use it for rehabilitation of „wrong thinking” individuals instead of sending them to prisons is that this thing is hella expensive, otherwise they'd already have an army of disappeared puppets.[/say]")
			
		addButton("Continue", "", "cont_explanation")
		
	if state == "cont_explanation":
		saynn("[say=issix]There are a couple of elements required for this operation to work, first one was to inject you with a substance that will ease in the later part. It will help with integrating the module in your body. I also mixed it with some other things, primarily something to help you relax, too much stress can only be bad for you.[/say]")
		saynn("He lets out a laugh.")
		saynn("[say=issix]Secondly... I need to get this metal arm positioned riiighhtttt heeerrreee.[/say]")
		saynn("You can hear some heavy metal machinery moving behind your head, eventually tip of something metallic and cold touches tip of your head, a gentle tap that stays there.")
		saynn("[say=issix]Good good.[/say]")
		saynn("You try to move your head to no avail. The restraints are so well fit that any movement of any body part is practically impossible.")
		saynn("[say=issix]With all of this done, I think we can proceed to stage where you are unconscious. If not for the fact I need to make a little disappearing act with parts of your memory I would not have to do that. So really, you have only yourself to blame, and now...[/say]")
		saynn("You can only see as the transparent mask gets lowered onto your face.")
		addButton("Whimper", "Whimper and shake", "whimper_and_shake")
		addButton("Accept", "Don't do anything", "acceptance")
		
	if state in ["whimper_and_shake", "acceptance"]:
		if state == "whimper_and_shake":
			saynn("You try to give some struggle to what's happening, even though you know it's quite useless. All of the shackles, all of the bondage on you is simply too powerful for you to break free. You can only symbolically express your fear.")
			saynn("[say=pc]Mphhhh, mmmmmM!!!![/say]")
		
		saynn("Soon after the mask seals your face away and a sweet smelling gas fills the space in between of its surface and your face, at first you attempt not to breathe it in, however your attempts are futile and soon you yield. Last thing you hear before falling is...")
		saynn("[say=issix]Good niiiighhtt![/say]")
		addButton("Blackness", "A blackness, void surrounds you as you yield to the nothingness", "yield_to_sleep")
		
	if state == "yield_to_sleep":
		if reason != "disobedience":
			saynn("Consciousness of reality fades away. What is left, is the world of dreams, the screen in a theater displaying its last screening.")
			saynn("And so you see your own life, or rather, some memorable moments from it. You become reminiscent of your past, thinking and seeing countless times that awkwardness of haunts you to this day, the moments of happiness spending time with those who enjoyed you, and the sad times are there too. All of those as if a collage of short films go through you. You somewhat realize you aren't truthfully conscious of what's happening, that all you see is your real past, your identity, your memories. And you feel your connection with those fade away. You thought it would be scarier than this, losing your memories. But somehow... You can't bring yourself to have emotions in this state.")
			saynn("Things you knew all well, the places on the planet you were on before you got sent to the prison, the taste of your favorite foods, the faces of your relatives... They are disappear as if they were too insignificant to muscle up an effort to preserve them. But reality is that you are simply this helpless. All you can do is watch them disappear and forget about them.")
			saynn("Memory after memory, feeling after feeling, feeble occurrences saved in your fragile brain matter lost to endlessly hungry void.")
			saynn("Even something as important to any creature – your own name, you can see its letters – [b]"+" ".join(GM.pc.getName().split(""))+"[/b] disappearing one by one into the void, and with last of them you feel like you've lost something so important to you.")
			saynn("This emptiness soon becomes filled by something else, a new name. Or is it new? Was it there before? [b][pulse color=#ff2b00 height=0.0 freq=2.0]Seir[/pulse][/b]. It's your name. It always was, right?")
			saynn("The more times you repeat the name, [b][pulse color=#ff2b00 height=0.0 freq=2.0]Seir[/pulse][/b], the more natural it feels, it becomes so obvious to you, how could you forget it? It's your name. A part of you so significant, a way for yourself and others to identify yourself. It's so ingrained deep within you, it's laughable concept for you to forget it.")
			saynn("Emotions flood your brain at once. Appreciation for your [b]Master[/b], concern for your [b]Master[/b], love for your [b]Master[/b]. You remember how wonderful your [b]Master Issix[/b] is, and you cannot wait to wake up and serve him again, like you did for a long time now. How long? You can't recall, but its been long.")
			
		else:
			saynn("Consciousness of reality fades away. What is left, is the world of dreams, one filled by the harem you are so happy to be in. Fulfilled, yes, that's the word. You are [b]fulfilled[/b] by being in it. You love the horny and always fun Azazel, the trickster. You love Hiisi – the guardian protector of the harem, always committed to protecting those part of the harem, and of course Lamia – sunshine and always happy fox breed with artistry matched by no one else in the prison. They are such awesome pets of your common [b]Master Issix[/b].")
			saynn("You recall so many moments spent with other pets. All of them happy moments. Helping others, laughing from jokes, reading books together, sharing food, playing and exercising together.")
			saynn("And then of course, your Master. The demon-dragon. You have many names for him. Owner, superior, protector, kind soul and of course the main word [b]Master[/b].")
			saynn("You adore him, enjoy being under his care and most importantly you love serving him. He is the one instilling discipline, the one to feed you, the one to allow you the privilege of being his servant.")
			saynn("Your visions are filled with all of them, pets and your Master. They are your family, one that you wouldn't want to exchange for anything in your life. They are precious to you.")
			saynn("[tornado radius=3.0 freq=1.5 connected=1][pulse color=#ff2b00 height=0.9 freq=1.0]You love them.[/pulse][/tornado]")
			
		addButton("Wake up", "", "wake_up")
		
	if state == "wake_up":
		saynn("Your eyes open. You are... On a bed inside of what looks to be a dark room. You move your paw freely before your face, it looks just fine. As opposed to how your head feels. Pulsating pain, headache. You are highly disoriented, your body sweats a little. your legs and arms feel numb.")
		if reason != "disobedience":
			saynn("[say=issix]There you are, how do you feel? Do you recall your name?[/say]")
			saynn("You recognize this voice, it's one of your [b]Master[/b].")
			saynn("[say=pc]Uhhh, name? It's... {pc.name}?[/say]")
			saynn("You say, a little bit unconvinced by your own answer. It feels natural to say it but subconsciously you feel like the answer is wrong for some reason?")
			saynn("[say=issix]Ahh, good, I'm glad. The doctor have said that there could be complications like memory loss.[/say]")
			saynn("[say=pc]Uhhhh.[/say]")
			saynn("You are still a bit dazed from entire ordeal.")
			saynn("[say=issix]Do you remember who I'm? Where you are? Why you are here?[/say]")
			saynn("[say=pc]I remember... You are my Master. I'm in... A prison?[/say]")
			saynn("You strain yourself an try to recall more, but to no avail, as if what separated you from the truth was a thick fog.")
			saynn("[say=issix]It's okey, you'll have time to remember. I think you remember the most important parts. You are in a prison called BDCC, and you just had an operation, the doctors left but I stayed for you, my pet.[/say]")
			saynn("You give no response, still recovering. You do have a brief moment of confusion, why would doctors leave so quickly? Why would the room be so dark? Why are you in a prison? But those thoughts are quickly pushed aside.")
			saynn("[say=issix]Come, take it slow.[/say]")
			saynn("He gives you his paw to stand up from the bed, you move your legs and body to stand up from the bed.")
			
		else:
			saynn("[say=issix]There you are, how do you feel?[/say]")
			saynn("[say=pc]I'm... Fine? I think?[/say]")
			saynn("[say=issix]Thank the intergalactic squid you are fine. I were a bit worried, not gonna lie, you've slept longer than I expected you to.[/say]")
			saynn("[say=pc]W-what happened Master?[/say]")
			saynn("[say=issix]... You've fallen victim to serious medical condition which had to be operated. All I can say is that the operation was a success. I've asked the doctors to leave us alone in here to when you wake up, too much stimuli when you wake up, that could only be bad.[/say]")
			saynn("[say=pc]I see..[/say]")
			saynn("It does make sense, you think, though why is the room dark? You can't remember what happened before you ended up in here. You remember the harem, Issix, who you are but not much beyond that.")
			saynn("[say=issix]It might still feel a little bit cloudy, bbut with time it should be better. Take it all slow.[/say]")
			saynn("You nod.")
			saynn("[say=issix]Take my paw and let's go when you are ready.[/say]")
			saynn("A paw gets extended towards you, you move your legs, and body to stand up from the bed.")
		
		addButton("Take paw", "Take paw and follow Issix", "back_harem")
		
	if state == "back_harem":
		aimCameraAndSetLocName("hall_mainentrance")
		saynn("You take your Master's paw and head towards the doors of this room. Everything still feels cloudy to you and you are incredibly disoriented.")
		
		saynn("[say=issix]We are not in a hurry, in fact... I think it's pretty late already. Azazel, Lamia and Hiisi are likely already in their cells. Why don't we go to your cell? You need to rest after the operation, and I'm not letting you go there alone, you are still weakened.[/say]")
		saynn("[say=pc]Y-yes Master, I'd like that.[/say]")
		saynn("And so you move through the almost empty halls, with majority of inmates already in their cells you stumble through the prison to reach your own cell along with your Master assisting you, helping you stand and walk.")
		saynn("[say=issix]You are doing well. Just a little further through the stairs.[/say]")
		addButton("Continue", "Continue walking", "back_cell")
		
	if state == "back_cell":
		aimCameraAndSetLocName(GM.pc.getCellLocation())
		saynn("You walk the stairs down to reach the cell block, and from there a straight route to your [color="+GM.pc.getInmateColorString()+"]"+GM.pc.getInmateTypeString()+"[/color] block and to find your cell.")
		saynn("[say=issix]Here we are, your cell.[/say]")
		saynn("He tucks your limp body to the bed.")
		if reason != "disobedience":
			saynn("[say=pc]Master, uhhh, I don't remember anything.[/say]")
			saynn("[say=issix]Hmm, yes, is there anything specific you'd want to know before resting?[/say]")
			saynn("[say=pc]I just feel so... Lost.[/say]")
			saynn("[say=issix]All is okey, pet. I'm here, what do you need?[/say]")
			saynn("[say=pc]Like, what am I even doing here? I don't remember how Master became my... Master and...[/say]")
			saynn("[say=issix]Shhh, those are big questions. It's late, get some rest, okey pet? We'll talk about those some other time, if you don't remember by yourself, I'll be happy to explain to you.[/say]")
			saynn("[say=pc]Okey, Master...[/say]")
		saynn("[say=issix]I'll see you in the morning, good night "+Globals.getPlayerPetName()+", sleep well.[/say]")
		saynn("Somehow you can't not feel grateful for just how much your Master cares about you and your well being. It doesn't take long for you to fall asleep.")
		addButton("Zzz...", "Yield to sleep", "sleep")
		
	if(state == "slept"):
		playAnimation(StageScene.Sleeping, "sleep", {bodyState={naked=true}})
		
		saynn("You slept in your cell. It's not the most pleasant experience but you managed to recover your energy.")
		
		saynn("You wake up when all the prison lights begin to turn on, considering the commotion you've woken up slightly later than usual.")
		
		saynn("Welcome to day "+str(GM.main.getDays())+" of your sentence.")
		
		addButton("Continue", "Time to wake up", "after_sleep")
		
	if state == "after_sleep":
		saynn("You rub your eyes and stretch your arms, as per usual. What is not usual is the fact that behind bars of your cell stands a looming figure of your Master.")
		saynn("[say=pc]Ummm, good morning?[/say]")
		saynn("[say=issix]Good morning, pet. How are you today?[/say]")
		saynn("[say=pc]I'm... Fine?[/say]")
		saynn("He smiles.")
		saynn("[say=issix]That's wonderful. I hoped to see if you are okey in the morning, I did say so, didn't I?[/say]")
		saynn("He did say something along the line of seeing you in the morning, you do recall that...")
		saynn("[say=pc]Right...[/say]")
		saynn("[say=issix]Do prepare yourself, I'll take you to my harem.[/say]")
		saynn("[say=pc]Yes, Master![/say]")
		saynn("You exclaimed in agreement, without thinking much about it. Not that you'd have a different answer for your Master. Making sure you are prepared you take most important things from your stash and join the Master.")
		addButton("Go", "Go with Master to the harem", "go_with_master_end")
		
	if state == "go_with_master_end":
		aimCamera("hall_ne_corner")
		setLocationName("Issix's harem")
		saynn("You are led to the corner of main hall's most lively square like platform, very close by to the stairs from cellblock.")
		clearCharacter()
		addCharacter("issix")
		if reason != "disobedience":
			saynn("[say=issix]Here we go, welcome back, pet.[/say]")
			saynn("You look around, a chair stands next to four blankets, while three of them are occupied by three creatures you... Feel familiarity with in some way, the last one is empty. Feline, canine and a fox look at their Master with admiration and kindness, however when their sight lands on you this expression changes drastically, to one full of distrust if not... Malice? Are they competitive or... Its something else?")
			saynn("[say=issix]Now now, we've talked about it. {pc.He} is fine now, you can drop your expressions, I'm positive that you'll get along.[/say]")
			saynn("What does he mean? Weren't you the pet for a while now? Why are you fine only now? Your memory is incredibly hazy and you feel like you'd be a bad pet if you asked now, but it really feels weird for him to say that...")
		else:
			addCharacter("azazel")
			addCharacter("hiisi")
			addCharacter("lamia")
			saynn("[say=issix]And we are back. How is everyone? Slept well?[/say]")
			saynn("He then engages in conversation with three other pets, after few exchanges he invites you to join.")
			saynn("[say=issix]{pc.Name} here promised {pc.he} will be visiting us more often now. I made sure it will be the case.[/say]")
			saynn("[say=azazel]Yay. Let's play, let's play![/say]")
			saynn("[say=issix]Azazel, please, give {pc.him} space, {pc.he} still needs some time since yesterday was tiring for him.[/say]")
			saynn("[say=azazel]Oh? What happened yesterday?[/say]")
			saynn("[say=issix]Nothing your head needs to be concerned about, alright?[/say]")
			saynn("He pets feline's head gently while smiling.")
			saynn("[say=azazel]Oh, sure Master![/say]")
			saynn("The only one who seems more intense than everyone else is Hiisi, who has been looking at you for few minutes now.")
			saynn("[say=issix]Anyways, {pc.Name}, feel free to do what you want now.[/say]")
			
		addButton("End", "", "endthescene")
		# GM.ES.triggerRun(Trigger.WakeUpInCell) #  We kind of don't want to trigger other events in case they mess with what we want to do here

func saveData():
	var data = .saveData()

	data["reason"] = reason

	return data

func loadData(data):
	.loadData(data)
	
	reason = SAVE.loadVar(data, "reason", null)

func _react(_action: String, _args):
	
	if _action == "back_cell":
		GM.pc.setLocation(GM.pc.getCellLocation())
	
	if _action == "wake_up":
		Globals.markDayAsComplete()
		setModuleFlag("IssixModule", "Noncon_Mode_Enabled", true)
		GM.main.processTimeUntil(GM.main.getTimeCap()-(5*60))
		if reason != "disobedience":
			GM.pc.getSkillsHolder().addPerk("PetName")
			GM.pc.addSkillExperience("Pet", 100)
			setModuleFlag("IssixModule", "Obtained_New_Name", true)
			GM.pc.getSkillsHolder().getPerks()["PetName"].runOnceWhenLearned()
			setModuleFlag("IssixModule", "Misc_Slavery_Info", {"day_enslaved": GM.main.getDays(), "scenes_seen": []})
			setModuleFlag("IssixModule", "Progression_Day_Next", GM.main.getDays()+2)
			setModuleFlag("IssixModule", "Issix_Mood", 20)
			setModuleFlag("IssixModule", "Todays_Bred_Slave", "hiisi")  # Just prevent it from being a player
			setModuleFlag("IssixModule", "Last_Walk", GM.main.getDays())
			setModuleFlag("IssixModule", "PC_Enslavement_Role", 1)
			var scenes = GM.main.getModuleFlag("IssixModule", "Misc_Slavery_Info", {"scenes_seen": []})
			scenes["scenes_seen"].append("IssixSlaveryIntroCont")
			GM.main.setModuleFlag("IssixModule", "Misc_Slavery_Info", scenes.duplicate(true))
		else:
			setModuleFlag("IssixModule", "Susipicious_Hiisi_Scene_Occured", false)
		match getModuleFlag("IssixModule", "Chemicals_Chosen", ""):
			"81'm'80", "H1'm'80":
				GM.pc.getSkillsHolder().addPerk("Bimbo")
			_:
				pass
			
	if _action == "sleep":
		GM.main.startNewDay()
		GM.pc.afterSleepingInBed()
		if(GM.ES.triggerReact(Trigger.SleepInCell)):
			pass
			
		processTime(6*60)
		_action = "slept"
		
	if _action == "after_sleep":
		GM.pc.updateAppearance()
		GM.main.showLog()
		GM.main.setModuleFlag("IssixModule", "PC_Should_Be_Punished", 0)
		GM.main.setModuleFlag("IssixModule", "PC_Pet_Didnt_Fullfill_Daily", false)
		GM.main.setModuleFlag("IssixModule", "Last_Day_Visited_Master", GM.main.getDays())

	if _action == "go_with_master_end":
		processTime(5*60)
		GM.pc.setLocation("hall_ne_corner")
		GM.pc.getReputation().addRep(RepStat.Alpha, -1000.0)
		
	
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)

