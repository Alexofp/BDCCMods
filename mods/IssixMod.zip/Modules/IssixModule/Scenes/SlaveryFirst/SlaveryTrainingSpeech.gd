extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "SpeechTrainingWithIssix"
	
var items_freezer = {"cookie": false, "f_vial": false, "c_vial": false, "r_vial": false}
var clock_offset = 0
var clock_alarm = 0
var pod_flashing = false
var pawns_interactions = []

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="stand"})
		addCharacter("issix")
		saynn("[say=pc]Master, is there some way I could be more like a pet for you?[/say]")
		if Globals.checkIfAchieved("Azazel_Corr_Dream_State", "Lost_Speech"):
			saynn("You recall one of your dreams you've had when hanging out with Azazel where Lamia was able to change your speech completely, so only pet-like words came out of you and you communicated like a feral.")
			saynn("[say=pc]Perhaps some way to change how I speak? Like... How animals communicate.[/say]")
			saynn("[say=issix]Hmm, would you really want that? It would impair you quite heavily. You do not need to become like literal feral pet just to please me.[/say]")
			saynn("[say=pc]Master, I'd love that![/say]")
			saynn("[say=issix]*sigh* I see. Well, I did read something in a journal about changing vocal cords of creatures to make them sound... Differently. Although this poses a problem of how others will be able to communicate with you, I wouldn't want you to lose ability to communicate with me and others on a whim of wanting to be a better pet. Ehh. Give me an hour, okey? I'll try to find something...[/say]")  # While I'd love to make the player completely feral spoken, that wouldn't make sense lore wise in any way, and I obviously wouldn't be able to rewrite every dialogue in the game to support a case where player is basically mute
		else:
			saynn("A wild thought appears in your head, perhaps he could.. Make you sounds like a feral animal? You do recall hearing about such a thing, though it was a degrading modification that rendered slaves completely incomprehensible for bemusement of their masters.")
			saynn("[say=pc]Umm, perhaps you could change how I speak?[/say]")
			saynn("[say=issix]How you speak? What do you have in mind, pet?[/say]")
			saynn("[say=pc]Like, make me sound like animals speak.[/say]")
			saynn("[say=issix]... Feral animals can't communicate complex ideas, their vocal speech is often too poor for that... However.. Hmm.. I do remember reading something about...[/say]")
			saynn("He pulls out his tablet and checks some stuff up on it.")
			saynn("[say=issix]Give me an hour or so, I want to check on something, alright?[/say]")
			saynn("[say=pc]Okey, Master![/say]")
			
		addButton("Wait", "Wait for Master to finish his research", "wait_master")
			
	if state == "wait_master":
		saynn("You nod to your Master and try to occupy your time when your Master spends some time with his noes up to a tablet running his paw fingers in all directions vigorously, you think he is browsing and reading something while also from time to time taking notes. Eventually he seems to come to some conclusion.")
		saynn("[say=issix]Okey, I think... It's actually possible. Like, actually possible. Though... I don't think anyone have done that before.[/say]")
		saynn("He looks... Excited.")
		saynn("[say=pc]Yay![/say]")
		saynn("[say=issix]In a nutshell it has everything to do with sound waves and hearing systems we possess. Because the latter is imperfect it can basically misinterpret sound waves which have traveled for a bit to mean something else. If we manipulate the source – in your case your vocal chords and mouth, we can make them produce sounds which from close proximity, like for yourself sounds like a lot of yapping, while to the receiver... Well... They will still sounds somewhat like yapping, but modulated to a degree where it's recognizable as speech, there is optimal hearing range from which they can best observe the sounds and hear words of what you are saying, so you'd have to speak from a little bit of a distance, otherwise it will sound like yips and yaps to your conversation partner.[/say]")
		saynn("You listen to Master's explanation in awe, you are sure there is a lot of science behind what he says, however he boils it down to something you can understand pretty well.")
		saynn("[say=issix]Do mind that this is... Just a theory, [b]for now[/b]. There is no paper showing this kind of operation has been attempted, I just combined multiple papers, some from science of sound and some about biological properties of organs allowing us to speak... But if we succeed... I could write a paper about it![/say]")
		saynn("His black eyes are sparking with joy, he is in his dreamy world.")
		saynn("[say=issix]*cough* That is of course, if this proves successful, which it might not. It's... A risk. And whether we take it I want to leave up to you. So, {pc.Name}, are you still interested in doing this? It would really fuck up your speech and you'd still have to relearn how to speak properly after operation, however if this is what you want, we could possibly help science too.[/say]")
		saynn("A new choice, whether you want to go with Master's devious plan or not risk it.")
		if GM.main.getTime() + 3*60*60 > GM.main.getTimeCap():
			saynn("[say=issix]That said, if we were to do that, you'd have to come here earlier in the day, it's almost sleep time here.[/say]")
			addDisabledButton("Do it", "It's too late in the day to do that")
			addButton("Later", "You'll think about it in the meantime", "dont_do_it")
		else:
			addButton("Do it", "Express interest in having the operation", "do_it")
			addButton("Nah", "Reject the prospect of undergoing such an operation (for now)", "dont_do_it")
	
	if state == "do_it":
		playAnimation(StageScene.Duo, "crawl", {npc="issix", npcAction="walk", flipNPC=true, bodyState={leashedBy="issix"}})
		aimCameraAndSetLocName("hall_mainentrance")
		saynn("[say=pc]I'd want to do it, Master.[/say]")
		saynn("[say=issix]Are you absolutely sure? I can't promise you everything will go according to plan. You might lose speech completely, and I don't mind having two mute pets, though while Lamia might not mind their impairment, you on the other paw will suffer much more because of it.[/say]")
		saynn("[say=pc]I... Trust you, Master, and I want to make myself more alike a pet.[/say]")
		saynn("[say=issix]Ahh, sometimes I feel like your goals are beyond my comprehension. But of course, I can't deny my pet its desire to become more pet like. Come with me then, actually... Let's do it properly, pet.[/say]")
		saynn("He takes out a leash from his stash of things and attaches it to your collar.")
		saynn("[say=issix]Now you look appropriately, let's go, you crawl.[/say]")
		saynn("And so, he leads you to the elevator like a proper pet.")
		addButton("Continue", "", "confessionary")
		
	if state == "confessionary":
		playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="walk", flipNPC=true, bodyState={leashedBy="issix"}})
		aimCameraAndSetLocName("medical_confessionary")
		saynn("You come to the medical wing and before you leave the elevator Master tells you")
		saynn("[say=issix]Try to not bring any attention to yourself, pet. Let's just say... Eliza shouldn't know about this, {eliza.he} has heart and a particular form of ethics that we currently don't need.[/say]")
		saynn("As you come closer, Master shoves you behind a pillar while he himself observes Eliza from a distance. After making sure {eliza.he} is occupied he swiftly rushes you through the medical lobby to the eastern corridor and confessionary.")
		saynn("[say=issix]Good, good. Now, stay here and wait for me... I'll need some some nurses to assist me if we are to do this. Thankfully this shouldn't be the difficult part, the difficult part is holing up here without Eliza or other... Less cooperative staff members noticing.[/say]")
		saynn("He unclasps your leash and leaves you in Medical Confessionary room.")
		addButton("Wait", "Wait for your Master", "wait_conf")
		
	if state == "wait_conf":
		removeCharacter("issix")
		saynn("And so you wait for your Master in confessionary room, stumbling through it and exploring its various crevices.")
		addButton("Freezer", "Open and check what is in the freezer looking device", "freezer")
		addButton("Chamber", "On left side of the room there stands a some sort of pod that could potentially hold one creature in it, there is a basic panel next to it and few buttons", "chamber")
		addButton("Alarm clock?", "A display with current time stands on one of the counters", "alarm")
		addButton("Wait", "Simply wait without touching anything", "after_wait_conf")
		
	if state == "freezer":
		saynn("You approach freezer looking device chucked in-between two silver counters. It has interactive doors that can be opened with a touch in the distinguished place. No label or text indicates what could be inside and the device itself is silent.")
		addButton("Touch opener", "Touch the distinguished place that likely opens the doors to the device", "open_freezer")
		addButton("Leave it", "Don't touch the freezer and do something else instead", "wait_conf")
		
	if state == "open_freezer":
		sayn("You touch the touch panel on the side of the doors and the freezer opens to you. After a small mist of cold air dissipates you can easily see the contents of the freezer – countless vials with labels on them, some unidentified plastic bags with frozen fluids and you can even see food items in there... Not a good place for them.")
		addButtonOfItem("C Vial", "Take the vial with big C on its label, as you read the C stands for Canidae", "c_vial")
		addButtonOfItem("F1 Vial", "Take the vial with big F1 on its label, as you read the F stands for Felidae", "f_vial")
		addButtonOfItem("Unlabeled Vial", "Take the vial without any label on it", "r_vial")
		addButtonOfItem("Cookie", "Take the frozen cookie", "cookie")
		addButton("Leave it", "Don't touch the contents of this freezer", "freezer")
		
	if state == "chamber":
		saynn("You approach a large pod, similar to cryopod in other room of medical wing, it lies dormant, empty and open. As far as you can see, its control panel that is a square touch pad on it is fairly basic.")
		addButton("Enter pod", "Enter the pod to see it from the inside", "enter_pod")
		if pod_flashing == false:
			addButton("Use buttons", "Controls of the touch screen", "use_buttons_pod")
		else:
			addDisabledButton("Use buttons", "The doors are closed and the indicator on the pod flashes red, you decide it's best to leave it alone")
		addButton("Leave it", "Don't touch the pad and do something else instead", "wait_conf")
		
	if state == "enter_pod":
		saynn("For whatever reason you decide to enter the empty pod, it's dry and producing plenty of echo, you can only imagine it would produce even more if the doors were closed. You look around, however there is nothing of interest going on there. To your disappointment it did not close by itself and turn you into one of those Dark Latex wolf creature you've seen in video games. Maybe another time...")  # OwO
		# TODO TF update stuff
		addButton("Leave it", "Leave the chamber", "chamber")
		
	if state == "use_buttons_pod":
		saynn("There can't be anything wrong with fiddling with medical equipment at random, right?")
		saynn("You use various displayed buttons with names that you can't decipher. The doors of the pod close and it makes many screeching noises that scare the heck out of you. Afterwards, an indicator on the pod flashes red constantly, you decide to leave it alone like that, hoping you didn't break it.")
		addButton("Leave it", "Leave it alone flashing like that", "chamber")
		
	if state in ["use_red_button", "use_blue_button", "use_purple_button", "alarm"]:
		saynn("You approach a thing that resembles an old-fashioned alarm clock. With aqua colored time display on the front showing "+("[b]" if state == "use_purple_button" else "")+Util.getTimeStringHHMMSS(clamp(GM.main.getTime()+clock_offset, 0, GM.main.getTimeCap()))+("[/b]" if state == "use_purple_button" else "")+" on the display. It has three colored buttons on it, likely to switch the time.")
		addButton("Red button", "Use red button", "use_red_button")
		addButton("Blue button", "Use blue button", "use_blue_button")
		addButton("Purple button", "Use purple button", "use_purple_button")
		addButton("Leave it", "Don't touch the pad and do something else instead", "wait_conf")
		
	if state == "dont_do_it":
		saynn("[say=pc]Can I... Think about it?[/say]")
		saynn("[say=issix]But of course you can dear pet, I don't want to do it without your permission, you are mu precious.[/say]")
		saynn("Issix sends you off with a smile.")
		addButton("Leave", "", "endthescene")
		
	if state == "after_wait_conf":
		addCharacter("issix")
		addCharacter(pawns_interactions[0])
		addCharacter(pawns_interactions[1])
		saynn("Doors to the room you are in open, looking at the entrance you see Issix along with two nurses.")
		saynn("[say=issix]Here is my precious patient – {pc.Name}. Hello, {pc.name}, I'm back, nurses will assist me.[/say]")
		saynn("[say=pc]Oh, okey Master.[/say]")
		saynn("Both of the nurses go to corner of the room and bring a medical bed with them. Sliding effortlessly on the floor to room's center.")
		saynn("[say=pawn1]Please hop onto it.[/say]")
		saynn("[say=pawn2]{pawn1.name} can you find [i]sodium thiopental[/i]?[/say]")
		saynn("[say=pawn1]It was the round drawer, wasn't it?[/say]")
		saynn("[say=pawn2]Yes.[/say]")
		saynn("Nurses walk around the room preparing for the operation, while your Master is both occupied by reading from his fancy tablet as well as from time to time looking at you. Meanwhile, you follow nurse's directive and sit on the bed that has been dragged and secured to the center of confessionary.")
		saynn("[say=issix]For the operation we will obviously require to give you general anaesthesia, so you'll be asleep for a while. ever had one?[/say]")
		addButton("Yes", "Yes, you've had one in the past", "yes_ana")
		addButton("No", "No, you've haven't had one in the past", "no_ana")
	
	if state in ["yes_ana", "no_ana"]:
		if state == "yes_ana":
			saynn("[say=pc]I did have one in the past, it wasn't too bad.[/say]")
			saynn("[say=issix]That's good to hear.[/say]")
		else:
			saynn("[say=pc]I didn't have any yet.[/say]")
			saynn("[say=issix]I see. You can compare it a lot to simply falling asleep. The weirdest part is after you regain consciousness, as the anaesthesia relents in stages. You'll be fairly weakened after you wake up, and won't be able to move at first. Feels odd.[/say]")
			saynn("[say=pc]Thank you Master for telling me.[/say]")
			saynn("[say=issix]But of course.[/say]")
		
		saynn("[say=issix]Everything we are doing is... On pretty short notice. But I don't want you to freak out, it will be just fine.[/say]")
		saynn("[say=pc]Have Master ever done... A medical operation before?[/say]")
		saynn("He smiles at you.")
		saynn("[say=issix]Well, I have plenty of theoretical medical knowledge, young creatures in my position studied more fields of science than are generally taught to other creatures. I can't say I have any practical experience but let's just say that it won't be needed. I assure you – you'll be just fine, okey?[/say]")
		saynn("[say=pc]I trust you, Master.[/say]")
		saynn("[say=issix]Of course you do. And now, can you please lay for me in here? We'll begin shortly.[/say]")
		saynn("And so you follow his command, spreading your entire body on this bed. Head and {pc.toes} pointing at opposite directions while you comfortably look upwards at illuminated ceiling while hearing shuffling all around you.")
		saynn("[say=pawn1]Here is the anaesthesia agent and here are the tools required for vocal cord tissue operation.[/say]")
		saynn("[say=issix]Thank you, {pawn1.Name}. One minute and we can begin.[/say]")
		saynn("For a moment a medical apron flashes in front of your up facing face.")
		saynn("[say=issix]{pc.Name}, now we can begin, have good dreams...[/say]")
		if state == "yes_ana":
			saynn("He says as a mask lowers over your face, at first very sanitary unpleasant smell hits your face, you feel relieved by the fact it's not your first time in this situation. A sweet smell fills out the mask shortly and you can immediately feel the pull of losing consciousness until... Nothingness.")
		else:
			saynn("He says as a mask lowers over your face, at first very sanitary unpleasant smell hits your face, you feel the adrenaline coursing your veins, being very unsure of doing something like this for the first time. You make fists and prepare for the worst. Soon, a sweet smell fills out the mask and immediately you feel deep pull into world of unconsciousness. You fade away...")
		addButton("...", "You are asleep", "asleep1")
		
	if state == "asleep1":
		clearCharacter()
		saynn("...")
		addButton("...", "", "asleep2")
		
	if state == "asleep2":
		saynn("...?")
		addButton("...", "", "woke_up")
		
	if state == "woke_up":  # TODO Implement changes happening as a result of player messing around
		addCharacter("issix")
		addCharacter(pawns_interactions[0])
		addCharacter(pawns_interactions[1])
		addCharacter("eliza")
		saynn("A blur of sounds assaults your ears, you open your eyes, the lit up ceiling fills your vision. You move your head to the side, blurred visions of multiple creatures appears. The rest of your body feels limp. After a minute, the sense of hearing comes back.")
		saynn("[say=issix]You are blowing it out of proportions Eliza, I didn't hur- [/say]")
		saynn("[say=eliza]Blowing it out of proportions? You've used a room belonging to medical staff to operate [b]by yourself[/b] on an inmate without any experience or permission. Am I really overreacting according to you? Do you know just how much of violation of... Everything that is?[/say]")
		saynn("[say=issix]First off, it was assisted operation by the use of remote technology, so technically it wasn't me doing the operation. And inmate is my own property-[/say]")
		saynn("[say=eliza]I don't care if a doctor from 9000 solar systems away was the one actually doing the operation, this is a technicality and none of you had authorization to do anything of this sort on BDCC. And you forget yourself, you are all the property of Alpha Corp once you became inmates, You included inmate {issix.inmateNumberFull}, out of everyone, you should know this the best.[/say]")
		saynn("Your Master makes a long sigh, clearly getting tired of arguing, he looked away from Eliza and looked at you, with your eyes open he notices you are conscious to fact of which he reacts immediately.")
		saynn("[say=issix]{pc.Name}! How are you? Actually no, don't answer, your throat still needs rest after the operation, try to relax and take it easy for now, alright?[/say]")
		saynn("You try to answer, but most you can do is a barely visible nod. Eliza looks at you briefly, her face still annoyed from the situation but somewhat relieved to see you regain consciousnesses.")
		saynn("[say=issix]We'll talk when we are back in the corner. Eliza, come with me, you can do the shouting outside.[/say]")
		saynn("They left the room. Two nurses you've seen before the operation shuffle around the room sorting various tools and putting them back in place. Soon enough they leave the room as well making you the only creature in the confessionary – still in the bed barely feeling alive with your body feeling incredibly weak.")
		addButton("Wait", "Stay where you are and wait", "stay_wait")
		
	if state == "stay_wait":
		clearCharacter()
		addCharacter("issix")
		aimCameraAndSetLocName("medical_nearconfessionary")
		saynn("Focusing on yourself and your state, you notice that both your throat as well as mouth feel... Strange. Beside odd taste in both of them, there is something unusual about them that you can't find a word to describe. In a way, they feel alien, unknown. As if someone put something inside of you that you've never had before and now its fully part of you. It's fairly obvious that it's just a matter of getting used to the new sensation.")
		saynn("Finally you can hear the doors to the room open. It's just your Master. He removes the white sheet from you and proceeds to instruct you to first sit and when you feel like it try and stand up. You follow those instructions and are standing in no time.")
		saynn("[say=issix]Great! The operation was a success. I mean, from standpoint of achieving biological structure we wanted to achieve, when it comes to testing if what we did really works I hope we can test that tomorrow. For now we need to give your vocal cords a little bit of time, so please, do not try to speak.[/say]")
		saynn("Giving you reassuring pat on your shoulders Issix takes his things, clasps a leash to your collar and begins to head out of the room with you behind.")
		saynn("[say=issix]Unfortunately during the operation Eliza showed up and we've had a long conversation, nothing you have to worry about though, my "+Globals.getPlayerPetName()+".[/say]")
		addButton("Follow", "Follow master on your way to the corner", "follow_master_to_corner")
		
	if state == "follow_master_to_corner":
		addCharacter("azazel")
		addCharacter("hiisi")
		addCharacter("lamia")
		aimCamera("hall_ne_corner")
		setLocationName("Issix's harem")
		saynn("You come back to Issix's corner – the harem. Many curious faces look towards you, even Hiisi who usually isn't one to be curious looks at you with interest. Your Master unleashes you.")
		saynn("[say=issix]Now now, as you all probably already know, {pc.Name} has decided to undergo a little operation. It wanted to be a pet to the point where it literally speaks like a feral animal one. So from today it will be communicating in noises.[/say]")
		saynn("[say=azazel]Wooow. Will {pc.he} like meow and shit?[/say]")
		if Species.Canine in GM.pc.getSpecies() and not Species.Feline in GM.pc.getSpecies():
			saynn("[say=hiisi]Az, you stupid or something? {pc.He} is clearly canine, not a feline. I'm sure he will woof. {pc.Name}, do a bark.[/say]")
		elif not Species.Feline in GM.pc.getSpecies():
			saynn("[say=hiisi]{pc.He} is not even a feline, Az. Only felines meow.[/say]")
		else:
			saynn("[say=hiisi]Maybe, though I'd prefer if {pc.he} barked.[/say]")
		
		saynn("Lamia shows signs of excitement at prospect of you not being able to talk.")
		
		saynn("[say=issix]Shh. {pc.Name} won't be speaking today, he is just shortly after operation, let its vocal cords recover, will you all? You'll all hear it tomorrow, assuming it can speak. And well, he should still be understandable to you assuming you hear it from a distance.[/say]")
		saynn("[say=azazel]Huuuuuh? What does Master mean by that?[/say]")
		saynn("[say=issix]If everything goes according to plan, whenever it speaks you'll still understand what it is saying. It will sound different, but should still be comprehensible. I won't bore you with science behind that, but theoretically it's possible, hopefully practically too, but we will see about that tomorrow.[/say]")
		saynn("The rest seem to be confused by Issix's explanation, however despite that they give it a rest, you spend a little bit more time in the harem.")
		addButton("Hang out", "Stay in the harem", "to_bed")
		
	if state == "to_bed":
		playAnimation(StageScene.Sleeping, "sleep", {bodyState={naked=true}})
		aimCameraAndSetLocName(GM.pc.getCellLocation())
		saynn("[say=issix]{pc.Name}, let me take you to your cell alright? You need rest before tomorrow. Come.[/say]")
		saynn("Once again, you follow your Master, this time to your own cell, he puts you to bed with care and leaves you there telling to go to sleep and give your body time to regenerate. You could technically try to do something, however you feel entirely drained and it's not late before you fall asleep.")
		addButton("Zzz...", "Fall asleep", "fall_asleep")
		
	if state == "fall_asleep":
		playAnimation(StageScene.Sleeping, "sleep", {bodyState={naked=true}})
		
		saynn("You slept in your cell. It's not the most pleasent experience but you managed to recover your energy.")
		
		saynn("You wake up when all the prison lights begin to turn on.")
		
		saynn("Welcome to day "+str(GM.main.getDays())+" of your sentence.")
		
		addButton("Continue", "Time to wake up", "endwake")
		
		GM.ES.triggerRun(Trigger.WakeUpInCell)

func saveData():
	var data = .saveData()

	data["items_freezer"] = items_freezer
	data["clock_offset"] = clock_offset
	data["clock_alarm"] = clock_alarm
	data["pod_flashing"] = pod_flashing
	data["pawns_interactions"] = pawns_interactions

	return data

func loadData(data):
	.loadData(data)

	items_freezer = SAVE.loadVar(data, "items_freezer", {"cookie": false, "f_vial": false, "c_vial": false, "r_vial": false})
	clock_offset = SAVE.loadVar(data, "clock_offset", 0)
	clock_alarm = SAVE.loadVar(data, "clock_alarm", 0)
	pod_flashing = SAVE.loadVar(data, "pod_flashing", false)
	pawns_interactions = SAVE.loadVar(data, "pawns_interactions", [])

func resolveCustomCharacterName(_charID):
	if _charID.begins_with("pawn"):
		return pawns_interactions[int(_charID[-1])-1]

	return null

func addButtonOfItem(name, desc, state):
	if items_freezer[state]:
		addDisabledButton(name, "You've taken this item")
	else:
		addButton(name, desc, state)

func _react(_action: String, _args):
	processTime(2*60)
	if _action in ["use_red_button", "use_blue_button", "use_purple_button"]:
		processTime(1)
		var color = _action.get_slice("_", 1)
		if color == "red" and 0 > clock_offset-5*60:
			clock_offset -= 5*60
		elif color == "blue" and GM.main.getTimeCap() > clock_offset + 5*60:
			clock_offset += 5*60
		elif color == "purple":
			clock_alarm = GM.main.getTime()+clock_offset
	
	if _action == "use_buttons_pod":
		pod_flashing = true
		
	if _action == "after_wait_conf":
		processTime(15*60)
		pawns_interactions = Globals.pick_unique_one(Globals.findPawns([[["isNurse"], []], [["isNurse"], []]]))
		# if null == pawns_interactions[0]:  # Won't work, pawns require baseCharacters in the game and I can't be bothered
		# 	pawns_interactions[0] = GM.main.IS.spawnPawn("tempIssixNurse", CharacterType.Nurse).charID
		# if null == pawns_interactions[1]:
		# 	pawns_interactions[1] = GM.main.IS.spawnPawn("tempIssixNurse2", CharacterType.Nurse).charID
		if pawns_interactions.count(null) > 0:
			pass # aaaaaaaaaaaaaaa
			
		# deletePawn
		
	if _action == "asleep1":
		processTime(46*60)
		
	if _action == "asleep2":
		processTime(37*60)
		
	if _action == "woke_up":
		processTime(24*60)
		GM.pc.getSkillsHolder().addPerk("PetSpeech")
		setModuleFlag("IssixModule", "Got_Speech_Scene", false)
		setModuleFlag("IssixModule", "Learned_Speech", true)
		GM.pc.addStamina(-GM.pc.getStamina())
	
	if _action == "stay_wait":
		processTime(15*60)
		
	if _action == "fall_asleep":
		GM.main.startNewDay()
		GM.pc.afterSleepingInBed()
		if(GM.ES.triggerReact(Trigger.SleepInCell)):
			pass

	if _action in ["c_vial", "f_vial", "r_vial", "cookie"]:
		items_freezer[_action] = true
		_action = "open_freezer"
		if _action == "cookie":
			GM.pc.getInventory().addItemID("Cookie")

	if _action == "wait_master":
		processTime(69*60)
		setModuleFlag("IssixModule", "Talked_About_Speech", true)

	if(_action == "endthescene"):
		endScene([false])
		return
		
	if _action == "to_bed":
		GM.pc.setLocation(GM.pc.getCellLocation())
		
	if _action == "endwake":
		GM.pc.updateAppearance()
		
		if(GM.ES.triggerReact(Trigger.WakeUpInCell)):
			GM.main.showLog()
			endScene([true])
			return
		GM.main.showLog()
		
		endScene([true])
		return

	setState(_action)
