extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "AfterSpeechOperationScene"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="sit"})
		addCharacter("issix")
		addCharacter("azazel")
		addCharacter("hiisi")
		addCharacter("lamia")
		saynn("Approaching Issix's harem your Master stands to greet you.")
		saynn("[say=issix]Welcome! How do you feel, pet? Can you speak now? Do you need some water maybe?[/say]")
		saynn("Without waiting for your answer he passes a water bottle to you, you use this opportunity to quench your thirst and make your throat a bit less dry.")
		saynn("[say=pc]T-thank y-[/say]")
		
		saynn("You attempt to speak the words as you'd normally do, however the sounds that escape you are not the ones you got used to. Even after entire operation and the night, nothing prepared you for a feeling so alien of heading something different from yourself than what you thought you said. Hearing that, you completely lose concentration on verbal communication, making you try again.")
		saynn("[say=pc]Twan- Twenk- Master?[/say]")
		saynn("Everyone else seems rather amused, pets chuckle to themselves at you stumbling the words.")
		saynn("[say=issix]Take it easy, "+Globals.getPlayerPetName()+". Don't expect to be able to speak well for the near future. You'll have to re-learn speaking properly again, it will take time and will be difficult. I'll try to help you along the way okey?... Okey. Now, can you try to say „Thank you”? Just try a few times, we'll see how it goes.[/say]")
		addButton("Thank you", "Do what is asked of you", "thankyou")
		
	if state == "thankyou":
		saynn("[say=pc]Thank you.[/say]")
		saynn("[say=pc]Thank you?[/say]")
		saynn("[say=pc]Thank you.[/say]")
		
		saynn("[say=hiisi]I mean, I think I can hear it, though it really does sound like bunch of yips and yaps.[/say]")
		saynn("[say=azazel]It's truthfully bizarre. It's like I can hear {pc.him} making animal noises and yet I understand what he is saying, I've never seen anything like this.[/say]")
		saynn("[say=issix]That's true, even I'm surprised by the effect. What we hear feels animal like and yet familiar. I expected it to sound different, I expected {pc.Name} to sound more regularly to us, but this... This is truthfully something else. I've recorded the samples now, I'll try to analyze them and see what's really going on.[/say]")
		saynn("[say=azazel]Woah, it even made Master surprised. Wasn't Master the one doing the operation?[/say]")
		saynn("[say=issix]I were... But this was not the plan. I still welcome it as a success, when {pc.Name} masters it, it will be able to speak without issues and everyone will hear them just as it intended.[/say]")
		saynn("[say=azazel]That's so cool. Can I get that operation next?[/say]")
		saynn("[say=hiisi]I swear if I hear you meowing for entire day, I don't think I could ever handle that.[/say]")
		saynn("Lamia burst out in laughter hearing Hiisi.")
		saynn("[say=azazel]Not surprising coming from Mr. I Have A Sadness Condition And Its Terminal.[/say]")
		saynn("Hiisi growls back at Azazel after that comment.")
		saynn("[say=issix]Quiet, pets. It will take a while before I can make another operation, so no, Az, you can't have it yet.[/say]")
		saynn("[say=azazel]Aw.[/say]")
		saynn("[say=issix]Anyways, I need to start working on writing it all up for later publishing. Thank you {pc.Name}, if you need help with training I'll be available.[/say]")
		addButton("Leave", "", "endthescene")
		

func _react(_action: String, _args):
	processTime(2*60)
	
	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Got_Speech_Scene", true)
		endScene()
		return
		
		
	setState(_action)

