extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "IssixAfterLost"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "sit", {npc="issix", npcAction="sit"})
		saynn("As you come near the corner, you see your blanket is still in its place. Issix raises from his chair, you also gain three other pairs of eyeballs staring through your skull from around him.")
		saynn("[say=issix]Welcome back, {pc.name}.[/say]")
		saynn("His tone very matter-of-fact, dry. There is no usual playfulness, superiority. The voice isn't as kind as usual.")
		saynn("[say=issix]Sit with me.[/say]")
		saynn("Issix produces a chair, inviting you to sit on it. It's an extra chair, it is facing his own chair. You sit on it, it's... Not very comfortable, but should be fine if you are not to sit on it for too long. Issix follows and sits on his own chair.")
		saynn("[say=issix]It would be unwise for me not to acknowledge my loss the other day. You've defeated me fair and square. Doing so in this place, in a prison has its consequences, for myself. Dozens of other inmates and guards saw our fight... And the winner.[/say]")
		saynn("[say=issix]And so, we have to find a way forward. From the way I see it, there are two options I can offer you.[/say]")
		saynn("[say=issix]Option A: You can continue to be my pet. Even though this fight brought certain... Trouble, I still have some patience left. It's not much, but if you really mean what you meant when you came into my possession – that you want to be my pet, then I can give you one last chance to do things right. If you will be a good "+Globals.getPlayerPetName()+" from now on then with time we can overlook what happened. But if not, there is also a second option.[/say]")
		saynn("[say=issix]Option B: You leave the harem. With heavy heart I can let you go. If that was the desire in your mind when you fought me, for which you've defeated me – then I can grant you this without any consequences. If you choose to go this way we will go our separate ways, you leave my pets alone, and I fuck right off.[/say]")
		if GM.pc.hasPerk("PetBrand"):
			saynn("He sighs.")
			saynn("[say=issix]Granted, it will not erase my permanent marker on your body, but you'll be free of me at the very least.[/say]")
		
		saynn("[say=issix]In normal circumstances you wouldn't have a choice, however it's clear that you have became a really powerful individual, and either you are too rebellious to be a pet, or you just really hate my guts, I don't care which it is. But I need your decision.[/say]")
		addMessage("( Continuing to misbehave might lead to non-con route. If you want to avoid this either stay good or leave the harem when you can )")
		addButton("Option A", "Living as Issix's pet is not so bad, say you choose option A", "option_a")
		addButton("Option B", "You want out", "option_b")

	if state == "option_a":
		saynn("[say=pc]I would still want to be part of the harem, Master.[/say]")
		saynn("[say=issix]Do you really? Then what is it about? Why do you continue to disappoint me? Why do you decide to fight against me?[/say]")
		saynn("[say=pc]It wasn't me starting it![/say]")
		saynn("[say=issix]This is exactly the problem, you don't understand your place. Your place is below me, you were reduced to something lesser than an inmate – you are a pet. The longer you live with this misguided idea that you are someone more the worse it is for you. You've given up on your life as it was and presented yourself to me. So when I want to teach you a lesson with force, you are supposed to submit, understood?[/say]")
		saynn("[say=pc]... Yes, Master.[/say]")
		saynn("[say=issix]I'm still pissed off, and you have A LOT to prove to me, pet. Do. Not. Do. This. Again.[/say]")
		saynn("A chill runs down your spine. You have a feeling that if your behavior repeats again it will really be bad. You nod in response.")
		
		saynn("[say=issix]That's it for now then, I'm done here.[/say]")
		addButton("End", "End of this conversation", "endthescene")
		
	if state == "option_b":
		saynn("[say=pc]I don't want to be part of this sick harem anymore![/say]")
		saynn("Your anger expressed this way took Issix by surprise, he didn't expect outburst of this scale.")
		saynn("[say=issix]Really?...[/say]")
		saynn("He thinks for a bit.")
		saynn("[say=issix]I'll be quite frank, I don't know what made you so bitter. When you joined as my pet you seemed enthusiastic, happy to be here, now? Couldn't be further from the truth. Perhaps I'm just not the Master you expected, because I don't make judgments this great – for you to end up in my care you have to be a very specific individual with the desire to serve.[/say]")
		saynn("[say=issix]But maybe you just aren't meant to serve under me, it's hurtful, but if that's your wish, so be it, you fought for it valiantly.[/say]")
		saynn("THe air is filled with tension. You look at other pets, Azazel's mouth is opened agape, Lamia and Hiisi are sad, or at least you think so, as their faces are turned away from you.")
		saynn("[say=issix]I'll make the necessary arrangement, but if it is freedom from myself you wish for, then consider it done. You do not have to come back here. Leave my pets alone. We are done. I'm no longer your Master, take your things and leave.[/say]")
		saynn("He points at your blanket, there isn't much there, but you pick up your own things and for the final time do as you are told by Issix.")
		addButton("Fuck you", "Say your final line", "option_b_fuck_you")
		addButton("Leave", "Simply leave in silence", "endthescene")
		
	if state == "option_b_fuck_you":
		saynn("[say=pc]Fuck you, Issix. Hope we never meet again.[/say]")
		saynn("He listens saddened, but doesn't respond. You leave.")
		addButton("Leave", "Simply leave in silence", "endthescene")

func _react(_action: String, _args):
	processTime(2*60)
	
	if(_action == "endthescene"):
		GM.main.setModuleFlag("IssixModule", "Last_Day_Visited_Master", GM.main.getDays())
		setModuleFlag("IssixModule", "Issix_Got_Rekt", false)
		endScene()
		return
		
	if _action == "option_b":
		setModuleFlag("IssixModule", "Quest_Rejected_By_Issix", 100)
		setModuleFlag("IssixModule", "PC_Enslavement_Role", 0)
		
	setState(_action)

