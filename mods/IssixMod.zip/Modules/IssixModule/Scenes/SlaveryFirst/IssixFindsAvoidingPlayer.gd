extends SceneBase

var reaction = false
const Globals = preload("res://Modules/IssixModule/Globals.gd")

var response = null
var used_item = null

func _init():
	sceneID = "IssixFoundPlayer"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="stand"})

		saynn("[say=issix]Hey there pet! Now, care to explain why haven't you visited for past "+str(GM.main.getDays()-getModuleFlag("IssixModule", "Last_Day_Visited_Master", GM.main.getDays()))+" days?[/say]")
		saynn("Issix almost running stops you with haste before the guard checkpoint. His face is a mix of concern and anger.")
		addButton("Excuse", "Think of an excuse to escape this awkward situation", "excuse")
		addButton("Honest", "Tell your Master that you just haven't had the time", "honest")
		if (GM.pc.getPersonality().getStat(PersonalityStat.Coward) < -0.5):
			addButton("Not a pet", "Tell your Master that you no longer wish to be his pet", "rejection")
		else:
			addDisabledButton("Not a pet", "You are too much of a coward to tell your Master this")
		if (GM.pc.getPersonality().getStat(PersonalityStat.Coward) < -0.8):
			addButton("Walk away", "Just keep walking", "leave")
		else:
			addDisabledButton("Walk away", "Let's be honest, you don't have balls to do this")

	if state == "excuse":
		saynn("[say=pc]I'm sorry, I were working on something really hard lately and...[/say]")
		saynn("[say=issix]Enough. I'm not interested in hearing any of this.[/say]")
		saynn("He comes to you and attaches the leash to your collar.")
		saynn("[say=issix]Disappearing like that and giving me such a bad excuse? That's disappointing, extremely disappointing. You are coming with me.[/say]")
		addButton("Continue", "Follow Issix to the corner", "walkcorner")

	if state == "honest":
		saynn("[say=pc]I'm very sorry Master. I didn't feel like coming lately. I've been taking time to do some-[/say]")
		saynn("[say=issix]Enough.[/say]")
		saynn("He comes to you and attaches the leash to your collar.")
		saynn("[say=issix]This is not what I expect of my pets, I were worried about you, you know? You know exactly what are my expectations towards you - you come to the corner, day after day, you spend some time with us and then you have the rest of entire day to spare. This isn't a lot to ask. Really.[/say]")
		saynn("His look of disappointment is pretty hard to bear on you. He leads you towards the corner.")
		addButton("Continue", "Follow Issix to the corner", "walkcorner")

	if state == "rejection":
		saynn("[say=pc]I don't want to be your pet anymore.[/say]")
		saynn("Your Master stands stunned by your proclamation.")
		saynn("[say=issix]What did you just say?[/say]")
		saynn("[say=pc]I no longer want to be your pet.[/say]")
		saynn("[say=issix]I don't think you understand your position, pet. You are not in a position to decide on that anymore, you've made your decision a while ago, you don't just get to change it because your feel like it, such decision belongs to your Master. Now, be a good "+Globals.getPlayerPetName()+" and come with me.[/say]")
		addButton("Continue", "Follow Issix to the corner", "walkcorner")

	if state == "leave":
		saynn("You decide to ignore the dragon-demon completely and continue walking, only to be stopped not even a step later by Your Master's hand grabbing you by the collar.")
		saynn("[say=issix]What the fuck do you think you are doing? I asked you a question.[/say]")
		saynn("[say=pc]I'm walking.[/say]")
		saynn("[say=issix]On twos, that's your first mistake, second is the direction you are going at.[/say]")
		saynn("As he says that he clasps a leash onto your collar and pulls you towards his corner in the main hall.")
		saynn("[say=issix]I'm not going to ask you. You are going with me.[/say]")
		addButton("Continue", "Unable to oppose such a strength, you follow Issix to the corner", "walkcorner")

	if state == "walkcorner":
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="stand", bodyState={leashedBy="issix"}})
		saynn("As you approach the corner, you feel three pets of Issix clearly thrown off by the situation. They avoid looking at you, intensifying the feeling of disgrace that was put on you. Your Master reaches his chair and forcefully pulls the leash down to make you sit on your blanket.")
		saynn("[say=issix]SIT[/say]")
		saynn("Seeing no other option, you sit, looking down.")
		match getModuleFlag("IssixModule", "Strikes_For_Disobedience", 0):
			0, 0.0:
				if reaction:
					saynn("[say=issix]Listen, pet. Perhaps I weren't clear enough. I expect to see you every day in here. I don't want to hear excuses, unless you are physically unable to appear in here, due to some fucked circumstances - you come here every day without fault.[/say]")
				else:
					saynn("[say=issix]Here is the deal, pet - I don't take no for an answer, and I don't buy bullshit. I'm very sure I made myself clear that I expect my property to come to my corner once a day, anything short of that is unacceptable. Unless you are abducted by aliens or nurses, you better come here every single day, fucking hell.[/say]")
				addButton("Understood", "Acknowledge your Master's commands", "understand")
			1, 1.0:
				saynn("[say=issix]So you did it again? You ignored my warning and stopped coming on your own? What the fuck are you thinking, pet? Do you think this is a joke? That I'm endlessly good and all? Perhaps it's the time I started to put some discipline in you huh? Yeah, I think you do need some discipline.[/say]")
				saynn("He strips down his clothes and puts on the boxers.")
				saynn("[say=issix]I tried to reason, but apparently my pet does not understand reason. When reason doesn't work, a more persuasive approach can help.[/say]")
				addButton("Fight", "Issix is ready to fight you", "startfight")
				addButton("Surrender", "Don't even attempt to fight", "surrenderfight")
			2, 2.0, _:
				saynn("[say=issix]I came to the conclusion I let you run on too loose of a leash. You disobeyed me multiple times now, I do not have any need for disobedient pet. Perhaps it's a failure of my own, perhaps you are just useless even as someone's pet. This ends today.[/say]")
				
				saynn("[say=issix]I'm done with giving you options, you come with me, hear that?[/say]")
				saynn("You've never seen your Master so angry. He is quite literally fuming, it doesn't seem like you have any more chances here, you feel like it's best to wait and see what happens.")
				# saynn("[say=issix]I'll give you two options, last fucking options.[/say]")
				# saynn("He breathes in the air and looks at you with intensity.")
				# saynn("[say=issix]I can release you - you could stop being my pet - if that's what you fucking want. Or you can submit to me in full - I can strip you of the very ability to disobey me. You'll be my walking puppet on the strings, something even lesser than a pet if you ask me, but we'll pretend like you are one.[/say]")
				# saynn("[say=issix]So what is it? Which option do you choose?[/say]")

				# addButton("Leave harem", "Stop being Issix's pet", "leaveharem")
				# Plan is player comes with Issix to the confessionary, they can fight for last time (player refuses to get non-cond)
				# During fight, Issix grabs player's bag? pockets? magic fucking inventory, they can use common healing items from it, player is unable to use it when this happens
				# If player wins anyways - they get kicked out of harem somehow, if they lose it activates non-con
				addButton("Submit", "Submit to Issix in full", "submitinfull")

	if state == "understand":
		saynn("[say=pc]I understand, Master.[/say]")
		saynn("[say=issix]You are still on the timeout, I expect you to stay in here for an hour longer today. This is the last time it happens.[/say]")
		addButton("Continue", "Continue", "backtothething")

	if state == "surrenderfight":
		# playAnimation(StageScene.PuppyPinned, "pinned", {pc="pc", npc="issix", bodyState={leashedBy="issix"}, npcBodyState={naked=false, hard=false}})
		playAnimation(StageScene.PuppyDuo, "kneel", {pc="issix", npc="pc", bodyState={naked=false, hard=false}, npcBodyState={naked=false, hard=false, leashedBy="issix"}})
		saynn("[say=issix]All that bravery leaving you the moment I lose my shirt? Or have you came to your senses? Can't complain, I do not like roughing up my pets like this. But since you are so nice on your knees already why not make use of it?[/say]")
		saynn("He pulls out bunch of black gear, takes your arms and instructs you to bend your arms which he secures in first part from the gear he pulled out. You quickly recognize the gear is a bitchsuit made to restrict your ability to move.")
		saynn("[say=issix]Arms are done, legs, will you?[/say]")

		saynn("You can feel your arms being severely restricted, the idea of straightening them is out of question, without external help you would be unable to do anything about your current state of body you are in. As you test your arms, the same thing happens to your legs, as your Master Issix secures them in very similar device.")
		saynn("[say=issix]Here we go. Just a few more things and we'll be golden.[/say]")
		addButton("Continue", "Oh shit, what now", "contsurrender")

	if state == "contsurrender":
		playAnimation(StageScene.PuppyPinned, "pinned", {pc="issix", npc="pc", bodyState={leashedBy="issix"}, npcBodyState={naked=false, hard=false}})
		saynn("With your lack of mobility and you can't do much at this point, other than accept everything that is happening to you. And so you do, trying to stand on your fours, struggling. Having to adapt to completely new balance and way of „standing”. Your Master continues to add further bondage gear onto you. A ball gag is first pushed into your mouth, then bondage mittens finishing your helpless look.")
		saynn("[say=issix]Think that's it, I think you look great now. In AlphaCorp that's how the leg footrest looks like in high-level corporate offices. Not a fan of footrest though, I prefer my feet on the ground, that said, the circumstances are pretty extraordinary here.[/say]")
		saynn("He puts his foot on your head and applies force making you collapse your front „legs” with your muzzle touching the ground.")
		saynn("[say=issix]This is a place for disobedient pets. Smelling the ground, under my foot. I want you to remember this feeling, to remember the helplessness you feel right now. My pets obey me, when I tell them to come here every day they do that. Do you understand now?[/say]")
		saynn("[say=pc]Yes, please, I understand.[/say]")
		saynn("[say=issix]Can barely hear your scowling. Good.[/say]")
		saynn("He lets go of his foot, kneels and unstraps your legs and arms.")
		saynn("[say=issix]Don't want to see you here today, I'm not unlocking the rest - this is your punishment, get the fuck away.[/say]")
		addButton("Leave", "Leave the place", "endthescene")


	if state == "if_won_issix_lust":
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="kneel"})
		saynn("[say=issix]Huff. Enough. I yield, fucking hell. Huff.[/say]")
		saynn("Clearly bothered by his inability to stay unaffected by your lusty advances Issix is on his knees in defeat, with a hardon in his paw.")
		saynn("[say=issix]I don't understand how you - a fucking slut could bring me to this state, but the fact is undeniable. To say I've been humiliated is an understatement. I can no longer call you my pet. You are a monster, a sex machine, huff..[/say]")
		saynn("His need evident, pent up sexual energy overwhelming the dragon")
		addButton("Finish him", "Give the dragon the relief he needs", "finishissix")
		addButton("Leave", "Let the dragon take care of his little problem by himself", "leaveissix")
		
	if state == "leaveissix":
		saynn("You decide to let go of the dragon. After your lustful victory he doesn't deserve any more humiliation. Questions mount in your head however, what now? You've defeated your Master, what they will think of you now? Are you still his pet?")
		saynn("You decide its best to let everyone breathe and skip Issix's corner today. After you walk off Azazel, Hiisi and Lamia drag their Master to the corner, they don't look at you. That's... Awkward.")
		addButton("End", "That's it for today", "endthescene")
		
	if state == "finishissix":
		saynn("You decide to exploit this situation, after bringing him to his knees, making him huff deeply thanks to your own sexual appeal you come closer, knowing he can't retaliate. You come closer to him, before you are interrupted...")
		saynn("[say=hiisi]I think that's enough, {pc.name}. It was a nice fight which you've won, but that's quite enough.[/say]")
		saynn("[say=azazel]Yes, please go now. Leave our Master.[/say]")
		saynn("All three of them take Issix from his knees and drag him off to the corner. You don't suppose you'd be welcomed there back, perhaps it's good to let the tensions out and visit some other time, after all, you don't know what to do now after all of this happened, are you still his pet? What do they think of you now?")
		addButton("End", "That's it for today", "endthescene")
	
	if state == "submitinfull":
		aimCameraAndSetLocName("hall_elevator")
		saynn("He takes metal cuffs from nearby and puts them on you. Deciding fighting right now would be disadvantageous, with Hiisi nearby and other inmates around this could get nasty really quickly.")
		saynn("[say=issix]Let's go.[/say]")
		saynn("You are led through the checkpoint, the guard there shivers and makes the way for Issix dragging you by the chain attached to your metal cuffs based on Issix's face expression alone. To call his mood as bad would be to make the understatement of the century. His face is angry. Really, really angry, and he drags you with no regard for you. Dragged to the elevator you leave on medical floor.")
		addButton("Medical", "Leave the elevator in medical", "medical_floor")
		
	if state == "medical_floor":
		aimCameraAndSetLocName("medical_confessionary")
		saynn("Only as the doors of elevator open he rushes you off it, dragged through the lobby to the off-limits zone. Eliza even if she wanted wouldn't be able to stop the raging demon of a bulldozer. You finally end up in a room you remember as „the confessionary”, the doors are locked behind you and Issix hides the key in his pocket. It's a bit difficult to see anything in here. The room is pretty dark, and little illumination there is comes from some kind of medical devices around. ")
		if "feline" in GM.pc.getSpecies():
			saynn("Your feline eyes do help a little, though not this much. You can still see everything if you concentrate a bit.")
			
		saynn("[say=issix]Stand here, no moves. If you move I'll make sure it is 10 times more painful.[/say]")
		saynn("It's scary, what does he mean? What will be painful? The room you are in only adds to the fear. There are countless of scary looking medical devices around you, from spiky needles, colorful fluids to devices which under right impression look more like torture devices rather than something that would help anyone. Issix is currently busy with some tools that you cannot see. You could potentially use this opportunity to get back at him, maybe it's worth to try to sneak on him? The metal cuffs might be a bit noisy though, however if not right now, you don't think there is going to be another such opportunity.")
		addButton("Sneak on", "Make last effort to secure your freedom", "sneak_issix")
		addButton("Wait", "Obey your Master, stand in place and don't move", "wait_issix")
		if GM.pc.getInventory().hasRemovableRestraints():
			addButton("Struggle", "Struggle of your restraints", "struggle")
		
	if state == "sneak_issix":
		saynn("While you don't know what Issix has in mind, one thing is for sure, it spells trouble for you. Feeling like if you don't take advantage of the situation now you'll never have another opportunity you decide to turn the fact Issix is occupied to your advantage and you slowly sneak towards him making no sound.")
		saynn("After you travel through half of the distance the success is slowly getting to you head, you can now hear Issix's mumbling.")
		saynn("[say=issix]Fuckin'...[/say]")
		saynn("[say=issix]This needs to go there...[/say]")
		saynn("[say=issix]Now where was this shit...[/say]")
		saynn("Eventually you are so close that you could try to take him down, or at least make a first move.")
		addButtonWithChecks("Horse dildo", "I mean... If there is nothing else? It is big.", "use_item", ["HorsecockDildo", false], [[ButtonChecks.HasItemID, "HorsecockDildo"]])
		addButtonWithChecks("Shiv", "Should be most effective to deal damage, right?", "use_item", ["Shiv", false], [[ButtonChecks.HasItemID, "Shiv"]])
		addButtonWithChecks("Fists", "A true classic", "use_fists", [], [[ButtonChecks.NotArmsRestrained], [ButtonChecks.NotHandsBlocked]])
		addButtonWithChecks("Pink vial", "Throw it, make love, not war!", "use_item", ["VialOfLiquidLust", true], [[ButtonChecks.HasItemID, "VialOfLiquidLust"], [ButtonChecks.NotArmsRestrained]])
		addButton("Abort", "Do not make the first move and come back", "medical_floor")
		
	if state == "use_item":
		if used_item == "HorsecockDildo":
			# Starts with 20 Pain
			saynn("Having nothing better to use you swing your horsecock dildo at Issix's right side of his head. To your utter amazement it makes contact and send him on the floor, briefly at least.")
			saynn("[say=issix]What the f- You attacked me? With...[/say]")
			saynn("He looks at your weapon of choice with disbelief.")
			saynn("[say=issix]A FUCKING DILDO?![/say]")
			saynn("What appears before you is the most confusing mix of emotions on Issix's face, at first he laughs, however it quickly gives in to face full of anger and confidence, he stands with no issue and readies himself up for a fight.")
			saynn("[say=issix]Might have gotten the first hit, I'll give you that, though I can't tell if you were serious or not. But if it's a fight you are looking for, you've just found it.[/say]")
			saynn("Stashing the dildo you ready yourself up as well.")
		elif used_item == "Shiv":
			# Starts with bleeding and 50 Pain
			saynn("Deciding to use something with an edge you figure using a Shiv will be the most effective. Considering the situation you are in, going for the kill might not be the stupidest idea, which is why you direct your swing at his neck. It does appear however that Issix catches on, and while you were able to sink it pretty deep, it was in his shoulder, not on his neck, as he turned around just in time.")
			saynn("[say=issix]Ou- FUUUCK. You little fucking cunt! You... You wanted to fucking kill me? What the fuck![/say]")
			saynn("After inspecting the wound he immediately begins to take a stance.")
			saynn("[say=issix]I'm going to make you regret this, and when I'm done you'll be licking my {issix.feet} in no time.[/say]")
			saynn("You prepare yourself for a fight.")
		elif used_item == "VialOfLiquidLust":
			# Starts naked with 50 lust
			saynn("Finding that you still have some vials of „Succubi perfume” you figure they could be useful in here, you take it in your paw, make a careful determination of how to throw it so you are not affected and... You apply force to break it just below his legs!")
			saynn("[say=issix]What the fu- Ohhhh. Ughhhh. You sneaky. *cough*[/say]")
			saynn("The effects are clear as a day, he got hard almost instantly, as well as he took off his uniform.")
			saynn("[say=issix]If you wanted a fuck you could have just asked, you know? No matter, I'm gonna get you on this table, the less wriggly you are the easier it will be.[/say]")
			saynn("You prepare yourself for a fight.")
		addButton("Fight", "Fight", "start_final_fight")
			
	if state == "use_fists":
		saynn("Deciding to go for a classic you prepare your fists to strike Issix. Coming as close as it is needed to strike him good you ready your arm and swing it in full force at his head.")
		if GM.pc.getStat(Stat.Strength) > 20:
			saynn("You manage to land a nice surprise hit on his head flying him to the ground.")
			saynn("[say=issix]Fuuuck. I have to admit, you pack a punch.[/say]")
			saynn("He recovers and stretches his arms for incoming battle.")
			saynn("[say=issix]But that won't be enough.[/say]")
		else:
			saynn("For a moment you think your hit landed pretty well, only to be quickly reminded of your inadequate power feeling a fist on your own face.")
			saynn("[say=issix]You hit like shit. Your place is as a pet, you are to be a toy of someone stronger than yourself. Don't even try to be a strong man. But since you asked, sure, we can dance. The less wriggly you are in the next stage the easier it will be for me.[/say]")
			saynn("He stands up and prepares for the battle.")
		
		addButton("Fight", "Fight", "start_final_fight")
	
	if state == "wait_issix":
		saynn("Fighting Issix is pointless. You've seen his strength and what he can do, everyone in the prison stays away from him. He is a real powerhouse you are not meant to compete. And something deep inside tells you about your place, to not raise your paw against your Master. To do as you are told. And while those feelings weren't the ones that led you to this place, for some reason they overwhelm your mind.")
		saynn("And so you wait, standing, for Issix to be done with whatever he is doing there, locked in a room.")
		addButton("Wait", "Wait some more", "wait2_issix")
		
	if state == "wait2_issix":
		saynn("You wander with your eyes, looking at everything in the room, Issix continues to work on something, what is it you can't tell as his back covers what he tinkers around. Then, he turns to frantically searching for something in countless drawers full of various medical tools clinking together as they slide from force of drawers getting opened and closed.")
		saynn("[say=issix]Got it.[/say]")
		saynn("Finally, he turns to you, coming closer, wrapping his paw around the chain linking two of your wrists together and leading you to the metallic bed at the center of the room. It's a single large bed, noteworthy are countless shackles wielded to it, for legs, arms, torso, neck, feet, wrists... The entire bed is affixed to the hooks coming out of the ground making it pretty resistant to any possible shaking coming from the patient.")
		saynn("[say=issix]Get yourself comfortable.[/say]")
		saynn("You doubt this will be the case. Fear coursing through you you nonetheless obediently jump on the bed and put your limbs and body in appropriate slots, them getting closed one by one by Issix making you ultimately helplessly bound in place at mercy of whoever is not.")
		saynn("[say=issix]Good "+Globals.getPlayerPetName()+". There is still hope for you. After all, if Hiisi is a loyal pet to this day, you can be too.[/say]")
		saynn("What was that about Hiisi? Before you are even able to vocalize your confusion a gag gets placed in your mouth by a pair of arms in surgical gloves which Issix has enrobed himself with.")
		saynn("[say=issix]Let's begin then.[/say]")
		addButton("Continue", "", "noncon_noncon_start")
		
	if state in ["if_final_won_issix_lust", "if_final_won_issix_pain"]:
		if state == "if_final_won_issix_pain":
			saynn("Finally, you were able to make Issix yields due to assault of your attacks.")
		else:
			saynn("Finally, you were able to make Issix yield in style, making him completely spent due to your constant sexual assaults.")
		saynn("[say=issix]Fine, runt. You've shown you want the freedom so much, I don't care anymore. Take it and fuck off from me and my pets.[/say]")
		addButton("Really?", "Stare at him in disbelief, is he really letting you go? No tricks?", "after_win_ex")
		addButton("Cocky", "You want more. You've defeated him, you should rightfully own his ass", "after_win_cocky")
		
	if state == "after_win_ex":
		saynn("[say=pc]And you mean it? I'm no longer your pet, you'll leave me alone if I leave you alone?[/say]")
		saynn("[say=issix]Do you want a blood contract or something? Of course I fucking mean it. What's the point of having a pet that not only is stronger than yourself but also rebellious like that? I don't need this shit in my prison. If you want to lash out go take down some other inmates, or guards if you dare. We are done.[/say]")
		saynn("[say=pc]I'm glad to hear, and I hope you'll honor the deal.[/say]")
		saynn("[say=issix]Sure, just leave me the fuck alone. Take it and go.[/say]")
		saynn("He passes you the key by throwing you at you with little struggle, he is not in shape.")
		saynn("[say=issix]But.. But If you ever mess with my pets, know this runt, this fight? It was nothing compared with what I'd inflict upon you. You may have beaten me here, sure. That's quite a fit. But you are alone, in a desolate, secret place in the space, and I'll use any power I have to crush you.[/say]")
		addButton("Whatever", "Say that you got what you wanted, hurting Azazel, Lamia or Hiisi is not in your plans", "after_win_pacifist")
		addButton("Threaten", "Say that he's weak, if you want you'll take him and his entire harem", "after_win_figher")
		
	if state == "after_win_cocky":
		saynn("[say=pc]You think we are done in here? Tough luck princess, I'm pretty sure I own your ass now.[/say]")
		saynn("[say=issix]No you do not, you may have beaten me here, but you own fuck nothing.[/say]")
		saynn("[say=pc]Oh yeah? How about this?[/say]")
		saynn("You come closer to his body laying on the floor, defeated. In last bid for strength he grabs your arm with a strong grip as you lowered your body to manhandle it.")
		saynn("[say=issix]If you hurt my pets, I'll not stop at anything, I'll collapse entire facility onto you. We. Are. Done.[/say]")
		saynn("As you are about to free yourself from the grip a wave of nausea hits you, your vision blurs and blackens for a few moments, the only thing you hear is some kind of chanting from where Issix's head was just a moment ago. You fall backwards from the commotion.")
		if ResourceLoader.exists("res://Modules/FoxLib/Resources/NotoSansRunic-Regular.ttf"):
			saynn("[say=issix][color=#ff2b00][matrix][runic]ᛟ ᛋᛈᛁᚱᛁᛏᛋ ᛟᚠ ᚺᛖᛚᛚ ᛁ ᛋᚢᛗᛗᛟᚾ ᛏᚺᛖᛖ.[/runic][/matrix][/color][/say]")
			saynn("[say=issix][color=#ff2b00][matrix][runic]ᛁᚾ ᛏᛁᛗᛖᛋ ᛟᚠ ᚾᛖᛖᛞ, ᛁ ᛋᚺᚨᛚᛚ ᚺᛖᛖᛞ ᚤᛟᚢᚱ ᚺᛖᛚᛈ.[/runic][/matrix][/color][/say]")
			saynn("[say=issix][color=#ff2b00][matrix][runic]ᚱᛖᛏᚢᚱᚾ ᛗᛖ ᛏᛟ ᛗᚤ ᚠᚨᛗᛁᛚᛁᚨᚱ ᚨᛒᛟᛞᛖ.[/runic][/matrix][/color][/say]")
		else:
			saynn("* rough sounding changing can be heard *")
		
		saynn("While the chanting happens you can't see what is happening, but you can hear it. There is also a fiery hot feeling coming from where Issix was, your "+Globals.getSkinWord()+" getting blasted with mild heat. After Issix's chant finishes all you san tell was that there was a flash and cling of something metal on the ceramic like floor surface. You blink, your vision clearing.")
		saynn("Where Issix was, he is there no more, what is left of him is just a single key. You pick it up, still a little dazed.")
		saynn("[say=pc]What the hell was that?[/say]")
		saynn("It's as if you've heard countless giggles from all around, but there is nothing around you, you are left in an empty, dark room, surrounded by medical devices and hum of unknown technology.")
		
		addButton("Pick up", "The key lies on the floor, take it", "after_win_cocky2")
		
	if state == "after_win_pacifist":
		aimCameraAndSetLocName("medical_nearconfessionary")
		saynn("[say=pc]Rest assured, I have no such plans. Let me be free and have fun with your stuff, just leave me alone.[/say]")
		saynn("[say=issix]Glad we agree.[/say]")
		
		saynn("After short awkward silence it does appear that you've both said your piece and you head towards the exit with key in paw. Unlocking the door you go through it, leaving Issix in the room behind, no longer his pet, his property.")
		addButton("Leave", "", "endthescene")
		
	if state == "after_win_cocky2":
		aimCameraAndSetLocName("medical_nearconfessionary")
		saynn("It's time to scram, you think. You hope the key that was left out on the floor fits the lock on the doors, and feel relief when it does. Leaving the medical concessionary alone.")
		addButton("Leave", "", "endthescene")
		
	if state == "after_win_figher":
		aimCameraAndSetLocName("medical_nearconfessionary")
		saynn("[say=pc]I've beaten you today, I'll beat you again. If your pets are on my way, I'll fold them too like a paper.[/say]")
		saynn("[say=issix]There is a tight line separating courage and bravado, I think you've crossed it a long time. Treat it as my final warning, do try me. Now, fuck off.[/say]")
		saynn("You smirk at him and head to the exit, leaving the room, with Issix in it.")
		addButton("Leave", "", "endthescene")
		
	if state in ["if_final_lost_issix_pain", "if_final_lost_issix_lust"]:
		if state == "if_final_lost_issix_pain":
			saynn("You collapse from the beating Issix gave you. A man with endless stamina and dirty tricks up his sleeve putting you down on your knees, completely draining your energy, showing you his superiority.")
		else:
			saynn("You collapse, your body no longer responding to your commands, fixated on lust and need for release. Issix owning your mind, weaving a net manipulating your thoughts and actions to produce a pet controlled by its lust.")
		
		saynn("[say=issix]To think you could win, ending up like a sniveling dog, on your knees. Weak, both in body and mind. Why do you insist on struggling so much? Don't you love the life of a pet I gave you? Don't you see how happy other pets in my care are?[/say]")
		saynn("He pauses, as if expecting an answer that never comes.")
		saynn("[say=issix]No matter. I'll make you see. You'll love it. I'll make you see it.[/say]")
		addButton("Continue", "", "noncon_noncon_start")

# Decided the following wouldn't work for characters I've written, but I'm leaving it as a comment
# 	if state == "finishissix":
# 		saynn("You decide to exploit this situation, after bringing him to his knees, making him huff deeply thanks to your own sexual appeal you come closer, knowing he can't retaliate.")
# 		
# 		if response == null:
# 			saynn("[say=pc]...[/say]")
# 			addButton("Dominate", "Dominate him thoroughly (light CBT)", "finishissix", [1])
# 			addButton("Kind", "Just kindly finish him off", "finishissix", [2])
# 		elif response == 1:
# 			saynn("[say=pc]Look at you, and you call yourself a Master? Pathetic.[/say]")
# 			saynn("Your words sting him, his face looks angry.")
# 			var days_in_harem = GM.main.getDays() - getModuleFlag("IssixModule", "Misc_Slavery_Info", {}).get("day_enslaved", GM.main.getDays())
# 			if days_in_harem > 50:
# 				saynn("[say=pc]I've been your pet for so long, for "+str(days_in_harem)+" days. Felt like years.[/say]")
# 			else:
# 				saynn("[say=pc]I've been your pet for "+str(days_in_harem)+" days. Lucky me that it's not that long.[/say]")
# 			
# 			saynn("[say=issix]You chose to be my pet, you chose to be under me.[/say]")  # TODO IF non-con route is added, this line has to vary
# 			saynn("[say=pc]My mistake.[/say]")
# 			saynn("You come closer to Issix, and crouch next to him looking at his hard {issix.penis}, he notices you and it feels as if he deep inside wants you to finish him off.")
# 			saynn("[say=issix]You've done enough, what else do you want? To humiliate me further?[/say]")
# 			saynn("[say=pc]Oh? I don't think it's your cue to talk, little bitch.[/say]")
# 			saynn("You grab him by his sack and squeeze, he flinches from pain.")
# 			saynn("[say=issix]Arggghhh. You already won, please.[/say]")
# 			saynn("Grabbing his hard pole you start jerking it off.")
# 			saynn("[say=issix]Aghhh.[/say]")
# 			saynn("[say=pc]How does [i]master[/i] feel like, huh?[/say]")
# 			saynn("[say=issix]...[/say]")
# 			saynn("[say=pc]Thought so.[/say]")
# 			saynn("You judge that Issix is close to giving in, you could probably let him cum or... You could be extra evil and make him beg for release. Either way he is already thoroughly dominated.")
# 			addButton("Evil", "Make him beg!", "make_issix_beg")
# 			addButton("Whatever", "Just let him cum and be over with it", "make_issix_cum")
# 
# 	if state == "make_issix_beg":
# 		saynn("As you see Issix already leaking pre you stop jerking him off and with your paw you raise his chin to face you, his face humiliated.")
# 		saynn("[say=pc][/say]")

	if state == "if_won_issix_pain":
		saynn("[say=issix]Enough. I yield.[/say]")
		saynn("Issix is laying on his knees in submission.")
		saynn("[say=issix]It's pathetic, for the Master to lose against his pet in a fight. You've made good enough of display of power. I... Don't know what to say. Leave now, I need a day to think things over, we will talk tomorrow.[/say]")
		addButton("Leave", "You've done enough", "endthescene")

	if state == "if_lost_issix":
		saynn("[say=issix]Do you get it now? Who OWNS YOU? Who is your Master? Do you understand now? You better fucking do. Don't you dare do this again, pet.[/say]")
		saynn("Feeling in pain, you don't have anything else to answer other than.")
		saynn("[say=pc]I'm sorry, Master, I won't do this again.[/say]")
		saynn("[say=issix]Do you really mean it? Or is that another lie? Look at me, LOOK![/say]")
		saynn("He grabs you by your neck, tilts your face to meet his gaze, his face angry, furious even, staring deep into you, just like when he was judging you when you wished to become his "+ Globals.getPlayerPetName() + ".")
		saynn("[say=issix]Don't make me assert control over you again.[/say]")
		saynn("He releases your body from heavy grip.")
		saynn("[say=issix]I think you suffered enough of humiliation for today. Do whatever you want, but I expect you tomorrow in the corner, as usual.[/say]")
		addButton("Leave", "Leave", "endthescene")

func _react(_action: String, _args):
	processTime(2*60)
	if _action == "honest":
		reaction = true
		
	if _action == "leaveissix":
		setModuleFlag("IssixModule", "Unwelcome_At_Corner", true)
		
	if _action == "finishissix":
		setModuleFlag("IssixModule", "Unwelcome_At_Corner", true)

	if _action == "contsurrender":
		var bg: ItemBase = GlobalRegistry.createItem("ballgag")
		bg.addSmartLock(SmartLock.KeyholderLock, "issix")
		var bm: ItemBase = GlobalRegistry.createItem("bondagemittens")
		bm.addSmartLock(SmartLock.KeyholderLock, "issix")
		GM.pc.getInventory().forceEquipByStoreOther(bg, "issix")
		GM.pc.getInventory().forceEquipByStoreOther(bm, "issix")
		Globals.markDayAsComplete()
		setModuleFlag("IssixModule", "Unwelcome_At_Corner", true)
		increaseModuleFlag("IssixModule", "Strikes_For_Disobedience")

	if _action == "startfight":
		var issix = GlobalRegistry.getCharacter("issix")
		issix.addLust(-issix.getLust())
		issix.addPain(-issix.getPain())
		runScene("FightScene", ["issix"], "issixfight")
		
	if _action == "struggle":
		runScene("StrugglingScene", [], "struggle_scene")
	
	if _action == "use_item":
		used_item = _args[0]
		var issix = GlobalRegistry.getCharacter("issix")
		issix.addLust(-issix.getLust())
		issix.addPain(-issix.getPain())
		if _args[1]:
			GM.pc.getInventory().removeXOfOrDestroy(used_item, 1)
		if used_item == "HorsecockDildo":
			issix.addPain(20)
		elif used_item == "Shiv":
			issix.addEffect(StatusEffect.Bleeding, [4])
			issix.addPain(50)
		elif used_item == "VialOfLiquidLust":
			issix.addLust(50)
			
	if _action == "noncon_noncon_start":
		runScene("NonconNonconScene", ["disobedience"], "nonconnoncon")
	
	if _action == "use_fists":
		if GM.pc.getStat(Stat.Strength) > 20:
			GlobalRegistry.getCharacter("issix").addPain(30)
		else:
			GM.pc.addPain(40)
		
	if _action == "start_final_fight":
		runScene("FightScene", ["issix", "finalfight"], "issixfinalfight")

	if _action == "understand":
		GM.main.setModuleFlag("IssixModule", "Is_Player_Forced_Today", 2*60*60)
		if not (getModuleFlag("IssixModule", "Issix_Mood", 50) >= 70 and reaction == true):
			increaseModuleFlag("IssixModule", "Strikes_For_Disobedience")

	if _action == "if_lost_issix":
		setModuleFlag("IssixModule", "Is_Player_Forced_Today", 3*60*60)

	if _action == "walkcorner":
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="stand", bodyState={leashedBy="issix"}})
		runScene("ParadedOnALeashScene", ["issix", GM.pc.getLocation(), "hall_ne_corner", [
			"Can't fucking believe this shit",
			"Did you really think this would work?",
			"Master says, pets obey"
		], "hall_ne_corner", "crawl"])

	if _action == "backtothething":
		runScene("SlaveryInfoScreen", [], "finishslaveryinfo")
		
	if _action == "submitinfull":
		GM.pc.getInventory().forceEquipByRemoveOther(GlobalRegistry.createItem("inmatewristcuffs"), "issix", false)
		
	if _action in ["after_win_cocky2", "after_win_figher", "after_win_pacifist"]:
		GM.pc.setLocation("medical_nearconfessionary")
		# Remove from harem
		setModuleFlag("IssixModule", "Issix_Anger_Noncon", 100)
		setModuleFlag("IssixModule", "PC_Enslavement_Role", 0)
		setModuleFlag("IssixModule", "Last_Day_Visited_Master", null)
		
		
	if _action == "wait2_issix":
		GM.pc.getInventory().forceEquipByStoreOther(GlobalRegistry.createItem("ballgag"), "issix")

	if(_action == "endthescene"):
		GM.main.setModuleFlag("IssixModule", "Last_Day_Visited_Master", GM.main.getDays())
		endScene()
		return

	setState(_action)
	
func saveData():
	var data = .saveData()

	data["used_item"] = used_item
	data["response"] = response

	return data

func loadData(data):
	.loadData(data)
	
	used_item = SAVE.loadVar(data, "used_item", null)
	response = SAVE.loadVar(data, "response", null)

func _react_scene_end(_tag, _result):
	if _tag == "finishslaveryinfo":
		endScene()
		
	if _tag == "struggle_scene":
		setState("medical_floor")

	if _tag == "nonconnoncon":
		GM.pc.setLocation("hall_ne_corner")
		setModuleFlag("IssixModule", "Last_Day_Visited_Master", GM.main.getDays())
		Globals.markDayAsComplete()
		endScene()

	if(_tag == "issixfight"):
		processTime(20 * 60)
		var battlestate = _result[0]
		var wonHow = _result[1]

		if(battlestate == "win"):
			if(wonHow == "lust"):
				setState("if_won_issix_lust")
			else:
				setState("if_won_issix_pain")
			addExperienceToPlayer(150)
			setModuleFlag("IssixModule", "Issix_Got_Rekt", true)
			setModuleFlag("IssixModule", "Unwelcome_At_Corner", true)
		else:
			setState("if_lost_issix")
			Globals.markDayAsComplete()
			increaseModuleFlag("IssixModule", "Strikes_For_Disobedience")
			addExperienceToPlayer(20)
			
	if _tag == "issixfinalfight":
		processTime(20 * 60)
		var battlestate = _result[0]
		var wonHow = _result[1]

		if(battlestate == "win"):
			if(wonHow == "lust"):
				setState("if_final_won_issix_lust")
			else:
				setState("if_final_won_issix_pain")
		else:
			if(wonHow == "lust"):
				setState("if_final_lost_issix_lust")
			else:
				setState("if_final_lost_issix_pain")
