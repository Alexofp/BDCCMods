extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")
var upProgressBar = preload("res://Modules/IssixModule/Internal/ProgressBar.tscn")

var PetTalk = null
var ui_text: LineEdit = null
var ui_progress: ProgressBar = null
var solution: String = ""
var initial_word: String = ""
var finished_puzzles := 0

# Spell backwards, count amount of letters, replace one of the letters with X and ask player to find it, rewrite the same word but with letter replaced to other one

const tasks := ["spell the word backwards", "count amount of letters in a word", "provide a missing letter", "rewrite given word with letter %s replaced by letter %s"]
const word_bank := ["promiscuous", "adventurous", "rectangular", "sunny", "enthralled", "hallucination", "horny", "servitude", "sophisticated", "reconditioned", "dejected", "enslaved", "bound", "fabricated", "confident", "hierarchy", "submission", "cattle", "compliance", "fantasy", "dominant", "infected", "acceptance", "admiration", "sympathetic", "command", "cooperation", "helpless", "leech", "vampire", "fishing", "restraint", "masculinity", "branding", "obedience", "consciousness", "collar", "degradation", "superstition", "anthropomorphization"]
const praise := ["Nice job, that was clear.", "Prefect, keep going.", "Sounded like a real good pet!", "Ah, music to my ears.", "Recited that like a true pro."]
const better := ["Not quite, try next one.", "Hmm, nope.", "That's... Let's just go with another one.", "Eh, that's not it.", "You really messed that one up, next.", "THat was pretty bad, do better, pet.", "Almost there but not quite."]

func _init():
	sceneID = "SpeechRegularTrainingWithIssix"
	PetTalk = load("res://Modules/IssixModule/SpeechModifiers/PetTalk.gd").new()

func _run():
	if(state == ""):
		addCharacter("issix")
		saynn("[say=pc]Master, can we train my speech a little?[/say]")
		saynn("[say=issix]Hmm, I guess you still need some help with that. Of course I'll help, besides, not only I've promised you I'll help but I'm still writing my paper and wouldn't mind some more data. Let's see..[/say]")
		
		saynn("After few taps on the tablet he says.")
		saynn("[say=issix]Yeah, this should be fine. Mhm... This looks good. Let's get this as well...[/say]")
		saynn("[say=issix]Plan is as follows: I dictate you words and you repeat them, alright?[/say]")
		addButton("Nod", "Begin the training", "start_game")
		
	if state == "round":
		saynn("[say=issix]Alright, your word will be...[/say]")
		puzzle()
		# var game = minigameScene.instance()
		# GM.ui.addCustomControl("minigame", game)
		# game.instantEscapePerk()
  # 
		# game.setDifficulty(RNG.randi_range(1, 3))
		# game.connect("minigameCompleted", self, "onMinigameCompleted")

# Backwards word
func puzzle1():
	initial_word = RNG.pick(word_bank)
	var reversed = ""
	for i in range(initial_word.length() - 1, -1, -1):
		reversed += initial_word[i]
	#warning-ignore:integer_division
	return [initial_word, reversed, tasks[0], int(initial_word.length())]
	
# count letters
func puzzle2():
	initial_word = RNG.pick(word_bank)
	return [initial_word, str(initial_word.length()), tasks[1], initial_word.length()/2+1]
	
# find missing letter
func puzzle3():
	initial_word = RNG.pick(word_bank)
	var random_letter_index = RNG.randi_range(0, initial_word.length()-1)
	return [initial_word.replacen(initial_word.substr(random_letter_index, 1), "X"), initial_word.substr(random_letter_index, 1), tasks[2], 3]
	
# rewrite word with new letter
func puzzle4():
	initial_word = RNG.pick(word_bank)
	var random_letter_index = RNG.randi_range(0, initial_word.length()-1)
	var random_other = RNG.pick(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "Y", "Z"])
	#warning-ignore:integer_division
	return [initial_word, initial_word.replacen(initial_word.substr(random_letter_index, 1), random_other), tasks[3] % [initial_word.substr(random_letter_index, 1).to_upper(), random_other], int(initial_word.length()/2)+1]


func _react(_action: String, _args):
	if _action == "start_game":
		GM.pc.getSkillsHolder().togglePerk("PetSpeak")  # Temporary so it doesn't interfere
		_action = "round"
	
	if(_action == "endthescene"):
		GM.pc.getSkillsHolder().togglePerk("PetSpeak")
		endScene()
		return
		
	if _action == "next_round":
		_action = "round"
	
	setState(_action)
	
func addProgressBar(id):
	var uiprogressbar = upProgressBar.instance()
	uiprogressbar.id = id
	GM.ui.textcontainer.add_child(uiprogressbar)
	GM.ui.textboxes[id] = uiprogressbar
	return uiprogressbar

func puzzle():
	var puzzle_data = call("puzzle"+str(RNG.randi_range(1, 4)))
	solution = puzzle_data[1]
	saynn("( %s )" % puzzle_data[2])
	yield(get_tree().create_timer(1.0), "timeout")
	saynn("3...")
	yield(get_tree().create_timer(1.0), "timeout")
	saynn("2...")
	yield(get_tree().create_timer(1.0), "timeout")
	saynn("1...")
	yield(get_tree().create_timer(1.0), "timeout")
	
	saynn("[say=issix][b]"+puzzle_data[0].to_upper()+"[/b][/say]")
	ui_text = GM.ui.addUITextbox("word_game")
	ui_progress = addProgressBar("word_game_pb")
	ui_progress.set_percent_visible(false)
	ui_progress.start()
	ui_progress.setTime(puzzle_data[3]+2 if OS.get_name() in ["Android", "iOS"] else puzzle_data[3])
	ui_progress.connect("timer_reached_zero", self, "endRound")
	ui_text.connect("text_changed", self, "_onTextChanged")
	ui_text.connect("text_entered", self, "_onTextEnter")
	
func _onTextChanged(text_changed: String):
	var caret = ui_text.caret_position
	ui_text.text = text_changed.to_upper()
	if ui_text.text == solution.to_upper():
		endRound()
	ui_text.caret_position = caret
	
func _onTextEnter(_ignore):
	if ui_text.text != solution.to_upper():
		ui_text.text = ""
		return
	endRound()
		
func endRound():
	finished_puzzles += 1
	ui_progress.queue_free()
	ui_text.queue_free()
	GM.ui.textboxes.erase("word_game")
	GM.ui.textboxes.erase("word_game_pb")
	if ui_text.text == solution.to_upper():
		saynn("[say=pc]%s![/say]" % [PetTalk.modify(initial_word, GM.pc, 30)])
		saynn("[say=issix]"+RNG.pick(praise)+"[/say]")
	else:
		saynn("[say=pc]%s[/say]" % [PetTalk.modify(initial_word, GM.pc, -1)])
		saynn("[say=issix]"+RNG.pick(better)+"[/say]")
	if finished_puzzles > 5:
		saynn("[say=issix]Well, hope that helped, let's try some more other time.[/say]")
		addButton("End", "", "endthescene")
	else:
		addButton("Next one", "Get next word", "next_round")

func saveData():
	var data = .saveData()
	
	data["finished_puzzles"] = finished_puzzles

	return data
	
func loadData(data):
	.loadData(data)
	
	finished_puzzles = SAVE.loadVar(data, "finished_puzzles", 0)
	
	if state == "round":
		GM.main.reRun()
