extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")
var preference = 0

func _init():
	sceneID = "PunRewAgainstWall"

func _run():
	if(state == ""):
		saynn("[say=issix]I've been thinking, you've been quite a well behaved pet, {pc.name}. I'd like to reward you for that. What do you think? Would you want to be pressed against the wall nicely by your Master, while {issix.he} pistons your pretty body?[/say]")
		addButton("Yes!", "Be excited about it", "yessex")
		Globals.addButtonCheckNoncon("Meh", "Reject the proposed activity", "nosex")
		
	if state == "nosex":
		saynn("[say=pc]As much as I'd love to receive Master's reward, this time I'll have to say no.[/say]")
		saynn("[say=issix]Oh? I see. Rewards are something pleasing, as it was supposed to give you something, you also have the right to reject it. As such, I'll honor your request, pet.[/say]")
		addButton("Leave", "Leave", "endthescene")

	if state == "yessex":
		saynn("You accept Master's offer to have {issix.his} way with you.")
		
		saynn("[say=issix]Mrrr, that's great to hear, come here.[/say]")
		saynn("Master pulls {issix.his} own uniform of {issix.himself}, flaunting the body, A waft of manly musk hits your nose.")
		var slotCoverage = Globals.getBodyCoveringItem(GM.pc, BodypartSlot.Vagina)  # Even if player doesn't have Vagina it should work with base game clothing
		if slotCoverage != null:
			saynn("[say=issix]We'll have to get rid of that "+slotCoverage.getVisibleName()+" before we begin, it just gets in my way.[/say]")
			
			saynn("Issix reaches for your garments and pulls them off you.")
			saynn("[say=issix]Isn't that batter? Mmm..[/say]")
			addButton("Continue", "", "walled")
		else:
			saynn("[say=issix]We don't need to do any undressing on your part, that's great, holes should be free.[/say]")
			addButton("Continue", "", "walled")

	if state == "walled":
		playAnimation(StageScene.SexPinnedBehind, "tease", {pc="issix", npc="pc", bodyState={naked=true, hard=false}, npcBodyState={naked=true, hard=false}})

		saynn("Master gently presses you with your back against the wall. {issix.His} clawed paws exploring your {pc.thick} sides, waist, arms. Despite how possessive his exploration is, you feel safe. You can tell that Master wants your „reward” just as much as you do.")
		saynn("[say=issix]How do you like your Master, pet? Move your paw over my fur, how is it? Mmm. [b]My[/b] little pet, so precious.[/say]")
		saynn("{issix.He} grabs you by your legs and while pressing with {issix.his} front, his arms move your legs over {issix.his} shoulders letting you rest your legs high up while being sandwiched in between of the dragon and the wall.")
		if GM.pc.hasReachableVagina():
			saynn("[say=issix]Now tell me, precious, where would you want your Master to take you today? Your body offers me a set of holes that I'm more than fine with exploring, it's a present to you, so the choice is yours today.[/say]")
			saynn("{issix.He} places his left clawed paw over your privates, massaging them both gently while awaiting your preference.")
			addButton("Vaginal", "Ask Master to take you vaginally", "vag")
			addButton("Anal", "Ask Master to take you anally", "anal")
		else:
			if GM.pc.hasReachablePenis():
				saynn("Master teases you by slowly stroking your {pc.penis} with {issix.his} clawed paw.")
			else:
				saynn("Master teases your privates by massaging them with {issix.his} clawed paw.")
			
			saynn("[say=issix]Mrr, good {pc.boy}. Now, its time for the main course.[/say]")
			addButton("Continue", "", "start_sex")
			
	if state == "start_sex":
		playAnimation(StageScene.SexAgainstWall, "tease", {pc="issix", npc="pc", bodyState={naked=true, hard=true}, npcBodyState={naked=true, hard=true}})  # inside, sex, fast
		
		if preference == 1:
			saynn("[say=pc]I'd like Master to take my {pc.vagina} today, please![/say]")
			saynn("[say=issix]Haha, so eager. I like it.[/say]")
		elif preference == 2:
			saynn("[say=pc]I'd like Master to take my {ass} today, please![/say]")
			saynn("[say=issix]Haha, so eager. I like it.[/say]")
		
		saynn("Azazel, asked for little help from Master, helped to apply lube up your needy "+("pucker" if preference in [2, 0] else "pussy slit")+", just in case your natural slickness wasn't enough.")
		saynn("[say=azazel]*sniff* Oh, it's the strawberry flavored one, now I want to lap it out of there.[/say]")
		saynn("With lube applied, your Master continues the teasing, by putting the tip of {issix.his} hardening {issix.penis} right into your "+pusass()+". With each such tease, {issix.his} {issix.penis} getting more and more distinctive as its surface rubs your bottom, you get that spark of endorphins going through your body.")
		saynn("[say=issix]Maybe you'd like me to keep at going like this, huh? Pet?[/say]")
		saynn("[say=pc]M-master. P-please, breed me.[/say]")
		saynn("[say=issix]I haven't heard a thing, maybe you should speak louder.[/say]")
		saynn("[say=pc]MASTER, PLEASE BREED ME![/say]")
		saynn("[say=issix]Hehe, as you wish, "+Globals.getPlayerPetName()+".[/say]")
		addButton("Thrust", "Your "+("pussy" if preference == 1 else "ass")+" is penetrated by his one-eyed monster", "sex_1")
		
	if state == "sex_1":
		playAnimation(StageScene.SexAgainstWall, "fast", {pc="issix", npc="pc", bodyState={naked=true, hard=true}, npcBodyState={naked=true, hard=true}})
		
		saynn("In a rhythmic manner, your Master rewards you for good behavior by thrusting {issix.his} bone into your "+pusass()+", you asked {issix.him} for it, after all. Intense feeling of overwhelming pleasure takes you, along with it, your panting reverbs the surfaces of the nearby walls, letting everyone know what a slut you are, bringing attention to your current love affair with your owner. Owner, of your body"+(", physical evidence of which currently hidden to the wall behind you." if getModuleFlag("IssixModule", "Issix_Branded_PC", false) else "."))
		saynn("[say=issix]You are doing great, keep i-t up![/say]")
		saynn("As the pistoning continues, sweat starts to be more and more noticeable, with love making being a fairly tiresome activity this is very normal. Same with moist, heavy and hot breathes coming out of Master's face straight at yours, unavoidable but welcome in this close encounter.")
		saynn("You close your eyes and arch your head back against the wall – only natural as satisfying feelings course and overwhelm your body.")
		saynn("[say=issix]I'm al- almost done, your "+pusass()+" is so great! Ughh![/say]")
		if preference == 1:
			saynn("And it's true, you are drooling like a faucet from both your mouth as well as your {pc.pussyStretch} pussy.")
			
		saynn("Approaching your own orgasm, you hear (and feel) approaching {issix.his}, it's a matter of seconds as you brace yourself, lost in pleasure.")
		addButton("Orgasm", "", "sex_2")
		
	if state == "sex_2":
		playAnimation(StageScene.SexAgainstWall, "tease", {pc="issix", npc="pc", pcCum=true, npcCum=true, bodyState={naked=true, hard=true}, npcBodyState={naked=true, hard=true}})
		
		saynn("[say=issix]Take.. Your... Reward![/say]")
		saynn("Finally, both of you achieve the great O, the climax. Master does not even entertain the idea of pulling out, letting {issix.his} seed fill insides of your greedy "+("and fertile " if fertile() else "")+pusass()+".")
		saynn("[say=issix]What a good pet you've been.[/say]")
		saynn("At the end there with {issix.his} cock still inside of you, {issix.he} pets your head and whispers how enjoyable your body is to {issix.him}.")
		saynn("Finally, when the pleasure dies out naturally, gently the dragon puts you back on your {pc.feet}, letting you stand on your own once again.")
		saynn("[say=issix]Hope you enjoyed your treat. There is plenty more coming from being a good attendant of mine.[/say]")
		
		saynn("You thank your Master for the opportunity and leave.")
		addButton("Back", "", "endthescene")

func pusass():
	return "{ass}" if preference in [0, 2] else "{pc.vagina}"
	
func fertile():
	return GM.pc.getBodypart(BodypartSlot.Anus).hasWomb() and GM.pc.getFertility() > 0.0 if preference in [0, 2] else GM.pc.getBodypart(BodypartSlot.Vagina).hasWomb() and GM.pc.getFertility() > 0.0

func saveData():
	var data = .saveData()

	data["preference"] = preference

	return data

func loadData(data):
	.loadData(data)
	
	preference = SAVE.loadVar(data, "preference", 0)


func _react(_action: String, _args):
	if _action == "vag":
		preference = 1
		_action = "start_sex"
		
	if _action == "anal":
		preference = 2
		_action = "start_sex"
		
	if _action == "sex_1":
		GM.pc.addLust(40)
	
	if _action == "sex_2":
		if preference in [0, 2]:
			GM.pc.cummedInAnusBy("issix", FluidSource.Penis)
			if GM.pc.hasReachablePenis():
				GlobalRegistry.getCharacter("issix").cummedOnBy("pc", FluidSource.Penis, 0.2)
			elif GM.pc.hasReachableVagina():
				GlobalRegistry.getCharacter("issix").cummedOnBy("pc", FluidSource.Vagina, 0.2)
		elif preference == 1:
			GM.pc.cummedInVaginaBy("issix", FluidSource.Penis)
			if GM.pc.hasReachablePenis():
				GlobalRegistry.getCharacter("issix").cummedOnBy("pc", FluidSource.Penis, 0.2)
			elif GM.pc.hasReachableVagina():
				GlobalRegistry.getCharacter("issix").cummedOnBy("pc", FluidSource.Vagina, 0.2)
		GM.pc.addLust(-GM.pc.getLust())


	if(_action == "endthescene"):
		increaseModuleFlag("IssixModule", "Pet_Time_Interaction_Today", 20*60)
		endScene()
		return

	setState(_action)
