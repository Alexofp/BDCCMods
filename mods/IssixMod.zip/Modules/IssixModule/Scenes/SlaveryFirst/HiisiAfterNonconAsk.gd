extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "HiisiAfterNonconAsk"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "stand", {npc="hiisi", npcAction="stand"})
		addCharacter("hiisi")
		saynn("You peacefully walk through the main halls of BDCC, and as you do that suddenly you feel pull on your right side that pushes you out into a small underused passageway.")
		saynn("[say=hiisi]{pc.Name}, we need to talk.[/say]")
		saynn("[say=pc]Hiisi? What's up?[/say]")
		saynn("He looks around making sure no one else sees you two. ")
		saynn("[say=hiisi]You've been dragged by our Master to the medical confectionary recently, correct?[/say]")
		addButton("Yes", "You do remember something about leaving it with Master, but can't remember entering one", "conf_yes")
		addButton("Don't remember", "You can't recall", "conf_idk")
		addButton("No", "You did not (lie)", "conf_no")
		
	if state in ["conf_yes", "conf_idk", "conf_no"]:
		if state == "conf_yes":
			saynn("[say=pc]I did, or at least I remember leaving one with Master after operation.[/say]")
		elif state == "conf_idk":
			saynn("[say=pc]Honestly, I can't remember anything about it, recently lost some memories, hopefully they come back...[/say]")
		else:
			saynn("[say=pc]No, I did not.[/say]")
			saynn("[say=hiisi]I know for sure you did, so there are two options: you don't remember or you are lying.[/say]")
			
		saynn("[say=hiisi]I simply want to know more about that. What you did there with Master, what happened, anything.[/say]")
		
		if state == "conf_yes":
			saynn("[say=pc]I'm sorry to say, but I don't really remember. I woke up on a medical bed and Master mentioned something about doctors and operation. Do you know if I've had any medical condition prior to my recent incident?[/say]")
			if GM.main.getModuleFlag("IssixModule", "Random_Encounter_Scene", 0) > 2:
				saynn("[say=hiisi]... You really don't know?[/say]")
				saynn("[say=pc]Don't know what?[/say]")
				saynn("[say=hiisi]Nevermind... If you really don't remember, then there is no point in me asking more, sorry for the trouble.[/say]")
				saynn("[say=pc]What is this about anyways?[/say]")
				saynn("[say=hiisi]Nothing, just forget it.[/say]")
				saynn("The way Hiisi reacted was certainly pretty strange to you. Why even bring that up? Is he suspicious of something? Canine left you there without answers.")
			else:
				saynn("[say=hiisi]Not that I know of, you've never had anything like this, and besides, before you were taken away Master was angry at you for not coming to the harem for few days... For like, third time.[/say]")
				saynn("[say=pc]I did that? ... I don't imagine doing something like this.[/say]")
				saynn("[say=hiisi]You better believe you did. I mean, I don't imagine leaving Az, Lamia and Master like that but...[/say]")
				saynn("He thinks for a moment, then looks at you as if he had lost train of thought.")
				saynn("[say=hiisi]You don't imagine leaving Master huh?[/say]")
				saynn("[say=pc]Not one bit.[/say]")
				saynn("[say=hiisi]That's.. Curious.[/say]")
				saynn("[say=pc]Why is that?[/say]")
				saynn("[say=hiisi]It's... Nothing. I'm not fully sure. Anyways, if you have nothing else to tell me about that time then I suppose I can let you go.[/say]")
				saynn("[say=pc]You sure you don't want to tell me more?[/say]")
				saynn("[say=hiisi]I'm sure. See you, {pc.name}.[/say]")
				saynn("He says as he leaves you alone there. He felt suspicious, but left you without any answers.")
		elif state == "conf_idk":
			saynn("[say=hiisi]Not that I know of, but what do you remember about yourself?[/say]")
			saynn("[say=pc]Umm... I... Honestly don't know.[/say]")
			saynn("[say=hiisi]And that isn't strange to you in any way?[/say]")
			saynn("[say=pc]Why would it? Master said I could lose my memory after some medical issues.[/say]")
			saynn("[say=hiisi]... Forget I asked, I'm out of here.[/say]")
			saynn("[say=pc]Sure, see you Hiisi.[/say]")
			saynn("And so the canine leaves.")
		else:
			saynn("[say=pc]I don't know what you are insinuating, and even if we were there, so what?[/say]")
			saynn("[say=hiisi]I just need to know, okey? So were you there? And what did you do there?[/say]")
			saynn("[say=pc]Again, I weren't there.[/say]")
			saynn("Canine growls in frustration.")
			saynn("[say=hiisi]I know for a fact you were. Fuck it. Forget I asked.[/say]")
			saynn("He leaves, annoyed. What is his deal?")
			
		addButton("Leave", "", "endthescene")
		

func _react(_action: String, _args):
	processTime(2*60)

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Susipicious_Hiisi_Scene_Occured", true)
		endScene()
		return

	setState(_action)
