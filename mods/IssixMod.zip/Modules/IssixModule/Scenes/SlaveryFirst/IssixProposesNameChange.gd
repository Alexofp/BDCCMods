extends SceneBase

func _init():
	sceneID = "IssixNameSuggestion"

func _run():
	if(state == ""):
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="stand"})
		saynn("Your Master gestures for you to come to him.")
		saynn("[say=issix]{pc.Name}, I were wondering... And I apologize for suddenness of this odd question but just how much is your name worth to you? How dear do you hold it?[/say]")
		saynn("[say=issix]A lot? Little? How significant it is for your core identity?[/say]")
		addButton("A lot", "Your name is you, its your very core identity", "precious_name")
		addButton("Significant", "Your name is significant but you don't see it as something inherently essential to you", "middle_name")
		addButton("It's a name", "Your name is a name given to you, but to you it's just identifier given to you by the society and you don't see it as part of your core identity", "indifferent_name")
		
	if state == "precious_name":
		saynn("[say=pc]My name decisively is me, without it, who am I? {pc.name} is a common thread that others choose to recognize me by and it's a single thing I know since my very beginning, of course it's very important to me.[/say]")
		saynn("[say=issix]Is it? And if someone was to snatch that bastion of self from you? If someone was to take away your name? Would that be the end of self? Would you be someone else entirely?[/say]")
		saynn("[say=pc]I guess? I feel that would be on part losing self.[/say]")
		saynn("[say=issix]I see. Well, I wanted to talk with you about that, actually. I wanted to ask you if you'd like to be given a new name, from your Master, one that would replace your old one forever.[/say]")
		saynn("[say=pc]Replace... A name?[/say]")
		saynn("[say=issix]In essence, yes. You can think of it as being born again and starting your life in servitude to me from the very start, with entirely new name given to you. You've been my dear pet for so long, and the way I see it, your current name stands in the way of really embracing who you are – my pet.[/say]")
		addButton("End", "(You can now agree to name change in training menu)", "endthescene")
		
	if state == "middle_name":
		saynn("[say=pc]I mean, obviously my name is pretty important to me – it is how I and everyone around referred to me from very beginning, however at the same time I do not see it as something [b]essential[/b] to me. It is a name, and if there are a really good reason for it, I could change it.[/say]")
		saynn("[say=issix]A really good reason you say? What kind?[/say]")
		saynn("[say=pc]I dunno, maybe if I were running away from something and needed new identity.[/say]")
		saynn("[say=issix]Hah, a classic. Well, what would you say about your Master asking you to? Would you think it's a good reason?[/say]")
		saynn("[say=pc]That's.. Sudden.[/say]")
		saynn("[say=issix]It is, but you don't have to give me your answer yet. You've been my dear pet for so long, and I see it as final step to solidify your position, your new life. Sleep and think about it, pet, and if you decide to do so, come and tell me, I'll be waiting.[/say]")
		addButton("End", "(You can now agree to name change in training menu)", "endthescene")
		
	if state == "indifferent_name":
		saynn("[say=pc]To be frank, it's nothing more than a word that people are associating me with, nothing more. It doesn't have any mroe power than words in the dictionary and honestly couldn't care less what is it, not in this place, especially. To some in here I'm already just a number.[/say]")
		saynn("[say=issix]That's... Unexpected, to say the least. I think many of creatures would say that a name is something very important to them, or that they don't imagine having it forced upon them or changed as they identify with it. You, on the other hand, don't seem to have the same idea?[/say]")
		saynn("[say=pc]It's just a word, Master already calls me a pet, and that's what I'm to Master, which is fine with me.[/say]")
		saynn("[say=issix]You surely are a strange one, but you speak with commitment to your philosophy and I respect that.[/say]")
		saynn("[say=issix]I've asked you about this, because I'd like for you to change your name. I want you to give it a thought and let me know if you'd agree to it. I'd be most delighted to replace your current name.[/say]")
		saynn("[say=pc]Uh, sure, I'll... Think about it and let you know if such is your desire Master.[/say]")
		saynn("[say=issix]Good pet. Good pet.[/say]")
		addButton("End", "(You can now agree to name change in training menu)", "endthescene")
			

func _react(_action: String, _args):
	processTime(2*60)

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Issix_Suggested_Name_Change", true)
		endScene()
		return

	setState(_action)
