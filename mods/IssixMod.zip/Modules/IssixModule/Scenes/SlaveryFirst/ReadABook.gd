extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var reason = null
const book_ids = ["plush"]

func _init():
	sceneID = "ReadABook"
	
func _initScene(_args = []):
	update_book_ids()
	setState(decideTypeBook())
	processTime(5*60)

func _run():
	if(state == ""):
		pass
		
	if state == "plush":
		saynn("You get a hold of a small booklet, it appears to be a part of longer series of books on supposedly magical items written by some whacko self-described scholar of „magic”. Though you have heard of this group of individuals – they do some pseudo-scientific research into interactions between demons and the world. They supposedly tap into powers of demons to enhance items with special features. Though their claims are not being taken seriously, with any beings of demonic origin denying existence of any kind of super powers originating with them.")
		saynn("Regardless, this group of individuals is known to be in hiding, many of them publishing their works under a pseudonym. The word is that the demons themselves are trying to get rid of those „scholars” for speaking a dangerous truth about an entire category of beings, as well as experimenting on some for their research.")
		saynn("This specific booklet has been apparently published under pen name of „Czarodziej” and appears to be entry number 3 in the series.")
		saynn("Inside, it isn't an usual comic book, or well, it is what you'd imagine a scholar to think of a comic book – while there are a lot of photos and illustrations, the author couldn't possibly restrain themselves from adding fat text excerpts detailing their findings.")
		addButton("First item", "Read about first item", "plush_2")
		
	if state == "plush_2":
		saynn("First 4 pages illustrate a supposedly magical wine glass stolen from one of the demons. On the pictures there is nothing extraordinary about it, there are measures in the background showing its width and height. The accompanied description says that resonance of vibrations that the glass produces when filled with fluids is vastly different from any regular wine glass, author suggests that demons use wine glasses like this one to enhance properties of fluids in them, while nothing that they know nothing about how those properties are supposedly boosted or what process actually takes to enhance the liquids...")
		addButton("Second item", "Read about second item", "plush_3")
		
	if state == "plush_3":
		saynn("You change the pages and navigate to description of the second item, the moment you see it you feel shivers all over your body. You recognize the item!")
		if getModuleFlag("IssixModule", "Azazel_Has_Plushie", true):
			saynn("It's Azazel's very plushie you can see from right here! It's standing on his blanket!")
		elif PCHasPlushie():
			saynn("It's the very plushie you've been given by Azazel! You have it right here with you! It's identical!")
		else:
			saynn("It's the very plushie you've been given by Azazel! You don't have it with you, but you can recognize it very well.")
		
		saynn("Your eyes constantly move in between of the booklet and the plushie itself, as you start reading scholar's description.")
		saynn("„This puppet extrudes large amounts of Amdemonium Al Zar, it brings attention how the puppet emits pink light from its body. This might be connected with puppet being a source of heat as well, radiating around 7 degrees celcius higher than the temperature of its environment.”")
		saynn("„None of my attempts to verify the contents of the puppet using specialized equipment succeeded. I've also attempted to remove the outer material, to no luck. Despite soft material covering the insides, as well as seemingly soft filling, the material seems near indestructible. Attempts to destroy the puppet using fire, force, gravitational forces, tearing, acids result in the very same – nothing.”")
		saynn("On last page describing the „puppet” as this researcher calls the plush you find interesting note:")
		saynn("„While researching the puppet, I were speaking with my colleague near it. After conversation was over, and my attention turned back to the puppet, I've noticed it has changed drastically! The temperature of puppet has fallen and now instead its readings show a different of seven degrees celcius LOWER than the environment! While analyzing what could have caused this change, I've tried to reproduce all of the events that happened in between, letting me to find that the puppet changes its property based on a command, similarly to some of the other demonic items seem to be doing. The command for this specific item is „[color=red]Mūto[/color]” – change. This was one of the words spoken by myself when conversing with fellow colleague. The utility of the puppet is still unclear, but it clearly has [i]something[/i]. It is worth noting, that after speaking the command, the puppet enters some kind of cycle that resets somewhere during the local night cycle of planet, connection with other celestial bodies perhaps?”")
		saynn("The notes on the plush ends there.")
		addButton("Third item", "Read about third item", "plush_4")
		
	if state == "plush_4":
		saynn("Third item appears to be of sexual nature. It's a thin leather-like harness, mostly back, with two red lines appearing near the edges of each belt. The scholar describes the item as such: „This leather harness has been acquired by member of the public on a black market. From information passed to me, it has been sold by poorer demon on brink of poverty. Normally demonic items are strictly prohibited to be sold or otherwise given to non-demonic entities, so it's certainly a rare method of acquisition.”")
		saynn("„This body harness continuously expels large amounts of demonic energy on its own, it also has bio signatures suggesting there is organic part to it. Material's structure seems to be very solid with self-healing properties, consistent with other demonic items.”")
		saynn("You flip the page to see what else is written on the entry, next pages have images of a anthropomorphic ferret earing the body harness, their face expression suggesting arousal and ferret being rather pent up.")
		saynn("„We have acquired o test subject to see how the harness reacts when put on an actual living being – obvious conclusion considering purpose of those body harnesses. While the harness did not latch onto subject at nearest occasion as we expected, while it was fully put on, it has sealed to wearer's or host's body. Each leather strap bonding with wearer's surface body structure, it's unclear what kind of process has to happen to unseal the harness.”")
		saynn("„The harness's red lines across the edges of each belt started visibly glowing, to the point the glow is visible under regular sunlight. Subject appears to experience increased arousal as a result of harness, calling many times for us to „Fuck them”, „Claim them” or to cite directly „p-please! i-i [i]*huff*[/i], need you to ju-just break meee”. Our tests show that after day 5 of wearing the harness their cognitive abilities have degraded significantly, likely due to constant state of arousal which takes its toll on test subject's mental capabilities. There are reasons to believe that harness additionally serves as way to extract life-essence from the wearer similarly to item no. 23, however this requires more studies.”")
		saynn("This is where the entry seems to end. Certainly sounds like an interesting piece of equipment... With that the booklet is complete. ")
		addButton("Back", "Go back", "endthescene")
		
		
	if state == "regular":
		saynn("You read one of the comic books, 20 minutes pass.")
		addButton("Back", "Go back", "endthescenetime")
	
func PCHasPlushie() -> bool:
	return GM.pc.getInventory().hasItemID("AzazelsPlushie") or GM.pc.getInventory().hasItemIDEquipped("AzazelsPlushie")

func saveData():
	var data = .saveData()

	return data

func loadData(data):
	.loadData(data)
	
func getRandomBook():
	var books = getModuleFlag("IssixModule", "Special_Books_Read", {})
	var book_ids = books.keys()
	book_ids.shuffle()
	for key in book_ids:
		if !books[key]:
			return key

func decideTypeBook() -> String:
	if !Globals.all(getModuleFlag("IssixModule", "Special_Books_Read", {}).values()):
		if RNG.chance(20):  # 1/5 chance that we will find a special book
			return getRandomBook()
	return "regular"

func update_book_ids():
	var books = getModuleFlag("IssixModule", "Special_Books_Read", {})
	for b_id in book_ids:
		if !books.has(b_id):
			books[b_id] = false
	GM.main.setModuleFlag("IssixModule", "Special_Books_Read", books.duplicate(true))

func readBook(book_id: String):
	Globals.modifyDictStates("Special_Books_Read", book_id, true)

func _react(_action: String, _args):
		
	if _action == "plush_2":
		processTime(5*60)
		readBook("plush")
		
	if _action == "plush_3":
		processTime(9*60)
		
	if _action == "plush_4":
		setModuleFlag("IssixModule", "Plushie_Learned_Password", true)
		processTime(9*60)
	
	if(_action == "endthescenetime"):
		processTime(15*60)
		endScene()
		return
	
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)

