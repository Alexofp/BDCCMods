extends SceneBase

var env = {"yard_": "greenery of yard along with slighly moist smell of greenery", "cell": "large cellblock, with iron bars all around standing strong against the ground", "hall": "regular looking halls and corridors, central piece of the prison available to the prisoners", "med_": "corridors sprawled all around, completing the look with smell of antiseptic in the air", "medical_": "one of many rooms gracing the medical staff with equipment they need to treat and heal prisoners and staff alike", "eng_": "countless restricted corridors responsible for giving many engineers in the prison to maintain the metal junk of a space station you call home", "mining_": "a spacious but crude looking walls reminding you of industrial purpose of this facility stretch around you"}

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "CorruptedVisionFlashback"

func _initScene(_args = []):
	setState("randomScene"+str(RNG.randi_range(1, 3)))
# 
# func resolveCustomCharacterName(_charID):
# 	if(_charID == "npc"):
# 		return npcID

func _run():
	if(state == ""):
		pass
		
	if state == "randomScene1":
		saynn("A regular day at BDCC, you could think. Talking around hallways, moving between rooms and sluts fucking each other in the corners. Your mundane walk is interrupted by sudden, heavy pulsating headache. You put a paw on your forehead and the prison around you swirls for a second. Your vision slowly darkens, and everything in it becomes more and more... Changed. Creatures looking as if they took a bath in dark purple mud, their faces mindless, thoughtless, all of their clothes, fur replaced with thick layer of something slick, hard.")
		saynn("The walls, and every surface around polluted in dark dark purple colors. Huge veins traveling through the ceiling, moving, pulsating. Smaller veins spread from those and connect with various devices - light switches, cameras and even go through small holes in hallway metal plating. The buzz of light replaced by this slocking sound of dark slime getting pumped and being pressed on.")
		saynn("The air is moist, as if full of a mix in between of decay and something synthetic.")
		saynn("Hearing rather unique sound behind you, you turn your head.")
		saynn("[say=pc]FUUUCKK![/say]")
		saynn("You exclaim as your body reflexively takes a jump backwards. Right next to your back stood a faceless doll like humanoid posture made of the same dark purple fluid but hardened – giving it a smooth surface.")
		saynn("[say=pc]What the fuck are you?![/say]")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]You remember us. Your integration isn't complete. Remember what we said, seek us out.[/pulse][/sayOther]")
		saynn("[say=pc]You are w-[/say]")
		saynn("Whatever you were about to say has been answered to you within your mind. Yes, it's the same entity that you remember from back when you were escaping from Issix in the dream.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]The hive must be rebuilt.[/pulse][/sayOther]")
		saynn("Faceless puppet before you very quickly melts down into the black sludge as the headache overtakes you once again. Your eyelids squeeze tight as you are trying to deal with immense pain before everything comes back to normal. Light comes to your vision, there are postures of others around you. It's as you remember it all.")
		saynn("[say=pc]Ugh, that was odd.[/say]")
		saynn("You are well aware that your dream left you with some long lasting effect, but is there more to the „hive”? Does it really exist?")
		addButton("Continue", "Calm down and continue to live your life", "endthescene")
		playEnv()
		
		
	if state == "randomScene2":
		saynn("As you walk along "+getEnvDetail()+", suddenly all of the lights go out for a mere moment. After they come back place around you is [i]much more different[/i]. Creatures walking with blank expression, the halls oozing with black viscous fluid dripping from the ceiling, flowing from the walls. The ground is a foot deep in the stuff, which means both of your {pc.feet} are entirely under the gunk. A loud, psychodelic music reverbs around you coming from a distance. Everything is so wrong.")
		saynn("[say=pc]WHAT THE [/say]")
		saynn("Each creature in vicinity turns their head towards you, and this sight terrifies you, necks of some of them shouldn't even allow them to turn this way. Their eyes are blank - no irises, no pupils, entirely white. They all freeze, so do you. The fear overtakes you, you'd run but they are all around, you don't want to get close to any of them. With every second of this terrifying sight, the music intensifies further.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Seek me out. Let me touch you, so we can spread this gift.[/pulse][/sayOther]")
		saynn("Familiar voice rings through all of them, all of the figures around you, said in slightly different tone depending on who the creature is, all said in unison, however.")
		saynn("The lights go out again. You start to run, somewhere you've seen biggest space to squeeze through the figures you saw. Just a second later lights come back, along with them the normality you are accustomed to. Whoever is nearby looks normal again, and dark-purple fluid no longer occupies every spot of the environment.")
		saynn("You recall the events of the chase that Issix gave you, and how you entered that place of secret fight club which was the core of the crazy corruption you saw. It cannot be a coincidence you still see snapshots of that insanity, could it? It all is in your head but... You aren't crazy, are you?")
		moveRandomly()
		addButton("Continue", "Calm down and continue to live your life", "endthescene")
		playEnv()
# 		
# 	if state == "randomScene4":
# 		"Humanoid figures that weren't there before with entirely smooth body features and no faces still somehow staring at you. "
		
	if state == "randomScene3":
		saynn("While wandering around the prison in monotonous routine of your daily walk your surroundings suddenly change within blink of your eyes.")
		saynn("You are standing in enormous circular chamber illuminated by ambient purple light coming from a tube sprawling from the very center of the room. Inside of tube there are bright pink crystallic formations hovering as they are submerged in some kind of transparent liquid. Everything around however is consumed by deep dark purple liquid, or rubber like layer. As you move around, the surface you are standing on with your {pc.feet} feels very much like that of meat, its fibrous moisty firm surface layered with the tar like substance on top. Your {pc.foot} sticks a little each time you try to take a step, sucked to the ground by fluid's properties.")
		saynn("The walls of this chamber are full of pods. Thinking back, you did see a pod like one of them in the past, it was the very same pod that you yourself entered before waking up in your bed, back when you were having a terrible dream of Issix chasing you. Each pod has a large vein coming out of it, going somewhere to the ceiling. What is noteworthy however, are the moans coming from the pods that are [b]not empty[/b]. Some of them, have a creature in them, all of similar height but different species, at least out of those you can still recognize. There are some that seem as if they enjoined their pod only recently – having large parts of their body, their fur or scales still exposed to the musty, heavy air around. They still seem to... Struggle? At least as much as one can call occasional limb stretching a struggle. Pods have formed their own form of bondage with black bands like restricting wrists, ankles, stomach and neck of each host.")
		saynn("While you can't see faces of each of the „victims” because of dark mask dripping tar like fluid, covering their entire faces, all of them breathe in unison - a slow, regular breath cycle.")
		saynn("There are of course those who seem to have spent in the pod a longer while. For those the entire body is covered with tar like fluid or, in case of some, the smooth version reminding more a doll made out of dark purple if not black rubber. Any sort of distinct body features they had were entirely erased to this standardized template of sorts.")
		saynn("Memorized by the wide picture of a nest you are seeing, a voice peaking out makes you jump.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Hive we seek to build. Everyone connected. Serving same purpose.[/pulse][/sayOther]")
		saynn("You ask in your thoughts how do you see all of this, where are you, how are they able to speak to you, the answers flood your mind.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Your mind is connected. Your body is not. You are attuned only in part. Seek me.[/pulse][/sayOther]")
		saynn("A loud bang reverb from one side of the chamber, from your right. Inky tar appears out of nowhere, covering everything, behaving like giant wave. It's a tsunami of tar approaching you momentarily. As you put your arms above to shield your head from incoming impact, it doesn't come and the sounds are replaced with regular noise of the prison.")
		saynn("You look around and see nothing special, just the same place you stood before appearing in large chamber. Other prisoners are looking at you weirdly.")
		
		moveRandomly()
		addButton("Continue", "Calm down and continue to live your life", "endthescene")
		playEnv()

func getEnvDetail():
	for e_type in env.keys():
		if e_type in GM.pc.getLocation():
			return env[e_type]
	return "familiar set of hallways"
	
func playEnv():
	if Globals.ofModule("IssixModule").IssixAudio["sounds_squelch"] == null:
		return
	while(true):
		Globals.ofModule("IssixModule").IssixAudio["sounds_squelch"].playAsSFX()
		yield(get_tree().create_timer(2.0 + RNG.randf_range(0.0, 3.0)), "timeout")
	
	
func moveRandomly():
	var directions = [GameWorld.Direction.NORTH, GameWorld.Direction.WEST, GameWorld.Direction.EAST, GameWorld.Direction.SOUTH]
	var direction = null
	directions.shuffle()
	while directions.size() > 0:
		direction = directions.pop_front()
		if GM.world.canGoID(GM.pc.getLocation(), direction):
			break
	if direction != null:
		var new_loc = GM.world.applyDirectionID(GM.pc.getLocation(), direction)
		if new_loc:
			GM.pc.setLocation(new_loc)
			aimCameraAndSetLocName(new_loc)

func _react(_action: String, _args):
	if _action == "randomScene2":
		processTime(5*60)
		moveRandomly()

	if _action == "endthescene":
		endScene([])
		return

	setState(_action)


func saveData():
	var data = .saveData()

	return data

func loadData(data):
	.loadData(data)

