extends SceneBase

var found_strapon = false
var pawns_interactions = null 

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "UnconciousPetRandom"

func _initScene(_args = []):
	GlobalRegistry.getCharacter("hiisi").addConsciousness(-1.0)

func _run():
	if(state == ""):
		saynn("When walking in between the cells you spot colors near the ground that shouldn't be there, it's a relatively obscure and hidden from plain sight place, but you've seen it in the past and instead of boring old flooring there is clearly something or someone laying there.")
		saynn("Curious, you stop in your tracks and take a step back to find out just what kind of oddity is happening in the prison this time. You recognize the design of prisoner uniform, it's visibly frayed and in bad shape, though red stripe across it is immediately visible. With still half of your vision obscured by the wall all you can tell is that the prisoner uniform does have its wearer underneath, it's not flat by any means, it's on someone.")
		addButton("Move closer", "Investigate (CW: mention of sexual assault)", "closer")
		addButton("Leave", "Not your problem", "endthescene")
		
	if state == "closer":
		addCharacter("hiisi")
		saynn("You come closer, seeing more and more as you approach. Revealing a canine shape in lying position, they don't appear to be moving, in fact, they look as if they are sleeping.")
		saynn("While approaching you notice that you know this fur color and well defined posture, it's Hiisi! Issix's pet.")
		saynn("But you get the immediate feeling something isn't right, it isn't regular for Hiisi to be out here alone laying on the ground.")
		
		saynn("[say=pc]Hiisi?[/say]")
		
		saynn("At this point you see the entirety of Hiisi's laying body. It's in such a position that wouldn't be comfortable to sleep in , in addition, his uniform is displaced - pants are missing from his bottom and as you change the viewing angle you notice matted fur around his butt, a fluid - no - cum disgracing canine's body, some still visibly leaking from his anus.")
		
		saynn("[say=pc]Fuck.[/say]")
		
		saynn("A scene is painted in your mind, unpleasant conclusion to what you see in front. Someone used Hiisi for their own pleasure, knocked out he shouldn't be much of a threat, regardless of his physical prowess. He still doesn't contact with the world outside, and you don't know whether the abuse left any serious and long-term consequences to his body.")
		
		addButton("Take advantage", "A horny thought appears in your mind - you could take advantage of canine's vulnerable position, he doesn't seem capable of waking up yet and the place is secluded enough you don't expect to get spotted by anyone for some time (CW: non-con)", "rape_start")
		addButton("Help", "Seek help for the canine, find Issix", "help_hiisi")
		addButton("Ignore", "It might be easier to just leave him there and pretend nothing happened, if someone sees you here they might think you had something to do with it", "ignore_situation")
		
	if state == "rape_start":
		# playAnimation(StageScene.SexMissionary, "sex", {pc="pc", npc="hiisi", bodyState={naked=true, hard=true}, npcBodyState={naked=true, hard=true}})
		
		playAnimation(StageScene.SexBehind, "tease", {pc="pc", npc="hiisi", bodyState={naked=true}, npcBodyState={naked=true}})  # Male on Hiisi inside/sex/fast
		# elif GM.pc.hasReachableVagina():
		# 	playAnimation(StageScene.SexCowgirl, "sex", {pc="hiisi", npc="pc", bodyState={naked=true}, npcBodyState={naked=true}})  # girl on Hiisi inside/sex/tease

		saynn("You happily give in to your impulse, swiftly taking your place in secluded place, making sure that whatever you are about to do is done in as much of secrecy that this place can offer you. There is still a significant risk involved here, regardless of what you do, you can't possibly hide completely from view of hallway, the only privacy afforded to you by thin layer of wall and some odd decorations hanging from it. Hiisi's being Issix's guard dog, you can't imagine the imposing dragon being particularly enthusiastic about (ab)using his property, but he doesn't need to know.")
		
		saynn("Hoping to make a quick job of it, you pull Hiisi's uniform off completely and move his body towards more comfortable for you position, deciding to lay him on his front. You double check he is still out of it.")
		if found_strapon:
			saynn("[say=pc]Now to just...[/say]")
			saynn("You look around the place hoping to find something to use. Luck struck it, it seems previous assailants have left something you can use, still warm and wet from last use, however this doesn't bother you much. You grab the found strapon and equip it.")
		elif !GM.pc.hasReachablePenis():
			saynn("You think how to use the dog for your own pleasure for a short moment, quickly deciding to use one of your strapons you have on yourself after seeing used one laying just nearby, likely left alone by previous assailants.")
			saynn("You equip your "+GM.pc.getWornStrapon().getVisibleName())
			
		saynn("[say=pc]Good dog, let's finish this before someone notices.[/say]")
		addButton("Continue", "", "rape2")
		
	if state == "rape2":
		playAnimation(StageScene.SexBehind, "tease", {pc="pc", npc="hiisi", bodyState={naked=true}, npcBodyState={naked=true}})
		
		saynn("You feel a mix of hormone induced lust with anxiety. Wile the former doesn't need to be explained, latter come sfrom the feeling that you need to constantly be on the guard. Every noise coming from behind the not-fully-protective wall makes you look in that direction just to make sure that whatever is going on there, is not some curious creature taking a peek at your lusty fuck.")
		saynn("This is to ignore the fact that the mind is questioning itself why exactly you are putting yourself in this situation. Is it really just a simple fulfillment of lustful urges or is it subconsciously a way to get back at Issix or Hiisi because you hate their guts? Issix looks like a privileged runt, fully confident in himself, thinking he has everything under control. And yet, yet you are right in this situation, grinding on his property, without his permission. As much as you've had the displeasure to talk to him, his attitude was always so dominating, he is always so full of himself.")
		saynn("At the back of your head there is almost a thought that you'd like him to see you. That you'd like him to admire YOU using HIS own pet, HIS property like a common whore. A forbidden fruit. Something you shouldn't have and yet...")
		
		saynn("A nudge of Hiisi's leg wakes you up from your stupor. You immediately try to assess the situation, but quickly realize it simply changed position due to your own grinding which you've been doing with your {pc.penisStraponShort} on {hiisi.name}'s butt for at least a minute, thinking of how your fuck may be a hate fuck.")
		
		saynn("[say=pc]Gave me a scare, pup. And what do you think about it?[/say]")
		saynn("But he doesn't respond.")
		saynn("[say=pc]Yeah, thought so. Fuck, you don't even need lubing, do you? You are pretty slick from all that cum inside already. Fuck.[/say]")
		saynn("There is no time to waste, you think.")
		addButton("Enter him", "Enter the canine with your prick", "rape3")
		
	if state == "rape3":
		playAnimation(StageScene.SexBehind, "sex", {pc="pc", npc="hiisi", bodyState={naked=true}, npcBodyState={naked=true}})
		saynn("After your prolonged warmup, you reposition Hiisi's body slightly to make your next activity a bit easier. Soon after, your {pc.penisStraponShort} enters Hiisi's abused hole without much of an issue, you don't have any doubts that his Master uses the hole regularly.")
		
		saynn("[say=pc]Fuck. Waste of a hole to leave it for use for only one man I say.[/say]")
		
		saynn("Your lust focused on penetrating Hiisi's hole, your arms keeping him in place below you, as you keep pushing with little care for his wellbeing. He can't complain about his position either, right now YOU are his Master. He is your toy to play with, a silent one.")
			
		saynn("[say=pc]I wonder, whether you'll stay being the guard dog for your dragon Master after this one, looks like someone already put you in place before me.[/say]")
		
		saynn("In wave of lust you grab him by his orange hair, close your own eyes and raise your head.")
		
		saynn("[say=pc]Gooood dog. I'm close already. You are a fun toy hehe.[/say]")
		saynn("Your thrusts become more aggressive, as you basically push your entire tool in the dog laying below you in full.")
		saynn("[say=pc]If- uff, you heard me, I- I'd tell you to f- fucking howl for me when I c- cum inside of YOUU![/say]")
		addButton("Cum", "Achieve orgasm", "rape4")
		
	if state == "rape4":
		playAnimation(StageScene.Solo, "stand", {pc="pc"})

		if GM.pc.getBodypartID(BodypartSlot.Penis) == "caninepenis" and not GM.pc.isWearingStrapon():
			saynn("Right before your moment you become sober enough to remember not to pull your entire knot in the canine as you do not want to tie with him, this is, after all, supposed to be a quick load dump before anyone notices. You put only half of your member into the canine before you erupt to fill his hot insides with your own cum.")
			
		elif GM.pc.isWearingStrapon() and GM.pc.isWearingLoadedStrapon():
			saynn("You push your entire member inside the canine in the last moment, pleasure reaching its apex. You spray Hiisi's insides with sticky matter that was inside, feeling your own body ejaculating multiple times in heat of a moment.")
		elif GM.pc.isWearingStrapon():
			saynn("You push your entire member inside the canine in the last moment, pleasure reaching its apex. You orgasm.")
		else:
			
			saynn("You push your entire member inside the canine in the last moment, pleasure reaching its apex. You spray Hiisi's insides with sticky matter of your own making, feeling your body ejaculating multiple times in heat of a moment.")
			
		saynn("[say=pc]Yesss, get a load of this.[/say]")
		saynn("Right after the climax high ends, you detach from Hiisi and leave his unmoving body where it is, not bothering to put his uniform back on"+", you do however, put on your own clothes back on so to not stand out too much" if !GM.pc.isFullyNaked() else ""+".")
		if found_strapon:
			saynn("You decide to trash the found strapon in the nearby trash bin too, no need to hold or leave any evidence.")
		elif GM.pc.isWearingStrapon():
			saynn("You unequip your strapon and hide it on yourself.")
		else:
			saynn("You clean yourself including your {pc.penis}.")
			
		saynn("Taking last look at the place and canine to make sure you are not leaving any evidence of wrongdoing, you leave the place squeezing through the wall that served well as your protector from curious eyes.")
		addButton("Bail out", "Leave this place", "run_rape")
			
	if state == "run_rape":
		saynn("After slinking back to the hallway you simply try to merge into day-to-day prison life as if nothing had happened. At the end of the day, this prison is filled with fucking and fighting, so you didn't do anything special, really... Unless you count the fact that the fucked was a pet of powerful prisoner who could ruin lives of those inside of the prison. Your blood rushes just a little bit faster thinking of this, quickly comforted by the feeling that you don't believe anyone [i]seen you[/i] do anything. It must have been a perfect „crime”, no way anyone saw you.")
		
		saynn("While minding your business, a conversation slips into your ears...")
		saynn("[sayMale]Someone is apparently raising hell over their missing pet in the other part of the prison.[/say]")
		saynn("[sayFemale]Really? Pets are pretty rare, I feel kind of bad for the owner.[/say]")
		saynn("[sayOther]True. This one was Issix's, one's that is on the corner of main hall, you know, on side of the laundry machine.[/say]")
		saynn("[sayMale]Issix's? Ouch. Hopefully they just got lost or something, if someone did something to their pet this prison might not have enough guards to contain the incoming war.[/say]")
		saynn("[sayFemale]You really think someone would hurt their pet? That's like signing their life away.[/say]")
		saynn("[sayOther]Well, maybe? They do have some enemies, you know.[/say]")
		saynn("[sayFemale]Sure, but you've heard the stories what happens with those who cross Him.[/say]")
		saynn("[sayMale]I've heard of those second day I came here, guy is dangerous, personally I tend to stay away as far as possible from them. Don't care if he is normally fine, I wouldn't ever want to come up on his radar.[/say]")
		saynn("[sayOther]Yeah, true. Though I did have sex with his pet once, Azazel..[/say]")
		saynn("The voices became quieter as the couple walked away from you. It seems like Hiisi's disappearance hasn't gone unnoticed. Better get away from here ASAP.")
		addButton("Walk", "Walk away", "endthescene")
		
	if state == "help_hiisi":
		aimCameraAndSetLocName("hall_ne_corner")
		saynn("You immediately get really close to Hiisi, putting paw fingers on his arm. The pulse is there, that's good. He definitely breathes, but doesn't respond to you at all. At this time it's clear to you that you'll have to ask for help in this situation. Leaving the mostly hidden recess in the wall in a hurry you move towards Issix's corner. When you arrive they aren't there, the blankets empty, the chair unoccupied, the sight almost uncanny.")
		saynn("[say=pc]Hey, uhh, have you seen Issix anywhere? Did they move?[/say]")
		saynn("[sayMale]The dragon right? No, I've only just arrived here.[/say]")
		saynn("A short feline nearby responds, while another voice from behind you appears.")
		saynn("[sayOther]I've seen the commotion, they went towards elevator, but it was solid 10 minutes ago.[/say]")
		saynn("[say=pc]Ahh, no idea where they went?[/say]")
		saynn("[sayOther]If I had to guess from the conversation to the medical but hells if I know.[/say]")
		saynn("[say=pc]Alright, thank you two.[/say]")
		saynn("With sense of new direction perhaps it would make more sense to follow them there, maybe they are still looking for him there, and if not, it would still make sense for you to notify the nurses about the situation.")
		addButton("To medical", "Take a new direction", "move_to_help")
		
	if state == "move_to_help":
		addCharacter("issix")
		addCharacter("lamia")
		addCharacter("azazel")
		addCharacter("eliza")
		addCharacter(pawns_interactions[0])
		saynn("In a quick pace that could only be described by a mix of run and a jog, you pass by the stairs to the cells below and you were just to turn left when in front of your eyes an uncommon sight appears - a cordon made out of two leashed inmates led by Issix in the very front of entire column. Behind those three, Eliza and one nurse. Clearly in a hurry, but not running. The nurse is dragging a stretcher in front.")
		saynn("[say=pc]Issix! Issix![/say]")
		saynn("Dragon gives you a look, his face a mix of anger and worry - furrowed eyebrows, animated black eyes, even though you could swear they are full of flames, just seeing them send you a chill, scowl on his face, and the body language sending a clear signal to everyone around that Issix is in fight-or-flight mode, though the only one flying would be anyone daring to stand in his way. Right when he looks at you, it's as if the anger was entirely directed at you. In all other situations you'd freeze in place and obey, but there is no time to waste here.")
		saynn("[say=pc]I know- where Hiisi is![/say]")
		saynn("[say=issix]No time.[/say]")
		saynn("His sight moves away from you as he continues the jog wasting no more words.")
		saynn("[say=azazel]Thanks {pc.name}, we know too, going there now.[/say]")
		saynn("A feline responded in a hurry as they followed their Master, medical staff behind them.")
		saynn("It appears all of them are well informed of Hiisi's position, that does give you some questions about the entire situation but you also feel somewhat relieved to hear that. The faster the help arrives the better.")
		addButton("Leave", "You are sure things are going to go well with Issix and medical staff on the way to Hiisi, they do seem to be following in good direction", "endthescene")
		
	if state == "ignore_situation":
		saynn("You don't feel like it's your responsibility to keep everyone safe and sound in here, it's a goddamn jungle in here, each needs to tend to themselves. Besides, putting your nose everywhere will only lead to get you into trouble.")
		saynn("You justify your decision further and further. While there might have been a thought creeping in, that maybe you didn't make the right choice, at least its kept at bay by your justification of this being a cruel place. This was the safest decision for you, and that's all that matters.")
		addButton("Leave", "Leave this place", "endthescene")
		
		
		
func saveData():
	var data = .saveData()

	data["found_strapon"] = found_strapon
	data["pawns_interactions"] = pawns_interactions

	return data

func loadData(data):
	.loadData(data)

	found_strapon = SAVE.loadVar(data, "found_strapon", false)
	pawns_interactions = SAVE.loadVar(data, "pawns_interactions", null)

func getDevCommentary():
	return "This one can get very dark. For those random scenes I were looking for ideas that would unequivocally be awful from Player's point of view, making them pretty clearly evil. I assume the player doesn't know where the options lead, so I want to give them choice to make terrible decision multiple times before they are locked into something they might not have liked. And if someone decides that rape is appropriate action for their character, then they better get ready for the consequences. Of course, outside of fiction this is absolutely abhorrent behavior and I feel the need to mention that there is no condoning from myself for such actions, only disdain and anger."

func hasDevCommentary():
	return true
	
# func resolveCustomCharacterName(_charID):
# 	if _charID.begins_with("pawn"):
# 		var chara = pawns_interactions[int(_charID[-1])-1]
# 		if chara == null:
# 			return "sayMale"


func _react(_action: String, _args):
	if _action == "closer":
		# TODO make butt cummy
		GM.pc.addLust(10)

	if _action == "rape_start":
		pawns_interactions = Globals.pick_unique_one(Globals.findPawns([[["isInmate"], []]]))
		if !GM.pc.hasReachablePenis():
			var strapons = GM.pc.getStrapons()
			if strapons.empty():
				found_strapon = true
				strapons = [GlobalRegistry.createItem("StraponFeline")]
				GM.pc.cummedOnBy(pawns_interactions[0] if pawns_interactions[0] != null else "rush", null, 0.1)
				GlobalRegistry.getCharacter("hiisi").cummedOnBy(pawns_interactions[0] if pawns_interactions[0] != null else "rush", null, 0.1)
			GM.pc.getInventory().equipItem(RNG.pick(strapons))
			addMessage("You equipped a strapon.")
		setModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 1)
		increaseModuleFlag("IssixModule", "Issix_Anger_Noncon", 4)
		
	if _action == "help_hiisi":
		setModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 2)
		increaseModuleFlag("IssixModule", "Issix_Anger_Noncon", -2)
		
	if _action == "ignore_situation":
		setModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 3)
			
	if _action == "rape2":
		GM.pc.addLust(50)
		
	if _action == "rape3":
		GM.pc.addLust(30)
		
	if _action == "rape4":
		GM.pc.addLust(-150)
		
	if _action == "move_to_help":
		pawns_interactions = Globals.pick_unique_one(Globals.findPawns([[["isNurse"], []]]))
		if pawns_interactions[0] == null:
			pawns_interactions[0] = ""
		
	if _action == "run_rape":
		GlobalRegistry.getCharacter("hiisi").cummedInAnusBy("pc")
		if found_strapon:
			GM.pc.removeStrapon()
		elif GM.pc.isWearingStrapon():
			GM.pc.unequipStrapon()

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 3)
		setModuleFlag("IssixModule", "Quest_Wait_Another_Day", true)

		GlobalRegistry.getCharacter("hiisi").addConsciousness(1.0)
		endScene()
		return

	setState(_action)
