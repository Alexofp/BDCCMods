extends SceneBase

func _init():
	sceneID = "GrabChemicals"

func _run():
	if state == "":
		saynn("You look for the chemicals that will allow you to destroy Issix mentioned by the horse and human couple. You quickly locate the drawer with failed experiments, you go through various drugs there, all of them labeled something. Fuck, what was the name of the drug?")
		addButton("81'm'80", "Pick up the drug with label of „81'm'80”", "pick_up", ["81'm'80"])
		addButton("NULLX", "Pick up the drug with label of „NULLX”", "pick_up", ["NULLX"])
		addButton("8R006'm'0TH34", "Pick up the drug with label of „8R006'm'0TH34”", "pick_up", ["8R006'm'0TH34"])
		addButton("H1'm'80", "Pick up the drug with label of „H1'm'80”", "pick_up", ["H1'm'80"])
		
	if state == "pick_up":
		saynn("You've picked up "+getModuleFlag("IssixModule", "Chemicals_Chosen")+" and stashed it.")
		addMessage("You've picked up the chemicals, quest has been updated.")
		addButton("Leave", "Leave before you are spotted", "endthescene")
		

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false

func _react(_action: String, _args):
	if _action == "pick_up":
		setModuleFlag("IssixModule", "Chemicals_Chosen", _args[0])
	
	if(_action == "endthescene"):
		increaseModuleFlag("IssixModule", "Random_Encounter_Scene", 2)
		endScene()
		return

	setState(_action)
