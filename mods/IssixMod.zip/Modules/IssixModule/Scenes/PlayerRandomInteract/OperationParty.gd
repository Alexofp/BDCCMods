extends SceneBase

var asked = {}
var wants_issix = false

# Start scene 3 days after first meet if player didn't start the quest
func _init():
	sceneID = "IssixGettingRidOf"

func resolveCustomCharacterName(_charID):
	if(_charID == "pawn1"):
		return "rowan"
	elif _charID == "pawn2":
		return "loxia"

func _run():
	asked[state] = true
	
	if(state == ""):
		addCharacter("rowan")
		addCharacter("loxia")
		saynn("You've arrived at marked location, the timing is right as well. You look around for someone who'd know more about the invitation you've gotten in your cell. At first everyone around seems to be in their perfectly normal BDCC prisoner behavior, however after spending a little more time being wary of your surroundings you notice two inmates giving you many glances. Both of them appear to have different mood, or maybe just different face expressions. One - "+Util.getSpeciesName(pawn1().getSpecies()) + " is looking at you with a stern look, the other one "+Util.getSpeciesName(pawn2().getSpecies()) + " - complete opposite, complete chill out, a smirk, if not lust. Both of them look pretty well built.")
		saynn("A minute later their talk seems to cease as they move towards you.")
		
		saynn("[say=pawn1]{pc.Name}, correct?[/say]")
		saynn("[say=pc]Yes...[/say]")
		saynn("[say=pawn2]Just look at {pc.him}, {pawn1.Name}! Such a {pc.thick} ass![/say]")
		saynn("[say=pawn1]{pawn2.Name}, just shut up! {pc.Name}, so we were not wrong about you. You really do have an issue with certain dragon fuck who thinks {issix.he} is the boss of the entire world. Correct?[/say]")
		saynn("[say=pawn2]A dragon fuck {issix.he} is![/say]")
		saynn("Unfazed by {pawn1.name} comment, {pawn2.name} compliments the sentence.")
		addButton("Sure", "That's true", "agree")
		addButton("No", "Issix does not bother you", "disagree")
		
	if state == "disagree":
		saynn("[say=pc]No, not really. I don't have an issue with the dragon.[/say]")
		saynn("[say=pawn1]... You don't?[/say]")
		saynn("[say=pawn2]Uuuuu![/say]")
		saynn("[say=pawn1]We were under impression you hate {issix.him}.[/say]")
		saynn("You reiterate that you don't.")
		saynn("[say=pawn2]Not even a sliver, a tiny seed of hatred for Issix?[/say]")
		saynn("[say=pawn1]Do you maybe hate {issix.his} pets?[/say]")
		saynn("[say=pawn2]Yeah! What about {issix.his} pets?[/say]")
		addButton("Hate 'em", "Say that you do hate the pets", "hate_pets")
		addButton("Don't", "Say that you do don't hate the pets", "not_hate_pets")
		
	if state == "hate_pets":
		saynn("[say=pc]The pets I do despise.[/say]")
		saynn("[say=pawn1]Here we go! Something at least. Listen, we have a deal for you then. We get rid of Issix, pets go with {issix.him}. Simple, right?[/say]")
		saynn("[say=pawn2]Simple, hehe.[/say]")
		createButtons()
		
	if state == "not_hate_pets":
		saynn("[say=pc]Don't care about them either.[/say]")
		saynn("Both of them go silent for a bit.")
		saynn("[say=pawn1]You sure?[/say]")
		if getModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 0) == 1:
			saynn("[say=pawn2]So the thing in the cellblock wasn't a hate fuck? You were just an opportunist?[/say]")
			saynn("[say=pc]How do you kn-[/say]")
			saynn("[say=pawn2]Give us some credit, we know shit![/say]")
			saynn("[say=pc]No, it was not a hate fuck.[/say]")
		saynn("[say=pawn2]Interesting...[/say]")
		saynn("[say=pawn1]That was a waste. Sorry for bothering you then. We have no business with you, come back if you ever change your view on Issix.[/say]")
		saynn("[say=pc]What was it about anyways?[/say]")
		saynn("[say=pawn1]Doesn't matter. Let's go to bed, it's getting late.[/say]")
		saynn("[say=pawn2]Yaaay! Bed![/say]")
		saynn("The two simply go towards the cells.")
		addButton("Leave", "You should leave too", "endthescene")
	
	if state == "agree":
		saynn("[say=pc]Maybe, can you explain what it's all about?[/say]")
		saynn("[say=pawn2]It's about {issix.him}![/say]")
		saynn("[say=pawn1]Both of us fucking hate that cunt, we've been doing reconnaissance of who could help us take {issix.him} down, during that we've learned of you and got a tip you might want to join our cause.[/say]")
		saynn("[say=pawn1]But we need someone committed if we want to work together. You in or not?[/say]")
		createButtons()
		
	if state == "whyissix":
		saynn("[say=pc]But why Issix? What did {issix.he} do to you that you want to „take {issix.him} down”?[/say]")
		saynn("[say=pawn1]{issix.He} is an arrogant bastard, simple as that.[/say]")
		saynn("[say=pawn2]It's because {issix.he} has taken Azazel from {pawn1.Name}![/say]")
		if "pets" in asked:
			saynn("[say=pc]Didn't {pawn1.Name} not care about what happens with pets after we do all of this?[/say]")
			saynn("[say=pawn1]Uhhmm, of course I do care about feline. I don't think he can be saved but... I'll have him after all is said and done.[/say]")
			saynn("[say=pawn1]Yeah...[/say]")
		else:
			saynn("You look quizzically at both of them, {pawn1.name} for a split moment looks distraught before {pawn1.he} responds.")
			saynn("[say=pawn1]Yeah. That's right.[/say]")
			saynn("[say=pc]Taken?[/say]")
			saynn("[say=pawn2]Yeah! Like, the feline was {pawn1.name}'s![/say]")
			saynn("[say=pc]Like a slave or...[/say]")
			saynn("[say=pawn2]No! Like a, you know, lover![/say]")
			saynn("[say=pc]In prison or like before the prison? And what's in it for you {pawn2.name}?[/say]")
			saynn("[say=pawn2]In prison you silly. As for me, I just share the resentment of my buddy {pawn1.name}, right? There is enough of hatred radiating off {pawn1.him} to be enough for both of us![/say]")
			
			saynn("{pawn2.He} laughs, clearly not taking the conversation as seriously as {pawn1.name} who continues to have extremely serious face expression.")
			saynn("[say=pc]Okey, I guess...[/say]")
		createButtons()
		
	if state == "whyme":
		saynn("[say=pc]So where do I come in with all of this?[/say]")
		saynn("[say=pawn1]Issix isn't a sex toy, {issix.he} can throw punches and has enough resources to wipe us all out. The only way to take {issix.him} down is to group up.[/say]")
		saynn("[say=pawn2]Yup! More heads that come in to help fight the good fight the better![/say]")
		saynn("[say=pc]I guess it does make sense, but then, why me? How do you know my name?[/say]")
		saynn("[say=pawn1]Your name? We...[/say]")
		saynn("{pawn1.He} pauses, as if to recall something.")
		saynn("[say=pawn2]Oh, we just overheard it after your little incident with that stinking canine.[/say]")
		saynn("[say=pc]Wait, what incident? How do you-[/say]")
		saynn("[say=pawn2]Reconnaissance, remember? We have eyeeesssss.[/say]")
		saynn("{pawn2.He} looks through the hole made with fingers that form ok sign, as if imitating some kind of binoculars. That's odd, you were sure nobody saw your deed with Hiisi.")
		createButtons()
		
	if state == "plan":
		saynn("[say=pc]Okey, sure, but do you have any plan? {issix.He} is powerful, and I'm sure if {issix.he} wanted {issix.he} could disappear us from here at moment's notice.[/say]")
		saynn("[say=pawn1]Okey, I don't know where you've got that impression from, but that's obviously false, {issix.he} is not THAT powerful. Sure, {issix.he} has contacts, slaves and probably someone on the inside in the guards but doesn't make {issix.him} invincible, does it?[/say]")
		saynn("[say=pawn2]And we do have a plan![/say]")
		saynn("[say=pawn1]And we do have a plan. We will lure him in deep in the prison, use sleeping gas to put {issix.him} to sleep and dispose of the pest. Don't worry, we will do the heavy lifting and drug the devil, you find us necessary items and make sure {issix.he} disappears.[/say]")
		saynn("[say=pc]You sure both of you can handle putting {issix.him} to sleep? It's a god damn devil, a very strong one at that.[/say]")
		saynn("[say=pawn2]Pfff, funny, of course we can! You have nothing to worry, once {issix.he} smells the funny gas it can take even the biggest asshole in the universe. That's how well they make this sleep gas.[/say]")
		saynn("[say=pc]Well, okey, you two drug the cunt, what then?[/say]")
		saynn("[say=pawn1]Then you turn {issix.him} into a stupid hunk of meat by providing them with some hard chemistry, don't worry, we have plan for that as well. If {issix.he} forgets who {issix.he} is, if we change {issix.him} into a bitch {issix.he} will no longer be a threat to anyone.[/say]")
		saynn("[say=pc]You are sure that will work? And how do we get all of that? Why do you need me?[/say]")
		saynn("[say=pawn2]It must work![/say]")
		saynn("[say=pawn1]No worries about materials, we know where to find the gas and chemicals. We need you to finish {issix.him}, both of us will make sure that until you are done, nobody will enter the room you are in and kill entire operation. Your role is crucial.[/say]")
		saynn("[say=pc]How will I even know what to do?[/say]")
		saynn("[say=pawn1]It will be easy, don't worry.[/say]")
		
		createButtons()
		
	if state == "pets":
		saynn("[say=pc]And what becomes of pets after all of this is done?[/say]")
		if wants_issix:
			saynn("[say=pawn1]Oh, I don't know. Maybe they will finally have to learn how to live off their own. I don't really care.[/say]")
			if "whyissix" in asked:
				saynn("[say=pc]Wouldn't you want to get the feline back?[/say]")
				saynn("{pawn1.Name} looks at you confused for a second before realizing something.")
				saynn("[say=pawn1]Yeah, I call dibs on Azazel, don't care about the rest. That's what I meant.[/say]")

			saynn("[say=pawn2]Maybe you want to pamper these animals? Though they might bite! Chomp chomp![/say]")
			saynn("[say=pawn1]I think Issix has them brainwashed well enough to only answer to {issix.him} though, wouldn't count on taking ownership of the harem.[/say]")
		else:
			saynn("[say=pawn1]If you don't like them then we can get rid of them, well, except Azazel I guess, I'll take him.[/say]")
			saynn("[say=pawn2]Yeah, we just do something with them so they are no longer here![/say]")
			
		createButtons()
		
	if state == "agree_to_crime":
		saynn("[say=pc]Okey, consider I'm in. What do we do next?[/say]")
		saynn("[say=pawn1]Wonderful. We need to get the sleeping gas and required pills to fry {issix.his} brain. We are sure you can fetch them yourself, can you? We know where they are, you can probably guess too - medical wing. More precisely medical storage should have them. It's fairly new product that this prison is now a client for, there are two large canisters, we only need one. When you are at it, do take the mask as well, it will be a lot easier for us. All of those should be in the storage.[/say]")
		saynn("[say=pawn2]Don't forget about the pills![/say]")
		saynn("[say=pawn1]I were getting to it {pawn1.Name}! ... The pills should be in the Research Lab, you'll be looking for rejected experiments, they are in separate drawer that is less protected than the other drawers. Should be the Experiment Number. [b]81'm'80[/b].[/say]")
		saynn("[say=pawn2]That's not even a number![/say]")
		saynn("[say=pawn1]Tell that to the eggheads. Anyways. We'll be here again same time tomorrow. Bring both things, don't get caught. When you are ready we'll all go.[/say]")
		saynn("[say=pc]Where will you lure {issix.him} in?[/say]")
		saynn("[say=pawn1]We'll fill you in with the details when we meet again. There is still something we need to check. Now go, we don't need to gather attention.[/say]")
		
		saynn("You leave, new task in mind.")
		
		addButton("Leave", "", "endthescene")
		
	if state == "bad_idea":
		saynn("[say=pc]To heck with that, I'm not participating in this. That's too dangerous, likely won't work and you two are fishy as fuck.[/say]")
		saynn("[say=pawn1]Oh we are fishy, huh? We want to finish this asshole for good, it's clear you want it too. So why are you such a pussy? Pissing your pants already?[/say]")
		saynn("[say=pc]I don't care, I'm out.[/say]")
		saynn("[say=pawn2]Wait, wait, wait. {pc.name}, think about it. We have an opportunity to deal with this prison's biggest asshole. They are powerful, yes, that's why we need a plan and helpers, no one can take {issix.him} down alone. You don't like our plan? Let's change it here and there if it makes you feel better, but both you and we need it.[/say]")
		saynn("[say=pc]Even if the plan is changed, this doesn't make you two any less fishy, I haven't seen you before,[/say]")
		saynn("[say=pawn2]And who can you trust in a place like this? You are taking a gamble, sure, but what if it's the right one? Are you gonna just let it pass?[/say]")
		
		saynn("There is awkward silence there for a moment as you think it over.")
		addButton("Fine", "Agree to join their efforts", "good_to_go")
		addButton("Nope", "That's still a no, let them find another idiot", "leave")
		
	if state == "good_to_go":
		saynn("[say=pc]... Okey. But we do it my way. No changing him, we kill the bastard, leave as little trace as we can, best if we dump them outside the station into the space, no shitty chemicals, quick and easy murder.[/say]")
		saynn("[say=pawn1]Wait that-[/say]")
		saynn("[say=pawn2]Sounds good to me.[/say]")
		saynn("[say=pc]Good. I'll go fetch the sleeping gas then.[/say]")
		saynn("[say=pawn2]Shake on it?[/say]")
		saynn("{pawn2.Name} extends {pawn2.his} paw to you. You shake on it, {pawn1.Name} simply looks at you two without saying anything.")
		saynn("[say=pawn2]See you tomorrow then. Good luck on your mission.[/say]")
		saynn("[say=pc]Thanks...[/say]")
		addButton("Leave", "Leave the place", "endthescene")
		
	if state == "leave":
		saynn("[say=pc]Nope, I'm out of here. Good luck, if you are really trying to do what you are saying you do.[/say]")
		saynn("[say=pawn2]Your choice, but don't blame us if {issix.he} ever comes back at you for what you've done, you'll be all alone and helpless. Turned into just another fucktoy.[/say]")
		saynn("You go away, showing both of them middle finger as you go. And that was all of it.")
		addButton("Leave", "", "endthescene")

	
func createButtons():
	if !("whyissix" in asked):
		addButton("Why?", "Why they want to mess with Issix?", "whyissix")
	else:
		addDisabledButton("Why?", "")
	if !("whyme" in asked):
		addButton("Why you?", "Why do they need you and how do they even know you?", "whyme")
	else:
		addDisabledButton("Why you?", "")
	if !("plan" in asked):
		addButton("Plan", "Do they have some sort of a plan? What to do?", "plan")
	else:
		addDisabledButton("Plan", "")
	if !("pets" in asked):
		addButton("Pets", "Ask about the pets, what becomes of them once Master is gone", "pets")
	else:
		addDisabledButton("Pets", "")
		
	if asked.size() < 4:
		addDisabledButton("Agree", "Should probably ask some questions first")
		addDisabledButton("Not in", "Should probably ask some questions first")
	else:
		addButton("Agree", "Respond you want to be a part of this (continue quest, CW: non-con)", "agree_to_crime")
		addButton("Not in", "This is way too off, you are not going to participate (abandon quest)", "bad_idea")
	
func pawn1() -> BaseCharacter:
	return GlobalRegistry.getCharacter("rowan")
	
func pawn2() -> BaseCharacter:
	return GlobalRegistry.getCharacter("loxia")

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false
	
func saveData():
	var data = .saveData()

	data["wants_issix"] = wants_issix

	return data

func loadData(data):
	.loadData(data)

	wants_issix = SAVE.loadVar(data, "wants_issix", false)


func _react(_action: String, _args):
	processTime(RNG.randi_range(2, 5) * 60)
	if _action in "agree_to_crime":
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 6)
		
	if _action == "good_to_go":
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 7)
		
	if _action == "agree":
		wants_issix = true
		
	if _action == "leave":
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 100)

	if(_action == "endthescene"):
		
		endScene()
		return

	setState(_action)
