extends SceneBase

func _init():
	sceneID = "GrabSleepingGas"

func _run():
	if state == "":
		saynn("You look for the sleeping gas canisters mentioned by the horse and human couple, you do find the medical mask, but no gas canisters in sight, even though you are frantically looking everywhere. Just after you have given up and were looking to go back before you are caught you notice two canisters just as mentioned right next to the exit from the room. Frustrating but you've got what you needed, it's time to bail.")
		addMessage("You've picked up the sleeping gas and secured it, quest has been updated.")
		addButton("Leave", "", "endthescene")


func getDevCommentary():
	return ""

func hasDevCommentary():
	return false

func _react(_action: String, _args):
	if(_action == "endthescene"):
		increaseModuleFlag("IssixModule", "Random_Encounter_Scene", 5)
		endScene()
		return

	setState(_action)
