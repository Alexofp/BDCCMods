extends SceneBase

var pawnID := ""

# Start scene 3 days after first meet if player didn't start the quest
func _init():
	sceneID = "AzazelCatchUpWith"

func _initScene(_args = []):
	pawnID = _args[0]
	if pawnID == null:
		endScene()
		return
	GM.main.IS.getPawn(pawnID).setLocation(GM.pc.getLocation())

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return pawnID

func _run():
	if(state == ""):
		addCharacter("azazel")
		addCharacter(pawnID)
		playAnimation(StageScene.Duo, "stand", {pc="azazel", npc=pawnID})
		saynn("While walking around the prison you overhear a voice you are familiar with.")
		saynn("[say=azazel]Heey there {npc.name}! What's up? Treating yourself fine?[/say]")
		saynn("[say=npc]More or less, how about you, Az?[/say]")
		saynn("[say=azazel]Oh, you know me. Been doing fine. Not much going on lately.[/say]")
		if getModuleFlag("IssixModule", "Azazel_Affection_given", 0) > 1:
			saynn("[say=azazel]Though I do have my eyes set on a new catch...[/say]")
		else:
			saynn("[say=azazel]Same old and everything is rather boring.[/say]")
		
		saynn("It could be rude to eardrop on their private conversation like that, though You could learn something new.")
		addButton("Listen in", "Continue to eardrop on this conversation", "continue_listening")
		addButton("Leave", "You are not up to continue listening", "endthescene")
			
	if state == "continue_listening":
		if getModuleFlag("IssixModule", "Azazel_Affection_given", 0) > 1:
			saynn("[say=npc]Oh shit, do tell, what's the name of the unlucky pray of kitty corruptor in front of me?[/say]")
			saynn("[say=azazel]Haha, oh you. Fancy nickname you got for me, but yeah, that probably fits. And it's {pc.name}.[/say]")
			saynn("[say=npc]{pc.name}? Hah, it does sound like they are in for hell of a ride. What will it be this time Az? I bet you are already plotting something mischievous for them. Witchcraft? Food? What's the key to their heart? And are they a chick or dude? You know, if it's the former...[/say]")
			saynn("[say=azazel]Nyaaaah! Too many questions at the same time![/say]")
			saynn("[say=npc]Right, sorry. So, what's your plan?[/say]")
			saynn("[say=azazel]I have drive to go for some drugs this time. Call it a classic, but I think they will work best on {pc.him}.[/say]")
			saynn("[say=npc]Really? Just don't overdo that, you know? Playing is fun, but don't lose it.[/say]")
			if GM.pc.getGender() == Gender.Female:
				saynn("[say=npc]And you know, if she would want to meet me...[/say]")
				saynn("[say=azazel]Pffff, she wouldn't![/say]")
				saynn("[say=npc]You never know![/say]")
				saynn("[say=azazel]Sure I do, when I'm done with them the only creature they will want to fuck is our Master.[/say]")
				saynn("[say=npc]Damn, sometimes I can't tell whether you are joking or not.[/say]")
				saynn("[say=azazel]Hehehehe. Good.[/say]")
				saynn("Azazel sticks out the tongue at {npc.him} making {npc.her} smile.")
			else:
				
				saynn("[say=azazel]Yeah yeah, sure, I'll be careful... Also how is your lookout for a prison wife looking like lately?[/say]")
				saynn("[say=npc]Oh shut up. You know it's shit, don't need to rub it in. This place sucks, everyone here is either a complete douche or a complete empty-headed whore.[/say]")
				saynn("[say=azazel]And where I'm on that binary?[/say]")
				saynn("[say=npc]You? Not a douche, so it leaves us empty-headed whore.[/say]")
				saynn("[say=azazel]How endearing! That's the better one of the two to be honest.[/say]")
				saynn("[say=npc]Agreed. But then, you are not a lady.[/say]")
				saynn("[say=azazel]You bet I'm not. Don't have those bombs you are looking for huh?[/say]")
				saynn("[say=npc]Haha, that and well, most importantly you aren't [b]like[/b] one.[/say]")
				
				saynn("[say=azazel]Right, will leave [i]that[/i] conversation for another time.[/say]")
				saynn("[say=npc]Sure, buddy.[/say]")
				
		else:
			saynn("[say=npc]No new toys to play with lately?[/say]")
			saynn("[say=azazel]No... I don't want to complain, I love Master's harem I'm part of, but that's true, it would be so fun to play with someone new. You are a meanie for not wanting to join, you know that?[/say]")
			saynn("[say=npc]Pfff. You call me that every time. You know why I don't want to.[/say]")
			saynn("[say=azazel]You are just no fun. No fun {npc.name}![/say]")
			saynn("Azazel sticks out the tongue at {npc.him} making {npc.her} smile.")
			saynn("[say=npc]If you stick it out like that someone will steal that spiky tongue of yours some day, you know?[/say]")
			saynn("[say=azazel]Hasn't happened yet![/say]")
			saynn("[say=npc]Maybe I'll be the first.[/say]")
			saynn("[say=azazel]I'd love to see you try.[/say]")
			saynn("Both of them laugh.")
		addButton("Continue", "Continue listening", "continue_listening2")
		
	if state == "continue_listening2":
		saynn("[say=azazel]Soooo... Mind handing me over that nip of yours. You know it's working on me ever since we started talking right?[/say]")
		saynn("[say=npc]Damn, this time I even packaged it really well to see if you'd sniff it out, how do you do that? I can't smell shit.[/say]")
		saynn("[say=azazel]Only true nip connoisseurs can find catnip inside a maze made of cheese.[/say]")
		saynn("[say=npc]... What?[/say]")
		saynn("[say=azazel]Forget it.[/say]")
		saynn("[say=npc]Dude, sometimes you say the silliest of lines. Anyways, here, enjoy.[/say]")
		saynn("{npc.Name} passes a plastic bag willed with something inside to Azazel.")
		saynn("[say=azazel]Yay! Thank you friend![/say]")
		saynn("Azazel proceeds to badly assault personal space of {npc.Name} by nudging his cheeks on {npc.his} upper chest area where Azazel's head reaches due to his short height, a heavy purring sound coming from Azazel. {npc.Name} handles this affection pretty well and even leans in.")
		
		saynn("[say=npc]Aww, gotta say, when you do that it totally makes up for spending days in this shithole.[/say]")
		saynn("[say=azazel]Hey, I appreciate you {npc.Name}, catnip or not.[/say]")
		
		saynn("Both spend some time being all affectionate with each other.")
		addButton("Attack", "Come closer to them and punch them", "assault")
		addButton("Insult", "Come closer and insult two creatures", "insult")
		addButton("Greet", "Say hi to the friends and pass them by", "greet")
			
	if state == "assault":
		saynn("You approach them both. Hearing someone come closer they give you a curious look until both of them realize you are coming closer to them specifically.")
		
		saynn("When you are close enough and you have their full attention your fist swings in the air intending to make contact with Azazel's chin.")
		if GM.pc.getStat(Stat.Agility) > 40:
			saynn("Fist bruises on Azazel's lower part of the chin and swings with full force in the air. The kitten barely escapes the punch with swift evade supported by {npc.Name} who dragged them away from you.")
		else:
			saynn("Your fist swings and misses the target completely. Azazel took steps back before you swung your fist in the air evading your attack completely.")
		
		saynn("[say=npc]Go fuck yourself asshole! Leave Az alone, what is your problem??[/say]")
		saynn("[say=pc]I hate your guts with passion.[/say]")
		saynn("[say=azazel]What the hell.[/say]")
		saynn("[say=npc]Come, Az, no need to linger near "+("red" if GM.pc.isHighSecInmate() else "asshole") +" with anger issues.[/say]")
		saynn("Before you can make another attack they are out of your sight.")
		if getModuleFlag("IssixModule", "Azazel_Affection_given", 0) > 1:
			say(" You can see disappointed and frightened look of Azazel as he looks behind at your face before disappearing out of view.")
		addButton("End", "Finish the encounter", "endthescene")
			
		
	if state == "insult":
		if getModuleFlag("IssixModule", "Azazel_Affection_given", 0) > 1:
			saynn("You approach them both. Hearing someone come closer at first they throw a curious look before Azazel realizing that's you gives a quick nudge to their friend before quickly stopping the hug.")
			saynn("[say=azazel]Oh, [b]{pc.name}[/b]! Hiiiiii![/say]")
			saynn("He says with mix of embarrassment and excitement, overemphasizing your name. {npc.Name} looks you over from head to {pc.toes}.")
			saynn("[say=azazel]What's up? Did you want something?[/say]")
			saynn("[say=pc]Me? Nah, not really. Just checking on slave fuck I know.[/say]")
			saynn("[say=azazel]... {pc.name}?[/say]")
			saynn("Responds, taken aback by your comment, his friend giving him the look.")
			saynn("[say=pc]Get your fucking act together, you are behaving like some fucking moron.[/say]")
			saynn("[say=azazel]Wh- what?[/say]")
			saynn("[say=pc]Start acting your age, though I doubt a whore like you would know how to act like a man.[/say]")
			saynn("Both of them do not respond, {npc.Name}'s face looks full of anger while Azazel is looking extremely surprised by your sudden outburst. You leave them like that and go on your way.")
		else:
			saynn("You approach them both. Hearing someone come closer they give you a curious look until both of them realize you are coming closer to them specifically.")
			saynn("[say=npc]Do you need something?[/say]")
			saynn("[say=pc]Just looking at meat. You two fucking each other or what?[/say]")
			saynn("[say=azazel]Huh?[/say]")
			saynn("[say=pc]Just commenting on whores I see before me.[/say]")
			saynn("[say=npc]If you are looking for a fight then go somewhere else, not in a mood.[/say]")
			saynn("[say=pc]Shut up, whore. If I want to fight I'll punch your face without your permission.[/say]")
			saynn("[say=npc]Jeez. What an ass, Az, let's go. This creature clearly needs some temper management.[/say]")
			saynn("[say=azazel]Mph. And just so you know, I happily will take „whore” as and adjective, can't insult me with that one honey.[/say]")
			saynn("They say before they leave the place you were in, giving you this space back fully for yourself.")
			
		addButton("End", "Finish the encounter", "endthescene")
		
	if state == "greet":
		saynn("You approach them both. Hearing someone come closer they give you a curious look until both of them realize you are coming closer to them specifically.")
		saynn("[say=azazel]Oh, [b]{pc.name}[/b]! Hiiiiii![/say]")
		
		saynn("[say=pc]Hey Azazel, how is it going?[/say]")
		saynn("[say=azazel]It's going fine, I were just catching up with {npc.Name}, do you know {npc.name}? {npc.Name} this is {pc.Name}, {pc.Name} this is {npc.Name}, my good friend in here.[/say]")
		saynn("[say=pc]Hey there![/say]")
		if GM.pc.getGender() == Gender.Female:
			saynn("[say=npc]Heeey there, say, do you like shiny trinkets? We both could roll to my cell, I have plenty of those that I would want to show you.[/say]")
			saynn("Azazel embarrassed by his friend puts his paw above on {npc.Name}'s muzzle.")
			saynn("[say=azazel]Don't mind {npc.him}, {npc.he} thinks {npc.he} is such a charmer, thinking {npc.he} is an ancient dragon hoarding shiny trinkets.[/say]")
			saynn("[say=npc]Az! Everyone loves shiny trinkets.[/say]")
			saynn("[say=azazel]This and 30 other lies you tell yourself every night to sleep.[/say]")
			saynn("[say=npc]Mph. You are just a weirdo.[/say]")
			saynn("[say=azazel]Uhuh. Sure.[/say]")
		else:
			saynn("[say=npc]Hi.[/say]")
			saynn("Short greeting, after which you shake paws. A short awkward silence follows.")
		
		saynn("[say=azazel]Shoot, {npc.Name}, let's go, wanted to show you something and there's not much time.[/say]")
		saynn("{npc.Name} seemingly surprised comes with Azazel who pulls {npc.him} by the arm.")
		saynn("[say=azazel]See you later {pc.name}![/say]")
		saynn("[say=pc]See you.[/say]")
			
		addButton("End", "Finish the encounter", "endthescene")
		
		
func saveData():
	var data = .saveData()

	data["pawnID"] = pawnID

	return data

func loadData(data):
	.loadData(data)

	pawnID = SAVE.loadVar(data, "pawnID", null)

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false


func _react(_action: String, _args):
	
	if _action == "assault":
		increaseModuleFlag("IssixModule", "Azazel_Affection_given", -9)
		increaseModuleFlag("IssixModule", "Issix_Anger_Noncon", 3)
		addMessage("Azazel will be avoiding you from now on.")

	if _action == "insult":
		increaseModuleFlag("IssixModule", "Azazel_Affection_given", -4)
		increaseModuleFlag("IssixModule", "Issix_Anger_Noncon", 2)

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 2)
		setModuleFlag("IssixModule", "Quest_Wait_Another_Day", true)
		endScene()
		return

	setState(_action)
