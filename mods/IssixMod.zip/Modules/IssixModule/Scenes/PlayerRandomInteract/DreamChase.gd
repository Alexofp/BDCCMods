extends SceneBase

# Endings: Corruption (1), Submission (2), Defeat (3), Escape (4), Win (5), Tentacles (6)

var light = false
var ventilators = false
var cleared_the_air = false
var tracked_pos = "petsdream_cellblock_pink_playercell"
var last_stam = 0
var corruption_bar = null
var corruption_amount = 0
var door = false
var dispenser = false
var sofa = false
var hello = false
var hot_water_tried = false
var teleport = false
var hand_items = []
var picked_up_items = {}
var issix_location = "hall_elevator"
var issix_pain = 0
var chance_to_escape = 100
var issix_stun = 0
var response = null
var player_neck_item = null
var tentacles_aggro = false
var placed_chair = false
var louver_removed = false
var dropped_items = {}
var backup_skindata = {}
var backup_restraints = []
var used_item = null
const fight_items = {"glitter": [0, "You throw entire box of glitter at Issix, it stops {issix.him} in the tracks for a second as {issix.he} tries to understand what just happened.", "Fucking glitter? Seriously? FUCK!... Though at least I won't have to clean that up."], "chair": [15, "You grab the chair with full strength and use it right on the dragon to defend yourself. It's a hit. Issix seems stunned, the chair however, is completely useless now.", null], "metal plate": [10, "You throw the metal plate at Issix, it's a direct hit. The metal plate makes a loud clinking sound, Issix scowls with pain while recovering.", null], "weights": [20, "Heavy weights make contact with Issix's chest making {issix.him} wince in pain as he collapses onto the ground, this buys you more time, better use it wisely!", null], "smoke bomb": [30, "This smoke bomb was produced very long time ago by long defunct company „Military Essentials”. But throwing it at general direction of Issix apparently triggered some kind of ancient mechanism generating large amount of smoke covering large area in it", "*cough* *cough*"], "brick": [30, "You throw a brick at Issix, successfully hitting the dragon.", null], "herbicide": [20, "You open and drain the bottle of herbicides on Issix, {issix.he} yelps in pain as the acidic substance makes contact with {issix.his} body.", "Arghhh, it burns!!"], "granade": [20, "You pull out the release trigger and with all the power you have you throw the grenade at the dragon. {issix.He} reflexively catches it before {issix.he} is electrocuted with high current giving you time to run away.", null], "rake": [5, "You swing with rakes at the demon, {issix.he} is rather unimpressed. You do manage to give {issix.him} a scratch with one of the attempted hits, however {issix.he} grabs the rakes from your paws, breaks them in half and throws them away from you. It's run time!", null]}
const all_available_rooms = ["hall_ne_corner", "hall_canteen", "main_laundry", "main_punishment_spot", "main_bathroom1", "main_dressing1", "yard_novaspot", "main_hallroom6", "yard_neargym", "yard_corridor2", "yard_deadend2", "yard_vaulthere", "gym_weights", "gym_secret", "main_bathroom2", "main_dressing2", "fight_club", "fight_slutwall", "fight_corner_nw", "fight_meme", "yard_stars_green", "main_green_corridor6", "main_green_secret", "main_green_corridor7", "vault_railing", "main_green_corridor11",
"yard_waterfall", "main_greenhouses"]
const custom_room = {"elevator": "hall_checkpoint", "secret_place": "petsdream_cellblock_corridor_part17"}

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "IssixChasesBadPlayer"

func _initScene(_args = []):
	aimCamera("petsdream_"+GM.pc.getCellLocation())
	tracked_pos = "petsdream_"+GM.pc.getCellLocation()
	last_stam = GM.pc.getStamina()
	pawn_visibility_fix()
	spawn_issix_world_pawn()
	backupSkindata()
	backupRestraints()
	SAVE.saveGameRelative("ISSIX_DREAM")
	addMessage("Game saved.")
	
func sumBool(bools: Array):
	var sum = 0
	for i in bools:
		if i == true:
			sum += 1
	return sum

func _run():
	var show_items = false
	
	pawn_visibility_fix()
	if state in all_available_rooms:
		yield(slowWalkChase(state), "completed")
	if state in custom_room:
		yield(slowWalkChase(custom_room.get(state)), "completed")
		
		
	if(state == ""):
		playAnimation(StageScene.Sleeping, "sleep", {bodyState={naked=true}})
		
		saynn("You slept in your cell. It's not the most pleasant experience but you managed to recover your energy.")
		
		saynn("You wake up when... No lights actually do turn on, did you wake up too early?")
		
		saynn("All cell doors are opened, but it smells... Different. The prison is also filled with deafening silence.")
		
		addButton("Peek", "Take a peek outside of your cell at what is going on", "peek")
		
	if state == "peek":
		saynn("You stick your head out your cell looking in direction of long hallway leading to the stairs, what catches you off-guard is that you see no one. Emptiness fills both the cells as well as the hallway. It's... Dark, with only light coming from tiny emergency indicators.")
		
		saynn("[say=pc]Hello?[/say]")
		
		saynn("Your word bounces off many walls, and yet isn't graced with any answer. This is oddly unusual, you've never seen this hallway illuminated this way, nor this quiet or empty. The atmosphere feels different too, though you can't put a finger on why.")
		
		addButton("Investigate", "See what's going on", "investigate")
		
	if state == "investigate":
		saynn("Putting your {pc.feet} forward, leaving the cell the mystique of the situation only amplifies. The hallway looks the same, though the light makes it seem much different. Warm orange light giving just enough to see that you are not about to stub your toe on anything big in front of you, but not enough to feel comfortable. Darkness makes this space feel like something else, and anxiety makes you think anything can jump out of those empty cells around you.")
		
		saynn("As you take more and more steps you begin to notice a structure where hallways from different sectors of cellblock merge, a structure that shouldn't be there, to see it whole you'd have to get closer.")
		
		# addButtonAt(6, "Come closer", "Move forwards", "fountain_place")
		state = GM.pc.getCellLocation()
		
	if state == "corridor_1":
		if cleared_the_air:
			yield(slowWalk("petsdream_cellblock_corridor_part2"), "completed")
			
			saynn("The smell gone now, the path cleared by sheer force of air from the ventilators. You can plunge into increasing complete darkness"+(" as the lamps do not seem to be working in this specific hallway." if light else ".") + " However you do see a little bit of light at the end of the hallway which you can use as a reference point to continue walking.")
			addButtonAt(6, "Continue", "Move forward", "corridor_2")
			addButtonAt(11, "Go back", "Move back towards the fountain", "fountain_place")
			
		else:
			saynn("As you are about to move into the corridor on the north, the intense smell of sweaty clothing and [i]something else[/i] hits you like a train. It comes from deeper in this hall. The revolting odor stops you from going any further and you come back to the fountain.")
			state = "fountain_place"
			
	if state == "corridor_2":
		yield(slowWalk("petsdream_cellblock_corridor_part5"), "completed")
		saynn("You follow the metal corridor, it stretches seemingly forever, the bright spot you are trying to get to doesn't seem this much closer, while the place behind you sems distant enough that you'd have to spend at least 10 minutes walking back.")
		saynn("To make matters worse, the visibility is getting worse. Whatever light still is here – it is very sparse, you aren't even sure how its reaching out from back that far back, but it is. What unsettles you is the dark goo that the walls on your sides are increasingly more covered with. The black viscous fluid doesn't move, or moves too slow for you to notice - it forms droplets visible as void darker than blackness itself.")
		addButtonAt(6, "Continue", "Move forward", "corridor_3")
		addButtonAt(11, "Go back", "Move back towards the fountain", "corridor_1")
		
	if state == "corridor_3":
		yield(slowWalk("petsdream_cellblock_corridor_part8"), "completed")
		saynn("The metal tube keeps going. You feel little hope from the fact that bright spot in front of you became slightly bigger as you closed some distance, though the relative safety of familiar cellblock behind you no longer exists where you are, being too far away to actually feel any safety from its existence. The darkness is almost absolute. Last time you looked at the walls they were almost solid void, covered with whatever fluid was there. Despite the ventilators, you can feel musty atmosphere in the air... ")
		saynn("Your curiosity about the dark goo is getting better of you. You still resist to come anywhere close to the wall, but your will is waning. The fluid seemed quite strange in property, and its color almost unnaturally black. Perhaps if you could just.. Touch it? Run it on your paw fingers? See what it is about?")
		addButtonAt(6, "Continue", "Move forward", "corridor_4")
		addButtonAt(11, "Go back", "Move back towards the fountain", "corridor_2")
		
	if state == "corridor_4":
		yield(slowWalk("petsdream_cellblock_corridor_part11"), "completed")
		saynn("As you continued walking, your legs getting increasingly tired, you've heard a sudden sound behind you. Something seemed to have collapsed, perhaps a part of the ceiling? That's what you judge from the sound and the fact that the cells behind you are no longer visible. That light has been completely cut off. It feels claustrophobic even, fear fills you. Any sense of familiarity and safety is now gone, if the tunnel is collapsing, and you don't see anything, can you even reach the end in front?")
		saynn("You take a long breath, calming yourself. It will be all fine. Just need to reach the end of this wretched tube.")
		saynn("At the same time, your thoughts now are quite set on trying to touch the black goo on the walls. Even though your intuition screams at you that this is a bad idea. Or would it?")
		addButton("Touch", "Touch the goo", "touch_goo")
		addButton("Resist", "Resist touching the goo", "resist_goo")
		
	if state == "touch_goo":
		saynn("It is so much easier to give in to your curiosity, to your desire. Like a little kid you can't possibly pass on an opportunity to feel something unknown. It's not enough to see it, there needs to be physical contact, greater understanding of texture, physics, temperature, feel of goo.")
		saynn("You close in to one of the walls, your {pc.feet} make contact with the substance which sticks to you hindering your movement as they stick to the ground, but you continue to move until your extended arm reaches the black inky substance with paw pads. The sensation is more viscous honey, more dense, more sticky, tar, perhaps, or rather, something close to it. The substance gives a faint smell of dampness and musk.")
		saynn("You grind it between your paw fingers, its stickiness is strong, almost like glue but it doesn't set. In some odd sense, the properties of fluid are alluring to you.")
		addButton("More", "Take more of it, put your entire paw on the wall, hell, why not both, maybe... Smear it onto yourself?", "smear_tar")
		addButtonAt(6, "Leave", "Move forward towards the light instead of playing with black tar", "corridor_5")
		
	if state == "smear_tar":
		look_tf()
		saynn("Just having it on few fingers is not enough for you. The substance invites you to have more of it on yourself. There is enough for it on all those walls for you to cover yourself with it. At first, you put both of your paws on the wall, the black substance crawls in between your fingers, in every nook and cranny of your paw. You giggle, it feels so good to have it on your paws. You make your paw into a fist, and then relax it again. Dark substance for a moment creates strings of itself connecting your paw pads together, before the strings break and collapse into your inky paw.")
		saynn("You don't mind sensations as if the black tar was setting on your " + Globals.getSkinWord()+". It feels secondary to good feelings brought by your new favorite substance. You bring the substance closer onto your naked chest and smear it, feeling the difficulty of doing so as your paw quickly runs out of tar to smear, making you repeat the same until at least your upper belly is covered in the stuff. Breathing which makes your chest inflate makes completely new, ticking sensations as the goo has to constantly reshape.")
		saynn("You can also feel the musty smell coming now from yourself, which isn't strange considering you've covered yourself in strange substance of same smell.")
		saynn("Your chest feels oddly warm.")
		addButtonAt(6, "Walk", "Continue walking towards the light", "corridor_5")
		
	if state == "resist_goo":
		saynn("You successfully stop yourself from touching the black substance and decide to continue walking forwards. There is no idea what could have happened if you touched this unknown substance.")
		addButtonAt(6, "Continue", "Move forward", "corridor_5")
		
	if state == "corridor_5":
		yield(slowWalk("petsdream_cellblock_corridor_part13"), "completed")
		if corruption_amount > 30:  # Corruptive Tar will make the player more worried, anxious and yet it will give pleasure and promise salvation if player only chooses to fall victim to its nasty tricks
			saynn("Your blackened {pc.feet} push forward with struggle, sticking to the ground with every step making locomotion unnecessarily difficult. A sticky sound follows each time a {pc.foot} is raised above the ground. Alas, you continue, getting closer to the long awaited light. You can't tell how much time went by since you started, from the cells, it must have been a while, maybe an hour or two even. The physics of this endeavor feel impossible, with you seeing the light from so afar, with the walk stretching for much longer than it should.")
			
			saynn("That said, you are almost there, even the light seem to already reach the details of your surrounding to a point where you can see whats around you. The tar like substance on the wall appears to be of different color, more... Purple? You look at your paws and sure enough – it is of the same color, even though back when you started noticing the goo you could swear it was void black.")
			saynn("What's more, looking towards the light feels you with anxiety as it looks... Empty. Thoughts fill your mind – what if you arrive there and there is nothing there? No escape? Your rout towards familiarity – cells has been cut off, there is not much you could do, probably.")
		else:
			saynn("You continue walking towards the light - a shimmer of hope that you plan to stick to. Your steps do not reverb, likely the wall goo substance muffles sounds coming at it – another strange property of it you have noticed.")
			
			saynn("Soon, you are almost there, even the light seem to already reach the details of your surrounding to a point where you can see whats around you. The tar like substance on the wall appears to be of different color, more... Purple? Back when you started noticing the wall goo, you could swear it was void black.")
			
		# saynn("As you continue, a loud shriek comes from the blackness behind you, ground vibrates. Instinctively you turn your head behind but can't see anything ")
		saynn("Being so close to the end, your pace quickens, hoping to arrive soon and maybe take a rest. Filled with "+("anxiety and " if corruption_amount>30 else "")+"curiosity of what's to come.")
		
		addButtonAt(6, "Continue", "Move forward", "corridor_6")
		if corruption_amount > 20:
			saynn("You feel the impulse to instead follow the path near the wall instead of the center of metal corridor. If you choose to go this way there is simply no way you'll avoid the tar like substance. While the center is completely clear of any tar, the sides of the tunnel are absolutely coated with dark-purple sticky tar. It drops from the ceiling, slides across the walls and pools on the floor in a 1-2 centimeter layer.")
			addButtonAt(7, "Tar path", "Continue moving forward but walking on the tar covered part of path", "tar_path")
		
	if state in ["corridor_6", "tar_path"]:
		yield(slowWalk("petsdream_cellblock_corridor_part16"), "completed")
		look_tf()
		if state == "tar_path":
			saynn("Your {pc.feet} walk on viscous surface of tar substance, making you used to regular schlop sounds resulting from {pc.foot} lifting and making contact. After a while you learn how to walk in the tar more efficiently, while it still significantly slows you down, making next steps is no longer so difficult.")
			saynn("You look below at your legs, it startles you slightly at first to see the purple tar covering your legs up to knee height. You know for sure that at no point the layer reached this high, and there is also no way the slime built enough momentum to fully cover your leg like this. The tar feels static, but you know it isn't. It has climbed your leg until it reached the knee, and it feels better than ever. That part of your leg is so smooth, so perfectly shaped, lightweight. You raise it to admire the beauty of tar on your body.")
		saynn("It is not too long after you arrive right before what looks to be end of the metal tube. A well lit end of the corridor. You can make out a frame of doors as well as paintings on the walls. There is not as much of tar on the walls which allows the room to illuminate the light coming from large ceiling lamp. There is some furniture there for sure, probably a table and a chair. You'll know for sure what's there when you get there just in a minute or two.")
			
		addButtonAt(6, "Continue", "Make last stride", "corridor_7")
		
	if state == "corridor_7":
		playAnimation(StageScene.Solo, "walk", {pc="pc"})
		aimCamera("petsdream_cellblock_corridor_part17")
		if corruption_amount > 40:
			saynn("You put your blackened {pc.feet} in a visibly distinct section of the corridor, with less tar you see the wallpaper featuring a collar with a chain as a leash.")
		else:
			saynn("You put your {pc.feet} in a visibly distinct section of the corridor, with less tar you see the wallpaper featuring a collar with a chain as a leash.")
		saynn("Wooden doors inside of a metal frame, fiery knob attached - stand in the center of wall opposite to the endless corridor you just came from. On the right wall two grand paintings featuring portraits of creatures with their faces missing. Both of them appear to be sitting in typical for portraits pose, a little bit to the side, empty front of their head facing the viewer. Those are quite unsettling. Below them, on the ground stand extremely puffy looking yellow sofas, partially covered with tar. Their surface has an unusually thick puffy padding, if you decided to sit on it, you'd likely collapse at least solid 8 cm in. On the opposite side there is a drawer with water dispenser filled halfway, with plastic cups attached on the side. If's fairly clean of any tar, with water looking extremely clear.")
		
		saynn("At the center of the distinct room lacking a wall on side you came from a long rectangular table stands, with its length stretching towards two walls leaving enough of space for 3 creatures to fit in between the table and the walls. Table is decorated with tablecloth that has a basic chessboard pattern of white and pink squares on it.")
		
		saynn("This being the end of the corridor, with so little in it, you start wondering if it was worth it. Hours must have passed since you ventured from cellblock with the fountain. If there is nothing behind those doors you are stuck here.")
		
		addButton("Door", "Check the know, try to open the door", "door_try")
		addButton("Dispenser", "Check out the water dispenser", "water_dispenser")
		addButton("Sofa", "Check out that sofa", "sofa")
		addButton("Hello?", "Try and see if someone responds?", "hello")
		
	if state == "pre_room":
		saynn("You stand in a room that lacks one wall. Everything is well illuminated by the lamp in the ceiling.")
		playAnimation(StageScene.Solo, "stand", {pc="pc"})
		if door == false:
			addButton("Door", "Check the know, try to open the door", "door_try")
		elif sumBool([door, dispenser, sofa, hello]) > 2:
			addButton("Door", "Check the doors again, perhaps you've missed something? (this will leave the room)", "door_try_second")
		else:
			addDisabledButton("Door", "You've already tried opening the door to no avail")
			
		if dispenser == false:
			addButton("Dispenser", "Check out the water dispenser", "water_dispenser")
		else:
			addDisabledButton("Dispenser", "You've taken a drink already")
			
		if sofa == false:
			addButton("Sofa", "Check out that sofa", "sofa")
		else:
			addDisabledButton("Sofa", "Not much more to do there")
			
		if hello == false:
			addButton("Hello?", "Try and see if someone responds?", "hello")
		else:
			addDisabledButton("Hello?", "You've tried that already")
			
	if state == "door_try_second":
		playAnimation(StageScene.Duo, "stand", {pc="issix", npc="pc"})

		saynn("Finding no other escape from this place, other than going back to darkness which you came from and likely getting nowhere, you revisit the doors you've left alone after not finding a way to turn the darnest knob.")
		saynn("As you analyze the possibilities of making your way through the doors you hear alarming sound from behind you, right from the large corridor into darkness. Besides heavy metallic clinking sounds, you also feel intimidating, bone chilling presence radiating from there. Slowly turning your head behind you see him. Issix.")
		saynn("[say=issix]Welcome {pc.Name}. had your fun?[/say]")
		saynn("He asks, taking a single step towards you, however he still is around 10 steps away from you. His demeanor serious and confrontational. On his left paw holding what looks to be a large metal slave collar, attached to medium length chain collar. All of which give loud metallic sound.")
		if getModuleFlag("IssixModule", "Unconcious_Hiisi_Result", 0) == 1:
			saynn("[say=issix]It's ironic you've decided to assault my pup. It's as if the cycle loves repeating itself. Rest assured however, I can turn worthless raping cunts like yourself into something useful. Nobody will miss you, but after I'm done with you maybe they will at the very least not hate you with passion.[/say]")
		saynn("He takes another two steps forward towards you, now swinging with the collar like a lasso.")
		saynn("[say=issix]And it's not like I particularly like turning items like you into something usable, quite the opposite. It goes against what I believe. But what I primarily believe in is to protect my dear pets from dipshits like you. And yes, I could simply disappear you. Sell you, kill you or make you incapable of hurting others. But you know what? Nothing gives me as much satisfaction as seeing the looks of surprise and admiration from other inmates seeing my newly branded pet - the nuisance of the prison brought down and tamed by myself – Issix.[/say]")
		saynn("He closes the distance, his presence even more intimidating than before, landing you on the doors behind you, they still hold but the knob isn't boiling hot anymore? At least you don't feel heat radiating from it anymore. Your back presses hard against the doors.")
		saynn("[say=issix]And after it is all said and done, you'll forget your shitty name, your shitty past and your entire identity. I'll give you meaning, I'll give you purpose, you'll call me Master, and I shall own you for the rest of your life. So show me your neck and lets get over it.[/say]")
		saynn("The moment he mentioned your neck, you've realized that the prisoner collar is missing. You put your paws on your neck, tracing the "+Globals.getSkinWord()+" on it, lacking the device. Your breath quickens and fight-or-flight response kicks in.")
		addButton("Continue", "", "behind_doors")
		
	if state == "behind_doors":
		saynn("Suddenly, the doors behind you give and you fall through. Surprised you find stable footing and look around...")
		saynn("You recognize this place! This is near the elevator in main hall, and the doors you just went through are exactly the doors of the elevator!")
		saynn("[say=pc]Woah. What the-[/say]")
		saynn("[say=issix]This is exactly why you need a leash, running is pointless pup. This prison doesn't have a an exit, you are stuck here with me.[/say]")
		saynn("You take a second look. Issix isn't coming at you with speed, the halls look empty and moving should be fairly quick, there is a hope that the layout is the same, and not changed as it was the case with the cellblock you came from. Fighting likely isn't an option, you can run, possibly hide and figure out something else later.")
		if corruption_amount > 80:
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]I can help. Just go, don't let him catch you.[/pulse][/sayOther]")
		addButton("We'll see", "„We'll see about it”", "response_run", ["wewillsee"])
		addButton("Fuck you", "„Fuck you”", "response_run", ["fuckyou"])
		addButton("Bring it on", "„Bring it on motherfucker”", "response_run", ["bringiton"])
		addButton("Yield", "Decide to willingly give yourself to Issix", "response_yield")
		
	if state == "response_yield":
		saynn("For whatever reason, you decide that running isn't what you want to do. Be it because you agree with Issix on futility of it, you don't feel strong enough to resist or simply because you actively want to give yourself to Issix.")
		saynn("Instead of running through the hallway to the main hall, you turn around and look at the demonic dragon coming to you in slow pace with a collar in his clawed paws.")
		saynn("[say=issix]Oh? "+Globals.getPlayerPetName().capitalize()+" had a flash of smarts? Good {pc.boy}.[/say]")
		saynn("He approaches you with a large silver slave collar slowly, and you don't resist when his clawed paws approach your neck, looking the other way, not at Issix himself.")
		saynn("[say=issix]You've made a good decision. There is no place you could hide in this prison. I'll make you anew, you'll see.[/say]")
		saynn("Heavy duty collar is slipped on your neck, and with a loud click fixed in place. Its heavy weight bears uncomfortably on your collarbone, giving you a permanent reminder of your sorry state you've been put into.")
		
		saynn("[say=issix]A good FIRST step. I'm going to make a good pet out of you still.[/say]")
		saynn("A heavy chain, attached to your collar pulls on your neck to move. When you try to stand up...")
		saynn("[say=issix]Down, dog! Four legs you have, get that idea of two legs out of stupid head of yours.[/say]")
		saynn("You whine and comply with your Master's order as both of you resume walking towards the elevator.")
		saynn("[say=issix]I expect the same obedience from you on the other side as well, pet. This role suits you better.[/say]")
		saynn("{issix.He} says without looking at you, you don't understand what does {issix.he} means by „the other side” however soon enough it stops mattering anyways.")
		addButton("Darkness", "You walk until everything goes dark again", "wakey_scene")
		
	if state == "response_run":
		if response == "wewillsee":
			saynn("[say=pc]Truthfully? Well, I think I'll take my chances, thank you.[/say]")
			saynn("{issix.He} smiles.")
			saynn("[say=issix]You don't have any, but hey, you are welcome to try. I'll enjoy this.[/say]")
		elif response == "fuckyou":
			saynn("[say=pc]Oh yeah? You know what, fuck you. I'd rather die than let you do shit to me. Die in hell asshole.[/say]")
			saynn("{issix.He} laughs.")
			saynn("[say=issix]Such a rebellious pet, I don't think I speak such uncivilized language. But I'm willing to teach you a better one, go on, try to escape.[/say]")
		else:
			saynn("[say=pc]Bring it on Motherfucker, come and get me if you can.[/say]")
			saynn("You show {issix.him} a vulgar sign with a paw. At first {issix.he} looks at you a little surprised, however soon that surprise is replaced by a smirk, {issix.he} stretches {issix.his} body. The hunt is on.")
			saynn("[say=issix]I haven't done that in a while pet, I'll enjoy being a predator for you, give me a good run, prey.[/say]")
		
		saynn("You start running into the open, it would be really good to keep as much of distance as possible from him. Perhaps you can even find something to fight back with?")
		addButton("Run", "", "elevator_from_cells")
	
	# MAIN HALL LOCATIONS
	
	if state == "elevator":
		pawn_visibility_fix()
		saynn("You are standing in hall checkpoint that is between the the elevator and main hall of the prison.")
		addButtonAt(10, "Canteen", "Go to the canteen", "hall_canteen")
		addButtonAt(11, "Main platform", "Go towards main platform", "main_punishment_spot")
		addButtonAt(12, "Issix's Corner", "Go to Issix's corner", "hall_ne_corner")
		if issix_location != "hall_elevator":
			addButtonAt(6, "Elevator", "Go back where you came from", "secret_place")
		if corruption_amount > 80:
			saynn("A familiar voice rings in your head.")
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Platform...[/pulse][/sayOther]")
		
	if state == "secret_place":
		aimCamera("petsdream_cellblock_corridor_part17")
		playAnimation(StageScene.Solo, "stand", {pc="pc"})
		saynn("You find yourself back in the very room from which last time you were in, you were scrambling to get away from, being chased by dragon demon holding heavy duty slave collar.")
		saynn("A good question to ask, would be why? Why here again? This seems to be a dead end, if Issix catches up you'll be toast. Last time you were here, there didn't seem to be any way out... Except maybe that ventilation shaft high above? But... Even if you move the table, there is no way you could reach it.")
		if "chair" in hand_items:
			addButton("Chair", "Stack a chair on top of the table", "stack_a_chair")
		if placed_chair:
			addButton("Climb", "Climb on top of the chair to reach the ventilation shaft", "ventilation")
			
		addButton("Go back", "Go back towards the main hall", "elevator_from_cells")
		
	if state == "ventilation":
		saynn("You've climbed on top of the chair, normally that would break all of the safety standard, the chair isn't stable at all, but to hell with safety standards in this situation!")
		if !louver_removed:
			saynn("Looking closer at the ventilation shaft, it doesn't seem like it will be this easy to slide in. The metal louver installed in the shaft is screwed tight to the frame.")
		else:
			saynn("The metal louver that was installed on the ventilation shaft is now gone, nothing is stopping you from simply using your arms to enter the ventilation shaft. It will be tight, but you'll take the relative safety of seemingly only way of escaping the enslavement.")
			
		if "screwdriver" in hand_items and !louver_removed:
			addButton("Unscrew", "Unscrew the louver", "unscrew_the_frame")
		if louver_removed:
			addButton("Climb", "Climb the ventilation shaft", "climb_shaft")
			
		addButton("Jump off", "Jump off the chair to the ground", "secret_place")
		
	if state == "climb_shaft":
		saynn("With a little bit of difficulty you've climbed up the metal ventilation shaft, after your entire body is in you continue slithering inside, not a great experience for claustrophobic creatures.")
		if "flashlight" in hand_items:
			saynn("The flashlight you've picked up is now coming really handy. There is little to no light in the shaft, and moving around in total darkness while is possible, would be a quite stressful experience.")
		else:
			saynn("Having no light to guide your moves you are going completely blind there. You are trying to mentally map directions so you don't end up going in circles, however it is a quite stressful adventure either way...")
		yield(darken(), "completed")
		
		addButton("Continue", "Continue", "shaft_2")
		
	if state == "shaft_2":
		saynn("Left, right, left, left... The maze of ventilation shafts quickly becomes a mess inside of your head, just how many turns and splits can this ventilation shaft have? You pass by some metal louver below, each time verifying what's under you. Sometimes its the places you recognized sometimes they were various maintenance rooms or staff rooms that you've never had the opportunity to see.")
		saynn("There are also smaller ventilation shafts splitting from the one you are going through, though those usually are way tighter than you'd feel comfortable in going through.")
		saynn("...")
		saynn("Every now and then you have to pause, crawling through the ventilation shaft becomes tiring pretty quick. It makes you think about situation you found yourself in. It's so quiet, no inmates, no guards walking around. It feels so real and yet somewhere deep you do know that it's not, and yet you are unable to wake up.")
		saynn("Doubts creep in, whether this even makes sense. Wherever you end up going, it's going to be the same goddamn prison, if Issix isn't waiting for you at the exit, {issix.he} is certainly going to catch up, and what then?")
		saynn("Full of thoughts you mindlessly continue to push through, until your busy mind becomes focused on something entirely else, a sound that you haven't heard for a long long time. One that sounds so wrong to you, so misplaced. Birds. Birds screaming, or more precisely seagulls, at least few of them, but you recognize some other large body of water birds as well. Why here? Is someone simply playing those sounds? Your pace quickens towards the sound, to make it even stranger, the air flow feels strong and stronger with each centimeter, the smell gives you this oceanic breeze vibe.")
		yield(darken(), "completed")
		addButton("Continue", "", "beach")
		
	if state == "beach":
		aimCameraAndSetLocName("dream_beach_22")
		saynn("You can't quite believe what you are seeing, but light, one that feels warm and real, not synthetic hits your face as you make a turn to the right. There is a square of vivid colors in the distance, the end of the ventilation shaft for sure but...")
		saynn("Your bewilderment is soon replaced by amazement. This feels unreal, you see real beach, sand and ocean? Palm trees around. Crawling you see more and more, the air so much lighter here, the light so strong it's unpleasant but you quickly adjust to new environment. Finally you see it all, at the end of the shaft, you crawl out into sandy surface conveniently just below the louverless exit from the pipe. To feel sand, the fresh air, sounds of smaller critters all around and the ocean waves hitting the sand  dispersing right after.")
		
		saynn("Even you've spent just about "+str(GM.main.getDays()) + " days in the prison, and you didn't expect to feel the freedom so soon. The joyous feeling of being unrestrained, able to frolic, enjoy yourself in this relaxing place. For a moment you forget about the prison, chase, your situation or where you came from. Completely ignoring the fact you've just crawled through air vent into middle of the beach. Right now, you are simply taking it all in, all surrounding, its yours now.")
		saynn("You lay on the sand, giggling to yourself, looking at the clear yellow sky above, just as you remember it.")
		saynn("Excitement turns to curiosity, curiosity turns to unease. The muted thoughts of this being so... False are creeping back in. Where are you? How are you here? This doesn't make any sense.")
		saynn("You look around, it all looks so real, the metal pipe you crawled out of seemingly stretches for miles behind the horizon though, that's.. Impossible. Around you there is the ocean, or what you assume to be the ocean, and a lot, a lot of palm trees. Main land seems to be positioned further away, the star providing heat that heats your "+Globals.getSkinWord()+" seems to be setting, and you increasingly feel the need to just... Rest. In the sand. Just for a minute. Can't be that bad right? After all this effort and stress it only feels natural.")
		saynn("You curl into a fetal position and take a nap...")
		addButton("Wake up", "", "wakey_scene")
		
	if state == "hall_ne_corner":
		saynn("Arriving at Issix's pet corner isn't likely to help you and yet you came here. The blankets are there, the chair is here, but there are no pets and the Master is currently chasing you. Probably best to leave this place as you can't find anything useful in here.")
		show_items = true
		addButtonAt(10, "Main hall", "Go back to connector between the main hall and the elevator", "elevator")
		addButtonAt(11, "Main platform", "Go towards main platform", "main_punishment_spot")
		addButtonAt(12, "Laundry", "Go towards laundry place", "main_laundry")
		
	if state == "hall_canteen":
		saynn("Canteen has a few nice places to hide, however perhaps more interestingly there are many items laying around. Metal plates, chairs, tables, you could perhaps fight back in here, or try to hide in various nooks and crannies of the canteen.")
		show_items = true
		addButtonAt(6, "Main hall", "Go back to connector between the main hall and the elevator", "elevator")
		addButtonAt(11,"Bathroom", "Go towards the bathroom", "main_bathroom1")
		# addButtonAt(16,"Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(12, "Main platform", "Go towards main platform", "main_punishment_spot")
		button_if_not_held("Chair", "You could pick up the chair and use it in a fight", "chair")
		button_if_not_held("Plate", "You could pick up the plate and... Use it as ranged weapon? Maybe?", "metal plate")
		
	if state == "main_laundry":
		saynn("You have arrived at the laundry, out of places to hide there aren't any really, machines in the room don't provide much cover and you'd be incredibly exposed if Issix was to enter the room. Best to get out of here, it's a dead end.")
		show_items = true
		button_if_not_held("Banana peel", "In one of the trash cans there is a banana peel, right where it belongs.", "banana peel")
		addButtonAt(6, "Issix's Corner", "Go to Issix's corner", "hall_ne_corner")
		addButtonAt(10, "Main platform", "Go towards main platform", "main_punishment_spot")
		addButtonAt(11, "Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		
	if state == "main_punishment_spot":
		saynn("A pillory, just a point in the main hall you can go through to get somewhere else, because sticking your head through the device and letting yourself get caught is not the wisest move.")
		show_items = true
		button_if_not_held("Dildo", "Someone left a black horse dildo near the pillory, perhaps you could pick that up for use?", "dildo")
		addButtonAt(6, "Main hall", "Go back to connector between the main hall and the elevator", "elevator")
		addButtonAt(5, "Canteen", "Go to the canteen", "hall_canteen")
		addButtonAt(10, "Bathroom", "Go towards the bathroom", "main_bathroom1")
		addButtonAt(11, "Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(12, "Laundry", "Go towards laundry place", "main_laundry")
		if corruption_amount > 80:
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]go Connector...[/pulse][/sayOther]")
			saynn("The voice in your head sounds incredibly weak and tired.")
		
	if state == "main_bathroom1":
		saynn("The bathrooms! You could in theory hide here, however those bathrooms weren't exactly made with idea of being sturdy enough to let someone be shielded from an assault. The doors are unlikely to hold Issix for long. If you could devise a plan and maybe dunk Issix in water... No, that wouldn't work. Silly idea.")
		show_items = true
		addButtonAt(10,"Dressing room", "Go towards the showers, in the dressing rooms and try to lock yourself in", "main_dressing1")
		addButtonAt(11,"Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(12,"Main platform", "Go towards main platform", "main_punishment_spot")
		
	if state == "main_dressing1":
		saynn("You find yourself inside the dressing room, locking the doors behind you.")
		addButtonAt(12, "Bathroom", "Leave the dressing room", "main_bathroom1")
		
	if state == "yard_novaspot":
		saynn("Nova's place is Nova-less, unsurprisingly there is not a soul in sight except that fucking dragon stepping on your toes.")
		show_items = true
		addButtonAt(6,"Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(7,"Greenhouses", "Go towards stairs leading to greenhouses", "yard_stars_green")
		addButtonAt(10,"Gym Connector", "Go towards the connector of gym area and rest of the yard", "yard_neargym")
		addButtonAt(12,"Corridor", "Go towards next crossroads of the prison yard", "yard_corridor2")
		
	if state == "main_hallroom6":
		show_items = true
		saynn("This corridor connects hallroom with prison yard, it usually is quite crowded as there are many creatures trying to go through it.")
		addButtonAt(6,"Main platform", "Go towards main platform", "main_punishment_spot")
		addButtonAt(5,"Bathroom", "Go towards the bathroom", "main_bathroom1")
		addButtonAt(7,"Laundry", "Go towards laundry place", "main_laundry")
		addButtonAt(10,"Nova", "Go towards the place where Nova usually hangs out", "yard_novaspot")
		addButtonAt(11,"Gym Connector", "Go towards the connector of gym area and rest of the yard", "yard_neargym")
		addButtonAt(12,"Greenhouses", "Go towards stairs leading to greenhouses", "yard_stars_green")
		if corruption_amount > 80:
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]gym![/pulse][/sayOther]")
		
	if state == "yard_neargym":
		show_items = true
		saynn("You are standing in place connecting the gym area with the yard.")
		addButtonAt(5,"Nova", "Go towards the place where Nova usually hangs out", "yard_novaspot")
		addButtonAt(6,"Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(10,"Gym", "Go towards gym area with weights", "gym_weights")
		addButtonAt(11,"Fight club", "Go towards the fight club", "gym_secret")
		addButtonAt(12,"Corridor", "Go towards next crossroads of the prison yard", "yard_corridor2")
		
	if state == "yard_corridor2":
		show_items = true
		saynn("A large open area with all sorts of trees, bushes, and other greenery. Stone pathways cross here, you can go in all major directions.")
		button_if_not_held("Plastic bag", "Somehow still one of the most widely used methods of transporting items, this yellow bag has „Frittte” written on it", "plastic bag")
		addButtonAt(5,"Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(7,"Greenhouses", "Go towards stairs leading to greenhouses", "yard_stars_green")
		addButtonAt(10,"Hallroom Connector", "Go towards the connector of gym area and rest of the yard", "yard_neargym")
		addButtonAt(11,"South", "Go towards the secluded resting place", "yard_deadend2")
		addButtonAt(12,"Waterfall", "Go towards the waterfall place", "yard_waterfall")
		addButtonAt(13,"The Swing", "Go towards place below the greenhouses", "yard_vaulthere")
		
	if state == "yard_deadend2":
		saynn("This small, cozy place is a carve out of the asteroid this station is firmly built on. However it's also a dead end. The faster you get out of here, the better for you.")
		addButtonAt(6,"Corridor", "Go towards crossroads of the prison yard you came from", "yard_corridor2")
		
	if state == "yard_vaulthere":
		saynn("This rather insignificant place offers some peace of mind and privacy... Unless you are being chased by imposing dragon demon.")
		button_if_not_held("Brick", "An actual, real red brick! Nobody builds with those anymore, but it could come in handy in a fight.", "brick")
		addButtonAt(10,"Corridor", "Go towards next crossroads of the prison yard", "yard_corridor2")
		addButtonAt(11,"Waterfall", "Go towards the waterfall place", "yard_waterfall")
		
	if state == "yard_waterfall":
		saynn("This place is one of relaxation. There are benches all around as well as a small pond along with a waterfall. It would be difficult to relax given the circumstances, but maybe there is something here you could use?")
		button_if_not_held("Bottle", "A bottle of herbicide, likely to manage weeds in this common area", "herbicide")
		addButtonAt(5, "Corridor", "Go towards next crossroads of the prison yard", "yard_corridor2")
		addButtonAt(6, "The Swing", "Go towards place below the greenhouses", "yard_vaulthere")
		
	if state == "gym_weights":
		saynn("You stand in the gym. It's not a hiding place, though there are some weights that you could use if it came to fight.")
		button_if_not_held("Weights", "Pick up some weights", "weights")
		addButtonAt(10,"Bathroom", "Go towards the bathrooms", "main_bathroom2")
		addButtonAt(11,"Fight club", "Go towards the fight club", "gym_secret")
		addButtonAt(12,"Hallroom Connector", "Go towards the connector of gym area and rest of the yard", "yard_neargym")
		
	if state == "gym_secret":
		saynn("The underground fight club... It could be a dead end, though something isn't right. The place isn't the same as you remember it, you can feel it. The misaligned wall panel can be moved.")
		show_items = true
		addButtonAt(5,"Gym", "Go towards the gym", "gym_weights")
		addButtonAt(7,"Connector", "Go towards the connector of gym area and rest of the yard", "yard_neargym")
		addButtonAt(10,"Bathroom", "Go towards the bathrooms", "main_bathroom2")
		addButtonAt(11,"Enter", "Enter the place behind the panel", "fight_club")
		if corruption_amount > 80:
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]through the pa-[/pulse][/sayOther]")
			saynn("The voice in your head cuts off.")
		
	if state == "main_bathroom2":
		saynn("The bathrooms! You could in theory hide here, however those bathrooms weren't exactly made with idea of being sturdy enough to let someone be shielded from an assault. The doors are unlikely to hold Issix for long. If you could devise a plan and maybe dunk Issix in water... No, that wouldn't work. Silly idea.")
		show_items = true
		addButtonAt(10,"Dressing room", "Go towards the showers, in the dressing rooms and try to lock yourself in", "main_dressing2")
		addButtonAt(6,"Gym", "Go towards the gym", "gym_weights")
		addButtonAt(12,"Connector", "Go towards the connector of gym area and rest of the yard", "yard_neargym")
		addButtonAt(11,"Fight club", "Go towards the fight club", "gym_secret")
		
	if state == "main_dressing2":
		saynn("You find yourself inside the dressing room, locking the doors behind you.")
		addButtonAt(12, "Bathroom", "Leave the dressing room", "main_bathroom2")
	
		
	if state == "fight_club":
		aimCamera("fight_entrance")
		if corruption_amount > 80:
			saynn("As you approach the wall panel you can feel warm and humid air coming through the gaps in-between the panel and the wall. You notice small droplets of so familiar to you tar, the very same you've seen in the cellblock corridor. You take a look behind, Issix can be heard in close distance. With some effort, the wall panel moves giving you enough space to move through and land in dark narrow corridor, in the past used for maintenance. The walls, ceiling and the floor are covered in layer of familiar to you tar. You take a step forward.")
			saynn("While you continue going forwards, the panel behind you closes, around it a mass of goo closing in the entrance – and to your best knowledge – the only exit there is.")
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]he doesn't have power over this place, you are safe.[/pulse][/sayOther]")
			saynn("The voice in your head says. Looking around this tunnel, previously used for maintenance leads further into a dark zone. Splotches of substance you are well acquainted with are visible on the walls here and there.")
			addButton("Walk", "Continue walking", "fight_slutwall")
		else:
			saynn("This tunnel was preciously used for maintenance, now it leads into a dark room which you can reach with a ladder.")
			addButton("East corner", "Continue walking towards eastern corner of the space", "fight_corner_nw")
			addButton("West corner", "Continue walking towards western corner of the space", "fight_slutwall")
			addButton("Back", "Come back", "gym_secret")
			
			
	if state == "fight_slutwall":
		if corruption_amount > 80:
			saynn("This seems to be the very core of corruption, huge [color=#250a4]dark purple veins[/color] form along the walls, pumping large amounts of tar inside, smaller veins spreading from the larger ones cover every nook and cranny. Tar is ever-present in this place, it is the place. There is not a single surface left, that wouldn't be covered with this slimy, vicious sludge. All of the environment is very much alive, living. When you focus a bit more on the reflective surface of tar you can see smaller worms moving everywhere, slithering. A rumble, like a heartbeat is heard in the entire space. The tar pumping, the slithering of the tar creatures, all of those create ambience that your entire body vibrates with.")
			saynn("Those vibrations, the rhythm of those pulses... It's in sync with you. You can feel it. Looking at yourself you see that the tar covers your entire body. Dark, hardened crust of tar feeling like your own skin. Your own heartbeat is synced to the beat of tar around you. The smell is earthy, strong, musky. It permanents the air around, it is in your lungs and it... Feels good.")
			saynn("Moving through the tar no longer feels difficult to you, instead it feels natural. You slide on the tar when you want, it slows you down when you want it to.")
			saynn("[say=pc]Ahhh, this is all... Excellent.[/say]")
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Is it not? This is... Our domain. Currently it's... Contained. It's far from ideal but... You can help.[/pulse][/sayOther]")
			saynn("[say=pc]It feels wonderful already? What is missing?[/say]")
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]It's not complete. Let me show....[/pulse][/sayOther]")
			saynn("In one moment, everything pulsates in specific pattern, with pulses coming from your right to your left, you can feel the pulse in your veins as well, strong pull, leading you somewhere. You turn left and...")
			addButton("Walk", "Walk where the pulse leads you.", "fight_meme")
		else:
			saynn("This maintenance space looks as if untouched by a living being since its creation. It could use some heavy maintenance by itself, as it looks as if it could crumble on your head at any moment. Large square space in the center seems to be mostly empty, just some metal handrails surrounding it. Otherwise on the walls stacks of wires and tubes coming and going through the walls. There is a dusty control panel standing on a metal bar.")
			addButton("Control panel", "Check out the control panel", "control_panel")
			addButton("West corner", "Go along the metal railing to another corner of this maintenance space", "fight_corner_nw")
			addButton("Back to gym", "Come back following the direction of the gym", "fight_club")
			
	if state == "control_panel":
		saynn("This dusty control panel has a bunch of buttons on it, after removing the dust two of them appear to be in yellow color and two in red.")
		saynn("Pressing the buttons doesn't do anything, the control panel seems entirely non-functional, and considering the sorry state its in, it would require work of serious engineers to get it to working condition.")
		button_if_not_held("Smoke bomb", "Laying next to the control panel there is an ancient smoke bomb, difficult to tell if it would work in a fight", "smoke bomb")
		addButton("Back", "", "fight_slutwall")
		
	if state == "fight_corner_nw":
		saynn("It's simply a corner inside maintenance space. Nothing of note here.")
		addButton("East corner", "", "fight_slutwall")
		addButton("Back to gym", "Come back following the direction of the gym", "fight_club")
			
	if state == "fight_meme":
		saynn("You approach a corner of the fight club, still wholly consumed with dark, vicious goo filling every nook of surface. There is one central part of the corner that easily catch sight - a pod. One that is shaped in such a way that any humanoid of average height would fit. There are separators for legs and arms as well as a mask on a wall. Everything in the same shade of dark purple goo.")
		saynn("From the pod, there are coming enormous veins that spread into the rest of the room, getting smaller and smaller with each meter, establishing the pod as something core to the room, the central piece giving it... Life?")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]This is it. The remaining piece is you. All you have to do is join. Allow yourself to become part of something greater, let us make the universe whole.[/pulse][/sayOther]")
		saynn("Those sounds that make words in your head root deep in your mind. They make perfect sense. Making the universe whole? Everyone should seek to do that, and you can be a part of that, of making everyone more... Aware, connected, fulfilled. Your face turns into a wide smile, it's not that far anymore, just a few steps towards the pod. You want to connect, to feel the goo flowing through you entirely.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]You see as it is. Imagining the world [i]better[/i], creatures [i]happier[/i], forever connected in a [i]hive[/i]. So join me, allow me to [i]connect[/i] you. You'll never be alone.[/pulse][/sayOther]")
		addButton("Approach", "Approach the beautiful pod", "approach_pod")
		
	if state == "approach_pod":
		saynn("You slowly step towards the pod, each of your {pc.feet} sinking a little into spongy surface made out of this lovely [color=#250a46]goo[/color]. Looking at the pod you notice many tube like tentacles, made out of more solid goo like substance aligned on the sides of the pod, some of those are on the inside of the form that will soon be the one connecting your body. A voice of reason, terrified of the prospect of coming any closer to this thing rings in your head.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]There is no hurt, no pain in the the process, you will join me just as I'll join you. Do not fear.[/pulse][/sayOther]")
		saynn("Those words weave into your brain like a tidal wave, completely ridding you of any doubts about the pod. Excitement rushes through you, for the unknown, to feel even more connected, to [b]be changed[/b].")
		saynn("Taking few hasty steps towards the pod, you do not need to be told how to enter it. Subconsciously you turn your back towards it and press on. First you feel your legs slot just in the right place, with small separator going from just beneath your crotch to your feet. Next, your {pc.thick} butt touches the stickyness of the pod behind you, a small slimy tube starts probing your ass with speed of snail looking for something. But soon enough your torso and arms join the rest. The sides of your torso almost ticking as the pod seems to adjust ever so slightly to your placement, making sure you fit right in, secured from all sides. Right after your stretched arms go above your head and touch the pod behind, you can feel a gentle yet strong tube locking each arm in the pod, the same happens below to your legs. This is undoubtedly for your own comfort, as it would be difficult to normally keep this pose.")
		saynn("You involutionary close your eyes, sensations coming from just about everywhere, from contact with the pod, from getting locked in. It's hot. You love it so much. The pleasure radiates from every single nerve in your body, much of it thanks to the vicious goo interfacing with your skin and body parts.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Yesssss. Yesssssss. Feel it? There will be more. You'll have to seek it out. We will now [b]forever[/b] be connected.[/pulse][/sayOther]")
		
		addButton("Continue", "", "end_pod")
		
	if state == "end_pod":
		saynn("Finally, you open your eyes, last moments before the dark mask closes on your face, shutting you off from sight, smell, and hearing. Each of your ears is connected wot the pod with a pliable tube, which seals them and starts to pump a viscous liquid inside. The tubes that connect with your nose however do not do the same, rather there is a strong smell coming from them, served straight into your breathing holes, filling you with lust and drugging your mind with sweet sweet promises of eternal bliss.")
		saynn("Your mouth is filled with the thickest of tubes. With each second you feel it extending beyond your mouth, into your throat. It doesn't inflate inside, however in pulsing manner it pumps [i]something[/i] inside of you.")
		saynn("This orgasmic bliss takes forever. Your ability to think is entirely replaced with sensations of pleasure coming from all points of your body and soul. There is simply no way to topple that experience, and if there is no way to topple it, is there any reason to live any longer? If you've lived through the best moment in your life, feeling entirely consumed, becoming de-facto a heart of something beyond your comprehension, something dark and yet so kind to let you join the hive. There it is. The reason. You want to be the heart. You want the best for the hive. You want to serve and be served by others in the hive.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]We need more.[/pulse][/sayOther]")
		saynn("And it makes sense. We do need more creatures become part of the hive. Hive only exists thanks to the numbers. Each servant of the hive is another enlightened creature partaking in shared hardships and pleasures. Joining the network of one.")
		saynn("Sharing experiences and pleasure is the ultimate goal of life. That's what the hive thinks for you, with you.")
		saynn("You'll be a good servant of the hive.")
		addButton("Wake up", "", "wakey_scene")
		
	if state == "yard_stars_green":
		show_items = true
		saynn("Path to the gardens. Usually ripe with guards this place is surprisingly silent. This could prove a great place to hide or lose Issix!")
		addButtonAt(10,"Hallroom Connector", "Go towards the place connecting hallroom with prison yard", "main_hallroom6")
		addButtonAt(11,"Corridor", "Go towards next crossroads of the prison yard", "yard_corridor2")
		addButtonAt(12,"Fork", "Go towards the fork in the paths to the greenhouses", "main_green_corridor6")
		
	if state == "main_green_corridor6":
		saynn("Entrance area of the greenhouses, there is also other path going to some kind of storehouse.")
		show_items = true
		addButtonAt(6,"Storehouse", "Go towards the storehouse stash", "main_green_secret")
		addButtonAt(11,"Greenhouses", "Go towards the greenhouses", "main_green_corridor7")
		
	if state == "main_green_secret":
		show_items = true
		saynn("Storehouse filled with various types of boxes, items are laying around, majority of them likely completely useless.")
		button_if_not_held("Baseball Cap", "If you weren't being chased, this could be apparel to show off with", "baseball cap")
		button_if_not_held("Flashlight", "A great utility item, one letter away from being a pleasure tool", "flashlight")
		button_if_not_held("Screwdriver", "It's a rare universal tool that molds to any kind of screw head there possibly can be, top notch stuff!", "screwdriver")
		button_if_not_held("Glitter", "The most annoying item in the entire world – glitter, hard to imagine how it helps but... It's there!", "glitter")
		button_if_not_held("Credits", "Many physical credits!", "credits")
		button_if_not_held("Decaying meat", "It reeks, but there is a sizable chunk of decaying meat", "decaying meat")
		addButtonAt(11,"Fork", "Go towards the fork in the paths to the greenhouses", "main_green_corridor6")
		
	if state == "main_green_corridor7":
		show_items = true
		saynn("The balcony here connects path north to greenhouses standing deeper south, there is also an opportunity for you to jump over the railing and the balcony.")
		if tentacles_aggro:
			saynn("There are angry noises of tentacles just behind you.")
			
		addButtonAt(6,"Entrance", "Go back to the entrance area", "main_green_corridor6")
		addButtonAt(10,"Vault over", "You could jump over the railing if you wanted, it's unlikely Issix will do the same", "vault_railing")
		if tentacles_aggro:
			addButtonAt(11,"Storage", "Try again to go south to greenhouses with crates...", "stay_tentacles")
		else:
			addButtonAt(11,"Storage", "Go further to south to greenhouses with large amounts of crates", "main_green_corridor11")
			
	if state == "vault_railing":
		saynn("You jump over the railing of the balcony and land in the side yard, barely making it. While the drop doesn't look too high, your {pc.foot} landed on the wrong side. But you are safe and sound. But where to go now?")
		addButton("Continue", "Continue", "yard_vaulthere")
		
	if state == "main_green_corridor11":
		
		if "decaying meat" in hand_items and tentacles_aggro == false:
			saynn("As you were approaching the storage greenhouse with apple tree, it became apparent that the site is not safe, with giant tentacle monster at its prime guarding the greenhouse, the thing looks especially violent today.")
			saynn("Despite of it not having any head or eyes, you have the uneasy feeling that your approach did not go unnoticed. Perhaps that's a reaction to something you are holding? As the tentacles stopped swishing around freely in air, they stood there motionless for a second before all pushing in your direction, disappearing in the ground, and then emerging from the ground much closer to you than they were before. They are approaching. Probably good time to RUN.")
			addButton("RUN", "Trace your steps back to the balcony", "main_green_corridor7")
			addButton("Stay", "Stay in place and see what the tentacles do with you", "stay_tentacles")
		elif tentacles_aggro == null:
			saynn("Tentacles gone, the place looks quiet. You could potentially check out what's inside that storage greenhouse and maybe eat an apple or two from the tree.")
			addButton("Balcony", "Come back to the balcony", "main_green_corridor7")
			addButton("Storage", "Check storage greenhouse", "main_greenhouses")
			
		else:
			saynn("As you were approaching the storage greenhouse with apple tree, it became apparent that the site is not safe, with giant tentacle monster at its prime guarding the greenhouse, the thing looks especially violent today.")
			saynn("It would be probably a good idea to distance yourself from the tentacles. Nothing good will come out of approaching them, you are sure.")
			addButton("Balcony", "Come back to the balcony", "main_green_corridor7")
			addButton("Approach", "Approach the tentacles anyways", "stay_tentacles")
			
	if state == "main_greenhouses":
		saynn("A greenhouse full of crates and items. It's possible you could use something from here.")
		button_if_not_held("Nails", "A box full of nails", "nails")
		button_if_not_held("Rakes", "Old school rakes", "rakes")
		button_if_not_held("Granade", "Energy sapping granade", "granade")
		button_if_not_held("Seeds", "Just some seeds", "seeds")
		if !("clothes" in picked_up_items):
			addButton("Clothes", "Various clothes to put on", "use_clothes")
		addButton("Apple", "Eat one of many apples laying on the ground", "eat_apple")
		addButton("Balcony", "Come back to the balcony", "main_green_corridor7")
		addButton("Mid-point", "Go west", "main_green_corridor11")
			
	if state == "stay_tentacles":
		playAnimation(StageScene.TentaclesSex, "sex", {pc="pc", npc="pc", bodyState={naked=true, hard=true}, plant=true, npcBodyState={naked=true, hard=true}})

		saynn("Deciding to embrace the tentacles instead of running away from them, against better judgment you approach them. They swish aggravated and the moment first ones emerge close enough to you, they wrap around your leg, then other limbs setting you in air like a trophy toy to play around with.")
		saynn("And play around they do, after taking hold of all of your limbs they swiftly take full control over your movements, your strength being no match to tentacle's iron grip.")
		saynn("Shortly after, their dexterous tentacles find places in your body to push through - namely - your anus and mouth, sliding in without much resistance. Thankfully for you, the tentacles are smooth, unlike the tree branches or irregular stalks of plants, meaning that instead of hurting, your body is rather experiencing rather pleasurable sensations. This doesn't change the fact that the tentacle in your mouth still has grassy taste that doesn't mix too well with the sickly sweet substance the tentacle emanates. If this continues, you'll likely be overwhelmed by the sensations really quickly.")
		if "herbicide" in hand_items:
			saynn("Soon enough, the tentacle in your ass jerks just enough for you to stun your body. This results in your paws dropping everything below. This includes a bottle of herbicides you had, which in its bad state breaks apart when it is hit by the tentacle mess below you. The shriek that followed was unreal, so loud, so alien. The tentacles momentarily withdrew somewhere else, leaving you laying on the ground.")
			addButton("Continue", "Stand up and see how to proceed", "tentacles_gone")
		else:
			addButton("Continue", "Let the plant have at it", "stay_tentacles2")
		
	if state == "tentacles_gone":
		saynn("You pick up your things, with exception of the herbicides which bottle of seemingly dissolved. After standing for a moment and finally catching your breath you look around. No tentacles in sight.")
		addButton("Continue", "", "main_green_corridor11")
		
	if state == "stay_tentacles2":
		playAnimation(StageScene.TentaclesSex, "fast", {pc="pc", npc="pc", bodyState={naked=true, hard=true}, plant=true, npcBodyState={naked=true, hard=true}})
		
		saynn("The plant makes a quick job of your mind, breaking it using a mix of sickly sweet substance coating your body from the outside and inside, that in turn gives you oddly warm sensation that further elevates the pleasure coming from your erogenous zones.")
		saynn("[say=pc]Ahhhh, fuckkk, fuuuuuck![/say]")
		saynn("Synapses firing constantly, your consciousnesses on the verge of saying good night, abundance of stimuli turning your gray matter into a putty. You don't even register as the ground below you opens up, as the tentacles slowly lower you, your {pc.feet} going below the ground into a hole filled with green, inviting tentacles. As you continue to be moved the last sight you register is Issix, standing up, with a smirk on his face, looking you over as you get wholly consumed by the ground. The moment your eyes reach the surface line, and your entire body now feeling nothing but writhing tentacles, you lose it, darkness envelops you.")
		addButton("Continue", "Continue", "wakey_scene")
		
	# CONT CELLBLOCK
			
	if state == "door_try":
		saynn("You come closer to the doors. They appear to be fairly sturdy, they would open outside, so if you were to go through them you'd have to push from where you are standing. Doors don't appear to have any signs of wear, looking very new.")
		
		saynn("You look at the knob, it's fiery – not just in appearance but also in temperature. Radiated heat hits the "+(Globals.getSkinWord() + " of your arm" if corruption_amount < 20 else " thick tar which covers your arm and somehow passes the sensation to your own nervous system")+ " as you come closer. You try to judge just how hot the knob is by covering over it with your paw. It becomes apparent that the heat is too much for you to touch the knob.")
		
		#saynn("Pulling and pushing when holding the knob in your paw only produces slightest sounds as the doors – apparently locked – jitter in frame. The knob doesn't turn in any direction, and ")
		
		addButtonWithChecks("Kick", "Attempt to kick the doors with your leg", "kick_door", [], [[ButtonChecks.StatCheck, Stat.Strength, 15], [ButtonChecks.StatCheck, Stat.Agility, 5]])
		
		if hand_items.find("water") != -1:
			addButton("Pour water", "You could try pouring water over the door knob to cool it down", "pour_water_knob")
		
		addButton("Back", "Look around the room again", "pre_room")
		
	if state == "pour_water_knob":
		saynn("You pour cold water over the door knob, the moment the stream of water touches the knob a loud sizzling sound can be heard and water evaporates in spontaneous expulsion of steam which takes you aback.")
		saynn("[say=pc]Woah.[/say]")
		
		saynn("The knob doesn't seem all that colder, and you still feel enormous heat coming off the knob. Was worth a try.")
		addButton("Back", "Look around the room again", "pre_room")
		
	if state == "kick_door":
		saynn("You take a few steps back, until you reach the table behind. From there you sprint towards the doors and at last second you raise your "+(" tar covered blackened {pc.feet}" if corruption_amount > 20 else "{pc.feet}")+" in the air and hit the target. Your leg and your body stops as entire momentum is consumed by barely budging doors. You make a few more attempts in place, however it soon becomes clear that the doors are too sturdy to yield to your assaults.")
		
		addButton("Back", "Look around the room again", "pre_room")
		
	if state == "water_dispenser":
		saynn("The water dispenser seems oddly spared from the tarry mess of your surroundings, water inside is clear – as it should be, small bubbles present sticking to the inside of installed the water tank.")
		saynn("The dispenser has two taps – one dispensing hot and another one cold water, marked with blue and red colors respectively. Very unsophisticated – but widely understood design. You could perhaps use the dispenser if you want.")
		addButton("Cold", "Pour water using cold tap", "cold_water")
		if hot_water_tried:
			addDisabledButton("Hot", "It's cold anyways")
		else:
			addButton("Hot", "Pour water using hot tap", "hot_water")
		addButton("Back", "Look around the room again", "pre_room")
		
	if state == "cold_water":
		saynn("You take the plastic cup from the stack attached to the side of the dispenser and put it right below the blue tap, while raising the control. Water pours out into your cup. ")
		addButton("Drink it", "Drink the water in a cup", "drink_water")
		if hand_items.size() > 0:
			addDisabledButton("Hold it", "Your paws are full")
		else:
			addButton("Hold it", "Keep to the water", "keep_water")
		addButton("Back", "Water dispenser, again", "water_dispenser")
		
	if state == "hot_water":
		saynn("You take the plastic cup from the stack attached to the side of the dispenser and put it right below the red tap, while raising the control. Water pours out into your cup. You expected the cup to get warm quickly from the hot water but this doesn't happen. After water fills the cup you check out the temperature but the water is cold. Water dispenser is not plugged to any socket so perhaps that makes sense.?")
		addButton("Drink it", "Drink the water in a cup", "drink_water")
		if hand_items.size() > 0:
			addDisabledButton("Hold it", "Your paws are full")
		else:
			addButton("Hold it", "Keep to the water", "keep_water")
		addButton("Back", "Water dispenser, again", "water_dispenser")
		
	if state == "drink_water":
		saynn("You drink some water, it's a regular water.")
		addButton("Continue", "Water dispenser, again", "water_dispenser")
		
	if state == "keep_water":
		saynn("You decide to hold the water in your paw for now.")
		addButton("Continue", "Water dispenser, again", "water_dispenser")
		
	if state == "hello":
		saynn("You hesitantly step towards the table in the center of „room”.")
		saynn("[say=pc]Hello? ...[/say]")
		saynn("[say=pc]Anyone here?[/say]")
		
		saynn("Eerie echo repeating your words answers you.")
		addButton("Back", "Look around the room again", "pre_room")
		
	if state == "sofa":
		saynn("You take a look at the yellow sofa in front of you. One part of it is almost fully covered in tar giving it glossy purple-black appearance, the other part shows its original yellow puffy material that covers the soft material inside. Regardless of tar, the sofa looks incredibly inviting, especially after the trip from the cellblock.")
		saynn("The part of sofa covered in tar looks almost living with the tar, it looks as if moving on its own - shifting dictated by slow motion. Light reflects off its smooth texture, quiet shlop sound comes from the tar mass as it mixes, breaks and connects.")
		if corruption_amount > 20:
			saynn("This entire spectacle watched in fascination by yourself. The tar substance is almost hypnotic. You could watch the tar for hours if it was in plasma lamp, and here it is on entire sofa, moving, squeezing around. Various naughty thoughts fill your head, how it would feel on your privates.")
		
		addButton("Sit", "Sit on the sofa, on the tar-less part of it", "sit_sofa")
		addButton("Back", "Look around the room again", "pre_room")
		
	if state == "sit_sofa":
		saynn("Feeling the need to rest you sit on the puffy sofa, right in yellow spot. Sure, there are some droplets of tar like substance around, but they are insignificant overall. Your body sinks into it considerably. You spread your arms around and relax, closing your eyes and taking a breath. It smells of wet cardboard and... Paint?")
		if corruption_amount > 1:
			saynn("If you wanted to spend here more time, and rest you could technically lay on the extra comfortable sofa, though there is not enough of space for that in the clean part of it, you'd have to utilize part that is covered in tar, which might not be as comfortable and... Safe.")
			addButton("Lay there", "You could lay there, though that would require you to occupy the space on the sofa filled with large amounts of tar", "lay_sofa")
		
		saynn("Or you could choose to simply sit back and relax, still being alert enough but letting your muscles take a small break, while you wait for... Something to happen.")
		if sofa:
			addDisabledButton("Sit", "You've already rested, there is determination in you to try and find some way to leave this place, more resting won't help you with this goal")
		else:
			addButton("Sit", "Stay there for a bit and recover stamina", "sit_sofa_2")
		addButton("Stand", "Stop relaxing, though, you didn't even start doing that!", "pre_room")
		
	if state == "sit_sofa_2":
		saynn("You continue to relax on the puffy sofa. You can faintly hear the slimy sounds on your right coming from the sofa, other than that there is background space station noise that you wouldn't be able to get rid of even in your dreams.")
		
		saynn("You let yourself close your eyes for a minute. Trying to process what even is going on everywhere around you, If this is a dream it's a very realistic one, one that you've never had the opportunity to experience before – sounds, touch and sight all contributing to realistic portrayal of reality, something unusual.")
		
		saynn("After short rest, a need to go forms in your head. It's time.")
		addButton("Stand up", "Finish resting on the sofa", "pre_room")
		
	if state == "lay_sofa":
		look_tf()
		saynn("There is a need for a comfortable rest within you, or perhaps you are being lulled into compliance by the strange tar on you, giving you ever so subliminal want to be embraced by even more tar. At this moment, you don't particularly care what's the reason. When the want to lay on the sofa appears in your mind, there is nothing to stop yourself from simply doing it.")
		saynn("Your "+("paws" if corruption_amount < 25 else "blackened paws")+" explore the sticky substance on the sofa, as you put arms to feel the darker side of the sofa and cushion your fall. The layer of tar on the sofa is significant, you guesstimate it to be around 1.5 centimeter based on how deep your paw fingers submerged.")
		if corruption_amount > 25:
			saynn("The existing tar that set on your paws passes the sticky sensations as if it wasn't there. Only solidifying the fact that it is the extension of your body, not a mere attachment or clothing. You lower yourself onto the mess, coating your arm and then front with tar. It pulls you into itself, the mass attaching to your "+Globals.getSkinWord() + ", increasing mass attached to you as if you were going straight into muddy quicksand.")
		else:
			saynn("New sensations flood your brain, the viscosity, the stickiness of tar in between of your paw fingers is... Almost alluring? There is something to it that makes you feel satisfied – moving fingers, pressing them against each other and feeling the slick and yet sticky texture. Makes you wish you've lowered your inhibitions a lot earlier and had some fun in mud or something else. The tar sticking to your "+Globals.getSkinWord() + ", increasing mass attached to you as if you were going straight into muddy quicksand.")
		
		saynn("[say=pc]Ahhh, [pulse color=#250a46 height=0.9 freq=0.6]so good[/pulse].[/say]")
		
		saynn("Your arms become coated with tar from one side until you lower your front and smush all that tar onto your body. Feeling it flow on your front. At times it feels as if snakes were passing through the thick tar underneath you, teasing you with their slithery body, though you quickly pass it as new sensations not related to acual living creatures in the tar. It does strike you as odd that the tar moves as if it was alive by itself, however that can't be true, right?")
			
		saynn("While your full front is now submerged in the thick tar, you still keep your head above the tar (after all, you doubt you could breathe through this), which quickly becomes a nuisance, and so it was only natural that you'd simply roll over to lay on your back, which you promptly do. With this, almost your entire body from head to {pc.toes} is covered in tar, pumping you with pleasurable sensations all over your body. And so you continues, laying on the sofa, covered entirely in thick layer of tar, which forms a layer across your body, filling in the gaps, claiming all the surface of your "+Globals.getSkinWord()+" for itself.")
		saynn("You stay in this blissful state, unaware of exact state of tar around you, overwhelmed by sensations of tar moving and teasing all parts of your body, rubbing you, touching you. In this blissful state, lulled into ignorance you almost don't notice how something alive is thrashing near your ears, waking you up only to state of awareness, not alertness, which to you feels unnecessary. There is nothing to worry in here, it's all good...")
		
		if corruption_amount < 50:
			addButton("Stand up", "There is no way you this isn't alarming to you, use all your muscles to leave the sofa", "stand_up_sofa")
			addButton("Ignore", "There is nothing to worry about, just continue laying in here, you need some rest after all", "continue_lay_sofa")
		else:
			saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Don't fret, I'm all the pleasure, I want to make you whole, to fade away all the pain. You NEED ME.[/pulse][/sayOther]")
			saynn("Everything this thing says is like a beautiful song to you, it makes perfect sense. You want the pleasure to continue, and they know just the way to do that, you just have to... Stay here, or at least, that's what you feel you have to do. You let your worries go and continue laying there, in the tar, as something approaches your ear.")
			addButton("Ignore", "Let them in", "continue_lay_sofa")
			addDisabledButton("Stand up", "You are too far gone, there isn't anything you can do")
			
	if state == "stand_up_sofa":
		saynn("In one go your entire body tenses and raises onto legs, bringing you into standing position. To another viewer it looked almost comical, but the reason for your urgent action was not born of humor to you. The pull of tar as you put all your muscles to work together in order to leave the sofa was significant, so was the amount you sunk into the puffy sofa as your limbs tried to find support needed to escape the gravitational pull towards comfortable sofa.")
		saynn("Looking again at the sofa, at first you feel nauseated, with dark spots appearing in your vision. Likely an effect of your sudden move taking away valuable oxygen from your brain, soon enough this feeling passes and what you see is... Nothing. The tar that was on the sofa seems to have already set to its previous state, leaving no evidence you just lied in it, in addition you can't find anything or anyone in place where you head was situated... Was it all just your imagination?")
		addButton("Continue", "That was... Odd...", "pre_room")
		
	if state == "continue_lay_sofa":
		look_tf()
		saynn("There is nothing that can possibly stop you from enjoying your well deserved break on the sofa. You simply stay as you were, huffing with pleasure. The feeling near your left ear now partially submerged under the tar did not disappear, instead it intensified until you feel something on the inside part of your ear. Something is clearly trying to get in and...")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Perfect. You'll do nicely.[/pulse][/sayOther]")
		saynn("... You let them in. And it felt good. As the slick worm went through your ear cavity, momentarily taking your ability to hear using that ear. Soon however, it was all fine and you felt something else, inside of your head.")
		saynn("Your arm jerks upward in one moment, your eyes open fully surprised by this development. You didn't do that, but you can control your arm again, you look at the slick tar covered arm.")
		saynn("[sayOther][pulse color=#250a46 height=0.9 freq=0.6]Limbs are tricky to work with. Pay it no mind. We still are not whole, you have a mission.[/pulse][/sayOther]")
		saynn("A voice rings inside of [ghost]your[/ghost] mind, it's cold, however each time it speaks immense pleasure radiates from [ghost]your[/ghost] head. [ghost]You[/ghost] want to hear its voice, but it won't come. And yet, without words exchanged, [ghost]you[/ghost] know you can't stay here. Laying on tarry sofa no longer brings [ghost]you[/ghost] pleasure. [ghost]You[/ghost] need to move.")
		saynn("Almost mechanically [ghost]you[/ghost] leave the sofa. By [ghost]your[/ghost] command still... Or was it?")
		addButton("Continue", "...", "pre_room")
		
		
	if state == "fountain_place":
		yield(slowWalk("petsdream_cellblock_nearcells"), "completed")
		GM.main.clearMessages()
		saynn("You approach the structure, it reveals to you more and more details with each step.")
		
		if getModuleFlag("IssixModule", "Azazel_Corruption_Scene", 0) > 4:
			saynn("You stare at the fountain in front, it is NOT the first time you see it. Last time it was in a... Dream? Whatever happened when Azazel drugged you. Natural conclusion you come to is that this is also a dream. Though, being conscious of this fact doesn't seem to help with waking up, and it feels more real than your usual dreams.")
			
			saynn("Similarly to the last time, the water in the fountain drops from the ceiling. A ring like shape with perfectly cut ring drain underneath. The pillar in the center is still there, though getting to it would require to sacrifice state of dryness you are in."+(" That, and it's unlikely you are going to be able to fully explore the pillar in this light." if not light else ""))
			
		else:
			saynn("The „Fountain” at the center is actually a stream of water dropping from the ceiling. A ring like shape with perfectly cut ring drain underneath. There seems to be something in the center of the ring, however you can't quite make what it may be through the distortion of body of water falling down. The „fountain” seems to be the only source of sound in vicinity, though light is very sparse.")

		addButton("Cross water", "Cross through the water", "cross_water")
		addButtonAt(6, "North", "Go north", "corridor_1")
		addButtonAt(10, "West", "Go west", "cellblock_orange_playercell")
		addButtonAt(11, "South", "Go south", "cellblock_pink_playercell")
		addButtonAt(12, "East", "Go east", "cellblock_red_playercell")
		
	if state == "cross_water":
		addButton("Go back", "Cross the water once again leaving the fountain", "fountain_place")
		if light:
			saynn("You cross the body of water in emerging on the other side. Your "+Globals.getSkinWord() + " " + Globals.skinIs() +" rather soaked. Water falls all around you and you can feel small droplets bouncing off the floor and hitting your legs.")
			saynn("The pillar is ordained by numerous symbols, none of which you understand.")
			if ResourceLoader.exists("res://Modules/FoxLib/Resources/NotoSansRunic-Regular.ttf"):
				sayn("[color=#ac1eff][runic]ᚹᚺᛖᚾ ᛟᚾᛖ ᚹᚨᚾᛏᛋ ᛏᛟ ᛗᚨᚾᛁᛈᚢᛚᚨᛏᛖ ᛏᚺᛖ ᛟᛏᚺᛖᚱ ᛏᚺᛖᚤ ᚲᚱᛖᚨᛏᛖ ᚨ [corrupt]---[/corrupt] ᛁᚾ ᛏᚺᛖ ᛗᛁᚾᛞ ᛟᚠ ᛏᚺᛖ ᛗᚨᚾᛁᛈᚢᛚᚨᛏᛖᛞ.[/runic][/color]")
				saynn("[color=#ac1eff][runic]ᛏᚺᛁᛋ [corrupt]---[/corrupt] ᚲᚨᚾᚾᛟᛏ ᛒᛖ ᚲᛚᛟᛋᛖᛞ, ᚨᚾᛞ ᚲᚨᚾ ᛒᛖ ᛖᛪᛈᛚᛟᛁᛏᛖᛞ ᛒᚤ ᛋᛟᛗᛖᛟᚾᛖ, ᛟᚱ ᛋᛟᛗᛖᛏᚺᛁᚾᚷ ᛖᛚᛋᛖ ᚹᛁᛏᚺ ᛏᚺᛁᚱᛋᛏ ᚠᛟᚱ ᚲᛟᚾᛏᚱᛟᛚ.[/runic][/color]")
				sayn("[color=#ac1eff][runic]ᛏᚺᛖ ᛏᚹᛟ ᛗᚨᚤ ᛋᛖᛖᛗ ᛋᚤᛗᛒᛁᛟᛏᛁᚲ, ᛟᚱ ᛖᚡᛖᚾ ᛏᚺᛖ ᛋᚨᛗᛖ.[/runic][/color]")
				sayn("[color=#ac1eff][runic]ᛒᚢᛏ ᛗᚨᚴᛖ ᚾᛟ ᛗᛁᛋᛏᚨᚴᛖ, ᛏᚺᛟᛋᛖ ᛏᚹᛟ ᚠᛟᚱᚲᛖᛋ ᚨᚱᛖ ᛞᚱᛁᚡᛖᚾ ᛒᚤ ᛏᚺᛖᛁᚱ ᛟᚹᚾ ᛞᛖᛋᛁᚱᛖᛋ.[/runic][/color]")
				saynn("[color=#ac1eff][runic]ᛏᚹᛟ ᚠᛟᚱᚲᛖᛋ, ᚹᛁᛏᚺ ᛟᚾᛖ ᚲᛟᛗᛗᛟᚾ ᛞᛖᛋᛁᚱᛖ ᛏᛟ ᚲᛟᚾᛏᚱᛟᛚ ᚨᚾᛞ ᚲᛟᚾᛩᚢᛖᚱ, ᚹᚨᚾᛏᛁᚾᚷ ᛏᚺᛖ ᚲᛟᚾᛏᚱᛟᛚ ᚠᛟᚱ ᛏᚺᛖᛗᛋᛖᛚᚡᛖᛋ.[/runic][/color]")
				sayn("[color=#ac1eff][runic]ᚤᛁᛖᛚᛞᛁᚾᚷ ᛏᛟ ᚨᚾᚤ ᛟᚠ ᛏᚺᛖᛗ ᛗᚨᚤ ᛋᛖᛖᛗ ᛏᛖᛗᛈᛏᛁᚾᚷ ᛒᚢᛏ [corrupt]------------------[/corrupt][/runic][/color]")
			else:
				saynn("Sadly, you can't make a shape of any of the symbols. An odd thought appears in your head as you try to concentrate on the code, which you should be able to see from this distance. That thought being „FoxLib”. But what is FoxLib? Why do you have that thought? Where does it come from? So many questions, so little answers. Perhaps the Fox that has been turned into Code can be turned back into fluffy Fox again some day.")
		else:
			saynn("You cross the body of water in relative darkness emerging on the other side. Your "+Globals.getSkinWord() + " " + Globals.skinIs() +" rather soaked. Water falls all around you and you can feel small droplets bouncing off the floor and hitting your legs.")
			saynn("At the center of „fountain” there is a pillar. You could tell there is something on it, but due to lack of lightning it's impossible to tell what.")
		
	if state == "push_yellow_button":
		if light:
			saynn("You push the yellow button. The red lights around become solid, no longer flashing. After few seconds the lamps above you light up, letting you see entire corridor without any issues.")
		else:
			saynn("You push the yellow button. The red lights around start flashing. After a second the lamps above you go dark, filling the corridor in darkness once again.")
		state = "cellblock_orange_playercell"
		
	if state == "cellblock_orange_playercell":
		yield(slowWalk("petsdream_cellblock_orange_playercell"), "completed")
		saynn("In a corner at the end of the corridor there is a table with headdress adorned with plumes as well as a leash.")
		
		if light:
			saynn("The yellow button is now easily visible thanks to the light. The lights around the yellow button no longer flash.")
		else:
			saynn("On the wall at the end of the corridor there is a yellow button, illuminated by flashing red but weak light.")
		addButton("Use button", "Push the yellow button", "push_yellow_button")
		addButtonAt(12, "Move", "Move towards the fountain", "fountain_place")
		
	if state == "hit_the_lever":
		if ventilators:
			saynn("You push the lever down until you hear sort of mechanism engage itself and quiet noise coming from behind you. You look behind but don't notice anything worrying.")
		else:
			saynn("You pull the lever up until you hear a click. It feels a bit quieter.")
		state = "cellblock_pink_playercell"
		
	if state == "cellblock_pink_playercell":
		yield(slowWalk("petsdream_cellblock_pink_playercell"), "completed")
		addButtonAt(6, "Move", "Move towards the fountain", "fountain_place")
		if light:
			saynn("In a corner at the end of the corridor there is a book titled „A Comprehensive Philosophy Explainer for Sluts: Explaining Ethics using Fetishes and Consent”, a cover presents a heavy duty collar, a whip and a diaper, you dare not to look into that book.")
			if not ventilators:
				saynn("There is a lever facing upwards right in the center of the wall. On its right there is a sign with image of a ventilator blade.")
			else:
				saynn("There is a lever facing downwards in the center of wall. On its right there is a sign with image of a ventilator blade.")
			addButton("Lever", "HIT THE LEVER!", "hit_the_lever")
				
		else:
			saynn("Not much is visible in relative darkness of hallway.")
			
		
	if state == "cellblock_red_playercell":
		yield(slowWalk("petsdream_cellblock_red_playercell"), "completed")
		if light:
			saynn("At the end of the corridor, right at the center of the wall a large metal shield is proudly displayed, decorated with a dog bone on its front. Right below, painted in red using a large paintbrush „YOU ARE NEXT”.")
			if getModuleFlag("IssixModule", "Azazel_Corruption_Scene", 0) > 4:
				saynn("Odd, since you know this isn't real, this warning. or perhaps a threat must be directed at... You. Or at least such is your conclusion.")
			saynn("If this wasn't creepy enough, on the ground lays a large canine shaped puppet, almost of size of a real anthropomorphic creature. Its clothing is torn apart, genitalia exposed. Turning it around reveals its back, which looks normal until you notice a puddle of fluid at height of its buttocks, a seemingly white-ish clear liquid is seeping from there.")
			saynn("Dread fills you.")
		else:
			saynn("Not much is visible in relative darkness of hallway, your legs hit something soft which looks to be a large puppet of some sort but you can't make out the details.")
		
		addButtonAt(10, "Move", "Move towards the fountain", "fountain_place")
		
	if state == "issix_fight_chased":
		saynn("Issix has caught up to you, {issix.his} clawed paws trying to get hold of you. You only have a short second before {issix.he} makes a quick job of your struggle.")
		for item in hand_items:
			if item in fight_items:
				addButton("Use: "+item, "Use item: "+item, "use_item_fight", [item])
		addButton("Attack", "Fight Issix", "fight_issix_attack")
		addButton("Escape", "Try to escape", "try_escape_issix")
		
	if state == "fight_issix_attack":
		playAnimation(StageScene.Rekt, "kill", {pc="issix", npc="pc"})

		saynn("The moment requires it and you feel ready. Standing up for yourself you prepare to fight back, putting fists in the air, looking at the dragon in contempt.")
		saynn("He looks at you, clearly enjoying the moment. It takes him one swift move of the arm to which you can't react fast enough before it grips your head.")
		saynn("[say=issix]Was a nice chase, prey. But you stood no chance. You are a weak peafowl, posing as a predator, but you are not one. Your display of power is just that – a display, but not one that induces fear in your opponents, bur rather a laugh.[/say]")
		saynn("[say=issix]Let's see what kind of creature I mold of you, will you still be this weakling taking advantage of others you are now, or will you be someone useful.[/say]")
		saynn("As you struggle, a heavy metal collar is attached to your neck, it weights heavily on the collarbone. You've been collared, and the second you feel it, all the strength leaves your body. The world slowly disappears and the last thing you see is Issix, with a grin, a devious grin.")
		addButton("Wake up", "Wake up", "wakey_scene")
		
	if state == "try_escape_issix_success":
		saynn("You attempt to escape from Issix by swiftly running towards one of {issix.his} sides. Your effort succeeds. Despite Issix's great form, you've caught the demon by surprise and his attempt to catch you was too slow.")
		saynn("[say=issix]Nice one. Won't be as easy next time.[/say]")
		saynn("„There won't be next time”, you think.")
		addButton("Run", "Run as far as possible", "run_to_safety")
		
	if state == "try_escape_issix_failure":
		playAnimation(StageScene.Rekt, "end", {pc="issix", npc="pc"})
		saynn("You attempt to escape from Issix by swiftly running towards one of {issix.his} sides, however the dragon is already well aware of your tricks, catching you with little effort. {issix.He} chuckles.")
		saynn("[say=issix]Not this time, my little prey. Not this time.[/say]")
		saynn("The sheer strength of a dragon sends you flying on your back, hitting the floor and immobilizing you as you lack breath. The terrorizing sound of steps approaches closer and closer until You can see kneeling figure right on your side. A red-black clawed paw of Issix holding a heavy heavy metal collar which {issix.he} brings closer to your neck.")
		saynn("[say=issix]And as such, a predator catches {issix.his} pray after futile struggle. Overpowered, the weakened animal now lays in submission, previously so assured of their own superiority over all, accountable to none, the alpha of the prison, reduced to a slave for the stronger.[/say]")
		saynn("You can't muster to feel angry. This feeling simply isn't there no matter how much you try to be. You slowly realize how right Issix is, and how little you can do about it now.")
		saynn("[say=issix]Isn't it poetic justice? ... You'll hurt no one now, I'll make sure of that.[/say]")
		saynn("A click is heard behind you, a cold feeling spreads from your throat where the heavy duty slave collar touches you, its heavy, its truthfully heavy. To call the collar secured to your neck adequate in limiting ones freedom is to say nothing. Removing this thing by brute force would be like trying to mine all of the resources on the rock you are imprisoned with a fucking spoon. Plastic one, at that. The collar is top of the class, and all you need to arrive at that conclusion is simply to feel it.")
		saynn("Issix stands up, smiling at your body, which doesn't have the strength to lift up. Darkness envelops your vision from the sides, as you lose consciousness. You hear last words before you are gone.")
		saynn("[say=issix]You'll be my toy forever.[/say]")
		addButton("Wake up", "Wake up", "wakey_scene")
		
	if state == "use_item_fight":
		saynn(fight_items[used_item][1])
		playAnimation(StageScene.Duo, "defeat", {pc="issix", npc="pc"})

		if fight_items[used_item][2] != null:
			saynn("[say=issix]"+fight_items[used_item][2]+"[/say]")
		if issix_stun > 0:
			addButton("Continue", "Decide where to go next while Issix is on the ground", find_safety_if_not())
		else:
			addButton("Continue", "Decide what to do next", "issix_fight_chased")
			
	if state == "wakey_scene":
		saynn("You open your eyes and see a familiar sight, the ceiling of your own cell. The familiar hum of the busy prison fills the scene around you. Just as you remember it, just as you got used to. You look towards the hallway, it's lit up and all normal, creatures are moving around, it's a new day.")
		saynn("It all sets in, it was all a dream, but this doesn't satisfy you. It was something more than just a dream. You know dreams, this wasn't one of those normal ones. This was something sinister, a warning, a travel to a plane of existence in between of dream and reality.")
		if getModuleFlag("IssixModule", "Dream_Chase_Ending", 0) == 6:
			saynn("You look at your body, it looks all normal now, no more sticky goo covering the body, no more voices in your head. Though it doesn't feel exactly the same as it was before the „dream”, something new is there, something sinister. As if echos of some new entity are reflecting from the walls. Something has changed.")
		addButton("Stand up", "Can't lay in bed all day", "endthescene")
			
		
	if show_items and hand_items:
		for item in hand_items:
			addButton("Drop: "+item, "Throw away "+item, "drop_item", [item, state])
		saynn("[i]You are currently holding the following: "+Util.join(hand_items, ", ")+".[/i]")
		
	if GM.pc.getStamina() > 1 and GM.pc.getStamina() < 20:
		saynn("[color=#FFA500]You are starting to feel exhausted.[/color]")
		
	if GM.pc.getStamina() < 1:
		saynn("[color=#aa0000]You are exhausted, your movement speed is now slower.[/color]")
		
	if !light:
		yield(darken(), "completed")
		
		
func saveData():
	var data = .saveData()

	data["light"] = light
	data["door"] = door
	data["dispenser"] = dispenser
	data["sofa"] = sofa
	data["hello"] = hello
	data["ventilators"] = ventilators
	data["cleared_the_air"] = cleared_the_air
	data["tracked_pos"] = tracked_pos
	data["last_stam"] = last_stam
	data["teleport"] = teleport
	data["corruption_amount"] = corruption_amount
	data["hot_water_tried"] = hot_water_tried
	data["hand_items"] = hand_items
	data["picked_up_items"] = picked_up_items
	data["issix_location"] = issix_location
	data["issix_stun"] = issix_stun
	data["chance_to_escape"] = chance_to_escape
	data["tentacles_aggro"] = tentacles_aggro
	data["placed_chair"] = placed_chair
	data["louver_removed"] = louver_removed
	data["response"] = response
	data["backup_restraints"] = backup_restraints
	data["backup_skindata"] = backup_skindata
	data["dropped_items"] = dropped_items
	data["used_item"] = used_item
	var neck_data = null
	if player_neck_item != null:
		neck_data = player_neck_item.saveData()
		neck_data["id"] = player_neck_item.id
	data["player_neck_item"] = neck_data

	return data

func loadData(data):
	.loadData(data)

	light = SAVE.loadVar(data, "light", false)
	ventilators = SAVE.loadVar(data, "ventilators", false)
	cleared_the_air = SAVE.loadVar(data, "cleared_the_air", false)
	tracked_pos = SAVE.loadVar(data, "tracked_pos", "")
	hot_water_tried = SAVE.loadVar(data, "hot_water_tried", false)
	door = SAVE.loadVar(data, "door", false)
	sofa = SAVE.loadVar(data, "sofa", false)
	dispenser = SAVE.loadVar(data, "dispenser", false)
	hello = SAVE.loadVar(data, "hello", false)
	last_stam = SAVE.loadVar(data, "last_stam", 100)
	teleport = SAVE.loadVar(data, "teleport", false)
	tentacles_aggro = SAVE.loadVar(data, "tentacles_aggro", false)
	placed_chair = SAVE.loadVar(data, "placed_chair", false)
	louver_removed = SAVE.loadVar(data, "louver_removed", false)
	response = SAVE.loadVar(data, "response", null)
	corruption_bar = GlobalRegistry.getModule("IssixModule").getBar("corruption")
	hand_items = SAVE.loadVar(data, "hand_items", [])
	picked_up_items = SAVE.loadVar(data, "picked_up_items", {})
	corruption_amount = SAVE.loadVar(data, "corruption_amount", 0)
	issix_location = SAVE.loadVar(data, "issix_location", "")
	issix_stun = SAVE.loadVar(data, "issix_stun", 0)
	chance_to_escape = SAVE.loadVar(data, "chance_to_escape", 100)
	backup_restraints = SAVE.loadVar(data, "backup_restraints", [])
	backup_skindata = SAVE.loadVar(data, "backup_skindata", {})
	dropped_items = SAVE.loadVar(data, "dropped_items", {})
	used_item = SAVE.loadVar(data, "used_item", null)
	var player_neck_item_partial = SAVE.loadVar(data, "player_neck_item", null)
	if player_neck_item_partial != null:
		player_neck_item = GlobalRegistry.createItem(player_neck_item_partial["id"])
		player_neck_item.loadData(player_neck_item_partial)
	pawn_visibility_fix()
	if corruption_bar != null:
		corruption_bar.setValue(corruption_amount)
		corruption_bar.visible = true

func getDevCommentary():
	return "This scene took ages to make! The idea is that it is player's dream forced upon by actual Issix pissed off a the player. Issix is wholly aware of the dream and participates in it. But there is also mysterious corruption that is something akin to super old hive... Things... The chase has multiple endings hopefully making the non-con route a bit more worth it."

func hasDevCommentary():
	return true
	
func slowWalk(target: String):
	# addMessage("You are moving...")
	playAnimation(StageScene.Solo, "walk", {pc="pc"})
	yield(get_tree(), "idle_frame")
	if !light:
		darken()
	var path = GM.world.calculatePath(tracked_pos, target)
	tracked_pos = target
	while path.size() > 0:
		var sloc = path.pop_front()
		aimCameraAndSetLocName(sloc)
		yield(get_tree().create_timer(0.5), "timeout")
		if !light:
			darken()
	# GM.main.clearMessages()
	
func slowWalkChase(target: String):
	if teleport:
		aimCameraAndSetLocName(target)
		GM.pc.setLocation(target)
		teleport = false
		tracked_pos = target
		yield(get_tree(), "idle_frame")
		GETREKTBDCC()
		yield(get_tree().create_timer(0.5), "timeout")
	elif tracked_pos == target:
		yield(get_tree(), "idle_frame")
		aimCameraAndSetLocName(target)
		GETREKTBDCC()
		yield(get_tree().create_timer(0.5), "timeout")
	else:
	# addMessage("You are moving...")
		yield(get_tree(), "idle_frame")
		GETREKTBDCC()
		var path = getPathAvoidingIssix(target)
		if path:
			path.pop_front()
		while path.size() > 0:
			var sloc = path.pop_front()
			aimCameraAndSetLocName(sloc)
			GM.pc.setLocation(sloc)
			playAnimation(StageScene.Solo, "jog" if !sloc.begins_with("fight") else "walk", {pc="pc"})
			var room = GM.world.getRoomByID(sloc)
			GM.world.pawns["pc"].moveToPos(room.global_position)
			tracked_pos = sloc
			if issix_location == sloc:
				enterIssixFight()
				break
			yield(get_tree().create_timer(0.5), "timeout")
			moveIssix()
			if issixShouldAttack(sloc):
				enterIssixFight()
				break
				
func GETREKTBDCC():
	# This function comes from the need of hooking stuff AFTER runCurrentScene runs
	# Sadly, BDCC doesn't make it easy, there is stuff happening after _run, and very little recourse on how to change that
	# So this is exploiting the fact we already utilize something that executes on first idle frame anyways and update the same shit ourselves
	pawn_visibility_fix()
	
func issixShouldAttack(pcPos: String):
	return issix_location == pcPos and issix_stun < 1
	
func enterIssixFight():
	setState("issix_fight_chased")
	
func getFCTileIds():
	var rooms = []
	for room in GM.world.cells["FightClubFloor"].values():
		rooms.append(room.roomID)
	return rooms
	
func darken():
	yield(get_tree(), "idle_frame")
	GM.world.setDarknessVisible(true)
	GM.world.setDarknessSize(15.0)
	
func moveIssix():
	if issix_stun > 0:
		issix_stun = issix_stun - 1
		return
	if corruption_amount > 80 and tracked_pos in getFCTileIds():  # TODO If pc pos is in fight club
		return
	var path = GM.world.calculatePath(issix_location, tracked_pos)
	if RNG.chance(75) or GM.pc.getStamina() < 1 or path.size() > 7:
		if path.size() > 1:
			issix_location = path[1]
			GM.main.IS.getPawn("issix").setLocation(issix_location)
			var room = GM.world.getRoomByID(issix_location)
			if !("issix" in GM.main.IS.pawns):
				GM.main.IS.spawnPawn("issix")
			if !(GM.world.pawns.has("issix")):
				GM.world.createWorldPawn("issix", GM.main.IS.getPawn("issix"), issix_location)
			GM.world.pawns["issix"].moveToPos(room.global_position)
			GM.world.pawns["issix"].loc = issix_location
	if dropped_items.has(issix_location):
		if "banana peel" in dropped_items[issix_location]:
			addMessage("You hear a loud noise of someone hitting the ground, could it be that your garbage displacement was more fruitful than you'd have imagined? If so... Praise banan.")
			issix_stun = issix_stun + 3
			dropped_items[issix_location].erase("banana peel")
		elif "nails" in dropped_items[issix_location]:
			addMessage("There is no movement for a while coming from behind you, could it be that the nails you've dropped on the ground slowed Issix down?")
			issix_stun = issix_stun + 3
			dropped_items[issix_location].erase("nails")
	if tracked_pos != "main_green_corridor11" and tentacles_aggro and "issix" in GM.main.IS.getPawnIDsNear("main_greenhouses", 3, 3.0) and !issix_location.begins_with("yard"):
		addMessage("You heard a loud scream and fight somewhere near the greenhouses, perhaps the tentacles met a worthy opponent?")
		issix_stun = issix_stun + 100
		tentacles_aggro = null

func getPathAvoidingIssix(target):
	var issixRoom = GM.world.getRoomByID(issix_location)
	var weight_scale = GM.world.astar.get_point_weight_scale(issixRoom.astarID)
	GM.world.astar.set_point_weight_scale(issixRoom.astarID, 8.0)
	var path = GM.world.calculatePath(tracked_pos, target)
	GM.world.astar.set_point_weight_scale(issixRoom.astarID, weight_scale)
	return path
	
	
func button_if_not_held(name, description, item_id):
	if picked_up_items.has(item_id):  # Item has been picked up
		pass
	elif hand_items.size() > 1 and not hand_items.has("plastic bag") and item_id != "plastic bag":
		addDisabledButton(name, "Your paws are occupied")
	elif "plastic bag" in hand_items and hand_items.size() > 4:
		addDisabledButton(name, "The plastic bag can't hold any more items")
	else:
		addButton(name, description, "pick_up_item", [item_id])

func supportsShowingPawns():
	return true
	
func pawn_visibility_fix():
	for pawnID in GM.world.pawns:
		var worldPawn:Node2D = GM.world.pawns[pawnID]
		worldPawn.visible = pawnID in ["issix", "pc"]
		if pawnID == "issix" and issix_stun > 0:
			worldPawn.setPawnActivityIcon(RoomStuff.PawnActivity.Unconscious)
		elif getState() == "issix_fight_chased" and pawnID in ["issix", "pc"]:
			worldPawn.setPawnActivityIcon(RoomStuff.PawnActivity.Fight)
		else:
			worldPawn.setPawnActivityIcon(null)
		
func spawn_issix_world_pawn():
	GM.main.IS.spawnPawn("issix")
	# GM.world.createWorldPawn("issix", pawn, "hall_elevator")

func exhaust_player(action):
	var exh = -1
	if action in ["hit_the_lever"]:
		exh = exh - 1
	if GM.pc.getStamina()-exh < 20 and GM.pc.getStamina() >= 20:
		addMessage("Your legs give in, you are becoming increasingly tired.")
	GM.pc.addStamina(exh)
	
func find_escape_room():
	var path = GM.world.calculatePath(tracked_pos, "main_punishment_spot")
	if path.size() > 1:
		for room in path:
			if room in all_available_rooms:
				return room
	else:
		path = GM.world.calculatePath(tracked_pos, "yard_corridor2")
		for room in path:
			if room in all_available_rooms:
				return room
	
	
func find_safety_if_not():
	if all_available_rooms.has(tracked_pos):
		return tracked_pos
	teleport = true
	return find_escape_room()
		

func change_corr(add_value: int, max_val = 99):
	update_parts(corruption_amount, corruption_amount + add_value)
	corruption_amount = clamp(corruption_amount + add_value, 0, max_val)
	if corruption_bar == null and Globals.ofModule("IssixModule").foxModuleAPI != null:
		corruption_bar = Globals.ofModule("IssixModule").registerBar("corruption", "Corruption", "#7700cc", 100)
		print("Registering Corruption Bar...")
		corruption_bar.visible = true
	if corruption_bar != null:
		corruption_bar.setValue(corruption_amount)
	else:
		addMessage("Your corruption increased to "+str(corruption_amount)+".")
		
func backupSkindata():
	var bodyparts = [BodypartSlot.Arms, BodypartSlot.Legs, BodypartSlot.Body, BodypartSlot.Tail, BodypartSlot.Head, BodypartSlot.Breasts, BodypartSlot.Ears]
	for bodypartSlot in bodyparts:
		var bodypart = GM.pc.getBodypart(bodypartSlot)
		if(bodypart == null):
			continue
		if(bodypart.supportsSkin()):
			backup_skindata[bodypartSlot] = bodypart.getSkinData()
		
func recoverSkindata():
	for bodypartSlot in backup_skindata.keys():
		var bodypart = GM.pc.getBodypart(bodypartSlot)
		if(bodypart == null):
			continue
		if(bodypart.supportsSkin()):
			bodypart.applySkinData(backup_skindata[bodypartSlot])
			
func backupRestraints():
	for restraint in GM.pc.getInventory().getEquippedRestraints():
		if restraint.isImportant():
			continue
		backup_restraints.append(restraint.getUniqueID())
		GM.pc.getInventory().unequipItem(restraint)
		
func recoverRestraints():
	for item in backup_restraints:
		GM.pc.getInventory().equipItem(GM.pc.getInventory().getItemByUniqueID(item))
		
func update_parts(old_value, new_value):
	if old_value < 20 and new_value >= 20:
		if GM.pc.getBodypart(BodypartSlot.Arms) != null and GM.pc.getBodypart(BodypartSlot.Arms).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Arms).applySkinData({"skin": "RunicSkin","r": Color("ff350629"),"g": Color("ff1f0010"),"b": Color("ff1c0016")})
		if GM.pc.getBodypart(BodypartSlot.Legs) != null and GM.pc.getBodypart(BodypartSlot.Legs).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Legs).applySkinData({"skin": "RunicSkin","r": Color("ff240f1f"),"g": Color("ff1f0010"),"b": Color("ff1e0317")})
	elif old_value < 50 and new_value >= 50:
		if GM.pc.getBodypart(BodypartSlot.Body) != null and GM.pc.getBodypart(BodypartSlot.Body).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Body).applySkinData({"skin": "RunicSkin","r": Color("ff1c0015"),"g": Color("ff2b0321"),"b": Color("ff1c0016")})
		if GM.pc.getBodypart(BodypartSlot.Tail) != null and GM.pc.getBodypart(BodypartSlot.Tail).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Tail).applySkinData({"skin": "RunicSkin","r": Color("ff300c27"),"g": Color("ff1f0010"),"b": Color("ff1c0016")})
		if GM.pc.getBodypart(BodypartSlot.Breasts) != null and GM.pc.getBodypart(BodypartSlot.Breasts).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Breasts).applySkinData({"skin": "RunicSkin","r": Color("ff310125"),"g": Color("ff2e0023"),"b": Color("ff1c0016")})
	elif old_value < 80 and new_value >= 80:
		if GM.pc.getBodypart(BodypartSlot.Ears) != null and GM.pc.getBodypart(BodypartSlot.Ears).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Ears).applySkinData({"skin": "RunicSkin","r": Color("ff1c0015"),"g": Color("ff1f0010"),"b": Color("ff3e0630")})
		if GM.pc.getBodypart(BodypartSlot.Head) != null and GM.pc.getBodypart(BodypartSlot.Head).supportsSkin():
			GM.pc.getBodypart(BodypartSlot.Head).applySkinData({"skin": "RunicSkin","r": Color("ff2e0023"),"g": Color("ff240f1f"),"b": Color("ff1c0016")})
		
func look_tf():
	if corruption_amount >=80:
		playAnimation(StageScene.TFLook, "head", {pc="pc"})
	elif corruption_amount >= 50:
		playAnimation(StageScene.TFLook, "crotch", {pc="pc"})
	elif corruption_amount >= 20:
		playAnimation(StageScene.TFLook, "hands", {pc="pc"})
		
# func cover_bodypart(bodypart: Bodypart):
# 	pass

func _react(_action: String, _args):
	exhaust_player(_action)
		
	if _action == "try_escape_issix":
		_action = "try_escape_issix_success" if RNG.chance(chance_to_escape) else "try_escape_issix_failure"
		chance_to_escape = chance_to_escape - 20
		
	if _action == "door_try":
		door = true
		
	if _action == "fight_issix_attack":
		setModuleFlag("IssixModule", "Dream_Chase_Ending", 3)
		GM.pc.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("inmatecollarslave"))
		
	if _action == "try_escape_issix_failure":
		setModuleFlag("IssixModule", "Dream_Chase_Ending", 3)
		GM.pc.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("inmatecollarslave"))
		
	if _action == "response_yield":
		setModuleFlag("IssixModule", "Dream_Chase_Ending", 2)
		GM.pc.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("inmatecollarslave"))
		
	if _action == "beach":
		setModuleFlag("IssixModule", "Dream_Chase_Ending", 4)
		
	if _action == "stay_tentacles2":
		setModuleFlag("IssixModule", "Dream_Chase_Ending", 6)
		
	if _action == "end_pod":
		change_corr(20, 100)
		setModuleFlag("IssixModule", "Dream_Chase_Ending", 1)
		
	if _action == "stack_a_chair":
		placed_chair = true
		hand_items.erase("chair")
		_action = "secret_place"
	
	if _action == "unscrew_the_frame":
		louver_removed = true
		_action = "ventilation"
		
	if _action == "climb_shaft":
		pass
		
	if _action == "vault_railing":
		teleport = true
		slowWalkChase("yard_vaulthere")
		
	if _action == "elevator_from_cells":
		GM.pc.setLocation("hall_checkpoint")
		tracked_pos = "hall_checkpoint"
		_action = "elevator"
		
	if _action == "elevator":
		pawn_visibility_fix()
		GM.main.IS.getPawn("issix").setLocation(issix_location)
		# issix_stun = 2
		
	if _action == "door_try_second":
		player_neck_item = GM.pc.getInventory().removeItemFromSlot(InventorySlot.Neck)
		
	if _action == "touch_goo":
		GM.pc.addLust(10)
		GM.pc.coverBodyWithFluid("CorruptiveTar", RNG.randf_range(100.0, 700.0))
		change_corr(8)
		
	if _action == "smear_tar":
		GM.pc.addLust(20)
		GM.pc.coverBodyWithFluid("CorruptiveTar", RNG.randf_range(800.0, 2000.0))
		change_corr(18)
		
	if _action == "tar_path":
		GM.pc.addLust(40)
		GM.pc.coverBodyWithFluid("CorruptiveTar", RNG.randf_range(1900.0, 2400.0))
		change_corr(30)
		
	# TODO If stamina hits 0 when going through corridor, let the player, stay, regain composure and get corrupted
	
	if _action == "response_run":
		response = _args[0]
		issix_location = "hall_elevator"
	
	if _action == "sit_sofa_2":
		GM.pc.addStamina(15)
		
	if _action == "run_to_safety":
		teleport = true
		_action = find_escape_room()
		aimCameraAndSetLocName(_action)
		GM.pc.setLocation(_action)
		tracked_pos = _action
		
	if _action == "tentacles_gone":
		tentacles_aggro = null
		hand_items.erase('herbicide')
		
	if _action == "use_clothes":
		picked_up_items["clothes"] = true
		GM.pc.getInventory().equipItem(GlobalRegistry.createItem("LeatherJacket"))
		_action = "main_greenhouses"
		
	if _action == "eat_apple":
		GM.pc.addStamina(40)
		moveIssix()
		_action = "issix_fight_chased" if issixShouldAttack(tracked_pos) else "main_greenhouses"
		
	if _action == "use_item_fight":
		if fight_items.has(_args[0]):
			used_item = _args[0]
			var damage = fight_items[used_item][0]
			issix_pain = issix_pain + damage
			issix_stun = issix_stun + int(damage / 5)
			hand_items.erase(used_item)
		
	if _action == "lay_sofa":
		GM.pc.addLust(50)
		GM.pc.coverBodyWithFluid("CorruptiveTar", RNG.randf_range(290.0, 340.0))
		change_corr(20)
		
	if _action == "cross_water":
		GM.pc.coverBodyWithFluid("Water", RNG.randf_range(290.0, 340.0))
		GM.pc.clearBodywritings()
		GM.pc.clearTallymarks()
		
	if _action == "continue_lay_sofa":
		GM.pc.addLust(50)
		GM.pc.coverBodyWithFluid("CorruptiveTar", RNG.randf_range(290.0, 340.0))
		change_corr(20)
		
	if _action in ["lay_sofa", "sit_sofa_2"]:
		sofa = true
	
	if _action == "hot_water":
		hot_water_tried = true
		
	if _action in ["cold_water", "hot_water"]:
		dispenser = true
		
	if _action == "drink_water":
		# var thebodypart = GM.pc.getBodypart(BodypartSlot.Head)  # Has terrible description in status effect so lets ignore this
		# thebodypart.addFluidOrifice("Water", 50.0)
		pass
	
	if _action == "keep_water":
		hand_items.append("water")
		
	if _action == "hello":
		hello = true
		
	if _action == "pour_water_knob":
		hand_items.erase("water")
		
	if _action == "drop_item":
		hand_items.erase(_args[0])
		if not dropped_items.has(tracked_pos):
			dropped_items[tracked_pos] = []
		dropped_items[tracked_pos].append(_args[0])
		addMessage("You've dropped "+_args[0].capitalize() + " on the ground")
		_action = _args[1]
		
	if _action == "push_yellow_button":
		light = !light
		
	if _action == "hit_the_lever":
		ventilators = !ventilators
		cleared_the_air = true
	
	if _action == "pick_up_item":
		var item = _args[0]
		addMessage("You've picked up "+item.capitalize())
		picked_up_items[item] = true
		hand_items.append(item)
		_action = tracked_pos
		
	if _action == "main_green_corridor11":
		if "decaying meat" in hand_items and tentacles_aggro == false:
			tentacles_aggro = true

	if(_action == "wakey_scene"):
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 4)
		setModuleFlag("IssixModule", "Quest_Wait_Another_Day", true)
		setModuleFlag("IssixModule", "Is_PC_Corrupted", corruption_amount)
		recoverSkindata()
		recoverRestraints()
		processTime(8*60)
		GM.main.IS.deletePawn("issix")
		GM.pc.setLocation(GM.pc.getCellLocation())
		if player_neck_item != null:
			GM.pc.getInventory().forceEquipRemoveOther(player_neck_item)
		if corruption_bar != null:
			corruption_bar.resetBar()
		GM.pc.getFluids().removeFluidType("CorruptiveTar")
			
	if _action == "endthescene":
		endScene()
		return

	setState(_action)

func getDebugActions():
	return [
		{
			"id": "emergencyClose",
			"name": "SAFELATCH",
			"args": [
			],
		},
	]
			
func doDebugAction(_id, _args = {}):
	if(_id == "emergencyClose"):
		if backup_skindata:
			recoverSkindata()
		if backup_restraints:
			recoverRestraints()
		if player_neck_item:
			GM.pc.getInventory().forceEquipRemoveOther(player_neck_item)
		GM.pc.setLocation(GM.pc.getCellLocation())
		endScene()
		return
