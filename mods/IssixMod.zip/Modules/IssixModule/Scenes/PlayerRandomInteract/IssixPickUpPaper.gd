extends SceneBase

# Start scene 3 days after first meet if player didn't start the quest
func _init():
	sceneID = "IssixPickUpPaper"

func _run():
	if(state == ""):
		saynn("You pick up the piece of paper. It seems to be some kind of an invitation, it reads:")
		saynn("[i]We've seen you.[/i]")
		saynn("[i]We have a common enemy.[/i]")
		saynn("[i]Meet us at dead end in the yard at 22. [s]bring booze!!![/s][/i]")
		saynn("Last part is barely visible due to scrawlings on top.")
		addButton("Take it", "Take the paper (starts a quest)", "accept_quest")
		addButton("Discard", "Discard the paper (abandons quest)", "discard")
		
	if state == "accept_quest":
		saynn("You take the piece of paper with you, making a mental note to appear there. The location is a bit vague, but you suppose it shouldn't be too difficult to find the dead end in the yard.")
		addButton("Continue", "", "endthescene")
		
	if state == "discard":
		saynn("You aren't interested in whatever this is, could be a trap.")
		addButton("Continue", "", "endthescene")

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false

func _react(_action: String, _args):
	
	if _action == "accept_quest":
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 5)
	
	if(_action == "endthescene"):
		endScene()
		return

	setState(_action)
