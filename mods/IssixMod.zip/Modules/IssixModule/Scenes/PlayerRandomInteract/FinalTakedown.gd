extends SceneBase

func _init():
	sceneID = "IssixFinalTakedown"

func resolveCustomCharacterName(_charID):
	if(_charID == "pawn1"):
		return "rowan"
	elif _charID == "pawn2":
		return "loxia"

func _run():
	if(state == ""):
		addCharacter("rowan")
		addCharacter("loxia")
		saynn("You arrive back at the discussed place. The two conspirators are already there.")
		saynn("[say=pawn1]Do you have it all?[/say]")
		saynn("{pawn1.He} unceremoniously {pawn1.verbS('welcome')} you.")
		saynn("[say=pc]I've got it all.[/say]")
		saynn("[say=pawn2]What a good {pc.boy}![/say]")
		saynn("[say=pawn1]We can start next phase then, we are taking {issix.him} down today.[/say]")
		saynn("[say=pc]Isn't it a bit too late for any taking down? It's almost cell time.[/say]")
		saynn("[say=pawn1]This is exactly what makes it the perfect time. Less creatures, staff is shuffling to go sleep if not already asleep. Issix's pets will go to sleep and have no reason to wonder where their master is, by the time anyone realizes it's morning and any traces leading to us will be much more difficult to find.[/say]")
		
		saynn("[say=pc]I guess if you put it this way...[/say]")
		addButton("Plan", "Let's go over the plan again", "plan")
		
	if state == "plan":
		
		saynn("[say=pc]Let's go again over the plan.[/say]")
		saynn("[say=pawn1]Yes, let's, we can't mess it up.[/say]")
		saynn("[say=pawn1]First you move into position. We've confirmed that the Medical Confessionary will be safe to work in around this time.[/say]")
		saynn("[say=pc]It's the room on the right after passing to med corridor on the right, right?[/say]")
		saynn("[say=pawn1]Right. "+("You'll wait there with the chemicals you grabbed from the medical." if getModuleFlag("IssixModule", "Random_Encounter_Scene") == 13 else "")+"[/say]")
		saynn("[say=pawn1]When we are sure you've had enough time to enter the Confessionary we'll lure {issix.him} out and separate {issix.him} from the pets.[/say]")
		saynn("[say=pc]And how will you do that?[/say]")
		saynn("[say=pawn1]We know a certain name from AlphaCorp that surely will grab {issix.his} attention, trust me, {issix.he} will want to see that person alone. Of course, they are not coming, but by the time they are near medical it will be too late.[/say]")
		saynn("[say=pc]And why would {issix.he} go to medical?[/say]")
		saynn("[say=pawn1]Because that person will be „visiting” Eliza.[/say]")
		saynn("[say=pc]Doesn't sound very believable.[/say]")
		saynn("[say=pawn1]It will be, trust me. When they step into corridor we'll have the time to grab {issix.him} and put {issix.him} to sleep. The gas should take effect within mere second and last for at least 4 hours. Even if {issix.he} struggles we can certainly hold {issix.him} for long enough to make {issix.him} sniff.[/say]")
		saynn("[say=pawn2]Yup![/say]")
		saynn("[say=pawn1]After that, it should be a short way to push them into the Confessionary and you do the magic.[/say]")
		saynn("[say=pc]You are not coming?[/say]")
		saynn("[say=pawn1]It's best for the mission if we stay at the entrance and make sure nobody enters it.[/say]")
		saynn("[say=pc]So you won't want to see {issix.him} get what {issix.he} deserves?[/say]")
		saynn("[say=pawn1]I'd love to, but no. Most important is that you are safe when doing that. I'll cherish the effects of our work after you leave the room. After that happens we all go our separate ways and not discuss what happened again.[/say]")
		saynn("[say=pc]We leave {issix.his} body there just like that?[/say]")
		if getModuleFlag("IssixModule", "Random_Encounter_Scene") == 13:
			saynn("[say=pawn1]It's fine if {issix.he} wakes up inside the Confessionary, {issix.he} will know nothing of who {issix.he} is or what {issix.he} did, the personality will be a blank slate, there will be no more Issix.[/say]")
		else:
			saynn("[say=pawn1]You wanted to kill {issix.him} amigo. If you want the cleanup feel free to do it alone. We've looked into spacing the body, however the security for vacuum doors is simply too high, not worth the effort. You can also leave {issix.him} there to be discovered by the staff, they will probably do some of their investigation or whatever, so you better not leave any traces.[/say]")
			saynn("[say=pawn1]I only hope you have something to end {issix.him} there.[/say]")
			if GM.pc.getInventory().hasItemID("Shiv") or GM.pc.getInventory().hasItemIDEquipped("Shiv"):
				saynn("[say=pc]This Shiv must do.[/say]")
				saynn("You show both of them a Shiv you have.")
				saynn("[say=pawn1]Good, good.[/say]")
			else:
				saynn("[say=pc]I'll figure something out. Shouldn't be difficult to do that in Confessionary.[/say]")
				saynn("[say=pawn1]Honestly, I preferred our solution but sure, it's your part of the job, don't mess it up or we all will pay.[/say]")
				saynn("[say=pc]I won't.[/say]")
				
		
		saynn("[say=pc]What about cameras?[/say]")
		saynn("[say=pawn2]I took care of them![/say]")
		saynn("[say=pc]What do you mean?[/say]")
		saynn("[say=pawn2]They will be temporarily disabled, I've made sure of it.[/say]")
		
		saynn("You ask them how, but they just smile at you.")
		addButton("Summary", "Summarize your task", "summarize")
		
	if state == "summarize":
		saynn("[say=pc]So, to summarize, I go to the Confessionary, hide there and wait for you to drop me Issix, "+("I drug {issix.him}" if getModuleFlag("IssixModule", "Random_Encounter_Scene") == 13 else "I kill {issix.him}")+", leave the room and we don't speak to each other again?[/say]")
		saynn("[say=pawn1]Precisely.[/say]")
		saynn("The entire plan doesn't sound very solid, but at the same time you've already put some time into this mission, being optimistic you nod.")
		saynn("[say=pawn1]Alright, if everything is clear, lets get a move on, all of this needs to be done within an hour, we can do it. {pc.Name}, you are first, go go go.[/say]")
		
		saynn("This enthusiastic chant is the last thing you hear from the two as you move towards the mission place.")
		addButton("Move", "Move towards the Medical Confessionary", "checkpoint" if GM.pc.getInventory().getItemsWithTag(ItemTag.Illegal).size() > 0 or GM.pc.getInventory().getEquippedItemsWithTag(ItemTag.Illegal).size() > 0 else "move")
		
	if state == "checkpoint":
		aimCameraAndSetLocName("hall_checkpoint")
		playAnimation(StageScene.Duo, "stand", {npc="cp_guard"})
		clearCharacter()
		addCharacter("cp_guard")
		saynn("[say=cp_guard]Stop, inmate. I'm going to frisk you yada yada.[/say]")
		saynn("A visibly tired checkpoint guard is on the verge of going asleep from the looks of it, and it would be very unfortunate if they were to frisk you right now, you are going to push them a little.")
		saynn("[say=pc]Ohhh, officer. I were just about to go to the medical as I've felt a bad cramp in my leg! Last time I've had this kind of cramp I had my leg paralyzed for an entire week, my friend said-[/say]")
		saynn("[say=cp_guard]Just go, ughhh.[/say]")
		saynn("If you kept going they'd likely simply doze off right there. Now your way is clear. On the way you can hear the guard murmur to themselves something about sleeping only 4 hours last night and expressing hope to finally sleep well enough this night.")
		addButton("Continue", "Enter elevator and go to Confessionary", "move")
		
	if state == "move":
		playAnimation(StageScene.Solo, "stand", {pc="pc"})
		aimCameraAndSetLocName("medical_confessionary")
		clearCharacter()
		saynn("You enter the elevator and the doors open in the medical wing. Half-sleepy nurses and guards do their final dances before they go to sleep. You utilize that carelessness to sneak into the Confessionary, which is thankfully open. Seeing no one there you step in and close the doors behind.")
		saynn("You likely have some time before the other two do their own task. So you rest for a bit and look around, thinking how best to finish yours.")
		if getModuleFlag("IssixModule", "Random_Encounter_Scene") == 13:
			saynn("You clutch your bottle of "+ getModuleFlag("IssixModule", "Chemicals_Chosen")+". It's actually not a bunch of pills, but rather a container with a liquid. Your best bet is that it is injected into the blood stream, so you promptly look for syringes around. And while you spot entire package of them, you also spot something even better. A universal medical chair. It's one of those do-all-kinds of things chairs, it does injections too in least painful way, after all, thanks to stabilizer shaky hands are an issue of the past with injections. You simply insert the vial with what you want, set the amount...")
			saynn("You realize, you have the vial from the failed experiment, but no idea how much should you inject! The amount can either be to little, just right or straight up kill the dragon.")
			saynn("[say=pc]Fuck.[/say]")
			saynn("That is, besides the fact that this particular vial was discarded for a reason. Oh well, no point in feeling bad about it now, you'll figure something out when the time comes.")
			saynn("Nervous, you clutch the vial in your paws awaiting the pair to drop the dragon in the Confessionary soon.")
		else:
			saynn("You walk from one end of the room to another. Waiting anxious for the signal, for the pair of shady inmates to come with demon-dragon hopefully in their arms limply hanging, sleeping.")
			saynn("Nervously a lot of different scenarios play out in your mind, as well as ideas on how to end dragon's life. You haven't got the chemicals but that was a shitty plan to begin with, no, your idea is a simpler one, a solid one.")
			if GM.pc.getInventory().hasItemID("Shiv") or GM.pc.getInventory().hasItemIDEquipped("Shiv"):
				saynn("Thankfully, you've got a Shiv with yourself, this will make this particular matter hopefully a lot smoother. If the duo do their job right, this will play out without a hitch.")
			else:
				saynn("You haven't prepared any sharp weapon with yourself, so you'll have to improvise. There are a lot of incredibly heavy objects around that you could use as blunt weapon to end incapable of defending {issix.himself} dragon's life. There are also syringes and various vials with unknown to you names around, probably if you mix them all and put their entire contents into the dragon that should do it.")
		
		saynn("As you were still thinking of how this will go down, you hear laughter and loud voices coming from behind the entrance. Spooked you hide behind one countless machines in the room.")
		addButton("Wait", "Wait for developments", "showtime")
		
	if state == "showtime":
		addCharacter("issix")
		saynn("The doors burst wide open as if kicked. Heavy sounds of hooves fill the room. You can tell something is not right. Have the two failed their job and led Issix right to you? If so, you are in grave danger.")
		saynn("[say=issix]Hello? Come on, I know you are here, and I know you were waiting here for me. So here I am![/say]")
		match getModuleFlag("IssixModule", "Dream_Chase_Ending", 0):
			4, 1:
				saynn("[say=issix]You might have escaped me last time, but this time we are in physical space. Don't be a rodent, show your ugly mug to me.[/say]")
			2, 3:
				saynn("[say=issix]I've caught you once and I'll do it again you worthless piece of shit. Show yourself, coward.[/say]")
			6:
				saynn("[say=issix]I'll assure you that this time it will be me who claims you, not the plant.[/say]")
		
		saynn("{issix.His} heavy hoove steps reverb entire room as {issix.he} walks around, your desire to look {issix.his} way is suppressed by sheer terror of possibly being spotted. Not that there is much of a choice in your situation, there isn't any escape route you can think of, maybe except running towards the doors when Issix leaves deeper into the room, but even that is rather unlikely to help in your situation, especially considering you hear noises from where the doors are, as if someone was right outside of the room. Perhaps accomplices?")
		addButton("Run", "Try to run out of the room", "run_room")
		addButton("Hide", "Continue hiding", "hide_room")
		addButton("Fight", "Attempt to fight the dragon", "attack_room")
		
	if state == "run_room":
		saynn("Perhaps doing a run for it feels like it gives you best chances of survival, for now. You place your {pc.feet} steadily on the ground, making sure that the moment you start running you'll fly off without an accident.")
		saynn("The thoughts in head race against each other, is it right time? Should you wait just a little longer for Issix to take another step? Or maybe he'll start approaching your hide'y hole? Finally, a thought wins over „Now or never”, in cacophony of tensing and relaxing your muscles work overtime to give you just the boost to the doorway so you are the first to reach them.")
		saynn("Time slows down. Your head looks to the right, the sight filling you with dread. There {issix.he} is. Just as you imagined {issix.him} with eyes of your imagination for past 20 seconds, but it's wrong. You barely left your hide hole and {issix.his} sight is already on you, as if {issix.he} knew, as if {issix.he} was just teasing you with not knowing where you are. The black eyes on an unsettling - happy face. The worst thing is - {issix.he} is already moving towards the doors. Inhuman reflexes, as if the demon knew the future a second earlier than you do. The fit cheetah chasing its pray as it did hundreds of time.")
		saynn("Another of your {pc.foot} hits the ground, the time still moves as if it didn't. Your brain gives you a verdict, a damning verdict - {issix.he} is closing in. Your paths will cross in two, maybe three more steps. {issix.He} is too close already, you're a goner.")
		saynn("There is no more time to do anything else. There is no other scenario than watch your own doom in slow motion. It's just then when it occurs to you that {issix.he} is holding something in one paw, something you recognize - it's the same mask, the same canisters as the ones you've snatched from the medical. {issix.He} has them. Somehow.")
		saynn("Another {pc.foot} hits the ground, {issix.he} is maybe two arm lengths away now, just one more step and it's over.")
		saynn("*stomp*")
		
		saynn("You feel your body cease to move as something strong grabs you by the should, iron grip, inescapable and commanding. For a moment, this culmination of events makes you dizzy and as your feeling of time returns to normal you open your eyes again.")
		saynn("A simple statement of fact leaves {issix.his} mouth.")
		saynn("[say=issix]Gotcha.[/say]")
		saynn("Your body, desperate for breath, being turned to face the demon dragon by force, takes a long breath, but something is wrong. This is not the air you are so accustomed to in the prison, the over filtered, recycled air filling entire prison. Only now you realize that somehow, on your face there is a mask, one that is filled with this sweet sweet flavored air. It's really sweet. You want more. And so you take another breath, the world becoming a blur.")
		saynn("[say=issix]It's okey now, just breathe, was a good...[/say]")
		saynn("The voice cuts off, it was enough, you are too sleepy now, nothing matters now, you just need to rest...")
		addButton("Wake up?", "Wake up", "wakeup")
		
	if state == "hide_room":
		saynn("Situation is intense enough, you freeze in place for now, hoping that your hide hole holds, hoping for that miracle {issix.he} is gonna stop looking and decide to leave.")
		saynn("[say=issix]My friends tell me you've been quite reliable. That's good. I like reliable. Here is to hope that after I'm done with you, you'll still be as reliable.[/say]")
		saynn("{issix.His} steps go to the opposite of the room. It's not particularly relieving that {issix.he} seems to be meticulous about the search, steps freezing in place every now and then while looking around and behind machinery and furniture. Soon enough {issix.he} moves to look under a small metal and intimidating device with a lot of needles sticking out of it. The worst part of that fact is that the device itself is only few meters away from you. You go breathless, you are sure {issix.he} is going to come where you are next.")
		saynn("Sound of approaching footstep. {issix.He} is coming. Step. Step. Time slows down, you cannot cram your body even further into the body of a large machine you are hiding behind.")
		saynn("His eyes meet yours, {issix.he} doesn't seem surprised, no, {issix.he} seems smirking. {issix.He} has you now. From {issix.his} perspective you are likely a terrified prey, now almost hyperventilating.")
		saynn("{issix.His} clawed paws come next, your left side {issix.he} simply drags you from behind the machinery that gave you temporary feeling of safety, you finally see {issix.him} in entirety. In other clawed paw {issix.he} holds something you remember seeing, it's the mask and two canisters of the gas, the very same you've brought to the two accomplices.")
		saynn("[say=issix]Having second thoughts? They will be your last.[/say]")
		saynn("Before you are able to protest a mast is pulled over your face, with a strong arm holding you by the back of your head and another one on pressing the mask onto your face you attempt to wriggle out of the grip to no avail. Trying not to breathe is difficult when doing physical effort to get away, soon enough you have no choice but to take a deep breath.")
		saynn("[say=issix]It's okey, just breath in. It will be over soon.[/say]")
		saynn("With this foreboding sentence - sleepiness hits you like a truck, you know it's not natural need to sleep, but regardless you are entirely powerless to resist it...")
		addButton("Wake up?", "Wake up", "wakeup")
		
	if state == "attack_room":
		saynn("Issix looks for you because {issix.he} wants to harm you. You've pissed {issix.him} off multiple times now, and if {issix.he} knows of the plan you had with the two that worked with you to get the gas and a mask – which {issix.he} likely does – you're sure {issix.he} isn't here for a snuggle session.")
		saynn("If you try to outrun the demonic dragon or continue hiding, the outcome is too predictable, and as such, you decide that resisting is worth a shot. Looking around doesn't spell good luck, there aren't any useful tools that could give you advantage.")
		if GM.pc.getInventory().hasItemID("Shiv") or GM.pc.getInventory().hasItemIDEquipped("Shiv"):
			saynn("What you do have, however, is the Shiv. Short range, but extremely effective. "+("It is what you wanted to do with Issix anyways, you'd rather {issix.he} be incapacitated, however desperate times call for desperate measures. " if getModuleFlag("IssixModule", "Random_Encounter_Scene") != 13 else "You didn't plan to kill Issix, however you are ready to defend yourself when threatened. ")+"With a shiv you stand at much greater chance of winning than without it. You clutch the shiv in your paw.")
		else:
			saynn("Having nothing to help you fight you are entirely dependent on the power of your own fists and will. You still dare not to look at Issix, so you don't fully know yet what you are facing, that's why you choose to wait for the right moment.")
		
		saynn("{issix.His} steps go to the opposite of the room. It's not particularly relieving that {issix.he} seems to be meticulous about the search, steps freezing in place every now and then while looking around and behind machinery and furniture. Soon enough {issix.he} moves to look under a small metal and intimidating device with a lot of needles sticking out of it. The worst part of that fact is that the device itself is only few meters away from you. You go breathless, you are sure {issix.he} is going to come where you are next.")
		saynn("Sound of approaching footstep. {issix.He} is coming. Step. Step. Time slows down, you cannot cram your body even further into the body of a large machine you are hiding behind. Time is right, you can feel {issix.him} right next to the machine you are hiding before. It's now or never.")
		addButton("Strike", "Attack the dragon", "strike_issix")
		
	if state == "strike_issix":
		if GM.pc.getInventory().hasItemID("Shiv") or GM.pc.getInventory().hasItemIDEquipped("Shiv"):
			saynn("Suddenly you spring into action, Shiv in your paw you swing it right where Issix stands, right where {issix.his} throat should be but right before it connects, your arm stops moving. Its grabbed by Issix's powerful arm, you try to wrestle it out of {issix.his} iron grip to no avail. {issix.He} is too strong. {issix.His} face smirking. Soon you drop the Shiv as Issix mangles your arm.")
		else:
			saynn("Suddenly you spring into action, your fist in motion on route to its target – the head. And right before it connects it stops, grabbed by Issix's powerful arm, you try to wrestle it out of {issix.his} iron grip to no avail. {issix.He} is too strong. {issix.His} face smirking.")
		saynn("You try your best to fight back, with other arm and your legs but each time the demon is one move before you, either avoiding or stopping your attacks. Only now you notice what {issix.he} holds in {issix.his} other paw – the mask and the canisters of gas you've handed to the two creatures before this operation started.")
		saynn("Your moves intensify but shortly after the mask finds its way to your face, covering the mouth and nostrils. As you realize the possible consequences your entire energy focuses on getting rid of it ASAP, ultimately, however, you are powerless to stop it. With much of energy lost fighting, you can only stop breathing for as log as your lungs allow you, which is not too long.")
		saynn("An oddly sweet gas makes it to your lungs as you take a deep breath, your face red from all the struggle, you see Issix, smiling at you as the darkness envelops your vision.")
		saynn("[say=issix]It's okey, just breathe now. It will all be over soon.[/say]")
		addButton("Wake up?", "Wake up", "wakeup")
		
		
func pawn1() -> BaseCharacter:
	return GlobalRegistry.getCharacter("rowan")
	
func pawn2() -> BaseCharacter:
	return GlobalRegistry.getCharacter("loxia")

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false
	
func transformPlayer():
	var chemical = getModuleFlag("IssixModule", "Chemicals_Chosen", "")
	match chemical:
		"81'm'80":
			GM.pc.setFemininity(100)
			var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
			if breasts == null or breasts.id == "malebreasts":
				var breasts_g = GlobalRegistry.createBodypart("humanbreasts")
				breasts_g.size = BreastsSize.I
				GM.pc.giveBodypartUnlessSame(breasts_g)
			elif breasts and breasts.getSize() < BreastsSize.I:
				breasts.setBreastSizeSafe(BreastsSize.I)
		"NULLX":
			GM.pc.removeBodypart(BodypartSlot.Penis)
			GM.pc.removeBodypart(BodypartSlot.Vagina)
		"8R006'm'0TH34":
			if GM.pc.getBodypart(BodypartSlot.Vagina) == null:
				GM.pc.giveBodypart(GlobalRegistry.createBodypart("vagina"))
			GM.pc.getSkillsHolder().addSkillExperience(Skill.Fertility, 1000)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityBellySize)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityBetterOvulation)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityBetterOvulationV2)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityBetterOvulationV3)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityBroodmother)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityDesireToBreed)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityMotherOfTheYear)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityPainTolerance)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilityProudMom)
			GM.pc.getSkillsHolder().addPerk(Perk.FertilitySubmissiveAndBreedable)
			var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
			if breasts == null or breasts.id == "malebreasts":
				var breasts_g = GlobalRegistry.createBodypart("humanbreasts")
				breasts_g.size = BreastsSize.D
				GM.pc.giveBodypartUnlessSame(breasts_g)
			elif breasts and breasts.getSize() < BreastsSize.D:
				breasts.setBreastSizeSafe(BreastsSize.D)
		"H1'm'80":
			GM.pc.setFemininity(0)


func _react_scene_end(_tag, _result):
	if _tag == "nonconned":
		endScene()
		return

func _react(_action: String, _args):
	processTime(RNG.randi_range(2, 5) * 60)
	
	if _action == "showtime":
		setModuleFlag("IssixModule", "Random_Encounter_Scene", 50)
		
	if _action == "wakeup":
		transformPlayer()
		runScene("NonconNonconScene", ["violence"], "nonconned")

	if(_action == "endthescene"):
		
		endScene()
		return

	setState(_action)
