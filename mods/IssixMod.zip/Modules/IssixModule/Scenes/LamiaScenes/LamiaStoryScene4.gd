extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var towel = false

func _init():
	sceneID = "LamiaStoryScene4"

func _initScene(_args = []):
	pass


func _run():
	
	if(state == ""):
		addCharacter("lamia")
		var days_since_last_feeding = GM.main.getDays() - getModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", 0)
		
		saynn("You notice "+str(days_since_last_feeding)+" fox figurines neatly stacked against each other on the edge of the blanket.")
		if days_since_last_feeding < 3:
			saynn("Figuring out that doing feeding earlier will help space them out and be less draining you signal to Lamia your willingness to let the parasite feed on you.")
		else:
			saynn("It's been a while since last feeding, you signal to Lamia your willingness to let the parasite feed on you.")
		
		saynn("He nods, stands up and takes you by your wrist pulling you with him, giving a sign to Hiisi, Hiisi raises and moves along with you two without any further comment.")
		addButton("Go", "Go with Lamia and Hiisi, see where they bring you.", "in_cell")
			
	if state == "in_cell":
		addCharacter("hiisi")
		aimCamera("cellblock_orange_nearcell")
		setLocationName("Issix's cell")
		playAnimation(StageScene.Duo, "walk", {pc="lamia", npc="pc", npcAction="walk", flipNPC=true})  # TODO Three people walking?
		
		if getModuleFlag("IssixModule", "Issix_Branded_PC", false) or GM.pc.hasPerk("Commands"):
			saynn("You are led to a cell you've already had opportunity to see before. Issix's tiny cell, with his hidden stash.")
			saynn("[say=pc]Here? Thought it would be more secluded place.[/say]")
			saynn("[say=hiisi]You are in for a surprise.[/say]")
		else:
			saynn("You are led to a cell in general cellblock. It's a relatively small cell with a bed, stash and stuff, looking mostly like essentials.")
			saynn("[say=pc]What's this place?[/say]")
			saynn("[say=hiisi]Master's cell.[/say]")
			saynn("It strikes you as strange, for this small place to be his cell. You expected something more... Grand.")
		saynn("Lamia approaches one of the corners on the opposite end from the entrance to the cell, kneels and puts his paw against the wall, feeling it for a moment until a clicking sound can be heard. Fox then invites you over with his arm, there isn't much space there, and you aren't sure why would his parasite feed in here, because this place is still visible from the hall but...")
		saynn("Then Lamia kneels and disappears in the wall? You can see that this disappearing act isn't really disappearing, he just enters some sort of hatch or something that reminds you of well hidden in plain sight dog doors. It's like a flap in the same color and very well fitted to a wall, that it looks just like the wall, but allows a person to crawl through it.")
		saynn("[say=pc]Woah, didn't know that was there.[/say]")
		saynn("[say=hiisi]Heh. Yeah. You can tell me about it later.[/say]")
		saynn("[say=pc]Have you been there? What's there? Are you coming?[/say]")
		saynn("[say=hiisi]Yes, I've been there. It's just a bigger room. And no, I'm going to watch you over until you get there. Don't want others to see it.[/say]")
		saynn("[say=pc]Ah. The feeding will probably take some time, you aren't going to stand there, right?[/say]")
		saynn("[say=hiisi]Of course not. I'm going to be back before you two are done.[/say]")
		saynn("[say=pc]So that's a... Bye for now?[/say]")
		saynn("[say=hiisi]See you later.[/say]")
		saynn("[say=pc]Yeah...[/say]")
		saynn("Fox's tail disappears in the „wall” and the hatch flops there a few times before coming to a still. You follow Lamia's lead and push the opening with your head as you move into the tight interior of a vent, it's around 3 meters long, enough to give you claustrophobic feeling,"+(" a feeling especially amplified by the fact you are pregnant and even if the belly isn't too big, it's bloated a little, which makes the movement in here especially troublesome. You" if GM.pc.isPregnant() else " you")+" can see pink bright colors coming through the other side as you crawl in, the flop stands still and you can hear a click, the exit is now shut off again and you can only crawl forwards.")
		addButton("Other side", "Crawl out of the vent", "secret_cell")
		
	if state == "secret_cell":
		aimCameraAndSetLocName("cellblock_orange_issixcell")
		removeCharacter("hiisi")
		playAnimation(StageScene.Nothing, "nothing", {pc="pc", npc="lamia", bodyState={naked=true, hard=true}, npcBodyState={naked=true, hard=true}})  # TODO No scene
		
		saynn("You emerge from the vent in a... rather pink looking room. Its size is 3 times of that small cell you crawled out of just a minute ago. The pink in shade of red rug on the floor is the first thing that you have the pleasure to come in contact with in the room. Its soft and incredibly pleasant to touch. On the left there is a bed covered by pink sheets with 4 different pillows on one side. Its size is enormous, compared to standard beds in cells. On the opposite end of the room is a screen of some sorts, though it's currently deactivated - being all black, below it is a drawer with a keyboard and some smaller devices you don't recognize. On the side of the room opposite to the vent you just crawled out is another drawer on top of which there are electronic frames displaying photos of... Issix's pets. You included. Unsure where the photo of your face got taken, but it certainly exists.")
		saynn("[say=pc]Woaaahhh. What is this place? It looks so... Fancy.[/say]")
		saynn("Lamia looks amused because of your comment. Thought it's not difficult for you to come to understanding that the room is Master's secret cell. It's in surprisingly good state for something secret, it's neat, organized and clean. On the ceiling there is bright light illuminating all sides of the room, along with what looks to be a security device of some sorts, or maybe utility like sprinklers in case of a fire? Difficult to tell. Standing up you continue to look at all of the details of this room, and there is a lot to take in.")
		saynn("[say=pc]Is this where Master normally sleeps?[/say]")
		saynn("Lamia shakes his head. It appears that Master sleeps in his cell, not to draw suspicion or for some other reason.")
		saynn("[say=pc]Hard to believe someone would pass on sleeping in such a bed.[/say]")
		saynn("Lamia sat on the bed for last 2 minutes as you were browsing the room, finally realizing the reason you are here.")
		saynn("[say=pc]Oh, sorry, you are probably waiting for me.[/say]")
		saynn("Lamia shows he doesn't mind, and then starts undressing his uniform.")
		saynn("You take the last look at the room before feeling the bed with your paw. It feels... Very comfortable. The mattress on the softer side, the cover sensually warm and incredibly pleasurable to touch, made with some kind of material you'd expect on expensive brothel beds. You sit, behind you Lamia without his uniform.")
		var torso = GM.pc.getInventory().getFirstItemThatCoversBodypart(BodypartSlot.Body)
		if torso != null:
			saynn("[say=pc]I assume I need to lose my "+torso.getVisibleName()+"?[/say]")
			saynn("Lamia nods.")
			if torso.isRestraint():
				if torso.getRestraintData() is RestraintUnremovable:
					saynn("[say=pc]Well, that might prove difficult... Is there a way around it?[/say]")
					saynn("You show Lamia, that your clothing is quite impossible to remove. Lamia thinks for a second before nodding.")
					
					saynn("[say=pc]I'll leave it to you then.[/say]")
				else:
					saynn("[say=pc]Well, I'll need some help with that, can you help?[/say]")
					saynn("Lamia helps you a bit with taking off "+torso.getVisibleName()+". Ultimately he is able to do it.")
					saynn("[say=pc]Thanks.[/say]")
		else:
			saynn("[say=pc]Heh, guess clothes won't be the problem in my case.[/say]")
			saynn("You point out lack of garments on your body. Lamia smiles and nods in agreement.")
		
		saynn("Lamia begins to lay on the bed. You still feel unsure about what to do, this being your first time, Lamia knows this and shows you to lay on your side next to him, your faces facing each other.")
		if GM.pc.getPersonality().getStat(PersonalityStat.Coward) > 0:
			saynn("[say=pc]Umm, haha. This feels strange.[/say]")
		else:
			saynn("[say=pc]Alright, what's next?[/say]")
			
		addButton("Next", "See what is next", "feeding")
		
	if state == "feeding":
		
		saynn("As you lay on your side, Lamia passes to you a sheet of paper that was laying nearby. It contains multiple panels explaining the feeding process. It was likely made just for you, considering the drawn figure looks very similar to you. You gather that the parasite is usually connecting with other body in stomach area, however in some special cases it doesn't have to be there. It usually takes around 2 hours, and creature being fed on may feel odd and weakened, something you already gathered by yourself based on what you've discussed with Master in the concessionary.")
		saynn("[say=pc]Sounds good to me. Though I wonder, why do it here and not in medical concessionary instead?[/say]")
		saynn("Lamia explains that since the feeding is pretty regular and time consuming, it wouldn't make sense to occupy rooms dedicated to medical branch of BDCC and this room is hidden enough to be comfortable. Something that is hard to disagree on.")
		saynn("[say=pc]Alright alright, yes, this makes a lot of sense. So, what now?[/say]")
		saynn("Fox morph leads your eyes to his own belly area, where a entrance, or exit for body of the parasite appears which is quickly replaced by the parasite itself slowly squirming out of his body. It's just as dark as you remember, countless amount of whiter „teeth” surround the open inky blackness in the center of extending tentacle, a momentary feeling of doubt fills you seeing this creature so close to your own body. You've shared your body with so many others in this prison, it's hard to call your body pure in any shape, but to let a parasitic creature take advantage of it? You do remember that you are doing it for Lamia but... ")
		saynn("You notice a large portion of the creature being out of Lamia's body, it contorts in all different directions as if happy to have the opportunity to be out for a bit.")
		saynn("Lamia moves his paw to the creature, wrapping its body in his paw as if he was massaging it. The size of the creature is large enough for it to be impossible for the vulpine to wrap around entire girth of the creature with a single paw.")
		saynn("[say=pc]It is kind of scary looking, though the longer I see it the less threatening it looks.[/say]")
		saynn("The creature brushes on your "+Globals.getSkinWord()+", leaving moist if not a little bit slimy smudges, in a way, it feels like tickling or playing with you.")
		saynn("[say=pc]Hah, stop it you little.[/say]")
		saynn("You say playfully. After a few minutes of this play Lamia looks at you expectantly.")
		saynn("[say=pc]Yeah... I'm ready when you are.[/say]")
		saynn("He nods and both of you look below as slowly, the parasite approaches your stomach area, a smaller black tentacle from the inside first makes contact with your "+Globals.getSkinWord()+".")
		saynn("[say=pc]Uahhh...[/say]")
		addButton("Feelings", "This feels so strange...", "feeding2")
		
	if state == "feeding2":
		
		saynn("Finally the end of parasite angles itself properly and puts pressure on your stomach area attaching itself to you, while you can definitely feel countless small teeth, they are rather flat and not painful at all. Feeling of discomfort from area where the parasite attached itself gives in to a feeling of numbness, feeling of warmness turns into slight chill coming from the place of contact slowly spreading outwards. Pace of your breath slows from its peak due to stress of new experience.")
		saynn("[say=pc]Huff. That's so odd and new. It feels kind of cold there? That's okey, right?[/say]")
		saynn("You look at Lamia who nods to you and puts one of his hands on your chin to straighten your head so you don't look back below at the parasite while spreading his arms outwards - one under you and one above bringing your bodies closer and basically hugging you in embrace. Feeling of warm body next to yours is certainly nice. The parasite seems to be attached quite well, as movement or removal of distance between two of you is not an issue for the parasitic organism.")
		saynn("The sincerity of fox's embrace cannot be denied. You can feel he is saying thanks for your willingness to help out, and probably for openness of mind you have, for whatever reason you've decided to do so.")
		saynn("Warm hug lasts for around half a minute before vulpine withdraws. He makes a sleepy gesture before laying his head on the pillow and closing eyes.")
		addButton("Continue", "", "feeding3")
		
	if state == "feeding3":
		saynn("And so you are, laying on your side with naked vulpine right next to you, falling into a nap while you feel a sucking sensation on your lower front caused by a parasite attached to your body, slowly taking away your blood and „life force” or whatever that is. It's undeniable that [i]something[/i] is happening as you can feel coldness spreading from the point of contact with the parasite reaching many distant places of your body. You feel tingling and occasional numbness on your stomach area.")
		saynn("What's weird, is that whenever you actually think about what you are doing, instead of fear, disgust or any other feelings you'd expect you feel... Comfort? You are helping a... Friend? Lamia is your friend, right? He is just a pet, your Master's pet, just like you are. It does make total sense for you to feel good about helping a friend.")
		
		yield(get_tree().create_timer(10.0), "timeout")
		
		saynn("[tornado radius=3.0 freq=1.5 connected=1][pulse color=#923aaa height=0.9 freq=1.0]So why.[/pulse][/tornado]")
		
		yield(get_tree().create_timer(2.0), "timeout")
		
		saynn("[tornado radius=3.0 freq=1.5 connected=1][pulse color=#823498 height=0.9 freq=1.0]Why do you feel like what you yearn for isn't only to help your friend,[/pulse][/tornado]")
		
		yield(get_tree().create_timer(2.0), "timeout")
		
		saynn("[tornado radius=3.0 freq=1.5 connected=1][pulse color=#612771 height=0.9 freq=1.0]but also to embrace a new one?[/pulse][/tornado]")
		
		yield(get_tree().create_timer(2.0), "timeout")
		
		addButton("More", "More", "feeding4")
		
	if state == "feeding4":
		saynn("You look below at black mass connecting your and Lamia's bodies. It pulsates. Rings appear on the part sank into your body, the rings slowly move towards the invisible part of Lamia's body, each getting smoother and smoother as more distance it travels until it disappears behind Lamia's belly.")
		
		yield(get_tree().create_timer(2.0), "timeout")
		
		saynn("Its as if it was taking you in in gulps. One.. Second.. Third.. Each looking the same, the light glistening on its slimy body as rings continue to appear regularly, deforming parasite's body. They are inevitable, like waves on the ocean.")
		
		yield(get_tree().create_timer(2.0), "timeout")
		
		saynn("You stare at them, mesmerized... Drifting apart...")
		
		yield(get_tree().create_timer(2.0), "timeout")
		addButton("Drop", "", "feeding_dream")
		# Globals.colorButton(0, Color.black)  # not entirely reliable
		
	if state == "feeding_dream":
		saynn("Darkness all around. There is no you, it's more like... You are nowhere? Asleep?")
		saynn("[color=black][ghost freq=1.0]Curious.[/ghost][/color]")
		saynn("A voice you don't know.")
		saynn("[color=black][ghost freq=1.0]Need.[/ghost][/color]")
		saynn("[color=black][ghost freq=1.0]Part. You..[/ghost][/color]")
		saynn("Echos of something or someone reverbs within nothingness.")
		saynn("[color=black][ghost freq=1.0]Accept.[/ghost][/color]")
		saynn("[color=black][ghost freq=1.0]Let us.[/ghost][/color]")
		saynn("You so much want to ask who is it but you can't.")
		saynn("[sayMale]{pc.name}...[/sayMale]")
		saynn("The voice distorts. Feeling of your body comes back but... Different.")
		addButton("Wake up", "Wake up", "after_feeding")
		
	if state == "after_feeding":
		saynn("You open your eyes, you are laying belly down before you look around. Lamia is getting clothed, you look below, no parasite to be found, the area where it was has clear evidence of it however – a ring of slime on your "+Globals.getSkinWord()+", with some of it making the bed sheets wet.")
		saynn("[say=pc]Umm, won't Master be angry at that?[/say]")
		saynn("Pointing at wet spot Lamia looks and waves it off, apparently not?")
		saynn("[say=pc]Alright, you know better... Umm, did I do everything right? Was it okey? I think I napped a bit too much.[/say]")
		saynn("The fox gives you a warm smile and thumbs up, also pointing the same question to you. You think for a moment, it was... Something new, and strange. There is a mix of feelings, some of them total opposites of each other. It was uncomfortable but then you felt comforted? It was warm but also cold? Right now? You feel drained, as if you just gave gallons of your own blood, there is also another feeling that you can't really put your finger on, but overall, you don't want to trouble the vulpine, and you reply with thumbs up as well, which makes Lamia happy.")
		addButton("Joke", "Joke to lighten the situation", "after_feeding_joke")
		addButton("Towel?", "Ask if there is a towel somewhere to clean up your "+Globals.getSkinWord(), "after_feeding_towel")
		
	if state == "after_feeding_joke":
		playAnimation(StageScene.Duo, "stand", {pc="lamia", npc="pc", npcAction="stand"})
		saynn("[say=pc]I could get fed on just to be in this room haha.[/say]")
		saynn("Lamia chuckles")
		saynn("[say=pc]No but seriously, it's... Pleasant, with nice pinky aesthetic, pleasant smell, fancy furniture and well... Calmness. Probably the only place in here to be undisturbed for longer.[/say]")
		saynn("Lamia nods to what you are saying.")
		saynn("[say=pc]Also a perfect place for hide and seek.[/say]")
		var torso = GM.pc.getInventory().getFirstItemThatCoversBodypart(BodypartSlot.Body)
		if torso != null and !(torso.isRestraint() and torso.getRestraintData() is RestraintUnremovable):
			saynn("You fix your clothing on yourself.")
		
		saynn("Lamia invites you to go first through the ventilation shaft which you do.")
		addButton("Leave", "Leave pink room", "back_in_issix_cell")
		
	if state == "after_feeding_towel":
		saynn("[say=pc]Got any towels here? Could use to clean some umm, slime?[/say]")
		saynn("Lamia approaches one of the drawers, pulls on the shelf and presents you with a dry towel which you use.")
		saynn("[say=pc]Thanks.[/say]")
		saynn("You try to give it back but Lamia gestures you should take it with you.")
		var torso = GM.pc.getInventory().getFirstItemThatCoversBodypart(BodypartSlot.Body)
		if torso != null and !(torso.isRestraint() and torso.getRestraintData() is RestraintUnremovable):
			saynn("You fix your clothing on yourself.")
		
		saynn("Lamia invites you to go first through the ventilation shaft which you do.")
		addButton("Leave", "Leave pink room", "back_in_issix_cell")
			
	if state == "back_in_issix_cell":
		aimCamera("cellblock_orange_nearcell")
		setLocationName("Issix's cell")
		addCharacter("hiisi")
		playAnimation(StageScene.Duo, "stand", {pc="hiisi", npc="pc", npcAction="stand"})
		saynn("As you crawl through the vent you hear a click in the metal flap before you, you push on it and it thankfully gives easily letting you leave.")
		saynn("Back on the other side you can see Hiisi surveying the cellblock. You crawl out of the shaft and brush off any dust you gathered through your crawl.")
		saynn("[say=pc]We are back. Uhhh, you didn't stand here all this time, right?[/say]")
		saynn("[say=hiisi]Of course not, I'm not stupid.[/say]")
		saynn("He retorted, sounding almost offended. Soon after, Lamia joins you.")
		saynn("[say=hiisi]Everything went fine?[/say]")
		saynn("[say=pc]Yeah.[/say]")
		saynn("[say=hiisi]Good. Glad to have someone else take that responsibility, Azazel is constantly pregnant and it falls onto me...[/say]")
		addButton("Empathetic", "Say how you feel for Hiisi and pledge help with helping Lamia from now on", "back_in_issix_cell_emp")
		addButton("Dismissive", "Mention you don't know whether you'll want to feed Lamia's parasite again", "back_in_issix_cell_dis")
		
	if state in ["back_in_issix_cell_emp", "back_in_issix_cell_dis"]:
		if state == "back_in_issix_cell_emp":
			saynn("[say=pc]Oh, most certainly. Happy to help out whenever I can.[/say]")
			saynn("Hiisi acknowledges your answer and directs you two to come back to the harem.")
			saynn("[say=hiisi]Okey, let's go back now.[/say]")
		elif state == "back_in_issix_cell_dis":
			saynn("[say=pc]Don't get used to that, don't think I'll be doing it again.[/say]")
			saynn("Hiisi's face gets annoyed, he faces away from you and stalks walking, retorting coldly.")
			saynn("[say=hiisi]Let's go.[/say]")
		
		saynn("[say=hiisi]And remember, no chatting about extra room.[/say]")
		saynn("You nod in silence as all of your start walking towards the corner"+(", you with your towel clutched in your paws." if towel else "."))
		addButton("Walk", "Continue walking towards the harem", "back_in_harem")
		
	if state == "back_in_harem":
		playAnimation(StageScene.Duo, "walk", {pc="hiisi", npc="pc", npcAction="walk", flipNPC=true})
		aimCamera("hall_ne_corner")
		setLocationName("Issix's corner")
		addCharacter("issix")
		saynn("The three of you finally reach your Master's harem, Hiisi and Lamia take their respective blankets as if nothing happened. Your Master, seeing you come back motions for you to get closer.")
		saynn("[say=issix]Everything went well on your first?[/say]")
		saynn("[say=pc]Yes, Master.[/say]")
		saynn("[say=issix]Splendid. I do expect you help out in the future with Lamia's little „problem”. It can be a chore, but he doesn't deserve to suffer.[/say]")
		saynn("You nod in agreement to Master.")
		if towel:
			saynn("[say=issix]I see you brought a towel, put it here, Hiisi will take it to laundry later.[/say]")
			saynn("Master points at basket with laundry. You do as you are told.")
		
		saynn("It seems you are dismissed.")
		addButton("End", "You've fed the little monster inside of Lamia, good job", "endthescene")
			
			
		

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false
	
func saveData():
	var data = .saveData()

	data["towel"] = towel

	return data

func loadData(data):
	.loadData(data)

	towel = SAVE.loadVar(data, "towel", false)


func _react(_action: String, _args):
	
	if _action == "":
		pass
		
	if _action == "after_feeding":
		processTime(Globals.calculateParasiteFeedingTime())
		GM.pc.addEffect("LifeEssenceDrained", [Globals.calculateParasiteEffectLength()])
		setModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", GM.main.getDays())
		Globals.increasePetAffection("lamia")
		GM.pc.addStamina(-200)
		increaseModuleFlag("IssixModule", "Lamias_Parasite_Fed_Times")
		
	if _action == "secret_cell":
		GM.world.getRoomByID("cellblock_orange_issixcell").visible = true
		processTime(15*60)
		
	if _action == "feeding":
		processTime(10*60)
		
	if _action == "feeding2":
		processTime(2*60)
		
	if _action == "feeding3":
		processTime(2*60)
		
	if _action == "feeding4":
		processTime(2*60)
		
	if _action == "feeding4":
		processTime(2*60)
		
	if _action == "feeding_dream":
		processTime(2*60)
		
	if _action == "after_feeding_towel":
		towel = true
		
	if _action == "back_in_issix_cell":
		GM.world.getRoomByID("cellblock_orange_issixcell").visible = false
		
	if _action == "in_cell":
		processTime(8*60)
		
	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Lamia_Encounter_scene", 5)
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	setState(_action)
