extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")
var solved_artworks = 0
var last_response = 0
var sum_responses = 0

func _init():
	sceneID = "LamiaStoryScene2"

func _initScene(_args = []):  # When coming into harem tile
	pass


func _run():
	
	if(state == ""):
		addCharacter("lamia")
		playAnimation(StageScene.Duo, "kneel", {pc="lamia", npcAction="kneel", npc="pc", bodyState={naked=false, hard=false}})
		saynn("[say=pc]I see you have some artwork stashed, let's do some sorting.[/say]")
		saynn("After all, this isn't your first rodeo, you've helped Lamia with sorting artwork in the past, you feel very fluent in art of artwork sorting at this point. Lamia nods but... This time Lamia pushes a pretty small stash of artwork towards yourself, signaling that those are the ones you are supposed to sort today. That's a first, and it slightly threw you off the track.")
		saynn("[say=pc]Huh? I mean, sure, I can do that....[/say]")
		saynn("First artwork shows a rug. On it - a metal plate with green peas, some potato puree and a bar of meat.")
		addButton("Blue box", "Put the artwork on top of others in the blue box", "next_artwork")
		addButton("Red box", "Put the artwork on top of others in the red box", "next_artwork")
		addButton("Green box", "Put the artwork on top of others in the green box", "next_artwork")
		addButton("Purple box", "Put the artwork on top of others in the purple box", "next_artwork")
		addButton("Explanation", "Try to remember the rules of categorizing Lamia's artwork", "explanation")

	if state == "explanation":
		saynn("You recall the following about Lamia's explanations:")
		saynn("The [color=blue]blue box[/color] is associated with PEOPLE, humanoids, anthropomorphic animals. If artwork features only a humanoid, or it has a feral animal along with humanoid, or the humanoid is drawn with a background - the artwork goes to this box.")
		saynn("The [color=red]red box[/color] is associated with feral animals and plants. If the artwork features only animal/plant or animal/plant and a background then it belongs in this box.")
		saynn("The [color=green]green box[/color] is for rather detailed backgrounds, though optionally artwork goes there if it has all of the elements - so animals/plants, humanoids as well as the background.")
		saynn("The [color=purple]purple box[/color] is for everything that doesn't fit in other boxes. Abstract art, simple text, figures or items.")
		addButton("Back", "Go back to categorizing art!", "")
		
	if state == "artwork2":
		saynn("You've categorized 1/8 artworks.")
		saynn("Next artwork you are presented with - a jar full of earthworms. While a still artwork cannot show them moving and wriggling about, the quality of the drawing is as usual for Lamia - very good, which makes it way easier to imagine this picture in reality.")
		saynn("You don't look directly at Lamia, but you can feel his undivided attention on your face. Today's sorting is certainly plenty unusual...")
		addButton("Quick", "Put it into red box quickly, you don't want to look at it", "next_artwork", [1])
		addButton("Normal", "Put it into the red box at regular pace, it's just another artwork", "next_artwork", [2])
		addButton("Slow", "Take a good look at the artwork and categorize it", "next_artwork", [3])

	if state == "artwork3":
		saynn("You've categorized 2/8 artworks.")
		saynn("The next artwork reveled to you depicts a view from inside of a building, with a window. The artwork is very dark, because even though it's clearly day outside, the light from the outside is completely blocked by innumerate small creatures with slug like body. There are easily dozens of those, and even though the window on the picture is wide, solid 90% of its surface is covered by slugs, the light can only enter into the building through small gaps not inhabited by bodies of slugs.")
		saynn("Lamia's gaze continues to linger on you, however you are trying to ignore it.")
		addButton("Interest", "This subject is interesting to you, and the portrayal of slug infestation is unique", "next_artwork", [3])
		addButton("Grimace", "Picture is inducing in you feeling of disgust, this slug infestation looks worrying", "next_artwork", [1])
		addButton("Shrug", "It's an interesting picture presenting unique kind of situation, but it needs to be categorized, right into the red box", "next_artwork", [2])
		
	if state == "artwork4":
		if last_response == 3:
			saynn("[say=pc]Wow, this is really interesting, gives me a feeling of apocalypse in a way.[/say]")
			saynn("Lamia smiles at you, taking your comment as praise")
		
		saynn("You've categorized 3/8 artworks.")
		saynn("The next artwork is a detailed sketch of centipede looking creature. It has long segmented body, with hundreds of little legs extending from the bottom of its body. A pair of antennae pushes out from its head, and what looks like a spiky stinger is part of its mouthpiece as well.")
		addButton("Detailed", "Say how detailed the artwork looks", "next_artwork", [2])
		addButton("Cute", "Say that you like how this creature looks like", "next_artwork", [3])
		addButton("Scary", "Mention how scary the creature looks, bugs do creep you out, and this one is huge", "next_artwork", [1])
		
	if state == "artwork5":
		match last_response:
			1:
				saynn("[say=pc]Damn, this one looks creepy. And its so large too.[/say]")
			2:
				saynn("[say=pc]Gotta admit, the detail in here is exquisite, you must have really spent a lot of time near this kind of creatures to study them huh?[/say]")
				saynn("You look at intrigued Lamia, who shrugs in response.")
				saynn("[say=pc]Oh well.[/say]")
			3:
				saynn("[say=pc]Awwww, how cuuute![/say]")
				saynn("Your squill makes Lamia chuckle, they are amused and... Happy?")
		saynn("You put the artwork into the red box again.")
		saynn("You've categorized 4/8 artworks.")
		saynn("The artwork beneath the one you've just categorized shows a dark slug. Arm length, thick as a bowling pin and judging by the glare of light covered in slippery mucus. On one end - its tail, the body simply gets thinner and thinner until it ends. On the other side however, a circular hole, inside barely visible due to an angle, but it looks very much like a dark void. Around the dark void, on the edges of circular hole - little white protrusions, flattened not spiky, very regular but with dark body tissue separating each one of them. Teeth perhaps?")
		saynn("You recognize the pattern in those artworks, it keeps repeating - bugs, sluggy creatures.")
		saynn("[say=pc]Woah. It's...[/say]")
		addButton("Pet!", "Mention that despite the look, you are sure the creature is friendly and you'd love to pet it", "next_artwork", [3])
		addButton("Analyze", "Bring your inner biologist and comment on looks of the depicted creature", "next_artwork", [2])
		addButton("Disgusting", "Call it what it is - a disgusting creature you want nothing to do with", "next_artwork", [1])
		
	if state == "artwork6":
		match last_response:
			1:
				saynn("[say=pc]Disgusting! Ewwww. Slimy and its... Mouth? Fuck, I'd puke if I ever were to see this creature on my own[/say]")
				saynn("You put the artwork into the red box again, glancing at Lamia while at it, their face hidden this time, they look away from you")
			2:
				saynn("[say=pc]How curious, I've never seen such a creature myself, are they part of your homeplanet? What kind of environment do they inhibit? Oh, I know, I know, must be some kind of humid jungle like environment am I right? And they feed on... Hmm. They look very much like from Hirudinea...[/say]")
				saynn("Lamia seems amused by torrent of your curious questions. His answers indicate that yes, this specific specimen is native to his home planet, and you were right about the environment.")
			3:
				saynn("[say=pc]Aaaaaaa, how adorable![/say]")
				saynn("At first Lamia doesn't know what to do with your answer, they seem rather confused, but a second later they burst out in laughter.")
				saynn("[say=pc]Huh? What's up Lamia? I just think that despite appearance, this creature is probably friendly and all of that. I'd happily hug it, I think.[/say]")
				saynn("After Lamia manages to calm down his laugh, he gives you a simple pet on the head, it's nice. Though they quickly become a bit more nervous as you put the artwork into correct box.")
				
		saynn("You've categorized 5/8 artworks.")
		
		saynn("The next artwork takes you aback. While previous artworks showed creatures - bugs, slugs and similar... This one shows the same creature as from previous artwork but... Appearing to come from belly area of anthropomorphic raccoon. Compared to previous artwork, around half of the body of the creature must be inside of the anthro, the „mouth” part is the one on the outside. Raccoon anthro meanwhile is simply standing, with rather happy face expression.")
		addButton("Hmm", "Stay rather neutral, look at the picture from scientific standpoint and try to say what you see", "next_artwork", [2])
		addButton("Give „look”", "Give Lamia the look of horror, have they really drawn this kind of horrible creature? What is this?", "next_artwork", [1])
		addButton("Like it", "Empathize that you really like the artwork", "next_artwork", [3])
		
	if state == "artwork7":
		match last_response:
			1:
				saynn("You look at Lamia with horror and disgust on your face, he looks at you, his eyes terrified of your judgment.")
				if sum_responses <= 6:
					saynn("He momentarily grabs the two artworks you were supposed to review and runs out with them somewhere. Hiisi giving a chase after Lamia. Maybe that was a bit too much for the fox?")
					saynn("You look around if someone seen the outburst, you see Azazel sighing and shaking his head without saying a word, their Master is busy talking with some inmate.")
					addButton("End", "That would be it for today's dose of helping...", "endthescene_early")
				else:
					saynn("Lamia hides his face in shame, only moving the artwork you were looking at along with other one underneath it, to one of the boxes.")
					saynn("[say=pc]I have to say, this one is particularly disg-[/say]")
					saynn("You were about to scold the fox, however you notice that the last artwork shows a singular beautifully orange flower, its petals unique - in almost hexagonal shape all around a purple circular center.")
					saynn("[say=pc]Well, I guess this one is fine.[/say]")
					addButton("Finish", "You move last artwork to the blue bin and be finished with helping Lamia for today", "summary")
				return
			2:
				saynn("[say=pc]Hmm. It really does look like this creature comes from stomach of the raccoon. This isn't a regular creature, but I've heard of some species in planetary systems that are parasitic in nature and basically integrate themselves into bodies of other larger than themselves creatures. Is that something you were basing it on?[/say]")
				saynn("Lamia thinks for a second and nods in agreement.")
				saynn("[say=pc]I see. I don't know much about those, I only read about them briefly. From scientific standpoint the relationship between the host and the parasitic creature is fascinating, but everything else about this situation is quite... Uncomfortable. Still, that's a very unique thing to depict, gonna give you that.[/say]")
				saynn("You put the artwork into the blue box.")
			3:
				saynn("[say=pc]Wow, that's... Pretty awesome! I've heard about those things, I think. They are parasitic organisms that integrate in body of their hosts. On one hand it's fairly fucked up but damn, I always wondered how does this feel like, and how one can even live with a giant parasite in their body![/say]")
				saynn("You say, maybe too excited considering the matter. before putting the artwork into a blue box. However Lamia looks positively surprised, listening to you and nodding along.")
		saynn("You've categorized 6/8 artworks.")
		saynn("The „pile” of artwork is no longe a pile, but rather lone two sheets of paper. Nevertheless, you've got last two artworks to help categorize, and this one pictures the same raccoon from earlier, characterized by unique fur pattern on side of their head. They are laying on what looks like an operating table in some kind of medical facility. There are two other blurry anthros somewhere in the background. Raccoon is covered by white bedspread and they seem to be conscious (as well as sad looking).")
		addButton("Curious", "Be curious about depicted scene", "next_artwork", [2])
		addButton("Compliment", "Point out few things you love about how it was drawn", "next_artwork", [3])
		addButton("Dismiss", "Say that you can't look at the raccoon again after seeing previous artwork", "next_artwork", [1])
		
	if state == "artwork8":
		match last_response:
			1:
				saynn("[say=pc]Can't look at that raccoon the same again. Infested scum. Disgusting.[/say]")
			2:
				saynn("[say=pc]Makes me wonder if this happens before or after last artwork, and what happened they ended up in hospital. Guess you ware not telling huh?[/say]")
				saynn("Lamia shakes his head.")
				saynn("[say=pc]Figure haha.[/say]")
			3:
				saynn("[say=pc]Wow, the way you depicted the raccoon, as well as pictured the environment of a hospital is so good. The lightning is superb, with it falling onto the raccoon giving hope for their recovery. Love it![/say]")
				saynn("Lamia blushes nodding.")
				saynn("[say=pc]Great job, great job.[/say]")
		saynn("You put the artwork into the green box.")
		
		saynn("You've categorized 7/8 artworks.")
		saynn("Last artwork there is shows a singular beautifully orange flower, its petals unique - in almost hexagonal shape all around a purple circular center. There are a few leaves visible, sticking out from the stem.")
		saynn("[say=pc]Hah, this one is easy.[/say]")
		saynn("You say as you put it into the red box, revealing the colors of blankets beneath the pile of artworks that once was.")
		addButton("Finish", "Finish the work for today", "summary")
		
	if state == "summary":
		saynn("[say=pc]Hah, that's all I guess. This batch was... Different, wasn't it?[/say]")
		saynn("Lamia looks abashed, it's quite clear that he wanted you to see those, but it was at the very least a strange experience. With him behaving the way he did and also giving you this artwork to sort.")
		if sum_responses <= 10:
			saynn("He dismisses you, collecting the boxes and stacking them together before they just... Lie on the blanket on their belly. That was it?")
		elif sum_responses <= 14:
			saynn("He gives you a smile and passes to you a single cookie for today's work. Now nice! He seems concerned about something, but you don't pursue that topic.")
		else:
			saynn("Lamia stacks together boxes of sorted artwork and hugs you with what you assume is all his might, because it's a hella squeezy hug. He seems oddly enthusiastic about something, and his other reward is apparently a cookie.")
		
		if !Globals.checkIfPCEnslaved():
			addMessage("Lamia's story can be continued after you join Issix's harem.")
		
		if sum_responses <= 10 and getModuleFlag("IssixModule", "QuestionnaireQ10", 1) > 2:
			saynn("[i]( Your responses indicate that you may not like graphic textual description of parasitic creatures, however previously you mentioned wanting to opt-in into this story mode, are you sure you want to continue with parasitism being enabled? )[/i]")
			addButton("Disable it", "Opt-out out of future parasite content entirely", "disable_parasite")
			addButton("Leave it", "Leave current settings are they are", "endthescene")
			addButton("Enable it", "Opt-in fully into parasite content in the future", "enable_parasite")
			return
		elif sum_responses >= 15 and getModuleFlag("IssixModule", "QuestionnaireQ10", 1) < 4:
			saynn("[i]( Your responses indicate that you may may like graphic textual description of parasitic creatures, however previously you mentioned wanting to opt-out out of them, are you sure you want to disable parasite content in the future? )[/i]")
			addButton("Disable it", "Opt-out out of future parasite content entirely", "disable_parasite")
			addButton("Leave it", "Leave current settings are they are", "endthescene")
			addButton("Enable it", "Opt-in fully into parasite content in the future", "enable_parasite")
			return
		
		addButton("Leave", "", "endthescene")
		
	if state == "disable_parasite":
		saynn("You've disabled parasite content.")
		addButton("Leave", "", "endthescene")
		
	if state == "enable_parasite":
		saynn("You've enabled all parasite content.")
		addButton("Leave", "", "endthescene")
		

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false
	
func saveData():
	var data = .saveData()

	data["last_response"] = last_response
	data["sum_responses"] = sum_responses

	return data

func loadData(data):
	.loadData(data)

	last_response = SAVE.loadVar(data, "last_response", 1)
	sum_responses = SAVE.loadVar(data, "sum_responses", 1)


func _react(_action: String, _args):
	if _action == "next_artwork":
		processTime(60)
		if _args and _args.size() > 0:
			last_response = _args[0]
			sum_responses += last_response
		solved_artworks += 1
		_action = "artwork"+str(solved_artworks+1)
		
	if _action == "enable_parasite":
		setModuleFlag("IssixModule", "QuestionnaireQ10", 4)
		
	if _action == "disable_parasite":
		setModuleFlag("IssixModule", "QuestionnaireQ10", 1)
		
	if _action == "summary":
		# Max: 18, Minimum: 6
		# We will split the difference into three groups
		# 6-10 - Person who didn't enjoy the parasite
		# 11-14 - Undecided
		# 15-18 - true deviant
		processTime(2*60)
		if sum_responses > 10:
			GM.pc.getInventory().addItemID("Cookie")
			addMessage("You've received one cookie")
	
	if _action == "endthescene_early":  # TODO Need to handle this case in this scene
		endScene()
		return

	if(_action == "endthescene"):
		# increaseModuleFlag("IssixModule", "Lamia_Times_Helped")
		setModuleFlag("IssixModule", "Lamia_Encounter_scene", 3)
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	setState(_action)
