extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")
var checked_parts := []

func _init():
	sceneID = "LamiaStoryScene3"

func _initScene(_args = []):
	pass


func _run():
	
	if(state == ""):
		addCharacter("lamia")
		addCharacter("issix")
		aimCameraAndSetLocName("hall_elevator")
		playAnimation(StageScene.Duo, "kneel", {npc="issix", npcAction="walk", flipNPC=true, bodyState={leashedBy="issix"}})
		saynn("You come into corner and begin to sit on your blanket before starting to do harem tasks. You spot your Master exchanging mysterious glances with Lamia, before Master asks you.")
		saynn("[say=issix]Pet, come with us. We need to talk.[/say]")
		saynn("Hiisi and Azazel, both in their usual place on the blankets give you a knowing look. It appears they are in the known of what's going on.")
		saynn("Issix leashes both you and Lamia and leads you though the halls to the elevator, you three enter it and luck have it, nobody else has entered the cargo elevator. Thoughts rush your head, did you do something wrong? Why you and Lamia? What's the purpose of such sudden ask?")
		saynn("[say=issix]I can see you are stressed, no need to be, pet. I just need a more... Secluded and silent place to talk with you about Lamia.[/say]")
		saynn("You glance at Lamia, he seem nervous, more nervous than you are, in fact. Troubled by something.")
		saynn("[say=pc]Is something wrong? Is Lamia... Hurt?[/say]")
		saynn("[say=issix]I'll answer your questions when we reach the confessionary. For now, be silent.[/say]")
		saynn("Master's serious tone doesn't feel you with confidence, and the atmosphere in the elevator seems... Tense and worrisome. What a day.")
		addButton("Continue", "", "medical")
		
	if state == "medical":
		aimCameraAndSetLocName("medical_confessionary")
		playAnimation(StageScene.Duo, "stand", {npc="issix", npcAction="stand"})
		saynn("You leave in medical wing. Issix talks to Eliza and gets permission to use the confessionary for an hour. You and Lamia are led there, after which Issix closes the doors and locks them.")
		saynn("[say=issix]I understand this might be overly stressful for both of you. I do want to stress that this secrecy is best way to approach what we will be talking about. I expect you, {pc.name} to not mention any topic we are going to talk about in public, with anyone. I want to be absolutely clear, this cannot become tomorrows gossip in the prison, and if it does, I'm willing to take unprecedented steps to hold you accountable. Do you understand?[/say]")
		saynn("Master unleashes both you and Lamia when speaking. Lamia goes to sit on the metal bed at the center, swaying his hanging legs back and forward.")
		saynn("[say=pc]Of course, Master. I understand.[/say]")
		saynn("[say=issix]Good.[/say]")
		saynn("Master looks at Lamia, as if asking for permission, Lamia responds with a subtle nod. Master sighs.")
		addButton("Listen", "Master has something to say", "explanation")
		
	if state == "explanation":
		if checked_parts.size() == 0:
			saynn("[say=issix]Lamia has... Certain condition, and he wanted me to tell you about it. He believes you are ready to hear it, and I agree. But I want to make it clear, that as my pet, I will not take kindly to any kind of bullying inside of harem. If what I'm about to say makes you think of Lamia any less than until now – we will have a problem. Lamia trusts you enough to share it with you, don't fuck it up, pet.[/say]")
			saynn("[say=issix]You see. You may already know, but Lamia comes from certain tribal planet Valp-, Vurp-? Ah fuck. The planet is inhabited by many tribes, but it also became part of AlphaCorp's territory, which is why he ended up in here. That is not this important however.[/say]")
			saynn("[say=issix]What is important, is that that planet in addition to many anthros is also rich in many many other diverse lifeforms that evolved through ages. Biologists claim that it was one of the few planets which life started on the earliest. I'm sure those egg-heads know what they are talking about, I've seen the reports from this planet, back in my time as I were in AlphaCorp the peace mis-, erm. colonizing it became a priority as soon as executives found out about it. All they care about are profits and goddamn „precious minerals”, motherfuckers...[/say]")
			saynn("He takes a breath.")
			saynn("[say=issix]Where were we? Ah, right, the nature. Lamia's tribe was, and probably still is...[/say]")
			saynn("He gives a look at Lamia, who has his head lowered down, feeling uncomfortable by the conversation with him in the spotlight.")
			saynn("[say=issix]Peculiar.[/say]")
			saynn("This wasn't the word he originally meant to say, it does feel like Master holds his tongue.")
			saynn("[say=issix]They believe that a way to get closer to nature was to literally take it in themselves, and I don't mean the medicine herbs stuff that Lamia does, even though that was a major part of their thing there. But I mean more take it into themselves in a more... Literally sense. They wanted to make nature part of themselves, or make themselves part of nature, I don't know.[/say]")
			saynn("You can feel Issix's disapproval in the tone.")
			saynn("[say=issix]It is customary in his tribe, for every creature turning adult to undergo a rite of passage. The rite of passage requires each member to become a host of a creature. They believe, that becoming a host creates a deep connection with the nature, as well as it deepens connection between tribesmen.[/say]")
			saynn("[say=issix]Scientifically accepted name for the species that they host is [i]Hirudo tenax infernalis gigantea[/i]. It's a lifeform that in many ways resembles a leech, and is generally considered a parasitic infestation to eradicate. The tribe Lamia was in was of different opinion, they see those lifeforms as their... How to put it... Soulmates.[/say]")
			saynn("Lamia looks at you two talking and nods along.")
			saynn("[say=issix]And before you freak out, I can assure you, you are safe. This kind of lifeform requires specific circumstances to infest, that unless you really want to, you won't find yourself in.[/say]")
			saynn("That's quite a lot to take in.")
		else:
			saynn("You can ask more questions.")
		addButton("Health", "Ask about health consequences of a parasite", "health_consequences", [-1])
		addButton("Pets", "Ask if Hiisi and Azazel know about this", "pets_know", [-1])
		addButton("Infestation?", "Ask how one gets infected with the parasite", "how_to_parasite", [-1])
		addButton("Remove?", "Ask if there is a way to remove the parasite", "remove_parasite", [-1])
		addButton("Lamia", "Ask Lamia how they feel about it today", "ask_lamia", [-1])
		addButton("Tribe", "Ask of tribal significance of those creatures", "tribal_significance", [-1])
		addButton("Sex drive", "Do those parasites... Kill sex drive?", "sex_drive", [-1])
		addButton("Hirudo...", "Ask more about those parasites", "hirudo", [-1])
		addButton("Master's opinion", "Ask Master about his opinion on the matter", "issix_opinion", [-1])
		if checked_parts.size() > 3:
			addButton("Continue", "Continue", "post_explanation")
		else:
			addDisabledButton("Continue", "You should probably first ask some questions")
		
	if state == "health_consequences":
		saynn("[say=pc]I imagine that hosting a [i]parasitic[/i] creature inside of you has its own consequences. What are those?[/say]")
		saynn("[say=issix]You aren't wrong. Those parasites are big, they can easily reach 10% to 20% of their host's body mass. And big body means that it also requires plenty of sustenance to stay alive. This specific parasite however, is a little bit different from many others. It is... Social. Those parasites generally prefer to feed on someone other than their host. It may seem weird, but this is unique biological development of this species.[/say]")
		saynn("[say=pc]On... Others?[/say]")
		saynn("[say=issix]Yes. While the parasite usually obtains around 40% of its monthly feed from the host, which in itself doesn't pose danger to the host, it encourages the host to seek others to share their blood and life essence. It then takes the rest 60% of monthly required feed from other creature – and it makes sense, the parasite wants a so to speak diverse diet. 60% is if host's parasite uses uninfected person's life essence. 60% is more than 40%, but whoever is getting fed on, will recover fully within a day or two, so it's usually not a big issue, unless you are already lacking some life force or blood for some reason. The most curious thing happens when person that is being fed on is another person infected with the same species. It turns out that when this happens only 10% of regular feed is acquired from given person but this satisfies the 60% of feed that would need to be acquired from the uninfected person. In other words, infected creatures are more efficient donors. This is also where the „social” part comes in. When the parasite feeds on another infected person, the two parasites communicate with each other. It has been shown that information exchanged by parasites of this species include information about environment, host's body and parasites status. Academic chatter also indicates there is more to that, however not something that has been proven.[/say]")
		saynn("[say=pc]I see... And, about my question?[/say]")
		saynn("[say=issix]Oh, right. I got off-track. This species even if dangerous, is incredibly fascinating as well. The danger occurs when the creature doesn't feed on another host for give or take 5 days. In that case, it will extract its feed entirely from its host, and this can have severe health effects – host will start feeling nausea, might vomit, look like death, in rare cases the parasite might even kill the host by taking too much. In general this is not something they want, because death of the host most often mean the death for the parasite itself as well, but there are documented cases of this occurring.[/say]")
		saynn("[say=pc]That's... Troubling...[/say]")
		saynn("[say=issix]And it isn't the end of it. From time to time parasite can produce certain substance that in most humanoid species cause strong abdominal pain, shivers and sometimes even blindness or hallucinations. All effects are temporary usually staying until the end of the day and the state doesn't pose serious danger to health, unless of course as a result of hallucination of blindness affected individual does something harmful to themselves... Speaking of which, you were already a witness to one of those episodes, right?[/say]")
		saynn("[say=pc]Master means the time I were filling a questionnaire?[/say]")
		saynn("[say=issix]Precisely.[/say]")
		saynn("[say=pc]I were.[/say]")
		saynn("[say=issix]Yes, I remember. You've had first paw experience seeing what happens then. We rushed to medical at once then. Thankfully, this happens very rarely. And the reasons for this dump of substances into host's body are still unknown.[/say]")
		addButton("Back", "", "explanation")
		
		
	if state == "pets_know":
		saynn("[say=pc]Uhh, do Azazel and Hiisi know about Lamia's condition?[/say]")
		saynn("[say=issix]Of course they do. They are part of this harem much longer than you are. Both of them assist Lamia with feeding from time to time, they empathize with Lamia and want least suffering for him.[/say]")
		saynn("[say=issix]Lamia uses a secret code to communicate how many days has it been since last feeding. You might have noticed fox figurines near their blanket. Their number is actually amount of days since last feeding. If the number gets near five either Hiisi or Azazel will know to... Volunteer themselves. Neat system, huh?[/say]")
		addButton("Back", "", "explanation")
		
	if state == "remove_parasite":
		saynn("[say=pc]Is there no way to remove the parasite?[/say]")
		saynn("[say=issix]I'm afraid there isn't. Even if Lamia wanted, which they don't, after ten days of parasite being inside of host's body, their integration with host's body reaches a point where separation of host and parasite is impossible. On technical terms, the integration goes so deep that the host becomes a completely new organism on its own, as a result of merging two creatures together, however for respect of hosts it is avoided to refer to them as if they were completely new species.[/say]")
		saynn("[say=issix]The parasite in many ways connects with internal body parts of their host. It becomes such an integral part of the organism that severing the two means death for both. Even with our current most advanced technology it's not possible to separate the two without death. Trust me, I did ask.[/say]")
		addButton("Back", "", "explanation")
		
	if state == "hirudo":
		saynn("[say=pc]Hiruho...[/say]")
		saynn("[say=issix]Hirudo tenax infernalis gigantea. If you ask me, the name is pretty on point.[/say]")
		saynn("[say=pc]Right... Anything more I should know about them?[/say]")
		saynn("[say=issix]Hmm. I guess one thing I haven't mentioned yet is how some researchers prefer to think of them more as symbiotic creatures than parasites. Not much on this is documented, however it is said that the parasite may help their hosts stay alive in life-threatening situations. Since the parasite integrates with the host so well, it becomes a sort of... Second pilot, so to speak. It doesn't connect with mind of their host, but to put it simply it may act as internal control panel for host's body. If they do, they always take the position of janitor fixing whatever is wrong, rather than influence their host to do their bidding. If you ask me, they just want to stay alive so of course they care to keep their host alive. But if the research on this proves true, and based on stories from Lamia's tribes I believe it will, it could mean that hosts will survive many medical emergencies that anyone else would die from without medical intervention. Internal organ failure, serious virus infections, bacterial infections, tissue damage, poison... Just imagine having a professional doctor inside of yourself, who monitors your health at all times and can do more than a real doctor from inside of you without any delay. Sure, it's creepy to have them inside of you, but they are clever and they know that survival of their host is paramount to theirs.[/say]")
		saynn("[say=pc]Huh. This does sound like invincibility, wouldn't rich people exploit it?[/say]")
		saynn("[say=issix]Research on those creatures is sparse, and all of the negative side-effects easily scare away most of the creatures. But you are right, it does sound like partial invincibility. They can't prevent your death in full, but they sure as hell can do a lot to help.[/say]")
		addButton("Back", "", "explanation")
		
	if state == "how_to_parasite":
		saynn("[say=pc]And how they reproduce? How does one become... Infected?[/say]")
		saynn("[say=issix]Those leeches are autogamous hermaphrodites – meaning they can self-fertilize and produce offspring without contact with others of their species. However in their case they can do that only as long as when being an adult of their species they've made contact with another adult of their species. They don't produce offspring unless they know there is a host nearby they can exploit. This usually happens when a host spends some time naked with another creature that can become a host of Hirudo tenax infernalis gigantea, some theorize they also require hormonal makeup usually associated with positive feelings for another creature in host's blood to produce offspring. They can feel when such contact occurs and after a few days the offspring will be ready for infestation. It is released only during the night, when host is asleep near the other vulnerable creature, since the offspring can't stay alive for too long outside of a body.[/say]")
		saynn("[say=issix]New host can be conscious, and in case of Lamia's tribe new hosts were often conscious while they allowed the parasite to... Enter their body, which occurs near the navel area. At first process is painless, however as the parasite integrates with all of the bodily organs hosts often report severe distress and pain. After 10 days after the parasite enters the body it completes its integration and becomes part of the host.[/say]")
		saynn("[say=pc]So, as long as nobody sleeps near Lamia... Naked, there is no risk of infection?[/say]")
		saynn("[say=issix]None. This is why this parasite is only known to infest feral mammals and... Willing anthros. It is of little concern to medical world because of it, even though hosts are considered patients in need of occasional help.[/say]")
		addButton("...", "Why does it sound so hot...", "can_i_owo")
		addButton("Back", "", "explanation")
		
	if state == "can_i_owo":
		saynn("Your cheeks get red, your head going down from embarrassment. Thinking of sleeping next to Lamia, naked, by sheer accident, for few nights in a row... Thinking of those „parasites” in way that would make many wince from sheer thought of letting them anywhere near their bodies.")
		saynn("[say=issix]*sigh* I'm cursed to know this body language. My explanation made you feel something, did it?[/say]")
		saynn("[say=issix]Don't bother answering. I can see it with my own eyes. Ehhh. Pet, you are a lost cause. If after description of pain and suffering your reaction is „damn, it's hot, I want it in me”, then I don't really know what to tell you, I don't feel rational arguments will work here. But if you really want it, help Lamia with their feeding problem few times, if they feel like sharing their... Guest... Then I won't stand in your way, even though I think that's stupid.[/say]")
		saynn("[say=pc]T-thank you M-master![/say]")
		saynn("He just sighs again.")
		addButton("Back", "", "explanation")
		
	if state == "sex_drive":
		saynn("[say=pc]Do those parasites kill any want to have... Sex?[/say]")
		saynn("[say=issix]Not from what I'm aware. If you are referring to Lamia's choice to avoid sex related things it's their personal thing, not a result of a parasite.[/say]")
		addButton("Back", "", "explanation")
		
	if state == "ask_lamia":
		saynn("You approach Lamia sitting on the bed.")
		saynn("[say=pc]Umm, I've heard from Master, but I wanted to ask you personally, how do you feel with... It in you?[/say]")
		saynn("Lamia puts his chin in his paw falling into deep thinking. He shows with his arms lulling like gesture.")
		saynn("[say=pc]Child? It is like a child to you? Hmm. Someone as important? I see.[/say]")
		saynn("It appears that Lamia thinks of the parasite in them more as someone to care for, as someone to... Love? You doubt you will get more specific than that, the connection between Lamia and that creature feels emotional in nature.")
		saynn("[say=pc]Just to make it clear? You... Like it?[/say]")
		saynn("Lamia nods in agreement, he smiles.")
		saynn("[say=pc]I see... Thank you.[/say]")
		addButton("Back", "", "explanation")
		
	if state == "tribal_significance":
		saynn("[say=pc]May I ask, what was significance of the parasite inside of Lamia's tribe?[/say]")
		saynn("[say=issix]That's a great question. One that... I were interested in as well. I've compiled some most important bits from research of scholars who research unique tribes like the one Lamia is part of.[/say]")
		saynn("He does a few clicks on the tablet he took with himself.")
		saynn("[say=issix]Take a look.[/say]")
		saynn("Mated screen of a tablet shows you a compiled dataset about the parasite inside of Lamia's tribe.")
		addButton("Legends", "Read about early history of tribe's connection with the parasite", "tribe_legends", [-1])
		addButton("Modern", "Read about modern understanding of the parasite by the tribe", "tribe_modern", [-1])
		addButton("Back", "", "explanation")
		
	if state == "tribe_legends":
		saynn("It's scholar's article about earliest mentions of the parasite in Lamia's tribe. Apparently the parasites weren't part of planet's ecosystem in earliest records of tribe's existence.")
		saynn("The article goes to say that when the parasites were first discovered by the tribe they were considered as negative forces to be eradicated. Tribesman were trying to destroy the perceived threat, seeing it infect countless mammals, it was considered as offense to the nature itself, a corruption to the world.")
		saynn("Many drawings accompany the fight against those negative forces, with creatures spearing and destroying the worm like creatures, in heroic poses standing on top of the mountains.")
		saynn("It later mentions that eradicating those forces was taking a heavy toll on nature around the tribe, some species stopped coming near the tribe entirely, many animals were killed in the name of eradicating the negative force of the worms. Tribesman began doubting whether this was the right recourse - to continue killing the creatures bearing the parasite in them.")
		saynn("A significant shift occurred after tribe elder's daughter got infected with the parasite. Old stories say that she always disagreed with how those parasites were perceived. She was disappearing from the village for days, until one day she has announced that she herself now hosts one of the parasites, and if the killing really is necessary, she will let the hunters make a quick job with her.")
		saynn("This had not happened, however. While disapproval of her actions filled both her father as well as rest of the tribe, she was spared from death. After a while, killing of feral animals hosting the parasites stopped as well. Tribal creatures continued to be wary of the parasites, but seeing elder's daughter living well had an effect on them.")
		saynn("In the following years she regularly left the tribe for few hours. Tribe creatures gossiped, and they knew she was feeding her parasite on other infected animals when away from the tribe. It filled many with disgust, some of them were raising concerns with village council of elders to exile her, they said she didn't belong and she had the mark of bad forces.")
		saynn("However despite that, the elders didn't exile her, she was watched, yes, but elders reached a conclusion she wasn't a threat. Things were fairly stable until at one point a terrible plague has spread in the tribe, sending entire tribe to beds. Terrible nausea, vomit, tiredness, pain. The only creature who wasn't affected was elder's daughter. She has tended to the sick, bringing them water, food in their most difficult times. Naturally, the fact she was the only one standing in face of plague raised suspicion, but her kindness and incredible dedication to reach every tribe creature with necessary care earned her the gratitude from many of those affected by the plague.")
		saynn("Nobody has died due to the plague, and the symptoms of strange plague have disappeared as fast as they appeared. The prejudice against elder's daughter have mostly stopped at that point. In the following years the tribe became aware of various ways that parasite hosts recovered quicker from or never fell to many different medical conditions. Tribe's awareness of various qualities of those parasites increased with each coming year, and the worry about them had faded away.")
		saynn("A true head scratcher to the scholars however, is how the parasites become such an integral part of the tribe to the point where each tribe creature became a host to the parasite. While there are records before that event and after, but there is nothing in the records or memory of tribe creatures about how the entire tribe made and embraced this pivotal change.")
		addButton("Back", "", "tribal_significance")
		
	if state == "tribe_modern":
		saynn("This appears to be scholar's dissertation on historical, social and technological parts of the entire tribe itself. You skip to section on parasites. Article is filled to the brim with exotic, pompous, difficult scientific vocabulary, thankfully you understand the most of it, even if reading takes a while longer than it usually would have.")
		
		saynn("The article analyzes cultural impact of parasites in tribe's society. It points out how parasites became integral part of lives, citing statistics on how many creatures give parasites they host names, how parasites are significant in social gatherings, where hosts let them „mingle” by allowing physical contact between parasites of multiple hosts. Tribe creates many memorabilia depicting likeness of Hirudo tenax infernalis gigantea – statues, figures, paintings, holorecordings including sexual objects like phallic toys or fleshlights. There are pictures of clothes specifically made to have holes around the stomach area as to expose the parasites to the outside world. It is noted that this isn't given that every host will wear this type of clothing, with some opting to wear clothes covering their entire body.")
		saynn("Parasites are seen as guardians and protectors, revered for helping tribe creatures stay healthy. Negative talk about the parasites is unheard of, creatures never refer to them as „parasites”, usually using different words such as „friends” or „guardians”, tribe creatures also stress on abolishing scientific categorization of those as parasites in support of calling them symbiotic creatures in nature, praising their medical as well as social benefits. While the former is a convincing argument, the latter is considered very questionable by the scholar.")
		saynn("Parasites seem to exhibit limited ability to communicate with their hosts. Hosts mention being able to encourage parasite normally fully inside host's body – to partially retract from their body exposing their existence. The degree to which a host can communicate with their parasite seems to depend on case-to-case basis.")
		saynn("Parasites are passed to born tribal creatures early on in their life, parents of young pass parasites to them during a ritual. The scholar laments that the ritual itself is done in secrecy making it impossible to document as no tribe person is interested in speaking about it. Interviewed younglings after the ritual are described as „enthusiastic” and „happy” following the ritual. They mention sense of belonging and community being the main feelings that they felt in regards to the ritual. Tribe believes that the ritual is a stepping stone in everyone's life and it makes them more connected to the natural world by having a part of it in themselves.")
		saynn("Hosts regularly engage in feedings where feeding occurs basically exclusively on other tribal creatures. This activity is considered relaxing, fun, and pleasant. There are some cases where feeding is sexualized or is part of sex acts. There are also other rituals involving parasites, some of them involve taking hallucinogenic substances or inducing hypnosis supposedly allowing the host to open full communication with their parasite. The tribe calls this state „synchronization”.")
		saynn("The psychological effect on the hosts is largely unknown. New hosts seem to be more cheerful, patient and kind in interactions, however it's unknown whether this is a direct result of the parasite or it is a response to social event of a ritual. Hirudo tenax infernalis gigantea is known to regularly release various hormones into the blood stream of their host with ability to manipulate their emotional state, in addition there is single strand of matter that the parasite makes in host's body that connects it with brain tissue, the effects of which weren't researched.")
		saynn("Outsiders are encouraged to become part of the tribe, however to do so the tribe requires them to become hosts to the same parasites by the ritual.")
		saynn("Then the scholar notes that this is the only known tribe to have such a relationship with a parasitic species, and concludes that while this is very unique and to many it could likely be seen as abominable, the tribe itself doesn't differ this much from many other tribes with their own customs.")
		addButton("Back", "", "tribal_significance")
		

	if state == "issix_opinion":
		saynn("You ask Issix about his opinion on matter of this parasite.")
		saynn("[say=issix]To tell you the truth, when I learned of species itself I were quite fascinated by it. It's quite a complex life form that chooses to live feeding of other creatures, but the level to which they integrate with their hosts is rarely seen. So from scientific point of view it is a rare and curious treat. But the tribe? Infesting oneself on purpose? It is mad. Reckless. Stupid. For a long time after learning about the tribe, which was after Lamia became my pet, I've held disdain towards this way of living. I've seen this tribe as nothing more than bunch of primitive fools, and this was visible in my relation with Lamia as well. It was... Complex.[/say]")
		saynn("[say=pc]...[/say]")
		saynn("[say=issix]On one of the walks, Azazel joined me near stream of water. We talked about this and that, he is a wonderful pet for philosophizing with. He also showed me that the way I looked at the tribe and Lamia was... Wrong. I thought that the scientific and rational basis for considering them fools and idiots for living how they lived was the only proper one. Azazel challenged that, and let me be clear, I don't usually let my pets challenge me, I have a weakness for philosophy though, for the better. Either way, he has told me, no, he taught me, that way of life is deeply personal and beyond grasp of science, truth. He has proved to me, that there is no single correct way to live a life, and each one of us will have different answer to questions such as „What is the point of existence?” or „What is your goal in life.”. I were too selfish in my worldview, thinking that I've know the only way to live life worth living.[/say]")
		saynn("[say=issix]Lamia's tribe chose nature as their way of living. And while a lot of their believes are based on misinterpretations of scientific methods, they've also achieved a lot by their own, discovered real applications of nature that informed intergalactic scientific community of something totally new or overlooked.[/say]")
		saynn("[say=issix]They may be fools, but the way they chose to live, to take the parasite as part of their lives ultimately is their own way of living, it is no more or less valid than my indulgence in pleasure and scientific method. Way of living is a deeply personal domain, that each one of us must face on their own, it's not something we can devise using science.[/say]")
		saynn("[say=issix]So what I think of entire thing? Considering the side-effects the parasite is a chore and maybe even danger to one's life. But if they are responsible with it, and decide that this is how they want to live, I'll not stand in their way. Doing otherwise is selfish and self-serving.[/say]")
		addButton("Back", "", "explanation")
		
	if state == "post_explanation":
		saynn("You finish asking questions, for a moment there is awkward silence in the confessionary, eventually Issix asks you to approach the metal bed in the center, on which Lamia sits, he instead now spreads his body to lie on his back.")
		saynn("[say=issix]I want you to see it, so you can answer my next question.[/say]")
		saynn("Lamia doesn't have issue with taking off his uniform to show you what's underneath. At first their body looks very normally, though the longer you stare you notice how unnatural the shape beneath their front body looks like, partially disguised by Lamia's fur.")
		saynn("Soon, the belly button area moves and a hole opens up with a parasite immediately taking place of the hole. Its round front with countless small „teeth” spread in circular motion around the opening to the void inside shows itself to you. Faint sound of two bodies grinding with mucus in-between, clinging to parasite's body as the parasite retracts half of itself.")
		saynn("You stare in amazement at the creature before you, Lamia's face calm and with no signs of experiencing any pain.")
		saynn("[say=pc]Wow. This must feel... Strange.[/say]")
		saynn("Lamia laughs and motions that it's okey, inviting you to feel comfortable.")
		saynn("[say=pc]So, it lives inside of you? Does it come out?[/say]")
		saynn("[say=issix]It does not. The part that you see here is more or less half of it. The rest is inside Lamia's body and cannot leave, it's basically integrated with body tissue for good..[/say]")
		saynn("[say=pc]I see...[/say]")
		saynn("[say=issix]You can touch it if you are curious. It doesn't bite, not unless Lamia wants anyways.[/say]")
		addButton("Touch", "Touch the parasite", "touch_parasite")
		addButton("Don't touch", "Do not touch the parasite", "not_touch_parasite")
		
	if state == "touch_parasite":
		saynn("You decide to touch the parasite, simply sliding tip of your finger on the side of its body. It feels slimy wet, suddenly a dark tentacle emerges from the „mouth” part, scaring you a little, you pull back your arm.")
		saynn("[say=issix]It's okey, it just reacted to your touch, it won't do you any harm.[/say]")
		saynn("With skepticism you once again put your paw next to the dark creature. Its tentacle, which you decided to call a tongue to simplify it for yourself, touches your paw finger and wraps around it. It feels funny, warm and... Pleasant? The texture of the appendage is smooth and nice to touch.")
		saynn("[say=pc]It's not... Feeding on me, right?[/say]")
		saynn("Both of them laugh.")
		saynn("[say=issix]Do you feel your blood and life force getting sucked through that? Haha. No, of course not. They feed through your belly area, not a finger. Besides, you WILL feel it if does.[/say]")
		saynn("After few seconds if contact it retreats back, hiding the tentacle in the dark void of its „mouth” and retreating back into Lamia's body.")
		saynn("[say=issix]Guess it got bored of you.[/say]")
		saynn("Master smirks. Lamia pulls his uniform back on so it covers his entire body and sits on the bed once again.")
		saynn("[say=issix]Well, this leaves us with the final question – do you wish to let Lamia's guest to feed on you? It requires regular feeding, at least once every 5 days. This is your choice, but it would unburden others, I suppose.[/say]")
		saynn("[say=pc]Uhhh, does it hurt?[/say]")
		saynn("[say=issix]No, it doesn't. You will feel worse off for some time while you recover, if you don't have one yourself.[/say]")
		saynn("[say=pc]I see...[/say]")
		addButton("Accept", "Accept proposal to let Lamia's parasite feed on you", "accept_feeding")
		addButton("Reject", "Reject proposal to let Lamia's parasite feed on you", "reject_feeding")
		
	if state == "not_touch_parasite":
		saynn("[say=pc]I think I'm good, thank you.[/say]")
		saynn("[say=issix]Not curious at all? Well, suit yourself. But with all of this there is one last lingering question for you. Lamia's guest there needs to be fed regularly, at least once every 5 days. This is your choice, but it would unburden others, I suppose.[/say]")
		saynn("[say=pc]Uhhh, does it hurt?[/say]")
		saynn("[say=issix]No, it doesn't. You will feel worse off for some time while you recover, if you don't have one yourself.[/say]")
		saynn("[say=pc]I see...[/say]")
		addButton("Accept", "Accept proposal to let Lamia's parasite feed on you", "accept_feeding")
		addButton("Reject", "Reject proposal to let Lamia's parasite feed on you", "reject_feeding")
		
	if state == "accept_feeding":
		saynn("[say=pc]I think I could do that, yeah.[/say]")
		saynn("[say=issix]Splendid. I'm sure Azazel and Hiisi will be happy to hear that. I think they both felt a bit tired of that lately, even if Azazel was extremely enthusiastic about it at first...[/say]")
		
	if state == "reject_feeding":
		saynn("[say=pc]No, I'm not willing to go through that. With all respect to Lamia, this sounds too risky and it's not something I want to participate in.[/say]")
		saynn("You take a look at Lamia, he seems unbothered by your response.")
		saynn("[say=issix]That's entirely understandable, a shame, because I thought you were enthusiastic about Lamia's pupil, but your response is way more sane than the other one you could give me. Truth be told, someone allowing a parasitic creature to feed on them is pretty insane.[/say]")
		saynn("[say=pc]What about Azazel and Hiisi?[/say]")
		saynn("[say=issix]Both of them rose to the occasion out of necessity and empathy for Lamia. What they are doing is insane, yes, but it's also very selfless and kind of them to do. This is a sacrifice, I don't necessarily want to require from everyone. If nobody did that I'd have to be more forceful, but I don't like being forceful, as you might have noticed.[/say]")
		saynn("[say=pc]I did, Master.[/say]")
		
	if state in ["accept_feeding", "reject_feeding"]:
		aimCamera("hall_ne_corner")
		setLocationName("Issix's Harem")
		saynn("[say=issix]Now, I want to reiterate, do not let even a squeak of Lamia's condition anywhere in the prison. Not even a lot of staff is aware, there are specific creatures from medical personel who assist in making sure everything is alright with Lamia, who are aware of his condition. This is for his safety. We managed to keep the parasite as well as his tribal connection under wraps for so long, and I want to keep it secret for as long as its needed. Understood?[/say]")
		saynn("[say=pc]Of course Master, understood.[/say]")
		if getModuleFlag("IssixModule", "Parasite_Feeding_Enabled", false) == true:
			saynn("[say=issix]When it comes to feeding, Lamia will pull you to our quiet place away from prying eyes of inmates and guards to do that.[/say]")
		
		saynn("[say=issix]That would be it for this debrief, let's get out of here, I think the longer I have to smell chlorine in the air, the worse I feel.[/say]")
		#saynn("[say=pc]Fair.[/say]")
		
		saynn("Lamia, Issix lead the way towards the corner. You stay behind. There are a lot of thoughts to process, a lot of new things you've seen. Lamia must have it tough, though on the other paw, he seems happier than anyone you've seen in this prison. It's almost eerie how someone in this condition could feel this way and yet, they are content.")
		saynn("You three arrive at the corner, Lamia and Issix taking their usual places. You take a look at Hiisi and Azazel, both of them look at you with curiosity, trying to read your face expression. What they see is you with your mind in the clouds, still processing everything you've learned, they quickly get bored of trying to get a read on you and continue doing their own things.")
		addButton("Finish", "", "endthescene")
		
		

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false
	
func saveData():
	var data = .saveData()

	data["checked_parts"] = checked_parts

	return data

func loadData(data):
	.loadData(data)

	checked_parts = SAVE.loadVar(data, "checked_parts", [])


func _react(_action: String, _args):
	if _action == "accept_feeding":
		setModuleFlag("IssixModule", "Parasite_Feeding_Enabled", true)
			
	if _action == "reject_feeding":
		setModuleFlag("IssixModule", "Parasite_Feeding_Enabled", false)
			
	if _action == "medical":
		processTime(10*60)
		
	if _action == "explanation":
		processTime(10*60)
		
	if _action == "post_explanation":
		processTime(10*60)
		
	if _action == "touch_parasite":
		processTime(5*60)
		
	if _action == "touch_parasite":
		processTime(2*60)
		
	if _action in ["accept_feeding", "reject_feeding"]:
		processTime(15*60)
			
	if _args.size() > 0 and _args[0] == -1:
		if !(_action in checked_parts):
			checked_parts.append(_action)
			processTime(6*60)
	
	# if _action == "endthescene_early":
	# 	endScene()
	# 	return

	if(_action == "endthescene"):
		# increaseModuleFlag("IssixModule", "Lamia_Times_Helped")
		setModuleFlag("IssixModule", "Lamia_Encounter_scene", 4)
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	setState(_action)
