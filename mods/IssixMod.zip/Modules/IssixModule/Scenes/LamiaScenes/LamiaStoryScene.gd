extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")
var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")
var pawns_interactions = []

func _init():
	sceneID = "LamiaStoryScene1"

func _initScene(_args = []):  # When coming into harem tile
	pawns_interactions = Globals.pick_unique_one(Globals.findPawns([[["isGuard"], []]]))
	if null in pawns_interactions:
		pawns_interactions[0] = "risha"

func resolveCustomCharacterName(_charID):
	if _charID.begins_with("pawn"):
		return pawns_interactions[int(_charID[-1])-1]

	return null

func _run():
	if(state == ""):
		addCharacter("lamia")
		saynn("As you move near Issix's corner, you see Lamia hailing you over.")
		addButton("Come", "Come to Lamia", "start_scene")
		addButton("Later", "Choose to come later", "endthescene_early")
		
	if state == "start_scene":
		addCharacter("lamia")
		addCharacter("hiisi")
		playAnimation(StageScene.Duo, "kneel", {pc="lamia", npcAction="kneel", npc="pc", bodyState={naked=false, hard=false}})
		saynn("You approach Lamia and sit next to them on their blanket as instructed.")
		
		saynn("[say=pc]Hey Lamia, is something wrong?[/say]")
		saynn("Shaking his head he takes 4-5 drawings along with something else. It's a dried plant of some sorts. The artwork depicts various similar plants.")
		saynn("[say=pc]Huh, what are those?[/say]")
		saynn("A voice from behind you speaks.")
		saynn("[say=hiisi]Medicinal plants, and a few others.[/say]")
		saynn("[say=pc]Hmm, what about them?[/say]")
		saynn("[say=hiisi]Lamia wants some. He had experience with making medicine from them before he ended in prison.[/say]")
		saynn("[say=pc]I see. The drawings are pretty detailed.[/say]")
		saynn("[say=hiisi]Lamia found the now withered plant on the floor near the elevator, he is now convinced that those grow in the prison because apparently the plant wouldn't be in such a great state if it was imported.[/say]")
		saynn("[say=pc]Mhm.[/say]")
		saynn("[say=hiisi]But there is only one place where this prison grows any plants.[/say]")
		saynn("Lamia lowers his head dejected.")
		saynn("[say=pc]Greenhouses?[/say]")
		saynn("[say=hiisi]Greenhouses.[/say]")
		saynn("[say=pc]Maybe staff at medical would be willing to help? Or why not just get to greenhouses.[/say]")
		saynn("[say=hiisi]Staff is no help. And greenhouses are off-limits to us. Lamia wanted me to go looking for those but Master is clear that we want no trouble from the guards.[/say]")
		saynn("[say=pc]I see. Well, I don't think I'd mind to look for them... Isn't that what you wanted to ask me Lamia?[/say]")
		saynn("Lamia's attention is immediately caught and he nods, aggressively.")
		saynn("[say=pc]Then sure, I can try.[/say]")
		if Globals.checkIfPCEnslaved():
			saynn("Hiisi looks all over your body.")
			
			if GM.pc.getStat(Stat.Strength) < 15:
				saynn("[say=hiisi]Look, I don't think it's a good idea, if guard spots you - they may attack you. That's in addition to making trouble for Master. And how will you even fight? There is not a muscle in your body.[/say]")
				if GM.pc.getStat(Stat.Sexiness) > 20:
					saynn("[say=pc]Don't you worry Hiisi, there are more forces in the world to fight with other than just simple strength.[/say]")
					saynn("Hiisi rolls his eyes.")
					saynn("[say=hiisi]Fine, I guess.[/say]")
				else:
					saynn("[say=pc]I'm sure I can figure something out.[/say]")
					saynn("[say=hiisi]This is NOT reassuring {pc.name}. You are not going there.[/say]")
					saynn("[say=pc]Hiisi! It will be fine, I promise. I've been there countless times.[/say]")
					saynn("[say=hiisi]... Eh. What makes you think it will be fine today too?[/say]")
					saynn("[say=pc]Comes from experience.[/say]")
					saynn("[say=hiisi]Well, if you so much want to get hurt for some plants then go for it. Remember, I warned you.[/say]")
					saynn("[say=pc]Thank you, Hiisi.[/say]")
					saynn("[say=hiisi]Mph.[/say]")
					saynn("He turns around.")
			else:
				saynn("[say=hiisi]Well, you do have some muscles...[/say]")
				saynn("He thinks for a while.")
				saynn("[say=hiisi]This could work, assuming you don't get into trouble.[/say]")
				saynn("[say=pc]I won't![/say]")
			
			saynn("[say=hiisi]Come back safe, {pc.name}.[/say]")
			saynn("You nod to him and leave.")
		else:
			
			saynn("[say=hiisi]... You are aware that this area is not supposed to be entered by the inmates, right?[/say]")
			saynn("[say=pc]Yes.[/say]")
			saynn("[say=hiisi]Okey, just making sure. what you do is none of my concern. I'm only making sure none of pets get into trouble. Good luck, I guess.[/say]")
		saynn("Lamia looks at you intensely, there is something in their look that you can't entirely decipher. A combination of curiosity, frustration and being „in the clouds”.")
		addButton("Go", "Go towards the Greenhouses", "before_greenhouses")
		
	if state == "before_greenhouses":
		aimCameraAndSetLocName("yard_nearstairs")
		removeCharacter("hiisi")
		playAnimation(StageScene.Duo, "jog", {pc="pc", npc="lamia", npcAction="jog", flipNPC=true})

		saynn("You continue walking towards the greenhouses, before you a set of stairs with markings signifying they are off-limits for the inmates. Crossing here means you are entering territory where guards can without any warning take you out. You look around to see if the coast is clear, and to your surprise, you see a familiar color palette hiding behind a corner. You come closer to confirm your suspicion.")
		saynn("[say=pc]Huh? Lamia? What are you doing here?[/say]")
		saynn("He looks embarrassed you've spotted him.")
		saynn("[say=pc]You are not supposed to come with me to the greenhouses, you know Hiisi is going to kill me if he learns about it, how did you even avoid having him on your tail?[/say]")
		saynn("Looking around, you don't see Hiisi tracking Lamia, or you for that matter. Lamia shrugs, but takes your paw in his hand and gives it a squeeze before walking towards the stairs.")
		saynn("[say=pc]Wait!!![/say]")
		saynn("The stairs deserved a refreshed look around to make sure no guard is there to spot you two going upwards to the greenhouses up the off-limit zone. Lamia doesn't seem to care about this too much though, going forward without any care in the world.")
		addButton("Continue", "Get led onto the stairs", "stairs_greenhouses")
		
	if state == "stairs_greenhouses":
		aimCameraAndSetLocName("yard_stars_green")
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="lamia", npcAction="walk", flipNPC=true})
		saynn("You get dragged on the stairs past the markings.")
		saynn("[say=pc]No, seriously Lamia stop![/say]")
		saynn("Lamia stops briefly and looks behind at you with questioning look.")
		saynn("[say=pc]Let me do this alone, I don't want to put you into trouble you know?[/say]")
		saynn("Lamia shakes his head.")
		if Globals.checkIfPCEnslaved():
			saynn("[say=pc]Guards can be aggressive, they could potentially do something bad to you, and then there is Hiisi and our Master who will skin me alive when they learn you went with me to the greenhouses.[/say]")
		else:
			saynn("[say=pc]Guards can be aggressive, they could potentially do something bad to you, and then there is Hiisi and your Master who will skin me alive when they learn you went with me to the greenhouses.[/say]")
		
		saynn("He resumes dragging you up the stairs, with renewed vigor and more carefulness, looking out for guards and sneaking around. You try your best to not garner attention as well. You give in to Lamia's stubborn want to go with you to look for the plants.")
		addButton("Continue", "", "deep_greenhouses")
		
	if state == "deep_greenhouses":
		aimCameraAndSetLocName("green_chokepoint")
		playAnimation(StageScene.Duo, "walk", {pc="lamia", npc="pc", npcAction="walk", flipNPC=true})
		saynn("You are being led though multiple corridors and greenhouses. There are a few guards moving around, whenever they are close Lamia pushes both of you into hiding spots, so far it worked pretty well, in fact it went so well you are surprised it worked until now.")
		saynn("[say=pc]Do we know where we are going? Where the plants are?[/say]")
		saynn("Lamia shrugs, guess you are going to wing it. You may not be as needed for this excursion, perhaps you are Lamia's moral support. Finally Lamia sharply tugs on your shoulder, the coast is clear and its time to move again.")
		
		saynn("You arrive at entrance to a greenhouse, however it is guarded with a very trivial lock, lamia fiddles with it unsuccessfully.")
		saynn("[say=pc]I can probably unlock it, do you have any metal hook or something I could use?[/say]")
		saynn("Lamia shakes his head, before he looks down and kneels looking around on the floor leading to the greenhouse frantically looking for something until they pick something up and present to you, it's a simple piece of metal that is thin and long, possibly something you could use.")
		saynn("[say=pc]Thanks.[/say]")
		addButton("Open", "Try to open it", "open_first_greehouse")
		
	if state == "open_first_greehouse":
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("minigame", game)
		# GM.ui.addCustomControl("minigame", game)
		game.instantEscapePerk()

		game.setDifficulty(RNG.randi_range(1, 3))
		game.connect("minigameCompleted", self, "onMinigameCompleted")
		
	if state == "open_first_greehouse_failed":
		
		saynn("You fiddle with piece of metal for 3 minutes and Lamia is visibly growing inpatient. The longer you stay here the bigger chance for you to get caught by the guards. You should really wrap it up.")
		addButton("Try again", "Retry breaking into the greenhouse", "open_first_greehouse")
		
	if state == "open_first_greehouse_success":
		aimCameraAndSetLocName("main_green_corridor9")
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="lamia", npcAction="walk", flipNPC=true})
		saynn("You successfully unlock the trivial lock guarding the doors and whats behind them.")
		saynn("[say=pc]We're in.[/say]")
		saynn("You said with pride, inviting Lamia in with your arm stretched towards the inside of a greenhouse, Lamia followed swiftly, immediately looking out at right and left at various plants. You can easily tell he is excited, his tail swishes left and right, his paws follow and touch leaves of many plants and he looks as if ready to collect many of those plants, barely restraining himself from doing so. You close the doors behind yourself not to draw attention to the greenhouse you are in.")
		saynn("The inside of greenhouse is warmer than the outside, it is also way more humid and gives earthy smell of plants. Plants of many sizes and varieties inhibit this place, as you walk on the hard path separating two halves of a greenhouse you notice how much care has been put into maintaining everything in here. ")
		saynn("[say=pc]Do you see anything?[/say]")
		saynn("Lamia ignores you, he continues to search among the plants, you slowly approach him.")
		saynn("[say=pc]Hey there, how is the search going?[/say]")
		saynn("Lamia shrugs, he still didn't find what he wanted.")
		saynn("[say=pc]I suppose there are more of those greenhouses, guess they all host different species of plants. Makes you wonder what a prison even needs them all for.[/say]")
		saynn("You eventually reach the end of this greenhouse and sneak out through the doors, promptly locking them again. Your paws are still empty, this means that the search continues.")
		addButton("Second", "Check out second greenhouse", "second_greenhouse")
		
	if state == "second_greenhouse":
		aimCameraAndSetLocName("main_green_corridor10")
		playAnimation(StageScene.Duo, "walk", {pc="lamia", npc="pc", npcAction="walk", flipNPC=true})
		saynn("You approach second greenhouse, this one doesn't seem to be locked at all. The set of doors to this one is very worn out, whatever lock would be here, likely would be pretty ineffective anyways.")
		saynn("[say=pc]Go in, I'll watch from here.[/say]")
		saynn("Lamia nods and enters the greenhouse while you guard the doors to it this time. Honestly though, not much happens. Occasional guard on patrol just walks mindlessly probably not expecting any inmates in this place. Everyone seems to be busy with their own thoughts, not that you can blame them. You yawn, Lamia surely takes his time looking at the plants. Eventually he comes out with a few plants in his paws.")
		saynn("[say=pc]Yay! So you found them?[/say]")
		saynn("Surprisingly, Lamia shakes his head. It appears those are „extras”, plants that he wants but none of them fit the look of the plants he was initially looking for.")
		saynn("[say=pc]Aww. Well, should we go to the next greenhouse then?[/say]")
		saynn("Lamia agrees. And so you sneak around towards yet another greenhouse.")
		addButton("Third", "Check out third greenhouse", "way_to_third")
		
	if state == "way_to_third":
		aimCameraAndSetLocName("main_green_corridor11")
		playAnimation(StageScene.Duo, "walk", {pc="lamia", npc="pc", npcAction="walk", flipNPC=true})
		addCharacter(pawns_interactions[0])
		saynn("As you make your way towards third greenhouse Lamia suddenly jumps and drops the plants he was holding onto the ground while he leaves the hard path connecting the furthest greenhouses with the rest of station.")
		saynn("[say=pc]Hey![/say]")
		saynn("You exclaim, quickly correcting your tone to mure hushed voice realizing this wasn't very sneaky of you. You look around, however thankfully it doesn't seem like there is any guard in proximity. Lamia however, unbothered by your shout crouches to a curious lowland in between greenhouses. It is rich in high greenery, terrain elevation likely makes it easier for water to stay down there for longer. However this greenery doesn't look organized and cared for like the one in greenhouses. Those are likely wild plants that found their way in here somehow. After few seconds you recognize some of those plants, because their shape is exact same as the ones Lamia has drawn.")
		saynn("[say=pc]Be careful down there, the foliage there is thick as hell, can't even see the ground below.[/say]")
		saynn("The fox morph simply continues to harvest various plants, meanwhile you pick up Lamia's dropped plants from the ground.")
		saynn("Suddenly both of you are spooked by the shout coming from someone.")
		saynn("[say=pawn1]The fuck are you doing in here? Don't you know this is OFF-FUCKING-LIMITS zone, inmates?[/say]")
		saynn("{pawn1.Name} reaches for {pawn1.his} stun baton while approaching Lamia, going straight for them into the greenery around them.")
		saynn("[say=pc]Fuck! Lamia, get the [/say]")
		saynn("You don't have to say anything, Lamia jumped and swiftly joined you, clearly relying on you as his protector.")
		saynn("[say=pawn1]You swift bitch. I'm gonna get y- AAAH[/say]")
		addButton("Watch", "Guard let out a scream, what is it?", "tentacle_beast")
		
	if state == "tentacle_beast":
		playAnimation(StageScene.TentaclesSex, "tease", {pc=pawns_interactions[0], plant=true})
		saynn("You watch as {pawn1.Name} falls onto their front as something is pulling {pawn1.him} by {pawn1.his} legs towards the center of lowland straight into thick greenery where they briefly disappear before emerging high above in between of many tentacles around them.")
		saynn("[say=pawn1]HELP! Fuuuck, HELP. INMATES! AAAAAAAAAAahhhhhh[/say]")
		saynn("[say=pc]Ummm. I think it's a clue for us to go.[/say]")
		saynn("Lamia is visibly spooked by the event. You do realize that if you get spotted in here this will only bring more trouble. It's not worth it.")
		saynn("[say=pc]Lets go, pronto.[/say]")
		addButton("Run", "Run away", "ran_outside")
		
	if state == "ran_outside":
		aimCameraAndSetLocName("yard_vaulthere")
		playAnimation(StageScene.Duo, "jog", {pc="lamia", npc="pc", npcAction="jog", flipNPC=true})
		removeCharacter(pawns_interactions[0])
		saynn("This time it's you who pulls Lamia by his paw and drag him straight to the balcony and you both use the railing to drop off right in the prison yard. The moment you land on hard ground below the railing you breathe out and feel safe.")
		saynn("[say=pc]Phew. That was something. You still got all of your things?[/say]")
		saynn("Lamia shows you the plants he collected and held tightly through the entire escapade.")
		saynn("[say=pc]Good. Let's go back to the harem and hope there is something left of me after Hiisi turns me into shreds.[/say]")
		saynn("Lamia responds by giving you pets, he communicates that you'll be just fine.")
		saynn("[say=pc]Thanks. Alright, let's move.[/say]")
		addButton("Back", "Come back to the harem", "come_back_harem")
		
	if state == "come_back_harem":
		aimCamera("hall_ne_corner")
		setLocationName("Issix's Harem")
		playAnimation(StageScene.Duo, "walk", {pc="lamia", npc="pc", npcAction="walk", flipNPC=true})
		saynn("After 8 minutes of walking you reach the harem, immediately bring gaze of everyone there on both of you, Lamia enthusiastically holding plenty of plants in his arms.")
		if Globals.checkIfPCEnslaved():
			saynn("[say=hiisi]{pc.Name}! I don't suppose Lamia is coming back with you because you met when coming back to the harem, does he?[/say]")
			saynn("He says in accusatory tone, visibly aggravated. Master Issix just laughs from his chair.")
			saynn("[say=pc]Well.. Lamia joined me when-[/say]")
			saynn("[say=issix]Calm down Hiisi, they are fine, don't you see?[/say]")
			saynn("He puts his paw on Hiisi's head, ruffling the hair of canine.")
			saynn("[say=hiisi]But t-[/say]")
			saynn("[say=issix]Give it a rest Hiisi. I'm sure {pc.Name} is responsible enough to protect Lamia.[/say]")
			saynn("[say=hiisi]As you wish, Master.[/say]")
			saynn("He said in unconvinced tone, but this likely means he is done with this topic.")
			saynn("[say=issix]{pc.name}, I meant it. If you don't think you can protect other pets, don't go to off-limit areas with them, or even don't go there yourself. It's trouble.[/say]")
			saynn("[say=pc]Understood, Master.[/say]")
		else:
			saynn("[say=hiisi]Lamia! Did you just follow {pc.Name}?? Didn't Master teach you anything about safety? {pc.He} isn't even Master's pet! You should have told me![/say]")
			saynn("[say=issix]Now now, Hiisi. Calm down. It's unfortunate what Lamia did, but the most important thing is that Lamia is in one piece and unharmed.[/say]")
			saynn("[say=azazel]Besides, Lamia did ask you about the plants earlier and you said no.[/say]")
			# saynn("Issix does seem to be relieved Lamia is fine, Hiisi is angry and Azazel seems quick to point out that Lamia's choice was caused by his inaction.")
			saynn("[say=hiisi]Well yes but...[/say]")
			saynn("[say=issix]There is something all of us can learn from this.[/say]")
			saynn("He turns to you.")
			saynn("[say=issix]Next time my pet finds itself near your legs, do bring them back here, alright? This could have turned badly. I know that you meant well, Lamia has been begging for those plants for a bit.[/say]")
			saynn("[say=pc]Sure...[/say]")
			saynn("[say=issix]And Lamia? Can you please not trust every single inmate that is nice to you?[/say]")
			saynn("Despite everything, Lamia looks rather proud of himself, but most importantly, he cherishes the plants in his paws.")
		saynn("[say=issix]{pc.Name}, you are dismissed now.[/say]")
		
		saynn("As you leave, Lamia begins to grind some of the plants he has gathered. What a day.")
		match getModuleFlag("IssixModule", "QuestionnaireQ10"):
			null:
				addMessage("(( Uh huh! Before we end, please answer a quick question regarding content you'd like to see in the future. Lamia's story line is parasite focused, so depending on this setting you may or may not see future content pertaining to Lamia. You'll be able to update this choice during enslavement quest. ))")
				addButton("Disable", "Completely disable all mentions/events related to parasite content.", "disable_parasite")
				addButton("References", "Enable only references to parasites, nothing graphic", "soft_parasite")
				addButton("Enable", "Enable full parasite content with all the graphic details", "enable_parasite")
				return
			1, 2:
				addMessage("The storyline for Lamia ends in here for you, as you've disabled any mention of parasite content and it is vital for the future content.")
			_:
				pass
		addButton("Leave", "Finish", "endthescene")
		
	if state in ["disable_parasite", "soft_parasite", "enable_parasite"]:
		match getModuleFlag("IssixModule", "QuestionnaireQ10"):
			1:
				saynn("(( Gotcha! Thank you for updating content settings, for you Lamia's storyline ends in here. ))")
			3:
				saynn("(( Gotcha! Thank you for updating content settings, for you Lamia's storyline has one more scene to see. ))")
			4:
				saynn("(( Kinky! Thank you for updating content settings, you opted to see entire Lamia's story ))")
		addButton("Leave", "Finish", "endthescene")
		
		
# 
func saveData():
	var data = .saveData()

	data["pawns_interactions"] = pawns_interactions

	return data

func loadData(data):
	.loadData(data)

	pawns_interactions = SAVE.loadVar(data, "pawns_interactions", ["risha"])

func onMinigameCompleted(result:MinigameResult):
	GM.main.pickOption("minigameResult", [result])

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false


func _react(_action: String, _args):
	if _action == "minigameResult":
		if _action == "minigameResult":
			var minigameResult: MinigameResult
			minigameResult = _args[0]
			var minigameScore:float = minigameResult.score
			if minigameScore >= 0.8:
				_action = "open_first_greehouse_success"
			else:
				_action = "open_first_greehouse_failed"
				
	if _action == "disable_parasite":
		setModuleFlag("IssixModule", "QuestionnaireQ10", 1)
				
	if _action == "soft_parasite":
		setModuleFlag("IssixModule", "QuestionnaireQ10", 3)
				
	if _action == "enable_parasite":
		setModuleFlag("IssixModule", "QuestionnaireQ10", 4)
				
	if _action == "come_back_harem":
		processTime(8*60)
	
	if _action == "open_first_greehouse_failed":
		processTime(3*60)
		
	if _action == "open_first_greehouse_success":
		processTime(20*60)
		
	if _action == "second_greenhouse":
		processTime(20*60)
		
	if _action == "ran_outside":
		processTime(5*60)
		GM.pc.addStamina(-30)
	
	if _action == "open_first_greehouse":
		pass
	
	if _action == "before_greenhouses":
		processTime(10*60)
	
	if _action == "endthescene_early":
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	if(_action == "endthescene"):
		Globals.increasePetAffection("lamia")
		setModuleFlag("IssixModule", "Lamia_Encounter_scene", 2)
		setModuleFlag("IssixModule", "Extra_Wait_Another_Day", true)
		setModuleFlag("IssixModule", "Lamia_Received_Medicine", false)
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	setState(_action)
