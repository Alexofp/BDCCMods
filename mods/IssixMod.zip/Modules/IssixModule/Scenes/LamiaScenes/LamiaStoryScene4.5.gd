extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

var towel = false
var fed_times = 1
var given_in_times = 0

func _init():
	sceneID = "LamiaParasiteReoccurring"
	

func _initScene(_args = []):
	fed_times = getModuleFlag("IssixModule", "Lamias_Parasite_Fed_Times", 1)  # I'll be referring to it often'
	given_in_times = getModuleFlag("IssixModule", "Lamias_Parasite_Given_In_Times", 0)  # I'll be referring to it often'


func _run():
	if(state == ""):
		addCharacter("lamia")
		addCharacter("hiisi")
		var days_since_last_feeding = GM.main.getDays() - getModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", 0)
		playAnimation(StageScene.Duo, "walk", {pc="hiisi", npc="pc", npcAction="walk", flipNPC=true})
		saynn("You notice "+str(days_since_last_feeding)+" fox figurines neatly stacked against each other on the edge of the blanket.")
		if days_since_last_feeding < 3:
			saynn("Figuring out that doing feeding earlier will help space them out and be less draining you signal to Lamia your willingness to let the parasite feed on you.")
		else:
			saynn("It's been a while since last feeding, you signal to Lamia your willingness to let the parasite feed on you.")
		
		saynn("He nods, stands up and takes you by your wrist pulling you with him, giving a sign to Hiisi, Hiisi raises and moves along with you two without any further comment.")
		addButton("Go", "Go with Lamia and Hiisi to Issix's cell", "in_cell")
			
	if state == "in_cell":
		aimCameraAndSetLocName("cellblock_orange_issixcell")
		removeCharacter("hiisi")
		playAnimation(StageScene.Nothing, "nothing", {pc="pc", npc="lamia", bodyState={naked=true, hard=true}, npcBodyState={naked=true, hard=true}})  # TODO No scene
		var is_clothed = GM.pc.getInventory().getFirstItemThatCoversBodypart(BodypartSlot.Body) != null
		
		saynn("Repeating the path already known to you you arrive at Issix's cell. Accompanied by Hiisi who as usual watched over Issix's cell.")
		if RNG.chance(4):
			saynn("For no reason, the amount of guards and inmates today is quite high in cellblock halls, prolonging the time you have to wait before entering the vent.")
			processTime(5*60)
		elif RNG.chance(20):
			saynn("There are a couple of inmates and guards passing by, it's a bit annoying but eventually Hiisi gives you go ahead, you push through the vent, Lamia behind you.")
		else:
			saynn("Today the coast is very clear and no inmates or guards are hindering your vent adventure. You enter the vent post haste, Lamia following your lead.")
			
		saynn("The light from very pink room hits your eyes. The comfortable oasis for rest and leisure, hidden in busy prison, behind a cell of... An influential inmate?")
		saynn("The comfortable red rug envelops the bottom of your {pc.feet} as you stand up. You can also see yourself in a mirror attached to a wall above one of the drawers.")
		saynn("The electronic devices you saw here on first visit are dead. Your frame, along with that of Issix's other pets is still standing on top of the drawer.")
		if fed_times < 2:
			saynn("The air smells of nothing in particular. Mainly just a smell of furniture. The pink bed is made and ready for you two.")
			
		elif fed_times < 5 or given_in_times < 4:  # Where it stays if player does not give in many times
			saynn("There is nothing that particularly catches your attention in terms of smell. The room still smells of furniture and at this point you are getting used to this room.")
			
		elif fed_times < 8:
			saynn("You are oddly excited about being here. The room looks just the same as the last time but... Why does it smell so good?")
			
		elif fed_times < 12 or given_in_times < 8:
			saynn("You are jittery from excitement about feeding Lamia's parasite. The weirdest part of it is that you don't really understand why. The room is filled with pleasant smell and when you look around... Was it something behind a bed? You take a look finding nothing, though you could swear you saw some dark small creature. Perhaps it's just from the excitement.")
		elif fed_times < 15 or given_in_times < 12:
			saynn("The room. It's the same inviting place where you started seeing your friend. You cannot wait to see it again.")
			
		elif fed_times < 18:
			saynn("It's time to see your friend. You must see it.")
			if is_clothed:
				saynn("You get undressed and throw it away without any care in the world.")
			
			saynn("Jumping on the bed you await the fox, he smiles at you with knowing smirk.")
			
		elif given_in_times > 17:
			saynn("It's a room for connecting with your dear friend, it smells of it, IT, IT. That's the only reason you are here, to connect with it. To feel whole again. THe pink walls, the pink room, it's the best room. This room is its and yours. You'll never let anyone else connect with it. You want IT.")
			
		if given_in_times < 3:
			saynn("Lamia, after dropping his uniform goes to lay on the side in the bed next to you, you both face each other.")
			addButton("Feed it", "Feed the parasite", "feeding")
			
		elif given_in_times < 10:
			saynn("You wait impatiently for Lamia for him to lie next to you on the bed as you usually do. Finally, when he does you feel this tingle of satisfaction as you see your friend emerge from Lamia's belly.")
			addButton("Feed it", "Feed friend", "feeding")
			
		else:
			saynn("You lie on the bed awaiting the fox to come on it as well. you feel very impatient, why does it take so long for Lamia to come here? You need to see you friend. You need to have him make you whole again. This moment finally comes, he lies next to you, you don't even look him in the face anymore, just at his belly, where you can see you dear friend emerge. It's beautiful as always.")
			addButton("Feed it", "Feed your beloved friend", "feeding")
		
	if state == "feeding":
		if given_in_times < 3:
			saynn("The shiny body of a parasite comes out, covered by mucus it dances in the air. You move closer to it until its side makes contact with your body and it attaches itself to your belly. The same coldness like before starts spreading through your body beginning with point of contact with the parasite.")
			saynn("You eventually fall into a nap.")
		elif given_in_times < 8:
			
			saynn("Partial body of the creature shows up. The impatience in you is replaced with relaxation. You take it in your paw and feel its warm, slimy juice wetting it. Its sweet smell now spreads in the air as you wave your paw. For some reason you feel enticed to spread it on your own body like a perfume, beginning to smear it across your belly and the face. Shortly after your encourage the creature to use your body – you get closer letting it reach you. It attaches itself to your belly and the sucking sensation begins.")
			saynn("You can't tell for sure, but it feels as if its... Tentacle entered you a little. As if it looked for something under your skin.")
			saynn("You let yourself drift away.")
		else:
			
			saynn("The gorgeous body if your friend emerges from belly of a fox. You stroke it, massage it. The lovely mucus that accumulates on your paw, that normally lets it move so easily out of Lamia's hole in their front is a perfect slimy liquid to spread all over your body, a marking of your love to the friend. You taste it with your mouth, the warm mucus is as sweet as it smells.")
			saynn("Starved for the filling you guide your friend to your own belly. When it finally attaches firmly to your body, it graces you with its love. You can definitely feel it now inside of you. It explores your body, your internal organs, you think.")
			saynn("You look forward to be more [i]connected[/i].")
		addButton("...", "", "dream")
		
	if state == "dream":
		if given_in_times < 3:
			saynn("When you fall into a nap, within your dream you can hear a quiet, distant, weak whisper:")
			saynn("[color=black][ghost freq=1.5]Back...[/ghost][/color]")
			saynn("[color=black][ghost freq=1.5]Feel? Strength...[/ghost][/color]")
			saynn("[color=black][ghost freq=1.5]Seeping.[/ghost][/color]")
			saynn("[color=black][ghost freq=1.5]Join.[/ghost][/color]")
			saynn("You have a vague feeling of something in the darkness of your dream, someone you can reach out to, something you can touch. Do you reach for it?")
			addButton("Reach", "Reach out for it", "accept_dream")
			addButton("Reject", "Do not reach out for it, reject the dream", "reject_dream")
			
		elif given_in_times < 8:
			saynn("When you fall into a nap, within your dream a dark "+Util.getSpeciesName(GM.pc.getSpecies())+" appears, speaking to you in gentle tone:")
			saynn("[color=black][ghost freq=2.0]Each time...[/ghost][/color]")
			saynn("[color=black][ghost freq=2.0]Connection stronger.[/ghost][/color]")
			saynn("[color=black][ghost freq=2.0]Entwined by...[/ghost][/color]")
			saynn("[color=black][ghost freq=2.0]Thread, together.[/ghost][/color]")
			saynn("The dark creature reaches out its paw to you. How do you answer this gesture?")
			addButton("Accept", "Accept their paw, put your own on theirs", "accept_dream")
			addButton("Reject", "Ignore it, leave and reject the dream", "reject_dream")
			
		elif given_in_times < 12:
			saynn("When you fall into a nap, within your dream a dark "+Util.getSpeciesName(GM.pc.getSpecies())+" shows up. It tells you in commanding tone:")
			
			saynn("[color=black][ghost freq=2.5]You seek me.[/ghost][/color]")
			saynn("[color=black][ghost freq=2.5]You want me.[/ghost][/color]")
			saynn("[color=black][ghost freq=2.5]You NEED me.[/ghost][/color]")
			
			saynn("[color=black][ghost freq=2.5]You – a prisoner. Let me make you.[/ghost][/color]")
			saynn("[color=black][ghost freq=2.5]Let me make you whole.[/ghost][/color]")
			saynn("[color=black][ghost freq=2.5]Remake you.[/ghost][/color]")
			saynn("[color=black][ghost freq=2.5]Embrace me.[/ghost][/color]")
			saynn("The dark creature is about to pull your by your paw. How do you answer this gesture?")
			addButton("Let them", "Let them pull you", "accept_dream")
			addButton("Run", "Leave it, reject the dream", "reject_dream")
			
		else:
			saynn("When you fall into a nap, a new [tornado][cuss]dream[/cuss][/tornado] occurs. This time its no longer a dark "+Util.getSpeciesName(GM.pc.getSpecies())+" but someone you know very well now, someone you consider a good friend living inside of Lamia's body, but this time you can see their entire body. Behind the dark half you know, the other one reminds you of tree roots, with major branches splitting into smaller and smaller veins, is this how your other part of a friend looks like? It speaks to you, with the same voice as the figure from the previous dreams spoke to you:")
		
			saynn("[color=black][ghost]Are you ready?[/ghost][/color]")
			saynn("[color=black][ghost]You'll not regret it.[/ghost][/color]")
			saynn("[color=black][ghost]Our connection is already strong.[/ghost][/color]")
			saynn("[color=black][ghost]Accept me. Let me help you.[/ghost][/color]")
			saynn("[color=black][ghost]Together we will be stronger.[/ghost][/color]")
			saynn("[color=black][ghost]Let me in you.[/ghost][/color]")
			saynn("[color=black][ghost]Let me BE you.[/ghost][/color]")
			
			saynn("You feel the desires of creature before you, it wants to be part of you forever. To remake you. To change you. Do you let want to let it? Do you want to pick it up and let it spread its root like veins through your entire body, so they forever become... Part of you.")
			addButton("Become a host", "Become their host", "accept_dream")
			addButton("Move away", "Leave them, reject the dream", "reject_dream")
		
	if state in ["accept_dream", "reject_dream"]:
		playAnimation(StageScene.Duo, "walk", {pc="lamia", npc="pc", npcAction="walk", flipNPC=true})
		addCharacter("hiisi")
		if given_in_times < 3:
			if state == "accept_dream":
				saynn("You reach your paw into the enveloping nothingness, and immediately when you feel the paw makes a contact with [i]something[/i], you wake up.")
			else:
				saynn("You decide not to reach out to the the unknown, instead you walk back until you wake up.")
			
		elif given_in_times < 8:
			if state == "accept_dream":
				saynn("You accept their paw, putting your own onto theirs. You can feel their warm paw grasping yours, though the paw feels slimy. Just as you were about to confirm this fact you woke up.")
			else:
				saynn("You ignore dark creature's offer and do not extend your paw towards theirs. Right after that decision you wake up.")
			
		elif given_in_times < 12:
			if state == "accept_dream":
				saynn("You allow the dark figure to pull you in, almost losing footing because of suddenness of this. You do keep up, however soon after your paw slips off the slimy paw. Right when you no longer touch the creature you wake up.")
			else:
				saynn("You decide not to let the unknown figure pull you wherever they want and evade their attempt to pull you. Right as their face looks at you everything disappears and you wake up.")
				
		else:
			if state == "accept_dream":
				saynn("You accept your friend, and immediately after you make a decision the creature is already inside of you. There is a rumble inside of your body, you wake up.")
				addMessage("This is currently where the parasite content ends, if you'd like to see more please let me know. Depending on feedback I might implement PC getting their own wriggler.")
			else:
				saynn("You shudder from idea of letting the parasite touch you, and scream „NO” as much as you can. You wake up, cold sweat running down your "+Globals.getSkinWord()+".")
				
		if fed_times == 1:
			saynn("[say=pc]Huh? What was t...[/say]")
			saynn("You look around, Lamia has his eyes opened while still laying on his side, the parasite not in sight. He pets your head.")
			saynn("[say=pc]Sorry... I think I've had a strange dream...[/say]")
			saynn("He laughs a little and stands up from the bed, putting on his clothes. You follow to do the same.")
			if state == "accept_dream":
				saynn("Your mind goes back to the dream you've had, did you make right decision? Was that truthfully your dream, or something induced by Lamia's parasite?")
			
		if given_in_times < 5:
			saynn("[say=pc]We should probably go now, Hiisi must be waiting.[/say]")
			saynn("Lamia nods and both of you leave the room crawling through the vent again.")
			
		else:
			saynn("You linger for a minute, reliving the satisfying moment of getting fed on and reflect on feeling of emptiness you feel deep inside. Finally, Lamia wakes you up from your stupor and takes you by your shoulder pointing towards the vent.")
			saynn("[say=pc]Oh, sorry Lamia, just been... Thinking...[/say]")
		
		saynn("You follow Lamia through the vent, to awaiting Hiisi. The vent entrance secured, you walk back towards harem's corner.")
		
		addButton("Walk back", "", "finish")
		
	if state == "finish":
		playAnimation(StageScene.Duo, "walk", {pc="hiisi", npc="pc", npcAction="walk", flipNPC=true})
		aimCamera("hall_ne_corner")
		setLocationName("Issix's corner")
		saynn("You are back at the harem.")
		
		addButton("Exit", "", "endthescene")
				
			
		

func getDevCommentary():
	return ""

func hasDevCommentary():
	return false
	
func saveData():
	var data = .saveData()

	data["fed_times"] = fed_times
	data["given_in_times"] = given_in_times

	return data

func loadData(data):
	.loadData(data)

	fed_times = SAVE.loadVar(data, "fed_times", getModuleFlag("IssixModule", "Lamias_Parasite_Fed_Times", 1))
	given_in_times = SAVE.loadVar(data, "given_in_times", getModuleFlag("IssixModule", "Lamias_Parasite_Given_In_Times", 0))


func _react(_action: String, _args):
	
	if _action == "feeding":
		processTime(4*60)
	
	if _action == "dream":
		processTime(4*60)
		
	if _action == "accept_dream":
		if getModuleFlag("IssixModule", "Lamias_Parasite_Given_In_Times") == null:
			addMessage("You've accepted the dream, this deepens your connection with the parasite")
		increaseModuleFlag("IssixModule", "Lamias_Parasite_Given_In_Times")
		
	if _action == "reject_dream":
		if given_in_times > 1:
			increaseModuleFlag("IssixModule", "Lamias_Parasite_Given_In_Times", -1)
		
	if _action in ["accept_dream", "reject_dream"]:
		processTime(Globals.calculateParasiteFeedingTime())
		GM.pc.addEffect("LifeEssenceDrained", [Globals.calculateParasiteEffectLength()])
		setModuleFlag("IssixModule", "Lamia_Parasite_Last_Feeding", GM.main.getDays())
		GM.pc.addStamina(-200)
		increaseModuleFlag("IssixModule", "Lamias_Parasite_Fed_Times")
		GM.world.getRoomByID("cellblock_orange_issixcell").visible = false
		
	if _action == "in_cell":
		GM.world.getRoomByID("cellblock_orange_issixcell").visible = true
		processTime(15*60)
		
	if(_action == "endthescene"):
		Globals.increasePetAffection("lamia")
		endScene()
		return

	setState(_action)
