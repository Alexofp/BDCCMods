extends SceneBase

const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "10question"

func _run():
	if(state == ""):
		saynn("[b]Frisk:[/b] "+Util.sayMale("Hey there, Issix Mod developer here. You've achieved lvl 10 of pet skill tree, impressive! Since this is almost the end of available content (assuming you've done all of the side stuff as well) figured I'd ask you for some feedback on the mod."))
		saynn("[b]Frisk:[/b] "+Util.sayMale("Should take less than 5 minutes, most questions are optional, and it will help me understand how am I doing currently with the content and what kind of content would players want in the future."))
		saynn("[b]Frisk:[/b] "+Util.sayMale("Apologies for this immersion ruining ask for feedback, it won't appear again in this release ;)"))
		saynn("[b]Frisk:[/b] "+Util.sayMale("(The link is https://cryptpad.fr/form/#/2/form/view/YUGrByVaCmDOC3qUSvNzDTbfU1p45Nem3x9D9YzwmUc/ btw, Cryptpad is privacy focused alternative to Google Forms and you can fill it entirely anonymously)"))
		addButton("Close", "I don't wanna give you no feedback, creep! Leave my BDCC alone.", "endthescene")
		addButton("Open link", "Opens link in default browser", "openlink")
		addButton("Copy link", "Copies link to clipboard, in case you'd like to open it in a different browser than your default", "clipboard")
		
	if state == "thanks":
		saynn("[b]Frisk:[/b] "+Util.sayMale("Thank you so much for wanting to participate! As a reward I'll leave the explaining to {pc.name} of why a plant egg laid by Azazel materialized in {pc.his} inventory out of nowhere to... You, the player. Good luck!"))
		addButton("What??", "", "endthescene")

func _react(_action: String, _args):
	if _action == "openlink":
		OS.shell_open("https://cryptpad.fr/form/#/2/form/view/YUGrByVaCmDOC3qUSvNzDTbfU1p45Nem3x9D9YzwmUc/")
		_action = "thanks"
		
	if _action == "clipboard":
		OS.set_clipboard("https://cryptpad.fr/form/#/2/form/view/YUGrByVaCmDOC3qUSvNzDTbfU1p45Nem3x9D9YzwmUc/")
		_action = "thanks"
		
	if _action == "thanks":
		var anEgg = GlobalRegistry.createItem("PlantEgg")
		anEgg.whoGaveBirth = "azazel"
		anEgg.setAmount(1)
		GM.pc.getInventory().addItem(anEgg)
	
	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Shown_Survey", true)
		endScene()
		return

	setState(_action)