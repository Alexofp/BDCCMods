extends SceneBase
const Globals = preload("res://Modules/IssixModule/Globals.gd")

var computer_track = null
var aquarium_mentioned = false

# TODO Functionality should include feeding transformation pills to the plants with various effects, unknown effect/reward?
# TODO Starts questline with Eliza
func _init():
	sceneID = "HiisiWanderScene5"
	
func _initScene(_args = []):
	if _args.size() > 0:
		setState("before_night")
	else:
		setState("night")
	
func _run():
	if state == "night":
		# Agressive plant fighting and classical music
		saynn("Once again you hear muted classical music right in the place you've heard it last. This time, however, you know where to look... If you wanted. Possibly you could get yourself something made out of metal and give a few good knocks on the place Hiisi exited from last time. Or you could not bother the canine this time, maybe hoping to catch the canine next time when they are entering (they must enter somewhere after his time in the corner, right?).")
		addButton("Knock", "Knock on the piece of rock!", "knock")
		addButton("Not today", "Leave it be for today", "endthescene")
		
	if state == "knock":
		addCharacter("hiisi")
		playAnimation(StageScene.Duo, "stand", {pc="pc", npc="hiisi"})
		yield(playPipe(), "completed")
		saynn("A lot of metal junk can be found on the station, if you look, anyway. After some time you do manage to find a metal pipe, hopefully its not that essential to station's functioning...")
		saynn("You bang the pipe against the solid rock that you earlier saw parting with canine behind, at least you believe it's the right place. Afterwards you wait a bit until the rock formation moves and entrance appears, in it, a known to you canine.")
		saynn("[say=hiisi]Don't make so much fucking raucous! Go in if you must![/say]")
		saynn("He stands aside so you can enter, which you promptly do. The giant rock once again shifts and locks you inside small entranceway with a square hole below which has a ladder leading down on one of its sides. Hiisi releases the electrical switch from his paw and begins to descent down the ladder first.")
		addButton("Follow him", "Follow the canine down the ladder", "ladder")
		
	if state == "ladder":
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="hiisi"})
		saynn("You follow the canine down the ladder. After around 3 meters down you already reach the end of it. Hiisi is moving forwards through very dim and tight corridor, you follow.")
		
		saynn("[say=hiisi]You really like to stick your nose everywhere, huh? {pc.name}? For your own good you should try not to, I considered impaling your ass with that metal pipe for a second.[/say]")
		saynn("[say=pc]You didn't.[/say]")
		saynn("[say=hiisi]You'd rather I did? I don't believe I ever invited you. That metal pipe belongs in your fucking ass.[/say]")
		
		saynn("You choose not to say anything as you follow.")
		addButton("Room", "You reach the technical room", "room")
		
	if state == "before_night":
		saynn("As you come to the yard and end up in the same place you've last seen Hiisi in previously coming out of their hiding hole, you see them again hanging out, slowly approaching the wall, looking around making sure there is no one around.")
		saynn("You come closer to him.")
		saynn("[say=pc]Hey Hiisi, what's up?[/say]")
		saynn("[say=hiisi]... I'm trying to go in...[/say]")
		saynn("[say=pc]You mind if I join you?[/say]")
		saynn("[say=hiisi]I do, but if you must...[/say]")
		saynn("He is hesitantly letting you join him, as he makes the rock formation part from its regular form.")
		saynn("[say=pc]How do you do that?[/say]")
		saynn("[say=hiisi]It's a trick. Come now, before someone spots us, watch out for the hole.[/say]")
		saynn("You quickly follow the canine and the rocks close in just behind your back, while both you and Hiisi stand in a very small space with square hole at the bottom. On one side of the hole a ladder sticks out, Hiisi quickly moves on to descent down using it. You follow right after.")
		
	if state == "ladder_before":
		saynn("You follow the canine down the ladder. After around 3 meters down you already reach the end of it. Hiisi is moving forwards through very dim and tight corridor, you follow.")
		
		saynn("[say=hiisi]I'm not sure what you are expecting honestly, prepare to be disappointed.[/say]")
		saynn("[say=pc]Maybe I'll be, maybe I'll be not.[/say]")
		
		saynn("As you approach the room at the end of the corridor, more and more light lets you see everything around.")
		addButton("Room", "You reach the technical room", "room")
	
	if state == "room":
		playAnimation(StageScene.Duo, "stand", {pc="pc", npc="hiisi"})
		yield(playMusic(), "completed")
		saynn("[say=hiisi]Here is what you so much wanted to see, happy?[/say]")
		saynn("You reach the technical room, the walls are covered in pipes, valves, various diagnostic equipment. At the wall side counter to the corridor you just came out from is a table with large glass aquarium, inside it you see some plants. To its right there is a kind of computer that looks gargantuan compared to all computers you've seen in your life. At first you didn't think it was a computer, thinking it's just another piece of equipment to keep the station running, but it does have typical controls of a computer.")
		saynn("[say=hiisi]It's for playing music. Some very old tech, but makes sounds clearer than anything I've ever seen on this station.[/say]")
		saynn("Hiisi explains. The screen shows interfaces your are not familiar with. Icons, consoles, names you don't recognize.")
		saynn("[say=hiisi]It runs kay-dee-eee Leenus. Extremely ancient tech, back from Terra. I don't know how it ended up on this station, maybe the engineer who was here before was an enthusiast of some old tech?[/say]")
		saynn("Hiisi operates the computer with no issues, using the controls to open the audio file and play it. After a second a crystal clear song starts playing from the speakers behind.")
		saynn("[say=pc]Seems like you figured out the computer.[/say]")
		saynn("[say=hiisi]To be frank, it took me some time, but it was a lot easier then I thought it would be, here, let me show you.[/say]")
		saynn("Hiisi shows you how to use controls of this ancient computer along with what to do to change music track.")
		saynn("[say=hiisi]Fun, isn't it? When I play with it it's as if my inner child emerges from the depths, as if I've seen that already. This feeling creeps me out sometimes. It does...[/say]")
		addButton("Think", "Choose what you can do")
		
	if state == "main":
		if Globals.ofModule("IssixModule").IssixAudio["metal_pipe"] != null:
			addButton("Computer", "Check the computer", "check_computer")
		else:
			addDisabledButton("Computer", "(functionality requires FoxLib)")
			
		addButton("Aquarium", "Look at aquarium", "aquarium")
		addButton("Box", "Ask about the box", "box")
		
	if state == "box":
		saynn("[say=pc]What's inside the box there?[/say]")
		saynn("You point your finger at box in the corner of the room.")
		saynn("[say=hiisi]Oh there...[/say]")
		
		saynn("He comes to the box, opens it and then closes, without showing you what's in it.")
		saynn("[say=hiisi]I think I'll leave it for some other time, if you decide to come back again.[/say]")
		saynn("[say=pc]Again?[/say]")
		saynn("[say=hiisi]Yes. I can show you how to enter and you are free to come and go as you wish, only do that when no one is around, so after everyone goes to their cells to sleep. For safety.[/say]")
		saynn("You nod.")
		saynn("[say=hiisi]So, should we go now?[/say]")
		if aquarium_mentioned:
			addButton("Sure", "Continue", "start_leaving")
		else:
			addButton("Not yet", "You still haven't inquired about the giant aquarium!", "main")
		
	if state == "aquarium":
		saynn("Your look focuses on glass container sitting at the top of a table, right in its center. The glass making up the walls of this container are transparent, top of the container is covered by a lid with controlled lamps pointed below.")
		saynn("The entire thing is clearly an aquarium, without any water inside. Instead, there is some soil at the bottom, on top of the soil there is green cover from which there are growing two small plants at two central points of the container.")
		saynn("[say=hiisi]It's just my little hobby.[/say]")
		saynn("[say=pc]Plants?[/say]")
		saynn("[say=hiisi]Well, yes, and no. It's more involved than just plants.[/say]")
		saynn("[say=pc]What do you mean?[/say]")
		saynn("[say=hiisi]Guess I can just show you...[/say]")
		addButton("Watch", "Hiisi grabs something and puts it through the top of aquarium", "aquarium_1")
		
	if state == "aquarium_1":
		saynn("You watch as Hiisi brings two pills to the top of the aquarium. They fit through rubber threshold, each directly after two plants. They drop to plants. Water is then dispensed from sides of the upper lid. Pills seem to somehow melt.")
		
		saynn("Hiisi grabs a stool from nearby and sits on it while observing intensely, you choose to simply stand there and watch... Plants.")
		saynn("Soon enough plants seem to react to the pills, as if animated their stems bend towards the pill dropped right at the base of their stem. Small strands of roots emerge from the ground trying to make as much contact with melted parts of pill which reacted to fluid dispensed from the aquarium.")
		saynn("All of this happened in speed you didn't anticipate those plants to move it.")
		saynn("[say=hiisi]Here comes the interesting part. Don't blink, you'll miss it.[/say]")
		saynn("Plants doubled in their sizes, both in height as well as in thickness. The path of growth also gained its direction - plants started growing towards each other. The one on the left putting its leaf towards the other one, the other one has different idea, instead letting leafless branch extend towards the plant on the left.")
		saynn("You expected to see some kind of cooperation between two plants for some reason, however that wasn't what followed. As the right plant reached petiole holding up the leaf of the left plant, it started encircling the thin branch. Tight embrace as snake strangling its victim it too tightened its grip. The leaf attempted to cover the branch of right plant, without much success, as the leaf suddenly detached from the petiole.")
		saynn("[say=pc]What the hell.[/say]")
		saynn("While you were focused on the action on the surface, a fight underground escaped your purview. There - roots coiling, growing, suffocating the other plant - hard at work. Plant on the left visibly getting weaker, withering away, changing colors from bright green to brighter yellow and then brown colors. Dying in real time, in your own eyes.")
		addButton("Continue", "", "aquarium_2")
		
	if state == "aquarium_2":
		saynn("[say=pc]What was that? Is it... Dead?[/say]")
		saynn("[say=hiisi]It is. Just like us, they too fight for their lives.[/say]")
		saynn("[say=pc]It happened so quick though...[/say]")
		saynn("[say=hiisi]I just sped all processes. With no pills it would have happened the same way, I only helped them grow...[/say]")
		saynn("[say=hiisi]We don't realize what is the world of plants and creatures around us, it usually isn't this fast, so we see the effects but not the process, and here? We can see it in all, and all the gory details.[/say]")
		saynn("[say=pc]Do plants usually... Do this?[/say]")
		saynn("[say=hiisi]Compete for resources often starving other plants of food? Yes. Directly attack each other like you saw? Usually not. Only certain species of plants do it so... Directly.[/say]")
		saynn("[say=pc]I see...[/say]")
		saynn("You stare some more at the plants in the aquarium.")
		addButton("Real fights", "Say that you'd have expected Hiisi to engage in or watch fights between creatures, rather than plants, like in The Underground", "aquarium_2_underground")
		addButton("Continue", "", "aquarium_3")
		
	if state == "aquarium_2_underground":
		saynn("[say=pc]Is this really your hobby? I'd have taken you'd prefer to spend your time in The Underground, watching fights in between inmates.[/say]")
		saynn("[say=hiisi]And why would you think so? Because I'm protecting Master's harem from harm with strength? I do what's necessary for us. But it doesn't mean I like it. I guess I'm just good at it.[/say]")
		saynn("[say=pc]Hm...[/say]")
		saynn("[say=hiisi]Truth be told, there is some inexplicable reason why I enjoy watching those plants go at it. I don't know why. I don't know why I'm like this. I don't know why... Who I'm... Like, those plants? I were drawn to watch them fight. Over and over. Planting them anew, feeding them substances and seeing who would win. I've heard that this kind of stuff a single planet is known for. „Ciecieszyn” its name, and it just feels so... Familiar.[/say]")
		saynn("[say=pc]Do you know why? Maybe you are from that planet?[/say]")
		
		saynn("[say=hiisi]... Maybe. I wouldn't know.[/say]")
		addButton("Continue", "", "aquarium_3")
		
	if state == "aquarium_3":
		saynn("[say=pc]So, do they just grow and fight? Is there some kind of predictor which one will survive?[/say]")
		saynn("[say=hiisi]The pill I fed them was a very basic one, QuickShift it's called. Maybe you've seen one already. But there are many more of those and all of them have different effects on those. Some make them more aggressive, some make them change colors, make them exude some fluid by emulating it and more. I haven't found out all of the properties, which is what makes this hobby more exciting, to see different effects.[/say]")
		saynn("[say=hiisi]I don't think there is other place with so many... Varied substances to use on those.[/say]")
		
		saynn("[say=hiisi]And when it comes to winning, I can't explain it. After doing so many of fights I usually am able to predict which one will win, though that's still not 100%  success rate, mind you.[/say]")
		
		saynn("Canine points at brown sack nearby.")
		saynn("[say=hiisi]Seeds for those plants are over there, by the way. In case you wanted to try some planting by yourself. Feel free to use them, there are a lot of them.[/say]")
		saynn("[say=pc]You don't mind?[/say]")
		saynn("[say=hiisi]Not really, maybe you'll like it too. And well...[/say]")
		saynn("[say=hiisi]If you have more of those strange pills that transform us, do try out. To be frank, I've been looking for many of them and experimenting trying to get certain effects. Once in a book that Master brought there was this article by some scientist who claimed they were able to make this specific type of plant cooperate with other plants of same type and together bear special kind of fruit. If the article is correct, it requires two plants fed same kind of chemical cocktail for this to happen. Though it's a long shot, it might have been that the article has been a fabrication or that the chemicals in this facility just wouldn't produce same effects.[/say]")
		addButton("Fruit?", "Ask what kind of fruit", "aquarium_4")
		
	if state == "aquarium_4":
		saynn("[say=pc]What kind of a fruit do the plants bear then?[/say]")
		saynn("[say=hiisi]Quantum fruit.[/say]")
		saynn("[say=pc]Quantum.. Fruit?[/say]")
		saynn("[say=hiisi]Yes. Properties of quantum fruit are unpredictable, the article described multiple different effects that could happen, each one weirder than the other.[/say]")
		saynn("[say=pc]Interesting, are they dangerous?[/say]")
		saynn("[say=hiisi]Maybe.[/say]")
		saynn("[say=pc]Hmm...[/say]")
		saynn("[say=hiisi]If you ever get them, let me know.[/say]")
		
		saynn("[say=hiisi]And uhh, don't overdo any of the pills, especially the QuickShift. Removing larger plants takes more time. Theoretically and practically growing them beyond certain size could end up very deadly for you.[/say]")
		
		saynn("[say=pc]Can they really grow out this big?[/say]")
		saynn("[say=hiisi]Probably, I didn't see any limits when I were using QuickShift, but I were careful not to overdo it. And here is the notebook, I keep various information on it about effects those pills have.[/say]")
		saynn("He points at the thin, rectangular paper sheets bent in the middle to give illusion of a notebook.")
		saynn("[say=hiisi]Had to use same thing that Lamia uses for his drawings, don't have access to other kinds of paper.[/say]")
		
		saynn("You browse through the „notebook”, quickly realizing there is only a single page with actual writing on it, everything else is blank.")
		saynn("[say=hiisi]... I didn't have much time or resources to procure many pills. If you can, it would be great if you brought some and filled the pages in with your observations.[/say]")
		addButton("Continue", "", "main")
		
	
	
	if state == "no_music_react":
		saynn("[say=hiisi]Don't like the music? Alright. Your choice. I love this basic instrument music. It is powerful. Especially when you look at the plants right there, it fits.[/say]")
		addButton("Okey", "Continue", "main")
		
	if state == "custom_music_react":
		saynn("[say=hiisi]Where did you find this song?... It's... Strange. Not bad just... Strange.[/say]")
		saynn("[say=pc]It was on the computer.[/say]")
		saynn("[say=hiisi]Weird, don't recall seeing this one.[/say]")
		addButton("Okey", "Continue", "main")
		
	if state == "start_leaving":
		saynn("[say=pc]Yeah, let's go.[/say]")
		
		saynn("He then shows you the exact mechanism for leaving and entering the place, and reminds you of watching out before entering while no one is around.")
		saynn("[say=hiisi]And try not to wreck the place, okey? I trust you, {pc.name}.[/say]")
		saynn("[say=pc]Of course, thank you.[/say]")
		saynn("He walks away towards the cellblock not looking behind. You just stand near the entrance, you should probably follow him, it's late.")
		addButton("Leave", "Leave", "endthescene")
		
		
		
func playPipe():
	yield(get_tree(), "idle_frame")
	yield(get_tree().create_timer(3.0), "timeout")
	Globals.playAudio("metal_pipe")
	
	
func playMusic():
	yield(get_tree(), "idle_frame")
	yield(get_tree().create_timer(5.0), "timeout")
	Globals.playAudio("classical2", 2)
		
		
func saveData():
	var data = .saveData()

	data["aquarium_mentioned"] = aquarium_mentioned
	
	return data

func loadData(data):
	.loadData(data)
	
	aquarium_mentioned = SAVE.loadVar(data, "aquarium_mentioned", false)

func _react_scene_end(_tag, _result):
	if _tag == "computerLeave":
		if computer_track == getModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track"):
			setState("main")
		elif getModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track") == "NONE":
			setState("no_music_react")
		elif getModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track") in ["classical1", "classical2"]:
			setState("main")
		else:
			setState("custom_music_react")
			

func _react(_action: String, _args):
	if _action == "knock":
		processTime(5*60)
		setModuleFlag("IssixModule", "Hiisi_Encounter_scene", 6)
		
	if _action == "ladder":
		processTime(5*60)
		
	if _action == "ladder_before":
		processTime(5*60)
		
	if _action == "room":
		processTime(5*60)
		
	if _action == "aquarium_3":
		aquarium_mentioned = true

	if _action == "check_computer":
		computer_track = getModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track")
		runScene("HiisiWanderScene5Computer", [], "computerLeave")

	if(_action == "endthescene"):
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	setState(_action)
