extends SceneBase
const Globals = preload("res://Modules/IssixModule/Globals.gd")

var time_waited = 0

# TODO In near pillory talks add a hint that someone has heard classical music after night in the yard if this scene is yet to play
# TODO Functionality should include feeding transformation pills to the plants with various effects, unknown effect/reward?
func _init():
	sceneID = "HiisiWanderScene4"
	
func _initScene(_args = []):
	if Globals.ofModule("IssixModule").IssixAudio["classical1"] != null:
		Globals.setAudioVolume(min(10, Globals.ofModule("FoxLib").audioVolume))
		Globals.playSound("classical1", 2)
	time_waited = 0
	
func _run():
	if(state == ""):
		# Agressive plant fighting and classical music
		saynn("As you check out the yard late at night before going to sleep you hear faint music playing ")
		
		saynn("This confuses you immensely, the source of the sound seems ambiguous and there isn't anything in sight, your eyes wander around while your ears attempt to get closer to its source. Few steps left, the sound becomes stronger, few steps right, it gets quieter again, you figure it could come either from above, as there is a ventilation vent situated directly above, one that is too high for you to reach or... Below? Despite it seeming like the worse idea, it seems more [i]grounded[/i] considering that the sound really does feel as if coming from below you instead. ")
		saynn("After short inspection you manage to notice tiny gaps in the grass below you forming a 1x1 meter square, the grass makes it difficult to spot but this irregularity becomes obvious after longer look. You assume this cannot be a coincidence,")
		saynn("Crouching you try to look for some way to... You don't know what, yet. Hardly an idea how to get under what the grass is hiding below.")
		saynn("[say=pc]Hello?[/say]")
		saynn("[say=pc]Open sesame?[/say]")
		
		saynn("You stomp with your {pc.feet} on the soil, but nothing happens. You try to feel what's in between of those gaps in soil with your paw fingers, and while you do feel the soil parting in those places, it quickly reaches to some kind of solid surface, can't make much of it.")
		saynn("After a while you decide you have ran out of ideas, though you could stick around and maybe something will happen?")
		addButton("Leave", "Nothing to do here", "leave")
		addButton("Wait", "It's fairly late but maybe its worth it?", "wait")
		
	if state == "wait":
		saynn(RNG.pick(["You wait 5 minutes, nothing happens.", "5 minutes - no luck", "Time passes, the music still plays but nothing else happens.", "You thought you've heard something, but it's just random space station noise.", "You stare at everything around, the music still going.", "Waiting makes you realize just how late it is and how sleepy you are."]))
		addButton("Leave", "Nothing to do here", "leave")
		addButton("Wait", "It's fairly late but maybe its worth it?", "wait")
		
	if state == "wait_music_stop":
		saynn("As you sit on the grass below you in anticipation of anything happening, you notice that the music stopped playing. Adrenaline rushes to your veins and you stand up, your waiting paid off though... With what exactly?")
		addButton("Leave", "Leave before something bad happens", "leave")
		addButton("WAIT", "You wouldn't leave now, right? After so long something is actually happening!", "hiisi_leaves")
		
	if state == "leave":
		saynn("Instead of waiting for something to happen you decide to just leave it be and do something else.")
		addButton("Continue", "", "endthescene")
		
		
	if state == "hiisi_leaves":
		saynn("At first you hear noises underneath, where you've heard the music play, loud metal noises, perhaps doors closing or some mechanical piston switching its state. For a bit it was quieter but then a whooshing sound slightly to your right, you look at the wall near yourself, a wall opens and when it does you can see someone you know – Hiisi himself!")
		saynn("They seem tired, as their figure moves out of the mystical space inside the wall, which promptly closes behind them, leaving a solid stone of the cave again.")
		saynn("At first it feels as if he didn't see you, but soon he looks again in your direction and seems rather surprised. You come closer to Hiisi.")
		saynn("[say=hiisi]Uhhh, hey there {pc.name}. It's quite late, you should probably head to your cell and give yourself some rest.[/say]")
		
		saynn("You question the canine on where they just came from and if they know what's up with the classical music..")
		saynn("[say=hiisi]Eh, you got me. It's just my little secret. Please don't mention it to anyone, okey?[/say]")
		addButton("Be insistent", "Ask for more", "ask_secret")
		
	if state == "ask_secret":
		saynn("[say=pc]Do you have your own hidey hole in there? What is it?[/say]")
		saynn("[say=hiisi]If you need to know, follow me, I can tell you a little bit as we go to the cells, and only because I trust you. Peep about it to someone else and I'll fuck you up, okey?[/say]")
		saynn("You know Hiisi means business, though the way they said it, in their tired, yawning voice feels rather non-threatening.")
		saynn("[say=pc]Alright, just spill the beans already, I waited like 25 minutes for this![/say]")
		saynn("[say=hiisi]Persistent, are you?[/say]")
		addButton("Listen", "Listen to the canine for his explanation", "listen_1")
		
	if state == "listen_1":
		addCharacter("hiisi")
		aimCameraAndSetLocName("yard_firstroom")
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="hiisi"})
		
		saynn("[say=hiisi]You are right, it is a kind of a hidey hole for myself, I go there in some nights when I want to wind down. Not a big deal really.[/say]")
		saynn("[say=pc]How? How did you find it? How do you access it? What do you do there? Huh?[/say]")
		saynn("You attack Hiisi with a barrage of questions, Hiisi sighs.")
		saynn("[say=hiisi]I simply saw an engineer go there a few times, during the nights. When Master and others go to their cells and sleep, I sometimes feel like chilling in the yards, I don't think engineer realized I were watching them. At some point they stopped coming, I later learned they resigned from BDCC, it was strange because it seemed they were the only creature going there.[/say]")
		saynn("[say=hiisi]I didn't visit the place until a while after they disappeared, keeping my distance and myself out of trouble, since I don't think BDCC staff would appreciate an inmate going to some kind of engineer place. At some point curiosity got better of me and I repeated the exact steps engineer took to go to the „hole”.[/say]")
		
		saynn("[say=hiisi]Insert the magic code and voilà! The gate opens for a short time.[/say]")
		addButton("Listen", "Continue", "listen_2")
		
	if state == "listen_2":
		aimCameraAndSetLocName("main_stairs_s")
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="hiisi"})
		saynn("Both of you continue towards the cell blocks. It is kind of unusual for Hiisi to be this chatty.")
		saynn("[say=hiisi]It was a little bit scary, going into the unknown. I did see how engineer go in there, but I never saw how they go out. I did go into a little bit of panic after the rocky doors closed behind me, again, it looked abandoned now that the engineer wasn't there, if I got stuck there I don't think anyone would find me, except maybe Master, but I don't know...[/say]")
		saynn("[say=hiisi]Thankfully inside, a makeshift button thing was hanging from the rocky ceiling that opens the doors again, I hope it never breaks...[/say]")
		saynn("[say=hiisi]After I descended down the ladder I found a cosy little maintenance room with a table and stuff.[/say]")
		saynn("[say=pc]What kind of stuff?[/say]")
		saynn("[say=hiisi]Stuff. Personal stuff, of that engineer. It's odd they left it there, seemed important.[/say]")
		saynn("[say=pc]Odd...[/say]")
		saynn("[say=hiisi]Yeah. I did a few changes to the room and now use it to chill.[/say]")
		addButton("Listen", "Continue", "listen_3")
		
	if state == "listen_3":
		aimCameraAndSetLocName("hall_mainentrance")
		playAnimation(StageScene.Duo, "walk", {pc="pc", npc="hiisi"})
		
		saynn("You ask about the music.")
		saynn("[say=hiisi]It is mine, yes.[/say]")
		saynn("[say=pc]Do you just listen to the music?[/say]")
		saynn("Hiisi stops and hesitates for a moment.")
		saynn("[say=hiisi]... Mostly...[/say]")
		saynn("[say=hiisi]Anyways, I'm going to sleep. Good night.[/say]")
		
		saynn("Without further ado he disappears behind the stairs leading to cellblocks before you can even respond. ")
		saynn("(( 5th Hiisi scene along with new mechanics are WIP and not available in this version ))")
		addButton("Go", "Leave", "endthescene")
		
func saveData():
	var data = .saveData()


	return data

func loadData(data):
	.loadData(data)

func _react(_action: String, _args):
	if _action == "wait":
		time_waited = time_waited + 1
		if time_waited > 4:
			_action = "wait_music_stop"
			Globals.stopAudio("classical1")
			Globals.setAudioVolume(null)
		processTime(5*60)

	if _action.begins_with("listen_"):
		processTime(2*60)

	if _action == "listen_3":
		GM.pc.setLocation("hall_mainentrance")
		setModuleFlag("IssixModule", "Hiisi_Encounter_scene", 5)

	if(_action == "endthescene"):
		Globals.stopAudio("classical1")
		Globals.setAudioVolume(null)
		setModuleFlag("IssixModule", "Had_Pet_Scene_Today", true)
		endScene()
		return

	setState(_action)
