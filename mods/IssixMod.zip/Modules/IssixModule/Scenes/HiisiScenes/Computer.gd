extends SceneBase
const Globals = preload("res://Modules/IssixModule/Globals.gd")

func _init():
	sceneID = "HiisiWanderScene5Computer"
	
var file_dialogue = null
	
func _ready():
	file_dialogue = FileDialog.new()
	
func _run():
	if state == "":
		saynn("[console]/-------------------------------------\\[/console]")
		saynn("[console]|          CURRENTLY PLAYING           |[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]"+getCurrentTrack()+"[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]|                                      |[/console]")
		saynn("[console]\\-------------------------------------/[/console]")
		addButton("Classical 1", "Play classical 1 song", "play", ["classical1"])
		addButton("Classical 2", "Play classical 2 song", "play", ["classical2"])
		addButton("Stop music", "Stop playing music", "stop_music")
		if OS.get_name() in ["Android", "HTML5"]:
			addDisabledButton("Find other", "This functionality is not available on your current platform, sorry :(")
		else:
			addButton("Find other", "Find other song", "file")
		
	if state == "file":
		pass
		
func getCurrentTrack() -> String:
	var track = getModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track", "classical2")
	if track.is_abs_path() and track.get_extension() in ["ogg", "mp3"]:
		return track.get_file().get_slice(".", "0")
	else:
		if track == "classical2":
			return "Sonata No. 4 in E Flat Major, Op. 7 - I. Allegro molto e con brio"
		if track == "classical1":
			return "07 Beethoven- Symphony #5 In C Minor, Op. 67 - 3. Allegro"
		if track == "NONE":
			return "No track selected"
	return track
		
func saveData():
	var data = .saveData()


	return data

func loadData(data):
	.loadData(data)
	
func stopPlayingKnownTracks():
	Globals.stopAudio("custom_hiisi_room")
	Globals.stopAudio("classical1")
	Globals.stopAudio("classical2")
	
func _musicFileChosen(path: String):
	if path.is_abs_path() and path.get_extension() in ["ogg", "mp3"]:
		var mod = Globals.ofModule("IssixModule")
		stopPlayingKnownTracks()
		mod.IssixAudio["custom_hiisi_room"] = mod.foxModuleAPI.newAudio("CustomPlayer", path)
		Globals.playSound("custom_hiisi_room", 2)
		setModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track", path)
		GM.main.reRun()

func _react(_action: String, _args):
	
	if _action == "file":
		file_dialogue.set_mode(0)
		file_dialogue.set_title("Choose audio file")
		file_dialogue.set_filters(PoolStringArray(["*.ogg ; OGG Audio","*.mp3 ; MP3 Audio"]))
		file_dialogue.connect("file_selected", self, "_musicFileChosen")
		file_dialogue.set_root_subfolder(OS.get_system_dir(OS.SYSTEM_DIR_MUSIC))
		file_dialogue.current_dir = OS.get_system_dir(OS.SYSTEM_DIR_MUSIC)
		file_dialogue.visible = true
		GM.main.getCurrentScene().add_child(file_dialogue)
		file_dialogue.popup_centered()
		file_dialogue.anchor_left = 0.5
		file_dialogue.anchor_top = 0.5
		file_dialogue.anchor_right = 0.5
		file_dialogue.anchor_bottom = 0.5
		file_dialogue.margin_left = -300.0
		file_dialogue.margin_top = -200.0
		file_dialogue.margin_right = 300.0
		file_dialogue.margin_bottom = 200.0
		_action = ""
		
	if _action == "play":
		var music = _args[0]
		setModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track", music)
		stopPlayingKnownTracks()
		Globals.playSound(music, 2)
		
	if _action == "stop_music":
		setModuleFlag("IssixModule", "Hiisi_PC_Chosen_Track", "NONE")
		stopPlayingKnownTracks()

	if(_action == "endthescene"):
		processTime(5*60)
		endScene()
		return

	setState(_action)
