# Child of the nurse's dialogue scene from the nursery. The original game file is not
# modified: this scene is registered under the same sceneID and replaces the original.
# The module folder starts with "Z_" so that it loads after MedicalModule.
extends "res://Modules/MedicalModule/Nursery/NurseryTalkScene.gd"

# Dialogue states in which the extra button is shown (the main talk menu).
const PERK_BUTTON_STATES = [""]

func _run():
	._run()
	if(state in PERK_BUTTON_STATES):
		addButton("Starting perks (100 cr.)", "Add or remove your starting perks", "eas_perkshop")

func _react(_action:String, _args):
	if(_action == "eas_perkshop"):
		runScene("PerkShopScene")
		return
	._react(_action, _args)
