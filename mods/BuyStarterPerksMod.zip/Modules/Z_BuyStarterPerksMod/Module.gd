extends Module

func _init():
	id = "BuyStarterPerksMod"
	author = "Discis"

	scenes = [
		"res://Modules/Z_BuyStarterPerksMod/PerkShopScene.gd",
		"res://Modules/Z_BuyStarterPerksMod/NurseryTalkSceneWithPerks.gd",
	]
