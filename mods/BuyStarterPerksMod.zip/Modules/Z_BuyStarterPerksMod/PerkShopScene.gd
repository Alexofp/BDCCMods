extends SceneBase

# Price of one change (adding OR removing a perk)
const PRICE = 100
const PER_PAGE = 8

# In-game hours that pass after every purchase
const PROCEDURE_HOURS = 5

# Optional: list perk ids here to skip auto-detection of starting perks,
# for example ["SomePerkID", "AnotherPerkID"]
const MANUAL_PERK_IDS = []

var page = 0
var lastMessage = ""
var cachedPerkIDs = null
var diagnosticsLogged = false

func _init():
	sceneID = "PerkShopScene"

# ---------- helpers ----------

func getCredits() -> int:
	if(GM.pc.has_method("getCredits")):
		return GM.pc.getCredits()
	return 0

func spendCredits(amount:int):
	if(GM.pc.has_method("addCredits")):
		GM.pc.addCredits(-amount)

# Tries several ways to recognise a "starting perk", because the exact flag
# used by the game is not known for sure.
func isStartingPerk(perkID:String, perk) -> bool:
	if(perkID.to_lower().begins_with("start")):
		return true
	if(perk.has_method("getSkillGroup")):
		var group = perk.getSkillGroup()
		if(group is String && "start" in group.to_lower()):
			return true
	for m in perk.get_method_list():
		var mname:String = m["name"]
		var lname:String = mname.to_lower()
		if(!("starting" in lname)):
			continue
		if(!(lname.begins_with("is") || lname.begins_with("can") || lname.begins_with("get") || lname.begins_with("has"))):
			continue
		if(m["args"].size() > 0):
			continue
		if(perk.call(mname) == true):
			return true
	for p in perk.get_property_list():
		var pname:String = p["name"]
		if(!("starting" in pname.to_lower())):
			continue
		if(perk.get(pname) == true):
			return true
	return false

func getStartingPerkIDs() -> Array:
	if(MANUAL_PERK_IDS.size() > 0):
		return MANUAL_PERK_IDS.duplicate()
	var result:Array = []
	for perkID in GlobalRegistry.perksObjects:
		if(isStartingPerk(perkID, GlobalRegistry.perksObjects[perkID])):
			result.append(perkID)
	result.sort()
	return result

# Fallback: scenes of the game that look like the starting perk picker
func findPickerSceneIDs() -> Array:
	var result:Array = []
	for scID in GlobalRegistry.scenes:
		if(scID == sceneID):
			continue
		var lid:String = str(scID).to_lower()
		if("perk" in lid && "start" in lid):
			result.append(scID)
	result.sort()
	return result

func logDiagnostics():
	if(diagnosticsLogged):
		return
	diagnosticsLogged = true
	var ids:Array = GlobalRegistry.perksObjects.keys()
	Log.print("[PerkShop] No starting perks detected. Registered perks ("+str(ids.size())+"): "+str(ids))
	var perkScenes:Array = []
	for scID in GlobalRegistry.scenes:
		if("perk" in str(scID).to_lower()):
			perkScenes.append(scID)
	Log.print("[PerkShop] Scenes with 'perk' in the id: "+str(perkScenes))
	if(ids.size() > 0):
		var scr = GlobalRegistry.perksObjects[ids[0]].get_script()
		if(scr != null):
			var base = scr.get_base_script()
			if(base != null && base.has_method("get_script_method_list")):
				var names:Array = []
				for m in base.get_script_method_list():
					names.append(m["name"])
				Log.print("[PerkShop] Perk base script "+str(base.resource_path)+" methods: "+str(names))

func perkName(perkID:String) -> String:
	var perk = GlobalRegistry.perksObjects[perkID]
	if(perk.has_method("getVisibleName")):
		return perk.getVisibleName()
	return perkID

func perkDescription(perkID:String) -> String:
	var perk = GlobalRegistry.perksObjects[perkID]
	if(perk.has_method("getVisibleDescription")):
		return str(perk.getVisibleDescription())
	return ""

func hasPerk(perkID:String) -> bool:
	return GM.pc.hasPerk(perkID)

func givePerk(perkID:String):
	GM.pc.getSkillsHolder().addPerk(perkID)

func takePerk(perkID:String):
	GM.pc.getSkillsHolder().removePerk(perkID)

# Looks up a constant of StageScene by name without a hard reference,
# so the mod still loads if the animation does not exist in this game version.
func getStageConst(constName:String):
	var st = StageScene
	var map = {}
	if(st is Script):
		map = st.get_script_constant_map()
	elif(st != null && st.get_script() != null):
		map = st.get_script().get_script_constant_map()
	return map.get(constName, null)

func playLyingAnimation():
	var stage = getStageConst("Sleeping")
	if(stage != null && has_method("playAnimation")):
		playAnimation(stage, "sleep", {pc="pc"})

func skipProcedureTime():
	if(has_method("processTime")):
		processTime(PROCEDURE_HOURS * 60 * 60)

# ---------- scene ----------

func _run():
	if(state == ""):
		if(cachedPerkIDs == null):
			cachedPerkIDs = getStartingPerkIDs()
		var perks:Array = cachedPerkIDs

		saynn("The nurse checks your file and offers to review your starting perks. Every change costs "+str(PRICE)+" credits.")
		saynn("Your credits: "+str(getCredits()))
		if(lastMessage != ""):
			saynn(lastMessage)

		if(perks.empty()):
			var pickers:Array = findPickerSceneIDs()
			if(pickers.empty()):
				logDiagnostics()
				saynn("No starting perks were found. Please check the game log for lines starting with [PerkShop].")
			else:
				saynn("The list of starting perks could not be built, but the game's own perk picker can be opened for "+str(PRICE)+" credits.")
				for scID in pickers:
					if(getCredits() >= PRICE):
						addButton("Open picker ("+str(scID)+")", "Pay "+str(PRICE)+" credits and open the original picker", "openpicker", [scID])
					else:
						addDisabledButton("Open picker ("+str(scID)+")", "Not enough credits")
		else:
			var from = page * PER_PAGE
			var to = min(from + PER_PAGE, perks.size())
			for i in range(from, to):
				var perkID = perks[i]
				var title = perkName(perkID)
				var desc = perkDescription(perkID)
				var verb = "Remove: " if hasPerk(perkID) else "Add: "
				if(getCredits() >= PRICE):
					addButton(verb+title, verb+"this perk for "+str(PRICE)+" credits.\n"+desc, "toggle", [perkID])
				else:
					addDisabledButton(verb+title, "Not enough credits")
			if(page > 0):
				addButton("Previous", "Previous page", "prevpage")
			if(to < perks.size()):
				addButton("Next", "Next page", "nextpage")
		addButton("Leave", "End the conversation", "endthescene")
	elif(state == "procedure"):
		playLyingAnimation()
		saynn("The nurse helps you onto a bed and tells you to lie down on your back. You stare up at the ceiling lights while she checks her equipment and gets to work.")
		saynn("A strange warmth spreads through your body and your eyelids grow heavy. When it finally fades, you can tell that something inside you has changed.")
		addButton("Continue", "Rest while the procedure finishes", "afterprocedure")
	elif(state == "aftercare"):
		saynn("You drift in and out of sleep. By the time the nurse lets you get up, about "+str(PROCEDURE_HOURS)+" hours have passed.")
		addButton("Continue", "Get up", "backtomenu")

func _react(_action:String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "prevpage"):
		page = max(0, page - 1)
		setState("")
		return
	if(_action == "nextpage"):
		page += 1
		setState("")
		return
	if(_action == "openpicker"):
		if(getCredits() >= PRICE):
			spendCredits(PRICE)
			runScene(_args[0])
		else:
			lastMessage = "You don't have enough credits."
			setState("")
		return
	if(_action == "toggle"):
		var perkID = _args[0]
		if(getCredits() < PRICE):
			lastMessage = "You don't have enough credits."
			setState("")
			return
		if(hasPerk(perkID)):
			spendCredits(PRICE)
			takePerk(perkID)
			lastMessage = "Perk removed: "+perkName(perkID)+" (-"+str(PRICE)+" credits)."
		else:
			spendCredits(PRICE)
			givePerk(perkID)
			lastMessage = "Perk added: "+perkName(perkID)+" (-"+str(PRICE)+" credits)."
		setState("procedure")
		return
	if(_action == "afterprocedure"):
		skipProcedureTime()
		setState("aftercare")
		return
	if(_action == "backtomenu"):
		setState("")
		return
	setState(_action)

func saveData():
	var data = .saveData()
	data["page"] = page
	return data

func loadData(data):
	.loadData(data)
	page = SAVE.loadVar(data, "page", 0)
