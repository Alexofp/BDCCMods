extends "res://FoxLib/FoxModule.gd"

const FoxLibAudioManager = preload("res://Modules/FoxLib/Internal/FoxLibAudioManager.gd")

const FoxLibModInitHelper = preload("res://Modules/FoxLib/Internal/FoxLibModInitHelper.gd")

var foxlibversion = "0.10.7"

var sound
var EffectSound
var AmSound
var soundDir = "res://Modules/SoundModule_legacy/"

var Psoundoption:bool = true
var Osoundoption:bool = true
var Tsoundoption:bool = true
var Ssoundoption:bool = true
var gagsoundoption:bool = true
var pitchVarianceOption:float
var HypnoOption:bool = false
var cumEffect:bool = false
var squirtEffect:bool = false
var spankOption:bool = false
var punchOption:bool = false
var clothOption:bool = false
var chainOption:bool = false
var plapOption:bool = false
var audiotest:bool = true
var voicepackoption = ""
var packReq = [
	"sounds_orgasm",
	"sounds_orgasm_gagged",
	"sounds_pleasure",
	"sounds_pleasure_gagged",
	"sounds_struggle",
	"sounds_struggle_gagged",
	"sounds_tease",
	"sounds_tease_gagged",
]
var effectReq = [
	"effects_chain",
	"effects_clothes",
	"effects_cum",
	"effects_grind",
#	"effects_handjob",
	"effects_hum",
	"effects_oral",
	"effects_plaps",
#	"effects_plaps2",
	"effects_sextoy",
	"effects_slap",
	"effects_spank",
	"effects_squirt",
]
var folders = []

var helpString:String = ""
var validNames = ["SoundMod_Effects", "SoundMod_pack_", "SoundMod_BGM", "SoundMod_"]

func folderCheck(_names:Array):
	var result = []
	for each in _names:
		if(each.begins_with("SoundMod_")):
			result.append(true)
		else:
			result.append(false)
	return result

func _init():
	id = "SoundModule_legacy"
	author = "bringlebangul"
	scenes = ["res://Modules/SoundModule_legacy/SoundTest.gd"]
	gameExtenders = [
		"res://Modules/SoundModule_legacy/PlaySounds.gd",
	]
	events = ["res://Modules/SoundModule_legacy/DebugEvent.gd"]
	
	var dir = Directory.new()
	if !dir.dir_exists(soundDir):
		dir.make_dir_recursive(soundDir)
		Log.printerr("[SoundMod] Somehow, the audio files are missing. Wtf?????")
	dir.open(soundDir)
	helpString += "Looking for audio files in "+ProjectSettings.globalize_path(soundDir)+"...\n"
	folders = sub_dir(soundDir)
	var actualFolders = []
	var checks = 0 #keep track of number of FoxLib audio objects created
	for packfolder in folders:
		if(packfolder.begins_with("SoundMod_Effects")): #this is the folder for sound effects
			var effectDir = soundDir + "SoundMod_Effects/"
			var EffectTypes = sub_dir(effectDir)
#			_numEff = EffectTypes.size()
			for type in EffectTypes:
				var name1 = type+"/"
				var dispName = name1.trim_prefix("effects_") #create the display name by editing the path as a string
				dispName = dispName.trim_suffix("/")
				if(dir.dir_exists(effectDir+name1)):
					dir.open(effectDir+name1)
					dir.list_dir_begin()
					var file = dir.get_next()
					EffectSound = self.newAudio("Effect"+dispName, dir.get_current_dir()+file)
					var files = dir_contents_minus_first(effectDir+name1)
					for entry in files:
						if entry.ends_with(".import"): #ignore .import files, they are only for use in the Godot editor
							continue
						var _temp = effectDir + name1 + entry
						EffectSound.addAudioPath(_temp) #FoxLib API to add audio
					dir.list_dir_end()
			Log.print("[SoundMod] Added "+String(EffectTypes.size())+ " sound effects")
			helpString += "Added "+String(EffectTypes.size())+ " sound effects\n"
			checks += EffectTypes.size()
			continue

		if(!is_valid_pack(soundDir+packfolder)):
			Log.printerr("[SoundMod] Error: Tried to read '"+soundDir+packfolder+"/' and did not find the correct directory structure.")
			helpString += "Error: Tried to read '"+soundDir+packfolder+"/' and did not find the correct directory structure.\n"
			continue
		else:
			actualFolders.append(packfolder)
		if(packfolder.begins_with("SoundMod_pack")): #this is one of possibly many voice pack folders
			var pack = packfolder.get_slice("_",2)
#			substr(packfolder.find("_")+1,-1)
			var Voicetypes = sub_dir(soundDir + packfolder)
			var list = (dir_contents(soundDir + packfolder))
			var s:String = "" #credits to voice actors and such
			for item in list:
				if item == "credits.txt":
					var f = File.new()
					f.open(soundDir + packfolder + "credits.txt", File.READ)
					s = f.get_as_text()
					f.close()
			for type in Voicetypes:
				var name1 = type + "/"
				var dispName = name1.trim_prefix("sounds_")
				dispName.erase(dispName.length()-1,1)
				name1 = packfolder + "/" + name1
				if(dir.dir_exists(soundDir+name1)):
					dir.open(soundDir+name1)
					dir.list_dir_begin()
					var file = dir.get_next()
					sound = self.newAudio("Sound"+dispName + pack, dir.get_current_dir()+file)
					var files = dir_contents_minus_first(soundDir+name1)
					for entry in files:
						if entry.ends_with(".import"):
							continue
						var _temp = soundDir + name1 + entry
						sound.addAudioPath(_temp)
					sound.setAuthor(s)
					dir.list_dir_end()
			Log.print("[SoundMod] Added voice "+packfolder.trim_prefix("SoundMod_")+" with "+String(Voicetypes.size())+ " sounds")
			helpString += "Added voice "+packfolder.trim_prefix("SoundMod_")+" with "+String(Voicetypes.size())+ " sounds\n"
			checks += Voicetypes.size()
	folders = actualFolders
	if FoxLibAudioManager.getAllAudioIDs().size() > 2:
		helpString += "FoxLib has created "+String(FoxLibAudioManager.getAllAudioIDs().size()-2)+" of "+String(checks)+" audio streams.\n" # minus two because the list given by FoxLib includes null and the FoxLib test audio
#	Log.print(String(FoxLibAudioManager.getAllAudioIDs()))
	helpString += "\n\nSoundMod Legacy version is self-contained and requires no unzipping.\nIf you still hear nothing:\n\t1.Check if Foxlib is working\n\t2.SoundMod might be incompatible with your device, sorry"
	FoxLibModInitHelper.callOnFoxLibModInit()

	
	
# runs after the game loads but before reaching the main menu
func postInit():
#	Log.print(String(GlobalRegistry.sexActivities.keys()))
	if(GlobalRegistry.getModule("FoxLib") == null):
		Log.print("[SoundMod] Error: "+id+" requires FoxLib")
		OS.alert("Error! SoundMod requires FoxLib! Please install Foxlib v"+foxlibversion+" or newer.", OS.get_executable_path())
	if(GlobalRegistry.getModule("SoundModule") != null):
		Log.print("[SoundMod] Error: "+id+" is not compatible with SoundMod. Only install one, not both.")
		OS.alert("Error: "+id+" is not compatible with SoundMod. Only install one, not both.", OS.get_executable_path())
#	var _temp = FoxLibAudioManager.getAllAudioIDs()	
	var f = File.new()
	if(f.file_exists("user://mods/.soundmodLockFile")): #check for hidden file, if it exists then SoundMod has been loaded before
		pass
	else:
		helpString = "SoundMod first-time setup! \nMake sure you installed FoxLib v0.10.7 or later!\nYou must select a voice pack in the Mod Options menu in order to hear audio playing!"
		f.open("user://mods/.soundmodLockFile", File.WRITE) #empty file created to indicate that this module has been loaded before
		f.close()
		validate(true) #make sure we validate since this is the first time
	
# function to check if folder names and paths are correct
func validate(_args):
#	Util.fixed_shell_open(ProjectSettings.globalize_path("res://Modules/SoundModule_legacy/README_soundmod.txt")) # in some OS this will open the README in the default text editor
	var dir = Directory.new()
	var checkMistake = GlobalRegistry.getModsFolder()+"/SoundMod.zip"
	var unzip = GDUnzip.new()
	unzip.load(checkMistake)
	var list = unzip.files
	for path in list:
		if("SoundMod_" in path):
			printerr("[SoundMod] Found audio folders inside"+ProjectSettings.globalize_path(checkMistake)+". Please delete and re-download.")
			helpString += "Error! Found audio folders inside"+ProjectSettings.globalize_path(checkMistake)+". Please delete and re-download."
			break
	dir.open(GlobalRegistry.getModsFolder())
	var _files = dir_contents(GlobalRegistry.getModsFolder())
	if(_files.has("Modules") || _files.has("SoundMod") || _files.has("SoundMod.json")): #check if the mod was extracted when it shouldn't be
		printerr("[SoundMod] It appears the mod itself was unzipped. Do not extract SoundMod.zip")
		helpString += "Error! It appears the mod itself was unzipped. Do not extract SoundMod.zip\n"
	var finalString = helpString #the helpstring was generated during loading, start with that
	OS.alert(finalString, OS.get_executable_path())

func onFoxLibModInit(foxModuleAPI):
#	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "openfiles", "Open audio folder", "Open the folder where sounds are saved").connect("option_changed", self, "open_mods_folder")
#	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "fixit", "Do it for me", "Try to unzip the audio files").connect("option_changed", self, "do_it_for_me")
	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "diditwork","Help! There's no sound!","Checks to see if you put audio in the right place").connect("option_changed", self, "validate")
#	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "installzip", "Select a .zip to add sounds", "Extracts a zip file to "+OS.get_user_data_dir()+"/soundmod/  \nWill overwrite existing!").connect("option_changed", self, "unzip_sounds")
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Settings","audiotest", "Show sound test in Me menu", "Show the sound test menu in the 'Me' menu",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Psoundoption", "Pleasure sounds", "Sound plays on arousal stat change",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Osoundoption", "Orgasm sounds", "Sound plays at orgasm",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Tsoundoption", "Tease sounds", "Sound plays on lust stat change",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","Ssoundoption", "Struggle sounds", "Sound plays on struggle attempt",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","gagsoundoption", "Gagged sounds", "Play variant sounds when gagged",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds","HypnoOption", "Hypno Hum", "Subtle hum when being hypnotized",true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "spankOption", "Spanking", "Play spanking sound effect when spanked", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "punchOption", "Spanking", "Play (mild) punching sound effect when beating up", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "clothOption", "Clothes rustle", "Play fabric noise when trying to remove clothing (will play even if removal gets resisted)", false)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "chainOption", "Chain noise", "Play metal clink when trying to leash or apply bondage (will play even if it gets resisted)", false)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "plapOption", "Plaps & glucks", "Play a short loop of plaps while fucking (timing will not sync)", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "cumEffect", "Cum effects", "Should ejaculation sounds play along with orgasm voice clips?", true)
	foxModuleAPI.addBooleanOptionInCategory("SoundMod Sounds", "squirtEffect", "Squirting", "Should characters with a vagina and no penis replace ejaculating with squirting?", true)
	foxModuleAPI.addSliderOptionInCategory("SoundMod Settings","pitchVarianceOption","Pitch variance","Slightly change pitch so sounds aren't repetitive", float(10))
	var select = []
	var dir = Directory.new()
	if !Util.folderExists(soundDir):
		dir.make_dir_recursive(soundDir)
	dir.open(soundDir)
	folders = sub_dir(soundDir)
	var actualFolders = []
	for packfolder in folders:
		if(!is_valid_pack(soundDir+packfolder)):
			continue
		else:
			actualFolders.append(packfolder.trim_prefix("SoundMod_"))
	for entry in actualFolders:
		select.append([entry, entry])
	select.append(["debug blank", "debug none"])
	foxModuleAPI.addListOptionInCategory("SoundMod Settings", "voicepackoption", "Voice Pack", select, "Select a voice pack. Packs are added by making a folder in the audio folder", "error")
#	foxModuleAPI.addBooleanOptionInCategory("SoundMod Settings", "BGMOption", "Background Music (EXPERIMENTAL)", "Play BGM sounds based on location", false).connect("option_changed", self, "showhideBGM")
#	foxModuleAPI.addSliderOptionInCategory("SoundMod Settings", "BGMVolume", "BGM volume (EXPERIMENTAL)","Volume for BGM sound", 50)
#	foxModuleAPI.addButtonOptionInCategory("SoundMod Settings", "BGMassign", "Assign BGM (EXPERIMENTAL)", "Assign music to locations").connect("option_changed", self, "BGM_popup")


#returns all the directories within the given directory (ignores files)
func sub_dir(path):
	var dir = Directory.new()
	var _folds:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir() && file_name != "." && file_name != "..":
				_folds.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to access the folder " +path)
	dir.list_dir_end()
	return _folds
	
# is this an audio file?
func is_this_audio(_filepath):
	if(_filepath.ends_with(".mp3") || _filepath.ends_with(".ogg") || _filepath.ends_with(".wav")):
		return true
	else:
		return false
	
# checks if the given directory has the expected directory structure for voice packs
func is_valid_pack(folder):
	var dir = Directory.new()
	var valid = false
	if dir.open(folder + "/") == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir() && file_name != "." && file_name != "..":
				if packReq.has(file_name):
					valid = true
				else:
					valid = false
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to access the folder " +folder)
	dir.list_dir_end()
	return valid	

# lists all the files in the given directory except the first one (assuming the first file was imported as a test)
func dir_contents_minus_first(path):
	var dir = Directory.new()
	var _file_names:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		dir.get_next()
		var file_name = dir.get_next()
		while(file_name != ""):
			if (!file_name.ends_with("import") && file_name != "." && file_name != ".."):
				_file_names.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to get the contents of " +path)
	dir.list_dir_end()
	return _file_names
	
# lists all the files in the given directory
func dir_contents(path):
	var dir = Directory.new()
	var _file_names:Array
	if dir.open(path) == OK:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while(file_name != ""):
			if (file_name != "." && file_name != ".."):
				_file_names.append(file_name)
			file_name = dir.get_next()
	else:
		printerr("[SoundMod] An error occurred when trying to get the contents of " +path)
	dir.list_dir_end()
	return _file_names
