extends "res://Scenes/CharacterCreatorScene.gd"

# Same sceneID as the vanilla character creator, registered later by this mod so it replaces it.
# Only adds a "Head layer order" button to the Body attributes menu, everything else is vanilla.

func _run():
	._run()
	if(state == "bodyAttributes"):
		addButton("Head layer order", "Choose which head features (horns, hair, ears) are drawn on top of each other", "headlayerorder")

func _react(_action: String, _args):
	if(_action == "headlayerorder"):
		runScene("HeadLayerOrderScene")
		return
	._react(_action, _args)
