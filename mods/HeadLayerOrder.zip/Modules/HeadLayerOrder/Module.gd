extends Module

# Drawing order of head features on the doll, configured via FoxLib "Mod Options".
# All doll parts are transparent flat meshes that Godot sorts by depth (z, camera looks along -z),
# so a part with a bigger z is drawn on top. Vanilla values are mixed (hair 0.028, horns 0.02,
# most ears ~0.1), which is why ears/horns/hair overlap inconsistently.
# This module watches parts being attached to a doll skeleton and moves their meshes along z so
# every front-facing mesh of a slot lands on that slot's layer. Moving the real z (not just
# sorting_offset) matters: the pattern shader uses depth_draw_alpha_prepass, so opaque pixels write
# depth and would still hide parts that are sorted in front of them. Meshes behind the head
# (z < 0, e.g. the back half of long hair) are left alone. No game files are replaced.

const CATEGORY = "Head layer order"
const GROUP = "HeadLayerOrderPart"

const LAYER_BASE_Z = 0.02  # layer 1 (just in front of the head/muzzle at ~0.01)
const LAYER_STEP_Z = 0.03  # distance between layers
const MAX_INNER_SPREAD = 0.02 # keeps the order of several front meshes inside one part
const BACK_THRESHOLD_Z = -0.005 # meshes below this are behind the head and stay untouched
const MAX_LAYER = 6

var enabled = true
var layers = {} # slot -> layer (0 = vanilla), kept in sync by FoxLib
var headSlots = ["horns", "hair", "ears"]

func _init():
	id = "HeadLayerOrder"
	author = "45hr4k"

	scenes = [
		"res://Modules/HeadLayerOrder/HeadLayerOrderScene.gd",
		# Vanilla scenes with an extra button (same sceneID, so they replace the originals)
		"res://Modules/HeadLayerOrder/CharacterCreatorSceneHLO.gd",
		"res://Modules/HeadLayerOrder/ChangeHaircutSceneHLO.gd",
	]

	var tree = Engine.get_main_loop()
	if(tree is SceneTree && !tree.is_connected("node_added", self, "onNodeAdded")):
		var _ok = tree.connect("node_added", self, "onNodeAdded")

func onFoxLibModInit(foxModuleAPI):
	# Called after all mods are loaded, so modded bodypart slots are known here
	headSlots = ["horns", "hair", "ears"]
	for slot in BodypartSlot.getAll():
		if(slot in headSlots || slot == BodypartSlot.Head):
			continue
		if(BodypartSlot.getSlotChildName(slot) == "head"):
			headSlots.append(slot)

	var enabledOption = foxModuleAPI.addBooleanOptionInCategory(CATEGORY, "enabled", "Enabled",
		"Off = vanilla drawing order for all head features.", true)
	var _ok = enabledOption.connect("option_changed", self, "onOptionChanged")

	var values = [[0, "Original (unchanged)"]]
	for i in range(1, MAX_LAYER + 1):
		values.append([i, getLayerName(i)])

	for slot in headSlots:
		var option = foxModuleAPI.addListOptionInCategory(CATEGORY, "layer_"+slot, BodypartSlot.getVisibleName(slot), values,
			"Layer of '"+slot+"' on the head. 1 = furthest back, "+str(MAX_LAYER)+" = furthest front.\nSlots with the same number keep their original order between each other.\nOriginal = don't change this slot.", 0).bindToField(layers, slot)
		_ok = option.connect("option_changed", self, "onOptionChanged")

static func getLayerName(layer) -> String:
	if(layer <= 0):
		return "Original"
	if(layer == 1):
		return "1 (furthest back)"
	if(layer == MAX_LAYER):
		return str(layer)+" (furthest front)"
	return str(layer)

func onOptionChanged(_value):
	refreshAll()

# FoxLib event: Godot scene changed
func onSceneChanged(newScene):
	if(!str(newScene).begins_with("MainScene:[") || !is_instance_valid(GM.main)):
		return
	if(!GM.main.is_connected("saveLoadingFinished", self, "refreshAll")):
		var _ok = GM.main.connect("saveLoadingFinished", self, "refreshAll")

# Re-apply to every doll that is currently on screen
func refreshAll():
	var tree = Engine.get_main_loop()
	if(!(tree is SceneTree)):
		return
	for part in tree.get_nodes_in_group(GROUP):
		applyToPart(part)

func onNodeAdded(node):
	# Doll3D.addPartObject(): skeleton.add_child(part), then part.initPart() -> handle it afterwards
	if(!node.has_method("initPart") || !(node.get_parent() is Skeleton)):
		return
	call_deferred("onPartAdded", weakref(node))

func onPartAdded(partRef):
	var part = partRef.get_ref()
	if(part == null || !is_instance_valid(part) || !part.is_inside_tree()):
		return
	var slot = findSlot(part)
	if(slot == null || !(slot in headSlots)):
		return
	part.set_meta("headLayerSlot", slot)
	part.set_meta("headLayerMeshes", collectMeshes(part))
	if(!part.is_in_group(GROUP)):
		part.add_to_group(GROUP)
	applyToPart(part)

func findSlot(part):
	var doll = part.get("doll3D")
	if(doll == null || !is_instance_valid(doll)):
		return null
	var parts = doll.get("parts")
	if(!(parts is Dictionary)):
		return null
	for slot in parts:
		if(parts[slot] == part):
			return slot
	return null

# Returns [[MeshInstance, original z relative to the part, original translation.z, index of the nearest
# collected ancestor mesh or -1], ...]. Parents always come before their children.
func collectMeshes(part) -> Array:
	var result = []
	var partInverse = part.global_transform.affine_inverse()
	var stack = [[part, -1]]
	while(!stack.empty()):
		var item = stack.pop_back()
		var node = item[0]
		var ancestorIndex = item[1]
		if(node is MeshInstance && node.mesh != null):
			var aabb = node.get_aabb()
			var center = (partInverse * node.global_transform).xform(aabb.position + aabb.size * 0.5)
			result.append([node, center.z, node.translation.z, ancestorIndex])
			ancestorIndex = result.size() - 1
		for child in node.get_children():
			if(child is Spatial):
				stack.append([child, ancestorIndex])
	return result

func getFlags():
	return {
		"layers": flag(FlagType.Dict), # slot -> layer, set in the character creator / mirror
	}

func getSaveLayers():
	if(!is_instance_valid(GM.main)):
		return null
	var saveLayers = GM.main.getModuleFlag(id, "layers", null)
	if(!(saveLayers is Dictionary) || saveLayers.empty()):
		return null
	return saveLayers

func hasSaveLayers() -> bool:
	return getSaveLayers() != null

func setSaveLayer(slot, layer):
	if(!is_instance_valid(GM.main)):
		return
	var saveLayers = getSaveLayers()
	if(saveLayers == null):
		# First change in this save: start from the Mod Options values for every slot
		saveLayers = {}
		for headSlot in headSlots:
			saveLayers[headSlot] = getOptionLayer(headSlot)
	else:
		saveLayers = saveLayers.duplicate()
	saveLayers[slot] = int(layer)
	GM.main.setModuleFlag(id, "layers", saveLayers)
	refreshAll()

func clearSaveLayers():
	if(!is_instance_valid(GM.main)):
		return
	GM.main.clearModuleFlag(id, "layers")
	refreshAll()

func getOptionLayer(slot) -> int:
	if(!layers.has(slot) || layers[slot] == null):
		return 0
	return int(clamp(int(layers[slot]), 0, MAX_LAYER))

# Save values win over the Mod Options defaults, "enabled" switches everything off
func getLayer(slot, ignoreEnabled = false) -> int:
	if(!enabled && !ignoreEnabled):
		return 0
	var saveLayers = getSaveLayers()
	if(saveLayers != null && saveLayers.has(slot) && saveLayers[slot] != null):
		return int(clamp(int(saveLayers[slot]), 0, MAX_LAYER))
	return getOptionLayer(slot)

func applyToPart(part):
	if(!is_instance_valid(part) || !part.has_meta("headLayerSlot")):
		return
	var layer = getLayer(part.get_meta("headLayerSlot"))
	var meshes = part.get_meta("headLayerMeshes")

	var minFrontZ = null
	for entry in meshes:
		if(entry[1] >= BACK_THRESHOLD_Z && (minFrontZ == null || entry[1] < minFrontZ)):
			minFrontZ = entry[1]

	var shifts = [] # z shift per entry, children subtract the shift their ancestor mesh already got
	for entry in meshes:
		var mesh = entry[0]
		var z = entry[1]
		var shift = 0.0
		if(layer > 0 && minFrontZ != null && z >= BACK_THRESHOLD_Z):
			# Tiny tie-breaker from the original z keeps the vanilla order between slots on the same layer
			var targetZ = LAYER_BASE_Z + (layer - 1) * LAYER_STEP_Z + min(z - minFrontZ, MAX_INNER_SPREAD) + clamp(minFrontZ, 0.0, 0.5) * 0.01
			shift = targetZ - z
		shifts.append(shift)
		if(!is_instance_valid(mesh)):
			continue
		var ancestorShift = shifts[entry[3]] if entry[3] >= 0 else 0.0
		mesh.translation.z = entry[2] + shift - ancestorShift
