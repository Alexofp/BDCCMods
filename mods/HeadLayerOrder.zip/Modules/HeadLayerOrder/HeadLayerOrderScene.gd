extends "res://Scenes/SceneBase.gd"

# Menu to pick the head layer order for this save (applies to every character).
# Opened from the character creator (Body attributes) and from the mirror (ChangeHaircutScene).

var pickingSlot = ""

func _init():
	sceneID = "HeadLayerOrderScene"

func getHLO():
	return GlobalRegistry.getModules().get("HeadLayerOrder")

func getLayerText(layer) -> String:
	return getHLO().getLayerName(layer)

func _run():
	var hlo = getHLO()
	if(hlo == null):
		saynn("HeadLayerOrder module is missing.")
		addButton("Back", "Go back", "endthescene")
		return

	if(state == ""):
		saynn("Choose which head features are drawn on top of each other. Layer 1 is furthest back, layer "+str(hlo.MAX_LAYER)+" is furthest front. Original = the game's own order.")
		saynn("This is saved with your game and applies to every character, not just you.")
		if(!hlo.enabled):
			saynn("[b]Head layer order is disabled in the Mod Options, these values have no effect right now.[/b]")
		if(!hlo.hasSaveLayers()):
			saynn("Currently using the defaults from the Mod Options.")

		for slot in hlo.headSlots:
			sayn(BodypartSlot.getVisibleName(slot)+": "+getLayerText(hlo.getLayer(slot, true)))
		sayn("")

		addButton("Done", "You're done", "endthescene")
		for slot in hlo.headSlots:
			addButton(BodypartSlot.getVisibleName(slot), "Change the layer of "+BodypartSlot.getVisibleNameNoCap(slot), "pickslot", [slot])
		if(hlo.hasSaveLayers()):
			addButton("Use defaults", "Forget the values of this save and use the defaults from the Mod Options again", "resetlayers")
		else:
			addDisabledButton("Use defaults", "Already using the defaults from the Mod Options")

	if(state == "pickslot"):
		saynn("Pick the layer for "+BodypartSlot.getVisibleNameNoCap(pickingSlot)+". Layer 1 is furthest back, layer "+str(hlo.MAX_LAYER)+" is furthest front.")
		saynn("Current: "+getLayerText(hlo.getLayer(pickingSlot, true)))

		addButton("Back", "Go back", "")
		addButton("Original", "Don't change how this slot is drawn", "setlayer", [0])
		for i in range(1, hlo.MAX_LAYER + 1):
			var buttonText = str(i)
			if(i == 1):
				buttonText += " (back)"
			elif(i == hlo.MAX_LAYER):
				buttonText += " (front)"
			addButton(buttonText, "Put "+BodypartSlot.getVisibleNameNoCap(pickingSlot)+" on layer "+getLayerText(i), "setlayer", [i])

func _react(_action: String, _args):
	var hlo = getHLO()

	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "pickslot"):
		pickingSlot = _args[0]

	if(_action == "setlayer"):
		if(hlo != null):
			hlo.setSaveLayer(pickingSlot, _args[0])
		setState("")
		return

	if(_action == "resetlayers"):
		if(hlo != null):
			hlo.clearSaveLayers()
		setState("")
		return

	setState(_action)

func saveData():
	var data = .saveData()
	data["pickingSlot"] = pickingSlot
	return data

func loadData(data):
	.loadData(data)
	pickingSlot = SAVE.loadVar(data, "pickingSlot", "")
