extends "res://Scenes/ChangeHaircutScene.gd"

# Same sceneID as the vanilla mirror scene, registered later by this mod so it replaces it.
# Only adds a "Head layer order" button to the first menu, everything else is vanilla.

func _run():
	._run()
	if(state == ""):
		addButton("Head layers", "Choose which head features (horns, hair, ears) are drawn on top of each other", "headlayerorder")

func _react(_action: String, _args):
	if(_action == "headlayerorder"):
		runScene("HeadLayerOrderScene")
		return
	._react(_action, _args)
