extends Module

var dickOptions : Dictionary = { # DICKtionary :3
	# dick id: option
}

func _init():
	id = "WintersExpandedPenises"
	author = "Avery Winters & Selinoccino"
	
	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Bodyparts/")
	
	partSkins = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Skins/")

func register():
	var modules = GlobalRegistry.getModules().keys()
	if "RodentUtils" in modules:
		bodyparts.append("res://Modules/WintersExpandedPenises/CompatibilityPatches/RatMode/CursedOvipositor/CursedOvipositor.gd")
		
	
	.register()
	
	var temp : String = "res://Modules/WintersExpandedPenises/WinterablePenisTemplate"
	
	
	
	if "BallsExtra" in modules:
		var c : Reference = GlobalRegistry.getModule("WintersCoreModule").createCodegen()
		
		c.setExtend('"%s.gd"' % temp, '"%sBALLS.gd"' % temp).do(bodyparts, true, true, false)
		
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/CompatibilityPatches/BallsExtra/"):
			GlobalRegistry.registerBodypart(bp)
	
	else:
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/CompatibilityPatches/BDCC/"):
			GlobalRegistry.registerBodypart(bp)
	
		if "Hypertus" in modules:
			var c : Reference = GlobalRegistry.getModule("WintersCoreModule").createCodegen()
		
			c.formatId("%shyperable").formatName("Hyper %s").setExtend('"%s.gd"' % temp, '"%sHyper.gd"' % temp).setTraits({"Hyperable": true }).do(bodyparts, true, false, true)
		
			c.formatName("%shyperable").doPartSkins(partSkins)
		
	

func isDickEnabled(dick:String) -> bool:
	var option = dickOptions.get(dick)
	if option:
		return option.getValue()
	
	return getDefaultForDick(dick)

func getDefaultForDick(dick:String) -> bool:
	var dicko = GlobalRegistry.getBodypartRef(dick)
	if !dicko:
		return false
	return dicko.isWinteredDefault() if dicko.has_method("isWinteredDefault") else false

func RatConfigure(ratconf):
	ratconf.overrideModConfigName(id, "Winter's Expanded Penises")
	#ratconfig.getOrCreateModConfig(id).overrideName("Winter's Expanded Penises").overrideAuthor("Avery & Selinoccino")
	
	ratconf.addCategory(id, getCategoryName({}))
	for thing in [PartTrait.PenisBarbs, PartTrait.PenisFlare, PartTrait.PenisKnot, PartTrait.PenisRidges, PartTrait.Ovipositor]:
		ratconf.addCategory(id, getCategoryName({thing:true}))
	
	ratconf.addCategory(id, "Tapered")
	
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Penis)
	for dickid in all:
		var bp = GlobalRegistry.getBodypartRef(dickid)
		if bp.has_method("isWinterable") && bp.isWinterable():
			var disp : String = bp.visibleName if bp else ("Error (%s)" % dickid)
			disp[0] = disp[0].to_upper()
			var desc : String = "Created by: %s\n\nEnable or disable this dick" % (bp.author if bp && bp.author else "(unknown)")
			
			var cat : String = getCategoryName(bp.getTraits())
			
			var ln : String = bp.visibleName.to_lower()
			if cat != "Hyper":
				if ln.begins_with("tapered"):
					cat = "Tapered"
				elif ln.begins_with("flared"):
					cat = "Flared"
				
			
			
			dickOptions[dickid] = ratconf.addOptionBool(id, dickid, cat, disp, desc, getDefaultForDick(dickid))
	

func getCategoryName(traits) -> String:
	if !traits:
		return "Generic"
	
	if traits.get("Hyperable", false):
		return "Hyper"
	
	var t = traits.keys()[0]
	if t == PartTrait.PenisBarbs:
		return "Barbed"
	elif t == PartTrait.PenisFlare:
		return "Flared"
	elif t == PartTrait.PenisKnot:
		return "Knotted"
	elif t == PartTrait.PenisRidges:
		return "Ridged"
	elif t == PartTrait.Ovipositor:
		return "Ovipositor"

	return "Generic"

func RatArchetify():
	var ratcalls : Reference = load("res://Modules/WintersExpandedPenises/CompatibilityPatches/RatMode/UNIVERSAL_SPECIES_CALLABLES.gd").new()
	for species in GlobalRegistry.getAllSpecies().values():
		ratcalls.registerToSpecies(species)
