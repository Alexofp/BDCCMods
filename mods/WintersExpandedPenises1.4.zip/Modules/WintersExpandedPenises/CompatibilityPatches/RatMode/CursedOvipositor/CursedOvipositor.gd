extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Cursed Ovipositor"
	id = "cursedovipositor"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any] if GlobalRegistry.getModule("RodentUtils").ratmode else []

func isWinterable() -> bool:
	return false

func initFluidProduction():
	fluidProduction = preload("res://Player/FluidProduction/CumAndEggsProduction.gd").new()
	fluidProduction.bodypart = weakref(self)
	
	fluidProduction.maxEggs = 10
	fluidProduction.eggsPerHour = 0.5
	fluidProduction.eggsSlowStart = 1
	fluidProduction.eggsPerHourSlow = 0.05

func getLewdAdjective():
	return RNG.pick(["ovipositor"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/CompatibilityPatches/RatMode/CursedOvipositor/CursedOvipositor.tscn"

func getTraits():
	return {
		PartTrait.Ovipositor: true,
	}

func getVulgarName() -> String:
	return "ovipositor cock"

func canStuffEggInto(_targetChar, _bodypart:String) -> bool:
	if(fluidProduction.getEggsAmount() <= 0):
		return false
	return true

func doStuffEggInto(_targetChar, _bodypart:String) -> Dictionary:
	if(!fluidProduction.useEgg()):
		return {success = false}
	var targetMenstrualCycle:MenstrualCycle = _targetChar.getMenstrualCycle()
	if(!targetMenstrualCycle):
		return {success = false}
	
	var unfertilizedEggCell := EggCell.new()
	unfertilizedEggCell.bigEgg = true
	unfertilizedEggCell.bigEggType = BigEggType.Unfertilized
	unfertilizedEggCell.laidType = BigEggType.Unfertilized
	unfertilizedEggCell.laidColor = Color.whitesmoke
	unfertilizedEggCell.isimpregnated = false
	unfertilizedEggCell.lifeSpan = 12*60*60 # 12 hours
	
	targetMenstrualCycle.injectEggCell(unfertilizedEggCell, OrificeType.fromBodypart(_bodypart))
	
	var theHole:String = "down {<TARGET>.your} hole"
	if(_bodypart == BodypartSlot.Vagina):
		theHole = "into {<TARGET>.your} pussy"
	if(_bodypart == BodypartSlot.Anus):
		theHole = "into {<TARGET>.your} anus"
	if(_bodypart == BodypartSlot.Head):
		theHole = "down {<TARGET>.your} throat"
	
	var theTextLine:String = "An unfertilized egg gets [b]stuffed "+theHole+"[/b] by {<USER>.your} ovipositor."
	theTextLine = theTextLine.replace("<TARGET>", _targetChar.getID())
	theTextLine = theTextLine.replace("<USER>", getCharacter().getID())
	
	return {
		success = true,
		text = theTextLine,
	}
