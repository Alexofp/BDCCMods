extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Tapered knotted penis"
	id = "taperedpenisknot"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getLewdAdjective():
	return RNG.pick(["knotted", "avian", "tapered", "smooth"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Tapered/TaperedKnottedPenis/TaperedKnottedPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}
