extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Tapered wide penis"
	id = "taperedwidepenis"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getLewdAdjective():
	return RNG.pick(["smooth", "tapered"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Tapered/TaperedWidePenis/TaperedWidePenis.tscn"
