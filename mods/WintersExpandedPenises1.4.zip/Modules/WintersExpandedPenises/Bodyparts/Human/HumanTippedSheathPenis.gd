extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Human tipped sheathed penis"
	id = "humantippedsheathpenis"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Human/HumanTippedSheathPenis/HumanTippedSheathPenis.tscn"

func getVulgarName() -> String:
	return "cock"

func generateRandomColors(_dynamicCharacter):
	pass
