extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Human tipped sheathed dual penis"
	id = "humantippeddualpenis"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func isWinteredDefault() -> bool:
	return false # Sets default option for penis

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Human/HumanTippedSheathDualPenis/HumanTippedSheathDualPenis.tscn"

func getVulgarName() -> String:
	return "cock"

func generateRandomColors(_dynamicCharacter):
	pass
