extends BodypartHead

func _init():
	visibleName = "human head Alt1"
	id = "shumanhead1"

func getCompatibleSpecies():
	return [Species.Human, Species.Demon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Humanoid/shumanhead1.tscn"

func getHeadLength():
	return 0.0
