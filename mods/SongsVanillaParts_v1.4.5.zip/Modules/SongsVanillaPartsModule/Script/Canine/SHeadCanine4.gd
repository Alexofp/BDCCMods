extends BodypartHead

func _init():
	visibleName = "Canine Head Alt 4"
	id = "scaninehead4"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Canine/SHeadCanine4/sheadCanine4.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
