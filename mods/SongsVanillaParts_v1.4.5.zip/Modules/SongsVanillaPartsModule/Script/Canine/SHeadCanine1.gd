extends BodypartHead

func _init():
	visibleName = "Canine Head Alt 1"
	id = "scaninehead1"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Canine/SHeadCanine1/sheadCanine1.tscn"

func getHeadLength():
	return 0.35

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
