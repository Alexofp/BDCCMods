extends BodypartHead

func _init():
	visibleName = "Canine Head Alt 3"
	id = "scaninehead3"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Canine/SHeadCanine3/sheadCanine3.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
