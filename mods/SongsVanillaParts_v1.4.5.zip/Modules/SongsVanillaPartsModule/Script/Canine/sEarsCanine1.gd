extends BodypartEars

func _init():
	visibleName = "Canine Ears Alt 1"
	id = "scanineears1"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Canine/SEarsCanine1/searsCanine1.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
