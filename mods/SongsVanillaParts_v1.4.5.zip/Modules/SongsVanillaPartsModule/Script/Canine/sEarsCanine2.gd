extends BodypartEars

func _init():
	visibleName = "Canine Ears Alt 2"
	id = "scanineears2"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Canine/SEarsCanine2/searsCanine2.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
