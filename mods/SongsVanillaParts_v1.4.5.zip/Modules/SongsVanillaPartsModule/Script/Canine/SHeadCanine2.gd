extends BodypartHead

func _init():
	visibleName = "Canine Head Alt 2"
	id = "scaninehead2"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Canine/SHeadCanine2/sheadCanine2.tscn"

func getHeadLength():
	return 0.55

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
