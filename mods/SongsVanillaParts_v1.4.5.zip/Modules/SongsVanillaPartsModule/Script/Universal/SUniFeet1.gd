extends BodypartLeg

func _init():
	visibleName = "Planti legs alt 1"
	id = "slegs1"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniFeet1/SUniFeet1.tscn"

func getTraits():
	return {
		PartTrait.LegsPlanti: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
