extends BodypartTail

func _init():
	visibleName = "tail alt 1"
	id = "tailalt1"

func getCompatibleSpecies():
	return [Species.Canine, Species.Feline, Species.Equine]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["fluffy"])

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniTail1/SUniTail1.tscn"
