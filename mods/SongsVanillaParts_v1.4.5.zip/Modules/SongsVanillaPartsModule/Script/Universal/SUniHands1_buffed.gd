extends BodypartArms

func _init():
	visibleName = "Buff Arms ALT 1"
	id = "sbuffarms1"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniHands1/SUniHands1_buffed.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
