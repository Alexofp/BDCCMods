extends BodypartTail

func _init():
	visibleName = "tail alt 3"
	id = "tailalt3"

func getCompatibleSpecies():
	return [Species.Canine, Species.Feline]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniTail3/SUniTail3.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
