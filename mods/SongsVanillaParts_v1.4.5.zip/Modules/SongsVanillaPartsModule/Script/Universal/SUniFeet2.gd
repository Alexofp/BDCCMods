extends BodypartLeg

func _init():
	visibleName = "Digi legs alt 1"
	id = "slegs2"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniFeet2/SUniFeet2.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
