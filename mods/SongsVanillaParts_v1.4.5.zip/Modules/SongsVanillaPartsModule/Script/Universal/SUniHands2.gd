extends BodypartArms

func _init():
	visibleName = "anthro arms ALT 2"
	id = "santhroarms2"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniHands2/SUniHands2.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
