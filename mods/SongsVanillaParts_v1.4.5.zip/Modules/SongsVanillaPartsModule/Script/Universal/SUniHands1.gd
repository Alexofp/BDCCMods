extends BodypartArms

func _init():
	visibleName = "anthro arms ALT 1"
	id = "santhroarms1"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniHands1/SUniHands1.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
