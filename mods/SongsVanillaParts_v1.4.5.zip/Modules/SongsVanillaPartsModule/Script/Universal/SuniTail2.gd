extends BodypartTail

func _init():
	visibleName = "tail alt 2"
	id = "tailalt2"

func getCompatibleSpecies():
	return [Species.Canine, Species.Feline]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniTail2/SUniTail2.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
