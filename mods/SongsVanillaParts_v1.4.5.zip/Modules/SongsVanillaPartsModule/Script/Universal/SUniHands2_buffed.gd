extends BodypartArms

func _init():
	visibleName = "Buff Arms ALT 2"
	id = "sbuffarms2"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Universal/SUniHands2/SUniHands2_buffed.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
