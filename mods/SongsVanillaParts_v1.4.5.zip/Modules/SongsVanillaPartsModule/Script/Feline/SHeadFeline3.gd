extends BodypartHead

func _init():
	visibleName = "Feline Head Alt 3"
	id = "sfelinehead3"

func getCompatibleSpecies():
	return [Species.Feline]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Feline/SHeadFeline3/sheadFeline3.tscn"

func getHeadLength():
	return 0.35

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
