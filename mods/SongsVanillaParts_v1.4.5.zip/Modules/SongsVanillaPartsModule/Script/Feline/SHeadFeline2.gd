extends BodypartHead

func _init():
	visibleName = "Feline Head Alt 2"
	id = "sfelinehead2"

func getCompatibleSpecies():
	return [Species.Feline]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Feline/SHeadFeline2/sheadFeline2.tscn"

func getHeadLength():
	return 0.25

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
