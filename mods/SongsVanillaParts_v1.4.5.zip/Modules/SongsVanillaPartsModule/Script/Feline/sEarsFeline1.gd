extends BodypartEars

func _init():
	visibleName = "Feline Ears Alt 1"
	id = "sfelineears1"

func getCompatibleSpecies():
	return [Species.Feline]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Feline/SEarsFeline1/searsFeline1.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
