extends BodypartHead

func _init():
	visibleName = "Feline Head Alt 1"
	id = "sfelinehead1"

func getCompatibleSpecies():
	return [Species.Feline]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Feline/SHeadFeline1/sheadFeline1.tscn"

func getHeadLength():
	return 0.25

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
