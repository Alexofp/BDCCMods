extends BodypartLeg

func _init():
	visibleName = "Songs Hoofs"
	id = "songhoofs"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Horse/SHorseHoof/shoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
