extends BodypartTail

func _init():
	visibleName = "Songs Horse Tail 1"
	id = "songhtail"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Horse/SHorseTails/stailHorse.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
