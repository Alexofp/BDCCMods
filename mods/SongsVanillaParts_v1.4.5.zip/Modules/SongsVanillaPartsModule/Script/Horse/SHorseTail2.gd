extends BodypartTail

func _init():
	visibleName = "Songs horse Tail 2"
	id = "songhtail2"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Horse/SHorseTails/stailHorse2.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
