extends BodypartHorns

func _init():
	visibleName = "Horse Horn Alt 1"
	id = "sdeerantlers3"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Horse/SHorseHorn1/SHorseHorn1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

