extends BodypartHead

func _init():
	visibleName = "Horse Head Alt"
	id = "songhorsehead"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Horse/SHorseHead/sheadHorse.tscn"

func getHeadLength():
	return 0.30

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
