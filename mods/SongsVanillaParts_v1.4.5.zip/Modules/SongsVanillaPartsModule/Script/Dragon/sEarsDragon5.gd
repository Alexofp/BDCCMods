extends BodypartEars

func _init():
	visibleName = "dragon ears Alt 5"
	id = "sdragonears5"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonEars5/sdragonEars5.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
