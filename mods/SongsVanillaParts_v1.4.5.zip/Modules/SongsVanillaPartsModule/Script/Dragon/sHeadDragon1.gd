extends BodypartHead

func _init():
	visibleName = "dragon head Alt 1"
	id = "sdragonhead1"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHead1/sdragonHead1.tscn"

func getHeadLength():
	return 0.5

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
