extends BodypartEars

func _init():
	visibleName = "dragon ears Alt 2"
	id = "sdragonears2"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonEars2/sdragonEars2.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
