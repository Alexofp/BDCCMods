extends BodypartLeg

func _init():
	visibleName = "Dragon legs alt 1 Fluffy"
	id = "sdragonlegs1f"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonLegs1f/slegsDragon1f.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts (made by moldy tub)"

func npcGenerationWeight(_dynamicCharacter):
	var head_id = ""
	if _dynamicCharacter.saveData().has("bodyparts"):
		head_id = _dynamicCharacter.saveData().bodyparts["head"]["id"]

	if head_id == "sdragonhead2":
		return 1.0
	else:
		return 0.0
