extends BodypartHorns

func _init():
	visibleName = "dragon horns Alt 2"
	id = "sdragonhorns2"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHorns2/sdragonHorns2.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
