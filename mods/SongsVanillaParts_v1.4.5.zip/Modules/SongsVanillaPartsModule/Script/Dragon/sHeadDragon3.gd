extends BodypartHead

func _init():
	visibleName = "dragon head Alt 3"
	id = "sdragonhead3"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHead3/sdragonHead3.tscn"

func getHeadLength():
	return 0.6

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
