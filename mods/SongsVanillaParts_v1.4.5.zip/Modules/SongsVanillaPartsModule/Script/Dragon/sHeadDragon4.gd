extends BodypartHead

func _init():
	visibleName = "dragon head Alt 4"
	id = "sdragonhead4"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHead4/sdragonHead4.tscn"

func getHeadLength():
	return 0.6

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
