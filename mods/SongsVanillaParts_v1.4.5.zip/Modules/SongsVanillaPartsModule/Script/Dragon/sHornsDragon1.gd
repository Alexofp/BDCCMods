extends BodypartHorns

func _init():
	visibleName = "dragon horns Alt 1"
	id = "sdragonhorns1"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHorns1/sdragonHorns1.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
