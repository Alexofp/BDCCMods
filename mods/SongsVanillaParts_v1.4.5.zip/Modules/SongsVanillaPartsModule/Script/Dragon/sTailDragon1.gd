extends BodypartTail

func _init():
	visibleName = "dragon tail alt 1"
	id = "sdragontail1"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonTail1/staildragon.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func npcGenerationWeight(_dynamicCharacter):
	var head_id = ""
	if _dynamicCharacter.saveData().has("bodyparts"):
		head_id = _dynamicCharacter.saveData().bodyparts["head"]["id"]

	if head_id == "sdragonhead2":
		return 1.0
	else:
		return 0.1
