extends BodypartHorns

func _init():
	visibleName = "dragon horns Alt 3"
	id = "sdragonhorns3"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHorns3/sdragonHorns3.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"

func npcGenerationWeight(_dynamicCharacter):
	var head_id = ""
	if _dynamicCharacter.saveData().has("bodyparts"):
		head_id = _dynamicCharacter.saveData().bodyparts["head"]["id"]

	if head_id == "sdragonhead2":
		return 8.0
	elif head_id == "sdragonhead4":
		return 40.0
	else:
		return 0.1
