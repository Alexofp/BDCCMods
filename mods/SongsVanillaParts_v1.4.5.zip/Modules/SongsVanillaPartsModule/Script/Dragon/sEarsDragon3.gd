extends BodypartEars

func _init():
	visibleName = "dragon ears Alt 3"
	id = "sdragonears3"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonEars3/sdragonEars3.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
