extends BodypartLeg

func _init():
	visibleName = "Dragon legs alt 1"
	id = "sdragonlegs1"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonLegs1/slegsDragon1.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
