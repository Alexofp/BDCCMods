extends BodypartEars

func _init():
	visibleName = "dragon ears Alt 4"
	id = "sdragonears4"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonEars4/sdragonEars4.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"

func npcGenerationWeight(_dynamicCharacter):
	var head_id = ""
	if _dynamicCharacter.saveData().has("bodyparts"):
		head_id = _dynamicCharacter.saveData().bodyparts["head"]["id"]

	if head_id == "sdragonhead2":
		return 20.0
	else:
		return 0.0
