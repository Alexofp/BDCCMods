extends BodypartHead

func _init():
	visibleName = "dragon head Alt 2"
	id = "sdragonhead2"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonHead2/sdragonHead2.tscn"

func getHeadLength():
	return 0.6

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
