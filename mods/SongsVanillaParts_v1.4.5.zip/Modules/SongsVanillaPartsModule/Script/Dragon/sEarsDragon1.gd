extends BodypartEars

func _init():
	visibleName = "dragon ears Alt 1"
	id = "sdragonears1"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Dragon/SDragonEars1/sdragonEars1.tscn"

func getCharacterCreatorDesc():
	return "From Songs vanilla parts"
