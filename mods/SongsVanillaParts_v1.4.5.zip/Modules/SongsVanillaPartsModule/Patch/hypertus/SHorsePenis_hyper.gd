extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Horse Penis Alt Hyperable"
	id = "songhorsepenishyperalbe"

func getCompatibleSpecies():
	return [Species.Any, Species.Equine, "scow", "sdeer"]

func getLewdAdjective():
	return RNG.pick(["flared", "horse-shaped", "horse"])

func getDoll3DScene():
	return "res://Modules/SongsVanillaPartsModule/PNG/Horse/SHorsePenis/spenisHorse.tscn"

func getTraits():
	return {
		PartTrait.PenisFlare: true,
		"Hyperable": true,
	}

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0
	else:
		return 1.0

func getVulgarName() -> String:
	return "horsecock"
