extends PartSkinBase

func _init():
	id = "songhpentt"
	partID = "songhorsepenis"

func getName():
	return "Twotone"

func getPatternTexture():
	return {
		"": preload("res://Modules/SongsVanillaPartsModule/Skins/Twotone/twotone.png"),
	}
