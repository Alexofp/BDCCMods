extends PartSkinBase

func _init():
	id = "songhpenspot"
	partID = "songhorsepenis"

func getName():
	return "Spotted"

func getPatternTexture():
	return {
		"": preload("res://Modules/SongsVanillaPartsModule/Skins/Spotted/Spotted.png"),
	}
	
	 
