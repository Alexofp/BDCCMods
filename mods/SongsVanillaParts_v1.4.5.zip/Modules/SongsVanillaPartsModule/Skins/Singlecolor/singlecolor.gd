extends PartSkinBase

func _init():
	id = "songhpensc"
	partID = "songhorsepenis"

func getName():
	return "SingleColor"

func getPatternTexture():
	return {
		"": preload("res://Modules/SongsVanillaPartsModule/Skins/Singlecolor/singlecolor.png"),
	}
	
	 
