extends Module
const FoxLibUIEventUtil = preload("res://Modules/FoxLib/Internal/FoxLibUIEventUtil.gd")
const FoxUIManager = preload("res://FoxLib/FoxUIManager.gd")
const FoxButton = preload("res://FoxLib/UI/FoxButton.gd")

var devSubScreen

func _init():
	id = "TwineInterfaceTranslator-Scenes"
	author = "Draderos"
	FoxLibUIEventUtil.registerInternal(self, "onSceneChangedInternal")
	

func runTwineConverter():
	Util.delete_children(devSubScreen)
	
	var scene = load("res://Modules/TwineSceneConverter/TwineSceneConverter.tscn")
	devSubScreen.add_child(scene.instance())

#Modified code based on FoxLib. Honestly I barely understand how FoxLib works so I can't extract all the functions from it in reasonable time to remove the dependency.
func onSceneChangedInternal():
	if FoxUIManager.hasFatalError():
		return
	var currentScene = FoxUIManager.getCurrentScene()
	# Log.print("TEST: " + str(currentScene))
	if str(currentScene).begins_with("MainMenu:["):
		applyOnMainMenu()

func applyOnMainMenu():
	var mainMenu = FoxUIManager.getCurrentScene()
	var container = mainMenu.get_node_or_null("MainHBox/CenterAreaVBox/DevToolsScreen")
	devSubScreen=container.get_node("DevScreen")
	var buttonGrid = container.get_node("GridContainer")
	var runGameTestButton = FoxButton.new()
	runGameTestButton.connect_on_pressed(self, "runTwineConverter")
	runGameTestButton.margin_left = 482.0
	runGameTestButton.margin_top = 30.0
	runGameTestButton.margin_right = 616.0
	runGameTestButton.margin_bottom = 56.0
	runGameTestButton.size_flags_horizontal = 3
	runGameTestButton.hint_tooltip = "A tool that can convert scenes written in Twine into code. Based on SceneConverter2 modified by Draderos\n(Twine Interface To Scene mod, injected with FoxLib)"
	runGameTestButton.text = "Twine Converter"
	buttonGrid.add_child(runGameTestButton)
