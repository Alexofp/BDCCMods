extends Control

# Can be used to convert a Twine twee export file to a BDCC scene code. Based on SceneConverter2.gd and modified by Draderos.
var lines = []
var _i = 0
var runs = {}
var tabAmount = 0
var reacts = {}
var sceneID = "TestScene"
var sceneParent:String = "SceneBase"
var sceneReacts = {}
var initSceneLines = []
var reactInitLines = []
var functions = []
var devCommentary = []
var runLines:Array = []
var reactLines:Array = []

var entryPoint=""
var linesStripped=[]
var runSkip=false
var currentSection="invalid section"
var usingVars=false
var savedVariblesWithComments=[]#Will generate variable code if it contains a comment only... But why would you comment on nothing?
var inCodeBlock=false
var currentPassage = ""
var currentSectionNeedsReturn=false
var lastLineIsReturn=false#If your react section is detected to set state manually but no attempt to manually return is detected
var npcAliasesWithComments=[]
var needsFunctionFirstLine=false
var generateDefaultEndScene=false
var vars=[]
var refCurrentSavedVar

var theGame:MainScene
var testingScene = false
var pickedSavePath = null

onready var savesContainer = $SavesMenu/ScrollContainer/SavesContainer
var saveGameElemenetScene = preload("res://UI/MainMenu/SaveGameElement.tscn")

func reset():
	lines = []
	reacts = {}
	_i = 0
	runs = {}
	tabAmount = 0
	sceneID = "TestScene"
	sceneParent = "SceneBase"
	sceneReacts = {}
	initSceneLines.clear()
	reactInitLines.clear()
	functions.clear()
	devCommentary = []
	runLines.clear()
	reactLines.clear()
	entryPoint=""
	linesStripped.clear()
	runSkip=false
	currentSection="invalid section"
	usingVars=false
	savedVariblesWithComments=[]
	inCodeBlock=false
	currentPassage = ""
	currentSectionNeedsReturn=false
	lastLineIsReturn=false
	npcAliasesWithComments.clear()
	needsFunctionFirstLine=false
	generateDefaultEndScene=false
	vars=[]
	refCurrentSavedVar=null


func setCurrentPassage(newcur):
	currentPassage = newcur

func renameStateActionTag(originalName):
	var renamedStateActionTag=originalName.to_lower().replace(" ","_").strip_edges()
	if renamedStateActionTag==entryPoint:
		return ""
	return renamedStateActionTag

func renameSceneID(inputString):
	var words = inputString.split(" ",false)
	var result = ""
	for word in words:
		if word == word.to_upper():
			result += word
		else:
			var firstLetter = word.left(1).to_upper()
			var restOfWord = word.substr(1)
			result += firstLetter + restOfWord
	return result

func makeEmptyArrayIfMissing(container,checkName):
	if !container.has(checkName):
		container[checkName]=[]

func addToActiveSection(thetext):
	if currentSection=="savedvars":
		if refCurrentSavedVar:
			refCurrentSavedVar["valueLines"].append(thetext)
			return
		savedVariblesWithComments.append(thetext)
		return
	if currentSection=="vars":
		vars.append(thetext)
		return
	if currentSection=="npcalias":
		npcAliasesWithComments.append(thetext)
		return
	for _j in range(tabAmount):
		thetext = "\t"+thetext

	#Check for setState in valid sections past this point
	var strippedNewReact=thetext.strip_edges()
	if strippedNewReact.begins_with('setState('):#Maybe also scan if other functions use setState?
			#if currentSection=="react":#Depends if people want to conditionally redirect out of a state they can still enter. I guess I am not going to care about this edge case so this is commented out.
			#	currentSectionNeedsReturn=true
			var splitSetState=strippedNewReact.split('"')
			if splitSetState.size()>=2:
				var originalStateName=splitSetState[1]
				thetext=thetext.replace(originalStateName,renameStateActionTag(originalStateName))
	
	if currentSection=="run":
		makeEmptyArrayIfMissing(runs,currentPassage)
		runs[currentPassage].append(thetext)
		return
	if currentSection=="prerun":
		runLines.append(thetext)
		return
	if currentSection=="prereact":
		reactLines.append(thetext)
		return
	if currentSection=="reactinit":
		reactInitLines.append(thetext)
		return
	if currentSection=="sceneinit":
		initSceneLines.append(thetext)
		return
	if currentSection=="react":
		makeEmptyArrayIfMissing(reacts,currentPassage)
		lastLineIsReturn=thetext.begins_with("return ") or thetext=="return"
		reacts[currentPassage].append(thetext)
		return
	if currentSection=="sceneend":
		makeEmptyArrayIfMissing(sceneReacts,currentPassage)
		sceneReacts[currentPassage].append(thetext)
		return
	if currentSection=="function":
		if needsFunctionFirstLine:
			functions.append(thetext)
			return
		functions.append("\t"+thetext)
		return

#Make sure to use this before changing sections
func setCurrentSection(sectionName):
	inCodeBlock=false
	tabAmount = 0
	needsFunctionFirstLine=false
	if currentSectionNeedsReturn:
		currentSectionNeedsReturn=false
		if !lastLineIsReturn:
			addToActiveSection("return")
	currentSection=sectionName
	
func checkNeedsPass(linesArray):
	var needsPass=true
	for line in linesArray:
		if line is Dictionary or !line.begins_with("#"):
			needsPass=false
	return needsPass

onready var inputTextEdit = $VBoxContainer/TextEdit
onready var outputTextEdit = $VBoxContainer/TextEdit2

func _ready():
	$VBoxContainer/TextEdit2.add_color_region('#', '', Color.cadetblue)

func _on_Button_pressed():
	reset()
	var result = []
	var text:String = inputTextEdit.text
	text = text.replace("“", '"')
	text = text.replace("”", '"')
	text = text.replace("‘", "'")
	text = text.replace("’", "'")
	#Get rid of empty lines
	for unprocessedLine in text.split("\n",false):
		unprocessedLine=unprocessedLine.replace("    ","\t")#Force swapping 4x spaces to tabs, maybe this should be inverted if spaces are more important than tabs? Sorta jank as it may replace in edge cases where for some odd reason you want 4 spaces in a string.
		var strippedLine=unprocessedLine.strip_edges()
		if strippedLine!="":
			lines.append(unprocessedLine)
			linesStripped.append(strippedLine)
	#Get Scene Name
	sceneID=renameSceneID(linesStripped[1])
	#Extract entry point and set loop start after the StoryData block, maybe convert to a section
	while(true):
		_i += 1
		var strippedLine=linesStripped[_i]
		if strippedLine.begins_with('"start": "'):
			entryPoint=renameStateActionTag(strippedLine.substr(10,strippedLine.length()-12))
			setCurrentSection("skip")
			break
	#Continue handling lines incrementally after start state is extracted
	var linesSize = lines.size()
	while(_i < linesSize-1):
		_i += 1
		var strippedLine: String = linesStripped[_i]
		# Detect Passages
		if(strippedLine.begins_with(":: ")):
			runSkip=false
			var passageNameEnd = strippedLine.rfind(" {")
			if passageNameEnd==-1:
				passageNameEnd=strippedLine.length()
			var passageName=strippedLine.substr(3,passageNameEnd-3)
			if passageName.nocasecmp_to("NOTES")==0:
				setCurrentSection("skip")
				setCurrentPassage("Error handling notes")
				continue
			if passageName.nocasecmp_to("ENDTHESCENE")==0:
				setCurrentSection("skip")
				setCurrentPassage("Error handling end scene")
				generateDefaultEndScene=true
				continue
			if passageName.nocasecmp_to("SAVED VARS")==0:
				setCurrentSection("savedvars")
				setCurrentPassage("Error handling saved vars")
				continue
			if passageName.nocasecmp_to("VARS")==0:
				setCurrentSection("vars")
				setCurrentPassage("Error handling saved vars")
				continue
			if passageName.nocasecmp_to("COMMENTARY")==0:
				setCurrentSection("commentary")
				setCurrentPassage("Error handling commentary")
				continue
			if passageName.nocasecmp_to("RUN")==0:
				setCurrentSection("prerun")
				setCurrentPassage("Error handling prepended run")
				continue
			if passageName.nocasecmp_to("REACT")==0:
				setCurrentSection("prereact")
				setCurrentPassage("Error handling prepended react")
				continue
			if passageName.nocasecmp_to("REACT INIT")==0:
				setCurrentSection("reactinit")
				setCurrentPassage("Error handling react init")
				continue
			if passageName.nocasecmp_to("SCENE INIT")==0:
				setCurrentSection("sceneinit")
				setCurrentPassage("Error handling scene init")
				continue
			if passageName.nocasecmp_to("NPC ALIASES")==0:
				setCurrentSection("npcalias")
				setCurrentPassage("Error handling NPC aliases")
				continue
			if passageName.to_upper().begins_with("FUNC "):
				setCurrentSection("function")
				setCurrentPassage(passageName.substr(5).replace(" ",""))
				needsFunctionFirstLine=true
				continue
			setCurrentSection("run")
			setCurrentPassage(renameStateActionTag(passageName))
			continue

		#State configuration and sections keywords
		if currentSection=="run":
			if strippedLine.nocasecmp_to(">NORUN")==0:
				runSkip=true
				continue
		if currentSection in ["run", "react", "sceneend"]:
			if strippedLine.nocasecmp_to(">REACT")==0:
				setCurrentSection("react")
				if runSkip:
					currentSectionNeedsReturn=true
				continue
			if strippedLine.nocasecmp_to(">SCENEEND")==0:
				setCurrentSection("sceneend")
				continue
			
		# Function first line
		if needsFunctionFirstLine:
			addToActiveSection("func "+currentPassage+"("+strippedLine+"):")
			needsFunctionFirstLine=false
			continue

		# Commentary
		if currentSection=="commentary":
			devCommentary.append(strippedLine)
			continue

		# Code block capture and end
		if inCodeBlock:
			if strippedLine=="]!":
				inCodeBlock=false
				continue
			addToActiveSection(lines[_i])
			continue

		# Comments
		if(strippedLine.begins_with("((")):
			addToActiveSection((lines[_i].replace(strippedLine,""))+"#"+ strippedLine)
			continue

		if(strippedLine.begins_with("#")):
			addToActiveSection(lines[_i])
			continue

		#Handle saved vars
		if currentSection=="savedvars":
			if strippedLine.begins_with("var "):
				var splitVarData = strippedLine.substr(4).split("=")
				var varName = splitVarData[0].strip_edges()
				refCurrentSavedVar={
					name = varName,
					valueLines = [],
				}
				if splitVarData.size()>=2:
					splitVarData.remove(0)
					refCurrentSavedVar["valueLines"].append(Util.join(splitVarData, "=").strip_edges())
				
				savedVariblesWithComments.append(refCurrentSavedVar)
				continue
			refCurrentSavedVar["valueLines"].append(lines[_i])
			continue

		if currentSection=="vars":
			addToActiveSection(lines[_i])
		
		#Handle npc aliases
		if currentSection=="npcalias":
			var splitAliasData = strippedLine.split(" ")
			var npcAlias = splitAliasData[0]
			splitAliasData.remove(0)
			var npcActual = Util.join(splitAliasData, " ")
			npcAliasesWithComments.append({
				alias=npcAlias,
				referTo=npcActual,
			})
			continue
		
		# Do not execute further parsing of lines in invalid sections
		if (currentSection in ["skip","commentary","vars","savedvars","npcalias"]) or (currentSection=="run" and runSkip):
			continue
			
		#Start code block, auto indented from script logic
		if strippedLine=="![":
			inCodeBlock=true
			continue

		# Single line code auto indented from the script logic
		if(strippedLine.begins_with("!")):
			var codeLine = strippedLine.substr(1).strip_edges()
			addToActiveSection(codeLine)
			continue

		# Script logic
		if(strippedLine.begins_with("?!") || strippedLine.begins_with("?end")):
			tabAmount -= 1
			continue
		if(strippedLine.begins_with("?else")):
			tabAmount -= 1
			addToActiveSection('else:')
			tabAmount += 1
			continue
		if(strippedLine.begins_with("?elif ")):
			var condition = strippedLine.substr(6)
			tabAmount -= 1
			addToActiveSection('elif ('+condition+'):')
			tabAmount += 1
			continue
		if(strippedLine.begins_with("?")):
			var condition = strippedLine.substr(1).strip_edges()
			addToActiveSection('if ('+condition+'):')
			tabAmount += 1
			continue

		# Running scenes
		if(strippedLine.begins_with("+")):
			var sceneData = strippedLine.substr(2).split("|")
			var strippedSceneData=[]
			for sceneDataChunk in sceneData:
				strippedSceneData.append(sceneDataChunk.strip_edges())
			var newSceneID=strippedSceneData[0]
			var newSceneArgs=""
			if strippedSceneData.size()>=2:
				newSceneArgs=strippedSceneData[1]
			addToActiveSection('runScene("'+newSceneID+'",['+newSceneArgs+'],"'+currentPassage+'")')
			continue

		# Do not execute further parsing of lines due to unsupported lines past this point
		#if currentSection in ["react","sceneend","sceneinit","reactinit","prereact"]:
		#	continue

		# Buttons, maybe move checks to anther line? Maybe allow | in description after moving checks.
		if(strippedLine.begins_with("[[")):
			var buttonDataChunks=strippedLine.substr(2).split("]]",false)
			var buttonName=""
			var buttonID=""
			var buttonDesc=""
			var buttonChecks
			if buttonDataChunks.size()>=1:
				var buttonNameIDChunk=buttonDataChunks[0].split("|",false)
				if buttonNameIDChunk.size()>=1:
					buttonName=buttonNameIDChunk[0].strip_edges()
				if buttonNameIDChunk.size()>=2:
					buttonID=buttonNameIDChunk[1]
				else:
					buttonID=buttonNameIDChunk[0]
			if buttonDataChunks.size()>=2:
				var buttonDescChecksChunk=buttonDataChunks[1].split("|",false)
				if buttonDescChecksChunk.size()>=1:
					buttonDesc=buttonDescChecksChunk[0]
				if buttonDescChecksChunk.size()>=2:
					buttonChecks=buttonDescChecksChunk[1]
			buttonID=renameStateActionTag(buttonID)#does the edge stripping too
			if(buttonChecks):
				addToActiveSection('addButtonWithChecks("'+buttonName+'","'+buttonDesc+'","'+buttonID+'",[],['+buttonChecks+'])')
			else:
				addToActiveSection('addButton("'+buttonName+'", "'+buttonDesc+'", "'+buttonID+'")')
			continue

		#Code injection for say lines
		strippedLine = strippedLine.replace("{{", '"+str(')
		strippedLine = strippedLine.replace("}}", ')+"')

		# Npcs saying things
		if(strippedLine.begins_with("=")):
			var msgData = strippedLine.substr(1)
			var msgDataSplit = msgData.split(":")
			var charID = msgDataSplit[0].strip_edges()
			msgDataSplit.remove(0)
			var whatSaid = Util.join(msgDataSplit, ":").strip_edges()
			whatSaid = whatSaid.replace("{{rahiMaster}}", '"+str(getFlag("RahiModule.rahiPCName", GM.pc.getName()))+"')
			addToActiveSection('saynn("[say='+charID+']'+whatSaid+'[/say]")')
			continue

		#Default to generic saynn
		addToActiveSection('saynn("'+strippedLine+'")')

	#BUILDING CODE
		
	result.append("extends "+sceneParent)
	result.append("")
	if(vars.size()>0):
		for varLine in vars:
			result.append(varLine)
		result.append("")
	
	if(!savedVariblesWithComments.empty()):
		for varOrComment in savedVariblesWithComments:
			if varOrComment is Dictionary:
				if varOrComment["valueLines"].size()==0:
					result.append("var "+str(varOrComment["name"]))
				else:
					var firstLine=true
					for varLine in varOrComment["valueLines"]:
						var varLineString=str(varLine)
						if firstLine:
							firstLine=false
							result.append("var "+str(varOrComment["name"])+" = "+varLineString)
						else:
							result.append(varLineString)
			else:
				result.append(varOrComment)
		result.append("")
	
	result.append("func _init():")
	result.append('\tsceneID = "'+sceneID+'"')
	result.append("")
	
	if(initSceneLines.size() > 0):
		result.append("func _initScene(_args = []):")
		for theLine in initSceneLines:
			result.append("\t"+theLine)
		if checkNeedsPass(initSceneLines):
			result.append("\tpass")
		result.append("")
	
	if(reactInitLines.size() > 0):
		result.append("func _reactInit():")
		for theLine in reactInitLines:
			result.append("\t"+theLine)
		if checkNeedsPass(reactInitLines):
			result.append("\tpass")
		result.append("")
	
	if(!npcAliasesWithComments.empty()):
		result.append("func resolveCustomCharacterName(_charID):")
		for npcAliasOrComment in npcAliasesWithComments:
			if npcAliasOrComment is Dictionary:
				result.append("\tif(_charID == \""+npcAliasOrComment["alias"]+"\"):")
				result.append("\t\treturn "+str(npcAliasOrComment["referTo"]))
			else:
				result.append("\t"+npcAliasOrComment)
		if checkNeedsPass(npcAliasesWithComments):
			result.append("\tpass")	
		result.append("")
	
	result.append("func _run():")
	if(!runLines.empty()):
		for line in runLines:
			result.append("\t"+line)
		result.append("")
	var hasNoRuns=true
	for runID in runs:
		if(runs[runID].size() > 0):
			hasNoRuns=false
			result.append('\tif(state == "'+runID+'"):')
			for runLine in runs[runID]:
				result.append('\t\t'+runLine)	
	if !runLines.empty() and hasNoRuns and checkNeedsPass(runLines):
		result.append("\tpass")
	result.append("")	
	
	if(!functions.empty()):
		result.append_array(functions)
		result.append("")
	
	result.append("func _react(_action: String, _args):")
	if(!reactLines.empty()):
		for line in reactLines:
			result.append("\t"+line)
		result.append("")

	if(generateDefaultEndScene):
		result.append('\tif(_action == "endthescene"):')
		result.append('\t\tendScene()')
		result.append('\t\treturn')
	
	for reactID in reacts:
		if(reacts[reactID].size() > 0):
			result.append('\tif(_action == "'+reactID+'"):')
			
			for reactLine in reacts[reactID]:
				result.append('\t\t'+reactLine)

	result.append("\tsetState(_action)")
	result.append("")
	
	if(!sceneReacts.empty()):
		result.append("func _react_scene_end(_tag, _result):")
		for sceneTag in sceneReacts:
			result.append('\tif(_tag == "'+str(sceneTag)+'"):')
				
			for reactLine in sceneReacts[sceneTag]:
				result.append('\t\t'+reactLine)
		result.append("")
	
	var hasVar=false
	for varOrComment in savedVariblesWithComments:
		if varOrComment is Dictionary:
			hasVar=true
	if(hasVar):
		result.append("func saveData():")
		result.append("\tvar data = .saveData()")
		for varOrComment in savedVariblesWithComments:
			if varOrComment is Dictionary:
				var varName=str(varOrComment["name"])
				result.append("\tdata[\""+varName+"\"] = "+varName)
		result.append("\treturn data")
		result.append("")

		result.append("func loadData(data):")
		result.append("\t.loadData(data)")
		for varOrComment in savedVariblesWithComments:
			if varOrComment is Dictionary:
				var varName=str(varOrComment["name"])
				var varLinesWithComments=varOrComment["valueLines"]
				var varLines=[]
				for varOrCommentLine in varLinesWithComments:
					if !varOrCommentLine.strip_edges().begins_with("#"):
						varLines.append(varOrCommentLine)
				if varLines.size()==0:
					result.append("\t"+varName+'=SAVE.loadVar(data,"'+varName+'",null)')
				else:
					var varLinesSize=varLines.size()
					var currentLineIndex=0
					while currentLineIndex<varLinesSize:
						var newVarLine=str(varLines[currentLineIndex])
						if currentLineIndex==0:
							newVarLine=str(varName)+'=SAVE.loadVar(data,"'+varName+'",'+newVarLine
						if currentLineIndex==varLinesSize-1:
							newVarLine=newVarLine+")"
						newVarLine="\t"+newVarLine
						result.append(newVarLine)
						currentLineIndex+=1
		result.append("")
	
	if(devCommentary != null && devCommentary.size() > 0):
		result.append("func getDevCommentary():")
		result.append("\treturn \""+Util.join(devCommentary, "\\n")+"\"")
		result.append("")
		result.append("func hasDevCommentary():")
		result.append("\treturn true")
		result.append("")

	outputTextEdit.text = Util.join(result, "\n")


#TESTING STUFF


func _on_TestButton_pressed():
	if(testingScene):
		return
	
	var newScript:GDScript = GDScript.new()
	newScript.source_code = outputTextEdit.text
	var _error = newScript.reload()
	if(_error != OK):
		$ErrorDialog.dialog_text = "There is an error in your scene's code somewhere"
		$ErrorDialog.show()
		return
		
	var newSceneID = GlobalRegistry.registerTemporaryScene(newScript)
	if(newSceneID == null):
		$ErrorDialog.dialog_text = "Unable to register test scene\nDoes scene inherit SceneBase?"
		$ErrorDialog.show()
		return
	
	$StopTestingButton.visible = true
	$GameSpotControl.visible = true
	$VBoxContainer.visible = false
	testingScene = true
	theGame = preload("res://Game/MainScene.tscn").instance()
	$GameSpotControl.add_child(theGame)
	theGame.setIsTestingScene(true)
	if(pickedSavePath != null):
		SAVE.loadGame(pickedSavePath)
	theGame.clearSceneStack()
	theGame.runScene(newSceneID)
	theGame.runCurrentScene()


func _on_StopTestingButton_pressed():
	if(!testingScene):
		return
	
	
	$StopTestingButton.visible = false
	$GameSpotControl.visible = false
	if(theGame):
		theGame.queue_free()
		theGame = null
	
	GlobalRegistry.clearTemporaryScenes()
	
	$VBoxContainer.visible = true
	testingScene = false

func updateSaves():
	Util.delete_children(savesContainer)
	
	var savesPaths = SAVE.getSavesSortedByDate()
	
	for savePath in savesPaths:
		var saveGameElementObject = saveGameElemenetScene.instance()
		savesContainer.add_child(saveGameElementObject)
		saveGameElementObject.setSaveFile(savePath)
		saveGameElementObject.connect("onLoadButtonPressed", self, "onSaveLoadButtonClicked")
		saveGameElementObject.setDeleteMode(false)
		saveGameElementObject.setPickMode()

func onSaveLoadButtonClicked(savePath):
	pickedSavePath = savePath
	$SavesMenu.visible = false
	$VBoxContainer.visible = true
	$VBoxContainer/HBoxContainer/PickSaveButton.text = pickedSavePath.get_file()


func _on_PickSaveButton_pressed():
	$SavesMenu.visible = true
	$VBoxContainer.visible = false
	updateSaves()


func _on_SavesBackButton_pressed():
	$SavesMenu.visible = false
	$VBoxContainer.visible = true
