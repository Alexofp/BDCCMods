extends Module

var target = load("res://Scenes/Cellblock/LaundryUniformMachineScene.gd")

func _init():
	id = "DyeFree"
	author = "bringulbangul"

# using multiline string for readability
var t0 = """		saynn("The machine waits for the clothing that it can dye. The screen reminds you that dyeing your inmate uniform is against the law and would lead to substantial increase of your sentence.")
		
		saynn("Cost: 5 credits")"""
var edit0 = """		saynn("The machine waits for the clothing that it can dye. The screen reminds you that dyeing your inmate uniform is against the law and would lead to substantial increase of your sentence.")
		
		saynn("[s]Cost: 5 credits[/s] It looks like some inmates have tampered with the machine, and now you can dye items without paying credits.")"""

var t1 = """addButtonWithChecks(item.getVisibleName(), item.getVisibleDescription(), "start_dye", [item], [[ButtonChecks.HasCredits, 5]])"""
var edit1 = """addButton(item.getVisibleName(), item.getVisibleDescription(), "start_dye", [item])"""

var t2 = """addButtonWithChecks("Confirm", "Pay 5 credits and finalize the color", "do_pay_coloritem", [theItem], [[ButtonChecks.HasCredits, 5]])"""
var edit2 = """addButton("Confirm", "Finalize the color", "do_pay_coloritem", [theItem])"""

var t3 = """		theItem.onDyed(theColor)
		GM.pc.addCredits(-5)"""
var edit3 = """		theItem.onDyed(theColor)
		GM.pc.addCredits(0)"""

var t4 = """Dyeing a clothing item cost: 5 credits."""
var edit4 = """Dyeing a clothing item cost:[s] 5 credits.[/s] Free!"""

func postInit(): # Called after everything is registered
	var original = target.source_code
	var modified = original.replace(t0, edit0)
	modified = modified.replace(t1, edit1)
	modified = modified.replace(t2, edit2)
	modified = modified.replace(t3, edit3)
	modified = modified.replace(t4, edit4)
	target.source_code = modified
	target.reload()
	if(edit1 in target.source_code):
		Log.print("DyeFree removed code 'GM.pc.addCredits(-5)' from res://Scenes/Cellblock/LaundryUniformMachineScene.gd")
