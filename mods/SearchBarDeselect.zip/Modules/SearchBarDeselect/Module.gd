extends Module

var target = load("res://UI/Inventory/GenericInventoryScreen.gd")
var target2 = load("res://UI/Inventory/InventoryScreen.gd")

func _init():
	id = "SearchBarDeselect"
	author = "bringulbangul"
	
var t0 = """func setEntries(newEntries:Dictionary):
"""
var hook0 = """	searchInput.release_focus()
"""

var t1 = """	if(shouldGrabInput && !OS.has_touchscreen_ui_hint()):
		searchInput.grab_focus()
"""

var hook1 = """	if(shouldGrabInput && !OS.has_touchscreen_ui_hint()):
		pass
"""

var t2 = """func onEntrySelected(theItem):
"""
var hook2 = """	searchInput.release_focus()
"""

func postInit(): # Called after everything is registered
	var original = target.source_code
	var modified = original.replace(t0, t0+hook0)
	target.source_code = modified
	target.reload()
#	Log.print(target.source_code.substr(target.source_code.find(t0), 120))
	if(hook0 in target.source_code):
		Log.print("SearchBarDeselect injected line \"searchInput.release_focus()\" into res://UI/Inventory/GenericInventoryScreen.gd")
	original = null
	modified = null
	original = target2.source_code
	modified = original.replace(t1, hook1)
	modified = modified.replace(t2, t2+hook2)
	target2.source_code = modified
	target2.reload()
#	print(modified)
	if(hook1 in target2.source_code && hook2 in target2.source_code):
		Log.print("SearchBarDeselect removed line \"searchInput.grab_focus()\" and injected line \"SearchInput.release_focus()\" into res://UI/Inventory/InventoryScreen.gd")
