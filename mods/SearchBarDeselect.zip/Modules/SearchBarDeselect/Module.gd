extends Module

var target = load("res://UI/Inventory/GenericInventoryScreen.gd")
var target2 = load("res://UI/Inventory/InventoryScreen.gd")

func _init():
	id = "SearchBarDeselect"
	author = "bringulbangul"
	
var t0 = "func setEntries(newEntries:Dictionary):\n"
var hook0 = "\tsearchInput.release_focus()\n"

var t1 = "\tif(shouldGrabInput && !OS.has_touchscreen_ui_hint()):\n\t\tsearchInput.grab_focus()\n"
var hook1 = "\tif(shouldGrabInput && !OS.has_touchscreen_ui_hint()):\n\t\tpass\n"

var t2 = "func onEntrySelected(theItem):\n"
var hook2 = "\tsearchInput.release_focus()\n"

func postInit(): # Called after everything is registered
	var original = target.source_code
	var modified = original.replace(t0, t0+hook0)
	target.source_code = modified
	target.reload()
	print(modified)
	original = null
	modified = null
	original = target2.source_code
	modified = original.replace(t1, hook1)
	modified = modified.replace(t2, t2+hook2)
	target2.source_code = modified
	target2.reload()
	print(modified)
	
