extends Species

var mimic : Species

var archetypes : Array = []

var sortable : Reference = GlobalRegistry.getModule("RodentUtils").createSortable()\
	.setObject(Sorter).setSort("sort_archetypes")\
	.setComparison("are_archetypes_same")

class Callable:
	var method : String # if return, return value is added as first arg ALWAYS
	var baseArgs : Array = [] # you define as modder
	var unbind : int = 0 # ignore added args
	var object : Object # object needs string variable called "id"
	var priority : int = 0 # lower = first, higher = later; think of it as order.
	
	func _init(o:Object, m:String):
		self.object = o
		self.method = m
	
	func setArgs(a:Array) -> Callable:
		self.baseArgs = a
		return self
	
	func setUnbind(u:int) -> Callable: # from added args, not base args
		self.unbind = u
		return self
	
	func setPriority(u:int) -> Callable: # high is later
		self.priority = u
		return self
	
	func setMethod(a:String) -> Callable:
		self.method = a
		return self
	
	func setObject(a:Object) -> Callable:
		self.object = a
		return self
	

class Archetype:
	var id : String = ""
	var optionDisplay : String = ""
	var description : String = ""
	var defaultWeight : float = 0.0 # doesn't count if <= 0.0
	
	var callable : Callable # this is called with args from onDynamicNpcCreation
	
	func _init(a:String) -> void:
		id = a
	

class Sorter:
	static func sort_callables(a, b) -> bool:
		if a.priority == b.priority:
			return a.object.id < b.object.id
		
		return a.priority < b.priority
	
	static func sort_archetypes(a, b) -> bool:
		if a is Archetype:
			a = a.id
		
		if b is Archetype:
			b = b.id
		
		return a < b
	
	static func are_archetypes_same(a, b) -> bool:
		if a is Archetype:
			a = a.id
		
		if b is Archetype:
			b = b.id
		
		return a == b
	
	

func getArchetypeWeight(aid:String) -> float:
	return GlobalRegistry.getModule("RAT_Archetypes").getWeightForArchetype(mimic.id+"::"+aid)

var callablesDict : Dictionary = {
	# method: [callables]
}

func createCallable(object:Object, method:String) -> Callable:
	return Callable.new(object, method)

func createArchetype(aid:String, callable:Callable, weight:float) -> Archetype:
	var n : Archetype = Archetype.new(aid)
	n.callable = callable
	n.defaultWeight = weight
	return n

func getArchetype(aid) -> Archetype:
	return sortable.getThing(aid, archetypes)

func addArchetype(archetype:Archetype) -> void:
	sortable.addThing(archetype, archetypes)

func addCallableToMethod(callable:Callable, method:String) -> void:
	var ar : Array = callablesDict.get_or_add(method, [])
	ar.insert(ar.bsearch_custom(callable, Sorter, "sort_callables"), callable)

func callAllVoidCallables(method:String, extraArgs:Array=[]) -> void:
	for callable in callablesDict.get(method, []):
		CallCallableVoid(callable, extraArgs)

func callAllReturnCallables(method:String, value, extraArgs:Array=[]):
	var returned = value
	for callable in callablesDict.get(method, []):
		returned = CallCallableReturn(callable, returned, extraArgs)
	
	return returned

func CallCallableVoid(cb:Callable, extraArgs:Array=[]) -> void:
	cb.object.callv(cb.method, getFinalArgsForCallable(cb, extraArgs))

func CallCallableReturn(cb:Callable, value, extraArgs:Array=[]):
	var args : Array = [value]
	args.append_array(getFinalArgsForCallable(cb, extraArgs))
	return cb.object.callv(cb.method, args)

func getFinalArgsForCallable(cb:Callable, extraArgs:Array=[]) -> Array:
	var finalArgs : Array = []
	finalArgs.append_array(cb.baseArgs)
	
	var extraSize : int = extraArgs.size()
	for i in Util.maxi(0, extraSize - cb.unbind):
		finalArgs.append(extraArgs[i])
	
	return finalArgs

func _init(m:Species):
	mimic = m
	id = m.id
	GlobalRegistry.allSpecies[id] = self
	

func onDynamicNpcCreation(_npc, _args):
	mimic.onDynamicNpcCreation(_npc, _args)
	
#	var mod = GlobalRegistry.getModule("RAT_Archetypes")
#
	callAllVoidCallables("onPreDynamicNpcCreation", [_npc, _args])
	
	var pairs : Array = []
	
	for arc in archetypes:
		var w = getArchetypeWeight(arc.id)
		if w > 0.0:
			pairs.append([arc, w])
	if pairs:
		var ar : Archetype = RNG.pickWeightedPairs(pairs)
		CallCallableVoid(ar.callable, [_npc, _args])
	
	callAllVoidCallables("onDynamicNpcCreation", [_npc, _args])
	


func getVisibleName():
	var v = mimic.getVisibleName()
	return callAllReturnCallables("getVisibleName", v)

func getVisibleDescription():
	var v = mimic.getVisibleDescription()
	return callAllReturnCallables("getVisibleDescription", v)

func getDefaultLegs(_gender):
	var v = mimic.getDefaultLegs(_gender)
	return callAllReturnCallables("getDefaultLegs", v, [_gender])

func getDefaultBreasts(_gender):
	var v = mimic.getDefaultBreasts(_gender)
	return callAllReturnCallables("getDefaultBreasts", v, [_gender])

func getDefaultHair(_gender):
	var v = mimic.getDefaultHair(_gender)
	return callAllReturnCallables("getDefaultHair", v, [_gender])

func getDefaultTail(_gender):
	var v = mimic.getDefaultTail(_gender)
	return callAllReturnCallables("getDefaultTail", v, [_gender])

func getDefaultBody(_gender):
	var v = mimic.getDefaultBody(_gender)
	return callAllReturnCallables("getDefaultBody", v, [_gender])

func getDefaultHead(_gender):
	var v = mimic.getDefaultHead(_gender)
	return callAllReturnCallables("getDefaultHead", v, [_gender])

func getDefaultArms(_gender):
	var v = mimic.getDefaultArms(_gender)
	return callAllReturnCallables("getDefaultArms", v, [_gender])

func getDefaultEars(_gender):
	var ear = mimic.getDefaultEars(_gender)
	return callAllReturnCallables("getDefaultEars", ear, [_gender])

func getDefaultHorns(_gender):
	var honr = mimic.getDefaultHorns(_gender)
	return callAllReturnCallables("getDefaultHorns", honr, [_gender])

func getDefaultPenis(_gender):
	var peen = mimic.getDefaultPenis(_gender)
	return callAllReturnCallables("getDefaultPenis", peen, [_gender])

func getDefaultVagina(_gender):
	var vag = mimic.getDefaultVagina(_gender)
	return callAllReturnCallables("getDefaultVagina", vag, [_gender])

func getDefaultAnus(_gender):
	var anus = mimic.getDefaultAnus(_gender)
	return callAllReturnCallables("getDefaultAnus", anus, [_gender])

func getDefaultForSlot(slot, _gender):
	var v = .getDefaultForSlot(slot, _gender)
	return callAllReturnCallables("getDefaultForSlot", v, [slot, _gender])

func getDefaultForSlotForNpcGender(slot, npcgender):
	var v = .getDefaultForSlotForNpcGender(slot, npcgender)
	return callAllReturnCallables("getDefaultForSlotForNpcGender", v, [slot, npcgender])

func getAllowedBodyparts():
	var a = mimic.getAllowedBodyparts()
	return callAllReturnCallables("getAllowedBodyparts", a)

func getAllowedBodypartsForNPCGender(_npcGender:String, _isTF:bool) -> Array:
	var al : Array = .getAllowedBodypartsForNPCGender(_npcGender, _isTF)
	
	return callAllReturnCallables("getAllowedBodypartsForNPCGender", al, [_npcGender, _isTF])

func getAllDefaultBodypartIDsForNPCGender(_npcGender:String) -> Array:
	var ar : Array = .getAllDefaultBodypartIDsForNPCGender(_npcGender)
	ar = callAllReturnCallables("getAllDefaultBodypartIDsForNPCGender", ar, [_npcGender])
	
	return ar

func isPlayable():
	return callAllReturnCallables("isPlayable", mimic.isPlayable())

func getEggCellOvulationAmount():
	return callAllReturnCallables("getEggCellOvulationAmount", mimic.getEggCellOvulationAmount())

func getEggsOvulationAmount() -> Array:
	return callAllReturnCallables("getEggsOvulationAmount", mimic.getEggsOvulationAmount())

func npcGenerationWeight():
	return callAllReturnCallables("npcGenerationWeight", mimic.npcGenerationWeight())

func canBeUsedForNPCType(_npcType):
	return callAllReturnCallables("canBeUsedForNPCType", mimic.canBeUsedForNPCType(_npcType), [_npcType])

func getSkinType():
	var st = mimic.getSkinType()
	st = callAllReturnCallables("getSkinType", st)
	return st

func generateSkinColors():
	var sc = mimic.generateSkinColors()
	sc = callAllReturnCallables("generateSkinColors", sc)
	return sc

func supportsMane():
	var v : bool = mimic.supportsMane()
	v = callAllReturnCallables("supportsMane", v)
	
	return v

func calculateScoreForSpeciesCalculations(_npc) -> float:
	var v : float = mimic.calculateScoreForSpeciesCalculations(_npc)
	
	v = callAllReturnCallables("calculateScoreForSpeciesCalculations", v, [_npc])
	
	return v

func generateEggType(_laidEgg:EggLaid) -> int:
	var t : int = BigEggType.Fertilized
	
	t = callAllReturnCallables("generateEggType", t, [_laidEgg])
	
	return t

func generateEggColor(_laidEgg:EggLaid) -> Color:
	var c : Color = mimic.generateEggColor(_laidEgg)
	c = callAllReturnCallables("generateEggColor", c, [_laidEgg])
	
	return c

func onEggLaid(_laidEgg:EggLaid, _eggCell:EggCell):
	.onEggLaid(_laidEgg, _eggCell)
	callAllVoidCallables("onEggLaid", [_laidEgg, _eggCell])

func getEggInventorySpritePath(_laidEgg:EggLaid) -> String:
	return callAllReturnCallables("getEggInventorySpritePath", mimic.getEggInventorySpritePath(_laidEgg), [_laidEgg])

