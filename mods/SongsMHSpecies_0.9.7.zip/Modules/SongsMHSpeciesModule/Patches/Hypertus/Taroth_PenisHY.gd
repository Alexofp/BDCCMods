extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Kulve penis Hyper"
	id = "sKulvePHY"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["wyvern", "tapered"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Penis/Taroth_Penis.tscn"

func getVulgarName() -> String:
	return "tapered dragon cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		"Hyperable": true,
	}

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getCharacterCreatorDesc():
	return "From MH Species"
