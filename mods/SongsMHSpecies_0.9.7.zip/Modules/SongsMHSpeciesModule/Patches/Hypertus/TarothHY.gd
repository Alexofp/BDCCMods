extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "sKulve"
	
func getVisibleName():
	return "Kulve Taroth"

func getDefaultLegs(_gender):
	return "sKulveLegs"

func getDefaultTail(_gender):
	return "sKulveTailA"

func isPlayable():
	return true

func getVisibleDescription():
	return "Mother Goddess of Gold"

func getDefaultHead(_gender):
	return "sKulveHead"

func getDefaultArms(_gender):
	return "sKulveArms"

func getDefaultEars(_gender):
	return null

func getDefaultBody(_gender):
	return "sKulvebody"

func getDefaultHorns(_gender):
	return "sKulveHorns"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sKulvePHY"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#cab756", "#5c4b31", "#49444d"], 
		["#baa122", "#8e6815", "#8e6815"], 
		["#e7c204", "#daad4a", "#4a4619"],
		["#c48d15", "#927b3a", "#2d281a"],
		#Black
		["#4e4727", "#241c04", "#48380d"],
		["#2f2c13", "#605021", "#2d281a"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
	
