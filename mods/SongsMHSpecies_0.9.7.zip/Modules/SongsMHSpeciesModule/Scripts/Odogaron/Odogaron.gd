extends Species

func _init():
	id = "sOdogaron"
	
func getVisibleName():
	return "Odogaron"

func getDefaultLegs(_gender):
	return "sOdogaronLegs"

func getDefaultTail(_gender):
	return "sOdogaronTail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Cruel Claw Wyvern"

func getDefaultHead(_gender):
	return "sOdogaronHead"

func getDefaultArms(_gender):
	return "sOdogaronArms"

func getDefaultEars(_gender):
	return "sOdogaronEars"

func getDefaultBody(_gender):
	return "sOdogaronbody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sOdogaronP"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#56201c", "#371a12", "#4c352e"], 
		["#693531", "#662b1b", "#864f3b"], 
		["#893f39", "#48271e", "#311c12"],
		["#823b22", "#632210", "#281c17"],
		#Ebony Odogaron
		["#5f5876", "#382a4f", "#382a4f"],
		["#685a99", "#433b7b", "#211d2e"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
	
