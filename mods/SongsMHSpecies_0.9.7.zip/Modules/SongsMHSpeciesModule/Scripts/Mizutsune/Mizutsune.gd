extends Species

func _init():
	id = "sMizutsune"
	
func getVisibleName():
	return "Mizutsune"

func getDefaultLegs(_gender):
	return "sMizutsuneLegs"

func getDefaultTail(_gender):
	return "sMizutsuneTail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Bubble Fox Wyvern"

func getDefaultHead(_gender):
	return "sMizutsuneHead"

func getDefaultArms(_gender):
	return "sMizutsuneArms"

func getDefaultEars(_gender):
	return "sMizutsuneEars"

func getDefaultBody(_gender):
	return "sMizutsunebody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sMizutsuneP"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#d2cfc1", "#633f5d", "#ad7b91"], 
		["#c8d2c1", "#7e3e5b", "#a67d8f"], 
		["#c3ddd4", "#955e80", "#d18caa"],
		["#e8dee5", "#765368", "#d9a6b1"],
		#Violet Mizutsune
		["#bcb5cf", "#42325e", "#7a6589"],
		["#9d98d0", "#3a2f67", "#7461a0"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
	
