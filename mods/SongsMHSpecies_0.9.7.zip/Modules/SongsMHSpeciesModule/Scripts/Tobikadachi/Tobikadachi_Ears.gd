extends BodypartEars

func _init():
	visibleName = "Tobikadachi ears"
	id = "sTobikadachiears"

func getCompatibleSpecies():
	return ["sTobikadachi", "sKulve"]

func getDoll3DScene():
	return null
