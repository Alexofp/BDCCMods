extends BodypartBody

func _init():
	visibleName = "Kulve body"
	id = "sKulvebody"

func getCompatibleSpecies():
	return ["sKulve"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Body/Taroth_body.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
