extends BodypartTail

func _init():
	visibleName = "Kulve tail"
	id = "sKulveTailB"

func getCompatibleSpecies():
	return ["sKulve"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_TailB/Taroth_TailB.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
