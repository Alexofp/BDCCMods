extends BodypartLeg

func _init():
	visibleName = "Kulve legs"
	id = "sKulveLegs"

func getCompatibleSpecies():
	return ["sKulve"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Legs/Taroth_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
