extends BodypartHorns

func _init():
	visibleName = "Kulve Horns"
	id = "sKulveHorns"

func getCompatibleSpecies():
	return ["sKulve"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Horns/Taroth_Horns.tscn"
