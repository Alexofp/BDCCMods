extends BodypartHead

func _init():
	visibleName = "Kulve Head"
	id = "sKulveHead"

func getCompatibleSpecies():
	return ["sKulve"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Head/Taroth_Head.tscn"

func getHeadLength():
	return 0.75
