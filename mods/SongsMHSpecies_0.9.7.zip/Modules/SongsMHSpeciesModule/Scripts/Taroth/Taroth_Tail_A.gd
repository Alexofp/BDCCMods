extends BodypartTail

func _init():
	visibleName = "Kulve tail coated"
	id = "sKulveTailA"

func getCompatibleSpecies():
	return ["sKulve"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_TailA/Taroth_TailA.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
