extends BodypartArms

func _init():
	visibleName = "Kulve arms"
	id = "sKulveArms"

func getCompatibleSpecies():
	return ["sKulve"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Arms/Taroth_Arms.tscn"
