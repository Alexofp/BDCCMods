extends BodypartArms

func _init():
	visibleName = "Kulve buff arms"
	id = "sKulveArmsBuff"

func getCompatibleSpecies():
	return ["sKulve"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Arms/Taroth_BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
