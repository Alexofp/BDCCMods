#v1.0
extends Module

func getFlags():
	return {
		
	}

func _init():
	
	id = "OrnateChastity"
	author = "_noro_"

	items = [
		"res://Modules/OrnateChastity/Items/Cages/KittyChastityCage.gd",
	]
