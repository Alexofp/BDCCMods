extends ImagePack

var speciesThing : Dictionary = {
	# image: species id array
	
}

func _init():
	id = "GenericPortraitsRewritten"
	artist = "Generic Portraits Rewritten (place last)"
	

func getCharacterImage(characterID: String, variant: Array):
	if(!characters.has(characterID)):
		var character = GlobalRegistry.getCharacter(characterID)
		if !character:
			return null
		
		return getGenericCharacterImage(character, variant, character.getID().hash())
	
	return .getCharacterImage(characterID, variant)

func fullUpdate() -> void:
	speciesThing.clear()
	
	for mod in GlobalRegistry.modules.values():
		if mod.has_method("getGenericPortraits"):
			var ndict : Dictionary = mod.getGenericPortraits()
			for image in ndict.keys():
				var ar : Array = speciesThing.get(image, [])
				ar.append_array(ndict[image])
				speciesThing[image] = ar

func getGenericCharacterImage(_character:BaseCharacter, _variant:Array, _hashID):
	var species = _character.getSpecies()
	if !species or typeof(species)!=TYPE_ARRAY:
		return null
	
	var prioritySpecies = species[0]
	
	for key in speciesThing.keys():
		if prioritySpecies in speciesThing[key]:
			return key
	
	return null

