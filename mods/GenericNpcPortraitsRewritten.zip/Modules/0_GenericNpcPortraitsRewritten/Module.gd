extends Module

#var fallbackPortrait = "res://Modules/0_GenericNpcPortraits/genericCanineOld.png"

func _init():
	id = "GenericNpcPortraitsRewritten"
	author = "Lucci-213, MoldyT, Selinoccino"

func register():
	.register()
	GlobalRegistry.registerImagePack("res://Modules/0_GenericNpcPortraitsRewritten/GenericImagePack.gd")
	OPTIONS.checkImagePackOrder(GlobalRegistry.imagePacks)

func postInit():
	var pack = GlobalRegistry.getImagePack("GenericPortraitsRewritten")
	if pack:
		pack.fullUpdate()

func getGenericPortraits() -> Dictionary:
	var path : String = "res://Modules/0_GenericNpcPortraitsRewritten/Images/"
	return {
		path+"genericFeline.png":[ Species.Feline ],
		path+"genericCanine.png":[ Species.Canine ],
		path+"genericEquine.png":[ Species.Equine ],
		path+"genericBat.png":[ "bat" ],
		path+"genericDragon.png":[ Species.Dragon ],
		path+"genericRaccoon.png":[ "raccoon" ],
		path+"genericRat.png":[ "rat" ],
		path+"genericRedpanda.png":[ "redpanda" ],
		path+"genericSkulldog.png":[ "skulldog" ],
		path+"genericShark.png":[ "shark" ],
		path+"genericProtogen.png": [ "protogen", "Protogen" ],
		path+"genericGoat.png": [ "goat" ],
		path+"genericBee.png": [ "bee" ],
		"res://Images/UI/GenericFace.png": [Species.Human],
	}
