extends "res://Modules/SongsHoofySpeciesModule/Compatibility/Hypertus/SheepBreastsHyper.gd"

func _init():
	visibleName = "Hyperable sheep male breasts"
	id = "sheepmalebreastsHY"
	size = BreastsSize.FLAT

func getLewdAdjective():
	return RNG.pick(["firm", "strong"])

func getLewdName():
	if(size <= BreastsSize.A):
		return "pecs"

	return RNG.pick(["manbreasts", "manboobs", "mantits", "jugs", "orbs"])

func getCompatibleSpecies():
	return ["sheep"]

func safeWhenExposed():
	if(size <= BreastsSize.A):
		return true
	
	return false

func generateDataFor(_dynamicCharacter):
	pass

func getTraits():
	return {
		"Hyperable": true,
	}
