extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "sheep"
	
func getVisibleName():
	return "Sheep"

func getDefaultBody(_gender):
	return "sheepbody"

func getDefaultLegs(_gender):
	return "sheephoofs"
	
func getDefaultTail(_gender):
	return "sheeptail"

func getDefaultHorns(_gender):
	return "sheepspiralhorns"

func isPlayable():
	return true

func getVisibleDescription():
	return "Cute fluffballs"

func getDefaultHead(_gender):
	return "sheephead"

func getDefaultArms(_gender):
	return "sheeparms"

func getDefaultEars(_gender):
	return "sheepears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return "sheepmalebreastsHY"
	
	return "sheepbreastsHY"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sheeppenisHY"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 2.0],
		[2, 8.0],
		[3, 6.0],
		[4, 4.0],
		[5, 2.0],
		[6, 1.0],
		[7, 0.5],
	]
