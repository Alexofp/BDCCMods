extends BodypartEars

func _init():
	visibleName = "Hoofy Ears2"
	id = "suniears2"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat", "sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Ears2/Uniears2.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
