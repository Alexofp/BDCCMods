extends BodypartEars

func _init():
	visibleName = "Hoofy Ears3"
	id = "suniears3"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat", "sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Ears3/Uniears3.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"
