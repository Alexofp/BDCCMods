extends BodypartHorns

func _init():
	visibleName = "Hoofy Horns1"
	id = "sunihorns1"

func getCompatibleSpecies():
	return ["scow", "sdeer", "sgoat", "sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/universalparts/Horns1/UniHorns1.tscn"

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func npcGenerationWeight(_dynamicCharacter):
	var npchead = _dynamicCharacter.getBodypart(BodypartSlot.Head)
	if npchead.id == "sgoathead3":
		return 0.5
	else :
		return 1.0
