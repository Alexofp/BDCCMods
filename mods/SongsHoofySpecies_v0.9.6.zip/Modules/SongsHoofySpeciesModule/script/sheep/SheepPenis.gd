extends BodypartPenis

func _init():
	visibleName = "sheep penis"
	id = "sheeppenis"

func getCompatibleSpecies():
	return ["sheep"]


func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Penis/SheepPenis.tscn"

