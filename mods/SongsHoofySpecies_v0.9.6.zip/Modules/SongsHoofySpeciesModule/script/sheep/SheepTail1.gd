extends BodypartTail

func _init():
	visibleName = "sheep tail 1"
	id = "sheeptail1"

func getCompatibleSpecies():
	return ["sheep"]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["fluffy"])

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Tail1/SheepTail1.tscn"
