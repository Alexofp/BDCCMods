extends BodypartHead

func _init():
	visibleName = "sheep head no wool"
	id = "sheepheadnowool"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/HeadNoWool/SheepHeadNoWool.tscn"

func getHeadLength():
	return 0.25
