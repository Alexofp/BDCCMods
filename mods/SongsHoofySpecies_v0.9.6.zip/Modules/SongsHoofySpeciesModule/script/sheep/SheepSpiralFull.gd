extends BodypartHorns

func _init():
	visibleName = "Backwards Spiral Full"
	id = "sheepspiralfull"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/HornsSpiralFull/SheepSpiralFull.tscn"
