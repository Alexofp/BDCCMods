extends BodypartTail

func _init():
	visibleName = "sheep tail 2"
	id = "sheeptail2"

func getCompatibleSpecies():
	return ["sheep"]

func getLewdSizeAdjective():
	return RNG.pick(["short"])

func getLewdAdjective():
	return RNG.pick(["fluffy"])

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Tail2/SheepTail2.tscn"
