extends BodypartHead

func _init():
	visibleName = "sheep head"
	id = "sheephead"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Head/SheepHead.tscn"

func getHeadLength():
	return 0.25
