extends BodypartLeg

func _init():
	visibleName = "sheep hoofs"
	id = "sheephoofs"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Feet/SheepHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
