extends BodypartEars

func _init():
	visibleName = "sheep ears"
	id = "sheepears"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Ears/SheepEars.tscn"
