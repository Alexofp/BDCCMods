extends BodypartHorns

func _init():
	visibleName = "sheep backwards spiral"
	id = "sheepspiralhorns"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/HornSpiral/SheepSpiral.tscn"
