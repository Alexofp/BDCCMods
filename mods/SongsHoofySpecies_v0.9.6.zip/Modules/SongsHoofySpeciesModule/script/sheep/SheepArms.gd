extends BodypartArms

func _init():
	visibleName = "sheep arms"
	id = "sheeparms"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Hands/SheepArms.tscn"
