extends BodypartBody

func _init():
	visibleName = "sheep body"
	id = "sheepbody"

func getCompatibleSpecies():
	return ["sheep"]

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Body/SheepBody.tscn"
