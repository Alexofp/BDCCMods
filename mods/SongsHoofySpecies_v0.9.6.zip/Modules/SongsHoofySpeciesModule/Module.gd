extends Module

#for Race bonus mod
var RaceBonus = ResourceLoader.exists("res://Modules/RaceBonusModPlus/Module.gd")

func _init():
	id = "hoofyspecies"
	author = "Songjo"
	
	bodyparts = [
	#All(38)
	#Cow(4)
		"res://Modules/SongsHoofySpeciesModule/script/cow/SCowHead1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/sCowHoofs1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/sCowHorns1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/SCowHead2.gd",
	#ClassicCow(6)(Originally by MaxMaxouCat and Avery Winter)
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/BovineEars.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/BovineHead.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/BovineTail.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/BullHorns.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/BullPenis.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/CowHorns.gd",
	#Deer(7)
		"res://Modules/SongsHoofySpeciesModule/script/deer/SDeerHead1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/sDeerAntlers1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/sDeerAntlers2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/sDeerAntlers3.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/sDeerAntlers4.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/sDeerHoofs1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/SDeerHead2.gd",
	#ClassicDeer(5)(Originally by MaxMaxouCat and Avery Winter)
		"res://Modules/SongsHoofySpeciesModule/script/deer/Deer_Classic/DeerEars.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/Deer_Classic/DeerHead.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/Deer_Classic/DeerHorns.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/Deer_Classic/DeerLegs.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/Deer_Classic/DeerTail.gd",
	#Goat(7)
		"res://Modules/SongsHoofySpeciesModule/script/goat/SGoatHead1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/sGoatHoofs1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/sGoatHorns1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/sGoatHorns2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/sGoatHoofs1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/SGoatHead2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/sGoatEars1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/SGoatHead3.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/sGoatHorns3.gd",
	#Suine(6)
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuineHead1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuineHead2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuineEars1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuineEars2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuineHoofs.gd",
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuineTail.gd",
	#Sheep(14)(originally by Thegaltor and Avery Winter)
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepArms.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepBody.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepBreasts.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepEars.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepHead.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepHeadNoWool.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepHoofs.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepMaleBreasts.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepPenis.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepSpiral.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepSpiralFull.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepTail1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepTail2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/SheepTail.gd",
	#Universal(9)
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniEars1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniEars2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniHorns1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniHorns2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniTail1.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniTail2.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniHoofs.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniEars3.gd",
		"res://Modules/SongsHoofySpeciesModule/script/universalparts/sUniEars4.gd",
	]
	
	species = [
		"res://Modules/SongsHoofySpeciesModule/script/cow/SCow.gd",
		"res://Modules/SongsHoofySpeciesModule/script/cow/Bovine_Classic/Bovine.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/SDeer.gd",
		"res://Modules/SongsHoofySpeciesModule/script/deer/Deer_Classic/Deer.gd",
		"res://Modules/SongsHoofySpeciesModule/script/goat/SGoat.gd",
		"res://Modules/SongsHoofySpeciesModule/script/suine/SSuine.gd",
		"res://Modules/SongsHoofySpeciesModule/script/sheep/Sheep.gd",
	]
	
	if (RaceBonus == true) :
		statusEffects = [
		"res://Modules/SongsHoofySpeciesModule/Compatibility/RaceBonus/RaceCow.gd",
		"res://Modules/SongsHoofySpeciesModule/Compatibility/RaceBonus/RaceDeerS.gd",
		"res://Modules/SongsHoofySpeciesModule/Compatibility/RaceBonus/RaceGoat.gd",
		]
