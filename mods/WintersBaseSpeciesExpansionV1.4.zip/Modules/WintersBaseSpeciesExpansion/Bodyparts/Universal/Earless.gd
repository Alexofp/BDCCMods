extends BodypartEars

func _init():
	visibleName = "No Ears"
	id = "earless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return null

func getCharacterCreatorDesc():
	return "From winters base expanded parts"

func npcGenerationWeight(_dynamicCharacter):
	return 0
