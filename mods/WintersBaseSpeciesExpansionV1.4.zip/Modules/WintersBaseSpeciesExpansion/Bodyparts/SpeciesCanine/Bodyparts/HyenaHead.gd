extends BodypartHead

func _init():
	visibleName = "hyena head"
	id = "hyenahead"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesCanine/Bodyparts/HyenaHead/HyenaHead.tscn"

func getHeadLength():
	return 0.55
