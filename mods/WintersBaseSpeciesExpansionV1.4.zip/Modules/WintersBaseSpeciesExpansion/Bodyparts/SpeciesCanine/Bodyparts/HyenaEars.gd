extends BodypartEars

func _init():
	visibleName = "hyena ears"
	id = "hyenaears"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesCanine/Bodyparts/HyenaEar/HyenaEars.tscn"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
