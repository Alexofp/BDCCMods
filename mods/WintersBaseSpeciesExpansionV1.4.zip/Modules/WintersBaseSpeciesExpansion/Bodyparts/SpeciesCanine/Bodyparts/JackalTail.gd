extends BodypartTail

func _init():
	visibleName = "Jackal tail"
	id = "jackaltail"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesCanine/Bodyparts/JackalTail/JackalTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
