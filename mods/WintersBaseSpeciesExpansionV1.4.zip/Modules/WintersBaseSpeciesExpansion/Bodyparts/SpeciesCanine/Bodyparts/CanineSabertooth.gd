extends BodypartHead

func _init():
	visibleName = "sabertooth wolf head"
	id = "saberwolfhead"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesCanine/Bodyparts/CanineSabertooth/CanineSabertooth.tscn"

func getHeadLength():
	return 0.6

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
