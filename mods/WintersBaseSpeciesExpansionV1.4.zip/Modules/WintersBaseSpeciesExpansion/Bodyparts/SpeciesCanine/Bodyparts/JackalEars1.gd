extends BodypartEars

func _init():
	visibleName = "Jackal ears"
	id = "jackalears"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesCanine/Bodyparts/JackalEars1/JackalEars1.tscn"
