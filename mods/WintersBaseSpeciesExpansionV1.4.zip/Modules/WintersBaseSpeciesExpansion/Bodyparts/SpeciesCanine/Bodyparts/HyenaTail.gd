extends BodypartTail

func _init():
	visibleName = "hyena tail"
	id = "hyenatail"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesCanine/Bodyparts/HyenaTail/HyenaTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
