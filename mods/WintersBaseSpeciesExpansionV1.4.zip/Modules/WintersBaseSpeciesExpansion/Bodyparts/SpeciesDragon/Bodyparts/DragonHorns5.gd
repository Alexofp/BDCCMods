extends BodypartHorns

func _init():
	visibleName = "Dragon Horns 5"
	id = "dragonhorns5"

func getCompatibleSpecies():
	return [Species.Dragon, Species.Demon]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesDragon/Bodyparts/DragonHorns5/DragonHorns5.tscn"

func getCharacterCreatorDesc():
	return "WintersBaseSpeciesExpanded"
