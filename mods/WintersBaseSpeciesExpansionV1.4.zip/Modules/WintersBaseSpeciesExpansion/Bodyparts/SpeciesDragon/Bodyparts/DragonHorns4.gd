extends BodypartHorns

func _init():
	visibleName = "Dragon Horns 4"
	id = "dragonhorns4"

func getCompatibleSpecies():
	return [Species.Dragon, Species.Demon]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesDragon/Bodyparts/DragonHorns4/DragonHorns4.tscn"

func getCharacterCreatorDesc():
	return "WintersBaseSpeciesExpanded"
