extends BodypartTail

func _init():
	visibleName = "dragon tail 2"
	id = "dragontail2"

func getCompatibleSpecies():
	return [Species.Dragon]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesDragon/Bodyparts/DragonTail2/DragonTail2.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}

func getCharacterCreatorDesc():
	return "WintersBaseSpeciesExpanded"
