extends BodypartHead

func _init():
	visibleName = "dragon head 3"
	id = "dragonhead3"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesDragon/Bodyparts/DragonHead3/DragonHead3.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "WintersBaseSpeciesExpanded"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
