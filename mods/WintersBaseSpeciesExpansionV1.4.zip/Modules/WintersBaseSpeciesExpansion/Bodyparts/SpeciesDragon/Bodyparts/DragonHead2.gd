extends BodypartHead

func _init():
	visibleName = "dragon head 2"
	id = "dragonhead2"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesDragon/Bodyparts/DragonHead2/DragonHead2.tscn"

func getHeadLength():
	return 0.7

func getCharacterCreatorDesc():
	return "WintersBaseSpeciesExpanded"

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
