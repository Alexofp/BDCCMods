extends BodypartHead

func _init():
	visibleName = "horse head 3"
	id = "horsehead3"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesEquine/Bodyparts/HorseHead3/HorseHead3.tscn"

func getHeadLength():
	return 0.55

func npcGenerationWeight(_dynamicCharacter):
	return 1.0
