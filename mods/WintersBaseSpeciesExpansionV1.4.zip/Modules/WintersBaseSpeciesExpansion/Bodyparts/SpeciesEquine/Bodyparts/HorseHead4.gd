extends BodypartHead

func _init():
	visibleName = "horse head 4"
	id = "horsehead4"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/WintersBaseSpeciesExpansion/Bodyparts/SpeciesEquine/Bodyparts/HorseHead4/HorseHead4.tscn"

func npcGenerationWeight(_dynamicCharacter):
	if(_dynamicCharacter.getFemininity() < 40):
		return 1.0
	return 0.0

func getHeadLength():
	return 0.55
