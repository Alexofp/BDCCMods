extends Module

func _init():
	id = "WintersBaseSpeciesExpansion"
	author = "Avery Winters (Code Improvements: Selinoccino) (Assets by Anon)"
	#Credits: Based on assembled mods by Anon compiled into one.
	
	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersBaseSpeciesExpansion/Bodyparts/")
