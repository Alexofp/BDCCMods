extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "SeedFloodEnterpriseVB"
	skillGroup = Skill.Breeder

func getVisibleName():
	return "Seed Flood Enterprise B"

func getVisibleDescription():
	return "You felt like your Balls could be better, You Like the Idea of Producing More Cum [b]Faster[/b] Along with Holding [b]More Cum[/b] now your lovely Balls can produce cum [b]375%[/b] Faster and hold [b]100%[/b] more cum!"

func getRequiredPerks():
	return [Perk.BreedCumProductionV3]

func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)

func getCost():
	return 3

func getPicture():
	return "res://Images/Perks/sperm5.png"

func getBuffs():
	return [
		buff(Buff.PenisCumProductionBuff, [375]),
		buff(Buff.PenisBallsVolumeBuff, [100]),
	]
