extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "SeedFloodEnterpriseVC"
	skillGroup = Skill.Breeder

func getVisibleName():
	return "Seed Flood Enterprise C"

func getVisibleDescription():
	return "You felt like your Balls could be better, You don't like cumming too much all at once, but the idea of rapidly refilling your balls does Excite you, then why stop where you are now. With this your balls will refill [b]375%[/b] however you'll loose [b]50%[/b] Capacity"

func getRequiredPerks():
	return [Perk.BreedCumProductionV3]

func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)

func getCost():
	return 3

func getPicture():
	return "res://Images/Perks/sperm5.png"

func getBuffs():
	return [
		buff(Buff.BreastsMilkProductionBuff, [375]),
		buff(Buff.PenisBallsVolumeBuff, [-50]),
	]
