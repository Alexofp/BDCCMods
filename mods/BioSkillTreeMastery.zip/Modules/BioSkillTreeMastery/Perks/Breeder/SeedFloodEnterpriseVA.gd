extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "SeedFloodEnterpriseVA"
	skillGroup = Skill.Breeder

func getVisibleName():
	return "Seed Flood Enterprise A"

func getVisibleDescription():
	return "You felt like your Balls could be better, why Cum More when you can Produce More Cum [b]Faster[/b]. Your Balls begin producing seed [b]750%[/b] faster!~ Along with that and recent discoveries~ you also gain more Virility the more sexy you are~/n/n(Credit to Wortzenhein for the Virility buff idea)"

func getRequiredPerks():
	return [Perk.BreedCumProductionV3]

func getSkillTier():
	return FoxGameRegistry.getPerkTierForLevel(self.skillGroup, 15)

func getCost():
	return 3

func getPicture():
	return "res://Images/Perks/sperm5.png"

func getBuffs():
	return [
		buff(Buff.PenisCumProductionBuff, [750]),
		buff(Buff.VirilityBuff, [100 * npc.getStat(Stat.Sexiness)]),
	]
