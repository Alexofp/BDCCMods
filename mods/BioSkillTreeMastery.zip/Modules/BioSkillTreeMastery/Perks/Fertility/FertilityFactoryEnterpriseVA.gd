extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "FertilityFactoryEnterpriseVA"
	skillGroup = Skill.Fertility

func getVisibleName():
	return "Fertility Factory Enterprise A"

func getRequiredPerks():
	return [Perk.FertilityBetterOvulationV2]

func getVisibleDescription():
	return "You Feel like your womb can do more... That's why you think you can become more fertile, produce more eggs and gestate new pups and kits [b]50% faster[/b]"

func getSkillTier():
	return 3

func getPicture():
	return "res://Images/Perks/Skill_Icon_FertilityBetterOvulation.png"

func getBuffs():

	return [
		buff(Buff.OvulationEggsAmountBuff, [200]),
		buff(Buff.MinOvulationEggsAmountBuff, [25]),
		buff(Buff.PregnancySpeedBuff, [50]),
		buff(Buff.FertilityBuff, [750]),
	]
