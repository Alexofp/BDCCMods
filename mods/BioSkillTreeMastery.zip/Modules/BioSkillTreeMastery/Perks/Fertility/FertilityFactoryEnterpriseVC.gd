extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "FertilityFactoryEnterpriseVC"
	skillGroup = Skill.Fertility

func getVisibleName():
	return "Fertility Factory Enterprise C"

func getRequiredPerks():
	return [Perk.FertilityBetterOvulationV2]

func getVisibleDescription():
	return "You Feel like your womb can do more... That's why you think you can become more fertile, produce even more eggs and even have more minimum eggs ready to be fertilized inside that slutty womb~"

func getSkillTier():
	return 3

func getPicture():
	return "res://Images/Perks/Skill_Icon_FertilityBetterOvulation.png"

func getBuffs():

	return [
		buff(Buff.OvulationEggsAmountBuff, [25]),
		buff(Buff.MinOvulationEggsAmountBuff, [75]),
		buff(Buff.FertilityBuff, [375]),
	]
