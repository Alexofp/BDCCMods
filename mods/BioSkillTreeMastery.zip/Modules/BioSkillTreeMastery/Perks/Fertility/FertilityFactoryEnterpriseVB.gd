extends PerkBase

const FoxGameRegistry = preload("res://FoxLib/FoxGameRegistry.gd")

func _init():
	id = "FertilityFactoryEnterpriseVB"
	skillGroup = Skill.Fertility

func getVisibleName():
	return "Fertility Factory Enterprise B"

func getRequiredPerks():
	return [Perk.FertilityBetterOvulationV2]

func getVisibleDescription():
	return "You Feel like your womb can do more... That's why you think you can become more effecient, gestate new pups and kits [b]100% faster[/b]"

func getSkillTier():
	return 3

func getPicture():
	return "res://Images/Perks/Skill_Icon_FertilityBetterOvulation.png"

func getBuffs():

	return [
		buff(Buff.PregnancySpeedBuff, [100]),
		buff(Buff.FertilityBuff, [375]),
	]
