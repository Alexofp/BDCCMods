extends "res://FoxLib/FoxModule.gd"

func _init():
	id = "BioSkillTreeMastery"
	author = "Bloxborne"
	
	perks = [
		#Miliking Enterprise
			"res://Modules/BioSkillTreeMastery/Perks/Milking/MilkingEnterpriseVA.gd",
			"res://Modules/BioSkillTreeMastery/Perks/Milking/MilkingEnterpriseVB.gd",
			"res://Modules/BioSkillTreeMastery/Perks/Milking/MilkingEnterpriseVC.gd",
			
		
		#Seed Flood Enterprise
			"res://Modules/BioSkillTreeMastery/Perks/Breeder/SeedFloodEnterpriseVA.gd",
			"res://Modules/BioSkillTreeMastery/Perks/Breeder/SeedFloodEnterpriseVB.gd",
			"res://Modules/BioSkillTreeMastery/Perks/Breeder/SeedFloodEnterpriseVC.gd",
			
		
		#Fertility Factory Enterprise
			"res://Modules/BioSkillTreeMastery/Perks/Fertility/FertilityFactoryEnterpriseVA.gd",
			"res://Modules/BioSkillTreeMastery/Perks/Fertility/FertilityFactoryEnterpriseVB.gd",
			"res://Modules/BioSkillTreeMastery/Perks/Fertility/FertilityFactoryEnterpriseVC.gd",
			
		
	]
	
	FoxGameRegistry.addPerkTierLevel("Milking", 15)
	FoxGameRegistry.addPerkTierLevel("Fertility", 15)
	FoxGameRegistry.addPerkTierLevel("Breeder", 15)
