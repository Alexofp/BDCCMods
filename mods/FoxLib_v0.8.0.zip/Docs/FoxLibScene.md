Require FoxLib/FLMH 0.8.0+

FLMH has the `#foxlib_scene` directive, allowing to make scene easily.

For example making a `.gd` with this:
```
#foxlib_scene FoxLibTestScene
#allow_softlock
#character fox2code

#code playAnimation(StageScene.Duo, "stand", {npc="fox2code", npcAction="sit"})
#code var hey = RNG.pick(["Hey", "Hi", "Hello"])

${hey}, this is a test FoxLib Scene

fox2code: How are you?

#state step2
#react GM.pc.addPain(5)

Hey

#state step3
#react GM.pc.addPain(5)
```

Will end up compiled as:
```gdscript
extends "res://FoxLib/FoxScene.gd"

func _init():
    sceneID = "FoxLibTestScene"
    initialSceneCharacters = ["fox2code"]
    allowSoftlock = true

func _run():
    if state == "":
        playAnimation(StageScene.Duo, "stand", {npc="fox2code", npcAction="sit"})
        var hey = RNG.pick(["Hey", "Hi", "Hello"])
        saynn("" + hey + ", this is a test FoxLib Scene")
        saynn("[say=fox2code]How are you?[/say]")
    elif state == "step2":
        saynn("Hey")

func _react(_action: String, _args):
    if _action == "step2":
        GM.pc.addPain(5)
    elif _action == "step3":
        GM.pc.addPain(5)
    ._react(_action, _args)
```
