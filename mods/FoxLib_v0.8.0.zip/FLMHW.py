#!/usr/bin/env python
# -*- coding: utf-8 -*-
# FoxLib ModHelper Wrapper
# It is recommended to use PyCharm to edit this file!

import os  # <- Used for file manipulation
import sys  # <- Used to parse program arguments
import stat  # <- Used to check unix file permissions (Not used on Windows)
import signal  # <- Ignore keyboard interrupts
import zipfile  # <- Used to extract FLMH.py from FoxLib.zip
import platform  # <- Used to check if you are on Windows/Mac/Linux
import subprocess  # <- Used to run FLMH.py

platforms_ids = {"Linux": "linux", "Darwin": "mac", "Windows": "windows", }
platform_id = platforms_ids.get(platform.system()) or None


def get_game_data_path():
    if platform_id is None:
        raise OSError("Getting game data path is not supported on this platform: " + platform.system())
    if platform_id == "windows":
        return os.path.join(os.getenv("APPDATA"), "Godot\\app_userdata\\BDCC")
    elif platform_id == "mac":
        return os.path.expanduser("~/Library/Application Support/Godot/app_userdata/BDCC")
    else:  # Assume Linux or unix like
        return os.path.expanduser("~/.local/share/godot/app_userdata/BDCC")


if __name__ == '__main__':
    game_data_path = get_game_data_path()
    game_mods_path = os.path.join(game_data_path, "mods")
    mod_helper_path = os.path.join(os.path.join(game_data_path, "foxlib"), "mod_helper")
    is_renewing = len(sys.argv) > 1 and sys.argv[1] == "renew"
    if not os.path.isdir(mod_helper_path) and not os.makedirs(mod_helper_path):
        raise IOError("Failed to create foxlib/mod_helper directory")
    foxlib_mod_zip = None
    foxlib_mod_helper_dest = None
    for file in os.listdir(game_mods_path):
        if file.startswith("FoxLib_v") and file.endswith(".zip"):
            foxlib_mod_zip = os.path.join(game_mods_path, file)
            foxlib_mod_helper_dest = os.path.join(mod_helper_path, "FLMH_v" + file[8:-4] + ".py")
    if foxlib_mod_zip is None:
        raise IOError("FoxLib was not found in your mods directory!")
    if is_renewing or not os.path.isfile(foxlib_mod_helper_dest):
        with zipfile.ZipFile(foxlib_mod_zip, 'r') as zip_ref:
            with zip_ref.open("FLMH.py") as compressed_script, open(foxlib_mod_helper_dest, 'wb') as extracted_script:
                extracted_script.write(compressed_script.read())
    if platform_id != "windows":
        unix_perms = os.stat(foxlib_mod_helper_dest).st_mode
        if (unix_perms & stat.S_IXUSR) == 0:
            unix_perms |= stat.S_IXUSR
            os.chmod(foxlib_mod_helper_dest, unix_perms)
    if is_renewing:
        print("FLMHW: Re-extracted a clean version of FLMH.py")
    else:
        process = subprocess.Popen([foxlib_mod_helper_dest] + sys.argv[1:])

        def forward_ctrl_c(signum, frame):
            process.send_signal(signal.SIGINT)

        signal.signal(signal.SIGINT, forward_ctrl_c)
        process.wait()
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        if process.returncode != 0:
            print("FoxLib ModHelper exited with code " + process.returncode)
