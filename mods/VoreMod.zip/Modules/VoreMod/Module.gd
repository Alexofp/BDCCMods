extends Module

func _init():
	id = "VoreMod"
	author = "bebrenkov"

	skills = [
		"res://Modules/VoreMod/Skills/VoreSkill.gd",
	]

	perks = [
		"res://Modules/VoreMod/Perks/VoreInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreExpansionV3.gd",

		"res://Modules/VoreMod/Perks/VoreBreastsInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsExpansionV3.gd",

		"res://Modules/VoreMod/Perks/VoreAnusInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreAnusExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreAnusExpansionV3.gd",
	]

	statusEffects = [
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedNPC.gd",
		"res://Modules/VoreMod/StatusEffects/VorePredatorBelly.gd",
		"res://Modules/VoreMod/StatusEffects/VoreWellFed.gd",
		"res://Modules/VoreMod/StatusEffects/VorePlayerDigesting.gd",
	]

	scenes = [
		"res://Modules/VoreMod/Scenes/VoreInteractScene.gd",
		"res://Modules/VoreMod/Scenes/VoreEscapeScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSexScene.gd",
		"res://Modules/VoreMod/Scenes/VoreBellyRideScene.gd",
		"res://Modules/VoreMod/Scenes/VoreDigestedDeathScene.gd",
	]

	events = [
		"res://Modules/VoreMod/Events/VoreEscapeEvent.gd",
		"res://Modules/VoreMod/Events/VoreInteractSwallowEvent.gd",
		"res://Modules/VoreMod/Events/VoreSleepBellyEvent.gd",
	]

	fetishes = [
		"res://Modules/VoreMod/Fetishes/VoreFetish.gd",
	]

	items = [
		"res://Modules/VoreMod/Items/VoreStopDigestionPill.gd",
		"res://Modules/VoreMod/Items/VoreAcceleratePill.gd",
	]
