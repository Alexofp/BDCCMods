extends Module
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	id = "VoreMod"
	author = "bebrenkov"
	GlobalRegistry.registerMapFloor("VoreModCellFloor", "res://Modules/VoreMod/Floors/VoreModCell.tscn")
	GlobalRegistry.registerStageScene("res://Player/StageScene3D/Scenes/TinyNpcDildoSex.tscn")
	skills = [
		"res://Modules/VoreMod/Skills/VoreSkill.gd",
	]
	perks = [
		"res://Modules/VoreMod/Perks/VoreInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreNoBodyChange.gd",
		"res://Modules/VoreMod/Perks/VoreForbiddenMethod.gd",
		"res://Modules/VoreMod/Perks/VoreApproachMagnet.gd",
		"res://Modules/VoreMod/Perks/VoreApproachRepellent.gd",
		"res://Modules/VoreMod/Perks/VoreExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreAnusInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreAnusExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreAnusExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreAnusEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreCockInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreCockExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreCockExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreCockEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaRebirth.gd",
		"res://Modules/VoreMod/Perks/VoreTailInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreTailExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreTailExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreTailEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreFusion.gd",
		"res://Modules/VoreMod/Perks/VoreEyeInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreEyeExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreEyeExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreEyeEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreEarInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreEarExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreEarExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreEarEndosoma.gd",
		"res://Modules/VoreMod/Perks/VorePregnancyTransfer.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaConvert.gd",
	]
	statusEffects = [
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedMouth.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedBreasts.gd",
		"res://Modules/VoreMod/StatusEffects/VoreBreastMilkFull.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedAnus.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedCock.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedVagina.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedTail.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedLegacy.gd",
		"res://Modules/VoreMod/StatusEffects/VoreRebirthController.gd",
		"res://Modules/VoreMod/StatusEffects/VorePredatorBelly.gd",
		"res://Modules/VoreMod/StatusEffects/VoreWellFed.gd",
		"res://Modules/VoreMod/StatusEffects/VorePlayerDigesting.gd",
		"res://Modules/VoreMod/StatusEffects/VoreTotemActive.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSizeChange.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedEye.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedEar.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedShrunk.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSlavePredatorDigesting.gd",
		"res://Modules/VoreMod/StatusEffects/VoreShrunkNPCPredator.gd",
		"res://Modules/VoreMod/StatusEffects/VoreNpcPlugEffect.gd",
	]
	scenes = [
		"res://Modules/VoreMod/Scenes/VoreInteractScene.gd",
		"res://Modules/VoreMod/Scenes/VoreEscapeScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSexScene.gd",
		"res://Modules/VoreMod/Scenes/VoreBellyRideScene.gd",
		"res://Modules/VoreMod/Scenes/VoreDigestedDeathScene.gd",
		"res://Modules/VoreMod/Scenes/VoreTotemRescueScene.gd",
		"res://Modules/VoreMod/Scenes/VoreFusionScene.gd",
		"res://Modules/VoreMod/Scenes/BodyScaleItemScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSizeChangePillScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSizeChangePillProgrammedScene.gd",
		"res://Modules/VoreMod/Scenes/VoreShrunkNPCReleaseScene.gd",
		"res://Modules/VoreMod/Scenes/VoreShrunkNPCSwallowScene.gd",
		"res://Modules/VoreMod/Scenes/VoreGrowthScene.gd",
		"res://Modules/VoreMod/Scenes/CellRaidScene.gd",
		"res://Modules/VoreMod/Scenes/CellSleepingNpcScene.gd",
		"res://Modules/VoreMod/Scenes/VoreLeashWalkScene.gd",
		"res://Modules/VoreMod/Scenes/TinyNpcDildoScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSlaveTalkScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSlaveBellyRideScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSlaveGivePillScene.gd",
		"res://Modules/VoreMod/Scenes/VoreOfferScene.gd",
		"res://Modules/VoreMod/Scenes/VoreShrunkNpcPlugScene.gd",
		"res://Modules/VoreMod/Scenes/VoreShrunkNpcButtplugScene.gd",
		"res://Modules/VoreMod/Scenes/VoreShrunkNpcVagplugScene.gd",
	]
	events = [
		"res://Modules/VoreMod/Events/VoreEscapeEvent.gd",
		"res://Modules/VoreMod/Events/VoreInteractSwallowEvent.gd",
		"res://Modules/VoreMod/Events/VoreSleepBellyEvent.gd",
		"res://Modules/VoreMod/Events/CellRaidEvent.gd",
		"res://Modules/VoreMod/Events/VoreOfferEvent.gd",
	]
	fetishes = [
		"res://Modules/VoreMod/Fetishes/VoreFetish.gd",
	]
	items = [
		"res://Modules/VoreMod/Items/VoreStopDigestionPill.gd",
		"res://Modules/VoreMod/Items/VoreAcceleratePill.gd",
		"res://Modules/VoreMod/Items/VoreTotem.gd",
		"res://Modules/VoreMod/Items/BodyScaleItem.gd",
		"res://Modules/VoreMod/Items/VoreSizeChangePill.gd",
		"res://Modules/VoreMod/Items/VoreSizeChangePillProgrammed.gd",
		"res://Modules/VoreMod/Items/VoreShrunkNPCItem.gd",
		"res://Modules/VoreMod/Items/RoomDebuggerItem.gd",
		"res://Modules/VoreMod/Items/VoreUndoFusionPill.gd",
	]
	gameExtenders = [
		"res://Modules/VoreMod/VoreSizeChangeExtender.gd",
	]
func getFlags():
	return {
		"PCBodyScale": flag(FlagType.Number),
		"NPCBodyScales": flag(FlagType.Dict),
		"PickedUpNPCs": flag(FlagType.Dict),
		"PickedUpPools": flag(FlagType.Dict),
		"cellNpcID": flag(FlagType.Text),
		"cellNpcName": flag(FlagType.Text),
		"cellReturnLocation": flag(FlagType.Text),
		"cellNpcSleeping": flag(FlagType.Bool),
		"ForbiddenVoreMethod": flag(FlagType.Text),
		"VoreOfferCD": flag(FlagType.Number),
		"VoreOfferNextAt": flag(FlagType.Number),
		"VoreOfferDebug": flag(FlagType.Bool),
	}
func postInit():
	pass
func giveRoomDebugger():
	if GM.pc == null:
		return
	var inv = GM.pc.getInventory()
	if inv == null:
		return
	for item in inv.getItems():
		if item.id == "RoomDebuggerItem":
			return
	var debugger = GlobalRegistry.createItem("RoomDebuggerItem")
	if debugger != null:
		inv.addItem(debugger)
		GM.main.addMessage("[VoreMod Debug] Room Debugger item added to your inventory. Use it to see room coordinates and IDs.")
const PICKUP_MAX_SCALE = 0.4
func pickUpShrunkNPC(npcID: String, currentDuration: float):
	if GM.main == null or GM.pc == null:
		return
	var npcChar = GlobalRegistry.getCharacter(npcID)
	if npcChar == null:
		return
	if VoreBodyScaleHelper.isNPCPickedUp(npcID):
		return
	if GM.main.IS.hasPawn(npcID):
		GM.main.IS.deletePawn(npcID)
	if npcChar.hasEffect("VoreSizeChange"):
		npcChar.removeEffect("VoreSizeChange")
	_captureAndRemovePools(npcID)
	VoreBodyScaleHelper.setNPCPickedUp(npcID, true)
	var item = GlobalRegistry.createItem("VoreShrunkNPCItem")
	if item == null:
		Log.printerr("VoreMod: Failed to create VoreShrunkNPCItem - item not registered!")
		return
	item.npcID = npcID
	item.duration = currentDuration
	GM.pc.getInventory().addItem(item)
func releaseNPCFromItem(itemObj, gentle: bool = true):
	if GM.main == null or GM.pc == null:
		return
	if itemObj == null:
		return
	var npcID = itemObj.npcID
	if npcID == "":
		return
	var npcChar = GlobalRegistry.getCharacter(npcID)
	var charName = "NPC"
	if npcChar != null and npcChar.has_method("getName"):
		charName = npcChar.getName()
	GM.pc.getInventory().removeItem(itemObj)
	VoreBodyScaleHelper.setNPCPickedUp(npcID, false)
	_restorePools(npcID)
	if not GM.main.IS.hasPawn(npcID):
		GM.main.IS.spawnPawn(npcID)
	var pawn = GM.main.IS.getPawn(npcID)
	if pawn != null:
		pawn.setLocation(GM.pc.getLocation())
	call_deferred("_deferredReapplyAfterRelease")
	if gentle:
		GM.main.addMessage("You gently set " + charName + " down on the floor.")
	else:
		GM.main.addMessage("You let " + charName + " drop out of your pocket onto the floor.")
func swallowNPCFromItem(itemObj):
	if GM.main == null or GM.pc == null:
		return
	if itemObj == null:
		return
	var npcID = itemObj.npcID
	if npcID == "":
		return
	GM.pc.getInventory().removeItem(itemObj)
	VoreBodyScaleHelper.setNPCPickedUp(npcID, false)
	_captureAndRemovePools(npcID)
	if GM.main.IS.hasPawn(npcID):
		GM.main.IS.deletePawn(npcID)
func _deferredReapplyAfterRelease():
	VoreBodyScaleHelper.reapplyAllNPCScales()
func giveShrunkNPCAsPill(itemObj, predator):
	if GM.main == null or GM.pc == null:
		return
	if itemObj == null or predator == null:
		return
	var npcID = itemObj.npcID
	if npcID == "":
		return
	var remaining = float(itemObj.duration)
	var preyChar = GlobalRegistry.getCharacter(npcID)
	var preyName = "someone"
	if preyChar != null and preyChar.has_method("getName"):
		preyName = preyChar.getName()
	GM.pc.getInventory().removeItem(itemObj)
	VoreBodyScaleHelper.setNPCPickedUp(npcID, false)
	_restorePools(npcID)
	if preyChar != null and preyChar.hasEffect("VoreSizeChange"):
		preyChar.removeEffect("VoreSizeChange")
	if GM.main.IS.hasPawn(npcID):
		GM.main.IS.deletePawn(npcID)
	var effRemaining = -1.0
	if remaining > 0.0:
		effRemaining = remaining
	predator.addEffect("VoreShrunkNPCPredator", [preyName, npcID, "mouth", effRemaining])
func tickPocketedNPCs(secondsPassed):
	if GM.pc == null or GM.main == null:
		return
	var inventory = GM.pc.getInventory()
	if inventory == null:
		return
	var toAutorelease = []
	var toBurst = []
	for item in inventory.getItems():
		if item.id == "VoreShrunkNPCItem":
			if item.duration > 0:
				item.duration -= float(secondsPassed)
				if item.duration <= 0.0:
					item.duration = 0.0
					if item.plugMode != null and item.plugMode != "":
						toBurst.append(item)
					else:
						toAutorelease.append(item)
	if toBurst.size() > 0:
		var burstItem = toBurst[0]
		var burstID = burstItem.npcID
		var burstChar = GlobalRegistry.getCharacter(burstID)
		var burstName = "Someone"
		if burstChar != null and burstChar.has_method("getName"):
			burstName = burstChar.getName()
		var burstMethod = "buttplug"
		if burstItem.plugMode == "vagina":
			burstMethod = "vaginalplug"
		inventory.removeItem(burstItem)
		VoreBodyScaleHelper.setNPCPickedUp(burstID, false)
		if GM.pc.hasEffect("VoreNpcPlug"):
			GM.pc.removeEffect("VoreNpcPlug")
		if burstChar != null:
			burstChar.removeEffect("VoreSizeChange")
			VoreBodyScaleHelper.applyNPCBodyScale(burstChar, 1.0)
		GM.main.runScene("VoreGrowthScene", [burstID, burstName, burstMethod])
		return
	for item in toAutorelease:
		var npcID = item.npcID
		var npcChar = GlobalRegistry.getCharacter(npcID)
		var charName = "Someone"
		if npcChar != null and npcChar.has_method("getName"):
			charName = npcChar.getName()
		inventory.removeItem(item)
		VoreBodyScaleHelper.setNPCPickedUp(npcID, false)
		_restorePools(npcID)
		if not GM.main.IS.hasPawn(npcID):
			GM.main.IS.spawnPawn(npcID)
		var pawn = GM.main.IS.getPawn(npcID)
		if pawn != null:
			pawn.setLocation(GM.pc.getLocation())
		if npcChar != null:
			VoreBodyScaleHelper.applyNPCBodyScale(npcChar, 1.0)
		GM.main.addMessage(charName + " suddenly grows back to normal size and tumbles out of your pocket! The shrink effect has worn off.")
	if toAutorelease.size() > 0:
		call_deferred("_deferredReapplyAfterRelease")
func resetFlagsOnNewDay():
	.resetFlagsOnNewDay()
	_advanceSlavePredatorDigestionOneDay()
func _advanceSlavePredatorDigestionOneDay():
	if GM.main == null:
		return
	for npcID in GM.main.dynamicCharacters.keys():
		var ch = GM.main.dynamicCharacters.get(npcID)
		if ch == null:
			continue
		if ch.hasEffect("VoreSlavePredatorDigesting"):
			var eff = ch.getEffect("VoreSlavePredatorDigesting")
			if eff != null:
				eff.onNewDay()
const FLAG_PICKED_UP_POOLS = "VoreMod.PickedUpPools"
func _getPickedUpPools() -> Dictionary:
	if GM.main == null:
		return {}
	var val = GM.main.getFlag(FLAG_PICKED_UP_POOLS, {})
	if val == null or !(val is Dictionary):
		return {}
	return val
func _setPickedUpPools(d: Dictionary):
	if GM.main == null:
		return
	GM.main.setFlag(FLAG_PICKED_UP_POOLS, d)
func _captureAndRemovePools(npcID: String):
	if GM.main == null:
		return
	var pools = []
	for poolID in GM.main.getDynamicCharactersPools():
		var ids = GM.main.getDynamicCharacterIDsFromPool(poolID)
		if ids.has(npcID):
			pools.append(poolID)
	if pools.size() > 0:
		var d = _getPickedUpPools()
		d[npcID] = pools
		_setPickedUpPools(d)
	GM.main.removeDynamicCharacterFromAllPools(npcID)
func _restorePools(npcID: String):
	if GM.main == null:
		return
	var d = _getPickedUpPools()
	if d.has(npcID):
		for poolID in d[npcID]:
			GM.main.addDynamicCharacterToPool(npcID, poolID)
		d.erase(npcID)
		_setPickedUpPools(d)
func restorePickedUpNPCs():
	if GM.pc == null or GM.main == null:
		return
	var inventory = GM.pc.getInventory()
	if inventory == null:
		return
	for item in inventory.getItems():
		if item.id == "VoreShrunkNPCItem":
			var npcID = item.npcID
			if npcID == "":
				continue
			VoreBodyScaleHelper.setNPCPickedUp(npcID, true)
			if GM.main.IS.hasPawn(npcID):
				GM.main.IS.deletePawn(npcID)
			if !_getPickedUpPools().has(npcID):
				_captureAndRemovePools(npcID)
			else:
				GM.main.removeDynamicCharacterFromAllPools(npcID)
