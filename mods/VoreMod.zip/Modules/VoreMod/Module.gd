extends Module

func _init():
	id = "VoreMod"
	author = "bebrenkov"

	skills = [
		"res://Modules/VoreMod/Skills/VoreSkill.gd",
	]

	perks = [
		"res://Modules/VoreMod/Perks/VoreInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreEndosoma.gd",

		"res://Modules/VoreMod/Perks/VoreBreastsInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreBreastsEndosoma.gd",

		"res://Modules/VoreMod/Perks/VoreAnusInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreAnusExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreAnusExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreAnusEndosoma.gd",

		"res://Modules/VoreMod/Perks/VoreCockInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreCockExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreCockExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreCockEndosoma.gd",

		"res://Modules/VoreMod/Perks/VoreVaginaInitiate.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaExpansionV2.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaExpansionV3.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaEndosoma.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaRebirth.gd",

		"res://Modules/VoreMod/Perks/VoreFusion.gd",

		"res://Modules/VoreMod/Perks/VorePregnancyTransfer.gd",
		"res://Modules/VoreMod/Perks/VoreVaginaConvert.gd",
	]

	statusEffects = [
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedMouth.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedBreasts.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedAnus.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedCock.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedVagina.gd",
		"res://Modules/VoreMod/StatusEffects/VoreSwallowedLegacy.gd",
		"res://Modules/VoreMod/StatusEffects/VoreRebirthController.gd",
		"res://Modules/VoreMod/StatusEffects/VorePredatorBelly.gd",
		"res://Modules/VoreMod/StatusEffects/VoreWellFed.gd",
		"res://Modules/VoreMod/StatusEffects/VorePlayerDigesting.gd",
		"res://Modules/VoreMod/StatusEffects/VoreTotemActive.gd",
	]

	scenes = [
		"res://Modules/VoreMod/Scenes/VoreInteractScene.gd",
		"res://Modules/VoreMod/Scenes/VoreEscapeScene.gd",
		"res://Modules/VoreMod/Scenes/VoreSexScene.gd",
		"res://Modules/VoreMod/Scenes/VoreBellyRideScene.gd",
		"res://Modules/VoreMod/Scenes/VoreDigestedDeathScene.gd",
		"res://Modules/VoreMod/Scenes/VoreTotemRescueScene.gd",
		"res://Modules/VoreMod/Scenes/VoreFusionScene.gd",
	]

	events = [
		"res://Modules/VoreMod/Events/VoreEscapeEvent.gd",
		"res://Modules/VoreMod/Events/VoreInteractSwallowEvent.gd",
		"res://Modules/VoreMod/Events/VoreSleepBellyEvent.gd",
	]

	fetishes = [
		"res://Modules/VoreMod/Fetishes/VoreFetish.gd",
	]

	items = [
		"res://Modules/VoreMod/Items/VoreStopDigestionPill.gd",
		"res://Modules/VoreMod/Items/VoreAcceleratePill.gd",
		"res://Modules/VoreMod/Items/VoreTotem.gd",
	]
