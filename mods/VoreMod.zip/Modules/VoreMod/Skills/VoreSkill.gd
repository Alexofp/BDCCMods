extends SkillBase


func _init():
	id = "Vore"

func getVisibleName():
	return "Vore"

func getShortName():
	return "Vore"

func getVisibleDescription():
	return "Ability to swallow defeated opponents whole and digest them\nover several days. Unlock different methods of absorption\n(mouth, breasts, rear) and increase your maximum capacity for each."

static func alwaysVisible() -> bool:
	return true

func getPerkTiers():
	return [
		[0],
		[5],
		[10],
	]
