extends Node
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _ready():
	var stage = get_parent()
	if stage == null:
		return
	if !stage.is_connected("child_entered_tree", self, "_onStageChildEntered"):
		stage.connect("child_entered_tree", self, "_onStageChildEntered")
	if stage.has_signal("sceneChanged"):
		if !stage.is_connected("sceneChanged", self, "_onSceneChanged"):
			stage.connect("sceneChanged", self, "_onSceneChanged")
	for child in stage.get_children():
		if child != self:
			_hookScene(child)
func _onStageChildEntered(child):
	if child == self:
		return
	_hookScene(child)
func _onSceneChanged():
	_triggerReapply()
func _hookScene(scene):
	if !scene.is_connected("child_entered_tree", self, "_onSceneChildEntered"):
		scene.connect("child_entered_tree", self, "_onSceneChildEntered")
	if scene.has_signal("doll_ready"):
		if !scene.is_connected("doll_ready", self, "_onDollReady"):
			scene.connect("doll_ready", self, "_onDollReady")
	_triggerReapply()
func _onSceneChildEntered(child):
	if child is Spatial:
		_triggerReapply()
func _onDollReady(_doll):
	_triggerReapply()
func _triggerReapply():
	yield(get_tree(), "idle_frame")
	VoreBodyScaleHelper.reapplyAllNPCScales()
	VoreBodyScaleHelper.applyPCBodyScale()
func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		var stage = get_parent()
		if stage and stage.is_connected("child_entered_tree", self, "_onStageChildEntered"):
			stage.disconnect("child_entered_tree", self, "_onStageChildEntered")
		if stage and stage.has_signal("sceneChanged"):
			if stage.is_connected("sceneChanged", self, "_onSceneChanged"):
				stage.disconnect("sceneChanged", self, "_onSceneChanged")