extends FetishBase

func _init():
	id = "Vore"
	dynamicChangesPersonalityAffectors = {
		PersonalityStat.Subby: 0.25,
		PersonalityStat.Coward: -0.2,
		PersonalityStat.Mean: -0.15,
	}

func getVisibleName():
	return "Vore"

func getGoals(_sexEngine, _domFetishHolder, _dom, _sub):
	return []

func isPossibleFor(_character):
	return true

func getInitialInterest(_character):
	return FetishInterest.Neutral
