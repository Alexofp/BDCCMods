extends SubGameWorld
func _on_CellRoom_onEnter(room):
	var npcID = GM.main.getModuleFlag("VoreMod", "cellNpcID", "")
	var npcName = GM.main.getModuleFlag("VoreMod", "cellNpcName", "someone")
	var isNight = GM.main.isVeryLate()
	var isSleeping = GM.main.getModuleFlag("VoreMod", "cellNpcSleeping", false)
	if npcID != "":
		if !GM.main.IS.hasPawn(npcID):
			var _p = GM.main.IS.spawnPawnIfNeeded(npcID)
		var pawn = GM.main.IS.getPawn(npcID)
		if pawn != null:
			pawn.setLocation("voremod_cell_interior")
	if npcID != "" and npcName != "":
		if isNight and isSleeping:
			room.sayn("You slip inside " + npcName + "'s cell. The door clicks shut behind you. " + npcName + " is fast asleep on the bunk, oblivious to your presence.")
		elif isNight:
			room.sayn("You step inside " + npcName + "'s cell. The door clicks shut behind you. " + npcName + " is sitting on the edge of their bed, looking at you in the dim light.")
		else:
			room.sayn("You step inside " + npcName + "'s cell. " + npcName + " is here, watching you from across the small room.")
	else:
		room.sayn("You step into the cell. It's cramped and bare.")
	if npcID != "" and isNight and isSleeping:
		room.addButton("Approach " + npcName, "Quietly step up to the sleeping " + npcName, "approach_sleeping")
	room.addButton("Leave cell", "Step back out into the corridor", "leave_cell")
func _on_CellRoom_onReact(_room, key):
	if key == "approach_sleeping":
		var npcID = GM.main.getModuleFlag("VoreMod", "cellNpcID", "")
		if npcID != "":
			_room.runScene("CellSleepingNpcScene", [npcID])
		return
	if key == "leave_cell":
		var returnLoc = GM.main.getModuleFlag("VoreMod", "cellReturnLocation", "")
		var npcID = GM.main.getModuleFlag("VoreMod", "cellNpcID", "")
		if npcID != "" and !_voreModCellOwnerIsAsleep() and _voreModCellOwnerIsHere(npcID):
			_room.runScene("CellConfrontScene", [npcID, "room"])
			return
		if npcID != "" and GM.main.IS.hasPawn(npcID):
			var pawn = GM.main.IS.getPawn(npcID)
			if pawn != null:
				pawn.setLocation(returnLoc)
		GM.main.setModuleFlag("VoreMod", "cellNpcID", "")
		GM.main.setModuleFlag("VoreMod", "cellNpcName", "")
		GM.main.setModuleFlag("VoreMod", "cellNpcSleeping", false)
		GM.main.setModuleFlag("VoreMod", "cellReturnLocation", "")
		if returnLoc != "":
			GM.pc.setLocation(returnLoc)
		else:
			GM.pc.setLocation("cellblock_orange_nearcell")
		GM.main.reRun()

func _voreModCellOwnerIsAsleep() -> bool:
	return bool(GM.main.getModuleFlag("VoreMod", "cellNpcSleeping", false))
func _voreModCellOwnerIsHere(npcID: String) -> bool:
	if !GM.main.IS.hasPawn(npcID):
		return false
	var pawn = GM.main.IS.getPawn(npcID)
	if pawn == null:
		return false
	return pawn.getLocation() == "voremod_cell_interior"
