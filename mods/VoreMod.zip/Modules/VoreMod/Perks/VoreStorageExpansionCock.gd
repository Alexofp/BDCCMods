extends PerkBase
func _init():
	id = "VoreStorageExpansionCock"
	skillGroup = "Vore"
func getVisibleName():
	return "Shaft Storage Expansion"
func getVisibleDescription():
	return "Your cock becomes a more capable smuggling vessel.\n[b]Effect:[/b] +3 item slots in your [b]cock[/b] compartment.\nCan be purchased multiple times."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreCockInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
