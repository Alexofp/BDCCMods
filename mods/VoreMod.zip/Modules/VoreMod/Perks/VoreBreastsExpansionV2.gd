extends PerkBase

func _init():
	id = "VoreBreastsExpansionV2"
	skillGroup = "Vore"

func getVisibleName():
	return "Swelling Bust"

func getVisibleDescription():
	return "Your chest can process more at once. You can now hold up to [b]2[/b] breast-absorbed prey at once."

func getSkillTier():
	return 1

func getCost():
	return 1

func getRequiredPerks():
	return ["VoreBreastsInitiate"]

func getPicture():
	return "res://Images/Perks/upgrade.png"

func canAppearInDungeons() -> bool:
	return false
