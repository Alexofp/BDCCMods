extends PerkBase

func _init():
	id = "VoreCockInitiate"
	skillGroup = "Vore"

func getVisibleName():
	return "Cock Absorption"

func getVisibleDescription():
	return "An additional method of absorption. You learn to draw a defeated opponent into your [b]cock[/b], drawing them down into your balls to be slowly churned and absorbed. While prey is held this way your balls swell to [b]300%[/b] of their normal size, returning to normal once the prey is digested or escapes. Maximum capacity: 1 prey at a time."

func getSkillTier():
	return 0

func getCost():
	return 1

func getRequiredPerks():
	return ["VoreInitiate"]

func getPicture():
	return "res://Images/Perks/upgrade.png"

func canAppearInDungeons() -> bool:
	return false
