extends PerkBase
func _init():
	id = "VoreVaginaRebirth"
	skillGroup = "Vore"
func getVisibleName():
	return "Womb Rebirth"
func getVisibleDescription():
	return "Instead of digesting prey held in your womb, your body remakes them. While this perk is [b]enabled[/b], womb prey are [b]not digested[/b] -- over about 6 days they are slowly unmade and reshaped into a fetus. Once the process completes you [b]become pregnant[/b], and the child you eventually give birth to is a copy of the swallowed victim: the same name, species and sex. [b]Toggle this perk off[/b] to let normal digestion resume. (Requires a womb.)"
func getMoreDescription():
	return "Overrides Endosoma (Womb) and normal womb digestion while enabled. Has no effect on prey held by any other method."
func getSkillTier():
	return 3
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreVaginaInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false