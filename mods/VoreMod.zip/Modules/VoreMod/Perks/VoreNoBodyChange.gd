extends PerkBase
func _init():
	id = "VoreNoBodyChange"
	skillGroup = "Vore"
func getVisibleName():
	return "Perfectly Unchanged"
func getVisibleDescription():
	return "While this perk is [b]enabled[/b], vore never leaves a permanent mark on your body. Your belly (and other places) still swell while prey is inside, but nothing sticks afterwards -- no thickness gain, no breast growth, no extra milk or cum. [b]Toggle this perk off[/b] (in the perk menu) if you want digestion to reshape you again."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return []
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
