extends PerkBase
func _init():
	id = "VoreTailExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Greedy Tail"
func getVisibleDescription():
	return "Your tail stretches to take more. You can now hold up to [b]2[/b] tail-absorbed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreTailInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
