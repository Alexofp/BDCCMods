extends PerkBase
func _init():
	id = "VoreObjectSmuggler"
	skillGroup = "Vore"
func getVisibleName():
	return "Professional Smuggler"
func getVisibleDescription():
	return "You know how to breathe, stand and smile while stuffed full of contraband. Guards are [b]far[/b] less likely to find anything when they search (or probe) you, and stored drugs are only half as likely to go off inside you."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreObjectInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
