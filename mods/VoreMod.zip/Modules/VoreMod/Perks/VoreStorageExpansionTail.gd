extends PerkBase
func _init():
	id = "VoreStorageExpansionTail"
	skillGroup = "Vore"
func getVisibleName():
	return "Tail Storage Expansion"
func getVisibleDescription():
	return "Your tail becomes thicker and more spacious for storing items.\n[b]Effect:[/b] +3 item slots in your [b]tail[/b] compartment.\nCan be purchased multiple times."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreTailInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
