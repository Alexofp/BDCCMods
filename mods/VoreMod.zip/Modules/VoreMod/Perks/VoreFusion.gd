extends PerkBase
func _init():
	id = "VoreFusion"
	skillGroup = "Vore"
func getVisibleName():
	return "Predatory Fusion"
func getVisibleDescription():
	return "A general vore perk that works for [b]every[/b] vore type. While this perk is [b]enabled[/b], a full digestion no longer ends in a simple absorption or death - instead predator and prey [b]fuse[/b] into a single new being.\n\nWhen [b]you fully digest an NPC[/b], you absorb them: you inherit every perk they had, and your level, core stats, skills and body are drawn to the midpoint between you and them. The new body becomes a [b]chimera[/b] - it keeps the species and base coloration of one of you, while breasts, cock, tail, ears, skin patterns and other parts are mixed in from both.\n\nWhen [b]an NPC fully digests you[/b], the same fusion happens and the merged being [b]replaces your character[/b] - you keep playing as the fusion instead of dying.\n\n[b]Toggle this perk off[/b] (in the perk menu) to return to normal digestion."
func getSkillTier():
	return 3
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false