extends PerkBase
func _init():
	id = "VoreVaginaExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Endless Depths"
func getVisibleDescription():
	return "Your womb becomes a near-bottomless chamber. You can now hold up to [b]3[/b] womb-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreVaginaExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
