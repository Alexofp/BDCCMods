extends PerkBase

func _init():
	id = "VoreApproachMagnet"
	skillGroup = "Vore"

func getVisibleName():
	return "Vore Magnet"

func getVisibleDescription():
	return "You give off an irresistible, hungry aura that draws predators and eager prey alike. NPCs approach you with vore offers [b]far more often[/b] -- roughly [b]double[/b] the chance each time, and they need only [b]half[/b] as long to gather their nerve again after the last approach.\n\n[i]Stacks against \"Vore Repellent\": taking both cancels the effect out.[/i]"

func getSkillTier():
	return 0

func getCost():
	return 1

func getRequiredPerks():
	return []

func getPicture():
	return "res://Images/Perks/upgrade.png"

func canAppearInDungeons() -> bool:
	return false
