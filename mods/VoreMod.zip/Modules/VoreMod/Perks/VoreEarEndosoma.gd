extends PerkBase
func _init():
	id = "VoreEarEndosoma"
	skillGroup = "Vore"
func getVisibleName():
	return "Endosoma (Ear)"
func getVisibleDescription():
	return "Endosomatophilia. While this perk is [b]enabled[/b], digestion is completely halted for prey held in your ear -- they stay alive and aware inside your ear canal indefinitely, gaining no progress and granting no final absorption. [b]Toggle this perk off[/b] (in the perk menu) to let digestion resume for that method again."
func getSkillTier():
	return 3
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreEarInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
