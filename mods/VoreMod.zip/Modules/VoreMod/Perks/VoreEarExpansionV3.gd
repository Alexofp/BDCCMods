extends PerkBase
func _init():
	id = "VoreEarExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Bottomless Canals"
func getVisibleDescription():
	return "Your ear canals become insatiable passages. You can now hold up to [b]3[/b] auditory-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreEarExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false