extends PerkBase
func _init():
	id = "VoreAnusEndosoma"
	skillGroup = "Vore"
func getVisibleName():
	return "Endosoma (Rear)"
func getVisibleDescription():
	return "Endosomatophilia. While this perk is [b]enabled[/b], digestion is completely halted for prey held in your rear and gut -- they stay alive and aware inside you indefinitely, gaining no progress and granting no final absorption. [b]Toggle this perk off[/b] (in the perk menu) to let digestion resume for that method again."
func getSkillTier():
	return 3
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreAnusInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
