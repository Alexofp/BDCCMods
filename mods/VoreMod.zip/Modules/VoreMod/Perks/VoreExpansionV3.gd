extends PerkBase

func _init():
	id = "VoreExpansionV3"
	skillGroup = "Vore"

func getVisibleName():
	return "Bottomless Stomach"

func getVisibleDescription():
	return "Your belly becomes a near-bottomless pit. You can now hold up to [b]3[/b] mouth-swallowed prey at once."

func getSkillTier():
	return 2

func getCost():
	return 1

func getRequiredPerks():
	return ["VoreExpansionV2"]

func getPicture():
	return "res://Images/Perks/upgrade.png"

func canAppearInDungeons() -> bool:
	return false
