extends PerkBase
func _init():
	id = "VoreObjectExpansion"
	skillGroup = "Vore"
func getVisibleName():
	return "Cargo Hold"
func getVisibleDescription():
	return "Practice makes room. [b]+2[/b] object capacity for every hole you can store cargo in. Your belly bulges like you are carrying twins when it is packed."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreObjectInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
