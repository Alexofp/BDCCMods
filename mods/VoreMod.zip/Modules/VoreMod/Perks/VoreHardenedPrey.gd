extends PerkBase
func _init():
	id = "VoreHardenedPrey"
	skillGroup = "Vore"
func getVisibleName():
	return "No Way Out"
func getVisibleDescription():
	return "While this perk is [b]enabled[/b], being prey gets genuinely brutal. Struggling costs more stamina and takes much longer, the predator acts against you far more often (squeezing, lying down on you, mocking you), you [b]cannot tell where you are[/b] while sealed inside, and escapes are harder. Recommended for anyone who thinks the prey side is too comfortable. [b]Toggle it off[/b] to go back to the gentler version."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return []
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
