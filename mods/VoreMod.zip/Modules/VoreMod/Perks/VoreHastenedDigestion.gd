extends PerkBase
func _init():
	id = "VoreHastenedDigestion"
	skillGroup = "Vore"
func getVisibleName():
	return "Hastened Digestion"
func getVisibleDescription():
	return "While this perk is [b]enabled[/b], being digested runs on [b]hours instead of nights[/b]: every 2 hours you spend inside a predator advances one stage, so the whole process takes about [b]12 hours[/b] instead of 6 days. Sleeping inside still advances a stage as usual. [b]Toggle it off[/b] (in the perk menu) to go back to the slow six-night version."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return []
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
