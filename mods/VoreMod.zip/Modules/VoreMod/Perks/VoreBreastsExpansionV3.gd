extends PerkBase
func _init():
	id = "VoreBreastsExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Boundless Bust"
func getVisibleDescription():
	return "Your breasts become voracious. You can now hold up to [b]3[/b] breast-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreBreastsExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false