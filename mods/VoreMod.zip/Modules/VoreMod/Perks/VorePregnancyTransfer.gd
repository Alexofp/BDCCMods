extends PerkBase
func _init():
	id = "VorePregnancyTransfer"
	skillGroup = "Vore"
func getVisibleName():
	return "Womb Thief"
func getVisibleDescription():
	return "A general vore perk that works for [b]every[/b] vore type. While this perk is [b]enabled[/b], if you fully digest (or otherwise process) a [b]pregnant[/b] NPC, the new life they were carrying does not perish with them - the fetus or fetuses are passed on to you, and [b]you become pregnant[/b] with their offspring.\n\nYou need a womb of your own to receive them; without one, the offspring are lost. [b]Toggle this perk off[/b] (in the perk menu) to let prey's pregnancies end with them as normal."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false