extends PerkBase

func _init():
	id = "VoreApproachRepellent"
	skillGroup = "Vore"

func getVisibleName():
	return "Vore Repellent"

func getVisibleDescription():
	return "You carry yourself with a cold, unapproachable air that makes others think twice. NPCs [b]very rarely[/b] dare to approach you with vore offers -- only about [b]a fifth[/b] of the usual chance each time, and they leave you alone for a [b]long[/b] while (roughly 15-25 rooms) between attempts.\n\n[i]Stacks against \"Vore Magnet\": taking both cancels the effect out.[/i]"

func getSkillTier():
	return 0

func getCost():
	return 1

func getRequiredPerks():
	return []

func getPicture():
	return "res://Images/Perks/upgrade.png"

func canAppearInDungeons() -> bool:
	return false
