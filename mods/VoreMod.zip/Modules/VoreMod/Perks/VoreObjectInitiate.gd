extends PerkBase
func _init():
	id = "VoreObjectInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Smuggler's Gullet"
func getVisibleDescription():
	return "You learn to swallow [b]objects[/b] instead of people. Every item in your inventory gains a [b]Store inside you[/b] button: pick any vore method you have unlocked and the item vanishes inside your body until you pull it back out. Base capacity: [b]2[/b] objects per unlocked hole. Cargo sloshing around inside you slowly builds arousal, and a stuffed gut keeps hunger away entirely."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
