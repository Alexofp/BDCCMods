extends PerkBase
func _init():
	id = "VoreVaginaExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Greedy Womb"
func getVisibleDescription():
	return "Your womb stretches to cradle more. You can now hold up to [b]2[/b] womb-absorbed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreVaginaInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
