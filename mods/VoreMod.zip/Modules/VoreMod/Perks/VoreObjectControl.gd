extends PerkBase
func _init():
	id = "VoreObjectControl"
	skillGroup = "Vore"
func getVisibleName():
	return "Iron Control"
func getVisibleDescription():
	return "Absolute mastery over every muscle that matters. Cargo [b]never[/b] slips out of you on its own - not when you climax, not while you sleep - and shifting objects arouse you half as much."
func getSkillTier():
	return 3
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreObjectInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
