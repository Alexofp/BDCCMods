extends PerkBase
func _init():
	id = "VoreEyeExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Infinite Stare"
func getVisibleDescription():
	return "Your eyes become insatiable voids. You can now hold up to [b]3[/b] ocular-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreEyeExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false