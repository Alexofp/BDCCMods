extends PerkBase
func _init():
	id = "VoreStorageExpansionAnus"
	skillGroup = "Vore"
func getVisibleName():
	return "Rear Storage Expansion"
func getVisibleDescription():
	return "Your rear becomes more capacious and efficient at holding items.\n[b]Effect:[/b] +3 item slots in your [b]rear/anus[/b] compartment.\nCan be purchased multiple times."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreAnusInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
