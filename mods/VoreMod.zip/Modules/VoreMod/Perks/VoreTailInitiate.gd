extends PerkBase
func _init():
	id = "VoreTailInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Tail Absorption"
func getVisibleDescription():
	return "An additional method of absorption. You learn to coil your tail around a defeated opponent and draw them deep inside, processing them within your powerful coils. Maximum capacity: 1 prey at a time."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
