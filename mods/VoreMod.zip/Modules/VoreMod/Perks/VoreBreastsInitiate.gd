extends PerkBase
func _init():
	id = "VoreBreastsInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Bust Absorption"
func getVisibleDescription():
	return "An additional method of absorption. You learn to draw a defeated opponent into your [b]breast[/b] tissue, slowly converting them. Maximum capacity: 1 prey at a time."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
