extends PerkBase
func _init():
	id = "VoreIrresistiblePrey"
	skillGroup = "Vore"
func getVisibleName():
	return "Irresistible Prey"
func getVisibleDescription():
	return "While this perk is [b]enabled[/b], predators stop asking nicely. Vore offers happen far more often, [b]refusing an offer very often gets ignored[/b] and you get taken in anyway, losing a fight can end with the winner [b]devouring you[/b] instead of just punishing you, and you are much more likely to wake up already inside someone. [b]Toggle it off[/b] if you want to be asked politely again."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return []
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
