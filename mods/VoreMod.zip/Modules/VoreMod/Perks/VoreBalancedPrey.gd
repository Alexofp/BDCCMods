extends PerkBase
func _init():
	id = "VoreBalancedPrey"
	skillGroup = "Vore"
func getVisibleName():
	return "Balanced Odds"
func getVisibleDescription():
	return "While this perk is [b]enabled[/b], hunger stops being the most likely thing to happen to you after a lost fight. Whenever the winner could devour you, the [b]Devour[/b] option is capped: it is never worth more than [b]every ordinary option put together[/b], so it tops out around a [b]50/50[/b] between ending up in somebody's stomach and the usual base-game result (getting punished, fucked, frisked or simply left alone). The chance the game shows for the winner's actions reflects this.\n\nIt never makes a predator hungrier than they already were -- the perk only ever [b]lowers[/b] the odds, so a winner who was not that interested in eating you stays that way. It also never [b]hides[/b] Devour and never changes whether the winner is allowed to eat you. [b]Toggle it off[/b] to let appetite decide again.\n\n[i]Works against \"Vore Irresistible Prey\": even with that perk on, the odds stay even.[/i]"
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return []
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
