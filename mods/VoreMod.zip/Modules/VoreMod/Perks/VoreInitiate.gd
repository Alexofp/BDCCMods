extends PerkBase
func _init():
	id = "VoreInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Vore Initiate"
func getVisibleDescription():
	return "Your starting vore perk. You learn how to unhinge your jaw and swallow a defeated opponent whole through your [b]mouth[/b]. Maximum capacity: 1 prey at a time."
func getSkillTier():
	return 0
func getCost():
	return 0
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false