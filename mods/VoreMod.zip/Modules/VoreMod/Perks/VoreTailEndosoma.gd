extends PerkBase
func _init():
	id = "VoreTailEndosoma"
	skillGroup = "Vore"
func getVisibleName():
	return "Endosoma (Tail)"
func getVisibleDescription():
	return "Endosomatophilia. While this perk is [b]enabled[/b], digestion is completely halted for prey held in your tail -- they stay alive and aware inside your coils indefinitely, gaining no progress and granting no final absorption. [b]Toggle this perk off[/b] (in the perk menu) to let digestion resume for that method again."
func getSkillTier():
	return 3
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreTailInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false