extends PerkBase
func _init():
	id = "VoreForbiddenMethod"
	skillGroup = "Vore"
func getVisibleName():
	return "Forbidden Flavor"
func getVisibleDescription():
	return "While this perk is [b]enabled[/b], you can declare one vore method untouchable. Pick it in the Me menu - from then on no NPC can use that method on you, [b]under any circumstances[/b]: offers, force-feeding, sleeping predators, even your own slaves. The chosen method is simply closed to them. [b]Toggle this perk off[/b] (in the perk menu) to become vulnerable to every method again."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
