extends PerkBase
func _init():
	id = "VoreAnusInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Rear Absorption"
func getVisibleDescription():
	return "An additional method of absorption. You learn to pull a defeated opponent into your [b]rear[/b], processing them through your digestive tract. Maximum capacity: 1 prey at a time."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false