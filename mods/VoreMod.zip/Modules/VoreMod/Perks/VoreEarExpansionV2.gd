extends PerkBase
func _init():
	id = "VoreEarExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Wider Canal"
func getVisibleDescription():
	return "Your ear canals stretch to take more. You can now hold up to [b]2[/b] auditory-absorbed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreEarInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false