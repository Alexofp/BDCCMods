extends PerkBase
func _init():
	id = "VoreStorageExpansionBreasts"
	skillGroup = "Vore"
func getVisibleName():
	return "Breast Storage Expansion"
func getVisibleDescription():
	return "Your breasts become softer and more accommodating for hidden cargo.\n[b]Effect:[/b] +3 item slots in your [b]breasts[/b] compartment.\nCan be purchased multiple times."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreBreastsInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
