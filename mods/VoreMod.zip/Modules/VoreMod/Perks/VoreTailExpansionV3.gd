extends PerkBase
func _init():
	id = "VoreTailExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Insatiable Tail"
func getVisibleDescription():
	return "Your tail becomes insatiable. You can now hold up to [b]3[/b] tail-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreTailExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false