extends PerkBase
func _init():
	id = "VoreAnusExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Greedy Rear"
func getVisibleDescription():
	return "Your tract stretches to take more. You can now hold up to [b]2[/b] rear-absorbed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreAnusInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
