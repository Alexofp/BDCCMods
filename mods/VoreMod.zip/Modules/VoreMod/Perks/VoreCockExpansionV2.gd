extends PerkBase
func _init():
	id = "VoreCockExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Heavy Hangers"
func getVisibleDescription():
	return "Your shaft and balls swell to take in more. You can now hold up to [b]2[/b] cock-absorbed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreCockInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
