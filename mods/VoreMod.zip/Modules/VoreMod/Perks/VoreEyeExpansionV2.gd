extends PerkBase
func _init():
	id = "VoreEyeExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Deeper Gaze"
func getVisibleDescription():
	return "Your eyes stretch to take more. You can now hold up to [b]2[/b] ocular-absorbed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreEyeInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
