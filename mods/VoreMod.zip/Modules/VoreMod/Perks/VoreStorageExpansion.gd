extends PerkBase
func _init():
	id = "VoreStorageExpansion"
	skillGroup = "Vore"
func getVisibleName():
	return "Universal Storage Expansion"
func getVisibleDescription():
	return "Your body becomes better at compartmentalizing. You learn to pack items more efficiently in [b]all[/b] your vore storage compartments.\n\n[b]Effect:[/b] +2 item slots for every vore method (mouth, anus, vagina, cock, breasts, tail).\n\nCan be purchased multiple times to further increase capacity."
func getSkillTier():
	return 2
func getCost():
	return 2
func getRequiredPerks():
	return ["VoreObjectInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
