extends PerkBase

func _init():
	id = "VoreVaginaConvert"
	skillGroup = "Vore"

func getVisibleName():
	return "Womb Reshaping"

func getVisibleDescription():
	return "A [b]womb-vore[/b] perk. While this perk is [b]enabled[/b], prey drawn up into your womb are not absorbed. Instead, on the sixth day they are automatically [b]reborn and slip back out alive[/b] - but their body has been reshaped, and their [b]species is changed to match yours[/b], along with their base coloration.\n\nThis takes priority over Womb Rebirth for womb-vore prey. [b]Toggle this perk off[/b] (in the perk menu) to return to normal womb-vore absorption."

func getSkillTier():
	return 3

func getCost():
	return 1

func getRequiredPerks():
	return ["VoreVaginaInitiate"]

func getPicture():
	return "res://Images/Perks/upgrade.png"

func canAppearInDungeons() -> bool:
	return false
