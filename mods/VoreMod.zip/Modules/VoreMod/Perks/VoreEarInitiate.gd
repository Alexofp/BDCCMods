extends PerkBase
func _init():
	id = "VoreEarInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Auditory Absorption"
func getVisibleDescription():
	return "A bizarre method of absorption. You learn to pull a [b]shrunk[/b] opponent into your ear canal, engulfing them whole through the opening. Only works on targets shrunk to [b]0.1x[/b] or smaller. Maximum capacity: 1 prey at a time."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
