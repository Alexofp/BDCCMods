extends PerkBase
func _init():
	id = "VoreStorageExpansionVagina"
	skillGroup = "Vore"
func getVisibleName():
	return "Womb Storage Expansion"
func getVisibleDescription():
	return "Your womb stretches to accommodate more items safely.\n[b]Effect:[/b] +3 item slots in your [b]womb/vagina[/b] compartment.\nCan be purchased multiple times."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreVaginaInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
