extends PerkBase
func _init():
	id = "VoreExpansionV2"
	skillGroup = "Vore"
func getVisibleName():
	return "Greedy Gullet"
func getVisibleDescription():
	return "Your throat and stomach stretch to accommodate more. You can now hold up to [b]2[/b] mouth-swallowed prey at once."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
