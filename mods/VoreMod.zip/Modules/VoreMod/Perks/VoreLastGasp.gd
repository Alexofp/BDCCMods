extends PerkBase
func _init():
	id = "VoreLastGasp"
	skillGroup = "Vore"
func getVisibleName():
	return "Last Gasp"
func getVisibleDescription():
	return "Even at the very last stage of digestion, when a predator has already written you off, you get [b]one final desperate attempt[/b] to force your way out instead of instantly being absorbed. The odds are terrible and you come out a wreck -- but it is not automatically over anymore."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return []
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
