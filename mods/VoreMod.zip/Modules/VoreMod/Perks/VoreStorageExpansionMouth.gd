extends PerkBase
func _init():
	id = "VoreStorageExpansionMouth"
	skillGroup = "Vore"
func getVisibleName():
	return "Stomach Expansion"
func getVisibleDescription():
	return "You learn to expand your stomach to hold more items at once.\n[b]Effect:[/b] +3 item slots in your [b]mouth/stomach[/b] compartment.\nCan be purchased multiple times."
func getSkillTier():
	return 1
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreObjectInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
