extends PerkBase
func _init():
	id = "VoreAnusExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Insatiable Rear"
func getVisibleDescription():
	return "Your rear becomes insatiable. You can now hold up to [b]3[/b] rear-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreAnusExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false
