extends PerkBase
func _init():
	id = "VoreCockExpansionV3"
	skillGroup = "Vore"
func getVisibleName():
	return "Breeder's Cauldron"
func getVisibleDescription():
	return "Your balls become a churning, near-bottomless vat. You can now hold up to [b]3[/b] cock-absorbed prey at once."
func getSkillTier():
	return 2
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreCockExpansionV2"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false