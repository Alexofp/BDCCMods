extends PerkBase
func _init():
	id = "VoreVaginaInitiate"
	skillGroup = "Vore"
func getVisibleName():
	return "Womb Absorption"
func getVisibleDescription():
	return "An additional method of absorption. You learn to pull a defeated opponent up inside your [b]vagina[/b], drawing them deep into your womb to be slowly absorbed. Maximum capacity: 1 prey at a time."
func getSkillTier():
	return 0
func getCost():
	return 1
func getRequiredPerks():
	return ["VoreInitiate"]
func getPicture():
	return "res://Images/Perks/upgrade.png"
func canAppearInDungeons() -> bool:
	return false