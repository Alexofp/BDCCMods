extends StatusEffectBase
const STAGE_COUNT = 6
const FINAL_STAGE = 6
const STAGE_NAMES = [
	"Swallowed",
	"Struggling",
	"Weakening",
	"Softening",
	"Dissolving",
	"Nearly Absorbed",
]
const ESCAPE_MAX_STAGE = 2
const ESCAPE_TIMER_MIN     = 1800
const ESCAPE_TIMER_MAX     = 5400
const ESCAPE_INITIAL_DELAY = 900
const NO_BODY_CHANGE_PERK = "VoreNoBodyChange"
var swallowedNames   = []
var swallowedIDs     = []
var swallowedMethods = []
var _pendingCleanup  = []
var _originalPools   = {}
var digestionStages  = {}
var escapeTimers     = {}
var tamedNPCs        = []
var brokenNPCs       = []
var _pendingEscapeID = ""
var digestionPausedNights = 0
func getVoreMethod() -> String:
	return "mouth"
func _stageDescList() -> Array:
	return []
func _sleepMsgList() -> Array:
	return []
func _sleepFinalMsg() -> String:
	return "{who} has been fully digested overnight."
func _endosomaPerkID() -> String:
	return ""
func _applyPartialEffect(_stage: int):
	pass
func _applyFinalEffect():
	pass
func _onPreyFullyProcessed(_npcID: String, who: String) -> bool:
	GM.main.addMessage(_getFinalMessage(who))
	GM.pc.addSkillExperience("Vore", 100)
	GM.main.addMessage("Fully digested! +100 Vore XP")
	if GM.pc != null and GM.pc.hasPerk("VoreFusion"):
		var npcChar = GlobalRegistry.getCharacter(_npcID)
		if npcChar != null:
			var fusionHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
			fusionHelper.performFusionWithMessages(GM.pc, npcChar)
	if GM.pc != null and GM.pc.hasPerk("VorePregnancyTransfer"):
		var preyChar = GlobalRegistry.getCharacter(_npcID)
		if preyChar != null:
			var pregHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
			var moved = pregHelper.transferPregnancy(preyChar, GM.pc)
			if moved > 0:
				GM.main.addMessage("As " + who + " breaks down, the new life they were carrying slips free and takes root in your womb. [b]You are now pregnant with their offspring![/b] (" + str(moved) + " transferred)")
			elif moved < 0:
				GM.main.addMessage(who + " was pregnant, but you have no womb to receive the offspring - the new life is lost with them.")
	if _bodyChangesSuppressed():
		GM.main.addMessage("The last of " + who + " is absorbed, but your body holds its shape -- your perk keeps you perfectly unchanged.")
	else:
		_applyFinalEffect()
	return true
func _releasePreyInsteadOfDigesting(_npcID: String, _who: String) -> bool:
	return false
func _countsTowardBelly() -> bool:
	return true
func _onPreyChanged():
	pass
func _init():
	id = "VoreSwallowedNPCBase"
	isBattleOnly = false
func getDigestionStage(npcID: String) -> int:
	return int(digestionStages.get(npcID, 0))
func getDigestionProgress(npcID: String) -> float:
	var stage = getDigestionStage(npcID)
	return clamp(float(stage) / float(STAGE_COUNT), 0.0, 1.0)
func isDigestionDisabled() -> bool:
	if GM.pc == null:
		return false
	var perkID = _endosomaPerkID()
	if perkID == "":
		return false
	return GM.pc.hasPerk(perkID)

func _bodyChangesSuppressed() -> bool:
	if GM.pc == null:
		return false
	return GM.pc.hasPerk(NO_BODY_CHANGE_PERK)
func initArgs(_args = []):
	if _args.size() > 0:
		var n = str(_args[0])
		if not swallowedNames.has(n):
			swallowedNames.append(n)
	if _args.size() > 1:
		var npcID = str(_args[1])
		if npcID != "" and not swallowedIDs.has(npcID):
			swallowedIDs.append(npcID)
			_pendingCleanup.append(npcID)
			digestionStages[npcID] = 0
			escapeTimers[npcID] = float(ESCAPE_INITIAL_DELAY) + RNG.randf_range(ESCAPE_TIMER_MIN, ESCAPE_TIMER_MAX)
			_captureAndRemovePools(npcID)
	if swallowedMethods.size() < swallowedIDs.size():
		swallowedMethods.append(getVoreMethod())
	_onPreyChanged()
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
	if character != null:
		character.updateNonBattleEffects()
func _captureAndRemovePools(npcID: String):
	if GM.main == null:
		return
	var pools = []
	for poolID in GM.main.getDynamicCharactersPools():
		var ids = GM.main.getDynamicCharacterIDsFromPool(poolID)
		if ids.has(npcID):
			pools.append(poolID)
	if pools.size() > 0:
		_originalPools[npcID] = pools
	GM.main.removeDynamicCharacterFromAllPools(npcID)
func _restorePools(npcID: String):
	if GM.main == null:
		return
	if _originalPools.has(npcID):
		for poolID in _originalPools[npcID]:
			GM.main.addDynamicCharacterToPool(npcID, poolID)
		_originalPools.erase(npcID)
func hasPendingEscape() -> bool:
	return _pendingEscapeID != ""
func getPendingEscapeID() -> String:
	return _pendingEscapeID
func clearPendingEscape():
	_pendingEscapeID = ""
func onNPCTamed(npcID: String):
	if not tamedNPCs.has(npcID):
		tamedNPCs.append(npcID)
	escapeTimers.erase(npcID)
	clearPendingEscape()
func onNPCCalmed(npcID: String):
	clearPendingEscape()
	if canStillEscape(npcID):
		escapeTimers[npcID] = RNG.randf_range(ESCAPE_TIMER_MAX, ESCAPE_TIMER_MAX * 2.0)
	else:
		escapeTimers.erase(npcID)
func canStillEscape(npcID: String) -> bool:
	if not swallowedIDs.has(npcID):
		return false
	if brokenNPCs.has(npcID) or tamedNPCs.has(npcID):
		return false
	return getDigestionStage(npcID) <= ESCAPE_MAX_STAGE
func getSwallowMethodForID(npcID: String) -> String:
	if swallowedIDs.has(npcID):
		return getVoreMethod()
	return getVoreMethod()
func getNameForID(npcID: String) -> String:
	var idx = swallowedIDs.find(npcID)
	if idx >= 0 and idx < swallowedNames.size():
		return swallowedNames[idx]
	return "your prey"
func onNPCEscaped(npcID: String):
	var idx = swallowedIDs.find(npcID)
	if idx >= 0:
		swallowedIDs.remove(idx)
		if idx < swallowedNames.size():
			swallowedNames.remove(idx)
		if idx < swallowedMethods.size():
			swallowedMethods.remove(idx)
	escapeTimers.erase(npcID)
	digestionStages.erase(npcID)
	_pendingCleanup.erase(npcID)
	clearPendingEscape()
	_restorePools(npcID)
	if GM.main != null:
		if not GM.main.IS.hasPawn(npcID):
			GM.main.IS.spawnPawn(npcID)
		var escapedPawn = GM.main.IS.getPawn(npcID)
		if escapedPawn != null and GM.pc != null:
			escapedPawn.setLocation(GM.pc.getLocation())
	if swallowedIDs.size() <= 0:
		swallowedNames.clear()
		swallowedMethods.clear()
		_onPreyChanged()
		stop()
		return
	_onPreyChanged()
	if character != null:
		character.updateNonBattleEffects()
func markBroken(npcID: String):
	if not brokenNPCs.has(npcID):
		brokenNPCs.append(npcID)
	escapeTimers.erase(npcID)
func releaseNPC(npcID: String):
	onNPCEscaped(npcID)
func pauseDigestion(nights: int = 1) -> String:
	if swallowedIDs.size() <= 0:
		return "Nothing happens - there is no one inside you to keep from digesting."
	digestionPausedNights = max(digestionPausedNights, nights)
	if character != null:
		character.updateNonBattleEffects()
	return "Your gut goes still. Digestion is halted for the next day - sleep will not break down your prey until then."
func accelerateDigestion() -> String:
	if swallowedIDs.size() <= 0:
		return "Nothing happens - there is no one inside you to digest."
	if GM.pc == null:
		return "Nothing happens."
	var advanced = 0
	var blocked  = 0
	for i in range(swallowedIDs.size()):
		var npcID = swallowedIDs[i]
		var stage = getDigestionStage(npcID)
		if isDigestionDisabled():
			blocked += 1
			continue
		if stage < STAGE_COUNT:
			digestionStages[npcID] = stage + 1
			if not _bodyChangesSuppressed():
				_applyPartialEffect(stage)
			GM.pc.addSkillExperience("Vore", 10 + stage * 5)
			advanced += 1
	for escNpcID in escapeTimers.keys():
		if getDigestionStage(escNpcID) > ESCAPE_MAX_STAGE:
			escapeTimers.erase(escNpcID)
	if _pendingEscapeID != "" and not canStillEscape(_pendingEscapeID):
		clearPendingEscape()
	if character != null:
		character.updateNonBattleEffects()
	if advanced <= 0:
		if blocked > 0:
			return "Nothing churns forward - Endosoma is keeping your prey perfectly preserved. Toggle the matching perk off to let digestion resume."
		return "Everyone inside you is already fully softened - sleep to finish digesting them."
	return "A churning heat floods through you. Digestion lurches forward - your prey is broken down a full stage faster."
func _getBellyCount() -> int:
	if not _countsTowardBelly():
		return 0
	return swallowedIDs.size()
func _progressBar(progress: float) -> String:
	var filled = int(round(progress * 10.0))
	var bar = "["
	for i in range(10):
		bar += "#" if i < filled else "."
	bar += "]"
	return bar
func getEffectName():
	return "Full Belly"
func getEffectDesc():
	if swallowedNames.size() <= 0:
		return "You have someone inside you."
	var namesText = Util.join(swallowedNames, ", ")
	var method    = getVoreMethod()
	var descList  = _stageDescList()
	var readyCount = 0
	for npcID in swallowedIDs:
		if getDigestionStage(npcID) >= STAGE_COUNT:
			readyCount += 1
	var desc = ""
	if readyCount > 0:
		desc = "You have " + namesText + " inside you. Some are nearly fully digested -- sleep to finish them."
	else:
		desc = "You have " + namesText + " inside you. They will be digested over several nights."
	for i in range(swallowedIDs.size()):
		var who      = swallowedNames[i] if i < swallowedNames.size() else "them"
		var npcID    = swallowedIDs[i]
		var stage    = getDigestionStage(npcID)
		var progress = getDigestionProgress(npcID)
		var stageIdx = clamp(stage, 0, STAGE_COUNT - 1)
		var stageName = STAGE_NAMES[stageIdx]
		var stageDesc = ""
		if stageIdx < descList.size():
			stageDesc = descList[stageIdx]
		var extraNote = ""
		if brokenNPCs.has(npcID):
			extraNote = " [broken]"
		elif tamedNPCs.has(npcID):
			extraNote = " [tamed]"
		if isDigestionDisabled():
			extraNote += " [Endosoma - digestion halted]"
		var nightsLeft = STAGE_COUNT - stage
		var nightsStr  = str(nightsLeft) + (" night" if nightsLeft == 1 else " nights")
		desc += "\n\n* " + who + extraNote + "  (" + method + ")"
		desc += "\n  Day " + str(stage + 1) + " of " + str(STAGE_COUNT) + "  -  " + stageName + "  " + _progressBar(progress)
		desc += "\n  " + who + " " + stageDesc
		if isDigestionDisabled():
			desc += "\n  [Held safe by Endosoma - kept alive, no digestion]"
		elif stage >= STAGE_COUNT - 1:
			desc += "\n  [Fully ready - sleep to complete digestion!]"
		else:
			desc += "\n  [~" + nightsStr + " remaining]"
	var bellyCount = _getBellyCount()
	if bellyCount == 1:
		desc += "\n\nYour belly is noticeably inflated."
	elif bellyCount == 2:
		desc += "\n\nYour belly is heavily distended and quite large."
	elif bellyCount >= 3:
		desc += "\n\nYour belly is massively inflated, looking grotesquely swollen!"
	return desc
func getEffectImage():
	var bellyCount = _getBellyCount()
	if bellyCount >= 2:
		return "res://Images/StatusEffects/bloating.png"
	elif bellyCount >= 1:
		return "res://Images/StatusEffects/belly.png"
	return "res://Images/StatusEffects/lactation.png"
func getIconColor():
	return IconColorGreen
func getBuffs():
	if swallowedIDs.size() <= 0:
		return []
	var result     = []
	var bellyCount = _getBellyCount()
	if bellyCount > 0:
		result.append(buff(Buff.InflatedBellyBuff, [40.0 * bellyCount]))
	return result
func processTime(_secondsPassed: int):
	if GM.main == null:
		return
	var cleaned = []
	for npcID in _pendingCleanup:
		if GM.main.isCharIDFighting(npcID):
			continue
		if GM.main.IS.hasPawn(npcID):
			GM.main.IS.deletePawn(npcID)
		cleaned.append(npcID)
	for npcID in cleaned:
		_pendingCleanup.erase(npcID)
	if _pendingEscapeID != "":
		return
	var toEscape = ""
	for npcID in escapeTimers.keys():
		if not swallowedIDs.has(npcID):
			escapeTimers.erase(npcID)
			continue
		if brokenNPCs.has(npcID) or tamedNPCs.has(npcID):
			escapeTimers.erase(npcID)
			continue
		if getDigestionStage(npcID) > ESCAPE_MAX_STAGE:
			escapeTimers.erase(npcID)
			continue
		escapeTimers[npcID] -= float(_secondsPassed)
		if escapeTimers[npcID] <= 0.0:
			toEscape = npcID
			break
	if toEscape != "":
		_pendingEscapeID = toEscape
func onSleeping():
	var accelEvent = GlobalRegistry.getEvent("VorePregAccelerationEvent")
	if accelEvent != null:
		accelEvent.accelerate()
	if GM.pc == null or GM.main == null:
		return
	if digestionPausedNights > 0:
		digestionPausedNights -= 1
		if swallowedIDs.size() > 0:
			GM.main.addMessage("The anti-digestion pill keeps working - nobody inside you is digested tonight.")
		if character != null:
			character.updateNonBattleEffects()
		return
	var toDigest  = []
	var toAdvance = []
	var heldByEndosoma = 0
	var endosomaActive = isDigestionDisabled()
	for i in range(swallowedIDs.size()):
		var npcID = swallowedIDs[i]
		if endosomaActive:
			heldByEndosoma += 1
			continue
		if getDigestionStage(npcID) >= STAGE_COUNT:
			toDigest.append(i)
		else:
			toAdvance.append(i)
	if heldByEndosoma > 0:
		GM.main.addMessage("Endosoma keeps " + str(heldByEndosoma) + " of your prey alive and undigested tonight - they make no progress while the perk stays enabled.")
	for i in toAdvance:
		var npcID = swallowedIDs[i]
		var who   = swallowedNames[i] if i < swallowedNames.size() else "them"
		var stage = getDigestionStage(npcID)
		digestionStages[npcID] = stage + 1
		var sleepMsg = _getSleepMessage(stage, who)
		GM.main.addMessage(sleepMsg)
		var partialExp = 10 + stage * 5
		GM.pc.addSkillExperience("Vore", partialExp)
		GM.main.addMessage(
			"Digestion progresses... +" + str(partialExp) + " Vore XP  [Stage "
			+ str(stage + 1) + "/" + str(STAGE_COUNT) + "]"
		)
		if not _bodyChangesSuppressed():
			_applyPartialEffect(stage)
	for escNpcID in escapeTimers.keys():
		if getDigestionStage(escNpcID) > ESCAPE_MAX_STAGE:
			escapeTimers.erase(escNpcID)
	if _pendingEscapeID != "" and not canStillEscape(_pendingEscapeID):
		clearPendingEscape()
	toDigest.sort()
	toDigest.invert()
	for i in toDigest:
		var npcID = swallowedIDs[i]
		var who   = swallowedNames[i] if i < swallowedNames.size() else "them"
		if _releasePreyInsteadOfDigesting(npcID, who):
			_restorePools(npcID)
			if GM.main != null:
				if not GM.main.IS.hasPawn(npcID):
					GM.main.IS.spawnPawn(npcID)
				var releasedPawn = GM.main.IS.getPawn(npcID)
				if releasedPawn != null and GM.pc != null:
					releasedPawn.setLocation(GM.pc.getLocation())
			swallowedIDs.remove(i)
			if i < swallowedNames.size():
				swallowedNames.remove(i)
			if i < swallowedMethods.size():
				swallowedMethods.remove(i)
			digestionStages.erase(npcID)
			escapeTimers.erase(npcID)
			_pendingCleanup.erase(npcID)
			continue
		var giveWellFed = _onPreyFullyProcessed(npcID, who)
		if giveWellFed:
			GM.pc.addEffect("VoreWellFed", [1])
		if GM.main.IS.hasPawn(npcID):
			GM.main.IS.deletePawn(npcID)
		if GM.main.dynamicCharacters.has(npcID):
			GM.main.removeDynamicCharacter(npcID)
		swallowedIDs.remove(i)
		if i < swallowedNames.size():
			swallowedNames.remove(i)
		if i < swallowedMethods.size():
			swallowedMethods.remove(i)
		digestionStages.erase(npcID)
		escapeTimers.erase(npcID)
		_pendingCleanup.erase(npcID)
		_originalPools.erase(npcID)
	_onPreyChanged()
	if swallowedIDs.size() <= 0:
		swallowedNames.clear()
		swallowedMethods.clear()
		digestionStages.clear()
		escapeTimers.clear()
		_pendingCleanup.clear()
		_originalPools.clear()
		tamedNPCs.clear()
		brokenNPCs.clear()
		_pendingEscapeID = ""
		stop()
	elif character != null:
		character.updateNonBattleEffects()
func _getSleepMessage(stage: int, who: String) -> String:
	var s        = clamp(stage, 0, STAGE_COUNT - 1)
	var msgList  = _sleepMsgList()
	var template = ""
	if s < msgList.size():
		template = msgList[s]
	return template.replace("{who}", who)
func _getFinalMessage(who: String) -> String:
	return _sleepFinalMsg().replace("{who}", who)
func saveData():
	return {
		"swallowedNames":   swallowedNames,
		"swallowedIDs":     swallowedIDs,
		"swallowedMethods": swallowedMethods,
		"tamedNPCs":        tamedNPCs,
		"brokenNPCs":       brokenNPCs,
		"escapeTimers":     escapeTimers,
		"digestionStages":  digestionStages,
		"pendingEscapeID":  _pendingEscapeID,
		"digestionPausedNights": digestionPausedNights,
		"originalPools":    _originalPools,
	}
func loadData(_data):
	swallowedNames   = SAVE.loadVar(_data, "swallowedNames",   [])
	swallowedIDs     = SAVE.loadVar(_data, "swallowedIDs",     [])
	swallowedMethods = SAVE.loadVar(_data, "swallowedMethods", [])
	tamedNPCs        = SAVE.loadVar(_data, "tamedNPCs",        [])
	brokenNPCs       = SAVE.loadVar(_data, "brokenNPCs",       [])
	escapeTimers     = SAVE.loadVar(_data, "escapeTimers",     {})
	digestionStages  = SAVE.loadVar(_data, "digestionStages",  {})
	_pendingEscapeID = SAVE.loadVar(_data, "pendingEscapeID",  "")
	digestionPausedNights = SAVE.loadVar(_data, "digestionPausedNights", 0)
	_originalPools   = SAVE.loadVar(_data, "originalPools", {})
	_pendingCleanup  = swallowedIDs.duplicate()
	while swallowedMethods.size() < swallowedIDs.size():
		swallowedMethods.append(getVoreMethod())
	for npcID in swallowedIDs:
		if not digestionStages.has(npcID):
			digestionStages[npcID] = 0
