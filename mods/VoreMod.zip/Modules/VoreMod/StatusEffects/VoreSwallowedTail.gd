extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const TAIL_SCALE_MULT = 2.5
var _tailEnlarged  = false
var _tailOrigScale = 1.0
const STAGE_DESC = [
	"has just been coiled up and drawn into your tail, squirming in the tight, muscled grip.",
	"is struggling inside your tail, the relentless coils squeezing tighter with every movement.",
	"is losing strength -- your tail's rhythmic constriction is wearing them down.",
	"is beginning to soften, your tail thickening as it absorbs their essence.",
	"is dissolving deep within your tail, the scales stretching visibly around the vanishing prey.",
	"is nearly fully absorbed -- only the richest essence of them remains, your tail heavy and satisfied.",
]
const SLEEP_MSG = [
	"You drift off feeling the weight in your tail. {who} squirms inside the coiled flesh, unable to escape your grip.",
	"Another night passes. {who} is still fighting against your tail's constriction, but each squeeze is stronger than the last.",
	"You wake to a warm, heavy sensation in your tail. {who}'s resistance is breaking down under the relentless pressure.",
	"The absorption of {who} is well underway. Your tail feels dense and warm, the scales stretched taut over your prey.",
	"You sleep deeply as {who} dissolves within your tail, the thick coils swelling and softening around them.",
	"Almost there. {who} is nearly all gone -- one more night and your tail will have claimed every last trace of them.",
]
const SLEEP_MSG_FINAL = "You wake to a deep, satisfied heaviness in your tail. {who} has been fully absorbed overnight -- rendered down completely, every last trace of them now part of your powerful, thickened tail."
func _init():
	id = "VoreSwallowedTail"
	isBattleOnly = false
func getVoreMethod() -> String:    return "tail"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreTailEndosoma"
func _countsTowardBelly() -> bool:
	return false
func _onPreyChanged():
	if GM.pc == null:
		return
	var tail = GM.pc.getBodypart(BodypartSlot.Tail)
	if tail == null:
		_tailEnlarged = false
		return
	var tailCount = swallowedIDs.size()
	if tailCount > 0 and not _tailEnlarged:
		_tailOrigScale = tail.getLength()
		tail.setLength(_tailOrigScale * TAIL_SCALE_MULT)
		tail.updateAppearance()
		_tailEnlarged = true
	elif tailCount <= 0 and _tailEnlarged:
		tail.setLength(_tailOrigScale)
		tail.updateAppearance()
		_tailEnlarged = false
func _applyPartialEffect(stage: int):
	var add = 1 + int(stage >= 3)
	var cur = GM.pc.getThickness()
	GM.pc.setThickness(int(min(cur + add, 150)))
func _applyFinalEffect():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 7, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Complete absorption. Your tail has drawn every last trace of your prey into you -- your powerful coils are thicker, heavier, and more satisfying than before. Thickness: " + str(newVal) + "%"
	)
func saveData():
	var data = .saveData()
	data["tailEnlarged"]  = _tailEnlarged
	data["tailOrigScale"] = _tailOrigScale
	return data
func loadData(_data):
	.loadData(_data)
	_tailEnlarged  = SAVE.loadVar(_data, "tailEnlarged",  false)
	_tailOrigScale = SAVE.loadVar(_data, "tailOrigScale", 1.0)
