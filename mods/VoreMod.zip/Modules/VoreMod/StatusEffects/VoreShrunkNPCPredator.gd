extends StatusEffectBase
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var preyNames   = []
var preyIDs     = []
var preyMethods = []
var timers      = {}
var _originalPools = {}
func _init():
	id = "VoreShrunkNPCPredator"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() >= 2:
		var pName = str(_args[0])
		var pID   = str(_args[1])
		var m     = "mouth"
		if _args.size() >= 3:
			m = str(_args[2])
		var remaining = -1.0
		if _args.size() >= 4:
			remaining = float(_args[3])
		if pID != "" and not preyIDs.has(pID):
			preyNames.append(pName)
			preyIDs.append(pID)
			preyMethods.append(m)
			timers[pID] = (-1.0 if remaining <= 0.0 else remaining)
			_captureAndRemovePools(pID)
			if GM.main != null and GM.main.IS.hasPawn(pID):
				GM.main.IS.deletePawn(pID)
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
func _captureAndRemovePools(npcID: String):
	if GM.main == null:
		return
	var pools = []
	for poolID in GM.main.getDynamicCharactersPools():
		var ids = GM.main.getDynamicCharacterIDsFromPool(poolID)
		if ids.has(npcID):
			pools.append(poolID)
	if pools.size() > 0:
		_originalPools[npcID] = pools
	GM.main.removeDynamicCharacterFromAllPools(npcID)
func tickSeconds(seconds):
	if preyIDs.size() <= 0:
		stop()
		return
	var sec = float(seconds)
	if sec <= 0.0:
		return
	var expired = []
	for pID in preyIDs.duplicate():
		var t = float(timers.get(pID, -1.0))
		if t < 0.0:
			continue
		t -= sec
		timers[pID] = t
		if t <= 0.0:
			expired.append(pID)
	if expired.size() > 0:
		_burst(expired[0])
		return
	if character != null:
		character.updateNonBattleEffects()
func _burst(triggerPreyID: String):
	var predator = character
	var predatorName = "the predator"
	var predatorID = ""
	var predatorWasSlave = false
	if predator != null:
		if predator.has_method("getName"):
			predatorName = predator.getName()
		if predator.has_method("getID"):
			predatorID = predator.getID()
		if predator.has_method("isSlaveToPlayer"):
			predatorWasSlave = predator.isSlaveToPlayer()
	var whoGrew = _nameForID(triggerPreyID)
	if GM.main != null:
		if predatorWasSlave:
			GM.main.addMessage(whoGrew + " suddenly surges back to full size inside your slave " + predatorName + "! There isn't room -- " + predatorName + " is torn apart from the inside and dies as " + whoGrew + " bursts free in your cell.")
		else:
			GM.main.addMessage(whoGrew + " suddenly surges back to full size inside " + predatorName + "! There isn't room -- " + predatorName + " is torn apart from the inside and dies as " + whoGrew + " bursts free.")
	var releaseLoc = _resolveReleaseLocation(predator, predatorWasSlave)
	for pID in preyIDs.duplicate():
		_releasePrey(pID, releaseLoc)
	if GM.main != null and predatorID != "":
		if predatorWasSlave:
			if predator.has_method("setEnslaveQuest"):
				predator.setEnslaveQuest(null)
			if predator.has_method("setNpcSlavery"):
				predator.setNpcSlavery(null)
		if GM.main.IS.hasPawn(predatorID):
			GM.main.IS.deletePawn(predatorID)
		GM.main.removeDynamicCharacterFromAllPools(predatorID)
		if GM.main.dynamicCharacters.has(predatorID):
			GM.main.removeDynamicCharacter(predatorID)
	preyNames.clear()
	preyIDs.clear()
	preyMethods.clear()
	timers.clear()
	_originalPools.clear()
	stop()
func _resolveReleaseLocation(predator, predatorWasSlave: bool) -> String:
	if predatorWasSlave and GM.pc != null and GM.pc.has_method("getCellLocation"):
		var cellLoc = GM.pc.getCellLocation()
		if cellLoc != null and str(cellLoc) != "":
			return str(cellLoc)
	if predator != null and GM.main != null and predator.has_method("getID"):
		var predID = predator.getID()
		if predID != "" and GM.main.IS.hasPawn(predID):
			var predPawn = GM.main.IS.getPawn(predID)
			if predPawn != null:
				var loc = predPawn.getLocation()
				if loc != null and str(loc) != "":
					return str(loc)
	if GM.pc != null:
		return GM.pc.getLocation()
	return ""
func _releasePrey(npcID: String, atLocation: String):
	var preyChar = GlobalRegistry.getCharacter(npcID)
	if preyChar != null and preyChar.hasEffect("VoreSizeChange"):
		preyChar.removeEffect("VoreSizeChange")
	VoreBodyScaleHelper.setNPCPickedUp(npcID, false)
	VoreBodyScaleHelper.removeNPCBodyScale(npcID)
	if preyChar != null:
		VoreBodyScaleHelper.applyNPCBodyScale(preyChar, 1.0)
	var restoredAnyPool = false
	if _originalPools.has(npcID):
		for poolID in _originalPools[npcID]:
			if GM.main.addDynamicCharacterToPool(npcID, poolID):
				restoredAnyPool = true
		_originalPools.erase(npcID)
	if !restoredAnyPool and preyChar != null and preyChar.has_method("getCharacterPool"):
		var defaultPool = preyChar.getCharacterPool()
		if defaultPool != null and str(defaultPool) != "":
			GM.main.addDynamicCharacterToPool(npcID, str(defaultPool))
	if GM.main != null:
		if not GM.main.IS.hasPawn(npcID):
			GM.main.IS.spawnPawn(npcID)
		var pawn = GM.main.IS.getPawn(npcID)
		if pawn != null and atLocation != "":
			pawn.setLocation(atLocation)
func _nameForID(npcID: String) -> String:
	var idx = preyIDs.find(npcID)
	if idx >= 0 and idx < preyNames.size():
		return preyNames[idx]
	var ch = GlobalRegistry.getCharacter(npcID)
	if ch != null and ch.has_method("getName"):
		return ch.getName()
	return "their prey"
func getEffectName():
	return "Live Prey Inside"
func getEffectDesc():
	if preyNames.size() <= 0:
		return "Has a tiny live captive squirming inside them."
	var namesText = Util.join(preyNames, ", ")
	var desc = "Has swallowed " + namesText + " whole while they were shrunk. They are alive inside, not being digested."
	for i in range(preyIDs.size()):
		var pID = preyIDs[i]
		var who = preyNames[i] if i < preyNames.size() else "them"
		var t = float(timers.get(pID, -1.0))
		if t < 0.0:
			desc += "\n\n* " + who + " -- shrunk permanently (harmless; will stay inside until freed another way)."
		else:
			var timeStr = Util.getTimeStringHumanReadable(int(max(t, 0)))
			desc += "\n\n* " + who + " -- shrink wears off in " + timeStr + "."
	desc += "\n\n[b]Warning:[/b] if a captive's shrink wears off while still inside, they grow back and kill the predator, bursting free."
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"
func getIconColor():
	return IconColorCyan
func getBuffs():
	if preyIDs.size() <= 0:
		return []
	return [buff(Buff.InflatedBellyBuff, [60.0 * preyIDs.size()])]
func saveData():
	return {
		"preyNames":   preyNames,
		"preyIDs":     preyIDs,
		"preyMethods": preyMethods,
		"timers":      timers,
		"originalPools": _originalPools,
	}
func loadData(_data):
	preyNames   = SAVE.loadVar(_data, "preyNames",   [])
	preyIDs     = SAVE.loadVar(_data, "preyIDs",     [])
	preyMethods = SAVE.loadVar(_data, "preyMethods", [])
	timers      = SAVE.loadVar(_data, "timers",      {})
	_originalPools = SAVE.loadVar(_data, "originalPools", {})
	while preyMethods.size() < preyIDs.size():
		preyMethods.append("mouth")
	for pID in preyIDs:
		if not timers.has(pID):
			timers[pID] = -1.0
