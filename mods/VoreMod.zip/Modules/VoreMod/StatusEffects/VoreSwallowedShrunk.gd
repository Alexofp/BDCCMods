extends StatusEffectBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
var preyNames: Array = []
var preyIDs: Array = []
var preyMethods: Array = []
var shrinkTimers: Dictionary = {}
func _init():
	id = "VoreSwallowedShrunk"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		var name = str(_args[0])
		if not preyNames.has(name):
			preyNames.append(name)
	if _args.size() > 1:
		var npcID = str(_args[1])
		if npcID != "" and not preyIDs.has(npcID):
			preyIDs.append(npcID)
	if _args.size() > 2:
		var method = str(_args[2])
		if preyMethods.size() < preyIDs.size():
			preyMethods.append(method)
	if _args.size() > 3:
		var dur = float(_args[3])
		if dur > 0:
			if preyIDs.size() > 0:
				shrinkTimers[preyIDs[preyIDs.size() - 1]] = dur
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
	if character != null:
		character.updateNonBattleEffects()
func processTime(_secondsPassed: int):
	if GM.main == null or GM.pc == null:
		return
	var grownPrey = []
	for npcID in shrinkTimers.keys():
		if not preyIDs.has(npcID):
			shrinkTimers.erase(npcID)
			continue
		shrinkTimers[npcID] -= float(_secondsPassed)
		if shrinkTimers[npcID] <= 0.0:
			shrinkTimers[npcID] = 0.0
			grownPrey.append(npcID)
	if grownPrey.size() > 0:
		var npcID = grownPrey[0]
		var idx = preyIDs.find(npcID)
		var preyName = preyNames[idx] if idx >= 0 and idx < preyNames.size() else "someone"
		var voreMethod = preyMethods[idx] if idx >= 0 and idx < preyMethods.size() else "mouth"
		if VoreSwallowed.getEffectForID(GM.pc, npcID) == null:
			_removePrey(npcID)
			if preyIDs.size() <= 0:
				_clearAndStop()
			return
		var npcChar = GlobalRegistry.getCharacter(npcID)
		if npcChar != null:
			npcChar.removeEffect("VoreSizeChange")
			var VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
			VoreBodyScaleHelper.applyNPCBodyScale(npcChar, 1.0)
		GM.main.runScene("VoreGrowthScene", [npcID, preyName, voreMethod])
	if preyIDs.size() <= 0:
		_clearAndStop()
func _removePrey(npcID: String):
	var idx = preyIDs.find(npcID)
	if idx < 0:
		return
	preyIDs.remove(idx)
	if idx < preyNames.size():
		preyNames.remove(idx)
	if idx < preyMethods.size():
		preyMethods.remove(idx)
	shrinkTimers.erase(npcID)
func _clearAndStop():
	preyNames.clear()
	preyIDs.clear()
	preyMethods.clear()
	shrinkTimers.clear()
	stop()
func getEffectName():
	var count = preyIDs.size()
	if count <= 0:
		return "Shrunk Prey Timer"
	return "Shrunk Prey (" + str(count) + ")"
func getEffectDesc():
	if preyIDs.size() <= 0:
		return "You have shrunk prey inside you, but their timers have expired."
	var desc = "You have swallowed prey that are still shrunk. If they grow back to normal size while inside you, they will burst out!\n"
	for i in range(preyIDs.size()):
		var who = preyNames[i] if i < preyNames.size() else "someone"
		var npcID = preyIDs[i]
		var method = preyMethods[i] if i < preyMethods.size() else "mouth"
		var remaining = shrinkTimers.get(npcID, 0.0)
		var timeStr = Util.getTimeStringHumanReadable(int(max(remaining, 0)))
		desc += "\n* " + who + " (" + method + ") -- shrink wears off in " + timeStr
	desc += "\n\n[b]Warning:[/b] If a shrunk prey grows back while still inside you, it will kill you!"
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/Invigoration.png"
func getIconColor():
	return IconColorCyan
func getBuffs():
	return []
func saveData():
	var data = .saveData()
	data["preyNames"] = preyNames
	data["preyIDs"] = preyIDs
	data["preyMethods"] = preyMethods
	data["shrinkTimers"] = shrinkTimers
	return data
func loadData(_data):
	preyNames = SAVE.loadVar(_data, "preyNames", [])
	preyIDs = SAVE.loadVar(_data, "preyIDs", [])
	preyMethods = SAVE.loadVar(_data, "preyMethods", [])
	shrinkTimers = SAVE.loadVar(_data, "shrinkTimers", {})
