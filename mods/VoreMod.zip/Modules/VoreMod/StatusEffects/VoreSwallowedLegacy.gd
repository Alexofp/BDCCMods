extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
var _legacyData = null
var _migrated   = false
func _init():
	id = "VoreSwallowedNPC"
	isBattleOnly = false
func getVoreMethod() -> String:
	return "mouth"
func loadData(_data):
	_legacyData = _data
	.loadData(_data)
func processTime(_secondsPassed: int):
	_doMigrate()
func onSleeping():
	_doMigrate()
func _doMigrate():
	if _migrated:
		return
	_migrated = true
	if character == null:
		stop()
		return
	var ids          = swallowedIDs.duplicate()
	var names        = swallowedNames.duplicate()
	var methods      = swallowedMethods.duplicate()
	var stages       = digestionStages.duplicate()
	var tamed        = tamedNPCs.duplicate()
	var broken       = brokenNPCs.duplicate()
	var pausedNights = digestionPausedNights
	var oldData          = _legacyData if _legacyData != null else {}
	var wasBallsEnlarged = SAVE.loadVar(oldData, "cockBallsEnlarged",  false)
	var ballsOrigScale   = SAVE.loadVar(oldData, "cockBallsOrigScale", 1.0)
	if wasBallsEnlarged:
		var penis = character.getBodypart(BodypartSlot.Penis)
		if penis != null:
			penis.ballsScale = ballsOrigScale
			penis.updateAppearance()
	swallowedIDs.clear()
	swallowedNames.clear()
	swallowedMethods.clear()
	digestionStages.clear()
	escapeTimers.clear()
	tamedNPCs.clear()
	brokenNPCs.clear()
	_pendingEscapeID = ""
	_pendingCleanup.clear()
	for i in range(ids.size()):
		var npcID  = ids[i]
		var who    = names[i]   if i < names.size()   else "your prey"
		var method = methods[i] if i < methods.size() else "mouth"
		var newID  = VoreSwallowed.effectIDForMethod(method)
		character.addEffect(newID, [who, npcID, method])
		var ne = character.getEffect(newID)
		if ne != null:
			if stages.has(npcID):
				ne.digestionStages[npcID] = int(stages[npcID])
			if tamed.has(npcID) and not ne.tamedNPCs.has(npcID):
				ne.tamedNPCs.append(npcID)
				ne.escapeTimers.erase(npcID)
			if broken.has(npcID) and not ne.brokenNPCs.has(npcID):
				ne.brokenNPCs.append(npcID)
				ne.escapeTimers.erase(npcID)
			if pausedNights > 0:
				ne.digestionPausedNights = max(ne.digestionPausedNights, pausedNights)
	if character != null:
		character.updateNonBattleEffects()
	stop()
func getBuffs():
	if _migrated:
		return []
	return .getBuffs()