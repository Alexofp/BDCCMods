extends StatusEffectBase
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var targetScale: float = 1.0
var durationSeconds: int = 3600
func _init():
	id = "VoreSizeChange"
	isBattleOnly = false
func setCharacter(c):
	.setCharacter(c)
	_connectBodypartSignal()
func initArgs(_args = []):
	if _args.size() > 0:
		targetScale = clamp(float(_args[0]), VoreBodyScaleHelper.MIN_SCALE, VoreBodyScaleHelper.MAX_SCALE)
	if _args.size() > 1:
		durationSeconds = int(_args[1])
		if durationSeconds < 0:
			durationSeconds = -1
		elif durationSeconds < 60:
			durationSeconds = 60
	_applyScaleToCharacter()
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	if _args.size() > 0:
		targetScale = clamp(float(_args[0]), VoreBodyScaleHelper.MIN_SCALE, VoreBodyScaleHelper.MAX_SCALE)
	if _args.size() > 1:
		durationSeconds = int(_args[1])
		if durationSeconds < 0:
			durationSeconds = -1
		elif durationSeconds < 60:
			durationSeconds = 60
	_applyScaleToCharacter()
	if character != null:
		character.updateNonBattleEffects()
func isPermanent() -> bool:
	return durationSeconds < 0
func processTime(_secondsPassed: int):
	if durationSeconds < 0:
		if character != null && !character.isPlayer():
			VoreBodyScaleHelper._applyNPCDollScale(character, targetScale)
		if character != null:
			character.updateNonBattleEffects()
		return
	durationSeconds -= _secondsPassed
	if durationSeconds <= 0:
		durationSeconds = 0
		stop()
		return
	if character != null && !character.isPlayer():
		VoreBodyScaleHelper._applyNPCDollScale(character, targetScale)
	if character != null:
		character.updateNonBattleEffects()
func _connectBodypartSignal():
	if character == null || character.isPlayer():
		return
	if !character.is_connected("bodypart_changed", self, "_onNPCBodypartChanged"):
		character.connect("bodypart_changed", self, "_onNPCBodypartChanged")
func _disconnectBodypartSignal():
	if character == null || character.isPlayer():
		return
	if character.is_connected("bodypart_changed", self, "_onNPCBodypartChanged"):
		character.disconnect("bodypart_changed", self, "_onNPCBodypartChanged")
func _onNPCBodypartChanged():
	call_deferred("_deferredApplyNPCScale")
func _deferredApplyNPCScale():
	if character != null && !character.isPlayer():
		VoreBodyScaleHelper._applyNPCDollScale(character, targetScale)
func _applyScaleToCharacter():
	if character == null:
		return
	if character.isPlayer():
		VoreBodyScaleHelper.setPCBodyScale(targetScale)
	else:
		VoreBodyScaleHelper.applyNPCBodyScale(character, targetScale)
func _revertScale():
	if character == null:
		return
	if character.isPlayer():
		VoreBodyScaleHelper.setPCBodyScale(1.0)
	else:
		var npcID = character.getID() if character.has_method("getID") else ""
		if npcID != "":
			VoreBodyScaleHelper.setNPCBodyScale(npcID, 1.0)
		else:
			VoreBodyScaleHelper.applyNPCBodyScale(character, 1.0)
func getEffectName():
	var scaleStr = str(stepify(targetScale, 0.01))
	if targetScale < 1.0:
		return "Shrunk (" + scaleStr + "x)"
	elif targetScale > 1.0:
		return "Enlarged (" + scaleStr + "x)"
	else:
		return "Normal Size"
func getEffectDesc():
	var scaleStr = str(stepify(targetScale, 0.01))
	var timeStr = Util.getTimeStringHumanReadable(durationSeconds)
	var desc = ""
	if targetScale < 1.0:
		desc = "Your body has been shrunk to " + scaleStr + "x its normal size. "
	elif targetScale > 1.0:
		desc = "Your body has been enlarged to " + scaleStr + "x its normal size. "
	else:
		desc = "Your body is at its normal size. "
	if durationSeconds < 0:
		desc += "This size change is [b]permanent[/b] and will only end if changed by another size-change pill."
	else:
		desc += "The effect will wear off in " + timeStr + ", returning you to your natural proportions."
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/Invigoration.png"
func getIconColor():
	if targetScale < 1.0:
		return IconColorCyan
	elif targetScale > 1.0:
		return IconColorRed
	return IconColorGreen
func stop():
	_disconnectBodypartSignal()
	_revertScale()
	if character != null:
		character.updateNonBattleEffects()
	.stop()
func saveData():
	var data = .saveData()
	data["targetScale"] = targetScale
	data["durationSeconds"] = durationSeconds
	return data
func loadData(data):
	.loadData(data)
	targetScale = SAVE.loadVar(data, "targetScale", 1.0)
	durationSeconds = SAVE.loadVar(data, "durationSeconds", 3600)
	_connectBodypartSignal()
