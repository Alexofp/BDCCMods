extends StatusEffectBase
const SECONDS_PER_STAGE = 4 * 60 * 60
var predName = "someone"
var voreMethod = "mouth"
var stageReached = 1
var secondsLeft = SECONDS_PER_STAGE
func _init():
	id = "VorePreyAftermath"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		predName = str(_args[0])
	if _args.size() > 1:
		voreMethod = str(_args[1])
	if _args.size() > 2:
		stageReached = int(max(1, int(_args[2])))
	secondsLeft = SECONDS_PER_STAGE * int(clamp(stageReached, 1, 6))
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	var newStage = stageReached
	if _args.size() > 2:
		newStage = int(max(1, int(_args[2])))
	if newStage >= stageReached:
		initArgs(_args)
		return
	secondsLeft = max(secondsLeft, SECONDS_PER_STAGE * int(clamp(newStage, 1, 6)))
	if character != null:
		character.updateNonBattleEffects()
func processTime(_secondsPassed: int):
	secondsLeft -= _secondsPassed
	if secondsLeft <= 0:
		secondsLeft = 0
		stop()
		return
	if character != null:
		character.updateNonBattleEffects()
func _fluidWord() -> String:
	match voreMethod:
		"mouth":   return "stomach acid"
		"breasts": return "milk"
		"anus":    return "slick"
		"cock":    return "cum"
		"vagina":  return "fluids"
		"tail":    return "slime"
	return "slick"
func _severity() -> int:
	var maxSeconds = float(SECONDS_PER_STAGE * int(clamp(stageReached, 1, 6)))
	if maxSeconds <= 0.0:
		return 1
	var frac = clamp(float(secondsLeft) / maxSeconds, 0.0, 1.0)
	return int(max(1, round(stageReached * frac)))
func getEffectName():
	return "Digestion Aftermath"
func getEffectDesc():
	var sev = _severity()
	var desc = "You were inside " + predName + " long enough for it to leave a mark. Your skin is raw, your muscles will not answer properly and you are still dripping with " + _fluidWord() + "."
	desc += "\n\nDamage taken: stage " + str(stageReached) + " of digestion. Current severity: " + str(sev) + "."
	desc += "\nWears off in " + Util.getTimeStringHumanReadable(secondsLeft) + ", getting weaker as you recover."
	if stageReached >= 4:
		desc += "\n\n[color=#ff5555]You very nearly died in there. Your body is a wreck.[/color]"
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"
func getIconColor():
	return IconColorRed
func getBuffs():
	var sev = _severity()
	return [
		buff(Buff.MaxStaminaBuff,             [-int(min(sev * 8, 50))]),
		buff(Buff.PhysicalDamageBuff,         [-int(min(sev * 5, 30))]),
		buff(Buff.AccuracyBuff,               [-int(min(sev * 4, 25))]),
		buff(Buff.DodgeChanceBuff,            [-int(min(sev * 4, 25))]),
		buff(Buff.ReceivedPhysicalDamageBuff, [int(min(sev * 6, 40))]),
		buff(Buff.AmbientPainBuff,            [int(min(sev * 2, 12))]),
	]
func saveData():
	return {
		"predName": predName,
		"voreMethod": voreMethod,
		"stageReached": stageReached,
		"secondsLeft": secondsLeft,
	}
func loadData(_data):
	predName = SAVE.loadVar(_data, "predName", "someone")
	voreMethod = SAVE.loadVar(_data, "voreMethod", "mouth")
	stageReached = SAVE.loadVar(_data, "stageReached", 1)
	secondsLeft = SAVE.loadVar(_data, "secondsLeft", SECONDS_PER_STAGE)
