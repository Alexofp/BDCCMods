extends StatusEffectBase
const MAX_STACKS     = 5
const DAYS_PER_STACK = 2
var stacks     = 1
var nightsLeft = DAYS_PER_STACK
func _init():
	id = "VoreWellFed"
	isBattleOnly = false
func initArgs(_args = []):
	var add = 1
	if _args.size() > 0:
		add = int(_args[0])
	stacks = clamp(add, 1, MAX_STACKS)
	nightsLeft = DAYS_PER_STACK
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	var add = 1
	if _args.size() > 0:
		add = int(_args[0])
	stacks = int(min(stacks + add, MAX_STACKS))
	nightsLeft = DAYS_PER_STACK
	if character != null:
		character.updateNonBattleEffects()
func getEffectName():
	return "Predator's Vigor (x" + str(stacks) + ")"
func getEffectDesc():
	return ("The rich nourishment of digested prey courses through you. You feel powerful, "
		+ "tougher and full of energy. Digest more prey to deepen the rush; it fades after a "
		+ "few nights without a fresh meal. (" + str(stacks) + "/" + str(MAX_STACKS)
		+ " stacks, " + str(nightsLeft) + " night(s) until a stack fades)")
func getEffectImage():
	return "res://Images/StatusEffects/Invigoration.png"
func getIconColor():
	return IconColorYellow
func getBuffs():
	if stacks <= 0:
		return []
	return [
		buff(Buff.PhysicalDamageBuff,         [6 * stacks]),
		buff(Buff.MeleeDamageBuff,            [6 * stacks]),
		buff(Buff.MaxPainBuff,                [6 * stacks]),
		buff(Buff.MaxStaminaBuff,             [8 * stacks]),
		buff(Buff.DodgeChanceBuff,            [3 * stacks]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-4 * stacks]),
	]
func onSleeping():
	nightsLeft -= 1
	if nightsLeft <= 0:
		stacks -= 1
		nightsLeft = DAYS_PER_STACK
		if stacks <= 0:
			stop()
			return
	if character != null:
		character.updateNonBattleEffects()
func saveData():
	return {
		"stacks":     stacks,
		"nightsLeft": nightsLeft,
	}
func loadData(_data):
	stacks     = SAVE.loadVar(_data, "stacks", 1)
	nightsLeft = SAVE.loadVar(_data, "nightsLeft", DAYS_PER_STACK)
