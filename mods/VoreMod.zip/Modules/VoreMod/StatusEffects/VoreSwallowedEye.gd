extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const STAGE_DESC = [
	"has just been pulled through your pupil, their tiny form squirming behind your eye.",
	"is struggling inside your ocular cavity, your body working to contain them.",
	"is losing strength -- the pressure behind your eye slowly winning.",
	"is beginning to break down, warmth spreading through your head.",
	"is deep in your ocular cavity, your body thickening with every hour.",
	"is nearly fully processed -- you can feel them becoming part of you.",
]
const SLEEP_MSG = [
	"You fall asleep with a dull pressure behind your eye. {who} has not given up yet.",
	"Another night of ocular digestion. {who} is still fighting, but your body is relentless.",
	"You wake slightly heavier. {who}'s resistance is breaking down inside your eye socket.",
	"{who} is beginning to dissolve properly now. You can feel your body thickening from within.",
	"A long, satisfying night. {who} is deep in your ocular cavity, your curves filling out as they dissolve.",
	"Almost done. {who} is nearly fully processed -- one more night will finish what your body started.",
]
const SLEEP_MSG_FINAL = "You wake noticeably thicker. {who} was fully processed overnight -- absorbed through your eye, every last bit of them now part of your curves."
func _init():
	id = "VoreSwallowedEye"
	isBattleOnly = false
func getVoreMethod() -> String:    return "eye"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreEyeEndosoma"
func _countsTowardBelly() -> bool:
	return false
func _applyPartialEffect(stage: int):
	var add = 1 + int(stage >= 3)
	var cur = GM.pc.getThickness()
	GM.pc.setThickness(int(min(cur + add, 150)))
func _applyFinalEffect():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 8, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Complete ocular digestion. You have become noticeably thicker -- every curve fuller than before. Thickness: " + str(newVal) + "%"
	)
func getEffectName():
	return "Full Eye"
func getEffectDesc():
	var desc = .getEffectDesc()
	return desc.replace("Full Belly", "Full Eye")