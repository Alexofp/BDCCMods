extends StatusEffectBase


const STAGE_COUNT = 6
const FINAL_STAGE = 6

const STAGE_NAMES = [
	"Swallowed",
	"Struggling",
	"Weakening",
	"Softening",
	"Dissolving",
	"Nearly Absorbed",
]

const ESCAPE_MAX_STAGE = 2


const STAGE_DESC_MOUTH = [
	"is alive and squirming inside your stomach, desperately trying to escape.",
	"is fighting hard against your stomach walls, but going nowhere.",
	"is growing weaker — their struggles are slowing down.",
	"is beginning to soften, your acids finally breaking them down.",
	"is rapidly dissolving, your belly gurgling with each movement.",
	"has been almost entirely absorbed — only traces remain.",
]

const STAGE_DESC_BREASTS = [
	"is being drawn into your breast tissue, still resisting the pull.",
	"is struggling against the absorption, their energy fighting your body.",
	"is losing the fight — the conversion process is taking hold.",
	"has begun to convert into fluid, your chest warming noticeably.",
	"is dissolving into rich milk, your breasts visibly swelling.",
	"is nearly fully converted — your breasts ache with fullness.",
]

const STAGE_DESC_ANUS = [
	"has just been pulled inside, squirming uncomfortably in your gut.",
	"is struggling inside you, your body working to contain them.",
	"is losing strength — your digestive tract slowly winning.",
	"is beginning to break down, adding warmth and weight to your body.",
	"is deep in your tract, your body thickening with every hour.",
	"is nearly fully processed — you can feel them becoming part of you.",
]


const SLEEP_MSG_MOUTH = [
	"You drift off with a full, gurgling belly. Inside, {who} squirms restlessly but can't escape your stomach.",
	"As you sleep, you can faintly feel {who} still fighting inside you. Their struggles are slowly weakening.",
	"{who}'s resistance is fading. You wake feeling your stomach acids have begun their work in earnest.",
	"You wake to a warm, heavy feeling in your gut. {who} is softening — the digestion is well underway.",
	"A night of deep, satisfied sleep. Your belly gurgles loudly as {who} rapidly dissolves within you.",
	"You wake feeling fuller than ever. {who} is almost entirely part of you now — one more rest and it will be complete.",
]

const SLEEP_MSG_MOUTH_FINAL = "{who} has been fully digested overnight. You feel their essence become a permanent part of you — warm, nourishing, complete."

const SLEEP_MSG_BREASTS = [
	"You rest with a warm pressure in your chest. {who} is being slowly drawn into your breast tissue.",
	"Another night passes. {who} is still resisting the conversion, but your body is patient.",
	"You wake feeling your chest is warmer than usual. {who}'s energy is fading into the absorption.",
	"The conversion of {who} has truly begun. You wake with a modest but noticeable fullness in your breasts.",
	"You sleep deeply as {who} rapidly converts to fluid within you. Your breasts swell noticeably.",
	"Almost there. {who} is nearly all milk now — one more night and the conversion will be complete.",
]

const SLEEP_MSG_BREASTS_FINAL = "You wake to find {who} has been fully converted overnight. Your breasts are heavy, aching, and overflowing with the results."

const SLEEP_MSG_ANUS = [
	"You fall asleep with a dense, uncomfortable fullness in your gut. {who} has not given up yet.",
	"Another night of digestion. {who} is still fighting, but your body is relentless.",
	"You wake slightly heavier. {who}'s resistance is breaking down inside your digestive tract.",
	"{who} is beginning to dissolve properly now. You can feel your body thickening from the inside.",
	"A long, satisfying night. {who} is deep in your tract, your curves filling out as they dissolve.",
	"Almost done. {who} is nearly fully processed — one more night will finish what your body started.",
]

const SLEEP_MSG_ANUS_FINAL = "You wake noticeably thicker. {who} was fully processed overnight — thoroughly absorbed, every last bit of them now part of your curves."

var swallowedNames   = []
var swallowedIDs     = []
var swallowedMethods = []
var _pendingCleanup  = []

var digestionStages  = {}

var escapeTimers     = {}
var tamedNPCs        = []
var brokenNPCs       = []
var _pendingEscapeID = ""

var digestionPausedNights = 0

const ESCAPE_TIMER_MIN     = 300
const ESCAPE_TIMER_MAX     = 1800
const ESCAPE_INITIAL_DELAY = 120

func _init():
	id = "VoreSwallowedNPC"
	isBattleOnly = false

func getDigestionStage(npcID: String) -> int:
	return int(digestionStages.get(npcID, 0))

func getDigestionProgress(npcID: String) -> float:
	var stage = getDigestionStage(npcID)
	return clamp(float(stage) / float(STAGE_COUNT), 0.0, 1.0)

func initArgs(_args = []):
	var voreMethod = "mouth"

	if _args.size() > 0:
		var n = str(_args[0])
		if not swallowedNames.has(n):
			swallowedNames.append(n)

	if _args.size() > 1:
		var npcID = str(_args[1])
		if npcID != "" and not swallowedIDs.has(npcID):
			swallowedIDs.append(npcID)
			_pendingCleanup.append(npcID)
			digestionStages[npcID] = 0
			escapeTimers[npcID] = float(ESCAPE_INITIAL_DELAY) + RNG.randf_range(ESCAPE_TIMER_MIN, ESCAPE_TIMER_MAX)

	if _args.size() > 2:
		voreMethod = str(_args[2])

	if swallowedMethods.size() < swallowedIDs.size():
		swallowedMethods.append(voreMethod)

	if character != null:
		character.updateNonBattleEffects()

func combine(_args = []):
	initArgs(_args)
	if character != null:
		character.updateNonBattleEffects()

func hasPendingEscape() -> bool:
	return _pendingEscapeID != ""

func getPendingEscapeID() -> String:
	return _pendingEscapeID

func clearPendingEscape():
	_pendingEscapeID = ""

func onNPCTamed(npcID: String):
	if not tamedNPCs.has(npcID):
		tamedNPCs.append(npcID)
	escapeTimers.erase(npcID)
	clearPendingEscape()

func onNPCCalmed(npcID: String):
	clearPendingEscape()
	if canStillEscape(npcID):
		escapeTimers[npcID] = RNG.randf_range(ESCAPE_TIMER_MAX, ESCAPE_TIMER_MAX * 2.0)
	else:
		escapeTimers.erase(npcID)

func canStillEscape(npcID: String) -> bool:
	if not swallowedIDs.has(npcID):
		return false
	if brokenNPCs.has(npcID) or tamedNPCs.has(npcID):
		return false
	return getDigestionStage(npcID) <= ESCAPE_MAX_STAGE

func getSwallowMethodForID(npcID: String) -> String:
	var idx = swallowedIDs.find(npcID)
	if idx >= 0 and idx < swallowedMethods.size():
		return swallowedMethods[idx]
	return "mouth"

func getNameForID(npcID: String) -> String:
	var idx = swallowedIDs.find(npcID)
	if idx >= 0 and idx < swallowedNames.size():
		return swallowedNames[idx]
	return "your prey"

func onNPCEscaped(npcID: String):
	var idx = swallowedIDs.find(npcID)
	if idx >= 0:
		swallowedIDs.remove(idx)
		if idx < swallowedNames.size():
			swallowedNames.remove(idx)
		if idx < swallowedMethods.size():
			swallowedMethods.remove(idx)

	escapeTimers.erase(npcID)
	digestionStages.erase(npcID)
	_pendingCleanup.erase(npcID)
	clearPendingEscape()

	if GM.main != null:
		if not GM.main.IS.hasPawn(npcID):
			GM.main.IS.spawnPawn(npcID)
		var escapedPawn = GM.main.IS.getPawn(npcID)
		if escapedPawn != null and GM.pc != null:
			escapedPawn.setLocation(GM.pc.getLocation())

	if swallowedIDs.size() <= 0:
		swallowedNames.clear()
		swallowedMethods.clear()
		stop()
		return

	if character != null:
		character.updateNonBattleEffects()

func markBroken(npcID: String):
	if not brokenNPCs.has(npcID):
		brokenNPCs.append(npcID)
	escapeTimers.erase(npcID)

func releaseNPC(npcID: String):
	onNPCEscaped(npcID)

func pauseDigestion(nights: int = 1) -> String:
	if swallowedIDs.size() <= 0:
		return "Nothing happens - there is no one inside you to keep from digesting."
	digestionPausedNights = max(digestionPausedNights, nights)
	if character != null:
		character.updateNonBattleEffects()
	return "Your gut goes still. Digestion is halted for the next day - sleep will not break down your prey until then."

func accelerateDigestion() -> String:
	if swallowedIDs.size() <= 0:
		return "Nothing happens - there is no one inside you to digest."
	if GM.pc == null:
		return "Nothing happens."

	var advanced = 0
	for i in range(swallowedIDs.size()):
		var npcID = swallowedIDs[i]
		var stage = getDigestionStage(npcID)
		if stage < STAGE_COUNT:
			var m = swallowedMethods[i] if i < swallowedMethods.size() else "mouth"
			digestionStages[npcID] = stage + 1
			_applyPartialEffect(m, stage)
			GM.pc.addSkillExperience("Vore", 10 + stage * 5)
			advanced += 1

	for escNpcID in escapeTimers.keys():
		if getDigestionStage(escNpcID) > ESCAPE_MAX_STAGE:
			escapeTimers.erase(escNpcID)
	if _pendingEscapeID != "" and not canStillEscape(_pendingEscapeID):
		clearPendingEscape()

	if character != null:
		character.updateNonBattleEffects()

	if advanced <= 0:
		return "Everyone inside you is already fully softened - sleep to finish digesting them."
	return "A churning heat floods through you. Digestion lurches forward - your prey is broken down a full stage faster."

func _getBellyCount() -> int:
	var count = 0
	for m in swallowedMethods:
		if m == "mouth" or m == "anus":
			count += 1
	return count

func _getCountByMethod(method: String) -> int:
	var count = 0
	for m in swallowedMethods:
		if m == method:
			count += 1
	return count

func _progressBar(progress: float) -> String:
	var filled = int(round(progress * 10.0))
	var bar = "["
	for i in range(10):
		bar += "█" if i < filled else "░"
	bar += "]"
	return bar

func getEffectName():
	return "Full Belly"

func getEffectDesc():
	if swallowedNames.size() <= 0:
		return "You have someone inside you."

	var namesText = Util.join(swallowedNames, ", ")

	var readyCount = 0
	for npcID in swallowedIDs:
		if getDigestionStage(npcID) >= STAGE_COUNT:
			readyCount += 1

	var desc = ""
	if readyCount > 0:
		desc = "You have " + namesText + " inside you. Some are nearly fully digested — sleep to finish them."
	else:
		desc = "You have " + namesText + " inside you. They will be digested over several nights."

	for i in range(swallowedIDs.size()):
		var m        = swallowedMethods[i] if i < swallowedMethods.size() else "mouth"
		var who      = swallowedNames[i]   if i < swallowedNames.size()   else "them"
		var npcID    = swallowedIDs[i]
		var stage    = getDigestionStage(npcID)
		var progress = getDigestionProgress(npcID)
		var stageIdx = clamp(stage, 0, STAGE_COUNT - 1)

		var stageName  = STAGE_NAMES[stageIdx]
		var stageDesc  = ""
		match m:
			"mouth":   stageDesc = STAGE_DESC_MOUTH[stageIdx]
			"breasts": stageDesc = STAGE_DESC_BREASTS[stageIdx]
			"anus":    stageDesc = STAGE_DESC_ANUS[stageIdx]

		var extraNote = ""
		if brokenNPCs.has(npcID):
			extraNote = " [broken]"
		elif tamedNPCs.has(npcID):
			extraNote = " [tamed]"

		var nightsLeft = STAGE_COUNT - stage
		var nightsStr  = str(nightsLeft) + (" night" if nightsLeft == 1 else " nights")

		desc += "\n\n* " + who + extraNote + "  (" + m + ")"
		desc += "\n  Day " + str(stage + 1) + " of " + str(STAGE_COUNT) + "  -  " + stageName + "  " + _progressBar(progress)
		desc += "\n  " + who + " " + stageDesc

		if stage >= STAGE_COUNT - 1:
			desc += "\n  [Fully ready - sleep to complete digestion!]"
		else:
			desc += "\n  [~" + nightsStr + " remaining]"

	var bellyCount = _getBellyCount()
	if bellyCount == 1:
		desc += "\n\nYour belly is noticeably inflated."
	elif bellyCount == 2:
		desc += "\n\nYour belly is heavily distended and quite large."
	elif bellyCount >= 3:
		desc += "\n\nYour belly is massively inflated, looking grotesquely swollen!"

	return desc

func getEffectImage():
	var bellyCount = _getBellyCount()
	if bellyCount >= 2:
		return "res://Images/StatusEffects/bloating.png"
	elif bellyCount >= 1:
		return "res://Images/StatusEffects/belly.png"
	return "res://Images/StatusEffects/lactation.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	if swallowedIDs.size() <= 0:
		return []
	var result     = []
	var bellyCount = _getBellyCount()
	if bellyCount > 0:
		result.append(buff(Buff.InflatedBellyBuff, [40.0 * bellyCount]))
	return result

func processTime(_secondsPassed: int):
	if GM.main == null:
		return

	var cleaned = []
	for npcID in _pendingCleanup:
		if GM.main.isCharIDFighting(npcID):
			continue
		if GM.main.IS.hasPawn(npcID):
			GM.main.IS.deletePawn(npcID)
		cleaned.append(npcID)
	for npcID in cleaned:
		_pendingCleanup.erase(npcID)

	if _pendingEscapeID != "":
		return

	var toEscape = ""
	for npcID in escapeTimers.keys():
		if not swallowedIDs.has(npcID):
			escapeTimers.erase(npcID)
			continue
		if brokenNPCs.has(npcID) or tamedNPCs.has(npcID):
			escapeTimers.erase(npcID)
			continue
		if getDigestionStage(npcID) > ESCAPE_MAX_STAGE:
			escapeTimers.erase(npcID)
			continue

		escapeTimers[npcID] -= float(_secondsPassed)
		if escapeTimers[npcID] <= 0.0:
			toEscape = npcID
			break

	if toEscape != "":
		_pendingEscapeID = toEscape

func onSleeping():
	var accelEvent = GlobalRegistry.getEvent("VorePregAccelerationEvent")
	if accelEvent != null:
		accelEvent.accelerate()

	if GM.pc == null or GM.main == null:
		return

	if digestionPausedNights > 0:
		digestionPausedNights -= 1
		if swallowedIDs.size() > 0:
			GM.main.addMessage("The anti-digestion pill keeps working - nobody inside you is digested tonight.")
		if character != null:
			character.updateNonBattleEffects()
		return

	var toDigest  = []
	var toAdvance = []

	for i in range(swallowedIDs.size()):
		var npcID = swallowedIDs[i]
		if getDigestionStage(npcID) >= STAGE_COUNT:
			toDigest.append(i)
		else:
			toAdvance.append(i)

	for i in toAdvance:
		var npcID = swallowedIDs[i]
		var m     = swallowedMethods[i] if i < swallowedMethods.size() else "mouth"
		var who   = swallowedNames[i]   if i < swallowedNames.size()   else "them"
		var stage = getDigestionStage(npcID)

		digestionStages[npcID] = stage + 1

		var sleepMsg = _getSleepMessage(stage, m, who)
		GM.main.addMessage(sleepMsg)

		var partialExp = 10 + stage * 5
		GM.pc.addSkillExperience("Vore", partialExp)
		GM.main.addMessage(
			"Digestion progresses... +" + str(partialExp) + " Vore XP  [Stage "
			+ str(stage + 1) + "/" + str(STAGE_COUNT) + "]"
		)

		_applyPartialEffect(m, stage)

	for escNpcID in escapeTimers.keys():
		if getDigestionStage(escNpcID) > ESCAPE_MAX_STAGE:
			escapeTimers.erase(escNpcID)
	if _pendingEscapeID != "" and not canStillEscape(_pendingEscapeID):
		clearPendingEscape()

	toDigest.sort()
	toDigest.invert()

	for i in toDigest:
		var npcID = swallowedIDs[i]
		var m     = swallowedMethods[i] if i < swallowedMethods.size() else "mouth"
		var who   = swallowedNames[i]   if i < swallowedNames.size()   else "them"

		GM.main.addMessage(_getFinalMessage(m, who))

		GM.pc.addSkillExperience("Vore", 100)
		GM.main.addMessage("Fully digested! +100 Vore XP")

		match m:
			"mouth":   _applyMouthFinal()
			"breasts": _applyBreastsFinal()
			"anus":    _applyAnusFinal()

		GM.pc.addEffect("VoreWellFed", [1])

		if GM.main.IS.hasPawn(npcID):
			GM.main.IS.deletePawn(npcID)
		if GM.main.dynamicCharacters.has(npcID):
			GM.main.removeDynamicCharacter(npcID)

		swallowedIDs.remove(i)
		if i < swallowedNames.size():
			swallowedNames.remove(i)
		if i < swallowedMethods.size():
			swallowedMethods.remove(i)
		digestionStages.erase(npcID)
		escapeTimers.erase(npcID)
		_pendingCleanup.erase(npcID)

	if swallowedIDs.size() <= 0:
		swallowedNames.clear()
		swallowedMethods.clear()
		digestionStages.clear()
		escapeTimers.clear()
		_pendingCleanup.clear()
		tamedNPCs.clear()
		brokenNPCs.clear()
		_pendingEscapeID = ""
		stop()
	elif character != null:
		character.updateNonBattleEffects()


func _getSleepMessage(stage: int, method: String, who: String) -> String:
	var s        = clamp(stage, 0, STAGE_COUNT - 1)
	var template = ""
	match method:
		"mouth":   template = SLEEP_MSG_MOUTH[s]
		"breasts": template = SLEEP_MSG_BREASTS[s]
		"anus":    template = SLEEP_MSG_ANUS[s]
	return template.replace("{who}", who)

func _getFinalMessage(method: String, who: String) -> String:
	var template = ""
	match method:
		"mouth":   template = SLEEP_MSG_MOUTH_FINAL
		"breasts": template = SLEEP_MSG_BREASTS_FINAL
		"anus":    template = SLEEP_MSG_ANUS_FINAL
	return template.replace("{who}", who)

func _applyPartialEffect(method: String, stage: int):
	match method:
		"mouth":
			var cur = GM.pc.getThickness()
			GM.pc.setThickness(int(min(cur + 1, 150)))
		"breasts":
			var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
			if breasts != null:
				var traits = breasts.getTraits()
				if not traits.has(PartTrait.BreastsMale):
					breasts.induceLactation()
					var fp = breasts.getFluidProduction()
					if fp != null:
						fp.fillPercent(0.15)
		"anus":
			var add = 1 + int(stage >= 3)
			var cur = GM.pc.getThickness()
			GM.pc.setThickness(int(min(cur + add, 150)))

func _applyMouthFinal():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 5, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Your body has fully absorbed every last nutrient. You feel warm and satisfied. Thickness: " + str(newVal) + "%"
	)

func _applyBreastsFinal():
	var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
	if breasts == null:
		GM.main.addMessage("The final remnants dissolve harmlessly — you have no breasts to receive them.")
		return
	var traits = breasts.getTraits()
	if traits.has(PartTrait.BreastsMale):
		var cur = GM.pc.getThickness()
		GM.pc.setThickness(int(min(cur + 5, 150)))
		GM.main.addMessage("The last of the conversion floods into raw muscle mass. Your chest feels iron-dense.")
		return
	breasts.induceLactation()
	var fp = breasts.getFluidProduction()
	if fp != null:
		fp.fillPercent(1.0)
	GM.main.addMessage(
		"Complete conversion achieved. Your breasts are completely overflowing — heavy, warm, and full to capacity."
	)

func _applyAnusFinal():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 8, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Complete digestion. You have become noticeably thicker — every curve fuller than before. Thickness: " + str(newVal) + "%"
	)

func saveData():
	return {
		"swallowedNames":   swallowedNames,
		"swallowedIDs":     swallowedIDs,
		"swallowedMethods": swallowedMethods,
		"tamedNPCs":        tamedNPCs,
		"brokenNPCs":       brokenNPCs,
		"escapeTimers":     escapeTimers,
		"digestionStages":  digestionStages,
		"pendingEscapeID":  _pendingEscapeID,
		"digestionPausedNights": digestionPausedNights,
	}

func loadData(_data):
	swallowedNames   = SAVE.loadVar(_data, "swallowedNames",   [])
	swallowedIDs     = SAVE.loadVar(_data, "swallowedIDs",     [])
	swallowedMethods = SAVE.loadVar(_data, "swallowedMethods", [])
	tamedNPCs        = SAVE.loadVar(_data, "tamedNPCs",        [])
	brokenNPCs       = SAVE.loadVar(_data, "brokenNPCs",       [])
	escapeTimers     = SAVE.loadVar(_data, "escapeTimers",     {})
	digestionStages  = SAVE.loadVar(_data, "digestionStages",  {})
	_pendingEscapeID = SAVE.loadVar(_data, "pendingEscapeID",  "")
	digestionPausedNights = SAVE.loadVar(_data, "digestionPausedNights", 0)
	_pendingCleanup  = swallowedIDs.duplicate()

	while swallowedMethods.size() < swallowedIDs.size():
		swallowedMethods.append("mouth")

	for npcID in swallowedIDs:
		if not digestionStages.has(npcID):
			digestionStages[npcID] = 0
