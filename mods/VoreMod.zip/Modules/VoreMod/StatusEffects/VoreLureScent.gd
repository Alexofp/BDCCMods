extends StatusEffectBase
var secondsLeft = 4 * 60 * 60
func _init():
	id = "VoreLureScent"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		secondsLeft = int(_args[0])
	if secondsLeft < 60:
		secondsLeft = 60
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	var add = 4 * 60 * 60
	if _args.size() > 0:
		add = int(_args[0])
	secondsLeft += add
	if character != null:
		character.updateNonBattleEffects()
func processTime(_secondsPassed: int):
	secondsLeft -= _secondsPassed
	if secondsLeft <= 0:
		secondsLeft = 0
		stop()
		return
func getEffectName():
	return "Irresistible Scent"
func getEffectDesc():
	return ("You smell, frankly, delicious. Every predator who gets near you has to fight the urge "
		+ "to simply take you in -- and a lot of them will not bother fighting it. Vore offers come "
		+ "much more often, refusals are much more likely to be ignored, and you are far more likely "
		+ "to wake up somewhere warm.\n\nWears off in " + Util.getTimeStringHumanReadable(secondsLeft) + ".")
func getEffectImage():
	return "res://Images/StatusEffects/Invigoration.png"
func getIconColor():
	return IconColorYellow
func saveData():
	return {
		"secondsLeft": secondsLeft,
	}
func loadData(_data):
	secondsLeft = SAVE.loadVar(_data, "secondsLeft", 4 * 60 * 60)
