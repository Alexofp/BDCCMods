extends StatusEffectBase
var npcName = "someone"
var npcID = ""
var plugMethod = "anus"
func _init():
	id = "VoreNpcPlug"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		npcName = str(_args[0])
	if _args.size() > 1:
		npcID = str(_args[1])
	if _args.size() > 2:
		var m = str(_args[2])
		if m == "vagina" or m == "anus":
			plugMethod = m
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
func _isVaginal() -> bool:
	return plugMethod == "vagina"
func getEffectName():
	if _isVaginal():
		return "Living Vaginal Plug (" + npcName + ")"
	return "Living Buttplug (" + npcName + ")"
func getEffectDesc():
	var holeWord = "pussy" if _isVaginal() else "anus"
	var baseDesc = "Tiny " + npcName + " is plugged snugly inside your " + holeWord + ", squirming faintly with every move you make. The constant pressure keeps you warm and sensitive, and it holds back any leaking."
	var warning = "[b]WARNING:[/b] If " + npcName + " grows back to normal size while still inside you, they will burst out -- and kill you."
	return baseDesc + "\n\n" + warning
func getEffectImage():
	if _isVaginal():
		return "res://Images/Items/bdsm/plug.png"
	return "res://Images/Items/bdsm/anal-plug.png"
func getIconColor():
	return IconColorPurple
func getBuffs():
	if _isVaginal():
		return [
			buff(Buff.AmbientLustBuff, [10]),
			buff(Buff.MinLoosenessVaginaBuff, [2.0]),
			buff(Buff.SensitivityGainBuff, [25.0]),
			buff(Buff.BlocksVaginaLeakingBuff),
		]
	return [
		buff(Buff.AmbientLustBuff, [10]),
		buff(Buff.MinLoosenessAnusBuff, [2.0]),
		buff(Buff.SensitivityGainBuff, [25.0]),
		buff(Buff.BlocksAnusLeakingBuff),
	]
func saveData():
	return {
		"npcName": npcName,
		"npcID": npcID,
		"plugMethod": plugMethod,
	}
func loadData(_data):
	npcName = SAVE.loadVar(_data, "npcName", "someone")
	npcID = SAVE.loadVar(_data, "npcID", "")
	plugMethod = SAVE.loadVar(_data, "plugMethod", "anus")
