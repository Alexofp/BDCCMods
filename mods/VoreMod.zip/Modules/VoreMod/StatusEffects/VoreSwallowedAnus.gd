extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const STAGE_DESC = [
	"has just been pulled inside, squirming uncomfortably in your gut.",
	"is struggling inside you, your body working to contain them.",
	"is losing strength -- your digestive tract slowly winning.",
	"is beginning to break down, adding warmth and weight to your body.",
	"is deep in your tract, your body thickening with every hour.",
	"is nearly fully processed -- you can feel them becoming part of you.",
]
const SLEEP_MSG = [
	"You fall asleep with a dense, uncomfortable fullness in your gut. {who} has not given up yet.",
	"Another night of digestion. {who} is still fighting, but your body is relentless.",
	"You wake slightly heavier. {who}'s resistance is breaking down inside your digestive tract.",
	"{who} is beginning to dissolve properly now. You can feel your body thickening from the inside.",
	"A long, satisfying night. {who} is deep in your tract, your curves filling out as they dissolve.",
	"Almost done. {who} is nearly fully processed -- one more night will finish what your body started.",
]
const SLEEP_MSG_FINAL = "You wake noticeably thicker. {who} was fully processed overnight -- thoroughly absorbed, every last bit of them now part of your curves."
func _init():
	id = "VoreSwallowedAnus"
	isBattleOnly = false
func getVoreMethod() -> String:    return "anus"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreAnusEndosoma"
func _applyPartialEffect(stage: int):
	var add = 1 + int(stage >= 3)
	var cur = GM.pc.getThickness()
	GM.pc.setThickness(int(min(cur + add, 150)))
func _applyFinalEffect():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 8, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Complete digestion. You have become noticeably thicker -- every curve fuller than before. Thickness: " + str(newVal) + "%"
	)