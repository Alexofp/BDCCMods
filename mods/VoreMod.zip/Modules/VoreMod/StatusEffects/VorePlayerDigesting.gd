extends StatusEffectBase
const FINAL_DAY = 6
const PERK_HASTENED = "VoreHastenedDigestion"
const FAST_SECONDS_PER_STAGE = 7200
const STAGE_NAMES = [
	"Swallowed",
	"Struggling",
	"Weakening",
	"Softening",
	"Dissolving",
	"Nearly Absorbed",
]
var predName = "someone"
var digestionDay = 1
var voreMethod = "mouth"
var secondsInside = 0
var pausedStages = 0
func _init():
	id = "VorePlayerDigesting"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		predName = str(_args[0])
	if _args.size() > 1:
		voreMethod = str(_args[1])
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	if _args.size() > 0:
		predName = str(_args[0])
	if _args.size() > 1:
		voreMethod = str(_args[1])
	if character != null:
		character.updateNonBattleEffects()
func _partWord() -> String:
	match voreMethod:
		"mouth":   return "gut"
		"breasts": return "breast flesh"
		"anus":    return "bowels"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye socket"
		"ear":     return "ear canal"
	return "gut"
func _fluidWord() -> String:
	match voreMethod:
		"mouth":   return "stomach acid"
		"breasts": return "milk"
		"anus":    return "slick"
		"cock":    return "cum"
		"vagina":  return "fluids"
		"tail":    return "slime"
	return "slick"
func _stageDesc(idx: int) -> String:
	var part = _partWord()
	var fluid = _fluidWord()
	match idx:
		0: return "You have just been taken in whole. The walls of " + predName + "'s " + part + " press in on every side, but you are still whole and strong."
		1: return "The heat is relentless. Your body aches as the " + part + " works against you, your strength beginning to fade."
		2: return "You are growing weaker. The " + fluid + " stings everywhere it touches and your limbs feel heavy and slow."
		3: return "Your body is softening. Exhaustion floods you and a deep, gnawing pain spreads through your flesh."
		4: return "You are coming apart. Searing pain wracks you as the " + part + " breaks you down piece by piece."
		5: return "Almost nothing of you remains. You are little more than sludge in " + predName + "'s " + part + " -- one more push and you are gone for good."
	return "You are sealed inside " + predName + "'s " + part + "."
func getStagesTotal() -> int:
	return FINAL_DAY
func getDigestionDay() -> int:
	return digestionDay
func getDigestionStage() -> int:
	return digestionDay
func getStageFraction() -> float:
	return clamp(float(digestionDay - 1) / float(max(1, FINAL_DAY - 1)), 0.0, 1.0)
func isFatal() -> bool:
	return digestionDay >= FINAL_DAY
func isPastNoReturn() -> bool:
	return digestionDay >= FINAL_DAY - 1
func isFastDigestion() -> bool:
	if character == null:
		return false
	return character.hasPerk(PERK_HASTENED)
func secondsPerStage() -> int:
	return FAST_SECONDS_PER_STAGE
func pauseDigestion(amount: int = 1) -> String:
	pausedStages += int(max(1, amount))
	secondsInside = 0
	return "Your own digestion grinds to a halt -- the next " + str(pausedStages) + " stage(s) of being broken down will simply not happen."
func accelerateDigestion() -> String:
	var before = digestionDay
	advanceDay()
	if digestionDay > before:
		return "You feel yourself dissolve faster: digestion jumps to stage " + str(digestionDay) + " of " + str(FINAL_DAY) + "."
	return "Nothing seems to change."
func setDigestionDay(newDay: int):
	digestionDay = int(clamp(newDay, 1, FINAL_DAY))
	if character != null:
		character.updateNonBattleEffects()

func resetSecondsInside():
	secondsInside = 0

func advanceDay() -> int:
	if pausedStages > 0:
		pausedStages -= 1
		if character != null:
			character.updateNonBattleEffects()
		if GM.main != null:
			GM.main.addMessage("The anti-digestion pill holds -- you are not broken down any further this time.")
		return digestionDay
	digestionDay += 1
	if digestionDay <= 3 && digestionDay < FINAL_DAY - 1 && RNG.chance(18):
		digestionDay += 1
		if GM.main != null:
			GM.main.addMessage("[color=#ff5555]Something gives way inside you -- digestion lurches forward an entire extra stage![/color]")
	if digestionDay > FINAL_DAY:
		digestionDay = FINAL_DAY
	secondsInside = 0
	if character != null:
		character.updateNonBattleEffects()
	return digestionDay
func processTime(_secondsPassed: int):
	addInsideSeconds(_secondsPassed)

func addInsideSeconds(amount: int) -> int:
	if amount <= 0:
		return 0
	if !isFastDigestion():
		return 0
	secondsInside += amount
	var advanced = 0
	while secondsInside >= secondsPerStage() && digestionDay < FINAL_DAY:
		var before = digestionDay
		secondsInside -= secondsPerStage()
		advanceDay()
		if digestionDay == before:
			break
		advanced += 1
	return advanced
func getEffectName():
	return "Being Digested"
func getEffectDesc():
	var idx = int(clamp(digestionDay - 1, 0, STAGE_NAMES.size() - 1))
	var desc = "You are sealed inside " + predName + "'s " + _partWord() + ", slowly being broken down."
	desc += "\n\nStage " + str(digestionDay) + " of " + str(FINAL_DAY) + " - " + STAGE_NAMES[idx]
	desc += "\n" + _stageDesc(idx)
	if isFastDigestion():
		var left = secondsPerStage() - secondsInside
		if left < 0:
			left = 0
		desc += "\n[i]Hastened Digestion: next stage in about " + Util.getTimeStringHumanReadable(left) + " spent inside.[/i]"
	else:
		desc += "\n[i]Each night spent inside advances one stage.[/i]"
	if pausedStages > 0:
		desc += "\n[color=#55ff55]Digestion is chemically paused for the next " + str(pausedStages) + " stage(s).[/color]"
	desc += "\n\n[b]While inside:[/b] you cannot dodge at all, every struggle burns stamina, and restraints make it far worse."
	if digestionDay >= 2:
		desc += "\n[color=#ff5555]The " + _fluidWord() + " is doing real damage -- you wake up in pain and drained.[/color]"
	if isPastNoReturn() && !isFatal():
		desc += "\n\n[color=#ff0000]Point of no return: too much of you is gone. " + predName + " will not let you back out now, and begging or bribing is pointless. All you can do is try to force your own way out -- or endure.[/color]"
	if isFatal():
		desc += "\n\n[color=#ff0000]You are about to be absorbed completely. There is almost nothing left to escape with.[/color]"
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"
func getIconColor():
	return IconColorRed
func getBuffs():
	var result = []
	var d = digestionDay
	result.append(buff(Buff.MaxStaminaBuff, [-int(min(d * 8, 45))]))
	result.append(buff(Buff.PhysicalDamageBuff, [-int(min(d * 5, 30))]))
	result.append(buff(Buff.AccuracyBuff, [-int(min(d * 4, 25))]))
	result.append(buff(Buff.DodgeChanceBuff, [-100]))
	if d >= 2:
		result.append(buff(Buff.AmbientPainBuff, [(d - 1) * 2]))
		result.append(buff(Buff.ReceivedPhysicalDamageBuff, [(d - 1) * 8]))
	return result
func saveData():
	return {
		"predName": predName,
		"digestionDay": digestionDay,
		"voreMethod": voreMethod,
		"secondsInside": secondsInside,
		"pausedStages": pausedStages,
	}
func loadData(_data):
	predName = SAVE.loadVar(_data, "predName", "someone")
	digestionDay = SAVE.loadVar(_data, "digestionDay", 1)
	voreMethod = SAVE.loadVar(_data, "voreMethod", "mouth")
	secondsInside = SAVE.loadVar(_data, "secondsInside", 0)
	pausedStages = SAVE.loadVar(_data, "pausedStages", 0)
