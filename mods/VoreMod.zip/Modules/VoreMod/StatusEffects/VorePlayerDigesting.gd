extends StatusEffectBase


const FINAL_DAY = 6

const STAGE_NAMES = [
	"Swallowed",
	"Struggling",
	"Weakening",
	"Softening",
	"Dissolving",
	"Nearly Absorbed",
]

const STAGE_DESC = [
	"You have just been swallowed whole. The churning walls press in, but you are still whole and strong.",
	"The heat is relentless. Your body aches as the gut works against you, your strength beginning to fade.",
	"You are growing weaker. The acids sting and your limbs feel heavy and slow.",
	"Your body is softening. Exhaustion floods you and a deep, gnawing pain spreads through your flesh.",
	"You are dissolving. Searing pain wracks you as the gut breaks you down piece by piece.",
	"Almost nothing of you remains. One more night inside and you will be gone for good.",
]

var predName = "someone"
var digestionDay = 1

func _init():
	id = "VorePlayerDigesting"
	isBattleOnly = false

func initArgs(_args = []):
	if _args.size() > 0:
		predName = str(_args[0])
	if character != null:
		character.updateNonBattleEffects()

func combine(_args = []):
	if _args.size() > 0:
		predName = str(_args[0])
	if character != null:
		character.updateNonBattleEffects()

func getDigestionDay() -> int:
	return digestionDay

func isFatal() -> bool:
	return digestionDay >= FINAL_DAY

func advanceDay() -> int:
	digestionDay += 1
	if character != null:
		character.updateNonBattleEffects()
	return digestionDay

func getEffectName():
	return "Being Digested"

func getEffectDesc():
	var idx = int(clamp(digestionDay - 1, 0, STAGE_NAMES.size() - 1))
	var desc = "You are sealed inside " + predName + "'s gut, slowly being digested over several days."
	desc += "\n\nDay " + str(digestionDay) + " of " + str(FINAL_DAY) + " - " + STAGE_NAMES[idx]
	desc += "\n" + STAGE_DESC[idx]
	if digestionDay >= 4:
		desc += "\n\n[color=#ff5555]The digestion has turned dangerous - you wake drained of all stamina and wracked with pain.[/color]"
	if digestionDay >= FINAL_DAY:
		desc += "\n\n[color=#ff0000]You are about to be fully digested. There is no escape left.[/color]"
	return desc

func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	var result = []
	var d = digestionDay
	result.append(buff(Buff.MaxStaminaBuff, [-int(min(d * 15, 90))]))
	result.append(buff(Buff.PhysicalDamageBuff, [-int(min(d * 10, 60))]))
	result.append(buff(Buff.AccuracyBuff, [-int(min(d * 5, 40))]))
	result.append(buff(Buff.DodgeChanceBuff, [-int(min(d * 5, 40))]))
	if d >= 4:
		result.append(buff(Buff.AmbientPainBuff, [(d - 3) * 6]))
		result.append(buff(Buff.ReceivedPhysicalDamageBuff, [(d - 3) * 25]))
	return result

func saveData():
	return {
		"predName": predName,
		"digestionDay": digestionDay,
	}

func loadData(_data):
	predName = SAVE.loadVar(_data, "predName", "someone")
	digestionDay = SAVE.loadVar(_data, "digestionDay", 1)
