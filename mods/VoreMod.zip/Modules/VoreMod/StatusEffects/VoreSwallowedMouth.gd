extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"

const STAGE_DESC = [
	"is alive and squirming inside your stomach, desperately trying to escape.",
	"is fighting hard against your stomach walls, but going nowhere.",
	"is growing weaker — their struggles are slowing down.",
	"is beginning to soften, your acids finally breaking them down.",
	"is rapidly dissolving, your belly gurgling with each movement.",
	"has been almost entirely absorbed — only traces remain.",
]

const SLEEP_MSG = [
	"You drift off with a full, gurgling belly. Inside, {who} squirms restlessly but can't escape your stomach.",
	"As you sleep, you can faintly feel {who} still fighting inside you. Their struggles are slowly weakening.",
	"{who}'s resistance is fading. You wake feeling your stomach acids have begun their work in earnest.",
	"You wake to a warm, heavy feeling in your gut. {who} is softening — the digestion is well underway.",
	"A night of deep, satisfied sleep. Your belly gurgles loudly as {who} rapidly dissolves within you.",
	"You wake feeling fuller than ever. {who} is almost entirely part of you now — one more rest and it will be complete.",
]

const SLEEP_MSG_FINAL = "{who} has been fully digested overnight. You feel their essence become a permanent part of you — warm, nourishing, complete."

func _init():
	id = "VoreSwallowedMouth"
	isBattleOnly = false

func getVoreMethod() -> String:    return "mouth"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreEndosoma"

func _applyPartialEffect(_stage: int):
	var cur = GM.pc.getThickness()
	GM.pc.setThickness(int(min(cur + 1, 150)))

func _applyFinalEffect():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 5, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Your body has fully absorbed every last nutrient. You feel warm and satisfied. Thickness: " + str(newVal) + "%"
	)
