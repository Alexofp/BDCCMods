extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"

const COCK_BALLS_MULT = 3.0

var _cockBallsEnlarged  = false
var _cockBallsOrigScale = 1.0

const STAGE_DESC = [
	"has just been drawn down into your balls, squirming in the churning heat.",
	"is struggling against the thick walls of your sack, but sinking deeper.",
	"is weakening — the relentless churning is wearing them down.",
	"is beginning to break down, your balls growing heavy and warm.",
	"is dissolving into thick seed, your sack swelling and aching.",
	"is nearly fully churned — only the richest essence of them remains.",
]

const SLEEP_MSG = [
	"You sleep with a heavy, churning ache in your balls. {who} squirms inside, unable to escape.",
	"Another night passes. {who} is still fighting the churn, but your sack is patient.",
	"You wake to a warm heaviness below. {who}'s struggles are fading into the churn.",
	"The churning of {who} has truly begun. Your balls feel dense and warm.",
	"You sleep deeply as {who} dissolves into thick seed within your swelling sack.",
	"Almost there. {who} is nearly all seed now — one more night and the churn will be complete.",
]

const SLEEP_MSG_FINAL = "You wake to a deep, satisfied heaviness. {who} has been fully churned overnight — rendered down into thick, potent seed that is now wholly part of you."

func _init():
	id = "VoreSwallowedCock"
	isBattleOnly = false

func getVoreMethod() -> String:    return "cock"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreCockEndosoma"

func _onPreyChanged():
	if GM.pc == null:
		return
	var penis = GM.pc.getBodypart(BodypartSlot.Penis)
	if penis == null:
		_cockBallsEnlarged = false
		return
	var cockCount = swallowedIDs.size()
	if cockCount > 0 and not _cockBallsEnlarged:
		_cockBallsOrigScale = penis.getBallsScale()
		penis.ballsScale = _cockBallsOrigScale * COCK_BALLS_MULT
		penis.updateAppearance()
		_cockBallsEnlarged = true
	elif cockCount <= 0 and _cockBallsEnlarged:
		penis.ballsScale = _cockBallsOrigScale
		penis.updateAppearance()
		_cockBallsEnlarged = false

func _applyPartialEffect(stage: int):
	var penis = GM.pc.getBodypart(BodypartSlot.Penis)
	if penis != null:
		var fp = penis.getFluidProduction()
		if fp != null:
			var before = fp.getFluidAmount()
			fp.fillPercent(0.1 + stage * 0.04)
			var gained = fp.getFluidAmount() - before
			if GM.main != null and gained > 0.0:
				GM.main.addMessage("Another part of your prey churns down into thick cum — +" + str(round(gained * 10.0) / 10.0) + " ml added to your heavy balls, and it stays.")
	else:
		var cur = GM.pc.getThickness()
		GM.pc.setThickness(int(min(cur + 1, 150)))

func _applyFinalEffect():
	var penis = GM.pc.getBodypart(BodypartSlot.Penis)
	if penis == null:
		var cur = GM.pc.getThickness()
		GM.pc.setThickness(int(min(cur + 6, 150)))
		GM.main.addMessage("The final remnants churn into raw mass — you have no cock to hold the seed.")
		return
	var fp = penis.getFluidProduction()
	if fp != null:
		fp.fillPercent(1.0)
	GM.main.addMessage(
		"Complete conversion achieved. Every last trace of your prey is now thick, potent cum — your balls are swollen and full to the brim, and it stays inside you to be spent at your leisure."
	)

func saveData():
	var data = .saveData()
	data["cockBallsEnlarged"]  = _cockBallsEnlarged
	data["cockBallsOrigScale"] = _cockBallsOrigScale
	return data

func loadData(_data):
	.loadData(_data)
	_cockBallsEnlarged  = SAVE.loadVar(_data, "cockBallsEnlarged",  false)
	_cockBallsOrigScale = SAVE.loadVar(_data, "cockBallsOrigScale", 1.0)
