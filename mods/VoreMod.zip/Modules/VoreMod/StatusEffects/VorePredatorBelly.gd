extends StatusEffectBase


var preyName = "someone"

func _init():
	id = "VorePredatorBelly"
	isBattleOnly = false

func initArgs(_args = []):
	if _args.size() > 0:
		preyName = str(_args[0])
	if character != null:
		character.updateNonBattleEffects()

func combine(_args = []):
	initArgs(_args)

func getEffectName():
	return "Stuffed With Prey"

func getEffectDesc():
	return "Has swallowed " + preyName + " whole. Their belly is hugely, squirming-ly distended."

func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [buff(Buff.InflatedBellyBuff, [80.0])]

func saveData():
	return {
		"preyName": preyName,
	}

func loadData(_data):
	preyName = SAVE.loadVar(_data, "preyName", "someone")
