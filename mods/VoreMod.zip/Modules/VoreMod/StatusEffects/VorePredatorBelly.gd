extends StatusEffectBase
var preyName = "someone"
var voreMethod = "mouth"
func _init():
	id = "VorePredatorBelly"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		preyName = str(_args[0])
	if _args.size() > 1:
		voreMethod = str(_args[1])
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
func _partWord() -> String:
	match voreMethod:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye"
		"ear":     return "ear"
	return "belly"
func _verbPhrase() -> String:
	match voreMethod:
		"mouth":   return "swallowed " + preyName + " whole"
		"breasts": return "drawn " + preyName + " into their breasts"
		"anus":    return "stuffed " + preyName + " up inside them"
		"cock":    return "drawn " + preyName + " down into their balls"
		"vagina":  return "drawn " + preyName + " up into their womb"
		"tail":    return "coiled " + preyName + " up inside their tail"
		"eye":     return "pulled " + preyName + " into their eye"
		"ear":     return "pulled " + preyName + " into their ear"
	return "swallowed " + preyName + " whole"
func getEffectName():
	return "Stuffed With Prey"
func getEffectDesc():
	if voreMethod == "eye" or voreMethod == "ear":
		return "Has " + _verbPhrase() + ". A tiny form is visible squirming inside their " + _partWord() + "."
	return "Has " + _verbPhrase() + ". Their " + _partWord() + " is hugely, squirming-ly distended."
func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"
func getIconColor():
	return IconColorGreen
func getBuffs():
	if voreMethod == "eye" or voreMethod == "ear":
		return []
	return [buff(Buff.InflatedBellyBuff, [80.0])]
func saveData():
	return {
		"preyName": preyName,
		"voreMethod": voreMethod,
	}
func loadData(_data):
	preyName = SAVE.loadVar(_data, "preyName", "someone")
	voreMethod = SAVE.loadVar(_data, "voreMethod", "mouth")