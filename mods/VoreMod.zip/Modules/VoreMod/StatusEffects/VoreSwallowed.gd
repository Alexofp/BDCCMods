extends Reference
const METHOD_TO_EFFECT = {
	"mouth":   "VoreSwallowedMouth",
	"breasts": "VoreSwallowedBreasts",
	"anus":    "VoreSwallowedAnus",
	"cock":    "VoreSwallowedCock",
	"vagina":  "VoreSwallowedVagina",
	"tail":    "VoreSwallowedTail",
	"eye":     "VoreSwallowedEye",
	"ear":     "VoreSwallowedEar",
}
const EFFECT_IDS = [
	"VoreSwallowedMouth",
	"VoreSwallowedBreasts",
	"VoreSwallowedAnus",
	"VoreSwallowedCock",
	"VoreSwallowedVagina",
	"VoreSwallowedTail",
	"VoreSwallowedEye",
	"VoreSwallowedEar",
]
const SHRUNK_ONLY_METHODS = ["eye", "ear"]
const SHRUNK_VORE_MAX_SCALE = 0.1
static func effectIDForMethod(method: String) -> String:
	return METHOD_TO_EFFECT.get(method, "VoreSwallowedMouth")
static func getEffects(pc) -> Array:
	var res = []
	if pc == null:
		return res
	for effID in EFFECT_IDS:
		if pc.hasEffect(effID):
			res.append(pc.getEffect(effID))
	return res
static func hasAnyPrey(pc) -> bool:
	return getEffects(pc).size() > 0
static func getEffectForMethod(pc, method: String):
	var effID = effectIDForMethod(method)
	if pc != null and pc.hasEffect(effID):
		return pc.getEffect(effID)
	return null
static func getEffectForID(pc, npcID: String):
	for eff in getEffects(pc):
		if eff.swallowedIDs.has(npcID):
			return eff
	return null
static func countForMethod(pc, method: String) -> int:
	var eff = getEffectForMethod(pc, method)
	if eff == null:
		return 0
	return eff.swallowedIDs.size()
static func totalCount(pc) -> int:
	var c = 0
	for eff in getEffects(pc):
		c += eff.swallowedIDs.size()
	return c
static func getEffectWithPendingEscape(pc):
	for eff in getEffects(pc):
		if eff.hasPendingEscape():
			return eff
	return null
static func getAllPrey(pc) -> Array:
	var out = []
	for eff in getEffects(pc):
		var method = eff.getVoreMethod()
		for i in range(eff.swallowedIDs.size()):
			var npcID = eff.swallowedIDs[i]
			out.append({
				"id":     npcID,
				"name":   eff.swallowedNames[i] if i < eff.swallowedNames.size() else "them",
				"method": method,
				"stage":  eff.getDigestionStage(npcID),
				"effect": eff,
			})
	return out