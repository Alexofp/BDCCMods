extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const SIZE_PER_PREY = 4
var _breastsEnlarged  = false
var _breastsOrigSize  = 0
const STAGE_DESC = [
	"is being drawn into your breast tissue, still resisting the pull.",
	"is struggling against the absorption, their energy fighting your body.",
	"is losing the fight -- the conversion process is taking hold.",
	"has begun to convert into fluid, your chest warming noticeably.",
	"is dissolving into rich milk, your breasts visibly swelling.",
	"is nearly fully converted -- your breasts ache with fullness.",
]
const SLEEP_MSG = [
	"You rest with a warm pressure in your chest. {who} is being slowly drawn into your breast tissue.",
	"Another night passes. {who} is still resisting the conversion, but your body is patient.",
	"You wake feeling your chest is warmer than usual. {who}'s energy is fading into the absorption.",
	"The conversion of {who} has truly begun. You wake with a modest but noticeable fullness in your breasts.",
	"You sleep deeply as {who} rapidly converts to fluid within you. Your breasts swell noticeably.",
	"Almost there. {who} is nearly all milk now -- one more night and the conversion will be complete.",
]
const SLEEP_MSG_FINAL = "You wake to find {who} has been fully converted overnight. Your breasts are heavy, aching, and overflowing with the results."
func _init():
	id = "VoreSwallowedBreasts"
	isBattleOnly = false
func getVoreMethod() -> String:    return "breasts"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreBreastsEndosoma"
func _countsTowardBelly() -> bool:
	return false
func getEffectName():
	return "Stuffed Breasts"
func getEffectImage():
	return "res://Images/StatusEffects/lactation.png"
func getBuffs():
	if swallowedIDs.size() <= 0:
		return []
	return [
		buff(Buff.BreastsForcedLactationBuff),
		buff(Buff.BreastsMilkProductionBuff, [80.0]),
	]
func _canGrowBreasts(breasts) -> bool:
	if breasts == null:
		return false
	if breasts.getBaseSize() == BreastsSize.FOREVER_FLAT:
		return false
	var traits = breasts.getTraits()
	if traits != null and traits.has(PartTrait.BreastsMale):
		return false
	return true
func _readOrigSize(breasts) -> int:
	if GM.pc != null and GM.pc.hasEffect("VoreBreastMilkFull"):
		var milkEff = GM.pc.getEffect("VoreBreastMilkFull")
		if milkEff != null:
			return int(milkEff.origSize)
	return int(breasts.size)
func _setBreastSize(breasts, newSize: int):
	breasts.size = newSize
	breasts.cached_size = breasts.getSize()
	breasts.updateAppearance()
func _onPreyChanged():
	if GM.pc == null:
		return
	var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
	if not _canGrowBreasts(breasts):
		_breastsEnlarged = false
		return
	var preyCount = swallowedIDs.size()
	if preyCount > 0:
		if not _breastsEnlarged:
			_breastsOrigSize = _readOrigSize(breasts)
			_breastsEnlarged = true
		_setBreastSize(breasts, _breastsOrigSize + SIZE_PER_PREY * preyCount)
	elif _breastsEnlarged:
		if GM.pc.hasEffect("VoreBreastMilkFull"):
			var milkEff = GM.pc.getEffect("VoreBreastMilkFull")
			if milkEff != null and milkEff.has_method("applyHoldSize"):
				milkEff.applyHoldSize()
		else:
			_setBreastSize(breasts, _breastsOrigSize)
		_breastsEnlarged = false
func _applyPartialEffect(stage: int):
	var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
	if breasts != null:
		var traits = breasts.getTraits()
		if not traits.has(PartTrait.BreastsMale):
			breasts.induceLactation()
			var fp = breasts.getFluidProduction()
			if fp != null:
				var before = fp.getFluidAmount()
				fp.fillPercent(0.1 + stage * 0.04)
				var gained = fp.getFluidAmount() - before
				if GM.main != null and gained > 0.0:
					GM.main.addMessage("Another part of your prey breaks down into rich milk -- +" + str(round(gained * 10.0) / 10.0) + " ml churned into your breasts, and it stays.")
			if _canGrowBreasts(breasts) and _breastsEnlarged:
				_setBreastSize(breasts, _breastsOrigSize + SIZE_PER_PREY * swallowedIDs.size())
		else:
			var cur = GM.pc.getThickness()
			GM.pc.setThickness(int(min(cur + 1, 150)))
func _applyFinalEffect():
	var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
	if breasts == null:
		GM.main.addMessage("The final remnants dissolve harmlessly -- you have no breasts to receive them.")
		return
	var traits = breasts.getTraits()
	if traits.has(PartTrait.BreastsMale):
		if not _bodyChangesSuppressed():
			var cur = GM.pc.getThickness()
			GM.pc.setThickness(int(min(cur + 5, 150)))
			GM.main.addMessage("The last of the conversion floods into raw muscle mass. Your chest feels iron-dense.")
		else:
			GM.main.addMessage("The last of the conversion is absorbed, but your perk keeps your body unchanged.")
		return
	breasts.induceLactation()
	var fp = breasts.getFluidProduction()
	var milkAmount = 0.0
	if fp != null:
		fp.fillPercent(1.0)
		var extra = 300.0
		if fp.getFluids() != null:
			fp.getFluids().addFluidIgnoreCapacity(fp.getFluidType(), extra, GM.pc.getFluidDNA(FluidSource.Breasts))
		milkAmount = fp.getFluidAmount()
	if not _canGrowBreasts(breasts):
		GM.main.addMessage(
			"Complete conversion achieved. Every last trace of your prey is now rich milk -- your breasts are heavy, warm and overflowing, and it stays inside you to be drained at your leisure."
		)
		return
	var origSize = _breastsOrigSize
	if not _breastsEnlarged:
		origSize = _readOrigSize(breasts)
	var holdSize = int(breasts.size)
	if holdSize < origSize + SIZE_PER_PREY:
		holdSize = origSize + SIZE_PER_PREY
	var permanentBonus = 1
	if _bodyChangesSuppressed():
		permanentBonus = 0
	_setBreastSize(breasts, holdSize)
	GM.pc.addEffect("VoreBreastMilkFull", [origSize, holdSize, permanentBonus, milkAmount])
	GM.main.addMessage(
		"Complete conversion achieved. Every last trace of your prey is now rich milk -- your breasts stay heavy and swollen with it until you drain them."
	)
func _onPreyFullyProcessed(_npcID: String, who: String) -> bool:
	GM.main.addMessage(_getFinalMessage(who))
	GM.pc.addSkillExperience("Vore", 100)
	GM.main.addMessage("Fully converted to milk! +100 Vore XP")
	if GM.pc != null and GM.pc.hasPerk("VoreFusion"):
		var npcChar = GlobalRegistry.getCharacter(_npcID)
		if npcChar != null:
			var fusionHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
			fusionHelper.performFusionWithMessages(GM.pc, npcChar)
	if GM.pc != null and GM.pc.hasPerk("VorePregnancyTransfer"):
		var preyChar = GlobalRegistry.getCharacter(_npcID)
		if preyChar != null:
			var pregHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
			var moved = pregHelper.transferPregnancy(preyChar, GM.pc)
			if moved > 0:
				GM.main.addMessage("As " + who + " breaks down, the new life they were carrying slips free and takes root in your womb. [b]You are now pregnant with their offspring![/b] (" + str(moved) + " transferred)")
			elif moved < 0:
				GM.main.addMessage(who + " was pregnant, but you have no womb to receive the offspring - the new life is lost with them.")
	_applyFinalEffect()
	if _bodyChangesSuppressed():
		GM.main.addMessage("The milk stays, but your perk keeps your chest from growing permanently -- once it is drained, you will return to your previous size.")
	return true
func saveData():
	var data = .saveData()
	data["breastsEnlarged"] = _breastsEnlarged
	data["breastsOrigSize"] = _breastsOrigSize
	return data
func loadData(_data):
	.loadData(_data)
	_breastsEnlarged = SAVE.loadVar(_data, "breastsEnlarged", false)
	_breastsOrigSize = SAVE.loadVar(_data, "breastsOrigSize", 0)
	_onPreyChanged()
