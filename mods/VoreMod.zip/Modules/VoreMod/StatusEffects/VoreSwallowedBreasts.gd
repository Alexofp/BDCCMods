extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const STAGE_DESC = [
	"is being drawn into your breast tissue, still resisting the pull.",
	"is struggling against the absorption, their energy fighting your body.",
	"is losing the fight -- the conversion process is taking hold.",
	"has begun to convert into fluid, your chest warming noticeably.",
	"is dissolving into rich milk, your breasts visibly swelling.",
	"is nearly fully converted -- your breasts ache with fullness.",
]
const SLEEP_MSG = [
	"You rest with a warm pressure in your chest. {who} is being slowly drawn into your breast tissue.",
	"Another night passes. {who} is still resisting the conversion, but your body is patient.",
	"You wake feeling your chest is warmer than usual. {who}'s energy is fading into the absorption.",
	"The conversion of {who} has truly begun. You wake with a modest but noticeable fullness in your breasts.",
	"You sleep deeply as {who} rapidly converts to fluid within you. Your breasts swell noticeably.",
	"Almost there. {who} is nearly all milk now -- one more night and the conversion will be complete.",
]
const SLEEP_MSG_FINAL = "You wake to find {who} has been fully converted overnight. Your breasts are heavy, aching, and overflowing with the results."
func _init():
	id = "VoreSwallowedBreasts"
	isBattleOnly = false
func getVoreMethod() -> String:    return "breasts"
func _stageDescList() -> Array:    return STAGE_DESC
func _sleepMsgList() -> Array:     return SLEEP_MSG
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreBreastsEndosoma"
func _countsTowardBelly() -> bool:
	return false
func getEffectImage():
	return "res://Images/StatusEffects/lactation.png"
func _applyPartialEffect(stage: int):
	var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
	if breasts != null:
		var traits = breasts.getTraits()
		if not traits.has(PartTrait.BreastsMale):
			breasts.induceLactation()
			var fp = breasts.getFluidProduction()
			if fp != null:
				var before = fp.getFluidAmount()
				fp.fillPercent(0.1 + stage * 0.04)
				var gained = fp.getFluidAmount() - before
				if GM.main != null and gained > 0.0:
					GM.main.addMessage("Another part of your prey breaks down into rich milk -- +" + str(round(gained * 10.0) / 10.0) + " ml churned into your breasts, and it stays.")
		else:
			var cur = GM.pc.getThickness()
			GM.pc.setThickness(int(min(cur + 1, 150)))
func _applyFinalEffect():
	var breasts = GM.pc.getBodypart(BodypartSlot.Breasts)
	if breasts == null:
		GM.main.addMessage("The final remnants dissolve harmlessly -- you have no breasts to receive them.")
		return
	var traits = breasts.getTraits()
	if traits.has(PartTrait.BreastsMale):
		var cur = GM.pc.getThickness()
		GM.pc.setThickness(int(min(cur + 5, 150)))
		GM.main.addMessage("The last of the conversion floods into raw muscle mass. Your chest feels iron-dense.")
		return
	breasts.induceLactation()
	var fp = breasts.getFluidProduction()
	if fp != null:
		fp.fillPercent(1.0)
	GM.main.addMessage(
		"Complete conversion achieved. Every last trace of your prey is now rich milk -- your breasts are heavy, warm and overflowing, and it stays inside you to be drained at your leisure."
	)