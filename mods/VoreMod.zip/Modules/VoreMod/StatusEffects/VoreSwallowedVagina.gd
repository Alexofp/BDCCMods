extends "res://Modules/VoreMod/StatusEffects/VoreSwallowedNPCBase.gd"
const VoreRebirthController = preload("res://Modules/VoreMod/StatusEffects/VoreRebirthController.gd")
const STAGE_DESC = [
	"has just been pulled up inside, squirming within the tight walls of your womb.",
	"is struggling against your inner walls, but your body holds them fast.",
	"is losing strength -- your womb slowly claiming them.",
	"is beginning to soften, your belly warming with their absorption.",
	"is dissolving deep in your womb, your middle rounding out noticeably.",
	"is nearly fully absorbed -- you can feel them becoming part of you.",
]
const SLEEP_MSG = [
	"You drift off with a full, warm pressure in your womb. {who} squirms restlessly but cannot escape.",
	"Another night passes. {who} is still resisting deep inside you, but your womb is relentless.",
	"You wake with a warm fullness low in your belly. {who}'s resistance is breaking down.",
	"The absorption of {who} is well underway. Your middle feels warm and gently rounded.",
	"You sleep deeply as {who} dissolves within your womb, your belly filling out softly.",
	"Almost done. {who} is nearly fully absorbed -- one more night will finish what your body started.",
]
const SLEEP_MSG_FINAL = "You wake softly rounded and warm. {who} was fully absorbed overnight -- drawn completely into you, every last bit now part of your body."
const STAGE_DESC_REBIRTH = [
	"has been pulled up inside your womb, squirming as it seals around them.",
	"is struggling within your womb, but your body has already begun to unmake them.",
	"is going limp -- their old form is slowly coming undone inside you.",
	"is losing all shape now, your womb reweaving them into something new.",
	"is little more than warm, formless potential deep within your womb.",
	"is almost fully reformed -- you can feel a tiny new life taking shape inside you.",
]
const SLEEP_MSG_REBIRTH = [
	"You drift off with a warm fullness in your womb. {who} squirms inside as your body begins to reshape them.",
	"Another night passes. {who}'s old form is steadily coming apart, reknit into something new.",
	"You wake with a strange warmth low in your belly. {who} is barely recognisable now.",
	"The reshaping of {who} is well underway. Your womb cradles their dissolving form.",
	"You sleep deeply as {who} loses the last of their shape, becoming raw new life within you.",
	"Almost there. {who} is nearly fully reformed -- one more night and a new life will quicken inside you.",
]
func _init():
	id = "VoreSwallowedVagina"
	isBattleOnly = false
func getVoreMethod() -> String:    return "vagina"
func _sleepFinalMsg() -> String:   return SLEEP_MSG_FINAL
func _endosomaPerkID() -> String:  return "VoreVaginaEndosoma"
func _rebirthActive() -> bool:
	return GM.pc != null and GM.pc.hasPerk("VoreVaginaRebirth")
func _convertActive() -> bool:
	return GM.pc != null and GM.pc.hasPerk("VoreVaginaConvert")
func _releasePreyInsteadOfDigesting(npcID: String, who: String) -> bool:
	if not _convertActive():
		return false
	var npc = GlobalRegistry.getCharacter(npcID)
	var npcName = who
	if npc != null:
		npcName = npc.getName()
		var helper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
		helper.convertSpeciesTo(npc, GM.pc)
	GM.main.addMessage(
		"After six days deep in your womb, " + npcName + " is not absorbed but reborn - your body reshapes them and they slip back out alive, their flesh now carrying [b]your species[/b]."
	)
	GM.pc.addSkillExperience("Vore", 100)
	GM.main.addMessage("Rebirth conversion complete! +100 Vore XP")
	return true
func isDigestionDisabled() -> bool:
	if _rebirthActive():
		return false
	return .isDigestionDisabled()
func _stageDescList() -> Array:
	if _rebirthActive():
		return STAGE_DESC_REBIRTH
	return STAGE_DESC
func _sleepMsgList() -> Array:
	if _rebirthActive():
		return SLEEP_MSG_REBIRTH
	return SLEEP_MSG
func _applyPartialEffect(stage: int):
	if _rebirthActive():
		return
	var add = 1 + int(stage >= 3)
	var cur = GM.pc.getThickness()
	GM.pc.setThickness(int(min(cur + add, 150)))
func _applyFinalEffect():
	var cur    = GM.pc.getThickness()
	var newVal = int(min(cur + 7, 150))
	GM.pc.setThickness(newVal)
	GM.main.addMessage(
		"Complete absorption. Your womb has drawn every last trace of your prey into you -- your body warm, soft and fuller than before. Thickness: " + str(newVal) + "%"
	)
func _onPreyFullyProcessed(npcID: String, who: String) -> bool:
	if _rebirthActive():
		var character  = GlobalRegistry.getCharacter(npcID)
		var npcName     = who
		var npcSpecies  = []
		var npcGender   = NpcGender.Female
		if character != null:
			npcName    = character.getName()
			npcSpecies = character.getSpecies()
			npcGender  = character.calculateNpcGender()
		var ok = VoreRebirthController.convertPreyToPregnancy(npcID, npcName, npcSpecies, npcGender)
		if ok:
			GM.main.addMessage(
				"The last traces of " + npcName + " come undone inside your womb -- not digested, but unmade and reformed into raw new life. A fetus quickens within you. [b]You are now pregnant[/b], carrying " + npcName + "'s rebirth."
			)
			GM.pc.addSkillExperience("Vore", 100)
			GM.main.addMessage("Rebirth begun! +100 Vore XP")
			return false
		GM.main.addMessage("Your body tries to reform " + npcName + ", but you have no womb to hold the new life. They are simply absorbed instead.")
		return ._onPreyFullyProcessed(npcID, who)
	return ._onPreyFullyProcessed(npcID, who)