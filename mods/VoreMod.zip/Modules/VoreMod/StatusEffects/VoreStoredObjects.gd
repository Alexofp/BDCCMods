extends StatusEffectBase
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

var storedByMethod = {
	"mouth":   [],
	"anus":    [],
	"vagina":  [],
	"cock":    [],
	"breasts": [],
	"tail":    [],
}

var prevLustLevel = 0.0

func _init():
	id = "VoreStoredObjects"
	isBattleOnly = false

func initArgs(_args = []):
	if(character != null):
		character.updateNonBattleEffects()

func combine(_args = []):
	pass

func addStoredItem(item, m: String):
	if(item == null):
		return
	if(!storedByMethod.has(m)):
		return
	storedByMethod[m].append(item)
	if(character != null):
		character.updateNonBattleEffects()

func totalStored() -> int:
	var total = 0
	for method in VoreObjectHelper.METHODS:
		if(storedByMethod.has(method)):
			total += storedByMethod[method].size()
	return total

func countForMethod(m: String) -> int:
	if(!storedByMethod.has(m)):
		return 0
	return storedByMethod[m].size()

func getEntriesForMethod(m: String) -> Array:
	var result = []
	if(!storedByMethod.has(m)):
		return result
	for i in range(storedByMethod[m].size()):
		var item = storedByMethod[m][i]
		if(item == null):
			continue
		result.append({
			"index":  i,
			"item":   item,
			"name":   item.getVisibleName(),
			"method": m,
		})
	return result

func getEntries() -> Array:
	var result = []
	for method in VoreObjectHelper.METHODS:
		result += getEntriesForMethod(method)
	return result

func getEntriesByMethod() -> Dictionary:
	var result = {}
	for method in VoreObjectHelper.METHODS:
		result[method] = getEntriesForMethod(method)
	return result

func popStoredItem(method: String, index: int, intoInventory: bool = true):
	if(!storedByMethod.has(method)):
		return null
	if(index < 0 || index >= storedByMethod[method].size()):
		return null
	var item = storedByMethod[method][index]
	storedByMethod[method].remove(index)
	if(item != null && intoInventory && character != null):
		var inv = character.getInventory()
		if(inv != null):
			item.currentInventory = null
			inv.addItem(item)
	if(character != null):
		character.updateNonBattleEffects()
	if(totalStored() <= 0):
		stop()
	return item

func getEffectName():
	return "Body Storage (" + str(totalStored()) + ")"

func getEffectDesc():
	if(totalStored() <= 0):
		return "You are not carrying anything inside you."
	var text = "You are carrying items stored inside your body in separate compartments. Each part holds its cargo independently:\n"
	for m in VoreObjectHelper.METHODS:
		var count = countForMethod(m)
		if(count <= 0):
			continue
		var names = []
		for item in storedByMethod[m]:
			if(item != null):
				names.append(item.getVisibleName())
		text += "[b]" + VoreObjectHelper.partWord(m).capitalize() + ":[/b] " + Util.join(names, ", ") + "\n"
	if(countForMethod("mouth") > 0):
		text += "\nYour gut is packed full - you could not eat another bite if you tried."
	return text

func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	var result = []
	var bellyCount = countForMethod("mouth") + countForMethod("anus") + countForMethod("vagina")
	if(bellyCount > 0):
		result.append(buff(Buff.InflatedBellyBuff, [min(80.0, 20.0 * float(bellyCount))]))
	if(countForMethod("breasts") > 0):
		result.append(buff(Buff.BreastsMilkProductionBuff, [30.0 * float(countForMethod("breasts"))]))
	return result

func processTime(_secondsPassed: int):
	if(totalStored() <= 0):
		stop()
		return
	var pc = character
	if(pc == null):
		return
	var hours = float(_secondsPassed) / 3600.0
	if(hours <= 0.0):
		return
	_addLust(pc, _lustPerHour() * hours)
	_tickDrugs(pc, hours)
	_checkLeaks(pc)
	_suppressHunger(pc)

func onSleeping():
	var pc = character
	if(pc == null || totalStored() <= 0):
		return
	if(VoreObjectHelper.hasPerk(pc, VoreObjectHelper.PERK_CONTROL)):
		return
	if(!RNG.chance(25.0)):
		return
	var leaked = _expelRandomLeaky(false)
	if(leaked != ""):
		GM.main.addMessage("You wake up to a mess: your body pushed " + leaked + " out of you while you slept.")

func _lustPerHour() -> float:
	var total = 0.0
	for m in VoreObjectHelper.METHODS:
		var count = countForMethod(m)
		if(count <= 0):
			continue
		match m:
			"mouth":   total += 0.4 * count
			"anus":    total += 0.8 * count
			"vagina":  total += 1.2 * count
			"cock":    total += 1.6 * count
			"breasts": total += 0.6 * count
			"tail":    total += 0.5 * count
			_:         total += 0.5 * count
	if(VoreObjectHelper.hasPerk(character, VoreObjectHelper.PERK_CONTROL)):
		total *= 0.5
	return total

func _addLust(pc, amount: float):
	if(pc == null || amount <= 0.0):
		return
	if(pc.has_method("addLust")):
		pc.addLust(amount)
	elif(pc.has_method("addArousal")):
		pc.addArousal(amount / 100.0)

func _getLustLevel(pc) -> float:
	if(pc != null && pc.has_method("getLustLevel")):
		return float(pc.getLustLevel())
	return 0.0

func _tickDrugs(pc, hours: float):
	var chancePerHour = 2.0
	if(VoreObjectHelper.hasPerk(pc, VoreObjectHelper.PERK_SMUGGLER)):
		chancePerHour = 1.0
	
	for method in VoreObjectHelper.METHODS:
		var i = storedByMethod[method].size() - 1
		while(i >= 0):
			var item = storedByMethod[method][i]
			if(item != null && item.addsIntoxication() > 0.0):
				if(RNG.chance(chancePerHour * hours)):
					_triggerDrug(pc, method, i)
			i -= 1

func _triggerDrug(pc, method: String, index: int):
	var item = storedByMethod[method][index]
	if(item == null):
		return
	var itemName = item.getVisibleName()
	popStoredItem(method, index, false)
	GM.main.addMessage("[b]" + itemName + " goes off inside your " + VoreObjectHelper.partWord(method) + "![/b] The casing gives out and the whole dose floods straight into you at once.")
	if(pc.has_method("addIntoxication")):
		pc.addIntoxication(item.addsIntoxicationToPC() * 1.5)
	var resultText = ""
	if(item.has_method("useInCombat")):
		resultText = str(item.useInCombat(pc, pc))
	if(resultText != ""):
		GM.main.addMessage(resultText)
	_addLust(pc, 8.0)

func _checkLeaks(pc):
	var lustLevel = _getLustLevel(pc)
	if(!VoreObjectHelper.hasPerk(pc, VoreObjectHelper.PERK_CONTROL)):
		if(prevLustLevel >= 0.7 && lustLevel < prevLustLevel - 0.3):
			var leaked = _expelRandomLeaky(true)
			if(leaked != ""):
				GM.main.addMessage("Your body clenches through the afterglow and shoves " + leaked + " right back out of you.")
		elif(lustLevel >= 0.9 && RNG.chance(8.0)):
			var slipped = _expelRandomLeaky(false)
			if(slipped != ""):
				GM.main.addMessage("You are far too worked up to hold everything in - " + slipped + " slips out of you.")
	prevLustLevel = lustLevel

func _expelRandomLeaky(_afterOrgasm: bool) -> String:
	var candidates = []
	for m in VoreObjectHelper.LEAKY_METHODS:
		if(countForMethod(m) > 0):
			candidates.append(m)
	if(candidates.size() <= 0):
		return ""
	var method = candidates[RNG.randi_range(0, candidates.size() - 1)]
	var index = RNG.randi_range(0, storedByMethod[method].size() - 1)
	var item = storedByMethod[method][index]
	if(item == null):
		return ""
	var itemName = item.getVisibleName()
	popStoredItem(method, index, true)
	return itemName

func _suppressHunger(pc):
	if(countForMethod("mouth") <= 0):
		return
	for effID in ["Hungry", "Hunger", "Starving", "Famished"]:
		if(pc.hasEffect(effID)):
			pc.removeEffect(effID)
	if(pc.has_method("setHunger") && pc.has_method("getHunger")):
		if(float(pc.getHunger()) > 0.0):
			pc.setHunger(0.0)

func saveData():
	var entries = {}
	for method in VoreObjectHelper.METHODS:
		entries[method] = []
		for item in storedByMethod[method]:
			if(item == null):
				continue
			entries[method].append({
				"itemID": item.id,
				"data":   item.saveData(),
			})
	return {
		"entries": entries,
		"prevLustLevel": prevLustLevel,
	}

func loadData(_data):
	storedByMethod = {
		"mouth":   [],
		"anus":    [],
		"vagina":  [],
		"cock":    [],
		"breasts": [],
		"tail":    [],
	}
	prevLustLevel = SAVE.loadVar(_data, "prevLustLevel", 0.0)
	var entries = SAVE.loadVar(_data, "entries", {})
	if(!(entries is Dictionary)):
		return
	for method in VoreObjectHelper.METHODS:
		if(!entries.has(method)):
			continue
		var methodEntries = entries[method]
		if(!(methodEntries is Array)):
			continue
		for entry in methodEntries:
			if(!(entry is Dictionary)):
				continue
			var itemID = SAVE.loadVar(entry, "itemID", "")
			if(itemID == ""):
				continue
			var item = GlobalRegistry.createItem(itemID)
			if(item == null):
				continue
			item.loadData(SAVE.loadVar(entry, "data", {}))
			item.currentInventory = null
			storedByMethod[method].append(item)
