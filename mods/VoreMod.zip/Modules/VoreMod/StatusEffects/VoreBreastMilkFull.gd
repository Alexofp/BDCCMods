extends StatusEffectBase
var origSize = 0
var holdSize = 0
var permanentBonus = 0
var milkRemaining = 0.0
var lastFluidAmount = -1.0
var _watching = false
func _init():
	id = "VoreBreastMilkFull"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() > 0:
		origSize = int(_args[0])
	if _args.size() > 1:
		holdSize = int(_args[1])
	if _args.size() > 2:
		permanentBonus = int(_args[2])
	if _args.size() > 3:
		milkRemaining = float(_args[3])
	_watching = false
	lastFluidAmount = _currentFluidAmount()
	applyHoldSize()
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	if _args.size() > 0:
		var newOrig = int(_args[0])
		if newOrig < origSize:
			origSize = newOrig
	if _args.size() > 1:
		holdSize = int(max(holdSize, int(_args[1])))
	if _args.size() > 2:
		permanentBonus += int(_args[2])
	if _args.size() > 3:
		milkRemaining += float(_args[3])
	_watching = false
	lastFluidAmount = _currentFluidAmount()
	applyHoldSize()
	if character != null:
		character.updateNonBattleEffects()
func _getBreasts():
	if character == null:
		return null
	return character.getBodypart(BodypartSlot.Breasts)
func _preyStillInside() -> bool:
	if character == null:
		return false
	if not character.hasEffect("VoreSwallowedBreasts"):
		return false
	var swallowed = character.getEffect("VoreSwallowedBreasts")
	if swallowed == null:
		return false
	return swallowed.swallowedIDs.size() > 0
func _currentFluidAmount() -> float:
	var breasts = _getBreasts()
	if breasts == null:
		return 0.0
	var fp = breasts.getFluidProduction()
	if fp == null:
		return 0.0
	return fp.getFluidAmount()
func _currentFluidLevel() -> float:
	var breasts = _getBreasts()
	if breasts == null:
		return 0.0
	var fp = breasts.getFluidProduction()
	if fp == null:
		return 0.0
	return fp.getFluidLevel()
func applyHoldSize():
	if _preyStillInside():
		return
	var breasts = _getBreasts()
	if breasts == null:
		return
	if breasts.getBaseSize() == BreastsSize.FOREVER_FLAT:
		return
	var traits = breasts.getTraits()
	if traits != null and traits.has(PartTrait.BreastsMale):
		return
	breasts.size = holdSize
	breasts.cached_size = breasts.getSize()
	breasts.updateAppearance()
func _restoreSize():
	var breasts = _getBreasts()
	if breasts == null:
		return
	if breasts.getBaseSize() == BreastsSize.FOREVER_FLAT:
		return
	var traits = breasts.getTraits()
	if traits != null and traits.has(PartTrait.BreastsMale):
		return
	var newSize = origSize + permanentBonus
	if newSize < BreastsSize.FLAT:
		newSize = BreastsSize.FLAT
	breasts.size = newSize
	breasts.cached_size = breasts.getSize()
	breasts.updateAppearance()
	if GM.main != null:
		if permanentBonus > 0:
			GM.main.addMessage("The last of the converted milk leaves your chest. Your breasts settle, a little larger than they were before.")
		else:
			GM.main.addMessage("The last of the converted milk leaves your chest. Your breasts return to their previous size.")
func getEffectName():
	return "Converted Milk"
func getEffectDesc():
	var desc = "Your breasts are swollen with milk converted from absorbed prey. They will stay this full until that milk is drained."
	if permanentBonus > 0:
		desc += " Afterward they will settle one size larger than before."
	else:
		desc += " Afterward they will return to their previous size."
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/lactation.png"
func getIconColor():
	return IconColorYellow
func getBuffs():
	return [
		buff(Buff.BreastsForcedLactationBuff),
		buff(Buff.BreastsMilkProductionBuff, [50.0]),
	]
func processTime(_secondsPassed: int):
	if _preyStillInside():
		return
	applyHoldSize()
	var amount = _currentFluidAmount()
	var level = _currentFluidLevel()
	if not _watching:
		_watching = true
		lastFluidAmount = amount
		if character != null:
			character.updateNonBattleEffects()
		return
	if lastFluidAmount >= 0.0 and amount < lastFluidAmount:
		milkRemaining -= (lastFluidAmount - amount)
	lastFluidAmount = amount
	if level < 0.2 or amount < 40.0:
		_restoreSize()
		stop()
		return
	if character != null:
		character.updateNonBattleEffects()
func saveData():
	return {
		"origSize": origSize,
		"holdSize": holdSize,
		"permanentBonus": permanentBonus,
		"milkRemaining": milkRemaining,
		"lastFluidAmount": lastFluidAmount,
		"watching": _watching,
	}
func loadData(_data):
	origSize = SAVE.loadVar(_data, "origSize", 0)
	holdSize = SAVE.loadVar(_data, "holdSize", 0)
	permanentBonus = SAVE.loadVar(_data, "permanentBonus", 0)
	milkRemaining = SAVE.loadVar(_data, "milkRemaining", 0.0)
	lastFluidAmount = SAVE.loadVar(_data, "lastFluidAmount", -1.0)
	_watching = SAVE.loadVar(_data, "watching", false)
	applyHoldSize()
