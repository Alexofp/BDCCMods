extends StatusEffectBase
var pending = []
const MAX_WAIT_DAYS = 120
func _init():
	id = "VoreRebirthController"
	isBattleOnly = false
static func convertPreyToPregnancy(npcID, npcName, npcSpecies, npcGender, motherChar = null) -> bool:
	if motherChar == null:
		motherChar = GM.pc
	if motherChar == null:
		return false
	var cycle = motherChar.getMenstrualCycle()
	if cycle == null or not cycle.hasAnyWomb():
		return false
	var orifice = OrificeType.Vagina
	for o in OrificeType.getAll():
		if cycle.hasWombIn(o):
			orifice = o
			break
	var speciesArr = npcSpecies.duplicate() if (npcSpecies is Array) else [str(npcSpecies)]
	if speciesArr.empty():
		speciesArr = motherChar.getSpecies()
	var egg = cycle.createEggCell()
	egg.setOrifice(orifice)
	egg.motherID         = "pc" if motherChar.isPlayer() else motherChar.getID()
	egg.motherSpecies    = motherChar.getSpecies()
	egg.isimpregnated    = true
	egg.fatherID         = npcID
	egg.causerID         = npcID
	egg.resultSpecies    = speciesArr
	egg.resultGender     = npcGender
	egg.progress         = 0.0
	egg.fetusReadyForBirth = false
	egg.monozygotic      = 1
	cycle.impregnatedEggCells.append(egg)
	motherChar.addEffect("VoreRebirthController", [npcID, npcName, speciesArr, npcGender])
	return true
func initArgs(_args = []):
	if _args.size() >= 4:
		var npcID = str(_args[0])
		for rec in pending:
			if rec.get("npcID", "") == npcID:
				return
		var species = _args[2] if (_args[2] is Array) else [str(_args[2])]
		pending.append({
			"npcID":      npcID,
			"name":       str(_args[1]),
			"species":    species,
			"gender":     str(_args[3]),
			"createdDay": GM.main.getDays() if GM.main != null else 0,
		})
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
func processTime(_secondsPassed: int):
	_checkBirths()
func onSleeping():
	_checkBirths()
func _checkBirths():
	if GM.CS == null:
		return
	var stillPending = []
	for rec in pending:
		var npcID   = rec.get("npcID", "")
		var matched = false
		for child in GM.CS.getChildren():
			if child.getFatherID() == npcID:
				child.setName(rec.get("name", "Child"))
				var sp = rec.get("species", null)
				if sp != null and sp is Array and not sp.empty():
					child.setSpecies(sp)
				matched = true
				break
		if matched:
			continue
		var createdDay = int(rec.get("createdDay", 0))
		if GM.main != null and (GM.main.getDays() - createdDay) > MAX_WAIT_DAYS:
			continue
		stillPending.append(rec)
	pending = stillPending
	if pending.empty():
		stop()
func getEffectName():
	return "Womb Rebirth"
func getEffectDesc():
	if pending.empty():
		return "Your womb is quietly reshaping your prey into new life."
	var names = []
	for rec in pending:
		names.append(rec.get("name", "your prey"))
	return "Your womb is carrying the reborn essence of " + Util.join(names, ", ") + ". When you give birth, they will return as a copy of their former self -- same name, species and sex."
func getEffectImage():
	return "res://Images/StatusEffects/belly.png"
func getIconColor():
	return IconColorGreen
func saveData():
	return {
		"pending": pending,
	}
func loadData(_data):
	pending = SAVE.loadVar(_data, "pending", [])
