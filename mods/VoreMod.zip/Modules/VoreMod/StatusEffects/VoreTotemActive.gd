extends StatusEffectBase

var anchorRoom = ""

func _init():
	id = "VoreTotemActive"
	isBattleOnly = false

func initArgs(_args = []):
	if _args.size() > 0:
		anchorRoom = str(_args[0])
	if character != null:
		character.updateNonBattleEffects()

func combine(_args = []):
	initArgs(_args)
	if character != null:
		character.updateNonBattleEffects()

func getAnchorRoom() -> String:
	return anchorRoom

func getEffectName():
	return "Vore Totem (armed)"

func getEffectDesc():
	return "A vore totem is bound to a location. The next time you would be fully digested, it will shatter and pull you back to where you activated it instead of letting you die. Single use."

func getEffectImage():
	return "res://Images/StatusEffects/Invigoration.png"

func getIconColor():
	return IconColorGreen

func saveData():
	return {
		"anchorRoom": anchorRoom,
	}

func loadData(_data):
	anchorRoom = SAVE.loadVar(_data, "anchorRoom", "")
