extends StatusEffectBase
const STAGE_COUNT = 6
const STAGE_NAMES = [
	"Freshly swallowed",
	"Struggling",
	"Weakening",
	"Softening",
	"Dissolving",
	"Nearly absorbed",
]
var preyNames   = []          
var preyIDs     = []          
var preyMethods = []          
var stages      = {}          
var _originalPools = {}       
func _init():
	id = "VoreSlavePredatorDigesting"
	isBattleOnly = false
func initArgs(_args = []):
	if _args.size() >= 2:
		var pName = str(_args[0])
		var pID   = str(_args[1])
		var m     = "mouth"
		if _args.size() >= 3:
			m = str(_args[2])
		if pID != "" and not preyIDs.has(pID):
			preyNames.append(pName)
			preyIDs.append(pID)
			preyMethods.append(m)
			stages[pID] = 0
			_captureAndRemovePools(pID)
			if GM.main != null and GM.main.IS.hasPawn(pID):
				GM.main.IS.deletePawn(pID)
	if character != null:
		character.updateNonBattleEffects()
func combine(_args = []):
	initArgs(_args)
func _captureAndRemovePools(npcID: String):
	if GM.main == null:
		return
	var pools = []
	for poolID in GM.main.getDynamicCharactersPools():
		var ids = GM.main.getDynamicCharacterIDsFromPool(poolID)
		if ids.has(npcID):
			pools.append(poolID)
	if pools.size() > 0:
		_originalPools[npcID] = pools
	GM.main.removeDynamicCharacterFromAllPools(npcID)
func getDigestionStage(npcID: String) -> int:
	return int(stages.get(npcID, 0))
func getDigestionProgress(npcID: String) -> float:
	return clamp(float(getDigestionStage(npcID)) / float(STAGE_COUNT), 0.0, 1.0)
func _partWord(m: String) -> String:
	match m:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye"
		"ear":     return "ear"
	return "belly"
func _predName() -> String:
	if character != null and character.has_method("getName"):
		return character.getName()
	return "your slave"
func onNewDay():
	if preyIDs.size() <= 0:
		stop()
		return
	var finished = []
	for pID in preyIDs.duplicate():
		var stage = getDigestionStage(pID)
		if stage < STAGE_COUNT:
			stage += 1
			stages[pID] = stage
			if GM.pc != null:
				GM.pc.addSkillExperience("Vore", 10 + stage * 3)
		if stage >= STAGE_COUNT:
			finished.append(pID)
	for pID in finished:
		_fullyDigest(pID)
	if preyIDs.size() <= 0:
		stop()
	elif character != null:
		character.updateNonBattleEffects()
func _fullyDigest(npcID: String):
	var who = _nameForID(npcID)
	if GM.main != null:
		GM.main.addMessage(_predName() + " has fully digested " + who + ".")
	if GM.pc != null:
		GM.pc.addSkillExperience("Vore", 60)
	if GM.main != null:
		if GM.main.IS.hasPawn(npcID):
			GM.main.IS.deletePawn(npcID)
		if GM.main.dynamicCharacters.has(npcID):
			GM.main.removeDynamicCharacter(npcID)
	_removePrey(npcID)
	_originalPools.erase(npcID)
func _removePrey(npcID: String):
	var idx = preyIDs.find(npcID)
	if idx >= 0:
		preyIDs.remove(idx)
		if idx < preyNames.size():
			preyNames.remove(idx)
		if idx < preyMethods.size():
			preyMethods.remove(idx)
	stages.erase(npcID)
func _nameForID(npcID: String) -> String:
	var idx = preyIDs.find(npcID)
	if idx >= 0 and idx < preyNames.size():
		return preyNames[idx]
	return "their prey"
func getEffectName():
	return "Stuffed With Prey"
func _progressBar(progress: float) -> String:
	var filled = int(round(progress * 10.0))
	var bar = "["
	for i in range(10):
		bar += "#" if i < filled else "."
	bar += "]"
	return bar
func getEffectDesc():
	if preyNames.size() <= 0:
		return "Has someone squirming inside them."
	var namesText = Util.join(preyNames, ", ")
	var desc = "Has swallowed " + namesText + ". They are being digested over several days."
	for i in range(preyIDs.size()):
		var pID   = preyIDs[i]
		var who   = preyNames[i] if i < preyNames.size() else "them"
		var m     = preyMethods[i] if i < preyMethods.size() else "mouth"
		var stage = getDigestionStage(pID)
		var stageIdx = clamp(stage, 0, STAGE_COUNT - 1)
		var stageName = STAGE_NAMES[stageIdx]
		var progress = getDigestionProgress(pID)
		var daysLeft = STAGE_COUNT - stage
		var daysStr = str(daysLeft) + (" day" if daysLeft == 1 else " days")
		desc += "\n\n* " + who + "  (" + m + " - " + _partWord(m) + ")"
		desc += "\n  Day " + str(stage) + "/" + str(STAGE_COUNT) + "  -  " + stageName + "  " + _progressBar(progress)
		if stage >= STAGE_COUNT:
			desc += "\n  [Fully digested]"
		else:
			desc += "\n  [~" + daysStr + " remaining]"
	var count = preyIDs.size()
	if count == 1:
		desc += "\n\nTheir belly is noticeably distended."
	elif count == 2:
		desc += "\n\nTheir belly is heavily swollen."
	elif count >= 3:
		desc += "\n\nTheir belly is grotesquely, massively bloated."
	return desc
func getEffectImage():
	return "res://Images/StatusEffects/bloating.png"
func getIconColor():
	return IconColorGreen
func getBuffs():
	if preyIDs.size() <= 0:
		return []
	return [buff(Buff.InflatedBellyBuff, [80.0 * preyIDs.size()])]
func saveData():
	return {
		"preyNames":   preyNames,
		"preyIDs":     preyIDs,
		"preyMethods": preyMethods,
		"stages":      stages,
		"originalPools": _originalPools,
	}
func loadData(_data):
	preyNames   = SAVE.loadVar(_data, "preyNames",   [])
	preyIDs     = SAVE.loadVar(_data, "preyIDs",     [])
	preyMethods = SAVE.loadVar(_data, "preyMethods", [])
	stages      = SAVE.loadVar(_data, "stages",      {})
	_originalPools = SAVE.loadVar(_data, "originalPools", {})
	while preyMethods.size() < preyIDs.size():
		preyMethods.append("mouth")
	for pID in preyIDs:
		if not stages.has(pID):
			stages[pID] = 0