extends Reference
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")

const EFFECT_ID = "VoreStoredObjects"

const PERK_INITIATE    = "VoreObjectInitiate"
const PERK_EXPANSION   = "VoreStorageExpansion"
const PERK_SMUGGLER    = "VoreObjectSmuggler"
const PERK_CONTROL     = "VoreObjectControl"

const PERK_EXPANSION_MOUTH   = "VoreStorageExpansionMouth"
const PERK_EXPANSION_ANUS    = "VoreStorageExpansionAnus"
const PERK_EXPANSION_VAGINA  = "VoreStorageExpansionVagina"
const PERK_EXPANSION_COCK    = "VoreStorageExpansionCock"
const PERK_EXPANSION_BREASTS = "VoreStorageExpansionBreasts"
const PERK_EXPANSION_TAIL    = "VoreStorageExpansionTail"

const METHOD_EXPANSION_PERKS = {
	"mouth":   PERK_EXPANSION_MOUTH,
	"anus":    PERK_EXPANSION_ANUS,
	"vagina":  PERK_EXPANSION_VAGINA,
	"cock":    PERK_EXPANSION_COCK,
	"breasts": PERK_EXPANSION_BREASTS,
	"tail":    PERK_EXPANSION_TAIL,
}

const METHODS = ["mouth", "anus", "vagina", "cock", "breasts", "tail"]

const METHOD_PERK = {
	"mouth":   "VoreInitiate",
	"anus":    "VoreAnusInitiate",
	"vagina":  "VoreVaginaInitiate",
	"cock":    "VoreCockInitiate",
	"breasts": "VoreBreastsInitiate",
	"tail":    "VoreTailInitiate",
}

const LEAKY_METHODS = ["cock", "vagina", "anus"]

static func hasPerk(pc, perkID: String) -> bool:
	if(pc == null || perkID == ""):
		return false
	return pc.hasPerk(perkID)

static func isUnlocked(pc) -> bool:
	return hasPerk(pc, PERK_INITIATE)

static func partWord(m: String) -> String:
	match m:
		"mouth":   return "stomach"
		"anus":    return "rear"
		"vagina":  return "womb"
		"cock":    return "cock"
		"breasts": return "breasts"
		"tail":    return "tail"
	return "body"

static func methodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow it down"
		"anus":    return "Push it up your rear"
		"vagina":  return "Slide it into your womb"
		"cock":    return "Stuff it down your cock"
		"breasts": return "Sink it into your breasts"
		"tail":    return "Tuck it into your tail"
	return "Store it"

static func storeText(m: String, itemName: String) -> String:
	match m:
		"mouth":   return "You tilt your head back and gulp " + itemName + " down whole. It settles into your stomach with a dull weight."
		"anus":    return "You work " + itemName + " past your rear with slow, patient pressure until your body swallows it up."
		"vagina":  return "You press " + itemName + " up inside yourself, stretching around it until it slips out of sight."
		"cock":    return "You painstakingly work " + itemName + " down your shaft. Your cock bulges obscenely before the shape sinks out of view."
		"breasts": return "You press " + itemName + " into your soft chest and let your body take it in, your breasts swelling around the shape."
		"tail":    return "You coil your tail around " + itemName + " and draw it in until only a faint bulge remains."
	return "You tuck " + itemName + " away inside yourself."

static func retrieveText(m: String, itemName: String) -> String:
	match m:
		"mouth":   return "You heave " + itemName + " back up your throat and wipe it off."
		"anus":    return "You squat down and push until " + itemName + " slides back out of your rear."
		"vagina":  return "You bear down and ease " + itemName + " back out of your womb."
		"cock":    return "You milk " + itemName + " back up your shaft until it pops free, slick and dripping."
		"breasts": return "You knead your chest until " + itemName + " works its way back out."
		"tail":    return "You uncoil your tail and " + itemName + " drops back into your hand."
	return "You retrieve " + itemName + " from inside you."

static func bodyAllows(pc, m: String) -> bool:
	if(pc == null):
		return false
	if(m == "vagina"):
		return pc.hasVagina()
	if(m == "cock"):
		return pc.hasPenis()
	if(m == "breasts"):
		return pc.hasNonFlatBreasts()
	return true

static func methodUnlocked(pc, m: String) -> bool:
	if(!isUnlocked(pc)):
		return false
	if(!METHOD_PERK.has(m)):
		return false
	if(!hasPerk(pc, METHOD_PERK[m])):
		return false
	if(!bodyAllows(pc, m)):
		return false
	if(VoreSwallowed.isMethodBlockedForPC(pc, m)):
		return false
	return true

static func capacity(pc, m: String) -> int:
	if(!methodUnlocked(pc, m)):
		return 0
	
	var cap = 2
	
	if(hasPerk(pc, PERK_EXPANSION)):
		cap += 2
	
	if(METHOD_EXPANSION_PERKS.has(m)):
		var specificPerk = METHOD_EXPANSION_PERKS[m]
		if(hasPerk(pc, specificPerk)):
			cap += 3
	
	return cap

static func anyMethodWithSpace(pc) -> bool:
	for m in METHODS:
		if(capacity(pc, m) > countForMethod(pc, m)):
			return true
	return false

static func getEffect(pc):
	if(pc == null):
		return null
	if(pc.hasEffect(EFFECT_ID)):
		return pc.getEffect(EFFECT_ID)
	return null

static func ensureEffect(pc):
	if(pc == null):
		return null
	if(!pc.hasEffect(EFFECT_ID)):
		pc.addEffect(EFFECT_ID, [])
	return getEffect(pc)

static func countForMethod(pc, m: String) -> int:
	var eff = getEffect(pc)
	if(eff == null):
		return 0
	return eff.countForMethod(m)

static func totalStored(pc) -> int:
	var eff = getEffect(pc)
	if(eff == null):
		return 0
	return eff.totalStored()

static func canStoreItem(item) -> bool:
	if(item == null):
		return false
	if(item.id == "VoreShrunkNPCItem"):
		return false
	if(item.isImportant()):
		return false
	if(item.isWornByWearer()):
		return false
	return true

static func getExtraItemActions(item) -> Array:
	var result = []
	var pc = GM.pc
	if(pc == null || item == null):
		return result
	if(!isUnlocked(pc)):
		return result
	if(canStoreItem(item) && anyMethodWithSpace(pc)):
		result.append({
			"name": "Store inside you",
			"scene": "VoreObjectStoreScene",
			"description": "Swallow " + item.getVisibleName() + " into your body and carry it where no guard will look. You can pull it back out later.",
			"onlyWhenCalm": true,
		})
	var stored = totalStored(pc)
	if(stored > 0):
		result.append({
			"name": "Body storage (" + str(stored) + ")",
			"scene": "VoreObjectStorageScene",
			"description": "Check what you are currently carrying inside your body and pull things back out.",
			"onlyWhenCalm": true,
		})
	return result

static func storeItem(pc, item, m: String) -> bool:
	if(pc == null || item == null):
		return false
	if(!methodUnlocked(pc, m)):
		return false
	if(countForMethod(pc, m) >= capacity(pc, m)):
		return false
	if(!canStoreItem(item)):
		return false
	var inv = pc.getInventory()
	var toStore = item
	if(item.amount > 1 && item.canCombine()):
		toStore = item.splitAmount(1)
		if(toStore == null):
			return false
	else:
		if(inv != null && inv.hasItem(item)):
			inv.removeItem(item)
	var eff = ensureEffect(pc)
	if(eff == null):
		return false
	eff.addStoredItem(toStore, m)
	return true

static func pickRandomStorableItem(pc):
	if(pc == null):
		return null
	var inv = pc.getInventory()
	if(inv == null):
		return null
	var candidates = []
	for item in inv.getItems():
		if(canStoreItem(item)):
			candidates.append(item)
	if(candidates.size() <= 0):
		return null
	return candidates[RNG.randi_range(0, candidates.size() - 1)]

static func pickRandomMethodWithSpace(pc) -> String:
	var options = []
	for m in METHODS:
		if(capacity(pc, m) > countForMethod(pc, m)):
			options.append(m)
	if(options.size() <= 0):
		return ""
	return options[RNG.randi_range(0, options.size() - 1)]
