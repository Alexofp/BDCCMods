extends "res://Scenes/SceneBase.gd"
var npcID: String = ""
var npcName: String = "them"
func _init():
	sceneID = "VoreSlaveGivePillScene"
func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	var character = GlobalRegistry.getCharacter(npcID)
	if character != null and character.has_method("getName"):
		npcName = character.getName()
func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID
func _getPills() -> Array:
	var result = []
	var inv = GM.pc.getInventory()
	if inv == null:
		return result
	for item in inv.getItems():
		if item.has_method("canUseInCombat") && item.canUseInCombat():
			result.append(item)
	return result
func _run():
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		saynn("There's no one here.")
		addButton("Back", "Step back", "endthescene")
		return
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID, npcBodyState={chains=[["normal", "neck", "scene", "floor"]]} })
	var pills = _getPills()
	if pills.size() == 0:
		saynn("You have no usable items in your inventory to give to [b]" + npcName + "[/b].")
		addButton("Back", "Never mind", "endthescene")
		return
	saynn("You dig through your belongings for something to make your slave [b]" + npcName + "[/b] swallow. Which item?")
	for i in range(pills.size()):
		var pill = pills[i]
		var desc = pill.getDescription() if pill.has_method("getDescription") else ""
		addButton(pill.getVisibleName(), desc, "give_pill", [i])
	addButton("Back", "Put your items away", "endthescene")
func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "give_pill":
		if _args.size() >= 1:
			_doGivePill(int(_args[0]))
		return
	setState(_action)
func _doGivePill(pillIndex: int):
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		addMessage("Couldn't find that character.")
		return
	var pills = _getPills()
	if pillIndex < 0 || pillIndex >= pills.size():
		addMessage("That item is no longer in your inventory.")
		return
	var pill = pills[pillIndex]
	var pillName = pill.getVisibleName()
	var resultMsg = pill.useInCombat(GM.pc, character)
	if resultMsg == null || resultMsg == "":
		resultMsg = pillName + " was used."
	addMessage("You order your slave " + character.getName() + " to swallow " + pillName + ". " + resultMsg)
	setState("")
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["npcName"] = npcName
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npcName = SAVE.loadVar(data, "npcName", "them")
