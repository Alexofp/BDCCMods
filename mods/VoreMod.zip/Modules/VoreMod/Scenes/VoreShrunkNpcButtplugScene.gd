extends "res://Modules/VoreMod/Scenes/VoreShrunkNpcPlugScene.gd"
func _init():
	sceneID = "VoreShrunkNpcButtplugScene"
	plugMethod = "anus"