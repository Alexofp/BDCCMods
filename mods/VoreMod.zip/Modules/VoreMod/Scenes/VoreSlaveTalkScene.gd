extends "res://Scenes/SceneBase.gd"
const VoreSwallowed        = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
const VoreBodyScaleHelper  = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var npcID: String = ""
var npcName: String = "them"
func _init():
	sceneID = "VoreSlaveTalkScene"
func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	var character = GlobalRegistry.getCharacter(npcID)
	if character != null and character.has_method("getName"):
		npcName = character.getName()
func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID
func _methodCapacity(m: String) -> int:
	var h = GM.pc.getSkillsHolder()
	var c = 0
	if(m == "mouth"):
		if(h.hasPerk("VoreInitiate")):    c += 1
		if(h.hasPerk("VoreExpansionV2")): c += 1
		if(h.hasPerk("VoreExpansionV3")): c += 1
	elif(m == "breasts"):
		if(h.hasPerk("VoreBreastsInitiate")):    c += 1
		if(h.hasPerk("VoreBreastsExpansionV2")): c += 1
		if(h.hasPerk("VoreBreastsExpansionV3")): c += 1
	elif(m == "anus"):
		if(h.hasPerk("VoreAnusInitiate")):    c += 1
		if(h.hasPerk("VoreAnusExpansionV2")): c += 1
		if(h.hasPerk("VoreAnusExpansionV3")): c += 1
	elif(m == "cock"):
		if(h.hasPerk("VoreCockInitiate")):    c += 1
		if(h.hasPerk("VoreCockExpansionV2")): c += 1
		if(h.hasPerk("VoreCockExpansionV3")): c += 1
	elif(m == "vagina"):
		if(h.hasPerk("VoreVaginaInitiate")):    c += 1
		if(h.hasPerk("VoreVaginaExpansionV2")): c += 1
		if(h.hasPerk("VoreVaginaExpansionV3")): c += 1
	elif(m == "tail"):
		if(h.hasPerk("VoreTailInitiate")):    c += 1
		if(h.hasPerk("VoreTailExpansionV2")): c += 1
		if(h.hasPerk("VoreTailExpansionV3")): c += 1
	elif(m == "eye"):
		if(h.hasPerk("VoreEyeInitiate")):    c += 1
		if(h.hasPerk("VoreEyeExpansionV2")): c += 1
		if(h.hasPerk("VoreEyeExpansionV3")): c += 1
	elif(m == "ear"):
		if(h.hasPerk("VoreEarInitiate")):    c += 1
		if(h.hasPerk("VoreEarExpansionV2")): c += 1
		if(h.hasPerk("VoreEarExpansionV3")): c += 1
	return c
func _currentCount(m: String) -> int:
	return VoreSwallowed.countForMethod(GM.pc, m)
func _methodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow whole (mouth)"
		"breasts": return "Absorb into breasts"
		"anus":    return "Absorb into rear"
		"cock":    return "Devour with cock"
		"vagina":  return "Take into womb"
		"tail":    return "Coil up in tail"
		"eye":     return "Absorb through eye"
		"ear":     return "Absorb through ear"
	return "Swallow"
func _npcScale() -> float:
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		return 1.0
	if character.hasEffect("VoreSizeChange"):
		var scaleEff = character.getEffect("VoreSizeChange")
		if scaleEff != null:
			return scaleEff.targetScale
	return VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
func _run():
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		saynn("There's no one here.")
		addButton("Back", "Step back", "endthescene")
		return
	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID, npcBodyState={chains=[["normal", "neck", "scene", "floor"]]} })
	if state == "":
		saynn("You size your slave [b]" + npcName + "[/b] up, a hungry glint in your eye. Which way should the vore go?")
		addButton("Swallow them", "Devour your slave " + npcName + " whole (you are the predator)", "open_swallow")
		addButton("Let them swallow you", "Order " + npcName + " to devour you instead (they are the predator)", "get_eaten")
		var preyHere = _nearbyPreyIDs()
		if preyHere.size() > 0:
			addButton("Feed them a captive", "Have " + npcName + " devour one of the captives you've brought into this cell", "open_feed")
		else:
			addDisabledButton("Feed them a captive", "There's no one else in this cell to feed them. Leash a defeated NPC and lead them into this cell first, then release them here.")
		var otherSlaves = _otherSlaveIDs()
		if otherSlaves.size() > 0:
			addButton("Feed them another slave", "Order " + npcName + " to devour one of your other slaves whole", "open_eatslave")
		else:
			addDisabledButton("Feed them another slave", "You don't have any other available slaves for " + npcName + " to devour.")
		addButton("Back", "Not right now", "endthescene")
		return
	if state == "eatslave":
		var slaveIDs = _otherSlaveIDs()
		if slaveIDs.size() <= 0:
			saynn("You don't have any other available slaves for " + npcName + " to devour right now.")
			addButton("Back", "Change your mind", "go_main")
			return
		saynn("Which of your other slaves should " + npcName + " swallow whole?")
		for pid in slaveIDs:
			var ch = GlobalRegistry.getCharacter(pid)
			var nm = ch.getName() if (ch != null and ch.has_method("getName")) else str(pid)
			addButton(nm, "Order " + npcName + " to devour your slave " + nm + " whole", "do_feed", [pid])
		addButton("Back", "Change your mind", "go_main")
		return
	if state == "swallow":
		saynn("You advance on " + npcName + ", deciding exactly how to devour them...")
		_addMethodButtons()
		addButton("Back", "Change your mind", "go_main")
		return
	if state == "feed":
		var preyIDs = _nearbyPreyIDs()
		if preyIDs.size() <= 0:
			saynn("There's no one else in this cell for " + npcName + " to devour. Leash a defeated NPC, lead them into this cell and release them here first.")
			addButton("Back", "Change your mind", "go_main")
			return
		saynn("You gesture to the captives you've dragged into the cell. Which one should " + npcName + " swallow whole?")
		for pid in preyIDs:
			var ch = GlobalRegistry.getCharacter(pid)
			var nm = ch.getName() if (ch != null and ch.has_method("getName")) else str(pid)
			addButton(nm, "Order " + npcName + " to devour " + nm + " whole", "do_feed", [pid])
		addButton("Back", "Change your mind", "go_main")
		return
func _addMethodButtons():
	var npcScale = _npcScale()
	var anyAvailable = false
	for m in ["mouth", "breasts", "anus", "cock", "vagina", "tail", "eye", "ear"]:
		var cap = _methodCapacity(m)
		if cap <= 0:
			continue
		var cur = _currentCount(m)
		if VoreSwallowed.SHRUNK_ONLY_METHODS.has(m):
			if npcScale > VoreSwallowed.SHRUNK_VORE_MAX_SCALE + 0.01:
				addDisabledButton(_methodLabel(m), "This method only works on prey shrunk to " + str(VoreSwallowed.SHRUNK_VORE_MAX_SCALE) + "x or smaller. (" + npcName + " is currently " + str(stepify(npcScale, 0.01)) + "x)")
				continue
		if cur < cap:
			anyAvailable = true
			addButton(_methodLabel(m), "Swallow " + npcName + " whole. (" + str(cur) + "/" + str(cap) + " " + m + " capacity used)", "do_swallow", [m])
		else:
			addDisabledButton(_methodLabel(m), "Your " + m + " capacity is full (" + str(cur) + "/" + str(cap) + ").")
	if !anyAvailable:
		saynn("You don't have any free vore capacity right now. Unlock or free up a vore method first.")
func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "go_main":
		setState("")
		return
	if _action == "open_swallow":
		setState("swallow")
		return
	if _action == "get_eaten":
		runScene("VoreSlaveBellyRideScene", [npcID])
		return
	if _action == "do_swallow":
		if _args.size() >= 1:
			_doSwallow(str(_args[0]))
		return
	if _action == "open_feed":
		setState("feed")
		return
	if _action == "open_eatslave":
		setState("eatslave")
		return
	if _action == "do_feed":
		if _args.size() >= 1:
			_doFeed(str(_args[0]))
		return
	setState(_action)
func _nearbyPreyIDs() -> Array:
	var result = []
	if GM.main == null or GM.pc == null:
		return result
	var loc = GM.pc.getLocation()
	if loc == "":
		return result
	var ids = GM.main.IS.getPawnIDsNear(loc, 2)
	for pid in ids:
		if pid == "pc":
			continue
		if pid == npcID:
			continue
		var ch = GlobalRegistry.getCharacter(pid)
		if ch == null or !ch.isDynamicCharacter():
			continue
		if ch.hasEffect("VorePredatorBelly"):
			continue
		if ch.hasEffect("VoreSlavePredatorDigesting"):
			continue
		if ch.hasEffect("VoreShrunkNPCPredator"):
			continue
		if !result.has(pid):
			result.append(pid)
	return result
func _otherSlaveIDs() -> Array:
	var result = []
	if GM.main == null:
		return result
	var slaves = GM.main.getDynamicCharacterIDsFromPool(CharacterPool.Slaves)
	for pid in slaves:
		if pid == npcID:
			continue
		var ch = GlobalRegistry.getCharacter(pid)
		if ch == null:
			continue
		if ch.hasEffect("VoreSlavePredatorDigesting"):
			continue
		if ch.hasEffect("VoreShrunkNPCPredator"):
			continue
		if !result.has(pid):
			result.append(pid)
	return result
func _predatorMethod(predator) -> String:
	var methods = ["mouth", "anus", "tail"]
	if predator != null:
		if predator.hasNonFlatBreasts():
			methods.append("breasts")
		if predator.hasPenis():
			methods.append("cock")
		if predator.hasVagina():
			methods.append("vagina")
	return methods[RNG.randi_range(0, methods.size() - 1)]
func _feedPartWord(m: String) -> String:
	match m:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye"
		"ear":     return "ear"
	return "belly"
func _doFeed(preyID: String):
	var predator = GlobalRegistry.getCharacter(npcID)
	var prey = GlobalRegistry.getCharacter(preyID)
	if predator == null or prey == null:
		setState("")
		return
	var preyName = prey.getName() if prey.has_method("getName") else "them"
	var predatorName = predator.getName() if predator.has_method("getName") else npcName
	var m = _predatorMethod(predator)
	var like = 0.0
	var fh = prey.getFetishHolder()
	if fh != null:
		like = fh.getFetishValue("Vore")
	var preyShrinkRemaining = 0.0
	var preyIsShrunk = false
	if prey.hasEffect("VoreSizeChange"):
		var scaleEff = prey.getEffect("VoreSizeChange")
		if scaleEff != null and scaleEff.targetScale < 1.0:
			preyIsShrunk = true
			preyShrinkRemaining = float(scaleEff.durationSeconds)
	if predator.hasEffect("VorePredatorBelly"):
		predator.removeEffect("VorePredatorBelly")
	if preyIsShrunk:
		var preyScaleEff = prey.getEffect("VoreSizeChange")
		if preyScaleEff != null and preyScaleEff.has_method("stop"):
			preyScaleEff.stop()
		predator.addEffect("VoreShrunkNPCPredator", [preyName, preyID, m, preyShrinkRemaining])
	else:
		predator.addEffect("VoreSlavePredatorDigesting", [preyName, preyID, m])
	if GM.main != null and GM.main.IS.hasPawn(preyID):
		GM.main.IS.deletePawn(preyID)
	GM.pc.addSkillExperience("Vore", 15)
	var partWord = _feedPartWord(m)
	var reaction = " " + preyName + " struggles helplessly the whole way down"
	if like >= 0.5:
		reaction = " " + preyName + " goes willingly, moaning as they slide down into " + predatorName + "'s " + partWord
	elif like >= 0.125:
		reaction = " " + preyName + " whimpers, secretly thrilled to end up in " + predatorName + "'s " + partWord
	elif like <= -0.5:
		reaction = " " + preyName + " screams and thrashes, but into " + predatorName + "'s " + partWord + " they go regardless"
	elif like <= -0.125:
		reaction = " " + preyName + " kicks and pleads as " + predatorName + "'s " + partWord + " swallows them up"
	var verb = "swallows them whole"
	match m:
		"breasts": verb = "draws them into their breasts"
		"anus":    verb = "stuffs them up inside their rear"
		"cock":    verb = "draws them down into their balls"
		"vagina":  verb = "draws them up into their womb"
		"tail":    verb = "coils them up inside their tail"
	var shrinkNote = ""
	if preyIsShrunk:
		if preyShrinkRemaining > 0.0:
			shrinkNote = " " + preyName + " is still shrunk, though -- when the effect wears off inside " + predatorName + ", " + predatorName + " won't survive it!"
		else:
			shrinkNote = " " + preyName + " is shrunk permanently, so they'll just stay tucked away inside " + predatorName + " harmlessly."
	addMessage("You shove the captive " + preyName + " toward your slave " + predatorName + ", who eagerly " + verb + "!" + reaction + "." + shrinkNote + " (+15 Vore XP)")
	setState("")
func _doSwallow(m: String):
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		return
	var preyName = character.getName()
	if _currentCount(m) >= _methodCapacity(m):
		addMessage("You can't fit anyone else in there right now.")
		setState("swallow")
		return
	var like = 0.0
	var fh = character.getFetishHolder()
	if fh != null:
		like = fh.getFetishValue("Vore")
	GM.pc.addEffect(VoreSwallowed.effectIDForMethod(m), [preyName, npcID, m])
	GM.pc.addSkillExperience("Vore", 20)
	var preyScale = 1.0
	var preyShrinkDuration = 0.0
	if character.hasEffect("VoreSizeChange"):
		var scaleEff = character.getEffect("VoreSizeChange")
		if scaleEff != null:
			preyScale = scaleEff.targetScale
			preyShrinkDuration = float(scaleEff.durationSeconds)
	if preyScale < 1.0 and preyShrinkDuration > 0.0:
		GM.pc.addEffect("VoreSwallowedShrunk", [preyName, npcID, m, preyShrinkDuration])
	if GM.main != null && GM.main.IS.hasPawn(npcID):
		GM.main.IS.deletePawn(npcID)
	var partWord = "stomach"
	if(m == "breasts"):   partWord = "chest"
	elif(m == "anus"):    partWord = "rear"
	elif(m == "cock"):    partWord = "balls"
	elif(m == "vagina"):  partWord = "womb"
	elif(m == "tail"):    partWord = "tail"
	elif(m == "eye"):     partWord = "eye"
	elif(m == "ear"):     partWord = "ear canal"
	var reaction = " They squirm in your grip"
	if(like >= 0.5):
		reaction = " They melt into you, sighing as they slide down into your " + partWord
	elif(like >= 0.125):
		reaction = " They whine softly, secretly thrilled to end up in your " + partWord
	elif(like <= -0.5):
		reaction = " They thrash and beg in horror, but down into your " + partWord + " they go regardless"
	elif(like <= -0.125):
		reaction = " They kick and protest as your " + partWord + " swallows them up"
	addMessage("You grab " + preyName + " and swallow your slave whole!" + reaction + ". (+20 Vore XP)")
	endScene()
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["npcName"] = npcName
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npcName = SAVE.loadVar(data, "npcName", "them")