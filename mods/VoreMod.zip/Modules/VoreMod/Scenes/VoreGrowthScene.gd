extends "res://Scenes/SceneBase.gd"
var npcID = ""
var npcName = "someone"
var voreMethod = "mouth"
func _init():
	sceneID = "VoreGrowthScene"
func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	if _args.size() > 1:
		npcName = str(_args[1])
	if _args.size() > 2:
		voreMethod = str(_args[2])
func _run():
	if state == "":
		var text1 = ""
		var text2 = ""
		var text3 = ""
		match voreMethod:
			"eye":
				text1 = "A terrible pressure builds behind your eye -- something is [b]growing[/b] inside your ocular cavity!"
				text2 = npcName + " has returned to their normal size while trapped behind your pupil. The stretching is unbearable -- your vision blurs as the socket swells grotesquely, tears streaming down your cheek. You clutch your face in agony as the expanding mass forces your eye socket wider and wider, but it's no use. The pressure becomes blinding, unbearable -- and then, with a wet, sickening crack, your skull gives way."
				text3 = "You collapse to the ground, your body broken from the inside. " + npcName + " steps free at full size, barely scathed, while you lie motionless -- your head shattered by the thing that grew where it should never have been.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"ear":
				text1 = "A muffled pressure deep in your ear becomes a [b]roaring[/b] agony -- something is [b]growing[/b] inside your ear canal!"
				text2 = npcName + " has returned to their normal size while wedged inside your auditory passage. The stretching is excruciating -- your ear canal is forced wider and wider, the pressure building in your skull until you can barely think. You scream, clutching the side of your head as the expanding mass pushes against your eardrum, deeper, wider -- until the bone simply can't take any more."
				text3 = "With a wet, crushing crunch, your skull fractures from within. " + npcName + " tumbles free at full size, shaken but alive. You lie on the ground, your head split open from the inside out, consciousness fading to nothing.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"mouth":
				text1 = "Your stomach lurches violently -- something is [b]growing[/b] inside you!"
				text2 = npcName + " has returned to their normal size while digesting in your stomach. The sudden expansion fills your gut beyond its limit, your belly swelling grotesquely as the tiny prey becomes full-sized. You double over, gasping -- your body can't contain this, the pressure is too much! Your skin stretches, tears -- your abdomen bursts open in a spray of warmth."
				text3 = npcName + " climbs free from your ruined body, stepping over your broken remains. You lie on the ground, your belly split open, everything going dark.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"breasts":
				text1 = "A terrible swelling builds in your chest -- something is [b]growing[/b] inside your breasts!"
				text2 = npcName + " has returned to their normal size while absorbed into your chest. Your breasts swell grotesquely, stretching your skin tight as the tiny prey becomes full-sized inside you. You cry out, clutching your chest as the expansion becomes unbearable -- your skin creaks, veins bulging, until finally the flesh can't hold any more."
				text3 = "Your chest bursts open in a wet spray, and " + npcName + " tumbles free at full size. You crumple to the ground, your torso torn apart, the last thing you feel is the cold floor against your cheek.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"anus":
				text1 = "A terrible pressure builds in your rear -- something is [b]growing[/b] inside your gut!"
				text2 = npcName + " has returned to their normal size while in your digestive tract. The sudden expansion fills you beyond your limit, your gut swelling as the tiny prey becomes full-sized. You gasp and clutch your belly -- the pressure is unbearable! Your body can't stretch fast enough, and the mounting force rips you apart from within."
				text3 = npcName + " forces their way out, your body breaking around them as they emerge at full size. You collapse, your midsection destroyed, consciousness slipping away into nothing.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"cock":
				text1 = "A terrible swelling builds in your shaft -- something is [b]growing[/b] inside your cock!"
				text2 = npcName + " has returned to their normal size while trapped in your member. The sudden expansion stretches you beyond your limit, your cock swelling grotesquely as the tiny prey becomes full-sized. You scream -- a mix of agony and involuntary stimulation -- as the pressure mounts beyond what your body can withstand."
				text3 = "With a wet, agonizing rupture, your groin tears apart and " + npcName + " forces free at full size. You crumple to the ground, your lower body ruined, the world going black around you.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"vagina":
				text1 = "A terrible swelling builds in your womb -- something is [b]growing[/b] inside you!"
				text2 = npcName + " has returned to their normal size while cradled in your womb. The sudden expansion fills you beyond your limit, your belly swelling as if heavily pregnant as the tiny prey becomes full-sized. You gasp and clutch your stomach -- the pressure is too much! Your body tries to birth them but the size is wrong, the force too violent -- flesh tears, and warmth floods out."
				text3 = npcName + " emerges from your ruined body at full size, stepping free as you crumple to the ground. Your lower body is destroyed, everything fading to black.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"tail":
				text1 = "A terrible pressure builds in your tail -- something is [b]growing[/b] inside it!"
				text2 = npcName + " has returned to their normal size while coiled inside your tail. The sudden expansion stretches your tail beyond its limit, the scales pulling apart as the tiny prey becomes full-sized. You hiss in pain as the swelling becomes unbearable -- the bones crack, the flesh rips, and your tail simply explodes from within."
				text3 = npcName + " bursts free from your shattered tail at full size. You collapse, your lower back torn open, the last thing you feel is the warm pool spreading beneath you.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"buttplug":
				text1 = "A terrible pressure builds deep in your rear -- the tiny plug is [b]growing[/b]! You were wearing " + npcName + " as a living buttplug, and now they're coming back to full size inside you!"
				text2 = npcName + " has returned to their normal size while wedged inside your gut like a plug. The sudden expansion stretches you beyond your limit, your belly swelling grotesquely as the tiny living plug becomes full-sized. You double over, gasping -- your body can't contain this, the pressure is unbearable! Your skin stretches, tears -- your abdomen bursts open in a spray of warmth."
				text3 = npcName + " climbs free from your ruined body, stepping over your broken remains. You lie on the ground, your belly split open, everything going dark.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			"vaginalplug":
				text1 = "A terrible swelling builds deep in your womb -- the tiny plug is [b]growing[/b]! You were wearing " + npcName + " as a living vaginal plug, and now they're coming back to full size inside you!"
				text2 = npcName + " has returned to their normal size while stuffed inside your pussy like a plug. The sudden expansion fills you beyond your limit, your belly swelling as if heavily pregnant as the tiny living plug becomes full-sized. You gasp and clutch your stomach -- the pressure is too much! Your body tries to push them out but the size is wrong, the force too violent -- flesh tears, and warmth floods out."
				text3 = npcName + " emerges from your ruined body at full size, stepping free as you crumple to the ground. Your lower body is destroyed, everything fading to black.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
			_:
				text1 = "A terrible pressure builds inside you -- something is [b]growing[/b]!"
				text2 = npcName + " has returned to their normal size while inside your body. The sudden expansion fills you beyond your limit, your body swelling grotesquely as the tiny prey becomes full-sized. You cry out in agony -- the pressure is too much! Your body cannot contain them, and it rips apart from the inside."
				text3 = npcName + " bursts free at full size, stepping over your broken remains. You lie motionless, your body destroyed from within, everything fading to black.\n\nYou have been killed from the inside. You are dead.\n\n[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]"
		saynn(text1)
		saynn("")
		saynn(text2)
		saynn("")
		saynn(text3)
		return
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["npcName"] = npcName
	data["voreMethod"] = voreMethod
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npcName = SAVE.loadVar(data, "npcName", "someone")
	voreMethod = SAVE.loadVar(data, "voreMethod", "mouth")
