extends "res://Scenes/SceneBase.gd"
var uniqueItemID = ""
var item: ItemBase
var targetNPC = null
const STEP = 0.1
const MIN_SCALE = 0.1
const MAX_SCALE = 5.0
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	sceneID = "BodyScaleItemScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
func _reactInit():
	if uniqueItemID == null || uniqueItemID == "":
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
func _getCurrentScale() -> float:
	if targetNPC != null:
		return VoreBodyScaleHelper.getNPCBodyScale(targetNPC)
	return VoreBodyScaleHelper.getCurrentPCScale()
func _applyScale(val: float):
	val = clamp(val, MIN_SCALE, MAX_SCALE)
	if targetNPC != null:
		VoreBodyScaleHelper.applyNPCBodyScale(targetNPC, val)
	else:
		VoreBodyScaleHelper.setPCBodyScale(val)
func _getTargetName() -> String:
	if targetNPC != null:
		if targetNPC.has_method("getName"):
			return targetNPC.getName()
		return "NPC"
	return "yourself"
func _run():
	var current = _getCurrentScale()
	var targetName = _getTargetName()
	saynn("=== Size Adjuster ===")
	saynn("Target: " + targetName)
	saynn("Current body scale: " + str(stepify(current, 0.01)) + "x")
	saynn("")
	saynn("1.0 = normal size")
	saynn("0.5 = half size   |   2.0 = double size")
	saynn("")
	saynn("Enter a value directly, or use the +/- buttons (step: " + str(STEP) + "):")
	var textBox: LineEdit = addTextbox("scale_value")
	textBox.text = str(stepify(current, 0.01))
	var _ok = textBox.connect("text_entered", self, "onEnterPressed")
	addButton("- " + str(STEP), "Decrease size by " + str(STEP), "step_minus")
	addButton("+ " + str(STEP), "Increase size by " + str(STEP), "step_plus")
	addButton("Apply", "Set body scale to entered value", "apply_text")
	addButton("Reset to 1.0", "Restore normal size", "reset_size")
	if targetNPC != null:
		addButton("Switch to: yourself", "Change your own size instead", "switch_to_pc")
	else:
		var npcDollFound = VoreBodyScaleHelper.findAnyNPCDoll()
		if npcDollFound != null:
			var npcName = "NPC"
			var npcChar = npcDollFound.savedCharacterID
			if npcChar != null && npcChar != "pc" && npcChar != GM.pc:
				if !(npcChar is String) && npcChar.has_method("getName"):
					npcName = npcChar.getName()
			addButton("Switch to: " + npcName, "Change NPC size instead", "switch_to_npc")
	addButton("Close", "Done", "endthescene")
func onEnterPressed(_new_text: String):
	GM.main.pickOption("apply_text", [])
func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "switch_to_pc":
		targetNPC = null
		addMessage("Target switched to yourself.")
		setState("")
		return
	if _action == "switch_to_npc":
		var npcDoll = VoreBodyScaleHelper.findAnyNPCDoll()
		if npcDoll != null:
			var npcChar = npcDoll.savedCharacterID
			if !(npcChar is String):
				targetNPC = npcChar
				addMessage("Target switched to " + targetNPC.getName() + ".")
			else:
				var ch = GlobalRegistry.getCharacter(npcChar)
				if ch != null:
					targetNPC = ch
					addMessage("Target switched to " + targetNPC.getName() + ".")
				else:
					addMessage("Could not resolve NPC object.")
		else:
			addMessage("No NPC found in scene.")
		setState("")
		return
	if _action == "reset_size":
		_applyScale(1.0)
		addMessage("Body scale of " + _getTargetName() + " reset to 1.0.")
		setState("")
		return
	if _action == "step_minus":
		var newVal = stepify(_getCurrentScale() - STEP, 0.01)
		_applyScale(newVal)
		addMessage("Body scale set to " + str(stepify(_getCurrentScale(), 0.01)) + "x")
		setState("")
		return
	if _action == "step_plus":
		var newVal = stepify(_getCurrentScale() + STEP, 0.01)
		_applyScale(newVal)
		addMessage("Body scale set to " + str(stepify(_getCurrentScale(), 0.01)) + "x")
		setState("")
		return
	if _action == "apply_text":
		var textInput = getTextboxData("scale_value")
		if !textInput.is_valid_float():
			addMessage("Please enter a valid number (e.g. 1.5 or 0.75).")
			setState("")
			return
		var val = float(textInput)
		if val < MIN_SCALE || val > MAX_SCALE:
			addMessage("Value must be between " + str(MIN_SCALE) + " and " + str(MAX_SCALE) + ".")
			setState("")
			return
		_applyScale(val)
		addMessage("Body scale set to " + str(stepify(val, 0.01)) + "x")
		setState("")
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	return data
func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	if uniqueItemID != null && uniqueItemID != "":
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)