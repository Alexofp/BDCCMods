extends "res://Scenes/SceneBase.gd"
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var uniqueItemID = ""
var item = null
var plugMethod = "anus"
func _init():
	sceneID = "VoreShrunkNpcPlugScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
func _reactInit():
	if uniqueItemID == null or uniqueItemID == "":
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
func _getItem():
	if item != null and is_instance_valid(item):
		return item
	if GM.pc != null and GM.pc.getInventory() != null:
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
	return item
func _npcName() -> String:
	var it = _getItem()
	if it == null or it.npcID == null or it.npcID == "":
		return "the tiny creature"
	var ch = GlobalRegistry.getCharacter(it.npcID)
	if ch != null and ch.has_method("getName"):
		return ch.getName()
	return "the tiny creature"
func _them() -> String:
	var it = _getItem()
	if it == null or it.npcID == null or it.npcID == "":
		return "them"
	var ch = GlobalRegistry.getCharacter(it.npcID)
	if ch != null and ch.has_method("getPronounThem"):
		return ch.getPronounThem()
	return "them"
func _scaleStr() -> String:
	var it = _getItem()
	if it == null or it.npcID == null or it.npcID == "":
		return "0.4x"
	return str(stepify(VoreBodyScaleHelper.getNPCBodyScaleByID(it.npcID), 0.01)) + "x"
func _run():
	var it = _getItem()
	if it == null:
		saynn("The tiny creature seems to have vanished from your pocket.")
		addButton("Huh?", "That's weird.", "endthescene")
		return
	var nname = _npcName()
	var them = _them()
	if state == "":
		if it.plugMode == "" or it.plugMode == null:
			var isVaginal = (plugMethod == "vagina")
			var holeWord = "pussy" if isVaginal else "anus"
			var partWord = "tailhole" if isVaginal else "butt"
			saynn("You reach into your pocket and pull out tiny " + nname + ", holding " + them + " between two fingers. At " + _scaleStr() + " their normal size, " + them + " could fit snugly inside your " + holeWord + " like a living plug -- warm, squirming, and very much alive.")
			saynn("Are you sure you want to push " + them + " into your " + partWord + "?")
			addButton("Insert into your " + holeWord, "Push tiny " + nname + " into your " + partWord + " and wear them as a living plug.", "do_insert")
			addButton("Cancel", "Put " + them + " back -- not right now.", "endthescene")
		else:
			var pluggedHole = "pussy" if it.plugMode == "vagina" else "anus"
			saynn("Tiny " + nname + " is still plugged snugly inside your " + pluggedHole + ", squirming faintly with every move you make. The constant pressure keeps you warm and sensitive.")
			if it.duration > 0:
				saynn("[i]Their shrink effect is still ticking down. If " + them + " grow back to normal size while inside you, they will burst out and kill you.[/i]")
			addButton("Pull out", "Reach inside and pull " + nname + " back out of your " + pluggedHole + ".", "do_pull_out")
			addButton("Leave it in", "Keep " + nname + " plugged inside you for now.", "endthescene")
		return
	if state == "inserted":
		saynn(insertMessage)
		addButton("Continue", "Enjoy the feeling.", "endthescene")
		return
	if state == "pulled_out":
		saynn("You sigh in relief as the tiny squirming pressure leaves you, and tuck " + nname + " back into your pocket.")
		addButton("Continue", "Done.", "endthescene")
		return
var insertMessage = ""
func _doInsert(method: String):
	var it = _getItem()
	if it == null:
		addMessage("The tiny creature seems to have vanished from your pocket.")
		endScene()
		return
	var isVaginal = (method == "vagina")
	var holeWord = "pussy" if isVaginal else "anus"
	var partWord = "tailhole" if isVaginal else "butt"
	var nname = _npcName()
	var them = _them()
	if isVaginal:
		if !GM.pc.hasReachableVagina():
			saynn("You can't use " + nname + " as a vaginal plug -- you don't have a reachable pussy right now.")
			addButton("Never mind", "Put " + them + " back.", "endthescene")
			return
	else:
		if !GM.pc.hasReachableAnus():
			saynn("You can't use " + nname + " as a buttplug -- you don't have a reachable anus right now.")
			addButton("Never mind", "Put " + them + " back.", "endthescene")
			return
	it.plugMode = method
	GM.pc.addEffect("VoreNpcPlug", [nname, it.npcID, method])
	processTime(5 * 60)
	GM.pc.addLust(30)
	insertMessage = "You strip down and position tiny " + nname + " against your " + holeWord + ". " + them + " let out a tiny muffled protest as you push them inside -- your " + partWord + " stretches just enough, and with a soft squelch they slip fully in.\n\n"
	insertMessage += "The sensation is unlike anything rubber could offer: warm, alive, squirming against your most sensitive spots with every little twitch. You feel a pleasant, constant pressure as " + nname + " settles in, a living plug that shifts and writhes with every step you take."
	setState("inserted")
func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return
	var it = _getItem()
	if it == null:
		addMessage("The tiny creature seems to have vanished from your pocket.")
		endScene()
		return
	if _action == "do_insert":
		_doInsert(plugMethod)
		return
	if _action == "do_pull_out":
		var nname = _npcName()
		var method = it.plugMode
		var holeWord = "pussy" if method == "vagina" else "anus"
		it.plugMode = ""
		if GM.pc.hasEffect("VoreNpcPlug"):
			GM.pc.removeEffect("VoreNpcPlug")
		processTime(5 * 60)
		saynn("You reach down and carefully pull tiny " + nname + " back out of your " + holeWord + ", " + _them() + " tumbling into your palm looking thoroughly mussed.")
		setState("pulled_out")
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	data["insertMessage"] = insertMessage
	return data
func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	insertMessage = SAVE.loadVar(data, "insertMessage", "")
	if uniqueItemID != null and uniqueItemID != "":
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
