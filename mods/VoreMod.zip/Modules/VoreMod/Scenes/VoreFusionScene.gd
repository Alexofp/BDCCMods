extends "res://Scenes/SceneBase.gd"
var predID = ""
var predName = "your predator"
func _init():
	sceneID = "VoreFusionScene"
func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])
	if(_args.size() > 1 && str(_args[1]) != ""):
		predName = str(_args[1])
	else:
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predName = predator.getName()
func _run():
	if(state == ""):
		saynn("The sixth day inside " + predName + " dawns - but instead of the end, something far stranger begins.")
		saynn("As the last of your old self comes undone, you do not vanish. " + predName + "'s flesh and yours refuse to stay apart, melting and knitting together into something wholly new. Their strength, their skills, their very shape pour into you as yours pour into them.")
		saynn("When it settles, a single being rises where two once were - carrying the traits, talents and perks of both of you, met in the middle. [b]This fusion is now you.[/b] You take control of the merged creature and carry on.")
		addButton("Continue", "Rise as the fused being", "endthescene")
		return
func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["predID"] = predID
	data["predName"] = predName
	return data
func loadData(data):
	.loadData(data)
	predID = SAVE.loadVar(data, "predID", "")
	predName = SAVE.loadVar(data, "predName", "your predator")
