extends "res://Scenes/SceneBase.gd"
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

var resultText = ""

func _init():
	sceneID = "VoreObjectProbeScene"

func _run():
	if(state == ""):
		playAnimation(StageScene.Solo, "stand")
		saynn("A guard steps into your path and taps a gloved finger against their belt. \"Random search. Hands on the wall, inmate.\"")
		saynn("They pat you down, find nothing in your pockets, and then pull a glove tighter with a snap. \"You lot always think you are clever. Let's see what you are really carrying.\"")
		addButton("Hold still", "Let them search you and pray they find nothing", "do_probe")
		addButton("Clench", "Fight your own body to keep the cargo where it is", "do_clench")
		return
	if(state == "result"):
		saynn(resultText)
		addButton("Continue", "Done", "endthescene")
		return

func _findChance(bonus: float) -> float:
	var eff = VoreObjectHelper.getEffect(GM.pc)
	if(eff == null):
		return 0.0
	var chance = 35.0 + 8.0 * float(eff.totalStored()) + bonus
	if(VoreObjectHelper.hasPerk(GM.pc, VoreObjectHelper.PERK_SMUGGLER)):
		chance -= 25.0
	if(VoreObjectHelper.hasPerk(GM.pc, VoreObjectHelper.PERK_CONTROL)):
		chance -= 10.0
	return max(3.0, chance)

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "do_probe" || _action == "do_clench"):
		var bonus = 0.0
		var flavor = "The guard's fingers push deep, searching every inch of you while you stare at the wall and try to think about anything else."
		if(_action == "do_clench"):
			bonus = -15.0
			flavor = "You lock every muscle you have and hold the cargo in place while they probe you. It is exhausting and humiliating in equal measure."
			GM.pc.addLust(6)
		else:
			GM.pc.addLust(3)
		var eff = VoreObjectHelper.getEffect(GM.pc)
		if(eff == null || eff.totalStored() <= 0):
			resultText = flavor + "\n\nThey find nothing, because there is nothing to find. \"Move along.\""
			setState("result")
			return
		if(RNG.chance(_findChance(bonus))):
			var confiscated = []
			var returned = []
			var entries = eff.getEntries()
			for entry in entries:
				var item = entry["item"]
				if(item == null):
					continue
				if(item.hasTag(ItemTag.Illegal)):
					confiscated.append(item.getVisibleName())
				else:
					returned.append(item.getVisibleName())
			while(eff.totalStored() > 0):
				var currentEntries = eff.getEntries()
				if(currentEntries.size() <= 0):
					break
				var first = currentEntries[0]
				var theItem = first["item"]
				var illegal = theItem != null && theItem.hasTag(ItemTag.Illegal)
				eff.popStoredItem(first["method"], first["index"], !illegal)
			resultText = flavor + "\n\n\"Well well. What do we have here?\" The guard drags your cargo out of you one piece at a time and lines it all up on the floor."
			if(confiscated.size() > 0):
				resultText += "\n\n[color=red]Confiscated:[/color] " + Util.join(confiscated, ", ") + ". \"Contraband. That is going in the incinerator, and you are going on my list.\""
			if(returned.size() > 0):
				resultText += "\n\nThey shove the rest back into your hands with a look of disgust: " + Util.join(returned, ", ") + "."
			GM.pc.addLust(4)
		else:
			resultText = flavor + "\n\nSomehow your body gives nothing away. The guard pulls back, annoyed, and waves you off. \"...Clean. Get out of my sight.\""
			resultText += "\n\nEverything you are carrying stayed exactly where you put it. (+15 Vore XP)"
			GM.pc.addSkillExperience("Vore", 15)
		setState("result")
		return
	setState(_action)

func saveData():
	var data = .saveData()
	data["resultText"] = resultText
	return data

func loadData(data):
	.loadData(data)
	resultText = SAVE.loadVar(data, "resultText", "")
