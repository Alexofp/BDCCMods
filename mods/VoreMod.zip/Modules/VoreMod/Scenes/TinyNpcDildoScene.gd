extends "res://Scenes/SceneBase.gd"
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var isPussy = true
var uniqueItemID = null
func _init():
	sceneID = "TinyNpcDildoScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
	var item = _getItem()
	if item != null and item.npcID != null and item.npcID != "":
		addCharacter(item.npcID)
func _getItem():
	return GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
func _npcScale():
	var item = _getItem()
	if item == null or item.npcID == null or item.npcID == "":
		return 0.4
	return VoreBodyScaleHelper.getNPCBodyScaleByID(item.npcID)
func _play(action, extra = {}):
	var item = _getItem()
	var args = {bodyState = {naked = true}}
	if item != null:
		args["npc"] = item.npcID
	args["npcScale"] = _npcScale()
	args["isPussy"] = isPussy
	for k in extra:
		args[k] = extra[k]
	playAnimation("TinyNpcDildoSex", action, args)
func _npcName() -> String:
	var item = _getItem()
	if item == null or item.npcID == null or item.npcID == "":
		return "the tiny creature"
	var ch = GlobalRegistry.getCharacter(item.npcID)
	if ch != null and ch.has_method("getName"):
		return ch.getName()
	return "the tiny creature"
func _them() -> String:
	var item = _getItem()
	if item == null or item.npcID == null or item.npcID == "":
		return "them"
	var ch = GlobalRegistry.getCharacter(item.npcID)
	if ch != null and ch.has_method("getPronounThem"):
		return ch.getPronounThem()
	return "them"
func _they() -> String:
	var item = _getItem()
	if item == null or item.npcID == null or item.npcID == "":
		return "they"
	var ch = GlobalRegistry.getCharacter(item.npcID)
	if ch != null and ch.has_method("getPronounThey"):
		return ch.getPronounThey()
	return "they"
func _run():
	var item = _getItem()
	if item == null:
		saynn("The tiny creature seems to have vanished from your pocket.")
		addButton("Huh?", "That's weird.", "endthescene")
		return
	var nname = _npcName()
	var them = _them()
	var they = _they()
	if state == "":
		_play("tease")
		saynn("You reach into your pocket and pull out tiny " + nname + ", holding " + them + " between two fingers. At only a fraction of their normal size, " + they + " fit in the palm of your hand with room to spare.")
		saynn("You study " + them + " for a long moment, a slow smile spreading across your face. " + nname + " squirms nervously in your grip, very aware of what that look means.")
		saynn("Which hole do you want to use " + them + " for..")
		addButtonWithChecks("Pussy", "Use " + them + " with your pussy.", "ride_pussy", [], [ButtonChecks.HasReachableVagina])
		addButtonWithChecks("Anus", "Use " + them + " with your butt.", "ride_anus", [], [ButtonChecks.HasReachableAnus])
		addButton("Cancel", "Put " + them + " back -- not right now.", "endthescene")
	if state == "begin_riding":
		_play("inside")
		saynn("You strip down and lift " + nname + " towards your " + ("pussy" if isPussy else "tailhole") + ". " + nname + " lets out a tiny muffled protest as you position " + them + ".")
		saynn("Fitting " + them + " inside your " + ("pussy" if isPussy else "butt") + " is slow and deliberate -- your " + ("slit" if isPussy else "anal ring") + " stretches just enough, every tiny movement sending sharp sparks of sensation through you.")
		addButton("Continue", "See what happens next.", "begin_penetration")
	if state == "begin_penetration":
		_play("sex")
		saynn("With a last firm push you feel " + nname + " slip fully inside you, buried in your " + ("slit" if isPussy else "ass") + ". The sensation is unlike anything rubber could offer -- warm, alive, squirming.")
		saynn("Their tiny movements press right against your most sensitive spots, every helpless twitch sending electric jolts of pleasure through your whole body.")
		if GM.pc.hasPenis():
			saynn("Your {pc.penis} stiffened the moment you started, now twitching and leaking at the sheer thrill of it.")
		if not isPussy and GM.pc.hasReachableVagina():
			saynn("Your neglected pussy clenches around nothing as you squeeze down around " + them + ".")
		saynn("You start moving your hips, using their tiny body for your own pleasure. Soft moans escape you as the helpless squirming only makes it better.")
		saynn("You feel the pleasure building, coiling tight. Almost there..")
		addButton("Cum!", "Use " + them + " until you climax.", "do_cum")
	if state == "do_cum":
		_play("fast", {pcCum = true, bodyState = {naked = true, hard = true}})
		saynn("You bear down harder, grinding and clenching around " + nname + " with increasing urgency, their frantic struggles only feeding your pleasure.")
		if GM.pc.hasPenis():
			saynn("Your whole body arches. A drawn-out moan tears from you as your {pc.penis} pulses and shoots strings of {pc.cum}, your inner walls spasming around " + them + " in a crushing, rhythmic grip.")
		elif GM.pc.hasReachableVagina():
			saynn("Your whole body arches. A loud moan tears from you as your pussy squirts and clenches, gripping " + them + " in a series of violent, ecstatic pulses.")
		else:
			saynn("Your whole body arches. A ragged moan tears from you, every muscle locking up as the orgasm crashes through you.")
		saynn("Your " + ("pussy" if isPussy else "tailhole") + " spasms around " + them + " in the aftershock, squeezing tight before finally relaxing.")
		addButton("Continue", "See what happens next.", "afterglow")
	if state == "afterglow":
		_play("inside")
		saynn("You slump back and catch your breath, blissed out and boneless. After a long lazy moment you reach down and carefully retrieve " + nname + ", who tumbles into your palm looking thoroughly used.")
		saynn("You hold " + them + " up and study " + them + " with half-lidded eyes, still glowing. \"Thanks for your help,\" you murmur, before tucking " + them + " back into your pocket.")
		saynn(nname + " sits dazed in your pocket as you pull your clothes back on.")
		addButton("Continue", "Nice.", "endthescene")
func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "ride_pussy":
		isPussy = true
		setState("begin_riding")
		GM.pc.addLust(50)
		return
	if _action == "ride_anus":
		isPussy = false
		setState("begin_riding")
		GM.pc.addLust(50)
		return
	if _action == "begin_penetration":
		processTime(60 * 5)
		GM.pc.addLust(50)
		if isPussy:
			GM.pc.gotOrificeStretchedWith(BodypartSlot.Vagina, 50)
		else:
			GM.pc.gotOrificeStretchedWith(BodypartSlot.Anus, 50)
		setState(_action)
		return
	if _action == "do_cum":
		processTime(5 * 60)
		if isPussy:
			GM.pc.gotOrificeStretchedWith(BodypartSlot.Vagina, 50)
		else:
			GM.pc.gotOrificeStretchedWith(BodypartSlot.Anus, 50)
		GM.pc.orgasmFrom("pc")
		GM.pc.addSkillExperience("Vore", 10)
		setState(_action)
		return
	if _action == "afterglow":
		processTime(6 * 60)
		setState(_action)
		return
func saveData():
	var data = .saveData()
	data["isPussy"] = isPussy
	data["uniqueItemID"] = uniqueItemID
	return data
func loadData(data):
	.loadData(data)
	isPussy = SAVE.loadVar(data, "isPussy", true)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", null)