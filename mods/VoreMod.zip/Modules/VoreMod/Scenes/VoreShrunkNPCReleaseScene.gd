extends "res://Scenes/SceneBase.gd"
var uniqueItemID = ""
var item = null
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	sceneID = "VoreShrunkNPCReleaseScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
func _reactInit():
	if uniqueItemID == null || uniqueItemID == "":
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
func _run():
	if state == "":
		_runMain()
	elif state == "after_release":
		_runAfterRelease()
func _runMain():
	var charName = "the tiny NPC"
	var npcChar = null
	if item != null and item.npcID != "":
		npcChar = GlobalRegistry.getCharacter(item.npcID)
		if npcChar != null and npcChar.has_method("getName"):
			charName = npcChar.getName()
	var scaleVal = 1.0
	if item != null:
		scaleVal = VoreBodyScaleHelper.getNPCBodyScaleByID(item.npcID)
	var scaleStr = str(stepify(scaleVal, 0.01))
	saynn("You carefully reach into your pocket and scoop out " + charName + ". At " + scaleStr + "x their normal size, they fit comfortably in the palm of your hand. You kneel down and gently set them on the floor.")
	saynn("")
	saynn("They look up at you, blinking as they adjust to the open space.")
	addButton("Set down gently", "Place them carefully on the floor", "do_release_gentle")
	addButton("Just drop them", "Let them go unceremoniously", "do_release_drop")
	addButton("Never mind", "Keep them in your pocket for now", "endthescene")
func _runAfterRelease():
	var charName = "the tiny NPC"
	if item != null and item.npcID != "":
		var npcChar = GlobalRegistry.getCharacter(item.npcID)
		if npcChar != null and npcChar.has_method("getName"):
			charName = npcChar.getName()
	saynn(charName + " stands on the floor at your feet, still shrunken but free from your pocket.")
	var durLeft = 0.0
	if item != null:
		durLeft = item.duration
	if durLeft > 0:
		saynn("The shrink effect still has time remaining -- they'll grow back on their own eventually.")
	else:
		saynn("They look up at you, waiting.")
	addButton("Close", "Done", "endthescene")
func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "do_release_gentle" or _action == "do_release_drop":
		if item == null:
			addMessage("Item not found in inventory.")
			setState("")
			return
		var voreMod = getModule("VoreMod")
		if voreMod != null:
			var gentle = (_action == "do_release_gentle")
			voreMod.releaseNPCFromItem(item, gentle)
		item = null
		setState("after_release")
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	return data
func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	if uniqueItemID != null and uniqueItemID != "":
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
