extends "res://Scenes/SceneBase.gd"
var uniqueItemID = ""
var item: ItemBase
var lastDuration: int = 3600
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	sceneID = "VoreSizeChangePillProgrammedScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
func _reactInit():
	if uniqueItemID == null || uniqueItemID == "":
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
func _durText(seconds: int) -> String:
	if seconds < 0:
		return "permanently (until changed by another pill)"
	return Util.getTimeStringHumanReadable(seconds)
func _run():
	if state == "":
		_runMain()
	elif state == "after_swallow":
		_runAfterSwallow()
func _runMain():
	var targetScale = 1.0
	var durationSeconds = 3600
	if item != null && item.has_method("setTargetScale"):
		targetScale = item.targetScale
		durationSeconds = item.durationSeconds
	var currentScale = VoreBodyScaleHelper.getCurrentPCScale()
	var scaleStr = str(stepify(targetScale, 0.01))
	var currentStr = str(stepify(currentScale, 0.01))
	var durStr = _durText(durationSeconds)
	saynn("=== Programmed Size-Change Pill ===")
	if targetScale < 1.0:
		saynn("You hold a [color=#" + Color.cyan.to_html() + "]shrink pill[/color] programmed to set your body scale to [b]" + scaleStr + "x[/b] for [b]" + durStr + "[/b].")
		saynn("Your current body scale is [b]" + currentStr + "x[/b].")
		saynn("Swallowing this will make you shrink.")
	elif targetScale > 1.0:
		saynn("You hold a [color=#" + Color.red.to_html() + "]growth pill[/color] programmed to set your body scale to [b]" + scaleStr + "x[/b] for [b]" + durStr + "[/b].")
		saynn("Your current body scale is [b]" + currentStr + "x[/b].")
		saynn("Swallowing this will make you grow.")
	else:
		saynn("You hold a [color=#" + Color.green.to_html() + "]reset pill[/color] that will restore your body scale to normal for [b]" + durStr + "[/b].")
		saynn("Your current body scale is [b]" + currentStr + "x[/b].")
	saynn("")
	if durationSeconds < 0:
		saynn("This pill is [b]permanent[/b] -- the size change will not wear off on its own and can only be changed by another size-change pill.")
	else:
		saynn("After the effect wears off, you will return to your normal size.")
	addButton("SWALLOW", "Swallow the pill and change size to " + scaleStr + "x for " + durStr, "swallow")
	addButton("Put away", "Don't use the pill", "endthescene")
func _runAfterSwallow():
	var currentScale = VoreBodyScaleHelper.getCurrentPCScale()
	var currentStr = str(stepify(currentScale, 0.01))
	var targetScale = 1.0
	var durationSeconds = 3600
	if item != null && item.has_method("setTargetScale"):
		targetScale = item.targetScale
		durationSeconds = item.durationSeconds
	else:
		durationSeconds = lastDuration
	var durStr = _durText(durationSeconds)
	if currentScale < 1.0:
		saynn("The pill slides down your throat and a cold tightness races through every limb. Flesh compresses, bones compact, and the world looms larger as you shrink down to " + currentStr + "x normal size.")
	elif currentScale > 1.0:
		saynn("The pill slides down your throat and warmth blooms through every limb. Flesh swells, bones stretch, and the world shrinks around you as you grow to " + currentStr + "x normal size.")
	else:
		saynn("The pill slides down your throat and a wave of normalcy spreads through your body. Everything returns to its natural proportions.")
	saynn("")
	saynn("New body scale: [b]" + currentStr + "x[/b]")
	if durationSeconds < 0:
		saynn("This change is [b]permanent[/b] -- you will stay this size until another size-change pill is used on you.")
	else:
		saynn("The effect will last for [b]" + durStr + "[/b], after which you will return to normal size.")
	addButton("Close", "Done", "endthescene")
func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "swallow":
		var targetScale = 1.0
		var durationSeconds = 3600
		if item != null && item.has_method("setTargetScale"):
			targetScale = item.targetScale
			durationSeconds = item.durationSeconds
		lastDuration = durationSeconds
		GM.pc.addEffect("VoreSizeChange", [targetScale, durationSeconds])
		if item != null:
			item.removeXOrDestroy(1)
			item = null
		setState("after_swallow")
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	data["lastDuration"] = lastDuration
	return data
func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	lastDuration = SAVE.loadVar(data, "lastDuration", 3600)
	if uniqueItemID != null && uniqueItemID != "":
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
