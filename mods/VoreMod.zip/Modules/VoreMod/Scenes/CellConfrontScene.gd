extends "res://Scenes/SceneBase.gd"
const TALK_BASE_CHANCE = 45.0
const TALK_AFFECTION_WEIGHT = 25.0
const TALK_MEANNESS_WEIGHT = 30.0
const RUN_BASE_CHANCE = 55.0
const RUN_HAND_PENALTY = 15.0
const RUN_ARM_PENALTY = 15.0
const RUN_LEG_PENALTY = 20.0
const CONFRONT_TIME = 300
const CELL_INTERIOR = "voremod_cell_interior"
var npcID: String = ""
var npcName: String = "someone"
var reason: String = "owner"
var ownerName: String = ""
var talkChance: float = TALK_BASE_CHANCE
var runChance: float = RUN_BASE_CHANCE
var resultText: String = ""
var resultOutcome: String = "escape"
func _init():
	sceneID = "CellConfrontScene"
func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	if _args.size() > 1:
		reason = str(_args[1])
	if _args.size() > 2:
		ownerName = str(_args[2])
	var character = GlobalRegistry.getCharacter(npcID)
	if character != null and character.has_method("getName"):
		npcName = character.getName()
	_calculateChances()
func _calculateChances():
	var affection: float = 0.0
	if GM.main != null and GM.main.RS != null and npcID != "":
		affection = GM.main.RS.getAffection(npcID, "pc")
	var meanness: float = 0.0
	if npcID != "":
		var character = GlobalRegistry.getCharacter(npcID)
		if character != null:
			var pers = character.getPersonality()
			if pers != null:
				meanness = pers.getStat(PersonalityStat.Mean)
	talkChance = clamp(TALK_BASE_CHANCE + affection * TALK_AFFECTION_WEIGHT - max(meanness, 0.0) * TALK_MEANNESS_WEIGHT, 5.0, 90.0)
	var penalty: float = 0.0
	if GM.pc != null:
		if GM.pc.hasBlockedHands():
			penalty += RUN_HAND_PENALTY
		if GM.pc.hasBoundArms():
			penalty += RUN_ARM_PENALTY
		if GM.pc.hasBoundLegs():
			penalty += RUN_LEG_PENALTY
	runChance = clamp(RUN_BASE_CHANCE - penalty, 5.0, 90.0)
func _introText() -> String:
	if reason == "bystander":
		var theOwner = ownerName
		if theOwner == "":
			theOwner = "someone else"
		return "A voice behind you: \"...the hell are you doing in [b]" + theOwner + "[/b]'s cell?\" It's [b]" + npcName + "[/b], another inmate from down the corridor, and they are standing square in the doorway with their arms folded. No way past them without an answer."
	if reason == "returned":
		return "The cell door slides open. [b]" + npcName + "[/b] is back early -- and finds you elbow-deep in their belongings. They stop dead, then plant themselves in the doorway so you can't slip past."
	if reason == "room":
		return "You are halfway to the door when [b]" + npcName + "[/b] moves. They put themselves between you and the only way out. \"Going somewhere?\""
	return "[b]" + npcName + "[/b] catches you red-handed! Their hand snaps around your wrist and they shove you back against the shelf. \"You've got some nerve.\" They are standing between you and the only way out."
func _run():
	if state == "":
		addCharacter(npcID)
		playAnimation(StageScene.Duo, "stand", {npc = npcID})
		saynn(_introText())
		saynn("Talk your way out, settle it with your fists, or make a dash for the corridor?")
		addButton("Talk your way out", "Roughly " + str(int(round(talkChance))) + "% chance -- depends on how much they like you and how mean they are", "do_talk")
		addButton("Fight", "Throw the first punch and settle it right here", "do_fight")
		addButton("Run for it", "Roughly " + str(int(round(runChance))) + "% chance -- restraints slow you down", "do_run")
		return
	if state == "result":
		saynn(resultText)
		addButton("Continue", "See what happens next", "continue_after_result")
		return
func _react(_action, _args):
	if _action == "do_talk":
		_doTalk()
		return
	if _action == "do_run":
		_doRun()
		return
	if _action == "do_fight":
		resultOutcome = "forced"
		resultText = "You put your fists up. [b]" + npcName + "[/b] does not need a second invitation."
		setState("result")
		return
	if _action == "continue_after_result":
		if resultOutcome == "escape":
			_finish()
		else:
			_startForcedInteraction()
		return
	setState(_action)
func _doTalk():
	if RNG.chance(talkChance):
		resultOutcome = "escape"
		if GM.main != null and GM.main.RS != null:
			GM.main.RS.addAffection(npcID, "pc", -0.05)
		resultText = "[b]" + npcName + "[/b] listens, jaw tight, and finally steps aside. \"Get out of my sight. And don't let me catch you around my cell again.\" You slip out into the corridor."
	else:
		resultOutcome = "forced"
		resultText = "[b]" + npcName + "[/b] does not buy a word of it. \"Right. We are doing this the hard way, then.\" They grab your collar and pull you in."
	setState("result")
func _doRun():
	if RNG.chance(runChance):
		resultOutcome = "escape"
		resultText = "You duck under their arm and bolt. There is shouting behind you, but by the time they reach the corridor you are already around the corner and out of sight."
	else:
		resultOutcome = "forced"
		resultText = "You try to slip past, but [b]" + npcName + "[/b] gets a fistful of your jumpsuit and slams you back into the cell. There is no running now."
	setState("result")
func _clearCellFlags():
	GM.main.setModuleFlag("VoreMod", "cellNpcID", "")
	GM.main.setModuleFlag("VoreMod", "cellNpcName", "")
	GM.main.setModuleFlag("VoreMod", "cellNpcSleeping", false)
	GM.main.setModuleFlag("VoreMod", "cellReturnLocation", "")
func _confrontSpot() -> String:
	var pcLoc = str(GM.pc.getLocation())
	if pcLoc == CELL_INTERIOR or GM.main.getModuleFlag("VoreMod", "cellNpcID", "") != "":
		var returnLoc = str(GM.main.getModuleFlag("VoreMod", "cellReturnLocation", ""))
		if returnLoc != "":
			return returnLoc
		if pcLoc != CELL_INTERIOR:
			return pcLoc
	return pcLoc
func _movePlayerTo(spot: String):
	if str(GM.pc.getLocation()) != spot:
		GM.pc.setLocation(spot)
func _moveNpcTo(spot: String):
	if npcID == "":
		return
	var pawn = GM.main.IS.spawnPawnIfNeeded(npcID)
	if pawn != null:
		pawn.setLocation(spot)
func _finish():
	var spot = _confrontSpot()
	_movePlayerTo(spot)
	_moveNpcTo(spot)
	_clearCellFlags()
	processTime(CONFRONT_TIME)
	endScene()
	GM.main.reRun()
func _startForcedInteraction():
	var spot = _confrontSpot()
	_movePlayerTo(spot)
	_clearCellFlags()
	_moveNpcTo(spot)
	GM.main.IS.spawnPawnIfNeeded("pc")
	processTime(CONFRONT_TIME)
	endScene()
	GM.main.IS.startInteraction("GenericAttack", {starter = npcID, reacter = "pc"})
	GM.main.reRun()
func supportsShowingPawns() -> bool:
	return true
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["npcName"] = npcName
	data["reason"] = reason
	data["ownerName"] = ownerName
	data["resultOutcome"] = resultOutcome
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npcName = SAVE.loadVar(data, "npcName", "someone")
	reason = SAVE.loadVar(data, "reason", "owner")
	ownerName = SAVE.loadVar(data, "ownerName", "")
	resultOutcome = SAVE.loadVar(data, "resultOutcome", "escape")
	_calculateChances()
