extends "res://Scenes/SceneBase.gd"
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
var preyID    = ""
var preyName  = "your prey"
var voreMethod = "mouth"
var arousalLevel = 0.0
const CLIMAX_THRESHOLD = 70.0
func _init():
	sceneID = "VoreSexScene"
func _initScene(_args = []):
	if(_args.size() > 0):
		preyID = str(_args[0])
	var effect = _getVoreEffect()
	if(effect != null):
		preyName   = effect.getNameForID(preyID)
		voreMethod = effect.getSwallowMethodForID(preyID)
func _getVoreEffect():
	if(GM.pc == null):
		return null
	return VoreSwallowed.getEffectForID(GM.pc, preyID)
func _partWord():
	match voreMethod:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "groin"
		"vagina":  return "womb"
		"tail":    return "tail"
	return "belly"
func _preyVoreLike() -> float:
	var character = GlobalRegistry.getCharacter(preyID)
	if(character == null):
		return 0.0
	var fh = character.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")
func _arousalBar() -> String:
	var filled = int(round(arousalLevel / 10.0))
	var bar = "["
	for i in range(10):
		bar += "#" if i < filled else "."
	bar += "]"
	return bar
func _run():
	var effect = _getVoreEffect()
	var part = _partWord()
	if(state == ""):
		if(effect == null || !effect.swallowedIDs.has(preyID)):
			saynn("There's no one inside you to enjoy right now.")
			addButton("Back", "Get up", "endthescene")
			return
		playAnimation(StageScene.Solo, "sit")
		var like = _preyVoreLike()
		saynn("You settle down and get comfortable, both hands resting on your full, gently shifting " + part + " where " + preyName + " is held.")
		if(like >= 0.5):
			saynn(preyName + " grinds and writhes against your insides on purpose, clearly loving every second of being your plaything. Each deliberate squirm sends a jolt of heat through you.")
		elif(like >= 0.125):
			saynn(preyName + " squirms shyly inside you, and you can tell they don't entirely hate the attention.")
		elif(like <= -0.5):
			saynn(preyName + " bucks and pounds against your walls in helpless protest -- and the desperate struggling only winds you up more.")
		else:
			saynn(preyName + " shifts uncomfortably inside you as you start to play with your " + part + ".")
		saynn("Arousal: " + _arousalBar() + "  " + str(int(arousalLevel)) + "%")
		addButton("Fondle", "Slowly knead and fondle your " + part, "do_fondle")
		addButton("Grind", "Grind against the prey trapped inside you", "do_grind")
		addButton("Whisper", "Tease " + preyName + " about their helpless situation", "do_whisper")
		if(arousalLevel >= CLIMAX_THRESHOLD):
			addButton("Climax", "Let yourself finish", "do_climax")
		else:
			addDisabledButton("Climax", "You're not worked up enough yet (need " + str(int(CLIMAX_THRESHOLD)) + "%)")
		addButton("Spit out", "Spit " + preyName + " back out and end this", "spit_out")
		addButton("Stop", "Stop and get up", "endthescene")
		return
	if(state == "climaxed"):
		playAnimation(StageScene.Solo, "sit")
		saynn("Pleasure crashes over you in waves. You clutch your " + part + " tight as you ride out the orgasm, " + preyName + " squirming helplessly through the whole thing.")
		saynn("You slump back, satisfied and warm, your prey still sealed snugly inside you.")
		addButton("Continue", "Catch your breath", "after_climax")
		return
	if(state == "spit_done"):
		playAnimation(StageScene.Solo, "stand")
		saynn("You heave and let " + preyName + " come tumbling back out, slick and gasping, dumped onto the floor in front of you.")
		addButton("Continue", "Done", "endthescene")
		return
func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	var like = _preyVoreLike()
	var likeBonus = 1.0 + abs(like) * 0.5
	if(_action == "do_fondle"):
		arousalLevel = min(100.0, arousalLevel + 12.0 * likeBonus)
		GM.pc.addArousal(0.08)
		GM.pc.addSkillExperience("Vore", 4)
		setState("")
		return
	if(_action == "do_grind"):
		arousalLevel = min(100.0, arousalLevel + 18.0 * likeBonus)
		GM.pc.addArousal(0.12)
		GM.pc.addSkillExperience("Vore", 5)
		setState("")
		return
	if(_action == "do_whisper"):
		arousalLevel = min(100.0, arousalLevel + 9.0 * likeBonus)
		GM.pc.addArousal(0.05)
		GM.pc.addSkillExperience("Vore", 4)
		setState("")
		return
	if(_action == "do_climax"):
		GM.pc.orgasmFrom("pc")
		GM.pc.addLust(-40)
		arousalLevel = 0.0
		GM.pc.addSkillExperience("Vore", 25)
		setState("climaxed")
		return
	if(_action == "after_climax"):
		setState("")
		return
	if(_action == "spit_out"):
		var effect = _getVoreEffect()
		if(effect != null):
			effect.releaseNPC(preyID)
		setState("spit_done")
		return
	setState(_action)
func supportsShowingPawns() -> bool:
	return true
func saveData():
	var data = .saveData()
	data["preyID"]       = preyID
	data["preyName"]     = preyName
	data["voreMethod"]   = voreMethod
	data["arousalLevel"] = arousalLevel
	return data
func loadData(data):
	.loadData(data)
	preyID       = SAVE.loadVar(data, "preyID", "")
	preyName     = SAVE.loadVar(data, "preyName", "your prey")
	voreMethod   = SAVE.loadVar(data, "voreMethod", "mouth")
	arousalLevel = SAVE.loadVar(data, "arousalLevel", 0.0)