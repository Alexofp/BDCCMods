extends "res://Scenes/SceneBase.gd"


var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")

const ESCAPE_THRESHOLD = 0.5

var predID = ""
var predName = "your predator"
var failedAttempts = 0

var awaitingFate = false
var swallowed = false

var _mgScore = 0.0
var _mgFailedHard = false
var _mgInstant = false

func _init():
	sceneID = "PlayerEatenScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])

	var fromDefeat = false
	if(_args.size() > 1):
		fromDefeat = bool(_args[1])

	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()
		if(GM.main != null):
			var _p = GM.main.IS.spawnPawnIfNeeded(predID)

	if(fromDefeat):
		awaitingFate = true
		swallowed = false
		_dragPlayerOff()
	else:
		awaitingFate = false
		swallowed = true
		_applyBelly()

func _dragPlayerOff():
	if(GM.pc == null):
		return
	var startRoom = GM.pc.getLocation()
	var destRoom = _pickAdjacentRoom(startRoom)
	if(destRoom == "" || destRoom == null):
		destRoom = startRoom
	GM.pc.setLocation(destRoom)
	if(GM.main != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.setLocation(destRoom)

func _pickAdjacentRoom(fromRoom) -> String:
	if(GM.world == null || fromRoom == null || fromRoom == ""):
		return ""
	var dirs = [GameWorld.Direction.NORTH, GameWorld.Direction.SOUTH, GameWorld.Direction.EAST, GameWorld.Direction.WEST]
	dirs.shuffle()
	for d in dirs:
		if(GM.world.canGoID(fromRoom, d)):
			var newRoom = GM.world.applyDirectionID(fromRoom, d)
			if(newRoom != null && newRoom != "" && newRoom != fromRoom):
				return newRoom
	return ""

func _applyBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		predator.addEffect("VorePredatorBelly", [GM.pc.getName()])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.setLocation(GM.pc.getLocation())

func _predatorRoom() -> String:
	if(GM.main == null):
		return ""
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn == null):
		return ""
	return pawn.getLocation()

func _wanderPredator():
	if(GM.main == null || GM.world == null):
		return
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn == null):
		return
	var room = pawn.getLocation()
	var dirs = [GameWorld.Direction.NORTH, GameWorld.Direction.SOUTH, GameWorld.Direction.EAST, GameWorld.Direction.WEST]
	dirs.shuffle()
	for d in dirs:
		if(GM.world.canGoID(room, d)):
			var newRoom = GM.world.applyDirectionID(room, d)
			if(newRoom != null && newRoom != "" && newRoom != room):
				pawn.setLocation(newRoom)
				return

func _run():
	if(state == "" && awaitingFate && !swallowed):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			saynn("Your captor is nowhere to be found. You scramble back to your feet, free.")
			addButton("Continue", "Get up", "endthescene")
			return

		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})

		var roomObj = null
		if(room != "" && GM.world != null):
			roomObj = GM.world.getRoomByID(room)
		if(roomObj != null):
			saynn("Beaten and unable to fight back, you are slung over " + predName + "'s shoulder and hauled away. When the world stops spinning you find yourself in [b]" + roomObj.getName() + "[/b], somewhere quiet and out of the way.")
		else:
			saynn("Beaten and unable to fight back, you are slung over " + predName + "'s shoulder and hauled away somewhere quiet and out of the way.")

		var like = 0.0
		var fh = predator.getFetishHolder()
		if(fh != null):
			like = fh.getFetishValue("Vore")
		if(like >= 0.5):
			saynn(predName + " looms over you, licking their lips hungrily. There's no mistaking what they intend to do with you...")
		elif(like >= 0.125):
			saynn(predName + " looks you over with a hungry little grin, clearly weighing whether to gulp you down...")
		else:
			saynn(predName + " stands over you, deciding what to do with their helpless prize...")

		saynn("[i]What happens next?[/i]")
		addButton("Get swallowed whole", "Let " + predName + " open wide and gulp you down whole. You'll end up inside them.", "do_swallow_pc")
		addButton("Beg and squirm free", "Plead and thrash - maybe " + predName + " will lose interest and let you go.", "defeat_release")
		return

	if(state == ""):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			saynn("Your predator is nowhere to be found. You spill back out into the open, free.")
			addButton("Continue", "Get up", "endthescene")
			return

		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})

		saynn("You are sealed inside " + predName + ", curled up in the hot, churning dark of their belly. There's no seeing out - all you can do is feel every step they take.")
		var roomObj = null
		if(room != "" && GM.world != null):
			roomObj = GM.world.getRoomByID(room)
		if(roomObj != null):
			saynn("Right now " + predName + " is lazily wandering around [b]" + roomObj.getName() + "[/b], their swollen belly swaying with you inside it.")
		else:
			saynn(predName + " carries you along, their swollen belly swaying with you inside it.")

		if(failedAttempts > 0):
			saynn("[i]Your previous struggles have left them a little careless - your next escape attempt will be easier.[/i]")

		addButton("Wait inside", "Stay put and watch where " + predName + " wanders next", "wait_inside")
		addButton("Struggle", "Fight and squirm to try to force your way back out (timing minigame)", "do_struggle")
		return

	if(state == "minigame"):
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("playereaten_minigame", game)
		game.setDifficulty(_calcDifficulty())
		game.connect("minigameCompleted", self, "onEscapeMinigameDone")
		return

	if(state == "escaped"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("With one last desperate heave you force the muscles open and spill out of " + predName + " in a slick, gasping heap!")
		saynn(predName + " staggers, utterly spent from the effort of holding you, and collapses to the floor to rest - just like after a lost fight.")
		addButton("Continue", "Catch your breath", "endthescene")
		return

	if(state == "released"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		saynn("You thrash, plead and make such a miserable nuisance of yourself that " + predName + " huffs in annoyance and shoves you away. Not worth the trouble. You scramble free and get out of there.")
		addButton("Continue", "Get out of here", "endthescene")
		return

func _calcDifficulty():
	var diff = 5 - failedAttempts
	if(diff < 2):
		diff = 2
	return diff

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "do_swallow_pc"):
		swallowed = true
		awaitingFate = false
		_applyBelly()
		if(GM.main != null):
			GM.main.processTime(RNG.randi_range(5, 15) * 60)
			GM.main.addMessage(predName + " opens wide and gulps you down whole! You slide into their belly with a heavy, wet gulp, and it bulges out around you.")
		setState("")
		return

	if(_action == "defeat_release"):
		setState("released")
		return

	if(_action == "wait_inside"):
		_wanderPredator()
		if(GM.main != null):
			GM.main.processTime(15 * 60)
		setState("")
		return

	if(_action == "do_struggle"):
		setState("minigame")
		return

	if(_action == "resolve_escape"):
		var success = _mgInstant || (!_mgFailedHard && _mgScore >= ESCAPE_THRESHOLD)
		if(success):
			_doEscape()
			setState("escaped")
		else:
			failedAttempts += 1
			if(GM.main != null):
				GM.main.addMessage("You thrash and push, but " + predName + "'s body holds firm. You'll have to try again.")
				GM.main.processTime(10 * 60)
			setState("")
		return

	setState(_action)

func _doEscape():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	var room = _predatorRoom()
	if(GM.main != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.makeExhausted()   # predator collapses and rests, like after a fight
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)

func onEscapeMinigameDone(result):
	_mgScore = result.score
	_mgFailedHard = result.failedHard
	_mgInstant = result.instantUnlock
	GM.main.pickOption("resolve_escape", [])

func supportsShowingPawns() -> bool:
	return true

func saveData():
	var data = .saveData()
	data["predID"]         = predID
	data["predName"]       = predName
	data["failedAttempts"] = failedAttempts
	data["awaitingFate"]   = awaitingFate
	data["swallowed"]      = swallowed
	return data

func loadData(data):
	.loadData(data)
	predID         = SAVE.loadVar(data, "predID", "")
	predName       = SAVE.loadVar(data, "predName", "your predator")
	failedAttempts = SAVE.loadVar(data, "failedAttempts", 0)
	awaitingFate   = SAVE.loadVar(data, "awaitingFate", false)
	swallowed      = SAVE.loadVar(data, "swallowed", true)
