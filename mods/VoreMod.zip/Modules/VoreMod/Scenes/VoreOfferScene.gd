extends "res://Scenes/SceneBase.gd"
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
var npcID = ""
var npcName = "them"
var npcLike = 0.0
var proposedMethod = ""     
var swallowMessage = ""
func _init():
	sceneID = "VoreOfferScene"
func _initScene(_args = []):
	if(_args.size() > 0):
		npcID = str(_args[0])
	var ch = GlobalRegistry.getCharacter(npcID)
	if(ch != null):
		npcName = ch.getName()
		var fh = ch.getFetishHolder()
		if(fh != null):
			npcLike = fh.getFetishValue("Vore")
	if(GM.main != null && GM.pc != null):
		GM.main.IS.spawnPawnIfNeeded(npcID)
		var pawn = GM.main.IS.getPawn(npcID)
		if(pawn != null):
			pawn.setLocation(GM.pc.getLocation())
func _playerCapacity(m: String) -> int:
	var h = GM.pc.getSkillsHolder()
	var c = 0
	if(m == "mouth"):
		if(h.hasPerk("VoreInitiate")):    c += 1
		if(h.hasPerk("VoreExpansionV2")): c += 1
		if(h.hasPerk("VoreExpansionV3")): c += 1
	elif(m == "breasts"):
		if(h.hasPerk("VoreBreastsInitiate")):    c += 1
		if(h.hasPerk("VoreBreastsExpansionV2")): c += 1
		if(h.hasPerk("VoreBreastsExpansionV3")): c += 1
	elif(m == "anus"):
		if(h.hasPerk("VoreAnusInitiate")):    c += 1
		if(h.hasPerk("VoreAnusExpansionV2")): c += 1
		if(h.hasPerk("VoreAnusExpansionV3")): c += 1
	elif(m == "cock"):
		if(h.hasPerk("VoreCockInitiate")):    c += 1
		if(h.hasPerk("VoreCockExpansionV2")): c += 1
		if(h.hasPerk("VoreCockExpansionV3")): c += 1
	elif(m == "vagina"):
		if(h.hasPerk("VoreVaginaInitiate")):    c += 1
		if(h.hasPerk("VoreVaginaExpansionV2")): c += 1
		if(h.hasPerk("VoreVaginaExpansionV3")): c += 1
	elif(m == "tail"):
		if(h.hasPerk("VoreTailInitiate")):    c += 1
		if(h.hasPerk("VoreTailExpansionV2")): c += 1
		if(h.hasPerk("VoreTailExpansionV3")): c += 1
	return c
func _playerCurrentCount(m: String) -> int:
	return VoreSwallowed.countForMethod(GM.pc, m)
func _playerAvailableMethods() -> Array:
	var result = []
	if(GM.pc == null):
		return result
	for m in ["mouth", "breasts", "anus", "cock", "vagina", "tail"]:
		if(_playerCapacity(m) > 0 and _playerCurrentCount(m) < _playerCapacity(m)):
			result.append(m)
	return result
func _playerMethodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow whole (mouth)"
		"breasts": return "Absorb into breasts"
		"anus":    return "Absorb into rear"
		"cock":    return "Devour with cock"
		"vagina":  return "Take into womb"
		"tail":    return "Coil up in tail"
	return "Swallow"
func _npcAvailableMethods() -> Array:
	var ch = GlobalRegistry.getCharacter(npcID)
	var methods = ["mouth", "anus", "tail"]
	if(ch != null):
		if(ch.hasNonFlatBreasts()):
			methods.append("breasts")
		if(ch.hasPenis()):
			methods.append("cock")
		if(ch.hasVagina()):
			methods.append("vagina")
	return methods
func _npcMethodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallowed whole"
		"breasts": return "Into the breasts"
		"anus":    return "Up the rear"
		"cock":    return "Into the cock"
		"vagina":  return "Into the womb"
		"tail":    return "Coiled up in tail"
	return "Swallowed whole"
func _npcMethodDesc(m: String) -> String:
	match m:
		"mouth":   return "Get gulped straight down into " + npcName + "'s belly"
		"breasts": return "Get drawn and absorbed into " + npcName + "'s breasts"
		"anus":    return "Get stuffed up into " + npcName + "'s guts"
		"cock":    return "Get drawn down into " + npcName + "'s balls"
		"vagina":  return "Get drawn up into " + npcName + "'s womb"
		"tail":    return "Get coiled up and swallowed into " + npcName + "'s tail"
	return "Get gulped down whole"
func _npcPartWord(m: String) -> String:
	match m:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
	return "belly"
func _pickLine(lines: Array) -> String:
	return lines[RNG.randi_range(0, lines.size() - 1)]
func _approachLine() -> String:
	if(npcLike >= 0.5):
		return _pickLine([
			npcName + " sidles up to you with a hungry gleam in their eyes, one hand resting on their own belly as they look you over.",
			npcName + " blocks your path, practically vibrating with excitement. Their gaze keeps dropping to your middle.",
		])
	if(npcLike >= 0.2):
		return _pickLine([
			npcName + " walks up to you, glancing around to make sure nobody is paying attention.",
			npcName + " falls into step beside you, wearing an oddly eager expression.",
		])
	return _pickLine([
		npcName + " hesitantly approaches you, fidgeting with their hands.",
		npcName + " shuffles over to you, looking both nervous and curious.",
	])
func _offerLine() -> String:
	if(npcLike >= 0.5):
		return _pickLine([
			npcName + " leans in and murmurs, \"I've been watching you. I want you inside me -- or me inside you. Your call.\"",
			npcName + " grins. \"Let's cut the small talk. You can swallow me, or I can swallow you. What do you say?\"",
		])
	if(npcLike >= 0.2):
		return _pickLine([
			npcName + " speaks low and fast: \"I... I've been curious about this whole vore thing. Would you swallow me? Or... let me swallow you instead?\"",
			npcName + " asks, \"How about you and I try something unusual? I'll take you in, or you take me in. Interested?\"",
		])
	return _pickLine([
		npcName + " mumbles, \"Look, this is weird, but... what if you swallowed me? Or I swallowed you? Just... think about it.\"",
		npcName + " clears their throat awkwardly. \"I don't even know why I'm asking this, but... want to try vore with me? Either way?\"",
	])
func _acceptPredatorLine() -> String:
	if(npcLike >= 0.5):
		return _pickLine([
			npcName + " beams and tips their head back, baring their throat for you. \"Yes. Take me.\"",
			npcName + " shivers with anticipation. \"I can't wait to be part of you.\"",
		])
	if(npcLike >= 0.2):
		return _pickLine([
			npcName + " takes a steadying breath. \"Alright. I'm yours. Do it.\"",
			npcName + " nods nervously, eyes wide. \"Okay. I trust you.\"",
		])
	return _pickLine([
		npcName + " swallows hard and nods. \"Okay... go on then.\"",
		npcName + " closes their eyes and waits, trembling slightly. \"Do it.\"",
	])
func _acceptPreyLine() -> String:
	if(npcLike >= 0.5):
		return _pickLine([
			npcName + " licks their lips and steps closer, sizing you up like a meal. \"You won't regret this.\"",
			npcName + " cracks their knuckles and grins down at you. \"Come here, little one.\"",
		])
	if(npcLike >= 0.2):
		return _pickLine([
			npcName + " looks you over with growing hunger. \"Are you sure? ...Alright. Don't struggle too much.\"",
			npcName + " takes a deep breath. \"Okay. I've always wondered what it'd be like...\"",
		])
	return _pickLine([
		npcName + " gives you an uncertain look. \"If you say so... here goes nothing.\"",
		npcName + " hesitates, then reaches for you. \"I hope this doesn't hurt too much.\"",
	])
func _refuseLine() -> String:
	if(npcLike >= 0.5):
		return _pickLine([
			npcName + " shrugs, hiding their disappointment behind a grin. \"Suit yourself. The offer stands if you change your mind.\"",
			npcName + " laughs it off. \"Fair enough. Maybe another time.\"",
		])
	return _pickLine([
		npcName + " deflates a little but nods. \"Right. Forget I said anything.\"",
		npcName + " backs off quickly. \"Yeah, that's... that's fine. Bye.\"",
	])
func _proposeLine(direction: String, method: String) -> String:
	var part = _npcPartWord(method)
	if(direction == "predator"):
		if(npcLike >= 0.5):
			return _pickLine([
				npcName + " pats their " + part + " meaningfully. \"I want to end up in your " + part + ". Please.\"",
				npcName + " whispers, \"Use your " + part + " for me. I want to feel it.\"",
			])
		return _pickLine([
			npcName + " says quietly, \"If it's all the same to you... I'd like to go in through your " + part + ".\"",
			npcName + " suggests, \"Your " + part + " looks like a nice place to end up.\"",
		])
	if(npcLike >= 0.5):
		return _pickLine([
			npcName + " smirks. \"I know exactly where I want you -- my " + part + ".\"",
			npcName + " rumbles, \"You're going in my " + part + ". No arguments.\"",
		])
	return _pickLine([
		npcName + " says hopefully, \"If I get to choose... I'd like to keep you in my " + part + ".\"",
		npcName + " pats their " + part + ". \"This is where you'll end up, if that's okay.\"",
	])
func _letPlayerChooseLine(direction: String) -> String:
	if(direction == "predator"):
		return _pickLine([
			npcName + " shrugs. \"It's your body -- you decide how to take me.\"",
			npcName + " offers, \"Take me however you like best.\"",
		])
	return _pickLine([
		npcName + " shrugs. \"It's your body -- tell me how you want to go in.\"",
		npcName + " gestures at themselves. \"Pick the way in. I'll follow your lead.\"",
	])
func _run():
	if(GM.pc == null):
		endScene()
		return
	if(state == ""):
		var ch = GlobalRegistry.getCharacter(npcID)
		if(ch == null):
			saynn(npcName + " got called away before they could say anything.")
			addButton("Continue", "Move along", "endthescene")
			return
		addCharacter(npcID)
		playAnimation(StageScene.Duo, "stand", {pc = "pc", npc = npcID})
		saynn(_approachLine())
		saynn(_offerLine())
		var methods = _playerAvailableMethods()
		if(methods.size() > 0):
			addButton("Swallow " + npcName, "Agree to take " + npcName + " in and devour them whole", "pick_predator")
		else:
			addDisabledButton("Swallow " + npcName, "You don't have any vore skill unlocked yet.")
		addButton("Let " + npcName + " swallow you", "Agree to be devoured by " + npcName, "pick_prey")
		addButton("Refuse", "Turn " + npcName + " down and walk away", "refuse")
		return
	if(state == "predator"):
		var ch = GlobalRegistry.getCharacter(npcID)
		if(ch == null):
			saynn(npcName + " slipped away while you were thinking.")
			addButton("Continue", "Move along", "endthescene")
			return
		addCharacter(npcID)
		playAnimation(StageScene.Duo, "stand", {pc = "pc", npc = npcID})
		saynn(_acceptPredatorLine())
		var methods = _playerAvailableMethods()
		if(methods.size() <= 0):
			saynn("...but you realize you can't actually do it -- you lack the skill.")
			addButton("Back off", "Step back and apologize", "back")
			return
		if(proposedMethod != "" and methods.has(proposedMethod)):
			saynn(_proposeLine("predator", proposedMethod))
			addButton(_playerMethodLabel(proposedMethod), "Take " + npcName + " in this way", "do_swallow", [proposedMethod])
			for m in methods:
				if(m == proposedMethod):
					continue
				addButton(_playerMethodLabel(m), "Take " + npcName + " in this way instead", "do_swallow", [m])
		else:
			saynn(_letPlayerChooseLine("predator"))
			for m in methods:
				addButton(_playerMethodLabel(m), "Take " + npcName + " in this way", "do_swallow", [m])
		addButton("Change your mind", "Step back and reconsider", "back")
		return
	if(state == "prey"):
		var ch = GlobalRegistry.getCharacter(npcID)
		if(ch == null):
			saynn(npcName + " slipped away while you were thinking.")
			addButton("Continue", "Move along", "endthescene")
			return
		addCharacter(npcID)
		playAnimation(StageScene.Duo, "stand", {pc = "pc", npc = npcID})
		saynn(_acceptPreyLine())
		if(proposedMethod != "" and _npcAvailableMethods().has(proposedMethod)):
			saynn(_proposeLine("prey", proposedMethod))
			addButton(_npcMethodLabel(proposedMethod), _npcMethodDesc(proposedMethod), "start_belly", [proposedMethod])
			addButton("Let " + npcName + " choose", "Let " + npcName + " decide how to take you in", "start_belly_picker")
		else:
			saynn(_letPlayerChooseLine("prey"))
			addButton("Choose how", "Decide how " + npcName + " takes you in", "start_belly_picker")
		addButton("Change your mind", "Step back and reconsider", "back")
		return
	if(state == "swallowed"):
		playAnimation(StageScene.Solo, "stand")
		saynn(swallowMessage)
		addButton("Continue", "Let the digestion begin", "endthescene")
		return
	if(state == "refused"):
		saynn(_refuseLine())
		addButton("Walk away", "Leave " + npcName + " behind", "endthescene")
		return
func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "back"):
		proposedMethod = ""
		setState("")
		return
	if(_action == "pick_predator"):
		proposedMethod = _rollProposal(_playerAvailableMethods().duplicate())
		setState("predator")
		return
	if(_action == "pick_prey"):
		proposedMethod = _rollProposal(_npcAvailableMethods().duplicate())
		setState("prey")
		return
	if(_action == "refuse"):
		setState("refused")
		return
	if(_action == "do_swallow"):
		if(_args.size() > 0):
			_doSwallowNPC(str(_args[0]))
		return
	if(_action == "start_belly"):
		if(_args.size() > 0):
			runScene("VoreBellyRideScene", [npcID, str(_args[0])])
		return
	if(_action == "start_belly_picker"):
		runScene("VoreBellyRideScene", [npcID, ""])
		return
func _react_scene_end(_tag, _result):
	endScene()
func _rollProposal(methods: Array) -> String:
	if(methods.size() <= 0):
		return ""
	if(RNG.randi_range(1, 100) <= 60):
		methods.shuffle()
		return str(methods[0])
	return ""
func _doSwallowNPC(method: String):
	if(GM.pc == null):
		endScene()
		return
	if(_playerCurrentCount(method) >= _playerCapacity(method)):
		saynn("You can't fit " + npcName + " in there right now.")
		setState("predator")
		return
	var ch = GlobalRegistry.getCharacter(npcID)
	var preyName = npcName
	if(ch != null):
		preyName = ch.getName()
	GM.pc.addEffect(VoreSwallowed.effectIDForMethod(method), [preyName, npcID, method])
	GM.pc.addSkillExperience("Vore", 20)
	if(GM.main != null and GM.main.IS.hasPawn(npcID)):
		GM.main.IS.deletePawn(npcID)
	removeCharacter(npcID)
	var partWord = _npcPartWord(method)
	var reaction = ""
	if(npcLike >= 0.5):
		reaction = " They eagerly let you do it, shivering with delight as they slip into your " + partWord + "."
	elif(npcLike >= 0.125):
		reaction = " They put up only a token protest, secretly thrilled to end up in your " + partWord + "."
	elif(npcLike <= -0.5):
		reaction = " They thrash and beg in horror, but down into your " + partWord + " they go regardless."
	elif(npcLike <= -0.125):
		reaction = " They squirm in discomfort as your " + partWord + " swallows them up."
	else:
		reaction = " They watch their own body disappear into your " + partWord + " with wide, wondering eyes."
	swallowMessage = "You swallow " + preyName + " whole!" + reaction + " (+20 Vore XP)"
	setState("swallowed")