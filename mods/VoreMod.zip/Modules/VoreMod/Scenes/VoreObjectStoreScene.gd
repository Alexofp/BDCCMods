extends "res://Scenes/SceneBase.gd"
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

var uniqueItemID = ""
var item = null
var lastText = ""

func _init():
	sceneID = "VoreObjectStoreScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		uniqueItemID = _args[0]

func _reactInit():
	if(uniqueItemID == null || uniqueItemID == ""):
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)

func _run():
	if(state == "stored"):
		saynn(lastText)
		addButton("Continue", "Done", "endthescene")
		return
	if(item == null):
		saynn("That item is not in your hands anymore.")
		addButton("Close", "Done", "endthescene")
		return
	var itemName = item.getVisibleName()
	saynn("You weigh " + itemName + " in your hands and consider where nobody would ever think to look for it.")
	if(item.hasTag(ItemTag.Illegal)):
		saynn("[color=red]This one is illegal - exactly the sort of thing worth hiding inside you.[/color]")
	if(item.addsIntoxication() > 0.0):
		saynn("[color=#ff8800]Careful: this is a drug. If the casing gives out inside you, the whole dose goes off at once.[/color]")
	saynn("Where do you want to put it?")
	for m in VoreObjectHelper.METHODS:
		var cap = VoreObjectHelper.capacity(GM.pc, m)
		if(cap <= 0):
			continue
		var cur = VoreObjectHelper.countForMethod(GM.pc, m)
		var label = VoreObjectHelper.methodLabel(m)
		var extra = ""
		if(m == "cock"):
			extra = " Storing cargo in your cock is notoriously unreliable - get too excited and you will shoot it right back out."
		elif(m == "vagina" || m == "anus"):
			extra = " Snug, roomy and easy to reach. It may still slip out if you get carried away."
		if(cur < cap):
			addButton(label, "Hide " + itemName + " in your " + VoreObjectHelper.partWord(m) + ". (" + str(cur) + "/" + str(cap) + " used)" + extra, "do_store", [m])
		else:
			addDisabledButton(label, "Your " + VoreObjectHelper.partWord(m) + " is packed full already (" + str(cur) + "/" + str(cap) + ").")
	addButton("Never mind", "Keep carrying it the boring way", "endthescene")

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "do_store"):
		if(_args.size() < 1):
			return
		var m = str(_args[0])
		if(item == null):
			lastText = "That item is gone."
			setState("stored")
			return
		var itemName = item.getVisibleName()
		if(!VoreObjectHelper.storeItem(GM.pc, item, m)):
			lastText = "No matter how you try, it will not fit in there right now."
			setState("stored")
			return
		item = null
		GM.pc.addSkillExperience("Vore", 10)
		var eff = VoreObjectHelper.getEffect(GM.pc)
		var count = 0
		if(eff != null):
			count = eff.totalStored()
		lastText = VoreObjectHelper.storeText(m, itemName) + " (+10 Vore XP)"
		lastText += "\n\nYou are now carrying " + str(count) + " object(s) inside your body. Nothing about you looks suspicious from the outside - your belly might beg to differ."
		setState("stored")
		return
	setState(_action)

func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	data["lastText"] = lastText
	return data

func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	lastText = SAVE.loadVar(data, "lastText", "")
	if(uniqueItemID != null && uniqueItemID != ""):
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
