extends "res://Scenes/SceneBase.gd"
var uniqueItemID = ""
var item: ItemBase
var desiredScale: float = 1.0
var desiredDurationSeconds: int = 3600
var targetNPC = null
const STEP = 0.1
const MIN_SCALE = 0.1
const MAX_SCALE = 5.0
const MIN_DURATION = 60
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	sceneID = "VoreSizeChangePillScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
func _reactInit():
	if uniqueItemID == null || uniqueItemID == "":
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
	desiredScale = _getCurrentScale()
func _getCurrentScale() -> float:
	if targetNPC != null:
		return VoreBodyScaleHelper.getNPCBodyScale(targetNPC)
	return VoreBodyScaleHelper.getCurrentPCScale()
func _applyScaleAndEffect(val: float, dur: int):
	val = clamp(val, MIN_SCALE, MAX_SCALE)
	if targetNPC != null:
		targetNPC.addEffect("VoreSizeChange", [val, dur])
	else:
		GM.pc.addEffect("VoreSizeChange", [val, dur])
func _getTargetName() -> String:
	if targetNPC != null:
		if targetNPC.has_method("getName"):
			return targetNPC.getName()
		return "NPC"
	return "yourself"
func _durationToString(seconds: int) -> String:
	if seconds < 0:
		return "permanently (until changed by another pill)"
	return Util.getTimeStringHumanReadable(seconds)
func _run():
	if state == "":
		_runMain()
	elif state == "after_swallow":
		_runAfterSwallow()
func _runMain():
	var current = _getCurrentScale()
	var targetName = _getTargetName()
	var scaleStr = str(stepify(desiredScale, 0.01))
	var durStr = _durationToString(desiredDurationSeconds)
	saynn("=== Size-Change Pill ===")
	saynn("A pill that can temporarily alter the body's size. Configure the desired scale and duration, then either swallow it or program it for later.")
	saynn("")
	saynn("Target: [b]" + targetName + "[/b]")
	saynn("Current body scale: [b]" + str(stepify(current, 0.01)) + "x[/b]  (1.0 = normal)")
	saynn("")
	saynn("== Scale ==")
	saynn("Desired body scale: [b]" + scaleStr + "x[/b]")
	if desiredScale < 1.0:
		saynn("This will make the target [color=#" + Color.cyan.to_html() + "]shrink[/color].")
	elif desiredScale > 1.0:
		saynn("This will make the target [color=#" + Color.red.to_html() + "]grow[/color].")
	else:
		saynn("This will [color=#" + Color.green.to_html() + "]restore normal size[/color].")
	saynn("")
	saynn("== Duration ==")
	saynn("Effect duration: [b]" + durStr + "[/b]")
	saynn("After the duration expires, the target will return to their normal size.")
	saynn("")
	var scaleBox = addTextbox("scale_value")
	scaleBox.text = scaleStr
	var _ok1 = scaleBox.connect("text_entered", self, "onScaleEnterPressed")
	var durBox = addTextbox("duration_minutes")
	durBox.text = "" if desiredDurationSeconds < 0 else str(int(desiredDurationSeconds / 60))
	var _ok2 = durBox.connect("text_entered", self, "onDurEnterPressed")
	saynn("")
	saynn("== Scale Controls ==")
	addButton("- " + str(STEP), "Decrease scale by " + str(STEP), "step_minus")
	addButton("+ " + str(STEP), "Increase scale by " + str(STEP), "step_plus")
	addButton("Apply scale field", "Set scale from text field", "apply_scale_text")
	saynn("")
	saynn("== Duration Presets ==")
	addButton("10 min", "Set duration to 10 minutes", "dur_10m")
	addButton("30 min", "Set duration to 30 minutes", "dur_30m")
	addButton("1 hour", "Set duration to 1 hour", "dur_1h")
	addButton("2 hours", "Set duration to 2 hours", "dur_2h")
	addButton("6 hours", "Set duration to 6 hours", "dur_6h")
	addButton("Permanent", "Make the size change permanent -- it will never wear off on its own and can only be changed by another size-change pill", "dur_perm")
	addButton("Apply duration field", "Set duration from the minutes text field", "apply_dur_text")
	saynn("")
	saynn("== Actions ==")
	addButton("SWALLOW", "Swallow the pill: apply " + scaleStr + "x for " + durStr + " now", "swallow")
	addButton("Program", "Create a programmed pill (" + scaleStr + "x, " + durStr + ") and put it in inventory. The blank pill is consumed.", "save_pill")
	if targetNPC != null:
		addButton("Switch to: yourself", "Change your own size instead", "switch_to_pc")
	else:
		var npcDollFound = VoreBodyScaleHelper.findAnyNPCDoll()
		if npcDollFound != null:
			var npcName = "NPC"
			var npcChar = npcDollFound.savedCharacterID
			if npcChar != null && npcChar != "pc" && npcChar != GM.pc:
				if !(npcChar is String) && npcChar.has_method("getName"):
					npcName = npcChar.getName()
			addButton("Switch for: " + npcName, "Give the pill to an NPC instead", "switch_to_npc")
	addButton("Put away", "Don't use the pill", "endthescene")
func _runAfterSwallow():
	var targetName = _getTargetName()
	var scaleStr = str(stepify(desiredScale, 0.01))
	var durStr = _durationToString(desiredDurationSeconds)
	if desiredScale < 1.0:
		saynn("The pill slides down " + targetName + "'s throat and a cold tightness races through every limb. Flesh compresses, bones compact, and the world looms larger as " + targetName + " shrink down to " + scaleStr + "x normal size.")
	elif desiredScale > 1.0:
		saynn("The pill slides down " + targetName + "'s throat and warmth blooms through every limb. Flesh swells, bones stretch, and the world shrinks around " + targetName + " as they grow to " + scaleStr + "x normal size.")
	else:
		saynn("The pill slides down " + targetName + "'s throat and a wave of normalcy spreads through their body. Everything returns to its natural proportions.")
	saynn("")
	saynn("New body scale: [b]" + scaleStr + "x[/b]")
	if desiredDurationSeconds < 0:
		saynn("This change is [b]permanent[/b] -- " + targetName + " will stay this size until another size-change pill is used.")
	else:
		saynn("The effect will last for [b]" + durStr + "[/b], after which " + targetName + " will return to normal size.")
	if item != null:
		addButton("Take another", "Configure another pill", "again")
	else:
		addDisabledButton("Take another", "No more Size-Change Pills left")
	addButton("Close", "Done", "endthescene")
func onScaleEnterPressed(_new_text):
	GM.main.pickOption("apply_scale_text", [])
func onDurEnterPressed(_new_text):
	GM.main.pickOption("apply_dur_text", [])
func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "switch_to_pc":
		targetNPC = null
		desiredScale = _getCurrentScale()
		addMessage("Target switched to yourself.")
		setState("")
		return
	if _action == "switch_to_npc":
		var npcDoll = VoreBodyScaleHelper.findAnyNPCDoll()
		if npcDoll != null:
			var npcChar = npcDoll.savedCharacterID
			if !(npcChar is String):
				targetNPC = npcChar
				if targetNPC.has_method("getName"):
					addMessage("Target switched to " + targetNPC.getName() + ".")
				else:
					addMessage("Target switched to NPC.")
			else:
				var ch = GlobalRegistry.getCharacter(npcChar)
				if ch != null:
					targetNPC = ch
					if targetNPC.has_method("getName"):
						addMessage("Target switched to " + targetNPC.getName() + ".")
					else:
						addMessage("Target switched to NPC.")
				else:
					addMessage("Could not resolve NPC object.")
			desiredScale = _getCurrentScale()
		else:
			addMessage("No NPC found in scene.")
		setState("")
		return
	if _action == "step_minus":
		desiredScale = stepify(clamp(desiredScale - STEP, MIN_SCALE, MAX_SCALE), 0.01)
		setState("")
		return
	if _action == "step_plus":
		desiredScale = stepify(clamp(desiredScale + STEP, MIN_SCALE, MAX_SCALE), 0.01)
		setState("")
		return
	if _action == "apply_scale_text":
		var textInput = getTextboxData("scale_value")
		if textInput == null || textInput == "":
			addMessage("Please enter a valid number.")
			setState("")
			return
		if !textInput.is_valid_float():
			addMessage("Please enter a valid number (e.g. 1.5 or 0.75).")
			setState("")
			return
		var val = float(textInput)
		if val < MIN_SCALE || val > MAX_SCALE:
			addMessage("Value must be between " + str(MIN_SCALE) + " and " + str(MAX_SCALE) + ".")
			setState("")
			return
		desiredScale = stepify(val, 0.01)
		setState("")
		return
	if _action == "dur_10m":
		desiredDurationSeconds = 600
		setState("")
		return
	if _action == "dur_30m":
		desiredDurationSeconds = 1800
		setState("")
		return
	if _action == "dur_1h":
		desiredDurationSeconds = 3600
		setState("")
		return
	if _action == "dur_2h":
		desiredDurationSeconds = 7200
		setState("")
		return
	if _action == "dur_6h":
		desiredDurationSeconds = 21600
		setState("")
		return
	if _action == "dur_perm":
		desiredDurationSeconds = -1
		setState("")
		return
	if _action == "apply_dur_text":
		var durText = getTextboxData("duration_minutes")
		if durText == null || durText == "":
			addMessage("Please enter a valid number of minutes.")
			setState("")
			return
		if !durText.is_valid_integer() && !durText.is_valid_float():
			addMessage("Please enter a valid number of minutes.")
			setState("")
			return
		var minutes = float(durText)
		if minutes < 1:
			addMessage("Duration must be at least 1 minute.")
			setState("")
			return
		desiredDurationSeconds = int(minutes * 60)
		if desiredDurationSeconds < MIN_DURATION:
			desiredDurationSeconds = MIN_DURATION
		setState("")
		return
	if _action == "swallow":
		_applyScaleAndEffect(desiredScale, desiredDurationSeconds)
		if item != null:
			item.removeXOrDestroy(1)
			item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
		setState("after_swallow")
		return
	if _action == "again":
		desiredScale = _getCurrentScale()
		setState("")
		return
	if _action == "save_pill":
		var newPill = GlobalRegistry.createItem("VoreSizeChangePillProgrammed")
		if newPill != null:
			newPill.setTargetScale(desiredScale)
			newPill.setDurationSeconds(desiredDurationSeconds)
			if item != null:
				item.removeXOrDestroy(1)
			GM.pc.getInventory().addItem(newPill)
			var scaleStr = str(stepify(desiredScale, 0.01))
			var durStr = _durationToString(desiredDurationSeconds)
			addMessage("Size-Change Pill consumed. Programmed pill (" + scaleStr + "x, " + durStr + ") added to inventory!")
		else:
			addMessage("Failed to create programmed pill. The item may not be registered.")
		endScene()
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	data["desiredScale"] = desiredScale
	data["desiredDurationSeconds"] = desiredDurationSeconds
	return data
func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	desiredScale = SAVE.loadVar(data, "desiredScale", 1.0)
	desiredDurationSeconds = SAVE.loadVar(data, "desiredDurationSeconds", 3600)
	if uniqueItemID != null && uniqueItemID != "":
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)