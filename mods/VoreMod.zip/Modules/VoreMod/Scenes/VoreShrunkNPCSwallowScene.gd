extends "res://Scenes/SceneBase.gd"
var uniqueItemID = ""
var item = null
var npcID = ""
var charName = "Someone"
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
func _init():
	sceneID = "VoreShrunkNPCSwallowScene"
func _initScene(_args = []):
	if _args.size() > 0:
		uniqueItemID = _args[0]
func _reactInit():
	if uniqueItemID == null || uniqueItemID == "":
		return
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
	if item != null:
		npcID = item.npcID
		var npcChar = GlobalRegistry.getCharacter(npcID)
		if npcChar != null and npcChar.has_method("getName"):
			charName = npcChar.getName()
func _run():
	if state == "":
		_runMain()
	elif state == "after_swallow":
		_runAfterSwallow()
func _runMain():
	if item == null:
		saynn("The pocket companion seems to have vanished.")
		addButton("Close", "Done", "endthescene")
		return
	saynn("You pull tiny " + charName + " out of your pocket and hold them in your palm. They look up at you, wondering what you're about to do.")
	saynn("")
	saynn("How do you want to swallow them?")
	for m in ["mouth", "breasts", "anus", "cock", "vagina", "tail", "eye", "ear"]:
		var cap = _methodCapacity(m)
		if cap <= 0:
			continue
		var cur = _currentCount(m)
		var label = _methodLabel(m)
		if cur < cap:
			addButton(label, "Swallow " + charName + " into your " + _partWord(m) + ". (" + str(cur) + "/" + str(cap) + " " + m + " capacity used)", "do_swallow", [m])
		else:
			addDisabledButton(label, "Your " + m + " capacity is full (" + str(cur) + "/" + str(cap) + ").")
	addButton("Never mind", "Put them back in your pocket.", "endthescene")
func _runAfterSwallow():
	saynn(charName + " slips down into your body, gone from the outside world.")
	addButton("Continue", "Done", "endthescene")
func _methodCapacity(m: String) -> int:
	var h = GM.pc.getSkillsHolder()
	var c = 0
	if m == "mouth":
		if h.hasPerk("VoreInitiate"):    c += 1
		if h.hasPerk("VoreExpansionV2"): c += 1
		if h.hasPerk("VoreExpansionV3"): c += 1
	elif m == "breasts":
		if h.hasPerk("VoreBreastsInitiate"):    c += 1
		if h.hasPerk("VoreBreastsExpansionV2"): c += 1
		if h.hasPerk("VoreBreastsExpansionV3"): c += 1
	elif m == "anus":
		if h.hasPerk("VoreAnusInitiate"):    c += 1
		if h.hasPerk("VoreAnusExpansionV2"): c += 1
		if h.hasPerk("VoreAnusExpansionV3"): c += 1
	elif m == "cock":
		if h.hasPerk("VoreCockInitiate"):    c += 1
		if h.hasPerk("VoreCockExpansionV2"): c += 1
		if h.hasPerk("VoreCockExpansionV3"): c += 1
	elif m == "vagina":
		if h.hasPerk("VoreVaginaInitiate"):    c += 1
		if h.hasPerk("VoreVaginaExpansionV2"): c += 1
		if h.hasPerk("VoreVaginaExpansionV3"): c += 1
	elif m == "tail":
		if h.hasPerk("VoreTailInitiate"):    c += 1
		if h.hasPerk("VoreTailExpansionV2"): c += 1
		if h.hasPerk("VoreTailExpansionV3"): c += 1
	elif m == "eye":
		if h.hasPerk("VoreEyeInitiate"):    c += 1
		if h.hasPerk("VoreEyeExpansionV2"): c += 1
		if h.hasPerk("VoreEyeExpansionV3"): c += 1
	elif m == "ear":
		if h.hasPerk("VoreEarInitiate"):    c += 1
		if h.hasPerk("VoreEarExpansionV2"): c += 1
		if h.hasPerk("VoreEarExpansionV3"): c += 1
	return c
func _currentCount(m: String) -> int:
	return VoreSwallowed.countForMethod(GM.pc, m)
func _methodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow whole (mouth)"
		"breasts": return "Absorb into breasts"
		"anus":    return "Absorb into rear"
		"cock":    return "Devour with cock"
		"vagina":  return "Take into womb"
		"tail":    return "Coil up in tail"
		"eye":     return "Absorb through eye"
		"ear":     return "Absorb through ear"
	return "Swallow"
func _partWord(m: String) -> String:
	match m:
		"mouth":   return "stomach"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye"
		"ear":     return "ear canal"
	return "body"
func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "do_swallow":
		if _args.size() < 1:
			return
		var m = _args[0]
		_doSwallow(m)
		return
	setState(_action)
func _doSwallow(m: String):
	if item == null:
		saynn("The pocket companion seems to have vanished.")
		setState("")
		return
	if _currentCount(m) >= _methodCapacity(m):
		saynn("You can't fit anyone else in there right now.")
		setState("")
		return
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		saynn("The character couldn't be found. Something went wrong.")
		setState("")
		return
	var preyName = character.getName()
	var like = 0.0
	var fh = character.getFetishHolder()
	if fh != null:
		like = fh.getFetishValue("Vore")
	var shrinkDur = 0.0
	if item != null:
		shrinkDur = float(item.duration)
	var voreMod = getModule("VoreMod")
	if voreMod != null:
		voreMod.swallowNPCFromItem(item)
	item = null
	GM.pc.addEffect(VoreSwallowed.effectIDForMethod(m), [preyName, npcID, m])
	GM.pc.addSkillExperience("Vore", 20)
	if shrinkDur > 0.0:
		GM.pc.addEffect("VoreSwallowedShrunk", [preyName, npcID, m, shrinkDur])
	var partWord = _partWord(m)
	var reaction = ""
	if like >= 0.5:
		reaction = " They eagerly let you do it, shivering with delight as they slip into your " + partWord + "."
	elif like >= 0.125:
		reaction = " They put up only a token protest, secretly thrilled to end up in your " + partWord + "."
	elif like <= -0.5:
		reaction = " They thrash and beg in horror, but down into your " + partWord + " they go regardless."
	elif like <= -0.125:
		reaction = " They squirm in discomfort as your " + partWord + " swallows them up."
	saynn("You swallow " + preyName + " whole!" + reaction + " (+20 Vore XP)")
	setState("after_swallow")
func saveData():
	var data = .saveData()
	data["uniqueItemID"] = uniqueItemID
	return data
func loadData(data):
	.loadData(data)
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	if uniqueItemID != null and uniqueItemID != "":
		item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
		if item != null:
			npcID = item.npcID
			var npcChar = GlobalRegistry.getCharacter(npcID)
			if npcChar != null and npcChar.has_method("getName"):
				charName = npcChar.getName()