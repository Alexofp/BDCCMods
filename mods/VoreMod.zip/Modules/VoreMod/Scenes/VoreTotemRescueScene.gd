extends "res://Scenes/SceneBase.gd"
var predID = ""
var predName = "your predator"
func _init():
	sceneID = "VoreTotemRescueScene"
func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()
func _run():
	if(state == ""):
		saynn("The sixth day inside " + predName + " should have been your very last...")
		saynn("But deep within the churning dark, the Vore Totem you activated flares to life. Ancient magic rips through the digestive haze, and in a sudden flash of warmth your half-dissolved body is torn free of " + predName + " entirely.")
		saynn("You reform - whole, breathing, and very much alive - back in the exact spot where you planted the totem. The totem itself is gone, spent completely to drag you back from the brink.")
		saynn("[i]The Vore Totem saved you from being fully digested and returned you to where you activated it. It has been consumed.[/i]")
		addButton("Continue", "Back from the brink", "endthescene")
		return
func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	setState(_action)
func saveData():
	var data = .saveData()
	data["predID"] = predID
	data["predName"] = predName
	return data
func loadData(data):
	.loadData(data)
	predID = SAVE.loadVar(data, "predID", "")
	predName = SAVE.loadVar(data, "predName", "your predator")