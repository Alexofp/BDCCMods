extends "res://Scenes/SceneBase.gd"

const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")

var selectedPrey = -1
var lastFlavor = ""

func _init():
	sceneID = "VoreInteractScene"

func _getPreyList() -> Array:
	return VoreSwallowed.getAllPrey(GM.pc)

func _methodLabel(m):
	match m:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "rear"
		"cock":    return "groin"
		"vagina":  return "belly"
	return "belly"

func _run():
	var preyList = _getPreyList()

	if(state == ""):
		if(preyList.size() <= 0):
			saynn("You place a hand on your stomach, but there is no one inside you right now. Your body is empty.")
			addButton("Back", "Nothing to do here", "endthescene")
			return

		saynn("You take a quiet moment alone to feel the prey squirming inside you. Who would you like to interact with?")
		for i in range(preyList.size()):
			var entry = preyList[i]
			var who   = entry["name"]
			var m     = entry["method"]
			var stage = entry["stage"]
			addButton(who, "Interact with "+who+" ("+m+", digestion day "+str(stage+1)+"/6)", "select", [i])
		addButton("Back", "Leave your prey be for now", "endthescene")
		return

	if(state == "interact"):
		if(selectedPrey < 0 || selectedPrey >= preyList.size()):
			setState("")
			return

		var entry = preyList[selectedPrey]
		var who  = entry["name"]
		var m    = entry["method"]
		var part = _methodLabel(m)

		playAnimation(StageScene.Solo, "stand")

		if(lastFlavor != ""):
			saynn(lastFlavor)
		else:
			saynn("You wrap your arms around your "+part+", feeling "+who+" shift faintly within you.")

		addButton("Pat", "Gently pat your "+part+" where "+who+" rests", "do_pat")
		addButton("Hug", "Wrap your arms around your "+part+" in a warm embrace", "do_hug")
		addButton("Rub", "Slowly rub and soothe your "+part+"", "do_rub")
		addButton("Whisper", "Whisper softly to "+who+"", "do_whisper")
		addButton("Squeeze", "Give your "+part+" a firm, possessive squeeze", "do_squeeze")
		addButton("Pleasure", "Sit down and use "+who+" for your own pleasure", "do_pleasure")
		addButton("Spit out", "Spit "+who+" back out of you", "do_spit")
		addButton("Back", "Pick someone else", "backtolist")
		return

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "select"):
		selectedPrey = _args[0]
		lastFlavor = ""
		setState("interact")
		return

	if(_action == "backtolist"):
		selectedPrey = -1
		lastFlavor = ""
		setState("")
		return

	var preyList = _getPreyList()
	var who = "them"
	var m = "mouth"
	var entry = null
	if(selectedPrey >= 0 && selectedPrey < preyList.size()):
		entry = preyList[selectedPrey]
		who = entry["name"]
		m   = entry["method"]
	var part = _methodLabel(m)

	if(_action == "do_pat"):
		lastFlavor = "You gently pat your "+part+", and "+who+" gives a weak, muffled response from deep inside you. A warm, smug satisfaction washes over you."
		GM.pc.addSkillExperience("Vore", 5)
		setState("interact")
		return
	if(_action == "do_hug"):
		lastFlavor = "You wrap both arms around your "+part+" and squeeze "+who+" close in a slow, affectionate embrace. They have nowhere to go but deeper into you."
		GM.pc.addSkillExperience("Vore", 5)
		setState("interact")
		return
	if(_action == "do_rub"):
		lastFlavor = "You knead and rub slow circles over your "+part+". "+who+" stirs sluggishly beneath your palms as your body works on them."
		GM.pc.addSkillExperience("Vore", 5)
		setState("interact")
		return
	if(_action == "do_whisper"):
		lastFlavor = "You lean down and whisper to "+who+" that there's no escape and no use struggling. You feel a shiver run through your "+part+"."
		GM.pc.addSkillExperience("Vore", 5)
		setState("interact")
		return
	if(_action == "do_squeeze"):
		lastFlavor = "You give your "+part+" a firm, possessive squeeze. "+who+" lets out a muffled whimper, fully at the mercy of your body."
		GM.pc.addSkillExperience("Vore", 8)
		setState("interact")
		return

	if(_action == "do_pleasure"):
		if(entry != null):
			runScene("VoreSexScene", [entry["id"]])
		return

	if(_action == "do_spit"):
		if(entry != null):
			var spitID = entry["id"]
			entry["effect"].releaseNPC(spitID)
			GM.main.addMessage("You heave "+who+" back up and spit them out onto the floor.")
		selectedPrey = -1
		lastFlavor = ""
		setState("")
		return

	setState(_action)
