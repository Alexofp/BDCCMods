extends "res://Scenes/SceneBase.gd"
var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")
const VoreRebirthController = preload("res://Modules/VoreMod/StatusEffects/VoreRebirthController.gd")
const ESCAPE_THRESHOLD = 0.5
var predID = ""
var predName = "your predator"
var voreMethod = "mouth"
var wombRebirthMode = false
var endosomaMode = false
var methodChosen = false
var failedAttempts = 0
var painDealt = 0
var predatorActivity = "wandering along without a care"
var pendingAnim = ""
var _mgScore = 0.0
var _mgFailedHard = false
var _mgInstant = false
const ACTIVITIES = [
	"rummaging through a nearby locker",
	"trading idle words with another inmate",
	"leaning against the wall to catch their breath",
	"strolling down the corridor without a care",
	"stretching, one hand resting on the swell of their bulging middle",
	"patting their bloated bulge with a satisfied sigh",
	"glancing around the room, looking for something to do",
	"shifting their weight, your bulge swaying with every step",
]
func _init():
	sceneID = "VoreBellyRideScene"
func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])
	if(_args.size() > 1 && str(_args[1]) != ""):
		voreMethod = str(_args[1])
		methodChosen = true
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()
		if(GM.main != null):
			var _p = GM.main.IS.spawnPawnIfNeeded(predID)
	if(methodChosen):
		_applyBelly()
func _part() -> String:
	match voreMethod:
		"mouth":   return "belly"
		"breasts": return "breasts"
		"anus":    return "guts"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye socket"
		"ear":     return "ear canal"
	return "belly"
func _availableMethods() -> Array:
	var methods = ["mouth", "mouth_endo"]
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		if(predator.hasNonFlatBreasts()):
			methods.append("breasts")
			methods.append("breasts_endo")
		if(predator.hasPenis()):
			methods.append("cock")
			methods.append("cock_endo")
		if(predator.hasVagina()):
			methods.append("vagina")
			methods.append("vagina_endo")
			methods.append("vagina_rebirth")
	methods.append("anus")
	methods.append("anus_endo")
	methods.append("tail")
	methods.append("tail_endo")
	methods.append("eye")
	methods.append("eye_endo")
	methods.append("ear")
	methods.append("ear_endo")
	return methods
func _allMethods() -> Array:
	return ["mouth", "mouth_endo", "breasts", "breasts_endo", "cock", "cock_endo", "vagina", "vagina_endo", "vagina_rebirth", "anus", "anus_endo", "tail", "tail_endo", "eye", "eye_endo", "ear", "ear_endo"]
func _methodDisabledReason(m: String) -> String:
	var predator = GlobalRegistry.getCharacter(predID)
	match m:
		"breasts":
			if(predator == null || !predator.hasNonFlatBreasts()):
				return predName + " doesn't have the breasts for this.."
		"cock":
			if(predator == null || !predator.hasPenis()):
				return predName + " doesn't have a penis.."
		"vagina", "vagina_rebirth":
			if(predator == null || !predator.hasVagina()):
				return predName + " doesn't have a vagina.."
		"eye", "eye_endo":
			return predName + " can't swallow you through their eye.."
		"ear", "ear_endo":
			return predName + " can't swallow you through their ear.."
	return "This method isn't available right now.."
func _methodLabel(m) -> String:
	match m:
		"mouth":           return "Swallowed whole"
		"breasts":         return "Into the breasts"
		"anus":            return "Up the rear"
		"cock":            return "Into the cock"
		"vagina":          return "Into the womb"
		"vagina_rebirth":  return "Into the womb (Reborn)"
		"tail":            return "Coiled up in tail"
		"mouth_endo":      return "Swallowed whole (Endosoma)"
		"breasts_endo":    return "Into the breasts (Endosoma)"
		"cock_endo":       return "Into the cock (Endosoma)"
		"vagina_endo":     return "Into the womb (Endosoma)"
		"anus_endo":       return "Up the rear (Endosoma)"
		"tail_endo":       return "Coiled up in tail (Endosoma)"
		"eye":             return "Through the eye"
		"eye_endo":        return "Through the eye (Endosoma)"
		"ear":             return "Through the ear"
		"ear_endo":        return "Through the ear (Endosoma)"
	return "Swallowed whole"
func _methodDesc(m) -> String:
	match m:
		"mouth":           return "Get gulped straight down into " + predName + "'s belly"
		"breasts":         return "Get drawn and absorbed into " + predName + "'s breasts"
		"anus":            return "Get stuffed up into " + predName + "'s guts"
		"cock":            return "Get drawn down into " + predName + "'s balls"
		"vagina":          return "Get drawn up into " + predName + "'s womb"
		"vagina_rebirth":  return "Get drawn up into " + predName + "'s womb, where instead of digesting you, their body will slowly reshape you into a new life -- " + predName + " carries a reborn copy of you to term while you're pushed back out unharmed"
		"tail":            return "Get coiled up and swallowed into " + predName + "'s tail"
		"eye":             return "Get pulled into " + predName + "'s eye"
		"eye_endo":        return "Get pulled into " + predName + "'s eye -- endosoma keeps you alive and undigested indefinitely"
		"ear":             return "Get pulled into " + predName + "'s ear"
		"ear_endo":        return "Get pulled into " + predName + "'s ear -- endosoma keeps you alive and undigested indefinitely"
	return "Get gulped down whole"
func _unlockPredatorAI():
	if GM.main == null or predID == "":
		return
	var pawn = GM.main.IS.getPawn(predID)
	if pawn == null:
		return
	if pawn.has_method("clearSceneLocks"):
		pawn.clearSceneLocks()
	if pawn.has_method("clearInteractionLock"):
		pawn.clearInteractionLock()
	if pawn.has_method("setAIState"):
		pawn.setAIState(0)
	elif pawn.has_method("setState"):
		pawn.setState(0)
	if pawn.has_method("moveToNextRandomCell"):
		pawn.moveToNextRandomCell()
	elif pawn.has_method("moveToRandomNeighbor"):
		pawn.moveToRandomNeighbor()
func _applyBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		if(!predator.hasEffect("VorePredatorBelly")):
			predator.addEffect("VorePredatorBelly", [GM.pc.getName(), voreMethod])
		if(!endosomaMode && !GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.addEffect("VorePlayerDigesting", [predName, voreMethod])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.setLocation(GM.pc.getLocation())
	_unlockPredatorAI()
func _syncBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		if(!predator.hasEffect("VorePredatorBelly")):
			predator.addEffect("VorePredatorBelly", [GM.pc.getName(), voreMethod])
		if(!endosomaMode && !GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.addEffect("VorePlayerDigesting", [predName, voreMethod])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn == null):
			pawn = GM.main.IS.spawnPawnIfNeeded(predID)
		if(pawn != null):
			var predLoc = pawn.getLocation()
			if(predLoc != null && predLoc != ""):
				if(GM.pc.has_method("setLocationSilent")):
					GM.pc.setLocationSilent(predLoc)
				else:
					GM.pc.setLocation(predLoc)
			else:
				pawn.setLocation(GM.pc.getLocation())
func _isFullyHypnotized() -> bool:
	if(GM.pc == null):
		return false
	var susp = GM.pc.getEffect("Suggestible")
	if(susp == null):
		return false
	if(susp.has_method("isInTrance")):
		return susp.isInTrance()
	return false
func _abortPreyState():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && predator.hasEffect("VorePredatorBelly")):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
func _predatorRoom() -> String:
	if(GM.main == null):
		return ""
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn == null):
		return ""
	return pawn.getLocation()
func _calcDifficulty():
	var diff = 5 - failedAttempts
	if(diff < 2):
		diff = 2
	return diff
func _likeValue() -> float:
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return 0.0
	var fh = predator.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")
func _run():
	if(!methodChosen):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			_abortPreyState()
			saynn("Your predator is nowhere to be found.")
			addButton("Continue", "Get up", "endthescene")
			return
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "stand", {pc = predID})
		saynn(predName + " has you helpless and looms over you, deciding just how to take you in. How do they devour you?")
		var available = _availableMethods()
		for m in _allMethods():
			if(m in available):
				addButton(_methodLabel(m), _methodDesc(m), "pick_method", [m])
			else:
				addDisabledButton(_methodLabel(m), _methodDisabledReason(m))
		return
	if(state == ""):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			_abortPreyState()
			saynn("Your predator is nowhere to be found. You spill back out into the open, free.")
			addButton("Continue", "Get up", "endthescene")
			return
		_syncBelly()
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		if(endosomaMode):
			saynn("You are nestled comfortably inside " + predName + ", curled up in the warm, safe interior of their " + _part() + ". No digestion threatens you here -- you are simply being carried along, sheltered within them like a living home.")
		else:
			saynn("You are sealed inside " + predName + ", curled up in the hot, churning dark of their " + _part() + ". There is no seeing out - all you can do is feel every step they take and ride along wherever they go.")
		var roomObj = null
		if(room != "" && GM.world != null):
			roomObj = GM.world.getRoomByID(room)
		if(roomObj != null):
			saynn("Right now " + predName + " is in [b]" + roomObj.getName() + "[/b], " + predatorActivity + ", their swollen " + _part() + " swaying with you inside it.")
		else:
			saynn(predName + " carries you along, " + predatorActivity + ", their swollen " + _part() + " swaying with you inside it.")
		if(failedAttempts > 0):
			saynn("[i]Your previous struggles have left them a little careless - your next escape attempt will be easier.[/i]")
		if(GM.main != null && GM.main.isVeryLate()):
			saynn("[i]It is the dead of night. Trapped inside " + predName + ", there is nothing left to do but let sleep drag you under until the prison stirs again.[/i]")
			addButton("Sleep", "You have no choice but to sleep the night away inside " + predName + "'s " + _part(), "do_sleep")
			return
		addButton("Wait", "Pass some time inside " + predName + "'s " + _part(), "open_wait")
		addButton("Sleep", "Curl up and sleep inside " + predName + "'s " + _part() + " until the next day", "do_sleep")
		if(_isFullyHypnotized()):
			addDisabledButton("Fight", "You are far too deep in trance to even think of fighting your way out...")
		else:
			addButton("Fight", "Squirm and force your way back out (timing minigame)", "do_struggle")
		addButton("Talk", "Try to speak with " + predName + " from inside their " + _part(), "open_talk")
		if(_isFullyHypnotized()):
			addDisabledButton("Actions", "You are far too deep in trance to act against " + predName + "...")
		else:
			addButton("Actions", "Do something to " + predName + " from the inside", "open_actions")
		return
	if(state == "actions"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		if(pendingAnim != ""):
			playAnimation(StageScene.Solo, pendingAnim, {pc = predID})
			pendingAnim = ""
		else:
			playAnimation(StageScene.Solo, "walk", {pc = predID})
		saynn("Pressed against the walls of " + predName + "'s " + _part() + ", you have plenty of room to make yourself a nuisance. What do you do?")
		saynn("[i]" + predName + "'s pain: " + str(predator.getPain()) + " / " + str(predator.painThreshold()) + ". Hurt them enough and they will be forced to heave you back up.[/i]")
		addButton("Kick", "Slam a foot hard into the walls around you", "act_kick")
		addButton("Punch", "Hammer your fists against the soft walls around you", "act_punch")
		addButton("Headbutt", "Throw your whole weight into a brutal headbutt", "act_headbutt")
		addButton("Bite", "Sink your teeth into the fleshy walls", "act_bite")
		addButton("Stretch", "Brace and shove outward, stretching them painfully", "act_stretch")
		addButton("Squirm", "Writhe and wriggle around to unsettle them", "act_squirm")
		addButton("Back", "Settle down for now", "back_to_belly")
		return
	if(state == "talk"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		var like = _likeValue()
		saynn("Your voice comes out muffled through layers of flesh, but " + predName + " can still hear you grumbling inside them.")
		if(like >= 0.5):
			saynn(predName + " gives their " + _part() + " a fond pat. \"Mmh, comfy in there? You feel [i]wonderful[/i] sloshing around inside me.\"")
		elif(like >= 0.125):
			saynn(predName + " chuckles, rubbing the squirming bulge. \"Settle down, little snack. You're not going anywhere just yet.\"")
		elif(like <= -0.5):
			saynn(predName + " scowls down at their " + _part() + ". \"Keep talking. It just makes taking you down feel that much sweeter.\"")
		else:
			saynn(predName + " shrugs, one hand on the swell of their " + _part() + ". \"Make yourself comfortable. You'll be in there a while.\"")
		addButton("Beg to be let out", "Plead with them to let you back out", "talk_beg")
		addButton("Ask where they're headed", "Ask what they plan to do with you", "talk_ask")
		addButton("Flirt", "Try to charm your way into their good graces", "talk_flirt")
		addButton("Threaten", "Promise they'll regret taking you in", "talk_threat")
		addButton("Back", "Stop talking", "back_to_belly")
		return
	if(state == "waiting"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		saynn("Sealed in the churning dark of " + predName + "'s " + _part() + ", you decide to simply pass the time. How long do you want to wait?")
		addButton("5 minutes", "Wait this much", "dowait_belly", [5 * 60])
		addButton("15 minutes", "Wait this much", "dowait_belly", [15 * 60])
		addButton("30 minutes", "Wait this much", "dowait_belly", [30 * 60])
		addButton("1 hour", "Wait this much", "dowait_belly", [1 * 60 * 60])
		addButton("2 hours", "Wait this much", "dowait_belly", [2 * 60 * 60])
		addButton("3 hours", "Wait this much", "dowait_belly", [3 * 60 * 60])
		addButton("Back", "Don't wait", "back_to_belly")
		return
	if(state == "slept_belly"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		var dig = GM.pc.getEffect("VorePlayerDigesting")
		var day = 1
		if(dig != null):
			day = dig.getDigestionDay()
		saynn("You let the suffocating heat and the gentle sway of " + predName + "'s " + _part() + " lull you under, curling up as small as you can in the cramped, slick dark.")
		saynn("Sleep takes you, and the hours slip away as " + predName + " carries you along through the night.")
		saynn("You wake to the prison lights flickering on - still sealed inside " + predName + "'s " + _part() + ". Welcome to day " + str(GM.main.getDays()) + " of your sentence.")
		saynn("[i]Digestion has advanced to day " + str(day) + " of 6.[/i]")
		if(day >= 4):
			saynn("[color=#ff5555]The acids have truly taken hold. You wake utterly drained of stamina, your body wracked with mounting pain. If you keep sleeping in here, you will not wake up again.[/color]")
		addButton("Continue", "Wake up inside", "back_to_belly")
		return
	if(state == "minigame"):
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("voreride_minigame", game)
		game.setDifficulty(_calcDifficulty())
		game.connect("minigameCompleted", self, "onEscapeMinigameDone")
		return
	if(state == "escaped"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("With one last desperate heave you force the muscles open and spill out of " + predName + " in a slick, gasping heap!")
		saynn(predName + " staggers, utterly spent, and collapses to the floor to rest - just like after a lost fight.")
		addButton("Continue", "Catch your breath", "endthescene")
		return
	if(state == "vomited"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("It is too much. " + predName + " doubles over, " + _part() + " heaving violently, and forces you back out in a rush of slick. You tumble out onto the floor, free at last.")
		addButton("Continue", "Pick yourself up", "endthescene")
		return
func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "pick_method"):
		if(_args.size() > 0):
			var pickedMethod = str(_args[0])
			if(pickedMethod == "vagina_rebirth"):
				voreMethod = "vagina"
				wombRebirthMode = true
				endosomaMode = false
			elif(pickedMethod.ends_with("_endo")):
				voreMethod = pickedMethod.replace("_endo", "")
				endosomaMode = true
				wombRebirthMode = false
			else:
				voreMethod = pickedMethod
				wombRebirthMode = false
				endosomaMode = false
		methodChosen = true
		_applyBelly()
		setState("")
		return
	if(_action == "open_wait"):
		setState("waiting")
		return
	if(_action == "dowait_belly"):
		var newt = _args[0]
		if(GM.main != null):
			GM.main.processTime(newt)
		_syncBelly()
		predatorActivity = ACTIVITIES[RNG.randi_range(0, ACTIVITIES.size() - 1)]
		setState("")
		return
	if(_action == "do_sleep"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		GM.main.startNewDay()
		GM.pc.afterSleepingInBed()
		_syncBelly()
		predatorActivity = ACTIVITIES[RNG.randi_range(0, ACTIVITIES.size() - 1)]
		if(endosomaMode):
			setState("slept_belly")
			return
		var dig = GM.pc.getEffect("VorePlayerDigesting")
		var day = 1
		if(dig != null):
			day = dig.advanceDay()
		if(day >= 6):
			if(GM.pc != null && GM.pc.hasPerk("VoreFusion")):
				var predatorChar = GlobalRegistry.getCharacter(predID)
				var fusionHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
				fusionHelper.performFusionWithMessages(GM.pc, predatorChar)
				if(GM.pc.hasEffect("VorePlayerDigesting")):
					GM.pc.removeEffect("VorePlayerDigesting")
				if(predatorChar != null && predatorChar.hasEffect("VorePredatorBelly")):
					predatorChar.removeEffect("VorePredatorBelly")
				GM.pc.addStamina(GM.pc.getMaxStamina())
				if(GM.main.IS.hasPawn(predID)):
					GM.main.IS.deletePawn(predID)
				if(GM.main.dynamicCharacters.has(predID)):
					GM.main.removeDynamicCharacter(predID)
				runScene("VoreFusionScene", [predID, predName])
				endScene()
				return
			if(GM.pc != null && GM.pc.hasEffect("VoreTotemActive")):
				_doTotemRescue()
				runScene("VoreTotemRescueScene", [predID])
				endScene()
				return
			if(wombRebirthMode):
				var predatorChar = GlobalRegistry.getCharacter(predID)
				if(predatorChar != null && GM.pc != null):
					var rebirthOk = VoreRebirthController.convertPreyToPregnancy("pc", GM.pc.getName(), GM.pc.getSpecies(), GM.pc.calculateNpcGender(), predatorChar)
					if(rebirthOk):
						if(GM.pc.hasEffect("VorePlayerDigesting")):
							GM.pc.removeEffect("VorePlayerDigesting")
						if(predatorChar.hasEffect("VorePredatorBelly")):
							predatorChar.removeEffect("VorePredatorBelly")
						GM.pc.addStamina(GM.pc.getMaxStamina())
						GM.main.addMessage("The last of your old self comes undone deep inside " + predName + "'s womb -- not digested, but unmade and reshaped into raw new life. " + predName + " is left carrying a reborn copy of you, and with a final shudder their body pushes you back out, whole and free once more.")
						GM.pc.addSkillExperience("Vore", 100)
						GM.main.addMessage("Rebirth begun! +100 Vore XP")
						endScene()
						return
					else:
						GM.main.addMessage(predName + "'s body tries to reshape you into new life, but they have no womb able to carry it. You are simply digested instead.")
			runScene("VoreDigestedDeathScene", [predID])
			endScene()
			return
		if(day >= 4):
			GM.pc.addStamina(-GM.pc.getStamina())
			GM.pc.addPain(GM.pc.painThreshold())
		setState("slept_belly")
		return
	if(_action == "do_struggle"):
		if(_isFullyHypnotized()):
			if(GM.main != null):
				GM.main.addMessage("You are far too deep in trance to fight back...")
			setState("")
			return
		setState("minigame")
		return
	if(_action == "open_actions"):
		if(_isFullyHypnotized()):
			if(GM.main != null):
				GM.main.addMessage("You are far too deep in trance to act against " + predName + "...")
			setState("")
			return
		setState("actions")
		return
	if(_action == "open_talk"):
		setState("talk")
		return
	if(_action == "back_to_belly"):
		setState("")
		return
	if(_action == "resolve_escape"):
		var success = _mgInstant || (!_mgFailedHard && _mgScore >= ESCAPE_THRESHOLD)
		if(success):
			_doEscape()
			GM.pc.addSkillExperience("Vore", 10)
			setState("escaped")
		else:
			failedAttempts += 1
			if(GM.main != null):
				GM.main.addMessage("You thrash and push, but " + predName + "'s body holds firm. You'll have to try again.")
				GM.main.processTime(10 * 60)
			setState("")
		return
	if(_action == "act_kick"):
		_doHit("hurt", 14, predName + " lurches as your foot crashes into them from the inside, doubling over with a pained grunt.")
		return
	if(_action == "act_punch"):
		_doHit("hurt", 10, "You hammer your fists into the soft walls. " + predName + " winces and clutches their churning " + _part() + ".")
		return
	if(_action == "act_headbutt"):
		_doHit("hurt", 16, "You throw your whole weight into a savage headbutt. " + predName + " stumbles, gasping, their " + _part() + " throbbing.")
		return
	if(_action == "act_bite"):
		_doHit("hurt", 18, "You sink your teeth into the fleshy wall. " + predName + " yelps and slaps at their bulging " + _part() + ".")
		return
	if(_action == "act_stretch"):
		_doHit("hurt", 12, "You brace and shove outward with all four limbs. " + predName + "'s " + _part() + " stretches grotesquely as they groan in pain.")
		return
	if(_action == "act_squirm"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addArousal(4.0)
			predator.addPain(4)
			painDealt += 4
		GM.main.addMessage("You writhe and wriggle, leaving " + predName + " shifting uncomfortably.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		_checkForcedOut()
		if(state == "actions"):
			pendingAnim = "hurt"
		return
	if(_action == "talk_beg"):
		var like = _likeValue()
		if(like >= 0.5 && RNG.randi_range(1, 100) <= 35):
			_doRelease()
			setState("escaped")
			return
		GM.main.addMessage(predName + " just laughs at your muffled begging.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		setState("talk")
		return
	if(_action == "talk_ask"):
		GM.main.addMessage(predName + " idly explains they're just going about their day - with you along for the ride.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		setState("talk")
		return
	if(_action == "talk_flirt"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addArousal(6.0)
		GM.main.addMessage("You purr and press against them invitingly. " + predName + "'s " + _part() + " gives an interested squeeze.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		setState("talk")
		return
	if(_action == "talk_threat"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addPain(3)
			painDealt += 3
		GM.main.addMessage("You snarl out a threat. " + predName + " only tightens around you in answer.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		_checkForcedOut()
		if(state == "talk"):
			setState("talk")
		return
	setState(_action)
func _doHit(anim, amount, text):
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.addPain(amount)
		painDealt += amount
	if(GM.main != null):
		GM.main.addMessage(text)
		GM.main.processTime(2 * 60)
	_checkForcedOut()
	if(state == "actions"):
		pendingAnim = anim
func _checkForcedOut():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return
	if(predator.getPain() >= predator.painThreshold()):
		_doEscape()
		GM.pc.addSkillExperience("Vore", 15)
		setState("vomited")
func _doEscape():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = _predatorRoom()
	if(GM.main != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.makeExhausted()
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)
func _doRelease():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = _predatorRoom()
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)
func _doTotemRescue():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = ""
	if(GM.pc != null && GM.pc.hasEffect("VoreTotemActive")):
		var totem = GM.pc.getEffect("VoreTotemActive")
		room = totem.getAnchorRoom()
		GM.pc.removeEffect("VoreTotemActive")
	if(GM.main != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.makeExhausted()
	if(GM.pc != null):
		GM.pc.addStamina(100000)
		GM.pc.addPain(-GM.pc.getPain())
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)
func onEscapeMinigameDone(result):
	_mgScore = result.score
	_mgFailedHard = result.failedHard
	_mgInstant = result.instantUnlock
	GM.main.pickOption("resolve_escape", [])
func supportsShowingPawns() -> bool:
	return false
func saveData():
	var data = .saveData()
	data["predID"]         = predID
	data["predName"]       = predName
	data["voreMethod"]     = voreMethod
	data["wombRebirthMode"] = wombRebirthMode
	data["endosomaMode"] = endosomaMode
	data["methodChosen"]   = methodChosen
	data["failedAttempts"] = failedAttempts
	data["painDealt"]      = painDealt
	data["predatorActivity"] = predatorActivity
	return data
func loadData(data):
	.loadData(data)
	predID         = SAVE.loadVar(data, "predID", "")
	predName       = SAVE.loadVar(data, "predName", "your predator")
	voreMethod     = SAVE.loadVar(data, "voreMethod", "mouth")
	wombRebirthMode = SAVE.loadVar(data, "wombRebirthMode", false)
	endosomaMode = SAVE.loadVar(data, "endosomaMode", false)
	methodChosen   = SAVE.loadVar(data, "methodChosen", true)
	failedAttempts = SAVE.loadVar(data, "failedAttempts", 0)
	painDealt      = SAVE.loadVar(data, "painDealt", 0)
	predatorActivity = SAVE.loadVar(data, "predatorActivity", "wandering along without a care")