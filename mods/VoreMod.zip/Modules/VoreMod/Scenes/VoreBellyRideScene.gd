extends "res://Scenes/SceneBase.gd"


var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")

const ESCAPE_THRESHOLD = 0.5

var predID = ""
var predName = "your predator"
var failedAttempts = 0
var painDealt = 0
var predatorActivity = "wandering along without a care"
var pendingAnim = ""

var _mgScore = 0.0
var _mgFailedHard = false
var _mgInstant = false

const ACTIVITIES = [
	"rummaging through a nearby locker",
	"trading idle words with another inmate",
	"leaning against the wall to catch their breath",
	"strolling down the corridor without a care",
	"stretching, one hand resting on the swell of their gut",
	"patting their bloated belly with a satisfied sigh",
	"glancing around the room, looking for something to do",
	"shifting their weight, your bulge swaying with every step",
]

func _init():
	sceneID = "VoreBellyRideScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])

	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()
		if(GM.main != null):
			var _p = GM.main.IS.spawnPawnIfNeeded(predID)

	_applyBelly()

func _applyBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		if(!predator.hasEffect("VorePredatorBelly")):
			predator.addEffect("VorePredatorBelly", [GM.pc.getName()])
		if(!GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.addEffect("VorePlayerDigesting", [predName])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.setLocation(GM.pc.getLocation())

func _syncBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		if(!predator.hasEffect("VorePredatorBelly")):
			predator.addEffect("VorePredatorBelly", [GM.pc.getName()])
		if(!GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.addEffect("VorePlayerDigesting", [predName])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			GM.pc.setLocation(pawn.getLocation())

func _predatorRoom() -> String:
	if(GM.main == null):
		return ""
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn == null):
		return ""
	return pawn.getLocation()

func _calcDifficulty():
	var diff = 5 - failedAttempts
	if(diff < 2):
		diff = 2
	return diff

func _likeValue() -> float:
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return 0.0
	var fh = predator.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")

func _run():
	if(state == ""):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			saynn("Your predator is nowhere to be found. You spill back out into the open, free.")
			addButton("Continue", "Get up", "endthescene")
			return

		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})

		saynn("You are sealed inside " + predName + ", curled up in the hot, churning dark of their belly. There is no seeing out - all you can do is feel every step they take and ride along wherever they go.")

		var roomObj = null
		if(room != "" && GM.world != null):
			roomObj = GM.world.getRoomByID(room)
		if(roomObj != null):
			saynn("Right now " + predName + " is in [b]" + roomObj.getName() + "[/b], " + predatorActivity + ", their swollen belly swaying with you inside it.")
		else:
			saynn(predName + " carries you along, " + predatorActivity + ", their swollen belly swaying with you inside it.")

		if(failedAttempts > 0):
			saynn("[i]Your previous struggles have left them a little careless - your next escape attempt will be easier.[/i]")

		addButton("Wait", "Pass some time inside " + predName + "'s belly", "open_wait")
		addButton("Sleep", "Curl up and sleep inside " + predName + "'s belly until the next day", "do_sleep")
		addButton("Fight", "Squirm and force your way back out (timing minigame)", "do_struggle")
		addButton("Talk", "Try to speak with " + predName + " from inside their gut", "open_talk")
		addButton("Actions", "Do something to " + predName + " from the inside", "open_actions")
		return

	if(state == "actions"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return

		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		if(pendingAnim != ""):
			playAnimation(StageScene.Solo, pendingAnim, {pc = predID})
			pendingAnim = ""
		else:
			playAnimation(StageScene.Solo, "walk", {pc = predID})

		saynn("Pressed against the walls of " + predName + "'s belly, you have plenty of room to make yourself a nuisance. What do you do?")
		saynn("[i]" + predName + "'s pain: " + str(predator.getPain()) + " / " + str(predator.painThreshold()) + ". Hurt them enough and they will be forced to heave you back up.[/i]")

		addButton("Kick", "Slam a foot hard into their stomach wall", "act_kick")
		addButton("Punch", "Hammer your fists against the soft walls around you", "act_punch")
		addButton("Headbutt", "Throw your whole weight into a brutal headbutt", "act_headbutt")
		addButton("Bite", "Sink your teeth into the fleshy walls", "act_bite")
		addButton("Stretch", "Brace and shove outward, stretching their gut painfully", "act_stretch")
		addButton("Squirm", "Writhe and wriggle around to unsettle them", "act_squirm")
		addButton("Back", "Settle down for now", "back_to_belly")
		return

	if(state == "talk"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return

		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})

		var like = _likeValue()
		saynn("Your voice comes out muffled through layers of flesh, but " + predName + " can still hear you grumbling inside them.")
		if(like >= 0.5):
			saynn(predName + " gives their belly a fond pat. \"Mmh, comfy in there? You feel [i]wonderful[/i] sloshing around inside me.\"")
		elif(like >= 0.125):
			saynn(predName + " chuckles, rubbing the squirming bulge. \"Settle down, little snack. You're not going anywhere just yet.\"")
		elif(like <= -0.5):
			saynn(predName + " scowls down at their gut. \"Keep talking. It just makes swallowing you feel that much sweeter.\"")
		else:
			saynn(predName + " shrugs, one hand on the swell of their stomach. \"Make yourself comfortable. You'll be in there a while.\"")

		addButton("Beg to be let out", "Plead with them to spit you back up", "talk_beg")
		addButton("Ask where they're headed", "Ask what they plan to do with you", "talk_ask")
		addButton("Flirt", "Try to charm your way into their good graces", "talk_flirt")
		addButton("Threaten", "Promise they'll regret swallowing you", "talk_threat")
		addButton("Back", "Stop talking", "back_to_belly")
		return

	if(state == "waiting"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})

		saynn("Sealed in the churning dark of " + predName + "'s belly, you decide to simply pass the time. How long do you want to wait?")

		addButton("5 minutes", "Wait this much", "dowait_belly", [5 * 60])
		addButton("15 minutes", "Wait this much", "dowait_belly", [15 * 60])
		addButton("30 minutes", "Wait this much", "dowait_belly", [30 * 60])
		addButton("1 hour", "Wait this much", "dowait_belly", [1 * 60 * 60])
		addButton("2 hours", "Wait this much", "dowait_belly", [2 * 60 * 60])
		addButton("3 hours", "Wait this much", "dowait_belly", [3 * 60 * 60])
		addButton("Back", "Don't wait", "back_to_belly")
		return

	if(state == "slept_belly"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})

		var dig = GM.pc.getEffect("VorePlayerDigesting")
		var day = 1
		if(dig != null):
			day = dig.getDigestionDay()

		saynn("You let the suffocating heat and the gentle sway of " + predName + "'s gut lull you under, curling up as small as you can in the cramped, slick dark.")
		saynn("Sleep takes you, and the hours slip away as " + predName + " carries you along through the night.")
		saynn("You wake to the prison lights flickering on - still sealed inside " + predName + "'s belly. Welcome to day " + str(GM.main.getDays()) + " of your sentence.")
		saynn("[i]Digestion has advanced to day " + str(day) + " of 6.[/i]")

		if(day >= 4):
			saynn("[color=#ff5555]The acids have truly taken hold. You wake utterly drained of stamina, your body wracked with mounting pain. If you keep sleeping in here, you will not wake up again.[/color]")

		addButton("Continue", "Wake up inside the belly", "back_to_belly")
		return

	if(state == "minigame"):
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("voreride_minigame", game)
		game.setDifficulty(_calcDifficulty())
		game.connect("minigameCompleted", self, "onEscapeMinigameDone")
		return

	if(state == "escaped"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("With one last desperate heave you force the muscles open and spill out of " + predName + " in a slick, gasping heap!")
		saynn(predName + " staggers, utterly spent, and collapses to the floor to rest - just like after a lost fight.")
		addButton("Continue", "Catch your breath", "endthescene")
		return

	if(state == "vomited"):
		var room = _predatorRoom()
		if(room != ""):
			aimCameraAndSetLocName(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("It is too much. " + predName + " doubles over, gut heaving violently, and brings you back up in a rush of slick. You tumble out onto the floor, free at last.")
		addButton("Continue", "Pick yourself up", "endthescene")
		return

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "open_wait"):
		setState("waiting")
		return

	if(_action == "dowait_belly"):
		var newt = _args[0]
		if(GM.main != null):
			GM.main.processTime(newt)
		_syncBelly()
		predatorActivity = ACTIVITIES[RNG.randi_range(0, ACTIVITIES.size() - 1)]
		if(GM.ES.triggerReact(Trigger.Waiting, [newt])):
			endScene()
			return
		setState("")
		return

	if(_action == "do_sleep"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		GM.main.startNewDay()
		GM.pc.afterSleepingInBed()
		_syncBelly()
		predatorActivity = ACTIVITIES[RNG.randi_range(0, ACTIVITIES.size() - 1)]
		var dig = GM.pc.getEffect("VorePlayerDigesting")
		var day = 1
		if(dig != null):
			day = dig.advanceDay()
		if(day >= 6):
			runScene("VoreDigestedDeathScene", [predID])
			endScene()
			return
		if(day >= 4):
			GM.pc.addStamina(-GM.pc.getStamina())
			GM.pc.addPain(GM.pc.painThreshold())
		setState("slept_belly")
		return

	if(_action == "do_struggle"):
		setState("minigame")
		return

	if(_action == "open_actions"):
		setState("actions")
		return

	if(_action == "open_talk"):
		setState("talk")
		return

	if(_action == "back_to_belly"):
		setState("")
		return

	if(_action == "resolve_escape"):
		var success = _mgInstant || (!_mgFailedHard && _mgScore >= ESCAPE_THRESHOLD)
		if(success):
			_doEscape()
			GM.pc.addSkillExperience("Vore", 10)
			setState("escaped")
		else:
			failedAttempts += 1
			if(GM.main != null):
				GM.main.addMessage("You thrash and push, but " + predName + "'s body holds firm. You'll have to try again.")
				GM.main.processTime(10 * 60)
			setState("")
		return

	if(_action == "act_kick"):
		_doHit("hurt", 14, predName + " lurches as your foot crashes into their gut from the inside, doubling over with a pained grunt.")
		return

	if(_action == "act_punch"):
		_doHit("hurt", 10, "You hammer your fists into the soft walls. " + predName + " winces and clutches their churning belly.")
		return

	if(_action == "act_headbutt"):
		_doHit("hurt", 16, "You throw your whole weight into a savage headbutt. " + predName + " stumbles, gasping, their stomach throbbing.")
		return

	if(_action == "act_bite"):
		_doHit("hurt", 18, "You sink your teeth into the fleshy wall. " + predName + " yelps and slaps at their bulging gut.")
		return

	if(_action == "act_stretch"):
		_doHit("hurt", 12, "You brace and shove outward with all four limbs. " + predName + "'s belly stretches grotesquely as they groan in pain.")
		return

	if(_action == "act_squirm"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addArousal(4.0)
			predator.addPain(4)
			painDealt += 4
		GM.main.addMessage("You writhe and wriggle, leaving " + predName + " shifting uncomfortably.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		_checkForcedOut()
		if(state == "actions"):
			pendingAnim = "hurt"
		return

	if(_action == "talk_beg"):
		var like = _likeValue()
		if(like >= 0.5 && RNG.randi_range(1, 100) <= 35):
			_doRelease()
			setState("escaped")
			return
		GM.main.addMessage(predName + " just laughs at your muffled begging.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		setState("talk")
		return

	if(_action == "talk_ask"):
		GM.main.addMessage(predName + " idly explains they're just going about their day - with you along for the ride.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		setState("talk")
		return

	if(_action == "talk_flirt"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addArousal(6.0)
		GM.main.addMessage("You purr and press against them invitingly. " + predName + "'s belly gives an interested squeeze.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		setState("talk")
		return

	if(_action == "talk_threat"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addPain(3)
			painDealt += 3
		GM.main.addMessage("You snarl out a threat. " + predName + " only tightens around you in answer.")
		if(GM.main != null):
			GM.main.processTime(2 * 60)
		_checkForcedOut()
		if(state == "talk"):
			setState("talk")
		return

	setState(_action)

func _doHit(anim, amount, text):
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.addPain(amount)
		painDealt += amount
	if(GM.main != null):
		GM.main.addMessage(text)
		GM.main.processTime(2 * 60)
	_checkForcedOut()
	if(state == "actions"):
		pendingAnim = anim

func _checkForcedOut():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return
	if(predator.getPain() >= predator.painThreshold()):
		_doEscape()
		GM.pc.addSkillExperience("Vore", 15)
		setState("vomited")

func _doEscape():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = _predatorRoom()
	if(GM.main != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.makeExhausted()
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)

func _doRelease():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = _predatorRoom()
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)

func onEscapeMinigameDone(result):
	_mgScore = result.score
	_mgFailedHard = result.failedHard
	_mgInstant = result.instantUnlock
	GM.main.pickOption("resolve_escape", [])

func supportsShowingPawns() -> bool:
	return true

func saveData():
	var data = .saveData()
	data["predID"]         = predID
	data["predName"]       = predName
	data["failedAttempts"] = failedAttempts
	data["painDealt"]      = painDealt
	data["predatorActivity"] = predatorActivity
	return data

func loadData(data):
	.loadData(data)
	predID         = SAVE.loadVar(data, "predID", "")
	predName       = SAVE.loadVar(data, "predName", "your predator")
	failedAttempts = SAVE.loadVar(data, "failedAttempts", 0)
	painDealt      = SAVE.loadVar(data, "painDealt", 0)
	predatorActivity = SAVE.loadVar(data, "predatorActivity", "wandering along without a care")
