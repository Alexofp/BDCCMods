extends "res://Scenes/SceneBase.gd"
var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")
const VoreRebirthController = preload("res://Modules/VoreMod/StatusEffects/VoreRebirthController.gd")
const VorePowerHelper = preload("res://Modules/VoreMod/VorePowerHelper.gd")
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
const ESCAPE_THRESHOLD = 0.5
const STRUGGLE_PAIN_TARGET = 95
const STRUGGLE_COOLDOWN = 15 * 60
const STRUGGLE_STAMINA = 25
const THREAT_COOLDOWN = 10 * 60
const THREAT_BASE_PAIN = 3
const BEG_COOLDOWN = 45 * 60
const FLIRT_BONUS_PER_USE = 8.0
const FLIRT_BONUS_CAP = 32.0
const LUST_THRESHOLD = 0.5
const LUST_BEG_BONUS = 10.0
const LIKE_BEG_BONUS = 15.0
const BRIBE_AMOUNT = 60

var predID = ""
var predName = "your predator"
var voreMethod = "mouth"
var wombRebirthMode = false
var endosomaMode = false
var methodChosen = false
var failedAttempts = 0
var painDealt = 0
var predatorActivity = "wandering along without a care"
var pendingAnim = ""
var _struggleCooldown = 0.0
var _threatCooldown = 0.0
var _begCooldown = 0.0
var threatUses = 0
var begUses = 0
var bribeUses = 0
var _flirtBonus = 0.0
var _mgScore = 0.0
var _mgFailedHard = false
var _mgInstant = false
var escapeProgress = 0.0
var lastPredActionText = ""

const ACTIVITIES = [
	"rummaging through a nearby locker",
	"trading idle words with another inmate",
	"leaning against the wall to catch their breath",
	"strolling down the corridor without a care",
	"stretching, one hand resting on the swell of their bulging middle",
	"patting their bloated bulge with a satisfied sigh",
	"glancing around the room, looking for something to do",
	"shifting their weight, your bulge swaying with every step",
]

func _init():
	sceneID = "VoreBellyRideScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])
	if(_args.size() > 1 && str(_args[1]) != ""):
		var wanted = str(_args[1])
		if(wanted == "__random__" || wanted == "random"):
			wanted = _rollPredatorMethod()
		if(wanted != ""):
			voreMethod = wanted
			methodChosen = true
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()
		if(GM.main != null):
			var _p = GM.main.IS.spawnPawnIfNeeded(predID)
	if(methodChosen):
		_applyBelly()

func _part():
	match voreMethod:
		"mouth":   return "belly"
		"breasts": return "breasts"
		"anus":    return "guts"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye socket"
		"ear":     return "ear canal"
	return "belly"

func _rollPredatorMethod():
	var available = _availableMethods()
	if(available.size() <= 0):
		return ""
	available.shuffle()
	return str(available[0])

func _availableMethods():
	var result = []
	var predator = GlobalRegistry.getCharacter(predID)
	var pool = ["mouth", "anus", "tail"]
	if(predator != null && predator.hasNonFlatBreasts()):
		pool.append("breasts")
	if(predator != null && predator.hasPenis()):
		pool.append("cock")
	if(predator != null && predator.hasVagina()):
		pool.append("vagina")
	for m in pool:
		if(!VoreSwallowed.isMethodBlockedForPC(GM.pc, m)):
			result.append(m)
	return result

func _allMethods():
	return ["mouth", "breasts", "anus", "cock", "vagina", "tail"]

func _methodDisabledReason(m):
	var predator = GlobalRegistry.getCharacter(predID)
	match m:
		"breasts":
			if(predator == null || !predator.hasNonFlatBreasts()):
				return predName + " doesn't have the breasts for this.."
		"cock":
			if(predator == null || !predator.hasPenis()):
				return predName + " doesn't have a penis.."
		"vagina", "vagina_rebirth":
			if(predator == null || !predator.hasVagina()):
				return predName + " doesn't have a vagina.."
	return "This method isn't available right now.."

func _methodLabel(m):
	match m:
		"mouth":   return "Swallowed whole"
		"breasts": return "Into the breasts"
		"anus":    return "Up the rear"
		"cock":    return "Into the cock"
		"vagina":  return "Into the womb"
		"tail":    return "Coiled up in tail"
	return "Devoured"

func _methodDesc(m):
	match m:
		"mouth":   return "Get gulped straight down into " + predName + "'s belly"
		"breasts": return "Get drawn and absorbed into " + predName + "'s breasts"
		"anus":    return "Get stuffed up into " + predName + "'s guts"
		"cock":    return "Get drawn down into " + predName + "'s balls"
		"vagina":  return "Get drawn up into " + predName + "'s womb"
		"tail":    return "Get coiled up and swallowed into " + predName + "'s tail"
	return "Get gulped down whole"

func _unlockPredatorAI():
	if(GM.main == null || predID == ""):
		return
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn == null):
		return
	if(pawn.has_method("clearSceneLocks")):
		pawn.clearSceneLocks()
	if(pawn.has_method("clearInteractionLock")):
		pawn.clearInteractionLock()
	if(pawn.has_method("setAIState")):
		pawn.setAIState(0)
	elif(pawn.has_method("setState")):
		pawn.setState(0)
	if(pawn.has_method("moveToNextRandomCell")):
		pawn.moveToNextRandomCell()
	elif(pawn.has_method("moveToRandomNeighbor")):
		pawn.moveToRandomNeighbor()

func _applyBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		if(!predator.hasEffect("VorePredatorBelly")):
			predator.addEffect("VorePredatorBelly", [GM.pc.getName(), voreMethod])
		if(!endosomaMode && !GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.addEffect("VorePlayerDigesting", [predName, voreMethod])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.setLocation(GM.pc.getLocation())
	_unlockPredatorAI()

func _syncBelly():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && GM.pc != null):
		if(!predator.hasEffect("VorePredatorBelly")):
			predator.addEffect("VorePredatorBelly", [GM.pc.getName(), voreMethod])
		if(!endosomaMode && !GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.addEffect("VorePlayerDigesting", [predName, voreMethod])
	if(GM.main != null && GM.pc != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn == null):
			pawn = GM.main.IS.spawnPawnIfNeeded(predID)
		if(pawn != null):
			var predLoc = pawn.getLocation()
			if(predLoc != null && predLoc != ""):
				if(GM.pc.has_method("setLocationSilent")):
					GM.pc.setLocationSilent(predLoc)
				else:
					GM.pc.setLocation(predLoc)
			else:
				pawn.setLocation(GM.pc.getLocation())

func _isFullyHypnotized():
	if(GM.pc == null):
		return false
	var susp = GM.pc.getEffect("Suggestible")
	if(susp != null && susp.has_method("isInTrance")):
		return susp.isInTrance()
	return false

func _isSubdued():
	if(GM.pc == null):
		return false
	if(GM.pc.has_method("getPain") && GM.pc.has_method("painThreshold")):
		return GM.pc.getPain() >= GM.pc.painThreshold()
	return false

func _abortPreyState():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null && predator.hasEffect("VorePredatorBelly")):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")

func _setRoomDisplay(room):
	if(room == ""):
		return
	if(_hard()):
		aimCameraAndSetLocName("Somewhere Unknown")
	else:
		aimCameraAndSetLocName(room)

func _predatorRoom():
	if(GM.main == null):
		return ""
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn == null):
		return ""
	return pawn.getLocation()

func _dig():
	if(GM.pc == null || !GM.pc.hasEffect("VorePlayerDigesting")):
		return null
	return GM.pc.getEffect("VorePlayerDigesting")

func _stage():
	var dig = _dig()
	if(dig == null):
		return 1
	return dig.getDigestionDay()

func _pastNoReturn():
	var dig = _dig()
	if(dig == null || endosomaMode):
		return false
	return dig.isPastNoReturn()

func _hard():
	if(GM.pc == null):
		return false
	return GM.pc.hasPerk("VoreHardenedPrey")

func _calcDifficulty():
	var diff = 5 - failedAttempts
	if(_hard()):
		diff += 1
	if(_pastNoReturn()):
		diff += 2
	if(diff < 2):
		diff = 2
	return diff

func _passTime(seconds):
	if(GM.main != null):
		GM.main.processTime(seconds)
	_struggleCooldown = max(0.0, _struggleCooldown - float(seconds))
	_threatCooldown = max(0.0, _threatCooldown - float(seconds))
	_begCooldown = max(0.0, _begCooldown - float(seconds))
	_maybePredatorInteract(seconds)

func _maybePredatorInteract(secondsPassed):
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null || GM.pc == null):
		return
	var chance = 35
	if(_hard()):
		chance = 60
	if(secondsPassed >= 600):
		chance += 25
	if(RNG.randi_range(1, 100) > chance):
		return
	var actions = ["squeeze", "mock", "pat", "lie_down"]
	if(predator.has_method("personalityScore")):
		if(predator.personalityScore({PersonalityStat.Mean: 1.0}) > 0.3):
			actions.append("squeeze")
			actions.append("mock")
		if(predator.personalityScore({PersonalityStat.Subby: 1.0}) > 0.3):
			actions.append("pat")
	actions.shuffle()
	var act = actions[0]
	var part = _part()
	var stg = _stage()
	match act:
		"squeeze":
			var pain = int(round(4.0 + stg * 3.0))
			if(endosomaMode):
				pain = int(round(pain * 0.4))
			GM.pc.addPain(pain)
			GM.pc.addStamina(-int(round(6.0 + stg * 2.0)))
			if(GM.pc.has_method("addConsciousness")):
				GM.pc.addConsciousness(-4.0)
			lastPredActionText = predName + " suddenly wraps both hands around their " + part + " and [b]squeezes[/b] down tight! You are crushed into the fleshy interior, gasping for breath."
			if(GM.main != null):
				GM.main.addMessage(lastPredActionText)
		"mock":
			lastPredActionText = predName + " pats the tight bulge of their " + part + ", chuckling cruelly. \"Keep squirming in there, little snack. You're never getting out.\""
			if(GM.main != null):
				GM.main.addMessage(lastPredActionText)
		"pat":
			lastPredActionText = predName + " gently strokes the curve of their " + part + ", sighing with satisfaction at the full, heavy weight of carrying you."
			if(GM.main != null):
				GM.main.addMessage(lastPredActionText)
		"lie_down":
			var pain2 = int(round(6.0 + stg * 2.0))
			if(endosomaMode):
				pain2 = int(round(pain2 * 0.4))
			GM.pc.addPain(pain2)
			GM.pc.addStamina(-10)
			lastPredActionText = predName + " leans heavily against a wall and shifts their full weight against their " + part + ", flattening you into the tight, yielding slime."
			if(GM.main != null):
				GM.main.addMessage(lastPredActionText)

func _resetCooldowns():
	_struggleCooldown = 0.0
	_threatCooldown = 0.0
	_begCooldown = 0.0
	threatUses = 0
	begUses = 0
	bribeUses = 0
	_flirtBonus = 0.0
	escapeProgress = 0.0

func _likeValue():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return 0.0
	var fh = predator.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")

func _affectionTowardsPlayer():
	if(GM.main == null):
		return 0.0
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn != null && pawn.has_method("getAffection")):
		return pawn.getAffection("pc")
	return 0.0

func _lustTowardsPlayer():
	if(GM.main == null):
		return 0.0
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn != null && pawn.has_method("getLust")):
		return pawn.getLust("pc")
	return 0.0

func _begChance():
	if(_pastNoReturn()):
		return 0.0
	var chance = 10.0
	chance += _affectionTowardsPlayer() * 40.0
	chance += _flirtBonus
	if(_likeValue() >= 0.5):
		chance += LIKE_BEG_BONUS
	if(_lustTowardsPlayer() >= LUST_THRESHOLD):
		chance += LUST_BEG_BONUS
	chance -= float(begUses) * 15.0
	return clamp(chance, 0.0, 85.0)

func _applyAftermath(stageNum):
	if(GM.pc == null || endosomaMode):
		return
	if(stageNum >= 1):
		GM.pc.addEffect("VorePreyAftermath", [predName, voreMethod, stageNum])

func _handleFinalStage():
	if(endosomaMode):
		return false
	var dig = _dig()
	if(dig == null || dig.getDigestionDay() < 6):
		return false
	if(GM.pc != null && GM.pc.hasPerk("VoreFusion")):
		var predatorChar = GlobalRegistry.getCharacter(predID)
		var fusionHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd").new()
		fusionHelper.performFusionWithMessages(GM.pc, predatorChar)
		if(GM.pc.hasEffect("VorePlayerDigesting")):
			GM.pc.removeEffect("VorePlayerDigesting")
		if(predatorChar != null && predatorChar.hasEffect("VorePredatorBelly")):
			predatorChar.removeEffect("VorePredatorBelly")
		GM.pc.addStamina(GM.pc.getMaxStamina())
		if(GM.pc.has_method("addConsciousness")):
			GM.pc.addConsciousness(100.0)
		if(GM.main != null && GM.main.IS.hasPawn(predID)):
			GM.main.IS.deletePawn(predID)
		if(GM.main != null && GM.main.dynamicCharacters.has(predID)):
			GM.main.removeDynamicCharacter(predID)
		runScene("VoreFusionScene", [predID, predName])
		endScene()
		return true
	if(GM.pc != null && GM.pc.hasEffect("VoreTotemActive")):
		_doTotemRescue()
		runScene("VoreTotemRescueScene", [predID])
		endScene()
		return true
	if(wombRebirthMode):
		var predatorChar = GlobalRegistry.getCharacter(predID)
		if(predatorChar != null && GM.pc != null):
			var rebirthOk = VoreRebirthController.convertPreyToPregnancy("pc", GM.pc.getName(), GM.pc.getSpecies(), GM.pc.calculateNpcGender(), predatorChar)
			if(rebirthOk):
				if(GM.pc.hasEffect("VorePlayerDigesting")):
					GM.pc.removeEffect("VorePlayerDigesting")
				if(predatorChar.hasEffect("VorePredatorBelly")):
					predatorChar.removeEffect("VorePredatorBelly")
				GM.pc.addStamina(GM.pc.getMaxStamina())
				if(GM.main != null):
					GM.main.addMessage("The last of your old self comes undone deep inside " + predName + "'s womb -- not digested, but unmade and reshaped into raw new life. " + predName + " is left carrying a reborn copy of you, and with a final shudder their body pushes you back out, whole and free once more.")
				GM.pc.addSkillExperience("Vore", 100)
				if(GM.main != null):
					GM.main.addMessage("Rebirth begun! +100 Vore XP")
				endScene()
				return true
			else:
				if(GM.main != null):
					GM.main.addMessage(predName + "'s body tries to reshape you into new life, but they have no womb able to carry it. You are simply digested instead.")
	runScene("VoreDigestedDeathScene", [predID, voreMethod])
	endScene()
	return true

func _isFinalStageReached() -> bool:
	if(endosomaMode):
		return false
	var dig = _dig()
	if(dig == null):
		return false
	return dig.getDigestionDay() >= 6
func _finalStagePrompt():
	var room = _predatorRoom()
	if(room != ""):
		_setRoomDisplay(room)
	if(predID != ""):
		addCharacter(predID)
		playAnimation(StageScene.Solo, "stand", {pc = predID})
	saynn("[color=#ff3333][b]Digestion Stage: 6 of 6.[/b][/color]")
	saynn("There is nothing left to fight with. The last of you comes apart in the churning heat of " + predName + "'s " + _part() + " -- whatever happens now is already out of your hands.")
	addButton("Continue", "There is no going back from here", "final_stage")
func _run():
	if(_isFinalStageReached()):
		_finalStagePrompt()
		return
	if(!methodChosen):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			_abortPreyState()
			saynn("Your predator is nowhere to be found.")
			addButton("Continue", "Get up", "endthescene")
			return
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "stand", {pc = predID})
		saynn(predName + " has you helpless and looms over you, deciding just how to take you in. How do they devour you?")
		var available = _availableMethods()
		if(available.size() <= 0):
			saynn("You can feel " + predName + "'s hunger pressing against your will - but the only way they could take you is one you have made untouchable. Your forbidden protection holds: no matter how they try, they simply cannot take you in.")
			addButton("Continue", "They can't take you", "endthescene")
			return
		for m in _allMethods():
			if(m in available):
				addButton(_methodLabel(m), _methodDesc(m), "pick_method", [m])
			else:
				addDisabledButton(_methodLabel(m), _methodDisabledReason(m))
		return
	if(state == ""):
		if(_isFinalStageReached()):
			_finalStagePrompt()
			return
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			_abortPreyState()
			saynn("Your predator is nowhere to be found. You spill back out into the open, free.")
			addButton("Continue", "Get up", "endthescene")
			return
		if(methodChosen && VoreSwallowed.isMethodBlockedForPC(GM.pc, voreMethod)):
			_abortPreyState()
			saynn("As " + predName + " tries to take you in, a deep-seated protection stirs inside you. The way they chose is forbidden to you - their attempt simply fails, and they cannot so much as begin.")
			addButton("Continue", "They can't take you this way", "endthescene")
			return
		_syncBelly()
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		if(endosomaMode):
			saynn("You are nestled comfortably inside " + predName + ", curled up in the warm, safe interior of their " + _part() + ". No digestion threatens you here -- you are simply being carried along, sheltered within them like a living home.")
		else:
			saynn("You are sealed inside " + predName + ", curled up in the hot, churning dark of their " + _part() + ". There is no seeing out - all you can do is feel every step they take and ride along wherever they go.")
		var roomObj = null
		if(room != "" && GM.world != null):
			roomObj = GM.world.getRoomByID(room)
		if(_hard()):
			saynn("You have no idea where you are. Sealed in the muffled, hot dark, all you can feel is " + predName + " swaying with every step -- " + predatorActivity + ".")
		elif(roomObj != null):
			saynn("Right now " + predName + " is in [b]" + roomObj.getName() + "[/b], " + predatorActivity + ", their swollen " + _part() + " swaying with you inside it.")
		else:
			saynn(predName + " carries you along, " + predatorActivity + ", their swollen " + _part() + " swaying with you inside it.")
		if(lastPredActionText != ""):
			saynn("[color=#ffaaaa]" + lastPredActionText + "[/color]")
		if(escapeProgress > 0.0):
			saynn("[i]Escape progress: " + str(int(round(escapeProgress * 100.0))) + "%. The walls are yielding under your struggles.[/i]")
		if(failedAttempts > 0):
			saynn("[i]Your previous struggles have left them a little careless - your next escape attempt will be easier.[/i]")
		if(!endosomaMode):
			var curStage = _stage()
			saynn("[b]Digestion Stage: " + str(curStage) + " of 6.[/b]")
			if(_pastNoReturn()):
				saynn("[color=#ff3333][b]POINT OF NO RETURN:[/b] Digestion has eaten away too much of you. Your body is dissolving into slurry -- they will never release you now, and struggling is near impossible![/color]")
		if(GM.pc != null):
			var stmText = "Stamina: " + str(int(GM.pc.getStamina())) + "/" + str(int(GM.pc.getMaxStamina()))
			var pnText = "Pain: " + str(int(GM.pc.getPain())) + "/" + str(int(GM.pc.painThreshold()))
			saynn("[i]" + stmText + " | " + pnText + "[/i]")
		if(GM.main != null && GM.main.isVeryLate()):
			saynn("[i]It is the dead of night. Trapped inside " + predName + ", there is nothing left to do but let sleep drag you under until the prison stirs again.[/i]")
			addButton("Sleep", "You have no choice but to sleep the night away inside " + predName + "'s " + _part(), "do_sleep")
			return
		addButton("Wait", "Pass some time inside " + predName + "'s " + _part() + " (recovers stamina)", "open_wait")
		addButton("Sleep", "Curl up and sleep inside " + predName + "'s " + _part() + " until the next day", "do_sleep")
		if(_isFullyHypnotized()):
			addDisabledButton("Fight", "You are far too deep in trance to even think of fighting your way out...")
		elif(_isSubdued()):
			addDisabledButton("Fight", "You are in too much pain to struggle. Catch your breath first.")
		elif(GM.pc != null && GM.pc.getStamina() < STRUGGLE_STAMINA):
			addDisabledButton("Fight", "Not enough stamina to struggle (needs " + str(STRUGGLE_STAMINA) + "). Wait to recover.")
		elif(_struggleCooldown > 0.0):
			addDisabledButton("Fight", "You're still too exhausted from your last attempt. You need about " + str(int(ceil(_struggleCooldown / 60.0))) + " more minutes to recover.")
		else:
			addButton("Fight", "Squirm and force your way back out [" + str(STRUGGLE_STAMINA) + " stamina, timing minigame]", "do_struggle")
		addButton("Talk", "Try to speak with " + predName + " from inside their " + _part(), "open_talk")
		if(_isFullyHypnotized()):
			addDisabledButton("Actions", "You are far too deep in trance to act against " + predName + "...")
		elif(_isSubdued()):
			addDisabledButton("Actions", "You are in too much pain to attack from inside.")
		else:
			addButton("Actions", "Do something to " + predName + " from the inside (costs stamina)", "open_actions")
		addButton("Inventory", "Open your inventory to use items (like energy drinks, pills, or food)", "open_inventory")
		return
	if(state == "actions"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		if(pendingAnim != ""):
			playAnimation(StageScene.Solo, pendingAnim, {pc = predID})
			pendingAnim = ""
		else:
			playAnimation(StageScene.Solo, "walk", {pc = predID})
		saynn("Pressed against the walls of " + predName + "'s " + _part() + ", you have room to strike from within. What do you do?")
		var painGoal = int(min(predator.painThreshold(), STRUGGLE_PAIN_TARGET))
		saynn("[i]" + predName + "'s pain: " + str(int(predator.getPain())) + " / " + str(painGoal) + ". Hurt them enough (" + str(painGoal) + " pain) and they will be forced to vomit you up.[/i]")
		if(GM.pc != null):
			saynn("[i]Your Stamina: " + str(int(GM.pc.getStamina())) + "/" + str(int(GM.pc.getMaxStamina())) + "[/i]")
		var armsBound = GM.pc != null && GM.pc.hasBoundArms()
		var handsBlocked = GM.pc != null && GM.pc.hasBlockedHands()
		var legsBound = GM.pc != null && GM.pc.hasBoundLegs()
		var oralBlocked = GM.pc != null && (GM.pc.isOralBlocked() || GM.pc.isGagged() || GM.pc.isBitingBlocked())
		var curStam = (GM.pc.getStamina() if GM.pc != null else 100)

		if(curStam < 14):
			addDisabledButton("Kick", "Needs 14 stamina.")
		else:
			var kDesc = "Slam a foot hard into the walls (14 stamina, 8 min)"
			if(legsBound):
				kDesc = "Legs bound -- exhausting kick with both feet (25 stamina, 8 min)"
			addButton("Kick", kDesc, "act_kick")

		if(armsBound):
			addDisabledButton("Punch", "Your arms are bound!")
		elif(curStam < 10):
			addDisabledButton("Punch", "Needs 10 stamina.")
		else:
			var pDesc = "Hammer your fists against the walls (10 stamina, 6 min)"
			if(handsBlocked):
				pDesc += " (muffled fists deal less pain)"
			addButton("Punch", pDesc, "act_punch")

		if(curStam < 16):
			addDisabledButton("Headbutt", "Needs 16 stamina.")
		else:
			addButton("Headbutt", "Throw your whole weight into a savage headbutt (16 stamina, 10 min)", "act_headbutt")

		if(oralBlocked):
			addDisabledButton("Bite", "Mouth or muzzle is bound/gagged!")
		elif(curStam < 12):
			addDisabledButton("Bite", "Needs 12 stamina.")
		else:
			addButton("Bite", "Sink your teeth into the fleshy wall (12 stamina, 8 min)", "act_bite")

		if(armsBound && legsBound):
			addDisabledButton("Stretch", "Both arms and legs bound -- impossible to shove outward!")
		elif(curStam < 18):
			addDisabledButton("Stretch", "Needs 18 stamina.")
		else:
			addButton("Stretch", "Brace and shove outward, stretching them painfully (18 stamina, 12 min)", "act_stretch")

		if(curStam < 6):
			addDisabledButton("Squirm", "Needs 6 stamina.")
		else:
			addButton("Squirm", "Writhe and wriggle around to unsettle them (6 stamina, 5 min)", "act_squirm")

		addButton("Back", "Settle down for now", "back_to_belly")
		return
	if(state == "talk"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		var like = _likeValue()
		saynn("Your voice comes out muffled through layers of flesh, but " + predName + " can still hear you grumbling inside them.")
		if(_pastNoReturn()):
			saynn("[color=#ff3333]" + predName + " pats their churning " + _part() + ", voice cold and mocking. \"Save your breath. You're basically digested already. There's nothing left of you to let out.\"[/color]")
		elif(like >= 0.5):
			saynn(predName + " gives their " + _part() + " a fond pat. \"Mmh, comfy in there? You feel [i]wonderful[/i] sloshing around inside me.\"")
		elif(like >= 0.125):
			saynn(predName + " chuckles, rubbing the squirming bulge. \"Settle down, little snack. You're not going anywhere just yet.\"")
		elif(like <= -0.5):
			saynn(predName + " scowls down at their " + _part() + ". \"Keep talking. It just makes taking you down feel that much sweeter.\"")
		else:
			saynn(predName + " shrugs, one hand on the swell of their " + _part() + ". \"Make yourself comfortable. You'll be in there a while.\"")
		
		if(_pastNoReturn()):
			addDisabledButton("Beg to be let out", "Point of no return -- they will not let out a half-dissolved meal.")
		elif(_begCooldown > 0.0):
			addDisabledButton("Beg to be let out", "You must wait " + str(int(ceil(_begCooldown / 60.0))) + " minutes before begging again.")
		elif(begUses >= 3):
			addDisabledButton("Beg to be let out", "They are thoroughly annoyed by your repeated begging and refuse to listen anymore.")
		else:
			addButton("Beg to be let out", "Plead with them to let you back out (15 min, cooldown applies)", "talk_beg")

		var credits = (GM.pc.getCredits() if GM.pc != null && GM.pc.has_method("getCredits") else 0)
		if(_pastNoReturn()):
			addDisabledButton("Bribe", "No amount of credits buys back a body this far gone.")
		elif(bribeUses >= 2):
			addDisabledButton("Bribe", "They have already refused your bribery.")
		elif(credits < BRIBE_AMOUNT):
			addDisabledButton("Bribe (" + str(BRIBE_AMOUNT) + "c)", "You need at least " + str(BRIBE_AMOUNT) + " credits.")
		else:
			addButton("Bribe (" + str(BRIBE_AMOUNT) + "c)", "Offer " + str(BRIBE_AMOUNT) + " credits to let you out", "talk_bribe")

		addButton("Ask where they're headed", "Ask what they plan to do with you", "talk_ask")
		addButton("Flirt", "Try to charm your way into their good graces", "talk_flirt")
		if(_threatCooldown > 0.0):
			addDisabledButton("Threaten", "Your voice needs a break. You need about " + str(int(ceil(_threatCooldown / 60.0))) + " more minutes before you can threaten them again.")
		else:
			addButton("Threaten", "Promise they'll regret taking you in", "talk_threat")
		addButton("Back", "Stop talking", "back_to_belly")
		return
	if(state == "waiting"):
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		saynn("Sealed in the churning dark of " + predName + "'s " + _part() + ", you decide to rest and pass the time. Resting restores your stamina.")
		addButton("15 minutes (+15 stam)", "Rest a bit", "dowait_belly", [15 * 60, 15])
		addButton("30 minutes (+30 stam)", "Rest for half an hour", "dowait_belly", [30 * 60, 30])
		addButton("1 hour (+60 stam)", "Rest for an hour", "dowait_belly", [1 * 60 * 60, 60])
		addButton("2 hours (Full stam)", "Rest for two hours", "dowait_belly", [2 * 60 * 60, 150])
		addButton("Back", "Don't wait", "back_to_belly")
		return
	if(state == "slept_belly"):
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "walk", {pc = predID})
		var day = _stage()
		saynn("You let the suffocating heat and the gentle sway of " + predName + "'s " + _part() + " lull you under, curling up as small as you can in the cramped, slick dark.")
		saynn("Sleep takes you, and the hours slip away as " + predName + " carries you along through the night.")
		saynn("You wake to the prison lights flickering on - still sealed inside " + predName + "'s " + _part() + ". Welcome to day " + str(GM.main.getDays()) + " of your sentence.")
		saynn("[i]Digestion has advanced to stage " + str(day) + " of 6.[/i]")
		if(day >= 4):
			saynn("[color=#ff5555]The acids have truly taken hold. You wake utterly drained of stamina, your body wracked with mounting pain. If you keep sleeping in here, you will not wake up again.[/color]")
		addButton("Continue", "Wake up inside", "back_to_belly")
		return
	if(state == "minigame"):
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("voreride_minigame", game)
		game.setDifficulty(_calcDifficulty())
		game.connect("minigameCompleted", self, "onEscapeMinigameDone")
		return
	if(state == "escaped"):
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("With one last desperate heave you force the muscles open and spill out of " + predName + " in a slick, gasping heap!")
		saynn(predName + " staggers, utterly spent, and collapses to the floor to rest - just like after a lost fight.")
		addButton("Continue", "Catch your breath", "endthescene")
		return
	if(state == "vomited"):
		var room = _predatorRoom()
		if(room != ""):
			_setRoomDisplay(room)
		addCharacter(predID)
		playAnimation(StageScene.Solo, "defeat", {pc = predID})
		saynn("It is too much. " + predName + " doubles over, " + _part() + " heaving violently, and forces you back out in a rush of slick. You tumble out onto the floor, free at last.")
		addButton("Continue", "Pick yourself up", "endthescene")
		return

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "final_stage"):
		if(!_handleFinalStage()):
			setState("")
		return
	if(_action == "pick_method"):
		if(_args.size() > 0):
			var pickedMethod = str(_args[0])
			if(VoreSwallowed.isMethodBlockedForPC(GM.pc, pickedMethod)):
				GM.main.addMessage("Something deep inside you refuses - that vore method is forbidden to you.")
				setState("")
				return
			if(pickedMethod == "vagina_rebirth"):
				voreMethod = "vagina"
				wombRebirthMode = true
				endosomaMode = false
			elif(pickedMethod.ends_with("_endo")):
				voreMethod = pickedMethod.replace("_endo", "")
				endosomaMode = true
				wombRebirthMode = false
			else:
				voreMethod = pickedMethod
				wombRebirthMode = false
				endosomaMode = false
		methodChosen = true
		_applyBelly()
		setState("")
		return
	if(_action == "open_wait"):
		setState("waiting")
		return
	if(_action == "dowait_belly"):
		var newt = _args[0]
		var stamGain = (_args[1] if _args.size() > 1 else 10)
		_passTime(newt)
		if(GM.pc != null):
			GM.pc.addStamina(stamGain)
		_syncBelly()
		predatorActivity = ACTIVITIES[RNG.randi_range(0, ACTIVITIES.size() - 1)]
		setState("")
		return
	if(_action == "do_sleep"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator == null):
			setState("")
			return
		var digBefore = _dig()
		var dayBefore = (digBefore.getDigestionDay() if digBefore != null else 1)
		GM.main.startNewDay()
		GM.pc.afterSleepingInBed()
		_resetCooldowns()
		_syncBelly()
		predatorActivity = ACTIVITIES[RNG.randi_range(0, ACTIVITIES.size() - 1)]
		if(endosomaMode):
			setState("slept_belly")
			return
		var dig = _dig()
		var day = dayBefore + 1
		if(dig != null):
			dig.setDigestionDay(day)
			dig.resetSecondsInside()
			day = dig.getDigestionDay()
		if(day >= 6):
			_handleFinalStage()
			return
		if(day >= 4):
			GM.pc.addStamina(-GM.pc.getStamina())
			GM.pc.addPain(GM.pc.painThreshold())
		setState("slept_belly")
		return
	if(_action == "do_struggle"):
		if(_isFullyHypnotized()):
			if(GM.main != null):
				GM.main.addMessage("You are far too deep in trance to fight back...")
			setState("")
			return
		if(_isSubdued()):
			if(GM.main != null):
				GM.main.addMessage("Your body simply will not obey -- you are in too much pain to struggle.")
			setState("")
			return
		if(GM.pc != null && GM.pc.getStamina() < STRUGGLE_STAMINA):
			if(GM.main != null):
				GM.main.addMessage("You don't have enough stamina to struggle right now.")
			setState("")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-STRUGGLE_STAMINA)
		var predatorChar = GlobalRegistry.getCharacter(predID)
		var percent = VorePowerHelper.percentToBeat(VorePowerHelper.getDamageStat(predatorChar), VorePowerHelper.getArmour(GM.pc))
		percent = clamp(percent, 15.0, 65.0)
		if(_pastNoReturn()):
			percent = clamp(percent + 20.0, 15.0, 85.0)
		if(!VorePowerHelper.beatsPercent(percent)):
			_passTime(6 * 60)
			_struggleCooldown = 6 * 60
			if(GM.main != null):
				GM.main.addMessage("You brace and shove with everything you have -- but " + predName + "'s body holds firm. Your struggles are pushed down, but you can try again soon. (Odds: " + str(int(round(percent))) + "%)")
			setState("")
			return
		setState("minigame")
		return
	if(_action == "open_inventory"):
		runScene("InventoryScene", [true])
		return
	if(_action == "open_actions"):
		if(_isFullyHypnotized()):
			if(GM.main != null):
				GM.main.addMessage("You are far too deep in trance to act against " + predName + "...")
			setState("")
			return
		setState("actions")
		return
	if(_action == "open_talk"):
		setState("talk")
		return
	if(_action == "back_to_belly"):
		setState("")
		return
	if(_action == "resolve_escape"):
		var success = _mgInstant || (!_mgFailedHard && _mgScore >= ESCAPE_THRESHOLD)
		if(success):
			var addProgress = 0.50
			if(_hard()):
				addProgress = 0.35
			if(_mgInstant):
				addProgress = 1.0
			escapeProgress += addProgress
			if(escapeProgress >= 1.0):
				_doEscape()
				GM.pc.addSkillExperience("Vore", 25)
				setState("escaped")
				return
			else:
				_passTime(6 * 60)
				_struggleCooldown = 2 * 60
				if(GM.main != null):
					GM.main.addMessage("You force yourself closer to the exit! The muscles stretch and loosen under your heaves (" + str(int(round(escapeProgress * 100.0))) + "% loosened). Keep pushing!")
				setState("")
				return
		else:
			failedAttempts += 1
			_passTime(6 * 60)
			_struggleCooldown = 8 * 60
			if(GM.main != null):
				GM.main.addMessage("You thrash and push, but " + predName + "'s body clamps down hard, forcing you back down. You're left gasping -- you'll need to catch your breath.")
			setState("")
		return
	if(_action == "act_kick"):
		var cost = 14
		var dmg = 7
		if(GM.pc != null && GM.pc.hasBoundLegs()):
			cost = 25
			dmg = 10
		if(GM.pc != null && GM.pc.getStamina() < cost):
			GM.main.addMessage("You are too exhausted to kick.")
			setState("actions")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-cost)
		_doHit("hurt", dmg, predName + " lurches as your foot crashes into them from the inside, doubling over with a pained grunt.", 8 * 60)
		return
	if(_action == "act_punch"):
		var cost = 10
		var dmg = 7
		if(GM.pc != null && GM.pc.hasBlockedHands()):
			dmg = 4
		if(GM.pc != null && GM.pc.getStamina() < cost):
			GM.main.addMessage("You are too exhausted to punch.")
			setState("actions")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-cost)
		_doHit("hurt", dmg, "You hammer your fists into the soft walls. " + predName + " winces and clutches their churning " + _part() + ".", 6 * 60)
		return
	if(_action == "act_headbutt"):
		var cost = 16
		if(GM.pc != null && GM.pc.getStamina() < cost):
			GM.main.addMessage("You are too exhausted to headbutt.")
			setState("actions")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-cost)
		_doHit("hurt", 9, "You throw your whole weight into a savage headbutt. " + predName + " stumbles, gasping, their " + _part() + " throbbing.", 10 * 60)
		return
	if(_action == "act_bite"):
		var cost = 12
		if(GM.pc != null && GM.pc.getStamina() < cost):
			GM.main.addMessage("You are too exhausted to bite.")
			setState("actions")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-cost)
		_doHit("hurt", 14, "You sink your teeth into the fleshy wall. " + predName + " yelps and slaps at their bulging " + _part() + ".", 8 * 60)
		return
	if(_action == "act_stretch"):
		var cost = 18
		if(GM.pc != null && GM.pc.getStamina() < cost):
			GM.main.addMessage("You are too exhausted to stretch outward.")
			setState("actions")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-cost)
		_doHit("hurt", 9, "You brace and shove outward with all four limbs. " + predName + "'s " + _part() + " stretches grotesquely as they groan in pain.", 12 * 60)
		return
	if(_action == "act_squirm"):
		var cost = 6
		if(GM.pc != null && GM.pc.getStamina() < cost):
			GM.main.addMessage("You are too exhausted to squirm.")
			setState("actions")
			return
		if(GM.pc != null):
			GM.pc.addStamina(-cost)
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addArousal(4.0)
			predator.addPain(4)
			painDealt += 4
		GM.main.addMessage("You writhe and wriggle, leaving " + predName + " shifting uncomfortably.")
		_passTime(5 * 60)
		_checkForcedOut()
		if(state == "actions"):
			pendingAnim = "hurt"
		return
	if(_action == "talk_beg"):
		begUses += 1
		_begCooldown = BEG_COOLDOWN
		var chance = _begChance()
		if(RNG.randi_range(1, 100) <= int(round(chance))):
			var aff = _affectionTowardsPlayer()
			if(aff >= 0.5):
				GM.main.addMessage("You plead with " + predName + " to let you out... and their affection for you finally wins out. With a reluctant sigh, their body opens and lets you back out.")
			elif(aff >= 0.1):
				GM.main.addMessage("You beg and plead from inside " + predName + " -- and, surprisingly, they give in, letting you back out.")
			else:
				GM.main.addMessage(predName + " gives in to your desperate begging and lets you out.")
			_doRelease()
			setState("escaped")
			return
		if(_affectionTowardsPlayer() >= 0.5):
			GM.main.addMessage(predName + " wavers, clearly tempted by your pleading... but in the end they decide to keep you a little longer.")
		else:
			GM.main.addMessage(predName + " just laughs at your muffled begging. \"You're not going anywhere, snack.\"")
		_passTime(15 * 60)
		setState("talk")
		return
	if(_action == "talk_bribe"):
		bribeUses += 1
		var credits = (GM.pc.getCredits() if GM.pc != null && GM.pc.has_method("getCredits") else 0)
		if(credits >= BRIBE_AMOUNT && GM.pc.has_method("addCredits")):
			GM.pc.addCredits(-BRIBE_AMOUNT)
		var predator = GlobalRegistry.getCharacter(predID)
		var bChance = 35.0 + _affectionTowardsPlayer() * 30.0
		if(predator != null && predator.has_method("personalityScore")):
			if(predator.personalityScore({PersonalityStat.Mean: 1.0}) > 0.3):
				bChance -= 20.0
		if(RNG.randi_range(1, 100) <= int(round(bChance))):
			GM.main.addMessage("\"Fine, deal.\" " + predName + " pockets your credits, heaves with a shudder, and regurgitates you onto the floor.")
			_doRelease()
			setState("escaped")
			return
		else:
			if(RNG.chance(50)):
				GM.main.addMessage("\"Thanks for the credits, cutie.\" " + predName + " laughs and rubs their belly -- they took your money and have no intention of letting you out!")
			else:
				GM.main.addMessage("\"Keep your money, I prefer my meal.\" " + predName + " rejects your bribe with a smirk.")
		_passTime(10 * 60)
		setState("talk")
		return
	if(_action == "talk_ask"):
		GM.main.addMessage(predName + " idly explains they're just going about their day - with you along for the ride.")
		_passTime(5 * 60)
		setState("talk")
		return
	if(_action == "talk_flirt"):
		var predator = GlobalRegistry.getCharacter(predID)
		if(predator != null):
			predator.addArousal(6.0)
			if(GM.main != null && GM.main.RS != null):
				GM.main.RS.addLust(predID, "pc", 0.02)
		_flirtBonus = min(FLIRT_BONUS_CAP, _flirtBonus + FLIRT_BONUS_PER_USE)
		if(_lustTowardsPlayer() >= LUST_THRESHOLD):
			GM.main.addMessage("You purr and press against them invitingly. " + predName + " shudders with obvious pleasure -- they're really starting to enjoy having you in there, and you can feel their resolve softening.")
		else:
			GM.main.addMessage("You purr and press against them invitingly. " + predName + "'s " + _part() + " gives an interested squeeze.")
		_passTime(5 * 60)
		setState("talk")
		return
	if(_action == "talk_threat"):
		var predator = GlobalRegistry.getCharacter(predID)
		var percent = VorePowerHelper.percentToBeat(VorePowerHelper.getDamageStat(GM.pc), VorePowerHelper.getArmour(predator))
		var painAmount = max(0, THREAT_BASE_PAIN - threatUses)
		threatUses += 1
		if(predator != null && painAmount > 0 && !VorePowerHelper.beatsPercent(percent)):
			predator.addPain(painAmount)
			painDealt += painAmount
			GM.main.addMessage("You snarl out a threat that actually lands -- " + predName + " flinches, and your words carry real weight from inside them. They would have needed to beat " + str(int(round(percent))) + "% odds to shrug it off.")
		elif(painAmount <= 0):
			GM.main.addMessage("You snarl out another threat, but " + predName + " has heard it all before by now -- the words bounce right off them.")
		else:
			GM.main.addMessage("You snarl out a threat, but " + predName + " just shrugs it off, their body tightening around you in answer.")
		_passTime(5 * 60)
		_threatCooldown = THREAT_COOLDOWN
		_checkForcedOut()
		setState("talk")
		return
	setState(_action)

func _doHit(anim, amount, hitText, timePassed = 120):
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.addPain(amount)
		painDealt += amount
	if(GM.main != null):
		GM.main.addMessage(hitText)
	_passTime(timePassed)
	if(_handleFinalStage()):
		return
	_checkForcedOut()
	if(state == "actions"):
		pendingAnim = anim

func _checkForcedOut():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return
	var target = min(predator.painThreshold(), STRUGGLE_PAIN_TARGET)
	if(predator.getPain() >= target):
		_doEscape()
		GM.pc.addSkillExperience("Vore", 15)
		setState("vomited")

func _doEscape():
	var curStage = _stage()
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = _predatorRoom()
	if(GM.main != null):
		var pawn = GM.main.IS.getPawn(predID)
		if(pawn != null):
			pawn.makeExhausted()
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)
	if(GM.pc != null && GM.pc.has_method("addConsciousness")):
		GM.pc.addConsciousness(100.0)
	_applyAftermath(curStage)

func _doRelease():
	var curStage = _stage()
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var room = _predatorRoom()
	if(GM.pc != null && room != ""):
		GM.pc.setLocation(room)
	if(GM.pc != null && GM.pc.has_method("addConsciousness")):
		GM.pc.addConsciousness(100.0)
	_applyAftermath(curStage)

func _doTotemRescue():
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predator.removeEffect("VorePredatorBelly")
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	if(GM.pc != null && GM.pc.hasEffect("VoreTotemActive")):
		GM.pc.removeEffect("VoreTotemActive")
	var room = "cell_mycell"
	if(GM.pc != null && GM.pc.has_method("getAnchorRoom")):
		room = GM.pc.getAnchorRoom()
	if(GM.pc != null):
		GM.pc.setLocation(room)
		GM.pc.addPain(-GM.pc.getPain())
		GM.pc.addStamina(GM.pc.getMaxStamina())
	_applyAftermath(4)

func onEscapeMinigameDone(result):
	_mgScore = result.score
	_mgFailedHard = result.failedHard
	_mgInstant = result.instantUnlock
	GM.main.pickOption("resolve_escape", [])

func supportsShowingPawns():
	return false

func saveData():
	var data = .saveData()
	data["predID"]         = predID
	data["predName"]       = predName
	data["voreMethod"]     = voreMethod
	data["wombRebirthMode"] = wombRebirthMode
	data["endosomaMode"] = endosomaMode
	data["methodChosen"]   = methodChosen
	data["failedAttempts"] = failedAttempts
	data["painDealt"]      = painDealt
	data["predatorActivity"] = predatorActivity
	data["struggleCooldown"] = _struggleCooldown
	data["threatCooldown"] = _threatCooldown
	data["begCooldown"]    = _begCooldown
	data["threatUses"]     = threatUses
	data["begUses"]        = begUses
	data["bribeUses"]      = bribeUses
	data["flirtBonus"]     = _flirtBonus
	data["escapeProgress"] = escapeProgress
	data["lastPredActionText"] = lastPredActionText
	return data

func loadData(data):
	.loadData(data)
	predID         = SAVE.loadVar(data, "predID", "")
	predName       = SAVE.loadVar(data, "predName", "your predator")
	voreMethod     = SAVE.loadVar(data, "voreMethod", "mouth")
	wombRebirthMode = SAVE.loadVar(data, "wombRebirthMode", false)
	endosomaMode = SAVE.loadVar(data, "endosomaMode", false)
	methodChosen   = SAVE.loadVar(data, "methodChosen", true)
	failedAttempts = SAVE.loadVar(data, "failedAttempts", 0)
	painDealt      = SAVE.loadVar(data, "painDealt", 0)
	predatorActivity = SAVE.loadVar(data, "predatorActivity", "wandering along without a care")
	_struggleCooldown = SAVE.loadVar(data, "struggleCooldown", 0.0)
	_threatCooldown   = SAVE.loadVar(data, "threatCooldown", 0.0)
	_begCooldown      = SAVE.loadVar(data, "begCooldown", 0.0)
	threatUses        = SAVE.loadVar(data, "threatUses", 0)
	begUses           = SAVE.loadVar(data, "begUses", 0)
	bribeUses         = SAVE.loadVar(data, "bribeUses", 0)
	_flirtBonus       = SAVE.loadVar(data, "flirtBonus", 0.0)
	escapeProgress    = SAVE.loadVar(data, "escapeProgress", 0.0)
	lastPredActionText = SAVE.loadVar(data, "lastPredActionText", "")
