extends "res://Scenes/SceneBase.gd"
var predID = ""
var predName = "your predator"
var voreMethod = "mouth"

func _init():
	sceneID = "VoreDigestedDeathScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])
	if(_args.size() > 1):
		voreMethod = str(_args[1])
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()

func _part():
	match voreMethod:
		"mouth":   return "gut"
		"breasts": return "breasts"
		"anus":    return "bowels"
		"cock":    return "cock and balls"
		"vagina":  return "womb"
		"tail":    return "tail"
		"eye":     return "eye socket"
		"ear":     return "ear canal"
	return "gut"

func _fluid():
	match voreMethod:
		"mouth":   return "stomach acids"
		"breasts": return "nourishing milk"
		"anus":    return "churning slick"
		"cock":    return "thick seed"
		"vagina":  return "womb fluids"
		"tail":    return "constricting slime"
	return "digestive juices"

func _run():
	if(state == ""):
		var part = _part()
		var fluid = _fluid()
		var isFast = false
		if(GM.pc != null && GM.pc.hasPerk("VoreHastenedDigestion")):
			isFast = true
		
		if(isFast):
			saynn("The relentless churning within " + predName + " finally runs its course. You do not survive to face another hour.")
			saynn("Hour by hour, the " + fluid + " and muscular walls of their " + part + " wore away at your strength. The last of your identity dissolved into slurry, completely broken down and absorbed into " + predName + " -- now nothing more than warmth, energy and soft weight on their body.")
		else:
			saynn("The sixth day inside " + predName + " dawns, but you do not wake to face it.")
			saynn("Through the long ordeal, the relentless churning of their " + part + " finished what it started. Bathed in " + fluid + ", the last of your strength dissolved away, your body broken down completely and absorbed into " + predName + " -- now nothing more than warmth and weight on their frame.")
		
		saynn("You have been fully digested. You are dead.")
		saynn("[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]")
		return

func saveData():
	var data = .saveData()
	data["predID"] = predID
	data["predName"] = predName
	data["voreMethod"] = voreMethod
	return data

func loadData(data):
	.loadData(data)
	predID = SAVE.loadVar(data, "predID", "")
	predName = SAVE.loadVar(data, "predName", "your predator")
	voreMethod = SAVE.loadVar(data, "voreMethod", "mouth")
