extends "res://Scenes/SceneBase.gd"

var predID = ""
var predName = "your predator"

func _init():
	sceneID = "VoreDigestedDeathScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		predID = str(_args[0])
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator != null):
		predName = predator.getName()

func _run():
	if(state == ""):
		saynn("The sixth day inside " + predName + " dawns, but you do not wake to face it.")
		saynn("Through the long night the gut finished what it started. The last of your strength dissolved away, your body broken down completely and absorbed into " + predName + " - now nothing more than warmth and weight on their swollen frame.")
		saynn("You have been fully digested. You are dead.")
		saynn("[i]There is no death in this game, so treat this as your ending. You can load your last save or use rollback to continue.[/i]")
		return

func saveData():
	var data = .saveData()
	data["predID"] = predID
	data["predName"] = predName
	return data

func loadData(data):
	.loadData(data)
	predID = SAVE.loadVar(data, "predID", "")
	predName = SAVE.loadVar(data, "predName", "your predator")
