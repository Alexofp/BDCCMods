extends "res://Scenes/SceneBase.gd"
var npcID = ""
var npc = null
func _init():
	sceneID = "VoreLeashWalkScene"
func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	npc = GlobalRegistry.getCharacter(npcID)
	addCharacter(npcID)
	_syncNpcToPlayer()
func resolveCustomCharacterName(_charID):
	if _charID == "npc":
		return npcID
	return .resolveCustomCharacterName(_charID)
func _syncNpcToPlayer():
	if GM.main == null or npcID == "":
		return
	if _isBeingDigested(npcID):
		return
	if !GM.main.IS.hasPawn(npcID):
		var _p = GM.main.IS.spawnPawnIfNeeded(npcID)
	var pawn = GM.main.IS.getPawn(npcID)
	if pawn != null:
		pawn.setLocation(GM.pc.getLocation())
func _isBeingDigested(checkID: String) -> bool:
	if GM.main == null or checkID == "":
		return false
	for cid in GM.main.dynamicCharacters.keys():
		var ch = GM.main.dynamicCharacters.get(cid)
		if ch == null:
			continue
		if ch.hasEffect("VoreSlavePredatorDigesting"):
			var eff = ch.getEffect("VoreSlavePredatorDigesting")
			if eff != null and eff.preyIDs.has(checkID):
				return true
		if ch.hasEffect("VoreShrunkNPCPredator"):
			var eff = ch.getEffect("VoreShrunkNPCPredator")
			if eff != null and eff.preyIDs.has(checkID):
				return true
	return false
func _run():
	if state == "":
		if npc == null or _isBeingDigested(npcID):
			saynn("There's no one on your leash anymore.")
			addButton("Continue", "Done", "endthescene")
			return
		var roomID = GM.pc.location
		var _roomInfo = GM.world.getRoomByID(roomID)
		aimCamera(roomID)
		_syncNpcToPlayer()
		playAnimation(StageScene.Duo, "walk", {pc = npcID, npc = "pc", npcAction = "walk", flipNPC = true, bodyState = {leashedBy = "pc"}})
		if GM.world.canGoID(roomID, GameWorld.Direction.NORTH):
			addButtonAt(6, "North", "Go north", "go", [GameWorld.Direction.NORTH, Direction.North])
		else:
			addDisabledButtonAt(6, "North", "Can't go north")
		if GM.world.canGoID(roomID, GameWorld.Direction.WEST):
			addButtonAt(10, "West", "Go west", "go", [GameWorld.Direction.WEST, Direction.West])
		else:
			addDisabledButtonAt(10, "West", "Can't go west")
		if GM.world.canGoID(roomID, GameWorld.Direction.SOUTH):
			addButtonAt(11, "South", "Go south", "go", [GameWorld.Direction.SOUTH, Direction.South])
		else:
			addDisabledButtonAt(11, "South", "Can't go south")
		if GM.world.canGoID(roomID, GameWorld.Direction.EAST):
			addButtonAt(12, "East", "Go east", "go", [GameWorld.Direction.EAST, Direction.East])
		else:
			addDisabledButtonAt(12, "East", "Can't go east")
		var npcName = npc.getName() if npc.has_method("getName") else "them"
		addButtonAt(5, "Release", "Let " + npcName + " off the leash here", "release_leash")
		addButtonAt(9, "Me", "Shows actions related to you and your personal information", "me")
		addButtonAt(13, "Tasks", "Look at your tasks", "tasks")
		addButtonAt(14, "Inventory", "Look at your inventory", "inventory")
		_roomInfo._onPreEnter()
		setLocationName(_roomInfo.getName())
		if GM.pc.isBlindfolded() && !GM.pc.canHandleBlindness():
			saynn(_roomInfo.getBlindDescription())
		else:
			saynn(_roomInfo.getDescription())
		saynn("You are leading " + npcName + " around on a leash.")
		var roomMemory = GM.main.getRoomMemory(roomID)
		if roomMemory != null && roomMemory != "":
			saynn("[i]" + roomMemory + "[/i]")
		_roomInfo._onEnter()
		GM.ES.triggerRun(Trigger.EnteringRoom, [GM.pc.location])
		return
	if state == "released":
		var npcName2 = npc.getName() if (npc != null && npc.has_method("getName")) else "them"
		saynn("You unclip the leash and let " + npcName2 + " go. They're free to wander off from here.")
		addButton("Continue", "Done", "endthescene")
		return
func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "actionCallback":
		runScene(_args[0])
		return
	if _action == "roomCallback":
		var _room = GM.world.getRoomByID(_args[0])
		return _room._onButton(_args[1])
	if _action == "go":
		playAnimation(StageScene.Duo, "walk", {pc = npcID, npc = "pc", npcAction = "walk", flipNPC = true, bodyState = {leashedBy = "pc"}})
		processTime(30)
		GM.pc.setLocation(GM.world.applyDirectionID(GM.pc.location, _args[0]))
		_syncNpcToPlayer()
		aimCamera(GM.pc.location)
		GM.main.showLog()
		return
	if _action == "release_leash":
		_syncNpcToPlayer()
		processTime(5)
		setState("released")
		return
	if _action == "inventory":
		runScene("InventoryScene")
		return
	if _action == "tasks":
		runScene("QuestLogScene")
		return
	if _action == "me":
		runScene("MeScene")
		return
	return
func getSceneCompanions():
	if npcID != "":
		return [npcID]
	return []
func supportsShowingPawns() -> bool:
	return true
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npc = GlobalRegistry.getCharacter(npcID)