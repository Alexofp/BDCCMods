extends "res://Scenes/SceneBase.gd"
const VoreSwallowed        = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
const VoreBodyScaleHelper  = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var npcID: String = ""
var npcName: String = "them"
func _init():
	sceneID = "CellSleepingNpcScene"
func _initScene(_args = []):
	if _args.size() > 0:
		npcID = str(_args[0])
	var character = GlobalRegistry.getCharacter(npcID)
	if character != null and character.has_method("getName"):
		npcName = character.getName()
func _methodCapacity(m: String) -> int:
	var h = GM.pc.getSkillsHolder()
	var c = 0
	if(m == "mouth"):
		if(h.hasPerk("VoreInitiate")):    c += 1
		if(h.hasPerk("VoreExpansionV2")): c += 1
		if(h.hasPerk("VoreExpansionV3")): c += 1
	elif(m == "breasts"):
		if(h.hasPerk("VoreBreastsInitiate")):    c += 1
		if(h.hasPerk("VoreBreastsExpansionV2")): c += 1
		if(h.hasPerk("VoreBreastsExpansionV3")): c += 1
	elif(m == "anus"):
		if(h.hasPerk("VoreAnusInitiate")):    c += 1
		if(h.hasPerk("VoreAnusExpansionV2")): c += 1
		if(h.hasPerk("VoreAnusExpansionV3")): c += 1
	elif(m == "cock"):
		if(h.hasPerk("VoreCockInitiate")):    c += 1
		if(h.hasPerk("VoreCockExpansionV2")): c += 1
		if(h.hasPerk("VoreCockExpansionV3")): c += 1
	elif(m == "vagina"):
		if(h.hasPerk("VoreVaginaInitiate")):    c += 1
		if(h.hasPerk("VoreVaginaExpansionV2")): c += 1
		if(h.hasPerk("VoreVaginaExpansionV3")): c += 1
	elif(m == "tail"):
		if(h.hasPerk("VoreTailInitiate")):    c += 1
		if(h.hasPerk("VoreTailExpansionV2")): c += 1
		if(h.hasPerk("VoreTailExpansionV3")): c += 1
	elif(m == "eye"):
		if(h.hasPerk("VoreEyeInitiate")):    c += 1
		if(h.hasPerk("VoreEyeExpansionV2")): c += 1
		if(h.hasPerk("VoreEyeExpansionV3")): c += 1
	elif(m == "ear"):
		if(h.hasPerk("VoreEarInitiate")):    c += 1
		if(h.hasPerk("VoreEarExpansionV2")): c += 1
		if(h.hasPerk("VoreEarExpansionV3")): c += 1
	return c
func _currentCount(m: String) -> int:
	return VoreSwallowed.countForMethod(GM.pc, m)
func _methodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow whole (mouth)"
		"breasts": return "Absorb into breasts"
		"anus":    return "Absorb into rear"
		"cock":    return "Devour with cock"
		"vagina":  return "Take into womb"
		"tail":    return "Coil up in tail"
		"eye":     return "Absorb through eye"
		"ear":     return "Absorb through ear"
	return "Swallow"
func _npcScale() -> float:
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		return 1.0
	if character.hasEffect("VoreSizeChange"):
		var scaleEff = character.getEffect("VoreSizeChange")
		if scaleEff != null:
			return scaleEff.targetScale
	return VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
func _getPills() -> Array:
	var result = []
	var inv = GM.pc.getInventory()
	if inv == null:
		return result
	for item in inv.getItems():
		if item.has_method("canUseInCombat") && item.canUseInCombat():
			result.append(item)
	return result
func _run():
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		saynn("The bunk is empty now. Whoever slept here is gone.")
		addButton("Leave", "Step back out", "endthescene")
		return
	addCharacter(npcID)
	playAnimation(StageScene.Sleeping, "sleep", {pc = npcID, hideNPC = true})
	if state == "":
		saynn("[b]" + npcName + "[/b] is fast asleep, curled up on the narrow cell bunk. Their chest rises and falls slowly -- they have no idea you're standing over them.")
		saynn("What do you want to do?")
		addButton("Leave", "Slip back out without waking " + npcName, "endthescene")
		addButton("Vore actions", "Swallow " + npcName + " whole while they sleep", "open_vore")
		addButton("Start sex scene", "Quietly climb onto the sleeping " + npcName, "start_sex")
		var pills = _getPills()
		if pills.size() > 0:
			addButton("Give item... (" + str(pills.size()) + " available)", "Force a pill or usable item into the sleeping " + npcName + "'s mouth.", "open_pill")
		else:
			addDisabledButton("Give item...", "You have no usable items in your inventory.")
		return
	if state == "vore":
		saynn("You loom over the sleeping " + npcName + ", deciding how to devour them...")
		var npcScale = _npcScale()
		var anyAvailable = false
		for m in ["mouth", "breasts", "anus", "cock", "vagina", "tail", "eye", "ear"]:
			var cap = _methodCapacity(m)
			if cap <= 0:
				continue
			var cur = _currentCount(m)
			if VoreSwallowed.SHRUNK_ONLY_METHODS.has(m):
				if npcScale > VoreSwallowed.SHRUNK_VORE_MAX_SCALE + 0.01:
					addDisabledButton(_methodLabel(m), "This method only works on prey shrunk to " + str(VoreSwallowed.SHRUNK_VORE_MAX_SCALE) + "x or smaller. (" + npcName + " is currently " + str(stepify(npcScale, 0.01)) + "x)")
					continue
			if cur < cap:
				anyAvailable = true
				addButton(_methodLabel(m), "Swallow the sleeping " + npcName + " whole. (" + str(cur) + "/" + str(cap) + " " + m + " capacity used)", "do_swallow", [m])
			else:
				addDisabledButton(_methodLabel(m), "Your " + m + " capacity is full (" + str(cur) + "/" + str(cap) + ").")
		if !anyAvailable:
			saynn("You don't have any free vore capacity right now. Unlock or free up a vore method first.")
		addButton("Back", "Leave them be for a moment", "go_main")
		return
	if state == "pill":
		saynn("You fish through your belongings for something to slip into the sleeping " + npcName + "'s mouth.")
		var pills = _getPills()
		if pills.size() == 0:
			saynn("You have no usable items left.")
			addButton("Back", "Never mind", "go_main")
			return
		for i in range(pills.size()):
			var pill = pills[i]
			var desc = pill.getDescription() if pill.has_method("getDescription") else ""
			addButton(pill.getVisibleName(), desc, "give_pill", [i])
		addButton("Back", "Put your items away", "go_main")
		return
func _react(_action, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "go_main":
		setState("")
		return
	if _action == "open_vore":
		setState("vore")
		return
	if _action == "open_pill":
		setState("pill")
		return
	if _action == "start_sex":
		runScene("GenericSexScene", ["pc", npcID])
		return
	if _action == "do_swallow":
		if _args.size() >= 1:
			_doSwallow(str(_args[0]))
		return
	if _action == "give_pill":
		if _args.size() >= 1:
			_doGivePill(int(_args[0]))
		setState("")
		return
	setState(_action)
func _doSwallow(m: String):
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		return
	var preyName = character.getName()
	if _currentCount(m) >= _methodCapacity(m):
		addMessage("You can't fit anyone else in there right now.")
		setState("vore")
		return
	var like = 0.0
	var fh = character.getFetishHolder()
	if fh != null:
		like = fh.getFetishValue("Vore")
	GM.pc.addEffect(VoreSwallowed.effectIDForMethod(m), [preyName, npcID, m])
	GM.pc.addSkillExperience("Vore", 20)
	var preyScale = 1.0
	var preyShrinkDuration = 0.0
	if character.hasEffect("VoreSizeChange"):
		var scaleEff = character.getEffect("VoreSizeChange")
		if scaleEff != null:
			preyScale = scaleEff.targetScale
			preyShrinkDuration = float(scaleEff.durationSeconds)
	if preyScale < 1.0 and preyShrinkDuration > 0.0:
		GM.pc.addEffect("VoreSwallowedShrunk", [preyName, npcID, m, preyShrinkDuration])
	if GM.main != null && GM.main.IS.hasPawn(npcID):
		GM.main.IS.deletePawn(npcID)
	var partWord = "stomach"
	if(m == "breasts"):   partWord = "chest"
	elif(m == "anus"):    partWord = "rear"
	elif(m == "cock"):    partWord = "balls"
	elif(m == "vagina"):  partWord = "womb"
	elif(m == "tail"):    partWord = "tail"
	elif(m == "eye"):     partWord = "eye"
	elif(m == "ear"):     partWord = "ear canal"
	var reaction = " They barely stir at first"
	if(like >= 0.5):
		reaction = " Half-asleep, they melt into you willingly, sighing with pleasure as they slide down into your " + partWord
	elif(like >= 0.125):
		reaction = " They mumble drowsily and squirm, secretly content to end up in your " + partWord
	elif(like <= -0.5):
		reaction = " They jolt awake mid-swallow, thrashing and begging in horror, but down into your " + partWord + " they go regardless"
	elif(like <= -0.125):
		reaction = " They wake with a startled squirm as your " + partWord + " swallows them up"
	addMessage("You scoop up the sleeping " + preyName + " and swallow them whole!" + reaction + ". (+20 Vore XP)")
	_returnToCorridor()
func _doGivePill(pillIndex: int):
	var character = GlobalRegistry.getCharacter(npcID)
	if character == null:
		addMessage("Couldn't find that character.")
		return
	var pills = _getPills()
	if pillIndex < 0 || pillIndex >= pills.size():
		addMessage("That item is no longer in your inventory.")
		return
	var pill = pills[pillIndex]
	var resultMsg = pill.useInCombat(GM.pc, character)
	if resultMsg == null || resultMsg == "":
		resultMsg = pill.getVisibleName() + " was used."
	addMessage("You carefully tip " + pill.getVisibleName() + " into the sleeping " + character.getName() + "'s mouth. " + resultMsg)
func _returnToCorridor():
	var returnLoc = GM.main.getModuleFlag("VoreMod", "cellReturnLocation", "")
	GM.main.setModuleFlag("VoreMod", "cellNpcID", "")
	GM.main.setModuleFlag("VoreMod", "cellNpcName", "")
	GM.main.setModuleFlag("VoreMod", "cellNpcSleeping", false)
	GM.main.setModuleFlag("VoreMod", "cellReturnLocation", "")
	endScene()
	if returnLoc != "":
		GM.pc.setLocation(returnLoc)
	else:
		GM.pc.setLocation("cellblock_orange_nearcell")
	GM.main.reRun()
func supportsShowingPawns() -> bool:
	return false
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["npcName"] = npcName
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	npcName = SAVE.loadVar(data, "npcName", "them")