extends "res://Scenes/SceneBase.gd"
const MIN_CELLS = 15
const BLOCK_NAMES = {
	"orange": "General-security cellblock",
	"lilac": "Lilac cellblock",
	"red": "High-security cellblock",
}
const BLOCK_INMATE_TYPE = {
	"orange": 0,
	"lilac": 2,
	"red": 1,
}
const ROOM_TO_BLOCK = {
	"cellblock_orange_nearcell": "orange",
	"cellblock_lilac_nearcell": "lilac",
	"cellblock_red_nearcell": "red",
}
const AWAY_CELL_DESCS = [
	"The cell is quiet. Personal items sit undisturbed on the shelf -- a few trinkets, some folded clothes. The owner is clearly somewhere else.",
	"Nobody home. The bed is unmade and a half-eaten ration sits on the small ledge. Their stuff is unguarded.",
	"The cell door is slightly ajar. Inside you can see their belongings left behind -- they must be out wandering the station.",
	"An empty cell, but clearly lived-in. A jacket hangs from a hook, personal effects line the shelf. The owner will be back sooner or later.",
]
const SEARCH_LOOT = [
	["Soap", 30],
	["PlasticBottle", 20],
	["Lube", 15],
	["EnergyDrink", 12],
	["Condom", 10],
	["AppleItem", 8],
]
const CELL_SEARCH_COOLDOWN = 24 * 60 * 60
const BYSTANDER_CHANCE_SEARCH = 20
const BYSTANDER_CHANCE_STEAL = 30
const BYSTANDER_CHANCE_NIGHT = 8
const OWNER_SPOT_CHANCE = 45
const OWNER_RETURN_CHANCE = 35
const SEARCH_TIME = 300
const STEAL_TIME = 600
var currentBlockID: String = ""
var currentBlockCells: Array = []
var selectedCellIndex: int = -1
var stolenItemName: String = ""
var stolenCredits: int = 0
var searchedNothing: bool = false
var wokeNPC: bool = false
var wokeNPCID: String = ""
func _init():
	sceneID = "CellRaidScene"
func _initScene(_args = []):
	if _args.size() > 0:
		currentBlockID = str(_args[0])
	else:
		var roomID = GM.pc.getLocation()
		if ROOM_TO_BLOCK.has(roomID):
			currentBlockID = ROOM_TO_BLOCK[roomID]
func _isNightTime() -> bool:
	if GM.main == null:
		return false
	return GM.main.isVeryLate()
func _run():
	if state == "":
		if currentBlockID == "":
			var roomID = GM.pc.getLocation()
			if ROOM_TO_BLOCK.has(roomID):
				currentBlockID = ROOM_TO_BLOCK[roomID]
		if currentBlockID == "":
			saynn("There are no cells to inspect here.")
			addButton("Back", "Return", "endthescene")
			return
		if currentBlockCells.size() == 0:
			currentBlockCells = _generateCellList()
		_runCellList()
		return
	if state == "cell_list":
		_runCellList()
		return
	if state == "cell_interior":
		_runCellInterior()
		return
	if state == "search_result":
		_runSearchResult()
		return
	if state == "steal_result":
		_runStealResult()
		return
func _collectExistingInmates() -> Array:
	var result = []
	if GM.main == null:
		return result
	if !BLOCK_INMATE_TYPE.has(currentBlockID):
		return result
	var wantedType = BLOCK_INMATE_TYPE[currentBlockID]
	var seenIDs = {}
	var poolIDs = GM.main.getDynamicCharacterIDsFromPool("Inmates")
	if poolIDs != null:
		for charID in poolIDs:
			if seenIDs.has(charID):
				continue
			seenIDs[charID] = true
			var character = GlobalRegistry.getCharacter(charID)
			if character == null:
				continue
			if !character.isInmate():
				continue
			if character.getInmateType() != wantedType:
				continue
			if character.isSlaveToPlayer():
				continue
			result.append({"id": charID, "name": character.getName()})
	for charID in GM.main.dynamicCharacters:
		if seenIDs.has(charID):
			continue
		seenIDs[charID] = true
		var character = GlobalRegistry.getCharacter(charID)
		if character == null:
			continue
		if !character.isInmate():
			continue
		if character.getInmateType() != wantedType:
			continue
		if character.isSlaveToPlayer():
			continue
		result.append({"id": charID, "name": character.getName()})
	return result
func _generateNewInmate() -> String:
	if GM.main == null:
		return ""
	var wantedType = BLOCK_INMATE_TYPE.get(currentBlockID, 0)
	var GeneratorClass = load("res://Characters/Dynamic/Generator/InmateGenerator.gd")
	if GeneratorClass == null:
		return ""
	var generator = GeneratorClass.new()
	var newID = NpcFinder.generateNpcForPool("Inmates", generator, {})
	if newID == null or newID == "":
		return ""
	var newChar = GlobalRegistry.getCharacter(newID)
	if newChar != null:
		newChar.setFlag(CharacterFlag.InmateType, wantedType)
	return newID
func _generateCellList() -> Array:
	var result = []
	var inmates = _collectExistingInmates()
	var maxAttempts = MIN_CELLS + 5
	var attempts = 0
	while inmates.size() < MIN_CELLS and attempts < maxAttempts:
		attempts += 1
		var newID = _generateNewInmate()
		if newID == "" or newID == null:
			break
		var newChar = GlobalRegistry.getCharacter(newID)
		if newChar == null:
			continue
		inmates.append({"id": newID, "name": newChar.getName()})
	for i in range(inmates.size()):
		result.append({
			"cellLabel": "Cell " + str(i + 1),
			"npcID": inmates[i]["id"],
			"npcName": inmates[i]["name"],
		})
	return result
func _isNPCHomeNow(npcID: String) -> bool:
	if _isNightTime():
		return true
	if GM.main != null and GM.main.IS.hasPawn(npcID):
		var pawn = GM.main.IS.getPawn(npcID)
		if pawn != null:
			var loc = pawn.getLocation()
			if loc != null and loc != "":
				if loc.find("cellblock") >= 0 or loc.find("cell") >= 0:
					return true
				return false
	return RNG.chance(50)
func _cellSlotKey() -> String:
	var label = ""
	if selectedCellIndex >= 0 and selectedCellIndex < currentBlockCells.size():
		var cell = currentBlockCells[selectedCellIndex]
		if cell is Dictionary and cell.has("cellLabel"):
			label = str(cell["cellLabel"])
	if label == "":
		label = "cell" + str(selectedCellIndex)
	return currentBlockID + "|" + label
func _cellSearchTimes() -> Dictionary:
	var times = GM.main.getModuleFlag("VoreMod", "cellSearchTimes", {})
	if times == null or !(times is Dictionary):
		return {}
	return times
func _isCellOnCooldown(npcID: String) -> bool:
	if GM.main == null:
		return false
	var times = _cellSearchTimes()
	var now = int(GM.main.getTimeInGlobalSeconds())
	for key in [npcID, _cellSlotKey()]:
		if key != "" and times.has(key) and now - int(times[key]) < CELL_SEARCH_COOLDOWN:
			return true
	return false
func _markCellSearched(npcID: String):
	if GM.main == null:
		return
	var times = _cellSearchTimes()
	var now = int(GM.main.getTimeInGlobalSeconds())
	for key in times.keys():
		if now - int(times[key]) >= CELL_SEARCH_COOLDOWN:
			times.erase(key)
	if npcID != "":
		times[npcID] = now
	times[_cellSlotKey()] = now
	GM.main.setModuleFlag("VoreMod", "cellSearchTimes", times)
func _searchCooldownText() -> String:
	return "You already searched this cell recently -- best to let things cool down before you come back."
func _bystanderChance(baseChance: int) -> int:
	if _isNightTime():
		return BYSTANDER_CHANCE_NIGHT
	return baseChance
func _pickBystander(excludeID: String) -> String:
	var candidates = []
	for cell in currentBlockCells:
		var theID = str(cell["npcID"]) if cell.has("npcID") else ""
		if theID == "" or theID == excludeID:
			continue
		candidates.append(theID)
	if candidates.size() > 0:
		return str(RNG.pick(candidates))
	var newID = _generateNewInmate()
	if newID == "" or newID == excludeID:
		return ""
	var newChar = GlobalRegistry.getCharacter(newID)
	if newChar == null:
		return ""
	currentBlockCells.append({
		"cellLabel": "Cell " + str(currentBlockCells.size() + 1),
		"npcID": newID,
		"npcName": newChar.getName(),
	})
	return newID
func _startConfrontation(whoID: String, reason: String, cellOwnerID: String = "", ownerName: String = ""):
	if whoID == "":
		setState("cell_list")
		return
	if cellOwnerID != "":
		_markCellSearched(cellOwnerID)
	runScene("CellConfrontScene", [whoID, reason, ownerName])
	endScene()
func _runCellList():
	var blockName = BLOCK_NAMES.get(currentBlockID, "Unknown block")
	if currentBlockCells.size() == 0:
		saynn("You look through the " + blockName + " but there don't seem to be any inmate cells assigned yet.")
		addButton("Back", "Leave", "endthescene")
		return
	if _isNightTime():
		saynn("You creep through the dim corridor of the " + blockName + ". The overhead lights have switched to their low night-cycle glow. The automatic cell doors are sealed shut for the night -- every inmate is locked inside.")
	else:
		saynn("You walk along the rows of cells in the " + blockName + ". Names and numbers are stenciled beside each door.")
	saynn("Which cell do you want to approach?")
	for i in range(currentBlockCells.size()):
		var cell = currentBlockCells[i]
		addButton(cell["cellLabel"], cell["npcName"] + "'s cell", "pick_cell", [i])
	addButton("Back", "Leave the cell block", "endthescene")
func _runCellInterior():
	if selectedCellIndex < 0 or selectedCellIndex >= currentBlockCells.size():
		setState("cell_list")
		return
	var cell = currentBlockCells[selectedCellIndex]
	var blockName = BLOCK_NAMES.get(currentBlockID, "Unknown block")
	var cellLabel = cell["cellLabel"]
	var npcID = cell["npcID"]
	var npcChar = GlobalRegistry.getCharacter(npcID)
	if npcChar == null:
		saynn("The nameplate says someone lives here, but the cell is stripped bare.")
		addButton("Leave", "Move on", "go_cell_list")
		return
	var npcName = npcChar.getName()
	var npcHome = _isNPCHomeNow(npcID)
	saynn("You approach " + cellLabel + " in the " + blockName + ". The nameplate reads [b]" + npcName + "[/b].")
	var onCooldown = _isCellOnCooldown(npcID)
	if npcHome:
		var isSleeping = false
		if _isNightTime():
			if !cell.has("sleeping"):
				cell["sleeping"] = RNG.chance(50)
				currentBlockCells[selectedCellIndex] = cell
			isSleeping = bool(cell["sleeping"])
		if _isNightTime():
			if isSleeping:
				saynn(npcName + " is fast asleep on their bunk, locked in for the night. Their slow breathing fogs the little window as you peer through the glass.")
			else:
				saynn(npcName + " is awake, sitting on the edge of their bed, locked in for the night. They notice you at the glass.")
		else:
			saynn(npcName + " is inside. They notice you at the window.")
		if _isNightTime() and isSleeping:
			addButton("Enter cell", "Step inside " + npcName + "'s cell -- they're asleep", "enter_cell", [npcID, npcName, true])
		else:
			addButton("Enter cell", "Step inside " + npcName + "'s cell -- they are awake, so this can get ugly", "enter_cell", [npcID, npcName, false])
		if onCooldown:
			addDisabledButton("Sneak in and steal", "You already searched this cell recently.")
			addDisabledButton("Search door area", "You already searched this cell recently.")
		else:
			addButton("Sneak in and steal", "Try to take something off the shelf while they are right there (very risky!)", "attempt_steal", [npcID, true])
			addButton("Search door area", "Check around the entrance -- they are watching, so keep it quick", "attempt_search_outside", [npcID, true])
	else:
		var descIdx = RNG.randi_range(0, AWAY_CELL_DESCS.size() - 1)
		saynn(AWAY_CELL_DESCS[descIdx])
		saynn(npcName + " is not here. Their belongings are unguarded.")
		if onCooldown:
			addDisabledButton("Sneak in and steal", "You already searched this cell recently.")
			addDisabledButton("Search door area", "You already searched this cell recently.")
		else:
			addButton("Sneak in and steal", "Slip inside and look for valuables", "attempt_steal", [npcID, false])
			addButton("Search door area", "Look around the entrance", "attempt_search_outside", [npcID, false])
	if onCooldown:
		saynn(_searchCooldownText())
	addButton("Leave", "Move on to another cell", "go_cell_list")
func _runSearchResult():
	if searchedNothing:
		saynn("You check every crevice near the door but come up empty.")
	else:
		saynn("You carefully check around the cell entrance.")
		if stolenCredits > 0:
			saynn("You find [b]" + str(stolenCredits) + " credits[/b] behind a loose panel.")
		if stolenItemName != "":
			saynn("You spot a [b]" + stolenItemName + "[/b] tucked into the doorframe.")
	addButton("Continue", "Move on", "go_cell_list")
func _runStealResult():
	if wokeNPC:
		var npcChar = GlobalRegistry.getCharacter(wokeNPCID)
		var npcName = "Someone"
		if npcChar != null:
			npcName = npcChar.getName()
		saynn(npcName + " catches you red-handed!")
		saynn("[b]" + npcName + ":[/b] \"Hey! What are you doing in my cell?!\"")
		addButton("Continue", "They are blocking the doorway -- this is not over", "caught_confront", [wokeNPCID])
	else:
		if stolenItemName != "" or stolenCredits > 0:
			saynn("You got your hands on something!")
			if stolenCredits > 0:
				saynn("Found [b]" + str(stolenCredits) + " credits[/b] under the mattress.")
			if stolenItemName != "":
				saynn("Swiped a [b]" + stolenItemName + "[/b] from the shelf.")
			saynn("You slip out undetected.")
		else:
			saynn("Nothing worth taking. You slip out empty-handed.")
		addButton("Continue", "Move on", "go_cell_list")
func _react(_action: String, _args):
	if _action == "endthescene":
		endScene()
		return
	if _action == "pick_cell":
		if _args.size() < 1:
			return
		selectedCellIndex = int(_args[0])
		setState("cell_interior")
		return
	if _action == "go_cell_list":
		selectedCellIndex = -1
		setState("cell_list")
		return
	if _action == "enter_cell":
		if _args.size() >= 2:
			var npcID = str(_args[0])
			var npcName = str(_args[1])
			var npcSleeping = false
			if _args.size() >= 3:
				npcSleeping = bool(_args[2])
			GM.main.setModuleFlag("VoreMod", "cellReturnLocation", GM.pc.getLocation())
			GM.main.setModuleFlag("VoreMod", "cellNpcID", npcID)
			GM.main.setModuleFlag("VoreMod", "cellNpcName", npcName)
			GM.main.setModuleFlag("VoreMod", "cellNpcSleeping", npcSleeping)
			if !GM.main.IS.hasPawn(npcID):
				var _p = GM.main.IS.spawnPawnIfNeeded(npcID)
			var pawn = GM.main.IS.getPawn(npcID)
			if pawn != null:
				pawn.setLocation("voremod_cell_interior")
			processTime(30)
			endScene()
			GM.pc.setLocation("voremod_cell_interior")
			GM.main.reRun()
		return
	if _action == "attempt_steal":
		_doSteal(_args)
		if state == "cell_interior" and !sceneEndedFlag:
			setState("steal_result")
		return
	if _action == "attempt_search_outside":
		_doSearchOutside(_args)
		if state == "cell_interior" and !sceneEndedFlag:
			setState("search_result")
		return
	if _action == "caught_confront":
		if _args.size() > 0:
			_startConfrontation(str(_args[0]), "owner", str(_args[0]))
		return
	if _action == "do_fight":
		_doFight(_args)
		return
	setState(_action)
func _doSteal(_args):
	if _args.size() < 1:
		return
	var npcID = str(_args[0])
	var npcIsHome = false
	if _args.size() > 1:
		npcIsHome = bool(_args[1])
	stolenItemName = ""
	stolenCredits = 0
	searchedNothing = false
	wokeNPC = false
	wokeNPCID = ""
	var npcChar = GlobalRegistry.getCharacter(npcID)
	if npcIsHome:
		var catchChance = 25
		if _isNightTime():
			catchChance = 40
		if RNG.chance(catchChance):
			processTime(STEAL_TIME)
			_startConfrontation(npcID, "owner", npcID)
			return
	else:
		if RNG.chance(_bystanderChance(BYSTANDER_CHANCE_STEAL)):
			var intruder = _pickBystander(npcID)
			var reason = "bystander"
			if intruder == "" or RNG.chance(OWNER_RETURN_CHANCE):
				intruder = npcID
				reason = "returned"
			var ownerName = ""
			if npcChar != null:
				ownerName = npcChar.getName()
			processTime(STEAL_TIME)
			_startConfrontation(intruder, reason, npcID, ownerName)
			return
	if RNG.chance(55):
		stolenCredits = RNG.randi_range(1, 8)
		GM.pc.addCredits(stolenCredits)
	if npcChar != null and RNG.chance(30):
		var npcInv = npcChar.getInventory()
		if npcInv != null:
			var items = npcInv.getItems()
			if items != null and items.size() > 0:
				var equipped = npcInv.getEquippedItems().values()
				var stealable = []
				for item in items:
					if equipped.has(item):
						continue
					stealable.append(item)
				if stealable.size() > 0:
					var stolenItem = RNG.pick(stealable)
					stolenItemName = stolenItem.getVisibleName()
					npcInv.removeItem(stolenItem)
					GM.pc.getInventory().addItem(stolenItem)
	processTime(STEAL_TIME)
	_markCellSearched(npcID)
	setState("steal_result")
func _doSearchOutside(_args):
	if _args.size() < 1:
		return
	var npcID = str(_args[0])
	var npcIsHome = false
	if _args.size() > 1:
		npcIsHome = bool(_args[1])
	stolenItemName = ""
	stolenCredits = 0
	searchedNothing = true
	if npcIsHome:
		if RNG.chance(OWNER_SPOT_CHANCE):
			processTime(SEARCH_TIME)
			_startConfrontation(npcID, "owner", npcID)
			return
	else:
		if RNG.chance(_bystanderChance(BYSTANDER_CHANCE_SEARCH)):
			var intruder = _pickBystander(npcID)
			var reason = "bystander"
			if intruder == "":
				intruder = npcID
				reason = "returned"
			processTime(SEARCH_TIME)
			_startConfrontation(intruder, reason, npcID)
			return
	if RNG.chance(35):
		stolenCredits = RNG.randi_range(1, 3)
		GM.pc.addCredits(stolenCredits)
		searchedNothing = false
	if RNG.chance(15):
		var totalWeight = 0
		for entry in SEARCH_LOOT:
			totalWeight += entry[1]
		var roll = RNG.randi_range(1, totalWeight)
		var cumulative = 0
		for entry in SEARCH_LOOT:
			cumulative += entry[1]
			if roll <= cumulative:
				var item = GlobalRegistry.createItem(entry[0])
				if item != null:
					stolenItemName = item.getVisibleName()
					GM.pc.getInventory().addItem(item)
				searchedNothing = false
				break
	processTime(SEARCH_TIME)
	_markCellSearched(npcID)
	setState("search_result")
func _doFight(_args):
	if _args.size() < 1:
		return
	var npcID = str(_args[0])
	if !GM.main.IS.hasPawn(npcID):
		var _p = GM.main.IS.spawnPawnIfNeeded(npcID)
	var pawn = GM.main.IS.getPawn(npcID)
	if pawn != null:
		pawn.setLocation(GM.pc.getLocation())
	processTime(30)
	runScene("FightScene", [npcID])
	endScene()
func saveData():
	var data = .saveData()
	data["currentBlockID"] = currentBlockID
	data["currentBlockCells"] = currentBlockCells
	data["selectedCellIndex"] = selectedCellIndex
	data["stolenItemName"] = stolenItemName
	data["stolenCredits"] = stolenCredits
	data["searchedNothing"] = searchedNothing
	data["wokeNPC"] = wokeNPC
	data["wokeNPCID"] = wokeNPCID
	return data
func loadData(data):
	.loadData(data)
	currentBlockID = SAVE.loadVar(data, "currentBlockID", "")
	currentBlockCells = SAVE.loadVar(data, "currentBlockCells", [])
	selectedCellIndex = SAVE.loadVar(data, "selectedCellIndex", -1)
	stolenItemName = SAVE.loadVar(data, "stolenItemName", "")
	stolenCredits = SAVE.loadVar(data, "stolenCredits", 0)
	searchedNothing = SAVE.loadVar(data, "searchedNothing", false)
	wokeNPC = SAVE.loadVar(data, "wokeNPC", false)
	wokeNPCID = SAVE.loadVar(data, "wokeNPCID", "")
