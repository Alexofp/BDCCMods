extends "res://Scenes/SceneBase.gd"
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

var lastText = ""

func _init():
	sceneID = "VoreObjectStorageScene"

func _run():
	var eff = VoreObjectHelper.getEffect(GM.pc)
	if(eff == null || eff.totalStored() <= 0):
		saynn("You press a hand against your body. Empty -- you are not carrying anything inside you right now.")
		addButton("Close", "Done", "endthescene")
		return
	if(lastText != ""):
		saynn(lastText)
		lastText = ""
	else:
		saynn("You take stock of everything currently stored inside your body.")
	
	for m in VoreObjectHelper.METHODS:
		var cap = VoreObjectHelper.capacity(GM.pc, m)
		var count = eff.countForMethod(m)
		if(count <= 0):
			continue
		sayn("[b]" + VoreObjectHelper.partWord(m).capitalize() + "[/b] (" + str(count) + "/" + str(cap) + ")")
	
	var entries = eff.getEntries()
	for entry in entries:
		var m = entry["method"]
		var idx = entry["index"]
		var itemName = entry["name"]
		addButton("Take out: " + itemName, "Pull " + itemName + " back out of your " + VoreObjectHelper.partWord(m) + ".", "do_take", [m, idx])
	
	if(entries.size() > 1):
		addButton("Empty yourself", "Push every last object back out, one after another.", "do_take_all")
	addButton("Close", "Leave the cargo where it is", "endthescene")

func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	var eff = VoreObjectHelper.getEffect(GM.pc)
	if(_action == "do_take"):
		if(eff == null || _args.size() < 2):
			setState("")
			return
		var m = str(_args[0])
		var idx = int(_args[1])
		var entries = eff.getEntriesForMethod(m)
		var entryName = "item"
		if(idx >= 0 && idx < entries.size()):
			entryName = entries[idx]["name"]
		var item = eff.popStoredItem(m, idx, true)
		if(item == null):
			lastText = "There is nothing there anymore."
		else:
			lastText = VoreObjectHelper.retrieveText(m, entryName)
			GM.pc.addSkillExperience("Vore", 5)
		setState("")
		return
	if(_action == "do_take_all"):
		if(eff == null):
			setState("")
			return
		var names = []
		for m in VoreObjectHelper.METHODS:
			while(eff.countForMethod(m) > 0):
				var entries = eff.getEntriesForMethod(m)
				if(entries.size() <= 0):
					break
				names.append(entries[0]["name"])
				eff.popStoredItem(m, 0, true)
		lastText = "One by one you force everything back out: " + Util.join(names, ", ") + ". By the end you are sweaty, slick and completely empty."
		GM.pc.addSkillExperience("Vore", 10)
		setState("")
		return
	setState(_action)

func saveData():
	var data = .saveData()
	data["lastText"] = lastText
	return data

func loadData(data):
	.loadData(data)
	lastText = SAVE.loadVar(data, "lastText", "")
