extends "res://Scenes/SceneBase.gd"
var minigameScene = preload("res://Game/Minigames/ClickAtTheRightTime/ClickAtTheRightTime.tscn")
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
const CALM_THRESHOLD = 0.5
var escapeNPCID = ""
var preyName    = "your prey"
var voreMethod  = "mouth"
var _mgScore       = 0.0
var _mgFailedHard  = false
var _mgInstant     = false
func _init():
	sceneID = "VoreEscapeScene"
func _initScene(_args = []):
	if(_args.size() > 0):
		escapeNPCID = str(_args[0])
	var effect = _getVoreEffect()
	if(effect != null):
		preyName   = effect.getNameForID(escapeNPCID)
		voreMethod = effect.getSwallowMethodForID(escapeNPCID)
		effect.clearPendingEscape()
func _getVoreEffect():
	if(GM.pc == null):
		return null
	return VoreSwallowed.getEffectForID(GM.pc, escapeNPCID)
func _partWord():
	match voreMethod:
		"mouth":   return "belly"
		"breasts": return "chest"
		"anus":    return "gut"
		"cock":    return "balls"
		"vagina":  return "womb"
		"tail":    return "tail"
	return "belly"
func _calcDifficulty():
	var stage = 0
	var effect = _getVoreEffect()
	if(effect != null):
		stage = effect.getDigestionStage(escapeNPCID)
	var diff = 5 - stage
	if(diff < 2):
		diff = 2
	return diff
func _run():
	var effect = _getVoreEffect()
	var part = _partWord()
	if(state == ""):
		if(effect == null || !effect.swallowedIDs.has(escapeNPCID) || !effect.canStillEscape(escapeNPCID) || (GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting"))):
			if(effect != null):
				effect.clearPendingEscape()
			saynn("The disturbance inside you settles. There is nothing to deal with right now.")
			addButton("Back", "Carry on", "endthescene")
			return
		playAnimation(StageScene.Solo, "stand")
		saynn("[b]Something is fighting back![/b]")
		saynn(preyName + " has suddenly found a second wind. You feel them thrashing violently inside your " + part + ", clawing and pushing in a desperate bid to climb back out before your body can finish them off.")
		saynn("If you don't get them back under control [i]right now[/i], they're going to force their way free.")
		addButton("Steady yourself", "Clamp down and try to calm the struggling prey (timing minigame)", "start_minigame")
		return
	if(state == "minigame"):
		var game = minigameScene.instance()
		GM.ui.addFullScreenCustomControl("voreescape_minigame", game)
		game.setDifficulty(_calcDifficulty())
		game.connect("minigameCompleted", self, "onCalmMinigameDone")
		return
	if(state == "calmed"):
		playAnimation(StageScene.Solo, "stand")
		saynn("You tense your muscles and bear down hard, smothering every escape attempt. Slowly, " + preyName + "'s frantic struggling weakens into exhausted twitching.")
		saynn("They're not going anywhere. Securely contained once more, " + preyName + " sinks back down into your " + part + " to continue being digested.")
		GM.pc.addSkillExperience("Vore", 15)
		saynn("[i]+15 Vore XP[/i]")
		addButton("Continue", "Back to what you were doing", "endthescene")
		return
	if(state == "escaping"):
		if(currentCharactersVariants.has(escapeNPCID) == false):
			addCharacter(escapeNPCID)
		playAnimation(StageScene.Duo, "stand", {npc = escapeNPCID})
		saynn("[b]They got out![/b]")
		saynn("With a final desperate heave, " + preyName + " forces their way back out of you, spilling onto the floor covered in slick and gasping for air -- but very much alive, and [i]furious[/i].")
		saynn(preyName + " scrambles to their feet, ready to fight. You'll have to overpower them again if you want them back.")
		addButton("Fight", "Subdue " + preyName + " all over again", "begin_escape_fight")
		return
	if(state == "after_win"):
		var backInside = (effect != null && effect.swallowedIDs.has(escapeNPCID))
		if(backInside):
			playAnimation(StageScene.Solo, "stand")
			saynn("You beat " + preyName + " down a second time and wasted no time stuffing them right back where they belong. Lesson learned -- there's no escaping you.")
		else:
			playAnimation(StageScene.Solo, "stand")
			saynn("You put " + preyName + " back down. Whether you choose to swallow them again or let them crawl away is up to you now.")
		addButton("Continue", "Carry on", "endthescene")
		return
	if(state == "after_loss"):
		playAnimation(StageScene.Solo, "stand")
		saynn("You couldn't put " + preyName + " down again. Battered and free, they don't waste the chance -- they turn tail and flee, vanishing from the area before you can recover.")
		if(GM.main != null && GM.main.IS.hasPawn(escapeNPCID)):
			GM.main.IS.deletePawn(escapeNPCID)
		addButton("Damn it", "Let them go", "endthescene")
		return
func _react(_action, _args):
	if(_action == "endthescene"):
		endScene()
		return
	if(_action == "start_minigame"):
		setState("minigame")
		return
	if(_action == "resolve_calm"):
		var success = _mgInstant || (!_mgFailedHard && _mgScore >= CALM_THRESHOLD)
		var effect = _getVoreEffect()
		if(success):
			if(effect != null):
				effect.onNPCCalmed(escapeNPCID)
			setState("calmed")
		else:
			if(effect != null):
				effect.onNPCEscaped(escapeNPCID)
			setState("escaping")
		return
	if(_action == "begin_escape_fight"):
		runScene("FightScene", [escapeNPCID, "VoreEscape"], "escapeFight")
		return
	setState(_action)
func onCalmMinigameDone(result):
	_mgScore      = result.score
	_mgFailedHard = result.failedHard
	_mgInstant    = result.instantUnlock
	GM.main.pickOption("resolve_calm", [])
func _react_scene_end(_tag, _result):
	if(_tag == "escapeFight"):
		var battlestate = ""
		if(_result is Array && _result.size() > 0):
			battlestate = _result[0]
		if(battlestate == "win"):
			setState("after_win")
		else:
			setState("after_loss")
func supportsShowingPawns() -> bool:
	return true
func saveData():
	var data = .saveData()
	data["escapeNPCID"] = escapeNPCID
	data["preyName"]    = preyName
	data["voreMethod"]  = voreMethod
	return data
func loadData(data):
	.loadData(data)
	escapeNPCID = SAVE.loadVar(data, "escapeNPCID", "")
	preyName    = SAVE.loadVar(data, "preyName", "your prey")
	voreMethod  = SAVE.loadVar(data, "voreMethod", "mouth")