extends GameExtender
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
var _connectedToStage: bool = false
var _pcSignalConnected: bool = false
var _updaterSpawned: bool = false
var _pickedUpRestored: bool = false
var _debuggerGiven: bool = false
func _init():
	id = "VoreSizeChangeExtender"
func register(_GES):
	_GES.register(self, ExtendGame.npcUpdateNonBattleEffects)
	_GES.register(self, ExtendGame.npcProcessTime)
	_GES.register(self, ExtendGame.pcProcessTime)
	_GES.register(self, ExtendGame.pcUpdateNonBattleEffects)
func pcUpdateNonBattleEffects(_pc):
	_lazySetup()
	VoreBodyScaleHelper.applyPCBodyScale()
func pcProcessTime(_pc, _seconds):
	_lazySetup()
	var mod = GlobalRegistry.getModule("VoreMod")
	if mod == null:
		return
	if mod.has_method("tickPocketedNPCs"):
		mod.tickPocketedNPCs(_seconds)
	_advanceShrunkNPCPredatorTimers(_seconds)
func _advanceShrunkNPCPredatorTimers(_seconds):
	if GM.main == null:
		return
	var sec = float(_seconds)
	if sec <= 0.0:
		return
	for npcID in GM.main.dynamicCharacters.keys():
		var ch = GM.main.dynamicCharacters.get(npcID)
		if ch == null:
			continue
		if !ch.hasEffect("VoreShrunkNPCPredator"):
			continue
		var eff = ch.getEffect("VoreShrunkNPCPredator")
		if eff != null && eff.has_method("tickSeconds"):
			eff.tickSeconds(sec)
func npcUpdateNonBattleEffects(_npc):
	_reapplyScaleForNPC(_npc)
	_tryConnectStageSignal()
func npcProcessTime(_npc, _seconds):
	_reapplyScaleForNPC(_npc)
func _reapplyScaleForNPC(_npc):
	if _npc == null:
		return
	if _npc.hasEffect("VoreSizeChange"):
		var effect = _npc.getEffect("VoreSizeChange")
		if effect != null && effect.targetScale != null:
			VoreBodyScaleHelper._applyNPCDollScale(_npc, effect.targetScale)
	var npcID = ""
	if _npc.has_method("getID"):
		npcID = _npc.getID()
	if npcID != "":
		var persistedScale = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
		if abs(persistedScale - 1.0) > 0.001:
			VoreBodyScaleHelper._applyNPCDollScale(_npc, persistedScale)
func _lazySetup():
	if GM.pc == null || GM.main == null:
		return
	_connectPCSignals()
	_spawnScaleUpdater()
	_restorePickedUpNPCs()
	_giveRoomDebugger()
func _connectPCSignals():
	if _pcSignalConnected:
		return
	if !GM.pc.has_signal("bodypart_changed"):
		return
	if !GM.pc.is_connected("bodypart_changed", self, "_onPCBodypartChanged"):
		var _ok = GM.pc.connect("bodypart_changed", self, "_onPCBodypartChanged")
	_pcSignalConnected = true
	VoreBodyScaleHelper.applyPCBodyScale()
func _onPCBodypartChanged():
	call_deferred("_deferredApplyScale")
func _deferredApplyScale():
	VoreBodyScaleHelper.applyPCBodyScale()
func _spawnScaleUpdater():
	if _updaterSpawned:
		return
	var stage = VoreBodyScaleHelper.getStage()
	if stage == null:
		return
	if !stage.has_node("VoreScaleUpdater"):
		var updater = Node.new()
		updater.name = "VoreScaleUpdater"
		updater.set_script(preload("res://Modules/VoreMod/VoreScaleUpdater.gd"))
		stage.add_child(updater)
	_updaterSpawned = true
func _restorePickedUpNPCs():
	if _pickedUpRestored:
		return
	_pickedUpRestored = true
	var mod = GlobalRegistry.getModule("VoreMod")
	if mod != null && mod.has_method("restorePickedUpNPCs"):
		mod.restorePickedUpNPCs()
func _giveRoomDebugger():
	if _debuggerGiven:
		return
	_debuggerGiven = true
	var mod = GlobalRegistry.getModule("VoreMod")
	if mod != null && mod.has_method("giveRoomDebugger"):
		mod.giveRoomDebugger()
func _tryConnectStageSignal():
	if _connectedToStage:
		return
	var stage = VoreBodyScaleHelper.getStage()
	if stage == null:
		return
	if stage.has_signal("sceneChanged"):
		if !stage.is_connected("sceneChanged", self, "_onStageSceneChanged"):
			stage.connect("sceneChanged", self, "_onStageSceneChanged")
	if !stage.is_connected("child_entered_tree", self, "_onStageChildEntered"):
		stage.connect("child_entered_tree", self, "_onStageChildEntered")
	_connectedToStage = true
func _onStageSceneChanged():
	call_deferred("_deferredReapplyAll")
func _onStageChildEntered(_child):
	call_deferred("_deferredReapplyAll")
func _deferredReapplyAll():
	VoreBodyScaleHelper.reapplyAllNPCScales()
	VoreBodyScaleHelper.applyPCBodyScale()
