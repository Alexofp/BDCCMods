extends Reference
const FLAG_PC_BODY_SCALE = "VoreMod.PCBodyScale"
const FLAG_NPC_BODY_SCALES = "VoreMod.NPCBodyScales"
const FLAG_PICKED_UP_NPCS = "VoreMod.PickedUpNPCs"
const MIN_SCALE = 0.1
const MAX_SCALE = 5.0
const PICKUP_MAX_SCALE = 0.4
const STAGE3D_PATH = "/root/MainScene/GameUI/MainLayout/RightPanel/Margin/PlayerPanel/ViewportWrapper/Viewport/Stage3D"
const PUNISH_MIN_SCALE = 0.6
const PUNISH_MAX_SCALE = 1.6
static func isScaleAllowedForPunish(scaleVal: float) -> bool:
	return scaleVal > PUNISH_MIN_SCALE && scaleVal < PUNISH_MAX_SCALE
static func isPunishAllowedForCharacter(charObj) -> bool:
	if charObj == null:
		return true
	if charObj.has_method("isPlayer") && charObj.isPlayer():
		return true
	var scaleVal = getNPCBodyScale(charObj)
	return isScaleAllowedForPunish(scaleVal)
static func getPunishBlockedReason(charObj) -> String:
	var scaleVal = 1.0
	if charObj != null:
		scaleVal = getNPCBodyScale(charObj)
	if scaleVal <= PUNISH_MIN_SCALE:
		return "They're currently shrunk too small for this -- wait for the size effect to wear off first.."
	if scaleVal >= PUNISH_MAX_SCALE:
		return "They're currently grown too large for this -- wait for the size effect to wear off first.."
	return "Their current body size makes this impossible right now.."
static func getPCBodyScale() -> float:
	if GM.main == null:
		return 1.0
	var val = GM.main.getFlag(FLAG_PC_BODY_SCALE, 1.0)
	if val == null:
		return 1.0
	return clamp(float(val), MIN_SCALE, MAX_SCALE)
static func setPCBodyScale(newScale: float):
	if GM.main == null:
		return
	newScale = stepify(clamp(newScale, MIN_SCALE, MAX_SCALE), 0.01)
	GM.main.setFlag(FLAG_PC_BODY_SCALE, newScale)
	applyPCBodyScale()
static func resetPCBodyScale():
	setPCBodyScale(1.0)
static func _getNPCScalesDict() -> Dictionary:
	if GM.main == null:
		return {}
	var val = GM.main.getFlag(FLAG_NPC_BODY_SCALES, {})
	if val == null:
		return {}
	return val
static func _saveNPCScaleFlag(npcCharID: String, newScale: float):
	if GM.main == null:
		return
	newScale = stepify(clamp(newScale, MIN_SCALE, MAX_SCALE), 0.01)
	var scales = _getNPCScalesDict()
	scales[npcCharID] = newScale
	GM.main.setFlag(FLAG_NPC_BODY_SCALES, scales)
static func setNPCBodyScale(npcCharID: String, newScale: float):
	_saveNPCScaleFlag(npcCharID, newScale)
	var npcChar = GlobalRegistry.getCharacter(npcCharID)
	if npcChar != null:
		_applyNPCDollScale(npcChar, newScale)
static func getNPCBodyScaleByID(npcCharID: String) -> float:
	var scales = _getNPCScalesDict()
	if scales.has(npcCharID):
		return clamp(float(scales[npcCharID]), MIN_SCALE, MAX_SCALE)
	return 1.0
static func removeNPCBodyScale(npcCharID: String):
	if GM.main == null:
		return
	var scales = _getNPCScalesDict()
	if scales.has(npcCharID):
		scales.erase(npcCharID)
		GM.main.setFlag(FLAG_NPC_BODY_SCALES, scales)
static func _getPickedUpDict() -> Dictionary:
	if GM.main == null:
		return {}
	var val = GM.main.getFlag(FLAG_PICKED_UP_NPCS, {})
	if val == null:
		return {}
	return val
static func isNPCPickedUp(npcCharID: String) -> bool:
	var d = _getPickedUpDict()
	return d.has(npcCharID) and d[npcCharID] == true
static func setNPCPickedUp(npcCharID: String, pickedUp: bool):
	if GM.main == null:
		return
	var d = _getPickedUpDict()
	if pickedUp:
		d[npcCharID] = true
	else:
		d.erase(npcCharID)
	GM.main.setFlag(FLAG_PICKED_UP_NPCS, d)
static func _getStage():
	if GM.main == null:
		return null
	if GM.ui != null && GM.ui.has_method("getStage3d"):
		var theStage = GM.ui.getStage3d()
		if theStage != null:
			return theStage
	return GM.main.get_tree().root.get_node_or_null(STAGE3D_PATH)
static func getPCDoll():
	var stage = _getStage()
	if stage == null || stage.currentScene == null:
		return null
	return _findDollForID("pc", stage.currentScene)
static func getNPCDoll(npcChar):
	if npcChar == null:
		return null
	var npcID = ""
	if npcChar.has_method("getID"):
		npcID = npcChar.getID()
	if npcID == "":
		return null
	var stage = _getStage()
	if stage == null || stage.currentScene == null:
		return null
	return _findDollForID(npcID, stage.currentScene)
static func _findDollForID(charID: String, scene) -> Object:
	if scene == null:
		return null
	if scene.has_method("getDolls"):
		for doll in scene.getDolls():
			if _dollMatchesID(doll, charID):
				return doll
	for child in scene.get_children():
		if child.get_class() == "Spatial" && child.has_method("prepareCharacter"):
			if _dollMatchesID(child, charID):
				return child
	return null
static func _dollMatchesID(doll, charID: String) -> bool:
	var savedID = doll.savedCharacterID
	if savedID == null:
		return false
	if savedID is String:
		return savedID == charID
	if savedID.has_method("getID"):
		return savedID.getID() == charID
	if charID == "pc" && savedID == GM.pc:
		return true
	return false
static func findAnyNPCDoll():
	var stage = _getStage()
	if stage == null || stage.currentScene == null:
		return null
	var scene = stage.currentScene
	if scene.has_method("getDolls"):
		for doll in scene.getDolls():
			var id = doll.savedCharacterID
			if id == null:
				continue
			if id is String && (id == "pc" || id == ""):
				continue
			if !(id is String) && id == GM.pc:
				continue
			return doll
	for child in scene.get_children():
		if child.get_class() == "Spatial" && child.has_method("prepareCharacter"):
			var id = child.savedCharacterID
			if id == null:
				continue
			if id is String && (id == "pc" || id == ""):
				continue
			if !(id is String) && id == GM.pc:
				continue
			return child
	return null
static func _collectAllDolls() -> Array:
	var stage = _getStage()
	if stage == null:
		return []
	var dolls = []
	for scene in stage.get_children():
		if !(scene.get_class() == "Node" || scene is Node):
			continue
		if scene.has_method("getDolls"):
			for doll in scene.getDolls():
				if doll != null:
					dolls.append(doll)
		for child in scene.get_children():
			if child.get_class() == "Spatial" && child.has_method("prepareCharacter"):
				dolls.append(child)
	return dolls
static func applyPCBodyScale():
	var scaleVal = getPCBodyScale()
	var doll = getPCDoll()
	if doll == null:
		return
	var cur = doll.get_scale()
	var sx = sign(cur.x) if cur.x != 0.0 else 1.0
	var sy = sign(cur.y) if cur.y != 0.0 else 1.0
	var sz = sign(cur.z) if cur.z != 0.0 else 1.0
	doll.set_scale(Vector3(sx * scaleVal, sy * scaleVal, sz * scaleVal))
static func _applyNPCDollScale(npcChar, scaleVal: float):
	var doll = getNPCDoll(npcChar)
	if doll == null:
		return
	var cur = doll.get_scale()
	var sx = sign(cur.x) if cur.x != 0.0 else 1.0
	var sy = sign(cur.y) if cur.y != 0.0 else 1.0
	var sz = sign(cur.z) if cur.z != 0.0 else 1.0
	doll.set_scale(Vector3(sx * scaleVal, sy * scaleVal, sz * scaleVal))
static func applyNPCBodyScale(npcChar, scaleVal: float = -1.0):
	if npcChar == null:
		return
	var npcID = ""
	if npcChar.has_method("getID"):
		npcID = npcChar.getID()
	if npcID == "":
		return
	if scaleVal < 0.0:
		scaleVal = getNPCBodyScaleByID(npcID)
	scaleVal = clamp(scaleVal, MIN_SCALE, MAX_SCALE)
	_saveNPCScaleFlag(npcID, scaleVal)
	_applyNPCDollScale(npcChar, scaleVal)
static func getNPCBodyScale(npcChar) -> float:
	if npcChar == null:
		return 1.0
	var npcID = ""
	if npcChar.has_method("getID"):
		npcID = npcChar.getID()
	if npcID != "":
		var persisted = getNPCBodyScaleByID(npcID)
		if abs(persisted - 1.0) > 0.001:
			return persisted
	var doll = getNPCDoll(npcChar)
	if doll != null:
		return abs(doll.get_scale().x)
	return 1.0
static func getCurrentPCScale() -> float:
	var doll = getPCDoll()
	if doll != null:
		var s = abs(doll.get_scale().x)
		if abs(s - 1.0) > 0.001:
			return s
	return getPCBodyScale()
static func applyScaleToCharacter(charObj, targetScale: float) -> String:
	if charObj == null:
		return "Nobody was affected."
	targetScale = clamp(targetScale, MIN_SCALE, MAX_SCALE)
	var charName = "Someone"
	if charObj.has_method("getName"):
		charName = charObj.getName()
	if charObj.isPlayer():
		setPCBodyScale(targetScale)
	else:
		applyNPCBodyScale(charObj, targetScale)
	var scaleStr = str(stepify(targetScale, 0.01))
	if targetScale < 1.0:
		return charName + " shrank to " + scaleStr + "x size!"
	elif targetScale > 1.0:
		return charName + " grew to " + scaleStr + "x size!"
	else:
		return charName + " returned to normal size."
static func onPCBodypartChanged():
	applyPCBodyScale()
static func reapplyAllNPCScales():
	var stage = _getStage()
	if stage == null:
		return
	var scales = _getNPCScalesDict()
	if scales.empty():
		return
	var dollsToCheck = _collectAllDolls()
	if stage.currentScene != null:
		if stage.currentScene.has_method("getDolls"):
			for doll in stage.currentScene.getDolls():
				if doll != null && !dollsToCheck.has(doll):
					dollsToCheck.append(doll)
		for child in stage.currentScene.get_children():
			if child.get_class() == "Spatial" && child.has_method("prepareCharacter"):
				if !dollsToCheck.has(child):
					dollsToCheck.append(child)
	for doll in dollsToCheck:
		var savedID = doll.savedCharacterID
		if savedID == null:
			continue
		var npcID = ""
		if savedID is String:
			npcID = savedID
		elif savedID.has_method("getID"):
			npcID = savedID.getID()
		if npcID == "" || npcID == "pc":
			continue
		if isNPCPickedUp(npcID):
			continue
		if scales.has(npcID):
			var s = clamp(float(scales[npcID]), MIN_SCALE, MAX_SCALE)
			if abs(s - 1.0) > 0.001:
				var cur = doll.get_scale()
				var sx = sign(cur.x) if cur.x != 0.0 else 1.0
				var sy = sign(cur.y) if cur.y != 0.0 else 1.0
				var sz = sign(cur.z) if cur.z != 0.0 else 1.0
				doll.set_scale(Vector3(sx * s, sy * s, sz * s))
static func getStage():
	return _getStage()
