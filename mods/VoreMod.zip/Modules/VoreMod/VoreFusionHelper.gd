extends Reference
const SNAPSHOT_FLAG = "FusionSnapshots"
const SNAPSHOT_MAX = 25

static func getSnapshotCount() -> int:
	return _getSnapshotStack().size()

static func _getSnapshotStack() -> Array:
	if(GM.main == null):
		return []
	var modVal = GM.main.getModuleFlag("VoreMod", "FusionSnapshots", {})
	if(modVal != null):
		if(modVal is Dictionary && modVal.has("stack") && (modVal["stack"] is Array)):
			return modVal["stack"]
		if(modVal is Array):
			return modVal
	var globVal = GM.main.getFlag("VoreMod.FusionSnapshots", [])
	if(globVal != null && (globVal is Array)):
		return globVal
	return []

static func _setSnapshotStack(stack: Array):
	if(GM.main == null):
		return
	GM.main.setModuleFlag("VoreMod", "FusionSnapshots", {"stack": stack})
	GM.main.setFlag("VoreMod.FusionSnapshots", stack)

static func pushSnapshot(snapshot: Dictionary):
	var stack = _getSnapshotStack()
	stack.append(snapshot)
	while(stack.size() > SNAPSHOT_MAX):
		stack.pop_front()
	_setSnapshotStack(stack)

static func popSnapshot() -> Dictionary:
	var stack = _getSnapshotStack()
	if(stack.size() <= 0):
		return {}
	var snap = stack[stack.size() - 1]
	stack.remove(stack.size() - 1)
	_setSnapshotStack(stack)
	return snap

static func captureSnapshot(player, npcName: String = "") -> Dictionary:
	var snapshot = {}
	snapshot["npcName"] = npcName
	var ph = player.getSkillsHolder()
	if(ph != null):
		snapshot["level"] = ph.getLevel()
		snapshot["experience"] = ph.experience if ("experience" in ph) else 0
		var stats = {}
		for statID in Stat.getAll():
			stats[statID] = ph.getBaseStat(statID)
		snapshot["stats"] = stats
		var skills = {}
		var skillsDict = ph.getSkills()
		for skillID in skillsDict:
			var skill = skillsDict[skillID]
			if(skill != null):
				skills[skillID] = skill.getLevel()
		snapshot["skills"] = skills
		var perks = []
		for perkID in ph.getPerks():
			perks.append(perkID)
		snapshot["perks"] = perks
	snapshot["femininity"] = player.getFemininity()
	snapshot["thickness"] = player.getThickness()
	snapshot["skin"] = player.pickedSkin
	snapshot["skinColors"] = [player.pickedSkinRColor, player.pickedSkinGColor, player.pickedSkinBColor]
	var parts = {}
	for slot in player.getBodyparts():
		var part = player.getBodypart(slot)
		if(part != null):
			parts[slot] = {"id": part.id, "data": part.saveDataForTF()}
	snapshot["parts"] = parts
	return snapshot

static func _removePerkThorough(ph, perkID):
	if(!ph.hasPerkDisabledOrNot(perkID)):
		return
	var perksDict = ph.getPerks()
	var perkObj = null
	if(perksDict.has(perkID)):
		perkObj = perksDict[perkID]
		ph.removePerk(perkID)
	if(perksDict.has(perkID)):
		if(perkObj != null):
			perkObj.npc = null
		perksDict.erase(perkID)
	if("disabledPerks" in ph):
		ph.disabledPerks.erase(perkID)

static func _restoreFromSnapshot(player, snapshot) -> bool:
	if(player == null):
		return false
	var ph = player.getSkillsHolder()
	if(ph == null):
		return false
	ph.setLevel(int(snapshot.get("level", ph.getLevel())))
	if("experience" in ph):
		ph.experience = int(snapshot.get("experience", 0))
	var stats = snapshot.get("stats", {})
	for statID in stats:
		ph.setStat(str(statID), int(stats[statID]))
	var skills = snapshot.get("skills", {})
	var curSkills = ph.getSkills()
	for skillID in curSkills.keys().duplicate():
		if(skills.has(skillID)):
			var skill = curSkills[skillID]
			if(skill != null):
				skill.setLevel(int(skills[skillID]))
		elif("skills" in ph):
			ph.skills.erase(skillID)
	for skillID in skills:
		if(!ph.getSkills().has(skillID)):
			ph.ensureSkillExists(skillID)
			var skill = ph.getSkill(skillID)
			if(skill != null):
				skill.setLevel(int(skills[skillID]))
	var perks = snapshot.get("perks", [])
	for perkID in ph.getPerks().keys().duplicate():
		if(!perks.has(perkID)):
			_removePerkThorough(ph, perkID)
	player.setFemininity(int(snapshot.get("femininity", player.getFemininity())))
	player.setThickness(int(snapshot.get("thickness", player.getThickness())))
	player.pickedSkin = snapshot.get("skin", player.pickedSkin)
	var cols = snapshot.get("skinColors", [])
	if(cols.size() >= 3):
		player.pickedSkinRColor = cols[0]
		player.pickedSkinGColor = cols[1]
		player.pickedSkinBColor = cols[2]
	var parts = snapshot.get("parts", {})
	for slot in player.getBodyparts().keys().duplicate():
		if(!parts.has(slot)):
			player.removeBodypart(slot, false)
	for slot in parts:
		var info = parts[slot]
		var partID = str(info.get("id", ""))
		if(partID == ""):
			continue
		var part = null
		if(player.hasBodypart(slot)):
			part = player.getBodypart(slot)
		if(part == null || part.id != partID):
			part = GlobalRegistry.createBodypart(partID)
			if(part == null):
				continue
			player.giveBodypart(part, false)
		part.loadDataForTF(info.get("data", {}))
	player.checkSkins(true)
	player.emit_signal("bodypart_changed")
	return true

static func undoLastFusion(player) -> Dictionary:
	var summary = {"ok": false, "npcName": "", "level": 0, "perksRemoved": 0, "skillsRemoved": 0, "partsReverted": 0}
	if(player == null):
		return summary
	var snapshot = popSnapshot()
	if(snapshot.empty()):
		return summary
	var ph = player.getSkillsHolder()
	summary["npcName"] = str(snapshot.get("npcName", "the other"))
	summary["level"] = int(snapshot.get("level", 0))
	if(ph != null):
		var perks = snapshot.get("perks", [])
		for perkID in ph.getPerks().keys().duplicate():
			if(!perks.has(perkID)):
				summary["perksRemoved"] += 1
		var skills = snapshot.get("skills", {})
		for skillID in ph.getSkills().keys().duplicate():
			if(!skills.has(skillID)):
				summary["skillsRemoved"] += 1
	summary["partsReverted"] = int(snapshot.get("parts", {}).size())
	if(_restoreFromSnapshot(player, snapshot)):
		summary["ok"] = true
	return summary

func performFusion(player, npc) -> Dictionary:
	var summary = {"ok": false, "npcName": "", "newLevel": 0, "gainedPerks": [], "speciesFrom": "", "slotsChanged": 0}
	if player == null or npc == null:
		return summary
	var ph = player.getSkillsHolder()
	var nh = npc.getSkillsHolder()
	if ph == null or nh == null:
		return summary
	summary["npcName"] = npc.getName()
	pushSnapshot(captureSnapshot(player, npc.getName()))
	var newLevel = int(round((ph.getLevel() + nh.getLevel()) / 2.0))
	if newLevel < 1:
		newLevel = 1
	ph.setLevel(newLevel)
	if "experience" in ph:
		ph.experience = 0
	summary["newLevel"] = newLevel
	var statIDs = Stat.getAll()
	var weights = {}
	var weightTotal = 0.0
	for statID in statIDs:
		var w = (ph.getBaseStat(statID) + nh.getBaseStat(statID)) / 2.0
		if w < 0:
			w = 0.0
		weights[statID] = w
		weightTotal += w
	var pointsToSpend = newLevel * 3
	var allocated = 0
	for idx in range(statIDs.size()):
		var statID = statIDs[idx]
		var val = 0
		if idx == statIDs.size() - 1:
			val = pointsToSpend - allocated
		elif weightTotal > 0.0:
			val = int(floor(pointsToSpend * (weights[statID] / weightTotal)))
			allocated += val
		else:
			val = int(pointsToSpend / statIDs.size())
			allocated += val
		if val < 0:
			val = 0
		ph.setStat(statID, val)
	var nSkills = nh.getSkills()
	for skillID in nSkills:
		ph.ensureSkillExists(skillID)
		var pSkill = ph.getSkill(skillID)
		var nSkill = nSkills[skillID]
		if pSkill != null and nSkill != null:
			var avgLvl = int(round((pSkill.getLevel() + nSkill.getLevel()) / 2.0))
			pSkill.setLevel(avgLvl)
	var gained = []
	var nPerks = nh.getPerks()
	for perkID in nPerks:
		if not ph.hasPerkDisabledOrNot(perkID):
			ph.addPerk(perkID)
			gained.append(perkID)
	summary["gainedPerks"] = gained
	player.setFemininity(int(round((player.getFemininity() + npc.getFemininity()) / 2.0)))
	player.setThickness(int(round((player.getThickness() + npc.getThickness()) / 2.0)))
	var bodyInfo = _mergeBodies(player, npc)
	summary["speciesFrom"] = bodyInfo["speciesFrom"]
	summary["slotsChanged"] = bodyInfo["slotsChanged"]
	summary["ok"] = true
	return summary
func _mergeBodies(player, npc) -> Dictionary:
	var info = {"speciesFrom": "", "slotsChanged": 0, "dominantIsNPC": false}
	var dominantIsNPC = (RNG.randi_range(0, 1) == 0)
	var dominant = npc if dominantIsNPC else player
	var other    = player if dominantIsNPC else npc
	info["dominantIsNPC"] = dominantIsNPC
	info["speciesFrom"] = dominant.getName()
	player.pickedSkin = dominant.getBaseSkinID()
	var cols = dominant.getBaseSkinColors()
	if cols.size() >= 3:
		player.pickedSkinRColor = cols[0]
		player.pickedSkinGColor = cols[1]
		player.pickedSkinBColor = cols[2]
	var slots = {}
	for s in player.getBodyparts():
		slots[s] = true
	for s in npc.getBodyparts():
		slots[s] = true
	var changed = 0
	for slot in slots.keys():
		var domHas = dominant.hasBodypart(slot)
		var othHas = other.hasBodypart(slot)
		var donor = null
		if domHas and othHas:
			donor = dominant if RNG.randi_range(0, 99) < 60 else other
		elif domHas:
			donor = dominant
		elif othHas:
			donor = other
		if _applySlotFrom(player, donor, slot):
			changed += 1
	info["slotsChanged"] = changed
	player.checkSkins(true)
	player.emit_signal("bodypart_changed")
	return info
func _applySlotFrom(player, donor, slot) -> bool:
	if donor == null:
		return false
	if not donor.hasBodypart(slot):
		if player.hasBodypart(slot):
			player.removeBodypart(slot, false)
			return true
		return false
	var srcPart = donor.getBodypart(slot)
	if srcPart == null:
		return false
	if player.hasBodypart(slot) and player.getBodypartID(slot) == srcPart.id:
		return false
	var newPart = GlobalRegistry.createBodypart(srcPart.id)
	if newPart == null:
		return false
	player.giveBodypart(newPart, false)
	newPart.loadDataForTF(srcPart.saveDataForTF())
	newPart.pickedSkin = srcPart.pickedSkin
	newPart.pickedRColor = srcPart.pickedRColor
	newPart.pickedGColor = srcPart.pickedGColor
	newPart.pickedBColor = srcPart.pickedBColor
	return true
func performFusionWithMessages(player, npc) -> Dictionary:
	var summary = performFusion(player, npc)
	if not summary["ok"]:
		return summary
	if GM.main != null:
		var nm = summary["npcName"]
		GM.main.addMessage("[b]Fusion![/b] You and " + nm + " meld into a single new being - your bodies, strength and skills drawn together to the middle, and all of " + nm + "'s perks now yours.")
		if summary["gainedPerks"].size() > 0:
			GM.main.addMessage("You inherit " + str(summary["gainedPerks"].size()) + " perk(s) from " + nm + ".")
		if summary["speciesFrom"] != "":
			GM.main.addMessage("The fused body settles into " + summary["speciesFrom"] + "'s species and coloration, reshaped with parts of both of you (" + str(summary["slotsChanged"]) + " body part(s) changed).")
		GM.main.addMessage("Your level settles at " + str(summary["newLevel"]) + " as the two of you become one.")
		if(player != null && player.isPlayer() && player.has_method("getInventory")):
			var inv = player.getInventory()
			if(inv != null):
				inv.addItemID("VoreUndoFusionPill")
				GM.main.addMessage("As the fusion settles, a [b]Defusion Pill[/b] materializes in your inventory - in case you ever want to undo it and return to who you were before.")
	return summary
func transferPregnancy(fromChar, toChar) -> int:
	if fromChar == null or toChar == null:
		return 0
	var src = fromChar.getMenstrualCycle()
	var dst = toChar.getMenstrualCycle()
	if src == null or dst == null:
		return 0
	if not src.isPregnant():
		return 0
	if not dst.hasAnyWomb():
		return -1
	var targetOrifice = OrificeType.Vagina
	for o in OrificeType.getAll():
		if dst.hasWombIn(o):
			targetOrifice = o
			break
	var moved = 0
	for egg in src.impregnatedEggCells.duplicate():
		if src.transferSpecificEggTo(egg, dst, targetOrifice):
			moved += 1
	for egg in src.bigEggs.duplicate():
		if src.transferSpecificEggTo(egg, dst, targetOrifice):
			moved += 1
	return moved
func convertSpeciesTo(target, source) -> bool:
	if target == null or source == null:
		return false
	var newSpecies = source.getSpecies()
	if newSpecies == null or not (newSpecies is Array) or newSpecies.empty():
		return false
	if "npcSpecies" in target:
		target.npcSpecies = newSpecies.duplicate()
		if "npcCustomSpeciesName" in target:
			target.npcCustomSpeciesName = ""
	elif target.has_method("setSpecies"):
		target.setSpecies(newSpecies.duplicate())
	else:
		return false
	var gender = target.getGender()
	for slot in BodypartSlot.getAll():
		if slot == BodypartSlot.Hair:
			continue
		if not target.hasBodypart(slot):
			continue
		var oldID = target.getBodypartID(slot)
		var newID = BodypartSlot.findReplacement(slot, oldID, newSpecies, gender)
		if newID != null and newID != "" and newID != oldID:
			target.switchBodypartSimple(newID)
	target.pickedSkin = source.getBaseSkinID()
	var cols = source.getBaseSkinColors()
	if cols.size() >= 3:
		target.pickedSkinRColor = cols[0]
		target.pickedSkinGColor = cols[1]
		target.pickedSkinBColor = cols[2]
	target.checkSkins(true)
	target.emit_signal("bodypart_changed")
	return true
