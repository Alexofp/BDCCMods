extends Reference

static func getDamageStat(ch) -> float:
	if ch == null:
		return 0.0
	if !ch.has_method("getStat"):
		return 0.0
	return float(ch.getStat(Stat.Strength))

static func getArmour(ch) -> float:
	if ch == null:
		return 0.0
	if !ch.has_method("getArmor"):
		return 0.0
	return float(ch.getArmor(DamageType.Physical))

static func percentToBeat(holderDamage: float, escaperArmour: float) -> float:
	return clamp(50.0 + (holderDamage - escaperArmour) * 2.0, 5.0, 95.0)

static func beatsPercent(percent: float) -> bool:
	return RNG.randi_range(1, 100) > int(round(percent))
