extends EventBase
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

const CD_FLAG = "VoreMod.VoreStuffCD"
const BASE_CHANCE = 6

func _init():
	id = "VoreObjectStuffEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)

func _getCd() -> int:
	var v = getFlag(CD_FLAG, 0)
	if(typeof(v) == TYPE_INT || typeof(v) == TYPE_REAL):
		return int(v)
	return 0

func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(GM.main.isInDungeon() || GM.main.isCharIDFighting("pc")):
		return false
	if(!VoreObjectHelper.isUnlocked(GM.pc)):
		return false
	if(GM.pc.hasEffect("VorePlayerDigesting")):
		return false
	var populations = GM.pc.getLocationPopulation()
	if(!(WorldPopulation.Inmates in populations)):
		return false
	var cd = _getCd()
	if(cd > 0):
		setFlag(CD_FLAG, cd - 1)
		return false
	if(RNG.randi_range(1, 100) > BASE_CHANCE):
		return false
	var m = VoreObjectHelper.pickRandomMethodWithSpace(GM.pc)
	if(m == ""):
		return false
	var item = VoreObjectHelper.pickRandomStorableItem(GM.pc)
	if(item == null):
		return false
	var itemName = item.getVisibleName()
	setFlag(CD_FLAG, RNG.randi_range(10, 20))
	if(!VoreObjectHelper.storeItem(GM.pc, item, m)):
		return false
	var part = VoreObjectHelper.partWord(m)
	addMessage("A pack of inmates crowds you in passing. \"Oi, everyone knows you are a walking storage locker now!\" Before you can argue, one of them grabs " + itemName + " out of your hands and works it into your " + part + " while the rest cheer. They wander off laughing, leaving you stuffed with your own gear.")
	GM.pc.addLust(5)
	return false

func getPriority():
	return 8
