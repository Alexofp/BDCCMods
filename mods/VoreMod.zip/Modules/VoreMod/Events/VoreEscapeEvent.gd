extends EventBase


func _init():
	id = "VoreEscapeEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)

func react(_triggerID, _args):
	if(GM.pc == null):
		return false
	if(!GM.pc.hasEffect("VoreSwallowedNPC")):
		return false

	if(GM.main != null && GM.main.isCharIDFighting("pc")):
		return false

	var effect = GM.pc.getEffect("VoreSwallowedNPC")
	if(effect == null || !effect.hasPendingEscape()):
		return false

	var npcID = effect.getPendingEscapeID()

	if(npcID == "" || !effect.canStillEscape(npcID)):
		effect.clearPendingEscape()
		return false

	runScene("VoreEscapeScene", [npcID])
	return true

func getPriority():
	return 20
