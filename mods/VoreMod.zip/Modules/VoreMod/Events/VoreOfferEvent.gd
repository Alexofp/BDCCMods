extends EventBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
const OFFER_CHANCE = 12
const COOLDOWN_MIN = 2
const COOLDOWN_MAX = 4
const CD_FLAG = "VoreMod.VoreOfferCD"
func _init():
	id = "VoreOfferEvent"
func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)
func _pickNPC() -> String:
	if(GM.pc == null || GM.main == null):
		return ""
	var loc = GM.pc.getLocation()
	if(loc == ""):
		return ""
	var ids = GM.main.IS.getPawnIDsNear(loc, 2)
	var anyCandidates = []
	var voreCandidates = []
	for pid in ids:
		if(pid == "pc"):
			continue
		var ch = GlobalRegistry.getCharacter(pid)
		if(ch == null || !ch.isDynamicCharacter()):
			continue
		if(ch.hasEffect("VorePredatorBelly")):
			continue
		var like = 0.0
		var fh = ch.getFetishHolder()
		if(fh != null):
			like = fh.getFetishValue("Vore")
		anyCandidates.append(pid)
		if(like >= 0.2):
			voreCandidates.append(pid)
	var pool = anyCandidates
	if(voreCandidates.size() > 0):
		pool = voreCandidates
	if(pool.size() <= 0):
		return ""
	pool.shuffle()
	return pool[0]
func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(GM.main.isInDungeon()):
		return false
	if(GM.main.isCharIDFighting("pc")):
		return false
	if(GM.main.isVeryLate()):
		return false
	if(GM.pc.hasEffect("VorePlayerDigesting")):
		return false
	if(VoreSwallowed.getEffectWithPendingEscape(GM.pc) != null):
		return false
	var populations = GM.pc.getLocationPopulation()
	if(!(WorldPopulation.Inmates in populations) && !(WorldPopulation.Guards in populations)):
		return false
	if(getFlag(CD_FLAG, 0) > 0):
		increaseFlag(CD_FLAG, -1)
		return false
	if(RNG.randi_range(1, 100) > OFFER_CHANCE):
		return false
	var npcID = _pickNPC()
	if(npcID == ""):
		return false
	setFlag(CD_FLAG, RNG.randi_range(COOLDOWN_MIN, COOLDOWN_MAX))
	GM.main.IS.spawnPawnIfNeeded(npcID)
	runScene("VoreOfferScene", [npcID])
	return true
func getPriority():
	return 10