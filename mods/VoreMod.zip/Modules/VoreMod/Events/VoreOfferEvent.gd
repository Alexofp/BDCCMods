extends EventBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")

const OFFER_CHANCE = 25
const CD_MIN = 2
const CD_MAX = 4

const CD_FLAG = "VoreMod.VoreOfferCD"
const DEBUG_FLAG = "VoreMod.VoreOfferDebug"

func _init():
	id = "VoreOfferEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)

func _hasPerk(perkID: String) -> bool:
	if(GM.pc == null):
		return false
	var h = GM.pc.getSkillsHolder()
	if(h == null):
		return false
	return h.hasPerk(perkID)

func _offerChance() -> int:
	var magnet = _hasPerk("VoreApproachMagnet")
	var repellent = _hasPerk("VoreApproachRepellent")
	if(magnet and !repellent):
		return 50
	if(repellent and !magnet):
		return 5
	return OFFER_CHANCE

func _cdRange() -> Array:
	var magnet = _hasPerk("VoreApproachMagnet")
	var repellent = _hasPerk("VoreApproachRepellent")
	if(magnet and !repellent):
		return [1, 1]
	if(repellent and !magnet):
		return [15, 25]
	return [CD_MIN, CD_MAX]

func _getCd() -> int:
	var v = getFlag(CD_FLAG, 0)
	if(typeof(v) == TYPE_INT || typeof(v) == TYPE_REAL):
		return int(v)
	return 0

func _debugOn() -> bool:
	return getFlag(DEBUG_FLAG, false) == true

func _dbg(msg):
	if(_debugOn()):
		addMessage("[VoreOffer] " + msg)

func _pickNPC() -> String:
	if(GM.pc == null || GM.main == null):
		return ""
	var loc = GM.pc.getLocation()
	if(loc == ""):
		return ""
	var ids = GM.main.IS.getPawnIDsNear(loc, 2)
	var anyCandidates = []
	var voreCandidates = []
	for pid in ids:
		if(pid == "pc"):
			continue
		var ch = GlobalRegistry.getCharacter(pid)
		if(ch == null || !ch.isDynamicCharacter()):
			continue
		if(ch.hasEffect("VorePredatorBelly")):
			continue
		var like = 0.0
		var fh = ch.getFetishHolder()
		if(fh != null):
			like = fh.getFetishValue("Vore")
		anyCandidates.append(pid)
		if(like >= 0.2):
			voreCandidates.append(pid)
	var pool = anyCandidates
	if(voreCandidates.size() > 0):
		pool = voreCandidates
	if(pool.size() <= 0):
		return ""
	pool.shuffle()
	return pool[0]

func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(GM.main.isInDungeon()):
		_dbg("blocked: in dungeon")
		return false
	if(GM.main.isCharIDFighting("pc")):
		_dbg("blocked: in a fight")
		return false
	if(GM.main.isVeryLate()):
		_dbg("blocked: night time (isVeryLate)")
		return false
	if(GM.pc.hasEffect("VorePlayerDigesting")):
		_dbg("blocked: player is being digested")
		return false
	if(VoreSwallowed.getEffectWithPendingEscape(GM.pc) != null):
		_dbg("blocked: prey has pending escape")
		return false
	var populations = GM.pc.getLocationPopulation()
	if(!(WorldPopulation.Inmates in populations) && !(WorldPopulation.Guards in populations)):
		_dbg("blocked: room has no inmate/guard population")
		return false
	var cd = _getCd()
	if(cd > 0):
		setFlag(CD_FLAG, cd - 1)
		_dbg("blocked: cooldown " + str(cd) + " rooms left")
		return false
	var chance = _offerChance()
	var roll = RNG.randi_range(1, 100)
	if(roll > chance):
		_dbg("blocked: chance roll " + str(roll) + "/" + str(chance) + "% (magnet=" + str(_hasPerk("VoreApproachMagnet")) + " repellent=" + str(_hasPerk("VoreApproachRepellent")) + ")")
		return false
	var npcID = _pickNPC()
	if(npcID == ""):
		var near := 0
		for pid in GM.main.IS.getPawnIDsNear(GM.pc.getLocation(), 2):
			if(pid != "pc"):
				near += 1
		_dbg("blocked: no NPC found near (nearby non-pc pawns=" + str(near) + ")")
		return false
	_dbg("OFFER firing -> " + npcID)
	var r = _cdRange()
	setFlag(CD_FLAG, RNG.randi_range(r[0], r[1]))
	GM.main.IS.spawnPawnIfNeeded(npcID)
	runScene("VoreOfferScene", [npcID])
	return true

func getPriority():
	return 10
