extends EventBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
func _init():
	id = "VoreSleepBellyEvent"
func registerTriggers(es):
	es.addTrigger(self, Trigger.WakeUpInCell)
func _pickPredator() -> String:
	if(GM.pc == null || GM.main == null):
		return ""
	var loc = GM.pc.getLocation()
	if(loc == ""):
		return ""
	var candidates = []
	var ids = GM.main.IS.getPawnIDsNear(loc, 2)
	for pid in ids:
		if(pid == "pc"):
			continue
		var ch = GlobalRegistry.getCharacter(pid)
		if(ch == null || !ch.isDynamicCharacter()):
			continue
		if(ch.hasEffect("VorePredatorBelly")):
			continue
		var like = 0.0
		var fh = ch.getFetishHolder()
		if(fh != null):
			like = fh.getFetishValue("Vore")
		if(like >= -0.25):
			candidates.append(pid)
	if(candidates.size() <= 0):
		return ""
	candidates.shuffle()
	return candidates[0]
func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(GM.main.isCharIDFighting("pc")):
		return false
	var wakeChance = 15
	if(_preyIsIrresistible()):
		wakeChance += 25
	if(_preyHasLureScent()):
		wakeChance += 20
	if(RNG.randi_range(1, 100) > wakeChance):
		return false
	var predID = _pickPredator()
	if(predID == ""):
		return false
	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return false
	GM.main.IS.spawnPawnIfNeeded(predID)
	var voreMethod = _pickMethod(predator)
	if(voreMethod == ""):
		return false
	predator.addEffect("VorePredatorBelly", [GM.pc.getName(), voreMethod])
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn != null):
		pawn.setLocation(GM.pc.getLocation())
	GM.main.addMessage("You wake to suffocating heat and crushing pressure on all sides. This is no cell - you have woken up sealed inside " + predator.getName() + "!")
	runScene("VoreBellyRideScene", [predID, voreMethod])
	return true
func _pickMethod(predator) -> String:
	var methods = ["mouth", "anus", "tail"]
	if(predator != null):
		if(predator.hasNonFlatBreasts()):
			methods.append("breasts")
		if(predator.hasPenis()):
			methods.append("cock")
		if(predator.hasVagina()):
			methods.append("vagina")
	var allowed = []
	for m in methods:
		if(!VoreSwallowed.isMethodBlockedForPC(GM.pc, m)):
			allowed.append(m)
	if(allowed.size() <= 0):
		return ""
	return allowed[RNG.randi_range(0, allowed.size() - 1)]
func getPriority():
	return 25

const PERK_IRRESISTIBLE_PREY = "VoreIrresistiblePrey"
func _preyIsIrresistible() -> bool:
	if(GM.pc == null):
		return false
	return GM.pc.hasPerk(PERK_IRRESISTIBLE_PREY)
func _preyHasLureScent() -> bool:
	if(GM.pc == null):
		return false
	return GM.pc.hasEffect("VoreLureScent")
func _preyVoreLike(ch) -> float:
	if(ch == null):
		return 0.0
	var fh = ch.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")
