extends EventBase


func _init():
	id = "VoreSleepBellyEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.WakeUpInCell)

func _pickPredator() -> String:
	if(GM.pc == null || GM.main == null):
		return ""
	var loc = GM.pc.getLocation()
	if(loc == ""):
		return ""
	var candidates = []
	var ids = GM.main.IS.getPawnIDsNear(loc, 2)
	for pid in ids:
		if(pid == "pc"):
			continue
		var ch = GlobalRegistry.getCharacter(pid)
		if(ch == null || !ch.isDynamicCharacter()):
			continue
		if(ch.hasEffect("VorePredatorBelly")):
			continue
		var like = 0.0
		var fh = ch.getFetishHolder()
		if(fh != null):
			like = fh.getFetishValue("Vore")
		if(like >= -0.25):
			candidates.append(pid)
	if(candidates.size() <= 0):
		return ""
	candidates.shuffle()
	return candidates[0]

func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(GM.main.isCharIDFighting("pc")):
		return false
	if(RNG.randi_range(1, 100) > 15):
		return false

	var predID = _pickPredator()
	if(predID == ""):
		return false

	var predator = GlobalRegistry.getCharacter(predID)
	if(predator == null):
		return false

	GM.main.IS.spawnPawnIfNeeded(predID)
	predator.addEffect("VorePredatorBelly", [GM.pc.getName()])
	var pawn = GM.main.IS.getPawn(predID)
	if(pawn != null):
		pawn.setLocation(GM.pc.getLocation())

	GM.main.addMessage("You wake to suffocating heat and crushing pressure on all sides. This is no cell - you have woken up sealed inside " + predator.getName() + "'s belly!")
	runScene("VoreBellyRideScene", [predID])
	return true

func getPriority():
	return 25
