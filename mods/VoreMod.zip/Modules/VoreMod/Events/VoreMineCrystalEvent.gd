extends EventBase
const CHANCE = 8

func _init():
	id = "VoreMineCrystalEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.WorkingInMines)

func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(RNG.randi_range(1, 100) > CHANCE):
		return false
	var inv = GM.pc.getInventory()
	if(inv == null):
		return false
	var crystal = GlobalRegistry.createItem("VoreShinyCrystal")
	if(crystal == null):
		return false
	inv.addItem(crystal)
	addMessage("Your pick bites into something that rings instead of crumbling. Wedged in the rock is a [b]Shiny Crystal[/b], worth more than a month of your wages - and strictly contraband. You pocket it before anyone looks your way, but a pocket will never survive a search.")
	return false

func getPriority():
	return 5
