extends EventBase
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

const CD_FLAG = "VoreMod.VoreProbeCD"
const BASE_CHANCE = 12

func _init():
	id = "VoreObjectProbeEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom)
	es.addTrigger(self, Trigger.Waiting)

func _getCd() -> int:
	var v = getFlag(CD_FLAG, 0)
	if(typeof(v) == TYPE_INT || typeof(v) == TYPE_REAL):
		return int(v)
	return 0

func react(_triggerID, _args):
	if(GM.pc == null || GM.main == null):
		return false
	if(GM.main.isInDungeon()):
		return false
	if(GM.main.isCharIDFighting("pc")):
		return false
	var eff = VoreObjectHelper.getEffect(GM.pc)
	if(eff == null || eff.totalStored() <= 0):
		return false
	var populations = GM.pc.getLocationPopulation()
	if(!(WorldPopulation.Guards in populations)):
		return false
	var cd = _getCd()
	if(cd > 0):
		setFlag(CD_FLAG, cd - 1)
		return false
	var chance = BASE_CHANCE
	if(VoreObjectHelper.hasPerk(GM.pc, VoreObjectHelper.PERK_SMUGGLER)):
		chance = 5
	if(RNG.randi_range(1, 100) > chance):
		return false
	setFlag(CD_FLAG, RNG.randi_range(8, 16))
	runScene("VoreObjectProbeScene", [])
	return true

func getPriority():
	return 12
