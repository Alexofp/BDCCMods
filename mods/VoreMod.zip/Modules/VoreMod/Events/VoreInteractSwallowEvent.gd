extends EventBase


func _init():
	id = "VoreSwallowInteractEvent"

func registerTriggers(es):
	es.addTrigger(self, Trigger.DefeatedDynamicNPC)

func _methodCapacity(m: String) -> int:
	var h = GM.pc.getSkillsHolder()
	var c = 0
	if(m == "mouth"):
		if(h.hasPerk("VoreInitiate")):    c += 1
		if(h.hasPerk("VoreExpansionV2")): c += 1
		if(h.hasPerk("VoreExpansionV3")): c += 1
	elif(m == "breasts"):
		if(h.hasPerk("VoreBreastsInitiate")):    c += 1
		if(h.hasPerk("VoreBreastsExpansionV2")): c += 1
		if(h.hasPerk("VoreBreastsExpansionV3")): c += 1
	elif(m == "anus"):
		if(h.hasPerk("VoreAnusInitiate")):    c += 1
		if(h.hasPerk("VoreAnusExpansionV2")): c += 1
		if(h.hasPerk("VoreAnusExpansionV3")): c += 1
	return c

func _currentCount(m: String) -> int:
	if(!GM.pc.hasEffect("VoreSwallowedNPC")):
		return 0
	var eff = GM.pc.getEffect("VoreSwallowedNPC")
	var c = 0
	for mm in eff.swallowedMethods:
		if(mm == m):
			c += 1
	return c

func _methodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow whole (mouth)"
		"breasts": return "Absorb into breasts"
		"anus":    return "Absorb into rear"
	return "Swallow"

func run(_triggerID, _args):
	if(GM.pc == null || _args.size() <= 0):
		return
	var npcID = _args[0]
	if(npcID == null || npcID == "" || npcID == "pc"):
		return

	var character = GlobalRegistry.getCharacter(npcID)
	if(character == null || !character.isDynamicCharacter()):
		return

	var anyMethod = false
	for m in ["mouth", "breasts", "anus"]:
		if(_methodCapacity(m) > 0):
			anyMethod = true
			break
	if(!anyMethod):
		return

	for m in ["mouth", "breasts", "anus"]:
		var cap = _methodCapacity(m)
		if(cap <= 0):
			continue
		var cur = _currentCount(m)
		if(cur < cap):
			addButton(_methodLabel(m), "Swallow " + character.getName() + " whole. They vanish from the map and are slowly digested. (" + str(cur) + "/" + str(cap) + " " + m + " capacity used)", "vore_swallow", [npcID, m])
		else:
			addDisabledButton(_methodLabel(m), "Your " + m + " capacity is full (" + str(cur) + "/" + str(cap) + ").")

func onButton(_method, _args):
	if(_method != "vore_swallow"):
		return
	if(_args.size() < 2):
		return
	var npcID = _args[0]
	var m     = _args[1]

	var character = GlobalRegistry.getCharacter(npcID)
	if(character == null):
		return
	var preyName = character.getName()

	if(_currentCount(m) >= _methodCapacity(m)):
		addMessage("You can't fit anyone else in there right now.")
		return

	var like = 0.0
	var fh = character.getFetishHolder()
	if(fh != null):
		like = fh.getFetishValue("Vore")

	GM.pc.addEffect("VoreSwallowedNPC", [preyName, npcID, m])
	GM.pc.addSkillExperience("Vore", 20)

	if(GM.main != null && GM.main.IS.hasPawn(npcID)):
		GM.main.IS.deletePawn(npcID)

	var partWord = "stomach"
	if(m == "breasts"):
		partWord = "chest"
	elif(m == "anus"):
		partWord = "rear"

	var reaction = ""
	if(like >= 0.5):
		reaction = " They eagerly let you do it, shivering with delight as they slip into your " + partWord + "."
	elif(like >= 0.125):
		reaction = " They put up only a token protest, secretly thrilled to end up in your " + partWord + "."
	elif(like <= -0.5):
		reaction = " They thrash and beg in horror, but down into your " + partWord + " they go regardless."
	elif(like <= -0.125):
		reaction = " They squirm in discomfort as your " + partWord + " swallows them up."

	addMessage("You swallow " + preyName + " whole!" + reaction + " (+20 Vore XP)")

func getPriority():
	return 15
