extends EventBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	id = "VoreSwallowInteractEvent"
func registerTriggers(es):
	es.addTrigger(self, Trigger.DefeatedDynamicNPC)
func _methodCapacity(m: String) -> int:
	var h = GM.pc.getSkillsHolder()
	var c = 0
	if(m == "mouth"):
		if(h.hasPerk("VoreInitiate")):    c += 1
		if(h.hasPerk("VoreExpansionV2")): c += 1
		if(h.hasPerk("VoreExpansionV3")): c += 1
	elif(m == "breasts"):
		if(h.hasPerk("VoreBreastsInitiate")):    c += 1
		if(h.hasPerk("VoreBreastsExpansionV2")): c += 1
		if(h.hasPerk("VoreBreastsExpansionV3")): c += 1
	elif(m == "anus"):
		if(h.hasPerk("VoreAnusInitiate")):    c += 1
		if(h.hasPerk("VoreAnusExpansionV2")): c += 1
		if(h.hasPerk("VoreAnusExpansionV3")): c += 1
	elif(m == "cock"):
		if(h.hasPerk("VoreCockInitiate")):    c += 1
		if(h.hasPerk("VoreCockExpansionV2")): c += 1
		if(h.hasPerk("VoreCockExpansionV3")): c += 1
	elif(m == "vagina"):
		if(h.hasPerk("VoreVaginaInitiate")):    c += 1
		if(h.hasPerk("VoreVaginaExpansionV2")): c += 1
		if(h.hasPerk("VoreVaginaExpansionV3")): c += 1
	elif(m == "tail"):
		if(h.hasPerk("VoreTailInitiate")):    c += 1
		if(h.hasPerk("VoreTailExpansionV2")): c += 1
		if(h.hasPerk("VoreTailExpansionV3")): c += 1
	elif(m == "eye"):
		if(h.hasPerk("VoreEyeInitiate")):    c += 1
		if(h.hasPerk("VoreEyeExpansionV2")): c += 1
		if(h.hasPerk("VoreEyeExpansionV3")): c += 1
	elif(m == "ear"):
		if(h.hasPerk("VoreEarInitiate")):    c += 1
		if(h.hasPerk("VoreEarExpansionV2")): c += 1
		if(h.hasPerk("VoreEarExpansionV3")): c += 1
	return c
func _currentCount(m: String) -> int:
	return VoreSwallowed.countForMethod(GM.pc, m)
func _methodLabel(m: String) -> String:
	match m:
		"mouth":   return "Swallow whole (mouth)"
		"breasts": return "Absorb into breasts"
		"anus":    return "Absorb into rear"
		"cock":    return "Devour with cock"
		"vagina":  return "Take into womb"
		"tail":    return "Coil up in tail"
		"eye":     return "Absorb through eye"
		"ear":     return "Absorb through ear"
	return "Swallow"
func _getPills() -> Array:
	var result = []
	var inv = GM.pc.getInventory()
	if inv == null:
		return result
	for item in inv.getItems():
		if item.has_method("canUseInCombat") && item.canUseInCombat():
			result.append(item)
	return result
var _pickingPillForNPC: String = ""
func run(_triggerID, _args):
	if _pickingPillForNPC != "":
		_runPillPicker()
		return
	if(GM.pc == null || _args.size() <= 0):
		return
	var npcID = _args[0]
	if(npcID == null || npcID == "" || npcID == "pc"):
		return
	var character = GlobalRegistry.getCharacter(npcID)
	if(character == null || !character.isDynamicCharacter()):
		return
	var npcScale = 1.0
	if character.hasEffect("VoreSizeChange"):
		var scaleEff = character.getEffect("VoreSizeChange")
		if scaleEff != null:
			npcScale = scaleEff.targetScale
	else:
		npcScale = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
	for m in ["mouth", "breasts", "anus", "cock", "vagina", "tail", "eye", "ear"]:
		var cap = _methodCapacity(m)
		if(cap <= 0):
			continue
		var cur = _currentCount(m)
		if VoreSwallowed.SHRUNK_ONLY_METHODS.has(m):
			if npcScale > VoreSwallowed.SHRUNK_VORE_MAX_SCALE + 0.01:
				addDisabledButton(_methodLabel(m), "This method only works on prey shrunk to " + str(VoreSwallowed.SHRUNK_VORE_MAX_SCALE) + "x or smaller. (" + character.getName() + " is currently " + str(stepify(npcScale, 0.01)) + "x)")
				continue
		if(cur < cap):
			addButton(_methodLabel(m), "Swallow " + character.getName() + " whole. They vanish from the map and are slowly digested. (" + str(cur) + "/" + str(cap) + " " + m + " capacity used)", "vore_swallow", [npcID, m])
		else:
			addDisabledButton(_methodLabel(m), "Your " + m + " capacity is full (" + str(cur) + "/" + str(cap) + ").")
	var pills = _getPills()
	if pills.size() > 0:
		addButton(
			"Give item... (" + str(pills.size()) + " available)",
			"Choose an item from your inventory and force " + character.getName() + " to use it.",
			"open_pill_picker",
			[npcID]
		)
	else:
		addDisabledButton("Give item...", "You have no usable items in your inventory.")
	addButton(
		"Leash",
		"Clip a leash on " + character.getName() + " and lead them around the station. Release them anywhere you like.",
		"start_leash",
		[npcID]
	)
	var pickupScale = 1.0
	var pickupDuration = 0.0
	if character.hasEffect("VoreSizeChange"):
		var eff = character.getEffect("VoreSizeChange")
		if eff != null:
			pickupScale = eff.targetScale
			pickupDuration = float(eff.durationSeconds)
	else:
		pickupScale = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
	if pickupScale <= VoreBodyScaleHelper.PICKUP_MAX_SCALE:
		if !VoreBodyScaleHelper.isNPCPickedUp(npcID):
			addButton("Pick up", "Scoop " + character.getName() + " up and slip them into your pocket (" + str(stepify(pickupScale, 0.01)) + "x)", "pick_up_shrunk_npc", [npcID, pickupDuration])
		else:
			addDisabledButton("Pick up", character.getName() + " is already in your pocket.")
	else:
		if pickupScale < 1.0:
			addDisabledButton("Pick up", character.getName() + " is too large to pick up. They need to be " + str(VoreBodyScaleHelper.PICKUP_MAX_SCALE) + "x or smaller. (Currently " + str(stepify(pickupScale, 0.01)) + "x)")
func _runPillPicker():
	var character = GlobalRegistry.getCharacter(_pickingPillForNPC)
	var npcName = "them"
	if character != null && character.has_method("getName"):
		npcName = character.getName()
	addMessage("=== Choose an item to give to " + npcName + " ===")
	var pills = _getPills()
	if pills.size() == 0:
		addMessage("You have no usable items left.")
		_pickingPillForNPC = ""
		return
	for i in range(pills.size()):
		var pill = pills[i]
		var desc = pill.getDescription() if pill.has_method("getDescription") else ""
		addButton(pill.getVisibleName(), desc, "give_pill", [i])
	addButton("Cancel", "Go back without giving anything.", "cancel_picker", [])
func onButton(_method, _args):
	if(_method == "vore_swallow"):
		_doSwallow(_args)
	elif(_method == "open_pill_picker"):
		if(_args.size() >= 1):
			_pickingPillForNPC = str(_args[0])
	elif(_method == "start_leash"):
		if(_args.size() >= 1):
			var leashNpcID = str(_args[0])
			if(GM.main != null):
				GM.main.IS.stopInteractionsForPawnID(leashNpcID)
				GM.main.IS.stopInteractionsForPawnID("pc")
			runScene("VoreLeashWalkScene", [leashNpcID])
	elif(_method == "give_pill"):
		_doGivePill(_args)
		_pickingPillForNPC = ""
	elif(_method == "cancel_picker"):
		_pickingPillForNPC = ""
	elif(_method == "pick_up_shrunk_npc"):
		_doPickUpShrunkNPC(_args)
func _doSwallow(_args):
	if(_args.size() < 2):
		return
	var npcID = _args[0]
	var m     = _args[1]
	var character = GlobalRegistry.getCharacter(npcID)
	if(character == null):
		return
	var preyName = character.getName()
	if(_currentCount(m) >= _methodCapacity(m)):
		addMessage("You can't fit anyone else in there right now.")
		return
	var like = 0.0
	var fh = character.getFetishHolder()
	if(fh != null):
		like = fh.getFetishValue("Vore")
	GM.pc.addEffect(VoreSwallowed.effectIDForMethod(m), [preyName, npcID, m])
	GM.pc.addSkillExperience("Vore", 20)
	var preyScale = 1.0
	var preyShrinkDuration = 0.0
	if character.hasEffect("VoreSizeChange"):
		var scaleEff = character.getEffect("VoreSizeChange")
		if scaleEff != null:
			preyScale = scaleEff.targetScale
			preyShrinkDuration = float(scaleEff.durationSeconds)
	if preyScale < 1.0 and preyShrinkDuration > 0.0:
		GM.pc.addEffect("VoreSwallowedShrunk", [preyName, npcID, m, preyShrinkDuration])
	if(GM.main != null && GM.main.IS.hasPawn(npcID)):
		GM.main.IS.deletePawn(npcID)
	var partWord = "stomach"
	if(m == "breasts"):   partWord = "chest"
	elif(m == "anus"):    partWord = "rear"
	elif(m == "cock"):    partWord = "balls"
	elif(m == "vagina"):  partWord = "womb"
	elif(m == "tail"):    partWord = "tail"
	elif(m == "eye"):     partWord = "eye"
	elif(m == "ear"):     partWord = "ear canal"
	var reaction = ""
	if(like >= 0.5):
		reaction = " They eagerly let you do it, shivering with delight as they slip into your " + partWord + "."
	elif(like >= 0.125):
		reaction = " They put up only a token protest, secretly thrilled to end up in your " + partWord + "."
	elif(like <= -0.5):
		reaction = " They thrash and beg in horror, but down into your " + partWord + " they go regardless."
	elif(like <= -0.125):
		reaction = " They squirm in discomfort as your " + partWord + " swallows them up."
	addMessage("You swallow " + preyName + " whole!" + reaction + " (+20 Vore XP)")
func _doGivePill(_args):
	if(_args.size() < 1):
		return
	var pillIndex = int(_args[0])
	var character = GlobalRegistry.getCharacter(_pickingPillForNPC)
	if(character == null):
		addMessage("Couldn't find that character.")
		return
	var pills = _getPills()
	if(pillIndex < 0 || pillIndex >= pills.size()):
		addMessage("That item is no longer in your inventory.")
		return
	var pill = pills[pillIndex]
	var resultMsg = pill.useInCombat(GM.pc, character)
	if resultMsg == null || resultMsg == "":
		resultMsg = pill.getVisibleName() + " was used."
	addMessage("You force " + character.getName() + " to use " + pill.getVisibleName() + ". " + resultMsg)
func _doPickUpShrunkNPC(_args):
	if(_args.size() < 2):
		return
	var npcID = str(_args[0])
	var durationLeft = float(_args[1])
	var character = GlobalRegistry.getCharacter(npcID)
	if(character == null):
		addMessage("Character not found.")
		return
	var charName = character.getName() if character.has_method("getName") else "NPC"
	var currentScale = 1.0
	if character.hasEffect("VoreSizeChange"):
		var eff = character.getEffect("VoreSizeChange")
		if eff != null:
			currentScale = eff.targetScale
			if eff.durationSeconds > 0:
				durationLeft = float(eff.durationSeconds)
	else:
		currentScale = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
	if currentScale > VoreBodyScaleHelper.PICKUP_MAX_SCALE + 0.01:
		addMessage(charName + " is too large to pick up! They need to be " + str(VoreBodyScaleHelper.PICKUP_MAX_SCALE) + "x or smaller.")
		return
	if VoreBodyScaleHelper.isNPCPickedUp(npcID):
		addMessage(charName + " is already in your pocket!")
		return
	if(GM.main != null && GM.main.IS.hasPawn(npcID)):
		GM.main.IS.deletePawn(npcID)
	if character.hasEffect("VoreSizeChange"):
		character.removeEffect("VoreSizeChange")
	var voreMod = getModule("VoreMod")
	if voreMod != null:
		voreMod.pickUpShrunkNPC(npcID, durationLeft)
	addMessage("You carefully scoop up tiny " + charName + " and slip them into your pocket. (" + str(stepify(currentScale, 0.01)) + "x)")
	GM.main.endCurrentScene()
func getPriority():
	return 15