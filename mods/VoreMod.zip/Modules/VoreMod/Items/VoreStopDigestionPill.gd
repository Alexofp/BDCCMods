extends ItemBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
func _init():
	id = "VoreStopDigestionPill"
func getVisibleName():
	return "Anti-Digestion Pill"
func getDescription():
	return "A bitter pill that completely shuts down your digestive system for a day. Any prey you've swallowed will be kept perfectly preserved - undigested - until the next day, when digestion resumes (take another to keep pausing it)."
func canUseInCombat():
	return true
func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	var effects = VoreSwallowed.getEffects(_attacker)
	if(_attacker != null && effects.size() > 0):
		var resultText = ""
		for eff in effects:
			resultText = eff.pauseDigestion(1)
		return _attacker.getName() + " took the anti-digestion pill. " + resultText
	return _attacker.getName() + " took the anti-digestion pill, but there's no one inside them to preserve."
func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Take the pill to halt digestion for a day",
		},
	]
func getPrice():
	return 6
func canSell():
	return true
func canCombine():
	return true
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]
func getBuyAmount():
	return 5
func getItemCategory():
	return ItemCategory.Medical
