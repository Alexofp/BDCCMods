extends ItemBase
func _init():
	id = "VoreTotem"
func getVisibleName():
	return "Vore Totem"
func getDescription():
	return "A small carved totem humming with protective magic. Activate it to bind your essence to your current location. The next time you would be fully digested by a predator, the totem shatters and pulls you back to this spot instead of letting you die. Single use - activating it again re-binds it to your new location."
func canUseInCombat():
	return true
func useInCombat(_attacker, _receiver):
	if(_attacker == null):
		return "Nothing happens."
	var room = _attacker.getLocation()
	if(room == null || room == ""):
		return _attacker.getName() + " tries to activate the Vore Totem, but it can't latch onto anywhere here."
	removeXOrDestroy(1)
	if(_attacker.hasEffect("VoreTotemActive")):
		_attacker.removeEffect("VoreTotemActive")
	_attacker.addEffect("VoreTotemActive", [room])
	return _attacker.getName() + " presses the Vore Totem and feels its magic bind to this very spot. Should " + _attacker.getName() + " ever be fully digested, it will tear them free and pull them back here."
func getPossibleActions():
	return [
		{
			"name": "Activate",
			"scene": "UseItemLikeInCombatScene",
			"description": "Bind the totem to your current location as a vore-death safety net",
		},
	]
func getPrice():
	return 40
func canSell():
	return true
func canCombine():
	return true
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]
func getBuyAmount():
	return 2
func getItemCategory():
	return ItemCategory.Generic
