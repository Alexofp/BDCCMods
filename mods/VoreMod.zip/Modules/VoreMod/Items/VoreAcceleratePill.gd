extends ItemBase


func _init():
	id = "VoreAcceleratePill"

func getVisibleName():
	return "Digestion Accelerator Pill"

func getDescription():
	return "A scalding-hot pill that kicks your metabolism into overdrive. Instantly advances the digestion of everyone currently inside you by a full stage (one day's worth)."

func canUseInCombat():
	return true

func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	if(_attacker != null && _attacker.hasEffect("VoreSwallowedNPC")):
		var eff = _attacker.getEffect("VoreSwallowedNPC")
		return _attacker.getName() + " took the accelerator pill. " + eff.accelerateDigestion()
	return _attacker.getName() + " took the accelerator pill, but there's no one inside them to digest."

func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Take the pill to speed up digestion",
		},
	]

func getPrice():
	return 6

func canSell():
	return true

func canCombine():
	return true

func addsIntoxication():
	return 0.0

func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]

func getBuyAmount():
	return 5

func getItemCategory():
	return ItemCategory.Medical
