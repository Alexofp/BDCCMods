extends ItemBase
const VoreSwallowed = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
func _init():
	id = "VoreAcceleratePill"
func getVisibleName():
	return "Digestion Accelerator Pill"
func getDescription():
	return "A scalding-hot pill that kicks your metabolism into overdrive. Instantly advances the digestion of everyone currently inside you by a full stage (one day's worth)."
func canUseInCombat():
	return true
func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	if(_attacker != null && _attacker.hasEffect("VorePlayerDigesting")):
		var own = _attacker.getEffect("VorePlayerDigesting")
		var ownText = ""
		if(own != null):
			ownText = own.accelerateDigestion()
		return _attacker.getName() + " took the accelerator pill. " + ownText
	var effects = VoreSwallowed.getEffects(_attacker)
	if(_attacker != null && effects.size() > 0):
		var resultText = ""
		for eff in effects:
			resultText = eff.accelerateDigestion()
		return _attacker.getName() + " took the accelerator pill. " + resultText
	return _attacker.getName() + " took the accelerator pill, but there's no one inside them to digest."
func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Take the pill to speed up digestion",
		},
	]
func getPrice():
	return 6
func canSell():
	return true
func canCombine():
	return true
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]
func getBuyAmount():
	return 5
func getItemCategory():
	return ItemCategory.Medical
