extends ItemBase
var targetScale: float = 1.0
var durationSeconds: int = 3600
var pillDesc: String = ""
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
func _init():
	id = "VoreSizeChangePillProgrammed"
func getVisibleName():
	var scaleStr = str(stepify(targetScale, 0.01))
	if targetScale < 1.0:
		return "Shrink Pill (" + scaleStr + "x)"
	if targetScale > 1.0:
		return "Growth Pill (" + scaleStr + "x)"
	return "Reset Pill (1.0x)"
func getDescription():
	var scaleStr = str(stepify(targetScale, 0.01))
	var timeStr = _durText()
	var desc = "A pill programmed to set body scale to " + scaleStr + "x for " + timeStr + ". "
	if targetScale < 1.0:
		desc += "This one will make the consumer shrink."
	elif targetScale > 1.0:
		desc += "This one will make the consumer grow."
	else:
		desc += "This one will restore normal size."
	if durationSeconds < 0:
		desc += " This effect is permanent -- the consumer keeps this size until another size-change pill is used on them."
	else:
		desc += " After the duration expires, the consumer returns to their normal size."
	desc += " Can be used on yourself or given to someone else during intimate moments."
	if pillDesc != "":
		desc += "\n\n" + pillDesc
	return desc
func canUseInCombat():
	return true
func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	var target = _receiver if _receiver != null && _receiver != _attacker else _attacker
	if target != null:
		target.addEffect("VoreSizeChange", [targetScale, durationSeconds])
	var scaleStr = str(stepify(targetScale, 0.01))
	if targetScale < 1.0:
		return target.getName() + " shrinks to " + scaleStr + "x size!"
	elif targetScale > 1.0:
		return target.getName() + " grows to " + scaleStr + "x size!"
	else:
		return target.getName() + " returns to normal size."
func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "VoreSizeChangePillProgrammedScene",
			"description": "Swallow the pill",
		},
	]
func setTargetScale(newScale: float):
	targetScale = stepify(clamp(newScale, 0.1, 5.0), 0.01)
func setDurationSeconds(newDuration: int):
	durationSeconds = newDuration
	if durationSeconds < 0:
		durationSeconds = -1  
	elif durationSeconds < 60:
		durationSeconds = 60
func isPermanent() -> bool:
	return durationSeconds < 0
func _durText() -> String:
	if durationSeconds < 0:
		return "permanently (until changed by another pill)"
	return Util.getTimeStringHumanReadable(durationSeconds)
func setPillDesc(newDesc: String):
	pillDesc = newDesc
func getPrice():
	return 5
func canSell():
	return true
func canCombine():
	return false
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
		ItemTag.SexEngineDrug,
	]
func getBuyAmount():
	return 1
func getItemCategory():
	return ItemCategory.Medical
func getInventoryImage():
	if targetScale < 1.0:
		return "res://Images/Items/medical/bluepill.png"
	return "res://Images/Items/medical/redpill.png"
func getSexEngineInfo(_sexEngine, _domInfo, _subInfo):
	var scaleStr = str(stepify(targetScale, 0.01))
	var timeStr = _durText()
	var pillName = "size pill"
	var usedName = "a programmed size pill"
	var descText = ""
	if targetScale < 1.0:
		pillName = "shrink pill (" + scaleStr + "x)"
		usedName = "a shrink pill programmed to " + scaleStr + "x for " + timeStr
		descText = "Shrinks the consumer to " + scaleStr + "x for " + timeStr + "."
	elif targetScale > 1.0:
		pillName = "growth pill (" + scaleStr + "x)"
		usedName = "a growth pill programmed to " + scaleStr + "x for " + timeStr
		descText = "Grows the consumer to " + scaleStr + "x for " + timeStr + "."
	else:
		pillName = "reset size pill"
		usedName = "a pill that restores normal size for " + timeStr
		descText = "Restores the consumer to normal size."
	return {
		"name": pillName,
		"usedName": usedName,
		"desc": descText,
		"scoreOnSub": 0.3,
		"scoreOnSelf": 0.3,
		"scoreSubScore": 0.3,
		"canUseOnDom": true,
		"canUseOnSub": true,
		"maxUsesByNPC": 2,
	}
func useInSex(_receiver):
	if _receiver != null:
		_receiver.addEffect("VoreSizeChange", [targetScale, durationSeconds])
	var scaleStr = str(stepify(targetScale, 0.01))
	var text = "{RECEIVER.You} {RECEIVER.youVerb('feel')} the pill take effect. "
	if targetScale < 1.0:
		text += "{RECEIVER.You} {RECEIVER.youVerb('shrink')} to " + scaleStr + "x size!"
	elif targetScale > 1.0:
		text += "{RECEIVER.You} {RECEIVER.youVerb('grow')} to " + scaleStr + "x size!"
	else:
		text += "{RECEIVER.You} {RECEIVER.youVerb('return')} to normal size."
	text = text.replace("RECEIVER", _receiver.getID())
	return {
		"text": text,
	}
func saveData():
	var data = .saveData()
	data["targetScale"] = targetScale
	data["durationSeconds"] = durationSeconds
	data["pillDesc"] = pillDesc
	return data
func loadData(data):
	.loadData(data)
	targetScale = SAVE.loadVar(data, "targetScale", 1.0)
	durationSeconds = SAVE.loadVar(data, "durationSeconds", 3600)
	pillDesc = SAVE.loadVar(data, "pillDesc", "")