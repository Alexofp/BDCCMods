extends ItemBase
var npcID: String = ""
var duration: float = 0.0
var plugMode: String = ""
func _init():
	id = "VoreShrunkNPCItem"
func getVisibleName():
	var charName = "Someone"
	var npcChar = GlobalRegistry.getCharacter(npcID)
	if npcChar != null and npcChar.has_method("getName"):
		charName = npcChar.getName()
	var base = "Pocket " + charName
	if plugMode != "":
		base += " (plugged in)"
	elif duration > 0:
		var scaleVal = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
		var scaleStr = str(stepify(scaleVal, 0.01))
		base += " (" + scaleStr + "x)"
	return base
func getDescription():
	var charName = "NPC"
	var npcChar = GlobalRegistry.getCharacter(npcID)
	if npcChar != null and npcChar.has_method("getName"):
		charName = npcChar.getName()
	var scaleVal = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
	var scaleStr = str(stepify(scaleVal, 0.01))
	var timeStr = _formatDuration(duration)
	var desc = "A tiny " + charName + " sits curled up in your pocket at " + scaleStr + "x their normal size.\n\n"
	if plugMode != "":
		var holeWord = "pussy" if plugMode == "vagina" else "anus"
		desc += "[b]They are currently plugged inside your " + holeWord + "![/b] You can pull them out at any time.\n\n"
		desc += "[color=#ff5555]WARNING:[/color] If the shrink effect wears off while they are still inside you, they will grow back to full size and [b]burst out of you, killing you![/b]"
		return desc
	if duration > 0:
		desc += "The shrink effect will wear off in " + timeStr + ", returning them to normal size automatically."
	else:
		desc += "The shrink effect has no expiry -- they will stay small until manually released or given another pill."
	return desc
func _formatDuration(secs: float) -> String:
	if secs <= 0:
		return "0s"
	var totalSecs = int(secs)
	var hours = totalSecs / 3600
	var minutes = (totalSecs % 3600) / 60
	var seconds = totalSecs % 60
	if hours > 0:
		return str(hours) + "h " + str(minutes) + "m " + str(seconds) + "s"
	elif minutes > 0:
		return str(minutes) + "m " + str(seconds) + "s"
	else:
		return str(seconds) + "s"
func getPossibleActions():
	if plugMode != "":
		return [
			{
				"name": "Pull out",
				"scene": "VoreShrunkNpcPlugScene",
				"description": "Pull the tiny character out of your " + ("pussy" if plugMode == "vagina" else "anus") + ".",
			},
		]
	var actions = [
		{
			"name": "Swallow",
			"scene": "VoreShrunkNPCSwallowScene",
			"description": "Choose a vore method and swallow this tiny character directly from your pocket.",
		},
		{
			"name": "Release",
			"scene": "VoreShrunkNPCReleaseScene",
			"description": "Take the tiny character out of your pocket and set them down in this room.",
		},
	]
	var scaleVal = VoreBodyScaleHelper.getNPCBodyScaleByID(npcID)
	if scaleVal <= VoreBodyScaleHelper.PICKUP_MAX_SCALE:
		var npcDisplayName = _npcDisplayName()
		actions.append({
			"name": "Use as dildo",
			"scene": "TinyNpcDildoScene",
			"description": "Use tiny " + npcDisplayName + " as a living dildo.",
		})
		actions.append({
			"name": "Use as buttplug",
			"scene": "VoreShrunkNpcButtplugScene",
			"description": "Push tiny " + npcDisplayName + " into your butt and wear them as a living buttplug.",
		})
		actions.append({
			"name": "Use as vaginal plug",
			"scene": "VoreShrunkNpcVagplugScene",
			"description": "Push tiny " + npcDisplayName + " into your pussy and wear them as a living vaginal plug.",
		})
	return actions
func _npcDisplayName() -> String:
	var npcChar = GlobalRegistry.getCharacter(npcID)
	if npcChar != null and npcChar.has_method("getName"):
		return npcChar.getName()
	return "NPC"
func canUseInCombat():
	return plugMode == ""
func useInCombat(_attacker, _receiver):
	var target = _receiver if (_receiver != null && _receiver != _attacker) else _attacker
	if target == null:
		return ""
	var mod = GlobalRegistry.getModule("VoreMod")
	var preyChar = GlobalRegistry.getCharacter(npcID)
	var preyName = "the tiny one"
	if preyChar != null && preyChar.has_method("getName"):
		preyName = preyChar.getName()
	if !target.isPlayer():
		var predName = target.getName() if target.has_method("getName") else "they"
		if mod == null || !mod.has_method("giveShrunkNPCAsPill"):
			return ""
		mod.giveShrunkNPCAsPill(self, target)
		var note = ""
		if duration > 0:
			note = " If the shrink wears off while " + preyName + " is still inside, " + predName + " won't survive it!"
		else:
			note = " " + preyName + " is shrunk permanently, so they'll just stay tucked away inside " + predName + " harmlessly."
		return predName + " gulps the tiny " + preyName + " down whole!" + note
	var shrinkDur = float(duration)
	if mod != null && mod.has_method("swallowNPCFromItem"):
		mod.swallowNPCFromItem(self)
	GM.pc.addEffect("VoreSwallowedMouth", [preyName, npcID, "mouth"])
	GM.pc.addSkillExperience("Vore", 20)
	if shrinkDur > 0.0:
		GM.pc.addEffect("VoreSwallowedShrunk", [preyName, npcID, "mouth", shrinkDur])
	return "You swallow the tiny " + preyName + " whole!"
func canSell():
	return false
func canCombine():
	return false
func getPrice():
	return 0
func getItemCategory():
	return ItemCategory.Medical
func getInventoryImage():
	return "res://Images/Items/medical/bluepill.png"
func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["duration"] = duration
	data["plugMode"] = plugMode
	return data
func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	duration = SAVE.loadVar(data, "duration", 0.0)
	plugMode = SAVE.loadVar(data, "plugMode", "")
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
