extends ItemBase
func _init():
	id = "VoreSizeChangePill"
func getVisibleName():
	return "Size-Change Pill"
func getDescription():
	return "A blank size-altering pill. Use it to open the configuration screen where you set a target scale and duration, then either swallow it immediately or program it for later use. The original pill is consumed when programming."
func canUseInCombat():
	return false
func getPossibleActions():
	return [
		{
			"name": "Configure & Use",
			"scene": "VoreSizeChangePillScene",
			"description": "Set target scale and duration, then swallow or program the pill",
		},
	]
func getPrice():
	return 8
func canSell():
	return true
func canCombine():
	return true
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]
func getBuyAmount():
	return 5
func getItemCategory():
	return ItemCategory.Medical
func getInventoryImage():
	return "res://Images/Items/medical/redpill.png"