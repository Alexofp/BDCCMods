extends ItemBase
func _init():
	id = "BodyScaleItem"
func getVisibleName():
	return "Size Adjuster"
func getDescription():
	return "A strange device found in the lab. Allows you to manually adjust your body size.\n1.0 is normal size. Lower values shrink you, higher values make you grow."
func getPossibleActions():
	return [
		{
			"name": "Adjust Size",
			"scene": "BodyScaleItemScene",
			"description": "Adjust your body size.",
		},
	]
func canUseInCombat():
	return false
func canSell():
	return false
func canCombine():
	return false
func getItemCategory():
	return ItemCategory.Medical
func getInventoryImage():
	return "res://Images/Items/medical/redpill.png"
