extends ItemBase
const VoreFusionHelper = preload("res://Modules/VoreMod/VoreFusionHelper.gd")
func _init():
	id = "VoreUndoFusionPill"
func getVisibleName():
	return "Defusion Pill"
func getDescription():
	return "A vial of hungry little nanites programmed to untangle a fusion. Taking it strips away everything the last NPC you fused with added to you - their perks, skills, stats, body parts and coloration - and returns you to exactly who you were before that fusion. Only undoes your most recent fusion."
func canUseInCombat():
	return true
func useInCombat(_attacker, _receiver):
	if(_attacker == null || !_attacker.isPlayer()):
		var whoName = "They"
		if(_attacker != null && _attacker.has_method("getName")):
			whoName = _attacker.getName()
		return whoName + " tried the defusion pill, but nothing happened - it only works on the one who fused."
	if(VoreFusionHelper.getSnapshotCount() <= 0):
		return "You take the defusion pill, but nothing happens - there is no fusion to undo."
	removeXOrDestroy(1)
	var summary = VoreFusionHelper.undoLastFusion(_attacker)
	if(summary["ok"]):
		var text = "You take the defusion pill. The nanites get to work, unraveling " + str(summary["npcName"]) + "'s influence on your body - "
		if(int(summary["perksRemoved"]) > 0):
			text += str(summary["perksRemoved"]) + " perk(s) and "
		if(int(summary["skillsRemoved"]) > 0):
			text += str(summary["skillsRemoved"]) + " skill(s) fade away, "
		text += "and your body settles back into the shape it had before the fusion. Your level returns to " + str(summary["level"]) + "."
		return text
	return "You take the defusion pill, but your body simply digests it - the fusion is already gone."
func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Take the pill to undo your most recent fusion",
		},
	]
func getPrice():
	return 25
func canSell():
	return true
func canCombine():
	return true
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]
func getBuyAmount():
	return 1
func getItemCategory():
	return ItemCategory.Medical
func getInventoryImage():
	return "res://Images/Items/medical/bluepill.png"
