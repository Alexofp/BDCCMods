extends ItemBase
const VoreObjectHelper = preload("res://Modules/VoreMod/ObjectVore/VoreObjectHelper.gd")

func _init():
	id = "VoreAbsorptionChest"

func getVisibleName():
	return "Absorption Vessel"

func getVisibleDescription():
	var desc = "[color=999999]A strange multi-chambered pouch integrated into your being. Items absorbed through different vore methods are stored in separate compartments:\n\n"
	desc += "Stomach (Mouth) • Rear (Anus) • Womb (Vagina)\nCock • Breasts • Tail\n\nEach compartment operates independently, allowing safe, organized storage.[/color]"
	return desc

func getPicture():
	return "res://Images/Items/container.png"

func isImportant():
	return true

func canCombine():
	return false

func getExtraUseButtons(_character):
	var result = []
	var pc = _character
	
	if pc == null:
		return result
	
	if !VoreObjectHelper.isUnlocked(pc):
		result.append({
			"name": "Storage compartments",
			"description": "You don't have the Smuggler's Gullet perk yet.",
		})
		return result
	
	var eff = VoreObjectHelper.getEffect(pc)
	if eff == null:
		result.append({
			"name": "Storage compartments (empty)",
			"description": "No items are currently absorbed.",
		})
		return result
	
	var totalStored = eff.totalStored()
	if totalStored <= 0:
		result.append({
			"name": "Storage compartments (empty)",
			"description": "No items are currently absorbed.",
		})
		return result
	
	var detailText = ""
	for method in VoreObjectHelper.METHODS:
		var count = eff.countForMethod(method)
		var cap = VoreObjectHelper.capacity(pc, method)
		if cap <= 0:
			continue
		detailText += "\n[b]" + VoreObjectHelper.partWord(method).capitalize() + ":[/b] " + str(count) + "/" + str(cap) + " items"
		var entries = eff.getEntriesForMethod(method)
		if entries.size() > 0:
			var names = []
			for entry in entries:
				names.append(entry["name"])
			detailText += " - " + Util.join(names, ", ")
	
	result.append({
		"name": "Storage compartments (" + str(totalStored) + " items)",
		"scene": "VoreObjectStorageScene",
		"description": "View and manage your separate storage compartments:" + detailText,
	})
	
	return result

func getSceneOnUse():
	return "VoreObjectStorageScene"

func isConsumable():
	return false

func canBeDropped():
	return false
