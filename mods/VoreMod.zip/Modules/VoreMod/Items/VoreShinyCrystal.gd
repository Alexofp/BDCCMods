extends ItemBase
func _init():
	id = "VoreShinyCrystal"

func getVisibleName():
	return "Shiny Crystal"

func getDescription():
	return "A thumb-sized crystal that catches the light in colours this station has no business containing. Prospectors say a single one is worth more than a month of mining wages.\n\nOf course, taking one out of the mines is theft, which makes it contraband. You will need a hiding place the guards cannot pat down."

func getPrice():
	return 220

func canSell():
	return true

func canCombine():
	return true

func getItemCategory():
	return ItemCategory.Generic

func getTags():
	return [
		ItemTag.Illegal,
	]

func addsIntoxication():
	return 0.0
