extends ItemBase
const LURE_DURATION = 4 * 60 * 60
func _init():
	id = "VoreLurePill"
func getVisibleName():
	return "Ambrosia Pill"
func getDescription():
	return "An unmarked pill that rewrites your scent for a few hours: sweet, warm and maddeningly appetizing. Predators around the station will offer to take you in far more often -- and a lot of them will not stop to ask. Perfect if you would rather not spend an hour begging someone to be unwilling about it."
func canUseInCombat():
	return true
func useInCombat(_attacker, _receiver):
	removeXOrDestroy(1)
	var target = _receiver
	if(target == null || target == _attacker):
		target = _attacker
	if(target != null):
		target.addEffect("VoreLureScent", [LURE_DURATION])
		return target.getName() + " suddenly smells absolutely delicious..."
	return "Nothing happens."
func getPossibleActions():
	return [
		{
			"name": "Consume",
			"scene": "UseItemLikeInCombatScene",
			"description": "Swallow the pill and start smelling like a meal",
		},
	]
func getPrice():
	return 10
func canSell():
	return true
func canCombine():
	return true
func addsIntoxication():
	return 0.0
func getTags():
	return [
		ItemTag.SoldByMedicalVendomat,
	]
func getBuyAmount():
	return 3
func getItemCategory():
	return ItemCategory.Medical
func getInventoryImage():
	return "res://Images/Items/medical/redpill.png"
