extends ItemBase
func _init():
	id = "RoomDebuggerItem"
func getName() -> String:
	return "Room Debugger"
func getVisibleName() -> String:
	return "Room Debugger"
func getDescription() -> String:
	return "A debug tool that shows info about the current room. Use this to find room IDs and coordinates for modding. [VoreMod Debug]"
func getIcon() -> String:
	return "res://Images/Items/generic/chip.png"
func canUse() -> bool:
	return true
func useInCombat(_char, _enemy):
	return "Not usable in combat."
func use(_char):
	if GM.world == null or GM.pc == null:
		return "World not loaded."
	var roomID = GM.pc.getLocation()
	var CellRaidRoomInfo = load("res://Modules/VoreMod/CellRaidRoomInfo.gd")
	var info = {}
	if CellRaidRoomInfo != null:
		info = CellRaidRoomInfo.getRoomInfo(roomID)
	else:
		info["roomID"] = roomID
		var room = GM.world.getRoomByID(roomID)
		if room != null:
			info["roomName"] = room.getName()
			info["description"] = room.getDescription()
			info["cell"] = str(room.getCell())
			info["floorID"] = room.getFloorID()
	var lines = []
	lines.append("=== ROOM DEBUG INFO ===")
	for key in info:
		lines.append(str(key) + ": " + str(info[key]))
	lines.append("")
	lines.append("=== ALL NEARBY ROOMS ===")
	var connected = GM.world.getConnectedRoomsNear(roomID, 3)
	for nearRoomID in connected:
		var nearInfo = {}
		if CellRaidRoomInfo != null:
			nearInfo = CellRaidRoomInfo.getRoomInfo(nearRoomID)
		else:
			var nearRoom = GM.world.getRoomByID(nearRoomID)
			if nearRoom != null:
				nearInfo["roomName"] = nearRoom.getName()
				nearInfo["cell"] = str(nearRoom.getCell())
		lines.append(nearRoomID + " | " + str(nearInfo.get("roomName", "?")) + " | cell=" + str(nearInfo.get("cell", "?")) + " | block=" + str(nearInfo.get("block", "none")))
	var message = "\n".join(lines)
	Log.print(message)
	GM.main.addMessage("Room info printed to console (Godot output). Location: " + roomID + " | Cell: " + str(info.get("cell", "?")) + " | Floor: " + str(info.get("floorID", "?")))
	for key in info:
		GM.main.addMessage("  " + str(key) + ": " + str(info[key]))
	return "Room debug info printed."