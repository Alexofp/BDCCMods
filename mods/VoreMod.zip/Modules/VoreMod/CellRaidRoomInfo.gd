extends Reference
const BLOCKS = {
	"orange": {
		"name": "General-security cellblock",
		"hubRoom": "cellblock_orange_nearcell",
		"cells": [
			"cellblock_orange_playercell",
		],
		"inmateTypeValue": 0,
		"colorName": "orange",
	},
	"lilac": {
		"name": "Lilac cellblock",
		"hubRoom": "cellblock_lilac_nearcell",
		"cells": [
			"cellblock_pink_playercell",
		],
		"inmateTypeValue": 2,
		"colorName": "lilac",
	},
	"red": {
		"name": "High-security cellblock",
		"hubRoom": "cellblock_red_nearcell",
		"cells": [
			"cellblock_red_playercell",
		],
		"inmateTypeValue": 1,
		"colorName": "red",
	},
}
const RAID_ROOMS = [
	"cellblock_orange_nearcell",
	"cellblock_lilac_nearcell",
	"cellblock_red_nearcell",
]
static func getInmateTypeForBlock(blockID: String):
	if !BLOCKS.has(blockID):
		return null
	var val = BLOCKS[blockID]["inmateTypeValue"]
	return val
static func getBlocksForRoom(roomID: String) -> Array:
	var result = []
	for blockID in BLOCKS:
		var block = BLOCKS[blockID]
		if block["hubRoom"] == roomID:
			result.append(blockID)
			return result
		if roomID in block["cells"]:
			result.append(blockID)
			return result
	return result
static func getInmatesForBlock(blockID: String) -> Array:
	if !BLOCKS.has(blockID):
		return []
	var block = BLOCKS[blockID]
	var wantedType = block["inmateTypeValue"]
	var result = []
	if GM.main == null:
		return result
	for charID in GM.main.getDynamicCharacters():
		var character = GM.main.getDynamicCharacters()[charID]
		if character == null or !character.isInmate():
			continue
		if character.getInmateType() != wantedType:
			continue
		if character.isSlaveToPlayer():
			continue
		var name = character.getName()
		var loc = ""
		if GM.main.IS.hasPawn(charID):
			loc = GM.main.IS.getPawn(charID).getLocation()
		result.append({
			"id": charID,
			"name": name,
			"location": loc,
		})
	return result
static func generateCellListForBlock(blockID: String) -> Array:
	var inmates = getInmatesForBlock(blockID)
	var result = []
	var cellNumber = 1
	for entry in inmates:
		result.append({
			"cellLabel": "Cell " + str(cellNumber),
			"npcID": entry["id"],
			"npcName": entry["name"],
			"npcLocation": entry["location"],
		})
		cellNumber += 1
	var emptyCount = RNG.randi_range(2, 5)
	for i in range(emptyCount):
		result.append({
			"cellLabel": "Cell " + str(cellNumber),
			"npcID": "",
			"npcName": "",
			"npcLocation": "",
		})
		cellNumber += 1
	_shuffleArray(result)
	return result
static func _shuffleArray(arr: Array):
	for i in range(arr.size() - 1, 0, -1):
		var j = RNG.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp
static func getBlockName(blockID: String) -> String:
	if BLOCKS.has(blockID):
		return BLOCKS[blockID]["name"]
	return "Unknown block"
static func shouldShowButton(roomID: String) -> bool:
	if !(roomID in RAID_ROOMS):
		return false
	return true
static func getRoomInfo(roomID: String) -> Dictionary:
	var result = {}
	if GM.world == null:
		result["error"] = "World not loaded"
		return result
	var room = GM.world.getRoomByID(roomID)
	if room == null:
		result["error"] = "Room not found: " + roomID
		return result
	result["roomID"] = roomID
	result["roomName"] = room.getName()
	result["description"] = room.getDescription()
	result["cell"] = str(room.getCell())
	result["floorID"] = room.getFloorID()
	result["canWest"] = room.canWest
	result["canEast"] = room.canEast
	result["canNorth"] = room.canNorth
	result["canSouth"] = room.canSouth
	result["isOfflimits"] = room.isOfflimitsForInmates()
	for blockID in BLOCKS:
		var block = BLOCKS[blockID]
		if block["hubRoom"] == roomID or roomID in block["cells"]:
			result["block"] = blockID
	return result
