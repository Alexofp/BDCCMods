extends BaseStageScene3D
onready var animationTree  = $AnimationTree
onready var animationTree2 = $AnimationTree2
onready var doll           = $Doll3D
onready var npcDoll        = $NPCDoll3D
onready var dildo          = $HorsecockDildo
func _init():
	id = "TinyNpcDildoSex"
func _ready():
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer())
	animationTree.active = true
	animationTree2.active = true
	_hideDildoMesh()
func _hideDildoMesh():
	_hideMeshesRecursive(dildo)
func _hideMeshesRecursive(node):
	for c in node.get_children():
		if c is MeshInstance:
			c.visible = false
		_hideMeshesRecursive(c)
func updateSubAnims():
	if doll.getArmsCuffed():
		animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree["parameters/CuffsBlend/blend_amount"] = 0.0
func playAnimation(animID, _args = {}):
	var firstDoll = "pc"
	if _args.has("pc"):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)
	var npcID = ""
	if _args.has("npc"):
		npcID = _args["npc"]
	if npcID != "" and npcDoll.getCharacterID() != npcID:
		npcDoll.prepareCharacter(npcID)
	if _args.has("bodyState"):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	npcDoll.applyBodyState({naked = true})
	var npcScale = 0.4
	if _args.has("npcScale"):
		npcScale = clamp(float(_args["npcScale"]), 0.1, 0.5)
	npcDoll.set_scale(Vector3(npcScale, npcScale, npcScale))
	var isPussy = true
	if _args.has("isPussy"):
		isPussy = _args["isPussy"]
	_placeNpc(isPussy)
	_applyNpcPose(npcScale)
	updateSubAnims()
	if _args.has("pcCum") and _args["pcCum"]:
		startCumPenis(doll)
	var sm  = animationTree ["parameters/StateMachine/playback"]
	var sm2 = animationTree2["parameters/StateMachine/playback"]
	if animID == "tease":
		sm.travel("HorsecockTease-loop")
		sm2.travel("TheHorseCockTease-loop")
	if animID == "inside":
		sm.travel("HorsecockInside-loop")
		sm2.travel("TheHorseCockInside-loop")
	if animID == "sex":
		sm.travel("HorsecockRide-loop")
		sm2.travel("TheHorseCockRide-loop")
	if animID == "fast":
		sm.travel("HorsecockRideFast-loop")
		sm2.travel("TheHorseCockRideFast-loop")
func _placeNpc(isPussy = true):
	npcDoll.global_transform.origin = dildo.global_transform.origin
	npcDoll.translation.z -= 0.10
	npcDoll.translation.y -= 0.05
	if not isPussy:
		npcDoll.translation.x += 0.32
func _applyNpcPose(npcScale):
	yield(get_tree(), "idle_frame")
	if npcScale >= 0.3:
		npcDoll.playAnimation("Kneeling-loop")
	else:
		npcDoll.playAnimation("Standing-loop")
func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if _args.has("pc"):
		firstDoll = _args["pc"]
	if doll.getCharacterID() != firstDoll:
		return false
	return true
func getSupportedStates():
	return ["tease", "inside", "sex", "fast"]
func getVarNpcs():
	return ["pc", "npc"]
