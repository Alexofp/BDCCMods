extends PawnInteractionBase

const VoreSwallowedGA = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")

var foundIllegalItems = false
var throwOutLoc = ""
var guardSurrender = false

func _init():
	id = "CaughtOffLimits"

func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("guard", _pawns["guard"])
	doInvolvePawn("inmate", _pawns["inmate"])
	setState("", "inmate")

func shouldRunOnMeet(_pawn1, _pawn2, _pawn2Moved:bool):
	if(!_pawn1.canBeInterrupted() || !_pawn2.canBeInterrupted()):
		return [false]
		
	if(_pawn2.isStaff() && _pawn1.isInmate()):
		var pawnTemp = _pawn1
		_pawn1 = _pawn2
		_pawn2 = pawnTemp
	
	if(_pawn1.isStaff() && _pawn2.isInmate()):
		var pawnLoc = _pawn2.getLocation()
		var pawnRoom = GM.world.getRoomByID(pawnLoc)
		
		var isBadLoc = pawnRoom.isLocToCatchOfflimits()
		
		if(isBadLoc):
			return [true, {guard=_pawn1.charID, inmate=_pawn2.charID}, {}]

	return [false]

func getActivityIconForRole(_role:String):
	return RoomStuff.PawnActivity.Chat

func init_text():
	saynn("{guard.name} notices {inmate.name} in an off-limits area!")
	sayLine("guard", "GuardCaughtOffLimits", {guard="guard", inmate="inmate"})

	addAction("fight", "Fight!", "Protect yourself!", "fight", 1.0, 60, {})
	addAction("surrender", "Surrender", "Maybe they won't be mean", "surrender", 1.0, 60, {})

func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "fight"):
		setState("about_to_fight", "guard")
	if(_id == "surrender"):
		setState("surrendered", "guard")


func about_to_fight_text():
	saynn("{inmate.name} prepares for a fight.")
	sayLine("guard", "GuardCaughtOffLimitsFight", {guard="guard", inmate="inmate"})

	addAction("fight", "Fight", "Begin the fight", "fight", 1.0, 600, {start_fight=["inmate", "guard"],})
	addAction("surrender", "Surrender", "You changed your mind", "surrender", 1.0, 30, {})

func about_to_fight_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "fight"):
		var fightResult = getFightResult(_args)
		
		if(fightResult["won"]):
			setState("inmate_won", "inmate")
			sendSocialEvent("inmate", "guard", SocialEventType.LostFight)
		else:
			setState("guard_won", "guard")
			sendSocialEvent("guard", "inmate", SocialEventType.LostFight)
	if(_id == "surrender"):
		setState("inmate_won", "inmate")
		guardSurrender = true


func surrendered_text():
	saynn("{inmate.name} raises {inmate.his} hands and gives up.")
	sayLine("guard", "GuardInmateSurrender", {guard="guard", inmate="inmate"})
	saynn("{guard.name} approaches {inmate.you}.")

	addAction("punish", "Punish", "They gotta serve a punishment!", "punishMean", 1.0, 60, {})
	addAction("frisk", "Frisk", "Go easy on them and just frisk them", "punish", 1.0, 30, {})
	_voreModAddDevourChoice("guard", "inmate", "punishMean")

func surrendered_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "vore_loser"):
		_voreModStartDevour("guard")
		return
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("guard"), target=getRoleID("inmate")}, {voreModDevourOffered = _voreModDevourWasOffered("guard", "inmate")})
	if(_id == "frisk"):
		if(getRolePawn("guard").isGuard()):
			setState("about_to_frisk", "inmate")
		else:
			startEscortOut()


func inmate_won_text():
	if(!guardSurrender):
		saynn("{guard.name} hits the floor. {inmate.name} won!")
		sayLine("guard", "FightLostGeneric", {winner="inmate", loser="guard"})
	else:
		saynn("{guard.name} changes {guard.his} mind at the last second and decides to surrender!")

	addAction("leave", "Leave", "Just leave while you can", "justleave", 1.0, 30, {})
	addAction("punish", "Punish", "Find a way to punish them", "punishMean", 1.0, 30, {})

	addDefeatButtons("inmate", "guard")

func inmate_won_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		setState("about_to_leave", "inmate")
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("inmate"), target=getRoleID("guard")})


func about_to_leave_text():
	saynn("{inmate.name} decides to just leave while {inmate.he} still can.")

	addAction("leave", "Continue", "See what happens next.", "default", 1.0, 30, {})

func about_to_leave_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		makeRoleExhausted("guard")
		stopMe()


func guard_won_text():
	saynn("{inmate.name} hits the floor. {guard.name} won!")
	sayLine("guard", "FightWonGeneric", {winner="guard", loser="inmate"})

	addAction("punish", "Punish", "They gotta serve a punishment!", "punishMean", 1.0, 60, {})
	addAction("frisk", "Frisk", "Search them and let them go", "punish", 1.0, 30, {})
	_voreModAddDevourChoice("guard", "inmate", "punishMean")

	addDefeatButtons("guard", "inmate")

func guard_won_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "vore_loser"):
		_voreModStartDevour("guard")
		return
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("guard"), target=getRoleID("inmate")}, {voreModDevourOffered = _voreModDevourWasOffered("guard", "inmate")})
	if(_id == "frisk"):
		if(getRolePawn("guard").isGuard()):
			setState("about_to_frisk", "inmate")
		else:
			startEscortOut()


func about_to_frisk_text():
	saynn("{guard.name} is about to frisk {inmate.name}.")
	sayLine("guard", "GuardFrisk", {guard="guard", inmate="inmate"})

	addAction("frisk", "Stay still", "Stay still and let them frisk you", "default", 1.0, 120, {})
	addAction("resist", "Resist", "Try to avoid being frisked", "resist", 1.0, 120, {})

func about_to_frisk_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "frisk"):
		var theChar = getRolePawn("inmate").getChar()
		foundIllegalItems = false
		
		if(theChar.isPlayer()):
			if(theChar.hasIllegalItems()):
				theChar.addCredits(-5)
				addMessage("5 credits were taken from you")
				foundIllegalItems = true
				theChar.getInventory().removeItemsList(theChar.getInventory().getItemsWithTag(ItemTag.Illegal))
				theChar.getInventory().removeEquippedItemsList(theChar.getInventory().getEquippedItemsWithTag(ItemTag.Illegal))
		else:
			foundIllegalItems = RNG.chance(50)
		setState("frisked", "guard")
	if(_id == "resist"):
		if(doDexterityCheck("inmate", "guard")):
			foundIllegalItems = false
			setState("frisked", "guard")
			if(getRolePawn("inmate").isPlayer()):
				addMessage("You managed to avoid the search!")
		else:
			setState("frisk_failed_resist", "guard")


func frisked_text():
	if(foundIllegalItems):
		saynn("{guard.name} takes away all contraband from {inmate.name} and also 5 credits on top!")
		sayLine("guard", "GuardFriskFound", {guard="guard", inmate="inmate"})
	else:
		saynn("{guard.name} doesn't find any contraband.")
		sayLine("guard", "GuardFriskNoFound", {guard="guard", inmate="inmate"})

	addAction("escort_out", "Escort out", "Time to make them go", "default", 1.0, 30, {})

func frisked_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "escort_out"):
		startEscortOut()


func escorting_out_text():
	saynn("{guard.name} is escorting {inmate.name} out of the off-limits zone.")
	if(RNG.chance(20)):
		sayLine("guard", "GuardKeepMoving", {guard="guard", inmate="inmate"})

	addAction("escort_out", "Escort out", "Go to the spot", "default", 1.0, 60, {})

func escorting_out_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "escort_out"):
		goTowards(throwOutLoc)
		if(getLocation() == throwOutLoc):
			setState("escorted_out", "guard")


func escorted_out_text():
	saynn("{guard.name} shoves {inmate.name} away.")
	sayLine("guard", "GuardGoAway", {guard="guard", inmate="inmate"})

	addAction("leave", "Leave", "Time to go", "default", 1.0, 30, {})

func escorted_out_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()


func frisk_failed_resist_text():
	saynn("{inmate.name} manages to avoid getting searched!")
	sayLine("guard", "GuardFriskFailResist", {guard="guard", inmate="inmate"})
	saynn("Looks like the guard is not happy.")

	addAction("punish", "Punish", "Punish them!", "default", 1.0, 60, {})

func frisk_failed_resist_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("guard"), target=getRoleID("inmate")})


func getAnimData() -> Array:
	if(getCurrentAction() == "fight"):
		return [StageScene.Duo, "shove", {pc="inmate", npc="guard", npcAction="hurt"}]
	if(getState() == "escorted_out"):
		return [StageScene.Duo, "hurt", {pc="inmate", npc="guard", npcAction="shove"}]
	return [StageScene.Duo, "stand", {pc="inmate", npc="guard"}]

func startEscortOut():
	if(GM.world.isLocSafe(getLocation())):
		setState("escorted_out", "guard")
		return
	throwOutLoc = GM.world.getSafeLoc(getLocation())
	goTowards(throwOutLoc)
	setState("escorting_out", "guard")

func getPreviewLineForRole(_role:String) -> String:
	if(_role == "guard"):
		return "{guard.name} has caught {inmate.name} off-limits and is dealing with {inmate.him}."
	if(_role == "inmate"):
		return "{inmate.name} was found by {guard.name}."
	return .getPreviewLineForRole(_role)

func saveData():
	var data = .saveData()

	data["foundIllegalItems"] = foundIllegalItems
	data["throwOutLoc"] = throwOutLoc
	data["guardSurrender"] = guardSurrender
	return data

func loadData(_data):
	.loadData(_data)

	foundIllegalItems = SAVE.loadVar(_data, "foundIllegalItems", false)
	throwOutLoc = SAVE.loadVar(_data, "throwOutLoc", "")
	guardSurrender = SAVE.loadVar(_data, "guardSurrender", false)

const VOREMOD_BALANCE_PERK = "VoreBalancedPrey"
const VOREMOD_BALANCE_SCORETYPE = "voremod_balance"
const VOREMOD_BALANCE_SHARE = 0.5
var _voreModBalancedRole = ""
var _voreModBalancedBaseType = "punish"
var _voreModBalancedBaseScore = 1.0
func getScoreTypeValue(_scoreType:String):
	if(_scoreType == VOREMOD_BALANCE_SCORETYPE):
		return _voreModBalancedDevourValue()
	return .getScoreTypeValue(_scoreType)
func _voreModBalancedDevourValue() -> float:
	var baseFinal:float = _voreModBalancedBaseScore * .getScoreTypeValue(_voreModBalancedBaseType)
	var total:float = 0.0
	for entry in actionBuffer:
		if(entry.has("disabled") && entry["disabled"]):
			continue
		var entryID:String = str(entry["id"]) if entry.has("id") else ""
		if(entryID == "vore_loser"):
			continue
		var entryScore:float = calcFinalActionScore(entry)
		if(entryScore > 0.0):
			total += entryScore
	if(total <= 0.0):
		return baseFinal
	var share:float = clamp(VOREMOD_BALANCE_SHARE, 0.05, 0.95)
	var capped:float = total * (share / (1.0 - share))
	return min(capped, baseFinal)
func _voreModRoleIsPlayer(_role:String) -> bool:
	if(getRoleID(_role) == "pc"):
		return true
	var ch = getRoleChar(_role)
	if(ch != null && GM.pc != null && ch == GM.pc):
		return true
	var pawn = getRolePawn(_role)
	if(pawn != null && pawn.has_method("isPlayer") && pawn.isPlayer()):
		return true
	return false
func _voreModClearStalePreyState(_winnerRole:String):
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var w = getRoleChar(_winnerRole)
	if(w != null && w.hasEffect("VorePredatorBelly")):
		w.removeEffect("VorePredatorBelly")
func _voreModDevourMethod(_winnerRole:String) -> String:
	var w = getRoleChar(_winnerRole)
	if(w == null || GM.pc == null):
		return ""
	var pool = ["mouth", "anus", "tail"]
	if(w.has_method("hasNonFlatBreasts") && w.hasNonFlatBreasts()):
		pool.append("breasts")
	if(w.has_method("hasPenis") && w.hasPenis()):
		pool.append("cock")
	if(w.has_method("hasVagina") && w.hasVagina()):
		pool.append("vagina")
	var allowed = []
	for m in pool:
		if(!VoreSwallowedGA.isMethodBlockedForPC(GM.pc, m)):
			allowed.append(m)
	if(allowed.size() <= 0):
		return ""
	allowed.shuffle()
	return str(allowed[0])
func _voreModCanDevour(_winnerRole:String, _loserRole:String) -> bool:
	if(GM.pc == null):
		return false
	if(!hasRoleChar(_winnerRole) || !hasRoleChar(_loserRole)):
		return false
	if(_voreModRoleIsPlayer(_winnerRole) || !_voreModRoleIsPlayer(_loserRole)):
		return false
	_voreModClearStalePreyState(_winnerRole)
	var w = getRoleChar(_winnerRole)
	if(w == null):
		return false
	if(!_preyIsIrresistible() && !_preyHasLureScent() && _preyVoreLike(w) < 0.2):
		return false
	return _voreModDevourMethod(_winnerRole) != ""
func _voreModShouldExplainDevour(_winnerRole:String, _loserRole:String) -> bool:
	if(GM.pc == null):
		return false
	if(_voreModRoleIsPlayer(_winnerRole) || !_voreModRoleIsPlayer(_loserRole)):
		return false
	return _preyIsIrresistible() || _preyHasLureScent()
func _voreModDevourBlockedReason(_winnerRole:String) -> String:
	var w = getRoleChar(_winnerRole)
	if(w == null):
		return "They are in no state to make a meal out of anyone.."
	if(_voreModDevourMethod(_winnerRole) == ""):
		return "Every way they could take you in is forbidden to you.."
	if(w.hasEffect("VorePredatorBelly")):
		return "They already have their hands full with someone else right now.."
	return "They just are not hungry enough for that.."
func _voreModDevourScore(_winnerRole:String) -> float:
	var score = 0.6 + _preyVoreLike(getRoleChar(_winnerRole))
	if(_preyIsIrresistible()):
		score += 2.0
	if(_preyHasLureScent()):
		score += 1.0
	return max(0.2, score)
func _voreModStartDevour(_winnerRole:String):
	var m = _voreModDevourMethod(_winnerRole)
	var winnerID = getRoleID(_winnerRole)
	if(m == "" || winnerID == ""):
		return
	if(GM.main != null):
		GM.main.addMessage("You lost -- and they have decided a beating would be a waste of a perfectly good meal.")
	stopMe()
	runScene("VoreBellyRideScene", [winnerID, m])
func _voreModDevourWasOffered(_winnerRole:String, _loserRole:String) -> bool:
	return _voreModCanDevour(_winnerRole, _loserRole) || _voreModShouldExplainDevour(_winnerRole, _loserRole)
func _voreModAddDevourChoice(_winnerRole:String, _loserRole:String, _scoreType:String = "punish"):
	if(_voreModCanDevour(_winnerRole, _loserRole)):
		if(_voreModTryBalancedDevour(_winnerRole, _scoreType)):
			return
		addAction("vore_loser", "Devour", "Why beat them when you could just eat them?", _scoreType, _voreModDevourScore(_winnerRole), 60, {})
	elif(_voreModShouldExplainDevour(_winnerRole, _loserRole)):
		addDisabledAction("Devour", _voreModDevourBlockedReason(_winnerRole))
func _voreModTryBalancedDevour(_winnerRole:String, _scoreType:String) -> bool:
	if(!_preyHasPerk(VOREMOD_BALANCE_PERK)):
		return false
	_voreModBalancedRole = _winnerRole
	_voreModBalancedBaseType = _scoreType
	_voreModBalancedBaseScore = _voreModDevourScore(_winnerRole)
	addAction("vore_loser", "Devour", "Why beat them when you could just eat them?", VOREMOD_BALANCE_SCORETYPE, 1.0, 60, {})
	return true
const PERK_IRRESISTIBLE_PREY = "VoreIrresistiblePrey"
func _preyHasPerk(_perkID:String) -> bool:
	if(GM.pc == null):
		return false
	if(GM.pc.has_method("getSkillsHolder")):
		var holder = GM.pc.getSkillsHolder()
		if(holder != null && holder.has_method("hasPerk") && holder.hasPerk(_perkID)):
			return true
	if(GM.pc.has_method("hasPerk") && GM.pc.hasPerk(_perkID)):
		return true
	return false
func _preyIsIrresistible() -> bool:
	return _preyHasPerk(PERK_IRRESISTIBLE_PREY)
func _preyHasLureScent() -> bool:
	if(GM.pc == null):
		return false
	return GM.pc.hasEffect("VoreLureScent")
func _preyVoreLike(ch) -> float:
	if(ch == null):
		return 0.0
	var fh = ch.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")
