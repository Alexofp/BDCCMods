extends PawnInteractionBase

const VoreSwallowedGA = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")

var voreModDevourOffered: bool = false

func _init():
	id = "PunishInteraction"

func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("punisher", _pawns["punisher"])
	doInvolvePawn("target", _pawns["target"])
	voreModDevourOffered = bool(_args.get("voreModDevourOffered", false))
	setState("", "punisher")

func init_text():
	saynn("{punisher.name} looms over {target.you}.")
	sayLine("punisher", "PunishDecide", {punisher="punisher", target="target"})
	
	var punisherRestraintsPreventPulling:bool = getRoleChar("punisher").hasBlockedHands() || getRoleChar("punisher").hasBoundArms()

	if(!punisherRestraintsPreventPulling && getRoleChar("target").getInventory().hasEquippedItemWithTag(ItemTag.AllowsEnslaving) && canGetToStocks()):
		addAction("stocks", "Stocks", "Lock them up in stocks!", "punishMean", 0.2 * getStocksScoreMult(), 60, {})
	elif(punisherRestraintsPreventPulling):
		addDisabledAction("Stocks", "You can't do that with restraints on your arms..")
	else:
		addDisabledAction("Stocks", ""+("They need to be wearing a collar for this!" if canGetToStocks() else "Stocks are too far..")+"")
	if(!punisherRestraintsPreventPulling && getRolePawn("punisher").isInmate() && getRoleChar("target").getInventory().hasEquippedItemWithTag(ItemTag.AllowsEnslaving) && canGetToSlutwall() && getRolePawn("target").isInmate()):
		addAction("slutwall", "Slutwall", "Force them into a slutwall!", "punishMean", 0.2 * getSlutwallScoreMult(), 60, {})
	elif(punisherRestraintsPreventPulling):
		addDisabledAction("Slutwall", "You can't do that with restraints on your arms..")
	else:
		addDisabledAction("Slutwall", ""+(("They need to be wearing a collar for this!" if !getRoleChar("target").getInventory().hasEquippedItemWithTag(ItemTag.AllowsEnslaving) else "They are not one of the inmates..") if canGetToSlutwall() else "Can't get to the slutwall..")+"")
	if(roleCanStartSex("punisher")):
		addAction("sex", "Sex", "Just have some fun with them!", "sexDom", 1.0, 60, {})
	else:
		addDisabledAction("Sex", "You can't fuck them with your restraints..")
	if(roleCanStartSex("target")):
		addAction("sexsub", "Submit to", "Let them fuck you", "sexSub", 1.0, 60, {})
	else:
		addDisabledAction("Submit to", "They can't fuck you with their restraints..")
	if(getRoleChar("punisher").isPlayer()):
		var elizaModule = GlobalRegistry.getModule("ElizaModule")
		if(elizaModule && elizaModule.hasAccessToTentacles()):
			if(!punisherRestraintsPreventPulling && getRoleChar("target").getInventory().hasEquippedItemWithTag(ItemTag.AllowsEnslaving) && canGetToStocks()):
				addAction("tentacles", "Tentacles", "Get them punished by the tentacles in your cell", "default", 0.0, 60, {})
			elif(punisherRestraintsPreventPulling):
				addDisabledAction("Tentacles", "You can't do that with restraints on your arms..")
			else:
				addDisabledAction("Tentacles", ""+("They need to be wearing a collar for this!" if canGetToStocks() else "Your cell is too far..")+"")
	if(!voreModDevourOffered):
		_voreModAddDevourChoice("punisher", "target")
	addAction("leave", "Leave", "Just leave", "justleave", 1.0, 30, {})

	addDefeatButtons("punisher", "target")

func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "vore_loser"):
		_voreModStartDevour("punisher")
		return
	if(_id == "stocks"):
		setState("about_to_stocks", "punisher")
	if(_id == "tentacles"):
		setState("about_to_tentacles", "punisher")
	if(_id == "slutwall"):
		setState("about_to_slutwall", "punisher")
	if(_id == "sex"):
		setState("about_to_sex", "punisher")
		sendSocialEvent("punisher", "target", SocialEventType.PunishSex)
	if(_id == "sexsub"):
		setState("about_to_subsex", "punisher")
	if(_id == "leave"):
		setState("just_leaving", "punisher")


func about_to_tentacles_text():
	saynn("{punisher.name} clips a leash to {target.your} collar.")
	addAction("cell", "Escort", "Escort them towards your cell", "default", 1.0, 60, {})

func about_to_tentacles_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "cell"):
		setState("pulling_to_cell_tentacles", "punisher")
		goTowards(GM.pc.getCellLocation())

func pulling_to_cell_tentacles_text():
	saynn("{punisher.name} is pulling {target.name} towards {punisher.his} cell!")
	addAction("cell", "Escort", "Pull them towards your cell", "default", 1.0, 60, {})

func pulling_to_cell_tentacles_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "cell"):
		goTowards(GM.pc.getCellLocation())
		if(getLocation() == GM.pc.getCellLocation()):
			var theTargetID:String = getRoleID("target")
			runScene("PSPCTentaclesPunish", [theTargetID])
			startInteraction("InScene", {main=theTargetID})
			stopMe()

func about_to_stocks_text():
	saynn("{punisher.name} clips a leash to {target.your} collar.")
	sayLine("punisher", "PunishDecideStocks", {punisher="punisher", target="target"})

	addAction("stocks", "Escort", "Escort them towards the stocks", "default", 1.0, 60, {})

func about_to_stocks_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "stocks"):
		setState("pulling_to_stocks", "punisher")
		goTowards("main_punishment_spot")


func about_to_sex_text():
	saynn("{punisher.name} grabs {target.you}..")
	sayLine("punisher", "PunishSex", {punisher="punisher", target="target"})

	addAction("sex", "Sex", "Start the sex", "default", 1.0, 300, {start_sex=["punisher", "target"],})

func about_to_sex_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "sex"):
		var _result = getSexResult(_args, true)
		setState("after_sex", "punisher")


func about_to_subsex_text():
	saynn("{punisher.name} submits to {target.you}..")
	sayLine("punisher", "PunishSubSex", {punisher="punisher", target="target"})

	addAction("sex", "Sex", "Start the sex", "default", 1.0, 300, {start_sex=["target", "punisher"],})

func about_to_subsex_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "sex"):
		var _result = getSexResult(_args, true)
		setState("after_sex", "punisher")


func pulling_to_stocks_text():
	saynn("{punisher.name} is pulling {target.name} towards the punishment platform!")

	addAction("stocks", "Escort", "Pull them towards the stocks", "default", 1.0, 60, {})

func pulling_to_stocks_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "stocks"):
		goTowards("main_punishment_spot")
		if(getLocation() == "main_punishment_spot"):
			setState("about_to_lock_stocks", "punisher")


func about_to_lock_stocks_text():
	saynn("{punisher.name} guides {target.name} to the stocks.")
	sayLine("punisher", "PunishAboutToStocks", {punisher="punisher", target="target"})

	addAction("lock_them", "Lock them", "Force them into the stocks", "default", 1.0, 120, {})

func about_to_lock_stocks_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "lock_them"):
		affectAffection("target", "punisher", -0.1)
		addRepScore("target", RepStat.Alpha, -3.0)
		sendSocialEvent("punisher", "target", SocialEventType.PunishStocks)
		setState("in_stocks", "punisher")


func in_stocks_text():
	saynn("{punisher.name} locks {target.name} into the stocks!")
	sayLine("punisher", "PunishLockIntoStocks", {punisher="punisher", target="target"})

	addAction("leave", "Leave", "Leave them be", "default", 1.0, 30, {})

func in_stocks_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()
		startInteraction("InStocks", {inmate=getRoleID("target")}, {punisherID=getRoleID("punisher")})


func after_sex_text():
	saynn("After sex, {punisher.name} leaves {target.you} alone..")

	addAction("leave", "Leave", "Time to go", "default", 1.0, 30, {})

func after_sex_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()


func just_leaving_text():
	saynn("{punisher.name} decides to just leave {target.name} alone..")

	addAction("leave", "Leave", "Time to go", "default", 1.0, 30, {})

func just_leaving_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()


func about_to_slutwall_text():
	saynn("{punisher.name} clips a leash to {target.your} collar.")
	sayLine("punisher", "PunishDecidedSlutwall", {punisher="punisher", target="target"})

	addAction("escort", "Escort", "Escort them towards the slutwall", "default", 1.0, 60, {})

func about_to_slutwall_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "escort"):
		setState("pulling_to_slutwall", "punisher")
		goTowards("fight_slutwall")


func pulling_to_slutwall_text():
	saynn("{punisher.name} is pulling {target.name} towards the slutwall!")

	addAction("escort", "Escort", "Pull them towards the slutwall", "default", 1.0, 60, {})

func pulling_to_slutwall_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "escort"):
		goTowards("fight_slutwall")
		if(getLocation() == "fight_slutwall"):
			setState("about_to_lock_slutwall", "punisher")


func about_to_lock_slutwall_text():
	saynn("{punisher.name} is locking {target.name} in the slutwall.")

	addAction("lock_them", "Lock them", "Force them into the slutwall", "default", 1.0, 120, {})

func about_to_lock_slutwall_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "lock_them"):
		affectAffection("target", "punisher", -0.1)
		addRepScore("target", RepStat.Alpha, -3.0)
		sendSocialEvent("punisher", "target", SocialEventType.PunishSlutwall)
		setState("in_slutwall", "punisher")


func in_slutwall_text():
	saynn("{punisher.name} locks {target.name} into the slutwall!")
	sayLine("punisher", "PunishLockIntoSlutwall", {punisher="punisher", target="target"})

	addAction("leave", "Leave", "Leave them be", "default", 1.0, 30, {})

func in_slutwall_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()
		startInteraction("InSlutwall", {inmate=getRoleID("target")}, {punisherID=getRoleID("punisher")})


func getAnimData() -> Array:
	if(getState() == "about_to_sex"):
		return [StageScene.SexStart, "start", {pc="punisher", npc="target"}]
	if(getState() == "in_slutwall"):
		return [StageScene.SlutwallSex, "tease", {pc="target", npc="punisher"}]
	if(getState() == "in_stocks"):
		return [StageScene.StocksSexOral, "tease", {npc="punisher", pc="target"}]
	if(getState() in ["pulling_to_stocks", "pulling_to_slutwall", "pulling_to_cell_tentacles"]):
		if(getLocation() != "main_punishment_spot" && getLocation() != "fight_slutwall"):
			return [StageScene.Duo, "walk", {pc="target", npc="punisher", npcAction="walk", flipNPC=true, bodyState={leashedBy="punisher"}}]
	if(getState() in [""]):
		return [StageScene.SexStart, "start", {pc="punisher", npc="target"}]
	
	return [StageScene.Duo, "stand", {pc="target", npc="punisher"}]

func getActivityIconForRole(_role:String):
	return RoomStuff.PawnActivity.Chat

func getPreviewLineForRole(_role:String) -> String:
	if(_role == "target"):
		return "{target.name} is being punished by {punisher.name}."
	if(_role == "punisher"):
		return "{punisher.name} is punishing {target.name}."
	return .getPreviewLineForRole(_role)

func saveData():
	var data = .saveData()
	data["voreModDevourOffered"] = voreModDevourOffered
	return data
func loadData(_data):
	.loadData(_data)
	voreModDevourOffered = SAVE.loadVar(_data, "voreModDevourOffered", false)
func isRoleOnALeash(_role:String) -> bool:
	if(_role == "target" && getState() in ["pulling_to_stocks", "pulling_to_slutwall", "pulling_to_cell_tentacles"]):
		return true
	return false
	
func isRoleLeashing(_role:String) -> bool:
	if(_role == "punisher" && getState() in ["pulling_to_stocks", "pulling_to_slutwall", "pulling_to_cell_tentacles"]):
		return true
	return false

const VOREMOD_BALANCE_PERK = "VoreBalancedPrey"
const VOREMOD_BALANCE_SCORETYPE = "voremod_balance"
const VOREMOD_BALANCE_SHARE = 0.5
var _voreModBalancedRole = ""
var _voreModBalancedBaseType = "punish"
var _voreModBalancedBaseScore = 1.0
func getScoreTypeValue(_scoreType:String):
	if(_scoreType == VOREMOD_BALANCE_SCORETYPE):
		return _voreModBalancedDevourValue()
	return .getScoreTypeValue(_scoreType)
func _voreModBalancedDevourValue() -> float:
	var baseFinal:float = _voreModBalancedBaseScore * .getScoreTypeValue(_voreModBalancedBaseType)
	var total:float = 0.0
	for entry in actionBuffer:
		if(entry.has("disabled") && entry["disabled"]):
			continue
		var entryID:String = str(entry["id"]) if entry.has("id") else ""
		if(entryID == "vore_loser"):
			continue
		var entryScore:float = calcFinalActionScore(entry)
		if(entryScore > 0.0):
			total += entryScore
	if(total <= 0.0):
		return baseFinal
	var share:float = clamp(VOREMOD_BALANCE_SHARE, 0.05, 0.95)
	var capped:float = total * (share / (1.0 - share))
	return min(capped, baseFinal)
func _voreModRoleIsPlayer(_role:String) -> bool:
	if(getRoleID(_role) == "pc"):
		return true
	var ch = getRoleChar(_role)
	if(ch != null && GM.pc != null && ch == GM.pc):
		return true
	var pawn = getRolePawn(_role)
	if(pawn != null && pawn.has_method("isPlayer") && pawn.isPlayer()):
		return true
	return false
func _voreModClearStalePreyState(_winnerRole:String):
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var w = getRoleChar(_winnerRole)
	if(w != null && w.hasEffect("VorePredatorBelly")):
		w.removeEffect("VorePredatorBelly")
func _voreModDevourMethod(_winnerRole:String) -> String:
	var w = getRoleChar(_winnerRole)
	if(w == null || GM.pc == null):
		return ""
	var pool = ["mouth", "anus", "tail"]
	if(w.has_method("hasNonFlatBreasts") && w.hasNonFlatBreasts()):
		pool.append("breasts")
	if(w.has_method("hasPenis") && w.hasPenis()):
		pool.append("cock")
	if(w.has_method("hasVagina") && w.hasVagina()):
		pool.append("vagina")
	var allowed = []
	for m in pool:
		if(!VoreSwallowedGA.isMethodBlockedForPC(GM.pc, m)):
			allowed.append(m)
	if(allowed.size() <= 0):
		return ""
	allowed.shuffle()
	return str(allowed[0])
func _voreModCanDevour(_winnerRole:String, _loserRole:String) -> bool:
	if(GM.pc == null):
		return false
	if(!hasRoleChar(_winnerRole) || !hasRoleChar(_loserRole)):
		return false
	if(_voreModRoleIsPlayer(_winnerRole) || !_voreModRoleIsPlayer(_loserRole)):
		return false
	_voreModClearStalePreyState(_winnerRole)
	var w = getRoleChar(_winnerRole)
	if(w == null):
		return false
	if(!_preyIsIrresistible() && !_preyHasLureScent() && _preyVoreLike(w) < 0.2):
		return false
	return _voreModDevourMethod(_winnerRole) != ""
func _voreModShouldExplainDevour(_winnerRole:String, _loserRole:String) -> bool:
	if(GM.pc == null):
		return false
	if(_voreModRoleIsPlayer(_winnerRole) || !_voreModRoleIsPlayer(_loserRole)):
		return false
	return _preyIsIrresistible() || _preyHasLureScent()
func _voreModDevourBlockedReason(_winnerRole:String) -> String:
	var w = getRoleChar(_winnerRole)
	if(w == null):
		return "They are in no state to make a meal out of anyone.."
	if(_voreModDevourMethod(_winnerRole) == ""):
		return "Every way they could take you in is forbidden to you.."
	if(w.hasEffect("VorePredatorBelly")):
		return "They already have their hands full with someone else right now.."
	return "They just are not hungry enough for that.."
func _voreModDevourScore(_winnerRole:String) -> float:
	var score = 0.6 + _preyVoreLike(getRoleChar(_winnerRole))
	if(_preyIsIrresistible()):
		score += 2.0
	if(_preyHasLureScent()):
		score += 1.0
	return max(0.2, score)
func _voreModStartDevour(_winnerRole:String):
	var m = _voreModDevourMethod(_winnerRole)
	var winnerID = getRoleID(_winnerRole)
	if(m == "" || winnerID == ""):
		return
	if(GM.main != null):
		GM.main.addMessage("You lost -- and they have decided a beating would be a waste of a perfectly good meal.")
	stopMe()
	runScene("VoreBellyRideScene", [winnerID, m])
func _voreModDevourWasOffered(_winnerRole:String, _loserRole:String) -> bool:
	return _voreModCanDevour(_winnerRole, _loserRole) || _voreModShouldExplainDevour(_winnerRole, _loserRole)
func _voreModAddDevourChoice(_winnerRole:String, _loserRole:String, _scoreType:String = "punish"):
	if(_voreModCanDevour(_winnerRole, _loserRole)):
		if(_voreModTryBalancedDevour(_winnerRole, _scoreType)):
			return
		addAction("vore_loser", "Devour", "Why beat them when you could just eat them?", _scoreType, _voreModDevourScore(_winnerRole), 60, {})
	elif(_voreModShouldExplainDevour(_winnerRole, _loserRole)):
		addDisabledAction("Devour", _voreModDevourBlockedReason(_winnerRole))
func _voreModTryBalancedDevour(_winnerRole:String, _scoreType:String) -> bool:
	if(!_preyHasPerk(VOREMOD_BALANCE_PERK)):
		return false
	_voreModBalancedRole = _winnerRole
	_voreModBalancedBaseType = _scoreType
	_voreModBalancedBaseScore = _voreModDevourScore(_winnerRole)
	addAction("vore_loser", "Devour", "Why beat them when you could just eat them?", VOREMOD_BALANCE_SCORETYPE, 1.0, 60, {})
	return true
const PERK_IRRESISTIBLE_PREY = "VoreIrresistiblePrey"
func _preyHasPerk(_perkID:String) -> bool:
	if(GM.pc == null):
		return false
	if(GM.pc.has_method("getSkillsHolder")):
		var holder = GM.pc.getSkillsHolder()
		if(holder != null && holder.has_method("hasPerk") && holder.hasPerk(_perkID)):
			return true
	if(GM.pc.has_method("hasPerk") && GM.pc.hasPerk(_perkID)):
		return true
	return false
func _preyIsIrresistible() -> bool:
	return _preyHasPerk(PERK_IRRESISTIBLE_PREY)
func _preyHasLureScent() -> bool:
	if(GM.pc == null):
		return false
	return GM.pc.hasEffect("VoreLureScent")
func _preyVoreLike(ch) -> float:
	if(ch == null):
		return 0.0
	var fh = ch.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")
