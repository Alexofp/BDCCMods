extends PawnInteractionBase
const VoreBodyScaleHelper = preload("res://Modules/VoreMod/VoreBodyScaleHelper.gd")
const VoreSwallowedGA = preload("res://Modules/VoreMod/StatusEffects/VoreSwallowed.gd")
var surrendered = false
var askCredits = 0
func _init():
	id = "GenericAttack"
func start(_pawns:Dictionary, _args:Dictionary):
	doInvolvePawn("starter", _pawns["starter"])
	doInvolvePawn("reacter", _pawns["reacter"])
	if(_args.has("askCredits")):
		askCredits = _args["askCredits"]
	setState("", "reacter")
func init_text():
	saynn("{starter.You} {starter.youVerb('attack')} {reacter.you}!")
	sayLine("starter", "AttackStart", {main="starter", target="reacter"})
	sayLine("reacter", "AttackReact", {main="reacter", target="starter"})
	addAction("fight", "Fight", "Fight back", "fight", 1.0, 300, {start_fight=["starter", "reacter"],})
	addAction("surrender", "Surrender", "It's not worth it!", "surrender", 1.0, 60, {})
func init_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "fight"):
		surrendered = false
		var fightResult = getFightResult(_args)
		if(fightResult["won"]):
			setState("starter_won", "starter")
			onStarterWin()
			sendSocialEvent("starter", "reacter", SocialEventType.LostFight)
		else:
			setState("reacter_won", "reacter")
			sendSocialEvent("reacter", "starter", SocialEventType.LostFight)
	if(_id == "surrender"):
		surrendered = true
		setState("starter_won", "starter")
		onStarterWin(true)
func _voreModIsPunishAllowed(_targetRole:String) -> bool:
	var targetChar = getRoleChar(_targetRole)
	return VoreBodyScaleHelper.isPunishAllowedForCharacter(targetChar)
func _voreModGetPunishBlockedReason(_targetRole:String) -> String:
	var targetChar = getRoleChar(_targetRole)
	return VoreBodyScaleHelper.getPunishBlockedReason(targetChar)
func starter_won_text():
	if(!surrendered):
		saynn("{starter.name} won the fight! {reacter.name} hits the floor, unable to continue fighting..")
		if(RNG.chance(50)):
			sayLine("reacter", "FightLostGeneric", {loser="reacter", winner="starter"})
		else:
			sayLine("starter", "FightWonGeneric", {winner="starter", loser="reacter"})
	else:
		saynn("{reacter.name} decides to surrender instantly..")
		sayLine("reacter", "FightSurrender", {loser="reacter", winner="starter"})
	if(askCredits > 0):
		saynn("{starter.You} {starter.youVerb('fetch', 'fetches')} "+str(askCredits)+" credits from {reacter.you}..")
	if(_voreModIsPunishAllowed("reacter")):
		addAction("punish", "Punish", "Have some fun!", "punish", 1.0, 60, {})
	else:
		addDisabledAction("Punish", _voreModGetPunishBlockedReason("reacter"))
	_voreModAddDevourChoice("starter", "reacter")
	addAction("leave", "Leave", "Just leave", "default", 0.1, 60, {})
	addDefeatButtonsOnlyEvent("starter", "reacter")
func starter_won_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "vore_loser"):
		_voreModStartDevour("starter")
		return
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("starter"), target=getRoleID("reacter")}, {voreModDevourOffered = _voreModDevourWasOffered("starter", "reacter")})
	if(_id == "leave"):
		setState("starter_won_leave", "starter")
func starter_won_leave_text():
	saynn("{starter.name} decides to leave {reacter.you} alone..")
	addAction("leave", "Leave", "Time to go..", "default", 1.0, 60, {})
func starter_won_leave_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()
func reacter_won_text():
	if(!surrendered):
		saynn("{reacter.name} won the fight! {starter.name} hits the floor, unable to continue fighting..")
		if(RNG.chance(50)):
			sayLine("starter", "FightLostGeneric", {loser="starter", winner="reacter"})
		else:
			sayLine("reacter", "FightWonGeneric", {winner="reacter", loser="starter"})
	else:
		saynn("{starter.name} decides to surrender instantly..")
		sayLine("starter", "FightSurrender", {loser="starter", winner="reacter"})
	if(_voreModIsPunishAllowed("starter")):
		addAction("punish", "Punish", "Punish them for attacking you!", "punish", 1.0, 60, {})
	else:
		addDisabledAction("Punish", _voreModGetPunishBlockedReason("starter"))
	_voreModAddDevourChoice("reacter", "starter")
	addAction("leave", "Leave", "Just leave", "surrender", 1.0, 60, {})
	addDefeatButtonsOnlyEvent("reacter", "starter")
func reacter_won_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "vore_loser"):
		_voreModStartDevour("reacter")
		return
	if(_id == "punish"):
		startInteraction("PunishInteraction", {punisher=getRoleID("reacter"), target=getRoleID("starter")}, {voreModDevourOffered = _voreModDevourWasOffered("reacter", "starter")})
	if(_id == "leave"):
		setState("reacter_won_leave", "reacter")
		affectAffection("starter", "reacter", 0.15)
func reacter_won_leave_text():
	saynn("{reacter.name} decides to leave {starter.you} alone..")
	addAction("leave", "Leave", "Time to go..", "default", 1.0, 60, {})
func reacter_won_leave_do(_id:String, _args:Dictionary, _context:Dictionary):
	if(_id == "leave"):
		stopMe()
func getAnimData() -> Array:
	if(getState() == "starter_won"):
		if(surrendered):
			return [StageScene.Duo, "stand", {pc="starter", npc="reacter", npcAction="kneel"}]
		else:
			return [StageScene.Duo, "stand", {pc="starter", npc="reacter", npcAction="defeat"}]
	if(getState() == "reacter_won"):
		if(surrendered):
			return [StageScene.Duo, "kneel", {pc="starter", npc="reacter"}]
		else:
			return [StageScene.Duo, "defeat", {pc="starter", npc="reacter"}]
	return [StageScene.Duo, "stand", {pc="starter", npc="reacter"}]
func onStarterWin(_isSurrender=false):
	if(askCredits > 0):
		if(getRolePawn("reacter").isPlayer()):
			GM.pc.addCredits(-askCredits)
			addMessage("You lost "+str(askCredits)+" credits!")
		if(getRolePawn("starter").isPlayer()):
			GM.pc.addCredits(askCredits)
			addMessage("You gained "+str(askCredits)+" credits!")
func getPreviewLineForRole(_role:String) -> String:
	if(_role == "starter"):
		return "{starter.name} is attacking {reacter.name}!"
	if(_role == "reacter"):
		return "{reacter.name} is being attacked by {starter.name}!"
	return .getPreviewLineForRole(_role)
func saveData():
	var data = .saveData()
	data["surrendered"] = surrendered
	data["askCredits"] = askCredits
	return data
func loadData(_data):
	.loadData(_data)
	surrendered = SAVE.loadVar(_data, "surrendered", false)
	askCredits = SAVE.loadVar(_data, "askCredits", 0)

const VOREMOD_BALANCE_PERK = "VoreBalancedPrey"
const VOREMOD_BALANCE_SCORETYPE = "voremod_balance"
const VOREMOD_BALANCE_SHARE = 0.5
var _voreModBalancedRole = ""
var _voreModBalancedBaseType = "punish"
var _voreModBalancedBaseScore = 1.0
func getScoreTypeValue(_scoreType:String):
	if(_scoreType == VOREMOD_BALANCE_SCORETYPE):
		return _voreModBalancedDevourValue()
	return .getScoreTypeValue(_scoreType)
func _voreModBalancedDevourValue() -> float:
	var baseFinal:float = _voreModBalancedBaseScore * .getScoreTypeValue(_voreModBalancedBaseType)
	var total:float = 0.0
	for entry in actionBuffer:
		if(entry.has("disabled") && entry["disabled"]):
			continue
		var entryID:String = str(entry["id"]) if entry.has("id") else ""
		if(entryID == "vore_loser"):
			continue
		var entryScore:float = calcFinalActionScore(entry)
		if(entryScore > 0.0):
			total += entryScore
	if(total <= 0.0):
		return baseFinal
	var share:float = clamp(VOREMOD_BALANCE_SHARE, 0.05, 0.95)
	var capped:float = total * (share / (1.0 - share))
	return min(capped, baseFinal)
func _voreModRoleIsPlayer(_role:String) -> bool:
	if(getRoleID(_role) == "pc"):
		return true
	var ch = getRoleChar(_role)
	if(ch != null && GM.pc != null && ch == GM.pc):
		return true
	var pawn = getRolePawn(_role)
	if(pawn != null && pawn.has_method("isPlayer") && pawn.isPlayer()):
		return true
	return false
func _voreModClearStalePreyState(_winnerRole:String):
	if(GM.pc != null && GM.pc.hasEffect("VorePlayerDigesting")):
		GM.pc.removeEffect("VorePlayerDigesting")
	var w = getRoleChar(_winnerRole)
	if(w != null && w.hasEffect("VorePredatorBelly")):
		w.removeEffect("VorePredatorBelly")
func _voreModDevourMethod(_winnerRole:String) -> String:
	var w = getRoleChar(_winnerRole)
	if(w == null || GM.pc == null):
		return ""
	var pool = ["mouth", "anus", "tail"]
	if(w.has_method("hasNonFlatBreasts") && w.hasNonFlatBreasts()):
		pool.append("breasts")
	if(w.has_method("hasPenis") && w.hasPenis()):
		pool.append("cock")
	if(w.has_method("hasVagina") && w.hasVagina()):
		pool.append("vagina")
	var allowed = []
	for m in pool:
		if(!VoreSwallowedGA.isMethodBlockedForPC(GM.pc, m)):
			allowed.append(m)
	if(allowed.size() <= 0):
		return ""
	allowed.shuffle()
	return str(allowed[0])
func _voreModCanDevour(_winnerRole:String, _loserRole:String) -> bool:
	if(GM.pc == null):
		return false
	if(!hasRoleChar(_winnerRole) || !hasRoleChar(_loserRole)):
		return false
	if(_voreModRoleIsPlayer(_winnerRole) || !_voreModRoleIsPlayer(_loserRole)):
		return false
	_voreModClearStalePreyState(_winnerRole)
	var w = getRoleChar(_winnerRole)
	if(w == null):
		return false
	if(!_preyIsIrresistible() && !_preyHasLureScent() && _preyVoreLike(w) < 0.2):
		return false
	return _voreModDevourMethod(_winnerRole) != ""
func _voreModShouldExplainDevour(_winnerRole:String, _loserRole:String) -> bool:
	if(GM.pc == null):
		return false
	if(_voreModRoleIsPlayer(_winnerRole) || !_voreModRoleIsPlayer(_loserRole)):
		return false
	return _preyIsIrresistible() || _preyHasLureScent()
func _voreModDevourBlockedReason(_winnerRole:String) -> String:
	var w = getRoleChar(_winnerRole)
	if(w == null):
		return "They are in no state to make a meal out of anyone.."
	if(_voreModDevourMethod(_winnerRole) == ""):
		return "Every way they could take you in is forbidden to you.."
	if(w.hasEffect("VorePredatorBelly")):
		return "They already have their hands full with someone else right now.."
	return "They just are not hungry enough for that.."
func _voreModDevourScore(_winnerRole:String) -> float:
	var score = 0.6 + _preyVoreLike(getRoleChar(_winnerRole))
	if(_preyIsIrresistible()):
		score += 2.0
	if(_preyHasLureScent()):
		score += 1.0
	return max(0.2, score)
func _voreModStartDevour(_winnerRole:String):
	var m = _voreModDevourMethod(_winnerRole)
	var winnerID = getRoleID(_winnerRole)
	if(m == "" || winnerID == ""):
		return
	if(GM.main != null):
		GM.main.addMessage("You lost -- and they have decided a beating would be a waste of a perfectly good meal.")
	stopMe()
	runScene("VoreBellyRideScene", [winnerID, m])
func _voreModDevourWasOffered(_winnerRole:String, _loserRole:String) -> bool:
	return _voreModCanDevour(_winnerRole, _loserRole) || _voreModShouldExplainDevour(_winnerRole, _loserRole)
func _voreModAddDevourChoice(_winnerRole:String, _loserRole:String, _scoreType:String = "punish"):
	if(_voreModCanDevour(_winnerRole, _loserRole)):
		if(_voreModTryBalancedDevour(_winnerRole, _scoreType)):
			return
		addAction("vore_loser", "Devour", "Why beat them when you could just eat them?", _scoreType, _voreModDevourScore(_winnerRole), 60, {})
	elif(_voreModShouldExplainDevour(_winnerRole, _loserRole)):
		addDisabledAction("Devour", _voreModDevourBlockedReason(_winnerRole))
func _voreModTryBalancedDevour(_winnerRole:String, _scoreType:String) -> bool:
	if(!_preyHasPerk(VOREMOD_BALANCE_PERK)):
		return false
	_voreModBalancedRole = _winnerRole
	_voreModBalancedBaseType = _scoreType
	_voreModBalancedBaseScore = _voreModDevourScore(_winnerRole)
	addAction("vore_loser", "Devour", "Why beat them when you could just eat them?", VOREMOD_BALANCE_SCORETYPE, 1.0, 60, {})
	return true
const PERK_IRRESISTIBLE_PREY = "VoreIrresistiblePrey"
func _preyHasPerk(_perkID:String) -> bool:
	if(GM.pc == null):
		return false
	if(GM.pc.has_method("getSkillsHolder")):
		var holder = GM.pc.getSkillsHolder()
		if(holder != null && holder.has_method("hasPerk") && holder.hasPerk(_perkID)):
			return true
	if(GM.pc.has_method("hasPerk") && GM.pc.hasPerk(_perkID)):
		return true
	return false
func _preyIsIrresistible() -> bool:
	return _preyHasPerk(PERK_IRRESISTIBLE_PREY)
func _preyHasLureScent() -> bool:
	if(GM.pc == null):
		return false
	return GM.pc.hasEffect("VoreLureScent")
func _preyVoreLike(ch) -> float:
	if(ch == null):
		return 0.0
	var fh = ch.getFetishHolder()
	if(fh == null):
		return 0.0
	return fh.getFetishValue("Vore")
