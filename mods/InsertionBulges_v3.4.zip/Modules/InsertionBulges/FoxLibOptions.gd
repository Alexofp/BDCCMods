const Boot := preload("res://Modules/InsertionBulges/Boot.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const T_BOOL := "boolean"
const T_PERCENT := "slider"
const T_CHOICE := "choice"
const T_BUTTON := "button"
const CAT_MAIN := "Insertion Bulges"
const CAT_SHAPE := "Insertion Bulges: Shape"
const CAT_MOTION := "Insertion Bulges: Movement"
const CAT_MORE := "Insertion Bulges: Two cocks and belly"
const CAT_THROAT := "Insertion Bulges: Mouth and throat"
const CATEGORIES := [CAT_MAIN, CAT_SHAPE, CAT_MOTION, CAT_MORE, CAT_THROAT]
const RESTORE_ID := "bulgeRestoreDefaults"
const ORAL_OWN_ID := "bulgeOralOwn"
const OPTIONS := [
{
	"id": "bulgesEnabled", "cat": CAT_MAIN, "type": T_BOOL, "advanced": false,
	"title": "Show bulges",
	"desc": "The body swells where a cock is inside it, and the part inside is hidden. Off turns the" \
		+ " whole mod off. More options: turn on \"Show advanced mod options\" at the top of this screen.",
},
{
	"id": "bulgeSizeModifier", "cat": CAT_MAIN, "type": T_PERCENT, "advanced": false,
	"title": "Bulge size",
	"desc": "How big bulges are, everywhere but the throat. 0% hides them. Recommended: 60%.",
},
{
	"id": "bulgeThroatPath", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["neck", "Simple"], ["body", "Detailed"]],
	"title": "Throat bulge",
	"desc": "Simple: the neck swells in one piece. Detailed: you see the cock go down the throat, with" \
		+ " its shape, as deep as it goes. Recommended: Simple.",
},
{
	"id": "bulgeLag", "cat": CAT_MAIN, "type": T_BOOL, "advanced": false,
	"title": "Soft motion",
	"desc": "Bulges swell, settle and wobble like flesh instead of jumping. Recommended: on.",
},
{
	"id": "bulgeBellyVariant", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["swell", "Belly swells"], ["off", "Off"]],
	"title": "Pregnant belly",
	"desc": "For a pregnant or cum-filled belly. Belly swells (recommended): each thrust swells the" \
		+ " whole belly, and the bulge shows where the belly starts and past it; the bigger the belly," \
		+ " the more it swells as a whole. Off: no change.",
},
{
	"id": "bulgePipeline", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["brush", "Detailed"], ["classic", "Simple"]],
	"title": "Drawing quality",
	"desc": "Detailed: the bulge copies the cock's outline. Simple: a smooth bulge, for old graphics" \
		+ " cards. If your card cannot draw Detailed, Simple is used on its own.",
},
{
	"id": RESTORE_ID, "cat": CAT_MAIN, "type": T_BUTTON, "advanced": false,
	"title": "Restore recommended settings",
	"desc": "Puts every Insertion Bulges option back to its recommended value. Other mods are not" \
		+ " touched. Reopen this screen to see the change.",
},
{
	"id": "bulgeShapeFidelity", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Cock shape",
	"desc": "0%: a smooth, round bulge. 100%: the real outline of the cock, with knot, flare and head.",
},
{
	"id": "bulgeOtherHalfAdd", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Knots and ridges",
	"desc": "Makes knots and ridges stand out more on the bulge.",
},
{
	"id": "bulgeOtherHalfFollow", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Copy the underside",
	"desc": "A cock's top and underside differ. 0% uses a mix of both; 100% copies the underside bump" \
		+ " for bump.",
},
{
	"id": "bulgeTipRound", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Soft end at the tip",
	"desc": "0%: the bulge stays full right to the tip. 100%: it fades out from the middle.",
},
{
	"id": "bulgeLipAmount", "cat": CAT_SHAPE, "type": T_PERCENT, "advanced": true,
	"title": "Opening at the hole",
	"desc": "The skin round the hole opens around the cock and is pulled out with it. 0% is off." \
		+ " Detailed drawing only.",
},
{
	"id": "bulgeDirection", "cat": CAT_SHAPE, "type": T_CHOICE, "advanced": true,
	"values": [["blend", "Between hole and cock"], ["shaft", "Along the cock"],
		["belly", "Along the belly"], ["torso", "Along the body"]],
	"title": "Bulge direction",
	"desc": "Which way the bulge runs in the body: along the cock, along the belly, straight up the" \
		+ " body, or between the hole and the cock (recommended).",
},
{
	"id": "bulgeWarp", "cat": CAT_SHAPE, "type": T_CHOICE, "advanced": true,
	"values": [["mesh", "Mesh"], ["flow", "Flow"], ["original", "Size limit"], ["stretch", "Stretch"],
		["bones", "Bones"]],
	"title": "Big bulges",
	"desc": "How a big cock's bulge grows. Mesh (recommended): the body's outline itself moves, as big" \
		+ " as the cock, and never folds. Flow: the skin flows outward, up to the room round the body." \
		+ " Size limit: stops at a fixed size, as in older versions. Stretch: like Flow, stretched from" \
		+ " the back. Bones: the belly and chest grow instead. Mesh, Flow and Stretch need Detailed drawing.",
},
{
	"id": "bulgeLagInflate", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Swell speed",
	"desc": "How fast a bulge grows. Everything here needs Soft motion on.",
},
{
	"id": "bulgeLagDeflate", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Settle speed",
	"desc": "How fast a bulge goes down. Lower lets it linger after a pose change.",
},
{
	"id": "bulgeLagWobble", "cat": CAT_MOTION, "type": T_PERCENT, "advanced": true,
	"title": "Wobble",
	"desc": "How much the flesh jiggles before it settles. 0% is none.",
},
{
	"id": "bulgeUnionOverlap", "cat": CAT_MORE, "type": T_PERCENT, "advanced": true,
	"title": "Merge two bulges",
	"desc": "With two cocks inside: 0% keeps two bulges, 100% makes them one.",
},
{
	"id": "bulgeBellyGain", "cat": CAT_MORE, "type": T_PERCENT, "advanced": true,
	"title": "Belly push",
	"desc": "How far each thrust pushes a pregnant belly. Needs Pregnant belly set to a \"Belly grows\"" \
		+ " choice.",
},
{
	"id": "bulgeTorsoArch", "cat": CAT_MORE, "type": T_PERCENT, "advanced": true,
	"title": "Torso stretch",
	"desc": "A cock longer than the body: its extra length bunches up and the bulge swells in an arch," \
		+ " most in the middle. 0% is off: the bulge just stops at the chest.",
},
{
	"id": "bulgeTorsoSwell", "cat": CAT_MORE, "type": T_BOOL, "advanced": true,
	"title": "Torso swells",
	"desc": "A cock longer than the body: the belly and the chest swell too as its extra length pushes" 		+ " in. Recommended: on.",
},
{
	"id": "bulgeOralSimpleSize", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true,
	"title": "Simple throat size",
	"desc": "How big the Simple throat bulge is. 0% hides it.",
},
{
	"id": "bulgeOralSize", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true,
	"title": "Detailed throat size",
	"desc": "How big the Detailed throat bulge is. 0% hides it.",
},
{
	"id": "bulgeOralMouthLength", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true,
	"title": "Mouth depth",
	"desc": "Detailed throat: how far the cock goes straight into the mouth before it turns down the" \
		+ " throat.",
},
{
	"id": "bulgeOralThroatStretch", "cat": CAT_THROAT, "type": T_BOOL, "advanced": true,
	"title": "Throat opens around the cock",
	"desc": "Detailed throat: the top of the throat widens as a knot or a thick tip passes, then" \
		+ " settles. Detailed drawing only.",
},
{
	"id": "bulgeOralSwallow", "cat": CAT_THROAT, "type": T_BOOL, "advanced": true,
	"title": "Swallowing",
	"desc": "Detailed throat: while the cock rests deep, the throat gives a small swallow every few" \
		+ " seconds. Off by default.",
},
{
	"id": ORAL_OWN_ID, "cat": CAT_THROAT, "type": T_BOOL, "advanced": true,
	"title": "Throat uses its own settings",
	"desc": "Off: the Detailed throat uses the Shape and Movement settings. On: it gets its own; close" \
		+ " and reopen this screen to see them.",
},
{
	"id": "bulgeOralShapeFidelity", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: cock shape",
	"desc": "Like \"Cock shape\", for the Detailed throat.",
},
{
	"id": "bulgeOralOtherHalfAdd", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: knots and ridges",
	"desc": "Like \"Knots and ridges\", for the Detailed throat.",
},
{
	"id": "bulgeOralOtherHalfFollow", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: copy the underside",
	"desc": "Like \"Copy the underside\", for the Detailed throat.",
},
{
	"id": "bulgeOralTipRound", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: soft end at the tip",
	"desc": "Like \"Soft end at the tip\", for the Detailed throat.",
},
{
	"id": "bulgeOralLagInflate", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: swell speed",
	"desc": "Like \"Swell speed\", for the throat.",
},
{
	"id": "bulgeOralLagDeflate", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: settle speed",
	"desc": "Like \"Settle speed\", for the throat.",
},
{
	"id": "bulgeOralLagWobble", "cat": CAT_THROAT, "type": T_PERCENT, "advanced": true, "twin": true,
	"title": "Throat: wobble",
	"desc": "Like \"Wobble\", for the throat.",
},
]
static func shipped(row:Dictionary):
	return Settings.compiled(str(row["id"]))
static func percentOf(row:Dictionary) -> int:
	return int(round(float(shipped(row)) * 100.0))
static func settingFor(row:Dictionary) -> String:
	if(str(row["type"]) == T_BUTTON || Settings.declaration(str(row["id"])) == null):
		return ""
	return str(row["id"])
static func rowFor(name:String) -> Dictionary:
	for row in OPTIONS:
		if(settingFor(row) == name):
			return row
	return {}
static func decode(row:Dictionary, raw):
	if(str(row["type"]) != T_PERCENT):
		return raw
	if(typeof(raw) != TYPE_INT && typeof(raw) != TYPE_REAL):
		return raw
	return float(raw) / 100.0
static func encode(row:Dictionary, given):
	if(str(row["type"]) != T_PERCENT):
		return given
	if(typeof(given) != TYPE_INT && typeof(given) != TYPE_REAL):
		return given
	return int(round(float(given) * 100.0))
const MANAGER_PATH := "res://Modules/FoxLib/Internal/FoxOptionsManager.gd"
const SECTION := Boot.MARKER_MOD
const STORE_LABEL := "FoxLib's mod options (section " + SECTION + " of user://foxlib/mod_options.cfg)"
const ABSENT := "insertionbulges-v3-no-such-foxlib-key"
const CACHE := {"looked": false, "manager": null}
static func manager():
	if(!CACHE["looked"]):
		CACHE["looked"] = true
		if(ResourceLoader.exists(MANAGER_PATH)):
			CACHE["manager"] = load(MANAGER_PATH)
	return CACHE["manager"]
static func live() -> bool:
	return manager() != null
static func storeLabel() -> String:
	return STORE_LABEL
static func forget() -> void:
	CACHE["looked"] = false
	CACHE["manager"] = null
static func stored(mgr = manager()) -> Dictionary:
	var out:Dictionary = {}
	if(mgr == null):
		return out
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name == ""):
			continue
		var raw = mgr.getOption(SECTION, str(row["id"]), ABSENT)
		if(typeof(raw) == TYPE_STRING && str(raw) == ABSENT):
			continue
		var vetted:Array = Settings.vetSetting(name, decode(row, raw))
		if(!vetted[0].empty()):
			Boot.loud("FoxLibOptions: " + STORE_LABEL + " holds '" + str(row["id"]) + "' = " \
				+ str(raw) + ", which this build cannot use - " \
				+ PoolStringArray(vetted[0]).join("; ") + ". THAT ONE SETTING IS IGNORED this run" \
				+ " and falls back to the bench or the compiled default; every other setting is" \
				+ " unaffected. Reset that option in FoxLib's mod options screen.")
			continue
		out[name] = vetted[1]
	return out
static func store(name:String, given, mgr = manager()) -> bool:
	if(mgr == null):
		Boot.loud("FoxLibOptions: asked to store '" + name + "' with FoxLib not installed. Nothing" \
			+ " written. This is a bug in the caller: Settings.store() must route to its own file" \
			+ " when FoxLib is absent.")
		return false
	var row:Dictionary = rowFor(name)
	if(row.empty()):
		Boot.loud("FoxLibOptions: '" + name + "' is not on FoxLib's options screen, so there is" \
			+ " nowhere in " + STORE_LABEL + " to put it. NOTHING WRITTEN and the value is NOT" \
			+ " saved. Add a row for it in FoxLibOptions.OPTIONS, or set it through the Bench.")
		return false
	mgr.setOption(SECTION, str(row["id"]), encode(row, given))
	mgr.optionalySave()
	return true
static func clear(name:String, mgr = manager()) -> bool:
	if(mgr == null || rowFor(name).empty()):
		return false
	mgr.clearOption(SECTION, str(rowFor(name)["id"]))
	mgr.optionalySave()
	return true
static func restoreDefaults(mgr = manager()) -> int:
	var cleared := 0
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name != "" && clear(name, mgr)):
			cleared += 1
	Boot.say("InsertionBulges v3: " + str(cleared) + " option(s) back to the recommended settings.")
	return cleared
const TWIN_ROWS := {}
static func showTwins(on:bool) -> void:
	for id in TWIN_ROWS:
		var made = TWIN_ROWS[id]
		if(on):
			made.enable = made.OPTION_ENABLE_ALWAYS
		else:
			made.enable = made.OPTION_HIDDEN
static func onOralOwn(on) -> void:
	showTwins(bool(on))
static func declare(api, host = null) -> Array:
	var ids:Array = []
	if(api == null):
		Boot.loud("FoxLibOptions: FoxLib called onFoxLibModInit with no API object. NO OPTION IS" \
			+ " REGISTERED and the mod has no menu this run; it still draws.")
		return ids
	for row in OPTIONS:
		var id:String = str(row["id"])
		var cat:String = str(row["cat"])
		var kind:String = str(row["type"])
		var made = null
		if(kind == T_BOOL):
			made = api.addBooleanOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				bool(shipped(row)))
		elif(kind == T_PERCENT):
			made = api.addSliderOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				percentOf(row))
		elif(kind == T_CHOICE):
			made = api.addListOptionInCategory(cat, id, str(row["title"]), row["values"],
				str(row["desc"]), str(shipped(row)))
		elif(kind == T_BUTTON):
			made = api.addButtonOptionInCategory(cat, id, str(row["title"]), str(row["desc"]))
			if(made != null && host != null && made.has_signal("option_changed")):
				made.connect("option_changed", host, "onRestoreDefaults")
		if(made == null):
			Boot.loud("FoxLibOptions: FoxLib answered nothing for option '" + id + "', so that one" \
				+ " row is not on the screen. The rest are. This is a FoxLib API change - re-read" \
				+ " FoxLib/FoxModuleAPI.gd.")
			continue
		if(bool(row.get("advanced", false))):
			made = made.advanced()
		if(bool(row.get("twin", false))):
			var twins:Dictionary = TWIN_ROWS
			twins[id] = made
		if(id == ORAL_OWN_ID && host != null && made.has_signal("option_changed")):
			made.connect("option_changed", host, "onOralOwnChanged")
		ids.append(id)
	showTwins(bool(Settings.value(ORAL_OWN_ID)))
	return ids
