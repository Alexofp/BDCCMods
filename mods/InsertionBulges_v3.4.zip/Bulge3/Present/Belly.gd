extends Reference
const Intent := preload("res://Bulge3/Stage/Intent.gd")
const FieldMath := preload("res://Bulge3/Present/Field.gd")
const BulgeUtils := preload("res://Bulge3/Doll/BulgeUtils.gd")
const VARIANT_OFF := "off"
const VARIANT_FADE := "fade"
const VARIANT_BONE := "bone"
const VARIANT_BLEND := "blend"
const VARIANT_SWELL := "swell"
const VARIANTS := [VARIANT_OFF, VARIANT_SWELL, VARIANT_FADE, VARIANT_BONE, VARIANT_BLEND]
const BONE := "DeformBelly"
const RISE := 0.706324
const P_FULL := 2.0
const META_GAME := "bdccBulge3Belly"
const TUNING := {"gain": 2.0}
const TORSO := {"on": false}
const BELLY_PER_ARCH := 1.0
const CHEST_PER_ARCH := 0.3
const CHEST_BONE := "DeformBreasts"
const META_CHEST := "bdccBulge3Chest"
static func torsoOn() -> bool:
	return bool(TORSO["on"])
const BULK_TO_ARCH := 2.0
static func bulkOn() -> bool:
	return FieldMath.warpMode() == FieldMath.WARP_BONES
static func gain() -> float:
	return float(TUNING["gain"])
static func skeletonOf(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll) || !theDoll.has_method("getDollSkeleton")):
		return null
	var holder = theDoll.getDollSkeleton()
	if(holder == null):
		return null
	return holder.getSkeleton()
static func decode(pose:Transform) -> float:
	var wide:float = pose.basis.get_scale().y
	if(wide > 1.0001):
		return wide
	return pose.origin.y / RISE
static func poseOf(theDoll):
	var skeleton = skeletonOf(theDoll)
	if(skeleton == null):
		return null
	var bone:int = skeleton.find_bone(BONE)
	if(bone < 0):
		return null
	return skeleton.get_bone_custom_pose(bone)
static func pregnancyOf(theDoll) -> float:
	var pose = poseOf(theDoll)
	if(pose == null):
		return 0.0
	if(theDoll.has_meta(META_GAME)):
		var had:Dictionary = theDoll.get_meta(META_GAME)
		if(pose.is_equal_approx(had["wrote"])):
			return float(had["p"])
	return decode(pose)
static func heatOf(p:float) -> float:
	return clamp(p / P_FULL, 0.0, 1.0)
const SWELL_GAIN := 1.5
const EDGE := 0.15
static func shareOf(p:float) -> float:
	return smoothstep(0.0, P_FULL, p)
static func insideAt(y:float, extent:Vector2) -> float:
	var e:float = max(EDGE * (extent.y - extent.x), 0.0001)
	return smoothstep(extent.x - e, extent.x + e, y) * (1.0 - smoothstep(extent.y - e, extent.y + e, y))
static func bandY(intent:Dictionary, i:int, n:int) -> float:
	var u:float = 0.5
	if(n > 1):
		u = float(i) / float(n - 1)
	var centre:Vector3 = intent["centre_rest"]
	var dir:Vector3 = intent["travel_dir_rest"]
	return centre.y + dir.y * (u - 0.5) * 2.0 * float(intent["column_half"])
static func masked(intent:Dictionary, extent:Vector2, share:float) -> Array:
	var shape:Array = []
	if(typeof(intent.get("shape")) == TYPE_ARRAY):
		shape = intent["shape"]
	if(shape.size() < 2):
		return [shape, insideAt(bandY(intent, 0, 1), extent)]
	var out:Array = []
	var total:float = 0.0
	var inside:float = 0.0
	for i in range(shape.size()):
		var here:float = insideAt(bandY(intent, i, shape.size()), extent)
		out.append(float(shape[i]) * (1.0 - share * here))
		total += float(shape[i])
		inside += float(shape[i]) * here
	if(total <= 0.0):
		return [out, 0.0]
	return [out, inside / total]
static func extentFor(eyes, owner:String):
	var helper = eyes.helperFor(owner)
	if(helper == null):
		return null
	for themesh in helper.getBulgeMeshesForZone(Intent.HOLE_VAGINA):
		var extent = BulgeUtils.bellyExtent(themesh, skeletonOf(eyes.dollFor(owner)), BONE)
		if(extent != null):
			return extent
	return null
static func apply(entries:Array, eyes, variant:String) -> void:
	var pushed:Dictionary = {}
	var torso:Dictionary = {}
	var heatByOwner:Dictionary = {}
	var extentByOwner:Dictionary = {}
	for entry in entries:
		if(typeof(entry) != TYPE_DICTIONARY || typeof(entry.get("intent")) != TYPE_DICTIONARY \
				|| typeof(entry.get("engagement")) != TYPE_DICTIONARY):
			continue
		var engagement:Dictionary = entry["engagement"]
		if(str(engagement.get("hole")) == Intent.HOLE_MOUTH):
			continue
		var owner:String = str(engagement.get("hole_owner"))
		if(!heatByOwner.has(owner)):
			heatByOwner[owner] = shareOf(pregnancyOf(eyes.dollFor(owner)))
		var heat:float = heatByOwner[owner]
		var arch:float = float(entry["intent"].get("arch", 0.0))
		if(torsoOn() && arch > 0.0):
			torso[owner] = max(float(torso.get(owner, 0.0)), arch)
		var bulk:float = float(entry["intent"].get("bulk", 0.0)) * BULK_TO_ARCH
		if(bulkOn() && bulk > 0.0):
			torso[owner] = max(float(torso.get(owner, 0.0)), bulk)
		if(heat <= 0.0 || variant == VARIANT_OFF):
			continue
		if(!extentByOwner.has(owner)):
			extentByOwner[owner] = extentFor(eyes, owner)
		if(extentByOwner[owner] == null):
			continue
		var amplitude:float = float(entry["intent"]["amplitude"])
		var made:Array = masked(entry["intent"], extentByOwner[owner], heat)
		var reshaped:Dictionary = entry["intent"].duplicate()
		reshaped["shape"] = made[0]
		entry["intent"] = reshaped
		pushed[owner] = max(float(pushed.get(owner, 0.0)), gain() * SWELL_GAIN * amplitude * float(made[1]) * heat)
	for owner in eyes.byID:
		var theDoll = eyes.dollFor(owner)
		if(theDoll == null):
			continue
		if(torso.has(owner)):
			pushed[owner] = float(pushed.get(owner, 0.0)) + BELLY_PER_ARCH * float(torso[owner])
			swellChest(theDoll, 1.0 + CHEST_PER_ARCH * float(torso[owner]))
		elif(theDoll.has_meta(META_CHEST)):
			restoreChest(theDoll)
		if(pushed.has(owner)):
			push(theDoll, float(pushed[owner]))
		elif(theDoll.has_meta(META_GAME)):
			restore(theDoll)
static func release(eyes) -> void:
	for owner in eyes.byID:
		var theDoll = eyes.dollFor(owner)
		if(theDoll != null && theDoll.has_meta(META_GAME)):
			restore(theDoll)
		if(theDoll != null && theDoll.has_meta(META_CHEST)):
			restoreChest(theDoll)
static func push(theDoll, extra:float) -> void:
	var p:float = pregnancyOf(theDoll)
	theDoll.setPregnancy(p + extra)
	theDoll.set_meta(META_GAME, {"p": p, "wrote": poseOf(theDoll)})
static func restore(theDoll) -> void:
	var had:Dictionary = theDoll.get_meta(META_GAME)
	theDoll.remove_meta(META_GAME)
	var pose = poseOf(theDoll)
	if(pose != null && pose.is_equal_approx(had["wrote"])):
		theDoll.setPregnancy(float(had["p"]))
static func swellChest(theDoll, factor:float) -> void:
	var skeleton = skeletonOf(theDoll)
	if(skeleton == null):
		return
	var bone:int = skeleton.find_bone(CHEST_BONE)
	if(bone < 0):
		return
	var now:Transform = skeleton.get_bone_custom_pose(bone)
	var base:Transform = now
	if(theDoll.has_meta(META_CHEST)):
		var had:Dictionary = theDoll.get_meta(META_CHEST)
		if(now.is_equal_approx(had["wrote"])):
			base = had["game"]
	var wrote := Transform(base.basis.scaled(Vector3(factor, factor, factor)), base.origin)
	skeleton.set_bone_custom_pose(bone, wrote)
	theDoll.set_meta(META_CHEST, {"game": base, "wrote": wrote})
static func restoreChest(theDoll) -> void:
	var had:Dictionary = theDoll.get_meta(META_CHEST)
	theDoll.remove_meta(META_CHEST)
	var skeleton = skeletonOf(theDoll)
	if(skeleton == null):
		return
	var bone:int = skeleton.find_bone(CHEST_BONE)
	if(bone >= 0 && skeleton.get_bone_custom_pose(bone).is_equal_approx(had["wrote"])):
		skeleton.set_bone_custom_pose(bone, had["game"])
