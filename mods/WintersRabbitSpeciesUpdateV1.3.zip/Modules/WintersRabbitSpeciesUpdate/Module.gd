extends Module

var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")

func _init():
	id = "WintersRabbitSpeciesUpdate"
	author = "Code: Fantos Idea/Graphics: Max-Maxou"

	bodyparts = [
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitEars1.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitEars2.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitEars3.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitHead.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitLegs.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitTail1.gd",
		"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Bodyparts/RabbitTail2.gd",
	]

	if (RAT_ArchetypeLoad == false):
		species = [
			"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/RabbitFluffy.gd"
		]
	else:
		species = [
			"res://Modules/WintersRabbitSpeciesUpdate/RabbitSpecies/Rabbit.gd"
		]

func getAddedRatArchetypes() -> Dictionary:
	var pathDir = "res://Modules/WintersFluffyBodyparts/CompatibilityPatches/RAT_BodypartArchetypes/"
	
	return {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)
	"rabbit": [pathDir+"ClawlessArchetypes.json"],
	}
