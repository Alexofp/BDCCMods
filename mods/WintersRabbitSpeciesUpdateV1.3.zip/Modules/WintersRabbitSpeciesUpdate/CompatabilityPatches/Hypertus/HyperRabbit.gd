extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "rabbit"

func isPlayable():
	return true

func getVisibleName():
	return "Rabbit"

func getVisibleDescription():
	return "Bunbun"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "flufflegsclawless"
	return "digilegs"

func getDefaultArms(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return "fluffarms"
	return "anthroarms"

func getDefaultTail(_gender):
	return "rabbittail1"

func getDefaultHead(_gender):
	return "rabbithead"

func getDefaultEars(_gender):
	return "rabbitears1"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "ovipositorpenishyperable"
	else:
		return null

func getDefaultVagina(_gender):
	if(_gender in [Gender.Female, Gender.Androgynous]):
		return "vaginaEggshyperable"
	else:
		return null

func getDefaultBreasts(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"
	else:
		if(_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 7.0],
		[3, 6.0],
		[4, 4.0],
		[5, 3.0],
		[6, 2.0],
		[7, 1.5],
	]
