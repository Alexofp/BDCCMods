extends Module

func _init():
	id = "ModManager"
	author = "Neith"

func postInit():
	var tree = Engine.get_main_loop()
	load("res://Modules/ModManager/Versions.gd").service(tree)
	if not tree.root.has_node("ModManagerIntegration"):
		var integration = load("res://Modules/ModManager/MenuIntegration.gd").new()
		integration.name = "ModManagerIntegration"
		tree.root.add_child(integration)
