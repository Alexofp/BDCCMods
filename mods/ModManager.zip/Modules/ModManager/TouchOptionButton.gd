extends OptionButton

const DRAG_DISTANCE = 10.0
var finger = -1
var origin = Vector2()
var guarded = false
var popup_state = []

func _ready():
	configure_scroll(get_popup())

func configure_scroll(node):
	if node is ScrollContainer:
		node.scroll_deadzone = max(node.scroll_deadzone, int(DRAG_DISTANCE))
		return
	for child in node.get_children():
		configure_scroll(child)

func guard_selection():
	if guarded:
		return
	var popup = get_popup()
	popup_state = [popup.is_blocking_signals(), popup.hide_on_item_selection, popup.hide_on_checkable_item_selection, popup.hide_on_state_item_selection]
	guarded = true
	# Let the native scroll container receive release events, but never activate a row.
	popup.set_block_signals(true)
	popup.hide_on_item_selection = false
	popup.hide_on_checkable_item_selection = false
	popup.hide_on_state_item_selection = false

func restore_selection():
	if not guarded:
		return
	var popup = get_popup()
	popup.set_block_signals(popup_state[0])
	popup.hide_on_item_selection = popup_state[1]
	popup.hide_on_checkable_item_selection = popup_state[2]
	popup.hide_on_state_item_selection = popup_state[3]
	guarded = false
	if not popup.visible:
		set_pressed(false)

func _input(event):
	# A new press or keyboard action is a new intent. A delayed emulated release is not.
	if (event is InputEventMouseButton and event.pressed and finger == -1) or (event is InputEventKey and event.pressed):
		restore_selection()
	if event is InputEventScreenTouch:
		if event.pressed and finger == -1:
			var popup = get_popup()
			if is_visible_in_tree() and ((popup.visible and popup.get_global_rect().has_point(event.position)) or get_global_rect().has_point(event.position)):
				restore_selection()
				finger = event.index
				origin = event.position
		elif not event.pressed and event.index == finger:
			finger = -1
			# Keep guarding until a fresh press, including any later compatibility mouse-up.
	elif event is InputEventScreenDrag and event.index == finger:
		if event.position.distance_to(origin) > DRAG_DISTANCE:
			guard_selection()

func _notification(what):
	if what == NOTIFICATION_WM_FOCUS_OUT or (what == NOTIFICATION_VISIBILITY_CHANGED and not is_visible_in_tree()):
		finger = -1
		restore_selection()
