extends Node

signal changed

const Links = preload("res://Modules/ModManager/ContentLinks.gd")
var cache = {}
var request:HTTPRequest
var queue = []
var active_url = ""
var urls = []
var errors = {}

func _ready():
	request = HTTPRequest.new()
	request.timeout = 25
	request.body_size_limit = 16*1024*1024
	request.connect("request_completed", self, "received")
	add_child(request)

func set_description(text):
	request.cancel_request()
	queue.clear()
	active_url = ""
	urls.clear()
	errors.clear()
	for url in Links.urls(text):
		if Links.is_image(url):
			add_url(url)
	load_next()

func add_url(url):
	if url in urls:
		return
	urls.append(url)
	if not cache.has(url):
		queue.append(url)

func load_next():
	if not active_url.empty() or queue.empty():
		return
	active_url = queue.pop_front()
	if cache.has(active_url):
		active_url = ""
		call_deferred("load_next")
		return
	var error = request.request(active_url)
	if error != OK:
		failed("Request error: "+str(error))

func failed(message):
	errors[active_url] = message
	active_url = ""
	emit_signal("changed")
	call_deferred("load_next")

func received(result, code, _headers, body):
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		failed("Image unavailable: HTTP "+str(code))
		return
	var image = Image.new()
	var error = ERR_FILE_UNRECOGNIZED
	if body.size() >= 8 and Array(body.subarray(0, 7)) == [137, 80, 78, 71, 13, 10, 26, 10]:
		error = image.load_png_from_buffer(body)
	elif body.size() >= 2 and body[0] == 255 and body[1] == 216:
		error = image.load_jpg_from_buffer(body)
	elif body.size() >= 12 and body.subarray(0, 3).get_string_from_ascii() == "RIFF" and body.subarray(8, 11).get_string_from_ascii() == "WEBP":
		error = image.load_webp_from_buffer(body)
	if error != OK or image.get_width() > 8192 or image.get_height() > 8192:
		failed("Unsupported image")
		return
	if image.get_width() > 1600 or image.get_height() > 1600:
		var scale = 1600.0/max(image.get_width(), image.get_height())
		image.resize(int(image.get_width()*scale), int(image.get_height()*scale), Image.INTERPOLATE_LANCZOS)
	show_image(active_url, image)
	active_url = ""
	call_deferred("load_next")

func show_image(url, image):
	var texture = ImageTexture.new()
	texture.create_from_image(image)
	cache[url] = texture
	emit_signal("changed")

func open_image(url):
	if errors.has(url):
		errors.erase(url)
		urls.erase(url)
	add_url(url)
	load_next()
