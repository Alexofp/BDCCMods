extends Tree

var manager
var insertion_visible = false
var insertion_rect = Rect2()
var insertion_y = 0.0
var name_width = 0.0
var hover_visible = false
var hover_rect = Rect2()
var vertical_scroll:VScrollBar
const BORDER_COLOR = Color("d7f0ff")
const SCROLL_EDGE = 48.0
const SCROLL_SPEED = 576.0

func _ready():
	set_drop_mode_flags(Tree.DROP_MODE_INBETWEEN)
	# Handle our own drag scrolling so leaving the window does not stop it.
	add_constant_override("scroll_speed", 0)
	for child in get_children():
		if child is VScrollBar:
			vertical_scroll = child
	# Draw our own uniform row borders instead of theme-specific cursor/button frames.
	for style in ["cursor", "cursor_unfocused", "custom_button", "custom_button_hover", "custom_button_pressed"]:
		add_stylebox_override(style, StyleBoxEmpty.new())
	var selection = StyleBoxEmpty.new()
	add_stylebox_override("selected", selection)
	add_stylebox_override("selected_focus", selection)
	add_color_override("drop_position_color", Color(0, 0, 0, 0))
	connect("resized", self, "schedule_name_layout")

func schedule_name_layout():
	call_deferred("layout_names")

func _process(delta):
	# The vertical scrollbar can change column width without resizing the tree.
	var row = get_root().get_children() if get_root() != null else null
	if row != null and get_item_area_rect(row, 2).size.x != name_width:
		layout_names()
	var position = get_local_mouse_position()
	update_hover(position)
	if get_viewport().gui_is_dragging():
		scroll_drag(position, get_viewport().gui_get_drag_data(), delta)
		# Scrolling can move the target under a stationary pointer without a new can_drop_data call.
		can_drop_data(position, get_viewport().gui_get_drag_data())
	elif insertion_visible:
		insertion_visible = false
		update()

func scroll_drag(position, data, delta):
	if not is_visible_in_tree() or vertical_scroll == null or not manager.order_valid or not data is Dictionary or data.get("origin") != self or not data.get("path") is String:
		return
	var top = get_stylebox("bg").get_margin(MARGIN_TOP)+get_font("font").get_height()+2*get_constant("vseparation")
	var bottom = rect_size.y-get_stylebox("bg").get_margin(MARGIN_BOTTOM)
	var speed = 0.0
	if position.y < top+SCROLL_EDGE:
		speed = (position.y-top-SCROLL_EDGE)/SCROLL_EDGE
	elif position.y > bottom-SCROLL_EDGE:
		speed = (position.y-bottom+SCROLL_EDGE)/SCROLL_EDGE
	vertical_scroll.value += speed*SCROLL_SPEED*delta

func row_bounds(row):
	var area = get_item_area_rect(row)
	area.position.x = get_stylebox("bg").get_margin(MARGIN_LEFT)
	area.size.x = min(area.size.x, rect_size.x-get_stylebox("bg").get_margin(MARGIN_RIGHT)-area.position.x)
	area.position.y += get_stylebox("bg").get_margin(MARGIN_TOP)-get_scroll().y
	area.size.y += get_constant("vseparation")
	return area

func update_hover(position):
	var row = get_item_at_position(position) if is_visible_in_tree() and Rect2(Vector2.ZERO, rect_size).has_point(position) else null
	var valid_hover = row != null
	var area = row_bounds(row) if valid_hover else Rect2()
	if valid_hover != hover_visible or area != hover_rect:
		hover_visible = valid_hover
		hover_rect = area
		update()

func layout_names():
	var row = get_root().get_children() if get_root() != null else null
	if row == null:
		return
	name_width = get_item_area_rect(row, 2).size.x
	var width = name_width-8
	if width < 32:
		return
	var font = get_font("font")
	while row != null:
		var data = row.get_metadata(2)
		var lines = []
		var line = ""
		for character in data.text:
			if not line.empty() and font.get_string_size(line+character).x > width:
				lines.append(line)
				line = ""
			line += character
		lines.append(line)
		data.lines = lines
		row.set_metadata(2, data)
		row.set_custom_minimum_height(int(ceil(lines.size()*font.get_height())))
		row = row.get_next()
	update()

func draw_mod_name(row, rect):
	var font = get_font("font")
	var lines = row.get_metadata(2).lines
	var y = rect.position.y+max(0, (rect.size.y-lines.size()*font.get_height())/2)+font.get_ascent()
	var color = get_color("font_color_selected" if row.is_selected(2) else "font_color")
	if row.get_metadata(2).get("state") in ["Update required", "Incompatible update", "Version unknown"]:
		color = Color("ffe0a0")
	elif row.get_metadata(2).get("state") == "Restart to update":
		color = BORDER_COLOR
	for line in lines:
		draw_string(font, Vector2(rect.position.x+4, y), line, color)
		y += font.get_height()

func get_drag_data(position):
	set_drop_mode_flags(Tree.DROP_MODE_INBETWEEN)
	var row = get_item_at_position(position)
	if row == null or not manager.order_valid:
		return null
	var entry = manager.entries[row.get_metadata(0)]
	if entry.path.get_file() == "BDCC.pck":
		return null
	var preview = Label.new()
	preview.text = entry.path.get_file()
	set_drag_preview(preview)
	return {"origin":self, "path":entry.path}

func can_drop_data(position, data):
	var valid = is_visible_in_tree() and Rect2(Vector2.ZERO, rect_size).has_point(position) and manager.order_valid and data is Dictionary and data.get("origin") == self and data.get("path") is String and get_item_at_position(position) != null
	insertion_visible = valid
	if valid:
		set_drop_mode_flags(Tree.DROP_MODE_INBETWEEN)
		var row = get_item_at_position(position)
		insertion_rect = row_bounds(row)
		insertion_y = insertion_rect.position.y
		if get_drop_section_at_position(position) > 0 or manager.entries[row.get_metadata(0)].path.get_file() == "BDCC.pck":
			insertion_y = insertion_rect.end.y
	update()
	return valid

func drop_data(position, data):
	if not can_drop_data(position, data):
		return
	var row = get_item_at_position(position)
	var target = int(row.get_metadata(0))
	if get_drop_section_at_position(position) > 0:
		target += 1
	insertion_visible = false
	update()
	manager.drop_entry(data.path, target)

func _notification(what):
	if what == NOTIFICATION_DRAG_END or what == NOTIFICATION_MOUSE_EXIT:
		insertion_visible = false
		hover_visible = false
		update()

func _draw():
	var selected = get_selected()
	if selected != null:
		var top = get_stylebox("bg").get_margin(MARGIN_TOP)+get_font("font").get_height()+2*get_constant("vseparation")
		var content = Rect2(Vector2(0, top), Vector2(rect_size.x, rect_size.y-top-get_stylebox("bg").get_margin(MARGIN_BOTTOM)))
		# Tint the whole row without changing the cell selection needed for priority editing.
		draw_rect(row_bounds(selected).clip(content), Color(0.84, 0.94, 1.0, 0.06))
	if insertion_visible:
		draw_bounds(insertion_rect, insertion_y)
	elif hover_visible:
		draw_bounds(hover_rect)

func draw_bounds(area, active_y = -1.0):
	var left = round(area.position.x+4)
	var right = round(area.end.x-4)
	var content_top = get_stylebox("bg").get_margin(MARGIN_TOP)+get_font("font").get_height()+2*get_constant("vseparation")
	for edge in [area.position.y, area.end.y]:
		var y = round(edge)+0.5
		if y < content_top or y >= rect_size.y-get_stylebox("bg").get_margin(MARGIN_BOTTOM):
			continue
		var color = BORDER_COLOR
		if active_y >= 0 and abs(edge-active_y) > 1:
			color.a = 0.5
		draw_line(Vector2(left, y), Vector2(right, y), color, 1)

func _gui_input(event):
	if event is InputEventMouseMotion:
		update_hover(event.position)
	elif event is InputEventMouseButton and event.pressed and event.button_index == BUTTON_LEFT and get_column_at_position(event.position) == 0:
		var row = get_item_at_position(event.position)
		if row != null:
			manager.toggle_entry(row.get_metadata(0))
			accept_event()
	elif event is InputEventKey and event.pressed and not event.echo and event.scancode == KEY_SPACE and get_selected_column() == 0 and get_selected() != null:
		manager.toggle_entry(get_selected().get_metadata(0))
		accept_event()
