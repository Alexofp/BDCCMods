extends Reference

static func sync_storage():
	# Include directory changes and native HTTP downloads in browser persistence.
	if OS.get_name() == "HTML5" and OS.has_feature("JavaScript"):
		JavaScript.force_fs_sync()

static func restart_message():
	if OS.get_name() == "HTML5":
		return "Reload the game page to apply changes."
	return "Restart the game to apply changes."

static func network_error():
	if OS.get_name() == "HTML5":
		return "The server may be unavailable or blocked by the browser's cross-origin policy."
	return ""

static func is_mod_path(path, mods_folder, platform):
	var folder = ProjectSettings.globalize_path(mods_folder).replace("\\", "/").simplify_path().trim_suffix("/")
	var absolute = ProjectSettings.globalize_path(path).replace("\\", "/").simplify_path()
	if platform == "Windows":
		folder = folder.to_lower()
		absolute = absolute.to_lower()
	return absolute.get_base_dir() == folder and absolute.get_file().get_extension().to_lower() in ["zip", "pck"] and absolute.get_file().to_lower() != "bdcc.pck"
