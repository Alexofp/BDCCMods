extends Node

# Archives are ordinary resource packs. Only the game's loader mounts them, on restart.
const STATE = "user://ModManager/versions.json"
const ORDER = "user://modOrder.json"
const Platform = preload("res://Modules/ModManager/Platform.gd")
const Links = preload("res://Modules/ModManager/ContentLinks.gd")
var archives = {}
var installed = {}
var valid = true
var disk_state = ""
var loaded_paths = []
var pending = {}
var message = ""

static func service(tree):
	if tree.root.has_node("ModManagerVersions"):
		return tree.root.get_node("ModManagerVersions")
	var node = load("res://Modules/ModManager/Versions.gd").new()
	node.name = "ModManagerVersions"
	tree.root.add_child(node)
	return node

static func canonical(path):
	var absolute = ProjectSettings.globalize_path(path).replace("\\", "/").simplify_path()
	return absolute.to_lower() if OS.get_name() == "Windows" else absolute

static func read_text(path):
	var file = File.new()
	if not file.file_exists(path):
		return ""
	if file.open(path, File.READ) != OK:
		return null
	var text = file.get_as_text()
	file.close()
	return text

static func read_order():
	var text = read_text(ORDER)
	if text == null:
		return null
	if text.empty():
		return []
	var parsed = JSON.parse(text)
	if parsed.error != OK or not parsed.result is Array:
		return null
	var seen = {}
	for entry in parsed.result:
		if not entry is Dictionary or not entry.get("path") is String or not entry.get("disabled") is bool or seen.has(canonical(entry.path)):
			return null
		seen[canonical(entry.path)] = true
	return parsed.result

func folder():
	return GlobalRegistry.getModsFolder().plus_file("ModManagerVersions")

func managed_shape(path):
	if not canonical(path).begins_with(canonical(folder())+"/"):
		return false
	var relative = canonical(path).trim_prefix(canonical(folder())+"/")
	var parts = relative.split("/")
	return parts.size() == 2 and parts[0].length() == 20 and parts[0].is_valid_hex_number() and parts[1].get_extension().to_lower() in ["zip", "pck"] and parts[1].to_lower() != "bdcc.pck"

func managed(path):
	return valid and archives.has(path) and managed_shape(path)

func _ready():
	disk_state = read_text(STATE)
	if disk_state == null:
		valid = false
	elif not disk_state.empty():
		var parsed = JSON.parse(disk_state)
		valid = parsed.error == OK and parsed.result is Dictionary and parsed.result.get("schema") == 1 and parsed.result.get("archives") is Dictionary
		if valid:
			archives = parsed.result.archives
			installed = parsed.result.get("installed", {}) if parsed.result.get("installed", {}) is Dictionary else {}
			valid = parsed.result.get("installed", {}) is Dictionary
			for path in installed:
				var receipt = installed[path]
				if not receipt is Dictionary or not receipt.get("version") is String or not receipt.get("sha256") is String:
					valid = false
					break
				if receipt.sha256.length() != 64 or not receipt.sha256.is_valid_hex_number():
					valid = false
					break
			for path in archives:
				var receipt = archives[path]
				if not receipt is Dictionary or not managed_shape(path) or not receipt.get("source") is String or not receipt.get("sha256") is String or not receipt.get("source_sha256") is String or not receipt.get("version") is String or not receipt.get("retired") is bool:
					valid = false
					break
				if receipt.sha256.length() != 64 or not receipt.sha256.is_valid_hex_number() or receipt.source_sha256.length() != 64 or not receipt.source_sha256.is_valid_hex_number() or canonical(path).get_base_dir().get_file() != receipt.sha256.substr(0, 20) or canonical(path) == canonical(receipt.source):
					valid = false
					break
	var order = read_order()
	if order == null:
		return
	var enabled_names = {}
	for entry in order:
		if not entry.disabled:
			enabled_names[entry.path.get_file()] = enabled_names.get(entry.path.get_file(), 0)+1
	for entry in order:
		if not entry.disabled and enabled_names[entry.path.get_file()] == 1 and entry.path.get_file() in GlobalRegistry.getLoadedMods():
			loaded_paths.append(canonical(entry.path))
	if valid:
		retire_previous(order)
	else:
		message = "Cannot read update records safely. Updates blocked; archives preserved."

func save():
	if not valid or read_text(STATE) != disk_state:
		message = "Update records changed externally. Restart before updating."
		return false
	var text = JSON.print({"schema":1,"archives":archives,"installed":installed}, "\t", true)
	var directory = Directory.new()
	if directory.make_dir_recursive(STATE.get_base_dir()) != OK:
		return false
	var file = File.new()
	var error = file.open(STATE+".tmp", File.WRITE)
	if error == OK:
		file.store_string(text)
		file.flush()
		error = file.get_error()
		file.close()
	if error == OK:
		error = directory.rename(STATE+".tmp", STATE)
	if error != OK:
		directory.remove(STATE+".tmp")
		message = "Cannot save update records: "+str(error)
		return false
	disk_state = text
	Platform.sync_storage()
	return true

func remember_install(path, version):
	if not valid or not File.new().file_exists(path):
		return false
	var hash_value = File.new().get_sha256(path)
	if hash_value.empty() or Links.clean_version(version).empty():
		return false
	var previous = installed.duplicate(true)
	installed[canonical(path)] = {"version":Links.clean_version(version),"sha256":hash_value}
	if save():
		return true
	installed = previous
	return false

func local_info(path):
	var info = Links.local_info(path)
	if not info.modversion.empty() or not valid:
		return info
	var receipt = installed.get(canonical(path), archives.get(path, {}))
	if not receipt.empty() and File.new().file_exists(path) and File.new().get_sha256(path) == receipt.sha256:
		info.modversion = receipt.version
	return info

func complete_order(saved):
	# Both screens use the same existing paths, recovery entries and retired-source filter.
	var entries = []
	var seen = {}
	for entry in saved:
		if File.new().file_exists(entry.path) and not seen.has(canonical(entry.path)):
			entries.append(entry.duplicate(true))
			seen[canonical(entry.path)] = true
	var files = GlobalRegistry.getRawModList()
	files.sort()
	for path in files:
		if not seen.has(canonical(path)):
			entries.append({"path":path,"disabled":false})
			seen[canonical(path)] = true
	if valid:
		var sources = {}
		for path in archives:
			sources[canonical(archives[path].source)] = true
		for path in archives:
			if File.new().file_exists(path) and not sources.has(canonical(path)) and not seen.has(canonical(path)):
				entries.append({"path":path,"disabled":true})
				seen[canonical(path)] = true
	var hidden = hidden_sources(entries)
	var retired = []
	for i in range(entries.size()-1, -1, -1):
		if entries[i].disabled and hidden.has(canonical(entries[i].path)):
			retired.push_front(entries.pop_at(i))
	return {"entries":entries,"retired":retired}

func is_loaded(path):
	return canonical(path) in loaded_paths

func retire_previous(order):
	# Run once per game, after normal pack loading. Never touch a current-session download.
	var selected = {}
	for entry in order:
		selected[canonical(entry.path)] = entry
	var changed = false
	for path in archives:
		var receipt = archives[path]
		if receipt.retired or not selected.has(canonical(path)):
			continue
		if not selected[canonical(path)].disabled and not is_loaded(path):
			continue
		var source = receipt.source
		if is_loaded(source) or (selected.has(canonical(source)) and not selected[canonical(source)].disabled):
			continue
		if not Platform.is_mod_path(source, GlobalRegistry.getModsFolder(), OS.get_name()) and not managed_shape(source):
			continue
		if not File.new().file_exists(path) or File.new().get_sha256(path) != receipt.sha256:
			continue
		if File.new().file_exists(source):
			if File.new().get_sha256(source) != receipt.source_sha256:
				message = "A previous archive changed; it was preserved: "+source.get_file()
				continue
			if Directory.new().remove(source) != OK:
				message = "Previous archive is still in use; cleanup will retry next launch."
				continue
			if managed_shape(source):
				Directory.new().remove(source.get_base_dir()) # Empty version directory only.
		receipt.retired = true
		installed.erase(canonical(source))
		changed = true
	if changed:
		# Keep receipts for existing versions, including disabled recovery entries.
		for path in archives.keys():
			if not File.new().file_exists(path):
				archives.erase(path)
		save()

func hidden_sources(entries):
	var selected = {}
	for entry in entries:
		selected[canonical(entry.path)] = true
	var hidden = {}
	if valid:
		for path in archives:
			if selected.has(canonical(path)) and File.new().file_exists(path):
				hidden[canonical(archives[path].source)] = true
	return hidden

func is_pending(path):
	return pending.has(path)

func forget(path):
	var changed = installed.erase(canonical(path))
	if archives.has(path):
		archives.erase(path)
		changed = true
	if changed:
		save()
