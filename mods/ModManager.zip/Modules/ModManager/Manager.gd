extends PanelContainer

const ORDER = "user://modOrder.json"
var entries = []
var disk_order = ""
var order_valid = true
var rebuilding = false
var tree:Tree
var search:LineEdit
var description:RichTextLabel
var status:Label
var browser
var ui
var language:OptionButton
var translate_button:Button
var notice:AcceptDialog
var preview_cache = {}
var remove_button:Button
var remove_dialog:ConfirmationDialog
var remove_path = ""
var body:HSplitContainer
var updates
var update_button:Button
var update_all_button:Button
var update_message:Label

func button(parent, text, method):
	var control = Button.new()
	control.text = text
	control.connect("pressed", self, method)
	parent.add_child(control)
	return control

func _ready():
	set_anchors_and_margins_preset(Control.PRESET_WIDE)
	ui = load("res://Modules/ModManager/UiTranslation.gd").new()
	add_child(ui)
	ui.connect("changed", self, "refresh_translation")
	var margin = MarginContainer.new()
	for side in ["left", "top", "right", "bottom"]:
		margin.add_constant_override("margin_"+side, 16)
	add_child(margin)
	var box = VBoxContainer.new()
	margin.add_child(box)
	var header = HBoxContainer.new()
	box.add_child(header)
	button(header, "Close", "close_manager")
	var title = Label.new()
	title.text = "Mod Manager"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	remove_button = button(header, "Delete", "request_delete")
	remove_button.disabled = true
	button(header, "Mod Browser", "open_browser")
	button(header, "Refresh", "refresh_mods")
	language = OptionButton.new()
	language.set_meta("no_translate", true)
	for code in TranslationLanguage.langs:
		language.add_item(code)
		language.get_popup().set_item_tooltip(language.get_item_count()-1, TranslationLanguage.langs[code])
		if code == AutoTranslation.getTargetLanguage():
			language.select(language.get_item_count()-1)
	header.add_child(language)
	translate_button = button(header, "Translate", "translate_interface")
	translate_button.set_meta("no_translate", true)
	search = LineEdit.new()
	search.placeholder_text = "Search installed mods"
	search.connect("text_changed", self, "render_entries")
	box.add_child(search)
	var update_bar = HBoxContainer.new()
	box.add_child(update_bar)
	update_button = button(update_bar, "Update", "update_selected")
	update_all_button = button(update_bar, "Update all", "update_all")
	update_button.disabled = true
	update_all_button.disabled = true
	update_message = Label.new()
	update_message.text = "Checking versions..."
	update_message.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	update_message.clip_text = true
	update_bar.add_child(update_message)
	body = HSplitContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(body)
	tree = load("res://Modules/ModManager/PriorityTree.gd").new()
	tree.manager = self
	tree.columns = 4
	tree.hide_root = true
	tree.column_titles_visible = true
	tree.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tree.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tree.size_flags_stretch_ratio = 1.0
	tree.rect_min_size.x = 560
	var titles = ["On", "Priority", "Mod", "Next launch"]
	for i in range(titles.size()):
		tree.set_column_title(i, titles[i])
		tree.set_column_expand(i, i == 2)
		tree.set_column_min_width(i, [55, 85, 240, 130][i])
	tree.connect("item_edited", self, "entry_edited")
	tree.connect("item_selected", self, "show_selected")
	body.add_child(tree)
	description = RichTextLabel.new()
	description.bbcode_enabled = true
	description.selection_enabled = true
	description.size_flags_vertical = Control.SIZE_EXPAND_FILL
	description.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	description.rect_min_size.x = 300
	body.add_child(description)
	status = Label.new()
	status.autowrap = true
	box.add_child(status)
	status.text = "Restart the game to apply changes."
	notice = AcceptDialog.new()
	add_child(notice)
	remove_dialog = ConfirmationDialog.new()
	remove_dialog.window_title = "Delete"
	remove_dialog.connect("confirmed", self, "confirm_delete")
	add_child(remove_dialog)
	updates = load("res://Modules/ModManager/Updates.gd").new()
	updates.owner_manager = self
	updates.connect("changed", self, "updates_changed")
	add_child(updates)
	reload_order()
	call_deferred("center_initial_split")

func center_initial_split():
	body.split_offset = 0

func refresh_mods():
	if updates.busy:
		return
	reload_order()
	updates.check()

func translate_interface():
	return ui.toggle_screen(self, language.get_item_text(language.selected))

func refresh_translation():
	translate_button.text = ui.tr("Original") if ui.language != "en" else "Translate"
	var row = tree.get_root().get_children() if tree.get_root() != null else null
	while row != null:
		var entry = entries[row.get_metadata(0)]
		row.set_text(3, ui.tr("Disabled") if entry.disabled else ui.tr("Enabled"))
		row = row.get_next()
	# Translated headings and states may be wider than their English originals.
	var font = tree.get_font("font")
	var minimum_width = 240+tree.get_stylebox("bg").get_minimum_size().x+24
	for column in [0, 1, 3]:
		var width = max([55, 85, 240, 130][column], font.get_string_size(tree.get_column_title(column)).x+20)
		row = tree.get_root().get_children() if tree.get_root() != null else null
		while row != null:
			width = max(width, font.get_string_size(row.get_text(column)).x+20)
			row = row.get_next()
		tree.set_column_min_width(column, int(ceil(width)))
		minimum_width += ceil(width)
	tree.rect_min_size.x = max(560, minimum_width)
	tree.call_deferred("layout_names")

func updates_changed():
	var selected_path = ""
	if tree.get_selected() != null:
		selected_path = entries[tree.get_selected().get_metadata(0)].path
	update_message.text = updates.message
	render_entries()
	update_all_button.disabled = true
	for entry in entries:
		if updates.can_update(entry.path, true):
			update_all_button.disabled = false
	var row = tree.get_root().get_children()
	while row != null:
		if entries[row.get_metadata(0)].path == selected_path:
			row.select(2)
			show_selected()
			break
		row = row.get_next()

func update_selected():
	var row = tree.get_selected()
	if row != null:
		updates.start([entries[row.get_metadata(0)].path])

func update_all():
	var paths = []
	for entry in entries:
		if updates.can_update(entry.path, true):
			paths.append(entry.path)
	updates.start(paths)

func error_message(text):
	notice.dialog_text = text
	ui.apply(self)
	notice.popup_centered()

func read_order_text():
	var file = File.new()
	if not file.file_exists(ORDER):
		return ""
	if file.open(ORDER, File.READ) != OK:
		return null
	var text = file.get_as_text()
	file.close()
	return text

func reload_order():
	disk_order = ""
	order_valid = true
	entries.clear()
	var raw = read_order_text()
	if raw == null:
		order_valid = false
	else:
		disk_order = raw
		if not raw.empty():
			var parsed = JSON.parse(raw)
			if parsed.error != OK or not parsed.result is Array:
				order_valid = false
			else:
				var seen = {}
				for entry in parsed.result:
					if not entry is Dictionary or not entry.get("path") is String or not entry.get("disabled") is bool or seen.has(entry.get("path")):
						order_valid = false
						break
					seen[entry.path] = true
					if File.new().file_exists(entry.path):
						entries.append(entry.duplicate(true))
	var files = GlobalRegistry.getRawModList()
	files.sort()
	for path in files:
		var exists = false
		for entry in entries:
			if entry.path == path:
				exists = true
		if not exists:
			entries.append({"path":path, "disabled":false})
	# Match the launcher's reserved base pack placement and disabled state.
	for i in range(entries.size()):
		if entries[i].path.get_file() == "BDCC.pck":
			var base = entries.pop_at(i)
			base.disabled = true
			entries.push_front(base)
			break
	render_entries()
	if not order_valid:
		error_message("Cannot read modOrder.json safely. Editing blocked; original preserved.")
	if updates != null:
		updates.rebuild()

func render_entries(_query = ""):
	rebuilding = true
	remove_button.disabled = true
	update_button.disabled = true
	tree.clear()
	var root = tree.create_item()
	var query = search.text.to_lower().strip_edges()
	for i in range(entries.size()):
		var entry = entries[i]
		var filename = entry.path.get_file()
		if not query.empty() and not query in filename.to_lower():
			continue
		var row = tree.create_item(root)
		row.set_metadata(0, i)
		for column in range(4):
			row.set_text_align(column, TreeItem.ALIGN_LEFT if column == 2 else TreeItem.ALIGN_CENTER)
		row.set_cell_mode(0, TreeItem.CELL_MODE_ICON)
		row.set_icon(0, tree.get_icon("unchecked" if entry.disabled else "checked", "Tree"))
		row.set_cell_mode(1, TreeItem.CELL_MODE_STRING)
		row.set_text(1, str(i))
		row.set_editable(1, order_valid and filename != "BDCC.pck")
		row.set_cell_mode(2, TreeItem.CELL_MODE_CUSTOM)
		var state = updates.records.get(entry.path, {}).get("state", "") if updates != null else ""
		row.set_metadata(2, {"text":filename,"lines":[filename],"state":state})
		row.set_custom_draw(2, tree, "draw_mod_name")
		row.set_tooltip(2, entry.path+("\n"+ui.tr(state) if not state.empty() else ""))
		row.set_text(3, ui.tr("Disabled") if entry.disabled else ui.tr("Enabled"))
	rebuilding = false
	ui.apply(self)
	refresh_translation()

func entry_edited():
	if rebuilding or not order_valid:
		return
	var row = tree.get_edited()
	var column = tree.get_edited_column()
	if column != 1:
		return
	var index = row.get_metadata(0)
	var snapshot = entries.duplicate(true)
	var path = entries[index].path
	var value = row.get_text(1).strip_edges()
	if not value.is_valid_integer() or int(value) < 0 or int(value) >= entries.size():
		error_message("Enter a priority between 0 and "+str(entries.size()-1)+".")
		render_entries()
		return
	move_entry(index, int(value))
	if not save_order():
		entries = snapshot
	render_entries()
	var current = tree.get_root().get_children()
	while current != null:
		if entries[current.get_metadata(0)].path == path:
			current.select(2)
			tree.ensure_cursor_is_visible()
			break
		current = current.get_next()

func move_entry(index, priority):
	if entries[index].path.get_file() == "BDCC.pck":
		return
	var first = 1 if not entries.empty() and entries[0].path.get_file() == "BDCC.pck" else 0
	var entry = entries.pop_at(index)
	entries.insert(int(clamp(priority, first, entries.size())), entry)

func toggle_entry(index):
	var entry = entries[index]
	if not order_valid or entry.path.get_file() == "BDCC.pck":
		return
	entry.disabled = not entry.disabled
	if not save_order():
		entry.disabled = not entry.disabled
	render_entries()
	var row = tree.get_root().get_children()
	while row != null:
		if row.get_metadata(0) == index:
			row.select(0)
			break
		row = row.get_next()

func drop_entry(path, insertion):
	if not order_valid:
		return
	for i in range(entries.size()):
		if entries[i].path == path:
			var snapshot = entries.duplicate(true)
			move_entry(i, insertion-1 if i < insertion else insertion)
			if not save_order():
				entries = snapshot
			render_entries()
			var row = tree.get_root().get_children()
			while row != null:
				if entries[row.get_metadata(0)].path == path:
					row.select(2)
					tree.ensure_cursor_is_visible()
					break
				row = row.get_next()
			return

func save_order():
	if not order_valid or read_order_text() != disk_order:
		error_message("Order changed externally. Reload before editing.")
		return false
	var text = JSON.print(entries, "\t", true)
	var temporary = ORDER+".modmanager-tmp"
	var file = File.new()
	var error = file.open(temporary, File.WRITE)
	if error == OK:
		file.store_string(text)
		file.flush()
		error = file.get_error()
		file.close()
	var directory = Directory.new()
	if error == OK and File.new().file_exists(ORDER):
		error = directory.copy(ORDER, ORDER+".modmanager-backup")
	if error == OK:
		error = directory.rename(temporary, ORDER)
	if error != OK:
		directory.remove(temporary)
		error_message("Cannot save order; original preserved. Error: "+str(error))
		return false
	disk_order = text
	get_tree().set_meta("ModManager_pending", true)
	return true

func show_selected():
	var row = tree.get_selected()
	if row == null:
		return
	var entry = entries[row.get_metadata(0)]
	remove_button.disabled = not order_valid or updates.busy or not can_delete_path(entry.path) or is_manager_archive(entry.path)
	update_button.disabled = not updates.can_update(entry.path)
	description.bbcode_text = entry.path.replace("[", "[lb]")+"\n"
	var record = updates.records.get(entry.path, {})
	if record.get("latest") != null:
		description.bbcode_text += "Installed version: "+str(record.local.get("modversion", "unknown"))+"\nLatest version: "+str(record.latest.modversion)+"\nStatus: "+str(record.state)+"\n\n"
	elif record.has("state"):
		description.bbcode_text += "Status: "+str(record.state)+"\n\n"
	if entry.path.get_extension() != "zip":
		description.bbcode_text += "Metadata unavailable for PCK"
		ui.apply(self)
		return
	var archive = GDUnzip.new()
	var metadata = entry.path.get_file().get_basename()+".json"
	if not archive.load(entry.path) or not archive.files.has(metadata):
		description.bbcode_text += "No metadata"
		ui.apply(self)
		return
	var bytes = archive.uncompress(metadata)
	if not bytes:
		return
	var parsed = JSON.parse(bytes.get_string_from_utf8())
	if parsed.error == OK and parsed.result is Dictionary:
		description.bbcode_text += "Author: "+str(parsed.result.get("author", "?"))+" · Mod: "+str(parsed.result.get("modversion", "?"))+" · Game: "+str(parsed.result.get("gameversion", "?"))+"\n"+str(parsed.result.get("description", ""))
	ui.apply(self)

func is_manager_archive(path):
	if path.get_extension().to_lower() != "zip":
		return path.get_file().to_lower() == "modmanager.pck"
	var archive = GDUnzip.new()
	return archive.load(path) and archive.files.has("Modules/ModManager/Module.gd")

func can_delete_path(path):
	var folder = ProjectSettings.globalize_path(GlobalRegistry.getModsFolder()).replace("\\", "/").simplify_path().trim_suffix("/")
	var absolute = ProjectSettings.globalize_path(path).replace("\\", "/").simplify_path()
	if OS.get_name() == "Windows":
		folder = folder.to_lower()
		absolute = absolute.to_lower()
	return absolute.get_base_dir() == folder and absolute.get_file().get_extension() in ["zip", "pck"] and absolute.get_file().to_lower() != "bdcc.pck"

func request_delete():
	var row = tree.get_selected()
	if row == null or remove_button.disabled:
		return
	remove_path = entries[row.get_metadata(0)].path
	remove_dialog.dialog_text = "Delete this mod archive?\n"+remove_path+"\n\nThis action cannot be undone."
	ui.apply(self)
	remove_dialog.popup_centered()

func confirm_delete():
	if not order_valid or not can_delete_path(remove_path) or is_manager_archive(remove_path):
		return
	for i in range(entries.size()):
		if entries[i].path != remove_path:
			continue
		if read_order_text() != disk_order:
			error_message("Order changed externally. Reload before deleting.")
			return
		if remove_path.get_file() in GlobalRegistry.getLoadedMods():
			error_message("This archive is in use. Disable this mod and restart the game, then click Delete again.")
			return
		var error = Directory.new().remove(remove_path)
		if error != OK:
			error_message("Cannot delete mod archive. Error: "+str(error))
			return
		entries.remove(i)
		save_order()
		description.bbcode_text = ""
		reload_order()
		return

func open_browser():
	if browser != null:
		return
	get_child(1).hide()
	browser = load("res://Modules/ModManager/Browser.gd").new()
	browser.ui = ui
	browser.preview_cache = preview_cache
	browser.connect("tree_exited", self, "browser_closed")
	add_child(browser)

func browser_closed():
	browser = null
	get_child(1).show()
	reload_order()

func close_manager():
	if not ui.busy and not updates.busy:
		queue_free()

func _exit_tree():
	preview_cache.clear()
