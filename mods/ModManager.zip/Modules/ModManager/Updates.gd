extends Node

const Links = preload("res://Modules/ModManager/ContentLinks.gd")
const CATALOGUE = "https://raw.githubusercontent.com/Alexofp/BDCCMods/main/allmods.json"
const FOLDER = "user://ModManager/updates"
signal changed
var auto_check = true
var catalogue = []
var checking = false
var busy = false
var message = "Checking versions..."
var http:HTTPRequest
var download
var records = {}
var queue = []
var current = {}
var jobs = []
var failures = []
var owner_manager
var catalogue_ready = false
var previous_errors = []

func _ready():
	http = HTTPRequest.new()
	http.timeout = 30
	http.connect("request_completed", self, "catalogue_received")
	add_child(http)
	download = HTTPRequest.new()
	download.timeout = 180
	download.connect("request_completed", self, "download_received")
	add_child(download)
	var pending = read_json(FOLDER.plus_file("pending.json"))
	if pending is Dictionary and pending.get("updates") is Array and int(pending.get("pid", -1)) == OS.get_process_id():
		jobs = pending.get("updates", [])
	var result = read_json(FOLDER.plus_file("result.json"))
	if result is Array:
		for entry in result:
			if entry is Dictionary and entry.get("error") is String and not entry.error.empty():
				previous_errors.append(entry.error)
	call_deferred("check_automatically")

func check_automatically():
	if auto_check:
		check()

func read_json(path):
	var file = File.new()
	if file.open(path, File.READ) != OK:
		return null
	var parsed = JSON.parse(file.get_as_text())
	file.close()
	return parsed.result if parsed.error == OK else null

func check():
	if checking or busy:
		return
	checking = true
	catalogue_ready = false
	message = "Checking versions..."
	emit_signal("changed")
	var error = http.request(CATALOGUE)
	if error != OK:
		checking = false
		message = "Cannot check versions. Press Refresh to retry."
		emit_signal("changed")

func catalogue_received(result, code, _headers, body):
	checking = false
	var parsed = JSON.parse(body.get_string_from_utf8()) if result == HTTPRequest.RESULT_SUCCESS and code == 200 else null
	if parsed == null or parsed.error != OK or not parsed.result is Dictionary or not parsed.result.get("mods") is Array:
		message = "Cannot check versions. Press Refresh to retry."
		emit_signal("changed")
		return
	catalogue.clear()
	catalogue_ready = true
	for latest in parsed.result.mods:
		if latest is Dictionary and latest.get("download") is String and latest.get("modversion") is String and latest.get("gameversion") is String and latest.get("name") is String:
			var entry = latest.duplicate()
			entry.modversion = Links.clean_version(entry.modversion)
			if not entry.modversion.empty():
				catalogue.append(entry)
	rebuild()

func rebuild():
	records.clear()
	var count = 0
	for entry in owner_manager.entries:
		var path = entry.path
		var latest = Links.catalogue_match(path, catalogue) if catalogue_ready else null
		var local = Links.local_info(path) if latest != null else {}
		var state = "Not in catalogue" if catalogue_ready else "Versions not checked"
		if latest != null:
			state = Links.state_from_version(local.get("modversion", ""), latest)
			if state == "Update required" and not GlobalRegistry.isVersionListHasCompatible(latest.gameversion):
				state = "Incompatible update"
		if state == "Update required":
			count += 1
		for job in jobs:
			if job.old_key == path:
				state = "Restart to update"
		records[path] = {"latest":latest,"local":local,"state":state}
	if not busy and not checking:
		message = "Some updates failed. Press Update to retry." if not failures.empty() else "Updates downloaded. Restart the game to apply." if not jobs.empty() else "Previous update failed: "+str(previous_errors[0]) if not previous_errors.empty() else "Updates available: "+str(count) if catalogue_ready else "Versions not checked"
	emit_signal("changed")

func can_update(path, bulk = false):
	if busy or checking or not catalogue_ready or not owner_manager.order_valid:
		return false
	var record = records.get(path, {})
	return record.get("latest") != null and (record.get("state") == "Update required" or not bulk and record.get("state") == "Version unknown") and owner_manager.can_delete_path(path) and not owner_manager.is_manager_archive(path)

func start(paths):
	if busy:
		return
	queue.clear()
	failures.clear()
	previous_errors.clear()
	for path in paths:
		if can_update(path):
			queue.append(path)
	if queue.empty():
		return
	busy = true
	next_download()

func next_download():
	if queue.empty():
		busy = false
		message = "Updates downloaded. Restart the game to apply." if failures.empty() else "Some updates failed. Press Update to retry."
		rebuild()
		emit_signal("changed")
		return
	var path = queue.pop_front()
	var latest = records[path].latest
	var filename = latest.download.get_file()
	if not latest.download.begins_with("https://") or not filename.get_extension().to_lower() in ["zip", "pck"] or ":" in filename or "\\" in filename or filename.to_lower() == "bdcc.pck":
		fail_current("Invalid download URL")
		return
	if Directory.new().make_dir_recursive(FOLDER) != OK:
		fail_current("Cannot create update folder")
		return
	current = {"old_key":path,"new_key":GlobalRegistry.getModsFolder().plus_file(filename),"latest":latest,"staged":FOLDER.plus_file(path.sha256_text()+".part")}
	download.download_file = current.staged
	message = "Downloading: "+latest.name
	emit_signal("changed")
	if download.request(latest.download) != OK:
		fail_current("Cannot start download")

func fail_current(error):
	if current.has("staged"):
		call_deferred("remove_failed_download", current.staged)
	failures.append(error)
	current = {}
	call_deferred("next_download")

func remove_failed_download(path):
	Directory.new().remove(path)

func download_received(result, code, _headers, _body):
	if current.empty():
		return
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		fail_current("Download failed: HTTP "+str(code))
		return
	var file = File.new()
	if file.open(current.staged, File.READ) != OK:
		fail_current("Cannot read download")
		return
	var magic = Array(file.get_buffer(4))
	file.close()
	var expected = [80, 75, 3, 4] if current.new_key.get_extension().to_lower() == "zip" else [71, 68, 80, 67]
	if magic != expected:
		fail_current("Invalid mod archive")
		return
	var validated = current.staged+"."+current.new_key.get_extension()
	if Directory.new().rename(current.staged, validated) != OK:
		fail_current("Cannot stage download")
		return
	current.staged = validated
	if current.new_key.get_extension().to_lower() == "zip":
		var archive = GDUnzip.new()
		if not archive.load(validated) or archive.files.empty():
			fail_current("Invalid ZIP directory")
			return
	var info = Links.local_info(validated, current.new_key.get_file().get_basename())
	# Metadata is authoritative when supplied; do not accept a different release.
	if not info.get("modversion", "").empty() and Links.normalized_version(info.modversion) != Links.normalized_version(current.latest.modversion):
		fail_current("Downloaded version differs from catalogue")
		return
	var job = {"old_key":current.old_key,"new_key":current.new_key,"old":ProjectSettings.globalize_path(current.old_key),"destination":ProjectSettings.globalize_path(current.new_key),"staged":ProjectSettings.globalize_path(current.staged),"version":current.latest.modversion,"sha256":File.new().get_sha256(current.staged)}
	jobs.append(job)
	if not save_jobs() or not start_helper():
		jobs.pop_back()
		save_jobs()
		fail_current("Cannot prepare update helper")
		return
	current = {}
	call_deferred("next_download")

func save_jobs():
	var file = File.new()
	var temporary = FOLDER.plus_file("pending.json.tmp")
	if file.open(temporary, File.WRITE) != OK:
		return false
	file.store_string(JSON.print({"pid":OS.get_process_id(),"mods_folder":ProjectSettings.globalize_path(GlobalRegistry.getModsFolder()),"order_path":ProjectSettings.globalize_path(owner_manager.ORDER),"updates":jobs}, "\t", true))
	file.close()
	return Directory.new().rename(temporary, FOLDER.plus_file("pending.json")) == OK

func start_helper():
	var tree = get_tree()
	if tree.has_meta("ModManager_update_helper") and OS.is_process_running(int(tree.get_meta("ModManager_update_helper"))):
		return true
	var target = FOLDER.plus_file("helper.pck")
	var source = File.new()
	if source.open("res://Modules/ModManager/UpdateHelper.pck", File.READ) != OK:
		return false
	var bytes = source.get_buffer(source.get_len())
	source.close()
	var file = File.new()
	if bytes.empty() or file.open(target, File.WRITE) != OK:
		return false
	file.store_buffer(bytes)
	file.close()
	var pid = OS.execute(OS.get_executable_path(), ["--main-pack",ProjectSettings.globalize_path(target),"--no-window","--audio-driver","Dummy","--modmanager-job="+ProjectSettings.globalize_path(FOLDER.plus_file("pending.json"))], false)
	if pid < 0:
		return false
	tree.set_meta("ModManager_update_helper", pid)
	return true

func _exit_tree():
	if not current.empty() and current.has("staged"):
		download.cancel_request()
		Directory.new().remove(current.staged)
