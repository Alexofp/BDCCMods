extends Node

const Links = preload("res://Modules/ModManager/ContentLinks.gd")
const CATALOGUE = "https://raw.githubusercontent.com/Alexofp/BDCCMods/main/allmods.json"
const Platform = preload("res://Modules/ModManager/Platform.gd")
signal changed
var auto_check = true
var catalogue = []
var checking = false
var message = "Checking versions..."
var http:HTTPRequest
var records = {}
var owner_manager
var catalogue_ready = false
var download:HTTPRequest
var busy = false
var queue = []
var current = {}
var failures = []
var completed = 0

func _ready():
	http = HTTPRequest.new()
	http.timeout = 30
	http.connect("request_completed", self, "catalogue_received")
	add_child(http)
	download = HTTPRequest.new()
	download.timeout = 180
	download.connect("request_completed", self, "download_received")
	add_child(download)
	call_deferred("check_automatically")

func check_automatically():
	if auto_check:
		check()

func check():
	if checking or busy:
		return
	checking = true
	message = "Checking versions..."
	emit_signal("changed")
	var error = http.request(CATALOGUE)
	if error != OK:
		checking = false
		rebuild()
		message = "Cannot check versions. Press Refresh to retry."
		emit_signal("changed")

func catalogue_received(result, code, _headers, body):
	checking = false
	var parsed = JSON.parse(body.get_string_from_utf8()) if result == HTTPRequest.RESULT_SUCCESS and code == 200 else null
	if parsed == null or parsed.error != OK or not parsed.result is Dictionary or not parsed.result.get("mods") is Array:
		rebuild()
		message = "Cannot check versions. Press Refresh to retry."
		emit_signal("changed")
		return
	catalogue.clear()
	catalogue_ready = true
	for latest in parsed.result.mods:
		if latest is Dictionary and latest.get("download") is String and latest.get("modversion") is String and latest.get("gameversion") is String and latest.get("name") is String:
			var entry = latest.duplicate()
			entry.modversion = Links.clean_version(entry.modversion)
			if not entry.modversion.empty():
				catalogue.append(entry)
	rebuild()

func rebuild():
	records.clear()
	var count = 0
	for entry in owner_manager.entries:
		var path = entry.path
		var latest = Links.catalogue_match(path, catalogue) if catalogue_ready else null
		var local = owner_manager.versions.local_info(path)
		var installed = local
		var pending = owner_manager.versions.is_pending(path)
		if pending:
			var source = owner_manager.versions.archives[path].source
			installed = owner_manager.versions.local_info(source)
		var state = "Not in catalogue" if catalogue_ready else "Versions not checked"
		if latest != null:
			state = Links.state_from_version(installed.get("modversion", ""), latest)
		if state == "Update required" and not pending:
			count += 1
		var outdated = state == "Update required"
		var game_version = installed.get("gameversion", "")
		var incompatible = game_version is String and not game_version.strip_edges().empty() and not GlobalRegistry.isVersionListHasCompatible(game_version)
		if incompatible:
			state = "Incompatible with game"
		records[path] = {"latest":latest,"local":local,"installed":installed,"state":state,"outdated":outdated,"incompatible":incompatible}
	if not checking and not busy:
		message = "Updates available: "+str(count) if catalogue_ready else "Versions not checked"
		if not owner_manager.versions.message.empty():
			message += ". "+owner_manager.versions.message
	emit_signal("changed")

func blocking_reason(path):
	var record = records.get(path, {})
	if not owner_manager.order_valid or not owner_manager.versions.valid:
		return "Cannot read order or update records safely."
	if owner_manager.versions.is_pending(path):
		return "Restart to apply the prepared update."
	if checking:
		return "Wait for the version check to finish."
	if not record.get("outdated", false) or record.get("latest") == null:
		return "No verified update available."
	if not GlobalRegistry.isVersionListHasCompatible(record.latest.gameversion):
		return "The catalogue release is incompatible with this game version."
	if not owner_manager.can_delete_path(path) or owner_manager.is_manager_archive(path):
		return "This archive cannot be updated here."
	var filename = record.latest.download.get_file()
	if not record.latest.download.begins_with("https://") or not filename.get_extension().to_lower() in ["zip", "pck"] or filename.to_lower() == "bdcc.pck" or ":" in filename or "\\" in filename:
		return "Unsupported download URL."
	var matches = 0
	for entry in owner_manager.entries:
		if Links.archive_stem(entry.path) == Links.archive_stem(path):
			matches += 1
	return "Multiple installed archives match this mod. Remove the duplicate first." if matches > 1 else ""

func start(paths):
	if busy or checking or paths.empty():
		return
	queue.clear()
	failures.clear()
	completed = 0
	for path in paths:
		var reason = blocking_reason(path)
		if not reason.empty():
			owner_manager.error_message(reason)
			return
		queue.append({"source":path,"latest":records[path].latest.duplicate(true)})
	busy = true
	next_download()

func next_download():
	current = {}
	if queue.empty():
		busy = false
		rebuild()
		message = "Updates prepared: "+str(completed)+". "+Platform.restart_message()
		if not failures.empty():
			message += " Failed: "+str(failures.size())
			owner_manager.error_message(PoolStringArray(failures).join("\n"))
		emit_signal("changed")
		return
	current = queue.pop_front()
	if owner_manager.read_order_text() != owner_manager.disk_order or not blocking_reason(current.source).empty():
		finish_one(false, "Order or installed mod changed. Refresh before updating.")
		return
	current.source_sha256 = File.new().get_sha256(current.source) if File.new().file_exists(current.source) else ""
	current.temporary = owner_manager.versions.folder().plus_file("Incoming").plus_file(current.latest.download.get_file())
	if current.source_sha256.empty() or Directory.new().make_dir_recursive(current.temporary.get_base_dir()) != OK:
		finish_one(false, "Cannot prepare the download folder.")
		return
	download.download_file = current.temporary
	message = "Downloading: "+current.latest.name
	emit_signal("changed")
	var error = download.request(current.latest.download)
	if error != OK:
		finish_one(false, "Download request failed: "+str(error))

func download_received(result, code, _headers, _body):
	if current.empty():
		return
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		finish_one(false, "Download failed: HTTP "+str(code)+". "+Platform.network_error())
		return
	if not archive_valid(current.temporary):
		finish_one(false, "Invalid mod archive. Original preserved.")
		return
	var info = Links.local_info(current.temporary)
	if not info.modversion.empty() and Links.state_from_version(info.modversion, current.latest) != "Up to date":
		finish_one(false, "Downloaded version does not match the catalogue. Original preserved.")
		return
	if not File.new().file_exists(current.source) or File.new().get_sha256(current.source) != current.source_sha256:
		finish_one(false, "Installed archive changed during download. Original preserved.")
		return
	var hash_value = File.new().get_sha256(current.temporary)
	var target = owner_manager.versions.folder().plus_file(hash_value.substr(0, 20)).plus_file(current.latest.download.get_file())
	if owner_manager.versions.canonical(target) == owner_manager.versions.canonical(current.source):
		finish_one(false, "The catalogue provided the already installed archive.")
		return
	var directory = Directory.new()
	if directory.make_dir_recursive(target.get_base_dir()) != OK:
		finish_one(false, "Cannot create version folder.")
		return
	var created = not File.new().file_exists(target)
	if (not created and File.new().get_sha256(target) != hash_value) or (created and directory.rename(current.temporary, target) != OK):
		finish_one(false, "Cannot store the new archive. Original preserved.")
		return
	var versions = owner_manager.versions
	var previous = versions.archives.duplicate(true)
	versions.archives[target] = {"source":current.source,"source_sha256":current.source_sha256,"sha256":hash_value,"version":current.latest.modversion,"retired":false}
	if not versions.save():
		versions.archives = previous
		if created:
			directory.remove(target)
		finish_one(false, "Cannot save update records. Original preserved.")
		return
	if not owner_manager.activate_update(current.source, target):
		versions.archives = previous
		versions.save()
		if created:
			directory.remove(target)
		finish_one(false, "Cannot save the new load order. Original preserved.")
		return
	finish_one(true, "")

func archive_valid(path):
	var file = File.new()
	if file.open(path, File.READ) != OK:
		return false
	var magic = file.get_32()
	if path.get_extension().to_lower() == "zip":
		file.close()
		var archive = GDUnzip.new()
		return magic == 0x04034b50 and archive.load(path) and not archive.files.empty()
	# Validate every PCK table range without mounting or executing the downloaded pack.
	if magic != 0x43504447 or file.get_len() < 88 or file.get_32() != 1:
		file.close()
		return false
	file.seek(84)
	var count = file.get_32()
	var valid = count > 0 and count <= 100000
	for _i in range(count if valid else 0):
		if file.get_position()+4 > file.get_len():
			valid = false
			break
		var length = file.get_32()
		if length > 4096 or file.get_position()+length+32 > file.get_len():
			valid = false
			break
		file.get_buffer(length)
		var offset = file.get_64()
		var size = file.get_64()
		file.get_buffer(16)
		if offset < 0 or size < 0 or offset > file.get_len() or size > file.get_len()-offset:
			valid = false
			break
	file.close()
	return valid

func finish_one(success, detail):
	if current.has("temporary") and File.new().file_exists(current.temporary):
		Directory.new().remove(current.temporary)
	if success:
		completed += 1
	else:
		failures.append(current.source.get_file()+": "+detail)
	Platform.sync_storage()
	rebuild()
	call_deferred("next_download")

func _exit_tree():
	if download != null:
		download.cancel_request()
	if current.has("temporary") and File.new().file_exists(current.temporary):
		Directory.new().remove(current.temporary)
		Platform.sync_storage()

