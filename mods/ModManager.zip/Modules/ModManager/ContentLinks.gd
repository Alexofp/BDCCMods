extends Reference

static func urls(text):
	var regex = RegEx.new()
	regex.compile("https?://[^\\s\\[\\]<>\"']+")
	var result = []
	for match_result in regex.search_all(text):
		var url = match_result.get_string().rstrip(".,;)")
		if not url in result:
			result.append(url)
	return result

static func is_image(url):
	return url.split("?")[0].split("#")[0].get_extension().to_lower() in ["png", "jpg", "jpeg", "webp"]

static func archive_stem(url):
	var stem = url.split("?")[0].get_file().get_basename().to_lower()
	var suffix = version_suffix(stem)
	if suffix != null:
		return stem.substr(0, suffix.get_start())
	# Keep support for older irregular suffixes such as _v1_.20.
	var regex = RegEx.new()
	regex.compile("_v?[0-9].*$")
	return regex.sub(stem, "")

static func version_suffix(stem):
	var regex = RegEx.new()
	regex.compile("(?i)(?:[_ -](?:(?:version|ver|v)[_ -]?)?|(?:version|ver|v)[_ -]?)([0-9]+(?:[._][0-9]+)*(?:[a-z]+[0-9]*)?(?:[-+][a-z0-9.]+)?)$")
	return regex.search(stem)

static func local_info(path, metadata_basename = ""):
	var info = {}
	if path.get_extension().to_lower() == "zip":
		var archive = GDUnzip.new()
		var metadata = (path.get_file().get_basename() if metadata_basename.empty() else metadata_basename)+".json"
		if archive.load(path) and archive.files.has(metadata):
			var bytes = archive.uncompress(metadata)
			if bytes:
				var parsed = JSON.parse(bytes.get_string_from_utf8())
				if parsed.error == OK and parsed.result is Dictionary:
					info = parsed.result
	elif path.get_extension().to_lower() == "pck":
		info = pck_info(path, metadata_basename)
	if not info.get("modversion") is String or info.modversion.strip_edges().empty():
		var match_result = version_suffix(path.get_file().get_basename())
		info["modversion"] = match_result.get_string(1) if match_result != null else ""
	info["modversion"] = clean_version(info.modversion)
	return info

static func pck_info(path, metadata_basename = ""):
	# Read metadata without mounting the pack or executing any of its scripts.
	var file = File.new()
	if file.open(path, File.READ) != OK:
		return {}
	if file.get_len() < 88 or file.get_32() != 0x43504447 or file.get_32() != 1:
		file.close()
		return {}
	file.seek(84)
	var count = file.get_32()
	var metadata = (path.get_file().get_basename() if metadata_basename.empty() else metadata_basename)+".json"
	if count > 100000:
		file.close()
		return {}
	for _i in range(count):
		if file.get_position()+4 > file.get_len():
			break
		var length = file.get_32()
		if length > 4096 or file.get_position()+length+32 > file.get_len():
			break
		var name = file.get_buffer(length).get_string_from_utf8().trim_suffix("\u0000").trim_prefix("res://")
		var offset = file.get_64()
		var size = file.get_64()
		file.get_buffer(16)
		if name == metadata and size >= 0 and size <= 1024*1024 and offset >= 0 and offset <= file.get_len() and size <= file.get_len()-offset:
			file.seek(offset)
			var parsed = JSON.parse(file.get_buffer(size).get_string_from_utf8())
			file.close()
			return parsed.result if parsed.error == OK and parsed.result is Dictionary else {}
	file.close()
	return {}

static func normalized_version(version):
	return clean_version(version).to_lower().trim_prefix("v")

static func clean_version(version):
	# Some catalogue entries append BBCode, including unfinished opening tags.
	var regex = RegEx.new()
	regex.compile("\\[/?(?:color|b|i|u|s|font|size)(?:=[^\\]]*)?(?:\\]|$)")
	return regex.sub(str(version), "", true).strip_edges()

static func version_state(path, latest):
	return state_from_version(local_info(path).get("modversion", ""), latest)

static func state_from_version(version, latest):
	if clean_version(version).empty() or clean_version(latest.modversion).empty():
		return "Version unknown"
	return "Up to date" if normalized_version(version) == normalized_version(latest.modversion) else "Update required"

static func catalogue_match(path, mods):
	var candidates = []
	for latest in mods:
		if archive_stem(latest.download) == archive_stem(path):
			candidates.append(latest)
	return candidates[0] if candidates.size() == 1 else null

static func target_for_url(url, mods):
	var clean = url.split("?")[0].split("#")[0]
	for entry in mods:
		if clean == entry.download.split("?")[0]:
			return entry
	# Versioned archive links may point at an older release of the same mod.
	var matches = []
	if clean.get_extension().to_lower() in ["zip", "pck"]:
		for entry in mods:
			if archive_stem(clean) == archive_stem(entry.download):
				matches.append(entry)
	return matches[0] if matches.size() == 1 else null

static func escaped(text):
	var result = text
	for character in ["\\", ".", "+", "*", "?", "^", "$", "(", ")", "[", "]", "{", "}", "|"]:
		result = result.replace(character, "\\"+character)
	return result

static func related(entry, mods):
	var tags = RegEx.new()
	tags.compile("\\[[^\\]]*\\]")
	var plain = tags.sub(entry.description, "", true).to_lower()
	var required = RegEx.new()
	required.compile("\\b(requires?|required|requirements|dependencies|depends on)\\b|зависимости|требуется")
	var negative = RegEx.new()
	negative.compile("not require|not actually require|doesn.t require|isn.t required|is not required|aren.t required|no longer|optional|removed|without.*dependency|не требуется")
	var direct = {}
	for url in urls(entry.description):
		var target = target_for_url(url, mods)
		if target != null:
			direct[target.download] = true
	var result = []
	for candidate in mods:
		if candidate.download == entry.download:
			continue
		var name_match = RegEx.new()
		var aliases = [candidate.name.to_lower(), archive_stem(candidate.download)]
		var patterns = []
		for alias in aliases:
			if alias.length() >= 4:
				patterns.append(escaped(alias))
		if patterns.empty():
			continue
		name_match.compile("(?<![a-z0-9])("+PoolStringArray(patterns).join("|")+")(?![a-z0-9])")
		var mentioned = direct.has(candidate.download)
		var needed = false
		var heading = false
		for line in plain.split("\n"):
			var found = name_match.search(line) != null
			mentioned = mentioned or found
			if found and (required.search(line) != null or heading) and negative.search(line) == null:
				needed = true
			heading = line.strip_edges() in ["requirements", "requirements:", "dependencies", "dependencies:"]
		if mentioned:
			result.append({"mod":candidate, "required":needed, "linked":direct.has(candidate.download)})
	return result
