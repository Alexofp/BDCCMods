extends Node

signal changed

var language = "en"
var cache = {}
var busy = false
var queued = false
var translator
var extra = ["Translate", "Original", "Yes", "No", "Enabled", "Disabled", "Author", "Mod", "Game", "Requires", "Linked", "Mentioned", "installed", "not installed", "Update required", "Up to date", "Version unknown", "Not in catalogue", "Incompatible with game", "Reload the game page to apply changes.", "mods", "Image unavailable", "Loading preview...", "No linked mods detected", "No metadata", "Metadata unavailable for PCK", "Restart the game to apply changes."]

func _ready():
	translator = load("res://Util/AutoTranslation/AutoTranslation.gd").new()
	add_child(translator)
	translator.loadData(AutoTranslation.saveData())
	translator.setShouldTranslate(true)

func tr(source):
	return cache.get(language, {}).get(source, source) if language != "en" else source

func field(node, kind, value, index = -1):
	var key = "mm_"+kind+str(index)
	var saved = node.get_meta(key) if node.has_meta(key) else {"source":value, "last":value}
	if value != saved.last:
		saved.source = value
	node.set_meta(key, saved)
	return {"node":weakref(node), "kind":kind, "source":saved.source, "key":key, "index":index}

func fields(root):
	var result = []
	if root.has_meta("no_translate"):
		return result
	if root is Tree:
		for i in range(root.columns):
			result.append(field(root, "column", root.get_column_title(i), i))
	elif root is OptionButton:
		for i in range(root.get_item_count()):
			result.append(field(root, "option", root.get_item_text(i), i))
	elif root is RichTextLabel:
		result.append(field(root, "bbcode_text", root.bbcode_text))
	elif root is Label or root is Button or root is AcceptDialog:
		var property = "dialog_text" if root is AcceptDialog else "text"
		result.append(field(root, property, root.get(property)))
		if root is AcceptDialog:
			result.append(field(root, "window_title", root.window_title))
			result.append(field(root.get_ok(), "text", root.get_ok().text))
			if root is ConfirmationDialog:
				result.append(field(root.get_cancel(), "text", root.get_cancel().text))
	elif root is LineEdit:
		result.append(field(root, "placeholder_text", root.placeholder_text))
	for child in root.get_children():
		# Native internal widgets inherit their owner's text; translate public controls only.
		if not root is Tree and not root is OptionButton and not root is AcceptDialog:
			result += fields(child)
	return result

func apply(root):
	if not is_instance_valid(root) or not root.is_inside_tree():
		return
	var missing = false
	for binding in fields(root):
		var node = binding.node.get_ref()
		var text = tr(binding.source)
		if binding.kind == "column":
			node.set_column_title(binding.index, text)
		elif binding.kind == "option":
			node.set_item_text(binding.index, text)
		else:
			node.set(binding.kind, text)
		node.set_meta(binding.key, {"source":binding.source, "last":text})
		missing = missing or (not binding.source.empty() and not cache.get(language, {}).has(binding.source))
	if language != "en" and missing and not busy and not queued:
		queued = true
		call_deferred("refresh", weakref(root))

func refresh(reference):
	queued = false
	var root = reference.get_ref()
	if root != null and root.is_inside_tree() and not busy:
		translate_screen(root, language)

func toggle_screen(root, target):
	return translate_screen(root, "en" if language != "en" else target)

func translate_screen(root, target):
	if busy:
		return
	var collected = fields(root)
	if target == "en":
		language = "en"
		apply(root)
		emit_signal("changed")
		return
	busy = true
	var existing = cache.get(target, {})
	var sources = extra.duplicate()
	for binding in collected:
		if not binding.source.empty() and not binding.source in sources:
			sources.append(binding.source)
	var inputs = {}
	var protected = {}
	var regex = RegEx.new()
	regex.compile("(\\[[^\\]\\n]*\\]|https?://[^\\s\\[\\]]+|user://[^\\s\\[\\]]+)")
	for source in sources:
		if existing.has(source):
			continue
		var text = ""
		var position = 0
		var tokens = []
		for match_result in regex.search_all(source):
			var token = "ZXQKEEP"+str(tokens.size())+"QXZ"
			tokens.append([token, match_result.get_string()])
			text += source.substr(position, match_result.get_start()-position)+token
			position = match_result.get_end()
		text += source.substr(position)
		inputs[source] = text
		protected[source] = tokens
	if not inputs.empty():
		translator.setTargetLanguage(target)
		var output = translator.translateDict(inputs)
		if output is GDScriptFunctionState:
			output = yield(output, "completed")
		for source in inputs:
			var text = output.get(source, inputs[source])
			var valid = true
			for pair in protected[source]:
				valid = valid and pair[0] in text
				text = text.replace(pair[0], pair[1])
			existing[source] = text.strip_edges() if valid else source
	cache[target] = existing
	language = target
	busy = false
	if is_instance_valid(root):
		apply(root)
	emit_signal("changed")
