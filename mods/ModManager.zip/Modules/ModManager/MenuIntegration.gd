extends Node

func _ready():
	get_tree().connect("node_added", self, "node_added")

func node_added(node):
	if node.filename == "res://UI/ModsMenu/ModsMenu.tscn":
		call_deferred("attach", weakref(node))

func attach(reference):
	var menu = reference.get_ref()
	if menu == null or not menu.is_inside_tree():
		return
	var grid = menu.get_node("VBoxContainer/GridContainer")
	if grid.has_node("ModManagerButton"):
		return
	var button = load("res://Game/UI/Buttons/BetterButton.tscn").instance()
	button.name = "ModManagerButton"
	button.text = "ModManager"
	button.myShortcutKey = "W"
	button.connect("pressedActually", self, "open_manager", [menu])
	grid.add_child(button)

func open_manager(menu):
	var host = menu.get_parent()
	while host != null and not host.has_method("setCustomScreen"):
		host = host.get_parent()
	if host == null or host.has_node("ModManager"):
		return
	var manager = load("res://Modules/ModManager/Manager.gd").new()
	manager.name = "ModManager"
	host.setCustomScreen(manager)
