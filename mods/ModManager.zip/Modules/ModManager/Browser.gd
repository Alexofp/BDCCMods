extends PanelContainer

const CATALOGUE = "https://raw.githubusercontent.com/Alexofp/BDCCMods/main/allmods.json"
const Links = preload("res://Modules/ModManager/ContentLinks.gd")
var mods = []
var filtered = []
var selected = null
var page = 0
var page_size = 15
var item_height = 0.0
var pending = false
var translating = false
var downloading = false
var download_entry = null
var temp_path = ""
var search:LineEdit
var sorting:OptionButton
var compatible:CheckBox
var list:ItemList
var pages:Label
var previous:Button
var next:Button
var details:RichTextLabel
var description_source:RichTextLabel
var status:Label
var install:Button
var translate_button:Button
var language:OptionButton
var close_button:Button
var refresh:Button
var catalogue_request:HTTPRequest
var download_request:HTTPRequest
var translator
var gallery
var back_button:Button
var ui
var preview_cache = {}
var notice:AcceptDialog
var installed_archives = {}
var installed_infos = {}

func button(parent, text, method):
	var node = Button.new()
	node.text = text
	node.connect("pressed", self, method)
	parent.add_child(node)
	return node

func _ready():
	set_anchors_and_margins_preset(Control.PRESET_WIDE)
	if ui == null:
		ui = load("res://Modules/ModManager/UiTranslation.gd").new()
		add_child(ui)
	ui.connect("changed", self, "refresh_translation")
	var margin = MarginContainer.new()
	for side in ["left", "top", "right", "bottom"]:
		margin.add_constant_override("margin_"+side, 16)
	add_child(margin)
	var box = VBoxContainer.new()
	box.add_constant_override("separation", 10)
	margin.add_child(box)
	var header = HBoxContainer.new()
	box.add_child(header)
	back_button = button(header, "← Back", "go_back")
	close_button = back_button
	back_button.disabled = false
	var title = Label.new()
	title.text = "Mod Browser"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	refresh = button(header, "Refresh", "fetch_catalogue")
	var tools = HBoxContainer.new()
	box.add_child(tools)
	search = LineEdit.new()
	search.placeholder_text = "Search name, author, description"
	search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search.connect("text_changed", self, "filter_changed")
	tools.add_child(search)
	sorting = OptionButton.new()
	for text in ["Newest", "Oldest", "Name"]:
		sorting.add_item(text)
	sorting.connect("item_selected", self, "filter_changed")
	tools.add_child(sorting)
	compatible = CheckBox.new()
	compatible.text = "Compatible"
	compatible.connect("toggled", self, "filter_changed")
	tools.add_child(compatible)
	language = OptionButton.new()
	language.set_meta("no_translate", true)
	for code in TranslationLanguage.langs:
		language.add_item(code)
		language.get_popup().set_item_tooltip(language.get_item_count()-1, TranslationLanguage.langs[code])
	var current_language = ui.language if ui.language != "en" else AutoTranslation.getTargetLanguage()
	for i in range(language.get_item_count()):
		if language.get_item_text(i).split(" ")[0] == current_language:
			language.select(i)
	language.connect("item_selected", self, "language_changed")
	tools.add_child(language)
	translate_button = button(tools, "Translate", "translate_description")
	translate_button.set_meta("no_translate", true)
	translate_button.text = ui.tr("Original") if ui.language != "en" else "Translate"
	var body = HSplitContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(body)
	var left = VBoxContainer.new()
	left.rect_min_size.x = 360
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(left)
	list = ItemList.new()
	list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	list.connect("item_selected", self, "select_item")
	left.add_child(list)
	var navigation = HBoxContainer.new()
	left.add_child(navigation)
	previous = button(navigation, "<", "previous_page")
	pages = Label.new()
	pages.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pages.align = Label.ALIGN_CENTER
	pages.set_meta("no_translate", true)
	navigation.add_child(pages)
	next = button(navigation, ">", "next_page")
	var right = VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(right)
	install = button(right, "Download", "download_mod")
	install.disabled = true
	# Keep the complete translatable BBCode separate from native inline textures.
	description_source = RichTextLabel.new()
	description_source.hide()
	add_child(description_source)
	details = RichTextLabel.new()
	details.set_meta("no_translate", true)
	details.bbcode_enabled = true
	details.selection_enabled = true
	details.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.connect("meta_clicked", self, "open_link")
	details.connect("resized", self, "schedule_description")
	right.add_child(details)
	gallery = load("res://Modules/ModManager/MediaGallery.gd").new()
	gallery.cache = preview_cache
	gallery.connect("changed", self, "render_description")
	add_child(gallery)
	status = Label.new()
	status.set_meta("no_translate", true)
	status.hide()
	add_child(status)
	notice = AcceptDialog.new()
	add_child(notice)
	catalogue_request = HTTPRequest.new()
	catalogue_request.timeout = 30
	catalogue_request.connect("request_completed", self, "catalogue_received")
	add_child(catalogue_request)
	download_request = HTTPRequest.new()
	download_request.timeout = 180
	download_request.connect("request_completed", self, "download_finished")
	add_child(download_request)
	translator = ui.translator
	show_original()
	fetch_catalogue()
	list.connect("resized", self, "schedule_resize")
	call_deferred("resize_page")
	ui.apply(self)

func fetch_catalogue():
	refresh.disabled = true
	report("Loading catalogue...")
	var error = catalogue_request.request(CATALOGUE)
	if error != OK:
		refresh.disabled = false
		report("Cannot load catalogue: " + str(error), true)

func catalogue_received(result, code, _headers, body):
	refresh.disabled = false
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		report("Catalogue request failed: HTTP " + str(code), true)
		return
	var parsed = JSON.parse(body.get_string_from_utf8())
	if parsed.error != OK or not parsed.result is Dictionary or not parsed.result.get("mods") is Array:
		report("Invalid catalogue", true)
		return
	var previous_download = "" if selected == null else selected.download
	mods.clear()
	installed_infos.clear()
	for entry in parsed.result.mods:
		if not entry is Dictionary:
			continue
		var valid = true
		for field in ["name", "author", "description", "download", "modversion", "gameversion"]:
			if not entry.get(field) is String:
				valid = false
		if valid:
			var copy = entry.duplicate()
			copy.modversion = Links.clean_version(copy.modversion)
			copy["index"] = mods.size()
			mods.append(copy)
	selected = null
	for entry in mods:
		if entry.download == previous_download:
			selected = entry
	back_button.disabled = false
	if selected != null:
		update_extra_content()
	else:
		gallery.set_description("")
		show_original()
	report("Catalogue loaded: " + str(mods.size()))
	filter_changed()

func filter_changed(_value = null):
	filtered.clear()
	var query = search.text.strip_edges().to_lower()
	for entry in mods:
		var haystack = entry.author if query.begins_with("@") else entry.name+" "+entry.author+" "+entry.description
		var needle = query.trim_prefix("@")
		if not needle.empty() and not needle in haystack.to_lower():
			continue
		if compatible.pressed and not GlobalRegistry.isVersionListHasCompatible(entry.gameversion):
			continue
		filtered.append(entry)
	filtered.sort_custom(self, "compare_mods")
	page = 0
	render_page()

func compare_mods(a, b):
	if sorting.selected == 2:
		return a.name.to_lower() < b.name.to_lower()
	return a.index < b.index if sorting.selected == 1 else a.index > b.index

func render_page():
	refresh_installed()
	var count = max(1, int(ceil(float(filtered.size()) / page_size)))
	page = int(clamp(page, 0, count-1))
	list.clear()
	for i in range(page*page_size, min((page+1)*page_size, filtered.size())):
		var entry = filtered[i]
		var state = installation_state(entry)
		list.add_item(("["+ui.tr(state)+"] " if state != "not installed" else "")+entry.name+" — "+entry.author+"  ("+entry.modversion+")")
		list.set_item_tooltip(list.get_item_count()-1, entry.name+"\n"+entry.author+"\n"+ui.tr("Game")+": "+entry.gameversion)
		if entry == selected:
			list.select(list.get_item_count()-1)
	pages.text = "%d / %d · %d " % [page+1, count, filtered.size()]+ui.tr("mods")
	previous.disabled = page == 0
	next.disabled = page == count-1
	ui.apply(self)
	call_deferred("resize_page")

func previous_page():
	page -= 1
	render_page()

func next_page():
	page += 1
	render_page()

func schedule_resize():
	call_deferred("resize_page")

func resize_page():
	var height = list.rect_size.y-list.get_stylebox("bg").get_minimum_size().y
	var row_height = item_height if item_height > 0 else list.get_font("font").get_height()+2*list.get_constant("vseparation")
	# ItemList rounds its font metrics and padding; measure actual row starts.
	var starts = {}
	if list.get_item_count() >= 5:
		for y in range(int(min(list.rect_size.y, row_height*6))):
			var index = list.get_item_at_position(Vector2(10, y), true)
			if index in [1, 4] and not starts.has(index):
				starts[index] = y
		if starts.has(1) and starts.has(4):
			item_height = max(item_height, ceil(float(starts[4]-starts[1])/3))
			row_height = item_height
	var count = max(1, int(height/max(1, row_height)))
	if count != page_size:
		var first = page*page_size
		page_size = count
		page = int(first/page_size)
		render_page()

func refresh_translation():
	translate_button.text = ui.tr("Original") if ui.language != "en" else "Translate"
	render_page()
	render_description()

func restore_original():
	ui.translate_screen(self, "en")

func report(message, error = false):
	status.text = message
	if error:
		notice.dialog_text = message
		ui.apply(self)
		notice.popup_centered()

func select_item(index):
	selected = filtered[page*page_size+index]
	update_extra_content()

func update_extra_content():
	gallery.set_description(selected.description)
	show_original()

func dependency_text():
	var text = ""
	for relation in Links.related(selected, mods):
		var target = relation.mod
		var kind = "Requires" if relation.required else "Linked" if relation.linked else "Mentioned"
		text += kind+": [url=mod://"+str(target.index)+"]"+safe_bb(target.name)+"[/url] ("+installation_state(target)+")\n"
	return "[color=#d7f0ff]"+(text.strip_edges() if not text.empty() else "No linked mods detected")+"[/color]"

func jump_to_mod(entry):
	search.text = ""
	compatible.pressed = false
	filter_changed()
	selected = entry
	page = int(filtered.find(entry)/page_size)
	render_page()
	update_extra_content()
	back_button.disabled = downloading or translating

func go_back():
	close_browser()

func safe_bb(text):
	return str(text).replace("[", "[lb]")

func show_original():
	if selected == null:
		description_source.bbcode_text = "Select a mod"
		install.disabled = true
		translate_button.disabled = false
		ui.apply(self)
		render_description(false)
		return
	show_description(selected.description)

func show_description(description):
	var version = safe_bb(selected.gameversion)
	var mod_version = safe_bb(selected.modversion)
	if not GlobalRegistry.isVersionListHasCompatible(selected.gameversion):
		version = "[color=#ff9999]"+version+" (check compatibility)[/color]"
		mod_version = "[color=#ff9999]"+mod_version+"[/color]"
	description_source.bbcode_text = "[b]"+safe_bb(selected.name)+"[/b]\nAuthor: "+safe_bb(selected.author)+"\nMod: "+mod_version+"\nGame: "+version+"\n\n"+dependency_text()+"\n\n"+description
	install.disabled = downloading or File.new().file_exists(mod_path(selected))
	install.text = "Already installed" if File.new().file_exists(mod_path(selected)) else "Download"
	translate_button.disabled = translating
	ui.apply(self)
	render_description(false)

func schedule_description():
	call_deferred("render_description")

func render_description(keep_scroll = true):
	var scroll = details.get_v_scroll().value if keep_scroll else 0.0
	var source = description_source.bbcode_text
	var regex = RegEx.new()
	regex.compile("(?is)\\[url=([^\\]]+)\\](.*?)\\[/url\\]|\\[img(?:=[^\\]]*)?\\](https?://.*?)\\[/img\\]|https?://[^\\s\\[\\]<>\"']+")
	var markup = ""
	var position = 0
	for match_result in regex.search_all(source):
		var url = match_result.get_string(1)
		if url.empty():
			url = match_result.get_string(3)
		if url.empty():
			url = match_result.get_string()
		if not Links.is_image(url):
			continue
		markup += source.substr(position, match_result.get_start()-position)
		if preview_cache.has(url):
			var texture = preview_cache[url]
			var width = min(texture.get_width(), max(1, details.rect_size.x-24))
			# A cached resource path lets native BBCode keep formatting across images without disk files.
			if texture.resource_path.empty():
				texture.take_over_path("res://ModManagerPreview/"+str(texture.get_instance_id())+".png")
			markup += "\n[img="+str(int(width))+"x"+str(int(width*texture.get_height()/texture.get_width()))+"]"+texture.resource_path+"[/img]\n"
		elif gallery.errors.has(url):
			markup += "[url="+url+"]"+ui.tr("Image unavailable")+"[/url]\n"
		else:
			markup += ui.tr("Loading preview...")+"\n"
		position = match_result.get_end()
	details.bbcode_text = markup+source.substr(position)
	details.get_v_scroll().set_deferred("value", scroll)

func language_changed(_index):
	show_original()

func translate_description():
	if translating or ui.busy:
		return
	translating = true
	translate_button.disabled = true
	back_button.disabled = true
	var result = ui.toggle_screen(self, language.get_item_text(language.selected))
	if result is GDScriptFunctionState:
		yield(result, "completed")
	translating = false
	translate_button.disabled = false
	back_button.disabled = downloading
	report("Translation ready")

func mod_path(entry):
	return GlobalRegistry.getModsFolder().plus_file(entry.download.get_file())

func refresh_installed():
	installed_archives.clear()
	for path in GlobalRegistry.getRawModList():
		installed_archives[Links.archive_stem(path)] = path

func installed_path(entry):
	var exact = mod_path(entry)
	if File.new().file_exists(exact):
		return exact
	return installed_archives.get(Links.archive_stem(entry.download), "")

func installation_state(entry):
	var path = installed_path(entry)
	if path.empty():
		return "not installed"
	if not installed_infos.has(path):
		installed_infos[path] = Links.local_info(path)
	var state = Links.state_from_version(installed_infos[path].get("modversion", ""), entry)
	return "installed" if state == "Up to date" else state

func download_mod():
	if selected == null or downloading:
		return
	var filename = selected.download.get_file()
	if not selected.download.begins_with("https://") or not filename.get_extension() in ["zip", "pck"] or filename in ["BDCC.pck", "", ".", ".."] or ":" in filename or "\\" in filename:
		report("Unsupported download URL", true)
		return
	if File.new().file_exists(mod_path(selected)):
		report("Already installed; manage it in the launcher", true)
		return
	var directory = Directory.new()
	var error = directory.make_dir_recursive(GlobalRegistry.getModsFolder())
	if error != OK:
		report("Cannot create mods folder: "+str(error), true)
		return
	download_entry = selected.duplicate()
	temp_path = mod_path(download_entry)+".mbplus-part"
	download_request.download_file = temp_path
	downloading = true
	install.disabled = true
	close_button.disabled = true
	report("Downloading: "+selected.name)
	error = download_request.request(selected.download)
	if error != OK:
		finish_download(false, "Download request failed: "+str(error))

func download_finished(result, code, _headers, _body):
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		finish_download(false, "Download failed: HTTP "+str(code))
		return
	var file = File.new()
	if file.open(temp_path, File.READ) != OK:
		finish_download(false, "Cannot read download")
		return
	var magic = file.get_buffer(4)
	file.close()
	var expected = [80, 75, 3, 4] if temp_path.ends_with(".zip.mbplus-part") else [71, 68, 80, 67]
	if Array(magic) != expected:
		finish_download(false, "Invalid mod archive")
		return
	if File.new().file_exists(mod_path(download_entry)):
		finish_download(false, "Destination exists")
		return
	var error = Directory.new().rename(temp_path, mod_path(download_entry))
	finish_download(error == OK, "Download complete" if error == OK else "Cannot install download: "+str(error))

func finish_download(success, message):
	downloading = false
	close_button.disabled = translating
	if not success and not temp_path.empty():
		Directory.new().remove(temp_path)
	if success:
		pending = true
		# Keep this reminder for every reopening of the browser in this process.
		get_tree().set_meta("ModManager_pending", true)
	report(message, not success)
	render_page()
	show_original()

func open_link(url):
	url = str(url)
	if url.begins_with("mod://"):
		var index = int(url.trim_prefix("mod://"))
		if index >= 0 and index < mods.size():
			jump_to_mod(mods[index])
		return
	if Links.is_image(url):
		gallery.open_image(url)
		return
	var target = Links.target_for_url(url, mods)
	if target != null:
		jump_to_mod(target)
		return
	if str(url).begins_with("https://") or str(url).begins_with("http://"):
		Util.fixed_shell_open(str(url))

func close_browser():
	if downloading or translating or ui.busy:
		return
	queue_free()
