extends Node

# Runs in a separate minimal Godot process, only after an explicit Update action.
func _ready():
	call_deferred("run")

func read_text(path):
	var file = File.new()
	if file.open(path, File.READ) != OK:
		return null
	var text = file.get_as_text()
	file.close()
	return text

func write_text(path, text):
	var file = File.new()
	var temporary = path+".tmp"
	if file.open(temporary, File.WRITE) != OK:
		return false
	file.store_string(text)
	file.flush()
	var error = file.get_error()
	file.close()
	return error == OK and Directory.new().rename(temporary, path) == OK

func canonical(path):
	var result = path.replace("\\", "/").simplify_path()
	return result.to_lower() if OS.get_name() == "Windows" else result

func absolute_key(path, profile):
	return profile.plus_file(path.trim_prefix("user://")) if path.begins_with("user://") else path

func apply_job(job, settings, job_folder):
	if not job is Dictionary:
		return "Invalid update record"
	for field in ["old", "destination", "staged", "old_key", "new_key", "version", "sha256"]:
		if not job.get(field) is String or job[field].empty():
			return "Invalid update record field"
	if not settings.get("mods_folder") is String or not settings.get("order_path") is String:
		return "Invalid update settings"
	var profile = job_folder.get_base_dir().get_base_dir()
	if canonical(settings.order_path) != canonical(profile.plus_file("modOrder.json")):
		return "Invalid mod order location"
	var root = canonical(settings.mods_folder)
	if canonical(job.old).get_base_dir() != root or canonical(job.destination).get_base_dir() != root or canonical(job.staged).get_base_dir() != canonical(job_folder):
		return "Invalid update paths"
	if canonical(absolute_key(job.old_key, profile)) != canonical(job.old) or canonical(absolute_key(job.new_key, profile)) != canonical(job.destination):
		return "Archive path does not match mod order key"
	if job.old.get_file().to_lower() == "bdcc.pck" or job.destination.get_file().to_lower() == "bdcc.pck" or not job.destination.get_extension().to_lower() in ["zip", "pck"]:
		return "Protected destination"
	if not File.new().file_exists(job.staged) or File.new().get_sha256(job.staged) != job.sha256:
		return "Staged archive missing or checksum mismatch"
	var original = read_text(settings.order_path)
	if original == null:
		return "Cannot read mod order"
	var parsed = JSON.parse(original)
	if parsed.error != OK or not parsed.result is Array:
		return "Invalid mod order"
	var index = -1
	for i in range(parsed.result.size()):
		var entry = parsed.result[i]
		if not entry is Dictionary or not entry.get("path") is String or not entry.get("disabled") is bool:
			return "Invalid mod order entry"
		if entry.path == job.old_key:
			index = i
	if index < 0:
		return "Mod is no longer present in the saved order"
	if canonical(job.old) != canonical(job.destination) and File.new().file_exists(job.destination):
		return "Destination archive already exists"
	var directory = Directory.new()
	# Keep the old file only until the archive and order transaction commits.
	var previous = job.staged+".previous"
	if File.new().file_exists(previous):
		return "Temporary replacement file already exists; original archive preserved"
	if directory.rename(job.old, previous) != OK:
		return "Original archive is still locked or inaccessible"
	if directory.rename(job.staged, job.destination) != OK:
		directory.rename(previous, job.old)
		return "Cannot install downloaded archive"
	parsed.result[index].path = job.new_key
	if read_text(settings.order_path) != original or directory.copy(settings.order_path, settings.order_path+".modmanager-update-backup") != OK or not write_text(settings.order_path, JSON.print(parsed.result, "\t", true)):
		directory.rename(job.destination, job.staged)
		directory.rename(previous, job.old)
		return "Cannot save mod order; archives rolled back"
	if directory.remove(previous) != OK:
		return "Update installed, but the previous temporary archive could not be deleted"
	return ""

func run():
	var job_path = ""
	for argument in OS.get_cmdline_args():
		if argument.begins_with("--modmanager-job="):
			job_path = argument.trim_prefix("--modmanager-job=")
	var initial = read_text(job_path)
	if initial == null:
		get_tree().quit(1)
		return
	var parsed = JSON.parse(initial)
	if parsed.error != OK or not parsed.result is Dictionary or not parsed.result.get("pid") is float and not parsed.result.get("pid") is int:
		get_tree().quit(1)
		return
	if int(parsed.result.pid) <= 0:
		get_tree().quit(1)
		return
	while OS.is_process_running(int(parsed.result.pid)):
		yield(get_tree().create_timer(0.2), "timeout")
	var latest = read_text(job_path)
	parsed = JSON.parse(latest if latest != null else "{}")
	if parsed.error != OK or not parsed.result is Dictionary or not parsed.result.get("updates") is Array:
		get_tree().quit(1)
		return
	var settings = parsed.result
	var results = []
	for job in settings.updates:
		var error = apply_job(job, settings, job_path.get_base_dir())
		results.append({"old":job.get("old", "") if job is Dictionary else "", "destination":job.get("destination", "") if job is Dictionary else "","version":job.get("version", "") if job is Dictionary else "","error":error})
	write_text(job_path.get_base_dir().plus_file("result.json"), JSON.print(results, "\t", true))
	Directory.new().remove(job_path)
	print("MODMANAGER_UPDATES_FINISHED ", results.size())
	get_tree().quit()
