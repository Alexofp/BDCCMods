extends EventBase

var scalepanel = preload("res://Modules/ScaleTweak/ScalePanel.tscn")
const AnimEdit = preload("res://Modules/ScaleTweak/ApplyST.gd")
var ApplyST = AnimEdit.new() # instnce of AnimEdit object, which will do all the tweaking
var runOnce:bool


func _init():
	id = "tweakApplyEvent"
	runOnce = true
	
#func _ready():
#	GM.main.connect("saveLoadingFinished", self, run("","")) # doesn't work

func registerTriggers(es):
	es.addTrigger(self, Trigger.SceneAndStateHook, ["WorldScene", ""]) # this is the base scene of the game

func run(_triggerID, _args):
	if(not is_connected("AnimChanged", self, "onChange")):
		GM.ui.getStage3d().connect("AnimChanged", self, "onChange") # connect the display window to onChange function
	if(runOnce): #make sure we get a fresh database
		setFlag("ScaleTweak.data", {})
		runOnce = false
	if(getFlag("ScaleTweak.data", null).empty()):
		loadData()
	var GUI = GM.ui # the main UI
	var weh = scalepanel.instance() # the scale panel
	if(GUI.debugScreen.get_child(0).get_child_count()<7): # sneak the scale panel into the debug UI, but only if it's not already present
		GUI.debugScreen.get_child(0).add_child(weh)
		var _ew = GUI.debugScreen.get_child(0).get_children()

# pretty much the same as in ScalePanel.gd
func loadData():
	var baseDir = GlobalRegistry.getModsFolder()
	var f:File = File.new()
	if(not f.file_exists(baseDir.plus_file("ScaleTweakSave.json"))):
		return
	var jsonResult
	var _err = f.open(baseDir.plus_file("ScaleTweakSave.json"),File.READ)
	assert(_err == OK,"[ScaleTweak] Saved poses file not found or does not exist")
	jsonResult = JSON.parse(f.get_as_text())
	assert(typeof(jsonResult.result) == TYPE_DICTIONARY, "[ScaleTweak] Could not read saved data file")
	var info = jsonResult.result	
	setFlag("ScaleTweak.heightList", info["heightList"])
	setFlag("ScaleTweak.data", info)
	

func getPriority():
	return 0

func onChange():
	if(GM.ui.debugScreen.visible): # do not try to tweak while we are editing the database in scalepanel
		return
	if(GM.main.getCurrentScene().sceneID == "FightScene"):
		return # temporary fix for 0.4.0
	ApplyST.on_change_stage(GM.ui.getStage3d().currentScene) # call the AnimEdit object to do all the tweaking
	return
