extends Module

var heightList = {}
var data = {}
var hack

func _init():
	id = "ScaleTweak"
	author = "bringulbangul"
	scenes = [
		
	]
	events = [
		"res://Modules/ScaleTweak/event.gd"
	]
	gameExtenders = [
		
	]
	
	
	
func getFlags():
	return {
		"heightList": flag(FlagType.Dict),
		"data": flag(FlagType.Dict),
		"rootRef": flag(FlagType.Anything)
	}


func preInit(): # Called before anything gets registered
	pass

func postInit(): # Called after everything is registered
	var target = load("res://Player/Stage3D/Stage3D.gd")
	var original = target.source_code
	var modified = original.replace("onready var animPlayer = $AnimationPlayer", "onready var animPlayer = $AnimationPlayer\nsignal AnimChanged()")
	modified = modified.replace("newScene.playAnimationFinal(actionID, args)", "newScene.playAnimationFinal(actionID, args)\n\temit_signal(\"AnimChanged\")")
	target.source_code = modified
	target.reload()
	

