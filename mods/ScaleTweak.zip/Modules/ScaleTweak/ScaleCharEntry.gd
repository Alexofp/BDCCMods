extends Control

var UUID
var CharID
var dollIns
var scale = 1
var customPose:Quat
var originalPose:Transform
var original = 0
var saved = null
var charPos = 0

onready var spin = $VBoxContainer/HBoxContainer/SpinBox
onready var slide = $VBoxContainer/HBoxContainer/HSlider
onready var resetbutton = $VBoxContainer/HBoxContainer/ResetButton
onready var loadsaved = $VBoxContainer/HBoxContainer/loadSavedbutton
onready var label = $VBoxContainer/Label

signal ResetScale(CharID, caller)
signal sliderChanged(CharID, value, caller)

func setNameAndValue(newtext, _newvalue):
	$VBoxContainer/Label.text = str(newtext)
	$VBoxContainer/HBoxContainer/SpinBox.value = _newvalue
	
func setActive(active):
	if(active):
		spin.editable = true
		slide.editable = true
		resetbutton.disabled = false
		loadsaved.disabled = false
	else:
		spin.editable = false
		slide.editable = false
		resetbutton.disabled = true
		loadsaved.disabled = true
	
func setminmaxsymmetric(_value):
	slide.min_value = -1*_value
	slide.max_value = _value
#	slide.step = _value/100
	spin.min_value = -1*_value
	spin.max_value = _value
#	spin.step = _value/100

func setminmax(_min, _max):
	slide.min_value = _min
	slide.max_value = _max
#	slide.step = _value/100
	spin.min_value = _min
	spin.max_value = _max
	
func setBoth(num):
	if(num > spin.max_value || num < spin.min_value):
		spin.value = original
		slide.value = original
	else:
		spin.value = num
		slide.value = num
	
func set_saved(num):
	saved = num
	
func set_original(num):
	original = num

func _on_ResetButton_pressed():
	spin.value = original
	emit_signal("ResetScale", CharID, self)
	
func _on_SpinBox_value_changed(_value):
	spin.share(slide)
	emit_signal("sliderChanged", CharID, _value, self)

func _on_HSlider_value_changed(_value):
	spin.value = _value

func _on_loadButton_pressed():
	if(not saved):
		spin.value = original
		slide.value = original
	else:
		spin.value = saved
		slide.value = saved
