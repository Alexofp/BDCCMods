extends WindowDialog

var scaleHeightentry = preload("res://Modules/ScaleTweak/ScaleCharEntry.tscn")
onready var filterEdit = $VBoxContainer/SearchBar/LineEdit
onready var HeightUI = $VBoxContainer/ScrollContainer/VBoxContainer

var localHeightList = {}
var globalHeightList = {}

signal EditHeightList(localHeightList)


func updateCharList(_globalHeightList):
	var filterText = filterEdit.text.to_lower()
	Util.delete_children(HeightUI) #clear any previous stuff
	if(GM.main == null):
		return
	var chars = GM.main.staticCharacters.keys() # get a list of all the pre-made characters
	chars.push_front("pc") # add pc to top of the list for convenience
	chars.append_array(GM.main.dynamicCharacters.keys())
	for pers in chars:
		if(pers in ["ghostHands","testchar","intro_detective","errorerror","latexParasite", "plantTentacles", "shemaleguard"]):
			continue # skip certain "characters" that don't have any visuals
		if("stash" in pers.to_lower() or "bidder" in pers.to_lower() or "inmate" in pers or "crowd" in pers.to_lower()):
			continue # skip certain "characters" that don't have any visuals
		var theName = GM.main.getCharacter(pers).getName()
		if(filterText != "" && !(filterText in theName.to_lower())):
			continue # if something is typed int the search box, only show the ones that match
		var newheightentry = scaleHeightentry.instance() # each characterID is mapped to an instance of this subscene (a cluster of controls)
		HeightUI.add_child(newheightentry) # add the control cluster to the UI
		newheightentry.setNameAndValue(theName + " ["+pers+"]",1) # save some useful data in the control instance
		newheightentry.CharID = pers
		newheightentry.loadsaved.visible = false
		newheightentry.set_original(1)
		newheightentry.set_saved(_globalHeightList[pers])
		newheightentry.setminmax(0.1,2) # custom method to set min and max of all controls in the cluster
		newheightentry.spin.value = _globalHeightList[pers]
		var _eorp = newheightentry.connect("sliderChanged", self, "onScaleEdit") # connect to custom signal of the instance (change in height setting)(used because two controls are linked)

func onScaleEdit(_charID, _value, _caller):
	localHeightList[_charID] = _value # save to the local heightList

func _on_CancelButton_pressed():
	Util.delete_children(HeightUI)
	visible = false


func _on_ChangeFlagButton_pressed():
	emit_signal("EditHeightList", localHeightList)
	yield(get_tree().create_timer(0.3), "timeout")
	visible = false
	Util.delete_children(HeightUI)


func _on_LineEdit_text_entered(_new_text):
	updateCharList(globalHeightList)


func _on_Button_pressed():
	updateCharList(globalHeightList)
