extends Node
class_name AnimEdit # custom class made for getting and applying scaletweak database

var stage:BaseStageScene3D
var theScene
var theState
var theVariant:String
var theSlot

var debug = true

var info = {}
var heightList = {}
const position = ["pc", "npc", "npc2", "npc3"]
const variants = ["var1","var2","var3","var4"]

var lineup = [0, 0, 0, 0]

func on_change_stage(_stageIns:BaseStageScene3D):
	stage = _stageIns
	theScene = stage.id
	theState = stage.currentAnim
	lineup = []
	lineup.resize(4)
	lineup.fill(float(1)) # consequence of slider controls and JSON - the values are read as floats, so we need floats to compare with them
	if(info.empty()):
		info = GM.main.getFlag("ScaleTweak.data", {}) #database gets saved to module flag in event.gd
		heightList = GM.main.getFlag("ScaleTweak.heightList", {})
		if(info.empty()):
			return #database wasn't loaded from file
	
	if(info[theScene].get_or_add(theState,{}).empty()):
		Log.print("[ScaleTweak] No edits to apply for "+theScene +":" + theState)
		return
	theVariant = parseScene() # this is a string!
	if(theVariant=="-1"):
		Log.print("[ScaleTweak] Animation found in database, but either there are no edits or the heights did not match")
		return
	elif(theVariant in ["0","1","2","3"]):
		Log.print("[ScaleTweak] Applying "+theScene +":" + theState+" variant"+theVariant+"")
	

	for pos in position:
#		var key = info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{})
		if(not info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).has(pos) || stage.getDolls().size() <= position.find(pos)):
			continue
		var theDoll:Doll3D = stage.getDolls()[position.find(pos)]
		theDoll.checkDirection()
		var Name = theDoll.savedCharacterID
		if(debug): 
			Log.print("[ScaleTweak] size "+Name+" set to "+String(info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add("scale",1.0)))
		ScaleEdit(theDoll, info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add("scale",1))
		for thing in info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}):
			if(thing == "dx"):
				if(debug): Log.print("[ScaleTweak] move "+Name+" to x="+String(info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add("dx",0)))
				XOffset(theDoll, info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add("dx",0))
			elif(thing == "dy"):
				if(debug): Log.print("[ScaleTweak] move "+Name+" to y="+String(info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add("dy",0)))
				YOffset(theDoll, info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add("dy",0))
			elif(thing != "scale"):
				var _fw = info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add(thing,0)
				if(debug): Log.print("[ScaleTweak] move "+Name+" "+thing+" to "+String(int(rad2deg(asin(_fw[2])*2)))+" degrees" )
				boneEdit(theDoll, info[theScene].get_or_add(theState,{}).get_or_add(theVariant,{}).get_or_add(pos, {}).get_or_add(thing,0), theBoneList.find(thing))
			


func parseScene():
	var theDolls = stage.getDolls()
	var theIDs = []
	for doll in theDolls:
		theIDs.append(doll.savedCharacterID)
	var _idx = 0
	var _debugstring = "position "
	for pers in theIDs:
		lineup[_idx] = heightList.get_or_add(pers, 1.0)
		_debugstring += "\""+position[_idx]+"\", "+String(heightList[pers])+" & "
		_idx += 1
	_debugstring = _debugstring.rstrip("& ")
	Log.print("[ScaleTweak] Looking for "+theScene +":" + theState+" with "+_debugstring)
	var hold = [null, null, null, null]
	_idx = 0
	for ii in variants:
		hold[_idx] = getVariants(theScene, theState, ii)
		_idx += 1
	for jj in [0,1,2,3]:
		Log.print("[ScaleTweak] " + String(hold[jj])+" vs "+String(lineup))
		var _ew = hold[jj]
		if(hold[jj] == [1,1,1,1]):
			continue
		if(hold[jj] == lineup): # if the heights of the current characters and the database match, we can use this variant
			return variants[jj]
			pass
	return "-1" # did not find a variant
		
func numberSlots():
	if(GM.ui.getStage3d().currentScene.has_node("Doll3D2")):
		return 2
	elif(GM.ui.getStage3d().currentScene.has_node("Doll3D3")):
		return 3
	elif(GM.ui.getStage3d().currentScene.has_node("Doll3D4")):
		return 4
	else:
		return 1

func getVariants(_scene, _state, _vvv):
	var theV = info[_scene].get_or_add(_state,{})
	var p1 = theV.get_or_add(_vvv,{})
	var aaa = []
	aaa.resize(4)
	aaa.fill(float(1)) # everything must float
	for idx in range(numberSlots()):
		var slot = position[idx]
		aaa[position.find(slot)] = float(p1.get_or_add(slot,{}).get_or_add("scale",float(1)))
	return aaa



#apply x offset
func XOffset(_theDoll, _value):
	_theDoll.position.x = _value #for translate, apply to the base doll
	GM.main.getCharacter(_theDoll.getCharacterID()).softUpdateDoll(_theDoll)

#apply y offset
func YOffset(_theDoll, _value):
	_theDoll.position.y = _value #for translate, apply to the base doll
	GM.main.getCharacter(_theDoll.getCharacterID()).softUpdateDoll(_theDoll)
	
# apply bone transform
func boneEdit(_theDoll, _value, _boneidx):
	var _skeleton = _theDoll.getDollSkeleton().getSkeleton()
	var rotat:Quat = Quat.IDENTITY
	if(typeof(_value) == TYPE_ARRAY):
		rotat = Quat(_value[0], _value[1], _value[2], _value[3])
	elif(typeof(_value) == TYPE_INT):
		rotat.set_axis_angle(Vector3(0,0,1),deg2rad(_value)) #twist the matrix coordinats along the z-axis
	if(_theDoll.isFacingRight): # again, need to flip the vector if the doll is flipped
		rotat.x *= -1
		rotat.y *= -1
		rotat.z *= -1
		rotat.w *= -1
	var thenumbers = Transform(rotat)
	_skeleton.set_bone_custom_pose(_boneidx, thenumbers)
	GM.main.getCharacter(_theDoll.getCharacterID()).softUpdateDoll(_theDoll)

# apply height by scaling
func ScaleEdit(_theDoll, _value):
	var size = Vector3(sign(_theDoll.scale.x), sign(_theDoll.scale.y), sign(_theDoll.scale.z))
	if(_theDoll!=null): #for scale, apply to the base doll
		size *= _value
		_theDoll.scale = size
	GM.main.getCharacter(_theDoll.getCharacterID()).softUpdateDoll(_theDoll)

const theBoneList = [
	"Hips", 
	"Chest", 
	"Neck", 
	"Head", 
	"Arm.L", 
	"ForeArm.L", 
	"Hand.L", 
	"Arm.R", 
	"ForeArm.R", 
	"Hand.R", 
	"DeformBreasts", 
	"Nipples", 
	"LegUpper.L", 
	"LegDown.L", 
	"Foot.L", 
	"DeformThigh.L",
	"Penis", 
	"Balls", 
	"Penis2", 
	"Penis3", 
	"Tail1", 
	"Tail2", 
	"Tail3", 
	"Tail4", 
	"Tail5", 
	"LegUpper.R", 
	"LegDown.R", 
	"Foot.R", 
	"DeformThigh.R", 
	"DeformBelly", 
	"DeformButt",
	]
