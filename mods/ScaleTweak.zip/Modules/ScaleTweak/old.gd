extends Control

var info = {}

var dolls = []

var scenePC = {}
var sceneNPC = {}
var sceneNPC2 = {}
var heightList = {}

var selectedAnim
var allAnims = GlobalRegistry.stageScenesCachedStates
var anims = allAnims.keys()
var selectedState = ""
var states = []

var names = []

var selectedPC
var selectedNPC
var selectedNPC2

var animStage:BaseStageScene3D
var draggingCamera: bool = false
var previousPosition: Vector2 = Vector2(0, 0)
var startMousePosition: Vector2 = Vector2(0, 0)
var requestedChars = []
var loadedChars = {}
var numSupportedChars = 0

var HeightControls = {}
var BoneControls = {}

const PC = 0
const NPC = 1
const NPC2 = 2
enum position {PC, NPC, NPC2}

var modversion = "0.1.2"

var scaleHeightentry = preload("res://Modules/ScaleTweak/ScaleCharEntry.tscn")
onready var filterEdit = $"TabContainer/Set Height/VBoxContainer/HBoxContainer/LineEdit"
onready var var_anim_list = $"TabContainer/Scale & Offset/AnimPickerSelector/AnimPickerSelectorVar/OptionButton"
onready var var_state_list = $"TabContainer/Scale & Offset/AnimPickerSelector/AnimPickerSelectorVar/VarOptionList"
onready var startEditButton = $"TabContainer/Scale & Offset/AnimPickerSelector/AnimPickerSelectorVar/startedit"
onready var first = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxContainer/VBoxContainer/firstcharacter"
onready var second = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxContainer/VBoxContainer2/secondcharacter"
onready var third = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxContainer/VBoxContainer3/thirdcharacter"
onready var l1 = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxContainer/VBoxContainer/Label"
onready var l2 = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxContainer/VBoxContainer2/Label2"
onready var l3 = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxContainer/VBoxContainer3/Label3"
onready var HeightUI = $"TabContainer/Set Height/VBoxContainer/VBoxHeights"
onready var BoneUI = $"TabContainer/Scale & Offset/ScrollContainer/VBoxEditBones"
onready var ButtonSave = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxOtherButtons/Buttonsave"
onready var ButtonLoad = $"TabContainer/Scale & Offset/AnimPickerSelector/HBoxOtherButtons/Buttonload"

# when tab is first selected from debug menu
func _on_ScalePanel_visibility_changed():
	setupHeightMenu() # prepare the first tab that controls height
	info = loadData()
	if(not info.empty()):
		_on_Buttonload_pressed(true) # load from file but only initilize heights
		var _mv = info.get("modversion")
		if(_mv != modversion):
			printerr("save file version does not match mod version, beware!")
	prepareCharMenus() #dunno why I put this here it can go with the Scale&Offset stuff\
	var _t = first.connect("charSelected", self, "on_char_select") 
	var _t2 = second.connect("charSelected", self, "on_char_select")
	var _t3 = third.connect("charSelected", self, "on_char_select")

func setupHeightMenu():
	updateCharList()
	for entry in HeightUI.get_children():
		entry.setActive(true) #redundant due to some changes
	$TabContainer.current_tab = 0 #make sure this tab is always the first subtab
	$"TabContainer/Set Height".visible = true #make the subtabs visible (they are hidden when inputs are wrong)
	$"TabContainer/Scale & Offset".visible = false

#get the character list of the current save file and assign each a height slider
func updateCharList():
	var filterText = filterEdit.text.to_lower()
	Util.delete_children(HeightUI) #clear any previous stuff
	if(GM.main == null):
		return
	var chars = GM.main.staticCharacters.keys() # get a list of all the pre-made characters
	chars.push_front("pc") # add pc to top of the list for convenience
	for pers in chars:
		if(pers in ["ghostHands","testchar","intro_detective","errorerror","latexParasite", "plantTentacles", "shemaleguard"]):
			continue # skip certain "characters" that don't have any visuals
		if("stash" in pers.to_lower() or "bidder" in pers.to_lower() or "inmate" in pers or "crowd" in pers.to_lower()):
			continue # skip certain "characters" that don't have any visuals
		var theName = GM.main.getCharacter(pers).getName()
		if(filterText != "" && !(filterText in theName.to_lower())):
			continue # if something is typed int the search box, only show the ones that match
		var newheightentry = scaleHeightentry.instance() # each characterID is mapped to an instance of this subscene (a cluster of controls)
		HeightUI.add_child(newheightentry) # add the control cluster to the UI
		newheightentry.setNameAndValue(theName + " ["+pers+"]",1) # save some useful data in the control instance
		newheightentry.CharID = pers
		newheightentry.setminmax(0.1,2) # custom method to set min and max of all controls in the cluster
		var _ok = newheightentry.connect("ResetScale", self, "onResetScale") # unused... just in case I needed to detect a reset
		var _dokey = newheightentry.connect("PickChar", self, "onSaveChar") # connect to the custom signal of the instance (button that says save)
		var _eorp = newheightentry.connect("sliderChanged", self, "onScaleEdit") # connect to custom signal of the instance (change in height setting)(used because two controls are linked)
	var dynchars = GM.main.dynamicCharacters.keys() # repeat this whole process with dynamic characters from the current save file
	for pers in dynchars:
		var theName = GM.main.getCharacter(pers).getName()
		if(filterText != "" && !(filterText in theName.to_lower())):
			continue
		var newheightentry = scaleHeightentry.instance()
		HeightUI.add_child(newheightentry)
		newheightentry.setNameAndValue(theName + " ["+pers+"]",1)
		newheightentry.CharID = pers
		newheightentry.setminmax(0.1,2) # I've chosen 0.1 and 2 based on what seems reasonable and can still be seen at the default zoom
		var _ok = newheightentry.connect("ResetScale", self, "onResetScale")
		var _dokey = newheightentry.connect("PickChar", self, "onPickChar")
		var _eorp = newheightentry.connect("sliderChanged", self, "onScaleEdit")

func _on_Set_Height_visibility_changed():
	pass # redundant
		
# redo the per-character subcontrols if something is put in the search bar
func _on_LineEdit_text_entered(_new_text):
	updateCharList() 

# same as above, but in case it's a touchscreen keyboard
func _on_Button_pressed():
	updateCharList() 
	
# lazy method to find the instanced height control from the character
func find_child_control_by_char(parent, charID):
	for entry in parent.get_children():
		if(entry.CharID == charID):
			return entry

# when switching tabs, check if we need to initialize anything
func _on_Scale__Offset_visibility_changed():
	if($TabContainer.current_tab == 1):
		if(var_anim_list.selected != -1 || var_state_list.selected != -1):
			pass #keep the values if they were set. Can do this because the list of animations won't change after we get it from globalregistry.
		else:
			var _ii = 0
			for anim in anims:
				var_anim_list.add_item(anim, _ii)
				_ii+=1
			var_anim_list.selected = -1
# initialize the controls for adding characters to the stagescene
func prepareCharMenus():
	first.clear()
	second.clear()
	third.clear()
	names.clear() #clear out anything old
	l1.text = "Char1" # change the label to show that character is not set
	l2.text = "Char2"
	l3.text = "Char3"
	var peeps = GM.main.staticCharacters.keys()
	peeps.push_front("pc")
	peeps.append_array(GM.main.dynamicCharacters.keys()) # construct the same character list as previous
	for pers in peeps:
		var theName = GM.main.getCharacter(pers).getName()
		names.append(theName) #also get the actual character name, since 'dynamicnpc99' isn't easy to remember
	ButtonSave.visible = false #hide the save and load buttons, we are not ready to use them
	ButtonLoad.visible = false
	selectedPC = null #lazy fix for these variables not getting uppdated
	selectedNPC = null
	selectedNPC2 = null
	requestedChars = ["TestPC"] # we need at least one character to render a stagescene without errors

# when a stagescene animation is selected from the list, get all its states and update the state list
func _on_OptionButton_item_selected(index):
	if(index < 0 || index >= anims.size()):
		return
	var_state_list.clear()
	selectedAnim = anims[index] #index of animation list and the drop-down box are matching
	if(selectedAnim is Array): #if the entry is somehow a dictionary we only care about the first bit
		selectedAnim = selectedAnim[0] #set global variable
	states = allAnims.get(anims[index]) # get all the possible states

	for item in states: #add to the state list
		var_state_list.add_item(str(item))
		
	if(states.size() <= 1):
		selectedState = states[0] # if there's only one state, then set it and lock the state control
		var_state_list.visible = true
		var_state_list.disabled = true
	else:
		var_state_list.visible = true #otherwise, show the state control
		var_state_list.disabled = false
	if(states.size() > 0):
		if(!states.has(selectedState)): #if the chosen state doesn't exist, default to first one
			selectedState = states[0] #this will carry over if the new stagescene animation has a state with the same name
	
	setSelectedAnim(anims[index]) # apply the stagescene
	onAnimDataChanged(selectedAnim,selectedState) # get ready to play animation
	Util.delete_children(BoneUI) #clear control list when changing stagescene
	_on_startedit_pressed(false) # reset the button that triggers control list (until we have characters selected)
	startEditButton.disabled = true #lock the button that triggers control list
	prepareCharMenus() # initialize
	resetStage() # clear the right side panel

# set variable when a state is selected from the list
func _on_VarOptionList_item_selected(index):
	if(index < 0 || index >= states.size()):
		return # whatever got selected was invalid
	selectedState = states[index] #update global variable
	ButtonLoad.text = "Load "+GM.ui.getStage3d().currentScene.id + ": "+selectedState+ " from file" #update the load button so we know what scene and state we are looking for
	onStateDataChanged(selectedAnim,selectedState) 

# based on what is in the character boxes, get the character reference and doll3d prepared
func updateLoadedChars():
	for loadedID in loadedChars.keys():
		if(!requestedChars.has(loadedID)): #if the character is loaded and we don't need it anymore, clear it
#			loadedChars[loadedID].queue_free() #deleting the characters when we're done with them is a good idea, except you can re-add that same character in the other textbox and cause errors
			loadedChars.erase(loadedID)

	for requestID in requestedChars:
		if(requestID==null): #bad reference
			continue
		if(!loadedChars.has(requestID)): 
			var actualID = requestID
			var theirID = actualID
			var newChar
			if(GlobalRegistry.getCharacter(actualID)): #if the character is already loaded, get their reference from globalregistry
				newChar = (GlobalRegistry.getCharacter(actualID))
			else:
				newChar = GlobalRegistry.createCharacter(actualID) #if the character is not loaded, make an instance and load the character
				newChar.id = theirID
			add_child(newChar) # add the loaded character to the scene tree
			loadedChars[requestID] = newChar # remember that we loaded this character

func onAnimDataChanged(_id, _state):
	selectedState = _state
	playAnim()

func onStateDataChanged(_id, _state):
	selectedState = _state
	playAnim()

# set the stagescene by name, create it if it doesn't exist, and get the number of characters it can have and show/hide text boxes accordingly
func setSelectedAnim(newA):
	selectedAnim = newA
	var _i = 0
	for animName in allAnims: #probably redundant
		if(animName == selectedAnim):
			var_anim_list.select(_i)
		_i += 1
	if(animStage != null): #if there's something playing, delete it so we can show the new animation right away
		animStage.queue_free()
		animStage = null
	if(newA==null):
		return #something went wrong
	animStage = GlobalRegistry.createStageScene(selectedAnim) # make the new animation stagescene
	if(animStage == null): #fallback in case nothing is chosen
		selectedAnim = StageScene.Solo
		animStage = GlobalRegistry.createStageScene(selectedAnim)
	var characters = GM.main.staticCharacters.keys() #create the character list as before
	characters.push_front("pc")
	characters.append_array(GM.main.dynamicCharacters.keys())
	$"%VBoxContainer".visible = true # first character controls are always visible (once stagescene is loaded)
	numSupportedChars = 1 #how many characters can be added?
	if(not selectedPC == null): 
		l1.text = names[characters.find(selectedPC)] #update the label with the name
	if(animStage.has_node("AnimationTree2")): #if a second character is supported
		numSupportedChars = 2
		$"%VBoxContainer2".visible = true # show the second text box
		if(not selectedNPC == null): 
			l2.text = names[characters.find(selectedNPC)]
	else:
		$"%VBoxContainer2".visible = false
	if(animStage.has_node("AnimationTree3")): #if a third character is supported
		numSupportedChars = 3
		$"%VBoxContainer3".visible = true #show the third text box
		if(not selectedNPC2 == null): 
			l3.text = names[characters.find(selectedNPC2)]
	else:
		$"%VBoxContainer3".visible = false

# quickly clear the right panel
func resetStage():
	GM.ui.getStage3d().resetToNothing()

# get the characters, stage3d, and assemble the parameters needed, then play the animation
func playAnim():
	requestedChars = [selectedPC, selectedNPC, selectedNPC2]
	if(selectedPC==null): #another lazy fix for characters sticking around after being removed
		requestedChars.remove(0)
	if(selectedNPC==null):
		requestedChars.remove(1)
	if(selectedNPC2==null):
		requestedChars.remove(2)
	var stage_3d = GM.ui.getStage3d()
	var animData = { #format for the extra arguments
			"pc":selectedPC,
			"npc":selectedNPC,
			"npc2":selectedNPC2,
			"bodyState":{"naked":true,"hard":true}, #put everyone in sex mode to make it easier to adjust se scenes
			"npcBodyState":{"naked":true,"hard":true},
			"npc2BodyState":{"naked":true,"hard":true},
			}
	if(selectedAnim==null):
		selectedAnim = "Solo" #fallback
	stage_3d.play(selectedAnim, selectedState, animData, false, false)
	dolls = GM.ui.getStage3d().currentScene.getDolls() #set global variable


# when a character is entered, check which text box it was and assign accordingly
func _on_character_item_selected(_index, _which): #custom signal has a hidden argument based on which text box activated

	var _eh = [first, second, third]
	var peeps = GM.main.staticCharacters.keys()
	peeps.push_front("pc")
	peeps.append_array(GM.main.dynamicCharacters.keys())
	match _which:
		0: 
			if(first.text in peeps): #assign character to the scene's first slot ("pc")
				selectedPC = first.text
				requestedChars[0] = selectedPC #set the character as one we want to load
				first.clear() #empty the text box
				first.placeholder_text = "Enter a charID" # show the hint text again
			else:
				selectedPC = null
				first.clear()
				first.placeholder_text = "ERROR: no matching character" #let the user know that wasn't a valid character
		1:
			if(second.text in peeps): #same thing, but we assign character to the scene's second slot ("npc")
				selectedNPC = second.text
				requestedChars[1] = selectedNPC
				second.clear()
				second.placeholder_text = "Enter a charID"
			else:
				selectedNPC = null
				second.clear()
				second.placeholder_text = "ERROR"
		2: 
			if(third.text in peeps): #same thing yet again, third slot is "npc2"
				selectedNPC2 = third.text
				requestedChars[2] = selectedNPC2
				third.clear()
				third.placeholder_text = "Enter a charID"
			else:
				selectedNPC2 = null
				third.clear()
				third.placeholder_text = "ERROR"
	
	startEditButton.disabled = false # enable editing mode
	startEditButton.pressed = false # since this is a toggle button, reset that
	if(selectedPC == null):
		startEditButton.disabled = true #if there's no valid first character, lock the button
		_on_startedit_pressed(false) #pretend we just toggled the button off
	if($"%VBoxContainer2".visible and selectedNPC == null): #same with character 2
		startEditButton.disabled = true
		_on_startedit_pressed(false)
	if($"%VBoxContainer3".visible and selectedNPC2 == null): #same with character 3
		startEditButton.disabled = true
		_on_startedit_pressed(false)
	updateLoadedChars() #handle getting the characters loaded
	setSelectedAnim(selectedAnim)
	playAnim()

# when entering edit mode, create the controls and apply the scale transforms. do the opposite when exiting
func _on_startedit_pressed(_pressed):
	if(_pressed):
		populateTransform() #create controls
		startEditButton.text = "Reset All"
		if(var_anim_list.selected == -1):
			var_anim_list._select_int(105) #fallback - this is "Solo" scene
		dolls = GM.ui.getStage3d().currentScene.getDolls()
		for doll in dolls: #set the scale of each doll3d
			if(heightList.keys().has(doll.savedCharacterID)):
				var ish = Vector3(1,1,1) #scale property is a vector
				if(doll.isFacingRight):
					ish = Vector3(-1, -1, -1) #right-facing characters are inverted, so we flip the vector
				doll.scale = ish*heightList[doll.savedCharacterID] #apply the saved height, if any
	else:
		startEditButton.text = "Start Editing"
		for entry in BoneUI.get_children():
			if(not entry.has_method("setminmax")):
				continue
			entry.spin.value = entry.default #reset all the sliders when toggled off
	
# create and assign sliders for modifying offset and rotation
func populateTransform(): 
	Util.delete_children(BoneUI) #clear old stuff

	dolls = GM.ui.getStage3d().currentScene.getDolls()
	var bones = []
	for doll in dolls:
		var person = doll.savedCharacterID
		var skeleton:Skeleton = doll.getDollSkeleton().getSkeleton() #need the skeleton to modify its bones
		bones = theBoneList

		var newoffsetentry = scaleHeightentry.instance() #instance a new control cluster for X offset
		BoneUI.add_child(newoffsetentry) # add it to the scene tree
		newoffsetentry.setNameAndValue(person +" ["+String(doll.get_instance_id())+"] X" + " offset",doll.position.x) #include the instance id of the doll, because it's possible to have two dolls of the same character
		newoffsetentry.CharID = person # set some useful variables
		newoffsetentry.charPos = [selectedPC, selectedNPC, selectedNPC2].find(person) # which character slot in the scene is this?
		newoffsetentry.setActive(true)
		var _ok = newoffsetentry.connect("sliderChanged", self, "onXOffset") # move the whole doll in X
		newoffsetentry.get_node("VBoxContainer/HBoxContainer/SelectButton").visible = false
		newoffsetentry.set_default(doll.position.x) # remember where the doll started - this is not always 0!
		
		newoffsetentry = scaleHeightentry.instance() #instance a new control cluster for y offset
		BoneUI.add_child(newoffsetentry)
		newoffsetentry.setNameAndValue(person +" ["+String(doll.get_instance_id())+"] Y"  + " offset",doll.position.y)
		newoffsetentry.CharID = person
		newoffsetentry.charPos = [selectedPC, selectedNPC, selectedNPC2].find(person)
		var _ok2 = newoffsetentry.connect("sliderChanged", self, "onYOffset")
		newoffsetentry.get_node("VBoxContainer/HBoxContainer/SelectButton").visible = false
		newoffsetentry.set_default(doll.position.y) # remember where the doll started - this is not always 0!
		newoffsetentry.setActive(true)
		for ii in bones: #add a control for each bone
			newoffsetentry = scaleHeightentry.instance()
			BoneUI.add_child(newoffsetentry)
			newoffsetentry.setNameAndValue(person +" ["+String(doll.get_instance_id())+"]" +" "+ ii + " rotate",0)
			newoffsetentry.CharID = person
			newoffsetentry.charPos = [selectedPC, selectedNPC, selectedNPC2].find(person)
			var _holy = skeleton.get_bone_rest(skeleton.find_bone(ii))
			newoffsetentry.originalPose = _holy #save the original pose in case we need to reset
			newoffsetentry.boneID = ii #bones are accessed by their index
			var _ok3 = newoffsetentry.connect("sliderChanged", self, "boneEdit") #connect custom signal
			newoffsetentry.get_node("VBoxContainer/HBoxContainer/SelectButton").visible = false # button not needed
			newoffsetentry.set_default(0)
			newoffsetentry.setActive(true)
			newoffsetentry.setminmaxsymmetric(180) # I've chosen -180 to 180 degrees, to avoid any issues with spinning too far

		var new = HSeparator.new() # we finished adding bones for this character, add a divider to show it's a new character next
		new.rect_min_size = Vector2(0,20)
		BoneUI.add_child(new)
		ButtonSave.visible = true # now we can activate save/load functions, because we know stagescene, state, and characters are set up
		ButtonLoad.visible = true
		ButtonLoad.text = "Load "+GM.ui.getStage3d().currentScene.id + ": "+selectedState+ " from file" #modify button text to make clear what is loaded

#apply x offset
func onXOffset(_charID, _value, _caller):
	var theDoll:Doll3D
	for entry in GM.ui.getStage3d().currentScene.getDolls():
		if(entry.getCharacterID() == _charID):
			theDoll = entry
	theDoll.position.x = _value #for translate, apply to the base doll

#apply y offset
func onYOffset(_charID, _value, _caller):
	var theDoll:Doll3D
	for entry in GM.ui.getStage3d().currentScene.getDolls():
		if(entry.getCharacterID() == _charID):
			theDoll = entry
	theDoll.position.y = _value #for translate, apply to the base doll
	
# apply bone transform
func boneEdit(_charID, _value, _caller):
	var theDoll:Doll3D
	for entry in GM.ui.getStage3d().currentScene.getDolls():
		if(entry.getCharacterID() == _charID):
			theDoll = entry
	var skeleton:Skeleton = theDoll.getDollSkeleton().getSkeleton()
	var bone = skeleton.find_bone(_caller.boneID)
	# the bone transform needs to be a 3x4 matrix, but since we ignore z-axis we can start with a 2x2 quat
	var rotat:Quat = Quat.IDENTITY 
	rotat.set_axis_angle(Vector3(0,0,1),deg2rad(_value)) #twist the matrix coordinats along the z-axis
	# Godot will convert to a 3x4 transform and fill the missing values accordingly, yay!
	_caller.customPose = rotat # save this info in the control for later
	skeleton.set_bone_custom_pose(bone, rotat) 
	# bones have three "states": rest, pose, and custom pose.
	# idk why but only the custom pose will work here

# apply height by scaling
func onScaleEdit(_charID, _value, _caller):
	var theDoll:Doll3D
	for entry in GM.ui.getStage3d().currentScene.getDolls():
		if(entry.getCharacterID() == _charID):
			theDoll = entry
	if(theDoll == null): # if nothing's showing, draw this character so we can see the height change
		GM.ui.getStage3d().play("Solo","stand",{"pc":_caller.CharID})
	var size = Vector3(1,1,1)
	if(theDoll!=null): #for scale, apply to the base doll
		if(theDoll.isFacingRight): # again, need to flip the vector if the doll is flipped
			size = Vector3(-_value, -_value, -_value)
			_caller.scale = _value
			theDoll.scale = size
		else:
			size = Vector3(_value, _value, _value)
			_caller.scale = _value
			theDoll.scale = size
	heightList[_charID] = _value # save to the global heightList
	
# make a dictionary of default values so we can compare to current values
func MakeDataTemplate(_theInfo):
#	var template = {}
#	for item in anims:
#		template[item] = {}
#		for sts in allAnims[item]:
#			template.get(item)[sts] = {}
#			for pos in ["pc","npc","npc2"]:
#				var _eh = {"dy":0,"dx":0,"scale":1,"id":""}
#				for bone in theBoneList:
#					_eh[bone] = [0,0,0,1]
#				template.get(item).get(sts)[pos] = _eh
#	template.merge(info, true)
#	return template
	var _tt = {}
	for bone in theBoneList:
		_tt[bone] = [0, 0, 0, 1]
	_tt.merge({"scale":1, "id":"", "dx":0, "dy":0}) #make a blank template of the data structure
	if(not _theInfo.has(selectedAnim)):
		_theInfo[selectedAnim] = {}
		for each in allAnims[selectedAnim]:
			_theInfo.get(selectedAnim)[each] = {"pc":_tt, "npc":_tt, "npc2":_tt}
	if(not _theInfo[selectedAnim].has(selectedState)):
		_theInfo.get(selectedAnim)[selectedState] = {"pc":_tt, "npc":_tt, "npc2":_tt}
#	if(_theInfo.get(selectedAnim)[selectedState].has(null)):
#		for key in _theInfo.get(selectedAnim)[selectedState]:
#			if(key == null):
#				_theInfo.erase(null)

	return _theInfo

# gather up all the data from the current control values, and only save the stuff that has changed
func _on_Buttonsave_pressed():
	var theNewDict = {}
	scenePC = {} # clear the global data storage dictionaries
	sceneNPC = {}
	sceneNPC2 = {}
	info = MakeDataTemplate(info.duplicate(true))
	var _fine = ["pc", "npc", "npc2"]
	for entry in HeightUI.get_children(): #loop through the height sliders
		var thePos = _fine[entry.charPos]
		heightList[entry.CharID] = entry.spin.value #get the heightlist
		if(entry.spin.value == info.get(selectedAnim).get(selectedState).get(_fine[entry.charPos])["scale"]): #if this control value is equal to the defaults, skip saving this data
			continue
		theNewDict.get_or_add(thePos,{})["id"] = entry.CharID
		theNewDict.get(thePos)["scale"] = entry.spin.value
	scenePC = theNewDict.get("pc", {}) # load the current data into the global dictionaries
	sceneNPC = theNewDict.get("npc", {})
	sceneNPC2 = theNewDict.get("npc2", {})

	theNewDict = {} # repeat same looping with the bone & offset sliders
	for thing in BoneUI.get_children():
		if(not thing.has_method("setminmax") || info.get(selectedAnim).get(selectedState).get(_fine[thing.charPos]).empty()): #ignore the divider line
			continue
#		var _efdw = info.get(selectedAnim).get(selectedState)
#		var _poe = _efdw.get(_fine[thing.charPos])
		if(thing.spin.value == info.get(selectedAnim).get(selectedState).get(_fine[thing.charPos])["dx"]):
			continue
		if(thing.spin.value == info.get(selectedAnim).get(selectedState).get(_fine[thing.charPos])["dy"]):
			continue
		if(thing.label.text.ends_with("X offset")):
			theNewDict.get_or_add(thing.charPos,{})["dx"] = thing.spin.value
		elif(thing.label.text.ends_with("Y offset")):
			theNewDict.get_or_add(thing.charPos,{})["dy"] = thing.spin.value
		else:
			var conv = [thing.customPose.x, thing.customPose.y, thing.customPose.z, thing.customPose.w]
			if(conv == info.get(selectedAnim).get(selectedState).get(_fine[thing.charPos])[thing.boneID]):
				continue
			theNewDict.get_or_add(thing.charPos,{})[thing.boneID] = conv
	scenePC.merge(theNewDict[0]) #combine with the stuff we previously saved
	if(sceneNPC):
		sceneNPC.merge(theNewDict[1]) #if no changes were made to npc slot, just make it empty
		sceneNPC = {}
	if(sceneNPC2):
		sceneNPC2.merge(theNewDict[2]) #if no changes were made to npc2 slot, just make it empty
		sceneNPC2 = {}
	
	saveData() #write to file
	

# write save data to JSON file
func saveData():
	var data = {}
	var sav = SAVE.loadGameInformationFromSaveRaw(SAVE.getSavesSortedByDate()[0]) # to help with troubleshooting
#		"gamename": playerName,
#		"credits": playerCredits,
#		"location": playerLocation,
#		"currentDay": gameDays,
#		"timeOfDay": gameTimeOfDay,
	data["modversion"] = modversion #make sure mod version is saved, I might have to change save/load functions in the future
	data["saveMeta"] = sav
	data["heightList"] = heightList # keep the full heightlist
	var scn = GM.ui.getStage3d().currentScene.id
	data.get_or_add(scn, {})[selectedState] = {"pc":scenePC, "npc":sceneNPC, "npc2":sceneNPC2} #create the data to be saved
	data.merge(info) # merge in only the info we know has changed since last save
	var baseDir = GlobalRegistry.getModsFolder() # determine file location
	var f:File = File.new()
	f.open(baseDir.plus_file("ScaleTweakSave.json"),File.WRITE_READ)
	f.store_line(JSON.print(data, "\t", true))
	f.close()
	
# get saved data and apply it to the sliders
func _on_Buttonload_pressed(_initialize):
	info = loadData()
	scenePC = {}
	sceneNPC = {}
	sceneNPC2 = {}
	if(info.get("heightList") != null):
		heightList = info.get("heightList")
	for entry in HeightUI.get_children():
		if(entry.CharID in heightList): # if the character height is already in the list, use that
			var size = heightList[entry.CharID]
			entry.scale = Vector3(size, size, size)
			entry.spin.value = size
			entry.slide.value = size
		else: #otherwise, just make it default
			entry.scale = Vector3(entry.default, entry.default, entry.default)
			entry.spin.value = entry.default
			entry.slide.value = entry.default
	if(_initialize): #can stop here if we're opening the menu for the first time
		return # also, trying to access the slides when they don't exist yet will cause errors
	var theScene = var_anim_list.get_item_text(var_anim_list.selected)
	var theState = var_state_list.get_item_text(var_state_list.selected)
	var stuff = {}
	if(info.get(theScene) == null): # when there's nothing in the save file means that no changes have been made
		print("[ScaleTweak] No data found for scene, loading defaults"+theScene)
	if(info.get(theScene).get(theState) == null):
		print("[ScaleTweak] No data found for scene "+theScene + " + state "+theState+", loading defaults")
	stuff = info.get_or_add(theScene, {}).get_or_add(theState, {}) # set up the info for the chosen stagescene and state
	for thing in BoneUI.get_children(): #loop through the bone & offset sliders
		if(not thing.has_method("setminmax")): #skip the dividers
			continue
		var iii = ["pc","npc","npc2"]
		if(stuff[iii[thing.charPos]].empty()):
			continue
		var bits = stuff.get_or_add(iii[thing.charPos], {})
		if(not thing.boneID and thing.label.text.ends_with("X offset")):
			thing.spin.value = bits.get("dx")
			continue
		if(not thing.boneID and thing.label.text.ends_with("Y offset")):
			thing.spin.value = bits.get("dy")
			continue
		if(stuff.empty() and not thing.boneID): # when there's nothing in the save file means that no changes have been made
			thing.spin.value = thing.default
			thing.slide.value = thing.default
			continue # nothing else needs to be done
		if(stuff.empty() and thing.boneID and bits): #if nothing is changed, it's all default
			thing.spin.value = 0
			thing.slide.value = 0
			continue
		var conv = bits.get_or_add(thing.boneID, [0,0,0,1]) # create the default values for 2x2 matrix
		var roto = Quat(conv[0], conv[1], conv[2], conv[3])
		var number = roto.angle_to(Quat.IDENTITY) #find the angle from the rotation
		thing.spin.value = stepify(rad2deg(-1*number), 0.01) # get the angle in degrees and round it
		thing.customPose = roto 
		
		var theDoll:Doll3D
		for entry in GM.ui.getStage3d().currentScene.getDolls():
			if(entry.getCharacterID() == thing.CharID):
				theDoll = entry
		var skeleton:Skeleton = theDoll.getDollSkeleton().getSkeleton()
		var bone = skeleton.find_bone(thing.boneID)
		skeleton.set_bone_custom_pose(bone, roto) # apply the saved custom pose
		GM.main.getCharacter(thing.CharID).softUpdateDoll(theDoll) # let the game know we messed with the pose

#read the save data from JSON
func loadData():
	var baseDir = GlobalRegistry.getModsFolder()
	var f:File = File.new()
	if(not f.file_exists(baseDir.plus_file("ScaleTweakSave.json"))): #make a new file if it doesn't exist
		var template = {
			"modversion":modversion,
			"saveMeta":{},
			"heightList":heightList,
		}
#		for item in anims:
#			template[item] = {}
#			for sts in allAnims[item]:
#				template.get(item)[sts] = {}
#				for pos in ["pc","npc","npc2"]:
#					var _eh = {"dy":0,"dx":0,"scale":1,"id":""}
#					for bone in theBoneList:
#						_eh[bone] = [0,0,0,1]
#					template.get(item).get(sts)[pos] = _eh
		return template
	var jsonResult
	var _err = f.open(baseDir.plus_file("ScaleTweakSave.json"),File.READ)
	assert(_err == OK,"[ScaleTweak] Saved poses file not found or does not exist")
	jsonResult = JSON.parse(f.get_as_text())
	assert(typeof(jsonResult.result) == TYPE_DICTIONARY, "[ScaleTweak] Could not read saved data file")
	return jsonResult.result

# dem bones
const theBoneList = [
	"Hips", 
	"Chest", 
	"Neck", 
	"Head", 
	"Arm.L", 
	"ForeArm.L", 
	"Hand.L", 
	"Arm.R", 
	"ForeArm.R", 
	"Hand.R", 
	"DeformBreasts", 
	"Nipples", 
	"LegUpper.L", 
	"LegDown.L", 
	"Foot.L", 
	"DeformThigh.L",
	"Penis", 
	"Balls", 
	"Penis2", 
	"Penis3", 
	"Tail1", 
	"Tail2", 
	"Tail3", 
	"Tail4", 
	"Tail5", 
	"LegUpper.R", 
	"LegDown.R", 
	"Foot.R", 
	"DeformThigh.R", 
	"DeformBelly", 
	"DeformButt",
	]


