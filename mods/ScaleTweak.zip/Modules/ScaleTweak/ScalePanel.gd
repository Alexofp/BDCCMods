extends Control

var info = {}
var data = {}
var heightList = {}

var selectedAnim
var allAnims = GlobalRegistry.stageScenesCachedStates
var anims = allAnims.keys()
var selectedState = ""
var states = []

var theCharList = []

var selectedPC
var selectedNPC
var selectedNPC2

var requestedChars = [null, null, null]
var loadedChars = {}
var numSupportedChars = 1

const position = ["pc", "npc", "npc2"]

var modversion = "0.1.5"

var scaleHeightentry = preload("res://Modules/ScaleTweak/ScaleCharEntry.tscn")
onready var dropdownAnim = $SceneAndState/Anims
onready var dropdownState = $SceneAndState/States
onready var startEditButton = $SceneAndState/startedit
onready var stopEditButton = $SceneAndState/stopedit
onready var first = $Characters/VBoxContainer/firstcharacter
onready var second = $Characters/VBoxContainer2/secondcharacter
onready var third = $Characters/VBoxContainer3/thirdcharacter
onready var l1 = $Characters/VBoxContainer/Label
onready var l2 = $Characters/VBoxContainer2/Label2
onready var l3 = $Characters/VBoxContainer3/Label3
onready var BoneUI1 = $ScaleControls/Char1Controls/ScrollContainer/VBoxEditSliders1
onready var BoneUI2 = $ScaleControls/Char2Controls/ScrollContainer/VBoxSliders2
onready var BoneUI3 = $ScaleControls/Char3Controls/ScrollContainer/VBoxSliders3
onready var col1 = $ScaleControls/Char1Controls
onready var col2 = $ScaleControls/Char2Controls
onready var col3 = $ScaleControls/Char3Controls
onready var ButtonSave = $HBoxOtherButtons/Buttonsave
onready var ButtonLoad = $HBoxOtherButtons/Buttonload
onready var dropdownVariant = $HBoxOtherButtons/buttonVariant
onready var pasteButton = $HBoxOtherButtons/Paste

onready var controlColumn = [BoneUI1, BoneUI2, BoneUI3]
enum {PC, NPC, NPC2}
var stage
var clipboard = {}
var variants = ["var1","var2","var3","var4"]

# when tab is first selected from debug menu
func _on_ScalePanel_visibility_changed():
	if(self.visible):
		info = loadData() # info will be the static database, if any
		data = {} # data will be the working database
		if(not info.empty()):
			_on_Buttonload_pressed(true) # load from file but only initilize heights
			var _mv = info.get("modversion") # check mod version
			if(_mv != modversion):
				printerr("[ScaleTweak] database file version does not match mod version, beware!")
		$HBoxOtherButtons.visible = false # hide most of the interface to ensure inputs will happen in the expected order
		$Characters.visible = false
		dropdownState.visible = false
		col1.visible = false
		col2.visible = false
		col3.visible = false
		startEditButton.disabled = true
		theCharList = generateCharList() # create list of all characters
		if(heightList.empty()): # if there was not a database file with heightList, create one
			for person in theCharList:
				heightList[person] = 1 # everyone gets the default scale of 1
		prepareDropdowns()
	else:
		_on_stopedit_pressed()

# make the list of all characters
func generateCharList() -> Array:
	var peeps = GM.main.staticCharacters.keys()
	peeps.push_front("pc") # put pc at the front for convenience
	peeps.append_array(GM.main.dynamicCharacters.keys())
	return peeps
	
	
# lazy method to find the instanced height control from the character
func find_child_control_by_char(parent, charID):
	for entry in parent.get_children():
		if(entry.CharID == charID):
			return entry

# initialize the dropdown menus
func prepareDropdowns():
	dropdownAnim.clear()
	for anim in anims:
		dropdownAnim.add_item(anim)
	dropdownAnim.selected = -1
	selectedAnim = null
	dropdownState.selected = -1
	selectedState = null
	dropdownVariant.clear()

# when a stagescene animation is selected from the list, get all its states and update the state dropdown
func _on_animation_item_selected(index):
	if(index < 0 || index >= anims.size()):
		return
	dropdownState.clear()
	dropdownVariant.clear() # number of variants depends on number of dolls
	dropdownVariant.add_item("Slot 1 is different height") # always have at least variant1
	dropdownVariant.selected = 0 # default to variant1
	if(selectedAnim is Array): #if the entry is somehow a dictionary we only care about the first bit
		selectedAnim = selectedAnim[0] #set global variable
	selectedAnim = anims[index] #index of animation list and the drop-down box are matching
	states = allAnims.get(anims[index]) # get all the possible states
	
	for item in states: #add to the state dropdown
		dropdownState.add_item(str(item))
	dropdownState.selected = 0 # fallback in case nothing gets set
	selectedState = dropdownState.get_item_text(dropdownState.selected) # read back the selection of the state dropdown
	if(states.size() <= 1):
		selectedState = states[0] # if there's only one state, then set it and lock the state control
		dropdownState.visible = true 
		dropdownState.disabled = true
		_on_state_item_selected(0) # since we locked the state control, pretend the user set it to that state
		requestedChars = ["TestPC", "TestPC", "TestPC"]
		startEditButton.disabled = false
		_on_character_item_selected(17,0) #if all this happened before we set the characters, use TestPC
	else:
		dropdownState.visible = true #otherwise, show the state control
		dropdownState.disabled = false
		startEditButton.disabled = true #lock the button that triggers control list until the state is set
		dropdownState.selected = -1
	if(states.size() > 0):
		if(!states.has(selectedState)): #if the chosen state doesn't exist, default to first one
			selectedState = states[0]
			dropdownState.selected = -1 #let us know that the state dropdown is invalid
	
	setSelectedAnim(anims[index]) # apply the stagescene
	Util.delete_children(BoneUI1)
	Util.delete_children(BoneUI2)
	Util.delete_children(BoneUI3) #clear control list when changing stagescene
	_on_stopedit_pressed() # reset the button that triggers control list (until we have characters selected)
	stopEditButton.text = "Cancel" # if turning off edit mode without saving, the button says cancel
	prepareCharMenus() # initialize
	if($SceneAndState/CheckBox.pressed): #check if we are adding characters besides TestPC
		$Characters.visible = true
	resetStage() # clear the right side panel

# initialize the controls for adding characters to the stagescene
func prepareCharMenus():
	first.clear()
	second.clear()
	third.clear()
	l1.text = "Char1" # change the label to show that character is not set
	l2.text = "Char2"
	l3.text = "Char3"
	$HBoxOtherButtons.visible = false
	selectedPC = "TestPC" #lazy fix for these variables not getting uppdated
	selectedNPC = "TestPC"
	selectedNPC2 = "TestPC"
	requestedChars = ["TestPC", "TestPC", "TestPC"] # we need at least one character to render a stagescene without errors
	
# initialize character controls
func _on_CheckBox_pressed():
	if($SceneAndState/CheckBox.pressed):
		$Characters.visible = true
	else:
		$Characters.visible = false

# set variable when a state is selected from the list
func _on_state_item_selected(index):
	if(index < 0 || index >= states.size()):
		return # whatever got selected was invalid
	selectedState = states[index] #update global variable
	if(info[selectedAnim].has(selectedState) and not info[selectedAnim][selectedState].empty()):
		ButtonLoad.disabled = false 
	else:
		ButtonLoad.disabled = true #if there is nothing in the database, we can't load it
	if(not selectedPC): # fallback: if no character was found, use TestPC
		selectedPC = "TestPC"
	_on_character_item_selected(theCharList.find(selectedPC),0) # pretend the user selected TestPC in case they didn't and we defaulted to TestPC
	setSelectedAnim(selectedAnim) # if changing state, we update the stagescene
	startEditButton.disabled = false # enable editing mode
	if(loadedChars.empty() or loadedChars.has(null)):
		$HBoxOtherButtons.visible = false # if something went wrong and there's no characters ready, don't show the controls yet
	for column in [0,1,2]:
		for entry in controlColumn[column].get_children():
			entry._on_ResetButton_pressed() # set all the sliders back to default
	playAnim() # show the animation

# when a character is entered, check which text box it was and assign accordingly
func _on_character_item_selected(_index, _which): #custom signal has a hidden argument based on which text box activated
	var peeps = theCharList #this was assigned during initialization
	if($SceneAndState/CheckBox.pressed): # don't bother if the character checkbox is false
		match _which:
			0: 
				if(first.text in peeps): #assign character to the scene's first slot ("pc")
					selectedPC = first.text
					requestedChars[0] = selectedPC #set the character as one we want to load
#					first.clear() #empty the text box
					l1.text = theCharList[theCharList.find(selectedPC)] #update the label with the name
					first.placeholder_text = "Enter a charID" # show the hint text again
					for each in BoneUI1.get_children():
						each.CharID = selectedPC # if the sliders are made, update which character ID they point to
				else:
					selectedPC = null
					first.clear()
					first.placeholder_text = "ERROR: no matching character" #let the user know that wasn't a valid character
			1:
				if(second.text in peeps): #same thing, but we assign character to the scene's second slot ("npc")
					selectedNPC = second.text
					requestedChars[1] = selectedNPC
#					second.clear()
					l2.text = theCharList[theCharList.find(selectedNPC)]
					second.placeholder_text = "Enter a charID"
					for each in BoneUI2.get_children():
						each.CharID = selectedNPC
				else:
					selectedNPC = null
					second.clear()
					second.placeholder_text = "ERROR: no matching character"
			2: 
				if(third.text in peeps): #same thing yet again, third slot is "npc2"
					selectedNPC2 = third.text
					requestedChars[2] = selectedNPC2
#					third.clear()
					l3.text = theCharList[theCharList.find(selectedNPC2)]
					third.placeholder_text = "Enter a charID"
					for each in BoneUI3.get_children():
						each.CharID = selectedNPC2
				else:
					selectedNPC2 = null
					third.clear()
					third.placeholder_text = "ERROR: no matching character"
		
		if(GM.ui.getStage3d().currentScene.getDolls().empty()): # if we have no dolls, check if we were about to edit
			if(not startEditButton.disabled): # if edit mode is enabled, refresh the dolls
				playAnim()
			return
		if(GM.ui.getStage3d().currentScene.getDolls()[0] == null): # if the doll instance got deleted, quit and let the user try again
			startEditButton.disabled = true #if there's no valid first character, lock the button
			_on_stopedit_pressed() #pretend we just toggled the button off
			return
		if($Characters/VBoxContainer2.visible and GM.ui.getStage3d().currentScene.getDolls()[1] == null): #same with character 2
			startEditButton.disabled = true
			_on_stopedit_pressed()
			return
		if($Characters/VBoxContainer3.visible and GM.ui.getStage3d().currentScene.getDolls()[2] == null): #same with character 3
			startEditButton.disabled = true
			_on_stopedit_pressed()
			return
	else:
		startEditButton.disabled = false
		selectedPC = "TestPC" # fallback
		selectedNPC = "TestPC"
		selectedNPC2 = "TestPC"
		requestedChars = ["TestPC", "TestPC", "TestPC"]
	
	updateLoadedChars() #handle getting the characters loaded
	if(GM.ui.getStage3d().currentScene.id != selectedAnim):
		setSelectedAnim(selectedAnim) # prepare the stagescene 
	playAnim()

# based on what is in the character boxes, get the character reference and doll3d prepared
func updateLoadedChars():
	for loadedID in loadedChars.keys():
		if(!requestedChars.has(loadedID)): #if the character is loaded and we don't need it anymore, clear it
#			loadedChars[loadedID].queue_free() #deleting the characters when we're done with them 
# However, since you can re-add that same character in the other textbox and cause errors, I decided not to
			loadedChars.erase(loadedID)

	for requestID in requestedChars:
		if(requestID==null): #bad reference
			continue
		if(!loadedChars.has(requestID)): 
			var actualID = requestID
			var theirID = actualID
			var newChar
			if(GlobalRegistry.getCharacter(actualID)): #if the character is already loaded, get their reference from globalregistry
				newChar = (GlobalRegistry.getCharacter(actualID))
			else:
				newChar = GlobalRegistry.createCharacter(actualID) #if the character is not loaded, make an instance and load the character
				newChar.id = theirID
			add_child(newChar) # add the loaded character to the scene tree
			loadedChars[requestID] = newChar # remember that we loaded this character


# set the stagescene by name, create it if it doesn't exist, and get the number of characters it can have and show/hide text boxes accordingly
func setSelectedAnim(newA):
	if(newA==null):
		return #something went wrong
	var _i = 0
	for animName in allAnims: #probably redundant
		if(animName == selectedAnim):
			dropdownAnim.select(_i)
		_i += 1
	var animStage:BaseStageScene3D = GM.ui.getStage3d().currentScene
	animStage = GlobalRegistry.createStageScene(selectedAnim) # make the new animation stagescene
	if(animStage == null): #fallback in case nothing is chosen
		selectedAnim = StageScene.Solo
		animStage = GlobalRegistry.createStageScene(selectedAnim)
	stage = animStage
	if($SceneAndState/CheckBox.pressed):
		$Characters.visible = true #redundant
		$Characters/VBoxContainer.visible = true # first character controls are always visible (once stagescene is loaded)
	col1.visible = true # scale controls for slot 1
	numSupportedChars = 1
	dropdownVariant.disabled = true # only one variant for a solo scene
	if(animStage.has_node("Doll3D2")): #if a second character is supported
		$Characters/VBoxContainer2.visible = true # show the second text box
		col2.visible = true
		numSupportedChars = 2
		dropdownVariant.disabled = false # add another variant
		if(dropdownVariant.get_item_count()==1):
			dropdownVariant.add_item("Slot 2 is different height")
	else:
		$Characters/VBoxContainer2.visible = false
		col2.visible = false
		numSupportedChars = 1
	if(animStage.has_node("Doll3D3")): #if a third character is supported
		$Characters/VBoxContainer3.visible = true #show the third text box
		col3.visible = true
		numSupportedChars = 3
		dropdownVariant.disabled = false # add another variant
		if(dropdownVariant.get_item_count()==2):
			dropdownVariant.add_item("Slot 3 is different height")
	else:
		$Characters/VBoxContainer3.visible = false
		col3.visible = false
		numSupportedChars = 1
		
# when selecting variant, limit the scale slider for the other positions in the scene
func _on_buttonVariant_item_selected(_index):
	for column in [0,1,2]:
		for entry in controlColumn[column].get_children():
			entry.variant = _index+1 #store the variant in the slider, just in case
			if(entry.UUID == "scale"):
				if(column == _index):
					entry.setActive(true) # if variant1, we can edit slot 1 which is "pc"
					entry.loadsaved.disabled = false
				else:
					entry._on_ResetButton_pressed() # set height back to 1
					entry.setActive(false) # if variant1, we can't edit other slots
					entry.loadsaved.disabled = true
		
# when entering edit mode, create the controls and apply the scale transforms.
func _on_startedit_pressed():
	$SceneAndState/startedit.visible = false #enable the interface for all the stuff
	$HBoxOtherButtons.visible = true
	$SceneAndState/CheckBox.disabled = true # lock a bunch of the interface so I don't have to code every possible mid-edit change
	dropdownAnim.disabled = true
	first.editable = false
	second.editable = false
	third.editable = false
	updateControlList("original") #create controls
	if(dropdownAnim.selected == -1):
		dropdownAnim._select_int(105) #fallback - this is "Solo" scene
	var dolls = GM.ui.getStage3d().currentScene.getDolls()
	for doll in dolls: #set the scale of each doll3d
		if(heightList.keys().has(doll.savedCharacterID)):
			var ish = Vector3(1,1,1) #scale property is a vector
			if(doll.isFacingRight):
				ish = Vector3(-1, -1, -1) #right-facing characters are inverted, so we flip the vector
			doll.scale = ish*heightList[doll.savedCharacterID] #apply the saved height, if any
			GM.main.getCharacter(doll.savedCharacterID).softUpdateDoll(doll)
	stopEditButton.visible = true # swap this button for the "stop editing" button
	stopEditButton.pressed = false
	_on_buttonVariant_item_selected(0) # make sure the variant is set to var1
	
# do the opposite when we stop editing
func _on_stopedit_pressed():
	stopEditButton.visible = false
	$SceneAndState/CheckBox.disabled = false
	dropdownAnim.disabled = false
	for pos in [0,1,2]:
		for entry in controlColumn[pos].get_children():
			entry.spin.value = entry.original #reset all the sliders when toggled off
	$HBoxOtherButtons.visible = false
	$SceneAndState/startedit.visible = true
	first.editable = true
	second.editable = true
	third.editable = true
	for each in BoneUI1.get_children(): #keep the sliders for now so user can see what they entered, but lock them
		each.setActive(false)
	for each in BoneUI2.get_children():
		each.setActive(false)
	for each in BoneUI3.get_children():
		each.setActive(false)
	
# quickly clear the right panel
func resetStage():
	GM.ui.getStage3d().resetToNothing()

# big long database indexing
func getSavedSliderValue(_UUID, _position):
	return info.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected], {}).get_or_add(_position,{}).get_or_add(_UUID,0)
	
# same but for our working database
func getCurrentSliderValue(_UUID, _position):
	return data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected], {}).get_or_add(_position,{}).get_or_add(_UUID,null)
	
# create sliders, set references, and connect signals
func updateControlList(_default): #_default chooses whether we initialize with the original stagescene3d setup, or with the database
	if(not _default=="saved" and not _default=="original"):
		return
	Util.delete_children(BoneUI1) #clear old stuff
	Util.delete_children(BoneUI2) #clear old stuff
	Util.delete_children(BoneUI3) #clear old stuff
	col1.visible = true #fallback
	var dolls = GM.ui.getStage3d().currentScene.getDolls()
	var bones = []
	var _ii = 0 #outer loop index
	for doll in dolls:
		var person = doll.savedCharacterID
		var theName = GM.main.getCharacter(person).getName()
		var skeleton:Skeleton = doll.getDollSkeleton().getSkeleton() #need the skeleton to modify its bones
		bones = theBoneList
		var newControl = scaleHeightentry.instance() #instance a new slider for height
		
		controlColumn[_ii].add_child(newControl) # add it to the scene tree
		newControl.setNameAndValue(theName +" ["+String(doll.get_instance_id())+"] Scale",heightList[person]) #include the instance id of the doll, because it's possible to have two dolls of the same character
		newControl.dollIns = doll.get_instance_id() # remember this so it's easier to find the doll later
		newControl.CharID = person # set some useful variables
		newControl.UUID = "scale" # unique identifier
		newControl.charPos = _ii # which character slot in the scene is this?
		var _ok1 = newControl.connect("sliderChanged", self, "onScaleEdit") # connect to the scale edit function
		newControl.setminmax(0.1,2)
		newControl.set_original(1) # the default height is always 1
		newControl.set_saved(getSavedSliderValue("scale",position[_ii])) # check if we have anything in the database
		if(newControl.saved == null):
			newControl.loadsaved.disabled = true #if nothing in database, we can't load
		else:
			newControl.loadsaved.disabled = false  
		if(_default == "saved" and not newControl.loadsaved.disabled):
			newControl._on_loadButton_pressed() # set the value to the database value
		elif(_default == "original"):
			newControl._on_ResetButton_pressed() # set the value to the default
		onScaleEdit(person, newControl.spin.value, controlColumn[_ii].get_child(0)) # apply what we set by pretending we moved it there
		
		newControl = scaleHeightentry.instance() # same thing again, but for x and y offset (only difference is we default to 0)
		controlColumn[_ii].add_child(newControl) # add it to the scene tree
		newControl.setNameAndValue(theName +" ["+String(doll.get_instance_id())+"] X" + " offset",doll.position.x) #include the instance id of the doll, because it's possible to have two dolls of the same character
		newControl.dollIns = doll.get_instance_id()
		newControl.CharID = person # set some useful variables
		newControl.UUID = "dx"
		newControl.charPos = _ii # which character slot in the scene is this?
		var _ok2 = newControl.connect("sliderChanged", self, "onXOffset")
		newControl.set_original(doll.position.x) # remember where the doll started - this is not always 0!
		newControl.set_saved(getSavedSliderValue("dx",position[_ii]))
		if(newControl.saved == 0 || newControl.saved == newControl.original):
			newControl.loadsaved.disabled = true
		else:
			newControl.loadsaved.disabled = false
		if(_default == "saved" and not newControl.loadsaved.disabled):
			newControl._on_loadButton_pressed()
		elif(_default == "original"):
			newControl._on_ResetButton_pressed()
		
		newControl = scaleHeightentry.instance()
		controlColumn[_ii].add_child(newControl)
		newControl.setNameAndValue(theName +" ["+String(doll.get_instance_id())+"] Y"  + " offset",doll.position.y)
		newControl.dollIns = doll.get_instance_id()
		newControl.CharID = person
		newControl.UUID = "dy"
		newControl.charPos = _ii
		var _ok3 = newControl.connect("sliderChanged", self, "onYOffset")
		newControl.set_original(doll.position.y) # remember where the doll started - this is not always 0!
		newControl.set_saved((getSavedSliderValue("dy",position[_ii])))
		if(newControl.saved == 0 || newControl.saved == newControl.original):
			newControl.loadsaved.disabled = true
		else:
			newControl.loadsaved.disabled = false
		if(_default == "saved" and not newControl.loadsaved.disabled):
			newControl._on_loadButton_pressed()
		elif(_default == "original"):
			newControl._on_ResetButton_pressed()
#		var _idx = 3
		for bone in bones: #add a control for each bone
			newControl = scaleHeightentry.instance()  #instance a new slider for bone editing, this will be different
			controlColumn[_ii].add_child(newControl)
			newControl.setNameAndValue(theName +" ["+String(doll.get_instance_id())+"]" +" "+ bone + " rotate",0)
			newControl.dollIns = doll.get_instance_id()
			newControl.CharID = person
			newControl.charPos = _ii
			var _holy = skeleton.get_bone_rest(skeleton.find_bone(bone)) # get the skeleton at rest
			newControl.originalPose = _holy #save the original pose in case we need to reset
			newControl.UUID = bone # the unique ID is the name of the bone
			newControl.slide.step = 1 # change the slider to only use integers
			newControl.spin.step = 1
			var _ok4 = newControl.connect("sliderChanged", self, "boneEdit") #connect custom signal
			var conv = getSavedSliderValue(bone,position[_ii]) #check if anything is in the database
			if(not conv): # if nothing in database, we default to this array
				conv = [0,0,0,1]
			var roto = Quat(conv[0], conv[1], conv[2], conv[3]) #construct a quaternion from the array
			var number = quat2angleZ(roto) #find the angle from the rotation
			newControl.set_original(0) # the original rotation is 0
			newControl.set_saved(number) # the angle that we set in degrees
			newControl.customPose = roto # also save the pose as a Quat
			if(newControl.customPose == Quat.IDENTITY):
				newControl.loadsaved.disabled = true # the pose is unchanged from default, nothing to load
			else:
				newControl.loadsaved.disabled = false
			newControl.setminmaxsymmetric(180) # I've chosen -180 to 180 degrees, to avoid any issues with spinning too far
			if(_default == "saved" and not newControl.loadsaved.disabled):
				newControl._on_loadButton_pressed()
				skeleton.set_bone_custom_pose(skeleton.find_bone(bone), roto) 
			elif(_default == "original"):
				newControl._on_ResetButton_pressed()
				skeleton.set_bone_custom_pose(skeleton.find_bone(bone), Quat.IDENTITY) 
#			_idx += 1
		_ii += 1
		
		ButtonSave.visible = true # now we can activate save/load functions, because we know stagescene, state, and characters are set up
		ButtonLoad.visible = true


# get the characters, stage3d, and assemble the parameters needed, then play the animation
func playAnim():
	var stage_3d = GM.ui.getStage3d()
	var animData = { #format for the extra arguments
			"pc":requestedChars[0],
			"npc":requestedChars[1],
			"npc2":requestedChars[2],
			"bodyState":{"naked":true,"hard":true}, #put everyone in sex mode to make it easier to adjust sex scenes
			"npcBodyState":{"naked":true,"hard":true},
			"npc2BodyState":{"naked":true,"hard":true},
			}
	if(selectedAnim==null):
		selectedAnim = "Solo" #fallback
	var _dummy = stage_3d.currentScene.canTransitionTo(selectedState, animData) # check if the main UI is going to reset the stage
	stage_3d.play(selectedAnim, selectedState, animData, true, false)
	if(not _dummy): # main UI has reset the stage, so the doll instance IDs point to nothing
		for column in [0,1,2]: # but we can easily find the new ones
			for entry in controlColumn[column].get_children():
				entry.dollIns = getDolls()[column].get_instance_id()
		

func getDolls():
	return GM.ui.getStage3d().currentScene.getDolls()

#apply x offset
func onXOffset(_charID, _value, _caller):
	var theDoll:Doll3D = instance_from_id(_caller.dollIns) #find the doll this slider references
	var _eh = GM.ui.getStage3d().currentScene
	theDoll.position.x = _value #for translate, apply to the base doll
	GM.main.getCharacter(_charID).softUpdateDoll(theDoll) #tell the game that we messed with the doll (this will re-apply props and boob/butt scaling)
	yield(get_tree().create_timer(0.3), "timeout") #wait a bit so we don't access memory on every single frame
	data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected], {}).get_or_add(position[_caller.charPos], {})["dx"] = _value # save any changes to the working database


#apply y offset
func onYOffset(_charID, _value, _caller):
	var theDoll:Doll3D = instance_from_id(_caller.dollIns) 
	theDoll.position.y = _value #for translate, apply to the base doll
	GM.main.getCharacter(_charID).softUpdateDoll(theDoll)
	yield(get_tree().create_timer(0.3), "timeout")
	data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected], {}).get_or_add(position[_caller.charPos], {})["dy"] = _value
	
# apply bone transform
func boneEdit(_charID, _value, _caller):
	var theDoll:Doll3D = instance_from_id(_caller.dollIns)
	var rotat:Quat = Quat.IDENTITY # the bone transform needs to be a 3x4 matrix, but we can start by representing the angle in 3D as a quaternion
	var skeleton:Skeleton = theDoll.getDollSkeleton().getSkeleton()
	var bone = skeleton.find_bone(_caller.UUID)
	if(typeof(_value) == TYPE_ARRAY): # in case something mixed up and we got an array instead of a Quat
		rotat = Quat(_value[0], _value[1], _value[2], _value[3])
	else:
		rotat.set_axis_angle(Vector3(0,0,1),deg2rad(_value)) #twist the matrix coordinates along the z-axis
	# Godot will convert it to a 3x4 transform internally, yay!
	_caller.customPose = rotat # save this info in the control for later
	skeleton.set_bone_custom_pose(bone, rotat) 
	# bones have three "states": rest, pose, and custom pose.
	# idk why but only the custom pose will work here
	GM.main.getCharacter(_charID).softUpdateDoll(theDoll)
	yield(get_tree().create_timer(0.3), "timeout")
	var conv = [rotat.x, rotat.y, rotat.z, rotat.w] # convert Quat to array so we can write to working database
	data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected], {}).get_or_add(position[_caller.charPos], {})[_caller.UUID] = conv

# math corner
# quaternion as rotation is four parts: x, y, z, and w
# take the angle as θ in radians
# for each of x, y, and z: Q.x = sin(θ/2)*cos(βx) where βx is the angle in radians between the rotation axis and the x-axis
# in our case where we rotate around z-axis, both βx and βy are 90 deg, and cos(90) = 0
# and for βz, cos(0) = 1
# for w, Q.w = cos(θ/2) although w is the magnitude and ignores the sign
# therefore we use Q.z = sin(θ/2)*cos(0) = sin(θ/2) and the original angle is 2*arcsin(Q.z)
func quat2angleZ(_input):
	var az
	if(typeof(_input) == TYPE_QUAT):
		az = _input.z
	elif(typeof(_input) == TYPE_ARRAY):
		az = _input[2]
	var degZ = rad2deg(asin(az)*2)
	return int(degZ)


# apply height by scaling
func onScaleEdit(_charID, _value, _caller):
	var theDoll:Doll3D = instance_from_id(_caller.dollIns)
	if(theDoll == null): # if nothing's showing, draw this character so we can see the height change
		GM.ui.getStage3d().play("Solo","stand",{"pc":_caller.CharID})
	var size = Vector3(1,1,1)
	if(theDoll!=null): #for scale, apply to the base doll
		if(theDoll.isFacingRight): # again, need to flip the vector if the doll is flipped
			size = Vector3(-_value, -_value, -_value)
			_caller.scale = _value
			theDoll.scale = size
		else:
			size = Vector3(_value, _value, _value)
			_caller.scale = _value
			theDoll.scale = size
	heightList[_charID] = _value # save to the global heightList
	GM.main.getCharacter(_charID).softUpdateDoll(theDoll)
	yield(get_tree().create_timer(0.3), "timeout") 
	data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected], {}).get_or_add(position[_caller.charPos], {})["scale"] = _value
	
# make a template for a new database save file
func MakeDataTemplate():
	var _theInfo = {"heightList":{},"saveMeta":{},"modversion":""}
	for anim in anims:
		_theInfo[anim] = {}
#		for each in allAnims[anim]:
#			_theInfo.get(anim)[each] = {"pc":{}, "npc":{}, "npc2":{}}
	return _theInfo

# gather up all the data from the current control values, and only save the stuff that has changed
func _on_Buttonsave_pressed():
	stopEditButton.text = " Back " # since we have saved the changes, the cancel edit button is now just back
	var theVariant = variants[dropdownVariant.selected] # get the variant name from the dropdown
	for pos in [0,1,2]:
		for entry in controlColumn[pos].get_children(): #loop through the height sliders
			var thePos = entry.charPos
			assert(thePos==pos, "[ScaleTweak] Didn't correctly link slider to character slot") # sanity check
#			var compare = getSavedSliderValue(entry.UUID, position[entry.charPos])
			if(entry.UUID == "scale" || entry.UUID == "dx" || entry.UUID == "dy"):
				var compare = getCurrentSliderValue(entry.UUID, position[entry.charPos])
				if(not compare):
					compare = 0
				if(not is_equal_approx(entry.spin.value, compare)): #check if the working database truly matches the slider value
					data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(theVariant, {}).get_or_add(position[entry.charPos],{})[entry.UUID] = entry.spin.value
					entry.set_saved(entry.spin.value) #update the slider's saved value while we are at it
					continue
				if(entry.spin.value == entry.original): #if this control value is equal to the defaults, skip saving this data by clearing the key from working database
					data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(theVariant, {}).get_or_add(position[entry.charPos],{}).erase(entry.UUID)
					continue
				entry.set_saved(entry.spin.value)
			else:
				var _eh = getCurrentSliderValue(entry.UUID, position[entry.charPos])
				var qq = Quat.IDENTITY
				if(_eh):
					qq = Quat(_eh[0], _eh[1], _eh[2], _eh[3]) # array to Quat conversion
				if(not qq.is_equal_approx(entry.customPose)):
					data.get_or_add(selectedAnim).get_or_add(selectedState).get_or_add(theVariant, {}).get_or_add(position[entry.charPos])[entry.UUID] = [entry.customPose.x, entry.customPose.y, entry.customPose.z, entry.customPose.w]
					entry.set_saved(quat2angleZ(entry.customPose))
					continue
				entry.set_saved(quat2angleZ(entry.customPose))
				if(entry.customPose == Quat.IDENTITY): #if this control value is equal to the defaults, skip saving this data
					data.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(theVariant, {}).get_or_add(position[entry.charPos],{}).erase(entry.UUID)
					continue
	clipboard = data[selectedAnim][selectedState][theVariant]
	
	info.get_or_add(selectedAnim, {}).get_or_add(selectedState, {}).get_or_add(theVariant, {}).merge(data[selectedAnim][selectedState][theVariant], true) #merge working database into static database
	for anim in allAnims.keys(): # reduce filesize by erasing unused keys in nested dictionary
		if(not info.has(anim)):
			printerr("[ScaleTweak] Didn't have all stagescenes in save file, it might be broken")
			info.get_or_add(anim,{})
		for state in info[anim]:
			if(info[anim][state].empty()):
					info[anim].erase(state)
					continue
			for vv in info[anim][state]:
				if(info[anim][state][vv].empty()):
					info[anim][state].erase(vv)
					continue
				for pos in info[anim][state][vv]:
					if(info[anim][state][vv][pos].empty()):
						info[anim][state][vv].erase(pos)
						continue
					for line in info[anim][state][vv][pos]:
						if(line == "scale" and info[anim][state][vv][pos][line] == 1):
							info[anim][state][vv][pos].erase(line)
							continue
						if(line == "dx" || line == "dy" || line == "scale"):
							continue
						if(typeof(info[anim][state][vv][pos][line]) != TYPE_ARRAY):
							info[anim][state][vv][pos].erase(line)
							continue
						if(info[anim][state][vv][pos][line] == [0,0,0,1]):
							info[anim][state][vv][pos].erase(line)
							continue
						
	
	saveData(info) #write to file
	info = loadData() #load what was just saved to static database as sanity check
	ButtonSave.text = "Saved!" # user feedback
	yield(get_tree().create_timer(1.0), "timeout")
	ButtonSave.text = "Save to file"

	

# write save data to JSON file
func saveData(_data):
	var sav = SAVE.loadGameInformationFromSaveRaw(SAVE.getSavesSortedByDate()[0]) # to help with troubleshooting
#		"gamename": playerName,
#		"credits": playerCredits,
#		"location": playerLocation,
#		"currentDay": gameDays,
#		"timeOfDay": gameTimeOfDay,
	info["modversion"] = modversion #make sure mod version is saved, so we know if it's compatible
	info["saveMeta"] = sav
	info["heightList"] = heightList # keep the full heightlist

	var baseDir = GlobalRegistry.getModsFolder() # determine file location
	var f:File = File.new()
	f.open(baseDir.plus_file("ScaleTweakSave.json"),File.WRITE_READ)
	f.store_line(JSON.print(info, "\t", true)) # data is saved as human-readable json
	f.close()
	
# get saved data and load it into memory, then optionally update the sliders with saved values
func _on_Buttonload_pressed(_initialize):
	info = loadData()
#	scenePC = {}
#	sceneNPC = {}
#	sceneNPC2 = {}
	if(info.get("heightList") != null):
		heightList = info.get("heightList")
	if(_initialize): #can stop here if we're opening the menu for the first time
		return # also, trying to access the sliders when they don't exist yet will cause errors
	for pos in [0,1,2]:
			for entry in controlColumn[pos].get_children():
				entry.spin.value = entry.original #reset all the sliders
	for pos in [0,1,2]:
		for entry in controlColumn[pos].get_children():
			if(not info[selectedAnim].get_or_add(selectedState, {}).get_or_add(variants[dropdownVariant.selected],{}).get_or_add(position[pos], {}).has(entry.UUID)):
				continue # if there's nothing in the database, we leave the control at its default (original) value
			var stored = info[selectedAnim][selectedState][variants[dropdownVariant.selected]][position[pos]][entry.UUID]
			if(typeof(stored) == TYPE_REAL || typeof(stored) == TYPE_INT):
				entry.spin.value = stored
				entry.set_saved(stored)
			elif(typeof(stored) == TYPE_ARRAY):
				entry.spin.value = quat2angleZ(stored)
				entry.set_saved(quat2angleZ(stored))
				entry.customPose = Quat(stored[0], stored[1], stored[2], stored[3])
#	updateControlList("saved")
	_on_buttonVariant_item_selected(dropdownVariant.selected) # pretend we picked the variant
	
#	GM.main.getCharacter(thing.CharID).softUpdateDoll(theDoll) # let the game know we messed with the pose

#read the save data from JSON
func loadData():
	var baseDir = GlobalRegistry.getModsFolder()
	var f:File = File.new()
	if(not f.file_exists(baseDir.plus_file("ScaleTweakSave.json"))): #make a new file if it doesn't exist
		var template = MakeDataTemplate()
		return template

	var jsonResult
	var _err = f.open(baseDir.plus_file("ScaleTweakSave.json"),File.READ)
	assert(_err == OK,"[ScaleTweak] Saved poses file not found or does not exist")
	jsonResult = JSON.parse(f.get_as_text())
	assert(typeof(jsonResult.result) == TYPE_DICTIONARY, "[ScaleTweak] Could not read saved data file")
	
	return jsonResult.result

# dem bones
const theBoneList = [
	"Hips", 
	"Chest", 
	"Neck", 
	"Head", 
	"Arm.L", 
	"ForeArm.L", 
	"Hand.L", 
	"Arm.R", 
	"ForeArm.R", 
	"Hand.R", 
	"DeformBreasts", 
	"Nipples", 
	"LegUpper.L", 
	"LegDown.L", 
	"Foot.L", 
	"DeformThigh.L",
	"Penis", 
	"Balls", 
	"Penis2", 
	"Penis3", 
	"Tail1", 
	"Tail2", 
	"Tail3", 
	"Tail4", 
	"Tail5", 
	"LegUpper.R", 
	"LegDown.R", 
	"Foot.R", 
	"DeformThigh.R", 
	"DeformBelly", 
	"DeformButt",
	]

# extra bonus feature to set heights of many characters at once
# haven't tested this as much, may still be bugs
func _on_showheightlist_pressed():
	$ScaleHeightPopup.globalHeightList = heightList
	$ScaleHeightPopup.updateCharList(heightList)
	$ScaleHeightPopup.popup_centered(Vector2(440,350))
	$ScaleHeightPopup.connect("EditHeightList", self, "onEditHeightlist")
	
# this only works for first character slot but I'm too lazy to fix it
func onEditHeightlist(_heightlist):
	heightList.merge(_heightlist,true)
	if(not BoneUI1.get_children().empty()):
		for entry in BoneUI1.get_children():
			if(entry.UUID == "scale" and _heightlist.has(entry.CharID)):
				onScaleEdit(entry.CharID, _heightlist[entry.CharID], BoneUI1.get_child(0))
				BoneUI1.get_child(0).set_saved(_heightlist[entry.CharID])


func _on_Paste_pressed():
	if(clipboard.empty()):
		return
	if(BoneUI1.get_children().empty()):
		return
	for key in clipboard.keys():
		var column = position.find(key)
		var values = clipboard[key]
		for entry in controlColumn[column].get_children():
			if(entry.UUID in values):
				var value = values[entry.UUID]
				if(entry.UUID == "scale"):
					onScaleEdit(entry.CharID, value, entry)
				if(typeof(value) == TYPE_ARRAY): 
					value = quat2angleZ(value)
				entry.spin.value = value
			
			
