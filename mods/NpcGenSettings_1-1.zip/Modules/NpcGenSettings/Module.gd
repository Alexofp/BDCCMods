extends Module
class_name NpcGenSettingsModule

var ArchetypesEnable
var BodyAttributesEnable
var PersonalitiesEnable
var FetishesEnable
var LustTopicsEnable

var MaleThicknessMax
var MaleThicknessMin
var MaleFeminityMax
var MaleFeminityMin
var FemaleThicknessMax
var FemaleThicknessMin
var FemaleFeminityMax
var FemaleFeminityMin
var AndrogynousThicknessMax
var AndrogynousThicknessMin
var AndrogynousFeminityMax
var AndrogynousFeminityMin
var OtherThicknessMax
var OtherThicknessMin
var OtherFeminityMax
var OtherFeminityMin

var PersonalityStrongChance
var PersonalityStrongMult

var BratMax
var BratMin
var MeanMax
var MeanMin
var SubbyMax
var SubbyMin
var ImpatientMax
var ImpatientMin
var NaiveMax
var NaiveMin
var CowardMax
var CowardMin

var VaginalSexGivingMax
var VaginalSexGivingMin
var VaginalSexReceivingMax
var VaginalSexReceivingMin
var AnalSexGivingMax
var AnalSexGivingMin
var AnalSexReceivingMax
var AnalSexReceivingMin
var OralSexGivingMax
var OralSexGivingMin
var OralSexReceivingMax
var OralSexReceivingMin
var TribadismMax
var TribadismMin
var StraponSexVaginalMax
var StraponSexVaginalMin
var StraponSexAnalMax
var StraponSexAnalMin
var BodywritingsMax
var BodywritingsMin
var MasochismMax
var MasochismMin
var SadismMax
var SadismMin
var ChokingMax
var ChokingMin
var UnconsciousSexMax
var UnconsciousSexMin
var DrugUseMax
var DrugUseMin
var BreedingMax
var BreedingMin
var BeingBredMax
var BeingBredMin
var CondomsMax
var CondomsMin
var LactationMax
var LactationMin
var SeedMilkingMax
var SeedMilkingMin
var ExhibitionismMax
var ExhibitionismMin
var BondageMax
var BondageMin
var RiggingMax
var RiggingMin
var RimmingGivingMax
var RimmingGivingMin
var RimmingReceivingMax
var RimmingReceivingMin
var FeetplayGivingMax
var FeetplayGivingMin
var FeetplayReceivingMax
var FeetplayReceivingMin
var HypnosisHypnotistMax
var HypnosisHypnotistMin
var HypnosisSubjectMax
var HypnosisSubjectMin
var TFGivingMax
var TFGivingMin
var TFReceivingMax
var TFReceivingMin

var FeminineBodyHates
var MasculineBodyHates
var AndroBodyHates
var ThickBodyHates
var SlimBodyHates
var AverageMassBodyHates
var ThickButtHates
var AverageButtHates
var SlimButtHates
var BigBreastsHates
var SmallBreastsHates
var MediumBreastsHates
var NoBreastsHates
var LactatingBreastsHates
var NoVaginaHates
var HasVaginaOnlyHates
var HasVaginaAndCockHates
var BigCockHates
var AverageCockHates
var SmallCockHates
var NoCockHates
var HasCockOnlyHates
var StuffedPussyHates
var StuffedAssHates
var StuffedPussyOrAssHates
var PregnantHates
var StuffedThroatHates
var CoveredInCumHates
var CoveredInLotsOfCumHates
var FullyNakedHates
var ExposedPussyHates
var ExposedAnusHates
var ExposedBreastsHates
var ExposedCockHates
var ExposedPantiesHates
var ExposedBraHates
var LooseAnusHates
var LoosePussyHates
var TightAnusHates
var TightPussyHates
var TallyMarksHates
var BodywritingsHates
var GagsHates
var BlindfoldsHates
var BDSMRestraintsHates
var ButtPlugsHates
var VaginalPlugsHates

var FeminineBodyReallyDislikes
var MasculineBodyReallyDislikes
var AndroBodyReallyDislikes
var ThickBodyReallyDislikes
var SlimBodyReallyDislikes
var AverageMassBodyReallyDislikes
var ThickButtReallyDislikes
var AverageButtReallyDislikes
var SlimButtReallyDislikes
var BigBreastsReallyDislikes
var SmallBreastsReallyDislikes
var MediumBreastsReallyDislikes
var NoBreastsReallyDislikes
var LactatingBreastsReallyDislikes
var NoVaginaReallyDislikes
var HasVaginaOnlyReallyDislikes
var HasVaginaAndCockReallyDislikes
var BigCockReallyDislikes
var AverageCockReallyDislikes
var SmallCockReallyDislikes
var NoCockReallyDislikes
var HasCockOnlyReallyDislikes
var StuffedPussyReallyDislikes
var StuffedAssReallyDislikes
var StuffedPussyOrAssReallyDislikes
var PregnantReallyDislikes
var StuffedThroatReallyDislikes
var CoveredInCumReallyDislikes
var CoveredInLotsOfCumReallyDislikes
var FullyNakedReallyDislikes
var ExposedPussyReallyDislikes
var ExposedAnusReallyDislikes
var ExposedBreastsReallyDislikes
var ExposedCockReallyDislikes
var ExposedPantiesReallyDislikes
var ExposedBraReallyDislikes
var LooseAnusReallyDislikes
var LoosePussyReallyDislikes
var TightAnusReallyDislikes
var TightPussyReallyDislikes
var TallyMarksReallyDislikes
var BodywritingsReallyDislikes
var GagsReallyDislikes
var BlindfoldsReallyDislikes
var BDSMRestraintsReallyDislikes
var ButtPlugsReallyDislikes
var VaginalPlugsReallyDislikes

var FeminineBodyDislikes
var MasculineBodyDislikes
var AndroBodyDislikes
var ThickBodyDislikes
var SlimBodyDislikes
var AverageMassBodyDislikes
var ThickButtDislikes
var AverageButtDislikes
var SlimButtDislikes
var BigBreastsDislikes
var SmallBreastsDislikes
var MediumBreastsDislikes
var NoBreastsDislikes
var LactatingBreastsDislikes
var NoVaginaDislikes
var HasVaginaOnlyDislikes
var HasVaginaAndCockDislikes
var BigCockDislikes
var AverageCockDislikes
var SmallCockDislikes
var NoCockDislikes
var HasCockOnlyDislikes
var StuffedPussyDislikes
var StuffedAssDislikes
var StuffedPussyOrAssDislikes
var PregnantDislikes
var StuffedThroatDislikes
var CoveredInCumDislikes
var CoveredInLotsOfCumDislikes
var FullyNakedDislikes
var ExposedPussyDislikes
var ExposedAnusDislikes
var ExposedBreastsDislikes
var ExposedCockDislikes
var ExposedPantiesDislikes
var ExposedBraDislikes
var LooseAnusDislikes
var LoosePussyDislikes
var TightAnusDislikes
var TightPussyDislikes
var TallyMarksDislikes
var BodywritingsDislikes
var GagsDislikes
var BlindfoldsDislikes
var BDSMRestraintsDislikes
var ButtPlugsDislikes
var VaginalPlugsDislikes

var FeminineBodySlightlyDislikes
var MasculineBodySlightlyDislikes
var AndroBodySlightlyDislikes
var ThickBodySlightlyDislikes
var SlimBodySlightlyDislikes
var AverageMassBodySlightlyDislikes
var ThickButtSlightlyDislikes
var AverageButtSlightlyDislikes
var SlimButtSlightlyDislikes
var BigBreastsSlightlyDislikes
var SmallBreastsSlightlyDislikes
var MediumBreastsSlightlyDislikes
var NoBreastsSlightlyDislikes
var LactatingBreastsSlightlyDislikes
var NoVaginaSlightlyDislikes
var HasVaginaOnlySlightlyDislikes
var HasVaginaAndCockSlightlyDislikes
var BigCockSlightlyDislikes
var AverageCockSlightlyDislikes
var SmallCockSlightlyDislikes
var NoCockSlightlyDislikes
var HasCockOnlySlightlyDislikes
var StuffedPussySlightlyDislikes
var StuffedAssSlightlyDislikes
var StuffedPussyOrAssSlightlyDislikes
var PregnantSlightlyDislikes
var StuffedThroatSlightlyDislikes
var CoveredInCumSlightlyDislikes
var CoveredInLotsOfCumSlightlyDislikes
var FullyNakedSlightlyDislikes
var ExposedPussySlightlyDislikes
var ExposedAnusSlightlyDislikes
var ExposedBreastsSlightlyDislikes
var ExposedCockSlightlyDislikes
var ExposedPantiesSlightlyDislikes
var ExposedBraSlightlyDislikes
var LooseAnusSlightlyDislikes
var LoosePussySlightlyDislikes
var TightAnusSlightlyDislikes
var TightPussySlightlyDislikes
var TallyMarksSlightlyDislikes
var BodywritingsSlightlyDislikes
var GagsSlightlyDislikes
var BlindfoldsSlightlyDislikes
var BDSMRestraintsSlightlyDislikes
var ButtPlugsSlightlyDislikes
var VaginalPlugsSlightlyDislikes

var FeminineBodyNeutral
var MasculineBodyNeutral
var AndroBodyNeutral
var ThickBodyNeutral
var SlimBodyNeutral
var AverageMassBodyNeutral
var ThickButtNeutral
var AverageButtNeutral
var SlimButtNeutral
var BigBreastsNeutral
var SmallBreastsNeutral
var MediumBreastsNeutral
var NoBreastsNeutral
var LactatingBreastsNeutral
var NoVaginaNeutral
var HasVaginaOnlyNeutral
var HasVaginaAndCockNeutral
var BigCockNeutral
var AverageCockNeutral
var SmallCockNeutral
var NoCockNeutral
var HasCockOnlyNeutral
var StuffedPussyNeutral
var StuffedAssNeutral
var StuffedPussyOrAssNeutral
var PregnantNeutral
var StuffedThroatNeutral
var CoveredInCumNeutral
var CoveredInLotsOfCumNeutral
var FullyNakedNeutral
var ExposedPussyNeutral
var ExposedAnusNeutral
var ExposedBreastsNeutral
var ExposedCockNeutral
var ExposedPantiesNeutral
var ExposedBraNeutral
var LooseAnusNeutral
var LoosePussyNeutral
var TightAnusNeutral
var TightPussyNeutral
var TallyMarksNeutral
var BodywritingsNeutral
var GagsNeutral
var BlindfoldsNeutral
var BDSMRestraintsNeutral
var ButtPlugsNeutral
var VaginalPlugsNeutral

var FeminineBodyKindaLikes
var MasculineBodyKindaLikes
var AndroBodyKindaLikes
var ThickBodyKindaLikes
var SlimBodyKindaLikes
var AverageMassBodyKindaLikes
var ThickButtKindaLikes
var AverageButtKindaLikes
var SlimButtKindaLikes
var BigBreastsKindaLikes
var SmallBreastsKindaLikes
var MediumBreastsKindaLikes
var NoBreastsKindaLikes
var LactatingBreastsKindaLikes
var NoVaginaKindaLikes
var HasVaginaOnlyKindaLikes
var HasVaginaAndCockKindaLikes
var BigCockKindaLikes
var AverageCockKindaLikes
var SmallCockKindaLikes
var NoCockKindaLikes
var HasCockOnlyKindaLikes
var StuffedPussyKindaLikes
var StuffedAssKindaLikes
var StuffedPussyOrAssKindaLikes
var PregnantKindaLikes
var StuffedThroatKindaLikes
var CoveredInCumKindaLikes
var CoveredInLotsOfCumKindaLikes
var FullyNakedKindaLikes
var ExposedPussyKindaLikes
var ExposedAnusKindaLikes
var ExposedBreastsKindaLikes
var ExposedCockKindaLikes
var ExposedPantiesKindaLikes
var ExposedBraKindaLikes
var LooseAnusKindaLikes
var LoosePussyKindaLikes
var TightAnusKindaLikes
var TightPussyKindaLikes
var TallyMarksKindaLikes
var BodywritingsKindaLikes
var GagsKindaLikes
var BlindfoldsKindaLikes
var BDSMRestraintsKindaLikes
var ButtPlugsKindaLikes
var VaginalPlugsKindaLikes

var FeminineBodyLikes
var MasculineBodyLikes
var AndroBodyLikes
var ThickBodyLikes
var SlimBodyLikes
var AverageMassBodyLikes
var ThickButtLikes
var AverageButtLikes
var SlimButtLikes
var BigBreastsLikes
var SmallBreastsLikes
var MediumBreastsLikes
var NoBreastsLikes
var LactatingBreastsLikes
var NoVaginaLikes
var HasVaginaOnlyLikes
var HasVaginaAndCockLikes
var BigCockLikes
var AverageCockLikes
var SmallCockLikes
var NoCockLikes
var HasCockOnlyLikes
var StuffedPussyLikes
var StuffedAssLikes
var StuffedPussyOrAssLikes
var PregnantLikes
var StuffedThroatLikes
var CoveredInCumLikes
var CoveredInLotsOfCumLikes
var FullyNakedLikes
var ExposedPussyLikes
var ExposedAnusLikes
var ExposedBreastsLikes
var ExposedCockLikes
var ExposedPantiesLikes
var ExposedBraLikes
var LooseAnusLikes
var LoosePussyLikes
var TightAnusLikes
var TightPussyLikes
var TallyMarksLikes
var BodywritingsLikes
var GagsLikes
var BlindfoldsLikes
var BDSMRestraintsLikes
var ButtPlugsLikes
var VaginalPlugsLikes

var FeminineBodyReallyLikes
var MasculineBodyReallyLikes
var AndroBodyReallyLikes
var ThickBodyReallyLikes
var SlimBodyReallyLikes
var AverageMassBodyReallyLikes
var ThickButtReallyLikes
var AverageButtReallyLikes
var SlimButtReallyLikes
var BigBreastsReallyLikes
var SmallBreastsReallyLikes
var MediumBreastsReallyLikes
var NoBreastsReallyLikes
var LactatingBreastsReallyLikes
var NoVaginaReallyLikes
var HasVaginaOnlyReallyLikes
var HasVaginaAndCockReallyLikes
var BigCockReallyLikes
var AverageCockReallyLikes
var SmallCockReallyLikes
var NoCockReallyLikes
var HasCockOnlyReallyLikes
var StuffedPussyReallyLikes
var StuffedAssReallyLikes
var StuffedPussyOrAssReallyLikes
var PregnantReallyLikes
var StuffedThroatReallyLikes
var CoveredInCumReallyLikes
var CoveredInLotsOfCumReallyLikes
var FullyNakedReallyLikes
var ExposedPussyReallyLikes
var ExposedAnusReallyLikes
var ExposedBreastsReallyLikes
var ExposedCockReallyLikes
var ExposedPantiesReallyLikes
var ExposedBraReallyLikes
var LooseAnusReallyLikes
var LoosePussyReallyLikes
var TightAnusReallyLikes
var TightPussyReallyLikes
var TallyMarksReallyLikes
var BodywritingsReallyLikes
var GagsReallyLikes
var BlindfoldsReallyLikes
var BDSMRestraintsReallyLikes
var ButtPlugsReallyLikes
var VaginalPlugsReallyLikes

var FeminineBodyLoves
var MasculineBodyLoves
var AndroBodyLoves
var ThickBodyLoves
var SlimBodyLoves
var AverageMassBodyLoves
var ThickButtLoves
var AverageButtLoves
var SlimButtLoves
var BigBreastsLoves
var SmallBreastsLoves
var MediumBreastsLoves
var NoBreastsLoves
var LactatingBreastsLoves
var NoVaginaLoves
var HasVaginaOnlyLoves
var HasVaginaAndCockLoves
var BigCockLoves
var AverageCockLoves
var SmallCockLoves
var NoCockLoves
var HasCockOnlyLoves
var StuffedPussyLoves
var StuffedAssLoves
var StuffedPussyOrAssLoves
var PregnantLoves
var StuffedThroatLoves
var CoveredInCumLoves
var CoveredInLotsOfCumLoves
var FullyNakedLoves
var ExposedPussyLoves
var ExposedAnusLoves
var ExposedBreastsLoves
var ExposedCockLoves
var ExposedPantiesLoves
var ExposedBraLoves
var LooseAnusLoves
var LoosePussyLoves
var TightAnusLoves
var TightPussyLoves
var TallyMarksLoves
var BodywritingsLoves
var GagsLoves
var BlindfoldsLoves
var BDSMRestraintsLoves
var ButtPlugsLoves
var VaginalPlugsLoves

# [ PlaceBeforeTarget, Target, PlaceAfterTarget ]
var hooks = [
	["const moddedGenerator = preload('res://Modules/NpcGenSettings/ModdedCharacterGeneratorBase.gd')\n", "func generate(_args = {}):", ""],
	["moddedGenerator.", "pickBodyAttributes(character, _args)", ""],
	["moddedGenerator.", "pickFetishes(character, _args)", ""],
	["moddedGenerator.", "pickLustInterests(character, _args)", ""],
	["moddedGenerator.", "pickPersonality(character, _args)", ""],
]

func _init():
	id = "NpcGenSettingsModule"
	author = "Mindstormsman"

# Hacky shit, FoxLib dosen't expose the float option type despite supporting it internally
func addFloatOption(foxModuleAPI, optionID, title, description=null, defaultValue=0):
	return self.addFloatOptionInCategory(foxModuleAPI, foxModuleAPI.getName(), optionID, title, description, defaultValue)

func addFloatOptionInCategory(foxModuleAPI, category, optionID, title, description=null, defaultValue=0):
	return foxModuleAPI.addOptionInCategoryInternal("float", category, optionID, title, description, defaultValue)

func onFoxLibModInit(foxModuleAPI):
	
	# Ultra Hacky Shit
	# replace(hook[Target], hook[PlaceBeforeTarget] + hook[Target] + hook[PlaceAfterTarget])
	var characterGeneratorBase = load("res://Characters/Dynamic/Generator/CharacterGeneratorBase.gd")
	var originalCode = characterGeneratorBase.source_code
	#var hook = "const moddedGenerator = preload('res://Modules/NpcGenSettings/ModdedCharacterGeneratorBase.gd')\nfunc generate(_args = {}):\n\treturn moddedGenerator.generate(self, _args)\n\nfunc _old_generate(_args = {}):"
	#var modifiedCode = originalCode.replace("func generate(_args = {}):", hook)
	var modifiedCode = originalCode
	for hook in hooks:
		modifiedCode = modifiedCode.replace(hook[1], hook[0] + hook[1] + hook[2])
	characterGeneratorBase.source_code = modifiedCode
	characterGeneratorBase.reload()
	
	# Basic, Enables
	foxModuleAPI.addBooleanOptionInCategory("NPC Generation Settings - Toggles", "ArchetypesEnable", "Enable Archetypes", "Archetypes modify personalities and fetishes, for example a bottom will become more subby and like receving more", true)
	foxModuleAPI.addBooleanOptionInCategory("NPC Generation Settings - Toggles", "BodyAttributesEnable", "Enable Body Attribues", "Turn on modified body attribute generation", false)
	foxModuleAPI.addBooleanOptionInCategory("NPC Generation Settings - Toggles", "PersonalitiesEnable", "Enable Personalities", "Turn on modified personality generation", false)
	foxModuleAPI.addBooleanOptionInCategory("NPC Generation Settings - Toggles", "FetishesEnable", "Enable Fetishes", "Turn on modified fetish generation", false)
	foxModuleAPI.addBooleanOptionInCategory("NPC Generation Settings - Toggles", "LustTopicsEnable", "Enable Lust Topics", "Turn on modified lust topic generation", false)
	
	# Body Attributes
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "MaleThicknessMax", "Male Thickness - Max", "", 60)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "MaleThicknessMin", "       - Min", "", 0)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "MaleFeminityMax", "Male Feminity - Max", "", 50)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "MaleFeminityMin", "       - Min", "", 0)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "FemaleThicknessMax", "Female Thickness - Max", "", 110)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "FemaleThicknessMin", "       - Min", "", 0)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "FemaleFeminityMax", "Female Feminity - Max", "", 100)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "FemaleFeminityMin", "       - Min", "", 50)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "AndrogynousThicknessMax", "Androgynous Thickness - Max", "", 100)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "AndrogynousThicknessMin", "       - Min", "", 0)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "AndrogynousFeminityMax", "Androgynous Feminity - Max", "", 75)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "AndrogynousFeminityMin", "       - Min", "", 25)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "OtherThicknessMax", "Other Thickness - Max", "", 100)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "OtherThicknessMin", "       - Min", "", 0)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "OtherFeminityMax", "Other Feminity - Max", "", 100)
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Body Attributes", "OtherFeminityMin", "       - Min", "", 0)
	
	# Personalities
	foxModuleAPI.addNumberOptionInCategory("NPC Generation Settings - Personalities", "PersonalityStrongChance", "Strong Personality Chance", "What % of personalities should be strong", 5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "PersonalityStrongMult", "Strong Personality Multiplier", "How much to multiply the RNG value rolled for a strong personality", 5.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "BratMax", "Brat - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "BratMin", "       - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "MeanMax", "Mean - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "MeanMin", "       - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "SubbyMax", "Subby - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "SubbyMin", "       - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "ImpatientMax", "Impatient - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "ImpatientMin", "       - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "NaiveMax", "Naive - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "NaiveMin", "       - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "CowardMax", "Coward - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Personalities", "CowardMin", "       - Min", "", -0.3)
	
	# Fetishes
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "VaginalSexGivingMax", "VaginalSexGiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "VaginalSexGivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "VaginalSexReceivingMax", "VaginalSexReceiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "VaginalSexReceivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "AnalSexGivingMax", "AnalSexGiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "AnalSexGivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "AnalSexReceivingMax", "AnalSexReceiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "AnalSexReceivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "OralSexGivingMax", "OralSexGiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "OralSexGivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "OralSexReceivingMax", "OralSexReceiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "OralSexReceivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "TribadismMax", "Tribadism - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "TribadismMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "StraponSexVaginalMax", "StraponSexVaginal - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "StraponSexVaginalMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "StraponSexAnalMax", "StraponSexAnal - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "StraponSexAnalMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BodywritingsMax", "Bodywritings - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BodywritingsMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "MasochismMax", "Masochism - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "MasochismMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "SadismMax", "Sadism - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "SadismMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "ChokingMax", "Choking - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "ChokingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "UnconsciousSexMax", "UnconsciousSex - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "UnconsciousSexMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "DrugUseMax", "DrugUse - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "DrugUseMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BreedingMax", "Breeding - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BreedingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BeingBredMax", "BeingBred - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BeingBredMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "CondomsMax", "Condoms - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "CondomsMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "LactationMax", "Lactation - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "LactationMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "SeedMilkingMax", "SeedMilking - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "SeedMilkingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "ExhibitionismMax", "Exhibitionism - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "ExhibitionismMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BondageMax", "Bondage - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "BondageMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "RiggingMax", "Rigging - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "RiggingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "RimmingGivingMax", "RimmingGiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "RimmingGivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "RimmingReceivingMax", "RimmingReceiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "RimmingReceivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "FeetplayGivingMax", "FeetplayGiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "FeetplayGivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "FeetplayReceivingMax", "FeetplayReceiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "FeetplayReceivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "HypnosisHypnotistMax", "HypnosisHypnotist - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "HypnosisHypnotistMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "HypnosisSubjectMax", "HypnosisSubject - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "HypnosisSubjectMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "TFGivingMax", "TFGiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "TFGivingMin", "      - Min", "", -0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "TFReceivingMax", "TFReceiving - Max", "", 0.3)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Fetishes", "TFReceivingMin", "      - Min", "", -0.3)
	
	# Lust Topics
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "FeminineBodyHates", "FeminineBodyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "MasculineBodyHates", "MasculineBodyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "AndroBodyHates", "AndroBodyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ThickBodyHates", "ThickBodyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "SlimBodyHates", "SlimBodyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "AverageMassBodyHates", "AverageMassBodyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ThickButtHates", "ThickButtHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "AverageButtHates", "AverageButtHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "SlimButtHates", "SlimButtHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "BigBreastsHates", "BigBreastsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "SmallBreastsHates", "SmallBreastsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "MediumBreastsHates", "MediumBreastsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "NoBreastsHates", "NoBreastsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "LactatingBreastsHates", "LactatingBreastsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "NoVaginaHates", "NoVaginaHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "HasVaginaOnlyHates", "HasVaginaOnlyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "HasVaginaAndCockHates", "HasVaginaAndCockHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "BigCockHates", "BigCockHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "AverageCockHates", "AverageCockHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "SmallCockHates", "SmallCockHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "NoCockHates", "NoCockHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "HasCockOnlyHates", "HasCockOnlyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "StuffedPussyHates", "StuffedPussyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "StuffedAssHates", "StuffedAssHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "StuffedPussyOrAssHates", "StuffedPussyOrAssHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "PregnantHates", "PregnantHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "StuffedThroatHates", "StuffedThroatHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "CoveredInCumHates", "CoveredInCumHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "CoveredInLotsOfCumHates", "CoveredInLotsOfCumHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "FullyNakedHates", "FullyNakedHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ExposedPussyHates", "ExposedPussyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ExposedAnusHates", "ExposedAnusHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ExposedBreastsHates", "ExposedBreastsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ExposedCockHates", "ExposedCockHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ExposedPantiesHates", "ExposedPantiesHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ExposedBraHates", "ExposedBraHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "LooseAnusHates", "LooseAnusHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "LoosePussyHates", "LoosePussyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "TightAnusHates", "TightAnusHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "TightPussyHates", "TightPussyHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "TallyMarksHates", "TallyMarksHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "BodywritingsHates", "BodywritingsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "GagsHates", "GagsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "BlindfoldsHates", "BlindfoldsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "BDSMRestraintsHates", "BDSMRestraintsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "ButtPlugsHates", "ButtPlugsHates", "", 0.5)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Hates", "VaginalPlugsHates", "VaginalPlugsHates", "", 0.5)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "FeminineBodyReallyDislikes", "FeminineBodyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "MasculineBodyReallyDislikes", "MasculineBodyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "AndroBodyReallyDislikes", "AndroBodyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ThickBodyReallyDislikes", "ThickBodyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "SlimBodyReallyDislikes", "SlimBodyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "AverageMassBodyReallyDislikes", "AverageMassBodyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ThickButtReallyDislikes", "ThickButtReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "AverageButtReallyDislikes", "AverageButtReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "SlimButtReallyDislikes", "SlimButtReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "BigBreastsReallyDislikes", "BigBreastsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "SmallBreastsReallyDislikes", "SmallBreastsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "MediumBreastsReallyDislikes", "MediumBreastsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "NoBreastsReallyDislikes", "NoBreastsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "LactatingBreastsReallyDislikes", "LactatingBreastsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "NoVaginaReallyDislikes", "NoVaginaReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "HasVaginaOnlyReallyDislikes", "HasVaginaOnlyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "HasVaginaAndCockReallyDislikes", "HasVaginaAndCockReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "BigCockReallyDislikes", "BigCockReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "AverageCockReallyDislikes", "AverageCockReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "SmallCockReallyDislikes", "SmallCockReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "NoCockReallyDislikes", "NoCockReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "HasCockOnlyReallyDislikes", "HasCockOnlyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "StuffedPussyReallyDislikes", "StuffedPussyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "StuffedAssReallyDislikes", "StuffedAssReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "StuffedPussyOrAssReallyDislikes", "StuffedPussyOrAssReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "PregnantReallyDislikes", "PregnantReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "StuffedThroatReallyDislikes", "StuffedThroatReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "CoveredInCumReallyDislikes", "CoveredInCumReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "CoveredInLotsOfCumReallyDislikes", "CoveredInLotsOfCumReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "FullyNakedReallyDislikes", "FullyNakedReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ExposedPussyReallyDislikes", "ExposedPussyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ExposedAnusReallyDislikes", "ExposedAnusReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ExposedBreastsReallyDislikes", "ExposedBreastsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ExposedCockReallyDislikes", "ExposedCockReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ExposedPantiesReallyDislikes", "ExposedPantiesReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ExposedBraReallyDislikes", "ExposedBraReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "LooseAnusReallyDislikes", "LooseAnusReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "LoosePussyReallyDislikes", "LoosePussyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "TightAnusReallyDislikes", "TightAnusReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "TightPussyReallyDislikes", "TightPussyReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "TallyMarksReallyDislikes", "TallyMarksReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "BodywritingsReallyDislikes", "BodywritingsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "GagsReallyDislikes", "GagsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "BlindfoldsReallyDislikes", "BlindfoldsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "BDSMRestraintsReallyDislikes", "BDSMRestraintsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "ButtPlugsReallyDislikes", "ButtPlugsReallyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyDislikes", "VaginalPlugsReallyDislikes", "VaginalPlugsReallyDislikes", "", 0.6)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "FeminineBodyDislikes", "FeminineBodyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "MasculineBodyDislikes", "MasculineBodyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "AndroBodyDislikes", "AndroBodyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ThickBodyDislikes", "ThickBodyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "SlimBodyDislikes", "SlimBodyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "AverageMassBodyDislikes", "AverageMassBodyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ThickButtDislikes", "ThickButtDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "AverageButtDislikes", "AverageButtDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "SlimButtDislikes", "SlimButtDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "BigBreastsDislikes", "BigBreastsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "SmallBreastsDislikes", "SmallBreastsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "MediumBreastsDislikes", "MediumBreastsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "NoBreastsDislikes", "NoBreastsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "LactatingBreastsDislikes", "LactatingBreastsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "NoVaginaDislikes", "NoVaginaDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "HasVaginaOnlyDislikes", "HasVaginaOnlyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "HasVaginaAndCockDislikes", "HasVaginaAndCockDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "BigCockDislikes", "BigCockDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "AverageCockDislikes", "AverageCockDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "SmallCockDislikes", "SmallCockDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "NoCockDislikes", "NoCockDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "HasCockOnlyDislikes", "HasCockOnlyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "StuffedPussyDislikes", "StuffedPussyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "StuffedAssDislikes", "StuffedAssDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "StuffedPussyOrAssDislikes", "StuffedPussyOrAssDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "PregnantDislikes", "PregnantDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "StuffedThroatDislikes", "StuffedThroatDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "CoveredInCumDislikes", "CoveredInCumDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "CoveredInLotsOfCumDislikes", "CoveredInLotsOfCumDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "FullyNakedDislikes", "FullyNakedDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ExposedPussyDislikes", "ExposedPussyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ExposedAnusDislikes", "ExposedAnusDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ExposedBreastsDislikes", "ExposedBreastsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ExposedCockDislikes", "ExposedCockDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ExposedPantiesDislikes", "ExposedPantiesDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ExposedBraDislikes", "ExposedBraDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "LooseAnusDislikes", "LooseAnusDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "LoosePussyDislikes", "LoosePussyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "TightAnusDislikes", "TightAnusDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "TightPussyDislikes", "TightPussyDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "TallyMarksDislikes", "TallyMarksDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "BodywritingsDislikes", "BodywritingsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "GagsDislikes", "GagsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "BlindfoldsDislikes", "BlindfoldsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "BDSMRestraintsDislikes", "BDSMRestraintsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "ButtPlugsDislikes", "ButtPlugsDislikes", "", 0.7)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Dislikes", "VaginalPlugsDislikes", "VaginalPlugsDislikes", "", 0.7)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "FeminineBodySlightlyDislikes", "FeminineBodySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "MasculineBodySlightlyDislikes", "MasculineBodySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "AndroBodySlightlyDislikes", "AndroBodySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ThickBodySlightlyDislikes", "ThickBodySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "SlimBodySlightlyDislikes", "SlimBodySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "AverageMassBodySlightlyDislikes", "AverageMassBodySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ThickButtSlightlyDislikes", "ThickButtSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "AverageButtSlightlyDislikes", "AverageButtSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "SlimButtSlightlyDislikes", "SlimButtSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "BigBreastsSlightlyDislikes", "BigBreastsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "SmallBreastsSlightlyDislikes", "SmallBreastsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "MediumBreastsSlightlyDislikes", "MediumBreastsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "NoBreastsSlightlyDislikes", "NoBreastsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "LactatingBreastsSlightlyDislikes", "LactatingBreastsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "NoVaginaSlightlyDislikes", "NoVaginaSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "HasVaginaOnlySlightlyDislikes", "HasVaginaOnlySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "HasVaginaAndCockSlightlyDislikes", "HasVaginaAndCockSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "BigCockSlightlyDislikes", "BigCockSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "AverageCockSlightlyDislikes", "AverageCockSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "SmallCockSlightlyDislikes", "SmallCockSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "NoCockSlightlyDislikes", "NoCockSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "HasCockOnlySlightlyDislikes", "HasCockOnlySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "StuffedPussySlightlyDislikes", "StuffedPussySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "StuffedAssSlightlyDislikes", "StuffedAssSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "StuffedPussyOrAssSlightlyDislikes", "StuffedPussyOrAssSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "PregnantSlightlyDislikes", "PregnantSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "StuffedThroatSlightlyDislikes", "StuffedThroatSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "CoveredInCumSlightlyDislikes", "CoveredInCumSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "CoveredInLotsOfCumSlightlyDislikes", "CoveredInLotsOfCumSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "FullyNakedSlightlyDislikes", "FullyNakedSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ExposedPussySlightlyDislikes", "ExposedPussySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ExposedAnusSlightlyDislikes", "ExposedAnusSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ExposedBreastsSlightlyDislikes", "ExposedBreastsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ExposedCockSlightlyDislikes", "ExposedCockSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ExposedPantiesSlightlyDislikes", "ExposedPantiesSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ExposedBraSlightlyDislikes", "ExposedBraSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "LooseAnusSlightlyDislikes", "LooseAnusSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "LoosePussySlightlyDislikes", "LoosePussySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "TightAnusSlightlyDislikes", "TightAnusSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "TightPussySlightlyDislikes", "TightPussySlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "TallyMarksSlightlyDislikes", "TallyMarksSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "BodywritingsSlightlyDislikes", "BodywritingsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "GagsSlightlyDislikes", "GagsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "BlindfoldsSlightlyDislikes", "BlindfoldsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "BDSMRestraintsSlightlyDislikes", "BDSMRestraintsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "ButtPlugsSlightlyDislikes", "ButtPlugsSlightlyDislikes", "", 0.6)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - SlightlyDislikes", "VaginalPlugsSlightlyDislikes", "VaginalPlugsSlightlyDislikes", "", 0.6)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "FeminineBodyNeutral", "FeminineBodyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "MasculineBodyNeutral", "MasculineBodyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "AndroBodyNeutral", "AndroBodyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ThickBodyNeutral", "ThickBodyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "SlimBodyNeutral", "SlimBodyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "AverageMassBodyNeutral", "AverageMassBodyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ThickButtNeutral", "ThickButtNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "AverageButtNeutral", "AverageButtNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "SlimButtNeutral", "SlimButtNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "BigBreastsNeutral", "BigBreastsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "SmallBreastsNeutral", "SmallBreastsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "MediumBreastsNeutral", "MediumBreastsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "NoBreastsNeutral", "NoBreastsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "LactatingBreastsNeutral", "LactatingBreastsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "NoVaginaNeutral", "NoVaginaNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "HasVaginaOnlyNeutral", "HasVaginaOnlyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "HasVaginaAndCockNeutral", "HasVaginaAndCockNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "BigCockNeutral", "BigCockNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "AverageCockNeutral", "AverageCockNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "SmallCockNeutral", "SmallCockNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "NoCockNeutral", "NoCockNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "HasCockOnlyNeutral", "HasCockOnlyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "StuffedPussyNeutral", "StuffedPussyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "StuffedAssNeutral", "StuffedAssNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "StuffedPussyOrAssNeutral", "StuffedPussyOrAssNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "PregnantNeutral", "PregnantNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "StuffedThroatNeutral", "StuffedThroatNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "CoveredInCumNeutral", "CoveredInCumNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "CoveredInLotsOfCumNeutral", "CoveredInLotsOfCumNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "FullyNakedNeutral", "FullyNakedNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ExposedPussyNeutral", "ExposedPussyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ExposedAnusNeutral", "ExposedAnusNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ExposedBreastsNeutral", "ExposedBreastsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ExposedCockNeutral", "ExposedCockNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ExposedPantiesNeutral", "ExposedPantiesNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ExposedBraNeutral", "ExposedBraNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "LooseAnusNeutral", "LooseAnusNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "LoosePussyNeutral", "LoosePussyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "TightAnusNeutral", "TightAnusNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "TightPussyNeutral", "TightPussyNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "TallyMarksNeutral", "TallyMarksNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "BodywritingsNeutral", "BodywritingsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "GagsNeutral", "GagsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "BlindfoldsNeutral", "BlindfoldsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "BDSMRestraintsNeutral", "BDSMRestraintsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "ButtPlugsNeutral", "ButtPlugsNeutral", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Neutral", "VaginalPlugsNeutral", "VaginalPlugsNeutral", "", 1.0)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "FeminineBodyKindaLikes", "FeminineBodyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "MasculineBodyKindaLikes", "MasculineBodyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "AndroBodyKindaLikes", "AndroBodyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ThickBodyKindaLikes", "ThickBodyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "SlimBodyKindaLikes", "SlimBodyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "AverageMassBodyKindaLikes", "AverageMassBodyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ThickButtKindaLikes", "ThickButtKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "AverageButtKindaLikes", "AverageButtKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "SlimButtKindaLikes", "SlimButtKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "BigBreastsKindaLikes", "BigBreastsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "SmallBreastsKindaLikes", "SmallBreastsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "MediumBreastsKindaLikes", "MediumBreastsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "NoBreastsKindaLikes", "NoBreastsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "LactatingBreastsKindaLikes", "LactatingBreastsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "NoVaginaKindaLikes", "NoVaginaKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "HasVaginaOnlyKindaLikes", "HasVaginaOnlyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "HasVaginaAndCockKindaLikes", "HasVaginaAndCockKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "BigCockKindaLikes", "BigCockKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "AverageCockKindaLikes", "AverageCockKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "SmallCockKindaLikes", "SmallCockKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "NoCockKindaLikes", "NoCockKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "HasCockOnlyKindaLikes", "HasCockOnlyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "StuffedPussyKindaLikes", "StuffedPussyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "StuffedAssKindaLikes", "StuffedAssKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "StuffedPussyOrAssKindaLikes", "StuffedPussyOrAssKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "PregnantKindaLikes", "PregnantKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "StuffedThroatKindaLikes", "StuffedThroatKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "CoveredInCumKindaLikes", "CoveredInCumKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "CoveredInLotsOfCumKindaLikes", "CoveredInLotsOfCumKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "FullyNakedKindaLikes", "FullyNakedKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ExposedPussyKindaLikes", "ExposedPussyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ExposedAnusKindaLikes", "ExposedAnusKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ExposedBreastsKindaLikes", "ExposedBreastsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ExposedCockKindaLikes", "ExposedCockKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ExposedPantiesKindaLikes", "ExposedPantiesKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ExposedBraKindaLikes", "ExposedBraKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "LooseAnusKindaLikes", "LooseAnusKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "LoosePussyKindaLikes", "LoosePussyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "TightAnusKindaLikes", "TightAnusKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "TightPussyKindaLikes", "TightPussyKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "TallyMarksKindaLikes", "TallyMarksKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "BodywritingsKindaLikes", "BodywritingsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "GagsKindaLikes", "GagsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "BlindfoldsKindaLikes", "BlindfoldsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "BDSMRestraintsKindaLikes", "BDSMRestraintsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "ButtPlugsKindaLikes", "ButtPlugsKindaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - KindaLikes", "VaginalPlugsKindaLikes", "VaginalPlugsKindaLikes", "", 1.0)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "FeminineBodyLikes", "FeminineBodyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "MasculineBodyLikes", "MasculineBodyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "AndroBodyLikes", "AndroBodyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ThickBodyLikes", "ThickBodyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "SlimBodyLikes", "SlimBodyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "AverageMassBodyLikes", "AverageMassBodyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ThickButtLikes", "ThickButtLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "AverageButtLikes", "AverageButtLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "SlimButtLikes", "SlimButtLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "BigBreastsLikes", "BigBreastsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "SmallBreastsLikes", "SmallBreastsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "MediumBreastsLikes", "MediumBreastsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "NoBreastsLikes", "NoBreastsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "LactatingBreastsLikes", "LactatingBreastsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "NoVaginaLikes", "NoVaginaLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "HasVaginaOnlyLikes", "HasVaginaOnlyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "HasVaginaAndCockLikes", "HasVaginaAndCockLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "BigCockLikes", "BigCockLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "AverageCockLikes", "AverageCockLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "SmallCockLikes", "SmallCockLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "NoCockLikes", "NoCockLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "HasCockOnlyLikes", "HasCockOnlyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "StuffedPussyLikes", "StuffedPussyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "StuffedAssLikes", "StuffedAssLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "StuffedPussyOrAssLikes", "StuffedPussyOrAssLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "PregnantLikes", "PregnantLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "StuffedThroatLikes", "StuffedThroatLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "CoveredInCumLikes", "CoveredInCumLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "CoveredInLotsOfCumLikes", "CoveredInLotsOfCumLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "FullyNakedLikes", "FullyNakedLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ExposedPussyLikes", "ExposedPussyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ExposedAnusLikes", "ExposedAnusLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ExposedBreastsLikes", "ExposedBreastsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ExposedCockLikes", "ExposedCockLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ExposedPantiesLikes", "ExposedPantiesLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ExposedBraLikes", "ExposedBraLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "LooseAnusLikes", "LooseAnusLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "LoosePussyLikes", "LoosePussyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "TightAnusLikes", "TightAnusLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "TightPussyLikes", "TightPussyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "TallyMarksLikes", "TallyMarksLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "BodywritingsLikes", "BodywritingsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "GagsLikes", "GagsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "BlindfoldsLikes", "BlindfoldsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "BDSMRestraintsLikes", "BDSMRestraintsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "ButtPlugsLikes", "ButtPlugsLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Likes", "VaginalPlugsLikes", "VaginalPlugsLikes", "", 1.0)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "FeminineBodyReallyLikes", "FeminineBodyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "MasculineBodyReallyLikes", "MasculineBodyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "AndroBodyReallyLikes", "AndroBodyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ThickBodyReallyLikes", "ThickBodyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "SlimBodyReallyLikes", "SlimBodyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "AverageMassBodyReallyLikes", "AverageMassBodyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ThickButtReallyLikes", "ThickButtReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "AverageButtReallyLikes", "AverageButtReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "SlimButtReallyLikes", "SlimButtReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "BigBreastsReallyLikes", "BigBreastsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "SmallBreastsReallyLikes", "SmallBreastsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "MediumBreastsReallyLikes", "MediumBreastsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "NoBreastsReallyLikes", "NoBreastsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "LactatingBreastsReallyLikes", "LactatingBreastsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "NoVaginaReallyLikes", "NoVaginaReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "HasVaginaOnlyReallyLikes", "HasVaginaOnlyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "HasVaginaAndCockReallyLikes", "HasVaginaAndCockReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "BigCockReallyLikes", "BigCockReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "AverageCockReallyLikes", "AverageCockReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "SmallCockReallyLikes", "SmallCockReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "NoCockReallyLikes", "NoCockReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "HasCockOnlyReallyLikes", "HasCockOnlyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "StuffedPussyReallyLikes", "StuffedPussyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "StuffedAssReallyLikes", "StuffedAssReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "StuffedPussyOrAssReallyLikes", "StuffedPussyOrAssReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "PregnantReallyLikes", "PregnantReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "StuffedThroatReallyLikes", "StuffedThroatReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "CoveredInCumReallyLikes", "CoveredInCumReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "CoveredInLotsOfCumReallyLikes", "CoveredInLotsOfCumReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "FullyNakedReallyLikes", "FullyNakedReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ExposedPussyReallyLikes", "ExposedPussyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ExposedAnusReallyLikes", "ExposedAnusReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ExposedBreastsReallyLikes", "ExposedBreastsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ExposedCockReallyLikes", "ExposedCockReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ExposedPantiesReallyLikes", "ExposedPantiesReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ExposedBraReallyLikes", "ExposedBraReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "LooseAnusReallyLikes", "LooseAnusReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "LoosePussyReallyLikes", "LoosePussyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "TightAnusReallyLikes", "TightAnusReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "TightPussyReallyLikes", "TightPussyReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "TallyMarksReallyLikes", "TallyMarksReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "BodywritingsReallyLikes", "BodywritingsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "GagsReallyLikes", "GagsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "BlindfoldsReallyLikes", "BlindfoldsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "BDSMRestraintsReallyLikes", "BDSMRestraintsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "ButtPlugsReallyLikes", "ButtPlugsReallyLikes", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - ReallyLikes", "VaginalPlugsReallyLikes", "VaginalPlugsReallyLikes", "", 1.0)

	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "FeminineBodyLoves", "FeminineBodyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "MasculineBodyLoves", "MasculineBodyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "AndroBodyLoves", "AndroBodyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ThickBodyLoves", "ThickBodyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "SlimBodyLoves", "SlimBodyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "AverageMassBodyLoves", "AverageMassBodyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ThickButtLoves", "ThickButtLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "AverageButtLoves", "AverageButtLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "SlimButtLoves", "SlimButtLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "BigBreastsLoves", "BigBreastsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "SmallBreastsLoves", "SmallBreastsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "MediumBreastsLoves", "MediumBreastsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "NoBreastsLoves", "NoBreastsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "LactatingBreastsLoves", "LactatingBreastsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "NoVaginaLoves", "NoVaginaLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "HasVaginaOnlyLoves", "HasVaginaOnlyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "HasVaginaAndCockLoves", "HasVaginaAndCockLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "BigCockLoves", "BigCockLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "AverageCockLoves", "AverageCockLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "SmallCockLoves", "SmallCockLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "NoCockLoves", "NoCockLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "HasCockOnlyLoves", "HasCockOnlyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "StuffedPussyLoves", "StuffedPussyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "StuffedAssLoves", "StuffedAssLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "StuffedPussyOrAssLoves", "StuffedPussyOrAssLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "PregnantLoves", "PregnantLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "StuffedThroatLoves", "StuffedThroatLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "CoveredInCumLoves", "CoveredInCumLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "CoveredInLotsOfCumLoves", "CoveredInLotsOfCumLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "FullyNakedLoves", "FullyNakedLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ExposedPussyLoves", "ExposedPussyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ExposedAnusLoves", "ExposedAnusLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ExposedBreastsLoves", "ExposedBreastsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ExposedCockLoves", "ExposedCockLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ExposedPantiesLoves", "ExposedPantiesLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ExposedBraLoves", "ExposedBraLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "LooseAnusLoves", "LooseAnusLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "LoosePussyLoves", "LoosePussyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "TightAnusLoves", "TightAnusLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "TightPussyLoves", "TightPussyLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "TallyMarksLoves", "TallyMarksLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "BodywritingsLoves", "BodywritingsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "GagsLoves", "GagsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "BlindfoldsLoves", "BlindfoldsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "BDSMRestraintsLoves", "BDSMRestraintsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "ButtPlugsLoves", "ButtPlugsLoves", "", 1.0)
	self.addFloatOptionInCategory(foxModuleAPI, "NPC Generation Settings - Lust Topics - Loves", "VaginalPlugsLoves", "VaginalPlugsLoves", "", 1.0)

func PersonalityLevels():
	return {
		"Brat":[
			BratMin, BratMax
		],
		"Mean":[
			MeanMin, MeanMax
		],
		"Subby":[
			SubbyMin, SubbyMax
		],
		"Impatient":[
			ImpatientMin, ImpatientMax
		],
		"Naive":[
			NaiveMin, NaiveMax
		],
		"Coward":[
			CowardMin, CowardMax
		],
	}

func FetishValues():
	return {
		"VaginalSexGiving":[
			VaginalSexGivingMin, VaginalSexGivingMax
		],
		"VaginalSexReceiving":[
			VaginalSexReceivingMin, VaginalSexReceivingMax
		],
		"AnalSexGiving":[
			AnalSexGivingMin, AnalSexGivingMax
		],
		"AnalSexReceiving":[
			AnalSexReceivingMin, AnalSexReceivingMax
		],
		"OralSexGiving":[
			OralSexGivingMin, OralSexGivingMax
		],
		"OralSexReceiving":[
			OralSexReceivingMin, OralSexReceivingMax
		],
		"Tribadism":[
			TribadismMin, TribadismMax
		],
		"StraponSexVaginal":[
			StraponSexVaginalMin, StraponSexVaginalMax
		],
		"StraponSexAnal":[
			StraponSexAnalMin, StraponSexAnalMax
		],
		"Bodywritings":[
			BodywritingsMin, BodywritingsMax
		],
		"Masochism":[
			MasochismMin, MasochismMax
		],
		"Sadism":[
			SadismMin, SadismMax
		],
		"Choking":[
			ChokingMin, ChokingMax
		],
		"UnconsciousSex":[
			UnconsciousSexMin, UnconsciousSexMax
		],
		"DrugUse":[
			DrugUseMin, DrugUseMax
		],
		"Breeding":[
			BreedingMin, BreedingMax
		],
		"BeingBred":[
			BeingBredMin, BeingBredMax
		],
		"Condoms":[
			CondomsMin, CondomsMax
		],
		"Lactation":[
			LactationMin, LactationMax
		],
		"SeedMilking":[
			SeedMilkingMin, SeedMilkingMax
		],
		"Exhibitionism":[
			ExhibitionismMin, ExhibitionismMax
		],
		"Bondage":[
			BondageMin, BondageMax
		],
		"Rigging":[
			RiggingMin, RiggingMax
		],
		"RimmingGiving":[
			RimmingGivingMin, RimmingGivingMax
		],
		"RimmingReceiving":[
			RimmingReceivingMin, RimmingReceivingMax
		],
		"FeetplayGiving":[
			FeetplayGivingMin, FeetplayGivingMax
		],
		"FeetplayReceiving":[
			FeetplayReceivingMin, FeetplayReceivingMax
		],
		"HypnosisHypnotist":[
			HypnosisHypnotistMin, HypnosisHypnotistMax
		],
		"HypnosisSubject":[
			HypnosisSubjectMin, HypnosisSubjectMax
		],
		"TFGiving":[
			TFGivingMin, TFGivingMax
		],
		"TFReceiving":[
			TFReceivingMin, TFReceivingMax
		],
	}

func LustTopicsWeightedPairs():
	return {
		"FeminineBody":[
			[Interest.Hates, FeminineBodyHates],
			[Interest.ReallyDislikes, FeminineBodyReallyDislikes],
			[Interest.Dislikes, FeminineBodyDislikes],
			[Interest.SlightlyDislikes, FeminineBodySlightlyDislikes],
			[Interest.Neutral, FeminineBodyNeutral],
			[Interest.KindaLikes, FeminineBodyKindaLikes],
			[Interest.Likes, FeminineBodyLikes],
			[Interest.ReallyLikes, FeminineBodyReallyLikes],
			[Interest.Loves, FeminineBodyLoves],
		],
		"MasculineBody":[
			[Interest.Hates, MasculineBodyHates],
			[Interest.ReallyDislikes, MasculineBodyReallyDislikes],
			[Interest.Dislikes, MasculineBodyDislikes],
			[Interest.SlightlyDislikes, MasculineBodySlightlyDislikes],
			[Interest.Neutral, MasculineBodyNeutral],
			[Interest.KindaLikes, MasculineBodyKindaLikes],
			[Interest.Likes, MasculineBodyLikes],
			[Interest.ReallyLikes, MasculineBodyReallyLikes],
			[Interest.Loves, MasculineBodyLoves],
		],
		"AndroBody":[
			[Interest.Hates, AndroBodyHates],
			[Interest.ReallyDislikes, AndroBodyReallyDislikes],
			[Interest.Dislikes, AndroBodyDislikes],
			[Interest.SlightlyDislikes, AndroBodySlightlyDislikes],
			[Interest.Neutral, AndroBodyNeutral],
			[Interest.KindaLikes, AndroBodyKindaLikes],
			[Interest.Likes, AndroBodyLikes],
			[Interest.ReallyLikes, AndroBodyReallyLikes],
			[Interest.Loves, AndroBodyLoves],
		],
		"ThickBody":[
			[Interest.Hates, ThickBodyHates],
			[Interest.ReallyDislikes, ThickBodyReallyDislikes],
			[Interest.Dislikes, ThickBodyDislikes],
			[Interest.SlightlyDislikes, ThickBodySlightlyDislikes],
			[Interest.Neutral, ThickBodyNeutral],
			[Interest.KindaLikes, ThickBodyKindaLikes],
			[Interest.Likes, ThickBodyLikes],
			[Interest.ReallyLikes, ThickBodyReallyLikes],
			[Interest.Loves, ThickBodyLoves],
		],
		"SlimBody":[
			[Interest.Hates, SlimBodyHates],
			[Interest.ReallyDislikes, SlimBodyReallyDislikes],
			[Interest.Dislikes, SlimBodyDislikes],
			[Interest.SlightlyDislikes, SlimBodySlightlyDislikes],
			[Interest.Neutral, SlimBodyNeutral],
			[Interest.KindaLikes, SlimBodyKindaLikes],
			[Interest.Likes, SlimBodyLikes],
			[Interest.ReallyLikes, SlimBodyReallyLikes],
			[Interest.Loves, SlimBodyLoves],
		],
		"AverageMassBody":[
			[Interest.Hates, AverageMassBodyHates],
			[Interest.ReallyDislikes, AverageMassBodyReallyDislikes],
			[Interest.Dislikes, AverageMassBodyDislikes],
			[Interest.SlightlyDislikes, AverageMassBodySlightlyDislikes],
			[Interest.Neutral, AverageMassBodyNeutral],
			[Interest.KindaLikes, AverageMassBodyKindaLikes],
			[Interest.Likes, AverageMassBodyLikes],
			[Interest.ReallyLikes, AverageMassBodyReallyLikes],
			[Interest.Loves, AverageMassBodyLoves],
		],
		"ThickButt":[
			[Interest.Hates, ThickButtHates],
			[Interest.ReallyDislikes, ThickButtReallyDislikes],
			[Interest.Dislikes, ThickButtDislikes],
			[Interest.SlightlyDislikes, ThickButtSlightlyDislikes],
			[Interest.Neutral, ThickButtNeutral],
			[Interest.KindaLikes, ThickButtKindaLikes],
			[Interest.Likes, ThickButtLikes],
			[Interest.ReallyLikes, ThickButtReallyLikes],
			[Interest.Loves, ThickButtLoves],
		],
		"AverageButt":[
			[Interest.Hates, AverageButtHates],
			[Interest.ReallyDislikes, AverageButtReallyDislikes],
			[Interest.Dislikes, AverageButtDislikes],
			[Interest.SlightlyDislikes, AverageButtSlightlyDislikes],
			[Interest.Neutral, AverageButtNeutral],
			[Interest.KindaLikes, AverageButtKindaLikes],
			[Interest.Likes, AverageButtLikes],
			[Interest.ReallyLikes, AverageButtReallyLikes],
			[Interest.Loves, AverageButtLoves],
		],
		"SlimButt":[
			[Interest.Hates, SlimButtHates],
			[Interest.ReallyDislikes, SlimButtReallyDislikes],
			[Interest.Dislikes, SlimButtDislikes],
			[Interest.SlightlyDislikes, SlimButtSlightlyDislikes],
			[Interest.Neutral, SlimButtNeutral],
			[Interest.KindaLikes, SlimButtKindaLikes],
			[Interest.Likes, SlimButtLikes],
			[Interest.ReallyLikes, SlimButtReallyLikes],
			[Interest.Loves, SlimButtLoves],
		],
		"BigBreasts":[
			[Interest.Hates, BigBreastsHates],
			[Interest.ReallyDislikes, BigBreastsReallyDislikes],
			[Interest.Dislikes, BigBreastsDislikes],
			[Interest.SlightlyDislikes, BigBreastsSlightlyDislikes],
			[Interest.Neutral, BigBreastsNeutral],
			[Interest.KindaLikes, BigBreastsKindaLikes],
			[Interest.Likes, BigBreastsLikes],
			[Interest.ReallyLikes, BigBreastsReallyLikes],
			[Interest.Loves, BigBreastsLoves],
		],
		"SmallBreasts":[
			[Interest.Hates, SmallBreastsHates],
			[Interest.ReallyDislikes, SmallBreastsReallyDislikes],
			[Interest.Dislikes, SmallBreastsDislikes],
			[Interest.SlightlyDislikes, SmallBreastsSlightlyDislikes],
			[Interest.Neutral, SmallBreastsNeutral],
			[Interest.KindaLikes, SmallBreastsKindaLikes],
			[Interest.Likes, SmallBreastsLikes],
			[Interest.ReallyLikes, SmallBreastsReallyLikes],
			[Interest.Loves, SmallBreastsLoves],
		],
		"MediumBreasts":[
			[Interest.Hates, MediumBreastsHates],
			[Interest.ReallyDislikes, MediumBreastsReallyDislikes],
			[Interest.Dislikes, MediumBreastsDislikes],
			[Interest.SlightlyDislikes, MediumBreastsSlightlyDislikes],
			[Interest.Neutral, MediumBreastsNeutral],
			[Interest.KindaLikes, MediumBreastsKindaLikes],
			[Interest.Likes, MediumBreastsLikes],
			[Interest.ReallyLikes, MediumBreastsReallyLikes],
			[Interest.Loves, MediumBreastsLoves],
		],
		"NoBreasts":[
			[Interest.Hates, NoBreastsHates],
			[Interest.ReallyDislikes, NoBreastsReallyDislikes],
			[Interest.Dislikes, NoBreastsDislikes],
			[Interest.SlightlyDislikes, NoBreastsSlightlyDislikes],
			[Interest.Neutral, NoBreastsNeutral],
			[Interest.KindaLikes, NoBreastsKindaLikes],
			[Interest.Likes, NoBreastsLikes],
			[Interest.ReallyLikes, NoBreastsReallyLikes],
			[Interest.Loves, NoBreastsLoves],
		],
		"LactatingBreasts":[
			[Interest.Hates, LactatingBreastsHates],
			[Interest.ReallyDislikes, LactatingBreastsReallyDislikes],
			[Interest.Dislikes, LactatingBreastsDislikes],
			[Interest.SlightlyDislikes, LactatingBreastsSlightlyDislikes],
			[Interest.Neutral, LactatingBreastsNeutral],
			[Interest.KindaLikes, LactatingBreastsKindaLikes],
			[Interest.Likes, LactatingBreastsLikes],
			[Interest.ReallyLikes, LactatingBreastsReallyLikes],
			[Interest.Loves, LactatingBreastsLoves],
		],
		"NoVagina":[
			[Interest.Hates, NoVaginaHates],
			[Interest.ReallyDislikes, NoVaginaReallyDislikes],
			[Interest.Dislikes, NoVaginaDislikes],
			[Interest.SlightlyDislikes, NoVaginaSlightlyDislikes],
			[Interest.Neutral, NoVaginaNeutral],
			[Interest.KindaLikes, NoVaginaKindaLikes],
			[Interest.Likes, NoVaginaLikes],
			[Interest.ReallyLikes, NoVaginaReallyLikes],
			[Interest.Loves, NoVaginaLoves],
		],
		"HasVaginaOnly":[
			[Interest.Hates, HasVaginaOnlyHates],
			[Interest.ReallyDislikes, HasVaginaOnlyReallyDislikes],
			[Interest.Dislikes, HasVaginaOnlyDislikes],
			[Interest.SlightlyDislikes, HasVaginaOnlySlightlyDislikes],
			[Interest.Neutral, HasVaginaOnlyNeutral],
			[Interest.KindaLikes, HasVaginaOnlyKindaLikes],
			[Interest.Likes, HasVaginaOnlyLikes],
			[Interest.ReallyLikes, HasVaginaOnlyReallyLikes],
			[Interest.Loves, HasVaginaOnlyLoves],
		],
		"HasVaginaAndCock":[
			[Interest.Hates, HasVaginaAndCockHates],
			[Interest.ReallyDislikes, HasVaginaAndCockReallyDislikes],
			[Interest.Dislikes, HasVaginaAndCockDislikes],
			[Interest.SlightlyDislikes, HasVaginaAndCockSlightlyDislikes],
			[Interest.Neutral, HasVaginaAndCockNeutral],
			[Interest.KindaLikes, HasVaginaAndCockKindaLikes],
			[Interest.Likes, HasVaginaAndCockLikes],
			[Interest.ReallyLikes, HasVaginaAndCockReallyLikes],
			[Interest.Loves, HasVaginaAndCockLoves],
		],
		"BigCock":[
			[Interest.Hates, BigCockHates],
			[Interest.ReallyDislikes, BigCockReallyDislikes],
			[Interest.Dislikes, BigCockDislikes],
			[Interest.SlightlyDislikes, BigCockSlightlyDislikes],
			[Interest.Neutral, BigCockNeutral],
			[Interest.KindaLikes, BigCockKindaLikes],
			[Interest.Likes, BigCockLikes],
			[Interest.ReallyLikes, BigCockReallyLikes],
			[Interest.Loves, BigCockLoves],
		],
		"AverageCock":[
			[Interest.Hates, AverageCockHates],
			[Interest.ReallyDislikes, AverageCockReallyDislikes],
			[Interest.Dislikes, AverageCockDislikes],
			[Interest.SlightlyDislikes, AverageCockSlightlyDislikes],
			[Interest.Neutral, AverageCockNeutral],
			[Interest.KindaLikes, AverageCockKindaLikes],
			[Interest.Likes, AverageCockLikes],
			[Interest.ReallyLikes, AverageCockReallyLikes],
			[Interest.Loves, AverageCockLoves],
		],
		"SmallCock":[
			[Interest.Hates, SmallCockHates],
			[Interest.ReallyDislikes, SmallCockReallyDislikes],
			[Interest.Dislikes, SmallCockDislikes],
			[Interest.SlightlyDislikes, SmallCockSlightlyDislikes],
			[Interest.Neutral, SmallCockNeutral],
			[Interest.KindaLikes, SmallCockKindaLikes],
			[Interest.Likes, SmallCockLikes],
			[Interest.ReallyLikes, SmallCockReallyLikes],
			[Interest.Loves, SmallCockLoves],
		],
		"NoCock":[
			[Interest.Hates, NoCockHates],
			[Interest.ReallyDislikes, NoCockReallyDislikes],
			[Interest.Dislikes, NoCockDislikes],
			[Interest.SlightlyDislikes, NoCockSlightlyDislikes],
			[Interest.Neutral, NoCockNeutral],
			[Interest.KindaLikes, NoCockKindaLikes],
			[Interest.Likes, NoCockLikes],
			[Interest.ReallyLikes, NoCockReallyLikes],
			[Interest.Loves, NoCockLoves],
		],
		"HasCockOnly":[
			[Interest.Hates, HasCockOnlyHates],
			[Interest.ReallyDislikes, HasCockOnlyReallyDislikes],
			[Interest.Dislikes, HasCockOnlyDislikes],
			[Interest.SlightlyDislikes, HasCockOnlySlightlyDislikes],
			[Interest.Neutral, HasCockOnlyNeutral],
			[Interest.KindaLikes, HasCockOnlyKindaLikes],
			[Interest.Likes, HasCockOnlyLikes],
			[Interest.ReallyLikes, HasCockOnlyReallyLikes],
			[Interest.Loves, HasCockOnlyLoves],
		],
		"StuffedPussy":[
			[Interest.Hates, StuffedPussyHates],
			[Interest.ReallyDislikes, StuffedPussyReallyDislikes],
			[Interest.Dislikes, StuffedPussyDislikes],
			[Interest.SlightlyDislikes, StuffedPussySlightlyDislikes],
			[Interest.Neutral, StuffedPussyNeutral],
			[Interest.KindaLikes, StuffedPussyKindaLikes],
			[Interest.Likes, StuffedPussyLikes],
			[Interest.ReallyLikes, StuffedPussyReallyLikes],
			[Interest.Loves, StuffedPussyLoves],
		],
		"StuffedAss":[
			[Interest.Hates, StuffedAssHates],
			[Interest.ReallyDislikes, StuffedAssReallyDislikes],
			[Interest.Dislikes, StuffedAssDislikes],
			[Interest.SlightlyDislikes, StuffedAssSlightlyDislikes],
			[Interest.Neutral, StuffedAssNeutral],
			[Interest.KindaLikes, StuffedAssKindaLikes],
			[Interest.Likes, StuffedAssLikes],
			[Interest.ReallyLikes, StuffedAssReallyLikes],
			[Interest.Loves, StuffedAssLoves],
		],
		"StuffedPussyOrAss":[
			[Interest.Hates, StuffedPussyOrAssHates],
			[Interest.ReallyDislikes, StuffedPussyOrAssReallyDislikes],
			[Interest.Dislikes, StuffedPussyOrAssDislikes],
			[Interest.SlightlyDislikes, StuffedPussyOrAssSlightlyDislikes],
			[Interest.Neutral, StuffedPussyOrAssNeutral],
			[Interest.KindaLikes, StuffedPussyOrAssKindaLikes],
			[Interest.Likes, StuffedPussyOrAssLikes],
			[Interest.ReallyLikes, StuffedPussyOrAssReallyLikes],
			[Interest.Loves, StuffedPussyOrAssLoves],
		],
		"Pregnant":[
			[Interest.Hates, PregnantHates],
			[Interest.ReallyDislikes, PregnantReallyDislikes],
			[Interest.Dislikes, PregnantDislikes],
			[Interest.SlightlyDislikes, PregnantSlightlyDislikes],
			[Interest.Neutral, PregnantNeutral],
			[Interest.KindaLikes, PregnantKindaLikes],
			[Interest.Likes, PregnantLikes],
			[Interest.ReallyLikes, PregnantReallyLikes],
			[Interest.Loves, PregnantLoves],
		],
		"StuffedThroat":[
			[Interest.Hates, StuffedThroatHates],
			[Interest.ReallyDislikes, StuffedThroatReallyDislikes],
			[Interest.Dislikes, StuffedThroatDislikes],
			[Interest.SlightlyDislikes, StuffedThroatSlightlyDislikes],
			[Interest.Neutral, StuffedThroatNeutral],
			[Interest.KindaLikes, StuffedThroatKindaLikes],
			[Interest.Likes, StuffedThroatLikes],
			[Interest.ReallyLikes, StuffedThroatReallyLikes],
			[Interest.Loves, StuffedThroatLoves],
		],
		"CoveredInCum":[
			[Interest.Hates, CoveredInCumHates],
			[Interest.ReallyDislikes, CoveredInCumReallyDislikes],
			[Interest.Dislikes, CoveredInCumDislikes],
			[Interest.SlightlyDislikes, CoveredInCumSlightlyDislikes],
			[Interest.Neutral, CoveredInCumNeutral],
			[Interest.KindaLikes, CoveredInCumKindaLikes],
			[Interest.Likes, CoveredInCumLikes],
			[Interest.ReallyLikes, CoveredInCumReallyLikes],
			[Interest.Loves, CoveredInCumLoves],
		],
		"CoveredInLotsOfCum":[
			[Interest.Hates, CoveredInLotsOfCumHates],
			[Interest.ReallyDislikes, CoveredInLotsOfCumReallyDislikes],
			[Interest.Dislikes, CoveredInLotsOfCumDislikes],
			[Interest.SlightlyDislikes, CoveredInLotsOfCumSlightlyDislikes],
			[Interest.Neutral, CoveredInLotsOfCumNeutral],
			[Interest.KindaLikes, CoveredInLotsOfCumKindaLikes],
			[Interest.Likes, CoveredInLotsOfCumLikes],
			[Interest.ReallyLikes, CoveredInLotsOfCumReallyLikes],
			[Interest.Loves, CoveredInLotsOfCumLoves],
		],
		"FullyNaked":[
			[Interest.Hates, FullyNakedHates],
			[Interest.ReallyDislikes, FullyNakedReallyDislikes],
			[Interest.Dislikes, FullyNakedDislikes],
			[Interest.SlightlyDislikes, FullyNakedSlightlyDislikes],
			[Interest.Neutral, FullyNakedNeutral],
			[Interest.KindaLikes, FullyNakedKindaLikes],
			[Interest.Likes, FullyNakedLikes],
			[Interest.ReallyLikes, FullyNakedReallyLikes],
			[Interest.Loves, FullyNakedLoves],
		],
		"ExposedPussy":[
			[Interest.Hates, ExposedPussyHates],
			[Interest.ReallyDislikes, ExposedPussyReallyDislikes],
			[Interest.Dislikes, ExposedPussyDislikes],
			[Interest.SlightlyDislikes, ExposedPussySlightlyDislikes],
			[Interest.Neutral, ExposedPussyNeutral],
			[Interest.KindaLikes, ExposedPussyKindaLikes],
			[Interest.Likes, ExposedPussyLikes],
			[Interest.ReallyLikes, ExposedPussyReallyLikes],
			[Interest.Loves, ExposedPussyLoves],
		],
		"ExposedAnus":[
			[Interest.Hates, ExposedAnusHates],
			[Interest.ReallyDislikes, ExposedAnusReallyDislikes],
			[Interest.Dislikes, ExposedAnusDislikes],
			[Interest.SlightlyDislikes, ExposedAnusSlightlyDislikes],
			[Interest.Neutral, ExposedAnusNeutral],
			[Interest.KindaLikes, ExposedAnusKindaLikes],
			[Interest.Likes, ExposedAnusLikes],
			[Interest.ReallyLikes, ExposedAnusReallyLikes],
			[Interest.Loves, ExposedAnusLoves],
		],
		"ExposedBreasts":[
			[Interest.Hates, ExposedBreastsHates],
			[Interest.ReallyDislikes, ExposedBreastsReallyDislikes],
			[Interest.Dislikes, ExposedBreastsDislikes],
			[Interest.SlightlyDislikes, ExposedBreastsSlightlyDislikes],
			[Interest.Neutral, ExposedBreastsNeutral],
			[Interest.KindaLikes, ExposedBreastsKindaLikes],
			[Interest.Likes, ExposedBreastsLikes],
			[Interest.ReallyLikes, ExposedBreastsReallyLikes],
			[Interest.Loves, ExposedBreastsLoves],
		],
		"ExposedCock":[
			[Interest.Hates, ExposedCockHates],
			[Interest.ReallyDislikes, ExposedCockReallyDislikes],
			[Interest.Dislikes, ExposedCockDislikes],
			[Interest.SlightlyDislikes, ExposedCockSlightlyDislikes],
			[Interest.Neutral, ExposedCockNeutral],
			[Interest.KindaLikes, ExposedCockKindaLikes],
			[Interest.Likes, ExposedCockLikes],
			[Interest.ReallyLikes, ExposedCockReallyLikes],
			[Interest.Loves, ExposedCockLoves],
		],
		"ExposedPanties":[
			[Interest.Hates, ExposedPantiesHates],
			[Interest.ReallyDislikes, ExposedPantiesReallyDislikes],
			[Interest.Dislikes, ExposedPantiesDislikes],
			[Interest.SlightlyDislikes, ExposedPantiesSlightlyDislikes],
			[Interest.Neutral, ExposedPantiesNeutral],
			[Interest.KindaLikes, ExposedPantiesKindaLikes],
			[Interest.Likes, ExposedPantiesLikes],
			[Interest.ReallyLikes, ExposedPantiesReallyLikes],
			[Interest.Loves, ExposedPantiesLoves],
		],
		"ExposedBra":[
			[Interest.Hates, ExposedBraHates],
			[Interest.ReallyDislikes, ExposedBraReallyDislikes],
			[Interest.Dislikes, ExposedBraDislikes],
			[Interest.SlightlyDislikes, ExposedBraSlightlyDislikes],
			[Interest.Neutral, ExposedBraNeutral],
			[Interest.KindaLikes, ExposedBraKindaLikes],
			[Interest.Likes, ExposedBraLikes],
			[Interest.ReallyLikes, ExposedBraReallyLikes],
			[Interest.Loves, ExposedBraLoves],
		],
		"LooseAnus":[
			[Interest.Hates, LooseAnusHates],
			[Interest.ReallyDislikes, LooseAnusReallyDislikes],
			[Interest.Dislikes, LooseAnusDislikes],
			[Interest.SlightlyDislikes, LooseAnusSlightlyDislikes],
			[Interest.Neutral, LooseAnusNeutral],
			[Interest.KindaLikes, LooseAnusKindaLikes],
			[Interest.Likes, LooseAnusLikes],
			[Interest.ReallyLikes, LooseAnusReallyLikes],
			[Interest.Loves, LooseAnusLoves],
		],
		"LoosePussy":[
			[Interest.Hates, LoosePussyHates],
			[Interest.ReallyDislikes, LoosePussyReallyDislikes],
			[Interest.Dislikes, LoosePussyDislikes],
			[Interest.SlightlyDislikes, LoosePussySlightlyDislikes],
			[Interest.Neutral, LoosePussyNeutral],
			[Interest.KindaLikes, LoosePussyKindaLikes],
			[Interest.Likes, LoosePussyLikes],
			[Interest.ReallyLikes, LoosePussyReallyLikes],
			[Interest.Loves, LoosePussyLoves],
		],
		"TightAnus":[
			[Interest.Hates, TightAnusHates],
			[Interest.ReallyDislikes, TightAnusReallyDislikes],
			[Interest.Dislikes, TightAnusDislikes],
			[Interest.SlightlyDislikes, TightAnusSlightlyDislikes],
			[Interest.Neutral, TightAnusNeutral],
			[Interest.KindaLikes, TightAnusKindaLikes],
			[Interest.Likes, TightAnusLikes],
			[Interest.ReallyLikes, TightAnusReallyLikes],
			[Interest.Loves, TightAnusLoves],
		],
		"TightPussy":[
			[Interest.Hates, TightPussyHates],
			[Interest.ReallyDislikes, TightPussyReallyDislikes],
			[Interest.Dislikes, TightPussyDislikes],
			[Interest.SlightlyDislikes, TightPussySlightlyDislikes],
			[Interest.Neutral, TightPussyNeutral],
			[Interest.KindaLikes, TightPussyKindaLikes],
			[Interest.Likes, TightPussyLikes],
			[Interest.ReallyLikes, TightPussyReallyLikes],
			[Interest.Loves, TightPussyLoves],
		],
		"TallyMarks":[
			[Interest.Hates, TallyMarksHates],
			[Interest.ReallyDislikes, TallyMarksReallyDislikes],
			[Interest.Dislikes, TallyMarksDislikes],
			[Interest.SlightlyDislikes, TallyMarksSlightlyDislikes],
			[Interest.Neutral, TallyMarksNeutral],
			[Interest.KindaLikes, TallyMarksKindaLikes],
			[Interest.Likes, TallyMarksLikes],
			[Interest.ReallyLikes, TallyMarksReallyLikes],
			[Interest.Loves, TallyMarksLoves],
		],
		"Bodywritings":[
			[Interest.Hates, BodywritingsHates],
			[Interest.ReallyDislikes, BodywritingsReallyDislikes],
			[Interest.Dislikes, BodywritingsDislikes],
			[Interest.SlightlyDislikes, BodywritingsSlightlyDislikes],
			[Interest.Neutral, BodywritingsNeutral],
			[Interest.KindaLikes, BodywritingsKindaLikes],
			[Interest.Likes, BodywritingsLikes],
			[Interest.ReallyLikes, BodywritingsReallyLikes],
			[Interest.Loves, BodywritingsLoves],
		],
		"Gags":[
			[Interest.Hates, GagsHates],
			[Interest.ReallyDislikes, GagsReallyDislikes],
			[Interest.Dislikes, GagsDislikes],
			[Interest.SlightlyDislikes, GagsSlightlyDislikes],
			[Interest.Neutral, GagsNeutral],
			[Interest.KindaLikes, GagsKindaLikes],
			[Interest.Likes, GagsLikes],
			[Interest.ReallyLikes, GagsReallyLikes],
			[Interest.Loves, GagsLoves],
		],
		"Blindfolds":[
			[Interest.Hates, BlindfoldsHates],
			[Interest.ReallyDislikes, BlindfoldsReallyDislikes],
			[Interest.Dislikes, BlindfoldsDislikes],
			[Interest.SlightlyDislikes, BlindfoldsSlightlyDislikes],
			[Interest.Neutral, BlindfoldsNeutral],
			[Interest.KindaLikes, BlindfoldsKindaLikes],
			[Interest.Likes, BlindfoldsLikes],
			[Interest.ReallyLikes, BlindfoldsReallyLikes],
			[Interest.Loves, BlindfoldsLoves],
		],
		"BDSMRestraints":[
			[Interest.Hates, BDSMRestraintsHates],
			[Interest.ReallyDislikes, BDSMRestraintsReallyDislikes],
			[Interest.Dislikes, BDSMRestraintsDislikes],
			[Interest.SlightlyDislikes, BDSMRestraintsSlightlyDislikes],
			[Interest.Neutral, BDSMRestraintsNeutral],
			[Interest.KindaLikes, BDSMRestraintsKindaLikes],
			[Interest.Likes, BDSMRestraintsLikes],
			[Interest.ReallyLikes, BDSMRestraintsReallyLikes],
			[Interest.Loves, BDSMRestraintsLoves],
		],
		"ButtPlugs":[
			[Interest.Hates, ButtPlugsHates],
			[Interest.ReallyDislikes, ButtPlugsReallyDislikes],
			[Interest.Dislikes, ButtPlugsDislikes],
			[Interest.SlightlyDislikes, ButtPlugsSlightlyDislikes],
			[Interest.Neutral, ButtPlugsNeutral],
			[Interest.KindaLikes, ButtPlugsKindaLikes],
			[Interest.Likes, ButtPlugsLikes],
			[Interest.ReallyLikes, ButtPlugsReallyLikes],
			[Interest.Loves, ButtPlugsLoves],
		],
		"VaginalPlugs":[
			[Interest.Hates, VaginalPlugsHates],
			[Interest.ReallyDislikes, VaginalPlugsReallyDislikes],
			[Interest.Dislikes, VaginalPlugsDislikes],
			[Interest.SlightlyDislikes, VaginalPlugsSlightlyDislikes],
			[Interest.Neutral, VaginalPlugsNeutral],
			[Interest.KindaLikes, VaginalPlugsKindaLikes],
			[Interest.Likes, VaginalPlugsLikes],
			[Interest.ReallyLikes, VaginalPlugsReallyLikes],
			[Interest.Loves, VaginalPlugsLoves],
		],
	}
