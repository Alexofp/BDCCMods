extends Reference
class_name ModdedCharacterGeneratorBase

static func pickBodyAttributes(character:DynamicCharacter, _args = {}):
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.BodyAttributesEnable:
			settingCheck = true
	
	if settingCheck:
		if(character.getGender() == Gender.Male):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.MaleThicknessMin, 
				npcGenSettingsModule.MaleThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.MaleFeminityMin, 
				npcGenSettingsModule.MaleFeminityMax)
		if(character.getGender() == Gender.Female):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.FemaleThicknessMin, 
				npcGenSettingsModule.FemaleThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.FemaleFeminityMin, 
				npcGenSettingsModule.FemaleFeminityMax)
		if(character.getGender() == Gender.Androgynous):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.AndrogynousThicknessMin, 
				npcGenSettingsModule.AndrogynousThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.AndrogynousFeminityMin, 
				npcGenSettingsModule.AndrogynousFeminityMax)
		if(character.getGender() == Gender.Other):
			character.npcThickness = RNG.randi_range(
				npcGenSettingsModule.OtherThicknessMin, 
				npcGenSettingsModule.OtherThicknessMax)
			character.npcFeminity = RNG.randi_range(
				npcGenSettingsModule.OtherFeminityMin, 
				npcGenSettingsModule.OtherFeminityMax)
	else:
		if(character.getGender() == Gender.Male):
			character.npcThickness = RNG.randi_range(0, 60)
			character.npcFeminity = RNG.randi_range(0, 50)
		if(character.getGender() == Gender.Female):
			character.npcThickness = RNG.randi_range(0, 110)
			character.npcFeminity = RNG.randi_range(50, 100)
		if(character.getGender() == Gender.Androgynous):
			character.npcThickness = RNG.randi_range(0, 100)
			character.npcFeminity = RNG.randi_range(25, 75)
		if(character.getGender() == Gender.Other):
			character.npcThickness = RNG.randi_range(0, 100)
			character.npcFeminity = RNG.randi_range(0, 100)

static func pickFetishes(character:DynamicCharacter, _args = {}):
	var fetishHolder = character.getFetishHolder()
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	
	fetishHolder.clear()
	
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.FetishesEnable:
			settingCheck = true
	
	if settingCheck:
		var values = npcGenSettingsModule.FetishValues()
		for fetishID in values:
			print(fetishID + " : " + fetishID[0] + " , " + fetishID[1])
			fetishHolder.setFetish(fetishID, RNG.randf_range(fetishID[0], fetishID[1]))
	else:
		for fetishID in GlobalRegistry.getFetishes():
			if(RNG.chance(50)):
				fetishHolder.setFetish(fetishID, RNG.pick([FetishInterest.Dislikes, FetishInterest.SlightlyDislikes, FetishInterest.SlightlyLikes]))
			elif(RNG.chance(5)):
				fetishHolder.setFetish(fetishID, RNG.pick([FetishInterest.Hates, FetishInterest.Loves]))
			else:
				fetishHolder.setFetish(fetishID, FetishInterest.Neutral)
	
	settingCheck = true
	if (npcGenSettingsModule != null):
		if !npcGenSettingsModule.ArchetypesEnable:
			settingCheck = false
	
	if settingCheck:
		for archetype in character.npcArchetypes:
			var fetishes = CharacterArchetype.getFetishes(archetype)
			for fetishID in fetishes:
				var addValue:float = fetishes[fetishID]
				if(addValue > 0.0):
					fetishHolder.addFetish(fetishID, RNG.randf_range(0.0, addValue))
				elif(addValue < 0.0):
					fetishHolder.addFetish(fetishID, -RNG.randf_range(0.0, -addValue))

	fetishHolder.removeImpossibleFetishes()

static func pickLustInterests(character:DynamicCharacter, _args = {}):
	var interestWeights = [
		[Interest.Hates, 0.5],
		[Interest.ReallyDislikes, 0.6],
		[Interest.Dislikes, 0.7],
		[Interest.SlightlyDislikes, 0.6],
		[Interest.KindaLikes, 1.0],
		[Interest.Likes, 1.0],
		[Interest.ReallyLikes, 1.0],
		[Interest.Loves, 1.0],
	]
	
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.LustTopicsEnable:
			settingCheck = true
	
	if settingCheck:
		var weights = npcGenSettingsModule.LustTopicsWeightedPairs()
		for topic in weights:
			var pickedInterest = RNG.pickWeightedPairs(weights[topic])
			if(pickedInterest != Interest.Neutral):
				character.getLustInterests().addInterest(topic, pickedInterest)
	else:
		for topicA in GlobalRegistry.getLustTopicObjects():
			var topic: TopicBase = topicA
			var handlesIDs = topic.handles_ids
			for id in handlesIDs:
				var pickedInterest = RNG.pickWeightedPairs(interestWeights)
				
				if(pickedInterest != Interest.Neutral):
					character.getLustInterests().addInterest(id, pickedInterest)

static func pickPersonality(character:DynamicCharacter, _args = {}):
	var npcGenSettingsModule = GlobalRegistry.getModules().get("NpcGenSettingsModule")
	var personality = character.getPersonality()
	var settingCheck = false
	if (npcGenSettingsModule != null):
		if npcGenSettingsModule.PersonalitiesEnable:
			settingCheck = true
	
	personality.clear()
	if settingCheck:
		var values = npcGenSettingsModule.PersonalityLevels()
		for statID in values:
			personality.setStat(statID, RNG.randf_range(values[statID][0], values[statID][1]))
			if(RNG.chance(npcGenSettingsModule.PersonalityStrongChance)):
				personality.setStat(statID, RNG.randf_range(values[statID][0], values[statID][1])*npcGenSettingsModule.PersonalityStrongMult)
	else:
		for statID in PersonalityStat.getAll():
			personality.setStat(statID, RNG.randf_range(-0.3, 0.3))
			if(RNG.chance(5)):
				personality.setStat(statID, RNG.randf_range(-0.3, 0.3)*5.0)
	
	settingCheck = true
	if (npcGenSettingsModule != null):
		if !npcGenSettingsModule.ArchetypesEnable:
			settingCheck = false
	
	if settingCheck:
		for archetype in character.npcArchetypes:
			var personalityChanges = CharacterArchetype.getPersonalityChanges(archetype)
			for personalityStat in personalityChanges:
				var howMuchMax = personalityChanges[personalityStat]
				
				if(howMuchMax > 0.0):
					personality.addStat(personalityStat, RNG.randf_range(0.0, howMuchMax))
				elif(howMuchMax < 0.0):
					personality.addStat(personalityStat, -RNG.randf_range(0.0, -howMuchMax))
