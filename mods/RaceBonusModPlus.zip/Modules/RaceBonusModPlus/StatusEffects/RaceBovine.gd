extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceBovine"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("bovine")):
		return true
	return false


func getEffectName():
	return "Bovine Fertility"

func getEffectDesc():
	return "As a bovine, you produce a lot from your body. Especially milk."

func getEffectImage():
	return "res://Images/StatusEffects/womb3.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.FertilityBuff,[100]),
		buff(Buff.PenisCumProductionBuff,[300]),
		buff(Buff.PregnancySpeedBuff,[300]),
		buff(Buff.VirilityBuff,[100]),
		buff(Buff.BreastsMilkProductionBuff,[300]),
		buff(Buff.PenisBallsVolumeBuff,[300]),
		buff(Buff.AmbientLustBuff, [10]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Breasts, 30]),
		buff(Buff.MaxLustBuff, [50]),
		buff(Buff.MaxPainBuff, [-30]),
		buff(Buff.SkillExperienceBuff, [Skill.Breeder, 100.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Fertility, 100.0]),
		buff(Buff.BreastsLactatingSizeLimitBuff, [2]),
	]
