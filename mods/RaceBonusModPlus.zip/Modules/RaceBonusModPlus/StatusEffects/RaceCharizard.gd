extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "Charizard"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["Charizard"]):
	if(_npc.getSpecies().has("Charizard")):
		return true
	return false


func getEffectName():
	return "Flame Lizard"

func getEffectDesc():
	return "A feirce and combat ready Pokerace weak to lust due to not normally being flirted with in any way."

func getEffectImage():
	return "res://Images/StatusEffects/biceps.png"

func getIconColor():
	return IconColorYellow

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[85]),
		buff(Buff.ReceivedLustDamageBuff, [110]),
		buff(Buff.PhysicalArmorBuff,[120]),
		buff(Buff.StatBuff, [Stat.Vitality, 2]),
		buff(Buff.StatBuff, [Stat.Strength, 6]),
	]
