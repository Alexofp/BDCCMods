extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceSnake"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["snake"]):
	if(_npc.getSpecies().has("snake")):
		return true
	return false


func getEffectName():
	return "Slippery Snake"

func getEffectDesc():
	return "Slithering serpents that have little strength, but easily able to dodge attacks sue to inherit dangersense."

func getEffectImage():
	return "res://Images/StatusEffects/dodging.png"

func getIconColor():
	return IconColorBlue

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[-90]),
		buff(Buff.ReceivedLustDamageBuff, [-10]),
		buff(Buff.DodgeChanceBuff, [35.0]),
		buff(Buff.StatBuff, [Stat.Vitality, 2]),
		buff(Buff.StatBuff, [Stat.Agility, 7]),
		buff(Buff.MaxStaminaBuff, [80]),
	]
