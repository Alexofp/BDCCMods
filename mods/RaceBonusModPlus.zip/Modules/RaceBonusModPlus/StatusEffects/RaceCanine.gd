extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceCanine"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("canine")):
		return true
	return false


func getEffectName():
	return "Canine's Instinct"

func getEffectDesc():
	return "As a canine, your unwavering loyalty makes you unable to deny others requests, but your keen sense of smell allow you to track and detect with exceptional precision."

func getEffectImage():
	return "res://Images/StatusEffects/crosshair.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[150]),
		buff(Buff.PhysicalDamageBuff,[30]),
		buff(Buff.ForcedObedienceBuff,[20]),
		buff(Buff.StatBuff, [Stat.Strength, 5]),
		buff(Buff.ForcedObedienceBuff,[20]),
	]
