extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceOrc"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("sugerrorc")):
		return true
	return false


func getEffectName():
	return "Orc Muscle"

func getEffectDesc():
	return "Orcs, an old Earth myth made real. They are muscular and powerful, able to tank hits, but unable to woo others so easily. They favor strength, but are weak to the pleasures of flesh."

func getEffectImage():
	return "res://Images/StatusEffects/recruitment.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 10]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-35.0]),
		buff(Buff.PhysicalDamageBuff,[100]),
		buff(Buff.LustDamageBuff, [-35.0]),
		buff(Buff.ReceivedLustDamageBuff, [250.0]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Vagina, 100]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Penis, 100]),
	]
