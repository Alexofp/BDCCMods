extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceDragon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["dragon"]):
	if(_npc.getSpecies().has("dragon")):
		return true
	return false


func getEffectName():
	return "Dragon's Power"

func getEffectDesc():
	return "As a dragon, you have strong power and body, but you just cannot resist those lustful call..."

func getEffectImage():
	return "res://Images/StatusEffects/biceps.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[100]),
		buff(Buff.ReceivedLustDamageBuff, [130]),
		buff(Buff.PhysicalArmorBuff,[100]),
		buff(Buff.StatBuff, [Stat.Vitality, 6]),
		buff(Buff.StatBuff, [Stat.Strength, 2]),
	]
