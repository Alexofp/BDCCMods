extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceEasternDragon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["easterndragon"]):
	if(_npc.getSpecies().has("easterndragon")):
		return true
	return false


func getEffectName():
	return "Godly Decendant"

func getEffectDesc():
	return "Once believed to grant wishes and be gods. These dragons are Resistant to Lust, but weak to physical"

func getEffectImage():
	return "res://Images/StatusEffects/dodging.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[-30]),
		buff(Buff.ReceivedLustDamageBuff, [-50]),
		buff(Buff.DodgeChanceBuff, [4.0]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.StatBuff, [Stat.Agility, 3]),
	]
