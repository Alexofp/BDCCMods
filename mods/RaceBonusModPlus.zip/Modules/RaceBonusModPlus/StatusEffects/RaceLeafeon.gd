extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceLeafeon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("leafeon")):
		return true
	return false


func getEffectName():
	return "Eevee-Grass"

func getEffectDesc():
	return "An Eevee that had evolved as one with nature. Leafeon are able to handle damage, but can't handle attention. As unmoving as a tree, yet sensitive under all that bark."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Vitality, 10]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-10.0]),
		buff(Buff.LustDamageBuff, [25.0]),
		buff(Buff.ReceivedLustDamageBuff, [-10.0]),
		buff(Buff.OverstimulationThresholdBuff, [170.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Stunned, 75.0]),
		buff(Buff.MaxPainBuff, [65]),
		buff(Buff.MaxLustBuff, [30]),
		buff(Buff.MaxStaminaBuff, [-20]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Vagina, 50]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Breasts, 40]),
	]
