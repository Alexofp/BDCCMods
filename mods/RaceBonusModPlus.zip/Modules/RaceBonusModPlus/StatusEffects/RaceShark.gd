extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceShark"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["shark"]):
	if(_npc.getSpecies().has("shark")):
		return true
	return false


func getEffectName():
	return "Dangerous Teeth"

func getEffectDesc():
	return "Sharks are powerful and slippery. They crush all in their way. Also kind hopeless romantics. Looking scary up front but just wanting love."

func getEffectImage():
	return "res://Images/StatusEffects/open-wound.png"

func getIconColor():
	return IconColorBlue

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[120]),
		buff(Buff.PhysicalArmorBuff,[50]),
		buff(Buff.DodgeChanceBuff, [10.0]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.StatBuff, [Stat.Strength, 5]),
		buff(Buff.ReceivedLustDamageBuff, [250]),
	]
