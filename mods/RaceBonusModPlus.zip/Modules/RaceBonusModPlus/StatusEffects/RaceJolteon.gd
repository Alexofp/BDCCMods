extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceJolteon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("jolteon")):
		return true
	return false


func getEffectName():
	return "Eevee-Electric"

func getEffectDesc():
	return "An Eevee That has evolved into being able to harness eletricity. They can hit hard and fast, having plenty of stamina to just keep attacking relentlessly."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[150]),
		buff(Buff.StatBuff, [Stat.Strength, 1]),
		buff(Buff.StatBuff, [Stat.Agility, 6]),
		buff(Buff.PhysicalDamageBuff,[65]),
		buff(Buff.ReceivedPhysicalDamageBuff, [75.0]),
		buff(Buff.LustDamageBuff, [-75.0]),
		buff(Buff.ReceivedLustDamageBuff, [20.0]),
		buff(Buff.OverstimulationThresholdBuff, [200.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 80.0]),
		buff(Buff.MaxStaminaBuff, [85]),
	]
