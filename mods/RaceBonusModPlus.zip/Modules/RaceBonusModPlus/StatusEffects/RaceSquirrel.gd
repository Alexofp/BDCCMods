extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "treenuts"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("treenuts")):
		return true
	return false


func getEffectName():
	return "Tree Nuts"

func getEffectDesc():
	return "A very nutty race. They can climb trees easily, but unfortunately there are no trees in prision."

func getEffectImage():
	return "res://Images/StatusEffects/butt.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff, [23.0]),
		buff(Buff.StatBuff, [Stat.Agility, 5]),
		buff(Buff.StatBuff, [Stat.Sexiness, 4]),
		buff(Buff.SkillExperienceBuff, [Skill.Exhibitionism, 150.0]),
		buff(Buff.PhysicalDamageBuff, [-50.0]),
		buff(Buff.ReceivedPhysicalDamageBuff, [40.0]),
		buff(Buff.OverstimulationThresholdBuff, [70.0]),
	]
