extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceDemon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["demon"]):
	if(_npc.getSpecies().has("demon")):
		return true
	return false


func getEffectName():
	return "Demon's Attraction"

func getEffectDesc():
	return "As a demon, you are a master in attracting others, Breeding or being breeded easily. However, You are very horny and don't move as much when about to be hit."

func getEffectImage():
	return "res://Images/StatusEffects/nested-hearts2.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.LustDamageBuff,[120]),
		buff(Buff.FinalFertilityModifierBuff, [80]),
		buff(Buff.FinalVirilityModifierBuff, [80]),
		buff(Buff.DodgeChanceBuff, [-35.0]),
		buff(Buff.AmbientLustBuff, [10]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [100]),
		buff(Buff.PregnancySpeedBuff, [100]),
		buff(Buff.OverstimulationThresholdBuff, [400.0]),
	]
