extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "Raichu"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("Raichu")):
		return true
	return false


func getEffectName():
	return "Storm Mouse"

func getEffectDesc():
	return "A powerful Mouse pokerace. Known as the champions of lightning and power. Normally they are defenders."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorYellow

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[135]),
		buff(Buff.StatBuff, [Stat.Strength, 3]),
		buff(Buff.StatBuff, [Stat.Agility, 6]),
		buff(Buff.PhysicalDamageBuff,[65]),
		buff(Buff.ReceivedPhysicalDamageBuff, [75.0]),
		buff(Buff.ReceivedLustDamageBuff, [26.0]),
		buff(Buff.OverstimulationThresholdBuff, [200.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 60.0]),
		buff(Buff.MaxStaminaBuff, [65]),
	]
