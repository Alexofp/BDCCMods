extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceMiddayLycan"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("middaylycan")):
		return true
	return false


func getEffectName():
	return "Day Breaker"

func getEffectDesc():
	return "A rocky caninemon race. They can be violent and very strong."

func getEffectImage():
	return "res://Images/StatusEffects/fangs.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 2]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.PhysicalDamageBuff, [30.0]),
		buff(Buff.PhysicalArmorBuff, [70]),
		buff(Buff.MaxStaminaBuff, [-30]),
	]
