extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceGardevoir"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("Gardevoir")):
		return true
	return false


func getEffectName():
	return "Psychic Beauty"

func getEffectDesc():
	return "Psychic mons with frail bodies. There is an anti-psychic-to-physical zone set around the prision, so only mind affecting psychic energy can work. Psychic teasing  is this race's only hope in this prision. Good luck, slut."

func getEffectImage():
	return "res://Images/StatusEffects/hypnosis.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff, [5.0]),
		buff(Buff.StatBuff, [Stat.Sexiness, 8]),
		buff(Buff.PhysicalDamageBuff, [-90.0]),
		buff(Buff.ReceivedPhysicalDamageBuff, [200.0]),
		buff(Buff.LustDamageBuff, [600.0]),
		buff(Buff.ReceivedLustDamageBuff, [200.0]),
		buff(Buff.OverstimulationThresholdBuff, [900.0]),
		buff(Buff.MaxStaminaBuff, [-10]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 100.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Stunned, 100.0]),
	]
