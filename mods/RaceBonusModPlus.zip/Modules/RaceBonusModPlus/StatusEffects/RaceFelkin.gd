extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceFelkin"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["felkin"]):
	if(_npc.getSpecies().has("felkin")):
		return true
	return false


func getEffectName():
	return "Demon Dragon"

func getEffectDesc():
	return "Not much is known. It is theorized Fellkin are a sort of reptilian-horse-demon offshoot. Felkin are both Fragile and beautiful with potential to become very tough."

func getEffectImage():
	return "res://Images/StatusEffects/nested-hearts2.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.LustDamageBuff,[80]),
		buff(Buff.OverstimulationThresholdBuff, [200.0]),
		buff(Buff.StatBuff, [Stat.Sexiness, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.ReceivedPhysicalDamageBuff, [50.0]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [123]),

	]
