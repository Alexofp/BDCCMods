extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceCrocodile"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("sugerrcrocodile")):
		return true
	return false


func getEffectName():
	return "Dinosaur Survivor"

func getEffectDesc():
	return "Crocodiles can DEATH ROLL YOU! Be afraid."

func getEffectImage():
	return "res://Images/StatusEffects/bleeding.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 7]),
		buff(Buff.StatBuff, [Stat.Vitality, 7]),
		buff(Buff.PhysicalArmorBuff,[65]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-15.0]),
		buff(Buff.PhysicalDamageBuff,[50]),
		buff(Buff.ReceivedLustDamageBuff, [-10.0]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Breasts, 100]),
	]
