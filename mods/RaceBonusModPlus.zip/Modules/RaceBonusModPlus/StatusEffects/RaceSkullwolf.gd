extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceSkullwolf"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("skulldog")):
		return true
	return false


func getEffectName():
	return "Grim Beast"

func getEffectDesc():
	return "A canine race with darker instincts. Easily felled by lust, they are very dangerous if you try to fight them head on"

func getEffectImage():
	return "res://Images/StatusEffects/wildfires.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[30]),
		buff(Buff.PhysicalDamageBuff,[90]),
		buff(Buff.ForcedObedienceBuff,[-50]),
		buff(Buff.StatBuff, [Stat.Strength, 12]),
		buff(Buff.ReceivedLustDamageBuff, [333]),
	]
