extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceLucario"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["lucario"]):
	if(_npc.getSpecies().has("lucario")):
		return true
	return false


func getEffectName():
	return "Aura Warrior"

func getEffectDesc():
	return "Feel the power of aura! Lust seems to take you easily because of it."

func getEffectImage():
	return "res://Images/StatusEffects/biceps.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[15]),
		buff(Buff.PhysicalDamageBuff,[135]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, 300.0]),
		buff(Buff.StatBuff, [Stat.Strength, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.PhysicalArmorBuff, [100]),
		buff(Buff.ReceivedLustDamageBuff, [300.0]),
		buff(Buff.MaxStaminaBuff, [50.0]),
	]
