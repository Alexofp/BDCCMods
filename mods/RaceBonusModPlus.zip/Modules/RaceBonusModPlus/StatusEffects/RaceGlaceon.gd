extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceGlaceon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("glaceon")):
		return true
	return false


func getEffectName():
	return "Eevee-Ice"

func getEffectDesc():
	return "An Eevee with a body seemingly made of ice! They can deal a lot of lust damage due to their beauty, but take a lot of lust damage in turn. Bring on that sexy heat."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 3]),
		buff(Buff.StatBuff, [Stat.Vitality, 3]),
		buff(Buff.PhysicalDamageBuff,[-10]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-10.0]),
		buff(Buff.LustDamageBuff, [35.0]),
		buff(Buff.ReceivedLustDamageBuff, [200.0]),
		buff(Buff.MaxPainBuff, [10]),
		buff(Buff.MaxLustBuff, [30]),
		buff(Buff.MaxStaminaBuff, [-20]),
	]
