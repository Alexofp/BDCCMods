extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceEevee"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("eevee")):
		return true
	return false


func getEffectName():
	return "Eevee-Normal"

func getEffectDesc():
	return "An Eevee is said to be able to evolve into other kinds of races, this one has instead decided to grow as it was, adapting to a little bit of everything."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[110]),
		buff(Buff.PhysicalDamageBuff,[10]),
		buff(Buff.ForcedObedienceBuff,[10]),
		buff(Buff.StatBuff, [Stat.Strength, 1]),
		buff(Buff.StatBuff, [Stat.Agility, 1]),
		buff(Buff.StatBuff, [Stat.Sexiness, 1]),
		buff(Buff.StatBuff, [Stat.Vitality, 1]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-10.0]),
		buff(Buff.LustDamageBuff, [10.0]),
		buff(Buff.ReceivedLustDamageBuff, [-10.0]),
		buff(Buff.OverstimulationThresholdBuff, [110.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 10.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Stunned, 10.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Bleeding, 10.0]),
		buff(Buff.MaxPainBuff, [10]),
		buff(Buff.MaxLustBuff, [10]),
		buff(Buff.MaxStaminaBuff, [20]),
	]
