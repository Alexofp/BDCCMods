extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceNightStalker"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["nightstalker"]):
	if(_npc.getSpecies().has("nightstalker")):
		return true
	return false


func getEffectName():
	return "Wasteland Snakedog"

func getEffectDesc():
	return "From a wasteland planet, this species is very durable. However, they are physically weak due to being a pack hunter"

func getEffectImage():
	return "res://Images/StatusEffects/nested-hearts2.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Agility, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-30.0]),
		buff(Buff.PhysicalDamageBuff, [-30.0]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [123]),
		buff(Buff.MaxPainBuff, [50]),
		buff(Buff.MaxStaminaBuff, [50]),
	]
