extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceHuman"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("human")):
		return true
	return false


func getEffectName():
	return "Human's mind"

func getEffectDesc():
	return "You are a human, nothing special, but your incredible adaptability allows you to learn everything faster."

func getEffectImage():
	return "res://Images/StatusEffects/recruitment.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	var buffs = [
		buff(Buff.StatBuff, [Stat.Strength, 4]),
		buff(Buff.StatBuff, [Stat.Vitality, 4]),
		buff(Buff.StatBuff, [Stat.Agility, 4]),
		buff(Buff.StatBuff, [Stat.Sexiness, 4]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-10.0]),
		buff(Buff.PhysicalDamageBuff,[10]),
		buff(Buff.LustDamageBuff, [10.0]),
		buff(Buff.ReceivedLustDamageBuff, [-10.0]),

	]
	for skill in Skill.getAll():
		buffs.append(buff(Buff.SkillExperienceBuff,[skill,250]))
	return buffs
