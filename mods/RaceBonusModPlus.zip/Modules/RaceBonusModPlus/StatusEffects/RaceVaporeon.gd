extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceVaporeon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("vaporeon")):
		return true
	return false


func getEffectName():
	return "Eevee-Water"

func getEffectDesc():
	return "An Eevee that has evolved to do amazingly in water, so much so they can handle the pressure. This has, in turn, made them the ultimate fuck machine and able to handle damage."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[-30]),
		buff(Buff.StatBuff, [Stat.Sexiness, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 5]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-20.0]),
		buff(Buff.LustDamageBuff, [-30.0]),
		buff(Buff.ReceivedLustDamageBuff, [-20.0]),
		buff(Buff.OverstimulationThresholdBuff, [690.0]),
		buff(Buff.MaxPainBuff, [50]),
		buff(Buff.MaxLustBuff, [50]),
		buff(Buff.MaxStaminaBuff, [-15]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Penis, 30]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Vagina, 30]),
	]
