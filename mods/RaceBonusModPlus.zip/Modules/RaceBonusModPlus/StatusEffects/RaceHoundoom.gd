extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceHoundoom"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("houndoom")):
		return true
	return false


func getEffectName():
	return "Dark Inferno"

func getEffectDesc():
	return "A blazing caninemon from the hotter reigions of the planet the lycans are from."

func getEffectImage():
	return "res://Images/StatusEffects/fangs.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 10]),
		buff(Buff.StatBuff, [Stat.Vitality, 3]),
		buff(Buff.PhysicalDamageBuff, [200.0]),
		buff(Buff.PhysicalArmorBuff, [100]),
		buff(Buff.ReceivedLustDamageBuff, [275]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, 120.0]),
		buff(Buff.ForcedObedienceBuff,[20]),
		buff(Buff.AmbientLustBuff, [5]),
	]
