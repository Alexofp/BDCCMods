extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceKobold"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["kobold"]):
	if(_npc.getSpecies().has("kobold")):
		return true
	return false


func getEffectName():
	return "Fleshlight/Dildo Lizard"

func getEffectDesc():
	return "Once a very small race, even though they have grown, they are still very stretchy and made for breeding. Physically weak and weak to lust in adhearence to their reputation as a fleshlight/Dildo race."

func getEffectImage():
	return "res://Images/StatusEffects/bleeding-heart.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[-60]),
		buff(Buff.ReceivedLustDamageBuff, [75]),
		buff(Buff.DodgeChanceBuff, [20.0]),
		buff(Buff.StatBuff, [Stat.Sexiness, 7]),
		buff(Buff.StatBuff, [Stat.Agility, 4]),
		buff(Buff.OverstimulationThresholdBuff, [500.0]),
		buff(Buff.SensitivityGainBuff, [80.0]),
		buff(Buff.MaxPainBuff, [75]),
		buff(Buff.SkillExperienceBuff, [Skill.Exhibitionism, 150.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Fertility, 150.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Breeder, 150.0]),
		buff(Buff.SkillExperienceBuff, [Skill.SexSlave, 150.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Milking, 150.0]),
		buff(Buff.SkillExperienceBuff, [Skill.CumLover, 150.0]),
	]
