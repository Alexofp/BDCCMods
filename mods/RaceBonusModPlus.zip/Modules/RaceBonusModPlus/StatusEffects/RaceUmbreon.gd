extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceUmbreon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("umbreon")):
		return true
	return false


func getEffectName():
	return "Eevee-Dark"

func getEffectDesc():
	return "An Eevee that soaked in moonlight. They can't be affected by lust, but are really weak to physical attacks! They can be very loving however, despite the edginess."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[150]),
		buff(Buff.ForcedObedienceBuff,[30]),
		buff(Buff.StatBuff, [Stat.Strength, 3]),
		buff(Buff.StatBuff, [Stat.Agility, 3]),
		buff(Buff.StatBuff, [Stat.Vitality, 3]),
		buff(Buff.PhysicalDamageBuff,[70]),
		buff(Buff.ReceivedPhysicalDamageBuff, [230.0]),
		buff(Buff.LustDamageBuff, [-40.0]),
		buff(Buff.ReceivedLustDamageBuff, [-95.0]),
		buff(Buff.OverstimulationThresholdBuff, [130.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Bleeding, 60.0]),
		buff(Buff.MaxPainBuff, [50]),
		buff(Buff.MaxLustBuff, [-50]),
		buff(Buff.MaxStaminaBuff, [30]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Penis, 50]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Vagina, 50]),
	]
