extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "Mew"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("Mew")):
		return true
	return false


func getEffectName():
	return "Mythical Cat"

func getEffectDesc():
	return "Thought to be extinct or really rare, they were actually placed in BDCC for a mass breeding program. This has caused them to become more evasive and more fertile"

func getEffectImage():
	return "res://Images/StatusEffects/mask.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff,[36]),
		buff(Buff.StatBuff, [Stat.Agility, 6]),
		buff(Buff.StatBuff, [Stat.Sexiness, 6]),
		buff(Buff.SkillExperienceBuff, [Skill.Exhibitionism, 15.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Fertility, 30.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Breeder, 30.0]),
		buff(Buff.ReceivedLustDamageBuff, [35.0]),
		buff(Buff.ReceivedPhysicalDamageBuff, [100.0]),
		buff(Buff.FertilityBuff,[120]),
		buff(Buff.VirilityBuff,[120]),

	]
