extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceProtogen"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["protogen"]):
	if(_npc.getSpecies().has("protogen")):
		return true
	return false


func getEffectName():
	return "Computational Fluff"

func getEffectDesc():
	return "Fluffy cyborgs with a pension for learning, but have a hard time understanding lustful acts. they are less fertile due to being part cyborg."

func getEffectImage():
	return "res://Images/StatusEffects/noenergy.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.LustDamageBuff,[-90]),
		buff(Buff.FinalFertilityModifierBuff, [-80]),
		buff(Buff.FinalVirilityModifierBuff, [-80]),
		buff(Buff.DodgeChanceBuff, [10.0]),
		buff(Buff.AmbientLustBuff, [-10]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [-50]),
		buff(Buff.StatBuff, [Stat.Strength, 4]),
		buff(Buff.OverstimulationThresholdBuff, [800.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, 400.0]),
		buff(Buff.SkillExperienceBuff, [Skill.BDSM, 400.0]),
		buff(Buff.SkillExperienceBuff, [Skill.SexSlave, 400.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Exhibitionism, 400.0]),
		buff(Buff.SkillExperienceBuff, [Skill.CumLover, 400.0]),
	]
