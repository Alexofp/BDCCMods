extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceDeer"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("deer")):
		return true
	return false


func getEffectName():
	return "Skittish Race"

func getEffectDesc():
	return "As a deer, you are quite skittish compared to other races."

func getEffectImage():
	return "res://Images/StatusEffects/kneeling.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff, [15.0]),
		buff(Buff.StatBuff, [Stat.Agility, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 2]),
		buff(Buff.SkillExperienceBuff, [Skill.SexSlave, 200.0]),
		buff(Buff.PhysicalDamageBuff, [-25.0]),
		buff(Buff.ReceivedPhysicalDamageBuff, [10.0]),
	]
