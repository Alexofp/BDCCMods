extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceSeahorse"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("seahorse")):
		return true
	return false


func getEffectName():
	return "Not a horse from water"

func getEffectDesc():
	return "An aquatic race not meant to be on land much. They are fragile, but are also able to hit fast and hard due to not being in water anymore."

func getEffectImage():
	return "res://Images/StatusEffects/armor-punch.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[5]),
		buff(Buff.PhysicalDamageBuff,[150]),
		buff(Buff.ReceivedPhysicalDamageBuff, [125.0]),
		buff(Buff.StatBuff, [Stat.Agility, 3]),
		buff(Buff.StatBuff, [Stat.Strength, 5]),
		buff(Buff.MinOvulationEggsAmountBuff, [3]),
		buff(Buff.MaxStaminaBuff, [125]),
		buff(Buff.OverstimulationThresholdBuff, [333.0]),
	]
