extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceLopunny"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("lopunny")):
		return true
	return false


func getEffectName():
	return "Sexymon"

func getEffectDesc():
	return "A sex symbol of a rabbit. You are practically ment to breed."

func getEffectImage():
	return "res://Images/StatusEffects/vulva.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[-15]),
		buff(Buff.PhysicalDamageBuff,[170]),
		buff(Buff.StatBuff, [Stat.Agility, 2]),
		buff(Buff.StatBuff, [Stat.Sexiness, 6]),
		buff(Buff.MinOvulationEggsAmountBuff, [3]),
		buff(Buff.PregnancySpeedBuff, [150]),
		buff(Buff.PenisBallsVolumeBuff, [400]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [100]),
		buff(Buff.OverstimulationThresholdBuff, [222.0]),
	]
