extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceFeline"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("feline")):
		return true
	return false


func getEffectName():
	return "Feline Greatness"

func getEffectDesc():
	return "You are a feline, cute, fragile, but your heightened senses and agility allow you to react faster and navigate the world with grace."

func getEffectImage():
	return "res://Images/StatusEffects/mask.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff,[9]),
		buff(Buff.StatBuff, [Stat.Agility, 6]),
		buff(Buff.StatBuff, [Stat.Sexiness, 2]),
		buff(Buff.SkillExperienceBuff, [Skill.Exhibitionism, 15.0]),
		buff(Buff.ReceivedLustDamageBuff, [-15.0]),
		buff(Buff.ReceivedPhysicalDamageBuff, [25.0]),
	]
