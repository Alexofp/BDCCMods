extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceEquine"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("equine")):
		return true
	return false


func getEffectName():
	return "Equine's Virility"

func getEffectDesc():
	return "As an equine, you are really really productive..."

func getEffectImage():
	return "res://Images/StatusEffects/womb3.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.FertilityBuff,[200]),
		buff(Buff.PenisCumProductionBuff,[200]),
		buff(Buff.PregnancySpeedBuff,[200]),
		buff(Buff.VirilityBuff,[200]),
		buff(Buff.BreastsMilkProductionBuff,[200]),
		buff(Buff.PenisBallsVolumeBuff,[200]),
		buff(Buff.StatBuff, [Stat.Strength, 6]),
	]
