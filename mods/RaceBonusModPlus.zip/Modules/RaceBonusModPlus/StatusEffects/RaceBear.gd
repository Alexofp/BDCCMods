extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceBear"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("sugerrbear")):
		return true
	return false


func getEffectName():
	return "Mighty Bear"

func getEffectDesc():
	return "Bears are scary strong, able to hit hard and tank much more. Beware trying to fight one."

func getEffectImage():
	return "res://Images/StatusEffects/bleeding.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 10]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-25.0]),
		buff(Buff.PhysicalDamageBuff,[111]),
		buff(Buff.LustDamageBuff, [15.0]),
		buff(Buff.ReceivedLustDamageBuff, [250.0]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Anus, 100]),
	]
