extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceDuskLycan"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("dusklycan")):
		return true
	return false


func getEffectName():
	return "Dusk of Fangs"

func getEffectDesc():
	return "A rocky caninemon race. They can be violent and very strong."

func getEffectImage():
	return "res://Images/StatusEffects/fangs.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 5]),
		buff(Buff.StatBuff, [Stat.Vitality, 2]),
		buff(Buff.PhysicalDamageBuff, [70.0]),
		buff(Buff.PhysicalArmorBuff, [30]),
		buff(Buff.MaxPainBuff, [-30]),
	]
