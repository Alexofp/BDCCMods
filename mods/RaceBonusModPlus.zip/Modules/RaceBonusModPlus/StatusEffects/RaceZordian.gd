extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "zordian"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["zordian"]):
	if(_npc.getSpecies().has("zordian")):
		return true
	return false


func getEffectName():
	return "Strange Flora Mammal"

func getEffectDesc():
	return "An odd species with what seems like a plant growing from the back of thier neck."

func getEffectImage():
	return "res://Images/StatusEffects/nested-hearts2.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[120]),
		buff(Buff.MaxPainBuff, [35]),
		buff(Buff.MaxLustBuff, [-30]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-15.0]),
		buff(Buff.ReceivedLustDamageBuff, [10.0]),
		buff(Buff.FinalFertilityModifierBuff, [60]),
		buff(Buff.FinalVirilityModifierBuff, [60]),
		buff(Buff.AmbientLustBuff, [10]),
		buff(Buff.PregnancySpeedBuff, [130]),
	]
