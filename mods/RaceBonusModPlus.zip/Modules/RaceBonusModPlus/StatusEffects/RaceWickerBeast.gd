extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceWickerBeast"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	# print(_npc.getSpecies())
	# if(_npc.getSpecies() == ["wickerbeast"]):
	if(_npc.getSpecies().has("wickerbeast")):
		return true
	return false


func getEffectName():
	return "War Dragon"

func getEffectDesc():
	return "A large dragon with powerful blows and light hide. Large, and able to deal damage, they can't take what they can dish out, but still very terrifying if they can land a hit."

func getEffectImage():
	return "res://Images/StatusEffects/biceps.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[300]),
		buff(Buff.ReceivedPhysicalDamageBuff, [300.0]),
		buff(Buff.StatBuff, [Stat.Vitality, 2]),
		buff(Buff.StatBuff, [Stat.Strength, 8]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, 250.0])
	]
