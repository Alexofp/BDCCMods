extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "Nido"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("Nido")):
		return true
	return false


func getEffectName():
	return "Nido Majesty"

func getEffectDesc():
	return "Nidos are the most royal of Pokeraces, having powerful bodies and strong fertility. They used to have poison in their bodies, but after being taken here, they have had such poisons neutralized."

func getEffectImage():
	return "res://Images/StatusEffects/recruitment.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 6]),
		buff(Buff.StatBuff, [Stat.Vitality, 10]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-35.0]),
		buff(Buff.PhysicalDamageBuff,[120]),
		buff(Buff.LustDamageBuff, [-42.0]),
		buff(Buff.ReceivedLustDamageBuff, [275.0]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Vagina, 130]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Penis, 130]),
	]
