extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceCrow"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("crow")):
		return true
	return false


func getEffectName():
	return "Pretty Bird"

func getEffectDesc():
	return "Fragile, probably here for theft. Anything that catches their eye they will like or even love!"

func getEffectImage():
	return "res://Images/StatusEffects/Invigoration.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.DodgeChanceBuff,[17]),
		buff(Buff.StatBuff, [Stat.Agility, 6]),
		buff(Buff.SkillExperienceBuff, [Skill.BDSM, 30.0]),
		buff(Buff.ReceivedLustDamageBuff, [100.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 100.0]),
		buff(Buff.PhysicalArmorBuff, [-50]),
	]
