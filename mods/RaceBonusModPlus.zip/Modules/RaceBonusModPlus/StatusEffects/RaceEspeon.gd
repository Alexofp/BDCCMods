extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceEspeon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("espeon")):
		return true
	return false


func getEffectName():
	return "Eevee-Psychic"

func getEffectDesc():
	return "An Eevee that has evolved psychic and lust powers. They are able to handle their lustful desires, but physical damage hurts them a lot and they have no muscle strength."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff,[-35]),
		buff(Buff.StatBuff, [Stat.Agility, 2]),
		buff(Buff.StatBuff, [Stat.Sexiness, 4]),
		buff(Buff.ReceivedPhysicalDamageBuff, [25.0]),
		buff(Buff.LustDamageBuff, [100.0]),
		buff(Buff.ReceivedLustDamageBuff, [-50.0]),
		buff(Buff.OverstimulationThresholdBuff, [120.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Stunned, 80.0]),
		buff(Buff.MaxPainBuff, [-10]),
		buff(Buff.MaxLustBuff, [50]),
	]
