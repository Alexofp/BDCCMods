extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceRabbit"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("rabbit")):
		return true
	return false


func getEffectName():
	return "Rabbit Habit"

func getEffectDesc():
	return "A rabbit is a highly fertile beast, while also being very agile."

func getEffectImage():
	return "res://Images/StatusEffects/splurt.png"

func getIconColor():
	return IconColorPurple

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[150]),
		buff(Buff.PhysicalDamageBuff,[-50]),
		buff(Buff.ForcedObedienceBuff,[200]),
		buff(Buff.StatBuff, [Stat.Agility, 5]),
		buff(Buff.PregnancySpeedBuff, [100]),
		buff(Buff.CrossSpeciesCompatibilityBuff, [100]),
	]
