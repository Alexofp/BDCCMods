extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceMidnightLycan"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("midnightlycan")):
		return true
	return false


func getEffectName():
	return "Midnight Terror"

func getEffectDesc():
	return "A rocky caninemon race. They can be violent and very strong. This one is a midnight variant, it is very fast and powerful, but lust is thier weakness!"

func getEffectImage():
	return "res://Images/StatusEffects/fangs.png"

func getIconColor():
	return IconColorRed

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 7]),
		buff(Buff.StatBuff, [Stat.Vitality, 7]),
		buff(Buff.PhysicalDamageBuff, [250.0]),
		buff(Buff.PhysicalArmorBuff, [50]),
		buff(Buff.ReceivedLustDamageBuff, [225]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, 150.0]),
	]
