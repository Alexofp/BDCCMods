extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceSylveon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("sylveon")):
		return true
	return false


func getEffectName():
	return "Eevee-Fairy"

func getEffectDesc():
	return "An Eevee that has evolved to look cute... and be extremely dangerous. Sylveons are able to hit hard and lightly tank damage."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.AccuracyBuff,[123]),
		buff(Buff.ForcedObedienceBuff,[20]),
		buff(Buff.StatBuff, [Stat.Strength, 4]),
		buff(Buff.StatBuff, [Stat.Agility, 1]),
		buff(Buff.StatBuff, [Stat.Vitality, 3]),
		buff(Buff.PhysicalDamageBuff,[80]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-10.0]),
		buff(Buff.LustDamageBuff, [-50.0]),
		buff(Buff.ReceivedLustDamageBuff, [-10.0]),
		buff(Buff.OverstimulationThresholdBuff, [110.0]),
		buff(Buff.StatusEffectImmunityBuff, [StatusEffect.Collapsed, 80.0]),
		buff(Buff.MaxPainBuff, [30]),
		buff(Buff.MaxLustBuff, [-20]),
		buff(Buff.MaxStaminaBuff, [30]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Breasts, 30]),
		buff(Buff.SensitivityGainBuff, [BodypartSlot.Anus, 30]),
	]
