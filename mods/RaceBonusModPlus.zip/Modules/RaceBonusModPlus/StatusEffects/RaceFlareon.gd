extends StatusEffectBase

func _init():
	# id = StatusEffect.DragonGift
	id = "RaceFlareon"
	isBattleOnly = false

	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91
	
func shouldApplyTo(_npc):
	if(_npc.getSpecies().has("flareon")):
		return true
	return false


func getEffectName():
	return "Eevee-Fire"

func getEffectDesc():
	return "An Eevee that has evolved to handle hot enviroments and hit hard. Flareons are, however, weak to lust attacks, their fluffy bodies being sensitive and weak to their own lust. Truly a touch starved species."

func getEffectImage():
	return "res://Images/StatusEffects/WombMarkGlowing.png"

func getIconColor():
	return IconColorGreen

func getBuffs():
	return [
		buff(Buff.ForcedObedienceBuff,[-10]),
		buff(Buff.StatBuff, [Stat.Strength, 6]),
		buff(Buff.StatBuff, [Stat.Agility, 1]),
		buff(Buff.PhysicalDamageBuff,[60]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-30.0]),
		buff(Buff.LustDamageBuff, [-45.0]),
		buff(Buff.ReceivedLustDamageBuff, [75.0]),
		buff(Buff.OverstimulationThresholdBuff, [150.0]),
		buff(Buff.MaxPainBuff, [20]),
		buff(Buff.MaxStaminaBuff, [40]),
	]
