extends Species

func _init():
	id = "ssuine"
	
func getVisibleName():
	return "Pig"

func getDefaultLegs(_gender):
	return "ssuinehoofs"

func getDefaultTail(_gender):
	return "suinetail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Oinky"

func getDefaultHead(_gender):
	return "ssuinehead1"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "ssuineears1"

func getDefaultHorns(_gender):
		return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[4, 3.0],
		[6, 4.0],
		[8, 2.0],
		[10, 1.0],
	]

func getDefaultBreasts(_gender):
	if ("WintersBreastExpansion" in GlobalRegistry.getModules()):
		if(_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv",])
		return RNG.pick(["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv",])
	else:
		if(_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
