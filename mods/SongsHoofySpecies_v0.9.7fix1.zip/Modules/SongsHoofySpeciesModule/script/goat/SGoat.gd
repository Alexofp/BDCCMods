extends Species

func _init():
	id = "sgoat"
	
func getVisibleName():
	return "Goat"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffhoofssmall", "scruffhoofssmall", "sgoathoofs1", "sunihoofs1"])
	return RNG.pick(["sgoathoofs1", "sunihoofs1"])

func getDefaultTail(_gender):
	return "sunitail2"

func isPlayable():
	return true

func getVisibleDescription():
	return "Curious and Stubbron friends."

func getDefaultHead(_gender):
	return "sgoathead1"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffbody", "scruffbody", "anthrobody"])
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"
	#Tried adding the fluffy arm part, but left it out since it didn't seem to fit well with the paws ㅠㅠ

func getDefaultEars(_gender):
	return "suniears3"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "sgoathorns1"
	else:
		return "sgoathorns2"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "humanpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 8.0],
		[3, 4.0],
		[4, 2.0],
		[5, 0.5],
	]

func getDefaultBreasts(_gender):
	var modules = GlobalRegistry.getModules()
	var WinterBreastmod = "WintersBreastExpansion" in modules
	var WinterFluffmod = "WintersFluffyBodyparts" in modules

	if WinterBreastmod and WinterFluffmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["fluffmalebreasts", "malefluffbreastsnippleinv", "malefluffbreastspuffy", "malefluffbreastspuffyinv"])
		return RNG.pick(["fluffbreasts", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"])

	elif WinterBreastmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"])
		return RNG.pick(["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"])

	elif WinterFluffmod:
		if (_gender in [Gender.Male]):
			return "fluffmalebreasts"
		return "fluffbreasts"

	else:
		if (_gender in [Gender.Male]):
			return "malebreasts"
		return "humanbreasts"
