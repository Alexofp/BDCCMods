extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "scow"
	
func getVisibleName():
	return "Cow"

func getDefaultLegs(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffhoofs", "fluffhoofssmall", "scruffhoofs", "scruffhoofssmall", "scowhoofs1", "sunihoofs1"])
	return RNG.pick(["scowhoofs1", "sunihoofs1"])

func getDefaultTail(_gender):
	return "sunitail1"

func isPlayable():
	return true

func getVisibleDescription():
	return "Milky Friends"

func getDefaultHead(_gender):
	return "scowhead1"

func getDefaultBody(_gender):
	if ("WintersFluffyBodyparts" in GlobalRegistry.getModules()):
		return RNG.pick(["fluffbody", "scruffbody", "anthrobody"])
	return "anthrobody"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "suniears1"

func getDefaultHorns(_gender):
	if(_gender in [Gender.Male]):
		return "scowhorns1"
	else:
		return null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "equinepenishyperable"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 10.0],
		[2, 1.5],
		[3, 0.5],
	]

func getDefaultBreasts(_gender):
	var modules = GlobalRegistry.getModules()
	var WinterBreastmod = "WintersBreastExpansion" in modules
	var WinterFluffmod = "WintersFluffyBodyparts" in modules

	if WinterBreastmod and WinterFluffmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["fluffmalebreastshyperable", "malefluffbreastsnippleinvhyperable", "malefluffbreastspuffyhyperable", "malefluffbreastspuffyinvhyperable"])
		return RNG.pick(["fluffbreastshyperable", "fluffbreastsnippleinvhyperable", "fluffbreastspuffyhyperable", "fluffbreastspuffyinvhyperable"])

	elif WinterBreastmod:
		if (_gender in [Gender.Male]):
			return RNG.pick(["malebreastsnipplehyperable", "malebreastsnippleinvhyperable", "malebreastspuffyhyperable", "malebreastspuffyinvhyperable"])
		return RNG.pick(["breastsnipplehyperable", "breastsnippleinvhyperable", "breastspuffyhyperable", "breastspuffyinvhyperable"])

	elif WinterFluffmod:
		if (_gender in [Gender.Male]):
			return "fluffmalebreastshyperable"
		return "fluffbreastshyperable"

	else:
		if (_gender in [Gender.Male]):
			return "malebreastshyperable"
		return "humanbreastshyperable"
