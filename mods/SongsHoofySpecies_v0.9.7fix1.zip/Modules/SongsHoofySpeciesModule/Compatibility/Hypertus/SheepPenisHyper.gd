extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable sheep penis"
	id = "sheeppenisHY"

func getCompatibleSpecies():
	return ["sheep", Species.Any]

func getTraits():
	return {
		"Hyperable": true,
	}

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getDoll3DScene():
	return "res://Modules/SongsHoofySpeciesModule/pngs/sheep/Penis/SheepPenis.tscn"

