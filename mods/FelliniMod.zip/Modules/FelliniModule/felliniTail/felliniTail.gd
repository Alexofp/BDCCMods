extends BodypartTail
class_name felliniTail

var error = ""

func _init():
	visibleName = "Fellini Tail"
	id = "felliniTail"
	
func getCompatibleSpecies():
	var felliniFunctions = preload("res://Modules/FelliniModule/FelliniOptions.gd").new()
	print("FelliniTail.getCompatibleSpecies is looking for saved species...")
	if felliniFunctions.checkJson():
		var getSpecies = felliniFunctions.readJsonSub("felliniTail", "Species")
		var speciesArray = getSpecies.split(", ")
		print("Saved species found, creating array: " + str(speciesArray))
		return speciesArray
	else:
		print("Unable to load saved species! Setting to default value")
		return [Species.Feline]
	


func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["fluffy"])

func getDoll3DScene():
	return "res://Modules/FelliniModule/felliniTail/felliniTail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
