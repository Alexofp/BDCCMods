extends Module

var _version = 1.3

func getFlags():
	return {
		"felliniCupFilled": flag(FlagType.Bool),
		"felliniMilkTrigger": flag(FlagType.Bool),
		"felliniAffection": flag(FlagType.Number),
	}

func _init():
	id = "felliniModule"
	author = "Mari"      
	
	items = [
		"res://Modules/FelliniModule/Clothing/felliniBoots.gd",
		"res://Modules/FelliniModule/Clothing/felliniJacket.gd",
		"res://Modules/FelliniModule/Clothing/felliniShorts.gd",
		"res://Modules/FelliniModule/Clothing/felliniCroptop.gd",
		"res://Modules/FelliniModule/Clothing/felliniCroptopNew.gd",
		"res://Modules/FelliniModule/Clothing/felliniMask.gd",
		"res://Modules/FelliniModule/Clothing/felliniChoker.gd",
		"res://Modules/FelliniModule/Clothing/felliniPouch.gd",
		"res://Modules/FelliniModule/Scenes/felliniMilkCup.gd",
		"res://Modules/FelliniModule/Scenes/felliniMilkJugs.gd",
		"res://Modules/FelliniModule/Clothing/felliniGloves.gd",
	]
	
	bodyparts = [
		"res://Modules/FelliniModule/felliniTail/felliniTail.gd",
		"res://Modules/FelliniModule/felliniHair/felliniHair.gd",
	]
	
	worldEdits = [
		"res://Modules/FelliniModule/Scenes/felliniMapIcon.gd"
	]
	
	events = [
		"res://Modules/FelliniModule/Scenes/felliniMilkTrigger.gd",
		"res://Modules/FelliniModule/Scenes/felliniTrigger.gd"
	]

	scenes = [
		"res://Modules/FelliniModule/Scenes/felliniMilkSale.gd",
		"res://Modules/FelliniModule/Scenes/felliniMilkTransferJugs.gd",
		"res://Modules/FelliniModule/Scenes/felliniCupTransfer.gd",
		"res://Modules/FelliniModule/Scenes/felliniCollar.gd",
		"res://Modules/FelliniModule/Scenes/felliniDebug.gd",
	]
