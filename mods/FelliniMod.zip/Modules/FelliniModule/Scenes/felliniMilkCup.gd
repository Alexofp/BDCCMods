extends ItemBase

func _init():
	id = "felliniMilkCup"

func getVisibleName():
	return "Milk Cup"
	
func getDescription():
	return "The guard asked for some milk and gave you this cup."

func canCombine():
	return false

func getTags():
	return [
		ItemTag.PlasticBottle,
		]

func generateFluids():
	fluids = Fluids.new()
	fluids.setCapacity(300.0)

func getPossibleActions():
	return [
		{
			"name": "Fill up",
			"scene": "felliniCupTransfer",
			"description": "Transfer the fluids between fluid containers",
		}
	]

func getInventoryImage():
	return "res://Modules/FelliniModule/Scenes/felliniMilkCup.png"
