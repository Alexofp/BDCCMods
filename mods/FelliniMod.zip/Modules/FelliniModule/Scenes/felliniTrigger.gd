extends EventBase

func _init():
	id = "felliniTrigger"

func registerTriggers(es):
		es.addTrigger(self, Trigger.EnteringRoom, "yard_corridor4")
		
func run(_triggerID, _args):
	if(getCharacter("fellinipack:pulchrafellini") == null):
		addDisabledButton("Error!", "Pulchra Fellini NPC not found! Make sure you have the datapack installed!")
	else:
		addButton("Options", "Change Fellini Mod options", "debug")

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "debug"):
		runScene("felliniDebug")
