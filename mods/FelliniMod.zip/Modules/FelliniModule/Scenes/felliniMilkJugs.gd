extends ItemBase

func _init():
	id = "felliniMilkJugs"

func getVisibleName():
	return "Milk Jugs"
	
func getDescription():
	return "The guard asked for milk and gave you these jugs."

func canCombine():
	return false

func getTags():
	return [
		ItemTag.PlasticBottle,
		]

func generateFluids():
	fluids = Fluids.new()
	fluids.setCapacity(2000.0)

func getPossibleActions():
	return [
		{
			"name": "Fill up",
			"scene": "felliniMilkTransferJugs",
			"description": "Transfer the fluids between fluid containers",
		}
	]

func getInventoryImage():
	return "res://Modules/FelliniModule/Scenes/felliniMilkJugs.png"
