extends "res://Scenes/SceneBase.gd"

var uniqueItemID = ""
var interactionItemID = ""
var item: ItemBase

func _init():
	sceneID = "felliniCollar"

func _initScene(_args = []):
	if(_args.size() > 0):
		uniqueItemID = _args[0]
	
func _reactInit():
	if(uniqueItemID == null || uniqueItemID == ""):
		return
		
func _run():
	if(state == ""):
		saynn("Here you can toggle if you want to wear this choker or the inmate collar")
		
		addButton("Close", "Enough messing around", "endthescene")
		
		var choker: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
		
		if(!choker.isWornByWearer()):
			addButton("Equip", "Wear this choker instead of the inmate collar", "toggle")
		else:
			addDisabledButton("Equip","You are already wearing this")
		
func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return
	
	if(_action == "toggle"):
		
		var choker: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
		
		if(!choker.isWornByWearer()):
			GM.pc.getInventory().removeItem(choker)
			GM.pc.getInventory().forceEquipStoreOther(choker)
			addMessage("You put on the choker")
		
		setState("")
		return
	
	setState(_action)

func saveData():
	var data = .saveData()
	
	data["uniqueItemID"] = uniqueItemID
	data["interactionItemID"] = interactionItemID
	
	return data
	
func loadData(data):
	.loadData(data)
	
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	interactionItemID = SAVE.loadVar(data, "interactionItemID", "")
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
