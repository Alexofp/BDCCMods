extends EventBase

func _init():
	id = "felliniMilkTrigger"

func registerTriggers(es):
	es.addTrigger(self, Trigger.EnteringRoom, "yard_corridor4")

func run(_triggerID, _args):
	if(getFlag("felliniModule.felliniMilkTrigger")):
		addButton("Shop", "Buy jugs and sell milk", "milkSale")

func getPriority():
	return 0

func onButton(_method, _args):
	if(_method == "milkSale"):
		runScene("felliniMilkSale")
