extends SceneBase

var uniqueItemID = ""
var interactionItemID = ""
var item: ItemBase

func _init():
	sceneID = "felliniMilkSale"
	
func _initScene(_args = []):
	addCharacter("fellinipack:pulchrafellini")
	playAnimation(StageScene.Duo, "stand", {npc="fellinipack:pulchrafellini"})
	if(_args.size() > 0):
		uniqueItemID = _args[0]
	
func _reactInit():
	if(uniqueItemID == null || uniqueItemID == ""):
		return
		
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)

func _run():
	if(state == ""):
		saynn("Here you can buy and sell milk jugs. Note that milk price increases with higher affection")
		saynn("Milk jugs price: 10 credits")
		saynn("Milk jugs (Full) sale price: "+ str(15 + getFlag("felliniModule.felliniAffection")) +" credits")
		saynn("")
		saynn("Current affection: " + str(getFlag("felliniModule.felliniAffection")))
		
		addButton("Leave", "", "endthescene")
		
		if(getFlag("felliniModule.felliniAffection") == null):
			setFlag("felliniModule.felliniAffection", 0)
			addMessage("Affection detected as NULL! Setting back to 0")
		
		if(GM.pc.getCredits() >= 10):
			addButton("Buy jugs", "Get jugs so you can store your milk and resell them.", "buy")
		else:
			addDisabledButton("Buy jugs", "You don't have enough credits")
	
	###########Looking for jugs...
		var found = 0
		
		for theitem in GM.pc.getInventory().getItems():
			if(theitem == item):
				continue
			
			
			if(theitem.getFluids() != null && theitem.getVisibleName() == "Milk Jugs"):
				if(theitem.getFluids().getFluidAmount() == 2000 && found != 1):
					if(theitem.getFluids().getDominantFluidID() == "Milk"):
						addButton("Sell jugs", "Sells the jugs for "+ str(15 + getFlag("felliniModule.felliniAffection")) +" credits", "jugSold", [theitem.getUniqueID()])
						found = found+1
					
		if(found == 0):
			addDisabledButton("Sell jugs", "You don't have jugs filled to 2000ml.")
		#######################
	

func _react(_action: String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "buy"):
		addMessage("You bought a pair of jugs for 10 credits")
		GM.pc.getInventory().addItem(GlobalRegistry.createItem("felliniMilkJugs"))
		GM.pc.addCredits(-10)
		return
	
	if(_action == "jugSold"):
			for theitem in GM.pc.getInventory().getItems():
				if(theitem == item):
					continue
				
				
				if(theitem.getFluids() != null && theitem.getVisibleName() == "Milk Jugs"):
					if(theitem.getFluids().getFluidAmount() == 2000):
						GM.pc.addCredits(15 + getFlag("felliniModule.felliniAffection"))
						GM.pc.getInventory().removeXFromItemOrDelete(theitem, 1)
						addMessage("You sold the jugs for "+ str(15 + getFlag("felliniModule.felliniAffection")) +" credits")
				else:
					continue
			setState("")
			return

	setState(_action)
	
func loadData(data):
	.loadData(data)
	
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
	interactionItemID = SAVE.loadVar(data, "interactionItemID", "")
	item = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
