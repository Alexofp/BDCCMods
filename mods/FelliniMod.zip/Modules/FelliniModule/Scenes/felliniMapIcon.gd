extends WorldEditBase

func _init():
	id = "felliniMapIcon"
	
func apply(world: GameWorld):
		world.setRoomSprite("yard_corridor4", RoomStuff.RoomSprite.PERSON)
