extends SceneBase

#Dev note: I had no idea what I was doing when making this script so Fellini Tail and Fellini Hair options are not updated in the same way
#Fellini Hair is the 2nd one I made so I'd say that it's the one you should copy if you need it for your own project
#DM me on discord if thing get desperate

var error = ""

var tailOriginal = ""
var tailSelected = ""

var hairEdited = null

var readyToApply = false
var jsonWriteThisSelected = ""
var jsonCategorySelected = ""
var jsonSubCategorySelected = ""

func _init():
	sceneID = "felliniDebug"

func _run():
	if(error == ""):
		if(state == ""):
			sayn("Choose if you want to debug the datapack or the mod")
			addButton("Cancel", "", "endthescene")
			addButton("Datapack", "Edit datapack settings", "datapack")
			addButton("Mod", "Edit mod settings", "mod")
		
		if(state == "mod"):
			sayn("Choose which item you want to edit")
			addButton("Back", "", "back")
			addButton("Tail", "Manage allowed species for Fellini Tail", "felliniTail")
			addButton("Hair", "Manage gender weight for Fellini Hair", "felliniHair")
			addButton("Defaults", "Reset all options to default", "default")
			readyToApply = false
			jsonWriteThisSelected = ""
			jsonCategorySelected = ""
			jsonSubCategorySelected = ""
		
		if(state == "felliniTail"):
			saynn("Select which species should have the tail")
			sayn("Current array: " + tailSelected)
			addButton("Back", "", "mod")
			if readyToApply:
				addButton("Apply", "", "Apply", [tailSelected, "felliniTail", "Species"])
			else:
				addDisabledButton("Apply", "")
			addButton("Reset", "", "reset", "felliniTail")
			addButton("Any", "", "tailAny")
			addDisabledButton("", "This does nothing")
			
			var allSpecies = GlobalRegistry.getAllPlayableSpecies()
			for specieID in allSpecies:
				var speciesInfo = GlobalRegistry.getSpecies(specieID)
				addButton(speciesInfo.getVisibleName(), "Enable or disable Fellini Tail for this specie", "editArray", [specieID])
			
		if(state == "felliniHair"):
			addButton("Back", "", "mod")
			addButton("Apply", "", "Apply", [hairEdited, "felliniHair", null])
			addButton("Reset", "", "reset", "felliniHair")
			saynn("Select which NPCs can spawn with Fellini Hair:")
			#hairEdited = [{"maleWeight":0.4},{"femaleWeight":0},{"allowNPCs":true}]
			if hairEdited == null:
				hairEdited = preload("res://Modules/FelliniModule/FelliniOptions.gd").new().readJson("felliniHair")
			for item in hairEdited:
				for key in item.keys():
					var value = item[key]
					if value is float:
						value = str(value * 100) + "%"
						sayn(str(key).capitalize() + ": " + str(value))
					else:
						sayn(str(key).capitalize() + ": " + str(value))
			var toggleValue = hairEdited[2]
			if toggleValue["allowNPCs"] == true:
				addButton("Disable", "Disable Fellini Hair for NPCs", "toggleHair", [hairEdited, false])
			else:
				addButton("Enable", "Enable Fellini Hair for NPCs", "toggleHair", [hairEdited, true])
			
			addDisabledButton("", "This does nothing")
			addButton("Male +10%", "", "calcNumber", [hairEdited, "male", 0.1])
			addButton("Male -10%", "", "calcNumber", [hairEdited, "male", -0.1])
			addButton("Female +10%", "", "calcNumber", [hairEdited, "female", 0.1])
			addButton("Female -10%", "", "calcNumber", [hairEdited, "female", -0.1])
	
	else:
		saynn("Fellini Mod has encountered an error! Contact the developer")
		saynn("Caused by: " + error)
		sayn("Try deleting the .json and trying again.")
		addButton("Leave", "", "endthescene")
		addButton("Delete .json", "Delete global options for the mod and try to reinitiate", "delete")

func _react(_action: String, _args):
	var felliniFunctions = preload("res://Modules/FelliniModule/FelliniOptions.gd").new()
#	if(_action == "test"):#for testing if the code works, otherwise not used in scene
#		print(hairEdited[2])
#		return
	
	if(_action == "endthescene"):
		endScene()
		return
	
	if(_action == "back"):
		setState("")
		return
	
	if(_action == "datapack"):
		endScene("felliniDebug")
		runScene("fellinipack:pulchradebug")
		return
	
	if(_action == "mod"):
		if !felliniFunctions.checkJson():
			error = "checkJson failed at _action == 'mod'"
		setState("mod")
		return
	
	if(_action == "reset"):
		tailSelected = tailOriginal
		hairEdited = felliniFunctions.readJson("felliniHair")
		readyToApply = true
		setState(_args)
		return
	
	if(_action == "tailAny"):
		tailSelected = "any"
		readyToApply = true
		setState("felliniTail")
		return
	
	if(_action == "editArray"):
		readyToApply = true
		editArray(_args)
		return
	
	if(_action == "felliniTail"):
		jsonCategorySelected = "felliniTail"
		jsonSubCategorySelected = "Species"
		tailOriginal = felliniFunctions.readJsonSub(jsonCategorySelected, jsonSubCategorySelected)
		tailSelected = tailOriginal
		setState("felliniTail")
		return
	
	if(_action == "felliniHair"):
		jsonCategorySelected = "felliniHair"
		setState("felliniHair")
		return
	
	if(_action == "toggleHair"):
		#[hairEdited, false]
		var hairSend = _args[0]
		var toggleSend = _args[1]
		hairEdit(hairSend, toggleSend, null)
		return
	
	if(_action == "calcNumber"):
		#[hairEdited, "male", 0.1]
		var hairSend = _args[0]
		var calcSend1 = _args[1]
		var calcSend2 = _args[2]
		hairEdit(hairSend, null, [calcSend1, calcSend2])
		return
	
	if(_action == "toggle"):
		var jsonCategory = _args[0]
		var jsonSubCategory = _args[1]
		var wantedValue = _args[2]
		if wantedValue:
			felliniFunctions.writeJsonSub(true, jsonCategory, jsonSubCategory)
		else:
			felliniFunctions.writeJsonSub(false, jsonCategory, jsonSubCategory)
		return
	
	if(_action == "default"):
		if felliniFunctions.setDefaultJson():
			addMessage("Options have been set to default")
			hairEdited = felliniFunctions.readJson("felliniHair")
		else:
			addMessage("Failed to set default options")
	
	if(_action == "Apply"):
		#args should look like [data, it's category, false or it's subcategory]
		print("Running Apply...")
		var jsonWriteThis = _args[0]
		print("jsonWriteThis is: " + str(jsonWriteThis))
		if jsonWriteThis != null:
			var jsonCategory = _args[1]
			var jsonSubCategory = _args[2]
			if jsonSubCategory != null:
				if felliniFunctions.writeJsonSub(jsonWriteThis, jsonCategory, jsonSubCategory):
					addMessage("Applied changes")
					return
				else:
					addMessage("Script error! No changes applied")
			else:
				if felliniFunctions.writeJson(jsonWriteThis, jsonCategory):
					addMessage("Applied changes")
				else:
					addMessage("Script error! No changes applied")
		else:
			addMessage("There is nothing to apply")
		return

	if(_action == "delete"):
		if felliniFunctions.setDefaultJson():
			addMessage("setDefaultJson() succeeded")
			addMessage("Leave and reload the scene")
		else:
			error = "setDefaultJson() failed"
		return

func editArray(specieID):
	var toString = str(specieID)
	var specie = toString.substr(1, toString.length() - 2) + ", "
	if "any" in tailSelected:
		tailSelected = ""
	if specie in tailSelected:
		addMessage(toString + " set to disabled")
		tailSelected = tailSelected.replace(specie, "")
	else:
		addMessage(toString + " set to enabled")
		tailSelected = tailSelected + specie
	
func hairEdit(hairEditedEdit, toggle, calc):#meow
	#hairEditedEdit = [{"maleWeight":0.4},{"femaleWeight":0},{"allowNPCs":true}]
	if toggle != null:
		#toggle = true or false
		hairEditedEdit[2] = {"allowNPCs": toggle}
	
	if calc != null:
		#calc is ["male", 0.1]
		if calc[0] == "male":
			var subCat = hairEditedEdit[0]
			var value = subCat["maleWeight"] + calc[1]
			var roundValue = round(value * 10) / 10
			if roundValue >= 0 and roundValue <= 3:#for some reason it did not reach 3 or 0 if I have not rounded it beforehand
				subCat["maleWeight"] = roundValue
				hairEditedEdit[0] = subCat
		elif calc[0] == "female":
			var subCat = hairEditedEdit[1]
			var value = subCat["femaleWeight"] + calc[1]
			var roundValue = round(value * 10) / 10
			if roundValue >= 0 and roundValue <= 3:
				subCat["femaleWeight"] = roundValue
				hairEditedEdit[1] = subCat
	
	hairEdited = hairEditedEdit
	return [hairEdited]
