extends Node

var version = 1.3
var modName = "FelliniMod"
var fileName = "felliniOptions.json"
var filePath = GlobalRegistry.getModsFolder() + "/" + fileName

var defaultJson = {
			"version": version, #				#category
			"felliniTail": [#						#category
				{"Species": "feline, "},#				#subcategory
				#{"SubName": SubValue},#			#empty subcategory
				],
			"felliniHair": [#						#category
				{"maleWeight": 0.5},
				{"femaleWeight": 1.0},
				{"allowNPCs": false},
				],
			}

func checkJson():
	print(modName + " is attempting to run checkJson inside " + str(get_name()))
	var file = File.new()
	
	if file.open(filePath, File.READ) == OK:
		var file_content = file.get_as_text()
		file.close()
		print(modName + " has found the json, looking for version")
		var result = JSON.parse(file_content)
		
		#find version inside Json
		var jsonVer = null
		if result.error == OK:
			var json_data = result.result
			jsonVer = json_data["version"]
			print("jsonVer: " + str(jsonVer))
		else:
			print(modName + ".checkJson parsing error, attempting to set default json")
			var succeed = setDefaultJson()
			if !succeed:
				print("[ERROR]: setDefaultJson failed!")
				return false
			print("default json was successful")
			jsonVer = version
		
		#match jsonVer to modVer
		print(modName + ".checkJson: Checking if matching...")
		if jsonVer != null:
			if jsonVer != version:
				print("Version does not match! Setting default json")
				return setDefaultJson()
			else:
				print("Version match! (" + str(jsonVer) + ")")
				return true
		else:
			print(modName + ".checkJson version detected as null, setting default json")
			return setDefaultJson()
	else:
		print(modName + " did not find a json inside, creating default json")
		return setDefaultJson()
	

func setDefaultJson():
	print("[WARN] " + modName + ".setDefaultJson running")
	var file = File.new()

	if file.open(filePath, File.WRITE) == OK:
		var data = defaultJson
		var json_string = JSON.print(data)
		file.store_string(json_string)
		file.close()
		print("Success! File saved at: ", filePath)
		return true
	else:
		print("Failed to open file for writing.")

func readJson(jsonCategory):
	print(modName + ".readJson looking for: '" + str(jsonCategory) + "'")
	var felliniError = ""
	var file = File.new()
	
	if file.open(filePath, File.READ) == OK:
		var file_content = file.get_as_text()
		file.close()
		var result = JSON.parse(file_content)
		if result.error == OK:
			var json_data = result.result
			if jsonCategory in json_data:#Searches for matching category in json
				var jsonExtractedData = json_data[jsonCategory]#You can choose to export category data or continue to subcategory
				print(modName + ".readJson was successful")
				return jsonExtractedData
			else:
				felliniError = "[ERROR]: " + modName + "readJson: Specified jsonCategory (" + jsonCategory + ") not found!"
				print(felliniError)
				return null
		else:
			felliniError = "[ERROR]: " + modName + ".readJson: Failed to parse JSON. Error: "
			print(felliniError, result.error_string)
			return null
	else:
		felliniError = "[ERROR]: " + modName + ".readJson: Failed to open file for reading."
		print(felliniError)
		return null

func readJsonSub(jsonCategory, jsonSubCategory):
	print(modName + ".readJsonSub looking for Subcategory: '" + str(jsonSubCategory) + "' inside Category: '" + str(jsonCategory) + "'")
	var felliniError = ""
	var file = File.new()
	
	if file.open(filePath, File.READ) == OK:
		var file_content = file.get_as_text()
		file.close()
		var result = JSON.parse(file_content)
		if result.error == OK:
			var json_data = result.result
			if jsonCategory in json_data:#Searches for matching category in json
				var category_data = json_data[jsonCategory]#You can choose to export category data or continue to subcategory
				var loops = 0
				for item in category_data:#Searches for matching subcategory in the array
					loops += 1
					if jsonSubCategory in item:
						felliniError = ""
						print(modName + ".readJsonSub was successful")
						var jsonExtractedData = item[jsonSubCategory]
						return jsonExtractedData#Extracting matching subcategory
					elif loops < 100:
						print(modName + ".readJsonSub loop no. " + str(loops))
					else:
						felliniError = "[ERROR]: " + modName + ".readJsonSub: Specified jsonSubCategory (" + str(jsonSubCategory) + ") not found! Looped 100 times!"
						print(felliniError)
						return false
			else:
				felliniError = "[ERROR]: " + modName + "readJsonSub: Specified jsonCategory (" + str(jsonCategory) + ") not found!"
				print(felliniError)
				return false
		else:
			felliniError = "[ERROR]: " + modName + ".readJsonSub: Failed to parse JSON. Error: "
			print(felliniError, result.error_string)
			return false
	else:
		felliniError = "[ERROR]: " + modName + ".readJsonSub: Failed to open file for reading."
		print(felliniError)
		return false

func writeJson(jsonWriteThis, jsonCategory):
	print(modName + ".writeJson running")
	var felliniError = ""
	var file = File.new()
	
	if file.open(filePath, File.READ) == OK:
			var file_content = file.get_as_text()
			file.close()
			var result = JSON.parse(file_content)
			if result.error == OK:
				var json_data = result.result
				json_data[jsonCategory] = jsonWriteThis
				var newData = JSON.print(json_data)
				if file.open(filePath, File.WRITE) == OK:
					file.store_string(newData)
					file.close()
				print("File updated successfully at: " + str(filePath))
				return true
			else:
				felliniError = "[ERROR]: " + modName + ".writeJson: Failed to parse JSON. Error: " + result.error_string
				print(felliniError)
				file.close()
				return false
	else:
		felliniError = "[ERROR]: " + modName + ".writeJson: Failed to open file for reading and writing."
		print(felliniError)
		file.close()
		return false


func writeJsonSub(jsonWriteThis, jsonCategory, jsonSubCategory):
	print(modName + " is attempting to run writeJsonSub inside " + str(get_name()))
	var felliniError = ""
	var file = File.new()
	
	if file.open(filePath, File.READ) == OK:
		var file_content = file.get_as_text()
		file.close()
		var result = JSON.parse(file_content)
		if result.error == OK:
			var json_data = result.result
			if file.open(filePath, File.WRITE) == OK:
				var loops = 0
				for item in json_data[jsonCategory]:
					loops += 1
					if(item.has(jsonSubCategory)):
						item[jsonSubCategory] = jsonWriteThis
						print("SubCategory '" + jsonSubCategory + "' has been found!")
						var newData = JSON.print(json_data)
						file.store_string(newData)
						file.close()
						print("File updated successfully at: " + str(filePath))
						felliniError = ""
						return true
					elif loops > 10:
						felliniError= "[ERROR]: " + modName + ".writeJsonSub: Specified jsonSubCategory '" + jsonSubCategory + "' not found! Looped 10 times!"
						print(felliniError)
						file.close()
						return false
					else:
						print(modName + ".writeJsonSub: Loop no." + str(loops))
			else:
				felliniError = "[ERROR]: " + modName + ".writeJsonSub: Failed to open file for writing"
				print(felliniError)
				return false
		else:
			felliniError = "[ERROR]: " + modName + ".writeJsonSub: Failed to parse JSON. Error: " + result.error_string
			print(felliniError)
			return false
	else:
		felliniError = "[ERROR]: " + modName + ".writeJsonSub: Failed to open file for reading"
		print(felliniError)
		return false
