extends BodypartHair

var error = ""

func _init():
	visibleName = "Fellini"
	id = "felliniHair"

func npcGenerationWeight(_dynamicCharacter):
	var felliniFunctions = preload("res://Modules/FelliniModule/FelliniOptions.gd").new()
	if felliniFunctions.readJsonSub("felliniHair", "allowNPCs"):
		if(_dynamicCharacter.getGender() == Gender.Male):
			return felliniFunctions.readJsonSub("felliniHair", "maleWeight")
		if(_dynamicCharacter.getGender() in [Gender.Female, Gender.Androgynous]):
			return felliniFunctions.readJsonSub("felliniHair", "femaleWeight")
		return 1.0
	else:
		return 0

func getDoll3DScene():
	return "res://Modules/FelliniModule/felliniHair/felliniHair.tscn"

func getTraits():
	return {
		PartTrait.HairPonytail: true,
	}
