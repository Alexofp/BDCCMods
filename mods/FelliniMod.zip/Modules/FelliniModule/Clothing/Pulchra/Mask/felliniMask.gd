extends ItemBase

var timer
var cockblock
var visible

func _init():
	id = "felliniMask"

func getVisibleName():
	return "Fellini Mask"
	
func getDescription():
	return "Advanced version of a face mask that can block even the smallest of particles."

func getClothingSlot():
	return InventorySlot.Mouth

func getPrice():
	return 15

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your mask"
	else:
		return "take off your mask"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your mask"
	else:
		return "put on your mask"

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {"gasmask": "res://Modules/FelliniModule/Clothing/Pulchra/Mask/felliniMask.tscn"}

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/Pulchra/Mask/icon.png"

func canDye():#Modified ItemBase function, for some reason this function runs after every single action so I used it to keep checking the mouth state
	if GM.ui != null && !itemState.isRemoved():
		runDelayed()
	return false

func runDelayed():#Custom function
	if !is_instance_valid(timer):
		timer = Timer.new()
		timer.wait_time = 0.01
		timer.one_shot = true
		GM.ui.add_child(timer)
		timer.connect("timeout", self, "_on_mask_timer_timeout")
	if !is_instance_valid(cockblock):
		cockblock = Timer.new()
		cockblock.wait_time = 0.05
		cockblock.one_shot = true
		GM.ui.add_child(cockblock)
	if cockblock.is_stopped():#I added another longer timer that prevents the timer looping on itself, since updating the item causes the canDye func to trigger and start the loop again
		cockblock.start()
		timer.start()

func _on_mask_timer_timeout():#Custom function
	pass
#	for doll in GM.ui.getStage3d().currentScene.dolls:
#		if getWearer().getID() == doll.savedCharacterID && getWearer().getInventory().getEquippedItem("mouth") != null && getWearer().getInventory().getEquippedItem("mouth").id == "felliniMask":
#			updateVisibility(doll)

func updateVisibility(doll):#Custom function
		if doll.temporaryState.has("mouth"):
			if doll.temporaryState["mouth"] == "open" && visible:
				getWearer().getInventory().unequipItem(self)
				visible = false
				getWearer().getInventory().equipItem(self)
			elif !visible:
				getWearer().getInventory().unequipItem(self)
				visible = true
				getWearer().getInventory().equipItem(self)
		elif !visible:
			getWearer().getInventory().unequipItem(self)
			visible = true
			getWearer().getInventory().equipItem(self)

func shouldBeVisibleOnDoll(_character, _doll):#Modified ItemBase function
	if visible == null:
		return true
	return visible
