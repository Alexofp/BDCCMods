extends ItemBase

func _init():
	id = "felliniChoker"

func getVisibleName():
	return "Fellini Choker"
	
func getDescription():
	return "A simple choker, apparently it allows inmates to wear it instead of the Inmate collar"

func getClothingSlot():
	return InventorySlot.Neck

func getBuffs():
	return [
		buff(Buff.AmbientLustBuff, [10]),
		buff(Buff.StatBuff, [Stat.Agility, 5])
		]

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniChoker/icon.png"


func getPossibleActions():
	return [
		{
			"name": "Replace",
			"scene": "felliniCollar",
			"description": "Choose to wear this instead of your inmate collar",
		}
	]

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"neck": "res://Modules/FelliniModule/Clothing/felliniChoker/felliniChoker.tscn",
	}
