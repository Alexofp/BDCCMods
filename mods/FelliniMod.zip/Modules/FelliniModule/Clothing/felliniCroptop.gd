extends ItemBase

func _init():
	id = "felliniCroptop"
	clothesColor = Color(1.0, 1.0, 1.0)

func getVisibleName():
	return "Fellini Crop-Top"
	
func getDescription():
	var text = "Sporty crop-top from a defeated fighter, apparently it's up for bidding. Maybe there is another way of getting this crop-top?"

	return text

func getClothingSlot():
	return InventorySlot.UnderwearTop

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 12]),
		buff(Buff.StatBuff, [Stat.Agility, 10])
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your crop-top"
	else:
		return "take off your crop-top"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the crop-top"
	else:
		return "put on the crop-top"

func getPrice():
	return 65

func getTags():
	return [
		ItemTag.SoldByTheAnnouncer,
		]

func generateItemState():
	itemState = BraState.new()
	itemState.canActuallyBeDamaged = false

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniCroptop/icon.png"

func getRiggedParts(_character):
	if(itemState.isRemoved() || itemState.isBraPulledUp()):
		return null
	if(itemState.isDamaged()):
		return {
			"bra": "res://Modules/FelliniModule/Clothing/felliniCroptop/felliniCroptop.tscn",
		}
	return {
		"bra": "res://Modules/FelliniModule/Clothing/felliniCroptop/felliniCroptop.tscn",
	}

func canDye():
	return true
