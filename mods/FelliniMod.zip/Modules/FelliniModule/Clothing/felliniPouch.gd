extends ItemBase

func _init():
	id = "felliniPouch"

func getVisibleName():
	return "Fellini Leg Pouches"
	
func getDescription():
	return "Simple set of 2 pouches that goes around your leg, useful for holding small items."

func getClothingSlot():
	return InventorySlot.Unique

#func getBuffs():
#	return [
#		]

#func getTags():
#	return [
#		]

func getPrice():
	return 5

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your leg pouches"
	else:
		return "take off your leg pouches"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your leg pouches"
	else:
		return "put on your leg pouches"

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"necklace": "res://Modules/FelliniModule/Clothing/felliniPouch/felliniPouch.tscn",
	}

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniPouch/icon.png"
