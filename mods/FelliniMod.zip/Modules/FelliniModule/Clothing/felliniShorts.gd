extends ItemBase

func _init():
	id = "felliniShorts"
	clothesColor = Color(0.19, 0.19, 0.19)

func getVisibleName():
	return "Fellini Shorts"
	
func getDescription():
	var text = "Cropped jeans with fur. They bearly cover your private parts."

	return text

func getClothingSlot():
	return InventorySlot.UnderwearBottom

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 5]),
		buff(Buff.StatBuff, [Stat.Agility, 5]),
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "slips down your shorts"
	else:
		return "slip down your shorts"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the shorts"
	else:
		return "put on the shorts"

func getPrice():
	return 10

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func generateItemState():
	itemState = PantiesState.new()
	itemState.canShiftAside = false
	itemState.casualName = "briefs"
	itemState.canActuallyBeDamaged = false

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	if(itemState.isDamaged()):
		return {
			"panties": "res://Modules/FelliniModule/Clothing/felliniShorts/felliniShorts.tscn",
		}
	return {
		"panties": "res://Modules/FelliniModule/Clothing/felliniShorts/felliniShorts.tscn",
	}

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniShorts/icon.png"

func canDye():
	return false
