extends ItemBase

func _init():
	id = "felliniBoots"

func getVisibleName():
	return "Fellini Boots"
	
func getDescription():
	return "Raised boots with spikes."

func getClothingSlot():
	return InventorySlot.Ankles

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 2]),
		buff(Buff.ReceivedPhysicalDamageBuff, [-10]),
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your boots"
	else:
		return "take off your boots"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your boots"
	else:
		return "put on your boots"

func getPrice():
	return 15

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func updateDoll(doll: Doll3D):
	doll.setState("boots", "hard")

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniBoots/icon.png"

func getRiggedParts(_character):
	return {
		"boots": "res://Modules/FelliniModule/Clothing/felliniBoots/felliniBoots.tscn"
	}
