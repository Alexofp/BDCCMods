extends ItemBase

func _init():
	id = "felliniGloves"

func getVisibleName():
	return "Fellini Gloves"
	
func getDescription():

	return "Leather fingerless gloves with some spikes. Be careful not to punch people that you care about."

func getClothingSlot():
	return InventorySlot.Hands

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Strength, 3])
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your gloves"
	else:
		return "take off your gloves"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your gloves"
	else:
		return "put on your gloves"

func getPrice():
	return 10

func canSell():
	return true


func getTags():
	return [ItemTag.SoldByUnderwearVendomat]

func updateDoll(doll: Doll3D):
	doll.setState("gloves", "fingerless")

func getRiggedParts(_character):
	return {
		"gloves": "res://Modules/FelliniModule/Clothing/felliniGloves/felliniGloves.tscn"
	}

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniGloves/felliniGlovesIcon.png"
