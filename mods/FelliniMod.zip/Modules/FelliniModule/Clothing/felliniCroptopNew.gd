extends ItemBase

func _init():
	id = "felliniCroptopNew"
	clothesColor = Color(1.0, 1.0, 1.0)

func getVisibleName():
	return "White Crop-Top"
	
func getDescription():
	var text = "Sporty crop-top with some extra cleavage."

	return text

func getClothingSlot():
	return InventorySlot.UnderwearTop

func getBuffs():
	return [
		buff(Buff.StatBuff, [Stat.Sexiness, 3]),
		buff(Buff.StatBuff, [Stat.Agility, 2])
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your crop-top"
	else:
		return "take off your crop-top"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the crop-top"
	else:
		return "put on the crop-top"

func getPrice():
	return 10

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func generateItemState():
	itemState = BraState.new()
	itemState.canActuallyBeDamaged = false

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniCroptopNew/icon.png"

func getRiggedParts(_character):
	if(itemState.isRemoved() || itemState.isBraPulledUp()):
		return null
	if(itemState.isDamaged()):
		return {
			"bra": "res://Modules/FelliniModule/Clothing/felliniCroptopNew/felliniCroptopNew.tscn",
		}
	return {
		"bra": "res://Modules/FelliniModule/Clothing/felliniCroptopNew/felliniCroptopNew.tscn",
	}

func canDye():
	return true
