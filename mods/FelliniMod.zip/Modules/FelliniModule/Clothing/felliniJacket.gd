extends ItemBase

func _init():
	id = "felliniJacket"

func getVisibleName():
	return "Fellini Jacket"
	
func getDescription():
	return "Unique 3-piece jacket, excellent for blocking blunt damage while not restraining the wearer."

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		buff(Buff.PhysicalArmorBuff, [5]),
		buff(Buff.StatBuff, [Stat.Sexiness, 2]),
		buff(Buff.StatBuff, [Stat.Agility, 5])
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your jacket"
	else:
		return "take off your jacket"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your jacket"
	else:
		return "put on your jacket"

func getPrice():
	return 25

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func generateItemState():
	itemState = ShirtAndShortsState.new()

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"clothing": "res://Modules/FelliniModule/Clothing/felliniJacket/felliniJacket.tscn",
	}

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniJacket/icon.png"

func canDye():
	return false
