extends ItemBase

func _init():
	id = "felliniMask"

func getVisibleName():
	return "Fellini Mask"
	
func getDescription():
	return "Advanced version of a face mask that can block even the smallest of particles."

func getClothingSlot():
	return InventorySlot.Mouth

#func getBuffs():
#	return [
#		]

#func getTags():
#	return [
#		]

func getPrice():
	return 15

func getTags():
	return [
		ItemTag.SoldByUnderwearVendomat,
		]

func getTakingOffStringLong(withS):
	if(withS):
		return "takes off your mask"
	else:
		return "take off your mask"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on your mask"
	else:
		return "put on your mask"

func getRiggedParts(_character):
	if(itemState.isRemoved()):
		return null
	return {
		"gasmask": "res://Modules/FelliniModule/Clothing/felliniMask/felliniMask.tscn",
	}

func getInventoryImage():
	return "res://Modules/FelliniModule/Clothing/felliniMask/icon.png"
