extends InventorySlot

const Piercings = "piercings"

static func getVisibleName(slot: String):
	if(slot == Piercings):
		return "Face piercings"
		
	return "Error"
