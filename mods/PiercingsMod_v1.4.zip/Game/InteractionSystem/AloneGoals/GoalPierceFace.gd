extends InteractionGoalBase

var DEBUG = false

func getScore(_pawn:CharacterPawn) -> float:
	if DEBUG: print_debug(">>>>> PIERCINGS <<<<<:")
	var supportedHeads = GlobalRegistry.getModule("PiercingsModule").getAdjusterFace().keys()
#	if DEBUG: print_debug( load("res://Modules/PiercingsModule/Items/Piercings/ScuffedPiercings.gd").adjuster)

	if(_pawn.getCharacter().hasBoundArms() || _pawn.getCharacter().hasBlockedHands()):
		return 0.0
	
	var headID = _pawn.getChar().getBodypartID(BodypartSlot.Head)
	if DEBUG: print_debug(">>>>> PIERCINGS <<<<<: head:")
	if DEBUG: print_debug(headID)
	if !supportedHeads.has(headID):
		if DEBUG: print_debug(">>>>> PIERCINGS <<<<<: yet unsupported species")
		return 0.0

	# already wears face piercings
	if(_pawn.getCharacter().getInventory().getEquippedItem("piercings") != null):
		return 0.0
	
	# datapack characters remain unaffected
	if(!"dynamicnpc" in _pawn.getCharacter().getID()):
		return 0.0

	var currentPiercingsPop = GM.main.getFlag("PiercingsModule.currentCountOfPopWithFacePiercings", 0)
	var maxPiercingsInPopsPer = GM.main.getFlag("PiercingsModule.maxPercentageOfPopWithFacePiercings", 10)
#	var currentPop = GM.main.getPawnCount()
#	var currentPop = OPTIONS.getSandboxPawnCount()
	var currentPop = GM.main.getDynamicCharacters().size()
	if DEBUG: print_debug("currentPop")
	if DEBUG: print_debug(currentPop)
	var maxPop = floor(currentPop*maxPiercingsInPopsPer/100)
	var reducer = 0
	if(GM.main.getDays() <= 1):
		reducer = 2
	elif(GM.main.getDays() <= 2):
		reducer = 3
	elif(GM.main.getDays() <= 5): # First 5 days have reduced amount of pawns
		reducer = 5
	if reducer > 0 && reducer < maxPop:
		maxPop = reducer
		
	if currentPiercingsPop >= maxPop:
		if DEBUG: print_debug(">>>>> PIERCINGS <<<<<: max pops reached")
		return 0.0
	if DEBUG: print_debug(">>>>> PIERCINGS <<<<<: calc start")

	var cowardStat = _pawn.getChar().getPersonality().getStat(PersonalityStat.Coward)
	var bratStat = _pawn.getChar().getPersonality().getStat(PersonalityStat.Brat)
	var naiveStat = _pawn.getChar().getPersonality().getStat(PersonalityStat.Naive)
	var calculation = cowardStat*RNG.randf_range(-1.0, 0.0) + bratStat*RNG.randf_range(0.0, 1.0) + naiveStat*RNG.randf_range(0.0, 1.0)
	if calculation < 0.0: calculation = 0.0

	if DEBUG: print_debug(">>>>> PIERCINGS <<<<<: calculation for "+_pawn.getChar().getName())
	if DEBUG: print_debug(calculation)

	return calculation

#func getKeepScore() -> float:
#	return 0.6

func getText():
	return "{main.name} is heading to the Medical to put on some face piercings!"

func getActions() -> Array:
	return [
		{
			id = "go",
			name = "Go",
			desc = "Do something",
			score = 1.0,
			args = {},
			time = 60,
		},
	]

func randomisePiercings(facePiercings, pawn):
	var facePiercingsConfig = {}
	var facePiercingsAmmount = RNG.randi_range(1, 4) + RNG.randi_range(0,1) #1: 1/8, 2:2/8, 3:2/8, 4:2/8, 5:1/8
	while facePiercingsAmmount > 0:
		var picked = RNG.pickWeighted(["nose", "side", "muzzle", "chin", "brow"], [30, 20, 10, 20, 11])
		if facePiercingsConfig.keys().has(picked):
			continue
		facePiercingsConfig[picked] = true
		facePiercingsAmmount -= 1
	facePiercings.getVariants = facePiercingsConfig
	var colorInfo
	if RNG.chance(0.33):
		colorInfo = pawn.getCharacter().getInmateType()
		if colorInfo == "Unknown":
			colorInfo = pawn.getPawnType()
		match colorInfo:
			"Generic": colorInfo = [Color.gold]
			"SexDeviant": colorInfo = [Color.purple]
			"HighSec": colorInfo = [Color.red]
			"Guard": colorInfo = [Color.blue]
			"Nurse": colorInfo = [Color.yellowgreen]
			"Engineer": colorInfo = [Color.yellow]
	else:
		colorInfo = RNG.pick([Color.blue, Color.darkgoldenrod, Color.darkorange, Color.darkturquoise, Color.green, Color.hotpink, Color.lawngreen, Color.webpurple, Color.royalblue, Color.goldenrod, Color.gray])
	facePiercings.clothesColor = colorInfo


func doAction(_id:String, _args:Dictionary):
	if(_id == "go"):
		if DEBUG: print_debug(">>>>> PIERCINGS <<<<<: "+getPawn().getChar().getName()+" goes to buy piercings ")
		if(getLocation() == "MedRoom2"):
			if DEBUG: print_debug(">>>>> PIERCINGS <<<<<:"+getPawn().getChar().getName()+" reached the vendomat ")
			getPawn().getCharacter().getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("ScuffedPiercings"))#.getVariants = {"nose": true}
			randomisePiercings( getPawn().getCharacter().getInventory().getAllEquippedItems().get("piercings"), getPawn() )
			GM.main.setFlag("PiercingsModule.currentCountOfPopWithFacePiercings", GM.main.getFlag("PiercingsModule.currentCountOfPopWithFacePiercings", 0)+1)
			GM.main.addMessage("You just received news that "+getPawn().getCharacter().getName()+" had "+getPawn().getCharacter().hisHer()+" face piercings done just now, cool!")
#			GM.main.addLogMessage("News", "You just received news that "+getPawn().getCharacter().getName()+" had "+getPawn().getCharacter().hisHer()+" face piercings done just now, cool!")
			completeGoal()
		goTowards("MedRoom2")
		

func getAnimData() -> Array:
	return [StageScene.Solo, "walk", {pc="main"}]

func getActivityIcon():
	return RoomStuff.PawnActivity.None
