# mod version 1.4
extends Module

func getFlags():
	return {
#		"NefereFirstTimeEncountered": flag(FlagType.Bool),
		"maxPercentageOfPopWithFacePiercings": flag(FlagType.Number),
		"currentCountOfPopWithFacePiercings": flag(FlagType.Number),
	}

### START: from Mindstormsman's mod 'Brutal Dreams'
var GlobalTasks = [
	"res://Modules/PiercingsModule/Tasks/DummyPierceFaceTask.gd",
]

func register():
	.register()

	for Task in GlobalTasks:
		GlobalRegistry.registerGlobalTask(Task)
### END

func _init():
	id = "PiercingsModule"
	author = "_noro_"
	
#	setFlag("maxPercentageOfPopWithFacePiercings", 10) # source?: a random article said it's 10% for UK and 14% for USA - of non ear piercings
	
#	scenes = [
#		"res://Modules/PiercingModule/Scenes/PiercingSaloonFirstEncounterScene.gd",
#		]
#	characters = [
#		"res://Modules/PiercingModule/Scenes/NefereCharacter.gd",
#	]
	items = [
		"res://Modules/PiercingsModule/Items/Piercings/ScuffedPiercings.gd", # legacy face piercings
		"res://Modules/PiercingsModule/Items/Piercings/FacePiercings.gd",
	]
	
	scenes = [
#		"res://Modules/PiercingsModule/Items/Models/ScuffedPiercings/CustomizeScuffedPiercings.gd",
		"res://Modules/PiercingsModule/Items/Models/FacePiercings/CustomizeFacePiercings.gd",
	]

func getAdjusterFace():
	return {
		# to reuse parts:
		#	{"muzzle":"", "nose":"", "side":"", "chin":"", "brow":""} 
		#	but they need to be in the same parent folder
		
		### base game \/
		"caninehead":	["Canidae", "CanineLong", "Canine"],
		"wolfhead":		["Canidae", "CanineLong", "Wolf"],
		"bulldoghead":	["Canidae", "CanineShort", "Bulldog"],
		"humanhead":	["Human"],
		"humanoldhead":	["Human"],
		"androidhead":	["Human"],
		"felinehead":	["Felidae", "Feline", "Cat"],
		"fennechead":	["Canidae", "Fox", "Fennec"],
		"foxhead":		["Canidae", "Fox", "Fox"],
		"horsehead":	["Equine", "Horse", "HorseSmall"],
		"horseheadbig":	["Equine", "Horse", "HorseBig"],
		"dragonhead":	["Scalies", "Draconic", "Dragon"],
		
	#	### SongsVanillaParts \/
		#bg
		"shumanhead1": ["Human"],
		"sfelinehead1": ["Felidae", "Feline", {"muzzle":"SongsFeline1", "nose":"SongsFeline1", "side":"SongsFeline1", "chin":"SongsFeline1", "brow":"Cat"}],
		"sfelinehead2": ["Felidae", "Feline", {"muzzle":"SongsFeline2", "nose":"SongsFeline2", "side":"SongsFeline1", "chin":"SongsFeline2", "brow":"Cat"}],
		"sfelinehead3": ["Felidae", "Feline", {"muzzle":"SongsFeline3", "nose":"SongsFeline3", "side":"SongsFeline1", "chin":"SongsFeline3", "brow":"Cat"}],
		"songhorsehead": ["Equine", "Horse", {"muzzle":"HorseSmall", "nose":"SongsHorse", "side":"HorseSmall", "chin":"SongsHorse", "brow":"HorseSmall"}],
		"scaninehead1": ["Canidae", "CanineLong", "SongsCanine1"],
		"scaninehead2": ["Canidae", "CanineLong", "SongsCanine2"],
		"scaninehead3": ["Canidae", "CanineLong", "SongsCanine3"],
		"scaninehead4": ["Canidae", "CanineLong", "SongsCanine4"],
		"sdragonhead1": ["Scalies", "Draconic", "SongsDragon1"],
		"sdragonhead2": ["Scalies", "Draconic", {"muzzle":"SongsDragon1", "nose":"SongsDragon2", "side":"SongsDragon2", "chin":"SongsDragon2", "brow":"SongsDragon1"} ],
		"sdragonhead3": ["Scalies", "Draconic", "SongsDragon3"],
		"sdragonhead4": ["Scalies", "Draconic", "SongsDragon4"],
		
		### SugerrCharacterParts # new 1.1 \/
		## older versions
			# bg
		"sugerrtuftedfelinehead": ["Felidae", "Feline", "Cat"],
		"sugerrtuftedfennechead": ["Canidae", "Fox", "Fennec"],
		"sugerrtuftedbulldoghead": ["Canidae", "CanineShort", "Bulldog"],
		"sugerrtuftedcaninehead": ["Canidae", "CanineLong", "Canine"],
		"sugerrtuftedfoxhead": ["Canidae", "Fox", "Fox"],
		"sugerrtuftedwolfhead": ["Canidae", "CanineLong", "Wolf"],
		"sugerrlongfurredfelinehead": ["Felidae", "Feline", "Cat"],
		"sugerrlongfurredfelineheadv2": ["Felidae", "Feline", "Cat"],
		"scaleddragonhead": ["Scalies", "Draconic", "Dragon"],
		"scaleddemonhead": ["Human"],
		## 1.2 fix1:
			# bg
		"sugerrscaleddemonhead": ["Human"],
		"sugerrscaleddragonhead": ["Scalies", "Draconic", "Dragon"],
			# custom
		"sugerrcanidhead1": ["Canidae", "CanineLong", "SugerrCanid1"],
		"sugerrbigcathead": ["Felidae", "Feline", "SugerrBigCatMuzzle"],
		"sugerrdraconichead1": ["Scalies", "Draconic", "SugerrDraconic1"],
		"sugerrdraconichead2": ["Scalies", "Draconic", {"muzzle":"SugerrDraconic2", "nose":"SugerrDraconic2", "side":"SugerrDraconic2", "chin":"SugerrDraconic2", "brow":"SugerrDraconic1"}],
		"sugerrdraconichead3": ["Scalies", "Draconic", "SugerrDraconic3"],
		## 1.3 # new 1.4
		"sugerrcanidhead2" : ["Canidae", "CanineLong", "SugerrCanid2"],
		"sugerrdraconichead4": ["Scalies", "Draconic", "SugerrDraconic4"],
		"sugerrdraconichead5": ["Scalies", "Draconic", {"muzzle":"SugerrDraconic5", "nose":"SugerrDraconic5", "side":"SugerrDraconic5", "chin":"SugerrDraconic5", "brow":"SugerrDraconic4"}],
		
		
	#	### AnonsAquaticSpecies
	#	"seahorsehead": ["Test"],
	#	"seahorsehead2": ["Test"],
	#	"sharkhead": ["Test"],

		### AnonsBaseSpeciesExpansion # new 1.1 \/
		# copied frome base
		"hyenahead": ["Canidae", "CanineLong", "Canine"],
		"horsehead3": ["Equine", "Horse", "HorseSmall"],
		"horsehead4": ["Equine", "Horse", "HorseBig"],
		"horsehead5": ["Equine", "Horse", "HorseSmall"],
		# base variations
		"saberwolfhead": ["Canidae", "CanineLong",  {"muzzle":"Wolf", "nose":"Wolf", "side":"Wolf", "chin":"SaberWolf", "brow":"Wolf"}],
		"sabercathead": ["Felidae", "Feline", {"muzzle":"Cat", "nose":"Cat", "side":"Cat", "chin":"SaberCat", "brow":"Cat"}],
		# new
		"dragonhead2": ["Scalies", "Draconic", "ABSEDragon2"],
		"dragonhead3": ["Scalies", "Draconic", {"muzzle":"ABSEDragon3", "nose":"ABSEDragon3", "side":"ABSEDragon3", "chin":"ABSEDragon3", "brow":"ABSEDragon2"}],

	#	### AnonsProtogenSpecies
	#	"protogenhead": ["Test"],
	#	"protogenhead2": ["Test"],
	#	"purogenhead": ["Test"],

		### AnonsSkulldogSpecies # new 1.1 \/
		"skullheadskull": ["Canidae", "CanineLong", "Skulldog"],
		"skulldoghead": ["Canidae", "CanineLong", {"muzzle":"Skulldog", "nose":"SkulldogSkull", "side":"Skulldog", "chin":"Skulldog", "brow":"SkulldogSkull"}],

		### EirasTrashSpecies # new 1.1 \/
		"bathead1": ["Bat", "Bat1"],
		"bathead2": ["Bat", {"muzzle":"Bat2", "nose":"Bat2", "side":"Bat2", "chin":"Bat2", "brow":"Bat1"}],
		"bathead3": ["Bat", {"muzzle":"Bat3", "nose":"Bat3", "side":"Bat3", "chin":"Bat3", "brow":"Bat1"}],
		"bathead4": ["Bat", {"muzzle":"Bat4", "nose":"Bat4", "side":"Bat4", "chin":"Bat4", "brow":"Bat1"}],
		"bathead5": ["Bat", {"muzzle":"Bat5", "nose":"Bat5", "side":"Bat5", "chin":"Bat5", "brow":"Bat1"}],
		"bathead6": ["Bat", "Bat6"],
		"possumhead": ["Marsupialia", "Possum"],
		"raccoonhead": ["Musteloidea", "Raccoon"],
		"raccoonheadnopattern": ["Musteloidea", "Raccoon"],
		"mousehead": ["Rodents", "Mouse"],
		"rathead": ["Marsupialia", "Possum"],# same as possum
		"redpandahead": ["Musteloidea", "RedPanda"],
		"redpandaheadalt": ["Musteloidea", "RedPanda"],
		"redpandaheadnopattern": ["Musteloidea", "RedPanda"],
		"squirrelhead":["Rodents", "Squirrel"],

		### Scaile Expansion 2.1 # new 1.2 \/
		"snakehead": ["Scalies", "Snake"],
		"koboldhead": ["Scalies", "Draconic", {"muzzle":"ABSEDragon2", "nose":"Kobold", "side":"ABSEDragon2", "chin":"ABSEDragon2", "brow":"Kobold"}],
		"snuppyhead": ["Hybrids", "Nightstalker"],#night salker
		"easternhybrid": ["Scalies", "Draconic", "EasternDragonHybrid"],
		"easternround": ["Scalies", "Draconic", "EasternDragonRound"],
		"easternsharp": ["Scalies", "Draconic", {"muzzle":"EasternDragonSharp", "nose":"EasternDragonSharp", "side":"EasternDragonSharp", "chin":"EasternDragonSharp", "brow":"EasternDragonRound"}],
		"felkinhead": ["Scalies", "Draconic", {"muzzle":"FelkinOld", "nose":"FelkinOld", "side":"FelkinOld", "chin":"FelkinOld", "brow":"Felkin"}],
		"felkinhead2": ["Scalies", "Draconic", "Felkin"],# aka "not shit felkin head"
		"felkinhead3": ["Scalies", "Draconic", {"muzzle":"FelkinOld3", "nose":"FelkinOld3", "side":"FelkinOld3", "chin":"FelkinOld3", "brow":"Felkin"}],
		"wickerhead": ["Scalies", "FurryReptiles", "Wickerbeast"],

		### SergalSpecies # new 1.2 \/
		"sergalhead": ["Scalies", "FurryReptiles", "Sergal"],
		"sergalhead2": ["Scalies", "FurryReptiles", {"muzzle":"Sergal3", "nose":"Sergal", "side":"Sergal", "chin":"Sergal", "brow":"Sergal"}],
		"sergalhead3": ["Scalies", "FurryReptiles", {"muzzle":"Sergal3", "nose":"Sergal", "side":"Sergal", "chin":"Sergal3", "brow":"Sergal"}],
	#
	#	### SouthernSergalSpecies
	#	"sserghead": ["Test"], # Broken?
	#
	#	### SongsHoofySpecies
	#	"scowhead1": ["Test"],
	#	"scowhead2": ["Test"],
	#	"sdeerhead1": ["Test"],
	#	"sdeerhead2": ["Test"],
	#	"sgoathead1": ["Test"],
	#	"sgoathead2": ["Test"],
	#
	#	### SylvanosZordianSpecies
	#	"zordianheadlong": ["Test"],
	#	"zordianheadshort": ["Test"],
	}

