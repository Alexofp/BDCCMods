extends GlobalTask
# from user Mindstormsman and his mod 'Brutal Dreams'

func _init():
	id = "DummyPierceFaceTask"
	goalID = "PierceFace"
#	var currentPiercingsPop = GM.main.getFlag("PiercingsModule.currentCountOfPopWithFacePiercings", 0)
#	var currentPop = GM.main.getPawnCount()
#	var currentPop = OPTIONS.getSandboxPawnCount()
#	var maxPiercingsInPopsPer = GM.main.getFlag("PiercingsModule.maxPercentageOfPopWithFacePiercings", 10)
#	maxAssignedUnscaled = currentPiercingsPop-currentPop*maxPiercingsInPopsPer
	maxAssignedUnscaled = 2

func canDoTask(_pawn:CharacterPawn) -> bool:
	return !_pawn.isPlayer()
