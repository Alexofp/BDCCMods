# adopted from BDSMstuff by DrDurka

extends SceneBase

var uniqueItemID = ""

var current_part
var current_style
var setVariants = {}

var changedPart = [null, null]

func _init():
	
	sceneID = "ChangePiercingsStyleFace"
	

func _initScene(_args = []):
	if(_args.size() > 0):
		uniqueItemID = _args[0]

func _run():
	var item: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID) # referring to an item node in the inventory 
	
	if(state == ""):
#		print_debug("!!!!!!!!!!!!!")
#		print_debug(item.getVariants)
		playAnimation(StageScene.Solo, "stand")
		saynn("Your current piercings are:")
		var counter = 0
		for part in item.variants.keys():
			addButton(part.capitalize(), "", "change", part)
		for part in item.getVariants.keys():	
			if item.getVariants.get(part): 
				saynn("• "+part)
				counter+=1
			
		if counter == 0: 
#			saynn("Full set of piercings (aka. Risha style piercings)") # if player removes everything, it goes back to full set
			saynn("You have taken all of your piercings off.")
			addButton("Continue", "Yes, I want them off", "takeoff")
		else:
			addButton("Done", "Now it fits me!", "end")
		
	if(state == "change"):
		var descString = ""
		if changedPart[1]:
			descString = "put on"
		else:
			descString = "take off"
		saynn("You "+descString+" "+changedPart[0]+" piercings.")
		addButton("Back", "That's better", "")

		
func _react(_action: String, _args):
	var item: ItemBase = GM.pc.getInventory().getItemByUniqueID(uniqueItemID)
	
	if(_action == "end"):
		endScene()
		
	if(_action == ""):
		setState("")
	
	if(_action == "takeoff"):
		endScene()
		runScene("TakeAnyItemOffScene", [uniqueItemID])
		return
	
	if(_action == "change"):
		playAnimation(StageScene.TFLook, "head", {bodyState={naked=true}})
		var variantState = !item.getVariants.get(_args)
		setVariants.merge({_args: variantState},true) # idk if it's even needed
		item.getVariants.merge(setVariants, true)
		changedPart[0] = _args
		changedPart[1] = variantState
#		item.configs[_args]= !item.variants[_args]
		setState("")
	
	setState(_action)
	return

func saveData():
	var data = .saveData()
	
	data["uniqueItemID"] = uniqueItemID
	
	return data
	
func loadData(data):
	.loadData(data)
	
	uniqueItemID = SAVE.loadVar(data, "uniqueItemID", "")
		
	return null
