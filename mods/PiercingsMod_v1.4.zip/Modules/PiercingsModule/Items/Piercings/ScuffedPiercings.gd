extends ItemBase

var DEBUG = false

var variants = {
	"nose": null,
	"side": null,
	"chin": null,
	"muzzle": null
}

var getVariants = {}

var configs = {}

var isRandomHead = false
var randomHead = ""

func _init():
	id = "ScuffedPiercings"

func getVisibleName():
	return "(LEGACY) Face piercings"
	
func getDescription():
	return "Set of piercings for your face. (This is a legacy version, from the mod version 1.3 and below.)"

func getClothingSlot():
	return "piercings"

func getBuffs():
	return [
		]

#func generateItemState():
#	itemState = ShirtAndShortsState.new()

func getRequiredBodypart():
	return BodypartSlot.Head

func getPrice():
	return 25

func canSell():
	return true

func getTags():
#	return [ItemTag.SoldByMedicalVendomat, ItemTag.KeptAfterDrugDenRun]#, ItemTag.CanBeForcedInStocks] <- extra kinky
	return [ItemTag.KeptAfterDrugDenRun]#, ItemTag.CanBeForcedInStocks] <- extra kinky
func getTakingOffStringLong(withS):
	isRandomHead = false
	if(withS):
		return "takes off your piercings"
	else:
		return "take off your piercings"

func getPuttingOnStringLong(withS):
	if(withS):
		return "puts on the piercings"
	else:
		return "put on the piercings"

# local, non standard function for getRiggedParts
func pickFromAdjuster(res):
		var fileNamePath
		if typeof( res[ res.size()-1 ] ) == TYPE_STRING:
			fileNamePath = ""
			if res.size()==1:
				fileNamePath = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/FacePiercings"+res[0]
			if res.size()==2:
				fileNamePath = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/"+res[1]+"/FacePiercings"+res[1]
			if res.size()==3:
				fileNamePath = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/"+res[1]+"/"+res[2]+"/FacePiercings"+res[2]
			if res.size()==4:
				fileNamePath = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/"+res[1]+"/"+res[2]+"/FacePiercings"+res[3]
		else:
			fileNamePath = {}
			if res.size()==1:
				for key in variants:
					fileNamePath[key] = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/FacePiercings"+res[0].get(key)
			if res.size()==2:
				for key in variants:
					fileNamePath[key] = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/"+res[1].get(key)+"/FacePiercings"+res[1].get(key)
			if res.size()==3:
				for key in variants:
					fileNamePath[key] = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/"+res[1]+"/"+res[2].get(key)+"/FacePiercings"+res[2].get(key)
			if res.size()==4:
				for key in variants:
					fileNamePath[key] = "res://Modules/PiercingsModule/Items/Models/FacePiercings/"+res[0]+"/"+res[1]+"/"+res[2]+"/FacePiercings"+res[3].get(key)
		
		return fileNamePath

func getRiggedParts(_character): # when the model loads they will be replaced by new FacePiercings
	var piercingsOldVariants = _character.getInventory().getAllEquippedItems().get("piercings").getVariants
	var piercingsOldColor = _character.getInventory().getAllEquippedItems().get("piercings").clothesColor
	_character.getInventory().forceEquipRemoveOther(GlobalRegistry.createItem("FacePiercings"))
	_character.getInventory().getAllEquippedItems().get("piercings").getVariants = piercingsOldVariants
	_character.getInventory().getAllEquippedItems().get("piercings").clothesColor = piercingsOldColor
	GM.main.playAnimation(StageScene.Solo, "stand") #weird, but works to reload the model of the character (mainly the player), so new item appears
#	var adjuster = GlobalRegistry.getModule("PiercingsModule").getAdjusterFace()
#
#	if(itemState.isRemoved()):
#		return null
##	return {
##		"headpiercings": "res://Modules/PiercingsModule/Items/Models/ScuffedPiercings/ScuffedPiercings.tscn",
##	}
#
#	var headID
#	if GM.main.saveDynamicCharactersData().has(_character.get_name()):
#		headID = GM.main.saveDynamicCharactersData()[_character.get_name()]["data"]["bodyparts"]["head"]["id"]
#	else:
#		headID = GM.pc.saveData().bodyparts["head"]["id"]
#
#	var returnString
#	if adjuster.keys().has(headID):
#		if DEBUG: print_debug("1 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
##		if DEBUG: print_debug("res://Modules/PiercingsModule/Items/Models/ScuffedPiercings/"+adjuster[headID][0]+"/ScuffedPiercings"+adjuster[headID][1]+".tscn")
#		var res = adjuster[headID]
#		if DEBUG: print_debug (res)
#		if DEBUG: print_debug (res.size())
#		returnString = pickFromAdjuster(res)
#	elif isRandomHead:
#		if DEBUG: print_debug("2 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
#		returnString = randomHead
#	else:
#		if DEBUG: print_debug("3 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
#		if DEBUG: print_debug("Unknown head ID '"+headID+"', picking radom model from: ")
#		var temp = ""
#		for v in adjuster.values():
#			temp+=str(v[-1])
#			temp+=", "
#		var res = RNG.pick(adjuster.values())
#		if DEBUG: print_debug(temp)
#		if DEBUG: print_debug("picked: ")
#		if DEBUG: print_debug(res)
#		returnString = pickFromAdjuster(res)
#		isRandomHead =  true
#		randomHead =  returnString
#
##	print_debug(returnString)
#
#	var returnDict = {}
#	if typeof(returnString) == TYPE_STRING && returnString == pickFromAdjuster(["Test"]):
#		returnDict["headpiercings"]=returnString+".tscn"
#	elif !(getVariants.has("nose") || getVariants.has("side") || getVariants.has("chin") || getVariants.has("muzzle")):
#		if DEBUG: print_debug("RISHA STYLE")
#		if typeof(returnString) == TYPE_DICTIONARY:
#			for key in variants:
#				returnDict["headpiercings"+key.capitalize()]=returnString.get(key)+key.capitalize()+".tscn"
#		else:
#			for key in variants:
#				returnDict["headpiercings"+key.capitalize()]=returnString+key.capitalize()+".tscn"
#	else:
#		if typeof(returnString) == TYPE_DICTIONARY:
#			for key in getVariants.keys():
#				if !getVariants.get(key) == true:
#					continue
#				if DEBUG: print_debug("CUSTOM dict: "+returnString.get(key)+key.capitalize()+".tscn")
#				returnDict["headpiercings"+key.capitalize()]=returnString.get(key)+key.capitalize()+".tscn"
#		else:
#			for key in getVariants.keys():
#		#		output.merge({"harnessHR1": type[getVariants["Type"]]},true)
#				if !getVariants.get(key) == true:
#					continue
#				if DEBUG: print_debug("CUSTOM: "+returnString+key.capitalize()+".tscn")
#				returnDict["headpiercings"+key.capitalize()]=returnString+key.capitalize()+".tscn"
##				returnDict["headpiercings2"]="res://Modules/PiercingsModule/Items/Models/ScuffedPiercings/Human/ScuffedPiercingsHuman.tscn"
##	if returnDict.empty():
##		returnDict["headpiercings"]=returnStringTscn #if player removes everything, it goes back to full set
##		return
#	return returnDict
	
func getInventoryImage():
	return "res://Images/Items/bdsm/chastitypiercing.png"

func canDye():
	return true
	
func isImportant():
	return true

func getPossibleActions():
	if(isWornByWearer()):
		return [
			{
				"name": "Customize",
				"scene": "ChangePiercingsStyle",
				"description": "Choose piercings",
			},
		]
	else: return []

func saveData():
	var data = .saveData()
	
	data ["config"] = getVariants
	return data
	
func loadData(data):
	.loadData(data)
	
	getVariants = SAVE.loadVar(data, "config", {})
