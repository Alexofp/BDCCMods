extends Module

func _init():
	id = "OvipositorEggEdit"
	author = "Lazarus"
	
	bodyparts = [
		"res://Modules/OviEggEditor/OvipositorPenis.gd",
	]
