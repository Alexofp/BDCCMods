extends CanvasLayer


const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const FoxLibOptions := preload("res://Modules/InsertionBulges/FoxLibOptions.gd")
const Driver := preload("res://Bulge4/Driver.gd")
const FOX_SCREEN := "res://Modules/FoxLib/UI/FoxLibModOptionsScreen.gd"
const STAGE3D := "res://Player/Stage3D/Stage3D.tscn"
const ROLES := {"pc": "bodyState", "npc": "npcBodyState", "npc2": "npc2BodyState", "npc3": "npc3BodyState"}
const NAKED := {"naked": true, "hard": true}
const FIRST_SCENE := "SexAllFours"
const SKIPPED := ["tentacles", "tribadism", "train", "rimming", "portal", "pawjob", "handjob", "fleshlight", "fisting",
	"doubledown", "armsraised", "self"]
const FIRST_PENIS := "equinepenis"
const FIND_FRAMES := 150

var stage
var scenes := []
var sceneID := FIRST_SCENE
var fast := false
var state := ""
var penisIDs := []
var tops := {}
var bottom
var bottomRole := {}
var finding := -1
var guessed := {}
var belly := 0.0
var touched := {}
var controls := {}
var lines := {}
var sections := {}
var tabs:TabContainer
var camera:Camera
var leftPanel:Control
var leftBar:Button
var showTops := true
var showScene := true
var folds := {}
var who:Label
var cover:Label
var penisBox:OptionButton
var lengthSlider:HSlider
var tightTag:Label
var tightSlider:HSlider
var viewBar:HBoxContainer
var sceneList:ItemList
var bulk := false
var closed := false


func _ready():
	layer = 120
	var cached:Dictionary = GlobalRegistry.getStageScenesCachedStates()
	for id in cached:
		var states = cached[id]
		if(typeof(states) == TYPE_ARRAY && states.has("sex") && states.has("fast") && !skipped(str(id))):
			scenes.append(str(id))
	scenes.sort()
	penisIDs = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Penis)
	penisIDs.sort()
	var root := Control.new()
	root.theme = load("res://GlobalTheme.tres")
	root.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	add_child(root)
	var shade := ColorRect.new()
	shade.color = Color(0.03, 0.03, 0.04)
	shade.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	root.add_child(shade)
	var line := HBoxContainer.new()
	line.set_anchors_and_margins_preset(Control.PRESET_WIDE, Control.PRESET_MODE_MINSIZE, 16)
	root.add_child(line)
	leftPanel = scenePanel()
	leftPanel.visible = false
	line.add_child(leftPanel)
	leftBar = Button.new()
	leftBar.rect_min_size.x = 22
	leftBar.size_flags_vertical = Control.SIZE_EXPAND_FILL
	leftBar.hint_tooltip = "Show or hide the scene, the characters and the bottom."
	leftBar.connect("pressed", self, "onLeftBar")
	line.add_child(leftBar)
	onLeftBar(false)
	line.add_child(stageView())
	line.add_child(optionsPanel())
	wrapTips(root)
	for role in ROLES:
		tops[role] = topCharacter(role)
	if(player() != null):
		onPlayer()
	else:
		onRandom()


const TIP_WIDTH := 70
func wrapTips(node:Node) -> void:
	if(node is Control && node.hint_tooltip.length() > TIP_WIDTH && !("\n" in node.hint_tooltip)):
		node.hint_tooltip = wrapped(node.hint_tooltip)
	for child in node.get_children():
		wrapTips(child)

static func wrapped(text:String) -> String:
	var out:String = ""
	var line:String = ""
	for word in text.split(" ", false):
		if(line != "" && line.length() + 1 + word.length() > TIP_WIDTH):
			out += line + "\n"
			line = word
		elif(line == ""):
			line = word
		else:
			line += " " + word
	return out + line


func skipped(id:String) -> bool:
	for word in SKIPPED:
		if(word in id.to_lower()):
			return true
	return false


func player():
	if(GM.main == null || !is_instance_valid(GM.main) || GM.pc == null || !is_instance_valid(GM.pc)):
		return null
	return GM.pc


func stageView() -> Control:
	var box := ViewportContainer.new()
	box.stretch = true
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var view := Viewport.new()
	view.own_world = true
	view.hdr = false
	box.add_child(view)
	stage = load(STAGE3D).instance()
	view.add_child(stage)
	var made := Camera.new()
	made.projection = Camera.PROJECTION_ORTHOGONAL
	made.size = VIEW_SIZE
	made.translation = VIEW_AT
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.1, 0.1, 0.12)
	made.environment = env
	view.add_child(made)
	made.current = true
	camera = made
	box.connect("gui_input", self, "onViewInput", [box])
	cover = label("Loading the scene...")
	cover.align = Label.ALIGN_CENTER
	cover.valign = Label.VALIGN_CENTER
	var back := StyleBoxFlat.new()
	back.bg_color = env.background_color
	cover.add_stylebox_override("normal", back)
	cover.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	box.add_child(cover)
	var bar := HBoxContainer.new()
	bar.rect_position = Vector2(8.0, 8.0)
	viewBar = bar
	for step in [-1, 1]:
		var arrow := Button.new()
		arrow.text = "<"
		arrow.hint_tooltip = "The previous scene"
		if(step > 0):
			arrow.text = ">"
			arrow.hint_tooltip = "The next scene"
		arrow.connect("pressed", self, "onSceneStep", [step])
		bar.add_child(arrow)
	box.add_child(bar)
	return box


func onSceneStep(step:int) -> void:
	if(scenes.empty()):
		return
	var at:int = wrapi(scenes.find(sceneID) + step, 0, scenes.size())
	if(sceneList != null):
		sceneList.select(at)
		sceneList.ensure_current_is_visible()
	onScene(at)


const VIEW_SIZE := 10.0
const VIEW_AT := Vector3(0.0, 4.141, 50.0)
func onViewInput(event:InputEvent, box:Control) -> void:
	var perPixel:float = camera.size / max(box.rect_size.y, 1.0)
	if(event is InputEventMouseButton && event.pressed && event.button_index in [BUTTON_WHEEL_UP, BUTTON_WHEEL_DOWN]):
		var factor := 0.9
		if(event.button_index == BUTTON_WHEEL_DOWN):
			factor = 1.0 / 0.9
		var size:float = clamp(camera.size * factor, 1.0, 40.0)
		var off:Vector2 = event.position - box.rect_size / 2.0
		var change:float = (camera.size - size) / max(box.rect_size.y, 1.0)
		camera.translation += Vector3(off.x * change, -off.y * change, 0.0)
		camera.size = size
		box.accept_event()
	elif(event is InputEventMouseMotion && event.button_mask != 0):
		camera.translation += Vector3(-event.relative.x * perPixel, event.relative.y * perPixel, 0.0)
		box.accept_event()


func onLeftBar(flip:bool = true) -> void:
	if(flip):
		leftPanel.visible = !leftPanel.visible
	leftBar.text = ">"
	if(leftPanel.visible):
		leftBar.text = "<"


func onResetView() -> void:
	camera.size = VIEW_SIZE
	camera.translation = VIEW_AT


func onShowTops(on:bool) -> void:
	showTops = on
	if(finding < 0):
		dress()


func onShowScene(on:bool) -> void:
	showScene = on
	if(finding < 0):
		dress()


func scenePanel() -> Control:
	var box := VBoxContainer.new()
	box.rect_min_size.x = 300
	box.add_constant_override("separation", 8)
	box.add_child(label("Insertion Bulges: try it on"))
	who = label("")
	box.add_child(who)
	var left := TabContainer.new()
	left.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(left)
	var scene := tabPage(left, "Scene")
	var list := ItemList.new()
	list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for id in scenes:
		list.add_item(id)
	if(scenes.has(sceneID)):
		list.select(scenes.find(sceneID))
	list.connect("item_selected", self, "onScene")
	scene.add_child(list)
	sceneList = list
	var speed := CheckBox.new()
	speed.text = "Fast"
	speed.connect("toggled", self, "onFast")
	scene.add_child(speed)
	scene.add_child(button("Reset the view", "onResetView"))
	var hint := label("Wheel: zoom. Drag: move.")
	hint.modulate = Color(1.0, 1.0, 1.0, 0.6)
	scene.add_child(hint)
	var people := tabPage(left, "Dolls")
	var mine := button("Your character", "onPlayer")
	mine.disabled = player() == null
	if(mine.disabled):
		mine.hint_tooltip = "Start or load a game to see your own character here."
	people.add_child(mine)
	people.add_child(button("Random character", "onRandom"))
	var whole := CheckBox.new()
	whole.text = "Show the penetrator"
	whole.pressed = showTops
	whole.hint_tooltip = "Show the whole body of who penetrates, not only the cock."
	whole.connect("toggled", self, "onShowTops")
	people.add_child(whole)
	var things := CheckBox.new()
	things.text = "Show the scene"
	things.pressed = showScene
	things.hint_tooltip = "Show the scene's things (floor, table, wall...). Off, with Show the penetrator off: only the" \
		+ " cock and who is penetrated."
	things.connect("toggled", self, "onShowScene")
	people.add_child(things)
	people.add_child(label("Cock"))
	penisBox = OptionButton.new()
	for id in penisIDs:
		penisBox.add_item(str(id))
	if(penisIDs.has(FIRST_PENIS)):
		penisBox.select(penisIDs.find(FIRST_PENIS))
	penisBox.connect("item_selected", self, "onPenis")
	people.add_child(penisBox)
	lengthSlider = sliderLine(people, "Cock length", " cm", 5.0, 80.0, 1.0, 20.0, "onLength")
	var body := tabPage(left, "Bottom")
	var _belly:HSlider = sliderLine(body, "Belly size", "", -0.5, 5.0, 0.05, belly, "onBelly")
	tightSlider = sliderLine(body, "Bottom tightness (loose 0, tight 1)", "", 0.0, 1.0, 0.05, 0.5, "onTight")
	tightSlider.hint_tooltip = "Stands for the bottom's own tightness (Body tightness: From the character), only in this" \
		+ " window: the character is not changed."
	body.add_child(button("Use the character's own tightness", "onOwnTight"))
	tightTag = label("")
	body.add_child(tightTag)
	return box


func tabPage(into:TabContainer, title:String) -> VBoxContainer:
	var page := VBoxContainer.new()
	page.name = title
	page.add_constant_override("separation", 10)
	into.add_child(page)
	return page


func sliderLine(box:Control, title:String, unit:String, from:float, to:float, step:float, at:float, method:String) -> HSlider:
	var tag := label(title + ": " + str(at) + unit)
	var slider := HSlider.new()
	slider.min_value = from
	slider.max_value = to
	slider.step = step
	slider.value = at
	slider.connect("value_changed", self, "onSliderTag", [title, unit, tag])
	slider.connect("value_changed", self, method)
	box.add_child(tag)
	box.add_child(slider)
	return slider


func onSliderTag(value:float, title:String, unit:String, tag:Label) -> void:
	tag.text = title + ": " + str(value) + unit


func optionsPanel() -> Control:
	var box := VBoxContainer.new()
	box.rect_min_size.x = 440
	box.add_constant_override("separation", 8)
	if(Settings.gles2()):
		var note := label(FoxLibOptions.GLES2_TEXT)
		note.add_color_override("font_color", FoxLibOptions.GLES2_RED)
		box.add_child(note)
	tabs = TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(tabs)
	for cat in FoxLibOptions.CATEGORIES:
		var scroll := ScrollContainer.new()
		scroll.name = tabTitle(str(cat))
		scroll.scroll_horizontal_enabled = false
		var rows := VBoxContainer.new()
		rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rows.add_constant_override("separation", 10)
		scroll.add_child(rows)
		for row in FoxLibOptions.OPTIONS:
			if(str(row["cat"]) != cat || str(row["type"]) == FoxLibOptions.T_BUTTON || row.has("when")):
				continue
			if(cat == FoxLibOptions.CAT_EXPERIMENTS):
				var fold = foldFor(row)
				if(fold != null):
					rows.add_child(fold)
			else:
				rows.add_child(lineFor(row))
		sections[cat] = scroll
		tabs.add_child(scroll)
	var lastUnder := {}
	var switchOf := {}
	for row in FoxLibOptions.OPTIONS:
		if(row.has("when") && lines.has(str(row["when"][0]))):
			var switch:String = str(row["when"][0])
			var after:Control = lastUnder.get(switch, lines[switch][0])
			var line:Control = lineFor(row)
			after.get_parent().add_child(line)
			after.get_parent().move_child(line, after.get_index() + 1)
			switchOf[str(row["id"])] = switch
			var up:String = switch
			while(true):
				lastUnder[up] = line
				if(!switchOf.has(up)):
					break
				up = switchOf[up]
	showSections()
	var buttons := HBoxContainer.new()
	buttons.add_child(button("Save", "onSave"))
	buttons.add_child(button("Defaults", "onDefaults"))
	buttons.add_child(button("Cancel", "onCancel"))
	box.add_child(buttons)
	return box


func tabTitle(cat:String) -> String:
	if(cat == FoxLibOptions.CAT_MAIN):
		return "Main"
	return cat.trim_prefix(FoxLibOptions.CAT_MAIN + ": ").capitalize()


func foldFor(row:Dictionary):
	var key:String = str(row.get("group", row["id"]))
	if(folds.has(key)):
		folds[key][1].append(row)
		folds[key][2].add_child(lineFor(row))
		return null
	var fold := VBoxContainer.new()
	var head := Button.new()
	head.toggle_mode = true
	head.align = Button.ALIGN_LEFT
	head.clip_text = true
	head.hint_tooltip = str(row["desc"])
	fold.add_child(head)
	var pad := MarginContainer.new()
	pad.add_constant_override("margin_left", 18)
	pad.add_constant_override("margin_bottom", 6)
	pad.visible = false
	var inside := VBoxContainer.new()
	inside.add_constant_override("separation", 10)
	inside.add_child(lineFor(row))
	pad.add_child(inside)
	fold.add_child(pad)
	head.connect("toggled", self, "onFold", [inside])
	folds[key] = [head, [row], inside]
	return fold


func onFold(open:bool, inside:Control) -> void:
	inside.get_parent().visible = open
	showSections()


func foldText(key:String) -> String:
	var values:Array = []
	for row in folds[key][1]:
		var id:String = str(row["id"])
		var value = Settings.value(id)
		var shown:String = str(value)
		if(str(row["type"]) == FoxLibOptions.T_BOOL):
			shown = "Off"
			if(bool(value)):
				shown = "On"
			if(folds[key][1].size() > 1):
				if(!bool(value)):
					continue
				shown = str(row["title"])
		elif(row.has("values")):
			for v in row["values"]:
				if(str(v[0]) == str(value)):
					shown = str(v[1])
		values.append(shown)
	var arrow := "+ "
	if(folds[key][2].get_parent().visible):
		arrow = "- "
	var title:String = str(folds[key][1][0].get("group", folds[key][1][0]["title"]))
	return arrow + title + ": " + PoolStringArray(values).join(", ")


func label(text:String) -> Label:
	var made := Label.new()
	made.text = text
	made.autowrap = true
	return made


func button(text:String, method:String) -> Button:
	var made := Button.new()
	made.text = text
	made.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	made.connect("pressed", self, method)
	return made


func lineFor(row:Dictionary) -> Control:
	var id:String = str(row["id"])
	var kind:String = str(row["type"])
	var value = Settings.value(id)
	if(id == "bulgeEffect"):
		value = drawnEffect()
	var made:Control
	if(kind == FoxLibOptions.T_BOOL):
		var check := CheckBox.new()
		check.text = str(row["title"])
		check.pressed = bool(value)
		check.connect("toggled", self, "onValue", [id])
		made = check
		controls[id] = check
	elif(kind == FoxLibOptions.T_PERCENT):
		made = VBoxContainer.new()
		var tag := label("")
		var slider := HSlider.new()
		slider.max_value = 100.0
		slider.step = 1.0
		slider.value = float(value) * 100.0
		slider.hint_tooltip = str(row["desc"])
		tag.text = str(row["title"]) + ": " + str(slider.value) + "%"
		slider.connect("value_changed", self, "onPercent", [id, str(row["title"]), tag])
		made.add_child(tag)
		made.add_child(slider)
		controls[id] = slider
	else:
		made = VBoxContainer.new()
		made.add_child(label(str(row["title"])))
		var choice := OptionButton.new()
		for i in range(row["values"].size()):
			choice.add_item(str(row["values"][i][1]))
			if(str(row["values"][i][0]) == str(value)):
				choice.select(i)
			if(id == "bulgeEffect" && Settings.gles2() && str(row["values"][i][0]) != "basic"):
				choice.set_item_disabled(i, true)
		choice.hint_tooltip = str(row["desc"])
		choice.connect("item_selected", self, "onChoice", [row])
		made.add_child(choice)
		controls[id] = choice
	made.hint_tooltip = str(row["desc"])
	lines[id] = [made, row]
	return made


func onValue(value, id:String, all:bool = true) -> void:
	touched[id] = value
	Settings.overlay(id, value)
	if(bulk):
		return
	if(all):
		showSections()
		return
	for key in folds:
		folds[key][0].text = foldText(key)


func drawnEffect() -> String:
	Driver.readSettings()
	return str(Driver.TUNING["effect"])


func showSections() -> void:
	var effect:String = drawnEffect()
	var wanted := {FoxLibOptions.CAT_MAIN: true, FoxLibOptions.CAT_MEDIUM: effect == "medium",
		FoxLibOptions.CAT_EXPERIMENTS: effect == "detailed"}
	var current:int = tabs.current_tab
	for cat in sections:
		var index:int = sections[cat].get_index()
		if(tabs.get_tab_hidden(index) == bool(wanted.get(cat, true))):
			tabs.set_tab_hidden(index, !bool(wanted.get(cat, true)))
	if(!bool(wanted.get(FoxLibOptions.CATEGORIES[current], true))):
		current = 0
	tabs.current_tab = current
	for id in lines:
		lines[id][0].visible = FoxLibOptions.shown(lines[id][1])
	for id in folds:
		folds[id][0].text = foldText(id)


func onPercent(value:float, id:String, title:String, tag:Label) -> void:
	tag.text = title + ": " + str(value) + "%"
	onValue(value / 100.0, id, false)


func onChoice(index:int, row:Dictionary) -> void:
	onValue(str(row["values"][index][0]), str(row["id"]))


func onScene(index:int) -> void:
	sceneID = str(scenes[index])
	play()


func onFast(on:bool) -> void:
	fast = on
	play()


func onPlayer() -> void:
	setBottom(player())
	who.text = "Shown: your character. Nothing is saved until you press Save."
	play()


func onRandom() -> void:
	setBottom(randomCharacter())
	who.text = "Shown: a random character. Nothing is saved until you press Save."
	play()


func setBottom(character) -> void:
	if(bottom != null && is_instance_valid(bottom) && bottom.get_parent() == self):
		bottom.queue_free()
	bottom = character


func onPenis(_index:int) -> void:
	for role in tops:
		givePenis(tops[role])
	play()


func onLength(value:float) -> void:
	for role in tops:
		var penis = tops[role].getBodypart(BodypartSlot.Penis)
		if(penis != null):
			penis.lengthCM = value
	for doll in dolls():
		if(doll.getCharacterID() != bottom):
			var penis = doll.getCharFromID(doll.getCharacterID()).getBodypart(BodypartSlot.Penis)
			if(penis != null):
				doll.setPenisScale(penis.getPenisScale())


func onTight(value:float) -> void:
	forceTight(value)


func onOwnTight() -> void:
	forceTight(-1.0)


func forceTight(value:float) -> void:
	var react:Dictionary = Driver.effectScript("detailed").REACT
	react["force"] = value


func onBelly(value:float) -> void:
	belly = value
	for doll in dolls():
		if(doll.getCharacterID() == bottom):
			doll.setPregnancy(belly)


func play() -> void:
	var args := {}
	for role in ROLES:
		args[role] = tops[role]
		args[ROLES[role]] = NAKED
	if(bottomRole.has(sceneID) || guessed.has(sceneID)):
		args[bottomRole.get(sceneID, guessed.get(sceneID))] = bottom
		var _was:bool = guessed.erase(sceneID)
		finding = -1
	else:
		finding = 0
		who.text = "Finding who is penetrated in " + sceneID + "..."
	var pose := "sex"
	if(fast):
		pose = "fast"
	if(state != ""):
		pose = state
	stage.play(sceneID, pose, args, true, true)
	cover.visible = finding >= 0
	if(finding < 0):
		dress()


func dress() -> void:
	var scene = stageScene()
	if(scene != null):
		var all:Array = dolls()
		for child in scene.get_children():
			var holds := false
			for doll in all:
				holds = holds || doll == child || child.is_a_parent_of(doll)
			if(child is Spatial && !holds):
				child.visible = showScene
	for doll in dolls():
		if(doll.getCharacterID() == bottom):
			doll.removeSlot(BodypartSlot.Penis)
			doll.setPregnancy(belly)
		else:
			doll.isOnlyPenis = !showTops
			doll.updateAlpha()


func _process(_delta):
	showTight()
	if(finding < 0):
		return
	finding += 1
	var owners := {}
	var report = reportOf()
	if(report != null):
		for r in report["relations"]:
			var owner:String = str(r["hole_owner"])
			owners[owner] = int(owners.get(owner, 0)) + 1
	var role := ""
	var best := 0
	var all:Array = []
	if(stageScene() != null):
		all = stageScene().getDolls()
	for owner in owners:
		var index:int = int(owner.trim_prefix("doll"))
		if(!owner.begins_with("doll") || index >= all.size() || all[index] == null || !is_instance_valid(all[index]) || int(owners[owner]) <= best):
			continue
		for one in tops:
			if(tops[one] == all[index].getCharacterID()):
				role = one
				best = int(owners[owner])
	if(role == "" && finding < FIND_FRAMES):
		return
	if(role == "" && report == null):
		guessed[sceneID] = "pc"
	else:
		if(role == ""):
			role = "pc"
		bottomRole[sceneID] = role
	who.text = "Shown: " + sceneID + ". Nothing is saved until you press Save."
	play()


func showTight() -> void:
	if(tightTag == null || !tightTag.is_visible_in_tree()):
		return
	var report = reportOf()
	var text := "Tightness: not used (Body tightness Off)"
	var from := " (the character's own)"
	if(float(Driver.effectScript("detailed").REACT["force"]) >= 0.0):
		from = " (the slider; Fixed tightness wins over it)"
	if(report != null && typeof(report["skins"]) == TYPE_ARRAY):
		for row in report["skins"]:
			if(typeof(row) == TYPE_DICTIONARY && row.has("tight")):
				text = "Tightness used: " + str(row["tight"]) + from
	tightTag.text = text


func stageScene():
	for child in stage.get_children():
		if(child.has_method("getDolls") && !child.is_queued_for_deletion()):
			return child
	return null


func dolls() -> Array:
	var scene = stageScene()
	if(scene == null):
		return []
	var out:Array = []
	for doll in scene.getDolls():
		if(doll != null && is_instance_valid(doll)):
			out.append(doll)
	return out


func reportOf():
	var scene = stageScene()
	if(scene == null || !scene.has_meta(Driver.META_REPORT)):
		return null
	var report = scene.get_meta(Driver.META_REPORT)
	if(typeof(report) != TYPE_DICTIONARY):
		return null
	return report


func topCharacter(role:String):
	var made = GlobalRegistry.createCharacter("TestPC")
	made.id = "insertionBulgesPreview_" + role
	add_child(made)
	givePenis(made)
	return made


func givePenis(character) -> void:
	if(penisBox.selected < 0):
		return
	var penis = GlobalRegistry.createBodypart(str(penisIDs[penisBox.selected]))
	if(penis == null):
		return
	character.giveBodypart(penis)
	penis.lengthCM = lengthSlider.value


func randomCharacter():
	var made = DynamicCharacter.new()
	made.id = "insertionBulgesPreview"
	add_child(made)
	var species:Array = []
	var all:Dictionary = GlobalRegistry.getAllSpecies()
	for id in all:
		if(all[id].canBeUsedForNPCType("inmate")):
			species.append(id)
	if(species.empty()):
		species = all.keys()
	made.npcSpecies = [RNG.pick(species)]
	made.npcGeneratedGender = NpcGender.generate()
	var gender = NpcGender.toNormalGender(made.npcGeneratedGender)
	if(gender == Gender.Male):
		made.npcThickness = RNG.randi_range(0, 60)
		made.npcFeminity = RNG.randi_range(0, 50)
	elif(gender == Gender.Female):
		made.npcThickness = RNG.randi_range(0, 110)
		made.npcFeminity = RNG.randi_range(50, 100)
	else:
		made.npcThickness = RNG.randi_range(0, 100)
		made.npcFeminity = RNG.randi_range(25, 75)
	for slot in BodypartSlot.getAll():
		var possible:Array = Bodypart.findPossibleBodypartIDs(slot, made, made.npcSpecies, made.npcGeneratedGender)
		var fullWeight:float = 0.0
		for pair in possible:
			fullWeight += max(0.0, pair[1])
		if(possible.empty() || !RNG.chance(fullWeight * 100.0)):
			continue
		var partID = RNG.pickWeightedPairs(possible)
		if(partID == null || str(partID) == ""):
			continue
		var part = GlobalRegistry.createBodypart(partID)
		if(part == null):
			continue
		made.giveBodypartUnlessSame(part)
		part.generateDataFor(made)
	made.applyRandomSkinAndColors()
	for slot2 in made.bodyparts:
		if(made.bodyparts[slot2] != null):
			made.bodyparts[slot2].generateRandomColors(made)
			made.bodyparts[slot2].generateRandomSkinIfCan(made)
	for one in made.getSpecies():
		var speciesObject = GlobalRegistry.getSpecies(one)
		if(speciesObject != null):
			speciesObject.onDynamicNpcCreation(made, {})
	made.updateNonBattleEffects()
	return made


func onDefaults() -> void:
	bulk = true
	for row in FoxLibOptions.OPTIONS:
		var id:String = str(row["id"])
		if(!controls.has(id)):
			continue
		var control = controls[id]
		var value = Settings.compiled(id)
		if(control is CheckBox):
			control.pressed = bool(value)
		elif(control is HSlider):
			control.value = float(value) * 100.0
		else:
			for i in range(row["values"].size()):
				if(str(row["values"][i][0]) == str(value) && !control.is_item_disabled(i)):
					control.select(i)
					onChoice(i, row)
	bulk = false
	showSections()


func onSave() -> void:
	var fox = Settings.foxLib()
	for id in touched:
		var shipped = Settings.compiled(id)
		if(fox != null && typeof(touched[id]) == typeof(shipped) && touched[id] == shipped):
			var _cleared:bool = fox.clear(id)
		else:
			var _stored:bool = Settings.store(id, touched[id])
	dropOverlay()
	refreshScreens(get_tree().root)
	queue_free()


func onCancel() -> void:
	dropOverlay()
	queue_free()


func _exit_tree():
	if(!closed):
		dropOverlay()


func dropOverlay() -> void:
	closed = true
	forceTight(-1.0)
	var overlay:Dictionary = Settings.OVERLAY
	for id in touched:
		overlay.erase(id)
	Settings.changed()


func refreshScreens(node:Node) -> void:
	var script = node.get_script()
	if(script != null && script.resource_path == FOX_SCREEN && node.is_visible_in_tree()):
		node.updateOptions()
	for child in node.get_children():
		refreshScreens(child)
