const Boot := preload("res://Bulge4/Boot.gd")
const DECLARED := {
"bulgeEffect": {
	"value": "detailed", "unit": "basic/medium/detailed", "owner": "Driver", "source": "PLANS/1-plan-4.0 decision 11",
	"note": "the drawing: a new id, so every player starts on Detailed (3.4's bulgePipeline is not read)",
},
"bulgeSizeModifier": {
	"value": 0.6, "unit": "0..1", "owner": "Basic, Medium", "source": "the published 3.4",
	"note": "how big Basic's and Medium's bulges are; Detailed: not yet (decision 12)",
},
"bulgeShapeFidelity": {
	"value": 0.8, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "how much the bump copies the cock's girth along it (Intent.shapeGain, normalisedShape)",
},
"bulgeLag": {
	"value": true, "unit": "on/off", "owner": "Medium (Spring)", "source": "the published 3.4",
	"note": "soft motion: each bump's size follows a damped spring, and fades out after the cock leaves",
},
"bulgePregnantBelly": {
	"value": true, "unit": "on/off", "owner": "Medium (Belly)", "source": "PLANS/1-plan-4.0 phase 6",
	"note": "3.4's bulgeBellyVariant swell (on) or off: a pregnant belly swells along the bump",
},
"bulgeOtherHalfAdd": {
	"value": 0.5, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "Knots and ridges: the facing half's own variation added on top, its bumps stand out more",
},
"bulgeLipAmount": {
	"value": 0.2, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "Opening at the hole: how far the skin at the entry opens round the shaft, a share of its girth there",
},
"bulgeDirection": {
	"value": "blend", "unit": "blend/shaft/belly/torso", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "which way the band runs: between hole and shaft, along the shaft, along the belly's edge, along the torso",
},
"bulgeLagDeflate": {
	"value": 0.25, "unit": "0..1 speed", "owner": "Medium (Spring)", "source": "the published 3.4",
	"note": "Settle speed: how fast a bump goes down again (soft motion)",
},
"bulgeTorsoArch": {
	"value": 0.5, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "a cock longer than the body: how much its extra length raises the bump's middle (0: it just stops)",
},
"bulgeOralSize": {
	"value": 0.6, "unit": "0..1", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "Throat size: bulgeSizeModifier for the throat",
},
"bulgeOralSwallow": {
	"value": false, "unit": "on/off", "owner": "Medium (Intent)", "source": "the published 3.4",
	"note": "a narrowing ring runs down the throat every few seconds while the cock rests deep",
},
"bulgeHidePenis": {
	"value": true, "unit": "on/off", "owner": "BulgeDoll.applyShaftClip (every effect)", "source": "PLANS/2-simplest",
	"debug": true,
	"note": "the part of the cock inside the body is hidden; off, it shows (players who want to see it turn the mod off)",
},
"bulgesEnabled": {
	"value": true, "unit": "on/off", "owner": "PRESENT", "source": "PLANS/PIANO1",
	"note": "no swelling when off; bulgeHidePenis still clips (Driver: Basic at size 0)",
},
"bulgeFollowBody": {
	"value": 0.7, "unit": "0..1", "owner": "PRESENT", "source": "PLANS/PIANO1 phase E",
	"note": "past the entry the cock turns to run along the penetrated body (lab bend): 0 straight",
},
"bulgeBelly": {
	"value": 1.0, "unit": "0..1", "owner": "PRESENT", "source": "PLANS/PIANO1 phase E",
	"note": "inside the body the cock runs toward the belly (lab belly): 0 the body's middle, 1 along the belly",
},
"bulgeNeck": {
	"value": "stop", "unit": "off/stop/through", "owner": "PRESENT (BodyDeform stop_at_neck, through)", "source": "PLANS/PIANO1 phase E; v4.0 PLANS/20-all-the-way-through P6",
	"note": "a cock longer than the torso: off = runs out of the top; stop = bows outward against the neck (lab stop_at_neck); through = goes on past the neck and out of the mouth",
},
"bulgeThroughHead": {
	"value": 0.5, "unit": "0..1", "owner": "PRESENT (RubberSkin.THROUGH)", "source": "v4.0 PLANS/20-all-the-way-through P4",
	"note": "All the way through: how far the head may turn toward the cock, 1 = 135 degrees (a third of it the neck's)",
},
"bulgeThroughSqueeze": {
	"value": 0.85, "unit": "0..1", "owner": "PRESENT (RubberSkin.THROUGH)", "source": "v4.0 PLANS/20-all-the-way-through P5; 0.85 the owner, PLANS/24 F3",
	"note": "All the way through: the cock narrower at the lips and wider just past them, 0 = as it is",
},
"bulgeNeckSoft": {
	"value": 0.5, "unit": "0..1 = 0..3 radii", "owner": "PRESENT (BodyDeform._press_soft, NECK_PRESS.ease)", "source": "v4.0 PLANS/28 (the owner, 2026-10-16: Compression)",
	"note": "Stop at the neck: how far past the neck the bow grows to its height, the cock squeezed meanwhile; 0 = the bow at once, as before",
},
"bulgeNeckTip": {
	"value": 1.0, "unit": "0..1", "owner": "PRESENT (BodyDeform._squeezed)", "source": "v4.0 PLANS/28 B (the owner: on by default)",
	"note": "Stop at the neck: the squeeze gathered toward the tip, the cock wider there; 0 = even along it",
},
"bulgeNeckBendTip": {
	"value": 0.0, "unit": "0..1", "owner": "PRESENT (BodyDeform._press_soft, _bowed)", "source": "v4.0 PLANS/28 D",
	"note": "Stop at the neck: the bow born near the tip, its peak moving to the middle as it grows; 0 = at the middle",
},
"bulgeNeckKeep": {
	"value": 0.0, "unit": "0..1 = 0..60 %", "owner": "PRESENT (BodyDeform._press_soft, NECK_PRESS.keep)", "source": "v4.0 PLANS/28 C",
	"note": "Stop at the neck: that share of the cock past the neck always squeezed, the bow lower",
},
"bulgeNeckBounce": {
	"value": 0.0, "unit": "0..1 = gain 0..6", "owner": "PRESENT (BodyDeform._bounce, NECK_PRESS.bounce)", "source": "v4.0 PLANS/28 E",
	"note": "Stop at the neck: a squeeze that overshoots as the tip hits the neck, by how fast it comes, and settles; 0 = none",
},
"bulgeDirectAt": {
	"value": 0.5, "unit": "0..1 = share of the cock's length", "owner": "CURVE (CockCurve.directOf, Driver opts.direct_at)", "source": "RESEARCH/AngleLab 2",
	"note": "with bulgeDirectionMode belly: how far from the hole, as a share of the cock's length, it meets the belly",
},
"bulgeReact": {
	"value": "off", "unit": "off/character/fixed", "owner": "PRESENT (RubberSkin.REACT)", "source": "PLANS/4-body-reacts experiment 1",
	"note": "how tight the penetrated body is: character = read from it (a cock too long or thick for a tight hole, or pain: sharp and high; a loose or trained hole, or lust: soft and low), fixed = bulgeTightness",
},
"bulgeTightness": {
	"value": 0.5, "unit": "0..1", "owner": "PRESENT (RubberSkin.REACT)", "source": "PLANS/4-body-reacts experiment 1",
	"note": "the tightness used when bulgeReact is fixed: 0 loose, 0.5 the rubber skin's own options, 1 tight",
},
"bulgeLingerOn": {
	"debug": true,
	"value": false, "unit": "on/off", "owner": "PRESENT (RubberSkin.lingering)", "source": "PLANS/4-body-reacts experiment 2",
	"note": "the deepest point of each stroke stays swollen and relaxes over bulgeLinger; when the cock leaves the bulge fades out",
},
"bulgeLinger": {
	"debug": true,
	"value": 0.5, "unit": "0..1 = 0..2 s", "owner": "PRESENT (RubberSkin.lingering)", "source": "PLANS/4-body-reacts experiment 2",
	"note": "how long the bulge lingers, with bulgeLingerOn",
},
"bulgePressMode": {
	"value": "off", "unit": "off/pressure/belly/outline/tip", "owner": "PRESENT (BodyDeform._press, PRESS)", "source": "RESEARCH/CurveLab PLAN 8",
	"note": "a bulge before the cock reaches the skin: pressure (A, a soft hill over the cock), belly (B, the belly in front of the tip swells round), outline (C, a low ridge in the cock's shape), tip (D, a lump at the tip)",
},
"bulgePress": {
	"value": 0.5, "unit": "0..1", "owner": "PRESENT (BodyDeform.PRESS.most)", "source": "RESEARCH/CurveLab PLAN 8 A",
	"note": "bulgePressMode's strength: its height at the skin, x PRESS.most / outline / belly cock radii",
},
"bulgePressReach": {
	"value": 0.5, "unit": "0..1 = 1..5 radii", "owner": "PRESENT (BodyDeform._sleeve_poly)", "source": "RESEARCH/CurveLab PLAN 8 A",
	"note": "how far inside the skin the cock's edge starts pressing it: lerp(1, 5) cock radii, 0.5 = 3",
},
"bulgeDirectionMode": {
	"value": "belly", "unit": "animated/sliders/feel/belly", "owner": "PRESENT (BodyDeform._bend, _canal, _arc_to)", "source": "PLANS/14-canal; feel by default: the owner, 2026-10-16 (Help with Reposition, as tested); belly by default: the owner, 2026-10-19 (RESEARCH/AngleLab 2)",
	"note": "how the cock's path inside is found: animated (straight, as the game draws it), sliders (bulgeFollowBody and bulgeBelly as always), feel (Auto: canal, RESEARCH/CurveLab: the hole's own canal and one arc kept per action, Bulge4/Curve/CockCurve; help moves the bodies toward the way the curve bends least), belly (Auto: belly, RESEARCH/AngleLab: as feel, but the cock curves from the hole to meet the belly's skin bulgeDirectAt of its length away, then the skin; help turns the bodies onto it). A saved canal, layers, one or body (CurveLab's tried methods) reads as feel (Driver)",
},
"bulgeReposeOn": {
	"value": true, "unit": "on/off", "owner": "Driver (opts.repose)", "source": "PLANS/19 Move the bodies (the owner 2026-10-19)",
	"note": "with bulgeDirectionMode feel or belly: the bodies moved so the cock comes in its way (ReposeScene); off: as animated, the cock straightened along its animated way",
},
"bulgeReposeCrowd": {
	"value": false, "unit": "on/off", "owner": "RubberSkin.run (opts.repose_crowd)", "source": "the owner 2026-10-20 (off by default, until SexDP and the scenes with more than two dolls are fixed)",
	"note": "bulgeReposeOn in a scene with more than two dolls too; off: there opts.repose is off (the cocks straightened along their animated way, as Move the bodies off)",
},
"bulgeStrokeStyle": {
	"value": "game", "unit": "game/natural/slow/custom", "owner": "Driver (STROKE_STYLES, strokeOpts)", "source": "PLANS/46 (the owner 2026-10-22: one simple control; RESEARCH/StrokeLab K30's corrections always on); PLANS/50: As the game by default",
	"note": "with bulgeReposeOn: the strokes. game = as animated (no clock), natural / slow = Driver.STROKE_STYLES on our clock (StrokeSplit) with K30's corrections, custom = the bulgeStroke* sliders",
},
"bulgeStrokeLength": {
	"value": 0.7, "unit": "0..1", "owner": "Driver.strokeOpts (opts.repose_travel = 2 x this)", "source": "PLANS/46",
	"note": "bulgeStrokeStyle custom: the stroke's length (0.5 = as animated)",
},
"bulgeStrokeStrength": {
	"value": 0.5, "unit": "0..1", "owner": "Driver.strokeOpts (Intensity = Meet = this, Stay = 1 - this)", "source": "PLANS/46",
	"note": "bulgeStrokeStyle custom: soft and lingering .. a hit, met by the partner",
},
"bulgeStrokeVariety": {
	"value": 0.5, "unit": "0..1", "owner": "Driver.strokeOpts (Variation = Deeper strokes = this)", "source": "PLANS/46",
	"note": "bulgeStrokeStyle custom: every stroke the same .. builds to a deeper one",
},
"bulgeStrokeRhythm": {
	"value": 0.6, "unit": "0..1", "owner": "Driver.strokeOpts (opts.stroke_stretch)", "source": "PLANS/46 (K30's split_follow)",
	"note": "bulgeStrokeStyle custom: the clock's stretch = the stroke's length factor ^ this (0: the animation's time, 1: its speed kept)",
},
"bulgeStrokeWarm": {
	"value": true, "unit": "on/off", "owner": "Driver.strokeOpts (opts.repose_warm 6 s)", "source": "PLANS/46 (PLANS/41's 60 %)",
	"note": "bulgeStrokeStyle natural, slow, custom: an engagement's first strokes go only part of the way deep, the whole stroke after 6 s",
},
"bulgeReposeMost": {
	"debug": true,
	"value": 0.5, "unit": "0..1", "owner": "PRESENT (ReposeScene.REPOSE.most)", "source": "RESEARCH/PENETRATION_DIRECTION",
	"note": "bulgeRepose: the longest move of the pelvis, x REPOSE.most shaft radii (0.5 = 3 radii)",
},
"bulgeReposeArch": {
	"debug": true,
	"value": 0.0, "unit": "0..1", "owner": "PRESENT (ReposeScene.ARCH)", "source": "RESEARCH/ReposeLab PLAN N1",
	"note": "bulgeRepose: the penetrated's pelvis pushed up (head down, shoulders rising), x ARCH.most radians; 0 none",
},
"bulgeReposeCurve": {
	"debug": true,
	"value": 0.5, "unit": "0..1", "owner": "PRESENT (ReposeScene.CURVE)", "source": "RESEARCH/ReposeLab PLAN N1",
	"note": "bulgeRepose: the penetrated's torso curve, 0 .. 1 = arched back .. C, 0.5 = as animated",
},
"bulgeBendMode": {
	"value": "push", "unit": "follow/push", "owner": "PRESENT (CockCurve.pushShare)", "source": "RESEARCH/CurveLab PLAN 10; push: the owner, 2026-10-16",
	"note": "Sliders and Auto: canal: follow, the curve always; push, the cock goes in straight, bends toward the curve only once its tip pushes the skin, straightens on the way out",
},
"bulgePushHard": {
	"value": 0.5, "unit": "0..1", "owner": "PRESENT (CockCurve.PUSH.give)", "source": "RESEARCH/CurveLab PLAN 10",
	"note": "bulgeBendMode push: how hard the belly is: 1 the tip stops at the skin, 0 it pushes the skin out PUSH.give cock radii",
},
"bulgePushRelax": {
	"value": 0.5, "unit": "0..1 = 1..6 radii, 0.15..1.2 s", "owner": "PRESENT (CockCurve.PUSH.relax, PUSH.spring)", "source": "RESEARCH/CurveLab PLAN 10; RESEARCH/PushLab (the spring)",
	"note": "bulgeBendMode push: how quickly the cock changes shape: pushing, it straightens over lerp(1, 6) cock radii pushed; the push over, it goes back to the curve with a time constant of lerp(0.15, 1.2) s",
},
"bulgeCanalBelly": {
	"value": 1.0, "unit": "0..1", "owner": "PRESENT (BodyDeform._canal, CANAL.reach)", "source": "PLANS/14-canal (the owner, 2026-10-06; 100 % by default: the owner, 2026-10-15)",
	"note": "bulgeDirectionMode canal: the canal's deep part drawn toward the belly skin (1 = the cock's axis on the skin, its edge out: the biggest bulge a curve gives)",
},
"bulgeSkinShadeStrength": {
	"value": 0.1, "unit": "0..1", "owner": "PRESENT", "source": "RESEARCH/MeshMergeLab PLAN point 1; 10 %: the owner, 2026-10-16",
	"note": "how visible that shade is (the lab harness's 60%; past 60% it gets darker faster, ~90% at 100%)",
},
"bulgeSkinShadeFade": {
	"value": 0.5, "unit": "0..1 = 0..3 shaft radii", "owner": "PRESENT (BodyDeform shade_base_fade)", "source": "PLANS/37 (the owner, 2026-10-20: 1.5 radii, adjustable 0..3)",
	"note": "the shade eases in from the shaft's base over 3 x this shaft radii (0: the old sharp edge across the cock)",
},
"bulgeSkinShadeStyle": {
	"value": "filled", "unit": "none, or soft/filled/halo/xray, each also _outline", "owner": "PRESENT", "source": "RESEARCH/MeshMergeLab PLAN 8d; none: PLANS/1-plan-4.0 decision 4; filled: the owner, 2026-10-16",
	"note": "the cock's shape seen through the skin, over the torso: none (no shade), soft (a soft dark inside, a light rim), filled (an even dark silhouette), halo (a blurred one), xray (the cock's own drawing, darkened); _outline adds the cock's drawn outline",
},
"bulgeSkinShadeOnTop": {
	"value": true, "unit": "on/off", "owner": "PRESENT", "source": "RESEARCH/MeshMergeLab PLAN 8c",
	"note": "the shade is drawn over everything (head, arms, legs, other dolls), not only over the torso",
},
}
const OVERLAY := {}
const CACHE := {"loaded": false, "settings": {}, "asked": false, "fox": null}
const CHANGED := {"n": 0}
static func changed() -> void:
	var counter:Dictionary = CHANGED
	counter["n"] = int(counter["n"]) + 1
static func overlay(name:String, given) -> void:
	var vetted:Array = vetSetting(name, given)
	if(!vetted[0].empty()):
		Boot.loud("Settings: '" + name + "' NOT overlaid, nothing changed - " \
			+ PoolStringArray(vetted[0]).join("; ") + ".")
		return
	var o:Dictionary = OVERLAY
	o[name] = vetted[1]
	changed()
static func declaration(name:String):
	return DECLARED.get(name)
static func gles2() -> bool:
	return OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2
static func compiled(name:String):
	if(DECLARED.has(name)):
		return DECLARED[name]["value"]
	return null
static func vetSetting(name:String, given) -> Array:
	var bad:Array = []
	if(!DECLARED.has(name)):
		bad.append("'" + name + "' is not one of this mod's settings (" \
			+ PoolStringArray(DECLARED.keys()).join(", ") + ")")
		return [bad, null]
	var declared = DECLARED[name]["value"]
	if(typeof(declared) == TYPE_REAL && typeof(given) == TYPE_INT):
		given = float(given)
	if(typeof(given) != typeof(declared)):
		bad.append("'" + name + "' wants " + typename(declared) + ", got " + typename(given))
		return [bad, null]
	return [bad, given]
static func typename(value) -> String:
	match typeof(value):
		TYPE_BOOL:
			return "a bool"
		TYPE_INT:
			return "an int"
		TYPE_REAL:
			return "a float"
		TYPE_STRING:
			return "a string"
	return "a value of type " + str(typeof(value))
const PATH := "user://bulge4_settings.json"
const FORMAT_VERSION := 1
const KEY_FORMAT := "format"
const KEY_SETTINGS := "settings"
const LEGAL_KEYS := [KEY_FORMAT, KEY_SETTINGS]
static func parse(text:String, where:String = PATH):
	var parsed:JSONParseResult = JSON.parse(text)
	if(parsed.error != OK):
		Boot.loud("Settings: " + where + " is not valid JSON - line " + str(parsed.error_line) + ": " \
			+ str(parsed.error_string) + ". NOTHING IS APPLIED and no setting is stored this run;" \
			+ " every setting falls back to the compiled default. Delete the file or" \
			+ " fix it - it is never partially read.")
		return null
	var doc = parsed.result
	var bad:PoolStringArray = PoolStringArray()
	if(typeof(doc) != TYPE_DICTIONARY):
		bad.append("the file is not a JSON object")
		return refuse(where, bad)
	for key in doc:
		if(!LEGAL_KEYS.has(key)):
			bad.append("unknown top-level key '" + str(key) + "' - legal keys are " \
				+ PoolStringArray(LEGAL_KEYS).join(", "))
	if(typeof(doc.get(KEY_FORMAT, null)) != TYPE_INT && typeof(doc.get(KEY_FORMAT, null)) != TYPE_REAL):
		bad.append("\"" + KEY_FORMAT + "\" is missing or is not a number - a settings file says which" \
			+ " build wrote it")
	elif(float(doc[KEY_FORMAT]) != float(FORMAT_VERSION)):
		bad.append("\"" + KEY_FORMAT + "\" is " + str(doc[KEY_FORMAT]) + " and this build reads " \
			+ str(FORMAT_VERSION))
	if(typeof(doc.get(KEY_SETTINGS, null)) != TYPE_DICTIONARY):
		bad.append("\"" + KEY_SETTINGS + "\" is missing or is not an object")
		return refuse(where, bad)
	var wanted:Dictionary = {}
	for name in doc[KEY_SETTINGS]:
		if(declaration(str(name)) == null):
			Boot.loud("Settings: " + where + " holds '" + str(name) + "', which this build has no" \
				+ " setting for. IGNORED; every other setting is read.")
			continue
		var vetted:Array = vetSetting(str(name), doc[KEY_SETTINGS][name])
		for complaint in vetted[0]:
			bad.append(str(complaint))
		if(vetted[0].empty()):
			wanted[str(name)] = vetted[1]
	if(!bad.empty()):
		return refuse(where, bad)
	return wanted
static func refuse(where:String, bad:PoolStringArray):
	Boot.loud("Settings: " + where + " REFUSED, NOTHING APPLIED - every setting falls back to the" \
		+ " compiled default this run. " + str(bad.size()) + " problem(s): " \
		+ bad.join("; ") + ". Delete the file or fix it; it is never partially read.")
	return null
static func loadFrom(path:String) -> Dictionary:
	var f := File.new()
	if(!f.file_exists(path)):
		return {}
	if(f.open(path, File.READ) != OK):
		Boot.loud("Settings: cannot open " + path + " for reading. Nothing applied; every setting" \
			+ " falls back to the compiled default this run.")
		return {}
	var text:String = f.get_as_text()
	f.close()
	var wanted = parse(text, path)
	if(wanted == null):
		if(Directory.new().rename(path, path + ".bak") == OK):
			Boot.loud("Settings: the refused " + path + " was moved to " + path + ".bak.")
		return {}
	return wanted
const FOXLIB_PATH := "res://Modules/InsertionBulges/FoxLibOptions.gd"
static func foxLib():
	if(!CACHE["asked"]):
		CACHE["asked"] = true
		var adapter = load(FOXLIB_PATH)
		if(adapter != null && adapter.live()):
			CACHE["fox"] = adapter
	return CACHE["fox"]
static func stored(fox = foxLib()) -> Dictionary:
	if(fox != null):
		return fox.stored()
	if(!CACHE["loaded"]):
		CACHE["loaded"] = true
		CACHE["settings"] = loadFrom(PATH)
	return CACHE["settings"]
static func write(settings:Dictionary, path:String = PATH) -> bool:
	var doc := {}
	doc[KEY_FORMAT] = FORMAT_VERSION
	doc[KEY_SETTINGS] = settings
	var f := File.new()
	if(f.open(path, File.WRITE) != OK):
		Boot.loud("Settings: cannot open " + path + " for writing. Nothing written and nothing" \
			+ " changed - the setting you just set is NOT saved and will not survive a restart.")
		return false
	f.store_string(JSON.print(doc, "  ", true))
	f.close()
	return true
static func store(name:String, given, fox = foxLib()) -> bool:
	var vetted:Array = vetSetting(name, given)
	if(!vetted[0].empty()):
		Boot.loud("Settings: '" + name + "' NOT stored, nothing changed and nothing written - " \
			+ PoolStringArray(vetted[0]).join("; ") + ".")
		return false
	if(fox != null):
		return fox.store(name, vetted[1])
	var next:Dictionary = stored(fox).duplicate()
	next[name] = vetted[1]
	if(!write(next)):
		return false
	CACHE["settings"] = next
	changed()
	return true
const OLD_FEEL := ["canal", "layers", "one", "body"]
static func directionMode() -> String:
	var direction:String = str(value("bulgeDirectionMode"))
	if(OLD_FEEL.has(direction)):
		return "feel"
	return direction
static func value(name:String):
	var declared = declaration(name)
	if(declared == null):
		Boot.loud("Settings: no setting named '" + name + "'. Add it to DECLARED in" \
			+ " Modules/InsertionBulges/Settings.gd, or fix the name.")
		return null
	if(OVERLAY.has(name)):
		return OVERLAY[name]
	if(bool(declared.get("debug", false))):
		return declared["value"]
	var mine:Dictionary = stored()
	if(mine.has(name)):
		return mine[name]
	return declared["value"]
