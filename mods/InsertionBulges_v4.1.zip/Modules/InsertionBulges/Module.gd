extends Module
const Boot := preload("res://Bulge4/Boot.gd")
const FoxLibOptions := preload("res://Modules/InsertionBulges/FoxLibOptions.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
func _init():
	id = "InsertionBulges"
	author = "xrob1"
func preInit():
	var _printed:bool = Boot.sayBootLineOnce()
func onFoxLibModInit(foxModuleAPI):
	if(!Boot.mayRun("onFoxLibModInit")):
		return
	var _ids:Array = FoxLibOptions.declare(foxModuleAPI, self)
	var tree = Engine.get_main_loop()
	if(Settings.gles2() && tree is SceneTree && !tree.is_connected("node_added", self, "onNodeAdded")):
		var _ok = tree.connect("node_added", self, "onNodeAdded")
const FOX_BUTTON := "res://Modules/FoxLib/UI/FoxLibOptionButtonType.gd"
func onGles2Note(_value = null):
	pass
func onNodeAdded(node:Node):
	var script = node.get_script()
	if(script != null && script.resource_path == FOX_BUTTON):
		call_deferred("redNote", node)
func redNote(node):
	if(is_instance_valid(node) && str(node.get("id")) == FoxLibOptions.foxId({"id": FoxLibOptions.GLES2_NOTE_ID}) \
			&& node.has_node("Label")):
		node.get_node("Label").add_color_override("font_color", FoxLibOptions.GLES2_RED)
const FOX_SCREEN := "res://Modules/FoxLib/UI/FoxLibModOptionsScreen.gd"
func onOptionChanged(_value):
	Settings.changed()
	if(!FoxLibOptions.refreshShown()):
		return
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		redrawScreens(tree.root)
func redrawScreens(node:Node) -> void:
	var script = node.get_script()
	if(script != null && script.resource_path == FOX_SCREEN && node.is_visible_in_tree()):
		node.call_deferred("updateOptions")
	for child in node.get_children():
		redrawScreens(child)
func onRestoreDefaults(_value = null):
	var _cleared:int = FoxLibOptions.restoreDefaults()
	onOptionChanged(null)
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		redrawScreens(tree.root)
func onTestBench(_value = null):
	var tree = Engine.get_main_loop()
	if(tree is SceneTree):
		tree.root.add_child(load("res://Modules/InsertionBulges/TestBench.gd").new())
