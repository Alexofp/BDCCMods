const Boot := preload("res://Bulge4/Boot.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const T_BOOL := "boolean"
const T_PERCENT := "slider"
const T_CHOICE := "choice"
const T_BUTTON := "button"
const CAT_MAIN := "Insertion Bulges"
const CAT_MEDIUM := "Insertion Bulges: Medium"
const CAT_EXPERIMENTS := "Insertion Bulges: Advanced"
const CATEGORIES := [CAT_MAIN, CAT_MEDIUM, CAT_EXPERIMENTS]
const RESTORE_ID := "bulgeRestore"
const GLES2_NOTE_ID := "bulgeGles2Note"
const GLES2_TITLE := "Your game runs on GLES2: only Basic works"
const GLES2_TEXT := "Your game runs on GLES2, so only the Basic effect can be drawn: Medium, Detailed and the Advanced" \
	+ " settings need GLES3. To use them: the game's Options, Display, Renderer: GLES3, then restart the game."
const GLES2_RED := Color(1.0, 0.35, 0.35)
const TESTBENCH_ID := "bulgeTestBench"
const ID_PREFIX := "v4_"
const OPTIONS := [
{
	"id": TESTBENCH_ID, "cat": CAT_MAIN, "type": T_BUTTON, "advanced": false, "on": "onTestBench",
	"title": "Try it on characters",
	"desc": "Opens a window with two characters in a sex pose and every option here: change them and see the bulge" \
		+ " at once, then Save or Cancel.",
},
{
	"id": "bulgeEffect", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": false,
	"values": [["basic", "Basic"], ["medium", "Medium"], ["detailed", "Detailed"]],
	"title": "Effect",
	"desc": "How the bulge is drawn. Basic: a plain swelling on the belly or the throat, nothing more. Medium: the bump copies the cock's shape and moves" \
		+ " softly. Detailed (recommended): the body's own outline stretches over the cock. Each effect's settings are" \
		+ " in its own section, shown with FoxLib's \"Show advanced mod options\".",
},
{
	"id": GLES2_NOTE_ID, "cat": CAT_MAIN, "type": T_BUTTON, "advanced": false, "gles2": true, "on": "onGles2Note",
	"title": GLES2_TITLE, "desc": GLES2_TEXT,
},
{
	"id": "bulgeSizeModifier", "cat": CAT_MAIN, "type": T_PERCENT, "advanced": false, "when": ["bulgeEffect", ["basic", "medium"]],
	"title": "Bulge size",
	"desc": "How big bulges are (Basic and Medium; Detailed follows the cock's own thickness). 0% hides them.",
},
{
	"id": "bulgeShapeFidelity", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Cock shape",
	"desc": "How much the bulge copies the cock's own shape (its knot, its flare). 0% = a smooth round bump.",
},
{
	"id": RESTORE_ID, "cat": CAT_MAIN, "type": T_BUTTON, "advanced": false, "on": "onRestoreDefaults",
	"title": "Restore recommended settings",
	"desc": "Puts every Insertion Bulges option back to its recommended value.",
},
{
	"id": "bulgeLag", "cat": CAT_MEDIUM, "type": T_BOOL, "advanced": true,
	"title": "Soft motion",
	"desc": "The bulge grows, shrinks and wobbles softly instead of following the cock at once.",
},
{
	"id": "bulgePregnantBelly", "cat": CAT_MEDIUM, "type": T_BOOL, "advanced": true,
	"title": "Pregnant belly",
	"desc": "A pregnant belly swells where the cock pushes inside it.",
},
{
	"id": "bulgeOtherHalfAdd", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Knots and ridges",
	"desc": "Makes knots and ridges stand out more on the bulge.",
},
{
	"id": "bulgeLipAmount", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Opening at the hole",
	"desc": "The skin round the hole opens around the cock and is pulled out with it. 0% is off.",
},
{
	"id": "bulgeDirection", "cat": CAT_MEDIUM, "type": T_CHOICE, "advanced": true,
	"values": [["blend", "Between hole and cock"], ["shaft", "Along the cock"],
		["belly", "Along the belly"], ["torso", "Along the body"]],
	"title": "Bulge direction",
	"desc": "Which way the bulge runs in the body: along the cock, along the belly, straight up the" \
		+ " body, or between the hole and the cock (recommended).",
},
{
	"id": "bulgeLagDeflate", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Settle speed",
	"desc": "How fast a bulge goes down. Lower lets it linger after a pose change. Needs Soft motion on.",
},
{
	"id": "bulgeTorsoArch", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Torso stretch",
	"desc": "A cock longer than the body: its extra length bunches up and the bulge swells in an arch," \
		+ " most in the middle. 0% is off: the bulge just stops at the chest.",
},
{
	"id": "bulgeOralSize", "cat": CAT_MEDIUM, "type": T_PERCENT, "advanced": true,
	"title": "Throat size",
	"desc": "How big the throat bulge is. 0% hides it.",
},
{
	"id": "bulgeOralSwallow", "cat": CAT_MEDIUM, "type": T_BOOL, "advanced": true,
	"title": "Swallowing",
	"desc": "While the cock rests deep in the throat, the throat gives a small swallow every few seconds.",
},
{
	"id": "bulgesEnabled", "cat": CAT_MAIN, "type": T_BOOL, "advanced": false,
	"title": "Show bulges",
	"desc": "The body swells where a cock is inside it. Off: no swelling at all (the part of the cock inside the body stays hidden).",
},
{
	"id": "bulgeSkinShadeStrength", "cat": CAT_MAIN, "type": T_PERCENT, "advanced": true, "when": ["bulgeEffect", ["detailed"]],
	"title": "Shade strength",
	"desc": "How visible the under-skin shade is. 0% = not at all, 100% = very dark.",
},
{
	"id": "bulgeSkinShadeFade", "cat": CAT_MAIN, "type": T_PERCENT, "advanced": true, "when": ["bulgeEffect", ["detailed"]],
	"title": "Shade fade",
	"desc": "How softly the shade starts at the cock's base. 0% = no fade, a sharp edge. 100% = the longest fade," \
		+ " over one and a half cock widths. 50% by default.",
},
{
	"id": "bulgeSkinShadeStyle", "cat": CAT_MAIN, "type": T_CHOICE, "advanced": true, "when": ["bulgeEffect", ["detailed"]],
	"values": [["none", "None"], ["soft", "Soft"], ["soft_outline", "Soft + outline"], ["filled", "Filled"],
		["filled_outline", "Filled + outline"], ["halo", "Halo"], ["halo_outline", "Halo + outline"],
		["xray", "X-ray"], ["xray_outline", "X-ray + outline"]],
	"title": "Shade style",
	"desc": "How the cock shows through the skin. None: it does not. Soft: a soft shadow with a light rim. Filled: an even dark shape." \
		+ " Halo: a blurred shadow. X-ray: the cock's own drawing, darker. + outline: the cock's drawn outline too.",
},
{
	"id": "bulgeSkinShadeOnTop", "cat": CAT_MAIN, "type": T_BOOL, "advanced": true, "when": ["bulgeEffect", ["detailed"]],
	"title": "Shade over everything",
	"desc": "The under-skin shade shows over the head, arms, legs and other characters too, not only over the body.",
},
{
	"id": "bulgeNeck", "cat": CAT_EXPERIMENTS, "type": T_CHOICE, "advanced": true,
	"values": [["off", "Off"], ["stop", "Stop at the neck"], ["through", "All the way through"]],
	"title": "Cock longer than the body",
	"desc": "Experimental. What a cock longer than the torso does (not in oral scenes). Off: it runs out of the top. Stop at the neck:" \
		+ " pushed against the neck it bows out, like a wire, and straightens as it pulls back. All the way through:" \
		+ " a cock long enough comes out of the mouth, which opens; the head tilts back toward it.",
},
{
	"id": "bulgeThroughHead", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["through"]],
	"title": "All the way through: head tilt",
	"desc": "How far the head tilts back, carried by the neck, to line the mouth up with the cock. 0% = the head stays" \
		+ " as animated, 100% = thrown far back (up to 135 degrees).",
},
{
	"id": "bulgeThroughSqueeze", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["through"]],
	"title": "All the way through: squeeze",
	"desc": "The lips squeeze the cock coming out: narrower at the lips, a little wider just past them. 0% = none," \
		+ " 100% = half as wide at the lips.",
},
{
	"id": "bulgeNeckSoft", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["stop"]],
	"title": "Stop at the neck: softness",
	"desc": "How gently the cock bends against the neck. 0% = it bows out at once, as soon as the tip touches. More = the" \
		+ " bow grows slowly as it pushes on, the cock squeezing shorter and thicker meanwhile. 100% = the softest.",
},
{
	"id": "bulgeNeckTip", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["stop"]],
	"title": "Stop at the neck: squeeze at the tip",
	"desc": "Where the cock squeezes as it presses against the neck. 0% = evenly along it. 100% = mostly near the tip," \
		+ " which gets thicker there.",
},
{
	"id": "bulgeNeckBendTip", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["stop"]],
	"title": "Stop at the neck: bend from the tip",
	"desc": "Where the bend starts. 0% = in the middle. 100% = near the tip, where it presses, then spreading to the" \
		+ " middle as it pushes on.",
},
{
	"id": "bulgeNeckKeep", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["stop"]],
	"title": "Stop at the neck: always squeezed",
	"desc": "How much of the cock pushed past the neck stays squeezed instead of bending. 0% = none (it all bends in" \
		+ " the end). 100% = most of it: a lower bend, a shorter, thicker cock.",
},
{
	"id": "bulgeNeckBounce", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeNeck", ["stop"]],
	"title": "Stop at the neck: bounce",
	"desc": "A quick extra squeeze when the tip hits the neck, stronger the faster it arrives, then it settles." \
		+ " 0% = none.",
},
{
	"id": "bulgeReact", "cat": CAT_EXPERIMENTS, "type": T_CHOICE, "advanced": true,
	"values": [["off", "Off"], ["character", "From the character"], ["fixed", "Fixed"]],
	"title": "Body tightness",
	"desc": "Experimental. How tightly the skin holds the cock. From the character: a cock too big (long or thick) for a tight hole, or" \
		+ " a character in pain, makes a sharp, high bulge; a loose or well-used hole, or an aroused character, a soft," \
		+ " low one. Fixed: always the value of Fixed tightness. Off: as it always was.",
},
{
	"id": "bulgePressMode", "cat": CAT_EXPERIMENTS, "type": T_CHOICE, "advanced": true,
	"values": [["off", "Off"], ["pressure", "Pressure"], ["belly", "Full belly"], ["outline", "Cock outline"], ["tip", "Tip bump"]],
	"title": "Something inside",
	"desc": "Experimental. A swelling that shows something is inside even before the cock reaches the skin. Pressure:" \
		+ " the skin over the cock rises softly, more the nearer it comes. Full belly: the belly in front of the tip" \
		+ " swells round, more the deeper the cock is. Cock outline: a low ridge in the cock's own shape. Tip bump: a" \
		+ " small lump where the tip is, moving with each thrust.",
},
{
	"id": "bulgeDirectionMode", "cat": CAT_EXPERIMENTS, "type": T_CHOICE, "advanced": true, "group": "Cock direction",
	"values": [["animated", "As animated"], ["sliders", "Sliders"], ["feel", "Auto: canal"], ["belly", "Auto: belly"]],
	"title": "Cock direction",
	"desc": "Experimental. How the cock comes into the body and finds its way inside. As animated: as the game draws it," \
		+ " straight, nobody moved. Sliders: bent inside by Follow the body and Toward the belly. Auto: canal:" \
		+ " the cock follows the hole's own canal in one smooth curve, and the bodies turn a little so it goes in the way" \
		+ " it bends least. Auto: belly: the cock curves from the hole to meet the belly's skin (where: Meets" \
		+ " the belly at), then follows it, and the bodies turn so it comes in that way.",
},
{
	"id": "bulgeReposeOn", "cat": CAT_EXPERIMENTS, "type": T_BOOL, "advanced": true,
	"title": "Move the bodies",
	"desc": "With Cock direction Auto: canal or Auto: belly: the bodies move and turn a little so the cock comes in" \
		+ " the way it bends inside (the line it comes in along is chosen for each scene and hole). Off: the bodies as" \
		+ " animated.",
},
{
	"id": "bulgeFollowBody", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeDirectionMode", ["sliders"]],
	"title": "Follow the body",
	"desc": "Inside the body the cock bends along it instead of going straight. 0% = straight.",
},
{
	"id": "bulgeBelly", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeDirectionMode", ["sliders"]],
	"title": "Toward the belly",
	"desc": "Inside the body the cock runs close to the belly and pushes it out. 0% = through the middle.",
},
{
	"id": "bulgeBendMode", "cat": CAT_EXPERIMENTS, "type": T_CHOICE, "advanced": true,
	"when": ["bulgeDirectionMode", ["sliders", "feel", "belly"]],
	"values": [["follow", "Follows the curve"], ["push", "Bend on push"]],
	"title": "Cock bend",
	"desc": "Experimental, with Cock direction Sliders, Auto: canal or Auto: belly. Follows the curve:" \
		+ " inside, the cock always follows its curve. Bend on push: the cock goes in straight; only when its tip pushes" \
		+ " against the skin does it bend toward the curve, more the deeper it pushes. Once the push is over the belly" \
		+ " brings it back to the curve, and pulling out it stays curved.",
},
{
	"id": "bulgeTightness", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeReact", ["fixed"]],
	"title": "Fixed tightness",
	"desc": "Body tightness Fixed: 0% = always soft and low, 50% = as it always was, 100% = always sharp and high.",
},
{
	"id": "bulgeReposeCrowd", "cat": CAT_EXPERIMENTS, "type": T_BOOL, "advanced": true,
	"when": ["bulgeReposeOn", ["True"]], "also": ["bulgeDirectionMode", ["feel", "belly"]],
	"title": "Move the bodies: with 3 or more",
	"desc": "Also in scenes with more than two characters (SexDP, SexTrain, SexGangbang...). Off: there the bodies" \
		+ " stay as animated.",
},
{
	"id": "bulgeStrokeStyle", "cat": CAT_EXPERIMENTS, "type": T_CHOICE, "advanced": true,
	"when": ["bulgeReposeOn", ["True"]], "also": ["bulgeDirectionMode", ["feel", "belly"]],
	"values": [["game", "As the game"], ["natural", "Natural"], ["slow", "Slow and deep"], ["custom", "Custom"]],
	"title": "Move the bodies: style",
	"desc": "How the thrusts move. As the game: every thrust as animated. Natural (recommended): a little longer, in groups" \
		+ " that build to a deeper one, the partner pushing back, a long cock taking its time. Slow and deep: long, slow," \
		+ " soft thrusts that stay deep. Custom: set it yourself with the sliders below.",
},
{
	"id": "bulgeStrokeLength", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeStrokeStyle", ["custom"]],
	"title": "Style: length",
	"desc": "How far in and out each thrust goes. 50% = as animated, 100% = twice as far.",
},
{
	"id": "bulgeStrokeStrength", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeStrokeStyle", ["custom"]],
	"title": "Style: strength",
	"desc": "0% = soft thrusts that linger deep, 100% = a firm push with a sudden stop, the partner pushing back.",
},
{
	"id": "bulgeStrokeVariety", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeStrokeStyle", ["custom"]],
	"title": "Style: variety",
	"desc": "0% = every thrust the same, 100% = groups of short thrusts building to one deeper thrust.",
},
{
	"id": "bulgeStrokeRhythm", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeStrokeStyle", ["custom"]],
	"title": "Style: rhythm",
	"desc": "0% = long thrusts at the game's pace (they move faster), 100% = long thrusts taking their time.",
},
{
	"id": "bulgeStrokeWarm", "cat": CAT_EXPERIMENTS, "type": T_BOOL, "advanced": true,
	"when": ["bulgeStrokeStyle", ["natural", "slow", "custom"]],
	"title": "Style: start slowly",
	"desc": "When a scene starts, the first thrusts go in only a little, then deeper each time for about 6 seconds.",
},
{
	"id": "bulgeCanalBelly", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeDirectionMode", ["feel"]],
	"title": "Curve toward the belly",
	"desc": "Inside the body Canal: how far the cock's curve goes toward the belly. 0% = the canal as it is, 100% = the" \
		+ " cock right under the belly skin, its edge out: the biggest bulge.",
},
{
	"id": "bulgePress", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgePressMode", ["pressure", "belly", "outline", "tip"]],
	"title": "Something inside: strength",
	"desc": "How high the swelling is when the cock is right under the skin. 50% = about half the cock's thickness.",
},
{
	"id": "bulgePushHard", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeBendMode", ["push"]], "also": ["bulgeDirectionMode", ["sliders", "feel", "belly"]],
	"title": "Bend on push: belly hardness",
	"desc": "How much the belly gives before the cock bends. 100% = hard, the tip stops at the skin and bends at once;" \
		+ " 0% = soft, the tip pushes the belly out about the cock's thickness before it bends.",
},
{
	"id": "bulgePushRelax", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true,
	"when": ["bulgeBendMode", ["push"]], "also": ["bulgeDirectionMode", ["sliders", "feel", "belly"]],
	"title": "Bend on push: how quickly it changes",
	"desc": "How quickly the cock changes shape. Pushing, it straightens and its tip pushes the belly out; once the" \
		+ " push is over, the belly brings it back to the curve, and pulling out it stays curved. 0% = quickly;" \
		+ " 100% = slowly (straightening over about three times the cock's thickness, back on the curve in about a second).",
},
{
	"id": "bulgePressReach", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgePressMode", ["pressure", "belly", "outline", "tip"]],
	"title": "Something inside: reach",
	"desc": "How far from the skin the cock starts lifting it. 0% = only when almost touching, 50% = three times the" \
		+ " cock's thickness, 100% = five times.",
},
{
	"id": "bulgeDirectAt", "cat": CAT_EXPERIMENTS, "type": T_PERCENT, "advanced": true, "when": ["bulgeDirectionMode", ["belly"]],
	"title": "Meets the belly at",
	"desc": "Auto: belly: how far along the cock it meets the belly. 30% = near the base (steep)," \
		+ " 50% = halfway, 100% = at the tip (gentle).",
},
]
static func shown(row:Dictionary) -> bool:
	if(!row.has("when")):
		return true
	if(row.has("also") && !row["also"][1].has(switchValue(str(row["also"][0])))):
		return false
	if(!row["when"][1].has(switchValue(str(row["when"][0])))):
		return false
	var up:Dictionary = rowFor(str(row["when"][0]))
	return up.empty() || shown(up)
static func switchValue(name:String) -> String:
	if(name == "bulgeDirectionMode"):
		return Settings.directionMode()
	if(name == "bulgeEffect" && Settings.gles2()):
		return "basic"
	return str(Settings.value(name))
const MADE := {}
const OPTION_ENABLE_ALWAYS := 0
const OPTION_HIDDEN := 4
static func refreshShown() -> bool:
	var moved:bool = false
	for row in OPTIONS:
		var made = MADE.get(foxId(row))
		if(made == null || !row.has("when")):
			continue
		var enable:int = OPTION_HIDDEN
		if(shown(row)):
			enable = OPTION_ENABLE_ALWAYS
		if(made.enable != enable):
			made.enable = enable
			moved = true
	return moved
static func foxId(row:Dictionary) -> String:
	return ID_PREFIX + str(row["id"])
static func shipped(row:Dictionary):
	return Settings.compiled(str(row["id"]))
static func percentOf(row:Dictionary) -> int:
	return int(round(float(shipped(row)) * 100.0))
static func settingFor(row:Dictionary) -> String:
	if(str(row["type"]) == T_BUTTON || Settings.declaration(str(row["id"])) == null):
		return ""
	return str(row["id"])
static func rowFor(name:String) -> Dictionary:
	for row in OPTIONS:
		if(settingFor(row) == name):
			return row
	return {}
static func decode(row:Dictionary, raw):
	if(str(row["type"]) != T_PERCENT):
		return raw
	if(typeof(raw) != TYPE_INT && typeof(raw) != TYPE_REAL):
		return raw
	return float(raw) / 100.0
static func encode(row:Dictionary, given):
	if(str(row["type"]) != T_PERCENT):
		return given
	if(typeof(given) != TYPE_INT && typeof(given) != TYPE_REAL):
		return given
	return int(round(float(given) * 100.0))
const MANAGER_PATH := "res://Modules/FoxLib/Internal/FoxOptionsManager.gd"
const SECTION := Boot.MARKER_MOD
const STORE_LABEL := "FoxLib's mod options (section " + SECTION + " of user://foxlib/mod_options.cfg)"
const ABSENT := "insertionbulges-v4-no-such-foxlib-key"
const CACHE := {"looked": false, "manager": null, "at": -1, "stored": {}}
static func manager():
	if(!CACHE["looked"]):
		CACHE["looked"] = true
		if(ResourceLoader.exists(MANAGER_PATH)):
			CACHE["manager"] = load(MANAGER_PATH)
	return CACHE["manager"]
static func live() -> bool:
	return manager() != null
static func stored(mgr = manager()) -> Dictionary:
	var out:Dictionary = {}
	if(mgr == null):
		return out
	var cache:Dictionary = CACHE
	var at:int = int(Settings.CHANGED["n"])
	if(int(cache["at"]) == at):
		return cache["stored"]
	for row in OPTIONS:
		var name:String = settingFor(row)
		if(name == ""):
			continue
		var raw = mgr.getOption(SECTION, foxId(row), ABSENT)
		if(typeof(raw) == TYPE_STRING && str(raw) == ABSENT):
			continue
		var vetted:Array = Settings.vetSetting(name, decode(row, raw))
		if(!vetted[0].empty()):
			Boot.loud("FoxLibOptions: " + STORE_LABEL + " holds '" + str(row["id"]) + "' = " \
				+ str(raw) + ", which this build cannot use - " \
				+ PoolStringArray(vetted[0]).join("; ") + ". THAT ONE SETTING IS IGNORED this run" \
				+ " and falls back to the bench or the compiled default; every other setting is" \
				+ " unaffected. Reset that option in FoxLib's mod options screen.")
			continue
		out[name] = vetted[1]
	cache["at"] = at
	cache["stored"] = out
	return out
static func store(name:String, given, mgr = manager()) -> bool:
	if(mgr == null):
		Boot.loud("FoxLibOptions: asked to store '" + name + "' with FoxLib not installed. Nothing" \
			+ " written. This is a bug in the caller: Settings.store() must route to its own file" \
			+ " when FoxLib is absent.")
		return false
	var row:Dictionary = rowFor(name)
	if(row.empty()):
		Boot.loud("FoxLibOptions: '" + name + "' is not on FoxLib's options screen, so there is" \
			+ " nowhere in " + STORE_LABEL + " to put it. NOTHING WRITTEN and the value is NOT" \
			+ " saved. Add a row for it in FoxLibOptions.OPTIONS, or set it through" \
			+ " the Bench.")
		return false
	mgr.setOption(SECTION, foxId(row), encode(row, given))
	mgr.optionalySave()
	Settings.changed()
	refreshShown()
	return true
static func clear(name:String, mgr = manager()) -> bool:
	if(mgr == null):
		return false
	var row:Dictionary = rowFor(name)
	if(row.empty() || !erased(row, mgr)):
		return false
	mgr.optionalySave()
	Settings.changed()
	refreshShown()
	return true
static func erased(row:Dictionary, mgr) -> bool:
	var raw = mgr.getOption(SECTION, foxId(row), ABSENT)
	if(typeof(raw) == TYPE_STRING && str(raw) == ABSENT):
		return false
	mgr.clearOption(SECTION, foxId(row))
	return true
static func restoreDefaults(mgr = manager()) -> int:
	var cleared := 0
	if(mgr != null):
		for row in OPTIONS:
			if(settingFor(row) != "" && erased(row, mgr)):
				cleared += 1
	if(cleared > 0):
		mgr.optionalySave()
		Settings.changed()
	Boot.say("InsertionBulges 4: " + str(cleared) + " option(s) back to the recommended settings.")
	return cleared
static func declare(api, host = null) -> Array:
	var ids:Array = []
	if(api == null):
		Boot.loud("FoxLibOptions: FoxLib called onFoxLibModInit with no API object. NO OPTION IS" \
			+ " REGISTERED and the mod has no menu this run; it still draws.")
		return ids
	for row in OPTIONS:
		var id:String = foxId(row)
		var cat:String = str(row["cat"])
		var kind:String = str(row["type"])
		var made = null
		var start = shipped(row)
		if(Settings.gles2() && cat != CAT_MAIN):
			continue
		if(!Settings.gles2() && bool(row.get("gles2", false))):
			continue
		if(Settings.gles2() && str(row["id"]) == "bulgeEffect"):
			row = row.duplicate()
			row["values"] = [["basic", "Basic"]]
			row["desc"] = GLES2_TEXT
			start = "basic"
		if(kind == T_BOOL):
			made = api.addBooleanOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				bool(shipped(row)))
		elif(kind == T_PERCENT):
			made = api.addSliderOptionInCategory(cat, id, str(row["title"]), str(row["desc"]),
				percentOf(row))
		elif(kind == T_CHOICE):
			made = api.addListOptionInCategory(cat, id, str(row["title"]), row["values"],
				str(row["desc"]), str(start))
		elif(kind == T_BUTTON):
			made = api.addButtonOptionInCategory(cat, id, str(row["title"]), str(row["desc"]))
			if(made != null && str(row["id"]) == GLES2_NOTE_ID && made.has_method("setPlaceholder")):
				made = made.setPlaceholder("Options, Display, Renderer")
			if(made != null && made.has_method("noOptionReset")):
				made = made.noOptionReset()
			if(made != null && host != null && made.has_signal("option_changed")):
				made.connect("option_changed", host, str(row["on"]))
		if(made == null):
			Boot.loud("FoxLibOptions: FoxLib answered nothing for option '" + id + "', so that one" \
				+ " row is not on the screen. The rest are. This is a FoxLib API change - re-read" \
				+ " FoxLib/FoxModuleAPI.gd.")
			continue
		elif(kind != T_BUTTON && host != null && made.has_signal("option_changed")):
			made.connect("option_changed", host, "onOptionChanged")
		if(bool(row.get("advanced", false))):
			made = made.advanced()
		var made_:Dictionary = MADE
		made_[id] = made
		ids.append(id)
	refreshShown()
	return ids
