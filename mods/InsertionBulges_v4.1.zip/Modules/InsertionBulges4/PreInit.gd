const Boot := preload("res://Bulge4/Boot.gd")
func _init():
	var _mayRun:bool = Boot.mayRun("PreInit")
