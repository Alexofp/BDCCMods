extends Reference
static func linesOf(source:String) -> Array:
	var lines:Array = []
	for line in source.split("\n"):
		if(line.find("#") < 0):
			lines.append(line)
			continue
		var quote:int = 0
		var i:int = 0
		var cut:int = -1
		while(i < line.length()):
			var ch:int = line.ord_at(i)
			if(quote != 0):
				if(ch == 92):
					i += 1
				elif(ch == quote):
					quote = 0
			elif(ch == 34 || ch == 39):
				quote = ch
			elif(ch == 35):
				cut = i
				break
			i += 1
		if(cut < 0):
			cut = line.length()
		lines.append(line.substr(0, cut))
	return lines
