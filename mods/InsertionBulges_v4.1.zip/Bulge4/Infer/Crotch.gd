extends Reference
const Acts := preload("res://Bulge4/Infer/Acts.gd")

static func holesOf(snapshot) -> Dictionary:
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return {}
	if(snapshot.has("crotch")):
		return snapshot["crotch"]
	var out:Dictionary = {}
	snapshot["crotch"] = out
	if(typeof(snapshot.get("engines")) != TYPE_ARRAY):
		return out
	var byCharID:Dictionary = Acts.byCharIDOf(snapshot)
	var penisUsed:int = Acts.tagValue("PenisUsed")
	var vaginaUsed:int = Acts.tagValue("VaginaUsed")
	var anusUsed:int = Acts.tagValue("AnusUsed")
	for record in snapshot["engines"]:
		if(typeof(record) != TYPE_DICTIONARY || typeof(record.get("activities")) != TYPE_ARRAY):
			continue
		for activity in record["activities"]:
			if(typeof(activity) != TYPE_DICTIONARY || activity.get("ended") == true || activity.get("readable") != true):
				continue
			var shafts:Array = []
			var holes:Array = []
			for info in Acts.participantsIn(activity):
				if(typeof(info) != TYPE_DICTIONARY || !byCharID.has(str(info.get("char_id"))) || typeof(info.get("tags")) != TYPE_ARRAY):
					continue
				var pid = byCharID[str(info["char_id"])]
				if(penisUsed in info["tags"]):
					shafts.append([pid, int(info.get("indx"))])
				if(vaginaUsed in info["tags"]):
					holes.append([pid, Acts.HOLE_VAGINA, int(info.get("indx"))])
				if(anusUsed in info["tags"]):
					holes.append([pid, Acts.HOLE_ANUS, int(info.get("indx"))])
			if(shafts.size() == 1 && holes.size() == 1):
				out[str(shafts[0][0]) + "|" + str(holes[0][0])] = holes[0][1]
				continue
			for placed in Acts.placeShafts(activity, shafts, holes):
				if(placed[1] != null):
					out[str(placed[0]) + "|" + str(placed[1])] = placed[2]
	return out
