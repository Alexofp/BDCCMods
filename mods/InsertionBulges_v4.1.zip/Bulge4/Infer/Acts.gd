extends Reference
const Evidence := preload("res://Bulge4/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const DOM_0:int = 0
const DOM_1:int = 1
const INDX_NONE:int = -99
const HOLE_VAGINA:String = "vagina"
const HOLE_ANUS:String = "anus"
const TAG_SCRIPT := "res://Game/SexEngine/SexActivityTag.gd"
const TAG_FALLBACK := {"PenisInside": 4, "VaginaPenetrated": 11, "AnusPenetrated": 12, "PenisUsed": 3, "VaginaUsed": 1,
	"AnusUsed": 2}
const TAG_CACHE := {}
static func tagValue(name:String) -> int:
	if(!TAG_CACHE.has(name)):
		var value:int = int(TAG_FALLBACK[name])
		var script = load(TAG_SCRIPT)
		if(script is Script):
			var constants:Dictionary = script.get_script_constant_map()
			if(constants.has(name)):
				value = int(constants[name])
		TAG_CACHE[name] = value
	return int(TAG_CACHE[name])
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("engines")) != TYPE_ARRAY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_ENGINE_FOR)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_ENGINE)
		return []
	var byCharID:Dictionary = byCharIDOf(snapshot)
	var items:Array = []
	for record in snapshot["engines"]:
		if(typeof(record) != TYPE_DICTIONARY):
			continue
		var activities = record.get("activities")
		if(typeof(activities) != TYPE_ARRAY):
			notes.append(READ_FAILED + ": " + Evidence.SRC_ENGINE)
			continue
		for activity in activities:
			readActivity(activity, byCharID, items, notes)
	return items
static func byCharIDOf(snapshot:Dictionary) -> Dictionary:
	var byCharID:Dictionary = {}
	for entry in rosterOf(snapshot):
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null || entry.get("char_id") == null):
			continue
		byCharID[str(entry["char_id"])] = entry["id"]
	return byCharID
static func readActivity(activity, byCharID:Dictionary, items:Array, notes:Array) -> void:
	if(typeof(activity) != TYPE_DICTIONARY):
		return
	if(activity.get("ended") == true):
		return
	if(activity.get("readable") != true):
		notes.append("engine: unreadable activity " + activityName(activity))
		return
	var shafts:Array = []
	var occupied:Array = []
	var penisInside:int = tagValue("PenisInside")
	var vaginaIn:int = tagValue("VaginaPenetrated")
	var anusIn:int = tagValue("AnusPenetrated")
	for info in participantsIn(activity):
		if(typeof(info) != TYPE_DICTIONARY):
			continue
		var charID:String = str(info.get("char_id"))
		if(!byCharID.has(charID)):
			continue
		var indx:int = int(info.get("indx"))
		if(indx <= INDX_NONE):
			continue
		var tags = info.get("tags")
		if(typeof(tags) != TYPE_ARRAY):
			continue
		var pid = byCharID[charID]
		if(penisInside in tags):
			shafts.append([pid, indx])
		if(vaginaIn in tags):
			occupied.append([pid, HOLE_VAGINA, indx])
		if(anusIn in tags):
			occupied.append([pid, HOLE_ANUS, indx])
	if(occupied.empty()):
		return
	if(shafts.size() == 1 && occupied.size() == 1):
		items.append(pairing(shafts[0][0], occupied[0][0], occupied[0][1], activity))
		return
	for placed in placeShafts(activity, shafts, occupied):
		if(placed[1] == null):
			notes.append("engine: " + str(placed[3]) + " (shaft " + str(placed[0]) + ") in " + activityName(activity))
			continue
		items.append(pairing(placed[0], placed[1], placed[2], activity))
static func placeShafts(activity:Dictionary, shafts:Array, holes:Array) -> Array:
	var out:Array = []
	var taken:Array = []
	for slotted in [true, false]:
		for shaft in shafts:
			var hole:String = holeOfShaft(activity, int(shaft[1]))
			if((hole != "") != slotted):
				continue
			var owners:Array = []
			for h in holes:
				if(str(h[0]) == str(shaft[0])):
					continue
				if(slotted && h[1] != hole):
					continue
				if(!slotted && taken.has(str(h[0]) + "|" + str(h[1]))):
					continue
				owners.append(h)
			if(slotted && owners.size() > 1):
				var subs:Array = []
				for h in owners:
					if(int(h[2]) < 0):
						subs.append(h)
				if(!subs.empty()):
					owners = subs
			if(owners.size() == 1):
				out.append([shaft[0], owners[0][0], owners[0][1], ""])
				taken.append(str(owners[0][0]) + "|" + str(owners[0][1]))
			elif(owners.empty()):
				out.append([shaft[0], null, hole, "cannot place the shaft"])
			else:
				out.append([shaft[0], null, hole, "hole " + hole + " is occupied on more than one participant"])
	return out
static func pairing(shaftOwner, holeOwner, holeID:String, activity:Dictionary) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_ENGINE,
		Evidence.CLAIM_PAIRING,
		{
			Evidence.SUBJ_SHAFT: shaftOwner,
			Evidence.SUBJ_HOLE_OWNER: holeOwner,
			Evidence.SUBJ_HOLE: holeID,
		},
		true,
		Evidence.CONF_ENGINE,
		{"activity": activityName(activity)}
	)
static func holeOfShaft(activity:Dictionary, indx:int) -> String:
	if(indx == DOM_0 && activity.get("dom0_slot") != null):
		return slotToHole(activity["dom0_slot"])
	if(indx == DOM_1 && activity.get("dom1_slot") != null):
		return slotToHole(activity["dom1_slot"])
	if(indx == DOM_0 && activity.get("used_slot") != null):
		return slotToHole(activity["used_slot"])
	return ""
static func slotToHole(slot) -> String:
	if(slot == HOLE_VAGINA):
		return HOLE_VAGINA
	if(slot == HOLE_ANUS):
		return HOLE_ANUS
	return ""
static func activityName(activity:Dictionary) -> String:
	var theID = activity.get("id")
	if(theID == null):
		return "(unnamed activity)"
	return str(theID)
static func rosterOf(snapshot:Dictionary) -> Array:
	if(typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return []
	return snapshot["participants"]
static func participantsIn(activity:Dictionary) -> Array:
	if(typeof(activity.get("participants")) != TYPE_ARRAY):
		return []
	return activity["participants"]
