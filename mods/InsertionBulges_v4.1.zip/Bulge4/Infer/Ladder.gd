extends Reference
const Evidence := preload("res://Bulge4/Infer/Evidence.gd")
const Fits := preload("res://Bulge4/Infer/Fits.gd")
const HOLE_MOUTH := "mouth"
const SOURCE_ORDER := [
	Evidence.SRC_ENGINE,
	Evidence.SRC_ORAL_HINT,
	Evidence.SRC_TAPER,
	Evidence.SRC_DECLARATION,
	Evidence.SRC_GEOMETRY,
]
const V3_SOURCE_ORDER := [
	Evidence.SRC_PORTAL,
]
const NOTE_NOT_IN_TABLE := "relation names a participant that is not in the table: "
const NOTE_NO_SHAFT := "claim refused, shaft owner has no shaft: "
const NOTE_ARROW := " -> "
static func fuse(snapshot, items:Array) -> Dictionary:
	var table:Dictionary = {
		"relations": [],
		"problems": [],
	}
	var participants:Dictionary = participantsOf(snapshot)
	var mouthShaft:Dictionary = Evidence.mouthShaftMap(items)
	var declared:Dictionary = Evidence.declaredLookup(items)
	var bySource:Dictionary = {}
	for one in items:
		if(typeof(one) != TYPE_DICTIONARY):
			continue
		var key:String = str(one.get("source"))
		if(!bySource.has(key)):
			bySource[key] = []
		bySource[key].append(one)
	for source in SOURCE_ORDER + V3_SOURCE_ORDER:
		for one in bySource.get(source, []):
			var relation = relationOf(one)
			if(relation == null):
				continue
			if(source == Evidence.SRC_GEOMETRY && withheld(table, relation, mouthShaft, declared)):
				continue
			claim(table, participants, relation)
	return table
static func relationOf(one:Dictionary):
	if(str(one.get("claim")) != Evidence.CLAIM_PAIRING || one.get("holds") != true):
		return null
	var subject = one.get("subject")
	if(typeof(subject) != TYPE_DICTIONARY):
		return null
	if(subject.get(Evidence.SUBJ_SHAFT) == null || subject.get(Evidence.SUBJ_HOLE_OWNER) == null \
			|| subject.get(Evidence.SUBJ_HOLE) == null):
		return null
	return {
		"shaft": subject[Evidence.SUBJ_SHAFT],
		"hole_owner": subject[Evidence.SUBJ_HOLE_OWNER],
		"hole": str(subject[Evidence.SUBJ_HOLE]),
		"source": str(one.get("source")),
		"confidence": int(one.get("confidence", 0)),
	}
static func claim(table:Dictionary, participants:Dictionary, relation:Dictionary) -> void:
	if(!participants.has(relation["shaft"]) || !participants.has(relation["hole_owner"])):
		note(table, NOTE_NOT_IN_TABLE + str(relation["shaft"]) + NOTE_ARROW
			+ str(relation["hole_owner"]))
		return
	if(!participants[relation["shaft"]]):
		note(table, NOTE_NO_SHAFT + str(relation["shaft"]) + NOTE_ARROW
			+ str(relation["hole_owner"]) + "/" + relation["hole"])
		return
	var existingForShaft = relationOfShaft(table, relation["shaft"])
	var existingForHole = relationOfHole(table, relation["hole_owner"], relation["hole"], relation["shaft"])
	var wanted:int = int(relation["confidence"])
	if(existingForShaft != null && int(existingForShaft["confidence"]) >= wanted):
		return
	if(existingForHole != null && int(existingForHole["confidence"]) >= wanted):
		return
	if(existingForShaft != null):
		drop(table, existingForShaft)
	if(existingForHole != null):
		drop(table, existingForHole)
	table["relations"].append(relation)
static func drop(table:Dictionary, relation:Dictionary) -> void:
	var at:int = table["relations"].find(relation)
	if(at >= 0):
		table["relations"].remove(at)
static func relationOfShaft(table:Dictionary, shaftOwner):
	for relation in table["relations"]:
		if(relation["shaft"] == shaftOwner):
			return relation
	return null
const HOLE_CAPACITY := {"vagina": 2}
static func relationOfHole(table:Dictionary, holeOwner, holeID:String, shaftOwner):
	var count:int = 0
	var weakest = null
	for relation in table["relations"]:
		if(relation["hole_owner"] != holeOwner || relation["hole"] != holeID || relation["shaft"] == shaftOwner):
			continue
		count += 1
		if(weakest == null || int(relation["confidence"]) < int(weakest["confidence"])):
			weakest = relation
	if(count < int(HOLE_CAPACITY.get(holeID, 1))):
		return null
	return weakest
static func note(table:Dictionary, what:String) -> void:
	if(!table["problems"].has(what)):
		table["problems"].append(what)
static func participantsOf(snapshot) -> Dictionary:
	var out:Dictionary = {}
	if(typeof(snapshot) != TYPE_DICTIONARY || typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return out
	for entry in snapshot["participants"]:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		out[entry["id"]] = entry.get("has_shaft") == true
	return out
static func withheld(table:Dictionary, relation:Dictionary, mouthShaft:Dictionary,
		declared:Dictionary) -> bool:
	var shaftOwner = relation["shaft"]
	var holeOwner = relation["hole_owner"]
	var tapered = Fits.taperSaid(mouthShaft, shaftOwner)
	if(relation["hole"] == HOLE_MOUTH && tapered != null && tapered):
		return false
	if(!Fits.declaredPenetration(declared, shaftOwner, holeOwner)):
		return false
	return reverseHeldAbove(table, shaftOwner, holeOwner, Evidence.CONF_RUNTIME)
static func reverseHeldAbove(table:Dictionary, shaftOwner, holeOwner, confidence:int) -> bool:
	if(str(shaftOwner) == str(holeOwner)):
		return false
	var reverse = relationOfShaft(table, holeOwner)
	if(reverse == null || str(reverse["hole_owner"]) != str(shaftOwner)):
		return false
	return int(reverse["confidence"]) > confidence
