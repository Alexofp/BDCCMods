extends Reference
const Evidence := preload("res://Bulge4/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const HOLE_MOUTH := "mouth"
const LATERAL_TOLERANCE:Dictionary = {
	"vagina": 0.55,
	"anus": 0.55,
	"mouth": 0.8,
}
const LATERAL_TOLERANCE_OTHER:float = 0.42
const MIN_INWARD_DOT:Dictionary = {
	"vagina": 0.6,
	"anus": 0.6,
	"mouth": 0.4,
}
const MIN_INWARD_DOT_OTHER:float = 0.6
const MIN_TIP_INSIDE:float = 0.2
const MIN_TIP_SHARE:float = 0.15
const MIN_SHAFT_LENGTH:float = 0.05
const LATERAL_WEIGHT:float = 0.1
const READ_FAILED:String = "cannotread"
static func contribute(snapshot, items:Array, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_HELPER_FOR)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_GEOMETRY)
		return []
	var mouthShaft:Dictionary = Evidence.mouthShaftMap(items)
	var declared:Dictionary = Evidence.declaredLookup(items)
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	var holes:Dictionary = {}
	if(typeof(snapshot.get("holes")) == TYPE_DICTIONARY):
		holes = snapshot["holes"]
	var ordered:Array = []
	var roster:Array = rosterOf(snapshot)
	for topEntry in roster:
		if(typeof(topEntry) != TYPE_DICTIONARY || topEntry.get("id") == null):
			continue
		var shaftOwner = topEntry["id"]
		var card = shafts.get(shaftOwner)
		if(!isShaft(card)):
			continue
		var length:float = float(card["length"])
		if(length < MIN_SHAFT_LENGTH):
			continue
		var base:Vector3 = card["base"]
		var tip:Vector3 = card["tip"]
		var dir:Vector3 = (tip - base) / length
		var tapered = taperSaid(mouthShaft, shaftOwner)
		var mouthVouched:bool = tapered != null && tapered
		for bottomEntry in roster:
			if(typeof(bottomEntry) != TYPE_DICTIONARY || bottomEntry.get("id") == null):
				continue
			var holeOwner = bottomEntry["id"]
			var declaredPair:bool = declaredPenetration(declared, shaftOwner, holeOwner)
			for holeID in holesOf(holes, holeOwner):
				var hid:String = str(holeID)
				if(hid == HOLE_MOUTH && tapered != null && !tapered):
					continue
				if(!declaredPair && !(hid == HOLE_MOUTH && mouthVouched)):
					continue
				var candidate = measure(holes, shaftOwner, holeOwner, hid, base, tip, dir, length)
				if(candidate != null):
					insertByFit(ordered, candidate)
	return assign(ordered)
static func assign(ordered:Array) -> Array:
	var items:Array = []
	for candidate in ordered:
		items.append(Evidence.item(
			Evidence.SRC_GEOMETRY,
			Evidence.CLAIM_PAIRING,
			{
				Evidence.SUBJ_SHAFT: candidate["shaft"],
				Evidence.SUBJ_HOLE_OWNER: candidate["hole_owner"],
				Evidence.SUBJ_HOLE: candidate["hole"],
			},
			true,
			Evidence.CONF_RUNTIME,
			{}
		))
	return items
static func measure(holes:Dictionary, shaftOwner, holeOwner, holeID:String, base:Vector3,
		tip:Vector3, dir:Vector3, length:float, gated:bool = true):
	var hole = holeAt(holes, holeOwner, holeID)
	if(!isHole(hole)):
		return null
	var pos:Vector3 = hole["pos"]
	var inward:Vector3 = hole["inward"]
	var along:float = (pos - base).dot(dir)
	var lateral:float = (pos - (base + dir * along)).length()
	var inwardDot:float = dir.dot(inward)
	var tipInside:float = (tip - pos).dot(inward)
	var fit:float = (1.0 - inwardDot) + lateral * LATERAL_WEIGHT
	if(gated):
		if(lateral > lateralLimit(holeID)):
			return null
		if(inwardDot < inwardLimit(holeID)):
			return null
		if(tipInside < min(MIN_TIP_INSIDE, MIN_TIP_SHARE * length)):
			return null
	return {
		"shaft": shaftOwner,
		"hole_owner": holeOwner,
		"hole": holeID,
		"along": along,
		"depth": length - along,
		"entry": pos,
		"axis": inward,
		"fit": fit,
	}
static func taperSaid(mouthShaft:Dictionary, shaftOwner):
	var said = mouthShaft.get(str(shaftOwner))
	if(typeof(said) != TYPE_BOOL):
		return null
	return said
static func declaredPenetration(declared:Dictionary, shaftOwner, holeOwner) -> bool:
	return declared.has(str(shaftOwner)) && declared[str(shaftOwner)].has(str(holeOwner))
static func insertByFit(ordered:Array, candidate:Dictionary) -> void:
	var at:int = 0
	while(at < ordered.size() && float(ordered[at]["fit"]) <= float(candidate["fit"])):
		at += 1
	ordered.insert(at, candidate)
static func rosterOf(snapshot:Dictionary) -> Array:
	if(typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return []
	return snapshot["participants"]
static func holesOf(holes:Dictionary, participantID) -> Array:
	if(typeof(holes.get(participantID)) != TYPE_DICTIONARY):
		return []
	return holes[participantID].keys()
static func holeAt(holes:Dictionary, participantID, holeID:String):
	if(typeof(holes.get(participantID)) != TYPE_DICTIONARY):
		return null
	return holes[participantID].get(holeID)
static func isShaft(card) -> bool:
	if(typeof(card) != TYPE_DICTIONARY):
		return false
	if(typeof(card.get("base")) != TYPE_VECTOR3 || typeof(card.get("tip")) != TYPE_VECTOR3):
		return false
	var length = card.get("length")
	return typeof(length) == TYPE_REAL || typeof(length) == TYPE_INT
static func isHole(hole) -> bool:
	if(typeof(hole) != TYPE_DICTIONARY):
		return false
	return typeof(hole.get("pos")) == TYPE_VECTOR3 && typeof(hole.get("inward")) == TYPE_VECTOR3
static func lateralLimit(holeID:String) -> float:
	if(LATERAL_TOLERANCE.has(holeID)):
		return float(LATERAL_TOLERANCE[holeID])
	return LATERAL_TOLERANCE_OTHER
static func inwardLimit(holeID:String) -> float:
	if(MIN_INWARD_DOT.has(holeID)):
		return float(MIN_INWARD_DOT[holeID])
	return MIN_INWARD_DOT_OTHER
