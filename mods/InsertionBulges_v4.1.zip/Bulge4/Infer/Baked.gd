extends Reference
const BakedSources := preload("res://Bulge4/Infer/BakedSources.gd")
const Oral := preload("res://Bulge4/Infer/Oral.gd")
const Declaration := preload("res://Bulge4/Infer/Declaration.gd")
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const LIVE := {}
static func oralContribute(snapshot, notes:Array):
	var baked = bakedEntry(snapshot)
	if(baked != null):
		if(baked["oral"].empty()):
			return baked["oral"]
		return baked["oral"].duplicate(true)
	return live("oral", snapshot, notes)
static func declarationContribute(snapshot, notes:Array):
	if(typeof(snapshot) == TYPE_DICTIONARY && notInside().has(str(snapshot.get("pose", "")))):
		return []
	var baked = bakedEntry(snapshot)
	if(baked != null):
		if(baked["declaration"].empty()):
			return baked["declaration"]
		return baked["declaration"].duplicate(true)
	return live("declaration", snapshot, notes)
static func live(kind:String, snapshot, notes:Array):
	var key:String = liveKey(kind, snapshot)
	var cache:Dictionary = LIVE
	if(key != "" && cache.has(key)):
		return cache[key].duplicate(true)
	var items
	if(kind == "oral"):
		items = Oral.contribute(snapshot, notes)
	else:
		items = Declaration.contribute(snapshot, notes)
	if(key != "" && typeof(items) == TYPE_ARRAY):
		cache[key] = items.duplicate(true)
	return items
static func liveKey(kind:String, snapshot) -> String:
	if(typeof(snapshot) != TYPE_DICTIONARY || Snapshot.cannotRead(snapshot, Snapshot.CAP_SCENE_SOURCE)):
		return ""
	var path = snapshot.get("scene_path")
	var source = snapshot.get("scene_source")
	if(typeof(path) != TYPE_STRING || typeof(source) != TYPE_STRING || source == ""):
		return ""
	var key:String = kind + "|" + path + "|" + str(snapshot.get("pose", ""))
	if(typeof(snapshot.get("participants")) == TYPE_ARRAY):
		for entry in snapshot["participants"]:
			if(typeof(entry) == TYPE_DICTIONARY && entry.get("id") != null):
				key += "|" + str(entry["id"])
	return key
static func bakedEntry(snapshot):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !BakedSources.TABLE.has(path)):
		return null
	var byPose = BakedSources.TABLE[path]
	var pose:String = str(snapshot.get("pose", ""))
	if(typeof(byPose) != TYPE_DICTIONARY || !byPose.has(pose)):
		return null
	return byPose[pose]
const NOT_INSIDE := {"built": false, "names": {}}
static func notInside() -> Dictionary:
	var cache:Dictionary = NOT_INSIDE
	if(cache["built"]):
		return cache["names"]
	cache["built"] = true
	for path in BakedSources.TABLE:
		var byPose = BakedSources.TABLE[path]
		var declares:bool = false
		for pose in byPose:
			if(!byPose[pose]["declaration"].empty()):
				declares = true
		if(!declares):
			continue
		for pose in byPose:
			if(str(pose) != "" && byPose[pose]["declaration"].empty()):
				cache["names"][str(pose)] = true
	return cache["names"]
