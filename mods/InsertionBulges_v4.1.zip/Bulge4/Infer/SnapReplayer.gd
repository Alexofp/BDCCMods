const Evidence := preload("res://Bulge4/Infer/Evidence.gd")
const Taper := preload("res://Bulge4/Infer/Taper.gd")
const Acts := preload("res://Bulge4/Infer/Acts.gd")
const Baked := preload("res://Bulge4/Infer/Baked.gd")
const PortalScenes := preload("res://Bulge4/Infer/PortalScenes.gd")
const Overlap := preload("res://Bulge4/Infer/Overlap.gd")
const Fits := preload("res://Bulge4/Infer/Fits.gd")
const NOTE_UNREADABLE := "unreadable: "
static func infer(snapshot, age:float) -> Dictionary:
	var notes:Array = []
	var items:Array = []
	var taperItems = Taper.contribute(snapshot, age, notes)
	if(typeof(taperItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_TAPER)
	else:
		items.append_array(taperItems)
	var actItems = Acts.contribute(snapshot, notes)
	if(typeof(actItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_ENGINE)
	else:
		items.append_array(actItems)
	var oralItems = Baked.oralContribute(snapshot, notes)
	if(typeof(oralItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_ORAL_HINT)
	else:
		items.append_array(oralItems)
	var declaredItems = Baked.declarationContribute(snapshot, notes)
	if(typeof(declaredItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_DECLARATION)
	else:
		items.append_array(declaredItems)
	var portalItems = PortalScenes.contribute(snapshot, notes)
	if(typeof(portalItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_PORTAL)
	else:
		items.append_array(portalItems)
	var overlapItems = Overlap.contribute(snapshot, notes)
	if(typeof(overlapItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_OVERLAP)
	else:
		items.append_array(overlapItems)
	var geometryItems = Fits.contribute(snapshot, items, notes)
	if(typeof(geometryItems) != TYPE_ARRAY):
		notes.append(NOTE_UNREADABLE + Evidence.SRC_GEOMETRY)
	else:
		items.append_array(geometryItems)
	return {"items": Evidence.oneCrotchHole(items), "notes": notes}
