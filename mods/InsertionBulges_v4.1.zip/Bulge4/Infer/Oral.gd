extends Reference
const Evidence := preload("res://Bulge4/Infer/Evidence.gd")
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const Lines := preload("res://Bulge4/Infer/Lines.gd")
const DOLL_VARS:Array = ["doll", "doll2", "doll3", "doll4"]
const CLAMP_CALL:String = ".clampPenisScale("
const OPEN_CALL:String = ".setTemporaryState(\"mouth\", \"open\")"
const HOLE_MOUTH:String = "mouth"
const READ_FAILED:String = "cannotread"
const DOLL_ID_PREFIX:String = "doll"
static func contribute(snapshot, notes:Array):
	if(typeof(snapshot) != TYPE_DICTIONARY || !snapshot.has("scene_source")):
		return null
	if(Snapshot.cannotRead(snapshot, Snapshot.CAP_SCENE_SOURCE)):
		notes.append(READ_FAILED + ": " + Evidence.SRC_ORAL_HINT)
		return []
	var source = snapshot["scene_source"]
	if(source == null):
		return []
	if(typeof(source) != TYPE_STRING || source == ""):
		notes.append(READ_FAILED + ": " + Evidence.SRC_ORAL_HINT)
		return []
	var pose = snapshot.get("pose")
	if(pose == null || str(pose) == ""):
		return []
	var known:Dictionary = knownIds(snapshot)
	var items:Array = []
	for region in regionsFor(Lines.linesOf(source), str(pose)):
		for pair in pairsIn(region):
			var giver = dollAt(known, int(pair[0]))
			var taker = dollAt(known, int(pair[1]))
			if(giver == null || taker == null):
				continue
			items.append(pairing(giver, taker, str(pose)))
	return items
static func pairing(giver, taker, pose:String) -> Dictionary:
	return Evidence.item(
		Evidence.SRC_ORAL_HINT,
		Evidence.CLAIM_PAIRING,
		{
			Evidence.SUBJ_SHAFT: giver,
			Evidence.SUBJ_HOLE_OWNER: taker,
			Evidence.SUBJ_HOLE: HOLE_MOUTH,
		},
		true,
		Evidence.CONF_AUTHORED,
		{"pose": pose}
	)
static func dollAt(known:Dictionary, index:int):
	var id:String = DOLL_ID_PREFIX + str(index)
	if(!known.has(id)):
		return null
	return id
static func regionsFor(lines:Array, pose:String, unguarded = null) -> Array:
	var regions:Array = []
	var current:Array = []
	var regionIndent:int = -1
	var skipIndent:int = -1
	var carried:String = ""
	var taken:Dictionary = {}
	var poseFalse:Dictionary = {}
	for line in lines:
		var text:String = line.strip_edges()
		if(text == ""):
			continue
		var indent:int = indentOf(line)
		if(indent == 0 && text.begins_with("func ")):
			carried = ""
			taken = {}
			poseFalse = {}
		if(skipIndent >= 0 && indent <= skipIndent):
			skipIndent = -1
		if(regionIndent >= 0 && indent <= regionIndent):
			regions.append(current)
			current = []
			regionIndent = -1
		if(skipIndent >= 0):
			continue
		var cond:String = conditionOf(text)
		var isElif:bool = text.begins_with("elif")
		if(cond == "" && text == "else:"):
			if(taken.get(indent, false)):
				skipIndent = indent
			elif(poseFalse.get(indent, false) && regionIndent < 0):
				regionIndent = indent
				current = []
				if(carried != ""):
					current.append(carried)
			continue
		if(cond != ""):
			if(isElif && taken.get(indent, false)):
				skipIndent = indent
				continue
			var poseGuard:bool = cond.find("animID") >= 0
			var guardTrue:bool = poseGuard && matchesPose(cond, pose)
			taken[indent] = guardTrue
			poseFalse[indent] = poseGuard && !guardTrue && (!isElif || poseFalse.get(indent, false))
			if(poseGuard):
				if(!guardTrue):
					skipIndent = indent
				elif(regionIndent < 0):
					regionIndent = indent
					current = []
					if(carried != ""):
						current.append(carried)
				continue
		if(regionIndent >= 0):
			current.append(line)
		else:
			if(unguarded != null):
				unguarded.append(line)
			if(line.find(CLAMP_CALL) >= 0):
				carried = line
	if(regionIndent >= 0):
		regions.append(current)
	return regions
static func matchesPose(condition:String, pose:String) -> bool:
	for disjunct in splitTop(normalized(condition), "||"):
		var readable:bool = false
		var answer:bool = true
		for conjunct in splitTop(unwrapped(disjunct.strip_edges()), "&&"):
			var truth:int = poseTruth(conjunct, pose)
			if(truth < 0):
				continue
			readable = true
			if(truth == 0):
				answer = false
		if(readable && answer):
			return true
	return false
static func splitTop(text:String, sep:String) -> Array:
	var parts:Array = []
	var depth:int = 0
	var start:int = 0
	var i:int = 0
	while(i < text.length()):
		var ch:String = text.substr(i, 1)
		if(ch == "(" || ch == "["):
			depth += 1
		elif(ch == ")" || ch == "]"):
			depth -= 1
		elif(depth == 0 && text.substr(i, sep.length()) == sep):
			parts.append(text.substr(start, i - start))
			start = i + sep.length()
			i += sep.length()
			continue
		i += 1
	parts.append(text.substr(start, text.length() - start))
	return parts
static func normalized(condition:String) -> String:
	return (" " + condition + " ").replace(" or ", " || ").replace(" and ", " && ").replace(" not ", " !").strip_edges()
static func poseTruth(conjunct:String, pose:String) -> int:
	var cond:String = unwrapped(conjunct.strip_edges())
	if(cond.find("||") >= 0):
		return -1
	var negated:bool = false
	if(cond.begins_with("!(") && cond.ends_with(")")):
		negated = true
		cond = unwrapped(cond.substr(2, cond.length() - 3).strip_edges())
	if(cond.begins_with("_animID")):
		cond = cond.substr(1, cond.length() - 1)
	if(!cond.begins_with("animID")):
		return -1
	var rest:String = cond.substr(6, cond.length() - 6).strip_edges()
	var literals:Array = literalsOf(rest)
	if(literals.empty()):
		return -1
	var answer:bool = false
	if(rest.begins_with("==")):
		answer = pose == str(literals[0])
	elif(rest.begins_with("!=")):
		answer = pose != str(literals[0])
	elif(rest.begins_with("in") && rest.find("[") >= 0):
		answer = pose in literals
	else:
		return -1
	if(negated):
		answer = !answer
	if(answer):
		return 1
	return 0
static func unwrapped(text:String) -> String:
	var cond:String = text
	while(cond.begins_with("(") && cond.ends_with(")")):
		cond = cond.substr(1, cond.length() - 2).strip_edges()
	return cond
static func pairsIn(region:Array) -> Array:
	var pairs:Array = []
	var giver:int = -1
	for line in region:
		if(line.find(CLAMP_CALL) >= 0):
			giver = dollCalling(line, CLAMP_CALL)
			continue
		if(line.find(OPEN_CALL) >= 0 && giver >= 0):
			var taker:int = dollCalling(line, OPEN_CALL)
			if(taker >= 0):
				pairs.append([giver, taker])
			giver = -1
	return pairs
static func dollCalling(line:String, call:String) -> int:
	var at:int = line.find(call)
	if(at < 0):
		return -1
	var start:int = at
	while(start > 0):
		var ch:String = line.substr(start - 1, 1)
		if(!isWordChar(ch)):
			break
		start -= 1
	return DOLL_VARS.find(line.substr(start, at - start))
static func isWordChar(ch:String) -> bool:
	return ch == "_" || (ch >= "0" && ch <= "9") || (ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z")
static func conditionOf(text:String) -> String:
	var body:String = ""
	if(text.begins_with("if(") || text.begins_with("if ")):
		body = text.substr(2, text.length() - 2)
	elif(text.begins_with("elif(") || text.begins_with("elif ")):
		body = text.substr(4, text.length() - 4)
	else:
		return ""
	if(!body.ends_with(":")):
		return ""
	body = body.substr(0, body.length() - 1).strip_edges()
	if(body.begins_with("(") && body.ends_with(")")):
		body = body.substr(1, body.length() - 2)
	return body
static func literalsOf(text:String) -> Array:
	var found:Array = []
	var at:int = text.find("\"")
	while(at >= 0):
		var end:int = text.find("\"", at + 1)
		if(end < 0):
			break
		found.append(text.substr(at + 1, end - at - 1))
		at = text.find("\"", end + 1)
	return found
static func indentOf(line:String) -> int:
	var depth:int = 0
	while(depth < line.length() && (line.substr(depth, 1) == "\t" || line.substr(depth, 1) == " ")):
		depth += 1
	return depth
static func rosterOf(snapshot:Dictionary) -> Array:
	if(typeof(snapshot.get("participants")) != TYPE_ARRAY):
		return []
	return snapshot["participants"]
static func knownIds(snapshot:Dictionary) -> Dictionary:
	var known:Dictionary = {}
	for entry in rosterOf(snapshot):
		if(typeof(entry) == TYPE_DICTIONARY && entry.get("id") != null):
			known[str(entry["id"])] = true
	return known
