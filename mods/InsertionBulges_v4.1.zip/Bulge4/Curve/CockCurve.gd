extends Reference

const BodyDeform := preload("res://Bulge4/Effects/Detailed/Lab/BodyDeform.gd")

static func find(o:Dictionary, bs:Dictionary, xa:Transform, start:Vector2, dir:Vector2, length:float, inside:float, hole:String,
		gap:float, r:float, toward:float) -> Dictionary:
	if(o.get("curve_cache") != null && o.get("pelvis") != null):
		return bodyFind(o, bs, xa, start, dir, length, inside, hole, gap, r, toward)
	var canal:Array = lane(bs, xa, start, hole, gap, toward)
	if(canal.size() < 2):
		return {}
	var arc:Array = arcOf(start, dir, length, canal, r, toward)
	var direct:Array = directOf(o, bs, xa, start, dir, inside, r, hole, length)
	if(!direct.empty()):
		return {"lane": direct[1], "axis": direct[0], "arc": arc}
	if(o.get("push") != null):
		var aim:float = aimed(start, dir, arc, inside)
		arc = scaled(arc, pushShare(o, bs, xa, start, dir, inside, r, {"arc": arc, "aim": aim}, hole), aim)
	return {"lane": canal, "axis": BodyDeform._arc_line(start, dir, arc, inside, BodyDeform.PATH_STEPS), "arc": arc}

const BODY := {"learn": 1.5}
static func bodyFind(o:Dictionary, bs:Dictionary, xa:Transform, start:Vector2, dir:Vector2, length:float, inside:float, hole:String,
		gap:float, r:float, toward:float) -> Dictionary:
	var cache:Dictionary = o["curve_cache"]
	var pelvis:Transform2D = o["pelvis"]
	var now:float = float(o.get("now", 0.0))
	var action:String = str(o.get("action", ""))
	var key:String = hole + "/" + str(int(o.get("cock_index", 0))) + "/" + str(bool(o.get("throat", false)))
	var kept = cache.get(key)
	var preroll = cache.get(hole + "/" + str(bool(o.get("throat", false))))
	if(kept == null && preroll != null && str(preroll["action"]) == action):
		kept = preroll.duplicate()
		cache[key] = kept
	if(kept == null || str(kept["action"]) != action || now < float(kept["since"])):
		kept = {"action": action, "since": now}
		cache[key] = kept
	var knobs:Array = [gap, toward]
	if(kept.has("lane") && !kept.has("knobs")):
		kept["knobs"] = knobs
	var moved:Array = []
	if(now - float(kept["since"]) < float(BODY["learn"]) || !kept.has("lane") || knobsMoved(kept.get("knobs"), knobs)):
		var canal:Array = lane(bs, xa, start, hole, gap, toward)
		if(canal.size() < 2):
			return {}
		kept["lane"] = xformAll(pelvis.affine_inverse(), canal)
		kept["knobs"] = knobs
		moved = canal
	else:
		moved = lane(bs, xa, start, hole, gap, toward)
		if(moved.size() < 2):
			moved = xformAll(pelvis, kept["lane"])
	var arc:Array = arcOf(start, dir, length, moved, r, toward)
	var direct:Array = directOf(o, bs, xa, start, dir, inside, r, hole, length)
	if(!direct.empty()):
		return {"lane": direct[1], "axis": direct[0], "arc": arc}
	if(o.get("push") != null):
		var aim:float = aimed(start, dir, arc, inside)
		arc = scaled(arc, pushShare(o, bs, xa, start, dir, inside, r, {"arc": arc, "aim": aim}, hole), aim)
	return {"lane": moved, "axis": BodyDeform._arc_line(start, dir, arc, inside, BodyDeform.PATH_STEPS), "arc": arc}

const DIRECT := {"step": 0.25, "past": 6.0}
static func directOf(o:Dictionary, bs:Dictionary, xa:Transform, start:Vector2, dir:Vector2, inside:float, r:float, hole:String, length:float) -> Array:
	var at:float = float(o.get("direct_at", 0.0))
	if(at <= 0.0 || inside <= 1e-6 || r <= 0.0):
		return []
	var skin:Array = BodyDeform._guide(bs, xa, 1.0, 0.0)
	if(skin.size() < 2):
		return []
	var cum:Array = BodyDeform._cumulative_open(skin)
	var hit:Array = directHitAt(skin, cum, start, r, at * length)
	if(hit.empty()):
		return []
	var full:Array = directBow(skin, cum, start, r, inside, hit)
	var way:Vector2 = hit[0]
	var axis:Array = resampled(BodyDeform._truncated(full, inside), BodyDeform.PATH_STEPS + 1)
	if(o.get("push") != null):
		var b:float = pushShare(o, bs, xa, start, dir, inside, r, {"tips": [start + way * inside, axis[axis.size() - 1]]}, hole)
		for i in range(axis.size()):
			axis[i] = (start + way * (inside * i / float(BodyDeform.PATH_STEPS))).linear_interpolate(axis[i], b)
	return [axis, full]

static func directHitAt(skin:Array, cum:Array, start:Vector2, r:float, dist:float) -> Array:
	var total:float = float(cum[cum.size() - 1])
	var step:float = float(DIRECT["step"]) * r
	var s:float = BodyDeform._project(skin, cum, start)
	var last:Array = []
	while(s < total):
		var v:Vector2 = BodyDeform._guide_at(skin, cum, s) - start
		var t:Vector2 = BodyDeform._guide_at(skin, cum, min(s + step, total)) - BodyDeform._guide_at(skin, cum, max(s - step, 0.0))
		if(v.length() >= r && t.length_squared() > 1e-12 && v.dot(t) > 0.0):
			last = [v.normalized(), s]
			if(v.length() >= dist):
				return last
		s += step
	return last

static func directBow(skin:Array, cum:Array, start:Vector2, r:float, inside:float, hit:Array) -> Array:
	var h:float = float(DIRECT["step"]) * r
	var total:float = float(cum[cum.size() - 1])
	var s:float = float(hit[1])
	var d:float = start.distance_to(BodyDeform._guide_at(skin, cum, s))
	var d1:float = clamp(total - s, h, d)
	s += d1
	var p1:Vector2 = BodyDeform._guide_at(skin, cum, s)
	var t1:Vector2 = BodyDeform._guide_at(skin, cum, s + h) - BodyDeform._guide_at(skin, cum, max(s - h, 0.0))
	if(t1.length_squared() < 1e-12):
		t1 = hit[0]
	var c0:Vector2 = start + Vector2(hit[0]) * (d * 2.0 / 3.0)
	var c1:Vector2 = p1 - t1.normalized() * (d1 * 2.0 / 3.0)
	var out:Array = []
	var n:int = int(max(ceil(2.0 * d / h), 2))
	for i in range(n):
		var t:float = float(i) / n
		var u:float = 1.0 - t
		out.append(start * u * u * u + c0 * 3.0 * u * u * t + c1 * 3.0 * u * t * t + p1 * t * t * t)
	var got:float = 0.0
	for i in range(1, n):
		got += Vector2(out[i]).distance_to(out[i - 1])
	var want:float = inside + float(DIRECT["past"]) * r
	while((got < want && (s <= total || got < inside)) || out.size() < 2):
		out.append(BodyDeform._guide_at(skin, cum, s))
		s += h
		got += h
	return out

static func resampled(line:Array, n:int) -> Array:
	var cum:Array = BodyDeform._cumulative_open(line)
	var total:float = float(cum[cum.size() - 1])
	var out:Array = []
	for q in range(n):
		out.append(BodyDeform._at_arc(line, cum, total * q / float(n - 1))[0])
	return out

const PUSH := {"give": 2.0, "relax": [1.0, 6.0], "rise": 3.0, "steps": 7, "exit": 3.0, "spring": [0.15, 1.2]}
static func pushShare(o:Dictionary, bs:Dictionary, xa:Transform, start:Vector2, dir:Vector2, inside:float, r:float,
		shape:Dictionary, hole:String) -> float:
	if(o.get("curve_cache") == null):
		return 1.0
	var give:float = (1.0 - clamp(float(o.get("push_hard", 0.5)), 0.0, 1.0)) * float(PUSH["give"])
	var need:float = needOf(bs, xa, start, dir, inside, shape, r, give)
	var now:float = float(o.get("now", 0.0))
	var st:Dictionary = pushState(o, hole)
	if(!st.has("b")):
		st["b"] = need
		st["inside"] = inside
		st["now"] = now
	var relax:float = clamp(float(o.get("push_relax", 0.5)), 0.0, 1.0)
	var D:float = max(lerp(float(PUSH["relax"][0]), float(PUSH["relax"][1]), relax) * r, 1e-6)
	var moved:float = inside - float(st["inside"])
	var b:float = float(st["b"])
	var dt:float = clamp(now - float(st["now"]), 0.0, 0.1)
	if(moved > 0.0):
		if(need < b):
			b = move_toward(b, need, moved / D)
		else:
			b = min(need, b + float(PUSH["rise"]) * dt)
	else:
		var tau:float = lerp(float(PUSH["spring"][0]), float(PUSH["spring"][1]), relax)
		b = max(b + (1.0 - b) * (1.0 - exp(-dt / tau)), need)
		if(moved < 0.0):
			b = min(b, inside / max(float(PUSH["exit"]) * r, 1e-6))
	st["b"] = b
	st["inside"] = inside
	st["now"] = now
	if(o.has("push_trace")):
		o["push_trace"].append([inside / r, need, b, -tipIn(bs, xa, tipOf(start, dir, inside, shape, b)) / r])
	return b

static func pushState(o:Dictionary, hole:String) -> Dictionary:
	var cache:Dictionary = o["curve_cache"]
	var key:String = "push/" + hole + "/" + str(int(o.get("cock_index", 0))) + "/" + str(bool(o.get("throat", false)))
	var action:String = str(o.get("action", ""))
	var st = cache.get(key)
	if(st == null || str(st["action"]) != action || float(o.get("now", 0.0)) < float(st.get("now", 0.0))):
		st = {"action": action}
		cache[key] = st
	return st

static func needOf(bs:Dictionary, xa:Transform, start:Vector2, dir:Vector2, inside:float, shape:Dictionary, r:float, give:float) -> float:
	var want:float = r * (1.0 - give)
	var inv:Transform = xa.affine_inverse()
	var scale:float = BodyDeform._scale(xa)
	var k:float = max(scale, 1e-6)
	var tip0:Vector2 = tipOf(start, dir, inside, shape, 0.0)
	var tip1:Vector2 = tipOf(start, dir, inside, shape, 1.0)
	var box := Rect2(BodyDeform._xy(inv.xform(BodyDeform._v3(start))), Vector2.ZERO)
	box = box.expand(BodyDeform._xy(inv.xform(BodyDeform._v3(tip0))))
	box = box.expand(BodyDeform._xy(inv.xform(BodyDeform._v3(tip1))))
	BodyDeform._sd_near(bs, box.grow((r + 0.3 * inside) / k + 2.0 * float(bs["cell"])))
	if(tipInBy(bs, inv, scale, tip0) >= want):
		return 0.0
	if(tipInBy(bs, inv, scale, tip1) < want):
		return 1.0
	var lo:float = 0.0
	var hi:float = 1.0
	for _i in range(int(PUSH["steps"])):
		var mid:float = 0.5 * (lo + hi)
		if(tipInBy(bs, inv, scale, tipOf(start, dir, inside, shape, mid)) >= want):
			hi = mid
		else:
			lo = mid
	return hi

static func tipOf(start:Vector2, dir:Vector2, inside:float, shape:Dictionary, b:float) -> Vector2:
	if(shape.has("arc")):
		return BodyDeform._arc_at(start, dir, scaled(shape["arc"], b, float(shape.get("aim", 0.0))), inside)
	return shape["tips"][0].linear_interpolate(shape["tips"][1], b)

static func tipIn(bs:Dictionary, xa:Transform, tip:Vector2) -> float:
	return tipInBy(bs, xa.affine_inverse(), BodyDeform._scale(xa), tip)

static func tipInBy(bs:Dictionary, inv:Transform, scale:float, tip:Vector2) -> float:
	return BodyDeform.BodyShape.sd(bs, BodyDeform._xy(inv.xform(BodyDeform._v3(tip)))) * scale

static func scaled(arc:Array, b:float, aim:float = 0.0) -> Array:
	var out:Array = arc.duplicate()
	for i in range(min(out.size(), 3)):
		out[i] = float(out[i]) * b
	if(out.size() > 0):
		out[0] = lerp(aim, float(arc[0]), b)
	return out

static func aimed(start:Vector2, dir:Vector2, arc:Array, inside:float) -> float:
	var tip:Vector2 = BodyDeform._arc_at(start, dir, arc, inside)
	if(tip.distance_squared_to(start) < 1e-12):
		return 0.0
	return dir.angle_to(tip - start)

static func keepLane(o:Dictionary, bs:Dictionary, start:Vector2, hole:String, gap:float, toward:float) -> void:
	var canal:Array = lane(bs, Transform.IDENTITY, start, hole, gap, toward)
	if(canal.size() < 2):
		return
	o["curve_cache"][hole + "/" + str(false)] = {"action": str(o.get("action", "")), "since": float(o.get("now", 0.0)) - float(BODY["learn"]),
		"lane": xformAll(o["pelvis"].affine_inverse(), canal)}

static func knobsMoved(was, now:Array) -> bool:
	if(was == null || was.size() != now.size()):
		return true
	for i in range(now.size()):
		if(abs(float(was[i]) - float(now[i])) > 0.02 * max(abs(float(now[i])), 0.05)):
			return true
	return false

static func xformAll(t:Transform2D, points:Array) -> Array:
	var out:Array = []
	for p in points:
		out.append(t.xform(p))
	return out

static func arcOf(start:Vector2, dir:Vector2, length:float, lane:Array, r:float, toward:float) -> Array:
	var cum:Array = BodyDeform._cumulative_open(lane)
	return BodyDeform._arc_to(start, dir, length, lane, cum, BodyDeform._project_soft(lane, cum, start, r), r, toward)

static func bestWay(lane:Array, h:Vector2, ref:Vector2, length:float, r:float) -> Vector2:
	if(lane.size() < 2 || ref == Vector2.ZERO):
		return ref
	var cum:Array = BodyDeform._cumulative_open(lane)
	var a:Array = BodyDeform._arc_fit(h, ref, length, lane, cum, BodyDeform._project(lane, cum, h), r, [0.0, 0.0], [0, 1])
	return ref.rotated(float(a[0]))

const LANE := {"slope": 0.6}
static func lane(bs:Dictionary, xa:Transform, start:Vector2, hole:String, gap:float, toward:float) -> Array:
	return BodyDeform._canal(BodyDeform._guide(bs, xa, 0.0, 0.0), BodyDeform._guide(bs, xa, 1.0, gap), start, hole,
		BodyDeform._guide(bs, xa, 1.0, 0.0), toward, float(LANE["slope"]))
