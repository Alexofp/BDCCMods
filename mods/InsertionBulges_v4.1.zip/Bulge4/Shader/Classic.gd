extends Reference
const Inject := preload("res://Bulge4/Shader/Inject.gd")
const KEY := "classic"
const META := "bulge4_classic"

static func shaderFor(source:Shader):
	if(source.has_meta(META)):
		var kept = source.get_meta(META)
		if(kept is Shader):
			return kept
		return null
	var made = Inject.shaderFor(source, KEY, partsFor(source.code))
	if(made == null):
		source.set_meta(META, false)
	else:
		source.set_meta(META, made)
	return made

static func partsFor(code:String) -> Dictionary:
	var parts:Dictionary = {"head": HEAD + SHAFT_CLIP_HEAD, "vertex_end": VERTEX_END, "fragment_top": FRAGMENT_TOP,
		"uv": "(UV - bulge_offset)", "fragment_end": FRAGMENT_END}
	if(hasWord(code, "UV_pattern") && hasWord(code, "pattern_size")):
		parts["extra"] = {"UV_pattern": "(UV_pattern - bulge_offset * pattern_size)"}
	if(hasWord(code, "texture_albedo")):
		parts["fragment_end"] = FRAGMENT_END + SKIRT_OVER_BODY
	parts["fragment_end"] += SHAFT_CLIP
	return parts

static func hasWord(code:String, word:String) -> bool:
	var re := RegEx.new()
	var _ok = re.compile("\\b" + word + "\\b")
	return re.search(code) != null

const HEAD := """
uniform vec4 bulge_seg0;
uniform vec4 bulge_par0;
uniform vec4 bulge_shp0 = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_shp0b = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_seg1;
uniform vec4 bulge_par1;
uniform vec4 bulge_shp1 = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_shp1b = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_seg2;
uniform vec4 bulge_par2;
uniform vec4 bulge_shp2 = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 bulge_shp2b = vec4(1.0, 1.0, 1.0, 1.0);
uniform float bulge_radial_on0 = 1.0;
uniform float bulge_radial_on1 = 1.0;
uniform float bulge_radial_on2 = 1.0;
uniform float bulge_shape_fidelity = 0.55;
uniform float bulge_rim_shape = 1.0;
uniform float bulge_push_radial = 0.0;
vec2 pushDirection(vec2 outward, float along, float across, float halfBand, float axisDepth, float amount) {
	if(amount <= 0.0) {
		return outward;
	}
	float beyond = sign(across) * max(abs(across) - halfBand, 0.0);
	vec2 radialDir = outward * max(along + axisDepth, max(axisDepth, 0.0001)) + vec2(-outward.y, outward.x) * beyond;
	if(length(radialDir) <= 0.0001) {
		return outward;
	}
	vec2 mixed = mix(outward, normalize(radialDir), amount);
	if(length(mixed) <= 0.0001) {
		return outward;
	}
	return normalize(mixed);
}
uniform vec2 bulge_aspect = vec2(1.0, 1.0);
uniform float bulge_expanded = 0.0;

uniform sampler2D bulge_baked;
uniform float bulge_baked_on = 0.0;
uniform float bulge_mesh_on = 0.0;
uniform vec2 bulge_rest_du = vec2(0.0);
uniform vec2 bulge_rest_dv = vec2(0.0);

varying float bulge_skirt;

float shapeAt(vec4 a, vec4 b, float u) {
	float f = clamp(u, 0.0, 1.0) * 6.0;
	float r = mix(a.x, a.y, smoothstep(0.0, 1.0, clamp(f, 0.0, 1.0)));
	r = mix(r, a.z, smoothstep(0.0, 1.0, clamp(f - 1.0, 0.0, 1.0)));
	r = mix(r, b.x, smoothstep(0.0, 1.0, clamp(f - 2.0, 0.0, 1.0)));
	r = mix(r, b.y, smoothstep(0.0, 1.0, clamp(f - 3.0, 0.0, 1.0)));
	r = mix(r, b.z, smoothstep(0.0, 1.0, clamp(f - 4.0, 0.0, 1.0)));
	r = mix(r, b.w, smoothstep(0.0, 1.0, clamp(f - 5.0, 0.0, 1.0)));
	return r;
}

uniform float bulge_band_plateau = 0.25;
uniform float bulge_union_overlap = 0.3;

vec4 bulgeField(vec2 uv, vec4 seg, vec4 par, vec4 shp, vec4 shp2, float radialOn) {
	if(par.x <= 0.0001 || par.y <= 0.0001) {
		return vec4(0.0);
	}
	vec2 p = uv * bulge_aspect;
	vec2 c = seg.xy * bulge_aspect;
	vec2 reach = seg.zw * bulge_aspect - c;
	float ramp = max(length(reach), 0.0001);
	vec2 outward = reach / ramp;
	vec2 rel = p - c;
	float along = dot(rel, outward);
	float across = dot(rel, vec2(-outward.y, outward.x));

	float plateau = across < 0.0 ? par.w : par.w * bulge_band_plateau;
	float h = clamp(1.0 - max(abs(across) - plateau, 0.0) / (par.x + par.w - plateau), 0.0, 1.0);
	h = h * h * (3.0 - 2.0 * h);
	float u = clamp(0.5 + across / max(2.0 * par.w, 0.0001), 0.0, 1.0);
	float profile = shapeAt(shp, shp2, u);
	h = h * mix(1.0, profile, bulge_shape_fidelity);
	float g = smoothstep(-ramp, 0.0, along);
	vec2 push = pushDirection(outward, along, across, par.w, shp.w, bulge_push_radial * radialOn);

	float weight = h * g;

	float axis = -shp.w;
	float r = max(shp.w + par.y, 0.0001);
	float tube = clamp(1.0 - abs(along - axis) / r, 0.0, 1.0);
	float lit = mix(weight, h * tube, bulge_rim_shape);
	return vec4(push * (par.y * weight) / bulge_aspect, weight, lit);
}
"""

const VERTEX_END := """
	bulge_skirt = 1.0 - COLOR.a;
	if(bulge_mesh_on > 0.5 && bulge_baked_on > 0.5) {
		vec2 moved = textureLod(bulge_baked, vec2(clamp(UV.x, 0.0, 1.0), 1.0 - clamp(UV.y, 0.0, 1.0)), 0.0).xy;
		VERTEX.xy += bulge_rest_du * moved.x + bulge_rest_dv * moved.y;
	}
"""

const FRAGMENT_TOP := """

	vec2 bulge_offset;
	float bulge_field;
	float bulge_shade;
	if(bulge_baked_on > 0.5) {
		vec4 baked = texture(bulge_baked, vec2(UV.x, 1.0 - UV.y));
		bulge_offset = baked.xy;
		bulge_field = baked.z;
		bulge_shade = baked.w;
	} else {
		vec4 bulge0 = bulgeField(UV, bulge_seg0, bulge_par0, bulge_shp0, bulge_shp0b, bulge_radial_on0);
		vec4 bulge1 = bulgeField(UV, bulge_seg1, bulge_par1, bulge_shp1, bulge_shp1b, bulge_radial_on1);
		vec4 bulge2 = bulgeField(UV, bulge_seg2, bulge_par2, bulge_shp2, bulge_shp2b, bulge_radial_on2);
		bulge_offset = bulge0.xy + bulge1.xy + bulge2.xy;
		float pushSum = length(bulge0.xy) + length(bulge1.xy) + length(bulge2.xy);
		float pushMost = max(max(length(bulge0.xy), length(bulge1.xy)), length(bulge2.xy));
		if(pushSum > 0.0) {
			bulge_offset *= (pushMost + bulge_union_overlap * (pushSum - pushMost)) / pushSum;
		}
		bulge_field = max(max(bulge0.w, bulge1.w), bulge2.w);
		bulge_shade = max(max(bulge0.w * bulge_par0.z, bulge1.w * bulge_par1.z), bulge2.w * bulge_par2.z);
	}
	if(bulge_mesh_on > 0.5) {
		bulge_offset = vec2(0.0);
	}
"""

const FRAGMENT_END := """
	if(bulge_shade > 0.001) {
		float rim = clamp(bulge_field * (1.0 - bulge_field) * 4.0, 0.0, 1.0);
		float core = smoothstep(0.55, 1.0, bulge_field);
		float shadeAmount = clamp(bulge_shade, 0.0, 1.5);
		ALBEDO *= mix(1.0, 0.78, rim * shadeAmount);
		ALBEDO *= mix(1.0, 1.13, core * shadeAmount);
	}
	vec2 bulge_uv = UV - bulge_offset;
	if(bulge_expanded > 0.5 && (bulge_uv.x < 0.0 || bulge_uv.x > 1.0 || bulge_uv.y < 0.0 || bulge_uv.y > 1.0)) {
		ALPHA = 0.0;
	}
"""

const SKIRT_OVER_BODY := """
	if(bulge_expanded > 0.5 && bulge_skirt > 0.001 && UV.x >= 0.0 && UV.x <= 1.0 && UV.y >= 0.0 && UV.y <= 1.0
			&& texture(texture_albedo, UV).a > 0.02) {
		ALPHA = 0.0;
	}
"""

const SHAFT_CLIP_HEAD := """
uniform float shaft_clip = 2.0;
uniform float shaft_clip_dir = -1.0;
uniform float shaft_clip_feather = 0.008;
uniform float shaft_clip_v = 0.0;
uniform float shaft_clip_slope = 0.0;
uniform float shaft_clip_keep = 2.0;
"""

const SHAFT_CLIP := """
	if(shaft_clip < 1.5) {
		float clipDistance = (UV.x - shaft_clip) * shaft_clip_dir + (UV.y - shaft_clip_v) * shaft_clip_slope;
		if(shaft_clip_keep < 1.5) {
			clipDistance = min(clipDistance, (UV.x - shaft_clip_keep) * shaft_clip_dir);
		}
		ALPHA *= 1.0 - smoothstep(-shaft_clip_feather, shaft_clip_feather, clipDistance);
	}
"""
