extends Reference
const Inject := preload("res://Bulge4/Shader/Inject.gd")
const Classic := preload("res://Bulge4/Shader/Classic.gd")
const KEY := "clip"

static func shaderFor(source:Shader):
	return Inject.shaderFor(source, KEY, {"head": Classic.SHAFT_CLIP_HEAD, "fragment_end": Classic.SHAFT_CLIP})
