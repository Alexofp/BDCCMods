extends Reference
const Fits := preload("res://Bulge4/Infer/Fits.gd")
const Measures := preload("res://Bulge4/Effects/Classic/Measures.gd")
const Settings := preload("res://Bulge4/Effects/Classic/Tuning.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const FieldMath := preload("res://Bulge4/Effects/Classic/Field.gd")
const CROTCH_SWITCH_MARGIN := 0.1
static func measuresFor(snapshot, engagement:Dictionary, prefer:String = ""):
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return null
	var shaftOwner = engagement.get("shaft")
	var holeOwner = engagement.get("hole_owner")
	var holeID:String = str(engagement.get("hole"))
	if(Measures.portalOwns(snapshot, shaftOwner, holeOwner)):
		return Measures.portalMeasuresFor(snapshot, shaftOwner, holeOwner, holeID)
	var shafts:Dictionary = {}
	if(typeof(snapshot.get("shafts")) == TYPE_DICTIONARY):
		shafts = snapshot["shafts"]
	var card = shafts.get(shaftOwner)
	if(!Fits.isShaft(card)):
		return null
	var length:float = float(card["length"])
	if(length < Fits.MIN_SHAFT_LENGTH):
		return null
	var base:Vector3 = card["base"]
	var tip:Vector3 = card["tip"]
	var dir:Vector3 = (tip - base) / length
	var holes:Dictionary = {}
	if(typeof(snapshot.get("holes")) == TYPE_DICTIONARY):
		holes = snapshot["holes"]
	var candidate = null
	if(holeID != HOLE_VAGINA):
		candidate = Fits.measure(holes, shaftOwner, holeOwner, holeID, base, tip, dir, length, false)
	else:
		var best = null
		var kept = null
		for crotch in [HOLE_VAGINA, HOLE_ANUS]:
			var open = Fits.measure(holes, shaftOwner, holeOwner, crotch, base, tip, dir, length, false)
			if(open != null && (best == null || float(open["fit"]) < float(best["fit"]))):
				best = open
			if(open != null && crotch == prefer):
				kept = open
		if(kept != null && best != null \
				&& float(kept["fit"]) <= float(best["fit"]) + CROTCH_SWITCH_MARGIN):
			best = kept
		if(best != null):
			candidate = best
	if(candidate == null):
		return null
	var oversize:Dictionary = {}
	if(typeof(snapshot.get("oversize")) == TYPE_DICTIONARY):
		oversize = snapshot["oversize"]
	var measures:Dictionary = Measures.measuresOf(candidate, card, oversize)
	measures["crotch_hole"] = str(candidate.get("hole", holeID))
	return measures
const HOLE_VAGINA := "vagina"
const HOLE_ANUS := "anus"
const HOLE_MOUTH := "mouth"
const CLIP_SKIN_OFFSET := 0.35
const ENTRY_DEADZONE := CLIP_SKIN_OFFSET
const FULL_DEPTH_FRACTION := 0.65
const FULLDEPTH_FLOOR_OVER_DEADZONE := 0.2
const BUMP_HEIGHT_MULT := 3.0
const BUMP_HEIGHT_MAX := 1.6
const SPREAD_OVERSIZE_CLAMP := [0.6, 1.4]
const BUMP_PUSH_MULT := 1.5
const BUMP_REACH_MIN := 0.25
const BUMP_REACH_MAX := 0.5
const BUMP_REACH_DEEPEST := 1.0
const AMPLITUDE_NO_FOLD_FRACTION = 1.0 / FieldMath.RAMP_SLOPE_PEAK
const BUMP_REACH_RATIO = 1.0 / AMPLITUDE_NO_FOLD_FRACTION
const BUMP_PUSH_MAX := 0.34
const MARGIN_USE := 0.85
const BUMP_TRAVEL := 1.0
const SOFT_LIMIT_KNEE := 0.75
const MESH_CEILING := 2.0
const ARCH := {"amount": 0.5, "max": 1.0, "scale": 1.0}
static func archFor(excess:float) -> float:
	return float(ARCH["amount"]) * float(ARCH["max"]) * tanh(max(excess, 0.0) / float(ARCH["scale"]))
static func arched(shape:Array, arch:float) -> Array:
	if(arch <= 0.0 || shape.size() < 2):
		return shape
	var out:Array = []
	for i in range(shape.size()):
		var x:float = float(i) / float(shape.size() - 1)
		out.append(float(shape[i]) * (1.0 + arch * sin(PI * x)) / (1.0 + arch))
	return out
const BUMP_COLUMN := 0.85
const BUMP_FRONT_PLANE := {"vagina": -0.35, "anus": -0.35}
const BUMP_FRONT_TILT := {"vagina": 0.0, "anus": 0.0}
const BUMP_FRONT_DIR := Vector3(-1.0, 0.0, 0.0)
const MAX_INSIDE_LENGTH := {"vagina": 3.0, "anus": 3.0, "mouth": 3.0}
const GIRTH_REFERENCE := 0.110
const SIZE_RESPONSE := 0.5
const SIZE_RESPONSE_MAX := 3.0
const MIN_AMPLITUDE := 0.005
const SHAPE_GAIN_MAX := 1.35
const SHAFT_AXIS_MIN_IN_PLANE := 0.5
const SHAFT_AXIS_MIN_FORWARD := 0.5
const SHADE_DEPTH_GAIN := 0.9
const BUMP_TRAVEL_DIR := {"vagina": 1.0, "anus": 1.0, "mouth": -1.0}
static func buildFor(rig, measures:Dictionary, card, zone:String):
	if(typeof(rig) != TYPE_DICTIONARY || typeof(rig.get("hips")) != TYPE_TRANSFORM):
		return null
	if(!Fits.isShaft(card)):
		return null
	var anchorRest = bulgeOriginFor(rig, zone)
	if(typeof(measures.get("anchor_hole")) == TYPE_STRING && typeof(rig.get("origin")) == TYPE_DICTIONARY \
			&& rig["origin"].get(measures["anchor_hole"]) != null):
		anchorRest = rig["origin"][measures["anchor_hole"]]
	if(anchorRest == null):
		return null
	var base:Vector3 = card["base"]
	var tip:Vector3 = card["tip"]
	if(typeof(measures.get("shaft_base")) == TYPE_VECTOR3 \
			&& typeof(measures.get("shaft_tip")) == TYPE_VECTOR3):
		base = measures["shaft_base"]
		tip = measures["shaft_tip"]
	var length:float = float(card["length"])
	if(length < Fits.MIN_SHAFT_LENGTH):
		return null
	var hips:Transform = rig["hips"]
	var tipRest:Vector3 = hips.xform(tip)
	var baseRest:Vector3 = hips.xform(base)
	var shaftFlat:Vector3 = Vector3(tipRest.x - baseRest.x, tipRest.y - baseRest.y, 0.0)
	var depth:float = float(measures.get("depth", 0.0))
	var oversize:float = float(measures.get("oversize", 0.0))
	var along:float = length - depth
	var deadzone:float = float(measures.get("deadzone", ENTRY_DEADZONE))
	var throatArc:float = -1.0
	var neckLength:float = 0.0
	var bent = null
	var throatBody:bool = zone == HOLE_MOUTH && mouthLikeCrotch()
	var contour:Array = []
	if(typeof(rig.get("contour")) == TYPE_ARRAY):
		contour = rig["contour"]
	if(throatBody):
		var neckAxis = rig.get("neck_axis")
		if(typeof(neckAxis) == TYPE_DICTIONARY && typeof(neckAxis.get("top")) == TYPE_VECTOR3 \
				&& typeof(measures.get("entry")) == TYPE_VECTOR3 && (tip - base).length() > 0.0001):
			neckLength = float(neckAxis.get("length", 0.0))
			var chain = rig.get("spine_chain")
			if(typeof(chain) == TYPE_ARRAY && chain.size() >= 2):
				bent = throatPath(measures["entry"], (tip - base).normalized(), chain, depth, length)
				throatArc = float(bent["in_head"])
			else:
				throatArc = arcLength(measures["entry"], (tip - base).normalized(), neckAxis["top"], -neckAxis["dir"]) \
					* mouthLength()
			deadzone = throatArc
	var fullDepth:float = max(length * FULL_DEPTH_FRACTION, deadzone + FULLDEPTH_FLOOR_OVER_DEADZONE)
	var depthAmount:float = clamp((depth - deadzone) / max(fullDepth - deadzone, 0.01), 0.0, 1.0)
	depthAmount = depthAmount * depthAmount * (3.0 - 2.0 * depthAmount)
	var mouthLimit:float = float(SIMPLE["reach"])
	var mouthRise:float = 0.0
	if(zone == HOLE_MOUTH && !throatBody):
		mouthRise = max(depth - ENTRY_DEADZONE, 0.0)
		var axis = rig.get("neck_axis")
		if(typeof(axis) == TYPE_DICTIONARY):
			mouthRise = max(axisRise(axis, measures.get("entry"), tip) - ENTRY_DEADZONE, 0.0)
	var girth:float = insertedGirth(measures, zone)
	var spread:float = min(girth * BUMP_HEIGHT_MULT \
		* clamp(oversize, SPREAD_OVERSIZE_CLAMP[0], SPREAD_OVERSIZE_CLAMP[1]), BUMP_HEIGHT_MAX)
	if(crotchLike(zone)):
		spread = spread * lerp(END_FADE_MIN, 1.0, endFade())
	var amplitude:float = pushFor(girth, depthAmount, oversize, zone)
	if(!crotchLike(zone)):
		amplitude = pushFor(girth, depthAmount, oversize, zone, float(Settings.value("bulgeOralSimpleSize")))
	var travelAxis:Vector3 = travelAxisFor(zone, shaftFlat)
	if(zone != HOLE_MOUTH && directionMode() != DIRECTION_BLEND):
		var rise0:float = max((tipRest - anchorRest).dot(travelAxis), 0.0)
		var travel0:float = softLimit(rise0, float(MAX_INSIDE_LENGTH.get(zone, 1.0))) * BUMP_TRAVEL
		var atY:float = anchorRest.y + travelAxis.y * (travel0 * (1.0 - BUMP_COLUMN * 0.5))
		travelAxis = directedAxis(directionMode(), zone, shaftFlat, contour, atY, travelAxis)
	var tipAlong:float = (tipRest - anchorRest).dot(travelAxis)
	var pathStart:float = 0.0
	if(throatBody):
		pathStart = ENTRY_DEADZONE
		if(throatArc >= 0.0):
			pathStart = throatArc
			anchorRest = anchorRest - travelAxis * neckLength
		tipAlong = max(depth - pathStart, 0.0)
	var travel:float = 0.0
	var excess:float = 0.0
	if(!crotchLike(zone)):
		travel = softLimit(mouthRise, mouthLimit) * BUMP_TRAVEL
	else:
		var rise:float = max(tipAlong, 0.0)
		travel = softLimit(rise, float(MAX_INSIDE_LENGTH.get(zone, 1.0))) * BUMP_TRAVEL
		excess = rise - softLimit(rise, float(MAX_INSIDE_LENGTH.get(zone, 1.0)))
	var column:float = BUMP_COLUMN
	if(!crotchLike(zone)):
		column = float(SIMPLE["column"])
	var columnHalf:float = abs(travel) * column * 0.5
	var frontAxis:Vector3 = frontOf(travelAxis).normalized()
	var span:Array = [travel * (1.0 - column), travel]
	if(throatBody):
		span = [0.0, travel]
		columnHalf = (span[1] - span[0]) * 0.5
	var alongAxis:Vector3 = anchorRest + travelAxis * ((span[0] + span[1]) * 0.5)
	var lip:Dictionary = lipFor(zone, measures, hips, base, tip, card, contour)
	if(zone != HOLE_MOUTH && lip["crossing"] != null && startAtMouth()):
		span[0] = min((lip["crossing"] - anchorRest).dot(travelAxis), span[0])
		columnHalf = max(span[1] - span[0], 0.0) * 0.5
		alongAxis = anchorRest + travelAxis * ((span[1] + span[0]) * 0.5)
	var bandFrom:float = 0.0
	var bandTo:float = 1.0
	if(throatBody):
		if(depth > 0.0001):
			bandFrom = clamp((pathStart + span[0]) / depth, 0.0, 1.0)
			bandTo = clamp((pathStart + span[1]) / depth, 0.0, 1.0)
			if(bent != null):
				bandFrom = clamp(pathStart / depth, 0.0, 1.0)
				bandTo = 1.0
	elif(tipAlong > 0.0001):
		bandFrom = clamp(span[0] / tipAlong, 0.0, 1.0)
		bandTo = clamp(span[1] / tipAlong, 0.0, 1.0)
	measures = withOtherHalf(measures, card, hips, frontAxis, zone)
	var band:Array = bandSamples(measures, bandFrom, bandTo)
	if(throatBody):
		var peak:float = 0.0
		for girthHere in band:
			peak = max(peak, girthHere)
		if(peak <= 0.0):
			peak = girth
		depthAmount = tipIn(tipAlong, peak)
		amplitude = pushFor(peak, depthAmount, oversize, zone)
	else:
		amplitude = amplitude * shapeGain(measures, zone, band)
	var arch:float = archFor(excess)
	amplitude = amplitude * (1.0 + arch)
	var shade:float = clamp(depthAmount * oversize * SHADE_DEPTH_GAIN, 0.0, 1.0) \
		* float(Settings.value("bulgeShade"))
	var here = contourAt(contour, alongAxis.y)
	var frontPlane:float = float(BUMP_FRONT_PLANE.get(zone, -0.35))
	if(here != null):
		frontPlane = here.x
	var tilt:float = float(BUMP_FRONT_TILT.get(zone, 0.0))
	if(zone == HOLE_MOUTH && (!mouthLikeCrotch() || here == null)):
		frontPlane = float(SIMPLE["front_plane"])
		tilt = float(SIMPLE["tilt"])
	var centreRest:Vector3 = Vector3(frontPlane, alongAxis.y, alongAxis.z)
	var frontDir:Vector3 = (frontAxis + Vector3(0.0, tilt, 0.0)).normalized()
	var margins:Array = []
	if(typeof(rig.get("margins")) == TYPE_ARRAY):
		margins = rig["margins"]
	var room:float = pushCeiling(margins, here)
	if(throatBody):
		room = channelCeiling(contour, margins, anchorRest, travelAxis, float(MAX_INSIDE_LENGTH[HOLE_MOUTH]))
	if(throatBody && bent != null && throatStretch() && depth > 0.0001):
		var shapeNow = measures.get("shape")
		if(typeof(shapeNow) == TYPE_ARRAY && !shapeNow.empty()):
			var girthTop:float = sampleAt(shapeNow, clamp(pathStart / depth, 0.0, 1.0))
			var topAt:Vector3 = anchorRest + travelAxis * span[0]
			var skin = contourAt(contour, topAt.y)
			var skinX:float = frontPlane
			if(skin != null):
				skinX = skin.x
			lip["at"] = Vector3(skinX, topAt.y, topAt.z)
			lip["dir"] = travelAxis
			lip["amount"] = girthTop * THROAT_STRETCH * tipIn(tipAlong, girthTop)
			lip["reach"] = girthTop * LIP_REACH_GIRTHS
			lip["motion"] = 0.0
	var deepest:float = reachMax()
	if(!crotchLike(zone)):
		deepest = simpleReachMax()
	var ceiling:float = MESH_CEILING
	if(FieldMath.warpMode() != FieldMath.WARP_MESH):
		ceiling = room
		if(FieldMath.capped()):
			ceiling = min(room, deepest * AMPLITUDE_NO_FOLD_FRACTION)
	var wanted:float = softLimit(amplitude, room)
	amplitude = softLimit(amplitude, ceiling)
	var reach:float = clamp(amplitude * BUMP_REACH_RATIO, BUMP_REACH_MIN, deepest)
	if(FieldMath.capped()):
		amplitude = min(amplitude, reach * AMPLITUDE_NO_FOLD_FRACTION)
	var out:Dictionary = {
		"zone": zone,
		"centre_rest": centreRest,
		"front_dir_rest": frontDir,
		"travel_dir_rest": travelAxis,
		"reach": reach,
		"spread": spread,
		"amplitude": amplitude,
		"shade": shade,
		"column_half": columnHalf,
		"band_from": bandFrom,
		"band_to": bandTo,
		"shape": arched(normalisedShape(zone, band), arch),
		"arch": arch,
		"bulk": max(wanted - amplitude, 0.0),
		"axis_depth": axisDepthBelow(centreRest, baseRest, tipRest, frontDir),
		"clip_on_axis": clipOnAxis(along, measures),
		"lip_rest": lip["at"],
		"lip_dir_rest": lip["dir"],
		"lip": lip["amount"],
		"lip_reach": lip["reach"],
		"lip_motion": lip["motion"],
		"visible": shows(amplitude, float(lip["amount"])),
	}
	if(!crotchLike(zone)):
		out["simple"] = true
		out["reach_max"] = deepest
		out["plateau"] = float(SIMPLE["plateau"])
	return out
static func clipOnAxis(along:float, measures:Dictionary) -> float:
	var at:float = float(measures.get("clip_along", along))
	return max(at + float(measures.get("clip_skin", CLIP_SKIN_OFFSET)), CLIP_SKIN_OFFSET)
static func withAmplitude(intent:Dictionary, amplitude:float) -> Dictionary:
	var out:Dictionary = intent.duplicate()
	var reach:float = clamp(amplitude * BUMP_REACH_RATIO, BUMP_REACH_MIN, float(intent.get("reach_max", reachMax())))
	reach = max(reach, float(intent.get("reach_keep", 0.0)))
	out["amplitude"] = amplitude
	if(FieldMath.capped()):
		out["amplitude"] = min(amplitude, reach * AMPLITUDE_NO_FOLD_FRACTION)
	out["reach"] = reach
	out["visible"] = shows(float(out["amplitude"]), float(intent.get("lip", 0.0)))
	return out
const MIN_LIP := 0.002
static func shows(amplitude:float, lip:float) -> bool:
	return amplitude > MIN_AMPLITUDE || lip > MIN_LIP
const SPRING_FLOOR := 0.0002
static func withSpring(intent:Dictionary, amplitude:float, lip:float, stroke:float = 0.0) -> Dictionary:
	var given:Dictionary = intent.duplicate()
	given["lip"] = lip
	given["lip_stroke"] = stroke
	var out:Dictionary = withAmplitude(given, amplitude)
	out["visible"] = springShows(float(out["amplitude"]), lip)
	return out
static func springShows(amplitude:float, lip:float) -> bool:
	return amplitude > SPRING_FLOOR || lip > MIN_LIP
static func bulgeOriginFor(rig:Dictionary, zone:String):
	var origin:Dictionary = {}
	if(typeof(rig.get("origin")) == TYPE_DICTIONARY):
		origin = rig["origin"]
	if(zone == HOLE_MOUTH):
		return origin.get(HOLE_MOUTH)
	var vagina = origin.get(HOLE_VAGINA)
	var anus = origin.get(HOLE_ANUS)
	if(vagina == null):
		return anus
	if(anus == null):
		return vagina
	return (vagina + anus) * 0.5
static func insertedGirth(measures:Dictionary, zone:String) -> float:
	var entry:float = float(measures.get("girth_at_entry", 0.0))
	var weight:float = clamp(float(Settings.value("bulgeInsertedGirth")), 0.0, 1.0)
	if(zone == HOLE_MOUTH || weight <= 0.0):
		return entry
	var shape = measures.get("shape")
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 1):
		return entry
	var total:float = 0.0
	for girthHere in shape:
		total += float(girthHere)
	var mean:float = total / float(shape.size())
	if(mean <= 0.0):
		return entry
	return lerp(entry, mean, weight)
static func withOtherHalf(measures:Dictionary, card, hips:Transform, frontAxis:Vector3,
		zone:String = "") -> Dictionary:
	if(typeof(measures.get("shape_up")) != TYPE_ARRAY || typeof(card.get("up")) != TYPE_VECTOR3):
		return measures
	var follow:float = clamp(float(Settings.forZone("bulgeOtherHalfFollow", zone)), 0.0, 1.0)
	var add:float = clamp(float(Settings.forZone("bulgeOtherHalfAdd", zone)), 0.0, 1.0)
	if(follow <= 0.0 && add <= 0.0):
		return measures
	var key:String = "shape_up"
	if(hips.basis.xform(card["up"]).dot(frontAxis) < 0.0):
		key = "shape_down"
	var out:Dictionary = measures.duplicate()
	out["shape"] = otherHalfShape(measures["shape"], measures[key], follow, add)
	return out
static func otherHalfShape(shape:Array, half:Array, follow:float, add:float) -> Array:
	if(half.size() != shape.size() || half.empty()):
		return shape
	var mean:float = 0.0
	for one in half:
		mean += float(one)
	mean = mean / float(half.size())
	var out:Array = []
	for i in range(shape.size()):
		out.append(max(lerp(float(shape[i]), float(half[i]), follow) + add * (float(half[i]) - mean), 0.0))
	return out
static func shapeGain(measures:Dictionary, zone:String, band:Array) -> float:
	if(!crotchLike(zone)):
		return 1.0
	if(band.empty()):
		return 1.0
	var base:float = insertedGirth(measures, zone)
	if(base <= 0.0):
		return 1.0
	var peak:float = base
	for girthHere in band:
		peak = max(peak, girthHere)
	var fidelity:float = clamp(float(Settings.forZone("bulgeShapeFidelity", zone)), 0.0, 1.0)
	return lerp(1.0, min(peak / base, SHAPE_GAIN_MAX), fidelity)
static func normalisedShape(zone:String, band:Array) -> Array:
	if(!crotchLike(zone)):
		return []
	if(band.empty()):
		return []
	var peak:float = 0.0
	for girthHere in band:
		peak = max(peak, girthHere)
	if(peak <= 0.0):
		return []
	var fidelity:float = clamp(float(Settings.forZone("bulgeShapeFidelity", zone)), 0.0, 1.0)
	var flat:float = 1.0
	if(zone == HOLE_MOUTH):
		flat = 0.0
		for girthHere in band:
			flat += girthHere / peak
		flat = flat / float(band.size())
	var out:Array = []
	for girthHere in band:
		out.append(lerp(flat, girthHere / peak, fidelity))
	return out
static func bandSamples(measures:Dictionary, fromF:float, toF:float) -> Array:
	var shape = measures.get("shape")
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 1):
		return []
	if(shape.size() == 1):
		return [float(shape[0])]
	var out:Array = []
	for i in range(shape.size()):
		out.append(sampleAt(shape, lerp(fromF, toF, float(i) / float(shape.size() - 1))))
	return out
static func sampleAt(shape:Array, f:float) -> float:
	var last:int = shape.size() - 1
	if(last <= 0):
		return float(shape[0])
	var at:float = clamp(f, 0.0, 1.0) * float(last)
	var low:int = int(floor(at))
	var high:int = int(min(low + 1, last))
	return lerp(float(shape[low]), float(shape[high]), at - low)
static func anatomicalAxisFor(zone:String) -> Vector3:
	var inward = null
	if(zone != HOLE_MOUTH):
		inward = BulgeDoll.ORIFICE_INWARD.get(zone)
	if(inward != null):
		var flat:Vector3 = Vector3(inward.x, inward.y, 0.0)
		if(flat.length() > 0.0001):
			return flat.normalized()
	return Vector3(0.0, float(BUMP_TRAVEL_DIR.get(zone, 1.0)), 0.0)
static func travelAxisFor(zone:String, shaftFlat:Vector3) -> Vector3:
	var anatomical:Vector3 = anatomicalAxisFor(zone)
	if(zone == HOLE_MOUTH):
		return anatomical
	if(shaftFlat.length() < SHAFT_AXIS_MIN_IN_PLANE):
		return anatomical
	var candidate:Vector3 = shaftFlat.normalized()
	if(candidate.dot(anatomical) <= 0.0):
		return anatomical
	var blend:float = clamp(frontOf(candidate).length() / SHAFT_AXIS_MIN_FORWARD, 0.0, 1.0)
	return anatomical.linear_interpolate(candidate, blend).normalized()
const DIRECTION_BLEND := "blend"
const DIRECTION_SHAFT := "shaft"
const DIRECTION_BELLY := "belly"
const DIRECTION_TORSO := "torso"
const BELLY_TANGENT_SPAN := 0.3
const DIRECTION := {"mode": DIRECTION_BLEND}
static func directionMode() -> String:
	return str(DIRECTION["mode"])
static func directedAxis(mode:String, zone:String, shaftFlat:Vector3, contour:Array, atY:float,
		fallback:Vector3) -> Vector3:
	var anatomical:Vector3 = anatomicalAxisFor(zone)
	if(mode == DIRECTION_SHAFT):
		if(shaftFlat.length() < SHAFT_AXIS_MIN_IN_PLANE || shaftFlat.normalized().dot(anatomical) <= 0.0):
			return fallback
		var along:Vector3 = shaftFlat.normalized()
		var blend:float = clamp(frontOf(along).length() / SHAFT_AXIS_MIN_FORWARD, 0.0, 1.0)
		return fallback.linear_interpolate(along, blend).normalized()
	if(mode == DIRECTION_TORSO):
		return Vector3(0.0, 1.0, 0.0)
	if(mode == DIRECTION_BELLY):
		var below = contourAt(contour, atY - BELLY_TANGENT_SPAN)
		var above = contourAt(contour, atY + BELLY_TANGENT_SPAN)
		if(below == null || above == null):
			return fallback
		var tangent:Vector3 = Vector3(above.x - below.x, 2.0 * BELLY_TANGENT_SPAN, 0.0).normalized()
		if(tangent.dot(anatomical) < 0.0):
			tangent = -tangent
		return tangent
	return fallback
const LIP := {"amount": 0.0, "motion": "open", "anchor": "hole", "start": false, "fade": 1.0,
	"mouth_like": false, "mouth_length": 0.4, "throat_stretch": true, "swallow": false}
const LIP_MOTIONS := ["open", "out", "in", "open_stroke"]
const LIP_ANCHOR_OUTLINE := "outline"
const CROSSING_STEPS := 48
const LIP_OPEN_GIRTHS := 1.0
const LIP_REACH_GIRTHS := 3.0
static func refresh() -> void:
	var direction:Dictionary = DIRECTION
	direction["mode"] = str(Settings.value("bulgeDirection"))
	var live:Dictionary = LIP
	live["amount"] = clamp(float(Settings.value("bulgeLipAmount")), 0.0, 1.0)
	live["motion"] = str(Settings.value("bulgeLipMotion"))
	live["anchor"] = str(Settings.value("bulgeLipAnchor"))
	live["start"] = bool(Settings.value("bulgeStartAtMouth"))
	live["fade"] = clamp(float(Settings.value("bulgeEndFade")), 0.0, 1.0)
	live["mouth_like"] = str(Settings.value("bulgeThroatPath")) == THROAT_BODY
	live["mouth_length"] = clamp(float(Settings.value("bulgeOralMouthLength")), 0.0, 1.0)
	live["throat_stretch"] = bool(Settings.value("bulgeOralThroatStretch"))
	live["swallow"] = bool(Settings.value("bulgeOralSwallow"))
const END_FADE_MIN := 0.2
static func endFade() -> float:
	return float(LIP["fade"])
const THROAT_BODY := "body"
static func mouthLikeCrotch() -> bool:
	return bool(LIP["mouth_like"])
const THROAT_STRETCH := 1.0
static func throatStretch() -> bool:
	return bool(LIP["throat_stretch"])
static func swallowOn() -> bool:
	return bool(LIP["swallow"])
static func mouthLength() -> float:
	return float(LIP["mouth_length"])
const ARC_STEPS := 16
static func arcLength(from:Vector3, outDir:Vector3, to:Vector3, inDir:Vector3) -> float:
	var handle:float = (to - from).length() / 3.0
	var out:Vector3 = from + outDir * handle
	var back:Vector3 = to - inDir * handle
	var total:float = 0.0
	var last:Vector3 = from
	for i in range(1, ARC_STEPS + 1):
		var t:float = float(i) / float(ARC_STEPS)
		var s:float = 1.0 - t
		var here:Vector3 = from * (s * s * s) + out * (3.0 * s * s * t) + back * (3.0 * s * t * t) + to * (t * t * t)
		total += (here - last).length()
		last = here
	return total
const PATH_STEPS := 32
static func throatPath(entry:Vector3, cockDir:Vector3, chain:Array, depth:float, length:float) -> Dictionary:
	var weld:float = min(length, chainLength(chain))
	var welded:Array = chainPoint(chain, weld)
	var top:Vector3 = chain[0]
	var gap:float = (welded[0] - entry).length()
	var p1:Vector3 = entry + cockDir * gap / 3.0 * mouthLength()
	var p2:Vector3 = welded[0] - welded[1] * gap / 3.0
	var arc:float = 0.0
	var last:Vector3 = entry
	var nearest:float = (entry - top).length()
	var inHead:float = 0.0
	for i in range(1, PATH_STEPS + 1):
		var t:float = float(i) / float(PATH_STEPS)
		var s:float = 1.0 - t
		var here:Vector3 = entry * (s * s * s) + p1 * (3.0 * s * s * t) + p2 * (3.0 * s * t * t) + welded[0] * (t * t * t)
		var piece:Vector3 = here - last
		var size:float = piece.length()
		if(size > 0.00001):
			var f:float = clamp((top - last).dot(piece) / (size * size), 0.0, 1.0)
			var away:float = (last + piece * f - top).length()
			if(away < nearest):
				nearest = away
				inHead = arc + size * f
		arc += size
		last = here
	return {"start": 0.0, "tip": max(depth - inHead, 0.0), "in_head": min(inHead, max(depth, 0.0))}
static func chainLength(chain:Array) -> float:
	var total:float = 0.0
	for i in range(chain.size() - 1):
		total += (chain[i + 1] - chain[i]).length()
	return total
static func chainPoint(chain:Array, down:float) -> Array:
	var walked:float = 0.0
	for i in range(chain.size() - 1):
		var piece:Vector3 = chain[i + 1] - chain[i]
		if(walked + piece.length() >= down || i == chain.size() - 2):
			return [chain[i] + piece.normalized() * (down - walked), piece.normalized()]
		walked += piece.length()
	return [chain[0], Vector3.DOWN]
static func crotchLike(zone:String) -> bool:
	return zone != HOLE_MOUTH || mouthLikeCrotch()
static func lipAnchor() -> String:
	return str(LIP["anchor"])
static func startAtMouth() -> bool:
	return bool(LIP["start"])
static func lipAmount() -> float:
	return float(LIP["amount"])
static func lipMotion() -> String:
	return str(LIP["motion"])
static func crossingOf(baseRest:Vector3, tipRest:Vector3, contour:Array) -> float:
	if(contour.empty()):
		return -1.0
	var was:float = 0.0
	for i in range(CROSSING_STEPS + 1):
		var f:float = float(i) / float(CROSSING_STEPS)
		var p:Vector3 = baseRest.linear_interpolate(tipRest, f)
		var here = contourAt(contour, p.y)
		if(here == null):
			return -1.0
		var past:float = p.x - here.x
		if(past >= 0.0):
			if(i == 0):
				return -1.0
			return (float(i - 1) + was / (was - past)) / float(CROSSING_STEPS)
		was = past
	return -1.0
static func lipFor(zone:String, measures:Dictionary, hips:Transform, base:Vector3, tip:Vector3,
		card = null, contour:Array = []) -> Dictionary:
	var out:Dictionary = {"at": Vector3.ZERO, "dir": Vector3(0.0, 1.0, 0.0), "amount": 0.0, "reach": 0.0,
		"motion": float(max(LIP_MOTIONS.find(lipMotion()), 0)), "crossing": null}
	var girth:float = float(measures.get("girth_at_entry", 0.0))
	if(zone == HOLE_MOUTH || typeof(measures.get("entry")) != TYPE_VECTOR3 || girth <= 0.0001):
		return out
	var dir:Vector3 = hips.basis.xform(tip - base)
	dir.z = 0.0
	if(dir.length() <= 0.0001):
		return out
	var inside:float = float(measures.get("depth", 0.0))
	out["at"] = hips.xform(measures["entry"])
	if(lipAnchor() == LIP_ANCHOR_OUTLINE && typeof(card) == TYPE_DICTIONARY):
		var baseRest:Vector3 = hips.xform(base)
		var tipRest:Vector3 = hips.xform(tip)
		var f:float = crossingOf(baseRest, tipRest, contour)
		if(f >= 0.0):
			var length:float = (tip - base).length()
			var there:float = Measures.girthFrom(card, float(card.get("length", length)) * f)
			if(there > 0.0001):
				girth = there
			out["at"] = baseRest.linear_interpolate(tipRest, f)
			out["crossing"] = out["at"]
			inside = length * (1.0 - f)
	var open:float = clamp(inside / (girth * LIP_OPEN_GIRTHS), 0.0, 1.0)
	out["dir"] = dir.normalized()
	out["amount"] = girth * lipAmount() * open
	out["reach"] = girth * LIP_REACH_GIRTHS
	return out
static func frontOf(axis:Vector3) -> Vector3:
	return BUMP_FRONT_DIR - axis * BUMP_FRONT_DIR.dot(axis)
static func reachMax() -> float:
	return lerp(BUMP_REACH_MAX, BUMP_REACH_DEEPEST, clamp(float(Settings.value("bulgeReachDeeper")), 0.0, 1.0))
static func softLimit(value:float, limit:float) -> float:
	var knee:float = limit * SOFT_LIMIT_KNEE
	if(value <= knee):
		return value
	var rest:float = max(limit - knee, 0.001)
	return knee + rest * tanh((value - knee) / rest)
static func axisRise(axis, mouthAnchor:Vector3, tip:Vector3) -> float:
	var origin:Vector3 = axis["origin"]
	var dir:Vector3 = axis["dir"]
	return (mouthAnchor - origin).dot(dir) - (tip - origin).dot(dir)
static func axisDepthBelow(centreRest:Vector3, baseRest:Vector3, tipRest:Vector3, frontDir:Vector3) -> float:
	var line:Vector3 = tipRest - baseRest
	var lengthSq:float = line.length_squared()
	var nearest:Vector3 = baseRest
	if(lengthSq > 0.0001):
		nearest = baseRest + line * clamp((centreRest - baseRest).dot(line) / lengthSq, 0.0, 1.0)
	return max((centreRest - nearest).dot(frontDir), 0.0)
static func contourAt(contour:Array, restY:float):
	if(contour.empty()):
		return null
	var first:Vector3 = contour[0]
	if(restY <= first.x):
		return Vector2(first.y, first.z)
	var last:Vector3 = contour[contour.size() - 1]
	if(restY > last.x):
		return Vector2(last.y, last.z)
	var low:int = 1
	var high:int = contour.size() - 1
	while(low < high):
		var mid:int = (low + high) >> 1
		if(contour[mid].x < restY):
			low = mid + 1
		else:
			high = mid
	var above:Vector3 = contour[low]
	var below:Vector3 = contour[low - 1]
	var span:float = above.x - below.x
	var t:float = 0.0
	if(span > 0.0001):
		t = (restY - below.x) / span
	return Vector2(lerp(below.y, above.y, t), lerp(below.z, above.z, t))
static func pushFor(girth:float, depthAmount:float, oversize:float, zone:String, size:float = -1.0) -> float:
	var sizeResponse:float = clamp(SIZE_RESPONSE * girth / GIRTH_REFERENCE, 0.0, SIZE_RESPONSE_MAX)
	if(size < 0.0):
		size = float(Settings.forZone("bulgeSizeModifier", zone))
	return girth * BUMP_PUSH_MULT * sizeResponse * depthAmount * oversize * size
const SIMPLE := {"reach": 3.0, "column": 1.0, "front_plane": -0.28, "tilt": 0.155, "reach_deeper": 0.3,
	"plateau": 0.25}
static func simpleReachMax() -> float:
	return lerp(BUMP_REACH_MAX, BUMP_REACH_DEEPEST, float(SIMPLE["reach_deeper"]))
const TIP_IN_GIRTHS := 2.0
static func tipIn(inside:float, girth:float) -> float:
	var t:float = clamp(inside / max(girth * TIP_IN_GIRTHS, 0.01), 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)
const CHANNEL_STEPS := 12
static func channelCeiling(contour:Array, margins:Array, top:Vector3, dir:Vector3, length:float) -> float:
	var room:float = INF
	for i in range(CHANNEL_STEPS + 1):
		var here = contourAt(contour, (top + dir * (length * float(i) / float(CHANNEL_STEPS))).y)
		if(here != null && here.y > 0.0):
			room = min(room, here.y * MARGIN_USE)
	if(room == INF):
		return pushCeiling(margins, null)
	return room
static func pushCeiling(margins:Array, here) -> float:
	if(here != null && here.y > 0.0):
		return here.y * MARGIN_USE
	var room:float = -1.0
	for one in margins:
		var margin:float = float(one)
		if(margin <= 0.0):
			continue
		if(room < 0.0):
			room = margin
		else:
			room = min(room, margin)
	if(room <= 0.0):
		return BUMP_PUSH_MAX
	return room * MARGIN_USE
