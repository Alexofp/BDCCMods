extends Reference
const PortalScenes := preload("res://Bulge4/Infer/PortalScenes.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const HOLE_MOUTH := "mouth"
const HOLE_VAGINA := "vagina"
const HOLE_ANUS := "anus"
const SLOT_HEAD := "head"
const DEFAULT_OVERSIZE := 0.9
const FALLBACK_GIRTH:float = 0.0
const PROFILE_MAX:float = 1.6
const STROKE_REFERENCE_LENGTH := 1.678
const PORTAL_AXIS_REST := Vector3(0.0, 1.0, 0.0)
const SHAPE := {"samples": BulgeUtils.SHAPE_TRANSPORT}

static func contextFor(stageScene, relations:Array) -> Dictionary:
	var context:Dictionary = Frame.of(stageScene, relations)
	if(!context.has("rig")):
		context["rig"] = {}
		context["oversize"] = {}
	var eyes = context["eyes"]
	var rigs:Dictionary = context["rig"]
	var oversize:Dictionary = context["oversize"]
	for r in relations:
		var owner = r["hole_owner"]
		if(!rigs.has(owner)):
			rigs[owner] = rigOf(eyes, owner)
		var pair:Array = []
		for holeID in Frame.HOLES:
			var key:String = oversizeKey(r["shaft"], owner, holeID)
			if(!oversize.has(key)):
				if(pair.empty()):
					pair = pairOf(eyes, r["shaft"], owner)
				oversize[key] = oversizeOf(pair, holeID)
	return context

static func engagementOf(relation:Dictionary) -> Dictionary:
	return {
		"shaft": relation["shaft"],
		"hole_owner": relation["hole_owner"],
		"hole": str(relation["hole"]),
		"provenance": {"source": str(relation["source"]), "confidence": int(relation["confidence"]), "refused": []},
		"state": "stated",
	}


static func measuresOf(candidate:Dictionary, card, oversize:Dictionary) -> Dictionary:
	var shape:Array = shapeOf(candidate, card)
	var measures:Dictionary = {
		"entry": candidate["entry"],
		"depth": candidate["depth"],
		"axis": candidate["axis"],
		"girth_at_entry": shape[0],
		"shape": shape,
		"oversize": float(oversize.get(
			oversizeKey(candidate["shaft"], candidate["hole_owner"], candidate["hole"]),
			DEFAULT_OVERSIZE)),
	}
	if(typeof(card) == TYPE_DICTIONARY && typeof(card.get("edge_up")) == TYPE_ARRAY \
			&& !card["edge_up"].empty()):
		measures["shape_up"] = shapeOf(candidate, card, "edge_up")
		measures["shape_down"] = shapeOf(candidate, card, "edge_down")
	return measures
static func shapeOf(candidate:Dictionary, card, key:String = "profile") -> Array:
	var along:float = float(candidate["along"])
	var depth:float = float(candidate["depth"])
	var out:Array = []
	var count:int = int(max(int(SHAPE["samples"]), 2))
	if(typeof(card) != TYPE_DICTIONARY || float(card.get("length", 0.0)) <= 0.0 || !card.has("skip")):
		for i in count:
			out.append(FALLBACK_GIRTH)
		return out
	var length:float = float(card["length"])
	var skip:float = float(card["skip"])
	var radius:float = float(card.get("radius", 0.0))
	var profile:Array = card.get(key, [])
	for i in count:
		var t:float = clamp((along + depth * float(i) / float(count - 1)) / length, 0.0, 1.0)
		out.append(radius * min(profileAt(profile, t, skip), PROFILE_MAX))
	return out
static func girthFrom(card, along, key:String = "profile") -> float:
	if(typeof(card) != TYPE_DICTIONARY):
		return FALLBACK_GIRTH
	var length:float = float(card.get("length", 0.0))
	if(length <= 0.0):
		return FALLBACK_GIRTH
	if(!card.has("skip")):
		return FALLBACK_GIRTH
	var t:float = clamp(float(along) / length, 0.0, 1.0)
	var shape:float = profileAt(card.get(key, []), t, float(card["skip"]))
	return float(card.get("radius", 0.0)) * min(shape, PROFILE_MAX)
static func profileAt(profile:Array, t:float, skip:float) -> float:
	if(profile.empty()):
		return 1.0
	var last:int = profile.size() - 1
	var span:float = max(1.0 - skip, 0.001)
	var local:float = clamp((t - skip) / span, 0.0, 1.0) * last
	var low:int = int(floor(local))
	var high:int = int(min(low + 1, last))
	return lerp(profile[low], profile[high], local - low)
static func oversizeKey(shaftOwner, holeOwner, holeID) -> String:
	return str(shaftOwner) + " " + str(holeOwner) + " " + str(holeID)


static func portalMeasuresFor(snapshot:Dictionary, shaftOwner, holeOwner, holeID:String):
	var row:Dictionary = PortalScenes.TABLE[snapshot["scene_path"]]
	var measured = transferred(snapshot, row, str(shaftOwner), str(holeOwner), holeID)
	if(measured == null):
		return null
	return measured["measures"]
static func portalOwns(snapshot, shaftOwner, holeOwner) -> bool:
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return false
	var path = snapshot.get("scene_path")
	if(typeof(path) != TYPE_STRING || !PortalScenes.TABLE.has(path)):
		return false
	var row:Dictionary = PortalScenes.TABLE[path]
	return row.has("portal") && str(row["shaft"]) == str(shaftOwner) \
		&& str(row["hole_owner"]) == str(holeOwner)
static func transferred(snapshot:Dictionary, row:Dictionary, shaftOwner:String, holeOwner:String,
		holeID:String):
	var hole = PortalScenes.transferred(snapshot, row, shaftOwner, holeOwner, holeID)
	if(hole == null):
		return null
	var card = hole["card"]
	var length:float = hole["length"]
	var along:float = hole["along"]
	var drawnAlong:float = clamp(along * length / STROKE_REFERENCE_LENGTH, 0.0, length)
	var depth:float = length - drawnAlong
	var oversize:Dictionary = {}
	if(typeof(snapshot.get("oversize")) == TYPE_DICTIONARY):
		oversize = snapshot["oversize"]
	var candidate:Dictionary = {
		"shaft": shaftOwner,
		"hole_owner": holeOwner,
		"hole": hole["id"],
		"along": drawnAlong,
		"depth": depth,
		"clip_along": along,
		"entry": hole["pos"],
		"axis": portalAxis(snapshot, holeOwner, hole["inward"]),
	}
	return {"hole": hole["id"], "measures": portalMeasures(candidate, card, oversize, length)}
static func portalAxis(snapshot:Dictionary, holeOwner:String, inward:Vector3) -> Vector3:
	var rigs = snapshot.get("rig")
	if(typeof(rigs) != TYPE_DICTIONARY || typeof(rigs.get(holeOwner)) != TYPE_DICTIONARY \
			|| typeof(rigs[holeOwner].get("hips")) != TYPE_TRANSFORM):
		return inward
	var hips:Transform = rigs[holeOwner]["hips"]
	return hips.affine_inverse().basis.xform(PORTAL_AXIS_REST).normalized()
static func portalMeasures(candidate:Dictionary, card, oversize:Dictionary, length:float) -> Dictionary:
	var measures:Dictionary = measuresOf(candidate, card, oversize)
	var axis:Vector3 = candidate["axis"]
	var tip:Vector3 = candidate["entry"] + axis * float(candidate["depth"])
	measures["shaft_tip"] = tip
	measures["shaft_base"] = tip - axis * length
	measures["clip_skin"] = 0.0
	measures["clip_along"] = float(candidate["clip_along"])
	measures["deadzone"] = 0.0
	return measures


static func rigOf(eyes, participantID):
	var helper = eyes.helperFor(participantID)
	if(helper == null):
		return null
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return null
	return {
		"hips": hipsToRest(skeleton),
		"origin": {
			"vagina": helper.getBulgeOriginRest("vagina"),
			"anus": helper.getBulgeOriginRest("anus"),
			"mouth": helper.getBulgeOriginRest("mouth"),
		},
		"neck_axis": helper.getNeckAxisWorld(),
		"spine_chain": helper.getSpineChainWorld(),
		"contour": helper.getFrontContour("vagina"),
		"margins": marginsOf(helper),
	}
static func hipsToRest(skeleton:Skeleton):
	var boneIdx:int = skeleton.find_bone("Hips")
	if(boneIdx < 0):
		return null
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	var restGlobal:Transform = BulgeUtils.getBoneRestGlobal(skeleton, boneIdx)
	return restGlobal * posedGlobal.affine_inverse()
static func marginsOf(helper) -> Array:
	var margins:Array = []
	for themesh in helper.getBulgeMeshesForZone("vagina"):
		if(!themesh.is_visible_in_tree()):
			continue
		margins.append(BulgeUtils.getFrontMargin(themesh))
	return margins
static func pairOf(eyes, shaftOwner, holeOwner) -> Array:
	var topChar = charFor(eyes.dollFor(shaftOwner))
	var bottomChar = charFor(eyes.dollFor(holeOwner))
	if(topChar == null || bottomChar == null):
		return [topChar, bottomChar, 0.0]
	return [topChar, bottomChar, topChar.getPenisSize()]
static func oversizeOf(pair:Array, holeID):
	var bottomChar = pair[1]
	if(pair[0] == null || bottomChar == null):
		return DEFAULT_OVERSIZE
	var slot:String = str(holeID)
	if(slot == HOLE_MOUTH):
		slot = SLOT_HEAD
	if(slot == HOLE_VAGINA && !bottomChar.hasBodypart(slot)):
		slot = HOLE_ANUS
	if(!bottomChar.hasBodypart(slot)):
		return DEFAULT_OVERSIZE
	var freeRoom:float = bottomChar.getPenetrationFreeRoom(slot, pair[2])
	return min(0.35 + max(-freeRoom, 0.0) / 18.0, 1.7)
static func charFor(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll) || !theDoll.has_method("getCharacterID")):
		return null
	var charID = theDoll.getCharacterID()
	if(charID is String):
		if(charID == ""):
			return null
		return GlobalRegistry.getCharacter(charID)
	if(typeof(charID) != TYPE_OBJECT || !is_instance_valid(charID)):
		return null
	if(!charID.has_method("getPenisSize") || !charID.has_method("getPenetrationFreeRoom")):
		return null
	return charID
