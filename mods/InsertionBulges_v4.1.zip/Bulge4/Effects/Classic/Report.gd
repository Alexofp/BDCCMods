extends Reference
const Evidence := preload("res://Bulge4/Infer/Evidence.gd")
const Intent := preload("res://Bulge4/Effects/Classic/Intent.gd")
const Spring := preload("res://Bulge4/Effects/Medium/Spring.gd")
const CONF_TO_HIDE := Evidence.CONF_RUNTIME
const MAX_BULGES_PER_DOLL = Intent.BulgeUtils.BULGE_SLOTS
static func build(entries:Array) -> Dictionary:
	var report:Dictionary = {"bulges": [], "clips": []}
	var usedSlots:Dictionary = {}
	for entry in rank(entries):
		var engagement:Dictionary = entry["engagement"]
		var intent = entry.get("intent")
		if(typeof(intent) != TYPE_DICTIONARY):
			continue
		if(bool(intent["visible"])):
			var ownerKey:String = str(engagement["hole_owner"])
			var slot:int = int(usedSlots.get(ownerKey, 0))
			if(slot < MAX_BULGES_PER_DOLL):
				usedSlots[ownerKey] = slot + 1
				report["bulges"].append({"entry": entry, "slot": slot})
		if(str(engagement["state"]) == Spring.STATE_SETTLING):
			continue
		if(!mayHide(int(engagement["provenance"]["confidence"]))):
			continue
		report["clips"].append({"entry": entry, "clip_on_axis": float(intent["clip_on_axis"])})
	return report
static func mayHide(confidence:int) -> bool:
	return confidence >= CONF_TO_HIDE
static func rank(entries:Array) -> Array:
	var ordered:Array = []
	var keys:Array = []
	for entry in entries:
		var key:Array = [depthOf(entry), int(entry["engagement"]["provenance"]["confidence"])]
		var at:int = 0
		while(at < ordered.size() && !comesFirst(key, keys[at])):
			at += 1
		ordered.insert(at, entry)
		keys.insert(at, key)
	return ordered
static func comesFirst(mine:Array, theirs:Array) -> bool:
	if(mine[0] != theirs[0]):
		return mine[0] > theirs[0]
	return mine[1] > theirs[1]
static func depthOf(entry:Dictionary) -> float:
	var measures = entry.get("measures")
	if(typeof(measures) != TYPE_DICTIONARY || !measures.has("depth")):
		return -INF
	return float(measures["depth"])
