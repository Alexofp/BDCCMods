extends Reference
const RAMP_SLOPE_PEAK := 1.5
const TUNING := {"fidelity": 0.55, "rim": 1.0, "radial": 0.0, "plateau": 0.25, "plateau_oral": 0.25}
static func fidelity() -> float:
	return float(TUNING["fidelity"])
static func rim() -> float:
	return float(TUNING["rim"])
static func radial() -> float:
	return float(TUNING["radial"])
const RADIAL_MAX := 0.5
static func setRadial(value:float) -> void:
	var live:Dictionary = TUNING
	live["radial"] = clamp(value, 0.0, 1.0) * RADIAL_MAX
static func setTuning(fidelityValue:float, rimValue:float) -> bool:
	if(fidelityValue < 0.0 || fidelityValue > 1.0 || rimValue < 0.0 || rimValue > 1.0):
		push_error("Field: fidelity and rim must both be within 0..1; still " \
			+ str(fidelity()) + "/" + str(rim()))
		return false
	var live:Dictionary = TUNING
	live["fidelity"] = fidelityValue
	live["rim"] = rimValue
	return true
const EPSILON := 0.0001
static func rampOf(slot:Dictionary, bulge_aspect:Vector2 = Vector2(1, 1)) -> float:
	var centre:Vector2 = slot["centre"] * bulge_aspect
	var reach:Vector2 = slot["front"] * bulge_aspect - centre
	return max(reach.length(), EPSILON)
static func bandPlateau() -> float:
	return float(TUNING["plateau"])
static func setTipRound(value:float) -> void:
	var live:Dictionary = TUNING
	live["plateau"] = 1.0 - clamp(value, 0.0, 1.0)
static func setOralTipRound(value:float) -> void:
	var live:Dictionary = TUNING
	live["plateau_oral"] = 1.0 - clamp(value, 0.0, 1.0)
static func plateauFor(zone:String) -> float:
	if(zone == "mouth"):
		return float(TUNING["plateau_oral"])
	return bandPlateau()
const LIP_SOFT := 1.25
const UNION_OVERLAP := 0.3
const UNION := {"overlap": UNION_OVERLAP}
static func unionOverlap() -> float:
	return float(UNION["overlap"])
static func setUnionOverlap(value:float) -> void:
	var live:Dictionary = UNION
	live["overlap"] = clamp(value, 0.0, 1.0)
const WARP_ORIGINAL := "original"
const WARP_FLOW := "flow"
const WARP_STRETCH := "stretch"
const WARP_BONES := "bones"
const WARP_MESH := "mesh"
const WARP_MODES := [WARP_ORIGINAL, WARP_FLOW, WARP_STRETCH, WARP_BONES, WARP_MESH]
const WARP := {"mode": WARP_ORIGINAL}
const FLOW_STEPS_MAX := 16
const FLOW_MARGIN := 1.25
static func warpMode() -> String:
	return str(WARP["mode"])
static func warpIndex() -> int:
	return WARP_MODES.find(warpMode())
static func setWarpMode(mode:String) -> void:
	var live:Dictionary = WARP
	live["mode"] = WARP_ORIGINAL
	if(mode in WARP_MODES):
		live["mode"] = mode
static func capped() -> bool:
	return warpMode() == WARP_ORIGINAL || warpMode() == WARP_BONES
static func slotLive(slot:Dictionary) -> bool:
	return float(slot["spread"]) > EPSILON && float(slot["amplitude"]) > EPSILON
static func flowSteps(slots:Array, bulge_aspect:Vector2 = Vector2(1, 1)) -> int:
	var total:float = 0.0
	var smallest:float = INF
	for slot in slots:
		if(!slotLive(slot)):
			continue
		total += float(slot["amplitude"])
		smallest = min(smallest, rampOf(slot, bulge_aspect) / RAMP_SLOPE_PEAK)
	if(total <= 0.0 || smallest == INF):
		return 1
	return int(clamp(ceil(total * FLOW_MARGIN / smallest), 1, FLOW_STEPS_MAX))
