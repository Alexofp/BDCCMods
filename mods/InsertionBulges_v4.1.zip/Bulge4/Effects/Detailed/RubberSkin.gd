extends Reference
const BodyDeform := preload("res://Bulge4/Effects/Detailed/Lab/BodyDeform.gd")
const BodyShape := preload("res://Bulge4/Effects/Detailed/Lab/BodyShape.gd")
const BodyPose := preload("res://Bulge4/Effects/Detailed/Lab/BodyPose.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const Eyes := preload("res://Bulge4/Observe/Eyes.gd")
const PropShaft := preload("res://Bulge4/Effects/Detailed/PropShaft.gd")
const PortalScenes := preload("res://Bulge4/Infer/PortalScenes.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const Basic := preload("res://Bulge4/Effects/Basic/Basic.gd")
const Crotch := preload("res://Bulge4/Infer/Crotch.gd")
const Repose := preload("res://Bulge4/Doll/Repose.gd")
const AnimAhead := preload("res://Bulge4/Doll/AnimAhead.gd")
const ReposeSolve := preload("res://Bulge4/Doll/ReposeSolve.gd")
const ReposeScene := preload("res://Bulge4/Doll/ReposeScene.gd")
const HOLES := Eyes.DOLL_HOLES
const SHAFT_BONE := "Penis"
const COVER := 1.0
const LOCK := true
const OPTS := {"backend": "auto", "shader_extra": {"UV_pattern": "(UV_pattern + bulge_d * pattern_size)"}, "posed_build": true}
const BENCH = ReposeScene.BENCH

static func lap(part:String, since:int) -> int:
	return ReposeScene.lap(part, since)
const META_STATE := "ib36Skin"
const SHADE_Z := 0.001
const META_SHAPE := "ib36ShaftShape"
const COCK_OFF := ["limp", "caged"]
const META_WEIGHTS := "ib36Weights"
const META_PORTAL := "bulge4PortalDeepest"
const WEIGHT_CELLS := 48

static func run(stageScene, relations:Array, opts:Dictionary = {}) -> Array:
	var o:Dictionary = OPTS.duplicate()
	for key in opts:
		o[key] = opts[key]
	for key in BENCH:
		o[key] = BENCH[key]
	if(bool(o.get("repose", false)) && !bool(o.get("repose_crowd", false)) && dollCount(stageScene) > 2):
		o["repose"] = false
	if(stageScene.has_meta(Frame.META_NOW)):
		o["now"] = float(stageScene.get_meta(Frame.META_NOW))
	o["action"] = actionOf(stageScene)
	var rows:Array = []
	var dolls:Array = stageScene.getDolls()
	var wanted:Dictionary = {}
	var props:Array = []
	var snapshot = null
	if(stageScene.has_meta(Frame.META_SNAPSHOT)):
		snapshot = stageScene.get_meta(Frame.META_SNAPSHOT)
	for given in relations:
		if(!HOLES.has(str(given["hole"]))):
			continue
		var r:Dictionary = given
		var owner:int = dollIndex(str(r["hole_owner"]))
		var by:int = dollIndex(str(r["shaft"]))
		if(by < 0 && propIndex(str(r["shaft"])) >= 0 && props.empty()):
			props = Eyes.propsIn(stageScene)
		if(owner < 0 || owner >= dolls.size() || by >= dolls.size() || (by < 0 && (propIndex(str(r["shaft"])) < 0 || propIndex(str(r["shaft"])) >= props.size()))):
			continue
		if(!wanted.has(owner)):
			wanted[owner] = []
		wanted[owner].append(r)
	var split:Dictionary = {}
	if(stageScene.has_meta(META_SPLIT)):
		split = stageScene.get_meta(META_SPLIT)
	var kept:Dictionary = {}
	for owner in wanted:
		wanted[owner] = inOrder(wanted[owner])
		splitCrotch(wanted[owner], dolls, snapshot, split, kept)
	stageScene.set_meta(META_SPLIT, kept)
	for index in range(dolls.size()):
		var doll = dolls[index]
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			if(!wanted.has(index)):
				if(float(o.get("linger", 0.0)) > 0.0 && torso.has_meta(META_STATE) && !stateOf(torso).get("ghosts", {}).empty()):
					var left:Dictionary = stateOf(torso)
					for was in left.get("reposed", []):
						if(is_instance_valid(was)):
							Repose.clear(was.getSkeletonNode())
							Repose.forget(was.getSkeletonNode())
							was.unbendShaft()
					left["reposed"] = []
					var fading:Dictionary = draw(torso, helper, [], o)
					fading["doll"] = "doll" + str(index)
					rows.append(fading)
				else:
					restore(torso)
				continue
			var tp0:int = OS.get_ticks_usec()
			aimCrotch(stageScene, torso, helper, dolls, wanted[index], o)
			var shafts:Array = []
			var holes:Array = []
			var by:Array = []
			for r in wanted[index]:
				var source = null
				if(dollIndex(str(r["shaft"])) >= 0):
					source = BulgeDoll.forDoll(dolls[dollIndex(str(r["shaft"]))])
				else:
					source = props[propIndex(str(r["shaft"]))]
				shafts.append([source, str(r["hole"]) == "mouth", portalOf(stageScene, r), str(r["hole"]), str(r["shaft"])])
				holes.append(str(r["hole"]))
				by.append(str(r["shaft"]))
			var ro:Dictionary = o
			var tight:float = -1.0
			if(str(o.get("react", "off")) == "character"):
				tight = tightOfTorso(dolls, doll, wanted[index])
			elif(str(o.get("react", "off")) == "fixed"):
				tight = clamp(float(o.get("tightness", 0.5)), 0.0, 1.0)
			if(tight >= 0.0):
				ro = reactTo(o, tight)
			if(str(o.get("grip_mode", "off")) == "shape_tight" && !BENCH.has("grip_tight")):
				if(tight < 0.0):
					tight = tightOfTorso(dolls, doll, wanted[index])
				ro = ro.duplicate()
				ro["grip_tight"] = tight
			if(bool(BENCH.get("capture_now", false))):
				ro = ro.duplicate()
				ro["capture_suffix"] = "_doll" + str(index)
			var alone:bool = true
			for one in shafts:
				alone = alone && !one[1]
			for r2 in relations:
				alone = alone && str(r2["shaft"]) != "doll" + str(index)
			var tp:int = lap("aim", tp0)
			preroll(stageScene, torso, helper, shafts, ro, alone)
			tp = lap("preroll", tp)
			reposeTorso(torso, helper, shafts, ro, alone)
			tp = lap("help", tp)
			var row:Dictionary = draw(torso, helper, shafts, ro)
			if(tight >= 0.0):
				row["tight"] = stepify(tight, 0.01)
			row["doll"] = "doll" + str(index)
			row["hole"] = holes[0]
			row["shaft"] = by[0]
			row["holes"] = holes
			row["shafts"] = by
			rows.append(row)
	if(wanted.empty()):
		warm(dolls, o)
	elif(bool(BENCH.get("capture_now", false))):
		var knobs:Dictionary = BENCH
		knobs["capture_now"] = false
	return rows

static func actionOf(stageScene) -> String:
	var path:String = ""
	if(stageScene.get_script() != null):
		path = stageScene.get_script().resource_path
	return path + ":" + str(stageScene.get("currentAnim"))

const ANUS_DEEP := 0.4
const ANUS_STEPS := 20
static func anchorAt(holeHelper, hole:String):
	var at = holeHelper.getOrificeAnchor(hole, true)
	if(hole != "anus" || at == null):
		return at
	var crotch = holeHelper.getOrificeAnchor("vagina", true)
	var torsos:Array = holeHelper.getBulgeMeshesForZone("")
	if(crotch == null || torsos.empty()):
		return at
	var state:Dictionary = stateOf(torsos[0])
	if(!state.has("anus_share")):
		state["anus_share"] = anusShareOf(bodyShapeOf(torsos[0], state), holeHelper.getSkeletonNode(), crotch, at)
	return crotch.linear_interpolate(at, float(state["anus_share"]))

static func holeAt(holeHelper, hole:String):
	if(hole == "vagina" || hole == "anus"):
		var torsos:Array = holeHelper.getBulgeMeshesForZone("")
		if(!torsos.empty() && stateOf(torsos[0]).has("crotch_aim")):
			var va = anchorAt(holeHelper, "vagina")
			var an = anchorAt(holeHelper, "anus")
			if(va != null && an != null):
				return va.linear_interpolate(an, float(stateOf(torsos[0])["crotch_aim"]["t"]))
	return anchorAt(holeHelper, hole)

const CROTCH_AIM := {"samples": 24, "learn": 1.5, "from": -0.5, "to": 1.5, "steps": 80}
static func aimCrotch(stageScene, torso, helper, dolls:Array, list:Array, o:Dictionary) -> void:
	var state:Dictionary = stateOf(torso)
	var crotch:Array = []
	for i in range(list.size()):
		if(["vagina", "anus"].has(str(list[i]["hole"])) && dollIndex(str(list[i]["shaft"])) >= 0):
			crotch.append(i)
	if(crotch.size() != 1):
		state.erase("crotch_aim")
		return
	var r:Dictionary = list[crotch[0]]
	var now:float = float(o.get("now", 0.0))
	var aim = state.get("crotch_aim")
	if(aim == null || str(aim["action"]) != str(o.get("action", "")) || str(aim["shaft"]) != str(r["shaft"]) || now < float(aim["since"])):
		aim = {"action": str(o.get("action", "")), "shaft": str(r["shaft"]), "since": now, "sum": 0.0, "n": 0, "t": 0.0, "ahead": false}
		state["crotch_aim"] = aim
		var ahead:Array = AnimAhead.of(stageScene)
		if(!ahead.empty()):
			var saved:Array = AnimAhead.save(ahead)
			var top = BulgeDoll.forDoll(dolls[dollIndex(str(r["shaft"]))])
			for k in range(int(CROTCH_AIM["samples"])):
				AnimAhead.poseAt(ahead, AnimAhead.lengthOf(ahead) * (float(k) + 0.5) / float(CROTCH_AIM["samples"]))
				var t = aimOf(helper, top)
				if(t != null):
					aim["sum"] = float(aim["sum"]) + float(t)
					aim["n"] = int(aim["n"]) + 1
			AnimAhead.restore(ahead, saved)
			if(int(aim["n"]) > 0):
				aim["t"] = float(aim["sum"]) / float(aim["n"])
				aim["ahead"] = true
	if(!bool(aim["ahead"]) && now - float(aim["since"]) < float(CROTCH_AIM["learn"])):
		var t = aimOf(helper, BulgeDoll.forDoll(dolls[dollIndex(str(r["shaft"]))]))
		if(t != null):
			aim["sum"] = float(aim["sum"]) + float(t)
			aim["n"] = int(aim["n"]) + 1
			aim["t"] = float(aim["sum"]) / float(aim["n"])
	var hole:String = "vagina"
	if(float(aim["t"]) >= 0.5):
		hole = "anus"
	if(str(r["hole"]) != hole):
		r = r.duplicate()
		r["hole"] = hole
		list[crotch[0]] = r

static func aimOf(bottom, top):
	if(bottom == null || top == null):
		return null
	var bottomSkel:Skeleton = bottom.getSkeletonNode()
	var topSkel:Skeleton = top.getSkeletonNode()
	if(bottomSkel == null || topSkel == null):
		return null
	Repose.clear(bottomSkel)
	Repose.clear(topSkel)
	var chain = top.shaftChainOf()
	var va = anchorAt(bottom, "vagina")
	var an = anchorAt(bottom, "anus")
	if(chain == null || va == null || an == null):
		return null
	var base:Vector2 = Repose.xy(chain["heads"][0])
	var tip:Vector2 = Repose.xy(chain["heads"][chain["heads"].size() - 1])
	if(base.distance_to(tip) < 1e-6):
		return null
	var v:Vector2 = Repose.xy(va)
	var a:Vector2 = Repose.xy(an)
	var best:float = INF
	var bestT:float = 0.0
	for k in range(int(CROTCH_AIM["steps"]) + 1):
		var t:float = lerp(float(CROTCH_AIM["from"]), float(CROTCH_AIM["to"]), float(k) / float(CROTCH_AIM["steps"]))
		var q:Vector2 = v.linear_interpolate(a, t)
		var d:float = q.distance_to(Geometry.get_closest_point_to_segment_uncapped_2d(q, base, tip))
		if(d < best):
			best = d
			bestT = t
	return bestT

static func anusShareOf(bshape:Dictionary, skel:Skeleton, crotch:Vector3, anus:Vector3) -> float:
	if(bshape.empty() || skel == null):
		return 1.0
	var depths:Array = []
	var deepest:float = 0.0
	for i in range(ANUS_STEPS + 1):
		var rest:Vector3 = BulgeUtils.worldToRest(skel, "Hips", crotch.linear_interpolate(anus, float(i) / float(ANUS_STEPS)))
		depths.append(BodyShape.sd(bshape, Vector2(rest.x, rest.y)))
		deepest = max(deepest, depths[i])
	if(deepest <= 0.0):
		return 1.0
	var share:float = 0.0
	for i in range(ANUS_STEPS + 1):
		if(depths[i] >= ANUS_DEEP * deepest):
			share = float(i) / float(ANUS_STEPS)
	return share

static func drawnNear(holeHelper, hole:Vector2, radius:float, reach:float = 3.0) -> Array:
	var torsos:Array = holeHelper.getBulgeMeshesForZone("")
	if(torsos.empty() || radius <= 0.0):
		return []
	var state:Dictionary = stateOf(torsos[0])
	if(!state.has("posed_bs")):
		return []
	var bs:Dictionary = state["posed_bs"]
	var mirror:float = 1.0
	if(bool(state["posed_mirror"])):
		mirror = -1.0
	BodyDeform._sd_near(bs, Rect2(Vector2(hole.x * mirror, hole.y), Vector2.ZERO).grow(reach * radius + 2.0 * float(bs["cell"])))
	return [bs, mirror]

static func wayOf(holeHelper, state:Dictionary, hole:String, h:Vector2, radius:float, deep:float, opts:Dictionary, along:Vector2 = Vector2.ZERO) -> Vector2:
	if(opts.get("curve") != null && bool(opts.get("straight", true)) && !opts.has("felt_off")):
		return feltWay(holeHelper, state, hole, h, radius, deep, opts)
	var got:Dictionary = laneOf(holeHelper, state, hole, h, radius, opts)
	if(!state.has("repose_belly")):
		state["repose_belly"] = {}
	state["repose_belly"][hole] = got.get("belly", Vector2.ZERO)
	if(!state.has("repose_lane")):
		state["repose_lane"] = {}
	state["repose_lane"][hole] = got.get("lane", [])
	if(bool(opts.get("straight", true))):
		return ReposeScene.entryLine(got.get("lane", []), h, radius)
	return ReposeScene.aimOf(got, h, radius, deep, opts, along)

static func feltWay(holeHelper, state:Dictionary, hole:String, h:Vector2, radius:float, deep:float, opts:Dictionary) -> Vector2:
	var skel:Skeleton = holeHelper.getSkeletonNode()
	var up:Vector2 = Vector2.UP
	if(skel != null && skel.find_bone(Repose.HIPS) >= 0):
		up = Repose.xy(Repose.world(skel, Repose.HIPS).basis.y).normalized()
	if(!state.has("felt")):
		state["felt"] = {}
	if(!state.has("repose_belly")):
		state["repose_belly"] = {}
	var now:float = float(opts.get("now", 0.0))
	var kept = state["felt"].get(hole)
	var knobs:Array = [radius, float(opts.get("canal_belly", 0.0)), float(opts.get("direct_at", 0.0))]
	if(kept == null || str(kept["action"]) != str(opts.get("action", "")) || now < float(kept["since"]) || opts["curve"].knobsMoved(kept["knobs"], knobs)):
		kept = {"action": str(opts.get("action", "")), "since": now, "knobs": knobs}
		state["felt"][hole] = kept
	var fresh:bool = int(state.get("posed_count", 0)) != int(kept.get("body", -1))
	if((fresh && now - float(kept["since"]) < float(opts["curve"].BODY["learn"])) || !kept.has("way")):
		kept["body"] = int(state.get("posed_count", 0))
		var got:Dictionary = laneOf(holeHelper, state, hole, h, radius, opts)
		var entry:Vector2 = ReposeScene.entryLine(got.get("lane", []), h, radius)
		if(entry == Vector2.ZERO):
			state["repose_belly"][hole] = got.get("belly", Vector2.ZERO)
			return Vector2.ZERO
		var way:Vector2 = opts["curve"].bestWay(got.get("lane", []), h, entry, deep * radius, radius)
		if(float(opts.get("direct_at", 0.0)) > 0.0 && Array(got.get("skin", [])).size() >= 2):
			var skin:Array = got["skin"]
			var hit:Array = opts["curve"].directHitAt(skin, BodyDeform._cumulative_open(skin), h, radius, float(opts["direct_at"]) * deep * radius)
			if(!hit.empty()):
				way = hit[0]
		var n:float = float(kept.get("n", 0))
		kept["way"] = (kept.get("way", Vector2.ZERO) * n + way.rotated(-up.angle())) / (n + 1.0)
		kept["belly"] = (kept.get("belly", Vector2.ZERO) * n + Vector2(got.get("belly", Vector2.ZERO)).rotated(-up.angle())) / (n + 1.0)
		kept["n"] = n + 1.0
	state["repose_belly"][hole] = Vector2(kept["belly"]).rotated(up.angle())
	return Vector2(kept["way"]).normalized().rotated(up.angle())

static func laneOf(holeHelper, state:Dictionary, hole:String, h:Vector2, radius:float, opts:Dictionary) -> Dictionary:
	var turn:float = 0.0
	var m = null
	if(state.get("posed_drawn_b") != null):
		m = state["posed_drawn_b"]
		h = m[2] + (h - m[2]).rotated(float(m[1])) + m[0]
		turn = float(m[1])
	var near:Array = drawnNear(holeHelper, h, radius, 1.0)
	if(near.empty()):
		return {}
	var bs:Dictionary = near[0]
	var mirror:float = near[1]
	var hb := Vector2(h.x * mirror, h.y)
	var gap:float = float(opts.get("belly_gap", BodyDeform.DEFAULTS["belly_gap"])) * radius
	var middle:Array = BodyDeform._guide(bs, Transform.IDENTITY, 0.0, 0.0)
	var skin:Array = BodyDeform._guide(bs, Transform.IDENTITY, 1.0, 0.0)
	var line:Array = middle
	var toward:float = 0.0
	if(opts.get("curve") != null):
		toward = clamp(float(opts.get("canal_belly", 0.0)), 0.0, 1.0)
		line = opts["curve"].lane(bs, Transform.IDENTITY, hb, hole, gap, toward)
	else:
		line = BodyDeform._guide(bs, Transform.IDENTITY, float(opts.get("belly", 0.0)), gap)
	if(line.size() < 2):
		return {}
	var belly:Vector2 = Vector2.ZERO
	if(middle.size() >= 2 && skin.size() == middle.size()):
		var mc:Array = BodyDeform._cumulative_open(middle)
		var sc:Array = BodyDeform._cumulative_open(skin)
		var g:float = BodyDeform._project(middle, mc, hb)
		belly = BodyDeform._guide_at(skin, sc, g * sc[skin.size() - 1] / max(mc[middle.size() - 1], 1e-6)) - BodyDeform._guide_at(middle, mc, g)
	var lane:Array = []
	for p in line:
		var q := Vector2(p.x * mirror, p.y)
		if(m != null):
			q = m[2] + (q - m[0] - m[2]).rotated(-turn)
		lane.append(q)
	var skinWorld:Array = []
	if(float(opts.get("direct_at", 0.0)) > 0.0):
		for p in skin:
			var q := Vector2(p.x * mirror, p.y)
			if(m != null):
				q = m[2] + (q - m[0] - m[2]).rotated(-turn)
			skinWorld.append(q)
	return {"lane": lane, "belly": Vector2(belly.x * mirror, belly.y).rotated(-turn), "toward": toward, "skin": skinWorld}

static func bellyOf(_holeHelper, state:Dictionary, hole:String, _h:Vector2) -> Vector2:
	return state.get("repose_belly", {}).get(hole, Vector2.ZERO)

static func thrustOf(_holeHelper, _state:Dictionary, _hole:String, _h:Vector2) -> Vector2:
	return Vector2.ZERO

static func fitTable(holeHelper, state:Dictionary, hole:Vector2, dir:Vector2, radius:float, deep:float) -> Array:
	if(state.has("repose_drawn_b")):
		var m:Array = state["repose_drawn_b"]
		hole = m[2] + (hole - m[2]).rotated(float(m[1])) + m[0]
		dir = dir.rotated(float(m[1]))
	var out:Array = []
	var near:Array = drawnNear(holeHelper, hole, radius, deep + 6.0)
	if(near.empty()):
		return out
	var mirror:float = near[1]
	var steps:int = int(round(float(ReposeScene.FIT["turn"]) / float(ReposeScene.FIT["step"])))
	for k in range(-steps, steps + 1):
		out.append(outsideAt(near[0], Vector2(hole.x * mirror, hole.y), Vector2(dir.x * mirror, dir.y).rotated(k * float(ReposeScene.FIT["step"]) * mirror), radius, deep))
	return out

static func outsideAt(bs:Dictionary, hole:Vector2, dir:Vector2, radius:float, deep:float = 0.0) -> float:
	for _k in range(12):
		if(BodyShape.sd(bs, hole - dir * 0.25 * radius) < 0.0):
			break
		hole -= dir * 0.25 * radius
	var across := Vector2(-dir.y, dir.x)
	var out := 0.0
	for along in [0.5, 1.0, 1.5, 2.0]:
		for side in [-1.0, -0.5, 0.5, 1.0]:
			out += max(-BodyShape.sd(bs, hole + (dir * along + across * side) * radius), 0.0)
	var on := 2.5
	while(on <= deep):
		out += max(-BodyShape.sd(bs, hole + dir * on * radius), 0.0)
		on += 1.0
	return out / radius

static func outsideOf(pose:Dictionary, info:Dictionary, c:Dictionary) -> float:
	var bs:Dictionary = pose["bs"]
	var dir:Vector2 = info["dir"]
	var radius:float = widestOf(c)
	var at:Vector2 = info["entry_pt"]
	BodyDeform._sd_near(bs, Rect2(at, Vector2.ZERO).grow(6.0 * radius + 2.0 * float(bs["cell"])))
	for _k in range(16):
		if(BodyShape.sd(bs, at) >= 0.0):
			break
		at += dir * 0.25 * radius
	var across := Vector2(-dir.y, dir.x)
	var out := 0
	var n := 0
	for along in [0.5, 1.0, 1.5, 2.0]:
		for side in [-1.0, -0.5, 0.5, 1.0]:
			n += 1
			if(BodyShape.sd(bs, at + dir * along * radius + across * side * radius) < 0.0):
				out += 1
	return float(out) / float(n)

const META_SPLIT := "bulge4CrotchSplit"
static func inOrder(list:Array) -> Array:
	var out:Array = []
	for r in list:
		var at:int = out.size()
		while(at > 0 && str(out[at - 1]["shaft"]) + "|" + str(out[at - 1]["hole"]) > str(r["shaft"]) + "|" + str(r["hole"])):
			at -= 1
		out.insert(at, r)
	return out

static func splitCrotch(list:Array, dolls:Array, snapshot, split:Dictionary, kept:Dictionary) -> void:
	var crotch:Array = []
	for i in range(list.size()):
		if(["vagina", "anus"].has(str(list[i]["hole"])) && dollIndex(str(list[i]["shaft"])) >= 0):
			crotch.append(i)
	if(crotch.size() != 2):
		return
	var a:Dictionary = list[crotch[0]]
	var b:Dictionary = list[crotch[1]]
	var told:Dictionary = Crotch.holesOf(snapshot)
	if(told.has(str(a["shaft"]) + "|" + str(a["hole_owner"])) && told.has(str(b["shaft"]) + "|" + str(b["hole_owner"]))):
		for k in range(2):
			var r:Dictionary = list[crotch[k]].duplicate()
			r["hole"] = str(told[str(r["shaft"]) + "|" + str(r["hole_owner"])])
			list[crotch[k]] = r
		return
	var key:String = str(a["hole_owner"]) + "|" + str(a["shaft"]) + "|" + str(b["shaft"])
	var who = characterOf(dolls[dollIndex(str(a["hole_owner"]))])
	if(who != null && who.has_method("hasBodypart") && !who.hasBodypart(BodypartSlot.Vagina)):
		for k in range(2):
			var r:Dictionary = list[crotch[k]].duplicate()
			r["hole"] = "anus"
			list[crotch[k]] = r
		return
	if(!split.has(key)):
		var bottom = BulgeDoll.forDoll(dolls[dollIndex(str(a["hole_owner"]))])
		if(bottom == null):
			return
		var va = anchorAt(bottom, "vagina")
		var an = anchorAt(bottom, "anus")
		var la:Array = shaftLine(dolls, str(a["shaft"]))
		var lb:Array = shaftLine(dolls, str(b["shaft"]))
		if(va == null || an == null || la.empty() || lb.empty()):
			return
		var v2 := Vector2(va.x, va.y)
		var a2 := Vector2(an.x, an.y)
		var aFront:bool = ReposeSolve.missOf(la, v2).length() + ReposeSolve.missOf(lb, a2).length() <= ReposeSolve.missOf(la, a2).length() + ReposeSolve.missOf(lb, v2).length()
		split[key] = aFront
	kept[key] = split[key]
	var holes:Array = ["anus", "vagina"]
	if(bool(split[key])):
		holes = ["vagina", "anus"]
	for k in range(2):
		var r:Dictionary = list[crotch[k]].duplicate()
		r["hole"] = holes[k]
		list[crotch[k]] = r

static func shaftLine(dolls:Array, shaft:String) -> Array:
	var helper = BulgeDoll.forDoll(dolls[dollIndex(shaft)])
	if(helper == null):
		return []
	var info = helper.getShaftInfo()
	if(info == null):
		return []
	return [Vector2(info["base"].x, info["base"].y), Vector2(info["tip"].x, info["tip"].y)]

const REACT := {"room_span": 20.0, "pain": 0.25, "lust": 0.25, "force": -1.0, "girth": 1.0, "girth_ref": 0.1273}
const REACT_ENDS := {"skin": [0.9, 1.25], "fillet": [1.0, 0.35], "fidelity": [0.5, 1.0]}
const REACT_SLOT := {"vagina": "vagina", "anus": "anus", "mouth": "head"}

static func tightOf(room:float, pain:float, lust:float) -> float:
	var t:float = 0.5 - room / (2.0 * float(REACT["room_span"]))
	return clamp(t + float(REACT["pain"]) * pain - float(REACT["lust"]) * lust, 0.0, 1.0)

static func reactTo(o:Dictionary, tight:float) -> Dictionary:
	var out:Dictionary = o.duplicate()
	for key in REACT_ENDS:
		var today:float = float(BodyDeform.DEFAULTS[key])
		var ends:Array = REACT_ENDS[key]
		if(tight < 0.5):
			out[key] = lerp(float(ends[0]), today, tight * 2.0)
		else:
			out[key] = lerp(today, float(ends[1]), tight * 2.0 - 1.0)
	return out

static func tightOfTorso(dolls:Array, holeDoll, relations:Array) -> float:
	if(float(REACT["force"]) >= 0.0):
		return float(REACT["force"])
	var body = characterOf(holeDoll)
	if(body == null || !body.has_method("getPenetrationFreeRoom")):
		return 0.5
	var pain:float = clamp(float(body.getPainLevel()), 0.0, 1.0)
	var lust:float = clamp(float(body.getLustLevel()), 0.0, 1.0)
	var tight:float = 0.0
	for r in relations:
		var room:float = 0.0
		var by:int = dollIndex(str(r["shaft"]))
		if(by >= 0):
			var top = characterOf(dolls[by])
			var slot:String = REACT_SLOT[str(r["hole"])]
			if(!body.hasBodypart(slot)):
				slot = "anus"
			if(top != null && top.has_method("getPenisSize")):
				room = float(body.getPenetrationFreeRoom(slot, sizeOf(top.getPenisSize(), dolls[by])))
		tight = max(tight, tightOf(room, pain, lust))
	if(BENCH.has("react_trace")):
		print("REACT tight ", tight)
	return tight

static func sizeOf(cm:float, topDoll) -> float:
	var share:float = float(BENCH.get("react_girth", REACT["girth"]))
	if(share <= 0.0 && !BENCH.has("react_trace")):
		return cm
	var info = BulgeDoll.forDoll(topDoll).getShaftInfo()
	var scale = topDoll.get("rememberedPenisScale")
	if(info == null || scale == null || float(scale) <= 0.01):
		return cm
	var thick:float = float(info["radius"]) / float(scale) / float(REACT["girth_ref"])
	if(BENCH.has("react_trace")):
		print("REACT girth ", float(info["radius"]) / float(scale), " x", thick, " ", cm, " cm -> ", cm * lerp(1.0, thick, share))
	return cm * lerp(1.0, thick, share)

static func characterOf(doll):
	if(doll == null || !is_instance_valid(doll) || !doll.has_method("getCharacterID")):
		return null
	var ch = doll.getCharFromID(doll.getCharacterID())
	if(ch == null || !is_instance_valid(ch)):
		return null
	return ch

static func lingering(state:Dictionary, carries:Array, posed:Dictionary, holeHelper, opts:Dictionary) -> Array:
	var seconds:float = float(opts.get("linger", 0.0))
	if(seconds <= 0.0):
		state.erase("ghosts")
		return []
	var now:float = float(opts.get("now", 0.0))
	var dt:float = clamp(now - float(state.get("ghost_now", now)), 0.0, 0.1)
	state["ghost_now"] = now
	if(!state.has("ghosts")):
		state["ghosts"] = {}
	var ghosts:Dictionary = state["ghosts"]
	for key in ghosts:
		ghosts[key]["age"] = float(ghosts[key]["age"]) + dt
	for c in carries:
		if(c.has("portal")):
			continue
		var entry = holeAt(holeHelper, str(c["hole"]))
		if(entry == null):
			continue
		var inside:float = Basic.insideOf(c["worldA"], c["worldB"], entry)
		var g = ghosts.get(c["key"])
		if(g == null || inside >= float(g["inside"]) || float(g["age"]) >= seconds):
			ghosts[c["key"]] = {"c": c, "local": skinningAt(posed, entry).affine_inverse() * c["xw"], "inside": inside,
				"age": 0.0, "hole": c["hole"]}
	var out:Array = []
	for key in ghosts.keys():
		var g:Dictionary = ghosts[key]
		var age:float = float(g["age"])
		if(age >= seconds):
			var _gone:bool = ghosts.erase(key)
			continue
		var entry = holeAt(holeHelper, str(g["hole"]))
		if(age <= 0.0 || entry == null):
			continue
		var fade:float = 1.0 - smoothstep(0.0, seconds, age)
		var c:Dictionary = g["c"]
		var shape:Dictionary = c["shape"].duplicate()
		var rad:Array = []
		for r in shape["rad"]:
			rad.append(float(r) * fade)
		shape["rad"] = rad
		var one:Dictionary = c.duplicate()
		one["helper"] = null
		one["ghost"] = true
		one["shape"] = shape
		one["xw"] = skinningAt(posed, entry) * g["local"]
		out.append(one)
	return out

static func warm(dolls:Array, opts:Dictionary) -> void:
	for doll in dolls:
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		var shaft = helper.getShaftInfo()
		if(shaft != null && !shaft["meshes"].empty() && !shapeReady(shaft["meshes"][0])):
			var _shape = shaftShapeOf(shaft["meshes"][0])
			return
		for torso in helper.getBulgeMeshesForZone(""):
			var state:Dictionary = stateOf(torso)
			if(state["bshape"] == null):
				var _bshape = bodyShapeOf(torso, state)
				return
			if(state.has("warm") || !bool(opts.get("posed_build", true))):
				continue
			state["warm"] = true
			var skel:Skeleton = helper.getSkeletonNode()
			if(skel == null || state["bshape"].empty()):
				continue
			var posed:Dictionary = posedOf(torso, state["orig"], skel)
			if(!posed.empty()):
				var _pose = BodyPose.pose(state["orig"], state["bshape"], posed["mats"], float(opts.get("lock_at", BodyDeform.DEFAULTS["lock_at"])), posed["at"], false)
				return

static func bodyShapeOf(torso, state:Dictionary) -> Dictionary:
	if(state["bshape"] == null):
		var bodyTex = BulgeUtils.getAlbedoTexture(torso)
		state["bshape"] = {}
		if(bodyTex != null):
			state["bshape"] = BodyShape.measure(state["orig"], bodyTex)
	return state["bshape"]

static func restoreAll(stageScene) -> void:
	for doll in stageScene.getDolls():
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = BulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			restore(torso)

static func dollCount(stageScene) -> int:
	var n:int = 0
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("getDolls")):
		return n
	for doll in stageScene.getDolls():
		if(doll != null && is_instance_valid(doll)):
			n += 1
	return n

static func dollIndex(id:String) -> int:
	if(!id.begins_with("doll")):
		return -1
	return int(id.substr(4))

static func propIndex(id:String) -> int:
	if(!id.begins_with(Eyes.KIND_PROP)):
		return -1
	return int(id.substr(Eyes.KIND_PROP.length()))

static func stateOf(torso) -> Dictionary:
	if(!torso.has_meta(META_STATE)):
		torso.set_meta(META_STATE, {"orig": torso.mesh, "on": false, "cache": {}, "bshape": null, "clips": []})
	return torso.get_meta(META_STATE)

static func restore(torso) -> void:
	if(!torso.has_meta(META_STATE)):
		return
	var state:Dictionary = torso.get_meta(META_STATE)
	unclip(state)
	for helper in state.get("reposed", []):
		if(is_instance_valid(helper)):
			Repose.clear(helper.getSkeletonNode())
			Repose.forget(helper.getSkeletonNode())
			helper.unbendShaft()
	state["reposed"] = []
	unturnHead(state)
	var doll = state.get("mouth_doll")
	if(doll != null):
		mouthOpen(state, doll, false)
		state.erase("through_out")
		state.erase("through_len")
		state.erase("through_ways")
		state.erase("through_long")
	restoreMesh(torso, state)

static func restoreMesh(torso, state:Dictionary) -> void:
	BodyDeform.skin_off(torso.fancyMaterial)
	hideShade(state)
	hideThrough(state)
	if(!bool(state["on"])):
		return
	state["on"] = false
	torso.mesh = state["orig"]
	torso.set_surface_material(0, torso.fancyMaterial)

static func carryOf(shaftHelper, posed:Dictionary, portal:Dictionary = {}):
	if(shaftHelper == null):
		return "no shaft doll"
	var shaft = shaftHelper.getShaftInfo()
	if(shaft == null || shaft["meshes"].empty()):
		return "no shaft mesh"
	var penis = shaft["meshes"][0]
	var cock = cockState(shaftHelper)
	if(COCK_OFF.has(cock)):
		return "the cock is " + cock
	var penisSkel:Skeleton = shaftHelper.getSkeletonNode()
	if(penisSkel == null):
		return "no skeleton"
	var base:int = penisSkel.find_bone(SHAFT_BONE)
	if(base < 0):
		return "no " + SHAFT_BONE + " bone"
	var shape:Dictionary = shaftShapeOf(penis)
	if(shape.empty()):
		return "cannot measure the shaft"
	var penisWorldFromRest:Transform = penisSkel.global_transform * penisSkel.get_bone_global_pose(base) \
		* BulgeUtils.getBoneRestGlobal(penisSkel, base).affine_inverse()
	var restA:Vector2 = shape["pts"][0]
	var restB:Vector2 = shape["pts"][shape["pts"].size() - 1]
	if(!portal.empty()):
		penisWorldFromRest = throughPortal(portal, penisWorldFromRest.xform(Vector3(restA.x, restA.y, 0.0)),
			penisWorldFromRest.xform(Vector3(restB.x, restB.y, 0.0))) * penisWorldFromRest
	var out:Dictionary = {"helper": shaftHelper, "mesh": penis.mesh, "mask": outlineTexture(penis), "shape": shape, "skel": penisSkel,
		"flip": det2(penisWorldFromRest.basis) < 0.0}
	if(!portal.empty()):
		out["portal"] = true
	placeCarry(out, penisWorldFromRest.xform(Vector3(restA.x, restA.y, 0.0)), penisWorldFromRest.xform(Vector3(restB.x, restB.y, 0.0)), posed)
	return out

static func carryOff(c:Dictionary) -> float:
	var skel:Skeleton = c["skel"]
	var shaft = c["helper"].getShaftInfo()
	var base:int = skel.find_bone(SHAFT_BONE)
	var mid:int = skel.find_bone("Penis2")
	var end:int = skel.find_bone("Penis3")
	if(shaft == null || base < 0 || mid < 0 || end < 0):
		return -1.0
	var rigid:Transform = skel.global_transform * skel.get_bone_global_pose(base) * BulgeUtils.getBoneRestGlobal(skel, base).affine_inverse()
	var restB:Vector2 = c["shape"]["pts"][c["shape"]["pts"].size() - 1]
	var off:float = 0.0
	for one in [[mid, BulgeUtils.getBoneRestGlobal(skel, mid).origin], [end, BulgeUtils.getBoneRestGlobal(skel, end).origin], [end, Vector3(restB.x, restB.y, 0.0)]]:
		var real:Vector3 = (skel.global_transform * skel.get_bone_global_pose(one[0]) * BulgeUtils.getBoneRestGlobal(skel, one[0]).affine_inverse()).xform(one[1])
		var d:Vector3 = real - rigid.xform(one[1])
		var across:Vector3 = rigid.basis.xform(Vector3.UP)
		if(BENCH.has("carry_across")):
			off = max(off, abs(Vector2(d.x, d.y).dot(Vector2(across.x, across.y).normalized())))
		else:
			off = max(off, Vector2(d.x, d.y).length())
	return stepify(off / max(float(shaft["radius"]), 0.0001), 0.01)

static func placeCarry(out:Dictionary, worldA:Vector3, worldB:Vector3, posed:Dictionary) -> void:
	var restA:Vector2 = out["shape"]["pts"][0]
	var restB:Vector2 = out["shape"]["pts"][out["shape"]["pts"].size() - 1]
	var atA:Transform = skinningAt(posed, worldA)
	var inA:Vector3 = atA.affine_inverse().xform(worldA)
	var inB:Vector3 = atA.affine_inverse().xform(worldB)
	var mirrored:bool = (det2(atA.basis) < 0.0) != bool(out["flip"])
	out["worldA"] = worldA
	out["worldB"] = worldB
	out["atA"] = atA
	out["inA"] = inA
	out["inB"] = inB
	out["xp"] = similarity(restA, restB, Vector2(inA.x, inA.y), Vector2(inB.x, inB.y), mirrored)
	out["xw"] = similarity(restA, restB, Vector2(worldA.x, worldA.y), Vector2(worldB.x, worldB.y), bool(out["flip"]))

static func portalOf(stageScene, r:Dictionary) -> Dictionary:
	if(str(r.get("source")) != "portal" || stageScene.get_script() == null):
		return {}
	var row = PortalScenes.TABLE.get(stageScene.get_script().resource_path.trim_prefix("res://"))
	if(typeof(row) != TYPE_DICTIONARY || !row.has("portal")):
		return {}
	var eyes = Eyes.new(stageScene)
	var helper = eyes.helperFor(str(r["shaft"]))
	var hole = eyes.holeOf(str(r["hole_owner"]), str(r["hole"]))
	if(helper == null || hole == null || helper.getShaftInfo() == null):
		return {}
	var card:Dictionary = helper.getShaftInfo()
	var opening = PortalScenes.openingOf(eyes.propsOf(str(row["portal"]["owner"])).get(str(row["portal"]["zone"])),
		card["base"], (card["tip"] - card["base"]).normalized())
	if(typeof(opening) != TYPE_VECTOR3):
		return {}
	if(!stageScene.has_meta(META_PORTAL)):
		stageScene.set_meta(META_PORTAL, {})
	var deepest:Dictionary = stageScene.get_meta(META_PORTAL)
	var key:String = str(r["shaft"]) + "|" + str(actionOf(stageScene))
	if(!deepest.has(key)):
		deepest[key] = {"along": 0.0}
	return {"opening": opening, "pos": hole["pos"], "inward": hole["inward"], "deepest": deepest[key]}

static func throughPortal(portal:Dictionary, a:Vector3, b:Vector3) -> Transform:
	var dir:Vector3 = Vector3(b.x - a.x, b.y - a.y, 0.0).normalized()
	var length:float = Vector2(b.x - a.x, b.y - a.y).length()
	var along:float = (portal["opening"] - a).dot(dir)
	var deepest:Dictionary = portal["deepest"]
	deepest["along"] = min(deepest["along"], along)
	var at:Vector3 = a + dir * (length - (length - along) * length / max(length - deepest["along"], 1e-6))
	var inward:Vector2 = Vector2(portal["inward"].x, portal["inward"].y)
	var turn := Basis(Vector3(0.0, 0.0, 1.0), inward.angle() - Vector2(dir.x, dir.y).angle())
	return Transform(turn, Vector3(portal["pos"].x, portal["pos"].y, at.z) - turn.xform(at))

static func carryOfProp(prop:Dictionary, posed:Dictionary):
	var skel:Skeleton = prop["skeleton"]
	var row:Dictionary = prop["row"]
	if(!is_instance_valid(skel) || !skel.is_visible_in_tree()):
		return "the prop is gone"
	var meshInstance:MeshInstance = null
	for child in skel.get_children():
		if(child is MeshInstance && child.skin != null):
			meshInstance = child
	if(meshInstance == null):
		return "no prop mesh"
	var cut:Dictionary = PropShaft.cutOf(meshInstance, row)
	var tex = BulgeUtils.getAlbedoTexture(meshInstance)
	var shape:Dictionary = PropShaft.shapeOf(cut, row, tex)
	var bone:int = skel.find_bone(str(row["bones"][0]))
	if(cut.empty() || shape.empty() || bone < 0):
		return "cannot measure the prop's shaft"
	var worldFromRest:Transform = meshInstance.global_transform * skel.get_bone_global_pose(bone) \
		* meshInstance.skin.get_bind_pose(cut["bind"]) * cut["frame"].affine_inverse()
	var restA:Vector2 = shape["pts"][0]
	var restB:Vector2 = shape["pts"][shape["pts"].size() - 1]
	var worldA:Vector3 = propPoint(meshInstance, row, cut, restA)
	var worldB:Vector3 = propPoint(meshInstance, row, cut, restB)
	var atA:Transform = skinningAt(posed, worldA)
	var inA:Vector3 = atA.affine_inverse().xform(worldA)
	var inB:Vector3 = atA.affine_inverse().xform(worldB)
	var mirrored:bool = det2(worldFromRest.basis) * det2(atA.basis) < 0.0
	var xp:Transform = similarity(restA, restB, Vector2(inA.x, inA.y), Vector2(inB.x, inB.y), mirrored)
	var xw:Transform = similarity(restA, restB, Vector2(worldA.x, worldA.y), Vector2(worldB.x, worldB.y),
		det2(worldFromRest.basis) < 0.0)
	return {"helper": null, "rigid": bool(row.get("rigid", false)), "mesh": cut["mesh"], "mask": tex, "mask_span": cut["uv_span"], "shape": shape,
		"skel": skel, "worldA": worldA, "worldB": worldB, "atA": atA, "inA": inA, "inB": inB, "xp": xp, "xw": xw}

static func propPoint(meshInstance:MeshInstance, row:Dictionary, cut:Dictionary, rest:Vector2) -> Vector3:
	var skin:Skin = meshInstance.skin
	var skel:Skeleton = meshInstance.get_parent()
	var best:int = cut["bind"]
	var bestD:float = INF
	for i in range(skin.get_bind_count()):
		if(!row["bones"].has(skin.get_bind_name(i))):
			continue
		var d:float = abs(cut["frame"].xform(skin.get_bind_pose(i).affine_inverse().origin).x - rest.x)
		if(d < bestD):
			bestD = d
			best = i
	var bone:int = skel.find_bone(skin.get_bind_name(best))
	return (meshInstance.global_transform * skel.get_bone_global_pose(bone) * skin.get_bind_pose(best)
		* cut["frame"].affine_inverse()).xform(Vector3(rest.x, rest.y, 0.0))

static func draw(torso, holeHelper, shafts:Array, opts:Dictionary = OPTS) -> Dictionary:
	var tq0:int = OS.get_ticks_usec()
	var state:Dictionary = stateOf(torso)
	var orig:Mesh = state["orig"]
	var torsoSkel:Skeleton = holeHelper.getSkeletonNode()
	if(torsoSkel == null):
		return fail(torso, "no skeleton")
	var bshape:Dictionary = bodyShapeOf(torso, state)
	if(bshape.empty()):
		return fail(torso, "cannot measure the body")
	tq0 = lap("draw.shape", tq0)
	var posed:Dictionary = posedOf(torso, orig, torsoSkel)
	tq0 = lap("draw.posed", tq0)
	if(posed.empty()):
		return fail(torso, "the torso has no skin binds")
	var carries:Array = []
	var why:String = ""
	for one in shafts:
		var c
		if(typeof(one[0]) == TYPE_DICTIONARY):
			c = carryOfProp(one[0], posed)
		else:
			c = carryOf(one[0], posed, one[2])
		if(typeof(c) == TYPE_STRING):
			why = c
			continue
		c["throat"] = bool(one[1])
		c["hole"] = str(one[3])
		c["key"] = str(one[4]) + "/" + str(one[3])
		carries.append(c)
	tq0 = lap("draw.carry", tq0)
	var ghosts:Array = []
	if(bool(opts.get("posed_build", true))):
		ghosts = lingering(state, carries, posed, holeHelper, opts)
	tq0 = lap("draw.linger", tq0)
	if(carries.empty() && ghosts.empty()):
		return fail(torso, why)
	var main:Dictionary
	if(carries.empty()):
		main = ghosts.pop_front()
	else:
		main = carries[0]
	var penisMesh:Mesh = main["mesh"]
	var shape:Dictionary = main["shape"]
	var penisSkel:Skeleton = main["skel"]
	var atA:Transform = main["atA"]
	var xp:Transform = main["xp"]
	var xw:Transform = main["xw"]
	opts = opts.duplicate()
	opts["throat"] = main["throat"]
	opts["hole"] = str(main.get("hole", ""))
	if(str(BENCH.get("capture_to", "")) != "" && bool(BENCH.get("capture_now", false))):
		captureTo(str(BENCH["capture_to"]) + str(opts.get("capture_suffix", "")), torso, orig, posed["mats"], carries)
	var t0:int = OS.get_ticks_usec()
	var posedBuild:bool = bool(opts.get("posed_build", true))
	var pose:Dictionary = {}
	var skin:ArrayMesh
	var tp:int = lap("draw.start", t0)
	if(posedBuild):
		pose = BodyPose.pose(orig, bshape, posed["mats"], float(opts.get("lock_at", BodyDeform.DEFAULTS["lock_at"])), posed["at"])
		tp = lap("draw.pose", tp)
		state["posed_bs"] = pose["bs"]
		state["posed_mirror"] = pose["mirror"]
		state["posed_drawn_b"] = state.get("repose_drawn_b")
		state["posed_count"] = int(state.get("posed_count", 0)) + 1
		if(opts.get("curve") != null || opts.get("push") != null):
			if(!state.has("curve_cache")):
				state["curve_cache"] = {}
			opts["curve_cache"] = state["curve_cache"]
			opts["pelvis"] = pelvisOf(torsoSkel, bool(pose["mirror"]))
			if(BENCH.has("push_trace")):
				opts["push_trace"] = []
		if(BENCH.has("fit_trace")):
			opts["fit_trace"] = []
		if((bool(opts.get("through", false)) || BENCH.has("through_trace")) && torsoSkel.find_bone("Head") >= 0):
			if(BENCH.has("through_trace")):
				opts["through_trace"] = []
			var headPart = holeHelper.doll.parts.get(BodypartSlot.Head)
			var headName:String = ""
			if(headPart != null):
				headName = str(headPart.name)
			var mouth:Vector3 = MOUTH.get(headName, MOUTH["HumanHead"])
			turnHead(state, torsoSkel, float(state.get("head_turn", 0.0)), bool(pose["mirror"]))
			var headXf:Transform = Repose.world(torsoSkel, "Head")
			var at:Vector2 = Repose.xy(headXf.xform(mouth))
			var way:Vector2 = Repose.xy(headXf.basis.xform(mouth)).normalized()
			var joint:Vector2 = Repose.xy(headXf.origin)
			if(bool(pose["mirror"])):
				at.x = -at.x
				way.x = -way.x
				joint.x = -joint.x
			opts["mouth"] = [at, way, joint]
			opts["head_known"] = MOUTH.has(headName)
		elif(state.has("head_skel")):
			unturnHead(state)
		if(BodyDeform.options(opts)["backend"] == "gpu"):
			var host:Node = torso.get_viewport()
			var mapName:String = "BulgeUvMap" + str(torso.get_instance_id())
			BodyPose.uv_map(pose, host, mapName)
			state["uv_map"] = host.get_node(mapName)
			freeWith(torso, state["uv_map"])
		var shade:float = float(opts.get("shade_strength", 0.0))
		if(carries.empty()):
			shade = 0.0
		var shadeMat = null
		if(shade > 0.0):
			shadeMat = shadeMaterialOf(state, main["mask"], 0, opts, main.get("mask_span", Vector2.ONE))
			if(shadeMat == null):
				shade = 0.0
			else:
				shadeMat.set_shader_param("cock_z", main["worldA"].z)
		var more:Array = []
		for i in range(1, carries.size()):
			var c:Dictionary = carries[i]
			var smat = null
			if(shade > 0.0):
				smat = shadeMaterialOf(state, c["mask"], i, opts, c.get("mask_span", Vector2.ONE))
				if(smat != null):
					smat.set_shader_param("cock_z", c["worldA"].z)
			more.append({"mesh": c["mesh"], "xp": BodyPose.flat_xf(pose, c["xw"]), "shape": c["shape"],
				"flip": false, "throat": c["throat"], "shade_mat": smat, "hole": str(c.get("hole", "")), "rigid": bool(c.get("rigid", false))})
		for g in ghosts:
			more.append({"mesh": g["mesh"], "xp": BodyPose.flat_xf(pose, g["xw"]), "shape": g["shape"],
				"flip": false, "throat": g["throat"], "shade_mat": null, "hole": str(g.get("hole", ""))})
		var others:Array = carries + ghosts
		if(carries.empty()):
			others.push_front(main)
		tp = lap("draw.prep", tp)
		gripOf(state, others, holeHelper, pose, opts)
		tp = lap("draw.grip", tp)
		opts["hole_pt"] = main.get("hole_pt")
		opts["rigid"] = bool(main.get("rigid", false))
		opts["pull"] = main.get("pull", 0.0)
		for i in range(more.size()):
			more[i]["hole_pt"] = others[i + 1].get("hole_pt")
			more[i]["pull"] = others[i + 1].get("pull", 0.0)
		opts["more"] = more
		skin = BodyDeform.deform(pose["mesh"], Transform.IDENTITY, penisMesh, BodyPose.flat_xf(pose, xw), shape,
			pose["bs"], false, true, COVER, shade, torso.fancyMaterial, shadeMat, LOCK, null, opts)
		tp = lap("draw.deform", tp)
	else:
		var more:Array = []
		for i in range(1, carries.size()):
			var c:Dictionary = carries[i]
			more.append({"mesh": c["mesh"], "xp": c["xp"], "shape": c["shape"], "flip": false, "throat": c["throat"], "hole": str(c.get("hole", ""))})
		opts["more"] = more
		skin = BodyDeform.deform(orig, Transform.IDENTITY, penisMesh, xp, shape, bshape, false, true,
			COVER, 0.0, torso.fancyMaterial, null, LOCK, state["cache"], opts)
	var row:Dictionary = {"backend": "-", "verts": 0, "hit": false}
	if(opts.has("push_trace")):
		row["push"] = opts["push_trace"]
	if(opts.has("through_trace")):
		row["through"] = opts["through_trace"]
	if(opts.has("fit_trace")):
		row["fit"] = opts["fit_trace"]
	if(BENCH.has("smooth_trace") && posedBuild):
		var drawnOutline = pose["bs"]["outline"]
		if(skin.has_meta("polys")):
			drawnOutline = skin.get_meta("polys")["target"]
		row["smooth_polys"] = [drawnOutline, pose["bs"]["outline"], pelvisOf(torsoSkel, bool(pose["mirror"]))]
	if(BENCH.has("press_trace") && skin.has_meta("polys") && !carries.empty()):
		var polys:Dictionary = skin.get_meta("polys")
		var r:float = widestOf(carries[0])
		row["bulge_area"] = stepify((abs(BodyShape.area(polys["target"])) - abs(BodyShape.area(polys["body"]))) / (r * r), 0.001)
		row["press"] = [pose["bs"].get("press_trace"), pose["bs"].get("belly_trace"), pose["bs"].get("split_trace")]
		row["press_us"] = pose["bs"].get("press_us")
		if(BENCH.has("press_polys")):
			row["polys"] = polys
	if(BENCH.has("carry_trace") && !carries.empty() && carries[0]["helper"] != null):
		row["carry_off"] = carryOff(carries[0])
		row["fade"] = [stepify(float(state.get("repose_w", -1.0)), 0.01), stepify(float(state.get("repose", {}).get("when", -1.0)), 0.001), str(state.get("repose", {}).get("keys", ""))]
	if(skin.has_meta("info") && typeof(skin.get_meta("info")) == TYPE_DICTIONARY):
		var info:Dictionary = skin.get_meta("info")
		row["hit"] = bool(info["hit"])
		row["entry"] = info["entry_pt"]
		row["base"] = info["base"]
		row["tip"] = info["tip"]
		if(info.has("ang") && !info["ang"].empty()):
			row["bend"] = info["ang"][info["ang"].size() - 1]
		if(bool(BENCH.get("curve_trace", false)) && posedBuild && info.has("axis")):
			row["arc"] = info.get("arc")
			for key in ["axis", "lane"]:
				var world:Array = []
				for p in info.get(key, []):
					world.append(BodyPose.world_of(pose, p))
				row[key + "_world"] = world
			row["cock_world"] = [BodyPose.world_of(pose, info["base"]), BodyPose.world_of(pose, info["entry_pt"]), BodyPose.world_of(pose, info["tip"])]
		if(bool(BENCH.get("hole_trace", false)) && posedBuild):
			var holes:Dictionary = {}
			for zone in HOLES:
				var at = holeAt(holeHelper, zone)
				if(at != null):
					holes[zone] = BodyPose.world_of(pose, Vector2(at.x, at.y))
			row["game_holes"] = holes
	var infos:Array = []
	if(skin.has_meta("infos")):
		infos = skin.get_meta("infos")
	var clips:Array = []
	for i in range(carries.size()):
		if(i >= infos.size() || !bool(infos[i]["hit"])):
			continue
		row["hit"] = true
		var c:Dictionary = carries[i]
		var crossing:Vector2 = infos[i]["entry_pt"]
		if(posedBuild):
			var traced = null
			if(i == 0 && (BENCH.has("clip_trace") || BENCH.has("seen_trace"))):
				traced = row
			crossing = crossingOf(pose, infos[i], c, traced, state, float(opts.get("now", 0.0)))
			if(i == 0 && BENCH.has("smooth_trace")):
				row["smooth_cut"] = [BodyPose.world_of(pose, infos[i]["entry_pt"]), BodyPose.world_of(pose, crossing), widestOf(c)]
			var mats:Array = state.get("shade_mats", [])
			var shadeStart:float = 0.0
			if(i < mats.size() && mats[i] != null && !BENCH.has("shade_at_entry")):
				mats[i].set_shader_param("shade_start", (crossing - infos[i]["entry_pt"]).dot(infos[i]["dir"]))
				shadeStart = float(mats[i].get_shader_param("shade_start"))
			if(traced != null && skin.has_meta("polys") && infos[i].has("path")):
				var target = skin.get_meta("polys")["target"]
				var past:int = 0
				var outside:int = 0
				for q in infos[i]["path"]:
					if((q - infos[i]["entry_pt"]).dot(infos[i]["dir"]) > shadeStart):
						past += 1
						if(!Geometry.is_point_in_polygon(q, target)):
							outside += 1
				row["path_out"] = stepify(float(outside) / max(past, 1), 0.01)
			if(traced != null):
				var d:Vector2 = infos[i]["dir"]
				row["shade_seen"] = seenPast(pose["bs"], infos[i]["entry_pt"], d, Vector2(-d.y, d.x), widestOf(c), shadeStart)
		if(c["helper"] == null || c.has("portal")):
			continue
		var entry:Vector2 = infos[i]["entry_pt"]
		var entryWorld:Vector3
		if(posedBuild):
			var flat:Vector2 = BodyPose.world_of(pose, crossing)
			entryWorld = Vector3(flat.x, flat.y, c["worldA"].z)
		else:
			var near:int = nearestVertex(weightLookupOf(orig), entry)
			entryWorld = BodyPose._blend(posed["mats"], posed["bones"], posed["weights"], near).xform(Vector3(entry.x, entry.y, 0.0))
		c["helper"].unTaperShaftBones()
		if(i == 0 && bool(BENCH.get("fit_trace", false)) && posedBuild):
			row["outside"] = outsideOf(pose, infos[i], c)
		c["helper"].applyShaftClip(entryWorld, bool(infos[i].get("long", false)))
		if(i == 0 && BENCH.has("clip_trace")):
			row["clip_world"] = [entryWorld, c["worldA"], c["worldB"]]
			var shaftMeshes:Array = c["helper"].getShaftInfo()["meshes"]
			var fit = null
			if(!shaftMeshes.empty()):
				fit = BulgeUtils.fitOf(shaftMeshes[0])
			if(fit != null):
				var rx:float = BulgeUtils.worldToRest(c["helper"].getSkeletonNode(), "Penis", entryWorld).x
				var mat = shaftMeshes[0].get("fancyMaterial")
				var params:Array = []
				if(mat != null):
					var u0:float = BulgeUtils.restToUV(fit, fit["restMin"]).x
					var u1:float = BulgeUtils.restToUV(fit, fit["restMax"]).x
					var clip = mat.get_shader_param("shaft_clip")
					var skelP:Skeleton = c["helper"].getSkeletonNode()
					var tipR:Vector3 = BulgeUtils.worldToRest(skelP, "Penis", c["worldB"])
					var baseR:Vector3 = BulgeUtils.worldToRest(skelP, "Penis", c["worldA"])
					var dirC:float = float(mat.get_shader_param("shaft_clip_dir"))
					params = [stepify(float(clip), 0.001), dirC, stepify(u0, 0.001), stepify(u1, 0.001),
						stepify(float(mat.get_shader_param("shaft_clip_feather")), 0.0001), str(mat.shader.code.find("shaft_clip") >= 0),
						"tip hidden", str((BulgeUtils.restToUV(fit, Vector2(tipR.x, tipR.y)).x - float(clip)) * dirC > 0.0),
						"base hidden", str((BulgeUtils.restToUV(fit, Vector2(baseR.x, baseR.y)).x - float(clip)) * dirC > 0.0),
						"scale", stepify(float(c["helper"].doll.get("rememberedPenisScale")), 0.01), "visible meshes", visibleMeshes(c["helper"].doll.parts.get(BodypartSlot.Penis))]
				row["clip_at"] = [stepify((rx - fit["restMin"].x) / max(fit["restMax"].x - fit["restMin"].x, 1e-6), 0.01), stepify(widestOf(c), 0.001), params]
		clips.append(c["helper"])
	for helper in state["clips"]:
		if(!clips.has(helper)):
			unclipOne(helper)
	state["clips"] = clips
	tp = lap("draw.hide", tp)
	state["sheet"] = sheetOf(state, carries, infos, pose, posedBuild, str(opts.get("direction", "")) == "sliders" && float(opts.get("bend", 0.0)) > 0.0)
	tp = lap("draw.sheet", tp)
	if(bool(BENCH.get("trace", false)) && row.has("entry")):
		row["trace"] = traceOf(bshape, skin.get_meta("info"), skin, penisSkel, atA)
	if(!skin.has_meta("polys")):
		restoreMesh(torso, state)
		row["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
		if(posedBuild):
			drawThrough(torso, state, skin, pose, carries, torsoSkel, opts, holeHelper.doll, posed)
		if(posedBuild && skin.has_meta("shaded") && !skin.get_meta("shaded").empty()):
			drawShade(torso, state, skin, pose, posed)
			row["shade_only"] = true
			return row
		row["why"] = "no outline change (the shaft stays inside the body, is outside it, or is past the lock line)"
		return row
	if(bool(BENCH.get("areas", false))):
		var polys:Dictionary = skin.get_meta("polys")
		row["area_body"] = stepify(BodyShape.area(polys["body"]), 0.001)
		row["area_target"] = stepify(BodyShape.area(polys["target"]), 0.001)
	if(BENCH.has("grip_radius") && posedBuild && main.has("hole") && skin.has_meta("info")):
		gripTrace(row, skin, pose, holeAt(holeHelper, str(main["hole"])), float(BENCH["grip_radius"]))
	var weighted:ArrayMesh
	if(posedBuild):
		weighted = BodyPose.unpose(skin, pose)
		if(weighted == null):
			restoreMesh(torso, state)
			row["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
			row["why"] = "the posed skin carries no bones"
			return row
	else:
		weighted = weightedOf(skin, orig)
	tp = lap("draw.unpose", tp)
	torso.mesh = weighted
	torso.set_surface_material(0, torso.fancyMaterial)
	state["on"] = true
	if(posedBuild):
		drawShade(torso, state, skin, pose, posed)
		drawThrough(torso, state, skin, pose, carries, torsoSkel, opts, holeHelper.doll, posed)
	tp = lap("draw.shade", tp)
	if(bool(BENCH.get("fold_check", false))):
		row["folded"] = foldedOf(skin, weighted, posed["mats"], pose)
	if(row.has("trace")):
		var wa:Array = weighted.surface_get_arrays(0)
		var posedSkin:Array = []
		var restSkin:Array = []
		for i in range(wa[Mesh.ARRAY_VERTEX].size()):
			var v:Vector3 = wa[Mesh.ARRAY_VERTEX][i]
			restSkin.append(v)
			posedSkin.append(BodyPose._blend(posed["mats"], wa[Mesh.ARRAY_BONES], wa[Mesh.ARRAY_WEIGHTS], i).xform(v))
		row["trace"]["skin_rest"] = listOf(restSkin)
		row["trace"]["skin_posed"] = listOf(posedSkin)
		row["trace"]["torso_posed"] = listOf(posed["at"])
		var fm = torso.fancyMaterial
		row["trace"]["drawn"] = {"format": weighted.surface_get_format(0), "uv2": (weighted.surface_get_format(0) & Mesh.ARRAY_FORMAT_TEX_UV2) != 0,
			"bones": (weighted.surface_get_format(0) & Mesh.ARRAY_FORMAT_BONES) != 0, "bulge_on": fm.get_shader_param("bulge_on"),
			"border_n": fm.get_shader_param("bulge_border_n"), "mapped_shader": fm.shader.code.find("bulge_shift") >= 0,
			"mesh_is_skin": weighted == skin, "surface_mat_same": torso.get_surface_material(0) == fm,
			"material_override": torso.material_override != null}
		var dump:String = str(BENCH.get("dump_to", ""))
		if(dump != "" && bool(BENCH.get("dump_now", false))):
			BENCH["dump_now"] = false
			var clean := ArrayMesh.new()
			clean.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, weighted.surface_get_arrays(0))
			var _m = ResourceSaver.save(dump + "/skin_mesh.res", clean)
			var params:Dictionary = {}
			for info in VisualServer.shader_get_param_list(fm.shader.get_rid()):
				var v = fm.get_shader_param(info["name"])
				if(v is Texture):
					var _t = ResourceSaver.save(dump + "/tex_" + info["name"] + ".res", v)
					v = "tex:" + info["name"]
				params[info["name"]] = v
			var f := File.new()
			if(f.open(dump + "/params.txt", File.WRITE) == OK):
				f.store_var(params)
				f.close()
			var sh := File.new()
			if(sh.open(dump + "/shader.txt", File.WRITE) == OK):
				sh.store_string(fm.shader.code)
				sh.close()
	row["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
	row["backend"] = str(skin.get_meta("stats")["backend"])
	row["verts"] = int(skin.get_meta("stats")["verts"])
	return row

const MOUTH := {"HorseHead": Vector3(0.764, -0.100, -0.082), "WolfHead": Vector3(0.407, -0.020, -0.063),
	"DragonHead": Vector3(0.508, 0.012, -0.068), "BulldogHead": Vector3(0.488, 0.010, -0.067),
	"HorseHead2": Vector3(0.709, 0.025, -0.079), "HumanHead": Vector3(0.450, -0.055, -0.065),
	"FoxHead": Vector3(0.561, -0.034, -0.071), "FelineHead": Vector3(0.537, -0.031, -0.070),
	"CanineHead": Vector3(0.545, -0.060, -0.070), "HumanOldHead": Vector3(0.449, -0.028, -0.065),
	"FennecHead": Vector3(0.508, -0.030, -0.068)}

static func pelvisOf(skel:Skeleton, mirror:bool):
	if(skel.find_bone(Repose.HIPS) < 0):
		return null
	var hips:Transform = Repose.world(skel, Repose.HIPS)
	var at:Vector2 = Repose.xy(hips.origin)
	var up:Vector2 = Repose.xy(hips.basis.y).normalized()
	if(mirror):
		at.x = -at.x
		up.x = -up.x
	return Transform2D(up, Vector2(-up.y, up.x), at)

static func sheetOf(state:Dictionary, carries:Array, infos:Array, pose:Dictionary, posedBuild:bool, guided:bool = false) -> Dictionary:
	var sheet:Dictionary = {}
	if(!posedBuild):
		return sheet
	for i in range(min(carries.size(), infos.size())):
		var info:Dictionary = infos[i]
		if(!bool(info["hit"]) || !info.has("axis")):
			continue
		var c:Dictionary = carries[i]
		var shaft:String = str(c["key"]).rsplit("/", true, 1)[0]
		var one:Dictionary = {"z": c["worldA"].z, "line": state.get("repose_way", {}).get(shaft, Vector2.ZERO),
			"knob": state.get("repose_way", {}).get(shaft + "/knob", 0.0), "arc": info.get("arc"),
			"radius": widestOf(c)}
		for key in ["lane", "path"]:
			var world:Array = []
			var from:String = key
			if(key == "path"):
				from = "axis"
			elif(guided && !info.has("lane")):
				from = "guide"
			for p in info.get(from, []):
				world.append(BodyPose.world_of(pose, p))
			one[key] = world
		var helpLane:Array = []
		var m = state.get("repose_drawn_b")
		for q in state.get("repose_lane", {}).get(str(c.get("hole", "")), []):
			if(m != null):
				q = m[2] + (q - m[2]).rotated(float(m[1])) + m[0]
			helpLane.append(q)
		one["help_lane"] = helpLane
		sheet[c["key"]] = one
	return sheet

const PREROLL := {"span": 1.8, "step": 0.15, "body": 3}
static func preroll(stageScene, torso, holeHelper, shafts:Array, opts:Dictionary, alone:bool) -> void:
	var state:Dictionary = stateOf(torso)
	var key:Array = [str(opts.get("action", "")), shaftKeys(shafts)]
	if(!bool(opts.get("repose", false)) || state.get("prerolled") == key || BENCH.has("preroll_off")):
		return
	var first:bool = !state.has("prerolled")
	state["prerolled"] = key
	if(!first && !BENCH.has("preroll_always")):
		return
	var ahead:Array = AnimAhead.of(stageScene)
	var skel:Skeleton = holeHelper.getSkeletonNode()
	if(ahead.empty() || skel == null):
		return
	var t0:int = OS.get_ticks_usec()
	var saved:Array = AnimAhead.save(ahead)
	var now:float = float(opts.get("now", 0.0))
	var at:float = AnimAhead.positionOf(ahead)
	var loop:float = max(AnimAhead.lengthOf(ahead), 1e-3)
	var steps:int = int(ceil(float(PREROLL["span"]) / float(PREROLL["step"])))
	var parts:Array = [0, 0, 0]
	var posed:Dictionary = BulgeDoll.POSED
	posed["ahead"] = true
	for k in range(steps):
		var back:float = float(steps - k) * float(PREROLL["step"])
		AnimAhead.poseAt(ahead, fposmod(at - back, loop))
		posed["n"] = int(posed["n"]) + 1
		var o:Dictionary = opts.duplicate()
		o["now"] = now - back
		var t1:int = OS.get_ticks_usec()
		reposeTorso(torso, holeHelper, shafts, o, alone)
		var t2:int = OS.get_ticks_usec()
		if(k % int(PREROLL["body"]) == 0 || k == steps - 1):
			drawnBody(torso, state, skel, opts)
		parts[0] += t2 - t1
		parts[1] += OS.get_ticks_usec() - t2
	var t3:int = OS.get_ticks_usec()
	keepLanes(state, holeHelper, shafts, opts)
	parts[2] += OS.get_ticks_usec() - t3
	AnimAhead.poseAt(ahead, at)
	posed["n"] = int(posed["n"]) + 1
	reposeTorso(torso, holeHelper, shafts, opts, alone)
	AnimAhead.restore(ahead, saved)
	posed["n"] = int(posed["n"]) + 1
	posed["ahead"] = false
	if(BENCH.has("preroll_ms")):
		var knobs:Dictionary = BENCH
		knobs["preroll_ms"].append((OS.get_ticks_usec() - t0) / 1000.0)
		if(BENCH.has("preroll_trace")):
			print("preroll ", key, " at ", now, " loop pos ", at, " help/body/lanes ms ", parts[0] / 1000, " ", parts[1] / 1000, " ", parts[2] / 1000, " steps ", steps)

static func shaftKeys(shafts:Array) -> String:
	var out:String = ""
	for one in shafts:
		out += str(one[4]) + "/" + str(one[3]) + " "
	return out

static func drawnBody(torso, state:Dictionary, skel:Skeleton, opts:Dictionary) -> void:
	var bshape:Dictionary = bodyShapeOf(torso, state)
	var posed:Dictionary = posedOf(torso, state["orig"], skel)
	if(bshape.empty() || posed.empty()):
		return
	var pose:Dictionary = BodyPose.pose(state["orig"], bshape, posed["mats"], float(opts.get("lock_at", BodyDeform.DEFAULTS["lock_at"])), posed["at"], false)
	state["posed_bs"] = pose["bs"]
	state["posed_mirror"] = pose["mirror"]
	state["posed_drawn_b"] = state.get("repose_drawn_b")
	state["posed_count"] = int(state.get("posed_count", 0)) + 1

static func keepLanes(state:Dictionary, holeHelper, shafts:Array, opts:Dictionary) -> void:
	if(opts.get("curve") == null || !state.has("posed_bs")):
		return
	if(!state.has("curve_cache")):
		state["curve_cache"] = {}
	var mirror:bool = bool(state.get("posed_mirror", false))
	var o:Dictionary = opts.duplicate()
	o["curve_cache"] = state["curve_cache"]
	o["pelvis"] = pelvisOf(holeHelper.getSkeletonNode(), mirror)
	for one in shafts:
		var helper = one[0]
		if(typeof(helper) == TYPE_DICTIONARY || helper == null || bool(one[1]) || !["vagina", "anus"].has(str(one[3]))):
			continue
		var hole = holeAt(holeHelper, str(one[3]))
		var shaft = helper.getShaftInfo()
		if(hole == null || shaft == null || o["pelvis"] == null):
			continue
		var start := Vector2(hole.x, hole.y)
		if(mirror):
			start.x = -start.x
		opts["curve"].keepLane(o, state["posed_bs"], start, str(one[3]),
			float(o.get("belly_gap", BodyDeform.DEFAULTS["belly_gap"])) * float(shaft["radius"]), clamp(float(o.get("canal_belly", 0.0)), 0.0, 1.0))

const SELF := "res://Bulge4/Effects/Detailed/RubberSkin.gd"
static func reposeTorso(torso, holeHelper, shafts:Array, opts:Dictionary, alone:bool) -> void:
	var state:Dictionary = stateOf(torso)
	var t0:int = OS.get_ticks_usec()
	var now:Array = ReposeScene.reposeAll(state, shafts, holeHelper, opts, alone, load(SELF))
	var helped:bool = bool(opts.get("repose", false))
	if(!helped):
		now = straighten(state, shafts)
	state["helped"] = helped
	if(opts.has("help_ms")):
		opts["help_ms"].append((OS.get_ticks_usec() - t0) / 1000.0)
	for helper in state.get("reposed", []):
		if(!now.has(helper) && is_instance_valid(helper)):
			Repose.clear(helper.getSkeletonNode())
			Repose.forget(helper.getSkeletonNode())
			helper.unbendShaft()
	state["reposed"] = now

static func straighten(state:Dictionary, shafts:Array) -> Array:
	var out:Array = []
	for one in shafts:
		var helper = one[0]
		if(typeof(helper) == TYPE_DICTIONARY || helper == null || !is_instance_valid(helper) || bool(one[1]) || !one[2].empty()):
			continue
		var skel:Skeleton = helper.getSkeletonNode()
		var shaft = helper.getShaftInfo()
		if(skel == null || shaft == null):
			continue
		if(bool(state.get("helped", false)) && state.get("reposed", []).has(helper)):
			Repose.clear(skel)
		var chain = helper.shaftChainOf()
		if(chain == null):
			continue
		var line:Array = ReposeScene.cockLine(chain, shaft)
		var way:Vector2 = (line[line.size() - 1] - line[0]).normalized()
		helper.bendShaft([way, way, way], chain["rest_axis"])
		out.append(helper)
	return out

const CUT := {"reach": 2.0, "past": 0.1, "ease": 20.0, "deep": 40.0}
const CUT_EDGES := [-1.0, 0.0, 1.0]
static func crossingOf(pose:Dictionary, info:Dictionary, c:Dictionary, row = null, state = null, now:float = 0.0) -> Vector2:
	var bs:Dictionary = pose["bs"]
	var dir:Vector2 = info["dir"]
	var at:Vector2 = info["entry_pt"]
	var radius:float = widestOf(c)
	var n := Vector2(-dir.y, dir.x)
	var edges:Array = CUT_EDGES
	var past:float = float(CUT["past"])
	if(BENCH.has("clip_axis")):
		edges = [0.0]
		past = 0.0
	var deepest:float = 0.0
	for f in edges:
		var e:float = enteredAt(bs, at + n * radius * f, dir, radius)
		if(e < float(CUT["reach"]) * radius):
			deepest = max(deepest, e)
	var start:float = deepest + past * radius
	if(state != null):
		if(!state.has("cut_held")):
			state["cut_held"] = {}
		var held:Array = state["cut_held"].get(c["key"], [start, now])
		if(now >= float(held[1])):
			if(start > float(held[0]) && float(CUT["deep"]) > 0.0):
				start = lerp(float(held[0]), start, clamp((now - float(held[1])) * float(CUT["deep"]), 0.0, 1.0))
			else:
				start = max(start, lerp(float(held[0]), start, clamp((now - float(held[1])) * float(CUT["ease"]), 0.0, 1.0)))
		state["cut_held"][c["key"]] = [start, now]
	if(row != null):
		row["clip_seen"] = seenPast(bs, at, dir, n, radius, start)
		row["pull"] = stepify(float(c.get("pull", 0.0)), 0.01)
	return at + dir * start

static func visibleMeshes(node) -> Array:
	var out:Array = []
	if(node == null):
		return out
	for child in node.get_children():
		if(child is MeshInstance && child.is_visible_in_tree()):
			var mat = child.get("fancyMaterial")
			var clipped:bool = mat != null && mat.shader != null && mat.shader.code.find("shaft_clip") >= 0
			out.append([child.name, clipped, child.material_override != null])
		out += visibleMeshes(child)
	return out

static func widestOf(c:Dictionary) -> float:
	var widest:float = 0.0
	for r in c["shape"]["rad"]:
		widest = max(widest, float(r))
	return max(widest * c["xw"].basis.x.length(), 0.0001)

static func enteredAt(bs:Dictionary, p:Vector2, dir:Vector2, radius:float) -> float:
	var reach:float = float(CUT["reach"]) * radius
	var first:float = reach
	for part in Geometry.intersect_polyline_with_polygon_2d(PoolVector2Array([p, p + dir * reach]), bs["outline"]):
		for q in part:
			first = min(first, (q - p).dot(dir))
	return max(first, 0.0)

static func seenPast(bs:Dictionary, at:Vector2, dir:Vector2, n:Vector2, radius:float, start:float) -> float:
	var seen:float = 0.0
	for f in [-1.0, -0.5, 0.0, 0.5, 1.0]:
		var e:float = enteredAt(bs, at + n * radius * f, dir, radius)
		if(e < float(CUT["reach"]) * radius):
			seen = max(seen, (e - start) / radius)
	return stepify(seen, 0.01)

const GRIP := {"radii": 2.5, "base": 0.5, "gain": 4.0, "hold_base": 0.2, "reach": 1.5, "release": 2.0, "let_go": 12.0,
	"loose": 0.3, "tight": 1.7}
static func gripOf(state:Dictionary, carries:Array, holeHelper, pose:Dictionary, opts:Dictionary) -> void:
	var mode:String = str(opts.get("grip_mode", "off"))
	var grip:float = clamp(float(opts.get("grip", 0.0)), 0.0, 1.0)
	if(mode == "off"):
		grip = 0.0
	var tightShare:float = 1.0
	if(mode == "shape_tight"):
		tightShare = lerp(float(GRIP["loose"]), float(GRIP["tight"]), clamp(float(opts.get("grip_tight", 0.5)), 0.0, 1.0))
	var now:float = float(opts.get("now", 0.0))
	var dt:float = clamp(now - float(state.get("grip_now", now)), 0.0, 0.1)
	state["grip_now"] = now
	if(!state.has("grip_strokes")):
		state["grip_strokes"] = {}
	var strokes:Dictionary = state["grip_strokes"]
	for c in carries:
		c.erase("hole_pt")
		c["pull"] = 0.0
		if(!c.has("hole") || str(c["hole"]) == "mouth"):
			continue
		var anchor = holeAt(holeHelper, str(c["hole"]))
		if(anchor == null):
			continue
		c["hole_pt"] = BodyPose.world_of(pose, Vector2(anchor.x, anchor.y))
		if(grip <= 0.0 || c.has("ghost")):
			continue
		var inside:float = Basic.insideOf(c["worldA"], c["worldB"], anchor)
		if(mode == "static"):
			if(!strokes.has(c["key"])):
				strokes[c["key"]] = [inside, inside]
			c["pull"] = grip * float(GRIP["radii"]) * (1.0 - Basic.strokeAmount(strokes[c["key"]], inside, dt))
			continue
		var length:float = max(c["worldA"].distance_to(c["worldB"]), 0.0001)
		var radius:float = widestOf(c)
		var was:Array = strokes.get(c["key"], [inside, 0.0])
		var moved:float = (float(was[0]) - inside) / radius
		var widening:float = wideningAt(c["shape"], inside / length) * 2.0 * float(opts.get("grip_shape", 0.5))
		var pull:float = gripStep(float(was[1]), moved, widening, tightShare, grip, dt)
		strokes[c["key"]] = [inside, pull]
		if(BENCH.has("grip_trace")):
			var ax:Vector3 = (c["worldB"] - c["worldA"]) / length
			var rel:Vector3 = anchor - c["worldA"]
			var across:float = (rel - ax * rel.dot(ax)).length()
			if(!state.has("grip_side")):
				state["grip_side"] = {}
			var prev:Array = state["grip_side"].get(c["key"], [inside, across])
			state["grip_side"][c["key"]] = [inside, across]
			print("GRIP ", Engine.get_frames_drawn(), " ", c["key"], " inside ", stepify(inside / length, 0.001), " along ", stepify((float(prev[0]) - inside) / radius, 0.0001),
				" across ", stepify((across - float(prev[1])) / radius, 0.0001), " widening ", stepify(widening, 0.001), " pull ", stepify(pull, 0.001))
		if(BENCH.has("grip_log")):
			BENCH["grip_log"].append([inside / length, widening, pull])
			BENCH["grip_radii"] = c["shape"]["rad"]
		c["pull"] = pull

static func gripStep(pull:float, moved:float, widening:float, tightShare:float, grip:float, dt:float) -> float:
	var press:float = clamp(float(GRIP["gain"]) * widening, 0.0, 1.0)
	if(moved > 0.0):
		pull += moved * clamp((float(GRIP["base"]) + press) * tightShare * 2.0 * grip, 0.0, 1.0)
	else:
		pull = max(pull + moved, 0.0)
	var held:float = float(GRIP["radii"]) * min((float(GRIP["hold_base"]) + press) * tightShare, 1.0)
	var slow:float = max(tightShare, 0.0001)
	if(pull > held):
		pull = held + (pull - held) * exp(-float(GRIP["let_go"]) / slow * dt)
	pull *= exp(-float(GRIP["release"]) / slow * dt)
	return clamp(pull, 0.0, float(GRIP["radii"]))

static func wideningAt(shape:Dictionary, inside:float) -> float:
	var rad:Array = shape["rad"]
	var n:int = rad.size()
	if(n < 2 || inside <= 0.0 || inside >= 1.0):
		return 0.0
	var at:int = int(round((1.0 - inside) * float(n - 1)))
	var widest:float = 0.0
	for r in rad:
		widest = max(widest, float(r))
	var step:float = max(shape["pts"][0].distance_to(shape["pts"][n - 1]) / float(n - 1), 0.0001)
	var reach:int = int(max(ceil(float(GRIP["reach"]) * widest / step), 1.0))
	var out:float = float(rad[at])
	for i in range(max(at - reach, 0), at):
		out = min(out, float(rad[i]))
	out = max(out, 0.0001)
	var most:float = 0.0
	for i in range(at, min(at + reach, n - 1) + 1):
		most = max(most, (float(rad[i]) / out - 1.0) * (1.0 - float(i - at) / float(reach + 1)))
	return most

static func gripTrace(row:Dictionary, skin:ArrayMesh, pose:Dictionary, anchor, radius:float) -> void:
	if(anchor == null):
		return
	var info:Dictionary = skin.get_meta("info")
	var hole:Vector2 = BodyPose.world_of(pose, Vector2(anchor.x, anchor.y))
	var dir:Vector2 = info["dir"]
	row["grip_out"] = stepify((hole - info["entry_pt"]).dot(dir), 0.001)
	row["grip_inside"] = stepify((info["tip"] - hole).dot(dir), 0.001)
	if(!skin.has_meta("polys")):
		row["grip_pulled"] = 0.0
		return
	var polys:Dictionary = skin.get_meta("polys")
	var disk := PoolVector2Array()
	for i in range(32):
		disk.append(hole + Vector2(radius, 0.0).rotated(TAU * float(i) / 32.0))
	var pulled:float = 0.0
	for gained in Geometry.clip_polygons_2d(polys["target"], polys["body"]):
		for near in Geometry.intersect_polygons_2d(gained, disk):
			pulled += abs(BodyShape.area(near))
	row["grip_pulled"] = stepify(pulled, 0.0001)

static func captureTo(dir:String, torso, orig:Mesh, mats:Array, carries:Array) -> void:
	var _made = Directory.new().make_dir_recursive(dir)
	var parts:Array = [["torso", orig, BulgeUtils.getAlbedoTexture(torso)]]
	var more:Array = []
	for i in range(carries.size()):
		var name:String = "penis"
		if(i > 0):
			name = "penis_" + str(i)
			more.append({"xp": carries[i]["xp"], "xw": carries[i]["xw"], "throat": carries[i]["throat"]})
		parts.append([name, carries[i]["mesh"], carries[i]["mask"]])
	for part in parts:
		var clean := ArrayMesh.new()
		clean.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, part[1].surface_get_arrays(0))
		var _saved = ResourceSaver.save(dir + "/" + part[0] + ".res", clean)
		var tex = part[2]
		if(tex != null):
			var img:Image = tex.get_data()
			if(img.is_compressed()):
				var _d = img.decompress()
			var _png = img.save_png(dir + "/" + part[0] + ".png")
	var f := File.new()
	if(f.open(dir + "/pose.var", File.WRITE) == OK):
		f.store_var({"mats": mats, "xp": carries[0]["xp"], "xw": carries[0]["xw"], "throat": carries[0]["throat"], "more": more})
		f.close()

static func foldedOf(skin:ArrayMesh, weighted:ArrayMesh, mats:Array, pose:Dictionary) -> int:
	var wa:Array = weighted.surface_get_arrays(0)
	var built:PoolVector3Array = wa[Mesh.ARRAY_VERTEX]
	if(!pose.empty()):
		built = skin.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
	var idx:PoolIntArray = wa[Mesh.ARRAY_INDEX]
	var drawn := PoolVector3Array()
	for i in range(wa[Mesh.ARRAY_VERTEX].size()):
		drawn.append(BodyPose._blend(mats, wa[Mesh.ARRAY_BONES], wa[Mesh.ARRAY_WEIGHTS], i).xform(wa[Mesh.ARRAY_VERTEX][i]))
	var flipped := 0
	var total := 0
	for t in range(0, idx.size() - 2, 3):
		var a:float = area2(built[idx[t]], built[idx[t + 1]], built[idx[t + 2]])
		var b:float = area2(drawn[idx[t]], drawn[idx[t + 1]], drawn[idx[t + 2]])
		if(a == 0.0 || b == 0.0):
			continue
		total += 1
		if((a > 0.0) != (b > 0.0)):
			flipped += 1
	return int(min(flipped, total - flipped))

static func area2(a:Vector3, b:Vector3, c:Vector3) -> float:
	return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)

static func traceOf(bshape:Dictionary, info:Dictionary, skin:ArrayMesh, penisSkel:Skeleton, atA:Transform) -> Dictionary:
	var out:Dictionary = {"outline": listOf(bshape["outline"]), "path": listOf(info.get("path", [])),
		"guide": listOf(info.get("guide", [])), "entry": listOf([info["entry_pt"]])}
	if(skin.has_meta("polys")):
		var polys:Dictionary = skin.get_meta("polys")
		out["sleeve"] = listOf(polys["sleeve"])
		out["target"] = listOf(polys["target"])
	var bones:Array = []
	for name in [SHAFT_BONE, "Penis2", "Penis3"]:
		var b:int = penisSkel.find_bone(name)
		if(b >= 0):
			var w:Vector3 = (penisSkel.global_transform * penisSkel.get_bone_global_pose(b)).origin
			bones.append(atA.affine_inverse().xform(w))
	out["animated_bones"] = listOf(bones)
	var base:int = penisSkel.find_bone(SHAFT_BONE)
	var tipBone:int = penisSkel.find_bone("Penis3")
	if(base >= 0 && tipBone >= 0):
		var baseScale:float = penisSkel.get_bone_global_pose(base).basis.get_scale().y
		out["taper_drawn"] = stepify(penisSkel.get_bone_global_pose(tipBone).basis.get_scale().y / baseScale, 0.001)
		out["taper_animated"] = stepify(penisSkel.get_bone_pose(tipBone).basis.get_scale().y
			* penisSkel.get_bone_pose(penisSkel.get_bone_parent(tipBone)).basis.get_scale().y, 0.001)
	return out

static func listOf(points) -> Array:
	var out:Array = []
	for p in points:
		out.append([stepify(p.x, 0.0001), stepify(p.y, 0.0001)])
	return out

const SHADE_STYLES := {"soft": [0, 0.0], "soft_outline": [0, 1.0], "filled": [1, 0.0], "filled_outline": [1, 1.0],
	"halo": [2, 0.0], "halo_outline": [2, 1.0], "xray": [3, 0.0], "xray_outline": [3, 1.0]}
const SHADE_TEXEL := Vector2(0.006, 0.012)
static func shadeMaterialOf(state:Dictionary, tex, slot:int, opts:Dictionary, span:Vector2 = Vector2.ONE):
	if(tex == null):
		return null
	var mats:Array = state.get("shade_mats", [])
	while(mats.size() <= slot):
		mats.append(null)
	var onTop:bool = bool(opts.get("shade_on_top", false))
	if(mats[slot] == null || mats[slot].get_shader_param("mask") != tex || mats[slot].shader != BodyDeform.shade_shader(onTop)):
		mats[slot] = BodyDeform.make_shade_material(tex, onTop)
	state["shade_mats"] = mats
	var look:Array = SHADE_STYLES.get(str(opts.get("shade_style", "soft")), SHADE_STYLES["soft"])
	if(mats[slot].get_shader_param("texel") != SHADE_TEXEL * span):
		mats[slot].set_shader_param("texel", SHADE_TEXEL * span)
	mats[slot].set_shader_param("style", int(look[0]))
	mats[slot].set_shader_param("shade_start", 0.0)
	mats[slot].set_shader_param("outline", float(look[1]))
	return mats[slot]

static func drawShade(torso, state:Dictionary, skin:ArrayMesh, pose:Dictionary, posed:Dictionary) -> void:
	if(skin.get_surface_count() < 2 || !skin.has_meta("shaded")):
		if(bool(BENCH.get("shade_trace", false))):
			print("SHADETRACE ", Engine.get_idle_frames(), " ", torso.get_instance_id(), " hidden surfaces=", skin.get_surface_count(), " shaded=", skin.has_meta("shaded"))
		hideShade(state)
		return
	var host:Node = torso.get_viewport()
	var node = state.get("shade_node")
	if(node == null || !is_instance_valid(node)):
		node = MeshInstance.new()
		node.name = "BulgeShade" + str(torso.get_instance_id())
		host.add_child(node)
		state["shade_node"] = node
		freeWith(torso, node)
	var at:PoolVector3Array = posed["at"]
	var cam = host.get_camera()
	var toward:float = 1.0
	if(cam != null && at.size() > 0 && cam.global_transform.origin.z < at[0].z):
		toward = -1.0
	var z:float = -INF
	for v in at:
		z = max(z, v.z * toward)
	z = (z + SHADE_Z) * toward
	var key:Array = []
	var gpu:bool = true
	for sf in range(1, skin.get_surface_count()):
		var mat = skin.surface_get_material(sf)
		gpu = gpu && bool(mat.get_shader_param("gpu_bend"))
		key.append([mat.get_instance_id(), skin.surface_get_array_len(sf), skin.surface_get_array_index_len(sf)])
	if(bool(BENCH.get("shade_trace", false))):
		print("SHADETRACE ", Engine.get_idle_frames(), " ", torso.get_instance_id(), " reuse=", gpu && key == state.get("shade_key") && node.mesh != null, " key=", key)
	if(gpu && key == state.get("shade_key") && node.mesh != null):
		for sf in range(1, skin.get_surface_count()):
			var mat = skin.surface_get_material(sf)
			mat.set_shader_param("mirror", bool(pose["mirror"]))
			mat.set_shader_param("shade_z", z)
		node.visible = true
		return
	state["shade_key"] = null
	if(gpu):
		state["shade_key"] = key
	var m := ArrayMesh.new()
	for sf in range(1, skin.get_surface_count()):
		var a:Array = skin.surface_get_arrays(sf)
		var mat = skin.surface_get_material(sf)
		if(bool(mat.get_shader_param("gpu_bend"))):
			mat.set_shader_param("mirror", bool(pose["mirror"]))
			mat.set_shader_param("shade_z", z)
		else:
			var verts:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
			for i in range(verts.size()):
				var w:Vector2 = BodyPose.world_of(pose, Vector2(verts[i].x, verts[i].y))
				verts[i] = Vector3(w.x, w.y, z)
			a[Mesh.ARRAY_VERTEX] = verts
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
		m.surface_set_material(sf - 1, mat)
	m.custom_aabb = BodyDeform.SHADE_AABB
	node.mesh = m
	node.global_transform = Transform.IDENTITY
	node.visible = true

const THROUGH := {"ease": 20.0, "z": 0.01, "hold": 0.4, "turn": 3.0, "settle": 20.0, "first": 2.0, "least": 1.0, "long": 2.0, "over": 0.05, "faint": 0.6, "most": 135.0, "neck": 0.33, "neck_most": 12.0, "pinch": 0.5, "swell": 0.2, "reach": 1.5, "width": 1.0}
static func drawThrough(torso, state:Dictionary, skin:ArrayMesh, pose:Dictionary, carries:Array, skel:Skeleton, opts:Dictionary, doll = null, posed:Dictionary = {}) -> void:
	var now:float = float(opts.get("now", 0.0))
	var head:float = float(opts.get("through_head", 0.0))
	var squeeze:float = clamp(float(opts.get("through_squeeze", 0.0)), 0.0, 1.0)
	var node = state.get("through_node")
	var infos:Array = []
	if(skin.has_meta("infos")):
		infos = skin.get_meta("infos")
	var eased:Dictionary = state.get("through_out", {})
	var was:float = float(state.get("through_now", now))
	state["through_now"] = now
	var m := ArrayMesh.new()
	var seen:Dictionary = {}
	var headWant:float = 0.0
	var headSet:bool = false
	var lens:Dictionary = state.get("through_len", {})
	state["through_len"] = lens
	var ways:Dictionary = state.get("through_ways", {})
	state["through_ways"] = ways
	var longs:Dictionary = state.get("through_long", {})
	state["through_long"] = longs
	var torsoZ = null
	var faceZ = null
	var headZ = null
	for inf in infos:
		if(!inf.has("through") || int(inf["through"]["pen"]) >= carries.size() || carries[int(inf["through"]["pen"])]["helper"] == null):
			continue
		var t:Dictionary = inf["through"]
		var c:Dictionary = carries[int(t["pen"])]
		var r:float = widestOf(c)
		var inside:float = float(t["inside"])
		var length:float = inside - float(t["out"])
		if(t.has("push")):
			inside = (inf.get("tip0", inf["tip"]) - inf["base"]).dot(inf["dir"]) + float(t["push"])
			length += inside - float(t["inside"])
		var action:String = str(opts.get("action", ""))
		if(lens.has(c["key"]) && (lens[c["key"]].size() < 4 || str(lens[c["key"]][3]) != action || now < float(lens[c["key"]][1]))):
			var _erased:bool = lens.erase(c["key"])
			var _was:bool = longs.erase(c["key"])
		if(!lens.has(c["key"])):
			lens[c["key"]] = [length, now, 1, action]
		elif(now - float(lens[c["key"]][1]) < float(THROUGH["first"])):
			var l:Array = lens[c["key"]]
			lens[c["key"]] = [float(l[0]) + (length - float(l[0])) / float(int(l[2]) + 1), l[1], int(l[2]) + 1, action]
		else:
			lens[c["key"]] = [lerp(float(lens[c["key"]][0]), length, 1.0 - exp(-clamp(now - was, 0.0, 0.1) / float(THROUGH["settle"]))), lens[c["key"]][1], 0, action]
		length = float(lens[c["key"]][0])
		var raw:float = inside - length
		if(raw >= float(THROUGH["least"]) * r):
			longs[c["key"]] = now
		if(now - float(longs.get(c["key"], -1000.0)) >= float(THROUGH["long"])):
			raw = min(raw, 0.0) - r
		if(raw > -r):
			state["through_near"] = now
		if(!headSet):
			headSet = true
			state["head_seen"] = now
			state["head_want"] = float(state.get("head_turn", 0.0)) + t["mouth"][1].angle_to(t["neck_way"])
			if(BENCH.has("through_trace")):
				BENCH["through_gap"] = rad2deg(abs(t["mouth"][1].angle_to(t["neck_way"])))
				BENCH["through_side"] = t["neck"].distance_to(t["mouth"][0]) / r

		var out:float = move_toward(float(eased.get(c["key"], 0.0)), max(raw, 0.0), float(THROUGH["ease"]) * r * clamp(now - was, 0.0, 0.1))
		eased[c["key"]] = out
		seen[c["key"]] = true
		var shade = null
		if(t.get("shade_mat") != null):
			if(torsoZ == null):
				torsoZ = torsoDepth(torso, posed)
			shade = throughShade(state, c, t, torsoZ)
		if(BENCH.has("through_trace") && !BENCH.has("through_push")):
			BENCH["through_push"] = float(t.get("push", -999.0)) / r
			var tube:Array = t["tube"]
			var turning:float = 0.0
			for q in range(1, tube.size() - 1):
				if((tube[q] - tube[q - 1]).length() > 0.000001 && (tube[q + 1] - tube[q]).length() > 0.000001):
					turning += abs(rad2deg((tube[q] - tube[q - 1]).angle_to(tube[q + 1] - tube[q])))
			BENCH["through_turning"] = turning
			if(skin.has_meta("polys")):
				var near:float = INF
				for q in skin.get_meta("polys")["target"]:
					near = min(near, Vector2(q.x, q.y).distance_to(t["mouth"][0]))
				BENCH["through_reach"] = near / r
			BENCH["through_shade"] = 0.0
			if(shade != null):
				BENCH["through_shade"] = (min(float(t["inside"]), float(t["len"])) - float(t["from"])) / r
		if(shade != null):
			if(headZ == null):
				headZ = Repose.world(skel, "Head").origin.z
			var sa:Array = alongTube(t, inf, float(t["from"]), pose,
				headZ + float(THROUGH["over"]) * towardCamera(torso, headZ))
			if(!sa.empty()):
				m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, sa)
				m.surface_set_material(m.get_surface_count() - 1, shade)
		if(out <= 0.0):
			continue
		var base:Vector2 = inf["base"]
		var dir:Vector2 = inf["dir"]
		var s0:float = (inf.get("tip0", inf["tip"]) - base).dot(dir) - out
		var from:Vector2 = base + dir * s0
		var mouth:Vector2 = t["mouth"][0]
		var way:float = t["way"].angle()
		if(ways.has(c["key"])):
			var last:float = float(ways[c["key"]])
			way = last + clamp(wrapf(way - last, -PI, PI), -float(THROUGH["turn"]) * clamp(now - was, 0.0, 0.1), float(THROUGH["turn"]) * clamp(now - was, 0.0, 0.1))
		ways[c["key"]] = way
		if(BENCH.has("through_trace") && !BENCH.has("through_way")):
			BENCH["through_way"] = rad2deg(way)
		var turn:float = dir.angle_to(Vector2(cos(way), sin(way)))
		var a:Array = t["mesh"].surface_get_arrays(0)
		var v:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
		var xp:Transform = t["xp"]
		if(faceZ == null):
			faceZ = faceDepth(torso, skel, doll)
			headZ = Repose.world(skel, "Head").origin.z
		var z:float = faceZ
		if(BENCH.has("through_trace")):
			BENCH["through_depth"] = (z - headZ) * towardCamera(torso, headZ)
		var lips:float = 0.0
		for i in range(v.size()):
			var q:Vector3 = xp.xform(v[i])
			var p := Vector2(q.x, q.y)
			var along:float = (p - base).dot(dir)
			if(along < s0):
				p -= dir * (along - s0)
				along = s0
			var share:float = float(THROUGH["width"])
			if(squeeze > 0.0):
				share *= squeezeAt((along - s0) / r, squeeze)
			if(share != 1.0):
				var mid:Vector2 = base + dir * along
				p = mid + (p - mid) * share
			if(along - s0 > 0.0 && along - s0 <= 0.2 * r):
				lips = max(lips, abs((p - base).cross(dir)))
			var w:Vector2 = BodyPose.world_of(pose, mouth + (p - from).rotated(turn))
			v[i] = Vector3(w.x, w.y, z)
		a[Mesh.ARRAY_VERTEX] = v
		if(BENCH.has("through_trace")):
			var far:float = 0.0
			var mw:Vector2 = BodyPose.world_of(pose, mouth)
			for q in v:
				far = max(far, Vector2(q.x, q.y).distance_to(mw))
			var drawn:Array = BENCH.get("through_drawn", [])
			drawn.append([out / r, far / r, lips / r, (inf.get("tip0", inf["tip"]) - inf["tip"]).dot(dir) / r])
			BENCH["through_drawn"] = drawn
		a[Mesh.ARRAY_BONES] = null
		a[Mesh.ARRAY_WEIGHTS] = null
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
		m.surface_set_material(m.get_surface_count() - 1, throughMaterial(state, c))
	for key in eased.keys():
		if(!seen.has(key)):
			eased.erase(key)
			ways.erase(key)
	state["through_out"] = eased
	if(state.has("head_want") && now - float(state.get("head_seen", -1000.0)) < float(THROUGH["hold"])):
		var most:float = clamp(head, 0.0, 1.0) * deg2rad(float(THROUGH["most"]))
		headWant = clamp(float(state["head_want"]), -most, most)
	else:
		state.erase("head_want")
	state["head_turn"] = move_toward(float(state.get("head_turn", 0.0)), headWant, float(THROUGH["turn"]) * clamp(now - was, 0.0, 0.1))
	if(BENCH.has("through_trace")):
		BENCH["through_head"] = rad2deg(float(state["head_turn"]))
	if(doll != null):
		mouthOpen(state, doll, now - float(state.get("through_near", -1000.0)) < float(THROUGH["hold"]))
		if(BENCH.has("through_trace")):
			BENCH["through_mouth"] = float(doll.getFinalState("mouth") == "open")
	if(m.get_surface_count() == 0):
		if(node != null && is_instance_valid(node)):
			node.visible = false
		return
	if(node == null || !is_instance_valid(node)):
		node = MeshInstance.new()
		node.name = "BulgeThrough" + str(torso.get_instance_id())
		torso.get_viewport().add_child(node)
		state["through_node"] = node
		freeWith(torso, node)
	m.custom_aabb = BodyDeform.SHADE_AABB
	node.mesh = m
	node.global_transform = Transform.IDENTITY
	node.visible = true

static func alongTube(t:Dictionary, inf:Dictionary, lo:float, pose:Dictionary, z:float) -> Array:
	var tube:Array = t["tube"]
	var hi:float = min(float(t["inside"]), float(t["len"]))
	lo = max(lo, 0.0)
	if(hi <= lo):
		return []
	var cum:Array = BodyDeform._cumulative_open(tube)
	var base:Vector2 = inf["base"]
	var dir:Vector2 = inf["dir"]
	var entry:float = (inf["entry_pt"] - base).dot(dir)
	var a:Array = t["mesh"].surface_get_arrays(0)
	var v:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
	var uv2 := PoolVector2Array()
	uv2.resize(v.size())
	var xp:Transform = t["xp"]
	for i in range(v.size()):
		var q:Vector3 = xp.xform(v[i])
		var p := Vector2(q.x, q.y)
		var along:float = (p - base).dot(dir)
		var s:float = clamp(along - entry, lo, hi)
		var at:Array = BodyDeform._at_arc(tube, cum, s)
		var w:Vector2 = BodyPose.world_of(pose, at[0] + (p - base - dir * along).rotated(dir.angle_to(at[1])))
		v[i] = Vector3(w.x, w.y, z)
		uv2[i] = Vector2(-0.0001, 0.0)
	a[Mesh.ARRAY_VERTEX] = v
	a[Mesh.ARRAY_TEX_UV2] = uv2
	a[Mesh.ARRAY_BONES] = null
	a[Mesh.ARRAY_WEIGHTS] = null
	return a

static func throughShade(state:Dictionary, c:Dictionary, t:Dictionary, torsoZ:float):
	var src = t.get("shade_mat")
	if(src == null):
		return null
	if(!state.has("through_shades")):
		state["through_shades"] = {}
	var mats:Dictionary = state["through_shades"]
	if(!mats.has(c["key"]) || mats[c["key"]][0] != src):
		var mat = src.duplicate()
		mat.set_shader_param("gpu_bend", false)
		mat.set_shader_param("cut_n", 0)
		mat.set_shader_param("shade_start", 0.0)
		mat.set_shader_param("shade_from", -1000.0)
		mats[c["key"]] = [src, mat]
	var mat = mats[c["key"]][1]
	for p in ["style", "outline", "alpha", "mask", "texel"]:
		mat.set_shader_param(p, src.get_shader_param(p))
	mat.set_shader_param("shade", float(src.get_shader_param("shade")) * float(THROUGH["faint"]))
	mat.set_shader_param("cock_z", torsoZ)
	return mat

static func torsoDepth(torso, posed:Dictionary) -> float:
	var at:PoolVector3Array = posed.get("at", PoolVector3Array())
	if(at.empty()):
		return 0.0
	var toward:float = towardCamera(torso, at[0].z)
	var z:float = -INF
	for v in at:
		z = max(z, v.z * toward)
	return (z + SHADE_Z) * toward

static func mouthOpen(state:Dictionary, doll, open:bool) -> void:
	if(!is_instance_valid(doll)):
		return
	if(bool(state.get("mouth_open", false)) == open && (!open || doll.getFinalState("mouth") == "open")):
		return
	state["mouth_open"] = open
	if(open):
		state["mouth_doll"] = doll
		state["mouth_was"] = doll.temporaryState.get("mouth")
		doll.setTemporaryState("mouth", "open")
		return
	var was = state.get("mouth_was")
	if(was != null):
		doll.setTemporaryState("mouth", was)
		return
	var _gone = doll.temporaryState.erase("mouth")
	var back = doll.getState("mouth")
	if(back == null):
		back = ""
	for slot in doll.parts:
		doll.parts[slot].setState("mouth", back)

static func turnHead(state:Dictionary, skel:Skeleton, a:float, mirror:bool) -> void:
	state["head_skel"] = skel
	var neck:float = clamp(a * float(THROUGH["neck"]), -deg2rad(float(THROUGH["neck_most"])), deg2rad(float(THROUGH["neck_most"])))
	turnNeck(state, skel, neck, mirror)
	turnBone(skel, "Head", a - neck, mirror)

static func turnBone(skel:Skeleton, boneName:String, a:float, mirror:bool) -> void:
	var i:int = skel.find_bone(boneName)
	if(i < 0):
		return
	if(mirror):
		a = -a
	skel.set_bone_custom_pose(i, Transform.IDENTITY)
	if(abs(a) < 0.0001):
		return
	var g:Transform = Repose.world(skel, boneName)
	var r := Basis(Vector3(0.0, 0.0, 1.0), a)
	var ts:Transform = skel.global_transform.affine_inverse() * Transform(r, g.origin - r.xform(g.origin)) * skel.global_transform
	var pr:Transform = skel.get_bone_rest(i)
	if(skel.get_bone_parent(i) >= 0):
		pr = skel.get_bone_global_pose(skel.get_bone_parent(i)) * pr
	skel.set_bone_custom_pose(i, pr.affine_inverse() * ts * pr)

static func turnNeck(state:Dictionary, skel:Skeleton, a:float, mirror:bool) -> void:
	var i:int = skel.find_bone("Neck")
	if(i < 0):
		return
	skel.set_bone_custom_pose(i, Transform.IDENTITY)
	var cur:Transform = skel.get_bone_global_pose(i)
	if(cur.is_equal_approx(skel.get_bone_global_pose_no_override(i))):
		state.erase("neck_ours")
		turnBone(skel, "Neck", a, mirror)
		return
	var base:Transform = cur
	var ours = state.get("neck_ours")
	if(ours != null && cur.is_equal_approx(ours[1])):
		base = ours[0]
	if(mirror):
		a = -a
	var g:Transform = skel.global_transform * base
	var r := Basis(Vector3(0.0, 0.0, 1.0), a)
	var mine:Transform = skel.global_transform.affine_inverse() * Transform(r, g.origin - r.xform(g.origin)) * g
	skel.set_bone_global_pose_override(i, mine, 1.0, true)
	state["neck_ours"] = [base, mine]

static func unturnHead(state:Dictionary) -> void:
	var skel = state.get("head_skel")
	state.erase("head_skel")
	state.erase("head_turn")
	state.erase("head_want")
	if(skel != null && is_instance_valid(skel) && skel.find_bone("Head") >= 0):
		skel.set_bone_custom_pose(skel.find_bone("Head"), Transform.IDENTITY)
	if(skel != null && is_instance_valid(skel) && skel.find_bone("Neck") >= 0):
		var ni:int = skel.find_bone("Neck")
		skel.set_bone_custom_pose(ni, Transform.IDENTITY)
		var ours = state.get("neck_ours")
		if(ours != null && skel.get_bone_global_pose(ni).is_equal_approx(ours[1])):
			skel.set_bone_global_pose_override(ni, ours[0], 1.0, true)
	state.erase("neck_ours")

static func hideThrough(state:Dictionary) -> void:
	var node = state.get("through_node")
	if(node != null && is_instance_valid(node)):
		node.visible = false

static func squeezeAt(x:float, squeeze:float) -> float:
	var reach:float = float(THROUGH["reach"])
	var lips:float = x / (0.5 * reach)
	var past:float = (x - reach) / (0.5 * reach)
	return 1.0 - squeeze * float(THROUGH["pinch"]) * exp(-lips * lips) + squeeze * float(THROUGH["swell"]) * exp(-past * past)

static func faceDepth(torso, skel:Skeleton, doll) -> float:
	var hz:float = Repose.world(skel, "Head").origin.z
	var toward:float = towardCamera(torso, hz)
	var face:float = hz
	if(doll != null && is_instance_valid(doll) && doll.parts.get(BodypartSlot.Head) != null):
		var todo:Array = [doll.parts[BodypartSlot.Head]]
		var found:bool = false
		while(!todo.empty()):
			var n = todo.pop_back()
			todo += n.get_children()
			if(n is MeshInstance && n.is_visible_in_tree()):
				var bb:AABB = n.get_transformed_aabb()
				var back:float = bb.position.z
				if(toward < 0.0):
					back = bb.end.z
				if(!found || (back - face) * toward < 0.0):
					face = back
				found = true
	return face - float(THROUGH["z"]) * toward

static func towardCamera(torso, z:float) -> float:
	var cam = torso.get_viewport().get_camera()
	if(cam != null && cam.global_transform.origin.z < z):
		return -1.0
	return 1.0

static func throughMaterial(state:Dictionary, c:Dictionary):
	if(!state.has("through_mats")):
		state["through_mats"] = {}
	var mats:Dictionary = state["through_mats"]
	var src = c["helper"].getShaftInfo()["meshes"][0].get_active_material(0)
	if(!mats.has(c["key"]) || mats[c["key"]][0] != src):
		var mat = src
		if(mat != null):
			mat = mat.duplicate()
			if(mat is ShaderMaterial):
				mat.set_shader_param("shaft_clip", 2.0)
		mats[c["key"]] = [src, mat]
	return mats[c["key"]][1]

static func freeWith(torso, node:Node) -> void:
	if(!torso.is_connected("tree_exiting", node, "queue_free")):
		var _c = torso.connect("tree_exiting", node, "queue_free", [], Object.CONNECT_ONESHOT)

static func hideShade(state:Dictionary) -> void:
	var node = state.get("shade_node")
	if(node != null && is_instance_valid(node)):
		node.visible = false

static func unclip(state:Dictionary) -> void:
	for helper in state["clips"]:
		unclipOne(helper)
	state["clips"] = []

static func unclipOne(helper) -> void:
	if(helper != null && is_instance_valid(helper)):
		helper.clearBulgeState()
		helper.restoreShaftTaper()

static func fail(torso, why:String) -> Dictionary:
	restore(torso)
	return {"hit": false, "why": why}

static func shaftShapeOf(penis) -> Dictionary:
	var mesh:Mesh = penis.mesh
	if(!mesh.has_meta(META_SHAPE)):
		mesh.set_meta(META_SHAPE, {})
	var shapes:Dictionary = mesh.get_meta(META_SHAPE)
	var tex = outlineTexture(penis)
	if(tex == null):
		return {}
	var key:int = tex.get_instance_id()
	if(!shapes.has(key)):
		shapes[key] = BodyDeform.shape(mesh, tex)
	return shapes[key]

static func shapeReady(penis) -> bool:
	var tex = outlineTexture(penis)
	return tex == null || (penis.mesh.has_meta(META_SHAPE) && penis.mesh.get_meta(META_SHAPE).has(tex.get_instance_id()))

static func cockState(shaftHelper) -> String:
	if(shaftHelper.doll == null || !shaftHelper.doll.has_method("getFinalState")):
		return ""
	var v = shaftHelper.doll.getFinalState("cock")
	if(v == null):
		return ""
	return str(v)

static func outlineTexture(meshInstance):
	return BulgeUtils.getAlbedoTexture(meshInstance)

static func weightedOf(skin:ArrayMesh, orig:Mesh) -> ArrayMesh:
	if(skin.has_meta("weighted")):
		return skin.get_meta("weighted")
	var a:Array = skin.surface_get_arrays(0)
	if(a[Mesh.ARRAY_BONES] != null && a[Mesh.ARRAY_BONES].size() == a[Mesh.ARRAY_VERTEX].size() * 4):
		skin.set_meta("weighted", skin)
		return skin
	var lookup:Dictionary = weightLookupOf(orig)
	var verts:PoolVector3Array = a[Mesh.ARRAY_VERTEX]
	var srcBones = lookup["bones"]
	var srcWeights = lookup["weights"]
	var bones := PoolIntArray()
	var weights := PoolRealArray()
	bones.resize(verts.size() * 4)
	weights.resize(verts.size() * 4)
	for i in range(verts.size()):
		var v:int = nearestVertex(lookup, Vector2(verts[i].x, verts[i].y))
		for j in range(4):
			bones[i * 4 + j] = int(srcBones[v * 4 + j])
			weights[i * 4 + j] = float(srcWeights[v * 4 + j])
	a[Mesh.ARRAY_BONES] = bones
	a[Mesh.ARRAY_WEIGHTS] = weights
	var out := ArrayMesh.new()
	out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	skin.set_meta("weighted", out)
	return out

static func weightLookupOf(orig:Mesh) -> Dictionary:
	if(orig.has_meta(META_WEIGHTS)):
		return orig.get_meta(META_WEIGHTS)
	var a:Array = orig.surface_get_arrays(0)
	var lookup:Dictionary = {"verts": a[Mesh.ARRAY_VERTEX], "bones": a[Mesh.ARRAY_BONES], "weights": a[Mesh.ARRAY_WEIGHTS],
		"box": orig.get_aabb()}
	orig.set_meta(META_WEIGHTS, lookup)
	return lookup

static func nearestVertex(lookup:Dictionary, p:Vector2) -> int:
	if(!lookup.has("near")):
		nearGridOf(lookup)
	var q:Vector2 = (p - lookup["origin"]) / float(lookup["cell"])
	var gx:int = int(clamp(floor(q.x), 0, int(lookup["nx"]) - 1))
	var gy:int = int(clamp(floor(q.y), 0, int(lookup["ny"]) - 1))
	return int(lookup["near"][gy * int(lookup["nx"]) + gx])

static func nearGridOf(lookup:Dictionary) -> void:
	var verts:PoolVector3Array = lookup["verts"]
	var box:AABB = lookup["box"]
	var cell:float = max(box.size.x, box.size.y) / float(WEIGHT_CELLS)
	var nx:int = int(ceil(box.size.x / cell)) + 1
	var ny:int = int(ceil(box.size.y / cell)) + 1
	var near := PoolIntArray()
	near.resize(nx * ny)
	for gy in range(ny):
		for gx in range(nx):
			var p := Vector2(box.position.x + (gx + 0.5) * cell, box.position.y + (gy + 0.5) * cell)
			var best:int = 0
			var bestD:float = INF
			for i in range(verts.size()):
				var d:float = p.distance_squared_to(Vector2(verts[i].x, verts[i].y))
				if(d < bestD):
					bestD = d
					best = i
			near[gy * nx + gx] = best
	lookup["origin"] = Vector2(box.position.x, box.position.y)
	lookup["cell"] = cell
	lookup["nx"] = nx
	lookup["ny"] = ny
	lookup["near"] = near

static func posedOf(torso, orig:Mesh, skel:Skeleton) -> Dictionary:
	var skin = torso.get("skin")
	if(skin == null):
		return {}
	var mats:Array = []
	for bind in range(skin.get_bind_count()):
		var bone:int = skin.get_bind_bone(bind)
		if(bone < 0):
			bone = skel.find_bone(skin.get_bind_name(bind))
		var m:Transform = Transform.IDENTITY
		if(bone >= 0):
			m = skel.global_transform * skel.get_bone_global_pose(bone) * skin.get_bind_pose(bind)
		mats.append(m)
	var lookup:Dictionary = weightLookupOf(orig)
	var verts:PoolVector3Array = lookup["verts"]
	var bones = lookup["bones"]
	var weights = lookup["weights"]
	var at:PoolVector3Array = BodyPose.skinned(verts, bones, weights, mats)
	return {"mats": mats, "at": at, "bones": bones, "weights": weights}

static func det2(b:Basis) -> float:
	return b.x.x * b.y.y - b.x.y * b.y.x

static func skinningAt(posed:Dictionary, p:Vector3) -> Transform:
	var at:PoolVector3Array = posed["at"]
	var best:int = 0
	var bestD:float = INF
	var p2 := Vector2(p.x, p.y)
	for i in range(at.size()):
		var d:float = p2.distance_squared_to(Vector2(at[i].x, at[i].y))
		if(d < bestD):
			bestD = d
			best = i
	return BodyPose._blend(posed["mats"], posed["bones"], posed["weights"], best)

static func similarity(a:Vector2, b:Vector2, a2:Vector2, b2:Vector2, mirrored:bool) -> Transform:
	var d:Vector2 = b - a
	if(mirrored):
		d.y = -d.y
	var d2:Vector2 = b2 - a2
	var den:float = max(d.length_squared(), 0.0000001)
	var ar:float = (d2.x * d.x + d2.y * d.y) / den
	var ai:float = (d2.y * d.x - d2.x * d.y) / den
	var xcol := Vector3(ar, ai, 0.0)
	var ycol := Vector3(-ai, ar, 0.0)
	if(mirrored):
		ycol = -ycol
	var s:float = sqrt(ar * ar + ai * ai)
	var basis := Basis(xcol, ycol, Vector3(0.0, 0.0, s))
	var o3:Vector3 = basis.xform(Vector3(a.x, a.y, 0.0))
	return Transform(basis, Vector3(a2.x - o3.x, a2.y - o3.y, 0.0))
