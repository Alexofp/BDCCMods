extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument


static func extract(mesh: Mesh, xf: Transform) -> Dictionary:
	var arr = mesh.surface_get_arrays(0)
	var v = arr[Mesh.ARRAY_VERTEX]
	var n = arr[Mesh.ARRAY_NORMAL]
	var uv = arr[Mesh.ARRAY_TEX_UV]
	var c = arr[Mesh.ARRAY_COLOR]
	var idx = arr[Mesh.ARRAY_INDEX]
	var count = v.size()
	var identity = xf == Transform.IDENTITY
	var ov = v
	if not identity:
		ov = PoolVector3Array()
		ov.resize(count)
		for k in count:
			ov[k] = xf.xform(v[k])
	var nb = xf.basis.inverse().transposed()
	var on = PoolVector3Array()
	on.resize(count)
	if n != null and n.size() == count:
		for k in count:
			on[k] = nb.xform(n[k]).normalized()
	else:
		for k in count:
			on[k] = Vector3.BACK
	var ouv = uv
	if uv == null or uv.size() != count:
		ouv = PoolVector2Array()
		ouv.resize(count)
		for k in count:
			ouv[k] = Vector2.ZERO
	var oc = c
	if c == null or c.size() != count:
		oc = PoolColorArray()
		oc.resize(count)
		for k in count:
			oc[k] = Color.white
	var oi = PoolIntArray()
	if idx != null and idx.size() > 0:
		oi = idx
	else:
		for k in count:
			oi.append(k)
	return {"v": ov, "n": on, "uv": ouv, "c": oc, "i": oi}


static func _pack(d: Dictionary) -> Array:
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = d["v"]
	arrays[Mesh.ARRAY_NORMAL] = d["n"]
	arrays[Mesh.ARRAY_TEX_UV] = d["uv"]
	arrays[Mesh.ARRAY_COLOR] = d["c"]
	if d.has("uv2"):
		arrays[Mesh.ARRAY_TEX_UV2] = d["uv2"]
	arrays[Mesh.ARRAY_INDEX] = d["i"]
	return arrays
