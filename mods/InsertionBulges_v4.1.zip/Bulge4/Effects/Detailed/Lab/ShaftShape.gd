extends Reference
# warning-ignore-all:unsafe_cast
# warning-ignore-all:void_assignment
# warning-ignore-all:standalone_ternary
# warning-ignore-all:incompatible_ternary
# warning-ignore-all:return_value_discarded
# warning-ignore-all:narrowing_conversion
# warning-ignore-all:standalone_expression
# warning-ignore-all:unreachable_code
# warning-ignore-all:unused_class_variable
# warning-ignore-all:unassigned_variable_op_assign
# warning-ignore-all:unassigned_variable
# warning-ignore-all:shadowed_variable
# warning-ignore-all:unused_variable
# warning-ignore-all:unused_argument

static func fitOf(mesh:Mesh):
	if(mesh == null || mesh.get_surface_count() <= 0):
		return null
	var arrays:Array = mesh.surface_get_arrays(0)
	if(arrays.size() <= Mesh.ARRAY_TEX_UV):
		return null
	var verts = arrays[Mesh.ARRAY_VERTEX]
	var uvs = arrays[Mesh.ARRAY_TEX_UV]
	if(verts == null || uvs == null || verts.size() < 3 || uvs.size() != verts.size()):
		return null
	var sxx:float = 0.0
	var sxy:float = 0.0
	var sx:float = 0.0
	var syy:float = 0.0
	var sy:float = 0.0
	var n:float = 0.0
	var sxu:float = 0.0
	var syu:float = 0.0
	var su:float = 0.0
	var sxv:float = 0.0
	var syv:float = 0.0
	var sv:float = 0.0
	var restMin := Vector2(99999.0, 99999.0)
	var restMax := Vector2(-99999.0, -99999.0)
	for i in range(verts.size()):
		var vert:Vector3 = verts[i]
		var uv:Vector2 = uvs[i]
		sxx += vert.x * vert.x
		sxy += vert.x * vert.y
		sx += vert.x
		syy += vert.y * vert.y
		sy += vert.y
		n += 1.0
		sxu += vert.x * uv.x
		syu += vert.y * uv.x
		su += uv.x
		sxv += vert.x * uv.y
		syv += vert.y * uv.y
		sv += uv.y
		restMin.x = min(restMin.x, vert.x)
		restMin.y = min(restMin.y, vert.y)
		restMax.x = max(restMax.x, vert.x)
		restMax.y = max(restMax.y, vert.y)
	var A := [[sxx, sxy, sx], [sxy, syy, sy], [sx, sy, n]]
	var bu := [sxu, syu, su]
	var bv := [sxv, syv, sv]
	var mu = solve3(A, bu)
	var mv = solve3(A, bv)
	if(mu == null || mv == null):
		return null
	return {
		"u": Vector3(mu[0], mu[1], mu[2]),
		"v": Vector3(mv[0], mv[1], mv[2]),
		"restMin": restMin,
		"restMax": restMax,
	}


static func restToUV(fit:Dictionary, restPos:Vector2) -> Vector2:
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	return Vector2(
		rowU.x * restPos.x + rowU.y * restPos.y + rowU.z,
		rowV.x * restPos.x + rowV.y * restPos.y + rowV.z)


static func solve3(A:Array, b:Array):
	var m := [
		[A[0][0], A[0][1], A[0][2], b[0]],
		[A[1][0], A[1][1], A[1][2], b[1]],
		[A[2][0], A[2][1], A[2][2], b[2]],
	]
	for col in range(3):
		var pivot := col
		for r in range(col + 1, 3):
			if(abs(m[r][col]) > abs(m[pivot][col])):
				pivot = r
		var swap = m[col]
		m[col] = m[pivot]
		m[pivot] = swap
		var diag:float = m[col][col]
		if(abs(diag) < 0.000000001):
			return null
		for c in range(col, 4):
			m[col][c] /= diag
		for r in range(3):
			if(r == col):
				continue
			var factor:float = m[r][col]
			for c in range(col, 4):
				m[r][c] -= factor * m[col][c]
	return [m[0][3], m[1][3], m[2][3]]


const SAMPLES_PER_COLUMN:int = 256
const ALPHA_CUT = 90
static func columnExtent(data:PoolByteArray, fit:Dictionary, x:float, minY:float, maxY:float, width:int, height:int) -> Vector2:
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	var dy = (maxY - minY) / float(SAMPLES_PER_COLUMN)
	var u0 = rowU.x * x + rowU.y * (minY + 0.5 * dy) + rowU.z
	var v0 = rowV.x * x + rowV.y * (minY + 0.5 * dy) + rowV.z
	var du = rowU.y * dy
	var dv = rowV.y * dy
	var lowest = -1
	for sample in range(SAMPLES_PER_COLUMN):
		var u = u0 + du * sample
		var v = v0 + dv * sample
		if u >= 0.0 and u <= 1.0 and v >= 0.0 and v <= 1.0:
			if data[(int(min(v * height, height - 1)) * width + int(min(u * width, width - 1))) * 4 + 3] >= ALPHA_CUT:
				lowest = sample
				break
	if lowest < 0:
		return Vector2.ZERO
	var highest = lowest
	for sample in range(SAMPLES_PER_COLUMN - 1, lowest, -1):
		var u = u0 + du * sample
		var v = v0 + dv * sample
		if u >= 0.0 and u <= 1.0 and v >= 0.0 and v <= 1.0:
			if data[(int(min(v * height, height - 1)) * width + int(min(u * width, width - 1))) * 4 + 3] >= ALPHA_CUT:
				highest = sample
				break
	return Vector2(lerp(minY, maxY, lowest / float(SAMPLES_PER_COLUMN)), lerp(minY, maxY, (highest + 1.0) / float(SAMPLES_PER_COLUMN)))


static func alphaData(image:Image) -> PoolByteArray:
	if image.get_format() != Image.FORMAT_RGBA8:
		image = image.duplicate()
		if image.is_compressed():
			image.decompress()
		image.convert(Image.FORMAT_RGBA8)
	return image.get_data()


const CLIFF_COLUMNS:int = 96
const CLIFF_LIMIT:float = 0.45
const CLIFF_RATIO:float = 1.35
const SKIP_BASE:float = 0.3
static func findCliff(data:PoolByteArray, fit:Dictionary, drawnBase:float, drawnTip:float, minY:float, maxY:float, width:int, height:int) -> float:
	var previous:float = -1.0
	var bestDrop:float = 0.0
	var bestT:float = -1.0
	for column in range(CLIFF_COLUMNS):
		var t:float = CLIFF_LIMIT * (column + 0.5) / float(CLIFF_COLUMNS)
		var extent:Vector2 = columnExtent(data, fit, lerp(drawnBase, drawnTip, t), minY, maxY, width, height)
		var here:float = max(extent.y - extent.x, 0.0)
		if(here <= 0.0):
			previous = -1.0
			continue
		if(previous > 0.0 && previous - here > bestDrop && previous / here >= CLIFF_RATIO):
			bestDrop = previous - here
			bestT = t
		previous = here
	if(bestT < 0.0):
		return SKIP_BASE
	return bestT


const DEFAULT_BINS:int = 64
const SCAN_COLUMNS:int = 48
static func measure(mesh:Mesh, texture:Texture, bins:int = DEFAULT_BINS) -> Dictionary:
	var fit = fitOf(mesh)
	if(fit == null || texture == null):
		return {}
	var image:Image = texture.get_data()
	if(image == null || image.is_empty()):
		return {}
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var width:int = image.get_width()
	var height:int = image.get_height()
	var data:PoolByteArray = alphaData(image)
	var drawnBase:float = restMax.x
	var drawnTip:float = restMin.x
	var first:int = -1
	for column in range(SCAN_COLUMNS):
		var x:float = lerp(restMax.x, restMin.x, (column + 0.5) / float(SCAN_COLUMNS))
		var extent0:Vector2 = columnExtent(data, fit, x, restMin.y, restMax.y, width, height)
		if(extent0.y - extent0.x > 0.0):
			drawnBase = x
			drawnTip = x
			first = column
			break
	if(first < 0):
		return {}
	for column in range(SCAN_COLUMNS - 1, first, -1):
		var x1:float = lerp(restMax.x, restMin.x, (column + 0.5) / float(SCAN_COLUMNS))
		var extent1:Vector2 = columnExtent(data, fit, x1, restMin.y, restMax.y, width, height)
		if(extent1.y - extent1.x > 0.0):
			drawnTip = x1
			break
	var skip:float = findCliff(data, fit, drawnBase, drawnTip, restMin.y, restMax.y, width, height)
	var extents:Array = []
	var total:float = 0.0
	var drawn:int = 0
	for bin in range(bins):
		var t:float = skip + (1.0 - skip) * (bin + 0.5) / float(bins)
		var x2:float = lerp(drawnBase, drawnTip, t)
		var extent:Vector2 = columnExtent(data, fit, x2, restMin.y, restMax.y, width, height)
		extents.append(extent)
		total += max(extent.y - extent.x, 0.0) * 0.5
		if(extent.y - extent.x > 0.0):
			drawn += 1
	var mean:float = total / float(max(drawn, 1))
	if(mean <= 0.0001):
		return {}
	return {
		"girth": mean,
		"span": Vector2(drawnBase, drawnTip),
		"skip": skip,
		"extents": extents,
		"fit": fit,
		"data": data,
		"width": width,
		"height": height,
	}
