extends Reference
const FieldMath := preload("res://Bulge4/Effects/Classic/Field.gd")
const BAKE_SHADER := preload("res://Bulge4/Effects/Medium/Bake.shader")
const SLOT_META := 4
const SLOT_LIP := 5
const SLOT_MORE := 6
const SLOT_FIRST_EXTRA := 7
const SLOT_INLINE_SAMPLES := 7
static func texelsFor(slots:Array) -> int:
	var most:int = SLOT_INLINE_SAMPLES
	for slot in slots:
		most = int(max(most, slot["shape"].size()))
	var past:int = most - SLOT_INLINE_SAMPLES
	return SLOT_FIRST_EXTRA + int(ceil(float(max(past, 0)) / 4.0))
const SLOT_FORMAT := Image.FORMAT_RGBAF
static func slotImage(slots:Array) -> Image:
	var width:int = texelsFor(slots)
	var img := Image.new()
	img.create(width, int(max(slots.size(), 1)), false, SLOT_FORMAT)
	img.lock()
	for s in range(slots.size()):
		var slot:Dictionary = slots[s]
		var centre:Vector2 = slot["centre"]
		var front:Vector2 = slot["front"]
		var shape:Array = slot["shape"]
		img.set_pixel(0, s, Color(centre.x, centre.y, front.x, front.y))
		img.set_pixel(1, s, Color(float(slot["spread"]), float(slot["amplitude"]),
			float(slot["shade"]), float(slot["column_half"])))
		img.set_pixel(2, s, Color(sampleOf(shape, 0), sampleOf(shape, 1), sampleOf(shape, 2),
			float(slot["axis_depth"])))
		img.set_pixel(3, s, Color(sampleOf(shape, 3), sampleOf(shape, 4), sampleOf(shape, 5),
			sampleOf(shape, 6)))
		var knots:int = shape.size()
		img.set_pixel(SLOT_META, s, Color(float(knots), float(slot.get("lip", 0.0)),
			float(slot.get("lip_reach", 0.0)), float(slot.get("lip_motion", 0.0))))
		var lipAt:Vector2 = slot.get("lip_at", centre)
		var lipToward:Vector2 = slot.get("lip_toward", centre)
		img.set_pixel(SLOT_LIP, s, Color(lipAt.x, lipAt.y, lipToward.x, lipToward.y))
		img.set_pixel(SLOT_MORE, s, Color(float(slot.get("radial_on", 1.0)), float(slot.get("lip_stroke", 0.0)),
			float(slot.get("plateau", FieldMath.bandPlateau())), 0.0))
		for at in range(SLOT_INLINE_SAMPLES, knots, 4):
			img.set_pixel(SLOT_FIRST_EXTRA + int((at - SLOT_INLINE_SAMPLES) / 4), s, Color(sampleOf(shape, at),
				sampleOf(shape, at + 1), sampleOf(shape, at + 2), sampleOf(shape, at + 3)))
	img.unlock()
	return img
static func sampleOf(shape:Array, at:int) -> float:
	if(at >= shape.size()):
		return 1.0
	return float(shape[at])
static func orientedShape(shape, uvA:Vector2, uvB:Vector2, uvBandEnd:Vector2,
		aspect:Vector2) -> Array:
	if(typeof(shape) != TYPE_ARRAY || shape.size() < 2):
		return []
	var here:Vector2 = uvA * aspect
	var outward:Vector2 = uvB * aspect - here
	var across:Vector2 = Vector2(-outward.y, outward.x)
	var towardsTip:Vector2 = uvBandEnd * aspect - here
	var out:Array = shape.duplicate()
	if(towardsTip.dot(across) < 0.0):
		out.invert()
	return out
static func materialFor(slots:Array, bulge_aspect:Vector2 = Vector2(1, 1)) -> ShaderMaterial:
	var mat := ShaderMaterial.new()
	mat.shader = BAKE_SHADER
	mat.set_shader_param("bulge_lip_soft", FieldMath.LIP_SOFT)
	mat.set_shader_param("bulge_ramp_slope_peak", FieldMath.RAMP_SLOPE_PEAK)
	update(mat, slots, bulge_aspect)
	return mat
static func update(mat:ShaderMaterial, slots:Array, bulge_aspect:Vector2 = Vector2(1, 1)) -> void:
	var image:Image = slotImage(slots)
	var slotTex = mat.get_shader_param("bulge_slots")
	if(slotTex is ImageTexture && slotTex.get_width() == image.get_width() && slotTex.get_height() == image.get_height()):
		slotTex.set_data(image)
	else:
		slotTex = ImageTexture.new()
		slotTex.create_from_image(image, 0)
		mat.set_shader_param("bulge_slots", slotTex)
	mat.set_shader_param("bulge_slot_count", slots.size())
	mat.set_shader_param("bulge_aspect", bulge_aspect)
	mat.set_shader_param("bulge_shape_fidelity", FieldMath.fidelity())
	mat.set_shader_param("bulge_rim_shape", FieldMath.rim())
	mat.set_shader_param("bulge_push_radial", FieldMath.radial())
	mat.set_shader_param("bulge_union_overlap", FieldMath.unionOverlap())
	mat.set_shader_param("bulge_warp_mode", FieldMath.warpIndex())
	if(FieldMath.warpMode() == FieldMath.WARP_FLOW):
		mat.set_shader_param("bulge_flow_steps", FieldMath.flowSteps(slots, bulge_aspect))
