extends Node
const Bake := preload("res://Bulge4/Effects/Medium/Bake.gd")
const SIDE := 256
var targets := {}
func textureFor(key:String, mesh, slots:Array, aspect:Vector2) -> ViewportTexture:
	if(!targets.has(key)):
		dropFreed()
		targets[key] = build(mesh)
	var entry:Dictionary = targets[key]
	var surface:ColorRect = entry["surface"]
	if(surface.material == null):
		surface.material = Bake.materialFor(slots, aspect)
	else:
		Bake.update(surface.material, slots, aspect)
	var viewport:Viewport = entry["viewport"]
	viewport.render_target_update_mode = Viewport.UPDATE_ONCE
	return viewport.get_texture()
func dropFreed() -> void:
	for key in targets.keys():
		var entry:Dictionary = targets[key]
		if(!is_instance_valid(entry["mesh"])):
			entry["viewport"].queue_free()
			targets.erase(key)
func build(mesh) -> Dictionary:
	var viewport := Viewport.new()
	viewport.usage = Viewport.USAGE_3D
	viewport.hdr = true
	viewport.transparent_bg = true
	viewport.size = Vector2(SIDE, SIDE)
	viewport.own_world = true
	var surface := ColorRect.new()
	surface.rect_size = viewport.size
	viewport.add_child(surface)
	add_child(viewport)
	return {"viewport": viewport, "surface": surface, "mesh": mesh}
