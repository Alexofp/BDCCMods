extends Reference
const SUBDIVIDE_LEVELS := 2
const META_SUBDIVIDED = "bdccBulge4SubdividedMesh"
const META_SUBDIVIDED_FROM = "bdccBulge4SubdividedFrom"

static func getSubdividedMesh(mesh:Mesh):
	if(mesh == null || mesh.has_meta(META_SUBDIVIDED_FROM)):
		return mesh
	if(mesh.has_meta(META_SUBDIVIDED)):
		var cached = mesh.get_meta(META_SUBDIVIDED)
		if(cached is Mesh):
			return cached
		return mesh
	if(mesh.get_surface_count() != 1 || (mesh is ArrayMesh && (mesh.get_blend_shape_count() > 0 \
			|| mesh.surface_get_primitive_type(0) != Mesh.PRIMITIVE_TRIANGLES))):
		return mesh
	var arrays:Array = mesh.surface_get_arrays(0)
	if(arrays[Mesh.ARRAY_INDEX] == null || arrays[Mesh.ARRAY_TEX_UV] == null):
		mesh.set_meta(META_SUBDIVIDED, false)
		return mesh
	for _level in range(SUBDIVIDE_LEVELS):
		arrays = subdivided(arrays)
	var built:ArrayMesh = ArrayMesh.new()
	built.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	built.custom_aabb = mesh.get_aabb()
	built.set_meta(META_SUBDIVIDED_FROM, weakref(mesh))
	mesh.set_meta(META_SUBDIVIDED, built)
	return built

static func subdivided(arrays:Array) -> Array:
	var verts:PoolVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var uvs:PoolVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var indices:PoolIntArray = arrays[Mesh.ARRAY_INDEX]
	var normals = arrays[Mesh.ARRAY_NORMAL]
	var tangents = arrays[Mesh.ARRAY_TANGENT]
	var bones = arrays[Mesh.ARRAY_BONES]
	var weights = arrays[Mesh.ARRAY_WEIGHTS]
	var colors = arrays[Mesh.ARRAY_COLOR]
	var hasColors:bool = colors != null && colors.size() == verts.size()
	var hasNormals:bool = normals != null && normals.size() == verts.size()
	var hasTangents:bool = tangents != null && tangents.size() == verts.size() * 4
	var hasBones:bool = bones != null && weights != null && bones.size() == verts.size() * 4 \
		&& weights.size() == verts.size() * 4
	var vertCount:int = verts.size()
	var room:int = vertCount + indices.size()
	var outVerts:PoolVector3Array = PoolVector3Array(verts)
	outVerts.resize(room)
	var outUVs:PoolVector2Array = PoolVector2Array(uvs)
	outUVs.resize(room)
	var outNormals = null
	var outColors = null
	if(hasColors):
		outColors = PoolColorArray(colors)
		outColors.resize(room)
	var outTangents = null
	var outBones = null
	var outWeights = null
	if(hasNormals):
		outNormals = PoolVector3Array(normals)
		outNormals.resize(room)
	if(hasTangents):
		outTangents = PoolRealArray(tangents)
		outTangents.resize(room * 4)
	if(hasBones):
		outBones = PoolIntArray(bones)
		outBones.resize(room * 4)
		outWeights = PoolRealArray(weights)
		outWeights.resize(room * 4)
	var outIndices:PoolIntArray = PoolIntArray()
	outIndices.resize(indices.size() * 4)
	var next:int = vertCount
	var write:int = 0
	var middles:Dictionary = {}
	var corner:Array = [0, 0, 0]
	var mid:Array = [0, 0, 0]
	for i in range(0, indices.size(), 3):
		corner[0] = indices[i]
		corner[1] = indices[i + 1]
		corner[2] = indices[i + 2]
		for k in range(3):
			var a:int = corner[k]
			var b:int = corner[(k + 1) % 3]
			var key:int = int(min(a, b)) * vertCount + int(max(a, b))
			if(!middles.has(key)):
				middles[key] = next
				outVerts[next] = (verts[a] + verts[b]) * 0.5
				outUVs[next] = (uvs[a] + uvs[b]) * 0.5
				if(hasNormals):
					outNormals[next] = (normals[a] + normals[b]).normalized()
				if(hasColors):
					outColors[next] = colors[a].linear_interpolate(colors[b], 0.5)
				if(hasTangents):
					for c in range(4):
						outTangents[next * 4 + c] = tangents[a * 4 + c]
				if(hasBones):
					var mixed:Dictionary = {}
					for end in [a, b]:
						for c in range(4):
							var bone:int = bones[end * 4 + c]
							mixed[bone] = float(mixed.get(bone, 0.0)) + weights[end * 4 + c] * 0.5
					var ranked:Array = []
					for bone in mixed:
						ranked.append([mixed[bone], bone])
					ranked.sort()
					ranked.invert()
					var total:float = 0.0
					for c in range(int(min(4, ranked.size()))):
						total += float(ranked[c][0])
					for c in range(4):
						if(c < ranked.size() && total > 0.0):
							outBones[next * 4 + c] = int(ranked[c][1])
							outWeights[next * 4 + c] = float(ranked[c][0]) / total
						else:
							outBones[next * 4 + c] = 0
							outWeights[next * 4 + c] = 0.0
				next += 1
			mid[k] = middles[key]
		for index in [corner[0], mid[0], mid[2], mid[0], corner[1], mid[1],
				mid[2], mid[1], corner[2], mid[0], mid[1], mid[2]]:
			outIndices[write] = index
			write += 1
	outVerts.resize(next)
	outUVs.resize(next)
	if(hasNormals):
		outNormals.resize(next)
	if(hasColors):
		outColors.resize(next)
	if(hasTangents):
		outTangents.resize(next * 4)
	if(hasBones):
		outBones.resize(next * 4)
		outWeights.resize(next * 4)
	var out:Array = []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = outVerts
	out[Mesh.ARRAY_TEX_UV] = outUVs
	out[Mesh.ARRAY_INDEX] = outIndices
	if(hasNormals):
		out[Mesh.ARRAY_NORMAL] = outNormals
	if(hasColors):
		out[Mesh.ARRAY_COLOR] = outColors
	if(hasTangents):
		out[Mesh.ARRAY_TANGENT] = outTangents
	if(hasBones):
		out[Mesh.ARRAY_BONES] = outBones
		out[Mesh.ARRAY_WEIGHTS] = outWeights
	return out

static func unsubdivided(mesh:Mesh):
	if(mesh != null && mesh.has_meta(META_SUBDIVIDED_FROM)):
		var source = mesh.get_meta(META_SUBDIVIDED_FROM).get_ref()
		if(source != null):
			return source
	return mesh
