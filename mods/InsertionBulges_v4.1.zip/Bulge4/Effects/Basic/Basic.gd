extends Reference
const Torso := preload("res://Bulge4/Doll/Torso.gd")
const Belly := preload("res://Bulge4/Effects/Medium/Belly.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const BELLY := 0
const THROAT := 1
const SLOT_OF := {"vagina": BELLY, "anus": BELLY, "mouth": THROAT}
const BELLY_KNOBS := {"extra": 1.0, "rest": 0.4}
const THROAT_KNOBS := {"spread": 0.8, "out": 0.5, "up": 0.3, "front_plane": -0.28, "tilt": 0.155, "rest": 0.0}
const STROKE := {"follow": 0.01}
const DEPTH := {"full": 0.65}
const REACH := 0.25
const THROAT_SLOT := 0
const META_STROKE := "bdccBulge4BasicStroke"
const META_STROKE_NOW := "bdccBulge4BasicStrokeNow"
const META_CLIPPED := "bdccBulge4BasicClipped"
const META_THROAT := "bdccBulge4BasicThroat"
const THROAT_PAR := "bulge_par0"

static func depthAmount(base:Vector3, tip:Vector3, inside:float) -> float:
	var length:float = base.distance_to(tip)
	if(length < 0.0001):
		return 0.0
	return smoothstep(0.0, length * float(DEPTH["full"]), inside)

static func insideOf(base:Vector3, tip:Vector3, entry:Vector3) -> float:
	var length:float = base.distance_to(tip)
	if(length < 0.0001):
		return 0.0
	return length - (entry - base).dot((tip - base) / length)

static func strokeAmount(stroke:Array, inside:float, dt:float = 1.0 / 60.0) -> float:
	var follow:float = 1.0 - pow(1.0 - float(STROKE["follow"]), dt * 60.0)
	stroke[0] = min(inside, lerp(float(stroke[0]), inside, follow))
	stroke[1] = max(inside, lerp(float(stroke[1]), inside, follow))
	var span:float = float(stroke[1]) - float(stroke[0])
	if(span < 0.01):
		return 1.0
	return (inside - float(stroke[0])) / span

static func run(stageScene, relations:Array, opts:Dictionary = {}) -> Array:
	var size:float = clamp(float(opts.get("size", 0.6)), 0.0, 1.0)
	var dolls:Array = stageScene.getDolls()
	var amounts:Dictionary = clip(stageScene, dolls, relations)
	var rows:Array = []
	for i in range(dolls.size()):
		var doll = dolls[i]
		var helper = Torso.helperOf(doll)
		if(helper == null):
			continue
		var id:String = "doll" + str(i)
		var on:Array = [0.0, 0.0]
		if(amounts.has(id)):
			on = amounts[id]
		var belly:float = float(on[BELLY]) * size
		var throat:float = float(on[THROAT]) * size
		if(belly > 0.0):
			Belly.push(doll, float(BELLY_KNOBS["extra"]) * belly)
		elif(doll.has_meta(Belly.META_GAME)):
			Belly.restore(doll)
		for torso in helper.getBulgeMeshesForZone(""):
			if(throat > 0.0 || torso.has_meta(META_THROAT)):
				writeThroat(torso, helper, throat)
		if(belly > 0.0 || throat > 0.0):
			rows.append({"doll": id, "belly": stepify(belly, 0.01), "throat": stepify(throat, 0.01)})
	return rows

static func writeThroat(torso, helper, scale:float) -> void:
	if(!Torso.prepare(torso)):
		return
	var material:ShaderMaterial = torso.fancyMaterial
	var slot:String = str(THROAT_SLOT)
	if(scale <= 0.0):
		material.set_shader_param(THROAT_PAR, Plane(0.0, 0.0, 0.0, 0.0))
		torso.remove_meta(META_THROAT)
		return
	if(torso.has_meta(META_THROAT)):
		var had:Plane = torso.get_meta(META_THROAT)
		material.set_shader_param(THROAT_PAR, Plane(had.x, had.y * scale, had.z, had.d))
		return
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return
	var neckBone:int = skeleton.find_bone("Neck")
	var headBone:int = skeleton.find_bone("Head")
	if(neckBone < 0 || headBone < 0):
		return
	var bottom:Vector3 = BulgeUtils.getBoneRestGlobal(skeleton, neckBone).origin
	var top:Vector3 = BulgeUtils.getBoneRestGlobal(skeleton, headBone).origin
	var neck:float = bottom.distance_to(top)
	var k:Dictionary = THROAT_KNOBS
	var up:float = neck * float(k["up"])
	var restA:Vector2 = Vector2(float(k["front_plane"]), (bottom.y + top.y) * 0.5 + up)
	var restB:Vector2 = restA + Vector2(-1.0, float(k["tilt"])).normalized() * REACH
	var uvA:Vector2 = BulgeUtils.restToUV(torso.uvFit, restA)
	var uvB:Vector2 = BulgeUtils.restToUV(torso.uvFit, restB)
	material.set_shader_param("bulge_seg" + slot, Plane(uvA.x, uvA.y, uvB.x, uvB.y))
	var par:Plane = Plane(neck * float(k["spread"]), neck * float(k["out"]), 0.0, up)
	material.set_shader_param(THROAT_PAR, Plane(par.x, par.y * scale, par.z, par.d))
	material.set_shader_param("bulge_shp" + slot, Plane(1.0, 1.0, 1.0, 1.0))
	material.set_shader_param("bulge_shp" + slot + "b", Plane(1.0, 1.0, 1.0, 1.0))
	material.set_shader_param("bulge_radial_on" + slot, 0.0)
	material.set_shader_param("bulge_shape_fidelity", 0.0)
	torso.set_meta(META_THROAT, par)

static func clip(stageScene, dolls:Array, relations:Array) -> Dictionary:
	var amounts:Dictionary = {}
	var strokes:Dictionary = {}
	var had:Dictionary = {}
	if(stageScene.has_meta(META_STROKE)):
		had = stageScene.get_meta(META_STROKE)
	var dt:float = 1.0 / 60.0
	if(stageScene.has_meta(Frame.META_NOW)):
		var now:float = float(stageScene.get_meta(Frame.META_NOW))
		if(stageScene.has_meta(META_STROKE_NOW)):
			dt = clamp(now - float(stageScene.get_meta(META_STROKE_NOW)), 0.0, 0.1)
		stageScene.set_meta(META_STROKE_NOW, now)
	var clipped:Array = []
	for r in relations:
		var shaftHelper = Torso.helperOf(Torso.dollAt(dolls, r["shaft"]))
		var holeHelper = Torso.helperOf(Torso.dollAt(dolls, r["hole_owner"]))
		if(shaftHelper == null || holeHelper == null || !SLOT_OF.has(str(r["hole"]))):
			continue
		var entry = holeHelper.getOrificeAnchor(str(r["hole"]))
		if(entry == null):
			continue
		shaftHelper.unTaperShaftBones()
		shaftHelper.applyShaftClip(entry)
		clipped.append(shaftHelper)
		var info = shaftHelper.getShaftInfo()
		if(typeof(info) != TYPE_DICTIONARY):
			continue
		var inside:float = insideOf(info["base"], info["tip"], entry)
		var key:String = str(r["shaft"]) + ">" + str(r["hole_owner"]) + "/" + str(r["hole"])
		var stroke:Array
		if(had.has(key)):
			stroke = had[key]
		else:
			stroke = [inside, inside]
		strokes[key] = stroke
		var slot:int = SLOT_OF[str(r["hole"])]
		var rest:float = float(BELLY_KNOBS["rest"])
		if(slot == THROAT):
			rest = float(THROAT_KNOBS["rest"])
		var amount:float = depthAmount(info["base"], info["tip"], inside) * lerp(rest, 1.0, strokeAmount(stroke, inside, dt))
		var owner:String = str(r["hole_owner"])
		if(!amounts.has(owner)):
			amounts[owner] = [0.0, 0.0]
		amounts[owner][slot] = max(float(amounts[owner][slot]), amount)
	stageScene.set_meta(META_STROKE, strokes)
	var was:Array = []
	if(stageScene.has_meta(META_CLIPPED)):
		was = stageScene.get_meta(META_CLIPPED)
	for helper in was:
		if(is_instance_valid(helper) && !clipped.has(helper)):
			helper.clearBulgeState()
			helper.restoreShaftTaper()
	stageScene.set_meta(META_CLIPPED, clipped)
	return amounts

static func restoreAll(stageScene) -> void:
	stageScene.remove_meta(META_STROKE)
	if(stageScene.has_meta(META_CLIPPED)):
		for helper in stageScene.get_meta(META_CLIPPED):
			if(is_instance_valid(helper)):
				helper.clearBulgeState()
				helper.restoreShaftTaper()
		stageScene.remove_meta(META_CLIPPED)
	for doll in stageScene.getDolls():
		if(doll != null && is_instance_valid(doll) && doll.has_meta(Belly.META_GAME)):
			Belly.restore(doll)
		var helper = Torso.helperOf(doll)
		if(helper != null):
			for torso in helper.getBulgeMeshesForZone(""):
				torso.remove_meta(META_THROAT)
	Torso.restoreAll(stageScene)
