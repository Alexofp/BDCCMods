extends Reference
const BULGE_DOLL_PATH := "res://Bulge4/Doll/BulgeDoll.gd"
const BULGE_UTILS_PATH := "res://Bulge4/Doll/BulgeUtils.gd"
const HOLE_VAGINA := "vagina"
const HOLE_ANUS := "anus"
const HOLE_MOUTH := "mouth"
const DOLL_HOLES := [HOLE_VAGINA, HOLE_ANUS, HOLE_MOUTH]
const KIND_DOLL := "doll"
const KIND_PROP := "prop"
const PROP_SHAFTS := [
	{"sign": "Shaft1", "bones": ["Shaft1", "Shaft2", "Shaft3", "Shaft4"], "radius": 0.22, "extend": 1.0},
	{"sign": "Knot", "bones": ["DildoBase.001", "Dildo", "Dildo.002", "Dildo.001"], "radius": 0.16,
		"extend": 1.0, "cut": ["DildoBase.001", "Dildo", "Knot", "Dildo.002", "Dildo.001"], "outline": "mesh"},
	{"sign": "Stick", "bones": ["Dildo1", "Dildo2", "Dildo3"], "radius": 0.16, "extend": 1.0, "rigid": true},
	{"sign": "DildoHandle", "bones": ["Dildo1", "Dildo2", "Dildo3", "Dildo4"], "radius": 0.16, "extend": 1.0,
		"off_material": "BDSMMachineNoDildos", "rigid": true},
	{"sign": "DildoHandle2", "bones": ["Dildo21", "Dildo22", "Dildo23", "Dildo24"], "radius": 0.16, "extend": 1.0,
		"off_material": "BDSMMachineNoDildos", "rigid": true},
]
const OVERLAP_PROBES := [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
const IMAGE_META := "bdccBulge4AlbedoImage"
const RES_PREFIX := "res://"
const SOURCE_META := "bdccBulge4SceneSource"
var scene = null
var dollScript = null
var utilsScript = null
var byID := {}
var propByID = null
func _init(stageScene):
	scene = stageScene
	dollScript = load(BULGE_DOLL_PATH)
	utilsScript = load(BULGE_UTILS_PATH)
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("getDolls")):
		return
	var dolls:Array = stageScene.getDolls()
	for index in range(dolls.size()):
		var theDoll = dolls[index]
		if(theDoll == null || !is_instance_valid(theDoll)):
			continue
		byID["doll" + str(index)] = theDoll
func sceneReady() -> bool:
	return scene != null && is_instance_valid(scene) && scene.has_method("getDolls")
func propsByID() -> Dictionary:
	if(propByID == null):
		propByID = {}
		if(sceneReady()):
			var props:Array = propsIn(scene)
			for index in range(props.size()):
				propByID[KIND_PROP + str(index)] = props[index]
	return propByID
func engineFor(participantID):
	var theDoll = dollFor(participantID)
	if(theDoll == null || utilsScript == null):
		return null
	return utilsScript.engineFor(theDoll)
func sceneSource():
	if(scene == null || !is_instance_valid(scene)):
		return null
	var theScript = scene.get_script()
	if(theScript == null):
		return null
	if(theScript.has_meta(SOURCE_META)):
		return theScript.get_meta(SOURCE_META)
	var text = theScript.source_code
	theScript.set_meta(SOURCE_META, text)
	return text
func sceneScriptPath():
	if(scene == null || !is_instance_valid(scene)):
		return null
	var theScript = scene.get_script()
	if(theScript == null):
		return null
	return stripResPrefix(str(theScript.resource_path))
static func stripResPrefix(path:String) -> String:
	if(path.begins_with(RES_PREFIX)):
		return path.substr(RES_PREFIX.length(), path.length() - RES_PREFIX.length())
	return path
func taperOf(participantID):
	var helper = helperFor(participantID)
	if(helper == null):
		return null
	var skeleton:Skeleton = helper.getSkeletonNode()
	if(skeleton == null):
		return null
	if(helper.getShaftInfo() == null):
		return null
	var hasTaperBone:bool = false
	for boneName in helper.TAPER_BONES:
		if(skeleton.find_bone(boneName) >= 0):
			hasTaperBone = true
			break
	if(!hasTaperBone):
		return null
	return helper.getShaftTaper()
func holeOf(participantID, holeID):
	var helper = helperFor(participantID)
	if(helper == null):
		return null
	return helper.getOrificeInfo(str(holeID))
func propsOf(participantID) -> Dictionary:
	var out:Dictionary = {}
	var theDoll = dollFor(participantID)
	if(theDoll == null):
		return out
	var zones = theDoll.get("dollAttachmentZones")
	if(typeof(zones) != TYPE_DICTIONARY):
		return out
	for zoneName in zones:
		var nodes = zones[zoneName]
		if(typeof(nodes) != TYPE_ARRAY):
			continue
		for zone in nodes:
			if(zone == null || !is_instance_valid(zone)):
				continue
			var props = zone.get("temporaryScenes")
			if(typeof(props) != TYPE_ARRAY):
				continue
			for prop in props:
				if(prop == null || !is_instance_valid(prop) || !(prop is Spatial)):
					continue
				out[str(zoneName)] = openingsOf(prop)
				break
			if(out.has(str(zoneName))):
				break
	return out
func openingsOf(prop) -> Array:
	for child in prop.get_children():
		if(!(child is Sprite3D) || child.texture == null):
			continue
		var box:AABB = child.get_aabb()
		var span:Array = opaqueSpanOf(child.texture)
		var low:float = float(span[0])
		var high:float = float(span[1])
		if(child.flip_h):
			low = 1.0 - float(span[1])
			high = 1.0 - float(span[0])
		var mid:Vector3 = box.position + box.size * 0.5
		var ends:Array = []
		for frac in [low, high]:
			var local := Vector3(box.position.x + box.size.x * frac, mid.y, mid.z)
			ends.append(child.global_transform.xform(local))
		return ends
	return [prop.global_transform.origin]
const SPAN_META := "bdccBulge4OpaqueSpan"
const OPAQUE_ALPHA := 0.5
const SPAN_ROW_STEP := 4
func opaqueSpanOf(texture) -> Array:
	if(texture.has_meta(SPAN_META)):
		return texture.get_meta(SPAN_META)
	var span:Array = [0.0, 1.0]
	var image = texture.get_data()
	if(image != null && image.is_compressed() && image.decompress() != OK):
		image = null
	if(image != null && image.get_width() > 0):
		var width:int = image.get_width()
		var first:int = -1
		var last:int = -1
		image.lock()
		for x in range(width):
			for y in range(0, image.get_height(), SPAN_ROW_STEP):
				if(image.get_pixel(x, y).a >= OPAQUE_ALPHA):
					if(first < 0):
						first = x
					last = x
					break
		image.unlock()
		if(first >= 0):
			span = [float(first) / width, float(last + 1) / width]
	texture.set_meta(SPAN_META, span)
	return span
static func propsIn(stageScene) -> Array:
	var out:Array = []
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("get_children")):
		return out
	for child in stageScene.get_children():
		if(!(child is Spatial) || child.has_method("prepareCharacter")):
			continue
		var skeleton = skeletonIn(child, 3)
		if(skeleton == null):
			continue
		for row in PROP_SHAFTS:
			if(skeleton.find_bone(str(row["sign"])) >= 0):
				out.append({"skeleton": skeleton, "row": row})
	return out
static func skeletonIn(node, depth:int):
	if(node is Skeleton):
		return node
	if(depth <= 0):
		return null
	for child in node.get_children():
		var found = skeletonIn(child, depth - 1)
		if(found != null):
			return found
	return null
func propShaftOf(participantID):
	var found = propsByID().get(str(participantID))
	if(found == null):
		return null
	var skeleton = found["skeleton"]
	if(!is_instance_valid(skeleton) || !skeleton.is_visible_in_tree()):
		return null
	var row:Dictionary = found["row"]
	if(row.has("off_material")):
		for child in skeleton.get_children():
			if(!(child is MeshInstance) || child.get_surface_material_count() == 0):
				continue
			var material = child.get_surface_material(0)
			if(material != null && str(row["off_material"]) in material.resource_path):
				return null
	var points:Array = []
	for boneName in row["bones"]:
		var boneIdx:int = skeleton.find_bone(str(boneName))
		if(boneIdx < 0):
			return null
		var at:Vector3 = (skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)).origin
		at.z = 0.0
		points.append(at)
	var base:Vector3 = points[0]
	var last:Vector3 = points[points.size() - 1]
	var tip:Vector3 = last + (last - points[points.size() - 2]) * float(row["extend"])
	return {
		"base": base,
		"tip": tip,
		"length": base.distance_to(tip),
		"radius": float(row["radius"]),
		"profile": [],
		"skip": 0.0,
	}
func overlapOf(participantID) -> Dictionary:
	var out:Dictionary = {}
	var card = propShaftOf(participantID)
	if(card == null || utilsScript == null):
		return out
	var dir:Vector3 = card["tip"] - card["base"]
	for dollID in byID:
		var helper = helperFor(dollID)
		if(helper == null):
			continue
		var skeleton:Skeleton = helper.getSkeletonNode()
		if(skeleton == null):
			continue
		var meshes:Array = helper.getBulgeMeshesForZone(HOLE_VAGINA)
		if(meshes.empty()):
			continue
		var drawn:int = 0
		for t in OVERLAP_PROBES:
			var rest:Vector3 = utilsScript.worldToRest(skeleton, "Hips", card["base"] + dir * float(t))
			if(drawnAt(meshes[0], Vector2(rest.x, rest.y))):
				drawn += 1
		out[dollID] = float(drawn) / float(OVERLAP_PROBES.size())
	return out
func drawnAt(themesh, rest:Vector2) -> bool:
	var fit = utilsScript.fitOf(themesh)
	if(typeof(fit) != TYPE_DICTIONARY):
		return false
	var low:Vector2 = fit["restMin"]
	var high:Vector2 = fit["restMax"]
	if(rest.x < low.x || rest.y < low.y || rest.x > high.x || rest.y > high.y):
		return false
	var image = albedoImageOf(themesh)
	if(image == null):
		return false
	image.lock()
	var drawn:bool = utilsScript.opaqueIn(image, fit, rest)
	image.unlock()
	return drawn
func albedoImageOf(themesh):
	var texture = utilsScript.getAlbedoTexture(themesh)
	if(texture == null):
		return null
	if(texture.has_meta(IMAGE_META)):
		var cached = texture.get_meta(IMAGE_META)
		if(cached is Image):
			return cached
		return null
	var image = texture.get_data()
	if(image != null && image.is_compressed() && image.decompress() != OK):
		image = null
	if(image == null):
		texture.set_meta(IMAGE_META, false)
	else:
		texture.set_meta(IMAGE_META, image)
	return image
func dollFor(participantID):
	var id:String = str(participantID)
	if(!byID.has(id)):
		return null
	var theDoll = byID[id]
	if(theDoll == null || !is_instance_valid(theDoll)):
		return null
	return theDoll
func helperFor(participantID):
	var theDoll = dollFor(participantID)
	if(theDoll == null || dollScript == null):
		return null
	return dollScript.forDoll(theDoll)
