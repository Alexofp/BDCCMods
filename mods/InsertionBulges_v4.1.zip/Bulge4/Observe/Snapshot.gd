extends Reference
const Eyes := preload("res://Bulge4/Observe/Eyes.gd")
const CAP_ENGINE_FOR := "engineFor"
const CAP_SCENE_SOURCE := "sceneSource"
const CAP_SCENE_PATH := "sceneScriptPath"
const CAP_TAPER_OF := "taperOf"
const CAP_HELPER_FOR := "helperFor"
const MESHES_KEY := "meshes"
const HOLE_INFO_KEY := "hole_info"
static func observe(view:Dictionary, providers) -> Dictionary:
	var roster:Array = []
	if(typeof(view.get("participants")) == TYPE_ARRAY):
		roster = view["participants"]
	var snapshot:Dictionary = {
		"pose": str(view.get("pose", "")),
		"participants": roster,
		"scene_source": null,
		"scene_path": null,
		"shafts": {},
		"holes": {},
		"tapers": {},
		"engines": [],
		"unread": [],
		"props": {},
		"overlap": {},
	}
	var unread:Array = []
	if(providers == null || !providers.has_method("engineFor")):
		unread.append(CAP_ENGINE_FOR)
	if(providers == null || !providers.has_method("taperOf")):
		unread.append(CAP_TAPER_OF)
	if(providers == null || !providers.has_method("helperFor")):
		unread.append(CAP_HELPER_FOR)
	if(providers == null || !providers.has_method("sceneSource")):
		unread.append(CAP_SCENE_SOURCE)
	else:
		var text = providers.sceneSource()
		if(typeof(text) == TYPE_STRING):
			snapshot["scene_source"] = text
		elif(text != null):
			unread.append(CAP_SCENE_SOURCE)
	if(providers == null || !providers.has_method("sceneScriptPath")):
		unread.append(CAP_SCENE_PATH)
	else:
		var path = providers.sceneScriptPath()
		if(typeof(path) == TYPE_STRING):
			snapshot["scene_path"] = path
		elif(path != null):
			unread.append(CAP_SCENE_PATH)
	unread.sort()
	snapshot["unread"] = unread
	if(providers == null):
		return snapshot
	var hasTaper:bool = providers.has_method("taperOf")
	var hasHole:bool = providers.has_method("holeOf")
	var hasProps:bool = providers.has_method("propsOf")
	for entry in roster:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null):
			continue
		var pid = entry["id"]
		snapshot["shafts"][pid] = shaftCardOf(providers, pid)
		snapshot["tapers"][pid] = null
		if(hasTaper):
			snapshot["tapers"][pid] = providers.taperOf(pid)
		var holes:Dictionary = {}
		var found = entry.get(HOLE_INFO_KEY)
		if(typeof(found) == TYPE_DICTIONARY):
			holes = found
			entry.erase(HOLE_INFO_KEY)
		else:
			for holeID in holesOf(entry):
				holes[str(holeID)] = null
				if(hasHole):
					holes[str(holeID)] = providers.holeOf(pid, str(holeID))
		snapshot["holes"][pid] = holes
		snapshot["props"][pid] = {}
		if(hasProps):
			snapshot["props"][pid] = providers.propsOf(pid)
	if(providers.has_method("overlapOf")):
		for entry in roster:
			if(typeof(entry) == TYPE_DICTIONARY && entry.get("kind") == Eyes.KIND_PROP):
				snapshot["overlap"][entry["id"]] = providers.overlapOf(entry["id"])
	snapshot["engines"] = engineRecords(roster, providers)
	return snapshot
static func build(stageScene, poseID):
	var bulgeDoll = load(Eyes.BULGE_DOLL_PATH)
	if(bulgeDoll == null):
		return null
	var eyes = Eyes.new(stageScene)
	return observe(viewOf(stageScene, poseID, bulgeDoll, eyes), eyes)
static func viewOf(stageScene, poseID, bulgeDoll, eyes) -> Dictionary:
	var pose:String = ""
	if(poseID != null):
		pose = str(poseID)
	var view:Dictionary = {
		"participants": [],
		"pose": pose,
	}
	if(stageScene == null || !is_instance_valid(stageScene) || !stageScene.has_method("getDolls")):
		return view
	var dolls:Array = stageScene.getDolls()
	for index in range(dolls.size()):
		var doll = dolls[index]
		if(doll == null || !is_instance_valid(doll)):
			continue
		var helper = bulgeDoll.forDoll(doll)
		if(helper == null):
			continue
		var holes:Array = []
		var infos:Dictionary = {}
		for holeID in Eyes.DOLL_HOLES:
			var info = helper.getOrificeInfo(holeID)
			if(info != null):
				holes.append(holeID)
				infos[holeID] = info
		view["participants"].append({
			"id": "doll" + str(index),
			"kind": Eyes.KIND_DOLL,
			"char_id": charIDOf(doll),
			"has_shaft": helper.getShaftInfo() != null,
			"holes": holes,
			HOLE_INFO_KEY: infos,
		})
	for propID in eyes.propsByID():
		view["participants"].append({
			"id": propID,
			"kind": Eyes.KIND_PROP,
			"char_id": null,
			"has_shaft": eyes.propShaftOf(propID) != null,
			"holes": [],
		})
	return view
static func charIDOf(doll):
	if(!doll.has_method("getCharacterID")):
		return null
	var charID = doll.getCharacterID()
	if(!(charID is String) || charID == ""):
		return null
	return charID
static func shaftCardOf(providers, participantID, copyArrays:bool = true):
	if(providers == null || !providers.has_method("helperFor")):
		return null
	if(str(participantID).begins_with(Eyes.KIND_PROP) && providers.has_method("propShaftOf")):
		return providers.propShaftOf(participantID)
	var helper = providers.helperFor(participantID)
	if(helper == null || !helper.has_method("getShaftInfo")):
		return null
	var info = helper.getShaftInfo()
	if(typeof(info) != TYPE_DICTIONARY):
		return null
	var card:Dictionary = {}
	for key in info:
		if(str(key) == MESHES_KEY):
			continue
		if(copyArrays && typeof(info[key]) == TYPE_ARRAY):
			card[key] = info[key].duplicate()
		else:
			card[key] = info[key]
	return card
static func engineRecords(roster:Array, providers) -> Array:
	var records:Array = []
	if(providers == null || !providers.has_method("engineFor")):
		return records
	var seen:Dictionary = {}
	for entry in roster:
		if(typeof(entry) != TYPE_DICTIONARY || entry.get("id") == null || entry.get("char_id") == null):
			continue
		var engine = providers.engineFor(entry["id"])
		if(typeof(engine) != TYPE_OBJECT):
			continue
		var key:int = engine.get_instance_id()
		if(seen.has(key)):
			continue
		seen[key] = true
		var activities = engine.get("activities")
		if(typeof(activities) != TYPE_ARRAY):
			records.append({"activities": null})
			continue
		var listed:Array = []
		for activity in activities:
			if(typeof(activity) != TYPE_OBJECT):
				listed.append(null)
				continue
			listed.append(activityRecord(activity))
		records.append({"activities": listed})
	return records
static func activityRecord(activity) -> Dictionary:
	var record:Dictionary = {
		"id": null,
		"ended": false,
		"readable": false,
		"participants": [],
		"dom0_slot": null,
		"dom1_slot": null,
		"used_slot": null,
	}
	var theID = activity.get("id")
	if(theID != null):
		record["id"] = str(theID)
	record["ended"] = activity.get("hasEnded") == true
	if(activity.has_method("getDom0Hole")):
		record["dom0_slot"] = slotValue(activity.getDom0Hole())
	if(activity.has_method("getDom1Hole")):
		record["dom1_slot"] = slotValue(activity.getDom1Hole())
	record["used_slot"] = slotValue(activity.get("usedBodypart"))
	record["readable"] = activity.has_method("convertCharIDToIndx") && activity.has_method("getTags")
	if(!record["readable"]):
		return record
	for group in [activity.get("doms"), activity.get("subs")]:
		if(typeof(group) != TYPE_ARRAY):
			continue
		for info in group:
			if(typeof(info) != TYPE_OBJECT || !info.has_method("getCharID")):
				continue
			var charID:String = str(info.getCharID())
			var indx:int = int(activity.convertCharIDToIndx(charID))
			var tags = activity.getTags(indx)
			var kept = null
			if(typeof(tags) == TYPE_ARRAY):
				kept = tags.duplicate()
			record["participants"].append({
				"char_id": charID,
				"indx": indx,
				"tags": kept,
			})
	return record
static func slotValue(slot):
	if(typeof(slot) != TYPE_STRING):
		return null
	return slot
static func holesOf(entry) -> Array:
	if(typeof(entry) != TYPE_DICTIONARY || typeof(entry.get("holes")) != TYPE_ARRAY):
		return []
	return entry["holes"]
static func cannotRead(snapshot, capability:String) -> bool:
	if(typeof(snapshot) != TYPE_DICTIONARY):
		return false
	var unread = snapshot.get("unread", [])
	if(typeof(unread) != TYPE_ARRAY):
		return false
	return unread.has(capability)
