extends Reference
const Snapshot := preload("res://Bulge4/Observe/Snapshot.gd")
const SnapReplayer := preload("res://Bulge4/Infer/SnapReplayer.gd")
const Ladder := preload("res://Bulge4/Infer/Ladder.gd")
const Frame := preload("res://Bulge4/Frame.gd")
const Settings := preload("res://Modules/InsertionBulges/Settings.gd")
const Boot := preload("res://Bulge4/Boot.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const CockCurve := preload("res://Bulge4/Curve/CockCurve.gd")
const AnimAhead := preload("res://Bulge4/Doll/AnimAhead.gd")
const StrokeSplit := preload("res://Bulge4/Doll/StrokeSplit.gd")
const EFFECTS := {"basic": "res://Bulge4/Effects/Basic/Basic.gd", "medium": "res://Bulge4/Effects/Medium/Medium.gd",
	"detailed": "res://Bulge4/Effects/Detailed/RubberSkin.gd"}
const DEFAULT_EFFECT := "detailed"
const LOADED := {}
const CLIP_ONLY := {"size": 0.0}
const TUNING := {"seen": -1, "on": true, "effect": DEFAULT_EFFECT, "opts": {}}
static func readSettings() -> void:
	var tuning:Dictionary = TUNING
	if(int(tuning["seen"]) == int(Settings.CHANGED["n"])):
		return
	tuning["seen"] = int(Settings.CHANGED["n"])
	tuning["on"] = bool(Settings.value("bulgesEnabled"))
	var effect:String = str(Settings.value("bulgeEffect"))
	if(effect == "simple"):
		effect = "basic"
	if(!EFFECTS.has(effect)):
		effect = DEFAULT_EFFECT
	if(Settings.gles2()):
		effect = "basic"
	tuning["effect"] = effect
	var hide:Dictionary = BulgeDoll.HIDE
	hide["on"] = bool(Settings.value("bulgeHidePenis"))
	var shade:float = 0.0
	var shadeStyle:String = str(Settings.value("bulgeSkinShadeStyle"))
	if(shadeStyle != "none"):
		shade = float(Settings.value("bulgeSkinShadeStrength"))
	var direction:String = Settings.directionMode()
	var help:bool = direction == "feel" || direction == "belly"
	var bend:float = float(Settings.value("bulgeFollowBody"))
	var belly:float = float(Settings.value("bulgeBelly"))
	if(direction == "animated"):
		bend = 0.0
		belly = 0.0
	var neck:String = str(Settings.value("bulgeNeck"))
	var pressMode:String = str(Settings.value("bulgePressMode"))
	tuning["opts"] = {"size": float(Settings.value("bulgeSizeModifier")), "bend": bend, "belly": belly,
		"stop_at_neck": neck != "off", "through": neck == "through", "through_head": float(Settings.value("bulgeThroughHead")), "through_squeeze": float(Settings.value("bulgeThroughSqueeze")), "neck_soft": float(Settings.value("bulgeNeckSoft")), "neck_tip": float(Settings.value("bulgeNeckTip")),
		"neck_bend_tip": float(Settings.value("bulgeNeckBendTip")), "neck_keep": float(Settings.value("bulgeNeckKeep")), "neck_bounce": float(Settings.value("bulgeNeckBounce")),
		"react": str(Settings.value("bulgeReact")), "tightness": float(Settings.value("bulgeTightness")),
		"linger": 2.0 * float(Settings.value("bulgeLinger")) * float(bool(Settings.value("bulgeLingerOn"))),
		"direction": direction,
		"repose": help && bool(Settings.value("bulgeReposeOn")), "repose_most": float(Settings.value("bulgeReposeMost")),
		"repose_crowd": bool(Settings.value("bulgeReposeCrowd")),
		"repose_line": -1.0, "repose_arch": float(Settings.value("bulgeReposeArch")),
		"repose_curve": 2.0 * float(Settings.value("bulgeReposeCurve")) - 1.0,
		"stroke_dir": 1.0,
		"shade_strength": shade,
		"shade_base_fade": 3.0 * float(Settings.value("bulgeSkinShadeFade")),
		"shade_style": shadeStyle, "shade_on_top": bool(Settings.value("bulgeSkinShadeOnTop")),
		"press": float(Settings.value("bulgePress")) * float(pressMode != "off"),
		"press_mode": pressMode,
		"press_reach": lerp(1.0, 5.0, float(Settings.value("bulgePressReach")))}
	if(str(Settings.value("bulgeBendMode")) == "push" && direction != "animated"):
		tuning["opts"]["push"] = CockCurve
		tuning["opts"]["push_hard"] = float(Settings.value("bulgePushHard"))
		tuning["opts"]["push_relax"] = float(Settings.value("bulgePushRelax"))
	strokeOpts(tuning["opts"])
	if(direction == "belly"):
		tuning["opts"]["direct_at"] = float(Settings.value("bulgeDirectAt"))
	if(help):
		tuning["opts"]["direction"] = "canal"
		tuning["opts"]["curve"] = CockCurve
		tuning["opts"]["canal_belly"] = float(Settings.value("bulgeCanalBelly"))

const STROKE_STYLES := {
	"game": {"travel": 0.5, "intensity": 0.5, "vary": 0.0, "deep": 0.0, "meet": 0.0, "stay": 0.0},
	"natural": {"travel": 0.7, "intensity": 0.5, "vary": 0.5, "deep": 0.5, "meet": 0.5, "stay": 0.5, "stretch": 0.6},
	"slow": {"travel": 0.9, "intensity": 0.3, "vary": 0.3, "deep": 1.0, "meet": 0.3, "stay": 0.8, "stretch": 1.0},
}
const STROKE_CLOCK := {"stroke_clock": true, "stroke_out_quick": 1.0, "stroke_in_quick": 1.0, "stroke_pauses": 1.0,
	"stroke_hand_slide": 0.5, "stroke_deep": 1.0, "stroke_vary_hard": 0.0, "stroke_steady": true, "stroke_regrip": true,
	"stroke_chest": true, "stroke_reserve": true, "stroke_vary_deep": true}
const STROKE_WARM := 6.0
static func strokeOpts(o:Dictionary) -> void:
	var style:String = str(Settings.value("bulgeStrokeStyle"))
	var s:Dictionary = STROKE_STYLES.get(style, STROKE_STYLES["natural"])
	if(style == "custom"):
		var strength:float = float(Settings.value("bulgeStrokeStrength"))
		var variety:float = float(Settings.value("bulgeStrokeVariety"))
		s = {"travel": float(Settings.value("bulgeStrokeLength")), "intensity": strength, "meet": strength,
			"stay": 1.0 - strength, "vary": variety, "deep": variety, "stretch": float(Settings.value("bulgeStrokeRhythm"))}
	o["repose_travel"] = 2.0 * float(s["travel"])
	o["repose_intensity"] = 2.0 * float(s["intensity"]) - 1.0
	o["repose_vary"] = float(s["vary"])
	o["repose_deep"] = float(s["deep"])
	o["repose_meet"] = float(s["meet"])
	o["repose_stay"] = float(s["stay"])
	o["repose_warm"] = 0.0
	if(!s.has("stretch")):
		return
	if(bool(Settings.value("bulgeStrokeWarm"))):
		o["repose_warm"] = STROKE_WARM
	if(bool(o["repose"])):
		for key in STROKE_CLOCK:
			o[key] = STROKE_CLOCK[key]
		o["stroke_stretch"] = float(s["stretch"])

static func effectScript(name:String):
	var loaded:Dictionary = LOADED
	if(!loaded.has(name)):
		loaded[name] = load(str(EFFECTS[name]))
	return loaded[name]
const META_FRAME := "bdccBulge4Frame"
const META_REPORT := "bdccBulge4Report"
const META_POSE := "bdccBulge4Pose"
const META_POSE_SINCE := "bdccBulge4PoseSince"
const META_KEPT := "bdccBulge4Kept"
const META_EFFECT := "bdccBulge4Effect"
const REFRESH := {"frames": 6, "young": 1.0}
const HELD_CONFIDENCE := -1
const FRAME_CLOCK := {"fps": 0}
static func tick(stageScene, frame:int, now:float):
	if(stageScene == null || !is_instance_valid(stageScene)):
		return null
	if(stageScene.has_meta(META_FRAME) && stageScene.get_meta(META_FRAME) == frame):
		if(stageScene.has_meta(META_REPORT)):
			return stageScene.get_meta(META_REPORT)
		return null
	if(int(FRAME_CLOCK["fps"]) > 0):
		now = float(frame - int(FRAME_CLOCK.get("from", 0))) / float(FRAME_CLOCK["fps"])
	if(!Boot.mayRun("Bulge4/Driver.tick")):
		return null
	stageScene.set_meta(META_FRAME, frame)
	stageScene.set_meta(META_REPORT, null)
	stageScene.set_meta(Frame.META_NOW, now)
	var t0:int = OS.get_ticks_usec()
	readSettings()
	var effect:String = str(TUNING["effect"])
	var opts:Dictionary = TUNING["opts"]
	if(opts.has("stroke_clock") && effect == "detailed"):
		StrokeSplit.step(stageScene, now, opts)
	if(!bool(TUNING["on"])):
		effect = ""
		if(bool(BulgeDoll.HIDE["on"])):
			effect = "basic"
			opts = CLIP_ONLY
	var drawn:String = ""
	if(stageScene.has_meta(META_EFFECT)):
		drawn = str(stageScene.get_meta(META_EFFECT))
	if(drawn != effect):
		if(drawn != ""):
			effectScript(drawn).restoreAll(stageScene)
		stageScene.set_meta(META_EFFECT, effect)
	if(effect == ""):
		stageScene.remove_meta(META_KEPT)
		return null
	var script = effectScript(effect)
	var poseID = stageScene.get("currentAnim")
	var pose:String = ""
	if(poseID != null):
		pose = str(poseID)
	var key:Array = [pose, dollKey(stageScene)]
	var age:float = ageOf(stageScene, str(key), now)
	var kept = null
	if(stageScene.has_meta(META_KEPT)):
		kept = stageScene.get_meta(META_KEPT)
	var empty:bool = kept != null && kept[2]["relations"].empty() && age < float(REFRESH["young"]) && !kept[4]
	if(kept == null || kept[1] != key || frame - int(kept[0]) >= int(REFRESH["frames"]) || frame < int(kept[0]) || empty):
		var snapshot = Snapshot.build(stageScene, pose)
		if(typeof(snapshot) != TYPE_DICTIONARY):
			stageScene.remove_meta(META_KEPT)
			script.restoreAll(stageScene)
			return null
		var inferred:Dictionary = SnapReplayer.infer(snapshot, age)
		stageScene.set_meta(Frame.META_SNAPSHOT, snapshot)
		var fused:Dictionary = Ladder.fuse(snapshot, inferred["items"])
		var shaftless:bool = !Ladder.participantsOf(snapshot).values().has(true)
		var holdable:bool = age > 0.0
		if(fused["relations"].empty() && age < float(REFRESH["young"]) && !shaftless && (!stageScene.has_meta(META_AHEAD) || stageScene.get_meta(META_AHEAD) != key)):
			stageScene.set_meta(META_AHEAD, key)
			var ahead = lookAhead(stageScene, pose, age)
			if(ahead != null):
				inferred = ahead[0]
				fused = ahead[1]
				holdable = true
		if(kept != null && kept[1] == key && kept[5]):
			var participants:Dictionary = Ladder.participantsOf(snapshot)
			for old in kept[2]["relations"]:
				var held:Dictionary = old.duplicate()
				held["confidence"] = HELD_CONFIDENCE
				Ladder.claim(fused, participants, held)
		kept = [frame, key, fused, inferred["notes"], shaftless, holdable]
		stageScene.set_meta(META_KEPT, kept)
	var table:Dictionary = kept[2]
	var t1:int = OS.get_ticks_usec()
	var report:Dictionary = {
		"pose": pose,
		"effect": effect,
		"relations": table["relations"],
		"problems": table["problems"],
		"notes": kept[3],
		"skins": script.run(stageScene, table["relations"], opts),
	}
	report["ms"] = (OS.get_ticks_usec() - t0) / 1000.0
	report["infer_ms"] = (t1 - t0) / 1000.0
	stageScene.set_meta(META_REPORT, report)
	return report
const AHEAD := {"samples": 8}
const META_AHEAD := "bdccBulge4Ahead"
static func lookAhead(stageScene, pose:String, age:float):
	var ahead:Array = AnimAhead.of(stageScene)
	if(ahead.empty()):
		return null
	var saved:Array = AnimAhead.save(ahead)
	var at:float = AnimAhead.positionOf(ahead)
	var loop:float = max(AnimAhead.lengthOf(ahead), 1e-3)
	var out = null
	var posed:Dictionary = BulgeDoll.POSED
	posed["ahead"] = true
	for k in range(1, int(AHEAD["samples"]) + 1):
		AnimAhead.poseAt(ahead, fposmod(at + loop * k / float(AHEAD["samples"]), loop))
		posed["n"] = int(posed["n"]) + 1
		var snapshot = Snapshot.build(stageScene, pose)
		if(typeof(snapshot) != TYPE_DICTIONARY):
			continue
		var inferred:Dictionary = SnapReplayer.infer(snapshot, age)
		var fused:Dictionary = Ladder.fuse(snapshot, inferred["items"])
		if(!fused["relations"].empty()):
			out = [inferred, fused]
			break
	AnimAhead.restore(ahead, saved)
	posed["n"] = int(posed["n"]) + 1
	posed["ahead"] = false
	return out

static func dollKey(stageScene) -> Array:
	var ids:Array = []
	for doll in stageScene.getDolls():
		if(doll != null && is_instance_valid(doll)):
			ids.append([doll.get_instance_id(), str(doll.get("savedCharacterID"))])
		else:
			ids.append(0)
	return ids
static func ageOf(stageScene, pose:String, now:float) -> float:
	if(!stageScene.has_meta(META_POSE) || str(stageScene.get_meta(META_POSE)) != pose):
		stageScene.set_meta(META_POSE, pose)
		stageScene.set_meta(META_POSE_SINCE, now)
	return now - float(stageScene.get_meta(META_POSE_SINCE))
