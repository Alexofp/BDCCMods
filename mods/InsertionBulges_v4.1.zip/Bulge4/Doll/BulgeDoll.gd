extends Node
const BulgeUtils = preload("res://Bulge4/Doll/BulgeUtils.gd")
const SLOT_PENIS := "penis"
const SLOT_STRAPON := "strapon"
const SLOT_HEAD := "head"
const SLOT_BODY := "body"
const NODE_NAME:String = "BulgeHelper"
const ANCHOR_BONE:Dictionary = {
	"vagina": "Hips",
	"anus": "Hips",
	"mouth": "Head",
}
const BULGE_BONE:Dictionary = {
	"vagina": "Hips",
	"anus": "Hips",
	"mouth": "Hips",
}
const BULGE_ORIGIN_BONE:Dictionary = {
	"mouth": "Neck",
}
const ANUS_OFFSET:Vector3 = Vector3(0.90518, -0.0511401, 0.0)
const MOUTH_OFFSET:Vector3 = Vector3(-0.31, -0.36, 0.0)
const SHAFT_RADIUS_FACTOR:float = 0.16
const TIP_EXTEND:float = 0.3
const ORIFICE_INWARD:Dictionary = {
	"vagina": Vector3(0.45, 0.89, 0.0),
	"anus": Vector3(-0.33, 0.94, 0.0),
	"mouth": Vector3(0.8, -0.6, 0.0),
}
var doll = null
var dirtyMeshes:Array = []
var taperCancelled:bool = false
var shaftInfoMemo = null
var memoFrame:int = -1
var memoTaper:bool = false
var memoScale:float = 0.0
var memoPosed:int = -1
var skeletonNode:Skeleton = null
static func forDoll(theDoll):
	if(theDoll == null || !is_instance_valid(theDoll)):
		return null
	var existing = theDoll.get_node_or_null(NODE_NAME)
	if(existing != null):
		return existing
	var helper = load("res://Bulge4/Doll/BulgeDoll.gd").new()
	helper.name = NODE_NAME
	helper.doll = theDoll
	theDoll.add_child(helper)
	return helper
func getSkeletonNode() -> Skeleton:
	if(!is_instance_valid(skeletonNode)):
		skeletonNode = doll.getDollSkeleton().getSkeleton()
	return skeletonNode
func getPatternMeshesForSlot(slot) -> Array:
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return []
	var part = doll.parts[slot]
	var meshes = part.get("meshesThatUpdateMaterial")
	if(typeof(meshes) != TYPE_ARRAY):
		return []
	return meshes
func hasVisibleSlot(slot) -> bool:
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return false
	return doll.parts[slot].visible
func getShaftMeshesForSlot(slot) -> Array:
	var pattern:Array = getPatternMeshesForSlot(slot)
	if(!pattern.empty()):
		return pattern
	if(!doll.parts.has(slot) || doll.parts[slot] == null):
		return []
	var found:Array = []
	collectShaftMeshes(doll.parts[slot], found)
	return found
func collectShaftMeshes(node, found:Array) -> void:
	for child in node.get_children():
		if(child is MeshInstance && child.mesh != null && "penis" in child.name.to_lower()):
			found.append(child)
		collectShaftMeshes(child, found)
func shaftMeshUsable(themesh) -> bool:
	if(themesh.has_method("supportsBulges")):
		return themesh.supportsBulges()
	return BulgeUtils.fitOf(themesh) != null
const POSED := {"n": 0}
func getShaftInfo():
	var frame:int = Engine.get_idle_frames()
	var scale:float = float(doll.rememberedPenisScale)
	var posed:int = int(POSED["n"])
	if(frame != memoFrame || taperCancelled != memoTaper || scale != memoScale || posed != memoPosed):
		shaftInfoMemo = measureShaftInfo()
		memoFrame = frame
		memoTaper = taperCancelled
		memoScale = scale
		memoPosed = posed
	return shaftInfoMemo
func measureShaftInfo():
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var meshes:Array = []
	var radius:float = 0.0
	var profile:Array = []
	var skip:float = BulgeUtils.PROFILE_SKIP_BASE
	var edges:Array = [[], []]
	for slot in [SLOT_PENIS, SLOT_STRAPON]:
		if(!hasVisibleSlot(slot)):
			continue
		for themesh in getShaftMeshesForSlot(slot):
			if(!themesh.is_visible_in_tree() || !shaftMeshUsable(themesh)):
				continue
			meshes.append(themesh)
			if(profile.empty()):
				profile = BulgeUtils.getShaftProfile(themesh)
				skip = BulgeUtils.getShaftSkip(themesh)
				edges = BulgeUtils.getShaftEdges(themesh)
			var measured:float = BulgeUtils.getShaftGirth(themesh)
			if(measured > 0.0001):
				radius = max(radius, measured)
			else:
				var fit:Dictionary = BulgeUtils.fitOf(themesh)
				radius = max(radius, (fit["restMax"].y - fit["restMin"].y) * SHAFT_RADIUS_FACTOR)
		if(!meshes.empty()):
			break
	if(meshes.empty()):
		return null
	var basePos = getBoneWorldPos("Penis")
	var midPos = getBoneWorldPos("Penis2")
	var endPos = getBoneWorldPos("Penis3")
	if(basePos == null || midPos == null || endPos == null):
		return null
	var tipPos:Vector3 = endPos + (endPos - midPos) * TIP_EXTEND
	var drawnLength:float = getDrawnShaftLength(meshes)
	var scale:float = max(doll.rememberedPenisScale, 0.01)
	if(drawnLength > 0.01):
		tipPos = basePos + (tipPos - basePos).normalized() * drawnLength * scale
	return {
		"base": basePos,
		"tip": tipPos,
		"length": basePos.distance_to(tipPos),
		"radius": radius * scale,
		"meshes": meshes,
		"profile": profile,
		"skip": skip,
		"edge_up": edges[0],
		"edge_down": edges[1],
		"up": shaftUpWorld(skeleton, basePos, tipPos),
	}
func shaftUpWorld(skeleton:Skeleton, basePos:Vector3, tipPos:Vector3) -> Vector3:
	var along:Vector3 = tipPos - basePos
	var across:Vector3 = Vector3(-along.y, along.x, 0.0).normalized()
	var restBase:Vector3 = BulgeUtils.worldToRest(skeleton, "Penis", basePos)
	var restSide:Vector3 = BulgeUtils.worldToRest(skeleton, "Penis", basePos + across * 0.1)
	if(restSide.y < restBase.y):
		return -across
	return across
func getDrawnShaftLength(meshes:Array) -> float:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null || meshes.empty()):
		return 0.0
	var boneIdx:int = skeleton.find_bone("Penis")
	if(boneIdx < 0):
		return 0.0
	var rootRestX:float = BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).origin.x
	var longest:float = 0.0
	for themesh in meshes:
		var span:Vector2 = BulgeUtils.getShaftSpan(themesh)
		if(span == Vector2.ZERO):
			continue
		longest = max(longest, abs(rootRestX - span.y))
	return longest
func getBoneWorldPos(boneName:String):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return null
	return (skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)).origin
func getOrificeAnchor(zone:String, fresh:bool = false):
	if(zone == "mouth"):
		var headNode = doll.get_node_or_null("BoneAttachments/HeadBoneAttachment")
		if(headNode == null || !hasVisibleSlot(SLOT_HEAD)):
			return null
		return attachmentWorld(headNode, fresh).xform(MOUTH_OFFSET)
	var crotchNode = doll.get_node_or_null("BoneAttachments/VaginaBoneAttachment")
	if(crotchNode == null):
		return null
	if(zone == "anus"):
		return attachmentWorld(crotchNode, fresh).xform(ANUS_OFFSET)
	if(zone == "vagina"):
		return attachmentWorld(crotchNode, fresh).origin
	return null
func attachmentWorld(node, fresh:bool) -> Transform:
	fresh = fresh || bool(POSED.get("ahead", false))
	var skeleton:Skeleton = getSkeletonNode()
	if(!fresh || skeleton == null || typeof(node.get("correctedTransform")) != TYPE_TRANSFORM):
		return node.global_transform
	var boneIdx:int = skeleton.find_bone(str(node.get("boneId")))
	if(boneIdx < 0):
		return node.global_transform
	var at:Transform = skeleton.get_bone_global_pose(boneIdx) * node.correctedTransform
	return node.get_parent().global_transform * at
func getOrificeInfo(zone:String):
	var anchor = getOrificeAnchor(zone)
	if(anchor == null):
		return null
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	return {
		"pos": anchor,
		"inward": BulgeUtils.restDirToWorld(skeleton, ANCHOR_BONE.get(zone, "Hips"), ORIFICE_INWARD.get(zone, Vector3(0.0, 1.0, 0.0))),
	}
func getBulgeMeshesForZone(_zone:String) -> Array:
	var result:Array = getPatternMeshesForSlot(SLOT_BODY)
	var filtered:Array = []
	for themesh in result:
		if(themesh.visible && themesh.supportsBulges()):
			filtered.append(themesh)
	return filtered
func getFrontContour(zone:String) -> Array:
	for themesh in getBulgeMeshesForZone(zone):
		if(!themesh.is_visible_in_tree()):
			continue
		var contour:Array = BulgeUtils.getFrontContour(themesh)
		if(!contour.empty()):
			return contour
	return []
func getBulgeOriginRest(zone:String):
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	if(BULGE_ORIGIN_BONE.has(zone)):
		var boneIdx:int = skeleton.find_bone(BULGE_ORIGIN_BONE[zone])
		if(boneIdx >= 0):
			return BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).origin
	var anchor = getOrificeAnchor(zone)
	if(anchor == null):
		return null
	return BulgeUtils.worldToRest(skeleton, BULGE_BONE.get(zone, "Hips"), anchor)
const HIDE := {"on": true}
func applyShaftClip(entryWorld:Vector3, force:bool = false):
	if(!HIDE["on"] && !force):
		clearBulgeState()
		return
	var shaftInfo = getShaftInfo()
	if(shaftInfo == null):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	var restEntryX:float = BulgeUtils.worldToRest(skeleton, "Penis", entryWorld).x
	for themesh in shaftInfo["meshes"]:
		var at:float = restEntryX
		var feather:float = 0.006
		if(themesh.has_method("setShaftClipAtRestX")):
			themesh.setShaftClipAtRestX(at, feather)
		else:
			BulgeUtils.setPlainShaftClip(themesh, at, feather)
		if(!dirtyMeshes.has(themesh)):
			dirtyMeshes.append(themesh)
func clearBulgeState():
	for themesh in dirtyMeshes:
		if(!is_instance_valid(themesh)):
			continue
		if(themesh.has_method("clearShaftClip")):
			themesh.clearShaftClip()
		else:
			BulgeUtils.clearPlainShaftClip(themesh)
	dirtyMeshes.clear()
func getNeckAxisWorld():
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	var neckIdx:int = skeleton.find_bone("Neck")
	var headIdx:int = skeleton.find_bone("Head")
	if(neckIdx < 0 || headIdx < 0):
		return null
	var neckWorld:Vector3 = (skeleton.global_transform * skeleton.get_bone_global_pose(neckIdx)).origin
	var headWorld:Vector3 = (skeleton.global_transform * skeleton.get_bone_global_pose(headIdx)).origin
	var along:Vector3 = headWorld - neckWorld
	if(along.length() < 0.0001):
		return null
	return {"origin": neckWorld, "dir": along.normalized(), "top": headWorld, "length": along.length()}
const SPINE_CHAIN := ["Head", "Neck", "Chest", "Hips"]
func getSpineChainWorld():
	var out:Array = []
	for boneName in SPINE_CHAIN:
		var at = getBoneWorldPos(boneName)
		if(at == null):
			return null
		out.append(at)
	return out
const TAPER_BONES:Array = ["Penis2", "Penis3"]
func getShaftTaper() -> float:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return 1.0
	var smallest:float = 1.0
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx < 0):
			continue
		smallest = min(smallest, skeleton.get_bone_pose(boneIdx).basis.get_scale().y)
	return smallest
func unTaperShaftBones() -> void:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx < 0):
			continue
		var poseScale:Vector3 = skeleton.get_bone_pose(boneIdx).basis.get_scale()
		var worst:float = min(min(poseScale.x, poseScale.y), poseScale.z)
		if(worst <= 0.001):
			skeleton.set_bone_custom_pose(boneIdx, Transform.IDENTITY)
			continue
		var inverse:Vector3 = Vector3(1.0 / poseScale.x, 1.0 / poseScale.y, 1.0 / poseScale.z)
		var pose:Transform = skeleton.get_bone_pose(boneIdx)
		skeleton.set_bone_custom_pose(boneIdx, pose * Transform.IDENTITY.scaled(inverse) * pose.affine_inverse())
	taperCancelled = true
func restoreShaftTaper() -> void:
	if(!taperCancelled):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in TAPER_BONES:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx >= 0):
			skeleton.set_bone_custom_pose(boneIdx, Transform.IDENTITY)
	taperCancelled = false
const SHAFT_CHAIN:Array = ["Penis", "Penis2", "Penis3"]
var shaftBent:bool = false
func shaftChainOf():
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return null
	unbendShaft()
	var heads:Array = []
	var dirs:Array = []
	var bones:Array = []
	for boneName in SHAFT_CHAIN:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx < 0):
			return null
		bones.append(boneIdx)
		heads.append(skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx).origin)
	var restAxis:Vector3 = shaftRestAxis(skeleton)
	for boneIdx in bones:
		dirs.append(shaftDirOf(skeleton, boneIdx, restAxis))
	return {"heads": heads, "dirs": dirs, "rest_axis": restAxis}
func shaftRestAxis(skeleton:Skeleton) -> Vector3:
	var first:int = skeleton.find_bone(SHAFT_CHAIN[0])
	var last:int = skeleton.find_bone(SHAFT_CHAIN[SHAFT_CHAIN.size() - 1])
	return Vector3(sign(BulgeUtils.getBoneRestGlobal(skeleton, last).origin.x - BulgeUtils.getBoneRestGlobal(skeleton, first).origin.x), 0.0, 0.0)
func shaftDirOf(skeleton:Skeleton, boneIdx:int, restAxis:Vector3) -> Vector2:
	var local:Vector3 = BulgeUtils.getBoneRestGlobal(skeleton, boneIdx).basis.inverse().xform(restAxis)
	var g:Transform = skeleton.get_bone_global_pose(boneIdx)
	var d:Vector3 = skeleton.global_transform.basis.xform(g.basis.xform(local))
	return Vector2(d.x, d.y).normalized()
func bendShaft(dirs:Array, restAxis:Vector3) -> void:
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	unbendShaft()
	var toWorld:Transform = skeleton.global_transform
	for i in range(min(dirs.size(), SHAFT_CHAIN.size())):
		var boneIdx:int = skeleton.find_bone(SHAFT_CHAIN[i])
		if(boneIdx < 0 || typeof(dirs[i]) != TYPE_VECTOR2):
			continue
		var now:Vector2 = shaftDirOf(skeleton, boneIdx, restAxis)
		var turn:float = now.angle_to(dirs[i])
		var g:Transform = skeleton.get_bone_global_pose(boneIdx)
		var pivot:Vector3 = toWorld.xform(g.origin)
		var r := Basis(Vector3(0.0, 0.0, 1.0), turn)
		var w := Transform(r, pivot - r.xform(pivot))
		skeleton.set_bone_global_pose_override(boneIdx, toWorld.affine_inverse() * w * toWorld * g, 1.0, true)
	shaftBent = true
func unbendShaft() -> void:
	if(!shaftBent):
		return
	var skeleton:Skeleton = getSkeletonNode()
	if(skeleton == null):
		return
	for boneName in SHAFT_CHAIN:
		var boneIdx:int = skeleton.find_bone(boneName)
		if(boneIdx >= 0):
			skeleton.set_bone_global_pose_override(boneIdx, Transform.IDENTITY, 0.0, false)
	shaftBent = false
const JOINT_BLEND := 0.5
