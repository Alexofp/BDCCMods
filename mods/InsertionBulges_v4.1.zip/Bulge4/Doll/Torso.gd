extends Reference
const Skirt := preload("res://Bulge4/Effects/Classic/Skirt.gd")
const Classic := preload("res://Bulge4/Shader/Classic.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const META_TORSO := "bdccBulge4Torso"

static func prepare(torso) -> bool:
	if(torso.has_meta(META_TORSO)):
		return true
	var material:ShaderMaterial = torso.fancyMaterial
	var injected = Classic.shaderFor(material.shader)
	if(injected == null):
		return false
	torso.set_meta(META_TORSO, {"mesh": torso.mesh, "shader": material.shader})
	material.shader = injected
	var expanded = Skirt.getExpandedMesh(torso.mesh, Skirt.PAD)
	if(expanded != null && expanded != torso.mesh):
		torso.mesh = expanded
		torso.set_surface_material(0, material)
		material.set_shader_param("bulge_expanded", 1.0)
	material.set_shader_param("bulge_aspect", torso.uvFit["aspect"])
	return true

static func restore(torso) -> void:
	if(!torso.has_meta(META_TORSO)):
		return
	var state:Dictionary = torso.get_meta(META_TORSO)
	var material:ShaderMaterial = torso.fancyMaterial
	for param in VisualServer.shader_get_param_list(material.shader.get_rid()):
		if(str(param["name"]).begins_with("bulge_")):
			material.set_shader_param(param["name"], null)
	material.shader = state["shader"]
	if(torso.mesh != state["mesh"]):
		torso.mesh = state["mesh"]
		torso.set_surface_material(0, material)
	torso.remove_meta(META_TORSO)

static func restoreAll(stageScene) -> void:
	for doll in stageScene.getDolls():
		var helper = helperOf(doll)
		if(helper == null):
			continue
		for torso in helper.getBulgeMeshesForZone(""):
			restore(torso)

static func helperOf(doll):
	if(doll == null || !is_instance_valid(doll)):
		return null
	return BulgeDoll.forDoll(doll)

static func dollAt(dolls:Array, id):
	var name:String = str(id)
	if(!name.begins_with("doll")):
		return null
	var index:int = int(name.substr(4))
	if(index < 0 || index >= dolls.size()):
		return null
	return dolls[index]

static func restToWorld(rig:Dictionary, restPoint:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().xform(restPoint)

static func restDirToWorld(rig:Dictionary, restDir:Vector3) -> Vector3:
	var hips:Transform = rig["hips"]
	return hips.affine_inverse().basis.xform(restDir).normalized()
