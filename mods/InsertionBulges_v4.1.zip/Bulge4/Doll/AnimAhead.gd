extends Reference

static func of(stageScene) -> Array:
	var out:Array = []
	for node in stageScene.get_children():
		if(!(node is AnimationTree)):
			continue
		var player = node.get_node_or_null(node.anim_player)
		var playback = node.get("parameters/StateMachine/playback")
		if(player == null || playback == null || !(node.tree_root is AnimationNodeBlendTree) || !node.tree_root.has_node("StateMachine")):
			return []
		var state:String = playback.get_current_node()
		var pos:float = playback.get_current_play_position()
		var travel:Array = playback.get_travel_path()
		if(!travel.empty()):
			state = str(travel[travel.size() - 1])
			pos = 0.0
		var machine = node.tree_root.get_node("StateMachine")
		if(state == "" || !machine.has_node(state) || !(machine.get_node(state) is AnimationNodeAnimation)):
			return []
		var anim:Animation = player.get_animation(machine.get_node(state).animation)
		var root = player.get_node_or_null(player.root_node)
		if(anim == null || root == null):
			return []
		var skel:Skeleton = null
		var bones:Array = []
		for track in range(anim.get_track_count()):
			if(anim.track_get_type(track) != Animation.TYPE_TRANSFORM):
				continue
			var path:PoolStringArray = str(anim.track_get_path(track)).split(":")
			if(path.size() != 2):
				return []
			var target = root.get_node_or_null(NodePath(path[0]))
			if(!(target is Skeleton) || (skel != null && target != skel)):
				return []
			var idx:int = target.find_bone(path[1])
			if(idx < 0):
				return []
			skel = target
			bones.append([track, idx])
		if(skel != null):
			out.append({"skel": skel, "bones": bones, "anim": anim, "pos": pos})
	return out

static func lengthOf(ahead:Array) -> float:
	return float(ahead[0]["anim"].length)

static func positionOf(ahead:Array) -> float:
	return float(ahead[0]["pos"])

static func poseAt(ahead:Array, time:float) -> void:
	for one in ahead:
		for b in one["bones"]:
			var got:Array = one["anim"].transform_track_interpolate(int(b[0]), time)
			one["skel"].set_bone_pose(int(b[1]), Transform(Basis(got[1]) * Basis().scaled(got[2]), got[0]))

static func save(ahead:Array) -> Array:
	var out:Array = []
	for one in ahead:
		var poses:Array = []
		for b in one["bones"]:
			poses.append(one["skel"].get_bone_pose(int(b[1])))
		out.append(poses)
	return out

static func restore(ahead:Array, saved:Array) -> void:
	for i in range(ahead.size()):
		for j in range(ahead[i]["bones"].size()):
			ahead[i]["skel"].set_bone_pose(int(ahead[i]["bones"][j][1]), saved[i][j])
