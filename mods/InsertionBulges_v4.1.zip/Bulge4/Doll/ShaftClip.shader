shader_type spatial;
render_mode async_visible,blend_mix,depth_draw_alpha_prepass,cull_disabled,specular_disabled,unshaded;
uniform vec4 albedo : hint_color;
uniform sampler2D texture_albedo : hint_albedo;
uniform float shaft_clip = 2.0;
uniform float shaft_clip_dir = -1.0;
uniform float shaft_clip_feather = 0.008;
uniform float shaft_clip_v = 0.0;
uniform float shaft_clip_slope = 0.0;
uniform float shaft_clip_keep = 2.0;
void fragment() {
	vec4 albedo_tex = texture(texture_albedo, UV);
	if(shaft_clip < 1.5) {
		float clipDistance = (UV.x - shaft_clip) * shaft_clip_dir + (UV.y - shaft_clip_v) * shaft_clip_slope;
		if(shaft_clip_keep < 1.5) {
			clipDistance = min(clipDistance, (UV.x - shaft_clip_keep) * shaft_clip_dir);
		}
		albedo_tex.a *= 1.0 - smoothstep(-shaft_clip_feather, shaft_clip_feather, clipDistance);
	}
	ALBEDO = albedo.rgb * albedo_tex.rgb;
	ALPHA = albedo.a * albedo_tex.a;
}
