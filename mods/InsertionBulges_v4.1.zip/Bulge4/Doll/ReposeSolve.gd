extends Reference

const W := {"miss": 10.0, "depth": 10.0, "way": 1.0, "fit": 4.0, "move": 0.1, "bend": 0.001, "head": 0.005, "wall": 20.0, "feet": 4000.0, "steady": 0.2, "hold": 1000.0}
const FOLLOW := 0.75
const ITER := 8
const WARM := 1
const DONE := 0.001
const GRAZE := 0.05
const SOFT := 0.05
const TORSO := 23.0
const TRIES := 8
const DAMP := 10.0

static func solve(model:Dictionary, iters:int = ITER) -> Array:
	for pair in model["pairs"]:
		pair["points"] = PoolVector2Array(pair["line"])
		pair["len"] = 0.0
		for i in range(pair["line"].size() - 1):
			pair["len"] += pair["line"][i].distance_to(pair["line"][i + 1])
	var res:Array = []
	if(model.has("slide")):
		var slid:Array = slide(model)
		model["prev"] = slid[0]
		res = slid[1]
	var quad:Array = quadOf(model)
	var q:Array = model["prev"].duplicate()
	var lam := 0.001
	if(res.empty()):
		res = residuals(model, q)
	var cost:float = costOf(res, q, quad)
	for _it in range(iters):
		var a:Array = []
		var g:Array = []
		var zero:Array = []
		zero.resize(q.size())
		for j in range(q.size()):
			zero[j] = 0.0
		for _i in range(q.size()):
			a.append(zero.duplicate())
			g.append(0.0)
		var rows:Array = jacobian(model, q)
		for k in range(rows.size()):
			var ix:Array = rows[k][0]
			var vx:Array = rows[k][1]
			var e:float = res[k]
			for u in range(ix.size()):
				var vu:float = vx[u]
				var au:Array = a[ix[u]]
				g[ix[u]] -= vu * e
				for w in range(u, ix.size()):
					au[ix[w]] += vu * vx[w]
		for i in range(q.size()):
			var ai:Array = a[i]
			for j in range(i):
				ai[j] = a[j][i]
			ai[i] += quad[0][i]
			g[i] -= quad[0][i] * (q[i] - quad[1][i])
		var stepped := false
		var size := INF
		for _try in range(TRIES):
			var damped:Array = []
			for i in range(q.size()):
				var row:Array = a[i].duplicate()
				row[i] = row[i] * (1.0 + lam) + 0.000001
				row.append(g[i])
				damped.append(row)
			var d:Array = linear(damped)
			var qn:Array = []
			for i in range(q.size()):
				qn.append(q[i] + d[i])
			var rn:Array = residuals(model, qn)
			var cn:float = costOf(rn, qn, quad)
			if(cn < cost):
				size = 0.0
				for di in d:
					size = max(size, abs(di))
				q = qn
				res = rn
				cost = cn
				lam = max(lam * 0.3, 0.000001)
				stepped = true
				break
			lam *= DAMP
		if(!stepped || size < DONE):
			break
	return q

static func slide(model:Dictionary) -> Array:
	var q:Array = model["prev"]
	var bodies:Array = model["bodies"]
	var r:float = float(model["r"])
	var b:int = int(model["slide"][0])
	var tops:Array = model["slide"][1]
	if(tops.empty()):
		return [q, []]
	var off:Vector2 = Vector2(q[3 * b], q[3 * b + 1]) - bodies[b]["target"] / r
	var want:Vector2 = Vector2.ZERO
	for one in tops:
		var k:int = int(one[0])
		var rel:Vector2 = Vector2(q[3 * k], q[3 * k + 1]) - bodies[k]["target"] / r - off
		want -= rel * float(one[1]) / float(tops.size())
	var quad:Array = quadOf(model, 0.0)
	var best:Array = q
	var bestRes:Array = residuals(model, q)
	var least:float = costOf(bestRes, q, quad)
	for f in [1.0, 0.5]:
		var c:Vector2 = (want - off) * f
		var t:Array = q.duplicate()
		for k in range(bodies.size()):
			t[3 * k] += c.x
			t[3 * k + 1] += c.y
		var tRes:Array = residuals(model, t)
		var cost:float = costOf(tRes, t, quad)
		if(cost < least):
			least = cost
			best = t
			bestRes = tRes
	return [best, bestRes]

static func quadOf(model:Dictionary, steady:float = -1.0) -> Array:
	if(steady < 0.0):
		steady = W["steady"]
	var r:float = float(model["r"])
	var weights:Array = []
	var centres:Array = []
	var hold:Dictionary = model.get("hold", {})
	for k in range(model["bodies"].size()):
		var body:Dictionary = model["bodies"][k]
		var target:Vector2 = body["target"] / r
		var to:Array = [target.x, target.y, 0.0]
		for c in range(3):
			var scale := 1.0
			if(c == 2):
				scale = max(float(body["L"]) / r, TORSO)
			var wm:float = W["move"] * float(body["w"]) * scale * scale
			var ws:float = steady * scale * scale
			var wh:float = 0.0
			var held:float = 0.0
			if(hold.has(3 * k + c)):
				wh = W["hold"] * scale * scale
				held = float(hold[3 * k + c])
			var wt:float = 0.0
			if(c == 2 && body.has("turn_to")):
				wt = W["move"] * float(body["turn_w"]) * scale * scale
			weights.append(wm + ws + wh + wt)
			centres.append((wm * float(to[c]) + ws * float(model["prev"][3 * k + c]) + wh * held + wt * float(body.get("turn_to", 0.0))) / max(wm + ws + wh + wt, 1e-12))
	for p in range(model["pairs"].size()):
		var scale:float = float(model["pairs"][p]["len"]) / r
		var wb:float = W["bend"] * scale * scale
		var ws:float = steady * scale * scale
		weights.append(wb + ws)
		centres.append(ws * float(model["prev"][weights.size() - 1]) / max(wb + ws, 1e-12))
	for what in ["tilt", "bridge"]:
		for body in model["bodies"]:
			if(body.has(what + "_at")):
				var scale:float = max(float(body["L"]) / r, TORSO)
				var wt:float = W["move"] * float(body[what + "_w"]) * scale * scale
				var ws:float = steady * scale * scale
				weights.append(wt + ws)
				centres.append((wt * float(body.get(what + "_to", 0.0)) + ws * float(model["prev"][weights.size() - 1])) / max(wt + ws, 1e-12))
	return [weights, centres]

static func costOf(res:Array, q:Array, quad:Array) -> float:
	var c:float = dot(res, res)
	for i in range(q.size()):
		c += quad[0][i] * (q[i] - quad[1][i]) * (q[i] - quad[1][i])
	return c

static func residuals(model:Dictionary, q:Array) -> Array:
	var r:float = float(model["r"])
	var bodies:Array = model["bodies"]
	var moves:Array = []
	for k in range(bodies.size()):
		moves.append(moveOf(bodies[k], q, k, r))
	var wMiss:float = sqrt(W["miss"]) / r
	var wDepth:float = sqrt(W["depth"]) / r
	var wHead:float = sqrt(W["head"]) / r
	var wWall:float = sqrt(W["wall"])
	var out:Array = []
	for p in range(model["pairs"].size()):
		var pair:Dictionary = model["pairs"][p]
		var top:int = pair["top"]
		var bottom:int = pair["bottom"]
		var h:Vector2 = pair["hole"]
		if(bottom >= 0):
			h = moves[bottom][0].xform(h)
		var points:PoolVector2Array = lineOf(model, q, moves, p)
		if(pair.has("keep")):
			var kept:Vector2 = (missOf(points, h) - pair["keep"]) * wMiss
			out.append(kept.x)
			out.append(kept.y)
		else:
			var miss:Vector2 = missOf(points, h) * wMiss
			out.append(miss.x)
			out.append(miss.y)
		if(pair.has("gap")):
			out.append(wDepth * ((h - points[0]).dot(dirOf(points)) - float(pair["gap"])))
		var way:Vector2 = pair.get("way", Vector2.ZERO)
		if(way != Vector2.ZERO && (pair.has("keep") || pair.has("way_w"))):
			if(bottom >= 0 && !pair.get("way_fixed", false)):
				way = moves[bottom][0].basis_xform(way)
			out.append(sqrt(W["way"] * float(pair.get("way_w", 1.0))) * dirOf(points).angle_to(way) * float(pair["len"]) / r)
		if(float(pair["fit"]) > 0.0 && !pair["table"].empty()):
			var turn:float = q[3 * top + 2] + tiltOf(bodies[top], q) + bridgeOf(bodies[top], q) + q[3 * bodies.size() + p]
			if(bottom >= 0):
				turn -= q[3 * bottom + 2] + tiltOf(bodies[bottom], q) + bridgeOf(bodies[bottom], q)
			out.append(sqrt(W["fit"] * float(pair["fit"])) * max(sampled(pair["table"], float(pair["turn"]), turn) - GRAZE, 0.0))
		if(pair.has("range")):
			var b:float = q[3 * bodies.size() + p]
			var tip:float = float(pair.get("len", 0.0)) / r
			out.append(wWall * soft((float(pair["range"][0]) - b) * tip))
			out.append(wWall * soft((b - float(pair["range"][1])) * tip))
	for k in range(bodies.size()):
		var body:Dictionary = bodies[k]
		var neck:Vector2 = body["neck"]
		var head:Vector2 = (moves[k][1].xform(neck) - neck) * wHead
		out.append(head.x)
		out.append(head.y)
		for limb in body["limbs"]:
			var root:Vector2
			if(limb[5]):
				root = moves[k][1].xform(limb[0])
			else:
				root = moves[k][0].xform(limb[0])
			var end:Vector2 = limb[1]
			if(limb.size() > 7 && float(limb[7]) > 0.0):
				if(limb[5]):
					end = end.linear_interpolate(moves[k][1].xform(end), float(limb[7]))
				else:
					end = end.linear_interpolate(moves[k][0].xform(end), float(limb[7]))
			if(limb[3] >= 0):
				end = end.linear_interpolate(moves[limb[3]][0].xform(limb[1]), limb[4])
			var wLimb:float = wWall
			if(!limb[5]):
				wLimb = sqrt(W["feet"])
			out.append(wLimb * soft((root.distance_to(end) - limb[2]) / r))
			out.append(zoneOf(limb, r) * max(root.distance_to(end) - zoneStart(limb), 0.0))
		out.append(wWall * soft((Vector2(q[3 * k], q[3 * k + 1]) - body["target"] / r).length() - float(body["most"])))
		if(body.has("turn_most")):
			walls(out, wWall, q[3 * k + 2], float(body["turn_most"]), float(body["L"]) / r)
		if(body.has("tilt_at")):
			walls(out, wWall, tiltOf(body, q), float(body["tilt_most"]), float(body["L"]) / r)
		if(body.has("bridge_at")):
			walls(out, wWall, bridgeOf(body, q), float(body["bridge_most"]), float(body["L"]) / r)
		if(body.has("floor")):
			out.append(sqrt(W["feet"]) * soft((float(body["floor"]) - moves[k][0].xform(body["pivot"]).y) / r))
	return out

static func jacobian(model:Dictionary, q:Array) -> Array:
	var r:float = float(model["r"])
	var bodies:Array = model["bodies"]
	var nb:int = bodies.size()
	var moves:Array = []
	var tws:Array = []
	for k in range(nb):
		moves.append(moveOf(bodies[k], q, k, r))
		tws.append(twistsOf(bodies[k], q, k, r))
	var acc:Array = []
	var acc2:Array = []
	acc.resize(q.size())
	acc2.resize(q.size())
	for i in range(q.size()):
		acc[i] = 0.0
		acc2[i] = 0.0
	var wMiss:float = sqrt(W["miss"]) / r
	var wDepth:float = sqrt(W["depth"]) / r
	var wHead:float = sqrt(W["head"]) / r
	var wWall:float = sqrt(W["wall"])
	var rows:Array = []
	for p in range(model["pairs"].size()):
		var pair:Dictionary = model["pairs"][p]
		var top:int = pair["top"]
		var bottom:int = pair["bottom"]
		var h:Vector2 = pair["hole"]
		var low:Array = []
		if(bottom >= 0):
			h = moves[bottom][0].xform(h)
			low = tws[bottom][0]
		var points:PoolVector2Array = lineOf(model, q, moves, p)
		var base:Vector2 = moves[top][0].xform(pair.get("pivot", pair["line"][0]))
		var line:Array = tws[top][0].duplicate()
		line.append([3 * nb + p, Vector3(1.0, base.y, -base.x)])
		var best:int = 0
		var bestD:float = INF
		for i in range(points.size() - 1):
			var c:Vector2 = Geometry.get_closest_point_to_segment_2d(h, points[i], points[i + 1])
			if(c.distance_squared_to(h) < bestD):
				bestD = c.distance_squared_to(h)
				best = i
		var pa:Vector2 = points[best]
		var d:Vector2 = points[best + 1] - pa
		var dd:float = max(d.dot(d), 1e-12)
		var t:float = (h - pa).dot(d) / dd
		for one in line:
			var da:Vector2 = at(one[1], pa)
			var dc:Vector2 = da
			if(t >= 1.0):
				dc = at(one[1], points[best + 1])
			elif(t > 0.0):
				var dl:Vector2 = at(one[1], points[best + 1]) - da
				dc = da + d * ((h - pa).dot(dl) - da.dot(d) - 2.0 * t * d.dot(dl)) / dd + dl * t
			acc[one[0]] -= dc.x * wMiss
			acc2[one[0]] -= dc.y * wMiss
		for one in low:
			var dh:Vector2 = at(one[1], h)
			var dm:Vector2 = dh
			if(t > 0.0 && t < 1.0):
				dm = dh - d * dh.dot(d) / dd
			acc[one[0]] += dm.x * wMiss
			acc2[one[0]] += dm.y * wMiss
		emit(rows, acc)
		emit(rows, acc2)
		var dir:Vector2 = dirOf(points)
		if(pair.has("gap")):
			for one in line:
				acc[one[0]] += wDepth * ((h - points[0]).dot(Vector2(-dir.y, dir.x)) * one[1].x - at(one[1], points[0]).dot(dir))
			for one in low:
				acc[one[0]] += wDepth * at(one[1], h).dot(dir)
			emit(rows, acc)
		var way:Vector2 = pair.get("way", Vector2.ZERO)
		if(way != Vector2.ZERO && (pair.has("keep") || pair.has("way_w"))):
			var kw:float = sqrt(W["way"] * float(pair.get("way_w", 1.0))) * float(pair["len"]) / r
			for one in line:
				acc[one[0]] -= kw * one[1].x
			if(bottom >= 0 && !pair.get("way_fixed", false)):
				for one in low:
					acc[one[0]] += kw * one[1].x
			emit(rows, acc)
		if(float(pair["fit"]) > 0.0 && !pair["table"].empty()):
			var turn:float = q[3 * top + 2] + tiltOf(bodies[top], q) + bridgeOf(bodies[top], q) + q[3 * nb + p]
			if(bottom >= 0):
				turn -= q[3 * bottom + 2] + tiltOf(bodies[bottom], q) + bridgeOf(bodies[bottom], q)
			var slope:float = 0.0
			if(sampled(pair["table"], float(pair["turn"]), turn) - GRAZE > 0.0):
				slope = sqrt(W["fit"] * float(pair["fit"])) * sampledSlope(pair["table"], float(pair["turn"]), turn)
			for i in turnsOf(bodies[top], top, q):
				acc[i] += slope
			acc[3 * nb + p] += slope
			if(bottom >= 0):
				for i in turnsOf(bodies[bottom], bottom, q):
					acc[i] -= slope
			emit(rows, acc)
		if(pair.has("range")):
			var b:float = q[3 * nb + p]
			var tip:float = float(pair.get("len", 0.0)) / r
			acc[3 * nb + p] = -wWall * softSlope((float(pair["range"][0]) - b) * tip) * tip
			emit(rows, acc)
			acc[3 * nb + p] = wWall * softSlope((b - float(pair["range"][1])) * tip) * tip
			emit(rows, acc)
	for k in range(nb):
		var body:Dictionary = bodies[k]
		var hp:Vector2 = moves[k][1].xform(body["neck"])
		for one in tws[k][1]:
			var dp:Vector2 = at(one[1], hp)
			acc[one[0]] += dp.x * wHead
			acc2[one[0]] += dp.y * wHead
		emit(rows, acc)
		emit(rows, acc2)
		for limb in body["limbs"]:
			var arm:int = 0
			if(limb[5]):
				arm = 1
			var root:Vector2 = moves[k][arm].xform(limb[0])
			var end:Vector2 = limb[1]
			var own:float = 0.0
			var mine:Vector2 = end
			if(limb.size() > 7 && float(limb[7]) > 0.0):
				own = float(limb[7])
				mine = moves[k][arm].xform(end)
				end = end.linear_interpolate(mine, own)
			var fw:float = 0.0
			var held:Vector2 = Vector2.ZERO
			if(limb[3] >= 0):
				fw = float(limb[4])
				held = moves[limb[3]][0].xform(limb[1])
				end = end.linear_interpolate(held, fw)
			var wLimb:float = wWall
			if(!limb[5]):
				wLimb = sqrt(W["feet"])
			var dist:float = root.distance_to(end)
			var u:Vector2 = (root - end) / max(dist, 1e-12) * wLimb * softSlope((dist - limb[2]) / r) / r
			for one in tws[k][arm]:
				acc[one[0]] += u.dot(at(one[1], root) - at(one[1], mine) * (own * (1.0 - fw)))
			if(limb[3] >= 0):
				for one in tws[limb[3]][0]:
					acc[one[0]] -= u.dot(at(one[1], held)) * fw
			emit(rows, acc)
			if(dist > zoneStart(limb)):
				u = (root - end) / max(dist, 1e-12) * zoneOf(limb, r)
				for one in tws[k][arm]:
					acc[one[0]] += u.dot(at(one[1], root) - at(one[1], mine) * (own * (1.0 - fw)))
				if(limb[3] >= 0):
					for one in tws[limb[3]][0]:
						acc[one[0]] -= u.dot(at(one[1], held)) * fw
			emit(rows, acc)
		var off:Vector2 = Vector2(q[3 * k], q[3 * k + 1]) - body["target"] / r
		if(off.length() > 0.0):
			var m:float = wWall * softSlope(off.length() - float(body["most"])) / off.length()
			acc[3 * k] = off.x * m
			acc[3 * k + 1] = off.y * m
		emit(rows, acc)
		if(body.has("turn_most")):
			wallRows(rows, acc, 3 * k + 2, wWall, q[3 * k + 2], float(body["turn_most"]), float(body["L"]) / r)
		if(body.has("tilt_at")):
			wallRows(rows, acc, int(body["tilt_at"]), wWall, tiltOf(body, q), float(body["tilt_most"]), float(body["L"]) / r)
		if(body.has("bridge_at")):
			wallRows(rows, acc, int(body["bridge_at"]), wWall, bridgeOf(body, q), float(body["bridge_most"]), float(body["L"]) / r)
		if(body.has("floor")):
			var fp:Vector2 = moves[k][0].xform(body["pivot"])
			var fs:float = -sqrt(W["feet"]) * softSlope((float(body["floor"]) - fp.y) / r) / r
			for one in tws[k][0]:
				acc[one[0]] += fs * at(one[1], fp).y
			emit(rows, acc)
	return rows

const ZONE := {"share": 0.9, "weight": 10.0}
static func zoneStart(limb:Array) -> float:
	return max(Vector2(limb[0]).distance_to(limb[1]), float(ZONE["share"]) * float(limb[2]))

static func zoneOf(limb:Array, r:float) -> float:
	return sqrt(float(ZONE["weight"])) / max(float(limb[2]) - zoneStart(limb), 0.5 * r)

static func emit(rows:Array, acc:Array) -> void:
	var ix:Array = []
	var vx:Array = []
	for i in range(acc.size()):
		if(acc[i] != 0.0):
			ix.append(i)
			vx.append(acc[i])
			acc[i] = 0.0
	rows.append([ix, vx])

static func wallRows(rows:Array, acc:Array, i:int, w:float, x:float, most:float, scale:float) -> void:
	if(i < acc.size()):
		acc[i] = w * softSlope((x - most) * scale) * scale
	emit(rows, acc)
	if(i < acc.size()):
		acc[i] = -w * softSlope((-x - most) * scale) * scale
	emit(rows, acc)

static func turnsOf(body:Dictionary, k:int, q:Array) -> Array:
	var out:Array = [3 * k + 2]
	for what in ["tilt_at", "bridge_at"]:
		var i:int = int(body.get(what, -1))
		if(i >= 0 && i < q.size()):
			out.append(i)
	return out

static func at(tw:Vector3, p:Vector2) -> Vector2:
	return Vector2(tw.y - tw.x * p.y, tw.z + tw.x * p.x)

static func around(tw:Vector3, angle:float, c:Vector2, dc:Vector2) -> Vector3:
	var w:Vector2 = dc - Vector2(-c.y, c.x) * tw.x
	var v:Vector2 = Vector2(tw.y, tw.z).rotated(angle) + w - w.rotated(angle)
	return Vector3(tw.x, v.x, v.y)

static func twistsOf(body:Dictionary, q:Array, k:int, r:float) -> Array:
	var pivot:Vector2 = body["pivot"]
	var chest:Vector2 = body["chest"]
	var a:float = q[3 * k + 2]
	var pv:Vector2 = pivot + Vector2(q[3 * k], q[3 * k + 1]) * r
	var lumbar:Vector2 = (chest - pivot).rotated(a) + pv
	var neck:Vector2 = (body["neck"] - chest).rotated(FOLLOW * a) + lumbar
	var c:float = bridgeOf(body, q)
	var sx := Vector3(0.0, r, 0.0)
	var sy := Vector3(0.0, 0.0, r)
	var turn := Vector3(1.0, pv.y, -pv.x)
	var dl:Vector2 = at(turn, lumbar)
	var chestTurn := Vector3(FOLLOW, FOLLOW * lumbar.y + dl.x, -FOLLOW * lumbar.x + dl.y)
	var dn:Vector2 = at(chestTurn, neck)
	var bridge := Vector3(1.0, neck.y, -neck.x)
	var pel:Array = [[3 * k, sx], [3 * k + 1, sy], [3 * k + 2, around(turn, c, neck, dn)]]
	var che:Array = [[3 * k, sx], [3 * k + 1, sy], [3 * k + 2, around(chestTurn, c, neck, dn)]]
	var ti:int = int(body.get("tilt_at", -1))
	if(ti >= 0 && ti < q.size()):
		pel.append([ti, around(Vector3(1.0, lumbar.y, -lumbar.x), c, neck, Vector2.ZERO)])
	var bi:int = int(body.get("bridge_at", -1))
	if(bi >= 0 && bi < q.size()):
		pel.append([bi, bridge])
		che.append([bi, bridge])
	return [pel, che]

static func softSlope(x:float) -> float:
	if(x > 20.0 * SOFT):
		return 1.0
	return 1.0 / (1.0 + exp(-x / SOFT))

static func sampledSlope(table:Array, span:float, x:float) -> float:
	if(table.size() == 1 || span <= 0.0):
		return 0.0
	var f:float = (x + span) / (2.0 * span)
	if(f <= 0.0 || f >= 1.0):
		return 0.0
	var i:int = int(min(floor(f * (table.size() - 1)), table.size() - 2))
	return (float(table[i + 1]) - float(table[i])) * (table.size() - 1) / (2.0 * span)

static func moveOf(body:Dictionary, q:Array, k:int, r:float) -> Array:
	var pivot:Vector2 = body["pivot"]
	var chest:Vector2 = body["chest"]
	var a:float = q[3 * k + 2]
	var t := Transform2D(a, pivot + Vector2(q[3 * k], q[3 * k + 1]) * r)
	t.origin -= t.basis_xform(pivot)
	var u := Transform2D(FOLLOW * a, t.xform(chest))
	u.origin -= u.basis_xform(chest)
	var b:float = tiltOf(body, q)
	if(b != 0.0):
		var lumbar:Vector2 = t.xform(chest)
		var tilt := Transform2D(b, lumbar)
		tilt.origin -= tilt.basis_xform(lumbar)
		t = tilt * t
	var c:float = bridgeOf(body, q)
	if(c != 0.0):
		var neck:Vector2 = u.xform(body["neck"])
		var bridge := Transform2D(c, neck)
		bridge.origin -= bridge.basis_xform(neck)
		t = bridge * t
		u = bridge * u
	return [t, u]

static func tiltOf(body:Dictionary, q:Array) -> float:
	var at:int = int(body.get("tilt_at", -1))
	if(at < 0 || at >= q.size()):
		return 0.0
	return float(q[at])

static func bridgeOf(body:Dictionary, q:Array) -> float:
	var at:int = int(body.get("bridge_at", -1))
	if(at < 0 || at >= q.size()):
		return 0.0
	return float(q[at])

static func lineOf(model:Dictionary, q:Array, moves:Array, p:int) -> PoolVector2Array:
	var pair:Dictionary = model["pairs"][p]
	if(moves.empty()):
		for k in range(model["bodies"].size()):
			moves.append(moveOf(model["bodies"][k], q, k, float(model["r"])))
	var base:Vector2 = pair.get("pivot", pair["line"][0])
	var turn := Transform2D(q[3 * model["bodies"].size() + p], base)
	turn.origin -= turn.basis_xform(base)
	var points = pair.get("points")
	if(points == null):
		points = PoolVector2Array(pair["line"])
	return (moves[int(pair["top"])][0] * turn).xform(points)

static func xf(model:Dictionary, q:Array, k:int, p:Vector2) -> Vector2:
	if(k < 0):
		return p
	return moveOf(model["bodies"][k], q, k, float(model["r"]))[0].xform(p)

static func upper(model:Dictionary, q:Array, k:int, p:Vector2) -> Vector2:
	return moveOf(model["bodies"][k], q, k, float(model["r"]))[1].xform(p)

static func endOf(model:Dictionary, q:Array, limb:Array, k:int) -> Vector2:
	var end:Vector2 = limb[1]
	if(limb.size() > 7 && float(limb[7]) > 0.0):
		if(limb[5]):
			end = end.linear_interpolate(upper(model, q, k, end), float(limb[7]))
		else:
			end = end.linear_interpolate(xf(model, q, k, end), float(limb[7]))
	if(int(limb[3]) < 0):
		return end
	return end.linear_interpolate(xf(model, q, int(limb[3]), limb[1]), float(limb[4]))

static func soft(x:float) -> float:
	if(x > 20.0 * SOFT):
		return x
	return SOFT * log(1.0 + exp(x / SOFT))

static func walls(out:Array, w:float, x:float, most:float, scale:float) -> void:
	out.append(w * soft((x - most) * scale))
	out.append(w * soft((-x - most) * scale))

static func sampled(table:Array, span:float, x:float) -> float:
	if(table.size() == 1 || span <= 0.0):
		return float(table[0])
	var f:float = clamp((x + span) / (2.0 * span), 0.0, 1.0) * (table.size() - 1)
	var i:int = int(min(floor(f), table.size() - 2))
	return lerp(float(table[i]), float(table[i + 1]), f - i)

static func missOf(line, h:Vector2) -> Vector2:
	var best:Vector2 = Vector2.ZERO
	var bestD:float = INF
	for i in range(line.size() - 1):
		var c:Vector2 = Geometry.get_closest_point_to_segment_2d(h, line[i], line[i + 1])
		if(c.distance_squared_to(h) < bestD):
			bestD = c.distance_squared_to(h)
			best = h - c
	return best

static func dirOf(line) -> Vector2:
	return (line[line.size() - 1] - line[0]).normalized()

static func dot(a:Array, b:Array) -> float:
	var s := 0.0
	for i in range(a.size()):
		s += a[i] * b[i]
	return s

static func linear(m:Array) -> Array:
	var n:int = m.size()
	for c in range(n):
		var p:int = c
		for i in range(c + 1, n):
			if(abs(m[i][c]) > abs(m[p][c])):
				p = i
		var t = m[c]
		m[c] = m[p]
		m[p] = t
		var mc:Array = m[c]
		if(abs(mc[c]) < 0.0000000001):
			continue
		for i in range(c + 1, n):
			var mi:Array = m[i]
			var f:float = mi[c] / mc[c]
			for j in range(c, n + 1):
				mi[j] -= f * mc[j]
	var x:Array = []
	x.resize(n)
	for i in range(n - 1, -1, -1):
		var mi:Array = m[i]
		var s:float = mi[n]
		for j in range(i + 1, n):
			s -= mi[j] * x[j]
		x[i] = 0.0
		if(abs(mi[i]) >= 0.0000000001):
			x[i] = s / mi[i]
	return x

static func spring(x:float, v:float, goal:float, halflife:float, dt:float) -> Array:
	var y:float = 2.0 * 0.6931471805599453 / max(halflife, 0.00001)
	var j0:float = x - goal
	var j1:float = v + j0 * y
	var e:float = exp(-y * dt)
	return [e * (j0 + j1 * dt) + goal, e * (v - j1 * y * dt)]
