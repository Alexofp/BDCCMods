extends Reference
const META_FIT = "bdccBulgeUVFit"
const OVERRIDE_META = "bulgeOptionOverrides"
const SHAFT_CLIP_SHADER = preload("res://Bulge4/Doll/ShaftClip.shader")
static func getUVFit(mesh:Mesh):
	if(mesh == null):
		return null
	if(mesh.has_meta(META_FIT)):
		var cached = mesh.get_meta(META_FIT)
		if(cached is Dictionary):
			return cached
		return null
	var fit = calculateUVFit(mesh)
	if(fit == null):
		mesh.set_meta(META_FIT, false)
	else:
		mesh.set_meta(META_FIT, fit)
	return fit
static func calculateUVFit(mesh:Mesh):
	if(mesh.get_surface_count() <= 0):
		return null
	var arrays:Array = mesh.surface_get_arrays(0)
	if(arrays.size() <= Mesh.ARRAY_TEX_UV):
		return null
	var verts = arrays[Mesh.ARRAY_VERTEX]
	var uvs = arrays[Mesh.ARRAY_TEX_UV]
	if(verts == null || uvs == null || verts.size() < 3 || uvs.size() != verts.size()):
		return null
	var A := [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
	var bu := [0.0, 0.0, 0.0]
	var bv := [0.0, 0.0, 0.0]
	var restMin := Vector2(99999.0, 99999.0)
	var restMax := Vector2(-99999.0, -99999.0)
	for i in range(verts.size()):
		var vert:Vector3 = verts[i]
		var uv:Vector2 = uvs[i]
		var p := [vert.x, vert.y, 1.0]
		for r in range(3):
			for c in range(3):
				A[r][c] += p[r] * p[c]
			bu[r] += p[r] * uv.x
			bv[r] += p[r] * uv.y
		restMin.x = min(restMin.x, vert.x)
		restMin.y = min(restMin.y, vert.y)
		restMax.x = max(restMax.x, vert.x)
		restMax.y = max(restMax.y, vert.y)
	var mu = solve3(A, bu)
	var mv = solve3(A, bv)
	if(mu == null || mv == null):
		return null
	var rowU := Vector3(mu[0], mu[1], mu[2])
	var rowV := Vector3(mv[0], mv[1], mv[2])
	var maxError := 0.0
	for i in range(verts.size()):
		var vert:Vector3 = verts[i]
		var predicted := Vector2(
			rowU.x * vert.x + rowU.y * vert.y + rowU.z,
			rowV.x * vert.x + rowV.y * vert.y + rowV.z)
		maxError = max(maxError, predicted.distance_to(uvs[i]))
	var scaleU:float = abs(rowU.x)
	var scaleV:float = abs(rowV.y)
	if(scaleU < 0.000001 || scaleV < 0.000001):
		return null
	return {
		"u": rowU,
		"v": rowV,
		"aspect": Vector2(1.0 / scaleU, 1.0 / scaleV),
		"restMin": restMin,
		"restMax": restMax,
		"error": maxError,
	}
static func restToUV(fit:Dictionary, restPos:Vector2) -> Vector2:
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	return Vector2(
		rowU.x * restPos.x + rowU.y * restPos.y + rowU.z,
		rowV.x * restPos.x + rowV.y * restPos.y + rowV.z)
const BULGE_SLOTS := 3
const SHAPE_TRANSPORT := 7
static func solve3(A:Array, b:Array):
	var m := [
		[A[0][0], A[0][1], A[0][2], b[0]],
		[A[1][0], A[1][1], A[1][2], b[1]],
		[A[2][0], A[2][1], A[2][2], b[2]],
	]
	for col in range(3):
		var pivot := col
		for r in range(col + 1, 3):
			if(abs(m[r][col]) > abs(m[pivot][col])):
				pivot = r
		var swap = m[col]
		m[col] = m[pivot]
		m[pivot] = swap
		var diag:float = m[col][col]
		if(abs(diag) < 0.000000001):
			return null
		for c in range(col, 4):
			m[col][c] /= diag
		for r in range(3):
			if(r == col):
				continue
			var factor:float = m[r][col]
			for c in range(col, 4):
				m[r][c] -= factor * m[col][c]
	return [m[0][3], m[1][3], m[2][3]]
static func getBoneRestGlobal(skeleton:Skeleton, boneIdx:int) -> Transform:
	var result := Transform.IDENTITY
	if(boneIdx < 0):
		return result
	var chain := []
	var idx := boneIdx
	while(idx >= 0):
		chain.append(skeleton.get_bone_rest(idx))
		idx = skeleton.get_bone_parent(idx)
	chain.invert()
	for restTransform in chain:
		result = result * restTransform
	return result
static func worldToRest(skeleton:Skeleton, boneName:String, worldPos:Vector3) -> Vector3:
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return worldPos
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	var boneLocal:Vector3 = posedGlobal.affine_inverse().xform(worldPos)
	return getBoneRestGlobal(skeleton, boneIdx).xform(boneLocal)
static func restDirToWorld(skeleton:Skeleton, boneName:String, restDir:Vector3) -> Vector3:
	var boneIdx:int = skeleton.find_bone(boneName)
	if(boneIdx < 0):
		return restDir
	var boneLocal:Vector3 = getBoneRestGlobal(skeleton, boneIdx).affine_inverse().basis.xform(restDir)
	var posedGlobal:Transform = skeleton.global_transform * skeleton.get_bone_global_pose(boneIdx)
	return posedGlobal.basis.xform(boneLocal).normalized()
const PROFILE_BINS:int = 64
const PROFILE_SAMPLES:int = 256
const PROFILE_ALPHA:float = 0.35
const PROFILE_SKIP_BASE:float = 0.3
const PROFILE_COLUMNS:int = 48
const CLIFF_RATIO:float = 1.35
const CLIFF_LIMIT:float = 0.45
const CLIFF_COLUMNS:int = 96
const FIT_KEYS:Array = ["bulgeShaftProfile", "bulgeShaftGirth", "bulgeShaftSkip", "bulgeShaftEdges", "bulgeShaftSpan",
	"bulgeBallsEnd", "bulgeFrontMargin", "bulgeFrontContour3"]
static func fitCacheOf(meshInstance) -> Texture:
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null):
		return null
	var key:int = 0
	if(meshInstance.mesh != null):
		key = meshInstance.mesh.get_instance_id()
	if(!texture.has_meta("bulgeFitMesh") || texture.get_meta("bulgeFitMesh") != key):
		for name in FIT_KEYS:
			if(texture.has_meta(name)):
				texture.remove_meta(name)
		texture.set_meta("bulgeFitMesh", key)
	return texture
static func getShaftProfile(meshInstance) -> Array:
	if(meshInstance == null || fitOf(meshInstance) == null):
		return []
	var texture:Texture = fitCacheOf(meshInstance)
	if(texture == null):
		return []
	if(texture.has_meta("bulgeShaftProfile")):
		return texture.get_meta("bulgeShaftProfile")
	var image:Image = texture.get_data()
	if(image == null):
		texture.set_meta("bulgeShaftProfile", [])
		texture.set_meta("bulgeShaftGirth", 0.0)
		texture.set_meta("bulgeShaftSkip", PROFILE_SKIP_BASE)
		texture.set_meta("bulgeShaftEdges", [[], []])
		return []
	var fit:Dictionary = fitOf(meshInstance)
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var width:int = image.get_width()
	var height:int = image.get_height()
	image.lock()
	var drawnBase:float = restMax.x
	var drawnTip:float = restMin.x
	var found:bool = false
	for column in range(PROFILE_COLUMNS):
		var x:float = lerp(restMax.x, restMin.x, (column + 0.5) / float(PROFILE_COLUMNS))
		if(columnThickness(image, fit, x, restMin.y, restMax.y, width, height) <= 0.0):
			continue
		if(!found):
			drawnBase = x
			found = true
		drawnTip = x
	if(!found):
		image.unlock()
		texture.set_meta("bulgeShaftProfile", [])
		texture.set_meta("bulgeShaftGirth", 0.0)
		texture.set_meta("bulgeShaftSkip", PROFILE_SKIP_BASE)
		texture.set_meta("bulgeShaftEdges", [[], []])
		return []
	var skip:float = findBallsCliff(image, fit, drawnBase, drawnTip, restMin.y, restMax.y, width, height)
	var ballsFound:bool = skip >= 0.0
	if(!ballsFound):
		skip = PROFILE_SKIP_BASE
	var profile:Array = []
	var extents:Array = []
	for bin in range(PROFILE_BINS):
		var t:float = skip + (1.0 - skip) * (bin + 0.5) / float(PROFILE_BINS)
		var x:float = lerp(drawnBase, drawnTip, t)
		var extent:Vector2 = columnExtent(image, fit, x, restMin.y, restMax.y, width, height)
		extents.append(extent)
		profile.append(max(extent.y - extent.x, 0.0) * 0.5)
	image.unlock()
	var total:float = 0.0
	for value in profile:
		total += value
	var mean:float = total / float(max(profile.size(), 1))
	if(mean <= 0.0001):
		texture.set_meta("bulgeShaftProfile", [])
		texture.set_meta("bulgeShaftGirth", 0.0)
		texture.set_meta("bulgeShaftSkip", PROFILE_SKIP_BASE)
		texture.set_meta("bulgeShaftEdges", [[], []])
		return []
	texture.set_meta("bulgeShaftGirth", mean)
	texture.set_meta("bulgeShaftSpan", Vector2(drawnBase, drawnTip))
	texture.set_meta("bulgeShaftSkip", skip)
	if(ballsFound):
		texture.set_meta("bulgeBallsEnd", lerp(drawnBase, drawnTip, skip))
	for i in range(profile.size()):
		profile[i] = profile[i] / mean
	texture.set_meta("bulgeShaftEdges", edgesOf(extents, mean))
	texture.set_meta("bulgeShaftProfile", profile)
	return profile
static func edgesOf(extents:Array, mean:float) -> Array:
	var n:float = 0.0
	var sx:float = 0.0
	var sy:float = 0.0
	var sxx:float = 0.0
	var sxy:float = 0.0
	for i in range(extents.size()):
		var e:Vector2 = extents[i]
		if(e.y - e.x <= 0.0):
			continue
		var mid:float = (e.x + e.y) * 0.5
		n += 1.0
		sx += i
		sy += mid
		sxx += i * i
		sxy += i * mid
	var up:Array = []
	var down:Array = []
	if(n < 2.0 || mean <= 0.0001):
		return [up, down]
	var slope:float = (n * sxy - sx * sy) / max(n * sxx - sx * sx, 0.000001)
	var offset:float = (sy - slope * sx) / n
	for i in range(extents.size()):
		var e:Vector2 = extents[i]
		if(e.y - e.x <= 0.0):
			up.append(0.0)
			down.append(0.0)
			continue
		var axis:float = offset + slope * i
		up.append(max(e.y - axis, 0.0) / mean)
		down.append(max(axis - e.x, 0.0) / mean)
	return [up, down]
static func getShaftEdges(meshInstance) -> Array:
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeShaftEdges")):
		return [[], []]
	return texture.get_meta("bulgeShaftEdges")
static func columnExtent(image:Image, fit:Dictionary, x:float, minY:float, maxY:float, width:int, height:int) -> Vector2:
	var lowest:float = 0.0
	var highest:float = 0.0
	var found:bool = false
	var rowU:Vector3 = fit["u"]
	var rowV:Vector3 = fit["v"]
	for sample in range(PROFILE_SAMPLES):
		var y:float = lerp(minY, maxY, (sample + 0.5) / float(PROFILE_SAMPLES))
		var restPos := Vector2(x, y)
		var uv := Vector2(
			rowU.x * restPos.x + rowU.y * restPos.y + rowU.z,
			rowV.x * restPos.x + rowV.y * restPos.y + rowV.z)
		if(uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0):
			continue
		var px:int = int(clamp(uv.x * width, 0, width - 1))
		var py:int = int(clamp(uv.y * height, 0, height - 1))
		if(image.get_pixel(px, py).a >= PROFILE_ALPHA):
			if(!found):
				lowest = y
				found = true
			highest = y
	if(!found):
		return Vector2.ZERO
	var half:float = 0.5 * (maxY - minY) / float(PROFILE_SAMPLES)
	return Vector2(lowest - half, highest + half)
static func getShaftSkip(meshInstance) -> float:
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeShaftSkip")):
		return PROFILE_SKIP_BASE
	return float(texture.get_meta("bulgeShaftSkip"))
static func findBallsCliff(image:Image, fit:Dictionary, drawnBase:float, drawnTip:float,
		minY:float, maxY:float, width:int, height:int) -> float:
	var previous:float = -1.0
	var bestDrop:float = 0.0
	var bestT:float = -1.0
	for column in range(CLIFF_COLUMNS):
		var t:float = CLIFF_LIMIT * (column + 0.5) / float(CLIFF_COLUMNS)
		var here:float = columnThickness(image, fit, lerp(drawnBase, drawnTip, t), minY, maxY, width, height)
		if(here <= 0.0):
			previous = -1.0
			continue
		if(previous > 0.0 && previous - here > bestDrop && previous / here >= CLIFF_RATIO):
			bestDrop = previous - here
			bestT = t
		previous = here
	return bestT
static func getBallsEnd(meshInstance):
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeBallsEnd")):
		return null
	return float(texture.get_meta("bulgeBallsEnd"))
static func getShaftGirth(meshInstance) -> float:
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeShaftGirth")):
		return 0.0
	return texture.get_meta("bulgeShaftGirth")
static func getAlbedoImage(meshInstance):
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null):
		return null
	return texture.get_data()
static func getAlbedoTexture(meshInstance):
	var texture:Texture = meshInstance.get("customAlbedo")
	if(texture == null):
		for material in [meshInstance.material_override, meshInstance.get_surface_material(0)]:
			if(material == null):
				continue
			if(material is ShaderMaterial):
				texture = material.get_shader_param("texture_albedo")
			elif(material is SpatialMaterial):
				texture = material.albedo_texture
			if(texture != null):
				break
	return texture
const MASK_SIZE:int = 64
const MASK_ALPHA:float = 0.35
static func getAlphaMask(meshInstance):
	if(meshInstance == null || fitOf(meshInstance) == null):
		return null
	var cacheOn:Texture = getAlbedoTexture(meshInstance)
	if(cacheOn == null):
		return null
	if(cacheOn.has_meta("bulgeAlphaMask")):
		var cached = cacheOn.get_meta("bulgeAlphaMask")
		if(cached is Dictionary):
			return cached
		return null
	var image:Image = getAlbedoImage(meshInstance)
	if(image == null):
		cacheOn.set_meta("bulgeAlphaMask", false)
		return null
	var width:int = image.get_width()
	var height:int = image.get_height()
	image.lock()
	var bits:PoolByteArray = PoolByteArray()
	for y in range(MASK_SIZE):
		var py:int = int(clamp((y + 0.5) / MASK_SIZE * height, 0, height - 1))
		for x in range(MASK_SIZE):
			var px:int = int(clamp((x + 0.5) / MASK_SIZE * width, 0, width - 1))
			if(image.get_pixel(px, py).a >= MASK_ALPHA):
				bits.append(1)
			else:
				bits.append(0)
	image.unlock()
	var mask:Dictionary = {"size": MASK_SIZE, "bits": bits}
	cacheOn.set_meta("bulgeAlphaMask", mask)
	return mask
static func isRestPointOpaque(meshInstance, restPos:Vector2) -> bool:
	var mask = getAlphaMask(meshInstance)
	if(mask == null):
		return true
	var uv:Vector2 = restToUV(fitOf(meshInstance), restPos)
	if(uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0):
		return false
	var size:int = mask["size"]
	var x:int = int(clamp(uv.x * size, 0, size - 1))
	var y:int = int(clamp(uv.y * size, 0, size - 1))
	var bits:PoolByteArray = mask["bits"]
	return bits[y * size + x] != 0
const MARGIN_ROWS:int = 24
static func getFrontMargin(meshInstance) -> float:
	if(meshInstance == null || fitOf(meshInstance) == null):
		return 0.0
	var cacheOn:Texture = fitCacheOf(meshInstance)
	if(cacheOn == null):
		return 0.0
	if(cacheOn.has_meta("bulgeFrontMargin")):
		return cacheOn.get_meta("bulgeFrontMargin")
	if(getAlphaMask(meshInstance) == null):
		return 0.0
	var fit:Dictionary = fitOf(meshInstance)
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var steps:int = 40
	var margins:Array = []
	for row in range(MARGIN_ROWS):
		var y:float = lerp(restMin.y, restMax.y, (row + 0.5) / float(MARGIN_ROWS))
		for step in range(steps + 1):
			var x:float = lerp(restMin.x, restMax.x, float(step) / float(steps))
			if(isRestPointOpaque(meshInstance, Vector2(x, y))):
				margins.append(x - restMin.x)
				break
	if(margins.empty()):
		cacheOn.set_meta("bulgeFrontMargin", 0.0)
		return 0.0
	margins.sort()
	var margin:float = margins[int(margins.size() / 2)]
	cacheOn.set_meta("bulgeFrontMargin", margin)
	return margin
const CONTOUR_ROWS:int = 96
const CONTOUR_STEPS:int = 80
const CONTOUR_REFINE:int = 8
static func opaqueIn(image:Image, fit:Dictionary, restPos:Vector2) -> bool:
	var uv:Vector2 = restToUV(fit, restPos)
	if(uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0):
		return false
	var px:int = int(clamp(uv.x * image.get_width(), 0, image.get_width() - 1))
	var py:int = int(clamp(uv.y * image.get_height(), 0, image.get_height() - 1))
	return image.get_pixel(px, py).a >= MASK_ALPHA
static func getFrontContour(meshInstance) -> Array:
	if(meshInstance == null || fitOf(meshInstance) == null):
		return []
	var cacheOn:Texture = fitCacheOf(meshInstance)
	if(cacheOn == null):
		return []
	if(cacheOn.has_meta("bulgeFrontContour3")):
		var cached = cacheOn.get_meta("bulgeFrontContour3")
		if(cached is Array):
			return cached
		return []
	var image:Image = getAlbedoImage(meshInstance)
	if(image == null || image.is_compressed()):
		cacheOn.set_meta("bulgeFrontContour3", [])
		return []
	var fit:Dictionary = fitOf(meshInstance)
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	image.lock()
	var rows:Array = []
	var stepWidth:float = (restMax.x - restMin.x) / float(CONTOUR_STEPS)
	for row in range(CONTOUR_ROWS):
		var y:float = lerp(restMin.y, restMax.y, (row + 0.5) / float(CONTOUR_ROWS))
		for step in range(CONTOUR_STEPS + 1):
			var x:float = restMin.x + stepWidth * float(step)
			if(opaqueIn(image, fit, Vector2(x, y))):
				var clear:float = x - stepWidth
				if(step > 0):
					for _i in range(CONTOUR_REFINE):
						var mid:float = (clear + x) * 0.5
						if(opaqueIn(image, fit, Vector2(mid, y))):
							x = mid
						else:
							clear = mid
				rows.append(Vector3(y, x, x - restMin.x))
				break
	image.unlock()
	cacheOn.set_meta("bulgeFrontContour3", rows)
	return rows
static func getShaftSpan(meshInstance) -> Vector2:
	var _profile = getShaftProfile(meshInstance)
	var texture:Texture = getAlbedoTexture(meshInstance)
	if(texture == null || !texture.has_meta("bulgeShaftSpan")):
		return Vector2.ZERO
	return texture.get_meta("bulgeShaftSpan")
static func columnThickness(image:Image, fit:Dictionary, x:float, minY:float, maxY:float, width:int, height:int) -> float:
	var extent:Vector2 = columnExtent(image, fit, x, minY, maxY, width, height)
	return max(extent.y - extent.x, 0.0)
static func fitOf(meshInstance):
	if(meshInstance == null):
		return null
	var own = meshInstance.get("uvFit")
	if(own != null):
		return own
	return getUVFit(meshInstance.mesh)
static func setPlainShaftClip(meshInstance, restX:float, feather:float = 0.006, cut:Array = []) -> void:
	var fit = fitOf(meshInstance)
	if(fit == null):
		return
	var restMin:Vector2 = fit["restMin"]
	if(restX <= restMin.x):
		clearPlainShaftClip(meshInstance)
		return
	var material:ShaderMaterial = getPlainClipMaterial(meshInstance)
	if(material == null):
		return
	var ballsX = null
	if(cut.size() == 2):
		ballsX = getBallsEnd(meshInstance)
	setClipParams(material, fit, restX, feather, cut, ballsX)
const CLIP_SLOPE_MOST := 2.0
static func setClipParams(material:ShaderMaterial, fit:Dictionary, restX:float, feather:float, cut:Array, ballsX = null) -> void:
	var restMin:Vector2 = fit["restMin"]
	var restMax:Vector2 = fit["restMax"]
	var at:Vector2 = Vector2(restX, (restMin.y + restMax.y) * 0.5)
	if(cut.size() == 2):
		at = cut[0]
	var clipUV:Vector2 = restToUV(fit, at)
	var rowU:Vector3 = fit["u"]
	var dir:float = 1.0
	if(rowU.x >= 0.0):
		dir = -1.0
	var slope:float = 0.0
	if(cut.size() == 2):
		var along:Vector2 = restToUV(fit, at + cut[1]) - clipUV
		if(abs(along.y) > 0.000001):
			slope = clipSlope(-along.x * dir / along.y)
	var keep:float = 2.0
	if(cut.size() == 2 && ballsX != null):
		keep = restToUV(fit, Vector2(float(ballsX), at.y)).x
	material.set_shader_param("shaft_clip", clipUV.x)
	material.set_shader_param("shaft_clip_v", clipUV.y)
	material.set_shader_param("shaft_clip_slope", slope)
	material.set_shader_param("shaft_clip_dir", dir)
	material.set_shader_param("shaft_clip_feather", feather * sqrt(1.0 + slope * slope))
	material.set_shader_param("shaft_clip_keep", keep)
static func clipSlope(s:float) -> float:
	return s / (1.0 + pow(s / CLIP_SLOPE_MOST, 4))
static func clearPlainShaftClip(meshInstance) -> void:
	if(meshInstance == null || !is_instance_valid(meshInstance)):
		return
	if(isPlainClipMaterial(meshInstance.material_override)):
		var source = plainSource(meshInstance)
		if(source != null):
			source.render_priority = meshInstance.material_override.render_priority
		meshInstance.material_override = null
static func isPlainClipMaterial(material) -> bool:
	return material is ShaderMaterial && material.shader == SHAFT_CLIP_SHADER
static func plainSource(meshInstance):
	var source = meshInstance.get_surface_material(0)
	if(source == null && meshInstance.mesh != null && meshInstance.mesh.get_surface_count() > 0):
		source = meshInstance.mesh.surface_get_material(0)
	if(!(source is SpatialMaterial)):
		return null
	return source
static func getPlainClipMaterial(meshInstance):
	var source = plainSource(meshInstance)
	if(source == null):
		return null
	var material = meshInstance.material_override
	if(!isPlainClipMaterial(material)):
		material = ShaderMaterial.new()
		material.shader = SHAFT_CLIP_SHADER
		material.render_priority = source.render_priority
		meshInstance.material_override = material
	elif(material.render_priority != source.render_priority):
		source.render_priority = material.render_priority
	material.set_shader_param("texture_albedo", source.albedo_texture)
	material.set_shader_param("albedo", source.albedo_color)
	return material
static func option(optionName:String, fallback):
	if(Engine.has_meta(OVERRIDE_META)):
		var overrides:Dictionary = Engine.get_meta(OVERRIDE_META)
		if(overrides.has(optionName)):
			return overrides[optionName]
	if(OPTIONS == null || !(optionName in OPTIONS)):
		return fallback
	return OPTIONS.get(optionName)
static func engineFor(doll):
	if(doll == null || !is_instance_valid(doll) || !doll.has_method("getCharacterID")):
		return null
	var charID = doll.getCharacterID()
	if(!(charID is String) || charID == ""):
		return null
	if(GM == null || GM.main == null || !GM.main.has_method("getSexEngineForCharacterID")):
		return null
	return GM.main.getSexEngineForCharacterID(charID)
