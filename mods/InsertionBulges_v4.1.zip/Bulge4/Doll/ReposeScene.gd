extends Reference
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const BulgeUtils := preload("res://Bulge4/Doll/BulgeUtils.gd")
const Repose := preload("res://Bulge4/Doll/Repose.gd")
const ReposeSolve := preload("res://Bulge4/Doll/ReposeSolve.gd")
const BodyDeform := preload("res://Bulge4/Effects/Detailed/Lab/BodyDeform.gd")
const StrokeSplit := preload("res://Bulge4/Doll/StrokeSplit.gd")
const BENCH := {}

const FIT := {"turn": 0.6, "step": 0.05}
const STROKE := {"span": 1.5, "across": 0.34}
static func thrustOf(state:Dictionary, key:String, cock:Vector2, r:float) -> Vector2:
	var was = state.get("stroke", {}).get(key)
	if(was == null || cock == Vector2.ZERO):
		return cock
	var spread:Vector3 = was[1]
	var sum:float = spread.x + spread.z
	if(sum <= 0.0):
		return cock
	var axis:Vector2 = Vector2(1.0, 0.0).rotated(0.5 * atan2(2.0 * spread.y, spread.x - spread.z))
	var c:float = axis.dot(cock.normalized())
	if(c < 0.0):
		axis = -axis
	var still:float = float(MOVER["still"]) * r
	return cock.rotated(cock.angle_to(axis) * smoothstep(still, 2.0 * still, sqrt(sum)) * smoothstep(0.0, float(STROKE["across"]), abs(c)))

static func strokeTurned(state:Dictionary, key:String, p:Vector2, u:Vector2, now:float) -> Vector2:
	if(!state.has("stroke")):
		state["stroke"] = {}
	var was = state["stroke"].get(key)
	if(was == null || now - float(was[2]) > GAP || now < float(was[2])):
		was = [p, Vector3.ZERO, now, now]
	var k:float = 1.0 - exp(-(now - float(was[2])) / float(STROKE["span"]))
	var centre:Vector2 = was[0].linear_interpolate(p, k)
	var d:Vector2 = p - centre
	var spread:Vector3 = was[1].linear_interpolate(Vector3(d.x * d.x, d.x * d.y, d.y * d.y), k)
	state["stroke"][key] = [centre, spread, now, was[3]]
	var sum:float = spread.x + spread.z
	if(sum <= 0.0):
		return Vector2.ZERO
	var axis:Vector2 = Vector2(1.0, 0.0).rotated(0.5 * atan2(2.0 * spread.y, spread.x - spread.z))
	var gap:float = sqrt(pow(spread.x - spread.z, 2) + 4.0 * spread.y * spread.y)
	var c:float = axis.dot(u)
	if(c < 0.0):
		axis = -axis
	return (d.rotated(axis.angle_to(u)) - d) * (gap / sum) * smoothstep(0.0, float(STROKE["across"]), abs(c))

const MOVER := {"span": 1.5, "still": 0.15, "least": 0.01}
static func moverOf(state:Dictionary, key:String, top:Vector2, bottom:Vector2, r:float, now:float) -> Array:
	if(!state.has("mover")):
		state["mover"] = {}
	var was = state["mover"].get(key)
	if(was == null || now - float(was[4]) > GAP || now < float(was[4])):
		was = [top, bottom, 0.0, 0.0, now, 0.0]
	var k:float = 1.0 - exp(-(now - float(was[4])) / float(MOVER["span"]))
	var mt:Vector2 = was[0].linear_interpolate(top, k)
	var mb:Vector2 = was[1].linear_interpolate(bottom, k)
	var rel:Vector2 = (top - mt) - (bottom - mb)
	var cov:float = lerp(float(was[2]), -(bottom - mb).dot(rel), k)
	var spread:float = lerp(float(was[3]), rel.length_squared(), k)
	var seen:float = float(was[5]) + now - float(was[4])
	state["mover"][key] = [mt, mb, cov, spread, now, seen]
	var still:float = float(MOVER["still"]) * r
	var sure:float = smoothstep(still, 2.0 * still, sqrt(spread)) * min(seen / float(MOVER["span"]), 1.0)
	if(spread <= 0.0):
		return [0.0, 0.0, rel]
	return [clamp(cov / spread, 0.0, 1.0), sure, rel]

static func dirNear(line:Array, h:Vector2) -> Vector2:
	var shortest:float = INF
	var near:float = INF
	var gaps:Array = []
	for i in range(line.size() - 1):
		gaps.append(h.distance_squared_to(Geometry.get_closest_point_to_segment_2d(h, line[i], line[i + 1])))
		if(line[i] != line[i + 1]):
			shortest = min(shortest, line[i].distance_to(line[i + 1]))
			near = min(near, gaps[i])
	if(shortest == INF):
		return (line[line.size() - 1] - line[0]).normalized()
	var width:float = pow(0.5 * BulgeDoll.JOINT_BLEND * shortest, 2)
	var sum:Vector2 = Vector2.ZERO
	for i in range(line.size() - 1):
		if(line[i] != line[i + 1]):
			sum += (line[i + 1] - line[i]).normalized() * exp(-(gaps[i] - near) / width)
	return sum.normalized()

const REPOSE := {"most": 6.0, "turn": 0.3, "top_turn": 0.6, "entry": 0.5, "way_most": 0.8, "halflife": 0.08, "held": 0.3, "free": 0.6, "slow": 0.5}

const ENTRY := {"in": 2.0, "corner": 45.0, "band": 10.0, "join": 6.0, "window": 1.0}
static func entryLine(lane:Array, h:Vector2, r:float) -> Vector2:
	if(lane.size() < 2):
		return Vector2.ZERO
	var cum:Array = BodyDeform._cumulative_open(lane)
	var g0:float = BodyDeform._project(lane, cum, h)
	var none:float = 1.0
	var sum:Vector2 = Vector2.ZERO
	var s:float = g0 + float(ENTRY["window"]) * r
	while(s < g0 + float(ENTRY["join"]) * r && s + float(ENTRY["window"]) * r < float(cum[lane.size() - 1]) && none > 0.0001):
		var here:Vector2 = BodyDeform._guide_at(lane, cum, s)
		var before:Vector2 = here - BodyDeform._guide_at(lane, cum, s - float(ENTRY["window"]) * r)
		var after:Vector2 = BodyDeform._guide_at(lane, cum, s + float(ENTRY["window"]) * r) - here
		var c:float = smoothstep(float(ENTRY["corner"]) - float(ENTRY["band"]), float(ENTRY["corner"]) + float(ENTRY["band"]), abs(rad2deg(before.angle_to(after))))
		if(c > 0.0):
			sum += (BodyDeform._guide_at(lane, cum, s + float(ENTRY["in"]) * r) - here).normalized() * none * c
			none *= 1.0 - c
		s += 0.25 * r
	sum += (BodyDeform._guide_at(lane, cum, g0 + float(ENTRY["in"]) * r) - h).normalized() * none
	return sum.normalized()

const AIM := {"share": 0.15}
static func aimOf(got:Dictionary, h:Vector2, radius:float, deep:float, opts:Dictionary, along:Vector2 = Vector2.ZERO) -> Vector2:
	if(got.empty()):
		return Vector2.ZERO
	var lane:Array = got["lane"]
	var cum:Array = BodyDeform._cumulative_open(lane)
	var share:float = float(BENCH.get("aim_share", AIM["share"]))
	var way:Vector2 = BodyDeform._guide_at(lane, cum, BodyDeform._project(lane, cum, h) + share * max(deep, 2.0) * radius) - h
	var tilt:float = float(REPOSE["entry"]) * clamp(float(opts.get("repose_entry", 0.0)), 0.0, 1.0)
	if(tilt > 0.0 && got["belly"] != Vector2.ZERO):
		way = way.rotated(sign(way.cross(got["belly"])) * tilt)
	way = way.normalized()
	if(along != Vector2.ZERO):
		way = along.rotated(clamp(along.angle_to(way), -float(REPOSE["way_most"]), float(REPOSE["way_most"])))
	return way

static func laneFit(lane:Array, start:Vector2, dir:Vector2, length:float, r:float, toward:float) -> float:
	var cum:Array = BodyDeform._cumulative_open(lane)
	var g0:float = BodyDeform._project(lane, cum, start)
	var a:Array = BodyDeform._arc_to(start, dir, length, lane, cum, g0, r, toward)
	return sqrt(float(BodyDeform._arc_res(start, dir, length, lane, cum, g0, r, a)[0]) / float(BodyDeform.CANAL["points"]))

const GAP := 0.5
const HELD := {"scenes": ["SexVent", "SexOverTable", "SexAgainstWall", "SexPinnedBehind", "MilkingProstateFuck"]}
static func heldIn(opts:Dictionary) -> bool:
	return int(BENCH.get("held", 1)) != 0 && HELD["scenes"].has(str(opts.get("action", "")).get_file().split(".")[0])

static func reposeAll(state:Dictionary, shafts:Array, holeHelper, opts:Dictionary, alone:bool, reader) -> Array:
	var tp:int = OS.get_ticks_usec()
	state.erase("base_turn")
	if(!bool(opts.get("repose", false))):
		state.erase("repose_drawn_b")
		return []
	var calm:Dictionary = Repose.CHEST_CALM
	calm["on"] = opts.has("stroke_chest")
	var bottomSkel:Skeleton = holeHelper.getSkeletonNode()
	if(bottomSkel == null):
		state.erase("repose_drawn_b")
		return []
	var atB:Dictionary = Repose.animated(bottomSkel)
	var straight:bool = bool(opts.get("straight", true))
	var thrusted:Array = []
	var tops:Array = []
	for one in shafts:
		var helper = one[0]
		if(typeof(helper) == TYPE_DICTIONARY || !one[2].empty() || helper == null || !is_instance_valid(helper) || bool(one[1])):
			continue
		var skel:Skeleton = helper.getSkeletonNode()
		var shaft = helper.getShaftInfo()
		if(skel == null || shaft == null):
			continue
		var at:Dictionary = Repose.animated(skel)
		var hole = reader.holeAt(holeHelper, str(one[3]))
		var chain = helper.shaftChainOf()
		if(at.empty() || chain == null || hole == null):
			continue
		var line:Array = cockLine(chain, shaft)
		var full:float = max(line[0].distance_to(line[1]) + line[1].distance_to(line[2]), float(shaft["length"]))
		var pivot:Vector2 = line[0]
		var way:Vector2 = (line[line.size() - 1] - line[0]).normalized()
		var entering:Vector2 = dirNear(line, Vector2(hole.x, hole.y))
		if(straight):
			line = straightOf(skel, chain, line, float(shaft["radius"]))
		tops.append([helper, skel, at, line, Vector2(hole.x, hole.y), str(one[4]), float(shaft["radius"]), chain,
			str(one[3]), pivot, way, entering, full])
	if(tops.empty()):
		state.erase("repose_drawn_b")
		return []
	tp = lap("h.read", tp)
	var t:float = float(opts.get("now", 0.0))
	var share:float = clamp(float(opts.get("repose_bottom", 0.5)), 0.0, 1.0)
	var withB:bool = alone && share > 0.0 && !atB.empty() && !heldIn(opts)
	var fit:float = clamp(float(opts.get("fit", 0.0)), 0.0, 1.0)
	var strokeDir:float = clamp(float(opts.get("stroke_dir", 0.0)), 0.0, 1.0)
	var thrust:float = clamp(float(opts.get("thrust", 1.0)), 0.0, 1.0)
	var tq:Array = []
	var r:float = 0.0
	var floor_y:float = INF
	if(!atB.empty()):
		floor_y = Repose.lowestFoot(atB)
	var keys:Array = []
	for top in tops:
		keys.append(top[5])
	if(withB):
		keys.append("bottom")
	var n:int = 5 * keys.size() + tops.size()
	var was:Dictionary = state.get("repose", {})
	var fresh:bool = false
	if(was.get("keys", []) != keys || t - float(was.get("when", -INF)) > GAP || t < float(was["when"])):
		fresh = true
		var zero:Array = []
		for _i in range(n):
			zero.append(0.0)
		was = {"goal": zero, "x": zero, "v": zero, "when": t}
		state["repose_w"] = 0.0
		for k in range(tops.size()):
			state.erase("turn_mean/" + str(k))
		state.erase("turn_free")
		state.erase("regrip")
		state.erase("regrip_line")
		Repose.forget(bottomSkel)
		for top in tops:
			Repose.forget(top[1])
	var fade:float = float(state.get("repose_w", 0.0))
	if(t > float(was["when"])):
		fade = min(fade + (t - float(was["when"])) / float(STRAIGHT["fade"]), 1.0)
	state["repose_w"] = fade
	var ats:Array = []
	var bodies:Array = []
	var pairs:Array = []
	var uMean:Vector2 = Vector2.ZERO
	var shareB:float = 0.0
	var shares:Array = []
	var pushB:Vector2 = Vector2.ZERO
	for ti in range(tops.size()):
		var top:Array = tops[ti]
		r += float(top[6]) / float(tops.size())
		floor_y = min(floor_y, Repose.lowestFoot(top[2]))
		var u:Vector2 = dirNear(top[3], top[4])
		uMean += u
		var target:Vector2 = Vector2.ZERO
		var length:float = lengthOf(top[3])
		var way:Vector2 = reader.wayOf(holeHelper, state, str(top[8]), top[4], float(top[6]), length / float(top[6]), opts,
			ReposeSolve.dirOf(top[3]))
		var deeper:float = 0.0
		thrusted.append(false)
		var _base:Vector2 = strokeTurned(state, "line/" + str(top[5]), top[9] - top[4], top[11], t)
		var line:Vector2 = reader.thrustOf(holeHelper, state, str(top[8]), top[4])
		if(line == Vector2.ZERO && top[11] != Vector2.ZERO):
			var learnt:Vector2 = thrustOf(state, "line/" + str(top[5]), top[11], float(top[6]))
			line = top[11].rotated(top[11].angle_to(learnt) * min((t - float(state["stroke"]["line/" + str(top[5])][3])) / float(STROKE["span"]), 1.0))
		var lineTurn:float = 0.0
		if(!state.has("repose_way")):
			state["repose_way"] = {}
		state["repose_way"].erase(top[5])
		if(straight && way != Vector2.ZERO && line != Vector2.ZERO):
			var toward:float = 1.0
			if(line.cross(way) < 0.0):
				toward = -1.0
			var knob:float = float(opts.get("repose_line", LINE["angle"]))
			if(knob < -float(LINE["most"])):
				knob = float(LINE["share"].get(str(top[8]), LINE["share"]["vagina"])) * abs(line.angle_to(way))
			lineTurn = toward * clamp(knob, -float(LINE["most"]), float(LINE["most"]))
			state["repose_way"][str(top[5]) + "/knob"] = lineTurn * toward
			way = line.rotated(lineTurn)
			state["repose_way"][top[5]] = way
		var mover:Array = []
		var mine:float = 0.0
		if(withB):
			mover = moverOf(state, str(top[5]), Repose.xy(top[2]["hips"].origin), Repose.xy(atB["hips"].origin), float(top[6]), t)
			mine = lerp(share, float(mover[0]), float(mover[1]))
		if(straight && thrust > 0.0 && way != Vector2.ZERO):
			var axis:Vector2 = thrustOf(state, "thrust/" + str(top[5]), top[11], float(top[6]))
			var pushed:Vector2 = axis.rotated(lineTurn)
			target = strokeTurned(state, "thrust/" + str(top[5]), Repose.xy(top[2]["hips"].origin) - top[4], pushed, t) * thrust
			var held:float = heldLength(state, str(top[5]), float(top[12]), t, float(HOLD["secs"]))
			var inside:float = held + (top[9] - top[4]).dot(axis)
			var kTravel:float = float(opts.get("repose_travel", 1.0))
			if(opts.has("stroke_clock") && !atB.empty()):
				kTravel *= sizeOf(held, thighOf(atB))
			if(opts.has("stroke_clock") && ti == 0):
				var link:Dictionary = StrokeSplit.LINK
				link["seen"] = t
				link["k"] = kTravel
				if(!opts.has("stroke_vary_deep")):
					link["k"] = kTravel * float(state.get("strokes", {}).get("travel/" + str(top[5]), {}).get("m", 1.0))
			roomHeld(state, "travel/" + str(top[5]), roomOf(top[2], pushed, floor_y), t)
			if(withB):
				var met0:float = meetOf(mine, opts)
				var metB:float = max(met0, 0.01) / float(BOTTOM_ROOM["factor"])
				state["reach_room"]["gate/travel/" + str(top[5])] = [smoothstep(float(BOTTOM_ROOM["gate"]), float(BOTTOM_ROOM["gate"]) + float(BOTTOM_ROOM["band"]), met0)]
				roomHeld(state, "out/travel/" + str(top[5]), roomOf(atB, pushed, floor_y) / metB, t)
				roomHeld(state, "deep/travel/" + str(top[5]), roomOf(atB, -pushed, floor_y) / metB, t)
			deeper = travelOf(state, "travel/" + str(top[5]), inside, kTravel,
				float(opts.get("repose_intensity", 0.0)), held, float(top[6]), t, float(opts.get("repose_vary", 0.0)),
				float(opts.get("repose_deep", 0.0)), float(opts.get("repose_warm", 0.0)), float(opts.get("repose_stay", 0.0)), opts)
			target += pushed * deeper
			thrusted[thrusted.size() - 1] = true
		elif(strokeDir > 0.0):
			var turned:Vector2 = u.rotated(float(was["goal"][3 * keys.size() + ti]))
			target = strokeTurned(state, "top/" + str(top[5]), Repose.xy(top[2]["hips"].origin), turned, t) * strokeDir
		ats.append(top[2])
		var wTop:float = 1.0
		if(withB):
			shareB += mine / float(tops.size())
			wTop = mine + float(MOVER["least"])
			shares.append([ti, mine])
			if(straight && thrust > 0.0 && way != Vector2.ZERO):
				var met:float = meetOf(mine, opts)
				pushB -= target * met / float(tops.size())
				target *= 1.0 - met
				if(met != mine):
					var both:Vector2 = -(met - mine) * mover[2]
					pushB += both / float(tops.size())
					target += both
		bodies.append(solveBody(top[2], wTop, target))
		var table:Array = []
		if(fit > 0.0):
			table = reader.fitTable(holeHelper, state, top[4], u, float(top[6]), max((top[3][top[3].size() - 1] - top[4]).dot(u) / float(top[6]), 0.0))
		pairs.append({"top": ti, "bottom": -1, "line": top[3], "pivot": top[9], "hole": top[4], "fit": fit, "table": table,
			"turn": round(float(FIT["turn"]) / float(FIT["step"])) * float(FIT["step"]), "range": pubisArc(top[2], top[7]["dirs"][0]),
			"keep": ReposeSolve.missOf(top[3], top[4]),
			"way": way})
		if(straight):
			pairs[-1].erase("keep")
			pairs[-1]["way_w"] = float(BENCH.get("straight_way", STRAIGHT["way"]))
			pairs[-1]["way_fixed"] = true
			if(thrust > 0.0):
				pairs[-1]["gap"] = top[4].distance_to(top[3][0]) - deeper
		if(BENCH.has("way_tilt") || BENCH.has("keep_shift")):
			var shown:Dictionary = pairs[-1]
			shown["way"] = shown["way"].rotated(float(BENCH.get("way_tilt", 0.0)))
			if(shown.has("keep")):
				shown["keep"] = shown["keep"] + ReposeSolve.dirOf(top[3]).tangent() * float(BENCH.get("keep_shift", 0.0)) * float(top[6])
	var facing:float = 0.0
	var bellyB:Vector2 = Vector2.ZERO
	if(withB):
		for top in tops:
			var belly:Vector2 = reader.bellyOf(holeHelper, state, str(top[8]), top[4])
			bellyB += belly
			facing += facingOf(belly, Repose.xy(top[2]["hips"].origin) - Repose.xy(atB["hips"].origin)) / float(tops.size())
		var targetB:Vector2 = Vector2.ZERO
		if(strokeDir > 0.0 && uMean != Vector2.ZERO):
			targetB = strokeTurned(state, "bottom", Repose.xy(atB["hips"].origin), uMean.normalized(), t) * strokeDir
		ats.append(atB)
		bodies.append(solveBody(atB, 1.0 + float(MOVER["least"]) - shareB, targetB + pushB))
		for pair in pairs:
			pair["bottom"] = bodies.size() - 1
	if(BENCH.has("repose_capture")):
		var _sink = BENCH["repose_capture"].call_func(state, holeHelper, tops, pairs, opts, alone)
	for k in range(bodies.size()):
		bodies[k]["tilt_at"] = 3 * bodies.size() + pairs.size() + k
		bodies[k]["tilt_w"] = float(TILT["bottom"])
		bodies[k]["tilt_most"] = 0.0
		if(withB && k == bodies.size() - 1):
			bodies[k]["tilt_most"] = float(TILT["most"]) * facing
		if(Repose.xy(ats[k]["hips"].origin).y - floor_y <= float(FLOOR["lying"]) * thighOf(ats[k])):
			bodies[k]["floor"] = Repose.xy(ats[k]["hips"].origin).y
		bodies[k]["bridge_at"] = 4 * bodies.size() + pairs.size() + k
		bodies[k]["bridge_w"] = float(BRIDGE["cost"])
		bodies[k]["bridge_most"] = float(BRIDGE["most"])
		var arch:float = float(opts.get("repose_arch", -1.0))
		if(withB && k == bodies.size() - 1 && arch > 0.0):
			arch = min(arch, 1.0)
			var up:float = 1.0
			if(bodies[k]["pivot"].x < bodies[k]["neck"].x):
				up = -1.0
			bodies[k]["bridge_to"] = up * arch * float(ARCH["most"])
			bodies[k]["bridge_w"] = float(ARCH["hold"])
			bodies[k]["bridge_most"] = float(ARCH["most"]) + 0.05
			bodies[k]["tilt_to"] = up * arch * float(TILT["most"])
			bodies[k]["tilt_w"] = float(ARCH["hold"])
			bodies[k]["tilt_most"] = float(TILT["most"]) + 0.05
		var curve:float = clamp(float(opts.get("repose_curve", 0.0)), -1.0, 1.0)
		if(withB && k == bodies.size() - 1 && curve != 0.0 && bellyB != Vector2.ZERO):
			bodies[k]["tilt_to"] = float(bodies[k].get("tilt_to", 0.0)) + curlOf(bodies[k], bellyB) * curve * float(CURVE["pelvis"])
			bodies[k]["tilt_w"] = float(CURVE["hold"])
			bodies[k]["tilt_most"] = abs(float(bodies[k]["tilt_to"])) + 0.05
		bodies[k]["most"] = float(REPOSE["most"]) * clamp(float(opts.get("repose_most", 0.5)), 0.0, 1.0)
		var turnMost:float = float(REPOSE["turn"])
		if(k < tops.size()):
			turnMost = float(REPOSE["top_turn"])
		bodies[k]["turn_most"] = turnMost * clamp(float(opts.get("repose_most", 0.5)), 0.0, 1.0)
		limbsOf(bodies, k, ats[k], floor_y)
	for _i in range(n):
		tq.append(0.0)
	if(straight && thrust > 0.0):
		for k in range(tops.size()):
			if(thrusted[k]):
				tq[3 * k] = bodies[k]["target"].x / r
				tq[3 * k + 1] = bodies[k]["target"].y / r
		if(withB):
			tq[3 * tops.size()] = pushB.x / r
			tq[3 * tops.size() + 1] = pushB.y / r
	var tqWas:Array = was.get("tq", tq)
	var prev:Array = was["goal"].duplicate()
	for i in range(n):
		prev[i] += float(tq[i]) - float(tqWas[i])
	var model:Dictionary = {"r": r, "bodies": bodies, "pairs": pairs, "prev": prev}
	if(withB):
		model["slide"] = [bodies.size() - 1, shares]
	tp = lap("h.model", tp)
	var steps:int = ReposeSolve.WARM
	if(fresh):
		steps = ReposeSolve.ITER
	if(opts.has("stroke_regrip")):
		regripOf(state, model, prev, tq, tqWas, steps, t - float(was["when"]), r)
	if(opts.has("stroke_steady")):
		steadyOf(state, model, prev, tq, tqWas, steps, t - float(was["when"]), tops.size())
	var goal:Array = ReposeSolve.solve(model, steps)
	if(BENCH.has("solve_trace")):
		var traced:Dictionary = BENCH
		traced["solve_trace"] = {"model": model.duplicate(), "goal": goal.duplicate()}
	var slow:float = float(BENCH.get("repose_slow", REPOSE["slow"]))
	if(straight && thrust > 0.0):
		slow = 0.0
	var x:Array = []
	var v:Array = []
	for i in range(n):
		var life:float = float(REPOSE["halflife"])
		if(slow > 0.0 && i < 3 * bodies.size()):
			life = slow
		var s:Array = ReposeSolve.spring(float(was["x"][i]) - float(tqWas[i]), float(was["v"][i]), float(goal[i]) - float(tq[i]), life, t - float(was["when"]))
		x.append(s[0] + float(tq[i]))
		v.append(s[1])
	if(slow > 0.0):
		model["hold"] = {}
		for i in range(3 * bodies.size()):
			model["hold"][i] = x[i]
		model["prev"] = goal
		var fast:Array = ReposeSolve.solve(model, ReposeSolve.WARM)
		for i in range(3 * bodies.size(), n):
			var s:Array = ReposeSolve.spring(float(was["x"][i]), float(was["v"][i]), float(fast[i]), float(REPOSE["halflife"]), t - float(was["when"]))
			x[i] = s[0]
			v[i] = s[1]
	tp = lap("h.solve", tp)
	var applied:Array = x
	var dtApply:float = t - float(was["when"])
	state["repose"] = {"keys": keys, "when": t, "goal": goal, "x": x, "v": v, "tq": tq}
	if(BENCH.has("fit_trace")):
		var knobs:Dictionary = BENCH
		knobs["way_trace"] = []
		for p in range(pairs.size()):
			var pair:Dictionary = pairs[p]
			if(pair["way"] == Vector2.ZERO):
				continue
			var moves:Array = []
			var drawn:PoolVector2Array = ReposeSolve.lineOf(model, applied, moves, p)
			var hNow:Vector2 = pair["hole"]
			var wayNow:Vector2 = pair["way"]
			if(int(pair["bottom"]) >= 0):
				hNow = moves[int(pair["bottom"])][0].xform(hNow)
				if(!pair.get("way_fixed", false)):
					wayNow = moves[int(pair["bottom"])][0].basis_xform(wayNow)
			knobs["way_trace"].append([abs(rad2deg(ReposeSolve.dirOf(pair["line"]).angle_to(pair["way"]))),
				abs(rad2deg(ReposeSolve.dirOf(drawn).angle_to(wayNow))), (ReposeSolve.missOf(drawn, hNow) - pair.get("keep", Vector2.ZERO)).length() / r,
				rad2deg(pair["way"].angle()), rad2deg(ReposeSolve.dirOf(pair["line"]).angle())])
	var moved:Array = []
	for k in range(bodies.size()):
		var body:Dictionary = bodies[k]
		var at:Dictionary = ats[k].duplicate()
		at["limbs"] = at["limbs"].duplicate()
		var skel:Skeleton = bottomSkel
		if(k < tops.size()):
			skel = tops[k][1]
		for limb in body["limbs"]:
			if(int(limb[3]) >= 0 || float(limb[7]) > 0.0):
				var end:Vector2 = ReposeSolve.endOf(model, applied, limb, k)
				if(opts.has("stroke_hand_slide") && int(limb[3]) >= 0 && bool(limb[5])):
					var hb:Dictionary = model["bodies"][int(limb[3])]
					var sp:Vector2 = (ReposeSolve.xf(model, applied, int(limb[3]), hb["neck"]) - ReposeSolve.xf(model, applied, int(limb[3]), hb["pivot"])).normalized()
					var mine:Vector2 = ReposeSolve.upper(model, applied, k, limb[1])
					var d:float = sp.dot(mine - end)
					var hk:String = "hand_slide/" + str(k) + "/" + str(limb[6])
					var rest:float = d
					if(state.has(hk)):
						rest = lerp(float(state[hk]), d, 1.0 - exp(-dtApply / float(SLIDE["ease"])))
					state[hk] = rest
					end += sp * (d - rest) * float(limb[4]) * clamp(float(opts["stroke_hand_slide"]), 0.0, 1.0)
				var aw:Array = at["limbs"][int(limb[6])].duplicate()
				aw.append(Transform(aw[2].basis, Vector3(end.x, end.y, aw[2].origin.z)))
				at["limbs"][int(limb[6])] = aw
				if(BENCH.has("fit_trace")):
					var knobs:Dictionary = BENCH
					if(!knobs.has("hand_to")):
						knobs["hand_to"] = {}
					knobs["hand_to"][str(skel.get_instance_id()) + "/" + str(Repose.LIMBS[int(limb[6])][2])] = [end, Engine.get_idle_frames()]
		var pelvis:Transform2D = ReposeSolve.moveOf(body, applied, k, r)[0]
		var tilt:float = ReposeSolve.tiltOf(body, applied)
		var shift:Vector2 = pelvis.xform(body["pivot"]) - body["pivot"]
		var bridge:float = ReposeSolve.bridgeOf(body, applied)
		var turn:float = applied[3 * k + 2] + tilt + bridge
		var lean:float = leanOf(state, str(keys[k]), Vector2(applied[3 * k], applied[3 * k + 1]), at, dtApply) - Repose.FOLLOW * tilt + (1.0 - Repose.FOLLOW) * bridge
		if(k < tops.size()):
			Repose.apply(skel, at, shift, turn, (tops[k][3][3] - tops[k][3][0]).normalized(), dtApply, lean)
			headLag(state, str(keys[k]), skel, at, dtApply)
			var base:float = applied[3 * bodies.size() + k]
			var chain:Dictionary = tops[k][7]
			if(straight):
				var want:Vector2 = tops[k][10].rotated(turn + base)
				var dirs:Array = []
				for d in chain["dirs"]:
					var was_d:Vector2 = d.rotated(turn)
					dirs.append(was_d.rotated(was_d.angle_to(want) * smoothstep(0.0, 1.0, fade)))
				tops[k][0].bendShaft(dirs, chain["rest_axis"])
			else:
				tops[k][0].bendShaft([chain["dirs"][0].rotated(turn + base), null, null], chain["rest_axis"])
			if(!state.has("base_turn")):
				state["base_turn"] = {}
			state["base_turn"][tops[k][5]] = base
			moved.append(tops[k][0])
			continue
		var front:Vector2 = Vector2.ZERO
		for top in tops:
			front += top[4] - body["pivot"]
		var spine:Vector2 = (body["chest"] - body["pivot"]).normalized()
		var flex:float = 0.0
		var curve:float = clamp(float(opts.get("repose_curve", 0.0)), -1.0, 1.0)
		if(curve != 0.0 && bellyB != Vector2.ZERO):
			flex = -curlOf(body, bellyB) * curve * float(CURVE["chest"])
		Repose.apply(bottomSkel, at, shift, turn, (front - spine * front.dot(spine)).normalized(), dtApply, lean + flex)
		if(flex != 0.0):
			var neck:Transform = Repose.world(bottomSkel, Repose.NECK)
			var back := Basis(Vector3(0.0, 0.0, 1.0), -flex)
			Repose.setWorld(bottomSkel, Repose.NECK, Transform(back, neck.origin - back.xform(neck.origin)) * neck)
		headLag(state, "bottom", bottomSkel, at, dtApply)
		state["repose_drawn_b"] = [shift, turn, body["pivot"]]
		moved.append(holeHelper)
	if(!withB):
		state.erase("repose_drawn_b")
	lap("h.apply", tp)
	return moved

const SLIDE := {"ease": 1.5}
const REGRIP := {"most": 2.0, "ease": 1.5, "gate": 3.0}
static func regripOf(state:Dictionary, model:Dictionary, prev:Array, tq:Array, tqWas:Array, steps:int, dt:float, r:float) -> void:
	var n:int = prev.size()
	var bodies:Array = model["bodies"]
	var mh:Dictionary = model.duplicate()
	var bh:Array = []
	for bb in bodies:
		var b2:Dictionary = bb.duplicate()
		var ls:Array = []
		for limb in bb["limbs"]:
			var l2:Array = limb.duplicate()
			if(int(l2[3]) >= 0 && bool(l2[5])):
				l2[2] = float(l2[2]) * 10.0
			ls.append(l2)
		b2["limbs"] = ls
		bh.append(b2)
	mh["bodies"] = bh
	var lp:Array = prev
	if(state.has("regrip_line") && state["regrip_line"].size() == n):
		lp = state["regrip_line"].duplicate()
		for i in range(n):
			lp[i] += float(tq[i]) - float(tqWas[i])
	mh["prev"] = lp
	var lineT:Array = ReposeSolve.solve(mh, steps)
	state["regrip_line"] = lineT
	var cs:Dictionary = state.get("regrip", {})
	var kc:float = 1.0 - exp(-max(dt, 0.0) / float(REGRIP["ease"]))
	var gd:float = float(REGRIP["gate"])
	for k in range(bodies.size()):
		var mv:Array = ReposeSolve.moveOf(bodies[k], lineT, k, r)
		var gate:float = 1.0 - smoothstep(gd, 2.0 * gd, abs(rad2deg(float(lineT[3 * k + 2]))))
		for limb in bodies[k]["limbs"]:
			if(int(limb[3]) < 0 || !bool(limb[5])):
				continue
			var root:Vector2 = mv[1].xform(limb[0])
			var end0:Vector2 = ReposeSolve.endOf(model, lineT, limb, k)
			var want:Vector2 = Vector2.ZERO
			var over:float = root.distance_to(end0) - float(limb[2])
			if(over > 0.0):
				want = (root - end0).normalized() * min(over, float(REGRIP["most"]) * r) * gate
			var ck:String = str(k) + "/" + str(limb[6])
			var c:Vector2 = cs.get(ck, want).linear_interpolate(want, kc)
			cs[ck] = c
			limb[1] = limb[1] + c * float(limb[4])
	state["regrip"] = cs

const STEADY := {"pull": 100.0, "ease": 3.0}
static func steadyOf(state:Dictionary, model:Dictionary, prev:Array, tq:Array, tqWas:Array, steps:int, dt:float, tops:int) -> void:
	var n:int = prev.size()
	var mf:Dictionary = model.duplicate()
	var fp:Array = prev
	if(state.has("turn_free") && state["turn_free"].size() == n):
		fp = state["turn_free"].duplicate()
		for i in range(n):
			fp[i] += float(tq[i]) - float(tqWas[i])
	mf["prev"] = fp
	var free:Array = ReposeSolve.solve(mf, steps)
	state["turn_free"] = free
	for k in range(tops):
		var body:Dictionary = model["bodies"][k]
		var tk:String = "turn_mean/" + str(k)
		var mean:float = float(free[3 * k + 2])
		if(state.has(tk)):
			mean = lerp(float(state[tk]), mean, 1.0 - exp(-max(dt, 0.0) / float(STEADY["ease"])))
		state[tk] = mean
		body["turn_to"] = mean
		body["turn_w"] = float(STEADY["pull"])

static func lap(part:String, since:int) -> int:
	var now:int = OS.get_ticks_usec()
	if(BENCH.has("prof")):
		var prof:Dictionary = BENCH["prof"]
		prof[part] = int(prof.get(part, 0)) + now - since
	return now

const FLOOR := {"lying": 0.5}
static func thighOf(at:Dictionary) -> float:
	var leg:Array = at["limbs"][0]
	return max(Repose.xy(leg[1] - leg[0]).length(), 0.0001)

const CURVE := {"pelvis": 0.3, "chest": 0.35, "hold": 50.0}
static func curlOf(body:Dictionary, belly:Vector2) -> float:
	var down:Vector2 = body["pivot"] - body["chest"]
	if(down.rotated(PI / 2.0).dot(belly) >= 0.0):
		return 1.0
	return -1.0

const ARCH := {"most": 0.35, "hold": 50.0}
const BRIDGE := {"cost": 0.05, "most": 0.0}
const TILT := {"bottom": 0.05, "most": 0.2, "facing": 0.2, "band": 0.2}
const STRAIGHT := {"axis": 0.6, "fade": 0.5, "way": 5.0}
const LINE := {"angle": -1.0, "most": 0.8, "share": {"anus": 0.85, "vagina": 0.6}}

static func facingOf(belly:Vector2, toward:Vector2) -> float:
	if(belly == Vector2.ZERO || toward == Vector2.ZERO):
		return 0.0
	return smoothstep(float(TILT["facing"]), float(TILT["facing"]) + float(TILT["band"]), belly.normalized().dot(toward.normalized()))

const TRAVEL := {"span": 2.0, "tip": 1.0, "base": 0.5, "most": 2.0}
const TRAVEL_DEEP := {"spill": 0.5}
const INTENSITY := {"reach": 0.3, "knee": 0.06, "turn": 0.03, "blend": 0.05}
const HOLD := {"secs": 1.5}
static func heldLength(state:Dictionary, key:String, length:float, now:float, secs:float) -> float:
	if(!state.has("cock_len")):
		state["cock_len"] = {}
	var was = state["cock_len"].get(key)
	var v:float = length
	if(was != null && now >= float(was[1]) && now - float(was[1]) <= GAP && secs > 0.0):
		v = length + (float(was[0]) - length) * exp(-(now - float(was[1])) / secs)
	state["cock_len"][key] = [v, now]
	return v

const ROOM := {"ease": 0.3, "factor": 2.0}
static func roomOf(at:Dictionary, way:Vector2, floor_y:float) -> float:
	var room:float = INF
	for i in range(2):
		var was:Array = at["limbs"][i]
		var a:float = Repose.xy(was[1] - was[0]).length()
		var b:float = Repose.xy(was[2].origin - was[1]).length()
		var gap:Vector2 = Repose.xy(was[0]) - Repose.xy(was[2].origin)
		var slope:float = gap.normalized().dot(way)
		var planted:float = 1.0 - smoothstep(Repose.PLANTED, Repose.PLANTED + float(PLANT["band"]), (was[2].origin.y - floor_y) / max(a + b, 0.0001))
		var w:float = slope * planted
		if(w > 0.0):
			room = min(room, (max((a + b) * Repose.REACH - gap.length(), 0.0) + (a + b) * (1.0 - smoothstep(0.0, float(ROOM["ease"]), w))) / w)
	return room

static func roomHeld(state:Dictionary, key:String, room:float, now:float) -> void:
	if(!state.has("reach_room")):
		state["reach_room"] = {}
	var was = state["reach_room"].get(key)
	if(was == null || now < float(was[1]) || now - float(was[1]) > GAP):
		was = [room, now, []]
	var seen:Array = was[2]
	seen.append([now, room])
	while(now - float(seen[0][0]) > float(TRAVEL["span"])):
		seen.pop_front()
	var least:float = INF
	for one in seen:
		least = min(least, float(one[1]))
	var v:float = least
	if(least < INF && float(was[0]) < INF):
		v = lerp(float(was[0]), least, 1.0 - exp(-(now - float(was[1])) / float(STROKE_FIX["ease"])))
	state["reach_room"][key] = [v, now, seen]

const KEEP := {"share": 0.15}
const BOTTOM_ROOM := {"factor": 1.0, "gate": 0.5, "band": 0.4, "stay": 1.0}
static func travelOf(state:Dictionary, key:String, s:float, k:float, hard:float, length:float, r:float, now:float,
		vary:float = 0.0, deep:float = 0.0, warm:float = 0.0, stay:float = 0.0, opts:Dictionary = {}) -> float:
	if(!state.has("travel")):
		state["travel"] = {}
	var seen:Array = state["travel"].get(key, [])
	if(!seen.empty() && (now < float(seen[-1][0]) || now - float(seen[-1][0]) > GAP)):
		seen = []
	var lo:float = s
	var hi:float = s
	for one in seen:
		lo = min(lo, float(one[1]))
		hi = max(hi, float(one[1]))
	var fixed:bool = int(BENCH.get("stroke_fix", 1)) != 0
	if(fixed):
		var ends:Array = easedEnds(state, key, now, lo, hi)
		lo = float(ends[0])
		hi = float(ends[1])
	var way:Array = [1.0, s, 0.0]
	var turned:float = 0.0
	var far:float = s
	if(!seen.empty()):
		way = seen[-1][2]
		var going:float = float(way[0])
		far = float(way[1])
		if((s - float(way[1])) * going > 0.0):
			way[1] = s
		elif((float(way[1]) - s) * going > float(INTENSITY["turn"]) * (hi - lo)):
			way[0] = -going
			way[1] = s
			turned = -going
		way[2] = lerp(float(way[2]), max(way[0], 0.0), 1.0 - exp(-(now - float(seen[-1][0])) / float(INTENSITY["blend"])))
	seen.append([now, s, way])
	var span:float = float(TRAVEL["span"])
	if(opts.has("stroke_clock")):
		span *= max(float(StrokeSplit.LINK["stretch"]), 1.0)
	while(now - float(seen[0][0]) > span):
		seen.pop_front()
	state["travel"][key] = seen
	vary = clamp(vary, 0.0, 1.0)
	deep = clamp(deep, 0.0, 1.0)
	var more:Dictionary = strokesOf(state, key, now, hi, turned, far, vary, deep, warm, opts)
	var reach:float = hi
	if(fixed):
		reach = clamp(float(more["reach"]), lo, hi)
	var m:float = float(more["m"])
	var w:float = float(more["w"])
	var g:float = float(more["g"])
	if(turned < 0.0):
		more["from"] = far
		more["stay"] = stayOf(state, key, int(more["n"]), stay, r)
	var sp:float = s
	var fromS:float = float(more["from"])
	var amount:float = float(more["stay"])
	if(float(way[0]) > 0.0):
		fromS = float(way[1])
		amount = 0.0
		if(s < fromS):
			amount = stayOf(state, key, int(more["n"]) + 1, stay, r)
	if(amount > 0.0 && fromS - lo > 0.000001):
		sp = lo + (fromS - lo) * (1.0 - lingerOf(1.0 - clamp((s - lo) / (fromS - lo), 0.0, 1.0), amount))
	k = clamp(k, 0.0, float(TRAVEL["most"]))
	hard = clamp(hard + float(more["dh"]), -1.0, 1.0)
	if(hi - lo < 0.000001 || (k == 1.0 && hard == 0.0 && m == 1.0 && w == 0.0 && g == 1.0 && float(more["stay"]) == 0.0 && sp == s)):
		return 0.0
	var deepest:float = max(length - float(TRAVEL["base"]) * r, hi)
	var legs:float = max(min(deepest, hi + float(ROOM["factor"]) * float(state.get("reach_room", {}).get(key, [INF])[0])), hi)
	var outest:float = min(float(TRAVEL["tip"]) * r, lo)
	var roomsB:Dictionary = state.get("reach_room", {})
	var gateB:float = float(roomsB.get("gate/" + key, [0.0])[0])
	outest = lerp(outest, max(outest, lo - float(roomsB.get("out/" + key, [INF])[0])), gateB)
	legs = lerp(legs, max(min(legs, hi + float(roomsB.get("deep/" + key, [INF])[0])), hi), gateB)
	var cap:float = deepest
	if(opts.has("stroke_reserve")):
		cap = max(deepest - deep * float(DEEP["most"]) * r, hi)
	cap = min(cap, legs)
	var half:float = min(0.5 * (hi - lo) * k, 0.5 * (cap - outest))
	var mid:float = clamp(0.5 * (lo + hi), outest + half, cap - half)
	if(opts.has("stroke_deep")):
		var extra:float = 2.0 * half - (hi - lo)
		if(extra > 0.0):
			var dd:float = clamp(float(opts["stroke_deep"]), 0.0, 1.0)
			var top:float = min(hi + dd * extra, cap)
			var spill:float = max(hi + dd * extra - deepest, 0.0) * float(TRAVEL_DEEP["spill"])
			var bottom:float = max(lo - (1.0 - dd) * extra - spill, outest)
			mid = 0.5 * (top + bottom)
			half = 0.5 * (top - bottom)
	if(m != 1.0 && opts.has("stroke_vary_deep")):
		var bottom2:float = mid - half
		var end2:float = clamp(mid + half + (m - 1.0) * 2.0 * half, bottom2, mid + half)
		mid = 0.5 * (end2 + bottom2)
		half = 0.5 * (end2 - bottom2)
	elif(m != 1.0):
		var end:float = mid + half
		half = clamp(half * m, 0.0, 0.5 * (end - outest))
		mid = end - half
	var keep:float = float(KEEP["share"]) * length
	var end3:float = mid + half
	var bottom3:float = max(mid - half, min(min(keep, hi - keep), end3))
	mid = 0.5 * (end3 + bottom3)
	half = 0.5 * (end3 - bottom3)
	var u:float = (sp - lo) / (hi - lo)
	var v:float = u
	var fu:float = (float(more["from"]) - lo) / (hi - lo)
	if(float(more["stay"]) > 0.0 && fu > 0.000001 && sp == s):
		v = fu * (1.0 - lingerOf(1.0 - clamp(u / fu, 0.0, 1.0), float(more["stay"])))
	var shaped:float = u
	if(reach == hi):
		shaped = shapeOf(u, hard)
	elif(reach - lo >= 0.000001 && sp <= reach):
		shaped = shapeOf((sp - lo) / (reach - lo), hard) * (reach - lo) / (hi - lo)
	u = lerp(v, shaped, float(way[2]))
	var drawn:float = mid - half + u * g * 2.0 * half
	if(w > 0.0):
		var extra:float = min(min(deep * float(DEEP["most"]) * r, float(DEEP["share"]) * 2.0 * half), max(legs - (mid + half), 0.0))
		var p:float = clamp(u, 0.0, 1.0)
		drawn += g * w * extra * p * p * (3.0 - 2.0 * p)
	return drawn - s

const SIZE := {"ref": 0.74, "least": 0.6, "most": 1.8, "power": 0.5}
static func sizeOf(length:float, thigh:float) -> float:
	return clamp(pow(length / max(thigh, 0.0001) / float(SIZE["ref"]), float(SIZE["power"])), float(SIZE["least"]), float(SIZE["most"]))

const STROKE_FIX := {"ease": 0.3}
const VARY := {"travel": 0.35, "hard": 0.6, "jitter": 0.3, "build": [3, 5], "ease": 0.1}
const DEEP := {"most": 1.5, "share": 0.5, "first": 2, "ease": 0.15}
const WARM := {"depth": 0.3}
static func strokesOf(state:Dictionary, key:String, now:float, hi:float, turned:float, far:float, vary:float, deep:float,
		warm:float = 0.0, opts:Dictionary = {}) -> Dictionary:
	if(!state.has("strokes")):
		state["strokes"] = {}
	var was:Dictionary = state["strokes"].get(key, {})
	if(was.empty() || now < float(was["t"]) || now - float(was["t"]) > GAP):
		was = {"t": now, "salt": key + "/" + str(stepify(now, 0.001)), "peaks": [], "reach": hi, "n": 0, "first": 0,
			"count": 1, "m": 1.0, "m_to": 1.0, "dh": 0.0, "climax": false, "on": 0.0, "w": 0.0, "since": now, "g": 1.0, "from": -1.0, "stay": 0.0}
	var dt:float = now - float(was["t"])
	was["t"] = now
	if(turned > 0.0):
		was["reach"] = hi
		for one in was["peaks"]:
			was["reach"] = min(float(was["reach"]), float(one))
		was["on"] = 0.0
		if(was.has("m_next")):
			was["m_to"] = was["m_next"]
		if(was.has("dh_next")):
			was["dh"] = was["dh_next"]
		if(bool(was["climax"]) && deep > 0.0 && int(was["n"]) >= int(DEEP["first"])):
			was["on"] = 1.0
	elif(turned < 0.0):
		var peaks:Array = was["peaks"]
		peaks.append(far)
		if(peaks.size() > 2):
			peaks.pop_front()
		was["n"] = int(was["n"]) + 1
		var n:int = int(was["n"])
		var salt:String = str(was["salt"])
		if(n - int(was["first"]) >= int(was["count"])):
			var build:Array = VARY["build"]
			was["first"] = n
			was["count"] = int(build[0]) + int(randomOf(salt, n, 0) * float(int(build[1]) - int(build[0]) + 1))
		var step:int = n - int(was["first"])
		was["climax"] = step == int(was["count"]) - 1
		var p:float = 2.0 * float(step) / float(max(int(was["count"]) - 1, 1)) - 1.0
		var j:float = float(VARY["jitter"])
		var mt:float = 1.0 + vary * float(VARY["travel"]) * clamp(p + j * (2.0 * randomOf(salt, n, 1) - 1.0), -1.0, 1.0)
		if(opts.has("stroke_vary_deep")):
			was["m_next"] = mt
		else:
			was["m_to"] = mt
		var hardK:float = float(opts.get("stroke_vary_hard", 1.0))
		was["dh_next"] = vary * hardK * float(VARY["hard"]) * clamp(p + j * (2.0 * randomOf(salt, n, 2) - 1.0), -1.0, 1.0)
	if(vary <= 0.0):
		was["m_to"] = 1.0
		was["dh"] = 0.0
	was["m"] = lerp(float(was["m"]), float(was["m_to"]), 1.0 - exp(-dt / float(VARY["ease"])))
	if(abs(float(was["m"]) - float(was["m_to"])) < 0.0001):
		was["m"] = was["m_to"]
	was["w"] = lerp(float(was["w"]), float(was["on"]), 1.0 - exp(-dt / float(DEEP["ease"])))
	if(float(was["w"]) < 0.0001 && float(was["on"]) == 0.0):
		was["w"] = 0.0
	was["g"] = 1.0
	if(warm > 0.0):
		was["g"] = lerp(float(WARM["depth"]), 1.0, smoothstep(0.0, warm, now - float(was["since"])))
	state["strokes"][key] = was
	return was

static func randomOf(salt:String, n:int, channel:int) -> float:
	return float(posmod(hash(salt + "/" + str(n) + "/" + str(channel)), 10007)) / 10007.0

static func easedEnds(state:Dictionary, key:String, now:float, lo:float, hi:float) -> Array:
	if(!state.has("stroke_ends")):
		state["stroke_ends"] = {}
	var was = state["stroke_ends"].get(key)
	if(was == null || now < float(was[2]) || now - float(was[2]) > GAP):
		was = [lo, hi, now]
	var k:float = 1.0 - exp(-(now - float(was[2])) / float(STROKE_FIX["ease"]))
	var ends:Array = [min(lo, lerp(float(was[0]), lo, k)), max(hi, lerp(float(was[1]), hi, k)), now]
	state["stroke_ends"][key] = ends
	return ends

const MEET := {"share": 0.5, "soft": 0.5}
static func meetOf(mine:float, opts:Dictionary) -> float:
	var hard:float = clamp(float(opts.get("repose_intensity", 0.0)), 0.0, 1.0)
	var amount:float = clamp(float(opts.get("repose_meet", 0.0)), 0.0, 1.0) * float(MEET["share"])
	return mine + amount * lerp(float(MEET["soft"]), 1.0, hard) * (1.0 - mine)

const LINGER := {"power": 3.0, "first": 2}
static func lingerOf(v:float, amount:float) -> float:
	var n:float = 1.0 + (float(LINGER["power"]) - 1.0) * amount
	v = clamp(v, 0.0, 1.0)
	return pow(v, n) * (n - (n - 1.0) * v)

static func stayOf(state:Dictionary, key:String, n:int, stay:float, r:float) -> float:
	if(n <= int(LINGER["first"])):
		return 0.0
	var roomsS:Dictionary = state.get("reach_room", {})
	return clamp(stay, 0.0, 1.0) * lerp(1.0, smoothstep(0.0, float(BOTTOM_ROOM["stay"]) * r, float(roomsS.get("out/" + key, [INF])[0])), float(roomsS.get("gate/" + key, [0.0])[0]))

static func shapeOf(u:float, hard:float) -> float:
	if(hard == 0.0):
		return u
	if(hard < 0.0):
		return lerp(u, u + u * u - u * u * u, -hard)
	var a:float = 1.0 / (1.0 - hard * float(INTENSITY["reach"])) - 1.0
	return softTop(u + a * u * u) / softTop(1.0 + a)

static func softTop(x:float) -> float:
	var w:float = 0.5 * float(INTENSITY["knee"])
	if(x <= 1.0 - w):
		return x
	if(x >= 1.0 + w):
		return 1.0
	return x - (x - 1.0 + w) * (x - 1.0 + w) / (4.0 * w)

static func cockLine(chain:Dictionary, shaft:Dictionary) -> Array:
	var line:Array = []
	for head in chain["heads"]:
		line.append(Vector2(head.x, head.y))
	var used:float = line[0].distance_to(line[1]) + line[1].distance_to(line[2])
	line.append(line[2] + chain["dirs"][2] * max(float(shaft["length"]) - used, 0.3 * line[1].distance_to(line[2])))
	return line

static func straightOf(skel:Skeleton, chain:Dictionary, line:Array, radius:float) -> Array:
	var way:Vector2 = (line[line.size() - 1] - line[0]).normalized()
	var off:Vector2 = ballsSide(skel, chain["rest_axis"], way) * float(STRAIGHT["axis"]) * radius
	var out:Array = [line[0] + off]
	var along:float = 0.0
	for i in range(1, line.size()):
		along += line[i - 1].distance_to(line[i])
		out.append(line[0] + off + way * along)
	return out

static func ballsSide(skel:Skeleton, restAxis:Vector3, dir:Vector2) -> Vector2:
	var p:int = skel.find_bone("Penis")
	var balls:int = skel.find_bone("Balls")
	if(p < 0 || balls < 0):
		return dir.tangent()
	var rest:Transform = BulgeUtils.getBoneRestGlobal(skel, p)
	var local:Vector3 = rest.affine_inverse().xform(BulgeUtils.getBoneRestGlobal(skel, balls).origin)
	var axis:Vector3 = rest.basis.inverse().xform(restAxis).normalized()
	local -= axis * local.dot(axis)
	var w:Vector3 = skel.global_transform.basis.xform(skel.get_bone_global_pose(p).basis.xform(local))
	var n:Vector2 = Vector2(w.x, w.y) - dir * Vector2(w.x, w.y).dot(dir)
	if(n.length() < 0.000001):
		return dir.tangent()
	return n.normalized()

const ARC_MARGIN := 0.17
static func pubisArc(at:Dictionary, dir:Vector2) -> Array:
	var up:Vector2 = Repose.xy(at["chest"] - at["hips"].origin)
	var thigh:Vector2 = Vector2.ZERO
	for i in range(2):
		thigh += Repose.xy(at["limbs"][i][1] - at["limbs"][i][0]).normalized()
	var toUp:float = dir.angle_to(up)
	var toThigh:float = dir.angle_to(thigh)
	var lo:float = min(min(toUp, toThigh), 0.0)
	var hi:float = max(max(toUp, toThigh), 0.0)
	if(sign(toUp) != sign(toThigh)):
		lo += ARC_MARGIN
		hi -= ARC_MARGIN
	return [min(lo, 0.0), max(hi, 0.0)]

const LAG := {"hz": 2.0, "zeta": 0.4, "gain": 1.0, "most": 0.2, "head_hz": 2.0, "head_zeta": 0.35, "head_most": 0.25, "step": 1.0 / 60.0}
static func leanOf(state:Dictionary, key:String, shift:Vector2, at:Dictionary, dt:float) -> float:
	if(!state.has("lean")):
		state["lean"] = {}
	var st = state["lean"].get(key)
	var most:float = float(LAG["most"])
	if(st == null || dt > GAP):
		state["lean"][key] = [0.0, 0.0, shift, Vector2.ZERO, -1.0]
		return 0.0
	if(dt <= 0.0):
		return most * tanh(float(st[0]) / most)
	var speed:Vector2 = (shift - st[2]) / dt
	var a:Vector2 = Vector2.ZERO
	if(float(st[4]) > 0.0):
		a = (speed - st[3]) / (0.5 * (dt + float(st[4])))
	var spine:Vector2 = (Repose.xy(at["neck"]) - Repose.xy(at["hips"].origin)).normalized()
	var w:float = TAU * float(LAG["hz"])
	var push:float = spine.cross(a) * float(LAG["gain"]) / 10.0
	var steps:int = int(ceil(dt / float(LAG["step"])))
	var h:float = dt / float(steps)
	for _i in range(steps):
		st[1] = float(st[1]) + (-w * w * float(st[0]) - 2.0 * float(LAG["zeta"]) * w * float(st[1]) - push) * h
		st[0] = float(st[0]) + float(st[1]) * h
	st[2] = shift
	st[3] = speed
	st[4] = dt
	return most * tanh(float(st[0]) / most)

static func lagOf(state:Dictionary, key:String, want:float, dt:float, hz:float, zeta:float) -> float:
	if(!state.has("lag")):
		state["lag"] = {}
	var st = state["lag"].get(key)
	if(st == null || dt > GAP):
		state["lag"][key] = [want, 0.0]
		return 0.0
	if(dt <= 0.0):
		return float(st[0]) - want
	var w:float = TAU * hz
	var steps:int = int(ceil(dt / float(LAG["step"])))
	var h:float = dt / float(steps)
	for _i in range(steps):
		st[1] = float(st[1]) + (w * w * (want - float(st[0])) - 2.0 * zeta * w * float(st[1])) * h
		st[0] = float(st[0]) + float(st[1]) * h
	return float(st[0]) - want

static func headLag(state:Dictionary, key:String, skel:Skeleton, at:Dictionary, dt:float) -> void:
	if(skel.find_bone(Repose.NECK) < 0):
		return
	var neck:Transform = Repose.world(skel, Repose.NECK)
	var drawn:Vector2 = Repose.xy(neck.origin) - Repose.xy(Repose.world(skel, Repose.CHEST).origin)
	var added:float = (Repose.xy(at["neck"]) - Repose.xy(at["chest"])).angle_to(drawn)
	var most:float = float(LAG["head_most"])
	var lag:float = most * tanh(lagOf(state, "head/" + key, added, dt, float(LAG["head_hz"]), float(LAG["head_zeta"])) / most)
	var turn := Basis(Vector3(0.0, 0.0, 1.0), lag)
	Repose.setWorld(skel, Repose.NECK, Transform(turn, neck.origin - turn.xform(neck.origin)) * neck)

static func solveBody(at:Dictionary, w:float, target:Vector2) -> Dictionary:
	var pivot:Vector2 = Repose.xy(at["hips"].origin)
	var neck:Vector2 = Repose.xy(at["neck"])
	return {"pivot": pivot, "chest": Repose.xy(at["chest"]), "neck": neck, "L": max(pivot.distance_to(neck), 0.0001),
		"w": w, "target": target, "limbs": []}

const PLANT := {"band": 0.1}
static func limbsOf(bodies:Array, k:int, at:Dictionary, floor_y:float) -> void:
	for i in range(Repose.LIMBS.size()):
		var was:Array = at["limbs"][i]
		var a:float = Repose.xy(was[1] - was[0]).length()
		var b:float = Repose.xy(was[2].origin - was[1]).length()
		var root:Vector2 = Repose.xy(was[0])
		var end:Vector2 = Repose.xy(was[2].origin)
		var far:float = max((a + b) * Repose.REACH, root.distance_to(end))
		if(i >= 2):
			far = max((a + b) * Repose.ARM, root.distance_to(end))
		var own:float = 1.0
		if(i >= 2):
			own = 1.0 - hungOf(at, end, a + b)
		var lift:float = (was[2].origin.y - floor_y) / max(a + b, 0.0001)
		own *= smoothstep(Repose.PLANTED, Repose.PLANTED + float(PLANT["band"]), lift)
		if(i < 2):
			bodies[k]["limbs"].append([root, end, far, -1, 0.0, false, i, own])
			continue
		var holds:int = -1
		var grip:float = 0.0
		for j in range(bodies.size()):
			var other:Dictionary = bodies[j]
			if(j == k):
				continue
			var gap:float = end.distance_to(Geometry.get_closest_point_to_segment_2d(end, other["pivot"], other["neck"])) / float(other["L"])
			var g:float = 1.0 - smoothstep(float(REPOSE["held"]), float(REPOSE["free"]), gap)
			if(g > grip):
				holds = j
				grip = g
		bodies[k]["limbs"].append([root, end, far, holds, grip, true, i, own])

const HUNG := {"over": 0.3, "band": 0.1}
static func hungOf(at:Dictionary, p:Vector2, length:float) -> float:
	var over:float = (p.y - Repose.xy(at["neck"]).y) / max(length, 0.0001)
	return smoothstep(float(HUNG["over"]) - float(HUNG["band"]), float(HUNG["over"]) + float(HUNG["band"]), over)

static func lengthOf(line:Array) -> float:
	var out:float = 0.0
	for i in range(1, line.size()):
		out += line[i].distance_to(line[i - 1])
	return out
