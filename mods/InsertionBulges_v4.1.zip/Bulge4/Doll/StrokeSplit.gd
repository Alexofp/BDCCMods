extends Reference
const AnimAhead := preload("res://Bulge4/Doll/AnimAhead.gd")
const BulgeDoll := preload("res://Bulge4/Doll/BulgeDoll.gd")
const SPLIT := {"bins": 64, "turn": 0.03, "gap": 0.5, "ease": 0.3, "frame": 0.05, "wait": 1.0, "least": 0.0005}
const LINK := {"k": 1.0, "seen": -1000.0, "stretch": 1.0}
const META := "bulge4Split"

static func step(stageScene, now:float, opts:Dictionary) -> void:
	var st:Dictionary = {}
	if(stageScene.has_meta(META)):
		st = stageScene.get_meta(META)
	var ahead:Array = AnimAhead.of(stageScene)
	if(ahead.size() != 2 || travelling(stageScene)):
		stageScene.set_meta(META, {})
		return
	var pos:float = AnimAhead.positionOf(ahead)
	var loop:float = max(AnimAhead.lengthOf(ahead), 0.001)
	var sig:String = str(ahead[0]["anim"].get_instance_id()) + "/" + str(ahead[1]["anim"].get_instance_id())
	if(str(st.get("sig", "")) != sig):
		st = fit(ahead, loop)
		st["sig"] = sig
		st["tau"] = pos
		st["pos"] = pos
		st["t"] = now
		st["cover"] = 0.0
		st["w"] = 0.0
		st["last"] = {}
		stageScene.set_meta(META, st)
	var dt:float = now - float(st["t"])
	var dpos:float = fposmod(pos - float(st["pos"]), loop)
	if(dpos > 0.5 * loop):
		dpos = 0.0
	if(dt > 0.0 && dt <= float(SPLIT["frame"])):
		st["cover"] = float(st["cover"]) + dpos
	st["t"] = now
	st["pos"] = pos
	var n:int = int(SPLIT["bins"])
	var engaged:bool = now - float(LINK["seen"]) <= float(SPLIT["gap"]) && float(st["cover"]) >= float(SPLIT["wait"]) * loop && !st["turns"].empty()
	var goal:float = float(engaged)
	st["w"] = goal + (float(st["w"]) - goal) * exp(-max(dt, 0.0) / float(SPLIT["ease"]))
	var link:Dictionary = LINK
	if(!engaged && float(st["w"]) < 0.01):
		st["w"] = 0.0
		st["tau"] = pos
		link["stretch"] = 1.0
	else:
		smoothClock(st, dpos, dt, loop, opts)
	if(float(st["w"]) > 0.0):
		apply(st, float(st["tau"]) / loop * float(n), float(st["w"]))

const SMOOTH := {"ease": 0.25, "power": 1.0, "turns": 0.5}
const OUTQ := {"power": 0.25, "rise": 0.6}
const PAUSE := {"width": 0.6}
static func smoothClock(st:Dictionary, dpos:float, dt:float, loop:float, opts:Dictionary) -> void:
	var n:int = int(SPLIT["bins"])
	var x:float = float(st["tau"]) / loop * float(n)
	var want:float = pow(max(float(LINK["k"]), 0.1), clamp(float(opts.get("stroke_stretch", 0.0)), 0.0, 1.0))
	var eased:float = want + (float(st.get("eased", want)) - want) * exp(-max(dt, 0.0) / float(SMOOTH["ease"]))
	st["eased"] = eased
	var link:Dictionary = LINK
	link["stretch"] = eased
	if(!st.has("slow")):
		shapesOf(st)
	var g:float = 1.0
	if(eased > 1.0):
		g = lerp(1.0, at(st["slow"], x), float(SMOOTH["turns"]))
		g *= 1.0 - clamp(float(opts.get("stroke_out_quick", 0.0)), 0.0, 1.0) * at(st["outs"], x) - clamp(float(opts.get("stroke_in_quick", 0.0)), 0.0, 1.0) * at(st["ins"], x)
		var pauses:float = clamp(float(opts.get("stroke_pauses", 0.0)), 0.0, 1.0)
		g *= max(1.0 - pauses * at(st["tn_out"], x) - pauses * at(st["tn_deep"], x), 0.0)
	st["tau"] = fposmod(float(st["tau"]) + dpos / max(1.0 + (eased - 1.0) * g, 0.1), loop)

static func shapesOf(st:Dictionary) -> void:
	var n:int = int(SPLIT["bins"])
	var d:Array = st["d"]
	var v:Array = []
	var most:float = 0.000001
	for i in range(n):
		v.append(float(d[(i + 1) % n]) - float(d[(i + n - 1) % n]))
		most = max(most, abs(float(v[i])))
	var low:float = d.min()
	var span:float = max(d.max() - low, 0.000001)
	var slow:Array = []
	var mean:float = 0.0
	var outs:Array = []
	var ins:Array = []
	var tout:Array = []
	var tdeep:Array = []
	for i in range(n):
		var s:float = float(v[i]) / most
		var u:float = (float(d[i]) - low) / span
		slow.append(pow(1.0 - abs(s), float(SMOOTH["power"])))
		mean += float(slow[i]) / float(n)
		outs.append(pow(max(-s, 0.0), float(OUTQ["power"])))
		ins.append(smoothstep(0.0, float(OUTQ["rise"]), s) * (1.0 - u))
		var tn:float = 1.0 - smoothstep(0.0, float(PAUSE["width"]), abs(s))
		tout.append(tn * (1.0 - u))
		tdeep.append(tn * u)
	for i in range(n):
		slow[i] = float(slow[i]) / max(mean, 0.000001)
	st["slow"] = slow
	st["outs"] = outs
	st["ins"] = ins
	st["tn_out"] = tout
	st["tn_deep"] = tdeep

static func apply(st:Dictionary, xtau:float, w:float) -> void:
	var last:Dictionary = st["last"]
	for b in st["bones"]:
		var skel:Skeleton = b[0]
		var idx:int = int(b[1])
		var live:Transform = skel.get_bone_pose(idx)
		var mine = last.get(b[5])
		if(mine != null && mine[0] == live):
			live = mine[1]
		var sc:Vector3 = live.basis.get_scale()
		var qr:Quat = b[2]
		var turn:Vector3 = logQ(qr.inverse() * live.basis.get_rotation_quat())
		var dr:Vector3 = (atC(b[3], xtau) - (turn - b[6])) * w
		var dp:Vector3 = (atC(b[4], xtau) - (live.origin - b[7])) * w
		var q:Quat = qr * expQ(turn + dr)
		var out := Transform(Basis(q) * Basis().scaled(sc), live.origin + dp)
		skel.set_bone_pose(idx, out)
		last[b[5]] = [out, live]
	var posed:Dictionary = BulgeDoll.POSED
	posed["n"] = int(posed["n"]) + 1

static func fit(ahead:Array, loop:float) -> Dictionary:
	var n:int = int(SPLIT["bins"])
	var hips:Array = []
	for one in ahead:
		var skel:Skeleton = one["skel"]
		var hi:int = skel.find_bone("Hips")
		var track:int = -1
		for b in one["bones"]:
			if(int(b[1]) == hi):
				track = int(b[0])
		if(track < 0 || skel.get_bone_parent(hi) >= 0):
			return {"d": [], "turns": [], "bones": []}
		hips.append([skel, hi, track, one["anim"]])
	var d:Array = []
	for i in range(n):
		var p:Array = []
		for h in hips:
			var got:Array = h[3].transform_track_interpolate(int(h[2]), loop * float(i) / float(n))
			p.append(h[0].global_transform.xform(h[0].get_bone_rest(int(h[1])).xform(got[0])))
		d.append(-p[0].distance_to(p[1]))
	var lo:float = d.min()
	var span:float = d.max() - lo
	if(span < 0.000001):
		return {"d": [], "turns": [], "bones": []}
	for i in range(n):
		d[i] = (float(d[i]) - lo) / span
	var bones:Array = []
	for one in ahead:
		for b in one["bones"]:
			var qs:Array = []
			var moves:Array = []
			var qm := Quat(0.0, 0.0, 0.0, 0.0)
			for i in range(n):
				var got:Array = one["anim"].transform_track_interpolate(int(b[0]), loop * float(i) / float(n))
				var q:Quat = got[1]
				if(!qs.empty() && q.dot(qs[0]) < 0.0):
					q = Quat(-q.x, -q.y, -q.z, -q.w)
				qs.append(q)
				moves.append(got[0])
				qm = Quat(qm.x + q.x, qm.y + q.y, qm.z + q.z, qm.w + q.w)
			qm = qm.normalized()
			var ws:Array = []
			var wm := Vector3.ZERO
			var om := Vector3.ZERO
			for i in range(n):
				ws.append(logQ(qm.inverse() * qs[i]))
				wm += ws[i] / float(n)
				om += moves[i] / float(n)
			var sr := PoolVector3Array()
			var sp := PoolVector3Array()
			var most:float = 0.0
			for i in range(n):
				sr.append(ws[i] - wm)
				sp.append(moves[i] - om)
				most = max(most, max(sr[i].length(), sp[i].length()))
			sr = smoothBins(sr)
			sp = smoothBins(sp)
			if(most >= float(SPLIT["least"])):
				bones.append([one["skel"], int(b[1]), qm, sr, sp, str(one["skel"].get_instance_id()) + "/" + str(b[1]), wm, om])
	return {"d": d, "turns": turnsOf(d), "bones": bones}

static func smoothBins(bins:PoolVector3Array) -> PoolVector3Array:
	var n:int = bins.size()
	var out := PoolVector3Array()
	for i in range(n):
		out.append(0.25 * bins[posmod(i - 1, n)] + 0.5 * bins[i] + 0.25 * bins[(i + 1) % n])
	return out

static func travelling(stageScene) -> bool:
	for node in stageScene.get_children():
		if(node is AnimationTree):
			var playback = node.get("parameters/StateMachine/playback")
			if(playback != null && !playback.get_travel_path().empty()):
				return true
	return false

static func turnsOf(bins:Array) -> Array:
	var n:int = bins.size()
	if(n == 0):
		return []
	var lo:int = 0
	var hi:float = -INF
	for i in range(n):
		if(float(bins[i]) < float(bins[lo])):
			lo = i
		hi = max(hi, float(bins[i]))
	var thr:float = float(SPLIT["turn"]) * (hi - float(bins[lo]))
	if(thr <= 0.0):
		return []
	var out:Array = [[lo, -1]]
	var going:int = 1
	var ext:int = lo
	for j in range(1, n + 1):
		var i:int = (lo + j) % n
		if((float(bins[i]) - float(bins[ext])) * float(going) > 0.0):
			ext = i
		elif((float(bins[ext]) - float(bins[i])) * float(going) > thr):
			if(going > 0):
				out.append([ext, 1])
			elif(ext != lo):
				out.append([ext, -1])
			going = -going
			ext = i
	if(going > 0 && ext != lo):
		out.append([ext, 1])
	out.sort_custom(BinSort, "byBin")
	return out

class BinSort:
	static func byBin(a, b) -> bool:
		return int(a[0]) < int(b[0])

static func at(bins:Array, x:float) -> float:
	var n:int = bins.size()
	if(n == 0):
		return 0.0
	var i0:int = int(floor(x))
	return lerp(float(bins[posmod(i0, n)]), float(bins[posmod(i0 + 1, n)]), x - floor(x))

static func atC(bins:PoolVector3Array, x:float) -> Vector3:
	var n:int = bins.size()
	var i:int = int(floor(x))
	var f:float = x - floor(x)
	var p0:Vector3 = bins[posmod(i - 1, n)]
	var p1:Vector3 = bins[posmod(i, n)]
	var p2:Vector3 = bins[posmod(i + 1, n)]
	var p3:Vector3 = bins[posmod(i + 2, n)]
	return 0.5 * (2.0 * p1 + (p2 - p0) * f + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * f * f + (3.0 * p1 - p0 - 3.0 * p2 + p3) * f * f * f)

static func logQ(q:Quat) -> Vector3:
	if(q.w < 0.0):
		q = Quat(-q.x, -q.y, -q.z, -q.w)
	var s:float = Vector3(q.x, q.y, q.z).length()
	if(s < 0.0000001):
		return Vector3(q.x, q.y, q.z) * 2.0
	return Vector3(q.x, q.y, q.z) / s * 2.0 * atan2(s, q.w)

static func expQ(w:Vector3) -> Quat:
	var a:float = w.length()
	if(a < 0.0000001):
		return Quat(w.x * 0.5, w.y * 0.5, w.z * 0.5, 1.0).normalized()
	return Quat(w / a, a)
