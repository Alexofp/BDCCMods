extends Reference
const ReposeSolve := preload("res://Bulge4/Doll/ReposeSolve.gd")
const HIPS := "Hips"
const CHEST := "Chest"
const NECK := "Neck"
const LIMBS := [["LegUpper.L", "LegDown.L", "Foot.L"], ["LegUpper.R", "LegDown.R", "Foot.R"],
	["Arm.L", "ForeArm.L", "Hand.L"], ["Arm.R", "ForeArm.R", "Hand.R"]]

const NAMES := [HIPS, CHEST, NECK,
	"LegUpper.L", "LegDown.L", "Foot.L", "LegUpper.R", "LegDown.R", "Foot.R",
	"Arm.L", "ForeArm.L", "Hand.L", "Arm.R", "ForeArm.R", "Hand.R"]

static func names() -> Array:
	return NAMES

static func clear(skel:Skeleton) -> void:
	for boneName in NAMES:
		var idx:int = skel.find_bone(boneName)
		if(idx >= 0):
			skel.set_bone_global_pose_override(idx, Transform.IDENTITY, 0.0, false)

static func forget(skel:Skeleton) -> void:
	if(skel == null):
		return
	if(skel.has_meta(META_SIDES)):
		skel.remove_meta(META_SIDES)
	if(skel.has_meta(META_CHEST)):
		skel.remove_meta(META_CHEST)

static func world(skel:Skeleton, boneName:String) -> Transform:
	return skel.global_transform * skel.get_bone_global_pose(skel.find_bone(boneName))

static func setWorld(skel:Skeleton, boneName:String, t:Transform) -> void:
	skel.set_bone_global_pose_override(skel.find_bone(boneName), skel.global_transform.affine_inverse() * t, 1.0, true)

static func xy(v:Vector3) -> Vector2:
	return Vector2(v.x, v.y)

static func turnTo(skel:Skeleton, boneName:String, from:Vector3, want:Vector3) -> void:
	var g:Transform = world(skel, boneName)
	setWorld(skel, boneName, turnOf(g, from, want) * g)

static func animated(skel:Skeleton) -> Dictionary:
	clear(skel)
	var limbs:Array = []
	for limb in LIMBS:
		if(skel.find_bone(limb[0]) < 0 || skel.find_bone(limb[1]) < 0 || skel.find_bone(limb[2]) < 0):
			return {}
		limbs.append([world(skel, limb[0]).origin, world(skel, limb[1]).origin, world(skel, limb[2])])
	if(skel.find_bone(HIPS) < 0 || skel.find_bone(CHEST) < 0 || skel.find_bone(NECK) < 0):
		return {}
	return {"limbs": limbs, "neck": world(skel, NECK).origin, "hips": world(skel, HIPS), "chest": world(skel, CHEST).origin}

const FOLLOW := 0.75
static func apply(skel:Skeleton, at:Dictionary, shift:Vector2, tilt:float, front:Vector2, dt:float = 1.0 / 60.0, lean:float = 0.0) -> void:
	var hips:Transform = at["hips"]
	var r := Basis(Vector3(0.0, 0.0, 1.0), tilt)
	setWorld(skel, HIPS, Transform(r, hips.origin - r.xform(hips.origin) + Vector3(shift.x, shift.y, 0.0)) * hips)
	var chest:Vector2 = xy(world(skel, CHEST).origin)
	var neck:Vector3 = world(skel, NECK).origin
	var want:Vector2 = chest + (xy(neck) - chest).rotated(chestTurn(skel, at, chest, -tilt * (1.0 - FOLLOW) + lean, dt))
	turnTo(skel, CHEST, neck, Vector3(want.x, want.y, neck.z))
	var got:Array = []
	for limb in LIMBS:
		got.append([world(skel, limb[0]), world(skel, limb[1]), world(skel, limb[2])])
	for i in range(LIMBS.size()):
		var bendsTo:Vector2 = front
		if(LIMBS[i][2].begins_with("Hand")):
			bendsTo = -front
		reach(skel, LIMBS[i], at["limbs"][i], bendsTo, got[i])

const ARM := 0.9
const BEND := 0.17
const META_CHEST := "bulge4ReposeChest"
const CHEST_EASE := 0.1
const CHEST_CALM := {"on": false, "bend": 0.5}
static func chestTurn(skel:Skeleton, at:Dictionary, chest:Vector2, wanted:float, dt:float = 1.0 / 60.0) -> float:
	var calm:bool = bool(CHEST_CALM["on"])
	var bend:float = BEND
	if(calm):
		bend = BEND * float(CHEST_CALM["bend"])
	var ref:float = wanted
	var last:Array = []
	if(skel.has_meta(META_CHEST)):
		last = skel.get_meta(META_CHEST)
		ref = float(last[0])
		if(!calm):
			ref = clamp(ref, wanted - BEND, wanted + BEND)
	var lo:float = -INF
	var hi:float = INF
	var sides:Dictionary = {}
	if(last.size() > 2):
		sides = last[2]
	for i in range(2, LIMBS.size()):
		var was:Array = at["limbs"][i]
		var far:float = max((xy(was[1] - was[0]).length() + xy(was[2].origin - was[1]).length()) * ARM, xy(was[2].origin - was[0]).length())
		var v:Vector2 = xy(world(skel, LIMBS[i][0]).origin) - chest
		var w:Vector2 = xy(goalOf(was).origin) - chest
		if(v.length() < 0.0001 || w.length() < 0.0001):
			continue
		var k:float = (v.length_squared() + w.length_squared() - far * far) / (2.0 * v.length() * w.length())
		if(k <= -1.0):
			sides.erase(i)
			continue
		var mid:float = ref + wrapf(v.rotated(ref).angle_to(w), -PI, PI)
		var half:float = acos(min(k, 1.0))
		if(calm):
			var gh:float = PI - half
			var gw:float = wanted + wrapf(mid + PI - wanted, -PI, PI)
			if(abs(wanted - gw) >= gh):
				sides.erase(i)
				if(gw > wanted):
					lo = max(lo, gw + gh - TAU)
					hi = min(hi, gw - gh)
				else:
					lo = max(lo, gw + gh)
					hi = min(hi, gw - gh + TAU)
				continue
			var side:float = float(sides.get(i, 0.0))
			if(side == 0.0):
				side = sign(ref - gw)
				if(side == 0.0):
					side = 1.0
			sides[i] = side
			if(side > 0.0):
				lo = max(lo, gw + gh)
			else:
				hi = min(hi, gw - gh)
			continue
		lo = max(lo, mid - half)
		hi = min(hi, mid + half)
	var turn:float = wanted
	if(lo <= hi):
		turn = clamp(wanted, lo, hi)
	else:
		turn = (lo + hi) * 0.5
	turn = clamp(turn, wanted - bend, wanted + bend)
	if(!last.empty() && dt > 0.0):
		var sv:Array = ReposeSolve.spring(ref, float(last[1]), turn, CHEST_EASE, min(dt, 0.25))
		turn = sv[0]
		if(!calm):
			turn = clamp(turn, wanted - bend, wanted + bend)
		last = [turn, sv[1], sides]
	elif(!last.empty()):
		turn = ref
	else:
		last = [turn, 0.0, sides]
	skel.set_meta(META_CHEST, last)
	return turn

const STRAIGHT := 0.15
const SWITCH := 0.1
const META_SIDES := "bulge4ReposeSides"
const REACH := 0.97
const SOFT := 0.01
static func reach(skel:Skeleton, limb:Array, was:Array, bendsTo:Vector2, got:Array) -> void:
	var g0:Transform = got[0]
	var g1:Transform = got[1]
	var g2:Transform = got[2]
	var root:Vector3 = g0.origin
	var a:float = xy(was[1] - was[0]).length()
	var b:float = xy(was[2].origin - was[1]).length()
	var goal:Transform = goalOf(was)
	var target:Vector2 = xy(goal.origin)
	var far:float = max((a + b) * REACH, xy(was[2].origin - was[0]).length())
	var soft:float = SOFT * (a + b)
	var gap:float = xy(root).distance_to(target)
	if(soft > 0.0 && gap > far - soft):
		target = xy(root) + (target - xy(root)) / gap * (far - soft + soft * (1.0 - exp(-(gap - far + soft) / soft)))
	var toward:Vector2 = target - xy(root)
	var d:float = clamp(toward.length(), abs(a - b) + 0.0001, a + b - 0.0001)
	if(a < 0.0001 || b < 0.0001 || toward.length() < 0.0001):
		return
	var open:float = acos(clamp((a * a + d * d - b * b) / (2.0 * a * d), -1.0, 1.0))
	var sides:Dictionary = {}
	if(skel.has_meta(META_SIDES)):
		sides = skel.get_meta(META_SIDES)
	else:
		skel.set_meta(META_SIDES, sides)
	var side:float = float(sides.get(limb[1], 0.0))
	if(side == 0.0):
		var reachWas:Vector2 = xy(was[2].origin - was[0])
		var bend:float = reachWas.normalized().cross(xy(was[1] - was[0]).normalized())
		side = sign(bend)
		if(abs(bend) < STRAIGHT):
			side = sign(toward.cross(bendsTo))
		if(side == 0.0):
			side = 1.0
	else:
		var ref:Vector2 = xy(root) + xy(was[1] - was[0]).rotated(xy(was[2].origin - was[0]).angle_to(toward))
		var same:Vector2 = xy(root) + toward.normalized().rotated(side * open) * a
		var other:Vector2 = xy(root) + toward.normalized().rotated(-side * open) * a
		if(other.distance_to(ref) < same.distance_to(ref) - SWITCH * (a + b)):
			side = -side
	sides[limb[1]] = side
	var knee:Vector2 = xy(root) + toward.normalized().rotated(side * open) * a
	var m0:Transform = turnOf(g0, g1.origin, Vector3(knee.x, knee.y, was[1].z))
	g1 = m0 * g1
	g2 = m0 * g2
	var m1:Transform = turnOf(g1, g2.origin, Vector3(target.x, target.y, goal.origin.z))
	setWorld(skel, limb[0], m0 * g0)
	setWorld(skel, limb[1], m1 * g1)
	setWorld(skel, limb[2], Transform(goal.basis, (m1 * g2).origin))

static func turnOf(g:Transform, from:Vector3, want:Vector3) -> Transform:
	var a:Vector2 = xy(from - g.origin)
	var b:Vector2 = xy(want - g.origin)
	if(a.length() < 0.000001 || b.length() < 0.000001):
		return Transform.IDENTITY
	var r := Basis(Vector3(0.0, 0.0, 1.0), a.angle_to(b))
	return Transform(r, g.origin - r.xform(g.origin))

static func goalOf(was:Array) -> Transform:
	if(was.size() > 3):
		return was[3]
	return was[2]

const PLANTED := 0.15
static func lowestFoot(at:Dictionary) -> float:
	var lowest := INF
	for i in range(2):
		lowest = min(lowest, at["limbs"][i][2].origin.y)
	return lowest
