extends Module

func _init():
	id = "sugerrstartingperks"
	author = "Sugerør"

	perks = [
		"res://Modules/SrStartingPerk/Perks/StartFragile.gd",
		"res://Modules/SrStartingPerk/Perks/StartLusty.gd",
		"res://Modules/SrStartingPerk/Perks/StartSlowLearn.gd",
		"res://Modules/SrStartingPerk/Perks/StartBreeder.gd",
		"res://Modules/SrStartingPerk/Perks/StartFertile.gd",
		"res://Modules/SrStartingPerk/Perks/StartApproachable.gd",
		"res://Modules/SrStartingPerk/Perks/StartUnapproachable.gd",
		"res://Modules/SrStartingPerk/Perks/StartCombatTrained.gd",
	]

