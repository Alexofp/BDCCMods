extends PerkBase

const SugerrStartWeak = "SugerrStartCombatTrained"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Combat Trained"

func getVisibleDescription():
	return "You have a buff to earning combat exp and dealing physical damage"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/stiletto.png"

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff, [25]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, 50.0]),
	]
