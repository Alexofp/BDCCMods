extends PerkBase

const SugerrStartWeak = "SugerrStartLusty"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Horny and a bad tease"

func getVisibleDescription():
	return "You have a debuff to both dealing and receiving lust damage"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/addiction.png"

func getBuffs():
	return [
		buff(Buff.LustDamageBuff, [-50]),
		buff(Buff.LustArmorBuff, [-50]),
		buff(Buff.ReceivedLustDamageBuff, [50]),
	]
