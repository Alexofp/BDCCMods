extends PerkBase

const SugerrStartWeak = "SugerrStartApproachable"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Approachable"

func getVisibleDescription():
	return "You have a higher chance to be approached by others"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/running.png"

func getBuffs():
	return [
		buff(Buff.EncounterChanceModifierInmatesBuff,[10]),
		buff(Buff.EncounterChanceModifierStaffBuff,[10]),
	]
