extends PerkBase

const SugerrStartWeak = "SugerrStartFragile"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Fragile"

func getVisibleDescription():
	return "You have a debuff to both dealing and receiving physical damage"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/distraction.png"

func getBuffs():
	return [
		buff(Buff.PhysicalDamageBuff, [-50]),
		buff(Buff.PhysicalArmorBuff, [-50]),
		buff(Buff.ReceivedPhysicalDamageBuff, [50]),
	]
