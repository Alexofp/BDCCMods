extends PerkBase

const SugerrStartWeak = "SugerrStartFertile"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Fertile"

func getVisibleDescription():
	return "You have a buff to earning fertility and breeder exp"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/StatusEffects/impregnation.png"

func getBuffs():
	return [
		buff(Buff.SkillExperienceBuff, [Skill.Breeder, 50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Fertility, 50.0]),
	]
