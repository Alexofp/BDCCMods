extends PerkBase

const SugerrStartWeak = "SugerrStartSlowLearn"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Slow Learner"

func getVisibleDescription():
	return "You have a debuff to earning exp in all perks"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/mansory.png"

func getBuffs():
	return [
		buff(Buff.SkillExperienceBuff, [Skill.Hypnosis, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.BDSM, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Breeder, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Combat, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.CumLover, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Exhibitionism, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Fertility, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.Milking, -50.0]),
		buff(Buff.SkillExperienceBuff, [Skill.SexSlave, -50.0]),	
	]
