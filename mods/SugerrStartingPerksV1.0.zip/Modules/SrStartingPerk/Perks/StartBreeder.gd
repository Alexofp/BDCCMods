extends PerkBase

const SugerrStartWeak = "SugerrStartBreeder"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Breedable Breeder"

func getVisibleDescription():
	return "You have a buff to fertility and virility"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/heartburn.png"

func getBuffs():
	return [
		buff(Buff.FertilityBuff,[35]),
		buff(Buff.VirilityBuff,[35]),
	]
