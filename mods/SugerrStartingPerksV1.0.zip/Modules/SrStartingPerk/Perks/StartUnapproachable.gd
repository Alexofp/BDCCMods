extends PerkBase

const SugerrStartWeak = "SugerrStartUnapproachable"

func _init():
	id = SugerrStartWeak
	skillGroup = Skill.Start

func getVisibleName():
	return "Unapproachable"

func getVisibleDescription():
	return "You have a lower chance to be approached by others"

func getSkillTier():
	return 0

func getPicture():
	return "res://Images/Perks/acrobatic.png"

func getBuffs():
	return [
		buff(Buff.EncounterChanceModifierInmatesBuff,[-10]),
		buff(Buff.EncounterChanceModifierStaffBuff,[-10]),
	]
