extends Module

func _init():
	id = "chastityBelts"
	author = "_noro_"
	
	items = [
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltBase.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltPenis.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltPenisVagina.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltAnus.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/AnusChastityBeltPenis.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/AnusChastityBeltPenisVagina.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBelt/AnusChastityBeltVagina.gd",
		
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentChastityBeltVagina.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentChastityBeltPenis.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentChastityBeltPenisVagina.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentChastityBeltAnus.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentAnusChastityBeltPenis.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentAnusChastityBeltPenisVagina.gd",
		"res://Modules/ChastityBeltsModule/Items/ChastityBeltPermanent/PermanentAnusChastityBeltVagina.gd"
	]
