extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltPenis.gd"

func _init():
	id = "PermanentEverythingChastityBelt"

func getVisibleName():
	return "Permanent Anus and Genitals Chastity Belt"

# DISCLAIMER Permanently blocking one's anus blocks... a one of basic bodily functions, so I won't be making the item accessable in game other than by debug menu - so if someone want's it they can have it.
func getDescription():
	return "Permanantly prevents access to the wearer's "+getBodyPartString()+". Nightmarish."

func generateRestraintData():
	restraintData = RestraintUnremovable.new()
	restraintData.setLevel(calculateBestRestraintLevel())

func isImportant():
	return true

func getTags():
	return [ItemTag.BDSMRestraint]
