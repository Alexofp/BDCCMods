extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/AnusChastityBeltVagina.gd"

func _init():
	id = "PermanentAnusVaginalChastityBelt"

func getVisibleName():
	return "Permanent Anus and Vagina Chastity Belt"

# DISCLAIMER Permanently blocking one's anus blocks... a one of basic bodily functions, so I won't be making the item accessable in game other than by debug menu - so if someone want's it they can have it.
func getDescription():
	return "Prevents access to the wearer's "+getBodyPartString()+". Forever - however unpractical and terrifying it is, it does exist."

func getTags():
	return [ItemTag.BDSMRestraint]

func generateRestraintData():
	restraintData = RestraintUnremovable.new()
	restraintData.setLevel(calculateBestRestraintLevel())
	
func isImportant():
	return true

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/NoCockBeltIco.png"
