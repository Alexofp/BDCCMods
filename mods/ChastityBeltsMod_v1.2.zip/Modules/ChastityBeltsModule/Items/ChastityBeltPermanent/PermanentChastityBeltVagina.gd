extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltBase.gd"

func _init():
	id = "PermanentChastityBeltVagina"

func getVisibleName():
	return "Permanent Vagina Chastity Belt"
	
# DISCLAIMER Permanently blocking one's anus blocks... a one of basic bodily functions, so I won't be making the item accessable in game other than by debug menu - so if someone want's it they can have it.
func getDescription():
	return "Prevents access to the wearer's "+getBodyPartString()+". Forever." #TODO
	
func generateRestraintData():
	restraintData = RestraintUnremovable.new()
	restraintData.setLevel(calculateBestRestraintLevel())
	
func isImportant():
	return true

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.SoldByMirri]
