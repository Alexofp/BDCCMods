extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltBase.gd"

func getBodyPartSlot(): return BodypartSlot.Anus
func getBodyPartSlot2(): return BodypartSlot.Penis
func getBodyPartString(): return "anus and penis"
func getInventorySlot(): return InventorySlot.Penis
func getBuffs():
	return [
	# vagina
#	buff(Buff.BlocksVaginaLeakingBuff),
#	buff(Buff.ChastityVaginaBuff),
	# anus
	buff(Buff.BlocksAnusLeakingBuff),
	buff(Buff.ChastityAnusBuff),
	#penis
	buff(Buff.ChastityPenisBuff),
	# misc
	buff(Buff.SensitivityGainBuff, [15.0]),
	buff(Buff.SkillExperienceBuff, [Skill.BDSM, 5])
]

func _init():
	id = "AnusPenisChastityBelt"

func getVisibleName():
	return "Anus and Penis Chastity Belt"

func getDescription():
	return "Prevents access to the wearer's "+getBodyPartString()+"."

func getRequiredBodypart():
	return getBodyPartSlot()

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.CanBeForcedByGuards, ItemTag.ChastityCage, ItemTag.SoldByTheAnnouncer, ItemTag.CanBeForcedInStocks]

func getRiggedParts(_character):
	return {
		"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoCockBelt/NoCockBelt.tscn",
#		"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoAnusCockBelt/NoAnusCockBelt.tscn",
		"chastity_cage": "res://Modules/ChastityBeltsModule/Items/Models/CockBelt/CockBelt.tscn",
	}

#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "limp")

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
		BodypartSlot.Anus: true,
	}

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize()+" was locked onto your penis, making it useless!"
	else:
		return getAStackNameCapitalize()+" was locked onto {receiver.nameS} penis, making it useless!"

func shouldBeVisibleOnDoll(_character, _doll):
	if((!_character.isBodypartCovered(getBodyPartSlot()) || _doll.isForcedExposed(getBodyPartSlot()))
	|| (!_character.isBodypartCovered(getBodyPartSlot2()) || _doll.isForcedExposed(getBodyPartSlot2()))
	):
		return true
	return false

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/CockBeltIco.png"
