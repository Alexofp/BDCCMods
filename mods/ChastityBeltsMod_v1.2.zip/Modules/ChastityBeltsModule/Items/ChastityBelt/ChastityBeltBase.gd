extends ItemBase

func getBodyPartSlot(): return BodypartSlot.Vagina
func getInventorySlot(): return InventorySlot.Vagina
func getBodyPartString(): return "vagina"
func getBuffs():
	return [
	# vagina
	buff(Buff.BlocksVaginaLeakingBuff),
	buff(Buff.ChastityVaginaBuff),
	# anus
#	buff(Buff.BlocksAnusLeakingBuff),
#	buff(Buff.ChastityAnusBuff),
	#penis
#	buff(Buff.ChastityPenisBuff),
	# misc
	buff(Buff.SensitivityGainBuff, [15.0]),
	buff(Buff.SkillExperienceBuff, [Skill.BDSM, 5])
]

func _init():
	id = "ChastityBelt"

func getVisibleName():
	return "Vagina Chastity Belt"
	
func getDescription():
	return "Prevents access to the wearer's "+getBodyPartString()+"." #TODO

func getClothingSlot():
#	return getInventorySlot() 
	return InventorySlot.UnderwearBottom # doesn't work with getRequiredBodypart(), but prevents equiping multiple 

func getRequiredBodypart():
	return getBodyPartSlot()

func getTakeOffScene():
	return "RestraintTakeOffNopeScene"

func getPrice():
	return 20

func canSell():
	return true

func canDye():
	return false

func isImportant():
	return false

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.CanBeForcedByGuards, ItemTag.SoldByTheAnnouncer, ItemTag.CanBeForcedInStocks]

func isRestraint():
	return true

func generateRestraintData():
#	restraintData = RestraintUnremovable.new() #TODO
#	restraintData = RestraintChastityCage.new()
	restraintData =  preload("res://Inventory/RestraintTypes/RestraintChastityBelt.gd").new()
	restraintData.setLevel(RNG.randi_range(3, 15))

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize()+" was put over your hips, blocking your "+getBodyPartString()+"!"
	else:
		return getAStackNameCapitalize()+" was put over {receiver.nameS} hips, blocking {receiver.hisHer} "+getBodyPartString()+"!"

#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "caged")

func getHidesParts(_character):
	return {
		BodypartSlot.Vagina: true,
	}

func getRiggedParts(_character):
	if _character.hasPenis():
		return {
			"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoAnusCockBelt/NoAnusCockBelt.tscn",
		}
	else:
		return {
			"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoAnusBelt/NoAnusBelt.tscn",
		}

func shouldBeVisibleOnDoll(_character, _doll):
	if(!_character.isBodypartCovered(getBodyPartSlot()) || _doll.isForcedExposed(getBodyPartSlot())):
		return true
	return false

func getAIForceItemWeight(_whoForcesNpc, _targetNpc):
	return 0.2

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/NoCockBeltIco.png"
