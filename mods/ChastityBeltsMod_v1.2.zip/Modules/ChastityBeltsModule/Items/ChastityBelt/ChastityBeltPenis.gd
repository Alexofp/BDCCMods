extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltBase.gd"

func getBodyPartSlot(): return BodypartSlot.Penis
func getBodyPartString(): return "penis"
func getInventorySlot(): return InventorySlot.Penis
func getBuffs():
	return [
	# vagina
#	buff(Buff.BlocksVaginaLeakingBuff),
#	buff(Buff.ChastityVaginaBuff),
	# anus
#	buff(Buff.BlocksAnusLeakingBuff),
#	buff(Buff.ChastityAnusBuff),
	#penis
	buff(Buff.ChastityPenisBuff),
	# misc
	buff(Buff.SensitivityGainBuff, [15.0]),
	buff(Buff.SkillExperienceBuff, [Skill.BDSM, 5])
]

func _init():
	id = "PenisChastityBelt"

func getVisibleName():
	return "Penis Chastity Belt"

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.CanBeForcedByGuards, ItemTag.ChastityCage, ItemTag.SoldByTheAnnouncer, ItemTag.CanBeForcedInStocks]

func getRiggedParts(_character):
	return {
#		"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoCockBelt/NoCockBelt.tscn",
		"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoAnusCockBelt/NoAnusCockBelt.tscn",
		"chastity_cage": "res://Modules/ChastityBeltsModule/Items/Models/CockBelt/CockBelt.tscn",
	}
#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "limp")

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
	}

func getForcedOnMessage(isPlayer = true):
	if(isPlayer):
		return getAStackNameCapitalize()+" was locked onto your "+getBodyPartString()+", making it useless!"
	else:
		return getAStackNameCapitalize()+" was locked onto {receiver.nameS} "+getBodyPartString()+", making it useless!"

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/CockBeltIco.png"
