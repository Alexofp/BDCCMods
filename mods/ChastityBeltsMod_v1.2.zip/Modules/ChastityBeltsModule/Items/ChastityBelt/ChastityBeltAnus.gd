extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltBase.gd"

func getBodyPartSlot(): return BodypartSlot.Anus
func getBodyPartString(): return "anus"
func getInventorySlot(): return InventorySlot.Anal
func getBuffs():
	return [
	# vagina
#	buff(Buff.BlocksVaginaLeakingBuff),
#	buff(Buff.ChastityVaginaBuff),
	# anus
	buff(Buff.BlocksAnusLeakingBuff),
	buff(Buff.ChastityAnusBuff),
	#penis
#	buff(Buff.ChastityPenisBuff),
	# misc
#	buff(Buff.SensitivityGainBuff, [15.0]),
	buff(Buff.SkillExperienceBuff, [Skill.BDSM, 5])
]

func _init():
	id = "AnusChastityBelt"

func getVisibleName():
	return "Anus Chastity Belt"
	
func getDescription():
	return "Prevents access to the wearer's "+getBodyPartString()+"." #TODO

func getRiggedParts(_character):
	if _character.hasPenis():
		return {
			"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoCockBelt/NoCockBelt.tscn",
		}
	else:
		return {
			"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/Belt/justBelt.tscn",
		}

func getHidesParts(_character):
	return {
		BodypartSlot.Anus: true,
	}

#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "limp")

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/NoCockBeltIco.png"
