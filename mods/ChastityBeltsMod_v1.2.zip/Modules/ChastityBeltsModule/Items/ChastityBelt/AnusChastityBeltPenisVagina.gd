extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltPenis.gd"

func getBodyPartSlot(): return BodypartSlot.Vagina
func getBodyPartSlot2(): return BodypartSlot.Penis
func getBodyPartSlot3(): return BodypartSlot.Anus
func getBodyPartString(): return "anus, penis and vagina"
func getInventorySlot(): return InventorySlot.Penis
func getBuffs():
	return [
	# vagina
	buff(Buff.BlocksVaginaLeakingBuff),
	buff(Buff.ChastityVaginaBuff),
	# anus
	buff(Buff.BlocksAnusLeakingBuff),
	buff(Buff.ChastityAnusBuff),
	#penis
	buff(Buff.ChastityPenisBuff),
	# misc
	buff(Buff.SensitivityGainBuff, [15.0]),
	buff(Buff.SkillExperienceBuff, [Skill.BDSM, 5])
]

func _init():
	id = "EverythingChastityBelt"

func getVisibleName():
	return "Anus and Genitals Chastity Belt"


func getRequiredBodypart():
	return getBodyPartSlot()

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.CanBeForcedByGuards, ItemTag.ChastityCage, ItemTag.SoldByTheAnnouncer, ItemTag.CanBeForcedInStocks]

func getRiggedParts(_character):
	return {
		"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoCockBelt/NoCockBelt.tscn",
		"chastity_cage": "res://Modules/ChastityBeltsModule/Items/Models/CockBelt/CockBelt.tscn",
	}

#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "limp")

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
		BodypartSlot.Vagina: true,
		BodypartSlot.Anus: true,
	}

func shouldBeVisibleOnDoll(_character, _doll):
	if((!_character.isBodypartCovered(getBodyPartSlot()) || _doll.isForcedExposed(getBodyPartSlot()))
	|| (!_character.isBodypartCovered(getBodyPartSlot2()) || _doll.isForcedExposed(getBodyPartSlot2()))
	|| (!_character.isBodypartCovered(getBodyPartSlot3()) || _doll.isForcedExposed(getBodyPartSlot3()))
	):
		return true
	return false

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/CockBeltIco.png"
