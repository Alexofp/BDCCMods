extends "res://Modules/ChastityBeltsModule/Items/ChastityBelt/ChastityBeltBase.gd"

func getBodyPartSlot(): return BodypartSlot.Vagina
func getBodyPartSlot2(): return BodypartSlot.Anus
func getBodyPartString(): return "anus and vagina"
func getInventorySlot(): return InventorySlot.Vagina
func getBuffs():
	return [
	# vagina
	buff(Buff.BlocksVaginaLeakingBuff),
	buff(Buff.ChastityVaginaBuff),
	# anus
	buff(Buff.BlocksAnusLeakingBuff),
	buff(Buff.ChastityAnusBuff),
	#penis
#	buff(Buff.ChastityPenisBuff),
	# misc
	buff(Buff.SensitivityGainBuff, [15.0]),
	buff(Buff.SkillExperienceBuff, [Skill.BDSM, 5])
]

func _init():
	id = "AnusVaginalChastityBelt"

func getVisibleName():
	return "Anus and Vagina Chastity Belt"

func getDescription():
	return "Prevents access to the wearer's "+getBodyPartString()+"." #TODO

func getRequiredBodypart():
	return getBodyPartSlot()

func getTags():
	return [ItemTag.BDSMRestraint, ItemTag.CanBeForcedByGuards, ItemTag.SoldByTheAnnouncer, ItemTag.CanBeForcedInStocks]

func getRiggedParts(_character):
	if _character.hasPenis():
		return {
			"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/NoCockBelt/NoCockBelt.tscn",
		}
	else:
		return {
			"chastity_belt": "res://Modules/ChastityBeltsModule/Items/Models/Belt/justBelt.tscn",
		}

#func updateDoll(doll: Doll3D):
#	doll.setState("cock", "limp")

func getHidesParts(_character):
	return {
		BodypartSlot.Anus: true,
		BodypartSlot.Vagina: true,
	}

func shouldBeVisibleOnDoll(_character, _doll):
	if((!_character.isBodypartCovered(getBodyPartSlot()) || _doll.isForcedExposed(getBodyPartSlot()))
	|| (!_character.isBodypartCovered(getBodyPartSlot2()) || _doll.isForcedExposed(getBodyPartSlot2()))
	):
		return true
	return false

func getInventoryImage():
	return "res://Modules/ChastityBeltsModule/Items/Models/NoCockBeltIco.png"
