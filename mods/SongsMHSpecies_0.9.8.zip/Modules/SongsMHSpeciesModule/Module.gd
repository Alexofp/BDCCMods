extends Module

var BallsExtra = ResourceLoader.exists("res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd")
#var HABT = ResourceLoader.exists("res://Modules/HeatAndBehaviorTraits/Events/PlayerHeatEvent.gd")Heat and Behavior Traits patch (not yet)

func _init():
	id = "SMHspeciesmod"
	author = "Songjo"
	
	bodyparts = [
		#Odogaron
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/OdogaronBody.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Ears.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Penis_Slit.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Tail.gd",
		#Tobi-Kadachi
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Body.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Penis_Slit.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Tail.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Ears.gd",
		#Rathalos
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Body.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Penis_Slit.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Tail.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Ears.gd",
		#Mizutsune
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Ears.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/MizutsuneBody.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Tail.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Penis_Slit.gd",
		#Kulve Taroth
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Horns.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Body.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Tail_A.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Tail_B.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Penis_Slit.gd",
		#Nergigante
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergigante_Head.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergigante_Horns.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Arms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Body.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_BuffArms.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Legs.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Penis.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Penis_Slit.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Tail.gd"
		]
	
	species = [
		"res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth.gd",
		"res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergigante.gd"
	]

	##Balls Extra patch
	if BallsExtra == true:
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Penis.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Odogaron/Odogaron_Penis_Slit.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Penis.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Tobikadachi/Tobikadachi_Penis_Slit.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Penis.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Rathalos/Rathalos_Penis_Slit.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Penis.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Mizutsune/Mizutsune_Penis_Slit.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Penis.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Taroth/Taroth_Penis_Slit.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Penis.gd")
		bodyparts.erase("res://Modules/SongsMHSpeciesModule/Scripts/Nergigante/Nergi_Penis_Slit.gd")
		
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Odogaron_Penis_BE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Odogaron_Penis_SlitBE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Tobikadachi_Penis_BE.gd") 
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Tobikadachi_Penis_SlitBE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Rathalos_Penis_BE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Rathalos_Penis_SlitBE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Mizutsune_Penis_BE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Mizutsune_Penis_SlitBE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Taroth_Penis_BE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Taroth_Penis_SlitBE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Nergi_Penis_BE.gd")
		bodyparts.insert(0,"res://Modules/SongsMHSpeciesModule/Patches/BallsExtra/Nergi_Penis_SlitBE.gd")

	##HABT patch (Not yet)
#	if HABT == true:
#		statusEffects = [
#			"res://Modules/SongsMHSpeciesModule/Patches/HABT/HABT_Nergigante.gd",
#		]
