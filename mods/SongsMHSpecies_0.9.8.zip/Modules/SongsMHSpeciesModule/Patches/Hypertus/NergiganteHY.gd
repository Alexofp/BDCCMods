extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "sNergi"
	
func getVisibleName():
	return "Nergigante"

func getDefaultLegs(_gender):
	return "sNergiLegs"

func getDefaultTail(_gender):
	return "sNergitail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Extinction Dragon"

func getDefaultHead(_gender):
	return "sNergiHead"

func getDefaultArms(_gender):
	return "sNergiArmsBuff"

func getDefaultEars(_gender):
	return "sTobikadachiears"

func getDefaultBody(_gender):
	return "sNergibody"

func getDefaultHorns(_gender):
	return "sNergiHorns"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sNergiPHY"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#484252", "#5d486a", "#a6a295"], 
		["#6c5973", "#352341", "#a39e94"], 
		["#3f364b", "#7c579f", "#b1a47f"],
		["#3d333e", "#492967", "#ad9fb7"],
		#ruiner nergigante
		["#35353e", "#625f6c", "#42414a"],
		["#323053", "#2c2630", "#3f3c56"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
	
