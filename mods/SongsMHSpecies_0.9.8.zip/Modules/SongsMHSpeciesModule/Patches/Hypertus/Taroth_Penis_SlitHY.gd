extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Slited Hyperable Kulve penis"
	id = "sKulvePSHY"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["dragon", "knotted", "slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Penis_Slit/Taroth_Penis_slit.tscn"

func getVulgarName() -> String:
	return "knotted dragon cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		"Hyperable": true,
	}

func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func getCharacterCreatorDesc():
	return "From MH Species"
