extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Slited Hyperable  Nergigante penis"
	id = "sNergiPSHY"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["dragon", "knotted", "barbed", "slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Penis_Slit/Nergi_Penis_slit.tscn"

func getVulgarName() -> String:
	return "Knotted dragon cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
		"Hyperable": true,
		}

func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func getCharacterCreatorDesc():
	return "From MH Species"
