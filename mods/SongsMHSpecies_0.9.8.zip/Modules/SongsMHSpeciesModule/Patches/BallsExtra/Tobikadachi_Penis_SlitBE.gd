extends "res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd"

func _init():
	visibleName = "Slited Tobikadachi penis"
	id = "sTobikadachiPenisSlit"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "wyvern", "ribbed"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Penis_Slit/Tobikadachi_Penis_slit.tscn"

func getVulgarName() -> String:
	return "wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getCharacterCreatorDesc():
	return "From MH Species"
