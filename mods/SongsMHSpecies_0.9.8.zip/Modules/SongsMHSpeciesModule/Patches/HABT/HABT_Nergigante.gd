extends StatusEffectBase

const IconColorFaintBlue = Color("#566375")

func _init():
	id = "HABT_Nergi"
	isBattleOnly = false
	
	alwaysCheckedForNPCs = true
	alwaysCheckedForPlayer = true
	priorityDuringChecking = 91

func shouldApplyTo(_npc):
	var allowed_species = ["sNergi"]
	
	for species in allowed_species:
		if(_npc.getSpecies().has(species)):
			return true
	return false

func getEffectName():
	var state = getCurrentState()
	
	match state:
		"tired": return "Nergigante"
		"inheat": return "Nergigante"
		_: return "Nergigante"

func getEffectDesc():
	var state = getCurrentState()
	var bodyType = getBodyType()
	
	return "Bodyparts combo: " + getBodyTypeName(bodyType) + "\nState: " + getStateName(state)

func getEffectImage():
	return "res://Modules/SongsMHSpeciesModule/Patches/HABT/Icons/Nergigante.png"

func getIconColor():
	var state = getCurrentState()
	
	match state:
		"tired": return IconColorFaintBlue
		"inheat": return IconColorYellow
		_: return IconColorRed

func getCurrentState():
	if character.getStamina() < 24:
		return "tired"
	elif character.isInHeat():
		return "inheat"
	else:
		return "stable"

func hasFemaleBreasts():
	if !character.hasBodypart(BodypartSlot.Breasts):
		return false
	
	var breasts = character.getBodypart(BodypartSlot.Breasts)
	if breasts == null:
		return false
	
	var breastSize = breasts.getSize()
	return breastSize > 0

func getBodyParts():
	var parts = []
	
	if hasFemaleBreasts():
		parts.append("Breasts")
	
	if character.hasBodypart(BodypartSlot.Penis):
		var penis = character.getBodypart(BodypartSlot.Penis)
		if penis != null:
			parts.append("Penis")
	
	if character.hasBodypart(BodypartSlot.Vagina):
		var vagina = character.getBodypart(BodypartSlot.Vagina)
		if vagina != null:
			parts.append("Vagina")
	
	return parts

func getBodyType():
	var parts = getBodyParts()
	parts.sort()
	
	if parts.size() == 0:
		return "unknown"
	
	match parts:
		["Penis"]: return "male"
		["Breasts", "Vagina"]: return "female"
		["Breasts", "Penis"]: return "shemale"
		["Breasts", "Penis", "Vagina"]: return "herm"
		["Vagina"]: return "peachboy"
		["Penis", "Vagina"]: return "maleherm"
		_: return "unknown"

func getBodyTypeName(bodyType):
	match bodyType:
		"male": return "Male"
		"female": return "Female"
		"shemale": return "Shemale"
		"herm": return "Herm"
		"peachboy": return "Peachboy"
		"maleherm": return "Maleherm"
		_: return "Unknown"

func getStateName(state):
	match state:
		"tired": return "Tired"
		"inheat": return "In Heat"
		"stable": return "Stable"
		_: return "Unknown"

func getBuffs():
	var state = getCurrentState()
	var bodyType = getBodyType()
	
	match bodyType:
		"male":
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.PenisCumProductionBuff,[-30]),
						buff(Buff.VirilityBuff,[-15]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.StatBuff, [Stat.Strength, 3]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.VirilityBuff,[15]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
		
		"female":
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.OvulationEggsAmountBuff, [-20]),
						buff(Buff.FertilityBuff,[-20]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.ReceivedLustDamageBuff, [35]),
						buff(Buff.PhysicalDamageBuff,[25]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.OvulationEggsAmountBuff, [50]),
						buff(Buff.FertilityBuff,[20]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 3]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.FertilityBuff,[10]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
		
		"shemale":
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.PenisCumProductionBuff,[-30]),
						buff(Buff.VirilityBuff,[-15]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.StatBuff, [Stat.Strength, 3]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.VirilityBuff,[15]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
		
		"herm":
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.PenisCumProductionBuff,[-30]),
						buff(Buff.OvulationEggsAmountBuff, [-20]),
						buff(Buff.FertilityBuff,[-20]),
						buff(Buff.VirilityBuff,[-15]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.ReceivedLustDamageBuff, [35]),
						buff(Buff.PhysicalDamageBuff,[25]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PenisCumProductionBuff,[70]),
						buff(Buff.OvulationEggsAmountBuff, [50]),
						buff(Buff.FertilityBuff,[20]),
						buff(Buff.VirilityBuff,[35]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 3]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.FertilityBuff,[10]),
						buff(Buff.VirilityBuff,[15]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
		
		"peachboy":
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.OvulationEggsAmountBuff, [-20]),
						buff(Buff.FertilityBuff,[-20]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.ReceivedLustDamageBuff, [35]),
						buff(Buff.PhysicalDamageBuff,[25]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.OvulationEggsAmountBuff, [50]),
						buff(Buff.FertilityBuff,[20]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 3]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.FertilityBuff,[10]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
		
		"maleherm":
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.PenisCumProductionBuff,[-30]),
						buff(Buff.OvulationEggsAmountBuff, [-20]),
						buff(Buff.FertilityBuff,[-20]),
						buff(Buff.VirilityBuff,[-15]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.ReceivedLustDamageBuff, [35]),
						buff(Buff.PhysicalDamageBuff,[25]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PenisCumProductionBuff,[70]),
						buff(Buff.OvulationEggsAmountBuff, [50]),
						buff(Buff.FertilityBuff,[20]),
						buff(Buff.VirilityBuff,[35]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 3]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.FertilityBuff,[10]),
						buff(Buff.VirilityBuff,[15]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
		
		_:
			match state:
				"tired":
					return [
						buff(Buff.ReceivedLustDamageBuff, [20]),
						buff(Buff.PhysicalDamageBuff,[7]),
						buff(Buff.PhysicalArmorBuff,[5]),
						buff(Buff.PenisCumProductionBuff,[-30]),
						buff(Buff.OvulationEggsAmountBuff, [-20]),
						buff(Buff.FertilityBuff,[-20]),
						buff(Buff.VirilityBuff,[-15]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 1]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"inheat":
					return [
						buff(Buff.ReceivedLustDamageBuff, [35]),
						buff(Buff.PhysicalDamageBuff,[25]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PenisCumProductionBuff,[70]),
						buff(Buff.OvulationEggsAmountBuff, [50]),
						buff(Buff.FertilityBuff,[20]),
						buff(Buff.VirilityBuff,[35]),
						buff(Buff.StatBuff, [Stat.Vitality, 5]),
						buff(Buff.StatBuff, [Stat.Strength, 3]),
						buff(Buff.StatBuff, [Stat.Agility, 4]),
					]
				"stable":
					return [
						buff(Buff.ReceivedLustDamageBuff, [15]),
						buff(Buff.PhysicalArmorBuff,[15]),
						buff(Buff.PhysicalDamageBuff,[15]),
						buff(Buff.FertilityBuff,[10]),
						buff(Buff.VirilityBuff,[15]),
						buff(Buff.StatBuff, [Stat.Vitality, 3]),
						buff(Buff.StatBuff, [Stat.Strength, 2]),
						buff(Buff.StatBuff, [Stat.Agility, 2]),
					]
