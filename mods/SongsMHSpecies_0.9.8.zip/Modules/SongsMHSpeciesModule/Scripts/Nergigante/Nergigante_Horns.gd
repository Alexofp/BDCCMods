extends BodypartHorns

func _init():
	visibleName = "Nergigante Horns"
	id = "sNergiHorns"

func getCompatibleSpecies():
	return ["sNergi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Horns/Nergi_Horns.tscn"
