extends BodypartHead

func _init():
	visibleName = "Nergigante Head"
	id = "sNergiHead"

func getCompatibleSpecies():
	return ["sNergi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Head/Nergi_Head.tscn"

func getHeadLength():
	return 0.75
