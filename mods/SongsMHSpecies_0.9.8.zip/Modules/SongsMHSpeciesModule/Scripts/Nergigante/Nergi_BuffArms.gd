extends BodypartArms

func _init():
	visibleName = "Nergigante buff arms"
	id = "sNergiArmsBuff"

func getCompatibleSpecies():
	return ["sNergi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Arms/Nergi_BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
