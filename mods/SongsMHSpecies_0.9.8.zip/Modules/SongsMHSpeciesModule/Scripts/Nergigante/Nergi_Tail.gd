extends BodypartTail

func _init():
	visibleName = "Nergigante Tail"
	id = "sNergitail"

func getCompatibleSpecies():
	return ["sNergi"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Tail/Nergi_Tail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
