extends BodypartLeg

func _init():
	visibleName = "Nergigante legs"
	id = "sNergiLegs"

func getCompatibleSpecies():
	return ["sNergi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Legs/Nergi_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
