extends BodypartArms

func _init():
	visibleName = "Nergigante arms"
	id = "sNergiArms"

func getCompatibleSpecies():
	return ["sNergi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Nergigante/Nergi_Arms/Nergi_Arms.tscn"
