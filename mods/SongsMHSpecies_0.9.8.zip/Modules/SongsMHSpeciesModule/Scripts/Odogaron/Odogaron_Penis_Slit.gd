extends BodypartPenis

func _init():
	visibleName = "Slited Odogaron penis"
	id = "sOdogaronPS"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "wyvern", "canine", "ribbed", "Slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Penis_Slit/Odogaron_Penis_slit.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}

func getVulgarName() -> String:
	return "knotted wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getCharacterCreatorDesc():
	return "From MH Species"
