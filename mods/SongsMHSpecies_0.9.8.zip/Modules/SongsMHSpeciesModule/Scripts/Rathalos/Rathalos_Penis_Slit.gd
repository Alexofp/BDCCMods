extends BodypartPenis

func _init():
	visibleName = "Slited Rathalos penis"
	id = "sRathalosPenisSlit"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["knotted", "wyvern", "ribbed", "Slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Penis_Slit/Rathalos_Penis_slit.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}

func getVulgarName() -> String:
	return "wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0

func getCharacterCreatorDesc():
	return "From MH Species"
