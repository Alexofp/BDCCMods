extends BodypartPenis

func _init():
	visibleName = "Slited Kulve penis"
	id = "sKulvePS"

func getCompatibleSpecies():
	return [Species.Any]

func getLewdAdjective():
	return RNG.pick(["dragon", "knotted", "slitted"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Taroth/Taroth_Penis_Slit/Taroth_Penis_slit.tscn"

func getVulgarName() -> String:
	return "knotted dragon cock"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		}

func npcGenerationWeight(_dynamicCharacter):
	return 0.0

func getCharacterCreatorDesc():
	return "From MH Species"
