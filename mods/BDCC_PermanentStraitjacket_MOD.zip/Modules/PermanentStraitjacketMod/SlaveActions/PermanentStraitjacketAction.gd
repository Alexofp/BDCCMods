extends SlaveActionBase

func _init():
	id = "PermanentStraitjacketAction"
	actionType = Action
	sceneID = "PermanentStraitjacketActionScene"
	buttonPriority = 32
	slaveMinLevel = 0

func getVisibleName():
	return "Permanent straitjacket"

func getVisibleDesc():
	return "Lock a permanent straitjacket onto this slave with a password, or unlock an existing one."

func _getWornJacket(_slaveID):
	var npc = GlobalRegistry.getCharacter(_slaveID)
	if(npc == null):
		return null
	var item = npc.getInventory().getEquippedItem(InventorySlot.Body)
	if(item != null && item.id == "PermanentStraitjacket"):
		return item
	return null

func isActionVisible(_slaveID):
	if(_getWornJacket(_slaveID) != null):
		return true
	if(GM.pc != null && GM.pc.getInventory().hasItemID("PermanentStraitjacket")):
		return true
	return false

func checkCanDo(_slaveID, _extraSlavesIDs = {}):
	var npc = GlobalRegistry.getCharacter(_slaveID)
	if(npc == null):
		return [false, "NPC not found."]

	if(_getWornJacket(_slaveID) != null):
		return [true]

	if(GM.pc == null || !GM.pc.getInventory().hasItemID("PermanentStraitjacket")):
		return [false, "You need a Permanent Straitjacket in your inventory."]

	if(!npc.invCanEquipSlot(InventorySlot.Body)):
		return [false, "This NPC cannot use the Body clothing slot."]

	if(npc.getInventory().hasSlotEquipped(InventorySlot.Body)):
		return [false, "Remove the item currently occupying the Body slot first."]

	return [true]
