extends "res://Scenes/SceneBase.gd"

var npcID:String = ""
var npc:DynamicCharacter
var errorText:String = ""

func _init():
	sceneID = "PermanentStraitjacketActionScene"

func _initScene(_args = []):
	if(_args.size() > 0):
		npcID = _args[0]
	npc = GlobalRegistry.getCharacter(npcID)

func resolveCustomCharacterName(_charID):
	if(_charID == "npc"):
		return npcID

func _getWornJacket():
	if(npc == null):
		return null
	var item = npc.getInventory().getEquippedItem(InventorySlot.Body)
	if(item != null && item.id == "PermanentStraitjacket"):
		return item
	return null

func _getPlayerJacket():
	if(GM.pc == null):
		return null
	for item in GM.pc.getInventory().getItems():
		if(item.id == "PermanentStraitjacket"):
			return item
	return null

func _showError():
	if(errorText != ""):
		saynn("[color=red]" + errorText + "[/color]")

func _run():
	if(npc == null):
		saynn("The NPC could not be found.")
		addButton("Close", "Return", "endthescene")
		return

	addCharacter(npcID)
	playAnimation(StageScene.Duo, "stand", {npc=npcID})

	if(state == ""):
		var worn = _getWornJacket()
		if(worn != null):
			saynn("{npc.name} is wearing a password-locked Permanent Straitjacket.")
			saynn("Enter the password to unlock and remove it. The NPC cannot remove it alone.")
			_showError()
			var unlockBox:LineEdit = addTextbox("psj_unlock_password")
			unlockBox.secret = true
			unlockBox.max_length = 64
			addButton("Unlock", "Remove the straitjacket if the password is correct", "unlock")
			addButton("Cancel", "Leave it locked", "endthescene")
			return

		var jacket = _getPlayerJacket()
		if(jacket == null):
			saynn("You do not have a Permanent Straitjacket in your inventory.")
			addButton("Close", "Return", "endthescene")
			return

		if(!npc.invCanEquipSlot(InventorySlot.Body)):
			saynn("{npc.name} cannot use the Body clothing slot.")
			addButton("Close", "Return", "endthescene")
			return

		if(npc.getInventory().hasSlotEquipped(InventorySlot.Body)):
			saynn("The Body slot is already occupied. Remove that item first.")
			addButton("Close", "Return", "endthescene")
			return

		saynn("Choose the password for the Permanent Straitjacket before locking it onto {npc.name}.")
		saynn("The password must contain at least 4 characters. You will need the exact same password to remove the restraint later.")
		_showError()

		say("Password: ")
		var passwordBox:LineEdit = addTextbox("psj_password")
		passwordBox.secret = true
		passwordBox.max_length = 64
		say("\nConfirm password: ")
		var confirmBox:LineEdit = addTextbox("psj_password_confirm")
		confirmBox.secret = true
		confirmBox.max_length = 64

		addButton("Lock it", "Set the password and equip the permanent straitjacket", "apply")
		addButton("Cancel", "Do not equip it", "endthescene")
		return

	if(state == "applied"):
		saynn("You secure the Permanent Straitjacket around {npc.name} and engage its password lock.")
		saynn("[color=yellow]{npc.name} cannot struggle out of it, use a restraint key to remove it, or take it off through normal inventory management.[/color]")
		addButton("Continue", "Finish", "endthescene")
		return

	if(state == "unlocked"):
		saynn("Password accepted. You unlock the Permanent Straitjacket and remove it from {npc.name}.")
		saynn("The lock has been reset and the straitjacket was returned to your inventory.")
		addButton("Continue", "Finish", "endthescene")
		return

func _react(_action:String, _args):
	if(_action == "endthescene"):
		endScene()
		return

	if(_action == "apply"):
		var password:String = str(getTextboxData("psj_password"))
		var confirmation:String = str(getTextboxData("psj_password_confirm"))

		if(password.length() < 4):
			errorText = "The password must contain at least 4 characters."
			setState("")
			return
		if(password != confirmation):
			errorText = "The two passwords do not match."
			setState("")
			return

		var jacket = _getPlayerJacket()
		if(jacket == null):
			errorText = "The Permanent Straitjacket is no longer in your inventory."
			setState("")
			return
		if(npc.getInventory().hasSlotEquipped(InventorySlot.Body)):
			errorText = "The Body slot became occupied. Remove that item first."
			setState("")
			return
		if(!jacket.setLockPassword(password)):
			errorText = "The password could not be configured."
			setState("")
			return

		GM.pc.getInventory().removeItem(jacket)
		var equippedOk = npc.getInventory().equipItem(jacket)
		if(!equippedOk):
			jacket.clearLockPassword()
			GM.pc.getInventory().addItem(jacket)
			errorText = "The restraint could not be equipped."
			setState("")
			return

		jacket.onEquippedBy(GM.pc, true)
		npc.updateAppearance()
		npc.updateNonBattleEffects()
		errorText = ""
		setState("applied")
		return

	if(_action == "unlock"):
		var jacket = _getWornJacket()
		if(jacket == null):
			errorText = "The locked straitjacket is no longer equipped."
			setState("")
			return

		var password:String = str(getTextboxData("psj_unlock_password"))
		if(!jacket.verifyLockPassword(password)):
			errorText = "Incorrect password. The straitjacket remains locked."
			setState("")
			return

		if(!npc.getInventory().unequipItem(jacket)):
			errorText = "The password was correct, but the restraint could not be removed."
			setState("")
			return

		npc.getInventory().removeItem(jacket)
		jacket.clearLockPassword()
		GM.pc.getInventory().addItem(jacket)
		npc.updateAppearance()
		npc.updateNonBattleEffects()
		errorText = ""
		setState("unlocked")
		return

	setState(_action)

func saveData():
	var data = .saveData()
	data["npcID"] = npcID
	data["errorText"] = errorText
	return data

func loadData(data):
	.loadData(data)
	npcID = SAVE.loadVar(data, "npcID", "")
	errorText = SAVE.loadVar(data, "errorText", "")
	npc = GlobalRegistry.getCharacter(npcID)
