extends ItemBase

const PASSWORD_SALT = "BDCC_PERMANENT_STRAITJACKET_MOD_V1|"
var lockPasswordHash:String = ""

func _init():
	id = "PermanentStraitjacket"

func getVisibleName():
	return "Permanent Straitjacket"

func getDescription():
	var text = "A reinforced latex straitjacket with a player-controlled password lock. Once locked onto an NPC, the NPC cannot struggle out of it or remove it with restraint keys."
	if(hasLockPassword()):
		text += "\n[color=yellow]Password lock: ACTIVE[/color]"
	else:
		text += "\n[color=gray]Password lock: not configured[/color]"
	text += "\nUse the 'Permanent straitjacket' slave action to apply or unlock it."
	return text

func getInventoryName():
	var result = .getInventoryName()
	if(hasLockPassword()):
		result += " (PASSWORD LOCKED)"
	return result

func getClothingSlot():
	return InventorySlot.Body

func getBuffs():
	return [
		buff(Buff.BlockedHandsBuff),
		buff(Buff.RestrainedArmsBuff),
	]

func getTags():
	return [
		ItemTag.BDSMRestraint,
		ItemTag.SoldByTheAnnouncer,
	]

func getPrice():
	return 100

func getSellPrice():
	return 50

func generateRestraintData():
	restraintData = RestraintUnremovable.new()
	restraintData.aiWontResist = true

# Standard NPC inventory management is intentionally prevented from applying
# this item because a password must be chosen first in the mod's slave action.
func canForceOntoNpc():
	return false

func canForceOntoStaticNpc():
	return false

# This non-default scene also makes ActionSlaveryManageInventory reject normal
# equipping. The dedicated mod action is the only supported way to apply it.
func getPutOnScene():
	return "PermanentStraitjacketCannotSelfEquipScene"

func getTakeOffScene():
	return "PermanentStraitjacketCannotSelfEquipScene"

func canBeEasilyRemovedByDom():
	return false

func isImportant():
	return true

func isPersistent():
	return true

func coversBodyparts():
	return {
		BodypartSlot.Body: true,
		BodypartSlot.Vagina: true,
		BodypartSlot.Penis: true,
	}

func getRiggedParts(_character):
	return {
		"straitjacket": "res://Inventory/RiggedModels/StraitJacket/StraitJacket.tscn",
	}

func getHidesParts(_character):
	return {
		BodypartSlot.Penis: true,
		BodypartSlot.Arms: true,
	}

func getHidesAttachments(_character):
	return {
		"wrist.R": true,
		"wrist.L": true,
	}

func getInventoryImage():
	return "res://Images/Items/bdsm/jacket.png"

func hasLockPassword() -> bool:
	return lockPasswordHash != ""

func _hashPassword(password:String) -> String:
	return (PASSWORD_SALT + password).sha256_text()

func setLockPassword(password:String) -> bool:
	if(password.length() < 4):
		return false
	lockPasswordHash = _hashPassword(password)
	return true

func verifyLockPassword(password:String) -> bool:
	if(!hasLockPassword()):
		return false
	return _hashPassword(password) == lockPasswordHash

func clearLockPassword():
	lockPasswordHash = ""

func saveData():
	var data = .saveData()
	data["lockPasswordHash"] = lockPasswordHash
	return data

func loadData(_data):
	.loadData(_data)
	lockPasswordHash = SAVE.loadVar(_data, "lockPasswordHash", "")
