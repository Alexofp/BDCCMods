extends Module

func _init():
	id = "PermanentStraitjacketMod"
	author = "Roberto"

	items = [
		"res://Modules/PermanentStraitjacketMod/Items/PermanentStraitjacket.gd",
	]

	scenes = [
		"res://Modules/PermanentStraitjacketMod/Scenes/PermanentStraitjacketActionScene.gd",
		"res://Modules/PermanentStraitjacketMod/Scenes/PermanentStraitjacketCannotSelfEquipScene.gd",
	]

	slaveActions = [
		"res://Modules/PermanentStraitjacketMod/SlaveActions/PermanentStraitjacketAction.gd",
	]

	gameExtenders = [
		"res://Modules/PermanentStraitjacketMod/Extenders/PermanentStraitjacketExtender.gd",
	]
