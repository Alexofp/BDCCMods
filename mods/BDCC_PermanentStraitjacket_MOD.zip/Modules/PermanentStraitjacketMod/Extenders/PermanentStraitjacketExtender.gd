extends GameExtender

func _init():
	id = "PermanentStraitjacketExtender"

func register(_GES:GameExtenderSystem):
	_GES.register(self, ExtendGame.npcUpdateNonBattleEffects)
	_GES.register(self, ExtendGame.npcProcessTime)
	_GES.register(self, ExtendGame.npcHoursPassed)

func _restoreLockedJacket(_npc):
	if(_npc == null || !_npc.has_method("getInventory")):
		return

	var inv = _npc.getInventory()
	if(inv == null):
		return

	var worn = inv.getEquippedItem(InventorySlot.Body)
	if(worn != null && worn.id == "PermanentStraitjacket" && worn.has_method("hasLockPassword") && worn.hasLockPassword()):
		return

	var lockedJacket = null
	for item in inv.getItems():
		if(item.id == "PermanentStraitjacket" && item.has_method("hasLockPassword") && item.hasLockPassword()):
			lockedJacket = item
			break

	if(lockedJacket == null):
		return

	# A locked jacket found in the NPC's stored inventory means some external
	# system removed it. Put it back on and store whatever replaced the Body slot.
	inv.removeItem(lockedJacket)
	var ok = inv.forceEquipStoreOther(lockedJacket)
	if(!ok):
		inv.addItem(lockedJacket)
		return

	if(_npc.has_method("updateAppearance")):
		_npc.updateAppearance()

func npcUpdateNonBattleEffects(_npc:Character):
	_restoreLockedJacket(_npc)

func npcProcessTime(_npc:Character, _seconds):
	_restoreLockedJacket(_npc)

func npcHoursPassed(_npc:Character, _hours):
	_restoreLockedJacket(_npc)
