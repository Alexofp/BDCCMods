BDCC - MOD: Permanent Straitjacket con contraseña
==================================================

IMPORTANTE
----------
Este paquete es un MOD independiente. NO reemplaza ni modifica archivos del
proyecto original de BDCC.

Contenido del mod
-----------------
- Objeto nuevo: Permanent Straitjacket
- ID: PermanentStraitjacket
- Se vende en la tienda del Announcer/Fight Club por 100 créditos.
- Usa el modelo visual de la straitjacket original de BDCC.
- El NPC no puede forcejear para quitársela.
- Las restraint keys no la abren.
- Está marcada como Important y Persistent.
- Un GameExtender del propio mod vuelve a equiparla si un proceso automático
  del NPC la mueve accidentalmente a su inventario mientras sigue bloqueada.
- La contraseña se almacena como hash SHA-256 dentro de los datos del objeto y
  persiste al guardar/cargar la partida.

Uso
---
1. Instala el ZIP como mod de BDCC.
2. Compra Permanent Straitjacket en el Announcer/Fight Club.
3. Habla con un NPC esclavizado.
4. En sus acciones aparecerá "Permanent straitjacket".
5. Si el NPC no la lleva puesta, la acción pedirá una contraseña y confirmación.
6. Tras bloquearla, el NPC no podrá quitársela por sí mismo.
7. Para retirarla, usa de nuevo "Permanent straitjacket" e introduce la
   contraseña correcta.
8. Al desbloquearla, vuelve al inventario del jugador y su contraseña se resetea.

Notas
-----
- La contraseña debe tener al menos 4 caracteres.
- El slot Body del NPC debe estar libre antes de aplicarla.
- El menú normal Take/Equip NO puede poner ni quitar esta camisa. Esto es
  intencional: así el mod puede exigir la contraseña sin parchear la UI original.
- El mod está orientado al sistema de NPC esclavizados de BDCC, que es donde el
  juego ofrece acciones de administración directa sobre NPCs.

Instalación
-----------
Coloca el archivo:
  BDCC_PermanentStraitjacket_MOD.zip

en la carpeta de mods de BDCC (user://mods desde la perspectiva de Godot) o
selecciónalo mediante el sistema de mods del juego si tu versión lo permite.

Estructura interna
------------------
Modules/PermanentStraitjacketMod/Module.gd
Modules/PermanentStraitjacketMod/Items/PermanentStraitjacket.gd
Modules/PermanentStraitjacketMod/SlaveActions/PermanentStraitjacketAction.gd
Modules/PermanentStraitjacketMod/Scenes/PermanentStraitjacketActionScene.gd
Modules/PermanentStraitjacketMod/Scenes/PermanentStraitjacketCannotSelfEquipScene.gd
Modules/PermanentStraitjacketMod/Extenders/PermanentStraitjacketExtender.gd

El proyecto original no necesita ser editado.
