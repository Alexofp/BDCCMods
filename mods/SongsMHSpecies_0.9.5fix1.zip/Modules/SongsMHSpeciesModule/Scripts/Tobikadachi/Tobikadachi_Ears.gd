extends BodypartEars

func _init():
	visibleName = "Tobikadachi ears"
	id = "sTobikadachiears"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getDoll3DScene():
	return null
