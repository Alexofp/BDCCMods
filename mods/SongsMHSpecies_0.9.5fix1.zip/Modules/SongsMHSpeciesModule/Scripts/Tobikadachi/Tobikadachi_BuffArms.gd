extends BodypartArms

func _init():
	visibleName = "Tobikadachi buff arms"
	id = "sTobikadachiArmsBuff"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Arms/Tobikadachi_BuffArm.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
