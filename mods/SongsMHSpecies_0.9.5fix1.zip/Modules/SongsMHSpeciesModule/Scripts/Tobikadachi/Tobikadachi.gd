extends Species

func _init():
	id = "sTobikadachi"
	
func getVisibleName():
	return "Tobikadachi"

func getDefaultLegs(_gender):
	return "sTobikadachiLegs"

func getDefaultTail(_gender):
	return "sTobikadachiTail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Flying Thunder Wyvern"

func getDefaultHead(_gender):
	return "sTobikadachiHead"

func getDefaultArms(_gender):
	return "sTobikadachiArms"

func getDefaultEars(_gender):
	return "sTobikadachiears"

func getDefaultBody(_genger):
	return "sTobikadachibody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sTobikadachiPenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#d4d7e8", "#77b9c7", "#3f6581"], 
		["#b4c5de", "#345f68", "#5b9db5"], 
		["#a5bbea", "#56a1d6", "#afafff"],
		["#74a3b8", "#29475c", "#4b4b5b"],
		#Viper Tobikadachi
		["#ba913a", "#e8b407", "#227c67"],
		["#ba7a3a", "#715909", "#e37200"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
	
