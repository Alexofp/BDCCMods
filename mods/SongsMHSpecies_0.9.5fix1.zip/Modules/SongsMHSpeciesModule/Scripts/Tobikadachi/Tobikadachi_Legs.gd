extends BodypartLeg

func _init():
	visibleName = "Tobikadachi legs"
	id = "sTobikadachiLegs"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Legs/Tobikadachi_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
