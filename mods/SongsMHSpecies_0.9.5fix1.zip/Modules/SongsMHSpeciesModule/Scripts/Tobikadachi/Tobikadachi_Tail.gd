extends BodypartTail

func _init():
	visibleName = "Tobikadachi tail"
	id = "sTobikadachiTail"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Tail/Tobikadachi_Tail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
