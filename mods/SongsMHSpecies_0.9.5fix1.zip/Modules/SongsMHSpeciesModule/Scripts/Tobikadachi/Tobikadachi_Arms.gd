extends BodypartArms

func _init():
	visibleName = "Tobikadachi arms"
	id = "sTobikadachiArms"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Arms/Tobikadachi_Arm.tscn"
