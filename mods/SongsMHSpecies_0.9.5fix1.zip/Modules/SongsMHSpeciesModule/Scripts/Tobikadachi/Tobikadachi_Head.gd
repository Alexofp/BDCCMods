extends BodypartHead

func _init():
	visibleName = "OTobikadachi Head"
	id = "sTobikadachiHead"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getCharacterCreatorDesc():
	return "From Hoofy Species"

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Head/Tobikadachi_Head.tscn"

func getHeadLength():
	return 0.75
