extends BodypartBody

func _init():
	visibleName = "Tobikadachi body"
	id = "sTobikadachibody"

func getCompatibleSpecies():
	return ["sTobikadachi"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/TobiKadachi/Tobikadachi_Body/Tobikadachi_Body.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
