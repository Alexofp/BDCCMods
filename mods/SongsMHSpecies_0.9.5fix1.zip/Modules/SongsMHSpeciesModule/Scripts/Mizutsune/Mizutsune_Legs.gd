extends BodypartLeg

func _init():
	visibleName = "odogaron legs"
	id = "sOdogaronLegs"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Legs/Odogaron_Legs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
