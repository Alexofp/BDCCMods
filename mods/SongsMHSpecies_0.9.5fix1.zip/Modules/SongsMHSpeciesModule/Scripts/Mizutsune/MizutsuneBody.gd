extends BodypartBody

func _init():
	visibleName = "odogaron body"
	id = "sOdogaronbody"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Body/Odogaron_Body.tscn"

func getVulgarName() -> String:
	return "normal body"

func getAVulgarName() -> String:
	return "a normal body"
