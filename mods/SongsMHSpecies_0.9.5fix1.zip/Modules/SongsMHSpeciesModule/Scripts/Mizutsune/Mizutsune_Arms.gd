extends BodypartArms

func _init():
	visibleName = "odogaron arms"
	id = "sOdogaronArms"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Arms/Odogaron_Arms.tscn"
