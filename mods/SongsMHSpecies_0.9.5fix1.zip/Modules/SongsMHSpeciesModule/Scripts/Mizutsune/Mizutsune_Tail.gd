extends BodypartTail

func _init():
	visibleName = "odogaron tail"
	id = "sOdogaronTail"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Tail/Odogaron_tail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
