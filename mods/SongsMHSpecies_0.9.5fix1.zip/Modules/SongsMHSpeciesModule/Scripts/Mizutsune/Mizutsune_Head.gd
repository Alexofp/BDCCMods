extends BodypartHead

func _init():
	visibleName = "Mizutsune Head"
	id = "sMizutsuneHead"

func getCompatibleSpecies():
	return ["sMizutsune"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Mizutsune/Mizutsune_Head/Mizutsune_Head.tscn"

func getHeadLength():
	return 0.75
