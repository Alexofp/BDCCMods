extends BodypartPenis

func _init():
	visibleName = "Odogaron penis"
	id = "sOdogaronP"

func getCompatibleSpecies():
	return Species.Any

func getLewdAdjective():
	return RNG.pick(["knotted", "wyvern", "canine", "ribbed"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Penis/Odogaron_Penis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}

func getVulgarName() -> String:
	return "knotted wyvern cock"

func npcGenerationWeight(_dynamicCharacter):
	if !(_dynamicCharacter.npcGeneratedGender in NpcGender.getAllWithPenis()):
		return 0.0
	else:
		return 1.0
