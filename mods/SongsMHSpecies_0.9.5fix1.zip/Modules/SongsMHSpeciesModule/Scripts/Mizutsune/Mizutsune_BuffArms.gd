extends BodypartArms

func _init():
	visibleName = "odogaron buff arms"
	id = "sOdogaronArmsBuff"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Arms/Odogaron_BuffArms.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
