extends BodypartEars

func _init():
	visibleName = "odogaron ears"
	id = "sOdogaronEars"

func getCompatibleSpecies():
	return ["sOdogaron"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Odogaron/Odogaron_Ears/Odogaron_Ears.tscn"
