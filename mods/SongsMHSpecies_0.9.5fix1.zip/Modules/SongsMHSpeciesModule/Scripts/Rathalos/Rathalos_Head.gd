extends BodypartHead

func _init():
	visibleName = "Rathalos Head"
	id = "sRathalosHead"

func getCompatibleSpecies():
	return ["sRathalos"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Head/Rathalos_Head.tscn"

func getHeadLength():
	return 0.75
