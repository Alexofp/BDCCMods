extends BodypartEars

func _init():
	visibleName = "Rathalos ears"
	id = "sRathalosEars"

func getCompatibleSpecies():
	return ["sRathalos"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Ears/Rathalos_Ears.tscn"
