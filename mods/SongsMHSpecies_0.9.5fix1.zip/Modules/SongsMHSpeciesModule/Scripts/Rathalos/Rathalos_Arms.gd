extends BodypartArms

func _init():
	visibleName = "Rathalos arms"
	id = "sRathalosArms"

func getCompatibleSpecies():
	return ["sRathalos"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Arms/Rathalos_Arm.tscn"
