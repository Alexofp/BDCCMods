extends BodypartArms

func _init():
	visibleName = "Rathalos buff arms"
	id = "sRathalosArmsBuff"

func getCompatibleSpecies():
	return ["sRathalos"]

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Arms/Rathalos_BuffArm.tscn"
	
func getTraits():
	return {
		PartTrait.ArmsBuff: true,
	}
