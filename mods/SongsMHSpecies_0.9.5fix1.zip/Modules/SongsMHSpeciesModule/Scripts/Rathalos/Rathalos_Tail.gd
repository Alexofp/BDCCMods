extends BodypartTail

func _init():
	visibleName = "Rathalos tail"
	id = "sRathalosTail"

func getCompatibleSpecies():
	return ["sRathalos"]

func getLewdSizeAdjective():
	return RNG.pick(["long"])

func getLewdAdjective():
	return RNG.pick(["scaly", "dragon"])

func getDoll3DScene():
	return "res://Modules/SongsMHSpeciesModule/Pngs/Rathalos/Rathalos_Tail/Rathalos_Tail.tscn"

func getTraits():
	return {
		PartTrait.TailFlexible: true,
	}
