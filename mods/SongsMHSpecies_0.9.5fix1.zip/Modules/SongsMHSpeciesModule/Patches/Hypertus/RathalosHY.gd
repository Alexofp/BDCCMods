extends "res://Modules/Z_Hypertus/Misc/SpeciesExtend.gd"

func _init():
	id = "sRathalos"
	
func getVisibleName():
	return "Rathalos"

func getDefaultLegs(_gender):
	return "sRathalosLegs"

func getDefaultTail(_gender):
	return "sRathalosTail"

func isPlayable():
	return true

func getVisibleDescription():
	return "Fire Wyvern"

func getDefaultHead(_gender):
	return "sRathalosHead"

func getDefaultArms(_gender):
	return "sRathalosArms"

func getDefaultEars(_gender):
	return "sRathalosEars"

func getDefaultBody(_genger):
	return "sRathalosbody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "sRathalosPenisHY"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[1, 4.0],
		[2, 5.0],
		[3, 2.0],
	]

## Will make every generated npc bald if uncommented
func onDynamicNpcCreation(_npc, _args):
	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func generateSkinColors():
	var colorpalette = [

		["#8d4b3a", "#5d372d", "#482d25"], 
		["#923d34", "#432821", "#432821"], 
		["#a54d60", "#4a1923", "#4a1923"],
		["#e26b78", "#722d3b", "#461f25"],
		#rathian
		["#859972", "#607844", "#31452b"],
		["#5a6e4d", "#353e2a", "#2d352a"],
	]
	
	var skincolor = RNG.pick(colorpalette)
	return [Color(skincolor[0]), Color(skincolor[1]), Color(skincolor[2])]
